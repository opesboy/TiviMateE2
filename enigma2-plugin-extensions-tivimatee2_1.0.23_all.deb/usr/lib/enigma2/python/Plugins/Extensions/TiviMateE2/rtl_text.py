# -*- coding: utf-8 -*-
"""Apply bundled Greta Arabic to TiviMateE2 labels without altering Enigma2 fonts.

OpenATV's skin.reloadSkins() calls enigma.clearFonts().  A registration
made earlier in a plugin import is *not* durable.  Look up the font face at
use time and restore it if the skin font table has been cleared.  Do not use
the global replacement flag (which would affect every Enigma2 screen).
"""

import os
import unicodedata

from Components.Label import Label
from enigma import gFont

_FONT_PATH = os.path.join(os.path.dirname(__file__), "skins", "fonts", "Greta.ttf")
_FONT_FACE = "TiviMateGreta"
_registered_without_query = False
_warned = set()


def _warn_once(key, message):
    if key not in _warned:
        _warned.add(key)
        print("[TiviMateE2][Greta] %s" % message)


def _faces():
    """Return the native OpenATV face list; None on older images."""
    try:
        from enigma import getFontFaces
        return getFontFaces()
    except (ImportError, AttributeError, TypeError):
        return None
    except Exception as exc:
        _warn_once("font-list", "Unable to query font faces: %s" % exc)
        return None


def register_greta():
    """Ensure our private alias exists in the current Enigma2 font table.

    Avoid caching a success flag when getFontFaces is supported.  A skin
    reload can invalidate earlier addFont calls without restarting Python.
    """
    global _registered_without_query
    if not os.path.isfile(_FONT_PATH):
        _warn_once("missing", "Font file missing: %s" % _FONT_PATH)
        return False

    faces = _faces()
    if faces is not None and _FONT_FACE in faces:
        return True
    if faces is None and _registered_without_query:
        return True

    try:
        from enigma import addFont
        # The fourth argument selects the global Arabic replacement font.
        # Keep it at 0: this font is private to TiviMateE2 widgets.
        try:
            addFont(_FONT_PATH, _FONT_FACE, 100, 0, 0)
        except TypeError:
            addFont(_FONT_PATH, _FONT_FACE, 100, 0)
        faces = _faces()
        if faces is not None and _FONT_FACE not in faces:
            _warn_once("register-check", "Native font was not registered: %s" % _FONT_FACE)
            return False
        _registered_without_query = True
        print("[TiviMateE2][Greta] Active font: %s" % _FONT_FACE)
        return True
    except Exception as exc:
        _warn_once("registration", "Font registration failed: %s" % exc)
        return False


def has_arabic_text(value):
    """Match Arabic text, including presentation forms, not Latin metadata."""
    for char in str(value or ""):
        cp = ord(char)
        if ((0x0600 <= cp <= 0x06FF or 0x0750 <= cp <= 0x077F or
             0x08A0 <= cp <= 0x08FF or 0xFB50 <= cp <= 0xFDFF or
             0xFE70 <= cp <= 0xFEFF) and
                unicodedata.bidirectional(char) in ("AL", "R")):
            return True
    return False


class DirectionalLabel(Label):
    """Use Greta Arabic in this plugin's native eLabel, not system fonts.

    Enigma2's label is initially skinned before movie metadata becomes ready.
    The native skin must therefore already contain the Greta face, even when
    the label starts empty; waiting for setText (the old approach) is not
    sufficient on all OpenATV/Pure2 variants.  LTR text restores the exact
    original skin font at paint time. This component never calls addFont with
    replacement=1 and never affects unrelated Enigma2 screens.
    """

    def __init__(self, text=""):
        self._directional_value = str(text or "")
        self._regular_font = None
        self._skin_halign = "left"
        self._skin_font_prepared = False
        Label.__init__(self, text)

    def _read_skin_attributes(self):
        for key, value in (getattr(self, "skinAttributes", None) or []):
            if key == "font" and self._regular_font is None:
                try:
                    family, size = str(value).rsplit(";", 1)
                    size = int(size)
                    if family and size > 0 and family != _FONT_FACE:
                        self._regular_font = (family, size)
                except (ValueError, TypeError):
                    pass
            elif str(key).lower() in ("halign", "horizontalalignment"):
                self._skin_halign = str(value).strip().lower()

    def _apply_direction(self):
        widget = getattr(self, "instance", None)
        if widget is None:
            return
        arabic = has_arabic_text(self._directional_value)
        if self._regular_font is None:
            self._read_skin_attributes()
        # Preserve original alignments for buttons and labels deliberately
        # centered in the design. Only ordinary left-aligned Arabic text
        # becomes right-aligned.
        if self._skin_halign not in ("center", "centre", "block"):
            try:
                widget.setHAlign(2 if arabic or self._skin_halign == "right" else 0)
            except Exception:
                pass
        if self._regular_font is None:
            return
        family, size = self._regular_font
        face = _FONT_FACE if arabic and register_greta() else family
        try:
            widget.setFont(gFont(face, size))
        except Exception as exc:
            _warn_once("native-font", "Could not apply label font: %s" % exc)

    def setText(self, value):
        self._directional_value = str(value or "")
        Label.setText(self, value)
        self._apply_direction()

    def _set_text_property(self, value):
        self.setText(value)

    # VariableText.text stores the base setter; override direct property use.
    text = property(Label.getText, _set_text_property)

    def applySkin(self, desktop, parent):
        self._read_skin_attributes()
        # IMPORTANT: a label may begin with empty text. Install the private
        # face in the native XML *before* the skin parser paints the widget.
        # This is the actual change from the previous font refresh builds.
        if self._regular_font and register_greta():
            old = self.skinAttributes or []
            self.skinAttributes = [
                (key, "%s;%d" % (_FONT_FACE, self._regular_font[1]))
                if key == "font" else (key, value)
                for key, value in old
            ]
            self._skin_font_prepared = True
        applied = Label.applySkin(self, desktop, parent)
        # The skin may have changed the native font in Label.applySkin.
        self._apply_direction()
        return applied

    def postWidgetCreate(self, instance):
        Label.postWidgetCreate(self, instance)
        # On Pure2 and older images native widgets may be created before all
        # attributes exist; applySkin does the final update later.
        self._read_skin_attributes()
        self._apply_direction()

    def onShow(self):
        try:
            Label.onShow(self)
        except Exception:
            pass
        # Reapply after returning to a previous screen, including skin switch.
        self._apply_direction()
