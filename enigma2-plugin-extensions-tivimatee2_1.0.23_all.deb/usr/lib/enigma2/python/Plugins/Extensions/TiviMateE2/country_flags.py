# -*- coding: utf-8 -*-
"""On-demand country flags for Movie and Series details.

TMDb supplies the production/origin country. The flag is downloaded only for
that country, in a separate, bounded worker pool (not the busy poster queue).
Small PNGs are cached on the configured HDD/USB/internal artwork root.
All Enigma widgets are updated from the GUI thread and late results cannot
replace the flag of a different screen/selection.
"""
import os
import re
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen
from urllib.error import URLError

_CODE = re.compile(r"^[A-Z]{2}$")
_COUNTRY_CACHE = {}
_COUNTRY_LOCK = threading.RLock()
_POOL = ThreadPoolExecutor(max_workers=2)
_FAIL_TTL = 120
_COUNTRY_TTL = 43200
_NETWORK_STATUS = threading.local()


def country_code(bundle, kind):
    if not isinstance(bundle, dict):
        return ""
    is_tv = str(kind or "").lower() in ("series", "tv", "shows")
    fields = ("origin_country", "production_countries") if is_tv else ("production_countries", "origin_country")
    for field in fields:
        rows = bundle.get(field) or []
        if isinstance(rows, dict):
            rows = [rows]
        if not isinstance(rows, (tuple, list)):
            continue
        for row in rows:
            raw = (row.get("iso_3166_1") or row.get("country_code")) if isinstance(row, dict) else row
            code = str(raw or "").strip().upper()
            if _CODE.fullmatch(code):
                return code
    return ""


def country_flag_url(bundle, kind):
    code = country_code(bundle, kind)
    return "https://flagcdn.com/w80/%s.png" % code.lower() if code else ""


def _flags_dir():
    from .cache_manager import get_cache_dir
    return get_cache_dir("flags")


def _flag_path(code):
    return os.path.join(_flags_dir(), "country_%s.png" % code.lower())


def _valid_png(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) < 80:
            return False
        with open(path, "rb") as f:
            header = f.read(24)
        return (len(header) == 24 and header[:8] == b"\x89PNG\r\n\x1a\n"
                and header[12:16] == b"IHDR"
                and int.from_bytes(header[16:20], "big") > 0
                and int.from_bytes(header[20:24], "big") > 0)
    except Exception:
        return False


def country_flag_path(bundle, kind):
    code = country_code(bundle, kind)
    if not code:
        return ""
    path = _flag_path(code)
    return path if _valid_png(path) else ""


def _download(url):
    _NETWORK_STATUS.last = "unknown"
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0",
        "Accept": "image/png,image/*;q=0.8",
    })
    # Older Enigma2 receivers may have an outdated CA bundle. First attempt
    # verified TLS and use the same last-resort image-only SSL compatibility as
    # the existing artwork helper, restricted to known fixed flag hosts.
    try:
        try:
            response = urlopen(request, timeout=7)
        except (ssl.SSLCertVerificationError, URLError) as exc:
            cause = getattr(exc, "reason", exc)
            # urllib commonly wraps certificate failures in URLError.
            if not isinstance(cause, ssl.SSLCertVerificationError):
                raise
            response = urlopen(request, timeout=7, context=ssl._create_unverified_context())
        with response:
            data = response.read(192 * 1024 + 1)
        if len(data) > 192 * 1024 or len(data) < 80:
            _NETWORK_STATUS.last = "invalid image size"
            return b""
        if (data[:8] != b"\x89PNG\r\n\x1a\n" or
                data[12:16] != b"IHDR"):
            _NETWORK_STATUS.last = "response is not PNG"
            return b""
        _NETWORK_STATUS.last = "ok"
        return data
    except Exception as exc:
        _NETWORK_STATUS.last = type(exc).__name__
        return b""


def _fetch_flag(code):
    """Dedicated fetch; never block on poster/backdrop downloads."""
    path = _flag_path(code)
    if _valid_png(path):
        return path
    sources = (
        "https://flagcdn.com/w80/%s.png" % code.lower(),
        "https://flagsapi.com/%s/flat/64.png" % code,
    )
    failures = []
    for url in sources:
        data = _download(url)
        if not data:
            failures.append(url.split("/")[2] + ": " + str(getattr(_NETWORK_STATUS, "last", "unknown")))
            continue
        temp = "%s.part.%s.%s" % (path, os.getpid(), threading.get_ident())
        try:
            with open(temp, "wb") as fh:
                fh.write(data)
            if not _valid_png(temp):
                continue
            os.replace(temp, path)
            return path
        except Exception:
            pass
        finally:
            try:
                if os.path.exists(temp):
                    os.unlink(temp)
            except Exception:
                pass
    # Keep one tiny diagnostic record. If both flag hosts are blocked by the
    # receiver's DNS/TLS/firewall, the next failure can be diagnosed accurately
    # without guessing or adding any image to the IPK.
    try:
        with open(os.path.join(_flags_dir(), "last_download_failure.txt"), "w") as f:
            f.write("Country: %s\n%s\n" % (code, "\n".join(failures)))
    except Exception:
        pass
    return ""


def _country_from_tmdb(kind, tmdb_id):
    key = ("tv" if kind in ("tv", "series") else "movie", str(tmdb_id))
    now = time.time()
    with _COUNTRY_LOCK:
        cached = _COUNTRY_CACHE.get(key)
        if cached and now - cached[1] < (_COUNTRY_TTL if cached[0] else _FAIL_TTL):
            return cached[0]
    country = ""
    try:
        from .tmdb_client import TMDbClient
        # Request only metadata for the resolved TMDb ID. This request is run
        # in the flag worker, never on the UI thread.
        payload = TMDbClient()._get("/%s/%s" % key, {"language": "en-US"}) or {}
        country = country_code(payload, kind)
    except Exception:
        pass
    with _COUNTRY_LOCK:
        if len(_COUNTRY_CACHE) > 256:
            _COUNTRY_CACHE.clear()
        _COUNTRY_CACHE[key] = (country, time.time())
    return country


def _fallback_draw(widget, path, token):
    if getattr(widget, "_tivimate_flag_token", None) != token:
        return
    try:
        if widget.instance and _valid_png(path):
            widget.instance.setPixmapFromFile(path)
            widget.show()
    except Exception:
        pass


def _decode_flag(widget, path, token):
    if not path or getattr(widget, "_tivimate_flag_token", None) != token:
        return
    try:
        if not widget.instance:
            return
        from enigma import ePicLoad, eTimer
        from .picload_compat import connect_picture_data
        loader = ePicLoad()
        widget._tivimate_flag_loader = loader

        def ready(_info=None):
            if (getattr(widget, "_tivimate_flag_token", None) != token or
                    getattr(widget, "_tivimate_flag_loader", None) is not loader):
                return
            try:
                pix = loader.getData()
                if pix and widget.instance:
                    widget.instance.setPixmap(pix)
                    widget.show()
                    widget._tivimate_flag_rendered = token
                else:
                    _fallback_draw(widget, path, token)
            except Exception:
                _fallback_draw(widget, path, token)
            finally:
                if getattr(widget, "_tivimate_flag_loader", None) is loader:
                    widget._tivimate_flag_loader = None

        conn = connect_picture_data(loader, ready, widget, oneshot=True)
        if conn is None:
            _fallback_draw(widget, path, token)
            return
        size = widget.instance.size()
        w = max(1, size.width())
        h = max(1, size.height())
        loader.setPara((w, h, 0, 0, False, 1, "#00000000"))
        result = loader.startDecode(path)
        if isinstance(result, int) and result < 0:
            _fallback_draw(widget, path, token)
            return

        # Some Enigma2 builds silently fail to emit PictureData for tiny PNGs.
        # Fallback to the known-working Pixmap.setPixmapFromFile path after a
        # short timeout, without replacing a successful decoded image.
        timer = eTimer()
        widget._tivimate_flag_fallback_timer = timer
        def timeout():
            if (getattr(widget, "_tivimate_flag_token", None) == token and
                    getattr(widget, "_tivimate_flag_rendered", None) != token):
                _fallback_draw(widget, path, token)
            try:
                timer.stop()
            except Exception:
                pass
            if getattr(widget, "_tivimate_flag_fallback_timer", None) is timer:
                widget._tivimate_flag_fallback_timer = None
        try:
            widget._tivimate_flag_timer_conn = timer.timeout.connect(timeout)
        except Exception:
            timer.callback.append(timeout)
        timer.start(800, True)
    except Exception:
        _fallback_draw(widget, path, token)


def _gui_on_ready(widget, token, path):
    if getattr(widget, "_tivimate_flag_token", None) == token and path:
        _decode_flag(widget, path, token)


def _worker(kind, tmdb_id, code):
    if not code and tmdb_id:
        code = _country_from_tmdb(kind, tmdb_id)
    if not code:
        return ""
    return _fetch_flag(code)


def show_country_flag(widget, bundle, kind, tmdb_id=None):
    """Display only a valid country flag for this details screen."""
    try:
        token = int(getattr(widget, "_tivimate_flag_token", 0)) + 1
        widget._tivimate_flag_token = token
        widget._tivimate_flag_rendered = None
        try:
            old_timer = getattr(widget, "_tivimate_flag_fallback_timer", None)
            if old_timer:
                old_timer.stop()
        except Exception:
            pass
        widget.hide()
        code = country_code(bundle, kind)
        if code:
            path = country_flag_path(bundle, kind)
            if path:
                _decode_flag(widget, path, token)
                return True
        candidate = str(tmdb_id or (bundle or {}).get("id") or "").strip()
        if not code and (not candidate.isdigit() or int(candidate) < 1):
            return False
        # Results arrive on the Enigma2 GUI thread; the worker performs all
        # network and file I/O, independently of the poster artwork queue.
        try:
            from twisted.internet import reactor
            def deliver(future):
                try:
                    path = future.result()
                except Exception:
                    path = ""
                reactor.callFromThread(_gui_on_ready, widget, token, path)
            _POOL.submit(_worker, kind, candidate if not code else None, code).add_done_callback(deliver)
        except Exception:
            # Pure2 images without Twisted callbacks use one short-lived GUI
            # poller. It does not perform downloads on the UI thread.
            from enigma import eTimer
            future = _POOL.submit(_worker, kind, candidate if not code else None, code)
            timer = eTimer()
            widget._tivimate_flag_poll_timer = timer
            def poll():
                if getattr(widget, "_tivimate_flag_token", None) != token:
                    timer.stop()
                    return
                if future.done():
                    timer.stop()
                    try:
                        _gui_on_ready(widget, token, future.result())
                    except Exception:
                        pass
                else:
                    timer.start(250, True)
            try:
                widget._tivimate_flag_poll_conn = timer.timeout.connect(poll)
            except Exception:
                timer.callback.append(poll)
            timer.start(250, True)
        return True
    except Exception:
        return False
