# -*- coding: utf-8 -*-
"""Shared VOD / TV-series poster policy for every TiviMateE2 page.

Vertical poster assets only.  GENRE, ContentHomeScreen, MediaScreen and other
screens keep their independent widget dimensions and visual styling.
"""
from . import artwork_queue as _queue

KIND = "posters"
PROVIDER_KEYS = (
    "stream_icon", "movie_image", "cover", "cover_big", "poster",
    "poster_url", "poster_path", "screenshot_uri", "image",
)


def provider_poster_url(source, item, extra=None):
    return _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)


def tmdb_poster_url(value):
    """Accept the absolute image URL or a TMDb poster_path; never a backdrop."""
    value = str(value or "").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/w500" + value
    return value if value.startswith(("https://", "http://")) else ""


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None):
    return _queue._request_artwork_core(url, KIND, callback, priority, errback)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
