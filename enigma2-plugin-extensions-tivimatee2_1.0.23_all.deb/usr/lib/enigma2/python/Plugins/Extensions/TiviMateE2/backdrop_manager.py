# -*- coding: utf-8 -*-
"""Shared backdrop policy for TiviMateE2 backgrounds and landscape artwork."""
from . import artwork_queue as _queue

KIND = "backdrops"
PROVIDER_KEYS = (
    "backdrop_path", "backdrop", "backdrop_url", "movie_backdrop",
    "fanart", "background", "screenshot_uri",
)


def provider_backdrop_url(source, item, extra=None):
    return _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)


def tmdb_backdrop_url(value, size="original"):
    value = str(value or "").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/%s" % size + value
    return value if value.startswith(("https://", "http://")) else ""


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None):
    return _queue._request_artwork_core(url, KIND, callback, priority, errback)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
