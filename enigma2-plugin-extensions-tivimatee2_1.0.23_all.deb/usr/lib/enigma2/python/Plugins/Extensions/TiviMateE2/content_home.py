# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
from .package_logos import package_logo_path, package_provider_key, package_logo_for_key
import os, time, json, hashlib, threading, random
from collections import OrderedDict
import queue as _queue
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from .rtl_text import DirectionalLabel
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from enigma import eServiceReference, ePicLoad, eConsoleAppContainer, ePoint, eTimer, eSize
try:
    from twisted.internet import reactor
except Exception:
    reactor = None
from .core import get_source_client, get_cached_catalog
from .filters import filter_items as filter_items_for_source
from .tmdb_client import TMDbClient, load_settings, backdrop_url, preferred_metadata_text
from .logo_manager import (logo_language, image_languages, best_tmdb_logo,
                           tmdb_logo_url, has_language_logo, localized_logo_url)
from .rating_cache import split_ranked, enrich_missing
from .tmdb_score_circle import show_score
from .country_flags import show_country_flag
from .filters import get_filtered_streams, get_allowed_category_ids, filter_categories, get_category_streams, get_category_streams_batch, get_cached_categories, get_stalker_landing_items, peek_category_streams_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
from difflib import SequenceMatcher
import re
from urllib.parse import urlparse, quote

from .cache_manager import get_cache_dir
from .artwork_queue import request_artwork, prefetch_artwork, artwork_path, cached_artwork
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, sx, sy, scale_size
from .i18n import tr, get_language, nav_label
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"


# Per-server movie recommendation backdrop paths. Persist on the configured
# artwork cache drive, not in /tmp or in IPTV server configuration files.
_RECOMMEND_BACKDROP_LOCK = threading.RLock()
_RECOMMEND_BACKDROP_INDEX = {}
_RECOMMEND_BACKDROP_ROOT = None


def _recommend_backdrop_key(source, row):
    source = source or {}
    row = row or {}
    identity = [
        str(source.get(k) or "") for k in ("type", "url", "portal", "username", "mac")
    ]
    identity.extend(str(row.get(k) or "") for k in (
        "stream_id", "vod_id", "id", "category_id", "name", "title", "year", "release_date"
    ))
    return hashlib.sha1("\x1f".join(identity).encode("utf-8", "ignore")).hexdigest()


def _recommend_backdrop_index():
    global _RECOMMEND_BACKDROP_ROOT, _RECOMMEND_BACKDROP_INDEX
    try:
        folder = os.path.join(get_cache_dir(), "recommendations")
    except Exception:
        return {}
    with _RECOMMEND_BACKDROP_LOCK:
        if _RECOMMEND_BACKDROP_ROOT != folder:
            _RECOMMEND_BACKDROP_ROOT = folder
            try:
                with open(os.path.join(folder, "backdrops.json"), "r") as handle:
                    loaded = json.load(handle)
                _RECOMMEND_BACKDROP_INDEX = loaded if isinstance(loaded, dict) else {}
            except Exception:
                _RECOMMEND_BACKDROP_INDEX = {}
        return _RECOMMEND_BACKDROP_INDEX


def _recommend_backdrop_get(source, row):
    key = _recommend_backdrop_key(source, row)
    with _RECOMMEND_BACKDROP_LOCK:
        data = _recommend_backdrop_index().get(key) or {}
        return dict(data) if isinstance(data, dict) else {}


def _recommend_backdrop_put(source, row, backdrop, tmdb_id):
    if not isinstance(backdrop, str) or not backdrop.strip():
        return
    key = _recommend_backdrop_key(source, row)
    with _RECOMMEND_BACKDROP_LOCK:
        cache = _recommend_backdrop_index()
        if not _RECOMMEND_BACKDROP_ROOT:
            return
        cache[key] = {"backdrop_path": backdrop.strip(), "tmdb_id": str(tmdb_id or ""), "at": int(time.time())}
        if len(cache) > 1500:
            keep = sorted(cache.items(), key=lambda x: int((x[1] or {}).get("at") or 0), reverse=True)[:1200]
            cache.clear()
            cache.update(keep)
        try:
            os.makedirs(_RECOMMEND_BACKDROP_ROOT, exist_ok=True)
            destination = os.path.join(_RECOMMEND_BACKDROP_ROOT, "backdrops.json")
            tmp = destination + ".tmp"
            with open(tmp, "w") as handle:
                json.dump(cache, handle, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, destination)
        except Exception:
            pass

CONTENT_LANDING_CACHE_DIR = data_path("content_landing")
TITLE_MATCH_CACHE_FILE = data_path("title_matches.json")
HOME_FEED_CACHE_FILE = data_path("home_feeds.json")
_HOME_FEED_CACHE_LOCK = threading.Lock()
_HOME_FEED_CACHE_MAX_AGE = 7 * 24 * 3600

def _package_diag(event, **fields):
    return None

def _home_feed_cache_load():
    try:
        with _HOME_FEED_CACHE_LOCK:
            with open(HOME_FEED_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _home_feed_cache_save(data):
    try:
        with _HOME_FEED_CACHE_LOCK:
            folder = os.path.dirname(HOME_FEED_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = HOME_FEED_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, HOME_FEED_CACHE_FILE)
        return True
    except Exception:
        return False


def _home_feed_cache_key(mode, source=None):
    source = source or {}
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source) or "")
    except Exception:
        source_key = str(source.get("name") or source.get("url") or "")
    return "%s|%s" % (str(mode or "popular_movies"), source_key)


def _home_feed_cache_get(mode, source=None, allow_stale=True):
    data = _home_feed_cache_load()
    row = data.get(_home_feed_cache_key(mode, source)) or {}
    if not isinstance(row, dict):
        return []
    try:
        age = int(time.time()) - int(row.get("updated") or 0)
    except Exception:
        age = _HOME_FEED_CACHE_MAX_AGE + 1
    mode_text = str(mode or "")
    if mode_text.startswith("backdrop_filtered_smart_") or mode_text.startswith("backdrop_all_enabled_"):
        # Package Backdrop selection stays fixed for exactly 6 hours.
        max_age = 6 * 60 * 60
    elif mode_text.startswith("you_might_like_server_"):
        max_age = 12 * 60 * 60
    else:
        max_age = _HOME_FEED_CACHE_MAX_AGE
    if not allow_stale and age > max_age:
        return []
    items = row.get("items") or []
    return [dict(x) for x in items if isinstance(x, dict)]


def _home_feed_cache_put(mode, source, items):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)]
    if not rows:
        return False
    data = _home_feed_cache_load()
    data[_home_feed_cache_key(mode, source)] = {
        "updated": int(time.time()),
        "items": rows[:30],
    }
    # Bound persistent cache.
    if len(data) > 100:
        ordered = sorted(
            data.items(),
            key=lambda kv: int((kv[1] or {}).get("updated") or 0),
            reverse=True
        )[:80]
        data = dict(ordered)
    return _home_feed_cache_save(data)


_TITLE_MATCH_CACHE_LOCK = threading.Lock()


def _title_match_cache_load():
    try:
        with _TITLE_MATCH_CACHE_LOCK:
            with open(TITLE_MATCH_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _title_match_cache_save(data):
    try:
        with _TITLE_MATCH_CACHE_LOCK:
            folder = os.path.dirname(TITLE_MATCH_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = TITLE_MATCH_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, TITLE_MATCH_CACHE_FILE)
        return True
    except Exception:
        return False


def _title_match_key(source, item):
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source or {}) or "")
    except Exception:
        source_key = str((source or {}).get("name") or (source or {}).get("url") or "")
    item = item or {}
    tid = str(item.get("tmdb_id") or item.get("id") or "").strip()
    title = str(item.get("_tmdb_title") or item.get("name") or item.get("title") or item.get("original_title") or "").strip().lower()
    year = str(item.get("year") or item.get("release_date") or item.get("releaseDate") or "")[:4]
    return "%s|%s|%s|%s" % (source_key, tid, title, year)


def _title_match_cache_status(source, item):
    """Return (cached, match).

    cached=True with match=None is a real cached miss. This prevents the same
    unsuccessful automatic title search from running again every time details open.
    """
    key = _title_match_key(source, item)
    data = _title_match_cache_load()
    if key not in data:
        return False, None
    row = data.get(key)
    if not isinstance(row, dict):
        return False, None
    if row.get("miss") is True:
        return True, None
    match = row.get("match")
    if isinstance(match, dict):
        return True, dict(match)
    return False, None


def _title_match_cache_get(source, item):
    cached, match = _title_match_cache_status(source, item)
    return match if cached and isinstance(match, dict) else None


def _title_match_cache_put(source, item, match):
    data = _title_match_cache_load()
    key = _title_match_key(source, item)
    if isinstance(match, dict):
        data[key] = {"match": dict(match), "miss": False, "updated": int(time.time())}
    elif match is None:
        # Cache "not found" too. The poster/details placeholder can therefore stay
        # stable without repeating an expensive server search on every open.
        data[key] = {"match": None, "miss": True, "updated": int(time.time())}
    else:
        return False
    if len(data) > 1200:
        ordered = sorted(data.items(), key=lambda kv: int((kv[1] or {}).get("updated") or 0), reverse=True)[:1000]
        data = dict(ordered)
    return _title_match_cache_save(data)



# Unified artwork policies; preserve old helper names for other modules.
from .artwork_queue import provider_asset_url as _server_asset_url
from .poster_manager import provider_poster_url as _server_poster_url
from .backdrop_manager import provider_backdrop_url as _server_backdrop_url

def _content_landing_cache_path(source, kind):
    try:
        raw = "%s|%s|%s|%s|%s" % (
            source.get("type") or "", source.get("url") or source.get("portal") or "",
            source.get("username") or "", source.get("mac") or "", kind or ""
        )
        digest = hashlib.md5(raw.encode("utf-8")).hexdigest()
        return os.path.join(CONTENT_LANDING_CACHE_DIR, digest + ".json")
    except Exception:
        return ""

def _load_content_landing_cache(source, kind):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path or not os.path.exists(path):
            return []
        with open(path, "r") as fh:
            data = json.load(fh)
        return list(data.get("items") or [])[:64] if isinstance(data, dict) else []
    except Exception:
        return []

def _save_content_landing_cache(source, kind, items):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path:
            return
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({"saved": int(time.time()), "items": list(items or [])[:64]}, fh)
        try:
            os.replace(tmp, path)
        except AttributeError:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
    except Exception:
        pass

# Fixed-size background pool for frequent ContentHome artwork/category jobs.
# Navigation can generate requests much faster than slow portals/TMDb can answer;
# a thread-per-keypress design eventually exhausts Enigma2.  Keep only four
# workers and coalesce stale jobs by logical key instead.
_CONTENT_BG_QUEUE = _queue.Queue(maxsize=128)
_CONTENT_BG_LOCK = threading.RLock()
_CONTENT_BG_LATEST = {}
_CONTENT_BG_STARTED = [False]
_CONTENT_BG_WORKERS = 4

def _content_bg_worker(index):
    while True:
        try:
            target, args, key, generation = _CONTENT_BG_QUEUE.get()
        except Exception:
            continue
        try:
            if key is not None:
                try:
                    with _CONTENT_BG_LOCK:
                        if _CONTENT_BG_LATEST.get(key) != generation:
                            continue
                except Exception:
                    pass
            try:
                target(*args)
            except Exception:
                pass
        finally:
            try:
                _CONTENT_BG_QUEUE.task_done()
            except (ValueError, AttributeError):
                pass

def _ensure_content_bg_workers():
    with _CONTENT_BG_LOCK:
        if _CONTENT_BG_STARTED[0]:
            return
        _CONTENT_BG_STARTED[0] = True
        for index in range(_CONTENT_BG_WORKERS):
            worker = threading.Thread(target=_content_bg_worker, args=(index,), name="TiviMateContentPool-%d" % (index + 1))
            worker.daemon = True
            worker.start()

def _submit_content_bg(target, args=(), key=None):
    _ensure_content_bg_workers()
    generation = 0
    if key is not None:
        with _CONTENT_BG_LOCK:
            generation = int(_CONTENT_BG_LATEST.get(key, 0) or 0) + 1
            _CONTENT_BG_LATEST[key] = generation
    try:
        _CONTENT_BG_QUEUE.put_nowait((target, tuple(args or ()), key, generation))
        return True
    except Exception:
        # A saturated queue is safer than allocating more receiver threads.
        # Visible cards/categories naturally request again on the next user move.
        return False

IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")

# Keep recently decoded pixmaps alive in RAM. This avoids ePicLoad decoding again
# when the user reopens the same movie during the current Enigma2 session.
_DETAILS_PIXMAP_CACHE = OrderedDict()
# Decoded pixmaps consume RAM on the receiver.  Keep a small LRU only while a
# details page is open; the full-quality source remains in the disk cache.
_DETAILS_PIXMAP_CACHE_LIMIT = 8
_DETAILS_DATA_CACHE = OrderedDict()
_DETAILS_DATA_CACHE_LIMIT = 24

def _tmdb_details_memory_key(key):
    """Isolate in-memory metadata by the user's configured TMDb language."""
    try:
        lang = TMDbClient().language
    except Exception:
        lang = "en-US"
    return "%s:%s" % (str(lang), str(key))

def _memory_get(cache, key):
    try:
        value = cache.pop(key)
        cache[key] = value
        return value
    except Exception:
        return None

def _memory_put(cache, key, value, limit):
    try:
        if key in cache:
            cache.pop(key)
        cache[key] = value
        while len(cache) > limit:
            cache.popitem(last=False)
    except Exception:
        pass


HOME_APPEARANCE_FILE = data_path("home_appearance.json")

def _content_default_mode(kind):
    """Movies and TV Shows default to no lower poster feed."""
    try:
        with open(HOME_APPEARANCE_FILE, "r") as handle:
            data = json.load(handle) or {}
        key = "movies_content" if kind == "vod" else "series_content"
        return "none"
    except Exception:
        return "none"


def _content_mode_title(kind, mode):
    is_movies = kind == "vod"
    mode = str(mode or "none").strip().lower()
    if mode == "none":
        return ""
    if mode == "prime":
        return "Prime Video Movies" if is_movies else "Prime Video TV Shows"
    return "Netflix Movies" if is_movies else "Netflix TV Shows"


def _hero_preview_summary(value, limit=175):
    """Keep the Movies/Series hero summary above its action buttons.

    Full metadata is retained for the details screen.  Only the short preview
    shown on the banner is compacted, without changing text language or order.
    """
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    text = text[:limit].rsplit(" ", 1)[0].rstrip()
    return (text or str(value or "")[:limit]).rstrip(" .,؛،") + "…"


CONTENT_HOME = '''<screen name="ContentHomeScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">
<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />
<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/content_overlay.png" alphatest="blend" zPosition="2" />
<ePixmap position="0,0" size="1920,125" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/vod_nav_wave85_only.png" alphatest="blend" zPosition="3" />
<ePixmap position="20,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="46,15" size="140,64" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="190,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="216,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="360,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="386,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="530,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="556,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="700,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="726,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="870,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="896,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1040,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/genre.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1066,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1210,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1236,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1380,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/server_finder.png" alphatest="blend" zPosition="7" />
<widget name="top8" position="1406,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1550,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top9" position="1576,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1720,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/favorites.png" alphatest="blend" zPosition="7" />
<widget name="top10" position="1746,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<widget name="topSelector" position="312,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
<ePixmap position="1500,398" size="300,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_logo_badge_wide.png" alphatest="blend" zPosition="5" />
<widget name="logoHintIcon" position="1522,420" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/logo_hint_icon.png" alphatest="blend" zPosition="6" />
<widget name="logoHint" position="1580,410" size="190,64" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="logoImage" position="1520,412" size="260,60" alphatest="blend" zPosition="7" />
<widget name="logoTitle" position="95,132" size="1040,82" font="Regular;52" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4" />
<widget name="heroMeta" position="100,226" size="1050,40" font="Regular;26" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4" />
<widget name="heroDesc" position="100,276" size="1060,106" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="100,398" size="254,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_play_c.png" alphatest="blend" zPosition="5" />
<widget name="heroPlay" position="112,410" size="230,64" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<ePixmap position="368,398" size="284,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_info_c.png" alphatest="blend" zPosition="5" />
<widget name="heroInfo" position="380,410" size="260,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="backdropTitle" position="80,500" size="720,45" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="backdrop0" position="82,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="92,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="backdropRate0" position="92,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="backdropLabel0" position="148,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="backdrop1" position="537,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="547,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="backdropRate1" position="547,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="backdropLabel1" position="603,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="backdrop2" position="992,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1002,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="backdropRate2" position="1002,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="backdropLabel2" position="1058,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="backdrop3" position="1447,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1457,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="backdropRate3" position="1457,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="backdropLabel3" position="1513,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="rank0" position="94,565" size="130,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank1" position="549,565" size="130,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank2" position="1004,565" size="130,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank3" position="1459,565" size="130,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="backdropSelector" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_410x210.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="latestTitle" position="80,772" size="720,45" font="Regular;32" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="latestCategoryName" position="80,772" size="1000,45" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="8" />
	<widget name="latest0" position="82,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell0" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge0" position="88,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate0" position="88,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel0" position="142,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest1" position="297,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell1" position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge1" position="303,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate1" position="303,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel1" position="357,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest2" position="512,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell2" position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge2" position="518,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate2" position="518,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel2" position="572,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest3" position="727,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell3" position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge3" position="733,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate3" position="733,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel3" position="787,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest4" position="942,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell4" position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge4" position="948,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate4" position="948,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel4" position="1002,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest5" position="1157,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell5" position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge5" position="1163,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate5" position="1163,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel5" position="1217,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest6" position="1372,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell6" position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge6" position="1378,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate6" position="1378,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel6" position="1432,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest7" position="1587,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell7" position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge7" position="1593,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate7" position="1593,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel7" position="1647,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latestSelector" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_170x205.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="footer" position="85,1042" size="1750,35" font="Regular;20" foregroundColor="#D4D7DD" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
	<widget name="actionButtons" position="85,1041" size="1750,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/content_action_buttons_r115.png" alphatest="blend" zPosition="4" />
</screen>'''

CONTENT_HOME = scale_skin(CONTENT_HOME)

# Retired accessibility ContentHome skin removed.

CATEGORY_POPUP = '''<screen name="ServerCategoryList" position="300,120" size="1320,840" flags="wfNoBorder" backgroundColor="#071A2B">
<widget name="panel" position="0,0" size="1320,840" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/category_popup_panel.png" alphatest="blend" zPosition="0" />
<widget name="brand" position="28,28" size="230,48" font="Regular;35" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="brandTagline" position="31,78" size="220,26" font="Regular;15" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideTitle" position="28,150" size="230,32" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideText" position="28,192" size="230,120" font="Regular;24" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="packageLogo" position="30,380" size="220,84" alphatest="blend" zPosition="4" />
<widget name="sectionBadge" position="42,696" size="196,35" font="Regular;19" foregroundColor="#FFFFFF" backgroundColor="#0D324A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="sideHint" position="40,778" size="200,22" font="Regular;15" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="title" position="350,26" size="700,46" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="subtitle" position="350,74" size="650,28" font="Regular;26" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="count" position="1030,38" size="225,34" font="Regular;24" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="2" />
<widget name="listHeader" position="367,134" size="400,25" font="Regular;27" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="list" position="350,192" size="890,472" font="Regular;27" itemHeight="58" scrollbarMode="showOnDemand" backgroundColor="#0A2134" foregroundColor="#F5F8FC" selectionBackgroundColor="#E8B83F" selectionForegroundColor="#071A2B" zPosition="2" />
<widget name="keys" position="350,720" size="910,62" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="actionButtons" position="350,733" size="910,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/category_popup_buttons_r67.png" alphatest="blend" zPosition="3" />
</screen>'''

CATEGORY_POPUP = scale_skin(CATEGORY_POPUP)


# ---------------------------------------------------------------------------
# Content category list
# ---------------------------------------------------------------------------

class ServerCategoryList(Screen):
    skin = CATEGORY_POPUP
    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self.source, self.kind = source, kind
        self.rows = []
        is_movies = kind == "vod"
        self["panel"] = Pixmap()
        self["brand"] = Label(tr("TiViMate"))
        self["brandTagline"] = Label(tr("IPTV EXPERIENCE"))
        self["sideTitle"] = Label(tr("YOUR LIBRARY"))
        self["sideText"] = Label(tr("Choose a collection\nto browse titles from\nyour selected server."))
        self["sectionBadge"] = Label(tr("MOVIES") if is_movies else tr("TV SHOWS"))
        self["sideHint"] = Label(tr("Press OK to open"))
        self["packageLogo"] = Pixmap()
        self["title"] = Label(tr("MOVIE CATEGORIES") if is_movies else tr("TV SHOW CATEGORIES"))
        self["subtitle"] = Label(tr("Browse the collections available on your server"))
        self["count"] = Label(tr(""))
        self["listHeader"] = Label(tr("AVAILABLE COLLECTIONS"))
        self["list"] = MenuList([])
        self["keys"] = Label("")
        self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close, "up": self.up, "down": self.down,
            "pageUp": self.pageUp, "pageDown": self.pageDown
        }, -1)
        self._categoryLoadToken = 0
        self._categoryLoadResult = None
        self._categoryLoadClosed = False
        self._categoryLoadStartedAt = 0.0
        self._categoryLoadTimer = eTimer()
        self._packageLogoTimer = eTimer()
        try:
            self._packageLogoTimer_conn = self._packageLogoTimer.timeout.connect(self._updatePackageLogo)
        except Exception:
            try:
                self._packageLogoTimer.callback.append(self._updatePackageLogo)
            except Exception:
                self._packageLogoTimer.timeout.get().append(self._updatePackageLogo)
        try:
            self._categoryLoadTimer_conn = self._categoryLoadTimer.timeout.connect(self._finishCategoryLoad)
        except Exception:
            try:
                self._categoryLoadTimer.callback.append(self._finishCategoryLoad)
            except Exception:
                self._categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        try:
            self["list"].onSelectionChanged.append(self._updatePackageLogo)
        except Exception:
            pass
        self.onLayoutFinish.append(self.load)
        self.onClose.append(self._stopCategoryLoader)

    def _stopCategoryLoader(self):
        self._categoryLoadClosed = True
        self._categoryLoadToken += 1
        try:
            self._categoryLoadTimer.stop()
            self._packageLogoTimer.stop()
        except Exception:
            pass

    def load(self):
        self._categoryLoadToken += 1
        token = self._categoryLoadToken
        source = dict(self.source)
        kind = self.kind
        self._categoryLoadResult = None
        self._categoryLoadStartedAt = time.monotonic()
        self["count"].setText(tr(""))

        def worker():
            try:
                cats, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                cats = filter_categories(source, kind, cats or [])
                rows = [(entry.get("category_name") or "Other", str(entry.get("category_id") or "")) for entry in cats]
                result = (token, rows, origin, "")
            except Exception as exc:
                result = (token, [], "error", str(exc))
            if not self._categoryLoadClosed and token == self._categoryLoadToken:
                self._categoryLoadResult = result

        _submit_content_bg(worker, key=("category-popup", id(self)))
        try:
            self._categoryLoadTimer.start(200, True)
        except Exception:
            pass

    def _finishCategoryLoad(self):
        if self._categoryLoadClosed:
            return
        result = self._categoryLoadResult
        if not result:
            if time.monotonic() - self._categoryLoadStartedAt > 12.0:
                self._categoryLoadToken += 1
                self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
                self["subtitle"].setText(tr("Check the selected server and try again"))
                self["count"].setText(tr("NO COLLECTIONS"))
                return
            try:
                self._categoryLoadTimer.start(250, True)
            except Exception:
                pass
            return
        self._categoryLoadResult = None
        token, rows, origin, error = result
        if token != self._categoryLoadToken:
            return
        if error:
            self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
            self["subtitle"].setText(tr("Check the selected server and try again"))
            self["count"].setText(tr("NO COLLECTIONS"))
            self["keys"].setText(error[:120])
            return
        self.rows = rows or []
        self["list"].setList(self.rows)
        self._updatePackageLogo()
        try:
            self._packageLogoTimer.start(120, True)
        except Exception:
            pass
        count = len(self.rows)
        self["count"].setText("%d COLLECTION%s" % (count, "" if count == 1 else "S"))
        if not count:
            self["subtitle"].setText(tr("No enabled collections are available for this server"))


    def _packageBrand(self, name):
        _key, path = package_provider_key(name), package_logo_path(name)
        return os.path.basename(path) if path else ""

    def _updatePackageLogo(self):
        try:
            current = self["list"].getCurrent()
            name = current[0] if current else ""
            path = package_logo_path(name)
            if not path or not os.path.exists(path):
                self["packageLogo"].hide()
                return

            widget = self["packageLogo"]
            try:
                if widget.instance:
                    widget.instance.setPixmapFromFile(path)
            except Exception:
                pass
            widget.show()
        except Exception:
            try:
                self["packageLogo"].hide()
            except Exception:
                pass


    def choose(self):
        current = self["list"].getCurrent()
        if current:
            self.close({"name": current[0], "id": current[1]})

    def up(self):
        self["list"].up()
        self._updatePackageLogo()

    def down(self):
        self["list"].down()
        self._updatePackageLogo()

    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: self["list"].up()
        self._updatePackageLogo()

    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: self["list"].down()
        self._updatePackageLogo()


MOVIE_DETAILS = '''<screen name="MovieDetailsScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="backdrop" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="poster" position="65,55" size="350,525" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" scale="1" />
<widget name="providerLogo" position="115,590" size="250,62" alphatest="blend" zPosition="12" />
<widget name="title" position="475,70" size="1040,76" font="Regular;52" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="logoImage" position="475,48" size="500,90" alphatest="blend" scale="1" zPosition="8" />
<widget name="meta" position="480,164" size="830,42" font="Regular;24" valign="center" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="countryFlag" position="1358,161" size="70,48" alphatest="blend" zPosition="9" />
<widget name="ratingCircle" position="1484,145" size="80,80" alphatest="blend" scale="1" zPosition="9" />
<widget name="ageIcon" position="1620,160" size="50,50" alphatest="blend" scale="1" zPosition="9" />
<widget name="desc" position="480,215" size="1000,190" font="Regular;25" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
	<widget name="watch" position="480,425" size="250,62" font="Regular;27" foregroundColor="#17191D" backgroundColor="#E8B83F" halign="center" valign="center" zPosition="5" />
	<widget name="sources" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0" />
	<widget name="trailer" position="770,425" size="250,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#6B3FA0" halign="center" valign="center" zPosition="5" />
	<widget name="moreInfo" position="1060,425" size="250,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#3C4652" halign="center" valign="center" zPosition="5" />
	<widget name="buttonSelector" position="475,420" size="260,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_action_selector_clean_cyan.png" alphatest="blend" zPosition="6" />
<widget name="actorsTitle" position="475,520" size="500,40" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="480,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel0" position="445,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor1" position="690,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel1" position="655,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor2" position="900,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel2" position="865,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor3" position="1110,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel3" position="1075,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor4" position="1320,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel4" position="1285,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor5" position="1530,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorSelector" position="474,569" size="132,132" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/actor_focus_r122.png" alphatest="blend" zPosition="7" />
<widget name="actorLabel5" position="1495,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="recommendTitle" position="65,795" size="500,42" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rec0" position="65,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel0" position="65,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell0" position="65,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec1" position="530,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel1" position="530,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell1" position="530,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec2" position="995,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel2" position="995,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell2" position="995,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec3" position="1460,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel3" position="1460,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell3" position="1460,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec4" position="1920,840" size="1,1" transparent="1" zPosition="0" />
<widget name="recLabel4" position="1920,840" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="0" />
<widget name="recShell4" position="1920,840" size="1,1" transparent="1" zPosition="0" />
	<widget name="recSelector" position="65,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_400x220.png" alphatest="blend" zPosition="8" scale="1" />
</screen>'''

MOVIE_DETAILS = scale_skin(MOVIE_DETAILS)


def _movie_continue_row(source, item):
    """Return a real Continue row for this movie, or build the same row shape once."""
    item = dict(item or {})
    # Never allow an embedded trailer item/URL into the movie Watch path.
    if item.get("_is_trailer") or str(item.get("_kind") or "").lower() == "trailer":
        return {}
    for _k in ("url", "stream_url"):
        _u = str(item.get(_k) or "").lower()
        if "youtube.com" in _u or "youtu.be" in _u or "googlevideo.com" in _u:
            item.pop(_k, None)
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source) or "")
    except Exception:
        source_key = ""

    wanted_id = str(
        (item or {}).get("stream_id") or
        (item or {}).get("vod_id") or
        (item or {}).get("id") or ""
    )
    wanted_title = str((item or {}).get("name") or (item or {}).get("title") or "").strip().lower()

    # Prefer the actual Continue Watching record if one exists.
    try:
        with open(data_path("resume.json"), "r") as handle:
            rows = json.load(handle) or {}
    except Exception:
        rows = {}

    if isinstance(rows, dict):
        for row in rows.values():
            if not isinstance(row, dict):
                continue
            saved_item = row.get("item") or {}
            servers = row.get("servers") or {}
            if source_key and isinstance(servers, dict) and source_key in servers:
                candidate = servers.get(source_key) or {}
                saved_item = candidate.get("item") or saved_item

            saved_id = str(
                saved_item.get("stream_id") or
                saved_item.get("vod_id") or
                saved_item.get("id") or ""
            )
            saved_title = str(
                saved_item.get("name") or saved_item.get("title") or row.get("title") or ""
            ).strip().lower()

            same = bool(wanted_id and saved_id and wanted_id == saved_id)
            if not same and wanted_title and saved_title:
                same = wanted_title == saved_title
            if same:
                return dict(row)

    # No Continue record yet: resolve the VOD URL once, then build the exact row shape.
    url = get_source_client(source).stream_url(item, "vod")
    if not url:
        return {}

    play_item = dict(item or {})
    play_item.pop("_continue_resume", None)
    play_item.pop("_continue_position", None)
    play_item["_source_type"] = (source or {}).get("type") or ""
    play_item["_source_key"] = source_key
    play_item["_kind"] = "vod"

    try:
        from .ui import _media_service_type
        service_type = int(_media_service_type(source, "vod"))
    except Exception:
        service_type = 4097

    server_entry = {
        "source_key": source_key,
        "source_type": (source or {}).get("type") or "",
        "streamurl": url,
        "service_type": service_type,
        "item": play_item,
    }
    return {
        "title": play_item.get("name") or play_item.get("title") or "MOVIE",
        "source_key": source_key,
        "source_type": (source or {}).get("type") or "",
        "streamurl": url,
        "service_type": service_type,
        "item": play_item,
        "servers": ({source_key: server_entry} if source_key else {}),
    }



# ---------------------------------------------------------------------------
# Movie details screen
# ---------------------------------------------------------------------------

MORE_INFO_SKIN = '''<screen name="MovieMoreInfoScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="hero" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="movieLogo" position="150,72" size="500,90" alphatest="blend" scale="1" zPosition="5" />
<widget name="title" position="150,90" size="1500,70" font="Regular;48" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="150,175" size="1500,42" font="Regular;25" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="stars" position="150,230" size="900,48" font="Regular;31" foregroundColor="#F5C542" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="1060,236" size="72,30" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/tmdb_badge.png" alphatest="blend" scale="1" zPosition="5" />
<widget name="rating" position="1165,235" size="395,40" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="150,300" size="1450,180" font="Regular;25" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="director" position="150,500" size="1450,40" font="Regular;23" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="cast" position="150,548" size="1550,34" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="150,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor1" position="410,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor2" position="670,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor3" position="930,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor4" position="1190,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor5" position="1450,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actorLabel0" position="278,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel1" position="538,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel2" position="798,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel3" position="1058,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel4" position="1318,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel5" position="1578,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="otherSources" position="820,500" size="280,56" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#315976" halign="center" valign="center" zPosition="5" />
<widget name="sourceSelector" position="810,490" size="300,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/more_info_source_selector_clean_cyan.png" alphatest="blend" zPosition="6" />
<widget name="counter" position="1570,748" size="200,34" font="Regular;20" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="thumb0" position="150,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb1" position="480,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb2" position="810,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb3" position="1140,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb4" position="1470,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="selector" position="140,780" size="320,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/more_info_backdrop_selector_clean_cyan.png" alphatest="blend" zPosition="6" />
<widget name="hint" position="150,970" size="500,45" font="Regular;21" foregroundColor="#B9C0C9" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
</screen>'''
MORE_INFO_SKIN = scale_skin(MORE_INFO_SKIN)

class MovieMoreInfoScreen(Screen):
    skin = MORE_INFO_SKIN
    X = [140, 470, 800, 1130, 1460]
    def __init__(self, session, item, tmdb_id, bundle=None, sources_callback=None):
        Screen.__init__(self, session)
        self.sources_callback = sources_callback
        self.focus = "backdrops"
        self.item = dict(item or {})
        self.tmdb_id = str(tmdb_id or "").strip()
        self.bundle = dict(bundle or {})
        self.urls = []
        self.index = 0
        self.picloads = []
        self._closed = False
        self["hero"] = Pixmap()
        self["movieLogo"] = Pixmap()
        try: self["movieLogo"].hide()
        except Exception: pass
        self["title"] = DirectionalLabel(""); self["meta"] = DirectionalLabel(""); self["stars"] = Label("")
        self["rating"] = Label(""); self["desc"] = DirectionalLabel(""); self["director"] = DirectionalLabel("")
        self["cast"] = Label(""); self["counter"] = Label(""); self["selector"] = Pixmap()
        self["otherSources"] = Label(tr("Other Sources")); self["sourceSelector"] = Pixmap()
        try: self["sourceSelector"].hide()
        except Exception: pass
        self["hint"] = Label("◀  Backdrop  ▶")
        for i in range(6):
            self["actor%d" % i] = Pixmap(); self["actorLabel%d" % i] = Label("")
            try: self["actor%d" % i].hide()
            except Exception: pass
        for i in range(5):
            self["thumb%d" % i] = Pixmap()
            try: self["thumb%d" % i].hide()
            except Exception: pass
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.close, "ok": self.ok, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down
        }, -1)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._onClose)

    def _onClose(self):
        self._closed = True
        self.picloads[:] = []

    def _imageUrl(self, path):
        path = str(path or "").strip()
        if not path: return ""
        if path.startswith(("http://", "https://")): return path
        return "https://image.tmdb.org/t/p/w1280" + (path if path.startswith("/") else "/" + path)

    def _collect(self, data):
        rows = ((data or {}).get("images") or {}).get("backdrops") or []
        # TMDb can return many near-identical variants next to each other.
        # First remove exact file-path duplicates, then spread the selection over
        # the full TMDb backdrop set instead of taking the first adjacent rows.
        candidates=[]; seen=set()
        for row in rows:
            path = row.get("file_path") if isinstance(row, dict) else row
            url = self._imageUrl(path)
            key = str(path or url).strip().lower()
            if url and key and key not in seen:
                seen.add(key); candidates.append(url)

        # Keep the More Info rail intentionally diverse.  Adjacent TMDb rows are
        # commonly alternate crops/language variants of the same scene.
        out=[]
        limit=5
        if len(candidates) <= limit:
            out.extend(candidates)
        elif candidates:
            # Evenly sample from the complete result set, always including the
            # first and last candidates. This avoids clusters of repeated scenes.
            last=len(candidates)-1
            picked=set()
            for i in range(limit):
                idx=int(round((float(i)*last)/float(limit-1)))
                if idx not in picked:
                    picked.add(idx); out.append(candidates[idx])

        # Provider/current backdrop is only a fallback and never duplicates an
        # already selected TMDb image.
        for path in (self.bundle.get("backdrop_path"), self.item.get("_tmdb_backdrop"), self.item.get("backdrop_path"), self.item.get("backdrop")):
            url=self._imageUrl(path)
            if url and url not in out and len(out) < limit:
                out.append(url)
        return out

    def _year(self, data):
        value=(data or {}).get("release_date") or self.item.get("releaseDate") or self.item.get("release_date") or self.item.get("year") or ""
        return str(value)[:4]

    def _applyInfo(self, data):
        if self._closed: return
        data=dict(data or {})
        title = preferred_metadata_text(data.get("title") or data.get("name"), self.item.get("name") or self.item.get("title"), TMDbClient().language) or "Movie"
        year=self._year(data)
        runtime=data.get("runtime") or self.item.get("duration") or self.item.get("runtime") or ""
        try:
            runtime=("%d min" % int(runtime)) if runtime not in (None, "") else ""
        except Exception:
            runtime=str(runtime or "")
        genres=data.get("genres") or []
        if isinstance(genres, list):
            genre_text=", ".join(str(x.get("name") or "") for x in genres if isinstance(x,dict) and x.get("name"))
        else: genre_text=str(genres or self.item.get("genre") or "")
        self["title"].setText(str(title))
        self["meta"].setText("  •  ".join(x for x in [year,runtime,genre_text] if x))
        # More Info has its own enriched synopsis.  The background loader also
        # asks TMDb for the English record when the normal/localized overview is
        # short, so this page can show a genuinely fuller plot instead of simply
        # repeating Movie Details. Provider text is still considered when longer.
        details_overview = str(self.bundle.get("overview") or self.item.get("plot") or self.item.get("description") or "").strip()
        story_candidates = []
        for value in (
            data.get("_more_info_overview"), data.get("overview"),
            data.get("description"), data.get("plot"), data.get("story"), data.get("about"),
            self.item.get("description"), self.item.get("plot"),
            self.item.get("story"), self.item.get("about"), self.item.get("overview")
        ):
            value = str(value or "").strip()
            if value and value not in story_candidates:
                story_candidates.append(value)
        detailed = max(story_candidates, key=len) if story_candidates else details_overview
        # When a non-English TMDb language is selected, prefer its returned
        # synopsis instead of choosing an English/provider text by length.
        # details_bundle already fills missing translations from English.
        try:
            lang = TMDbClient().language.lower()
            if lang.startswith(("ar", "fr", "tr")):
                localized = str(data.get("overview") or "").strip()
                if lang.startswith("ar"):
                    # Do not claim the provider's English prose is Arabic.
                    localized = next((str(value).strip() for value in (
                        data.get("overview"), self.bundle.get("overview"),
                        data.get("description"), self.item.get("plot")
                    ) if any("\u0600" <= char <= "\u06ff" for char in str(value or ""))), localized)
                if localized:
                    detailed = preferred_metadata_text(localized, self.item.get("plot") or self.item.get("description"), lang)
        except Exception:
            pass
        self["desc"].setText((preferred_metadata_text(
            detailed, self.item.get("plot") or self.item.get("description"), TMDbClient().language)
            or details_overview or "No description available")[:900])
        rating=data.get("vote_average") or self.item.get("rating") or self.item.get("vote_average") or ""
        votes=data.get("vote_count") or ""
        try:
            rv=float(rating); filled=max(0,min(5,int(round(rv/2.0))))
            self["stars"].setText(("★"*filled)+("☆"*(5-filled)))
            rt="%.1f / 10" % rv
            if votes: rt += "   •   %s votes" % votes
            self["rating"].setText(rt)
        except Exception:
            self["stars"].setText(""); self["rating"].setText(str(rating or ""))
        credits=data.get("credits") or {}
        crew=credits.get("crew") or []
        directors=[]
        for row in crew:
            if isinstance(row,dict) and str(row.get("job") or "").lower()=="director" and row.get("name"):
                if row.get("name") not in directors: directors.append(row.get("name"))
        self["director"].setText(("Director: " + ", ".join(directors[:2])) if directors else "")
        cast=[row for row in (credits.get("cast") or []) if isinstance(row,dict) and row.get("name")][:6]
        self["cast"].setText("Cast" if cast else "")
        self._renderCast(cast)
        self._applyMovieLogo(data)

    def _applyMovieLogo(self, data):
        images=(data or {}).get("images") or {}
        logos=images.get("logos") or []
        wanted=logo_language()
        # Avoid an English flash while the localized images worker is running.
        path=best_tmdb_logo(logos, wanted) if (has_language_logo(logos, wanted) or not self.tmdb_id) else ""
        if not path:
            try: self["movieLogo"].hide(); self["title"].show()
            except Exception: pass
            return
        url=tmdb_logo_url(path, "w500")
        def done(local):
            if self._closed: return
            self._decode(local,"movieLogo",500,90)
            try: self["title"].hide()
            except Exception: pass
        request_artwork(url,"logos",done,priority=95)

    def _profileUrl(self, path):
        path=str(path or "").strip()
        if not path: return ""
        if path.startswith(("http://","https://")): return path
        return "https://image.tmdb.org/t/p/w185" + (path if path.startswith("/") else "/"+path)

    def _renderCast(self, cast):
        for i in range(6):
            row=cast[i] if i < len(cast) else {}
            name=str(row.get("name") or "")
            character=str(row.get("character") or "")
            label=name + (("\n" + character) if character else "")
            self["actorLabel%d"%i].setText(label[:70])
            url=self._profileUrl(row.get("profile_path"))
            if url:
                self._load(url,"actor%d"%i,120,120,25,"posters")
            else:
                try: self["actor%d"%i].hide()
                except Exception: pass

    def start(self):
        self._applyInfo(self.bundle)
        self.urls = self._collect(self.bundle)
        if self.urls: self._applyUrls(self.urls)
        threading.Thread(target=self._fetchDetailsAndImages, name="TiviMateMoreInfo", daemon=True).start()

    def _fetchDetailsAndImages(self):
        try:
            tmdb=TMDbClient()
            if not tmdb.configured() or not self.tmdb_id: return
            details={}
            try: details=tmdb.details_bundle(self.tmdb_id, "vod") or {}
            except Exception: details={}
            try: images=tmdb._get("/movie/%s/images" % self.tmdb_id, {"include_image_language": image_languages(tmdb)}) or {}
            except Exception: images={}
            merged_data=dict(self.bundle); merged_data.update(details or {})
            if images: merged_data["images"]=images

            # More Info enrichment: TMDb often has a much fuller English overview
            # than the localized record used by Movie Details. Fetch it only on
            # this background More Info path and use it only when it is genuinely
            # longer, leaving the normal Movie Details metadata untouched.
            try:
                current_plot = str(merged_data.get("overview") or self.item.get("plot") or self.item.get("description") or "").strip()
                english = tmdb._get("/movie/%s" % self.tmdb_id, {"language":"en-US"}) or {}
                english_plot = str(english.get("overview") or "").strip()
                # Do not insert an English expansion over an available
                # French/Turkish/Arabic TMDb synopsis. Use it only if the
                # localized record has no description, or English is selected.
                if (english_plot and english_plot != current_plot and
                        len(english_plot) >= len(current_plot) + 60 and
                        (tmdb.language.lower().startswith("en") or not str(details.get("overview") or "").strip())):
                    merged_data["_more_info_overview"] = english_plot
            except Exception:
                pass
            self._lastMoreInfoData = dict(merged_data)
            urls=self._collect(merged_data)
            merged=[]
            for u in list(self.urls)+list(urls):
                if u and u not in merged: merged.append(u)
            if reactor is not None:
                reactor.callFromThread(self._applyInfo, merged_data)
                reactor.callFromThread(self._applyUrls, merged)
        except Exception: return

    def _applyUrls(self, urls):
        if self._closed: return
        self.urls=list(urls or [])
        if not self.urls: return
        if self.index >= len(self.urls): self.index=0
        self._render()

    def _load(self, url, widget, width, height, priority=50, bucket="backdrops"):
        if not url or self._closed: return
        def done(path, w=widget, x=width, y=height):
            if self._closed: return
            self._decode(path,w,x,y)
        request_artwork(url, bucket, done, priority=priority)

    def _decode(self, path, widget, width, height):
        if self._closed: return
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget):
            try:
                ptr=l.getData()
                if ptr and not self._closed and self[w].instance:
                    self[w].instance.setPixmap(ptr); self[w].show()
            except Exception: pass
            try: self.picloads.remove(l)
            except Exception: pass
        rw,rh=scale_size(width,height)
        connect_picture_data(loader,ready,self,oneshot=True)
        loader.setPara((rw,rh,0,0,False,1,"#00000000")); loader.startDecode(path)

    def _render(self):
        if not self.urls: return
        self["counter"].setText("%d / %d" % (self.index+1,len(self.urls)))
        self._load(self.urls[self.index],"hero",1920,1080,100)
        start=max(0,min(self.index-2,max(0,len(self.urls)-5)))
        visible=self.urls[start:start+5]
        for i in range(5):
            if i < len(visible): self._load(visible[i],"thumb%d"%i,300,142,30)
            else:
                try: self["thumb%d"%i].hide()
                except Exception: pass
        try:
            slot=self.index-start
            self["selector"].instance.move(ePoint(sx(self.X[max(0,min(4,slot))]),sy(780)))
        except Exception: pass

    def _focus(self):
        try:
            self["sourceSelector"].setVisible(self.focus == "sources")
            self["selector"].setVisible(self.focus == "backdrops" and bool(self.urls))
        except Exception:
            pass

    def left(self):
        if self.focus == "backdrops" and self.urls:
            self.index=(self.index-1)%len(self.urls); self._render()
    def right(self):
        if self.focus == "backdrops" and self.urls:
            self.index=(self.index+1)%len(self.urls); self._render()
    def up(self):
        self.focus = "sources"; self._focus()
    def down(self):
        self.focus = "backdrops"; self._focus()
    def ok(self):
        if self.focus == "sources" and callable(self.sources_callback):
            # Open the real Other Sources chooser above More Info.  Do not close
            # this screen first, otherwise Enigma2 falls back to Movie Details.
            try: self.sources_callback()
            except Exception: pass
            return
        self._render()

TRAILER_POPUP = scale_skin(r'''<screen name="TrailerPopupScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<widget name="trailerBackdrop" position="0,0" size="1920,1080" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="1" />
<eLabel position="398,223" size="1124,4" backgroundColor="#D7E3FF" zPosition="4" />
<eLabel position="398,852" size="1124,4" backgroundColor="#D7E3FF" zPosition="4" />
<eLabel position="398,223" size="4,633" backgroundColor="#D7E3FF" zPosition="4" />
<eLabel position="1518,223" size="4,633" backgroundColor="#D7E3FF" zPosition="4" />
<widget name="video" position="402,227" size="1116,625" backgroundColor="transparent" zPosition="2" />
<widget name="movieLogo" position="710,866" size="500,105" alphatest="blend" zPosition="5" />
<widget name="movieTitleFallback" position="610,875" size="700,80" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="hint" position="410,1000" size="1100,30" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="4" />
</screen>''')

class TrailerPopupScreen(Screen):
    skin = TRAILER_POPUP
    def __init__(self, session, service_ref, title="Trailer", parent_screen=None):
        Screen.__init__(self, session)
        self.parent_screen = parent_screen
        self.service_ref = service_ref
        self["trailerBackdrop"] = Pixmap()
        self._backdrop_loader = None
        self._backdrop_url = ""
        if parent_screen is not None:
            try:
                item = parent_screen.item or {}
                self._backdrop_url = parent_screen._norm(
                    item.get("_tmdb_backdrop") or item.get("backdrop_path") or
                    item.get("backdrop") or item.get("backdrop_url"), "w780")
            except Exception:
                pass
        self.old_service = None
        try:
            self.old_service = session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass
        if VideoWindow is None:
            raise RuntimeError("VideoWindow is not available on this image")
        try:
            self["video"] = VideoWindow(decoder=0, fb_width=1920, fb_height=1080)
        except TypeError:
            self["video"] = VideoWindow(decoder=0)
        self["movieLogo"] = Pixmap()
        self["movieTitleFallback"] = Label(str(title or ""))
        self._trailer_logo_loader = None
        self._trailer_logo_url = ""
        if parent_screen is not None:
            try:
                item = parent_screen.item or {}
                self._trailer_logo_url = str(item.get("_player_movie_logo") or "").strip()
                if not self._trailer_logo_url:
                    self._trailer_logo_url = parent_screen._movieLogoUrl(getattr(parent_screen, "_tmdb_bundle", {}) or {})
                self["movieTitleFallback"].setText(str(item.get("name") or item.get("title") or title or ""))
            except Exception:
                pass
        self["movieLogo"].hide()
        self.onLayoutFinish.append(self._load_trailer_logo)
        self["hint"] = Label("BACK  Close Trailer")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close, "ok": self.close, "red": self.close
        }, -1)
        self.onLayoutFinish.append(self._load_trailer_backdrop)
        self.onLayoutFinish.append(self._play)
        self.onClose.append(self._restore)
        self.onClose.append(self._clear_parent)

    def _load_trailer_backdrop(self):
        if not self._backdrop_url:
            return
        def done(path):
            try:
                loader = ePicLoad()
                self._backdrop_loader = loader
                def ready(_=None):
                    try:
                        ptr = loader.getData()
                        if ptr and self["trailerBackdrop"].instance:
                            self["trailerBackdrop"].instance.setPixmap(ptr)
                            self["trailerBackdrop"].show()
                    except Exception:
                        pass
                connect_picture_data(loader, ready, self, oneshot=True)
                loader.setPara((1920,1080,0,0,False,1,"#000000"))
                loader.startDecode(path)
            except Exception:
                pass
        request_artwork(self._backdrop_url, "backdrops", done, priority=90)

    def _load_trailer_logo(self):
        if not self._trailer_logo_url:
            return
        def done(path):
            try:
                loader = ePicLoad()
                self._trailer_logo_loader = loader
                def ready(_=None):
                    try:
                        ptr = loader.getData()
                        if ptr and self["movieLogo"].instance:
                            self["movieLogo"].instance.setPixmap(ptr)
                            self["movieLogo"].show()
                            self["movieTitleFallback"].hide()
                    except Exception:
                        pass
                connect_picture_data(loader, ready, self, oneshot=True)
                loader.setPara((500,105,0,0,False,1,"#000000"))
                loader.startDecode(path)
            except Exception:
                pass
        request_artwork(self._trailer_logo_url, "logos", done, priority=90)

    def _clear_parent(self):
        parent = self.parent_screen
        if parent is not None:
            try:
                if getattr(parent, "_trailerOverlay", None) is self:
                    parent._trailerOverlay = None
            except Exception:
                pass

    def _play(self):
        try:
            self.session.nav.playService(self.service_ref)
        except Exception:
            self.close()

    def _restore(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        if self.old_service:
            try:
                self.session.nav.playService(self.old_service)
            except Exception:
                pass


class MovieDetailsScreen(Screen):
    skin = MOVIE_DETAILS
    REC_X = [65, 530, 995, 1460]
    ACTOR_X = [474, 684, 894, 1104, 1314, 1524]
    def __init__(self, session, source, item, server_items=None, source_context=None):
        Screen.__init__(self, session)
        self.source = source
        self.item = item or {}
        self._serverPackageProvider = str(self.item.get("_server_package_provider") or self.item.get("_tmdb_provider") or "")
        self.server_items = list(server_items or [])
        # Recommendations must never follow whichever page/list happens to be
        # current after the details screen opens. Keep a dedicated immutable
        # source context, separate from the provider-wide catalog used by Watch
        # and Other Sources.
        self.source_context = dict(source_context or {})
        self.recommendation_items = list(self.source_context.get("items") or server_items or [])
        self._recommendationCategoryId = str(
            self.source_context.get("category_id") or
            self.item.get("_source_category_id") or self.item.get("category_id") or ""
        ).strip()
        self._recommendationScope = str(
            self.source_context.get("scope") or self.item.get("_source_scope") or "details"
        ).strip()
        self._sourceTitleIndex = None
        self.sources_list = []
        self.recommendations = []
        self.actors = []
        self._primaryArtworkReady = False
        self._watchResolveStarted = False
        self._watchReady = bool(self.item.get("stream_id") or self.item.get("vod_id"))
        self._sourcesSearchRunning = False
        self._sourcesSearchDone = False
        self._fastVodRowsCache = None
        self._fullVodRowsCache = None
        self._vodSelectedSource = dict(self.source or {})
        self.focus = "buttons"
        self.button_index = 0
        self.rec_index = 0
        self.actor_index = 0
        self.downloads, self.picloads = [], []
        self._detail_pixmap_keys = set()
        self._image_requests = {}
        # Worker threads never touch Enigma2 widgets directly.  A small GUI
        # poller drains completed work on the main thread; the workers only
        # append plain Python call records to this queue.  This remains safe on
        # Python 3 Enigma2 and does not depend on Twisted reactor integration.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        self["backdrop"] = Pixmap(); self["poster"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["logoImage"] = Pixmap()
        try: self["logoImage"].hide()
        except Exception: pass
        self["title"] = DirectionalLabel(self.item.get("name") or self.item.get("title") or "Movie")
        self["meta"] = DirectionalLabel(""); self["desc"] = DirectionalLabel(tr(""))
        self["ratingCircle"] = Pixmap()
        self["ratingCircle"].hide()
        self["countryFlag"] = Pixmap()
        self["countryFlag"].hide()
        self["ageIcon"] = Pixmap()
        self["ageIcon"].hide()
        self._movieAgeToken = ""
        self["watch"] = Label(tr("▶  Watch") if self._watchReady else tr("Searching...")); self["sources"] = Label(tr("Press for Other Sources")); self["trailer"] = Label("▶  Trailer"); self["moreInfo"] = Label("ⓘ  " + tr("More Info"))
        self["buttonSelector"] = Pixmap(); self["actorsTitle"] = Label(tr("Actors")); self["actorSelector"] = Pixmap()
        for i in range(6):
            self["actor%d" % i] = Pixmap()
            self["actorLabel%d" % i] = Label("")
            try:
                self["actor%d" % i].hide()
            except Exception:
                pass
        self["recommendTitle"] = Label(tr("Recommendations"))
        for i in range(5):
            self["rec%d" % i] = Pixmap(); self["recLabel%d" % i] = Label("")
            self["recShell%d" % i] = Pixmap()
            # Keep the whole recommendation card hidden until its real backdrop
            # has decoded successfully: image + label + geometric shell appear together.
            for _name in ("rec%d" % i, "recLabel%d" % i, "recShell%d" % i):
                try:
                    self[_name].hide()
                except Exception:
                    pass
        self["recSelector"] = Pixmap()
        self._trailerOverlay = None
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self._cancelOrCloseTrailer, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "green": self.watchSelected, "yellow": self.playTrailer
        }, -1)
        self.onLayoutFinish.append(self._startGuiDispatch)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._closeTrailerOverlay)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkMemory)


    def _updateProviderLogo(self):
        try:
            provider = str((self.item or {}).get("_server_package_provider") or (self.item or {}).get("_tmdb_provider") or self._serverPackageProvider or "").strip().lower()
            if provider == "prime_video":
                provider = "prime"
            path = package_logo_for_key(provider)
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(120, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(120, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _releaseArtworkMemory(self):
        # The local widgets are destroyed with the screen; release the LRU refs
        # too so large backdrops never accumulate between detail pages.
        self._image_requests = {}
        self.downloads = []
        self.picloads = []
        for key in list(getattr(self, "_detail_pixmap_keys", set())):
            _DETAILS_PIXMAP_CACHE.pop(key, None)
        self._detail_pixmap_keys = set()


    def _deferredServerMatch(self):
        """Resolve a TMDb discovery movie only after its details screen opens."""
        wanted_id = str(self.item.get("tmdb_id") or self.item.get("id") or "").strip()
        wanted = [self._title_norm(self.item.get(field)) for field in ("name", "title", "original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)

        def row_tmdb_id(row):
            row = row or {}
            for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                for key in ("tmdb_id", "tmdb", "tmdbid"):
                    value = mapping.get(key)
                    if value not in (None, ""):
                        try:
                            return str(int(value))
                        except Exception:
                            value = str(value).strip()
                            if value:
                                return value
            return ""

        def match_rows(rows):
            if wanted_id:
                for row in rows or []:
                    if row_tmdb_id(row) == wanted_id:
                        return dict(row)
            best = None
            best_score = 0.0
            for row in rows or []:
                row_year = self._year(row)
                if target_year and row_year and target_year != row_year:
                    continue
                candidates = [self._title_norm((row or {}).get(field)) for field in ("name", "title", "original_title")]
                score = max([self._title_score(a, b) for a in wanted for b in candidates] or [0.0])
                if target_year and row_year:
                    if score < 0.94:
                        continue
                elif score < 0.98:
                    continue
                if score > best_score:
                    best, best_score = dict(row), score
            return best

        # First use the already loaded full Xtream catalogue / warmed Home index.
        match = match_rows(self.server_items or [])
        if match:
            return match

        source = dict(self._vodSelectedSource or {})
        try:
            client = get_source_client(source)
            if source.get("type") == "xtream":
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                return match_rows(rows)
            if source.get("type") == "stalker":
                categories, _origin = get_cached_categories(source, "vod", client=client, wait_for_server=True)
                categories = filter_categories(source, "vod", categories or [])
                for category in categories:
                    category_id = str((category or {}).get("category_id") or "")
                    if not category_id:
                        continue
                    rows, _origin = get_category_streams(
                        source, "vod", client, category_id,
                        use_cache=True, wait_for_server=True
                    )
                    match = match_rows(rows or [])
                    if match:
                        return match
        except Exception:
            pass
        return None



    def _loadDeferredTmdbMovie(self):
        self.loadDetails()



    def start(self):
        self["ageIcon"].hide()
        self.applyInitialDetails()
        if self._watchReady:
            self._setWatchReady()
        else:
            self._setWatchSearching()
        self.updateFocus()
        # Show cached same-package recommendations immediately; never wait for
        # TMDb cast, plot or provider VOD info before drawing this separate rail.
        self._startServerRecommendationResolve({})
        # Artwork/details first. No provider-wide Watch/Sources scan here.
        t = threading.Thread(target=self.loadDetails, name="TiviMateMovieDetails")
        t.daemon = True
        t.start()


    def applyInitialDetails(self):
        title = self.item.get("name") or self.item.get("title") or "Movie"
        year = str(self.item.get("releaseDate") or self.item.get("release_date") or self.item.get("year") or "")[:4]
        genre = self.item.get("genre") or ""
        self["title"].setText(title)
        # The TMDb score is rendered in a dedicated circular indicator.  Do not
        # label a provider rating as an official TMDb percentage.
        show_score(self["ratingCircle"], None)
        show_country_flag(self["countryFlag"], {}, "movie")
        self["meta"].setText("  •  ".join(x for x in [year, str(genre)] if x))
        self["desc"].setText((self.item.get("plot") or self.item.get("description") or "")[:700])
        poster = self.item.get("_resolved_server_poster") or _server_poster_url(self.source, self.item)
        # Details backdrop: paint one already-resolved/current backdrop immediately
        # and keep it stable for this page. Do not repaint a second, different
        # backdrop when TMDb metadata arrives later.
        backdrop = self._norm(
            self.item.get("_tmdb_backdrop") or self.item.get("backdrop_path") or
            self.item.get("backdrop") or self.item.get("backdrop_url"),
            "w780"
        )
        self._detailBackdropLocked = bool(backdrop)
        if poster:
            self.loadImage(poster, "poster", 350, 525)
        if backdrop:
            self.loadImage(backdrop, "backdrop", 1920, 1080)

    def _norm(self, value, size="w780"):
        if isinstance(value, list): value = value[0] if value else ""
        if not isinstance(value, str): return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("/"): value = "https://image.tmdb.org/t/p/%s%s" % (size, value)
        return value


    def _title_norm(self, value):
        # Normalize movie titles across provider packages. Package branding,
        # quality/language tags and year must never stop the same movie matching.
        text = str(value or "").lower().replace("&", " and ")
        text = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", text)

        # Strip common platform/package labels first.
        text = re.sub(r"\bamazon\s+prime(?:\s+video)?\b", " ", text)
        text = re.sub(r"\bprime\s+video\b", " ", text)
        text = re.sub(r"\bapple\s+tv\+?\b", " ", text)
        text = re.sub(r"\bdisney\+?\b", " ", text)
        text = re.sub(r"\bhbo\s+max\b", " ", text)
        text = re.sub(r"\bparamount\+?\b", " ", text)
        text = re.sub(r"\bnetflix\b", " ", text)

        text = re.sub(
            r"\b(nf|amz|amzn|ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|8k|uhd|fhd|hd|sd|"
            r"hevc|x265|x264|hdr|web[- ]?dl|bluray|brrip|webrip|remux|top|"
            r"2160p|1080p|720p|576p|480p|vod|movies?)\b",
            " ", text
        )
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())


    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _title_score(self, wanted, candidate):
        """Return a score only for genuinely matching release titles."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens, candidate_tokens = set(wanted.split()), set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0
        # Partial title containment is safe only when every significant token matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94
        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0

    def _playable_item(self):
        if self.item.get("stream_id"):
            return self.item
        return self.sources_list[0] if self.sources_list else None


    def _fullServerVodCatalog(self):
        """Return the complete movie catalog for Other Sources on this server."""
        source = dict(self._vodSelectedSource or {})
        client = get_source_client(source)
        rows = []

        if source.get("type") == "xtream":
            # One provider-wide request includes every VOD package/category.
            try:
                rows = list(client.streams("vod") or [])
            except Exception:
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])

        elif source.get("type") == "stalker":
            # Search every real VOD package. Do not restrict to the package
            # from which the details screen was opened.
            try:
                categories = list(client.categories("vod") or [])
            except Exception:
                categories = []

            for category in categories:
                cid = str((category or {}).get("category_id") or
                          (category or {}).get("id") or "").strip()
                if not cid:
                    continue
                try:
                    cat_rows, _origin = get_category_streams(
                        source, "vod", client, cid,
                        use_cache=True, wait_for_server=True
                    )
                    rows.extend(list(cat_rows or []))
                except Exception:
                    try:
                        rows.extend(list(client.streams("vod", cid) or []))
                    except Exception:
                        pass

            if not rows:
                try:
                    rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                except Exception:
                    rows = []
        else:
            try:
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
            except Exception:
                rows = []

        # Deduplicate provider rows while preserving provider/category order.
        out = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            key = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if key in seen:
                continue
            seen.add(key)
            out.append(dict(row))
        return out


    def _matchingServerSources(self, rows, exclude_primary=True):
        title_fields = ("name", "title", "original_title")
        wanted = [self._title_norm(self.item.get(field)) for field in title_fields]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        primary_id = str(self.item.get("stream_id") or self.item.get("vod_id") or "")
        matches, seen = [], set()

        for row in rows or []:
            row_id = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            if exclude_primary and primary_id and row_id and row_id == primary_id:
                continue
            unique = row_id or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue
            candidate_titles = [self._title_norm(row.get(field)) for field in title_fields]
            score = max([self._title_score(w, c) for w in wanted for c in candidate_titles] or [0.0])
            if score < 0.90:
                continue
            row_year = self._year(row)
            if target_year and row_year and abs(target_year-row_year) > 1:
                continue
            matches.append((score, 1 if target_year and row_year == target_year else 0, dict(row)))
            seen.add(unique)

        matches.sort(key=lambda value: (value[0], value[1]), reverse=True)
        return [value[2] for value in matches]


    def _buildSourceTitleIndex(self):
        """Index server rows by normalized title once, avoiding a full fuzzy scan every time."""
        if self._sourceTitleIndex is not None:
            return self._sourceTitleIndex
        index = {}
        for row in self.server_items:
            try:
                seen = set()
                for field in ("name", "title", "original_title"):
                    norm = self._title_norm(row.get(field))
                    if norm and norm not in seen:
                        seen.add(norm)
                        index.setdefault(norm, []).append(row)
            except Exception:
                continue
        self._sourceTitleIndex = index
        return index


    def _cachedOtherSourceRows(self):
        """Read VOD package RAM/disk cache only; never contact the provider."""
        source = dict(self._vodSelectedSource or {})
        allowed = get_allowed_category_ids(source, "vod")
        category_ids = []

        if allowed is not None:
            category_ids = [str(cid) for cid in allowed if str(cid)]
        else:
            try:
                categories, _origin = get_cached_categories(source, "vod", wait_for_server=False)
            except Exception:
                categories = []
            for category in list(categories or []):
                cid = str((category or {}).get("category_id") or
                          (category or {}).get("id") or "").strip()
                if cid:
                    category_ids.append(cid)

        rows, seen = [], set()
        for cid in category_ids:
            try:
                cached, _origin = peek_category_streams_cache(source, "vod", cid)
            except Exception:
                cached = []
            for row in list(cached or []):
                if not isinstance(row, dict):
                    continue
                sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
                key = sid or (
                    self._title_norm(row.get("name") or row.get("title") or ""),
                    str(row.get("category_id") or cid),
                    str(row.get("container_extension") or "")
                )
                if key in seen:
                    continue
                seen.add(key)
                rows.append(dict(row))
        return rows

    def findSources(self):
        try:
            # Other Sources only: RAM/disk package cache first.  If an alternate
            # copy is already cached, open it immediately and do not touch server.
            cached_rows = self._cachedOtherSourceRows()
            sources = self._matchingServerSources(cached_rows)
            if sources:
                self._queueGui(self.applySources, sources[:24])
                return

            # Cache miss: preserve the existing provider-wide server fallback.
            rows = self._fullServerVodCatalog()
            sources = self._matchingServerSources(rows)

            if rows:
                self.server_items = list(rows)
                self._sourceTitleIndex = None

            self._queueGui(self.applySources, sources[:24])
        except Exception:
            self._queueGui(self.applySources, [])





    def applySources(self, sources):
        # Keep the movie copy we are currently viewing in Other Sources too.
        # The alternate-source search normally excludes the primary stream_id,
        # which made the original playable link disappear from the chooser.
        # Prepend a clean copy of the resolved current VOD, then append matches.
        primary = None
        try:
            current = dict(self.item or {})
            if current.get("stream_id") or current.get("vod_id"):
                primary = current
            else:
                cached = self._cachedServerMatch()
                if cached and (cached.get("stream_id") or cached.get("vod_id")):
                    primary = dict(cached)
        except Exception:
            primary = None

        combined = []
        seen = set()
        if primary:
            primary["_other_sources_current"] = True
            combined.append(primary)
            pid = str(primary.get("stream_id") or primary.get("vod_id") or primary.get("id") or "")
            if pid:
                seen.add(pid)

        for row in list(sources or []):
            if not isinstance(row, dict):
                continue
            candidate = dict(row)
            rid = str(candidate.get("stream_id") or candidate.get("vod_id") or candidate.get("id") or "")
            if rid and rid in seen:
                continue
            if rid:
                seen.add(rid)
            combined.append(candidate)

        self.sources_list = combined[:25]
        count = len(self.sources_list)
        if count:
            self["sources"].setText("Other Sources (%d)" % count)
        else:
            self["sources"].setText(tr("No Other Sources"))


    def _recommendationPool(self):
        """Return rows from the movie's real source context, never the current UI page.

        Other Sources is allowed to warm/replace ``self.server_items`` with the
        whole provider catalog. Recommendations deliberately use the separate
        ``recommendation_items`` snapshot and, when possible, lock it to the
        movie's real category_id.
        """
        rows=[dict(x) for x in list(self.recommendation_items or []) if isinstance(x,dict)]
        cid=str(self._recommendationCategoryId or "").strip()

        # RECENT ADDED (Movies) special rule:
        # Only when the movie was opened from RECENT ADDED, keep the
        # recommendation backdrop rail inside that exact Recent Added snapshot.
        # Normal movie packages keep their existing behaviour unchanged.
        if self._recommendationScope == "movies_recent_filtered":
            return rows

        # If Home opened a TMDb card, identify the real server row/category from
        # the warmed catalog once. This removes the old 'Home list = context' bug.
        if not cid and self.server_items:
            try:
                matches=self._matchingServerSources(self.server_items, exclude_primary=False)
                if matches:
                    matched=dict(matches[0] or {})
                    cid=str(matched.get("category_id") or matched.get("categoryId") or "").strip()
                    if cid:
                        self._recommendationCategoryId=cid
                        # Preserve the playable server identity on the current item.
                        for key in ("stream_id","vod_id","container_extension","category_id"):
                            if matched.get(key) not in (None,"") and self.item.get(key) in (None,""):
                                self.item[key]=matched.get(key)
            except Exception:
                pass

        if cid:
            # Recommendation rail is package-cache first: use the exact current
            # movie package from RAM/HDD cache before the normal package path.
            # On a cache miss, preserve the existing same-package behaviour.
            try:
                cached,_origin=peek_category_streams_cache(self.source,"vod",cid)
                if cached:
                    return [dict(x) for x in cached if isinstance(x,dict)]
            except Exception:
                pass

            filtered=[r for r in rows if str(r.get("category_id") or r.get("categoryId") or "").strip()==cid]
            if filtered:
                return filtered
            # Cache miss: keep the original path for this exact package only.
            try:
                client=get_source_client(self.source)
                fetched,_origin=get_category_streams(
                    self.source,"vod",client,cid,use_cache=True,wait_for_server=True
                )
                if fetched:
                    return [dict(x) for x in fetched if isinstance(x,dict)]
            except Exception:
                pass

        return rows


    def _serverOnlyTmdbRecommendations(self, data):
        """Fast recommendations from the item's explicit source context only."""
        import random

        rows=self._recommendationPool()
        if not rows:
            return []

        current_id=str(
            self.item.get("stream_id") or
            self.item.get("vod_id") or
            self.item.get("id") or ""
        ).strip()
        current_title=self._recommendTitleNorm(
            self.item.get("name") or self.item.get("title") or ""
        )

        pool=[]
        seen=set()

        for row in rows:
            sid=str(
                row.get("stream_id") or
                row.get("vod_id") or
                row.get("id") or ""
            ).strip()
            title=self._recommendTitleNorm(
                row.get("name") or row.get("title") or ""
            )

            if current_id and sid and sid==current_id:
                continue
            if not current_id and current_title and title==current_title:
                continue

            unique=("id:"+sid) if sid else ("title:"+title)
            if not unique or unique in seen:
                continue
            seen.add(unique)

            # Same-package server row stays fully playable.
            row["_recommend_server_match"]=True
            pool.append(row)

        if not pool:
            return []

        # Stable daily random picks: reopening details uses the same cached
        # artwork rather than choosing four new uncached films every time.
        seed = "%s|%s|%s|%s" % (
            _recommend_backdrop_key(self.source, self.item),
            str(self._recommendationCategoryId or ""),
            str(self._recommendationScope or ""),
            time.strftime("%Y-%m-%d"),
        )
        random.Random(seed).shuffle(pool)

        # Prefer real same-package backdrops already present in the provider
        # row or our persistent per-movie backdrop metadata cache. Never prefer
        # a poster in the horizontal recommendation rail.
        image_cached, metadata_known, missing = [], [], []
        # Inspect only a bounded random sample for existing backdrop files and
        # saved TMDb paths. Large provider packages may contain 10,000+ rows.
        for row in pool[:80]:
            url = row.get("backdrop_path") or row.get("backdrop") or row.get("backdrop_url")
            if not url:
                known = _recommend_backdrop_get(self.source, row)
                url = known.get("backdrop_path") or ""
                if url:
                    row["backdrop_path"] = url
                    if known.get("tmdb_id") and not row.get("tmdb_id"):
                        row["tmdb_id"] = known["tmdb_id"]
            if url:
                try:
                    local = cached_artwork(self._norm(url, "w780"), "backdrops")
                except Exception:
                    local = None
                (image_cached if local else metadata_known).append(row)
            else:
                missing.append(row)
        # Already-downloaded HDD/USB images win over URL-only candidates. A
        # missing image never stops the four cards from being selected.
        return (image_cached + metadata_known + missing + pool[80:])[:4]



    def loadDetails(self):
        try:
            # Details are cache-first, identical in spirit to the fast TV
            # Shows path.  Opening More Info must never wait on provider vod_info.
            tmdb = TMDbClient()
            raw_title = self.item.get("name") or self.item.get("title") or self.item.get("original_title") or ""
            item_year = self._year(self.item) or None
            provider_tid = self.item.get("tmdb_id") or self.item.get("tmdb")
            title_key = "vod:title:%s:%s" % (self._title_norm(raw_title), str(item_year or ""))
            id_key = "vod:%s" % str(provider_tid or "") if provider_tid else ""

            cached = _memory_get(_DETAILS_DATA_CACHE, _tmdb_details_memory_key(id_key)) if id_key else None
            if not cached:
                cached = _memory_get(_DETAILS_DATA_CACHE, _tmdb_details_memory_key(title_key))
            # A cached details row is final only when its actor cards are complete.
            # Older cache records can contain provider name-only cast rows; returning
            # here used to bypass the normal TMDb credits enrichment below entirely.
            data = dict(cached) if cached else {}
            if data.get("id"):
                self.item["tmdb_id"] = str(data.get("id"))
            cached_cast = ((data.get("credits") or {}).get("cast") or [])
            cached_visible = list(cached_cast[:6])
            cached_cast_complete = bool(cached_visible) and all(
                isinstance(x, dict) and x.get("id") and x.get("profile_path")
                for x in cached_visible
            )
            # An actor-complete cache may still contain an English overview
            # from older builds. Complete localization by TMDb id before using it.
            needs_arabic = (str(tmdb.language or "").lower().startswith("ar")
                            and not any("\u0600" <= ch <= "\u06ff" for ch in str(data.get("overview") or ""))
                            and bool(provider_tid or data.get("id")))
            if cached and cached_cast_complete and not needs_arabic:
                self._queueGui(self.applyDetails, data)
                return

            # Keep cached metadata/artwork, but allow incomplete actor rows to pass
            # through the exact same credits path used by a normal working movie.
            tid = provider_tid or data.get("id") or data.get("tmdb_id")
            found = None

            # details_bundle and search_title both have persistent disk caches, so
            # repeated visits normally stay local even after a GUI restart.
            if tid:
                try:
                    data = tmdb.details_bundle(tid, "vod") or {}
                except Exception:
                    data = {}

            # Provider details recovery: the catalog row may contain a poster but
            # no plot/rating/genre/date. In that case get_vod_info must still be
            # queried for this movie; previously it was queried only when the
            # poster was missing, leaving Movie Details at 0.0 / no description.
            have_plot = bool((data or {}).get("overview") or self.item.get("plot") or self.item.get("description"))
            have_rating = bool((data or {}).get("vote_average") or self.item.get("rating"))
            # A poster alone is not enough: recover provider details whenever the
            # two fields shown most prominently by Movie Details are incomplete.
            need_provider_info = not have_plot or not have_rating
            need_provider_poster = not _server_poster_url(self.source, self.item) and not (data or {}).get("poster_path")
            if need_provider_info or need_provider_poster:
                try:
                    sid = self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("id")
                    if sid and str((self.source or {}).get("type") or "").lower() == "xtream":
                        provider_data = get_source_client(self.source).vod_info(sid) or {}
                        provider_info = provider_data.get("info") if isinstance(provider_data, dict) else {}
                        provider_movie = provider_data.get("movie_data") if isinstance(provider_data, dict) else {}
                        provider_extra = {}
                        if isinstance(provider_movie, dict):
                            provider_extra.update(provider_movie)
                        if isinstance(provider_info, dict):
                            provider_extra.update(provider_info)

                        # Fill only missing Movie Details metadata from the same
                        # provider. Existing TMDb/catalog values keep priority.
                        if isinstance(provider_info, dict):
                            if not (data or {}).get("overview"):
                                value = provider_info.get("plot") or provider_info.get("description")
                                if value:
                                    data["overview"] = value
                            if not (data or {}).get("vote_average"):
                                value = provider_info.get("rating")
                                if value not in (None, "", 0, "0", "0.0"):
                                    data["vote_average"] = value
                            if not (data or {}).get("release_date"):
                                value = provider_info.get("releasedate") or provider_info.get("releaseDate") or provider_info.get("release_date")
                                if value:
                                    data["release_date"] = value
                            if not (data or {}).get("genres"):
                                value = provider_info.get("genre")
                                if value:
                                    data["genres"] = [{"name": x.strip()} for x in str(value).split(",") if x.strip()]
                        # Movie Details actors: fill cast from the same provider first.
                        # Xtream providers commonly expose cast/actors as a comma-separated
                        # string in vod_info rather than TMDb-style credits.
                        if not ((data.get("credits") or {}).get("cast") or []):
                            provider_cast = provider_info.get("cast") or provider_info.get("actors") if isinstance(provider_info, dict) else ""
                            if provider_cast:
                                if isinstance(provider_cast, (list, tuple)):
                                    cast_rows = []
                                    for actor in provider_cast:
                                        if isinstance(actor, dict):
                                            name = actor.get("name") or actor.get("actor") or ""
                                            if name:
                                                cast_rows.append(dict(actor, name=name))
                                        elif actor:
                                            cast_rows.append({"name": str(actor).strip()})
                                else:
                                    # Provider cast may use Arabic comma/semicolon/newlines.
                                    # Never turn the whole raw cast string into one Actor card.
                                    cast_rows = [{"name": x.strip()} for x in re.split(r"[,،;؛\n\r|]+", str(provider_cast)) if x.strip()]
                                if cast_rows:
                                    data["credits"] = {"cast": cast_rows[:6]}

                        provider_poster = _server_poster_url(self.source, self.item, extra=provider_extra)
                        if provider_poster:
                            self.item["_resolved_server_poster"] = provider_poster
                            if need_provider_poster:
                                self._queueGui(self.loadImage, provider_poster, "poster", 350, 525)
                        # Movie Details backdrop: use the same provider vod_info artwork
                        # that can already be available to the large Movies page.
                        # Keep it as a fallback only; existing page/TMDb behaviour stays intact.
                        if not (self.item.get("backdrop_path") or self.item.get("backdrop") or self.item.get("backdrop_url")):
                            provider_backdrop = _server_backdrop_url(self.source, self.item, extra=provider_extra)
                            if provider_backdrop:
                                self.item["backdrop"] = provider_backdrop
                                try:
                                    request_artwork(provider_backdrop, "backdrops", None, priority=100)
                                except Exception:
                                    pass
                except Exception:
                    pass

            # Actors fallback/enrichment: provider vod_info often supplies only
            # comma-separated actor names, without TMDb profile_path images.
            # Treat a name-only cast as incomplete: resolve TMDb cast for this same
            # movie and merge profile images/characters by actor name.  This keeps
            # provider names when present and changes no poster/backdrop/metadata.
            current_cast = ((data.get("credits") or {}).get("cast") or [])
            visible_cast = list(current_cast[:6])
            cast_needs_profiles = (
                not visible_cast or
                any(not (isinstance(x, dict) and x.get("profile_path")) for x in visible_cast) or
                len(visible_cast) < 6
            )
            if cast_needs_profiles:
                try:
                    # Reuse the TMDb movie already resolved for this details page.
                    # Old/Arabic provider titles can be transliterated differently, so
                    # searching the title again may resolve no movie even though this
                    # page already has the correct TMDb metadata/backdrop.
                    cast_tid = (data or {}).get("id") or (data or {}).get("tmdb_id") or self.item.get("tmdb_id")
                    if not cast_tid and raw_title:
                        cast_found = tmdb.search_title(raw_title, "vod", item_year) or {}
                        if not cast_found:
                            cast_found = tmdb.search_title(raw_title, "vod", None) or {}
                        cast_tid = (cast_found or {}).get("id") or (cast_found or {}).get("tmdb_id")
                    if cast_tid:
                        # Use the normal TMDb credits rows (id/name/profile_path).
                        # details_bundle may legitimately return an older cache that has
                        # metadata/artwork but no credits, so fall back to the dedicated
                        # credits endpoint only when actor cards are incomplete.
                        cast_bundle = tmdb.details_bundle(cast_tid, "vod") or {}
                        tmdb_cast = ((cast_bundle.get("credits") or {}).get("cast") or [])
                        if not tmdb_cast or any(not (isinstance(x, dict) and x.get("profile_path")) for x in tmdb_cast[:6]):
                            credits_data = tmdb.media_credits(cast_tid, "vod") or {}
                            if credits_data.get("cast"):
                                tmdb_cast = credits_data.get("cast") or []
                        if tmdb_cast:
                            # TMDb credits are authoritative for actor cards because
                            # provider cast strings commonly contain names only.  Build
                            # the six visible cards from TMDb so every available actor
                            # carries id/profile_path; preserve provider character text
                            # only when the actor name matches.
                            provider_by_name = {}
                            for row in current_cast:
                                if isinstance(row, dict):
                                    key = self._title_norm(row.get("name") or "")
                                    if key:
                                        provider_by_name[key] = row
                            merged = []
                            for row in tmdb_cast:
                                if len(merged) >= 6:
                                    break
                                if not isinstance(row, dict):
                                    continue
                                base = dict(row)
                                key = self._title_norm(base.get("name") or "")
                                provider_row = provider_by_name.get(key) or {}
                                if provider_row.get("character") and not base.get("character"):
                                    base["character"] = provider_row.get("character")
                                merged.append(base)
                            if merged:
                                data["credits"] = {"cast": merged}
                            if not self.item.get("tmdb_id"):
                                self.item["tmdb_id"] = str(cast_tid)
                except Exception:
                    pass

            # If this provider movie cannot be resolved to a TMDb movie ID, do not
            # leave name-only Actor cards behind. Resolve each provider actor name
            # directly to a TMDb person so the normal cards receive id/profile_path.
            final_cast = ((data.get("credits") or {}).get("cast") or [])
            if final_cast and any(not (isinstance(x, dict) and x.get("id") and x.get("profile_path")) for x in final_cast[:6]):
                resolved_people = []
                for actor in final_cast[:6]:
                    if not isinstance(actor, dict):
                        continue
                    if actor.get("id") and actor.get("profile_path"):
                        resolved_people.append(dict(actor))
                        continue
                    actor_name = str(actor.get("name") or "").strip()
                    if not actor_name:
                        continue
                    try:
                        person = tmdb.search_person(actor_name) or {}
                    except Exception:
                        person = {}
                    if person.get("id"):
                        row = dict(person)
                        row["name"] = person.get("name") or actor_name
                        if actor.get("character") and not row.get("character"):
                            row["character"] = actor.get("character")
                        resolved_people.append(row)
                # Do not display unusable name-only cards. Every visible actor must
                # be a real TMDb person and therefore open Actor information normally.
                if resolved_people:
                    data["credits"] = {"cast": resolved_people[:6]}
                else:
                    data["credits"] = {"cast": []}

            useful = bool(
                data.get("poster_path") or data.get("backdrop_path") or data.get("overview") or
                ((data.get("credits") or {}).get("cast") or []) or
                ((data.get("recommendations") or {}).get("results") or []) or
                ((data.get("similar") or {}).get("results") or [])
            )

            if not useful and raw_title:
                found = tmdb.search_title(raw_title, "vod", item_year) or {}
                if not found:
                    found = tmdb.search_title(raw_title, "vod", None) or {}
                resolved = (found or {}).get("id") or (found or {}).get("tmdb_id")
                if resolved:
                    tid = resolved
                    try:
                        data = tmdb.details_bundle(tid, "vod") or {}
                    except Exception:
                        data = {}

            if found:
                seed = dict(found)
                seed.update(data or {})
                data = seed

            # Poster-only recovery: use the same title-cleaning artwork search
            # used by the player when the normal details bundle has no poster.
            # This is especially useful for Arabic/provider-tagged titles.
            if raw_title and not (data or {}).get("poster_path"):
                try:
                    artwork = tmdb.search_artwork(raw_title, kind="vod", year=item_year, required_key="poster_path") or {}
                    if artwork.get("poster_path"):
                        seed = dict(artwork)
                        seed.update(data or {})
                        seed["poster_path"] = artwork.get("poster_path")
                        data = seed
                except Exception:
                    pass

            if tid:
                self.item["tmdb_id"] = str(tid)
            data = dict(data or {})
            if data:
                if tid:
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("vod:%s" % str(tid)), data, _DETAILS_DATA_CACHE_LIMIT)
                _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key(title_key), data, _DETAILS_DATA_CACHE_LIMIT)

            self._queueGui(self.applyDetails, data)
        except Exception:
            self._queueGui(self.applyDetails, {})


    def _startServerRecommendationResolve(self, data):
        snapshot=dict(data or {})
        token="%s:%s" % (
            str(self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("tmdb_id") or ""),
            str(self.item.get("name") or self.item.get("title") or "")
        )
        self._recommendResolveToken=token

        def worker():
            try:
                recs=self._serverOnlyTmdbRecommendations(snapshot)
            except Exception:
                recs=[]
            self._queueGui(self._applyServerRecommendations,token,recs)

        threading.Thread(
            target=worker,
            name="TiviMateServerRecommendations",
            daemon=True
        ).start()

    def _applyServerRecommendations(self, token, recs):
        if token != getattr(self,"_recommendResolveToken",""):
            return
        self.recommendations=list(recs or [])[:4]
        for i in range(4):
            item=self.recommendations[i] if i<len(self.recommendations) else None
            self["recLabel%d" % i].setText((item.get("name") or item.get("title") or "")[:34] if item else "")
            if item:
                # Backdrop only. Never show poster/cover in recommendation cards.
                # Keep the placeholder until a real backdrop is available.
                url=self._norm(
                    item.get("backdrop_path") or item.get("backdrop") or
                    item.get("backdrop_url"),
                    "w780"
                )
                if url:
                    self.loadImage(url,"rec%d" % i,400,190)
        self.updateFocus()
        # Download only the missing backdrop metadata. Existing backdrop URLs
        # already use the artwork queue's HDD/USB/RAM cache via loadImage.
        self._startRecommendationBackdropResolve(token, self.recommendations)


    def _startRecommendationBackdropResolve(self, token, items):
        # Cache-first: only rows with no backdrop need a TMDb lookup. Resolve
        # those at most two at a time; don't hold up three other cards behind
        # one slow provider or TMDb network response.
        rows = [
            (index, dict(row)) for index, row in enumerate(list(items or [])[:4])
            if isinstance(row, dict) and not (
                row.get("backdrop_path") or row.get("backdrop") or row.get("backdrop_url")
            )
        ]
        if not rows:
            return
        source_snapshot = dict(self.source or {})

        def resolve(index, row):
            title = str(row.get("name") or row.get("title") or "").strip()
            if not title:
                return None
            # Recheck persistent metadata, as another screen may have saved it.
            known = _recommend_backdrop_get(source_snapshot, row)
            if known.get("backdrop_path"):
                return index, known["backdrop_path"], known.get("tmdb_id") or ""
            tmdb = TMDbClient()
            tid = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbid") or "").strip()
            backdrop = ""
            resolved_id = tid
            if tid:
                try:
                    details = tmdb.details_bundle(tid, "vod") or {}
                    backdrop = details.get("backdrop_path") or ""
                    if not backdrop:
                        backdrop = next((pic.get("file_path") for pic in
                            ((details.get("images") or {}).get("backdrops") or [])
                            if isinstance(pic, dict) and pic.get("file_path")), "")
                except Exception:
                    pass
            if not backdrop:
                year = self._year(row) or None
                try:
                    found = tmdb.search_artwork(title, kind="vod", year=year,
                                                required_key="backdrop_path") or {}
                except Exception:
                    found = {}
                backdrop = found.get("backdrop_path") or ""
                resolved_id = str(found.get("tmdb_id") or found.get("id") or resolved_id or "").strip()
                if not backdrop:
                    try:
                        found = tmdb.search_artwork(title, kind="vod", year=year) or {}
                    except Exception:
                        found = {}
                    resolved_id = str(found.get("tmdb_id") or found.get("id") or resolved_id or "").strip()
                    if resolved_id:
                        try:
                            details = tmdb.details_bundle(resolved_id, "vod") or {}
                            backdrop = details.get("backdrop_path") or ""
                            if not backdrop:
                                backdrop = next((pic.get("file_path") for pic in
                                    ((details.get("images") or {}).get("backdrops") or [])
                                    if isinstance(pic, dict) and pic.get("file_path")), "")
                        except Exception:
                            pass
            if not backdrop:
                return None
            # Persist path/ID separately from the image bytes kept by the
            # artwork queue. This makes subsequent visits truly cache-first.
            _recommend_backdrop_put(source_snapshot, row, backdrop, resolved_id)
            return index, backdrop, resolved_id

        def worker():
            with ThreadPoolExecutor(max_workers=2) as executor:
                futures = [executor.submit(resolve, index, row) for index, row in rows]
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        if result:
                            self._queueGui(self._applyRecommendationBackdrops, token, [result])
                    except Exception:
                        pass

        threading.Thread(target=worker, name="TiviMateRecommendationBackdrops",
                         daemon=True).start()

    def _applyRecommendationBackdrops(self, token, updates):
        if token != getattr(self,"_recommendResolveToken",""):
            return
        for index,backdrop,tid in list(updates or []):
            if not (0 <= int(index) < len(self.recommendations)):
                continue
            try:
                item=self.recommendations[index]
                item["backdrop_path"]=backdrop
                if tid and not item.get("tmdb_id"):
                    item["tmdb_id"]=tid
                url=self._norm(backdrop,"w780")
                if url:
                    fallback_url=""
                    if isinstance(backdrop, str) and backdrop.startswith("/"):
                        fallback_url=self._norm(backdrop,"original")
                    self.loadImage(url,"rec%d" % index,400,190, fallback_url=fallback_url, retry=2)
            except Exception:
                pass


    def _movieLogoUrl(self, data):
        logos = ((data or {}).get("images") or {}).get("logos") or []
        return tmdb_logo_url(best_tmdb_logo(logos, logo_language()), "w500")

    def _applyMovieTitleLogoUrl(self, url):
        url = str(url or "").strip()
        if not url:
            return
        self.item["_player_movie_logo"] = url
        self.item["_player_movie_logo_lang"] = logo_language()
        self.loadImage(url, "logoImage", 500, 90)

    def _loadMovieTitleLogo(self, data):
        images = ((data or {}).get("images") or {})
        tid = str((data or {}).get("id") or self.item.get("tmdb_id") or self.item.get("tmdb") or "").strip()
        language = logo_language()
        token = "%s:%s" % (tid, language)
        self._movieTitleLogoToken = token
        # Cached TMDb metadata may carry just the English artwork list. Don't
        # render it ahead of an available Arabic/French/Turkish official logo.
        if has_language_logo(images.get("logos") or [], language):
            url = self._movieLogoUrl(data)
            if url:
                self._applyMovieTitleLogoUrl(url)
            return
        if not tid:
            url = self._movieLogoUrl(data)
            if url:
                self._applyMovieTitleLogoUrl(url)
            return
        def worker():
            try:
                client = TMDbClient()
                resolved = localized_logo_url(client, "movie", tid, images)
                if resolved and getattr(self, "_movieTitleLogoToken", "") == token:
                    self._queueGui(self._applyMovieTitleLogoUrl, resolved)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateMovieDetailsLogo", daemon=True).start()

    def _showMovieAgeCertification(self, token, certification):
        """Only show genuine German FSK pictograms, never text age badges.

        Other regional certificates such as R (US) have no suitable
        pictogram, so leave this space empty instead of showing a rectangle.
        The separate circular TMDb score stays untouched.
        """
        if token != getattr(self, "_movieAgeToken", ""):
            return
        self["ageIcon"].hide()
        value = str((certification or {}).get("certification") or "").strip()
        region = str((certification or {}).get("region") or "").upper()
        if region != "DE":
            return
        match = re.match(r"^(?:FSK\s*)?(0|6|12|16|18)\s*\+?$", value, re.I)
        if not match:
            return
        image = os.path.join(PLUGIN_PATH, "skins", "movies", "parental", "FSK_%s.png" % match.group(1))
        if os.path.isfile(image):
            try:
                self["ageIcon"].instance.setPixmapFromFile(image)
                self["ageIcon"].show()
            except Exception:
                pass

    def _loadMovieAgeCertification(self, data):
        # Opening Details must not block artwork, navigation or the video player.
        tmdb_id = str((data or {}).get("id") or self.item.get("tmdb_id") or self.item.get("tmdb") or "").strip()
        if not tmdb_id or tmdb_id == getattr(self, "_movieAgeToken", ""):
            return
        self._movieAgeToken = tmdb_id
        appended = (data or {}).get("release_dates")
        def worker():
            try:
                rating = TMDbClient().movie_age_certification(tmdb_id, appended)
            except Exception:
                rating = {}
            self._queueGui(self._showMovieAgeCertification, tmdb_id, rating)
        threading.Thread(target=worker, name="TiviMateMovieAgeCertification", daemon=True).start()

    def applyDetails(self, data):
        self._tmdb_bundle = dict(data or {})
        self._loadMovieAgeCertification(data)
        server_title = self.item.get("name") or self.item.get("title") or ""
        # Preserve Arabic provider titles on screen. TMDb English/localized title
        # is metadata fallback only and must not replace an existing Arabic name.
        selected_tmdb_language = TMDbClient().language.lower()
        title = preferred_metadata_text(data.get("title"), server_title, selected_tmdb_language) or "Movie"
        year = str(data.get("release_date") or self.item.get("releaseDate") or self.item.get("year") or "")[:4]
        rating = data.get("vote_average")
        genres = ", ".join(x.get("name", "") for x in (data.get("genres") or [])[:3])
        runtime = data.get("runtime") or ""
        self["title"].setText(title)
        self._loadMovieTitleLogo(data)
        self["meta"].setText("  •  ".join(x for x in [year, genres, ("%s min" % runtime) if runtime else ""] if x))
        show_score(self["ratingCircle"], rating)
        show_country_flag(self["countryFlag"], data, "movie", self.item.get("tmdb_id") or self.item.get("tmdb"))
        localized_overview = preferred_metadata_text(
            data.get("overview"), self.item.get("plot") or self.item.get("description"),
            selected_tmdb_language) or "No description available"
        self["desc"].setText(localized_overview[:700])
        # Text-only handoff to the existing VOD player. Leave artwork, stream
        # identity, subtitle and resume fields exactly as they were.
        self.item["_tmdb_metadata_locale"] = selected_tmdb_language
        self.item["_tmdb_metadata_title"] = title
        self.item["_tmdb_metadata_overview"] = localized_overview
        tmdb_poster = self._norm(data.get("poster_path"), "w500")
        server_poster = self.item.get("_resolved_server_poster") or _server_poster_url(self.source, self.item)
        tmdb_backdrop = self._norm(data.get("backdrop_path"), "w780")
        server_backdrop = self._norm(self.item.get("backdrop_path") or self.item.get("backdrop") or self.item.get("backdrop_url"), "w780")
        # Server poster is primary. TMDb is used only when the server
        # poster is missing/unavailable; the player itself performs no network lookup.
        poster = server_poster or tmdb_poster
        backdrop = tmdb_backdrop or server_backdrop
        if poster:
            self.item["_player_cover"] = poster
            self.item["poster_path"] = poster
            try:
                self.item["_player_cover_cache"] = artwork_path(poster, "posters")
            except Exception:
                self.item["_player_cover_cache"] = ""
            try:
                if server_poster and tmdb_poster and server_poster != tmdb_poster:
                    self.item["_player_cover_cache_fallback"] = artwork_path(tmdb_poster, "posters")
                else:
                    self.item["_player_cover_cache_fallback"] = ""
            except Exception:
                self.item["_player_cover_cache_fallback"] = ""
        if backdrop:
            self.item["_tmdb_backdrop"] = backdrop
        if data.get("id"):
            self.item["tmdb_id"] = str(data.get("id"))
        if data.get("title"):
            self.item["_tmdb_title"] = data.get("title")
        # Logo handoff is tagged with the TMDb locale so the native player
        # never reuses an English URL after switching to Arabic (or vice versa).
        try:
            _logos = ((data.get("images") or {}).get("logos") or [])
            _wanted = logo_language()
            _path = best_tmdb_logo(_logos, _wanted)
            if _path and has_language_logo(_logos, _wanted):
                self.item["_player_movie_logo"] = tmdb_logo_url(_path, "w500")
                self.item["_player_movie_logo_lang"] = _wanted
            else:
                self.item.pop("_player_movie_logo", None)
                self.item.pop("_player_movie_logo_lang", None)
        except Exception:
            pass
        if poster:
            self.loadImage(
                poster, "poster", 350, 525,
                fallback_url=(tmdb_poster if server_poster and tmdb_poster and poster == server_poster else "")
            )
        else:
            self._primaryArtworkComplete()
        if backdrop and not getattr(self, "_detailBackdropLocked", False):
            # Only fill the backdrop when the page opened without one. If an
            # initial backdrop is already visible, keep it instead of swapping.
            self._detailBackdropLocked = True
            self.loadImage(backdrop, "backdrop", 1920, 1080, fallback_url=(server_backdrop if backdrop != server_backdrop else ""))
        cast = ((data.get("credits") or {}).get("cast") or [])[:6]
        self.actors = [dict(x) for x in cast if isinstance(x, dict)]
        if self.actor_index >= len(self.actors):
            self.actor_index = 0
        for i in range(6):
            if i < len(cast):
                name = cast[i].get("name") or ""
                character = cast[i].get("character") or ""
                self["actorLabel%d" % i].setText((name + ("\n" + character if character else ""))[:45])
                profile = self._norm(cast[i].get("profile_path"), "w185")
                if profile:
                    self.loadImage(profile, "actor%d" % i, 120, 120)
                else:
                    try:
                        self["actor%d" % i].hide()
                    except Exception:
                        pass
            else:
                self["actorLabel%d" % i].setText(tr(""))
                try:
                    self["actor%d" % i].hide()
                except Exception:
                    pass
        # Recommendation rail is independent and started on page entry.
        # Never hide cached cards when a slower TMDb details callback arrives.
        self.updateFocus()
        if not getattr(self, "_recommendResolveToken", None):
            self._startServerRecommendationResolve(data)

    def loadImage(self, url, widget, width, height, fallback_url="", retry=1):
        """Render detail artwork reliably: primary URL, one retry, then fallback."""
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_url:
                return self.loadImage(fallback_url, widget, width, height, fallback_url="", retry=0)
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        token = "%s|%s" % (widget, url)
        requests[widget] = token
        priority = 100 if widget in ("poster", "backdrop") else 45
        def done(path, w=widget, x=width, y=height, expected=token):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            key = "%s|%sx%s" % (path, x, y)
            self.decode(path, w, x, y, key)

        def failed(_path, w=widget, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_image_requests", {}).get(w) != token:
                return
            if retries > 0:
                # One controlled retry only. request_artwork keeps cache/dedup logic.
                self.loadImage(primary, w, width, height, fallback_url=fb, retry=retries - 1)
            elif fb and fb != primary:
                self.loadImage(fb, w, width, height, fallback_url="", retry=0)


        if widget in ("backdrop", "hero") or str(widget).startswith(("trend", "rec")):
            cache_kind = "backdrops"
        elif widget == "logoImage":
            cache_kind = "logos"
        else:
            cache_kind = "posters"
        request_artwork(url, cache_kind, done, priority=priority, errback=failed)

    def _setWatchSearching(self):
        try:
            self["watch"].setText(tr("Searching..."))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                self["watch"].instance.setForegroundColor(parseColor("#17191D"))
        except Exception:
            pass

    def _setWatchReady(self):
        try:
            self["watch"].setText(tr("▶  Watch"))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#2E9D57"))
                self["watch"].instance.setForegroundColor(parseColor("#FFFFFF"))
        except Exception:
            pass

    def _setWatchUnavailable(self):
        try:
            self["watch"].setText(tr("Watch unavailable"))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#555B63"))
                self["watch"].instance.setForegroundColor(parseColor("#FFFFFF"))
        except Exception:
            pass

    def _setSourcesSearching(self):
        try:
            self["sources"].setText(tr("Searching Sources..."))
        except Exception:
            pass



    def _primaryArtworkComplete(self):
        if self._primaryArtworkReady:
            return
        self._primaryArtworkReady = True
        if self._watchReady:
            self._setWatchReady()
            return
        self._startWatchResolve()




    def _fastSearchMovieRows(self):
        """Fast first pass: use the complete warmed catalog, not cached query results."""
        if self._fastVodRowsCache is not None:
            return list(self._fastVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or {})
            client = XtreamClient(source) if source.get("type") == "xtream" else StalkerClient(source)
            rows = list(get_filtered_streams(source, "vod", client, use_cache=True) or [])
        except Exception:
            rows = []
        self._fastVodRowsCache = list(rows or [])
        return list(self._fastVodRowsCache)


    def _fullServerMovieRowsFallback(self):
        """Filtered-only fallback.

        Never expand a movie search into disabled/hidden packages. Both automatic
        and manual resolution obey exactly the same saved category filter.
        """
        if self._fullVodRowsCache is not None:
            return list(self._fullVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or self.source or {})
            client = get_source_client(source)
            rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
        except Exception:
            rows = []
        self._fullVodRowsCache = list(rows or [])
        return list(self._fullVodRowsCache)


    def _fastTitleCandidates(self, rows):
        raw_title = (
            self.item.get("_tmdb_title") or self.item.get("name") or
            self.item.get("title") or self.item.get("original_title") or ""
        )
        query = self._title_norm(raw_title)
        if not query:
            return []

        exact = []
        loose = []
        qtokens = [x for x in query.split() if len(x) > 1]

        for row in rows or []:
            name = self._title_norm(row.get("name") or row.get("title") or row.get("original_title") or "")
            if not name:
                continue
            if name == query:
                exact.append(row)
                continue
            ntokens = [x for x in name.split() if len(x) > 1]
            if query in name or name in query:
                loose.append(row)
                continue
            if qtokens and ntokens and all(token in ntokens for token in qtokens):
                loose.append(row)

        return exact + loose





    def _cachedServerMatch(self):
        cached = _title_match_cache_get(self._vodSelectedSource or self.source, self.item)
        if cached:
            return cached
        return None

    def _cachedServerMatchStatus(self):
        return _title_match_cache_status(self._vodSelectedSource or self.source, self.item)

    def _mergeResolvedMatch(self, match):
        original = dict(self.item or {})
        match = dict(match or {})
        for key in (
            "tmdb_id", "_tmdb_title", "backdrop_path", "rating",
            "plot", "description", "year", "_home_tmdb_feed",
            "_tmdb_provider", "_server_package_provider"
        ):
            if not match.get(key) and original.get(key):
                match[key] = original.get(key)
        self.item = match
        self._watchReady = True
        self._setWatchReady()
        try:
            self._updateProviderLogo()
        except Exception:
            pass

    def _forceWatchResolve(self):
        """Manual deep search from WATCH after an automatic miss."""
        if self._watchResolveStarted:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # Manual retry may bypass a cached miss, but it must NEVER bypass
                # the user's package/category filter.
                cached, cached_match = self._cachedServerMatchStatus()
                if cached_match is not None:
                    match = cached_match
                else:
                    source = dict(self._vodSelectedSource or self.source or {})
                    client = get_source_client(source)
                    rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    _title_match_cache_put(self._vodSelectedSource or self.source, self.item, None)
                    try:
                        self["watch"].setText(tr("▶  Watch / Search"))
                        if self["watch"].instance:
                            self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                            self["watch"].instance.setForegroundColor(parseColor("#17191D"))
                    except Exception:
                        pass
                    return
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, match)
                self._mergeResolvedMatch(match)

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchForceSearch")
        t.daemon = True
        t.start()


    def _startWatchResolve(self):
        if self._watchResolveStarted or self._watchReady:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # 0. Persistent cache includes both successful matches and real misses.
                # A cached miss stops automatic searching immediately.
                cache_known, cache_match = self._cachedServerMatchStatus()
                match = cache_match

                # 1. Already loaded FILTERED page/package data: essentially free.
                if not cache_known and match is None:
                    rows = list(self.server_items or [])
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 2. Enabled/filtered VOD catalog used by Search.
                if not cache_known and match is None:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 3. Full server VOD only when the fast filtered paths failed.
                if not cache_known and match is None:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    if not cache_known:
                        _title_match_cache_put(self._vodSelectedSource or self.source, self.item, None)
                    try:
                        self["watch"].setText(tr("▶  Watch / Search"))
                        if self["watch"].instance:
                            self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                            self["watch"].instance.setForegroundColor(parseColor("#17191D"))
                    except Exception:
                        pass
                    return
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, match)
                self._mergeResolvedMatch(match)

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchFilteredFirst")
        t.daemon = True
        t.start()




    def _searchSourcesOnDemand(self):
        if self._sourcesSearchRunning:
            return
        if self._sourcesSearchDone:
            self.showSources()
            return

        self._sourcesSearchRunning = True
        self._setSourcesSearching()

        def worker():
            sources = []
            used_rows = []
            try:
                exclude_primary = bool(self.item.get("stream_id") or self.item.get("vod_id"))

                # 0. Other Sources: RAM/HDD package cache first, with no provider request.
                # This is intentionally before warmed/server search so opening
                # Other Sources is instant whenever the movie already exists in cache.
                rows = self._cachedOtherSourceRows()
                if rows:
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows

                # 1. Existing warmed data.
                if not sources:
                    rows = list(self.server_items or [])
                    if rows:
                        candidates = self._fastTitleCandidates(rows)
                        sources = self._matchingServerSources(
                            candidates, exclude_primary=exclude_primary
                        )[:24]
                        used_rows = rows

                # 2. Filtered/enabled Search catalog.
                if not sources:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows

                # 3. Only if still zero, expand to full server VOD.
                if not sources:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows
            except Exception:
                sources = []

            def finish():
                self._sourcesSearchRunning = False
                self._sourcesSearchDone = True
                if used_rows:
                    self.server_items = list(used_rows)
                    self._sourceTitleIndex = None
                self.applySources(sources)
                self.showSources()

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateSourcesFilteredFirst")
        t.daemon = True
        t.start()


    def decode(self,path,widget,width,height,mem_key=None):
        key = mem_key or ("%s|%sx%s" % (path, width, height))
        ptr = _memory_get(_DETAILS_PIXMAP_CACHE, key)
        if ptr is not None:
            try:
                self._detail_pixmap_keys.add(key)
                if self[widget].instance: self[widget].instance.setPixmap(ptr)
                if widget == "logoImage":
                    try:
                        self["logoImage"].show()
                        self["title"].hide()
                    except Exception:
                        pass
                if str(widget).startswith("actor"):
                    self[widget].show()
                if str(widget).startswith("rec") and str(widget)[3:].isdigit():
                    try:
                        _idx = str(widget)[3:]
                        self["rec%s" % _idx].show()
                        self["recLabel%s" % _idx].show()
                        self["recShell%s" % _idx].show()
                    except Exception:
                        pass
                if widget == "poster":
                    self._primaryArtworkComplete()
                return
            except Exception:
                pass
        l=ePicLoad(); self.picloads.append(l)
        def ready(_=None,loader=l,w=widget,k=key):
            try:
                ptr=loader.getData()
                if ptr:
                    self._detail_pixmap_keys.add(k)
                    _memory_put(_DETAILS_PIXMAP_CACHE, k, ptr, _DETAILS_PIXMAP_CACHE_LIMIT)
                    if self[w].instance: self[w].instance.setPixmap(ptr)
                    if w == "logoImage":
                        try:
                            self["logoImage"].show()
                            self["title"].hide()
                        except Exception:
                            pass
                    if str(w).startswith("actor"):
                        self[w].show()
                    if str(w).startswith("rec") and str(w)[3:].isdigit():
                        try:
                            _idx = str(w)[3:]
                            self["rec%s" % _idx].show()
                            self["recLabel%s" % _idx].show()
                            self["recShell%s" % _idx].show()
                        except Exception:
                            pass
                    if w == "poster":
                        self._primaryArtworkComplete()
            except Exception:
                pass
            try:
                if loader in self.picloads:
                    self.picloads.remove(loader)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(l, ready, self, oneshot=True); l.setPara((render_width,render_height,0,0,False,1,"#00000000")); l.startDecode(path)

    def updateFocus(self):
        try:
            self["buttonSelector"].setVisible(self.focus=="buttons")
            self["actorSelector"].setVisible(self.focus=="actors" and bool(self.actors))
            self["recSelector"].setVisible(self.focus=="recommend" and bool(self.recommendations))
            if self.focus=="buttons": self["buttonSelector"].instance.move(ePoint(sx((475,765,1055)[max(0,min(2,self.button_index))]), sy(420)))
            if self.focus=="actors": self["actorSelector"].instance.move(ePoint(sx(self.ACTOR_X[self.actor_index]), sy(569)))
            if self.focus=="recommend": self["recSelector"].instance.move(ePoint(sx(self.REC_X[self.rec_index]), sy(840)))
        except Exception: pass

    def left(self):
        if self.focus=="buttons": self.button_index=max(0,self.button_index-1)
        elif self.focus=="actors": self.actor_index=max(0,self.actor_index-1)
        elif self.focus=="recommend": self.rec_index=max(0,self.rec_index-1)
        self.updateFocus()
    def right(self):
        if self.focus=="buttons": self.button_index=min(2,self.button_index+1)
        elif self.focus=="actors": self.actor_index=min(max(0,len(self.actors)-1),self.actor_index+1)
        elif self.focus=="recommend": self.rec_index=min(max(0,len(self.recommendations)-1),self.rec_index+1)
        self.updateFocus()
    def up(self):
        if self.focus=="recommend" and self.actors:
            self.focus="actors"
        else:
            self.focus="buttons"
        self.updateFocus()
    def down(self):
        if self.focus=="buttons" and self.actors:
            self.focus="actors"
        elif self.focus=="actors" and self.recommendations:
            self.focus="recommend"
        elif self.recommendations:
            self.focus="recommend"
        self.updateFocus()

    def _rowTmdbId(self, row):
        row = row or {}
        for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
            for key in ("tmdb_id", "tmdb", "tmdbid", "tmdbId"):
                value = mapping.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _recommendTitleNorm(self, value):
        text=str(value or "").lower()
        text=text.replace("&"," and ")
        text=re.sub(r"\b(?:netflix|nf|prime video|amazon prime|prime|amz|amzn)\b"," ",text)
        text=re.sub(r"\b(?:4k|uhd|fhd|fullhd|hd|sd|hdr|dv|dolby|atmos|hevc|x265|x264)\b"," ",text)
        text=re.sub(r"\b(?:multi|dual|audio|arabic|english|eng|ar|sub|subs|dub|dubbed)\b"," ",text)
        text=re.sub(r"\b(?:19|20)\d{2}\b"," ",text)
        text=re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}"," ",text)
        text=re.sub(r"[^a-z0-9]+"," ",text)
        return " ".join(text.split())

    def _recommendationMatches(self, target, rows):
        target = target or {}
        wanted_id = str(target.get("tmdb_id") or target.get("id") or "").strip()
        wanted_titles = [
            self._recommendTitleNorm(target.get(field))
            for field in ("name", "title", "original_title")
        ]
        wanted_titles = list(dict.fromkeys(x for x in wanted_titles if x))
        target_year = self._year(target)

        ranked = []
        seen = set()
        for row in rows or []:
            if not isinstance(row, dict):
                continue

            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            unique = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue

            exact_tmdb = bool(wanted_id and self._rowTmdbId(row) == wanted_id)
            candidate_titles = [
                self._recommendTitleNorm(row.get(field))
                for field in ("name", "title", "original_title")
            ]
            score = max(
                [self._title_score(w, c) for w in wanted_titles for c in candidate_titles] or [0.0]
            )

            if score < 0.90:
                for wanted in wanted_titles:
                    wanted_tokens = set(wanted.split())
                    if not wanted_tokens:
                        continue
                    for candidate in candidate_titles:
                        candidate_tokens = set(candidate.split())
                        if not candidate_tokens:
                            continue
                        overlap = wanted_tokens & candidate_tokens
                        coverage = float(len(overlap)) / float(max(1, min(len(wanted_tokens), len(candidate_tokens))))
                        if coverage >= 0.90 and len(overlap) >= 2:
                            score = max(score, 0.91)

            if not exact_tmdb and score < 0.84:
                continue

            row_year = self._year(row)
            exact_year = bool(target_year and row_year and target_year == row_year)
            if target_year and row_year and abs(target_year - row_year) > 1 and not exact_tmdb:
                continue

            ranked.append((1 if exact_tmdb else 0, 1 if exact_year else 0, score, dict(row)))
            seen.add(unique)

        ranked.sort(key=lambda value: (value[0], value[1], value[2]), reverse=True)
        return [value[3] for value in ranked]


    def ok(self):
        if self.focus=="actors" and self.actors:
            self._openActorMovies(self.actors[self.actor_index])
            return
        if self.focus=="buttons":
            if self.button_index==0:
                self.watchSelected()
            elif self.button_index==1:
                self.playTrailer()
            else:
                self.openMoreInfo()
            return
        if self.focus=="recommend" and self.recommendations:
            next_item=dict(self.recommendations[self.rec_index] or {})
            next_item["_source_scope"]=self._recommendationScope
            if self._recommendationCategoryId:
                next_item["_source_category_id"]=self._recommendationCategoryId
            self.session.open(
                MovieDetailsScreen,self.source,next_item,self.server_items,
                {"scope":self._recommendationScope,"category_id":self._recommendationCategoryId,"items":list(self.recommendation_items or [])}
            )
            return

    def _openActorMovies(self, actor):
        actor = dict(actor or {})
        person_id = str(actor.get("id") or "").strip()
        actor_name = str(actor.get("name") or "Actor").strip()
        if not person_id:
            self.session.open(MessageBox, tr("Actor information is unavailable."), MessageBox.TYPE_INFO)
            return
        if getattr(self, "_actorMoviesLoading", False):
            return
        self._actorMoviesLoading = True
        self["meta"].setText("Loading %s movies..." % actor_name)

        current_sid = str(self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("id") or "")
        current_tmdb = str(self.item.get("tmdb_id") or self.item.get("tmdb") or "")
        category_id = str(
            self.source_context.get("category_id") or
            self.item.get("_source_category_id") or
            self.item.get("category_id") or self.item.get("categoryId") or
            self._recommendationCategoryId or ""
        ).strip()
        context_rows = list(self.source_context.get("items") or [])

        def worker():
            matches = []
            try:
                # One TMDb credits lookup; search exactly six movie packages total:
                # current package + up to five other enabled/filtered packages.
                credits = TMDbClient().person_movie_credits(person_id) or {}
                cast_rows = [dict(x) for x in (credits.get("cast") or []) if isinstance(x, dict)]
                cast_rows.sort(key=lambda x: float(x.get("popularity") or 0), reverse=True)

                def exact_title(value):
                    return self._recommendTitleNorm(value)

                def collect_exact(rows, result_category_id):
                    before = len(matches)
                    by_title = {}
                    for row in (rows or []):
                        if not isinstance(row, dict):
                            continue
                        for field in ("name", "title", "original_title"):
                            key = exact_title(row.get(field))
                            if key:
                                by_title.setdefault(key, []).append(row)
                    for credit in cast_rows:
                        wanted = []
                        for field in ("name", "title", "original_title"):
                            key = exact_title(credit.get(field))
                            if key and key not in wanted:
                                wanted.append(key)
                        # Keep duplicates that really exist in different packages/rows,
                        # but do not append the same row twice through title aliases.
                        found = []
                        found_ids = set()
                        for key in wanted:
                            for row in (by_title.get(key) or []):
                                marker = id(row)
                                if marker in found_ids:
                                    continue
                                found_ids.add(marker)
                                found.append(row)
                        for row in found:
                            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
                            rtmdb = str(self._rowTmdbId(row) or "")
                            if (current_sid and sid == current_sid) or (current_tmdb and rtmdb and rtmdb == current_tmdb):
                                continue
                            result = dict(row)
                            result["_source_category_id"] = str(result_category_id or "")
                            matches.append(result)
                    return len(matches) - before

                # Build the six-package scope first: current + five other allowed packages.
                categories, _origin = get_cached_categories(self.source, "vod", wait_for_server=False)
                allowed_ids = get_allowed_category_ids(self.source, "vod")
                allowed_set = None if allowed_ids is None else set(str(x) for x in allowed_ids)
                blocked = {
                    "all", "all movies", "all films", "all vod",
                    "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المحتوى"
                }
                package_ids = []
                if category_id:
                    package_ids.append(category_id)
                for entry in (categories or []):
                    if len(package_ids) >= 6:
                        break
                    if not isinstance(entry, dict):
                        continue
                    cid = str(entry.get("category_id") or "").strip()
                    name = str(entry.get("category_name") or "").strip()
                    if not cid or cid in package_ids or cid == "__recent_added__":
                        continue
                    if allowed_set is not None and cid not in allowed_set:
                        continue
                    if name.lower() in blocked:
                        continue
                    package_ids.append(cid)

                # Current package rows already on screen are the fastest source.
                current_rows = []
                for row in (context_rows + list(self.server_items or [])):
                    if not isinstance(row, dict):
                        continue
                    rcid = str(row.get("category_id") or row.get("categoryId") or "").strip()
                    if not category_id or rcid == category_id:
                        current_rows.append(dict(row))
                cache_misses = []
                for cid in package_ids:
                    if cid == category_id and current_rows:
                        collect_exact(current_rows, cid)
                        continue
                    rows, cache_origin = peek_category_streams_cache(self.source, "vod", cid)
                    if cache_origin == "miss":
                        cache_misses.append(cid)
                        continue
                    collect_exact(rows, cid)

                # Fetch only uncached packages from the same six-package scope.
                if cache_misses:
                    client = get_source_client(self.source)
                    for cid in cache_misses:
                        rows, _server_origin = get_category_streams(
                            self.source, "vod", client, cid,
                            use_cache=True, wait_for_server=True
                        )
                        collect_exact(rows, cid)
            except Exception:
                matches[:] = []

            def finish():
                self._actorMoviesLoading = False
                self["meta"].setText("")
                if not matches:
                    self.session.open(MessageBox, "No movies for %s were found." % actor_name, MessageBox.TYPE_INFO)
                    return
                from .ui import MediaScreen
                self.session.open(MediaScreen, self.source, "vod", category_id, actor_name, matches)
            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateActorCacheMovies")
        t.daemon = True
        t.start()

    def _actorMovieChosen(self, item=None):
        if not item:
            return
        next_item = dict(item or {})
        self.session.open(
            MovieDetailsScreen, self.source, next_item, self.server_items,
            {"scope": self._recommendationScope, "category_id": self._recommendationCategoryId, "items": list(self.recommendation_items or [])}
        )

    def showSources(self):
        if not self.sources_list:
            self.session.open(MessageBox,"No exact alternate source is available for this movie.",MessageBox.TYPE_INFO)
            return
        rows = []
        for x in self.sources_list:
            label = x.get("name") or x.get("title") or "Source"
            if x.get("_other_sources_current"):
                label = "Current Source  •  %s" % label
            rows.append((label, x))
        self.session.openWithCallback(self.sourceChosen, SourceChoiceScreen, rows, "EXACT MATCHING SOURCES", self.source, self.item)
    def sourceChosen(self,item=None):
        if item: self.playItem(item)
    def toggleFavourite(self):
        item = self._playable_item() or self.item
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, "vod", item)
            title = item.get("name") or item.get("title") or "الفيلم"
            if not saved:
                self["meta"].setText(tr("Unable to save favorite"))
            elif added:
                self["meta"].setText("★ تمت إضافة %s إلى المفضلات" % title)
            else:
                self["meta"].setText("☆ تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["meta"].setText("تعذر تحديث المفضلة: %s" % exc)


    def _resolveHomeMovieForPlay(self):
        if getattr(self, "_homePlayResolving", False):
            return

        cached = self._cachedServerMatch()
        if cached:
            self.sources_list = [cached]
            self.playItem(cached)
            return

        # Home passes a warmed server VOD index. Resolve synchronously in memory
        # first; this avoids the visible search delay for Backdrop movies.
        if self.server_items:
            wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
            wanted = list(dict.fromkeys(x for x in wanted if x))
            target_year = self._year(self.item)
            best = None
            best_score = 0.0
            for row in self.server_items:
                candidate_titles = [self._title_norm((row or {}).get(field)) for field in ("name","title","original_title")]
                score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                if not score:
                    continue
                row_year = self._year(row or {})
                if target_year and row_year and abs(target_year-row_year) > 1:
                    continue
                if target_year and row_year == target_year:
                    score += 0.02
                if score > best_score:
                    best, best_score = dict(row), score
            if best is not None and best_score >= 0.90:
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, best)
                self.sources_list = [best]
                self.playItem(best)
                return

        self._homePlayResolving = True
        # Keep WATCH label stable; the lookup is background-only.
        # This avoids a visible loading/search state for short cache misses.
        wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        source = dict(self.source or {})

        def worker():
            best = None
            best_score = 0.0
            try:
                client = get_source_client(source)
                rows = list(self._fullServerVodCatalog() or [])
                for row in rows:
                    candidate_titles = [self._title_norm(row.get(field)) for field in ("name","title","original_title")]
                    score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                    if not score:
                        continue
                    row_year = self._year(row)
                    if target_year and row_year and abs(target_year-row_year)>1:
                        continue
                    bonus = 0.02 if target_year and row_year == target_year else 0.0
                    if score + bonus > best_score:
                        best = dict(row); best_score = score + bonus
                if best_score < 0.90:
                    best = None
            except Exception:
                best = None

            def finish():
                self._homePlayResolving = False
                self["watch"].setText(tr("▶  Watch"))
                if not best:
                    self.session.open(MessageBox, tr("This movie is not available on the current server."), MessageBox.TYPE_INFO)
                    return
                # Keep the rich TMDb artwork/details while provider identity drives playback.
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                self.sources_list = [best]
                self.playItem(best)
            self._queueGui(finish)

        t=threading.Thread(target=worker,name="TiviMateHomeMoviePlayResolve")
        t.daemon=True; t.start()


    def openMoreInfo(self):
        # Same-movie artwork only. Reuse the already resolved TMDb id/bundle;
        # the More Info screen performs an images-only fallback when needed.
        tmdb_id = str(self.item.get("tmdb_id") or self.item.get("tmdb") or "").strip()
        bundle = dict(getattr(self, "_tmdb_bundle", {}) or {})
        if not tmdb_id:
            tmdb_id = str(bundle.get("id") or "").strip()
        if not tmdb_id:
            self.session.open(MessageBox, tr("Movie images are still loading."), MessageBox.TYPE_INFO)
            return
        self.session.open(MovieMoreInfoScreen, self.item, tmdb_id, bundle, self._searchSourcesOnDemand)

    def playTrailer(self):
        # Self-contained path: TMDb exact trailer ID -> bundled YouTube resolver -> Enigma2 player.
        # No Browser plugin and no external yt-dlp package are required.
        if getattr(self, "_trailerResolving", False):
            return
        item = dict(self.item or {})
        bundle = dict(getattr(self, "_tmdb_bundle", {}) or {})
        tid = item.get("tmdb_id") or item.get("_locked_tmdb_id") or bundle.get("id") or bundle.get("tmdb_id")
        try:
            tid = int(str(tid or "0").strip())
        except Exception:
            tid = 0
        if tid <= 0:
            self.session.open(MessageBox, "Trailer information is still loading.", MessageBox.TYPE_INFO)
            return
        self._trailerResolving = True
        try: self["trailer"].setText("Loading...")
        except Exception: pass

        def worker():
            result = {"state": "failed"}
            try:
                # Trailer lookup is independent of the user's TMDb metadata
                # language. Keep Arabic/localized UI details untouched and
                # request English video entries for this exact TMDb movie ID.
                tmdb = TMDbClient(language="en-US")
                payload = tmdb.media_videos(tid, "vod") or {}
                rows = payload.get("results") or [] if isinstance(payload, dict) else []
                candidates = []
                for row in rows:
                    if not isinstance(row, dict): continue
                    if str(row.get("site") or "").strip().lower() != "youtube": continue
                    if str(row.get("type") or "").strip().lower() != "trailer": continue
                    key = str(row.get("key") or "").strip()
                    if not key: continue
                    name = str(row.get("name") or "Trailer").strip() or "Trailer"
                    official = bool(row.get("official"))
                    lang = str(row.get("iso_639_1") or "").strip().lower()
                    # Do not silently select an Arabic/other-language trailer
                    # when TMDb details are displayed in Arabic.
                    if lang != "en":
                        continue
                    score = (100 if official else 0) + (40 if "official trailer" in name.lower() else (20 if "official" in name.lower() else 0))
                    try: score += min(6, max(0, int(row.get("size") or 0) // 360))
                    except Exception: pass
                    candidates.append((score, str(row.get("published_at") or ""), row))
                if not candidates:
                    result = {"state": "missing"}
                else:
                    candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)
                    chosen = candidates[0][2]
                    key = str(chosen.get("key") or "").strip()
                    # Enigma2 4097 trailer path: accept only ONE progressive MP4
                    # containing both video and audio.  Do not feed MoviePlayer
                    # DASH/video-only URLs or the old ``&suburi=`` split pair.
                    from .services.ultrastalker_youtube import UltraYouTubeResolver
                    direct = str(UltraYouTubeResolver().extract_progressive(key, timeout=15) or "").strip()
                    if direct:
                        result = {"state": "ready", "url": direct, "name": str(chosen.get("name") or "Trailer")}
                    else:
                        result = {"state": "no_stream"}
            except Exception as exc:
                result = {"state": "error", "error": str(exc)}

            def finish():
                self._trailerResolving = False
                try: self["trailer"].setText("▶  Trailer")
                except Exception: pass
                state = result.get("state")
                if state == "missing":
                    self.session.open(MessageBox, "No English trailer available for this movie.", MessageBox.TYPE_INFO); return
                if state != "ready":
                    msg = "YouTube did not provide a progressive MP4 trailer with video + audio."
                    if result.get("error"): msg += "\n\n" + str(result.get("error"))[:350]
                    self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR); return
                try:
                    # Keep the proven 4097 + single progressive MP4 path, but
                    # render it in a centered popup over Movie Details instead of
                    # replacing the details screen with the full movie player.
                    trailer_url = str(result.get("url") or "").strip()
                    trailer_name = str(result.get("name") or "Trailer").strip() or "Trailer"
                    ref = eServiceReference(4097, 0, trailer_url)
                    try: ref.setName(trailer_name)
                    except Exception: pass
                    # Open Trailer as a real popup screen, exactly like the Other Sources
                    # flow: Movie Details remains underneath and BACK closes only the popup.
                    # Do not reuse/attach an overlay dialog to the Watch action.
                    self.session.open(TrailerPopupScreen, ref, trailer_name, self)
                except Exception as exc:
                    self.session.open(MessageBox, "Trailer player failed:\n%s" % exc, MessageBox.TYPE_ERROR)
            if reactor is not None:
                try:
                    reactor.callFromThread(finish); return
                except Exception: pass
            self._queueGui(finish)

        try:
            t = threading.Thread(target=worker, name="TiviMateTrailerEmbeddedYT")
            t.daemon = True; t.start()
        except Exception as exc:
            self._trailerResolving = False
            try: self["trailer"].setText("▶  Trailer")
            except Exception: pass
            self.session.open(MessageBox, "Trailer failed:\n%s" % exc, MessageBox.TYPE_ERROR)

    def _closeTrailerOverlay(self):
        dlg = getattr(self, "_trailerOverlay", None)
        if dlg is None:
            return False
        self._trailerOverlay = None
        try:
            if self.session.current_dialog is dlg:
                dlg.close()
            else:
                self.session.deleteDialog(dlg)
        except Exception:
            pass
        return True

    def _cancelOrCloseTrailer(self):
        if self._closeTrailerOverlay():
            return
        self.close()

    def watchSelected(self):
        item = dict(self.item or {})
        # Watch is movie-only. Trailer playback must stay on the Trailer action.
        if item.get("_is_trailer") or str(item.get("_kind") or "").lower() == "trailer":
            self._forceWatchResolve()
            return
        for _k in ("url", "stream_url"):
            _u = str(item.get(_k) or "").lower()
            if "youtube.com" in _u or "youtu.be" in _u or "googlevideo.com" in _u:
                item.pop(_k, None)
        if not self._watchReady or not (item.get("stream_id") or item.get("vod_id")):
            self._forceWatchResolve()
            return
        item["_kind"] = "vod"
        item.pop("_is_trailer", None)
        self.playItem(item)


    def playItem(self,item):
        try:
            row = _movie_continue_row(self.source, item)
            if not row:
                raise Exception("No playable URL")
            from .ui import play_vod_exact_continue_path
            play_vod_exact_continue_path(
                self.session,
                row,
                current_source=dict(self.source or {}),
                callback=None
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to play:\n%s" % exc, MessageBox.TYPE_ERROR)

SOURCE_CHOICE = '''<screen name="SourceChoiceScreen" position="330,160" size="1260,760" flags="wfNoBorder" backgroundColor="#20242A">
<widget name="movieLogo" position="45,28" size="330,82" alphatest="blend" zPosition="3" />
<widget name="movieTitle" position="45,35" size="330,65" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="poster" position="65,120" size="290,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="title" position="405,30" size="805,55" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" />
<widget name="list" position="405,110" size="805,500" font="Regular;27" itemHeight="54" scrollbarMode="showOnDemand" backgroundColor="#20242A" foregroundColor="#FFFFFF" selectionBackgroundColor="#3A414B" selectionForegroundColor="#F2D36B" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="405,632" size="805,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/source_choice_guide_r69.png" alphatest="blend" zPosition="3" />
</screen>'''

SOURCE_CHOICE = scale_skin(SOURCE_CHOICE)

class SourceChoiceScreen(Screen):
    skin=SOURCE_CHOICE
    def __init__(self,session,rows,title="EXACT MATCHING SOURCES",source=None,movie_item=None):
        Screen.__init__(self,session); self.rows=rows or []
        self.source=dict(source or {}); self.movie_item=dict(movie_item or {})
        self["title"]=Label(title)
        self["list"]=MenuList([(x[0],x[1]) for x in self.rows])
        self["keys"]=Label(tr("OK Play     EXIT Back"))
        self["guideBar"]=Pixmap(); self["poster"]=Pixmap(); self["movieLogo"]=Pixmap()
        self["movieTitle"]=Label(self.movie_item.get("name") or self.movie_item.get("title") or "")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.ok,"cancel":self.close,"up":lambda:self["list"].up(),"down":lambda:self["list"].down()},-1)
        self.onLayoutFinish.append(self._loadMovieArtwork)

    def _loadMovieArtwork(self):
        item=self.movie_item or {}
        poster=str(item.get("_tmdb_poster") or item.get("stream_icon") or item.get("cover") or item.get("poster") or item.get("poster_path") or "").strip()
        if poster and poster.startswith("/") and item.get("_tmdb"):
            poster="https://image.tmdb.org/t/p/w500" + poster
        elif poster:
            poster=_server_asset_url(self.source, poster)
        logo=str(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "").strip()
        if logo and logo.startswith("/") and item.get("_tmdb"):
            logo="https://image.tmdb.org/t/p/w500" + logo
        elif logo:
            logo=_server_asset_url(self.source, logo)

        def set_image(widget, url, kind):
            if not url:
                return
            def done(path):
                try:
                    if path and os.path.exists(path):
                        self[widget].instance.setPixmapFromFile(path); self[widget].show()
                        if widget == "movieLogo": self["movieTitle"].hide()
                except Exception:
                    pass
            try: request_artwork(url, kind, done, priority=0)
            except Exception: pass
        set_image("poster", poster, "posters")
        set_image("movieLogo", logo, "logos")

    def ok(self):
        c=self["list"].getCurrent()
        if c:self.close(c[1])



def _screen_content_dedupe_key(item, kind=""):
    row = item or {}
    tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
    if tmdb_id and tmdb_id not in ("0", "None", "none"):
        return "tmdb:%s:%s" % (str(kind or ""), tmdb_id)
    title = str(row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or "").lower().strip()
    title = re.sub(r"[\[\(][^\]\)]*(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264|arabic|english|multi)[^\]\)]*[\]\)]", " ", title, flags=re.I)
    title = re.sub(r"(?<![a-z0-9])(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264)(?![a-z0-9])", " ", title, flags=re.I)
    title = re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", title)).strip()
    year = str(row.get("year") or row.get("release_date") or row.get("releaseDate") or row.get("first_air_date") or "").strip()
    m = re.search(r"(?:19|20)\d{2}", year)
    year = m.group(0) if m else ""
    if title:
        return "title:%s:%s:%s" % (str(kind or ""), title, year)
    provider_id = str(row.get("series_id") or row.get("stream_id") or row.get("vod_id") or row.get("id") or "").strip()
    return "id:%s:%s" % (str(kind or ""), provider_id) if provider_id else ""


def _screen_dedupe_content(items, kind=""):
    out, seen = [], set()
    for item in list(items or []):
        key = _screen_content_dedupe_key(item, kind)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        out.append(item)
    return out



# ---------------------------------------------------------------------------
# Content home screen
# ---------------------------------------------------------------------------

class ContentHomeScreen(Screen):
    # Independent fixed limits: top backdrop row is always 12,
    # while Backdrop poster content remains 50.
    BACKDROP_ITEM_LIMIT = 12
    POSTER_ITEM_LIMIT = 50

    skin = CONTENT_HOME

    TOP = ["Home", "Search", "Live", "Movies", "TV Shows", "Packages", "GENRE", "Resume", "Server Finder", "Settings", "Favorites"]
    TOP_X = [20, 190, 360, 530, 700, 870, 1040, 1210, 1380, 1550, 1720]
    TOP_W = [170] * 11
    BACKDROP_X = [80, 535, 990, 1445]
    LATEST_X = [80, 295, 510, 725, 940, 1155, 1370, 1585]

    def _title_score(self, wanted, candidate):
        """Strict normalized title score used by Backdrop server matching."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens = set(wanted.split())
        candidate_tokens = set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0

        # Safe containment only when nearly the whole meaningful title matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94

        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0



    def __init__(self, session, source, kind, initialMode=None, actorRows=None, actorName=""):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source, self.kind = source, kind
        self._actorRows = list(actorRows or [])
        self._actorName = str(actorName or "").strip()
        self._actorMode = bool(self._actorRows and self._actorName)
        self.contentGeneration = 0
        self.contentMode = _content_default_mode(kind)

        # Recent has its own request generation and stable last-good result.
        # An old/empty response is never allowed to erase a newer visible row.
        self.recentRequestToken = 0
        self.recentStable = []
        self.focus = "top"
        self.topIndex = 3 if kind == "vod" else 4
        self.backdrops, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        # Fast package switching: build category indexes once, then every
        # red/blue package change is RAM-only with no timer/network wait.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        # Complete package responses loaded in this screen only.
        # Key = exact provider category_id, value = full provider response.
        self._fullPackageRows = {}
        self._categorySwitchPreviewNow = False
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        self.categoryLoadToken = 0
        # Stalker category requests run in a worker.  Do not rely on Twisted
        # being integrated with Enigma2: the eTimer below is the only route that
        # applies a finished red/blue category request to the GUI thread.
        self.stalkerCategoryLoadResult = None
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadTimer = eTimer()
        try:
            self._stalkerCategoryLoadTimer_conn = self.stalkerCategoryLoadTimer.timeout.connect(self._finishStalkerCategoryLoad)
        except Exception:
            try:
                self.stalkerCategoryLoadTimer.callback.append(self._finishStalkerCategoryLoad)
            except Exception:
                self.stalkerCategoryLoadTimer.timeout.get().append(self._finishStalkerCategoryLoad)
        self.sortMode = "default"
        self.backdropStart = self.backdropIndex = self.latestStart = self.latestIndex = 0
        self.downloads, self.picloads = [], []
        self._image_requests = {}
        # One main-thread dispatcher is used for every worker result on Movies
        # and TV Shows.  Network/poster work stays in the background exactly as
        # before; only the final widget update is serialized on Enigma2's GUI
        # thread.  This prevents red/blue/yellow/navigation restarts on images
        # where Twisted exists but is not integrated with the Enigma2 mainloop.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        # VOD list rows frequently contain only poster art.  Delay the richer
        # backdrop lookup briefly so rapid navigation never starts one network
        # request per key press, then discard every stale result by token.
        self._previewRequestId = 0
        self._previewBackdropPending = None
        # Movies metadata uses the same cache-first path as TV Shows.
        # Visible movie cards are warmed quietly so hero/details navigation does
        # not wait for a fresh TMDb search on every key press.
        self._metadataWarmKeys = set()
        self._previewBackdropTimer = eTimer()
        try:
            self._previewBackdropTimer_conn = self._previewBackdropTimer.timeout.connect(self._beginPreviewBackdropLookup)
        except Exception:
            try:
                self._previewBackdropTimer.callback.append(self._beginPreviewBackdropLookup)
            except Exception:
                self._previewBackdropTimer.timeout.get().append(self._beginPreviewBackdropLookup)
        for i, text in enumerate(self.TOP): self["top%d" % i] = Label(nav_label(text))
        self["topSelector"] = Pixmap()
        self["hero"] = Pixmap(); self["logoImage"] = Pixmap(); self["logoHintIcon"] = Pixmap(); self["logoHint"] = Label("LOGO"); self["logoTitle"] = DirectionalLabel(""); self["heroMeta"] = DirectionalLabel(""); self["heroDesc"] = DirectionalLabel("")
        self["heroPlay"] = Label("▶  " + tr("Play")); self["heroInfo"] = Label("ⓘ  " + tr("More Info"))
        # Fixed top hero/backdrop title. Setting #6 only changes the lower row.
        primary_title = "Movies You Might Like" if kind == "vod" else "TV Shows You Might Like"
        self["backdropTitle"] = Label((self._actorName + (" - TV SHOWS" if kind == "series" else " - MOVIES")) if self._actorMode else tr(primary_title))
        self["latestTitle"] = Label(tr("TV Shows" if kind == "series" else "Movies") if self._actorMode else tr(_content_mode_title(kind, self.contentMode)))
        self["latestCategoryName"] = Label("")
        for i in range(4):
            self["backdrop%d" % i] = Pixmap(); self["rank%d" % i] = Label("")
            self["backdropLabel%d" % i] = Label(""); self["backdropRate%d" % i] = Label("")
        for i in range(8):
            self["latest%d" % i] = Pixmap()
            self["latestShell%d" % i] = Pixmap()
            self["latestBadge%d" % i] = Pixmap()
            self["latestLabel%d" % i] = Label(""); self["latestRate%d" % i] = Label("")
        self["backdropSelector"] = Pixmap(); self["latestSelector"] = Pixmap()
        self["footer"] = Label(""); self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "red": self.previousCategory, "green": self.categories, "yellow": self.toggleSort,
            "yellowlong": self.addCurrentFavourite, "blue": self.nextCategory
        }, -1)
        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkResources)
        self.onClose.append(self._stopStalkerCategoryLoadTimer)


    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(120, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(120, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _applyArabicHeadingLayout(self):
        if get_language() != "ar":
            return
        try:
            for name, y in (("trendingTitle", 500), ("latestTitle", 772)):
                widget = self[name]
                if widget and widget.instance:
                    widget.instance.move(ePoint(sx(1110), sy(y)))
                    widget.instance.resize(eSize(sx(730), sy(45)))
                    try:
                        widget.instance.setHAlign(2)
                    except Exception:
                        pass
        except Exception:
            pass

    def _layoutReady(self):
        self._applyArabicHeadingLayout()
        self._positionLatestCategoryName()
        self._startGuiDispatch()
        self.start()

    def _releaseArtworkResources(self):
        self._image_requests = {}
        self.downloads = []
        self.picloads = []

    def _stopStalkerCategoryLoadTimer(self):
        # Invalidate workers before screen teardown, so a late portal reply
        # cannot attempt to repaint a screen that no longer exists.
        self.categoryLoadToken = getattr(self, "categoryLoadToken", 0) + 1
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadResult = None
        try:
            self.stalkerCategoryLoadTimer.stop()
        except Exception:
            pass

    def start(self):
        if self._actorMode:
            self.serverItems = list(self._actorRows)
            self.categoryItems = list(self._actorRows)
            self.latest = list(self._actorRows)
            self.backdrops = []
            self.latestStart = self.latestIndex = 0
            self.categoryName = self._actorName
            self.focus = "latest"
            self["latestCategoryName"].setText("")
            self["heroDesc"].setText("%d movies available on this server" % len(self.latest))
            self.renderBackdrops()
            self.renderLatest()
            self.updateFocus()
            self.preview()
            return
        # Recent opens from a dedicated last-good cache. Keep it visible while
        # the server refresh runs; never blank the row during a second request.
        if self.contentMode == "recent":
            cache_mode = "recent_%s" % self.kind
            cached_latest = _home_feed_cache_get(cache_mode, self.source, allow_stale=True)
            if not cached_latest:
                cached_latest = _load_content_landing_cache(self.source, self.kind)
            if cached_latest:
                self.recentStable = self._sortedItems(cached_latest)
                self.latest = _screen_dedupe_content(self.recentStable, self.kind)
                self.latestStart = self.latestIndex = 0
                self.categoryName = "RECENT ADDED"
                self._updateLatestTitle()
                self.renderLatest()
        self.updateFocus()
        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentHome"); t.daemon = True; t.start()

    def worker(self, generation=None):
        if generation is None:
            generation = self.contentGeneration

        # Series server-first path:
        # Render the selected Series package before doing any Backdrop work.
        # Backdrop can never delay the first usable Series content on a cold
        # Enigma image. No extra timer/hook/module is introduced here.
        if self.kind == "series":
            self._loadServer(generation)
            if generation != self.contentGeneration:
                return
            self._loadBackdrops(generation)
            return

        # Movies keeps its existing parallel path.
        trend_thread = threading.Thread(target=self._loadBackdrops, args=(generation,), name="TiviMateBackdrops")
        trend_thread.daemon = True
        trend_thread.start()
        self._loadServer(generation)

    def _loadServer(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        source = dict(self.source or {})
        kind = self.kind
        try:
            client = get_source_client(source)

            # FILTER IS AUTHORITATIVE.
            _package_diag("LOAD_SERVER_BEGIN", source=source.get("name") or source.get("url") or "", source_type=source.get("type") or "", kind=kind, mode=self.contentMode)
            raw_categories, _origin = get_cached_categories(
                source, kind, client=client, wait_for_server=True
            )
            filtered = filter_categories(source, kind, raw_categories or [])
            _package_diag("CATEGORIES", kind=kind, origin=_origin, raw_count=len(raw_categories or []), filtered_count=len(filtered or []))

            # Keep provider category rows untouched.  Only accept rows that have
            # a real provider id usable by the same endpoint as the big page.
            categories = []
            seen = set()
            for row in filtered:
                if not isinstance(row, dict):
                    continue
                cid = str(
                    row.get("category_id")
                    or row.get("id")
                    or row.get("genre_id")
                    or row.get("group_id")
                    or ""
                ).strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                entry = dict(row)
                entry["category_id"] = cid
                if not entry.get("category_name"):
                    entry["category_name"] = (
                        entry.get("name")
                        or entry.get("title")
                        or entry.get("genre")
                        or "Other"
                    )
                categories.append(entry)
                _package_diag("CATEGORY_ENABLED", kind=kind, category_id=cid, category_name=entry.get("category_name") or "")

            _package_diag("CATEGORIES_READY", kind=kind, count=len(categories))
            if not categories:
                raise RuntimeError("No enabled packages are available for this library.")

            # Recent Added remains its own setting/feed.  It does not modify the
            # normal package list or package navigation.
            if self.contentMode == "recent":
                # Recent Added is intentionally simple. Build the Recent
                # ordering, keep only the newest twenty-five rows, and resolve TMDb
                # metadata for those twenty-five only. No partial first-package paint,
                # no progressive 5+5 worker, and no metadata work for the rest.
                self.recentRequestToken += 1
                recent_token = self.recentRequestToken

                # Both the visible Recent Add page and the notification watcher
                # use this single enabled-package feed. Other package pages are
                # unaffected and Recent retains its latest-25 presentation.
                from .recent_feed import recent_added_items
                try:
                    recent = recent_added_items(source, kind, client, categories, 25)
                except Exception:
                    recent = []

                # Shared Recent fast-path for Movies + TV Shows:
                # Paint the newest 25 from provider rows immediately. Do not block
                # either Recent page on synchronous TMDb/details enrichment. Normal
                # lazy poster/details fallback remains available after the GUI paints.

                self._queueGui(
                    self.recentReady,
                    recent_token, recent, categories, generation, False
                )
                return

            # NORMAL PACKAGES:
            # Xtream: use the same provider-wide catalogue path that Recent uses.
            # Group that fresh catalogue back into the user's enabled packages,
            # then sort each package by the provider add/update timestamp. This
            # keeps package navigation unchanged while avoiding provider category
            # responses whose order may be stale or arbitrary.
            first = categories[0]
            first_id = str(first.get("category_id") or "")
            first_name = first.get("category_name") or "Other"
            first_items = []
            if kind in ("vod", "series") and source.get("type") == "xtream":
                # Fast package landing for BOTH Movies and Series.  Never download
                # the provider-wide catalogue just to paint the first small-poster
                # row: that request can be very large on Xtream servers.  Use the
                # selected package RAM/disk cache first, and on a real miss fetch
                # only that package.  The same per-package cache is then reused by
                # Prev/Next package navigation.
                _package_diag("FIRST_PACKAGE_FAST_FETCH_BEGIN", kind=kind, category_id=first_id, category_name=first_name)
                first_items, first_origin = get_category_streams(
                    source, kind, client, first_id, use_cache=True, wait_for_server=True
                )
                first_items = self._sortedItems(first_items)
                if first_items:
                    self._fullPackageRows[first_id] = list(first_items)
                _package_diag("FIRST_PACKAGE_FAST_FETCH_DONE", kind=kind, category_id=first_id, category_name=first_name, origin=first_origin, item_count=len(first_items))
            else:
                _package_diag("FIRST_PACKAGE_FETCH_BEGIN", kind=kind, category_id=first_id, category_name=first_name)
                first_items = list(client.streams(kind, first_id) or [])
                first_items = self._sortedItems(first_items)
                _package_diag("FIRST_PACKAGE_FETCH_DONE", kind=kind, category_id=first_id, category_name=first_name, item_count=len(first_items))

            # Pass the full first package to GUI. Other packages are fetched only
            # when Prev/Next selects them.
            self._queueGui(
                self.serverReady,
                first_items, first_items, categories,
                {"category_id": first_id, "category_name": first_name},
                generation
            )
        except Exception as exc:
            _package_diag("LOAD_SERVER_ERROR", kind=kind, error=repr(exc))
            self._queueGui(self.serverFailed, str(exc), generation)


    def _loadBackdrops(self, generation=None):
        """Fast random Backdrop rail from enabled packages only.

        The rail never leaves the user's active Movies/TV Shows package filter.
        It samples enabled packages in a random order,
        accepts content from any year, removes duplicate titles, limits one
        package from dominating the row, and caches the final random selection
        so normal page opens stay fast.
        """
        if generation is None:
            generation = self.contentGeneration
        kind = self.kind
        page_kind = "vod" if self.kind == "vod" else "series"
        source = dict(self.source or {})
        try:
            saved_allowed = get_allowed_category_ids(source, page_kind)
            client = get_source_client(source)
            category_names = {}
            category_order = []
            m3u_entries = None
            categories_seed = None

            # Fast Backdrop startup:
            # - Existing saved package filters use RAM/disk metadata immediately.
            # - A brand-new image/server may read categories once to discover the
            #   currently enabled package IDs.
            # - An empty result stays silent and never triggers a blocking retry.
            if saved_allowed is None:
                cache_version = "v29_2026_12_all_enabled"
                cache_mode = "backdrop_all_enabled_%s_%s_all" % (cache_version, page_kind)
                fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
                if fresh_cached:
                    self._queueGui(
                        self.backdropsReady,
                        fresh_cached[:self.BACKDROP_ITEM_LIMIT],
                        generation, []
                    )
                    return

                if source.get("type") in ("m3u", "fg"):
                    try:
                        m3u_entries, _m3u_origin = get_cached_catalog(
                            source, "live", lambda: M3UClient(source).entries(),
                            wait_for_server=True
                        )
                    except Exception:
                        m3u_entries = []
                    allowed = set(
                        str((row or {}).get("group") or (row or {}).get("category_id") or "").strip()
                        for row in (m3u_entries or [])
                        if isinstance(row, dict)
                    )
                else:
                    try:
                        categories_seed, _cat_origin = get_cached_categories(
                            source, page_kind, client=client, wait_for_server=True
                        )
                    except Exception:
                        categories_seed = []
                    allowed = set(
                        str((cat or {}).get("category_id") or (cat or {}).get("id") or
                            (cat or {}).get("genre_id") or (cat or {}).get("group_id") or "").strip()
                        for cat in (categories_seed or [])
                        if isinstance(cat, dict)
                    )
            else:
                allowed = set(str(x) for x in (saved_allowed or []) if str(x))
                if not allowed:
                    self._queueGui(self.backdropsReady, [], generation, [])
                    return

                filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
                cache_version = "v29_2026_12_all_enabled"
                cache_mode = "backdrop_all_enabled_%s_%s_%s" % (cache_version, page_kind, filter_sig)
                fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
                if fresh_cached:
                    self._queueGui(
                        self.backdropsReady,
                        fresh_cached[:self.BACKDROP_ITEM_LIMIT],
                        generation, []
                    )
                    return
            if source.get("type") in ("m3u", "fg"):
                try:
                    m3u_entries, _m3u_origin = get_cached_catalog(
                        source, "live", lambda: M3UClient(source).entries(),
                        wait_for_server=True
                    )
                except Exception:
                    m3u_entries = []
                for raw in list(m3u_entries or []):
                    if not isinstance(raw, dict):
                        continue
                    cid = str(raw.get("group") or raw.get("category_id") or "").strip()
                    if not cid or cid not in allowed:
                        continue
                    if cid not in category_names:
                        category_names[cid] = cid
                        category_order.append(cid)
            try:
                if m3u_entries is not None:
                    categories, _origin = [], "m3u"
                elif categories_seed is not None:
                    categories, _origin = list(categories_seed or []), "seed"
                else:
                    categories, _origin = get_cached_categories(
                        source, page_kind, client=client, wait_for_server=False
                    )

                # With a saved package filter, an empty metadata cache means the
                # background category refresh has only just started. Do not wait
                # here and do not compete with the normal Series page loading.
                if saved_allowed is not None and m3u_entries is None and not categories:
                    self._queueGui(self.backdropsReady, [], generation, [])
                    return

                for cat in categories or []:
                    if not isinstance(cat, dict):
                        continue
                    cid = str(cat.get("category_id") or "")
                    if not cid or cid not in allowed:
                        continue
                    name = str(
                        cat.get("category_name") or cat.get("name") or
                        cat.get("title") or ""
                    )
                    category_names[cid] = name
                    if cid not in category_order:
                        category_order.append(cid)
            except Exception:
                pass

            # Keep Backdrop rails strict: Movies rail = films only, Series rail = TV series only.
            # Exclude sports, wrestling/UFC, programmes, theatre, music, kids/cartoon/anime
            # and obvious cross-kind packages before any catalogue request.
            blocked_backdrop_tokens = (
                # Sports / fighting
                "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
                "wwe", "wrestling", "raw", "smackdown", "nxt",
                "sport", "sports", "football", "soccer", "match", "matches", "event", "events",
                "رياضة", "رياضي", "مباريات", "مباراة", "قتال", "ملاكمة", "مصارعة",

                # Music
                "music", "song", "songs", "concert", "karaoke", "album", "clip", "clips",
                "اغاني", "أغاني", "اغنية", "أغنية", "حفلة", "حفلات", "موسيقى",

                # Programs / shows (but NOT movie/film terms)
                "program", "programs", "programme", "programmes",
                "برامج", "برنامج",

                # Cartoons / animation / kids
                "anime", "animation", "animated", "cartoon", "cartoons", "kids", "children", "child",
                "انمي", "أنمي", "كرتون", "كرتوني", "كرتونية", "اطفال", "أطفال",

                # Theatre / plays
                "theater", "theatre", "play", "plays", "stage",
                "مسرح", "مسرحية", "مسرحيات",

                # Adult / XXX
                "xxx", "adult", "porn", "porno", "18+", "18 plus",
                "اباحي", "إباحي", "اباحية", "إباحية"
            )

            def backdrop_item_allowed(row, category_name=""):
                row = row or {}
                text = " ".join(str(row.get(k) or "") for k in (
                    "name", "title", "genre", "category_name", "description", "plot"
                )).lower()
                if category_name:
                    text += " " + str(category_name).lower()
                if any(token in text for token in blocked_backdrop_tokens):
                    return False
                # Strict content split for Backdrops only:
                # Movies page accepts films, Series page accepts TV series.
                # Enabled packages/settings are not modified here.
                if page_kind == "vod":
                    wrong = (
                        "series", "tv series", "tv show", "tvshow",
                        "season", "episode",
                        "مسلسل", "مسلسلات", "موسم", "حلقة"
                    )
                else:
                    wrong = (
                        "movie", "movies", "film", "films", "cinema",
                        "فيلم", "افلام", "أفلام"
                    )
                return not any(token in text for token in wrong)


            # Backdrop rail searches only the user's enabled packages.
            # The active Package Filter is the source of truth; no provider-brand
            # whitelist is applied. Existing safety/kind checks still apply.
            category_order = [cid for cid in category_order if cid in allowed]

            # Cold-flash / first-open fallback:
            # On a clean Enigma image category metadata can still be empty on the
            # first pass even though the enabled package IDs are already known.
            # Use those enabled IDs directly instead of failing until a second open.
            if not category_order:
                self._queueGui(self.backdropsReady, [], generation, [])
                return

            # Movies and Series: choose random enabled packages.
            ordered_ids = list(category_order)
            random.shuffle(ordered_ids)
            # Search every enabled package for the Backdrop rail.
            # The active Package Filter is the only package limit; keep collecting
            # until 12 valid Backdrops are available (or all enabled packages are exhausted).
            if not ordered_ids:
                raise RuntimeError("No enabled packages for Backdrop")

            # Movies and Series both target 12 Backdrops.
            target_count = self.BACKDROP_ITEM_LIMIT
            seen = set()

            def prepare_row(raw, cid):
                if not isinstance(raw, dict):
                    return None
                item_cid = str(
                    raw.get("category_id") or raw.get("categoryId") or
                    raw.get("genre_id") or raw.get("genre-id") or cid
                )
                if item_cid and item_cid not in allowed:
                    return None
                if not backdrop_item_allowed(raw, category_names.get(str(cid), "")):
                    return None
                title = str(raw.get("name") or raw.get("title") or "")
                if not title:
                    return None
                # This visual rail is 2026-only for both Movies and TV Shows.
                try:
                    item_year = str(self._year(raw) or "").strip()[:4]
                except Exception:
                    item_year = ""
                if item_year != "2026":
                    return None
                row = dict(raw)
                display_title = self._backdropDisplayTitle(title)
                dedupe_title = re.sub(r"[^a-z0-9]+", " ", display_title.lower()).strip()
                if not dedupe_title:
                    dedupe_title = re.sub(r"\s+", " ", display_title.lower()).strip()
                key = "title:%s" % dedupe_title
                if not dedupe_title or key in seen:
                    return None
                seen.add(key)
                row["_display_title"] = display_title
                row["_you_might_like"] = True
                row["_source_category_id"] = str(cid)
                row["_source_category_name"] = category_names.get(str(cid), "")
                try:
                    year_value = str(self._year(raw) or "").strip()[:4]
                except Exception:
                    year_value = ""
                if year_value:
                    row["_backdrop_year"] = year_value
                return row

            if page_kind == "series":
                # Same loading idea as Home -> Popular TV Shows:
                # random enabled package order, load 4 packages at a time,
                # collect valid Series rows, stop as soon as enough content exists,
                # then make one final random selection.
                pool = []
                batch_size = 4
                for offset in range(0, len(ordered_ids), batch_size):
                    batch_ids = ordered_ids[offset:offset + batch_size]
                    if m3u_entries is not None:
                        package_batches = []
                        for cid in batch_ids:
                            rows = [
                                raw for raw in list(m3u_entries or [])
                                if isinstance(raw, dict)
                                and str(raw.get("group") or raw.get("category_id") or "").strip() == str(cid)
                            ]
                            package_batches.append((cid, rows, "m3u"))
                    else:
                        package_batches = get_category_streams_batch(
                            source, page_kind, client, batch_ids,
                            use_cache=True, wait_for_server=True, max_workers=4
                        )

                    for cid, rows, _origin in package_batches:
                        for raw in rows or []:
                            row = prepare_row(raw, cid)
                            if row is not None:
                                pool.append(row)

                    if len(pool) >= target_count:
                        break

                if not pool:
                    raise RuntimeError("No usable content found in enabled Series packages")
                random.shuffle(pool)
                selected = pool[:target_count]
            else:
                # Movies: search all enabled packages in small batches and stop
                # only after 12 valid Backdrops are collected (or all packages end).
                pool = []
                batch_size = 4
                for offset in range(0, len(ordered_ids), batch_size):
                    batch_ids = ordered_ids[offset:offset + batch_size]
                    if m3u_entries is not None:
                        package_batches = []
                        for cid in batch_ids:
                            rows = [
                                raw for raw in list(m3u_entries or [])
                                if isinstance(raw, dict)
                                and str(raw.get("group") or raw.get("category_id") or "").strip() == str(cid)
                            ]
                            package_batches.append((cid, rows, "m3u"))
                    else:
                        package_batches = get_category_streams_batch(
                            source, page_kind, client, batch_ids,
                            use_cache=True, wait_for_server=True, max_workers=4
                        )
                    for cid, rows, _origin in package_batches:
                        rows = list(rows or [])
                        random.shuffle(rows)
                        for raw in rows:
                            row = prepare_row(raw, cid)
                            if row is not None:
                                pool.append(row)
                    if len(pool) >= target_count:
                        break
                if not pool:
                    raise RuntimeError("No usable content found in enabled Movies packages")
                random.shuffle(pool)
                selected = pool[:target_count]
            if not selected:
                raise RuntimeError("No usable random Backdrop content")

            _home_feed_cache_put(cache_mode, source, selected)
            self._queueGui(self.backdropsReady, selected, generation, [])
        except Exception as exc:
            self._queueGui(self.backdropsFailed, str(exc), generation)



    def serverReady(self, latest, allItems=None, categories=None, landingCategory=None, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.serverItems = list(allItems or [])
        self.categoryItems = []
        self.categoriesList = list(categories or [])

        # Build one in-memory category map once. This removes the repeated
        # full-catalog scan that used to happen on every package key press.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        if self.source.get("type") == "xtream":
            for row in self.serverItems:
                try:
                    cid = str((row or {}).get("category_id") or (row or {}).get("categoryId") or "")
                    if cid:
                        self._categoryRowsIndex.setdefault(cid, []).append(row)
                except Exception:
                    pass
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        landing_id = str((landingCategory or {}).get("category_id") or "")
        landing_name = (landingCategory or {}).get("category_name") or ""
        if landing_id == "__recent_added__":
            self.categoryIndex = -1
            self.categoryName = landing_name or "RECENT ADDED"
            self.categoryItems = list(allItems or [])
            self._updateLatestTitle()
        elif landing_id:
            for index, category in enumerate(self.categoriesList):
                if str(category.get("category_id") or "") == landing_id:
                    self.categoryIndex = index
                    self.categoryName = category.get("category_name") or landing_name or "Other"
                    self._updateLatestTitle()
                    self.categoryItems = list(allItems or [])
                    if landing_id:
                        self._fullPackageRows[landing_id] = list(allItems or [])
                    break
        server_latest = latest or []

        # SERVER/PACKAGE POSTERS ARE A SEPARATE PERMANENT PATH.
        # NONE means: no automatic Netflix/Prime/Trending lower feed.
        # It does NOT disable server packages, Recent Added, or their posters.
        if self.contentMode in ("none", "recent"):
            self.latest = _screen_dedupe_content(server_latest, self.kind)
            self.latestStart = self.latestIndex = 0
            if self.latest:
                _submit_content_bg(_save_content_landing_cache,
                                   args=(dict(self.source), self.kind, list(self.latest)[:64]),
                                   key=("landing-cache", id(self), self.kind))
            self._updateLatestTitle()
            self.renderLatest()
        elif not self.latest:
            # Automatic provider modes are supplied later by TMDb.
            self.latest = []
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()
        if self.source.get("type") == "stalker" and not self.latest:
            self["heroDesc"].setText(tr("Stalker packages are ready. Open Categories and select a package to load its titles."))
        if not self.backdrops:
            # Keep the opening focus on the top navigation. Once the user presses
            # DOWN, focus goes to Backdrops first (or Latest only if Trending is unavailable).
            if self.focus != "top":
                self.focus = "backdrops" if self.backdrops else ("latest" if self.latest else "backdrops")
                self.preview()
            self.updateFocus()


    def backdropsReady(self, backdrops, generation=None, lower_items=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Keep the cached Backdrop selection in a stable order on every page
        # open. _loadBackdrops() already randomises the provider selection before
        # storing it in the 6-hour cache, so re-shuffling here only makes Movies
        # jump around unnecessarily between opens.
        self.backdrops = _screen_dedupe_content(backdrops or [], self.kind)[:self.BACKDROP_ITEM_LIMIT]

        # Movies intentionally keep the cached order unchanged until the
        # backdrop cache is refreshed/expired.

        # No automatic provider lower row. Server packages remain independent.
        # Reset the rail position BEFORE rendering. Previously renderBackdrops()
        # could run with the old backdropStart, then the index was reset to 0
        # without another render; the first image request could therefore be
        # missed until the user pressed again.
        if self.backdrops:
            self.backdropStart = self.backdropIndex = 0
            # Movies / Series landing pages always open with the selector on
            # the first backdrop card. Do not leave initial focus on TOP.
            self.focus = "backdrops"

        self.renderBackdrops()

        if self.focus == "backdrops":
            self.preview()
        self.updateFocus()


    def serverFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Recent is sticky-last-good: a retry/network failure cannot make the
        # row disappear after it was already visible.
        if self.contentMode == "recent" and self.recentStable:
            self.latest = _screen_dedupe_content(self.recentStable, self.kind)
            self.latestStart = self.latestIndex = 0
            self.categoryName = "RECENT ADDED"
            self._updateLatestTitle()
            self.renderLatest()
            self.updateFocus()
            return

        self.serverItems, self.categoryItems, self.categoriesList = [], [], []
        self.categoriesLoaded = True
        self.latest = []
        self._updateLatestTitle()
        self["heroDesc"].setText("Unable to load the selected server library: %s" % msg)
        self.renderLatest(); self.updateFocus()


    def backdropsFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.backdrops = []
        self.renderBackdrops()
        if self.latest:
            if self.focus != "top":
                self.focus = "latest"
                self.preview()
            self["heroDesc"].setText("Backdrops unavailable. Server content is still available.\n%s" % msg)
        else:
            self["heroDesc"].setText("Unable to load Backdrops: %s" % msg)
        self.updateFocus()


    def current(self):
        arr = self.backdrops if self.focus == "backdrops" else self.latest
        idx = self.backdropStart + self.backdropIndex if self.focus == "backdrops" else self.latestStart + self.latestIndex
        return arr[idx] if 0 <= idx < len(arr) else None

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, self.kind, target)
            title = target.get("name") or target.get("title") or "العنصر"
            if not saved:
                self["footer"].setText(tr("Unable to save favorite"))
            elif added:
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText("تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["footer"].setText("تعذر تحديث المفضلة: %s" % exc)

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            self["footer"].setText(tr("Select a movie or TV show first"))
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import is_favourite, add_favourite
            title = target.get("name") or target.get("title") or "العنصر"
            if is_favourite(self.source, self.kind, target):
                self["footer"].setText("%s موجود بالفعل في المفضلات" % title)
            elif add_favourite(self.source, self.kind, target):
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText(tr("Unable to save favorite"))
        except Exception as exc:
            self["footer"].setText("Unable to save favorite: %s" % exc)

    def norm(self, value):
        if isinstance(value, list): value = value[0] if value else ""
        if isinstance(value, str):
            value = value.strip().replace("\\/", "/")
            if value.startswith("["):
                try: value = (json.loads(value) or [""])[0]
                except Exception: pass
            if value.startswith("/"): value = backdrop_url(value)
        return value or ""

    def imageUrl(self, item, backdrop=False):
        item = item or {}
        if backdrop:
            value = item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or item.get("movie_backdrop")
            # Provider/server artwork may be relative to the Xtream/Stalker host.
            # Do not treat every leading slash as a TMDb path; resolve server rows
            # against the active source, while TMDb feed rows keep TMDb semantics.
            if item.get("_tmdb"):
                return self.norm(value)
            return _server_asset_url(self.source, value) if value else ""

        # TMDb provider rows already contain complete TMDb artwork URLs.
        # Do not send them through the connected-server poster resolver.
        if item.get("_tmdb"):
            return self.norm(
                item.get("stream_icon")
                or item.get("cover")
                or item.get("poster")
                or item.get("poster_path")
            )

        # Home rows that were resolved by the TMDb warm pass already carry a
        # poster and backdrop from the same TMDb movie id. Prefer that exact
        # poster here instead of a provider poster that may belong to another
        # title while the hero backdrop is correct. This is display-only and
        # does not change package/server data or other artwork lookup paths.
        exact_tmdb_poster = self.norm(item.get("_tmdb_poster") or "")
        if exact_tmdb_poster:
            return exact_tmdb_poster

        # Server/package rows without a resolved Home TMDb poster continue to
        # use the existing server-aware resolver unchanged.
        return _server_poster_url(self.source, item)

    def logoUrl(self, item):
        return self.norm(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "")

    def setPlaceholder(self, widget, name):
        try: self[widget].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", name))
        except Exception: pass

    def _tmdbTitleCandidates(self, *values):
        """Return safe TMDb title candidates without changing server list labels.

        IPTV providers often prefix names with bouquet/group tags such as
        ``FRI |`` or ``EN |``.  Those labels are useful in the UI but can make
        TMDb return no result.  Only the fallback lookup uses these cleaned
        variants, so the fast server-artwork path remains untouched.
        """
        out = []
        for value in values:
            raw = str(value or "").strip()
            if not raw:
                continue
            variants = [raw]
            if "|" in raw:
                tail = raw.split("|")[-1].strip()
                if tail:
                    variants.insert(0, tail)
            # Remove a leading [GROUP] / (GROUP) tag only for TMDb lookup.
            variants.append(re.sub(r"^\s*[\[(][^\])]{1,16}[\])]\s*", "", raw).strip())
            for candidate in variants:
                clean = self._normTitle(candidate)
                if clean and clean not in out:
                    out.append(clean)
        return out

    def _tmdbSearchArtwork(self, item, extra=None, required_key="poster_path"):
        """One TMDb artwork path for every Movies/TV Shows surface.

        Always let the shared TMDb client see the original provider title
        first.  Its global title normalizer handles 4K/NF/language/provider
        prefixes consistently on every server.  Local legacy candidates remain
        only as a final compatibility fallback.
        """
        tmdb = TMDbClient()
        data = dict(item or {})
        if isinstance(extra, dict):
            merged = dict(extra)
            merged.update(data)
            data = merged
        values = [data.get("name"), data.get("title"), data.get("original_title"), data.get("original_name")]
        year = self._year(data) or None
        # A provider TMDb id is the most reliable identity, especially for Arabic
        # titles. Use it before any title search so poster/backdrop fallback cannot
        # miss because of translated/transliterated names.
        resolved_id = str(data.get("tmdb_id") or data.get("tmdb") or data.get("tmdbid") or "").strip()
        if resolved_id:
            try:
                bundle = tmdb.details_bundle(resolved_id, self.kind) or {}
                if bundle.get(required_key):
                    return bundle
            except Exception:
                pass
        seen = set()
        # Original labels first: TMDbClient.search_artwork() owns the canonical
        # All-server normalization.
        for value in values:
            candidate = str(value or "").strip()
            key = candidate.lower()
            if not candidate or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        # Keep old local variants for unusual bouquet labels, but never make
        # them the primary lookup path.
        for candidate in self._tmdbTitleCandidates(*values):
            key = str(candidate or "").strip().lower()
            if not key or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        return {}

    def _tmdbBackdropFallback(self, item, widget, width, height, server_fallback=""):
        """Resolve the rail backdrop with the same TMDb match used by More Info.

        The large Backdrop rail must not trust a provider backdrop first.
        Some providers attach the wrong wide image to the correct movie.  Resolve
        TMDb ID/title+year exactly like loadDetails(), cache that resolved ID/path
        on the live item, and use the provider image only if TMDb has no backdrop.
        """
        item = item or {}
        raw_title = str(item.get("name") or item.get("title") or item.get("original_title") or item.get("original_name") or "").strip()
        if not raw_title:
            if server_fallback:
                self.loadImage(server_fallback, widget, width, height)
            return
        token = (raw_title, str(item.get("stream_id") or item.get("series_id") or item.get("id") or ""))
        if not hasattr(self, "_backdrop_fallback_tokens"):
            self._backdrop_fallback_tokens = {}
        self._backdrop_fallback_tokens[widget] = token

        # Reuse an already-resolved TMDb backdrop immediately.
        cached_backdrop = self.norm(item.get("_tmdb_backdrop") or "")
        if cached_backdrop:
            self.loadImage(cached_backdrop, widget, width, height)
            return

        def worker():
            backdrop = ""
            resolved_id = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
            try:
                tmdb = TMDbClient()
                kind = self.kind
                year = self._year(item) or None
                data = {}

                # Same fast path as More Info: a provider TMDb ID wins when valid.
                if resolved_id:
                    try:
                        data = tmdb.details_bundle(resolved_id, kind) or {}
                    except Exception:
                        data = {}
                    backdrop = self.norm(data.get("backdrop_path") or "")

                # Same title/year resolver as More Info when no useful ID/backdrop.
                if not backdrop:
                    found = {}
                    try:
                        found = tmdb.search_title(raw_title, kind, year) or {}
                    except Exception:
                        found = {}
                    if not found:
                        try:
                            found = tmdb.search_title(raw_title, kind, None) or {}
                        except Exception:
                            found = {}
                    rid = str((found or {}).get("id") or (found or {}).get("tmdb_id") or "").strip()
                    if rid:
                        resolved_id = rid
                        try:
                            data = tmdb.details_bundle(resolved_id, kind) or {}
                        except Exception:
                            data = {}
                    backdrop = self.norm((data or {}).get("backdrop_path") or (found or {}).get("backdrop_path") or "")
            except Exception:
                backdrop = ""

            final_url = backdrop or server_fallback
            if not final_url:
                return

            def apply():
                if getattr(self, "_backdrop_fallback_tokens", {}).get(widget) != token:
                    return
                try:
                    if backdrop:
                        item["_tmdb_backdrop"] = backdrop
                        # Keep provider backdrop untouched; this key makes future
                        # rail renders prefer the exact TMDb artwork without another match.
                        if resolved_id:
                            item["tmdb_id"] = resolved_id
                except Exception:
                    pass
                self.loadImage(final_url, widget, width, height)

            self._queueGui(apply)
            request_artwork(final_url, "backdrops", None, priority=2)

        _submit_content_bg(worker, key=("backdrop-exact-tmdb", id(self), str(widget), token))

    def _tmdbPosterFallback(self, item, widget, width, height, failed_url=""):
        """Find a TMDb poster only when the server poster is missing or failed."""
        # A reused card may already be loading another item. Never let an old
        # server failure replace the artwork of the new card.
        if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
            return
        def worker():
            try:
                if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
                    return
                found = self._tmdbSearchArtwork(item or {}, required_key="poster_path")
                poster = self.norm(found.get("poster_path") or "")
                if not poster:
                    return
                def apply():
                    # The slot may have been reused while TMDb was queried.
                    current = getattr(self, "_image_requests", {}).get(widget)
                    if failed_url and current != failed_url:
                        return
                    self.loadImage(poster, widget, width, height)
                self._queueGui(apply)
            except Exception:
                pass
        _submit_content_bg(worker, key=("poster-fallback", id(self), str(widget)))

    def _posterFileValid(self, path):
        """Cheap local validation for server posters before decoding.

        This deliberately does not touch the downloader/queue.  It only catches
        server URLs that return an HTML/error body or a tiny/broken file, so the
        existing TMDb fallback can take over without affecting artwork speed.
        """
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return True
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return True
            if head.startswith(b"RIFF") and head[8:12] == b"WEBP":
                return True
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return True
            return False
        except Exception:
            return False

    def loadImage(self, url, widget, width, height, fallback_item=None):
        """Show cached artwork fast; hero backdrops recover through TMDb if needed."""
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        requests[widget] = url

        if widget == "hero":
            priority = 120
        elif widget == "logoImage":
            priority = 100
        elif widget.startswith("backdrop"):
            priority = 75
        elif widget.startswith("latest"):
            priority = 85
        else:
            priority = 50

        def force_hero_tmdb(expected=url):
            if getattr(self, "_image_requests", {}).get("hero") != expected:
                return
            item = self.current()
            if not item:
                return
            self._previewRequestId += 1
            request_id = self._previewRequestId
            # The provider backdrop already failed at download time. Bypass it on
            # this retry; otherwise _lookupPreviewArtwork sees the same non-empty
            # URL and keeps selecting it forever instead of reaching TMDb.
            _submit_content_bg(
                self._lookupPreviewArtwork,
                args=(dict(item), request_id, True, False, True),
                key=("hero-tmdb-fallback", id(self))
            )

        def done(path, w=widget, x=width, y=height, expected=url, item=fallback_item):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            if item is not None and not self._posterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except OSError:
                    pass
                self._tmdbPosterFallback(item, w, x, y, expected)
                return
            if w == "hero":
                try:
                    if not path or not os.path.exists(path) or os.path.getsize(path) < 1000:
                        try:
                            if path and os.path.exists(path):
                                os.remove(path)
                        except OSError:
                            pass
                        force_hero_tmdb(expected)
                        return
                except Exception:
                    force_hero_tmdb(expected)
                    return
            self.decode(path, w, x, y)

        def failed(_path, w=widget, expected=url, item=fallback_item, x=width, y=height):
            if w == "hero":
                force_hero_tmdb(expected)
                return
            if item is not None:
                self._tmdbPosterFallback(item, w, x, y, expected)


        if str(widget).startswith("backdrop"):
            cache_kind = "backdrops_top"
        elif widget in ("hero", "backdrop") or str(widget).startswith("rec"):
            cache_kind = "backdrops"
        elif widget == "logoImage":
            cache_kind = "logos"
        else:
            cache_kind = "posters"
        request_artwork(
            url, cache_kind, done, priority=priority,
            errback=failed if (fallback_item is not None or widget == "hero") else None
        )

    def decode(self, path, widget, width, height):
        loader = ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget):
            try:
                ptr = l.getData()
                if ptr and self[w].instance:
                    self[w].instance.setPixmap(ptr)
                    try:
                        self[w].show()
                    except Exception:
                        pass
                    if str(w).startswith("latest") and str(w)[6:].isdigit():
                        _slot = int(str(w)[6:])
                        for _name in ("latestShell%d" % _slot, "latestBadge%d" % _slot,
                                      "latestLabel%d" % _slot):
                            try:
                                self[_name].show()
                            except Exception:
                                try:
                                    self[_name].setVisible(True)
                                except Exception:
                                    pass
                        try:
                            if str(self["latestRate%d" % _slot].getText() or "").strip():
                                self["latestRate%d" % _slot].show()
                        except Exception:
                            pass
                    if w == "logoImage":
                        try:
                            self["logoHintIcon"].setVisible(False)
                            self["logoHint"].setVisible(False)
                        except Exception:
                            pass
            except Exception:
                pass
            # A late ePicLoad callback may arrive after Enigma2 has torn down
            # the screen attributes.  Never crash while releasing its loader.
            try:
                loaders = getattr(self, "picloads", None)
                if loaders is not None and l in loaders:
                    loaders.remove(l)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(loader, ready, self, oneshot=True); loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000")); loader.startDecode(path)

    def _setCardMeta(self, prefix, slot, item):
        # Large Movies/TV page: clean provider/quality/language prefixes for
        # every visible card label (Backdrop row and lower poster row) while
        # preserving the original server name inside the item for playback,
        # source matching and TMDb lookup.
        raw_title = str((item or {}).get("_display_title") or (item or {}).get("name") or (item or {}).get("title") or "").strip()
        title = self._backdropDisplayTitle(raw_title) if raw_title else ""
        rating = str((item or {}).get("rating") or (item or {}).get("rating_5based") or "").strip()
        limit = 30 if prefix == "backdrop" else 16
        self["%sLabel%d" % (prefix, slot)].setText(title[:limit] + ("…" if len(title) > limit else ""))
        self["%sRate%d" % (prefix, slot)].setText(rating[:4])

    def renderBackdrops(self):
        visible = []
        for slot in range(4):
            idx = self.backdropStart + slot
            item = self.backdrops[idx] if idx < len(self.backdrops) else None
            # Backdrop ranking badge: #1 .. #12 follows the actual rail order.
            self["rank%d" % slot].setText(("#%d" % (idx + 1)) if item else "")
            self.setPlaceholder("backdrop%d" % slot, "trend_transparent_placeholder.png")
            self._setCardMeta("backdrop", slot, item)
            if item:
                visible.append((slot, item))

        # Resolve TMDb information strictly one-by-one.  As soon as each item
        # has its final backdrop URL, hand the image to the normal artwork
        # queue; image downloads themselves remain parallel/fast.
        self._startBackdropMetadataResolve(visible)

    def _startBackdropMetadataResolve(self, visible):
        rows = [(int(slot), item) for slot, item in list(visible or []) if isinstance(item, dict)]
        if not rows:
            return

        token = "%s:%s:%s" % (
            str(self.kind or ""),
            str(self.backdropStart),
            "|".join(str(
                (item or {}).get("stream_id") or
                (item or {}).get("series_id") or
                (item or {}).get("id") or
                (item or {}).get("name") or
                (item or {}).get("title") or ""
            ) for _slot, item in rows)
        )
        self._backdropMetadataToken = token

        def apply_one(slot, item, backdrop, resolved_id, server_fallback):
            if token != getattr(self, "_backdropMetadataToken", ""):
                return
            try:
                if backdrop:
                    item["_tmdb_backdrop"] = backdrop
                    if resolved_id:
                        item["tmdb_id"] = resolved_id
            except Exception:
                pass

            final_url = backdrop or server_fallback
            if final_url:
                # Small Movies/Series cards are only 410x210.  Use TMDb w780
                # here to reduce transfer size; large/details backdrops keep w780.
                if "image.tmdb.org/t/p/" in str(final_url):
                    final_url = re.sub(
                        r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                        r"\1w780\2",
                        str(final_url),
                        count=1
                    )
                # Normal artwork queue remains parallel/fast.
                self.loadImage(final_url, "backdrop%d" % slot, 410, 210)

        def worker():
            try:
                tmdb = TMDbClient()
            except Exception:
                tmdb = None

            # One worker, one loop: TMDb information is resolved one item at a time.
            for slot, item in rows:
                if token != getattr(self, "_backdropMetadataToken", ""):
                    return

                backdrop = self.norm(item.get("_tmdb_backdrop") or "")
                resolved_id = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
                server_fallback = self.imageUrl(item, True)

                # Keep the provider backdrop only as a fallback.  Large Movies/Series
                # cards must resolve the same TMDb movie/series ID used by More Info
                # so a provider image cannot override the correct details artwork.

                # Cached TMDb backdrop needs no metadata request.
                if backdrop:
                    self._queueGui(
                        apply_one, slot, item, backdrop, resolved_id, server_fallback
                    )
                    continue

                raw_title = str(
                    item.get("name") or item.get("title") or
                    item.get("original_title") or item.get("original_name") or ""
                ).strip()

                if tmdb is not None and raw_title:
                    try:
                        kind = self.kind
                        year = self._year(item) or None
                        data = {}

                        # Fast path: provider already supplied a TMDb ID.
                        if resolved_id:
                            try:
                                data = tmdb.details_bundle(resolved_id, kind) or {}
                            except Exception:
                                data = {}
                            backdrop = self.norm(data.get("backdrop_path") or "")

                        # Otherwise resolve title/year, then fetch the exact details.
                        if not backdrop:
                            found = {}
                            try:
                                found = tmdb.search_title(raw_title, kind, year) or {}
                            except Exception:
                                found = {}
                            if not found:
                                try:
                                    found = tmdb.search_title(raw_title, kind, None) or {}
                                except Exception:
                                    found = {}

                            rid = str(
                                (found or {}).get("id") or
                                (found or {}).get("tmdb_id") or ""
                            ).strip()
                            if rid:
                                resolved_id = rid
                                try:
                                    data = tmdb.details_bundle(resolved_id, kind) or {}
                                except Exception:
                                    data = {}

                            backdrop = self.norm(
                                (data or {}).get("backdrop_path") or
                                (found or {}).get("backdrop_path") or ""
                            )
                    except Exception:
                        backdrop = ""

                # Queue image immediately, then continue resolving metadata for
                # the next item.  Image downloading is not serialized.
                self._queueGui(
                    apply_one, slot, item, backdrop, resolved_id, server_fallback
                )

        _submit_content_bg(
            worker,
            key=("backdrop-metadata-seq", id(self), token)
        )

    def renderLatest(self):
        for slot in range(8):
            idx = self.latestStart + slot
            item = self.latest[idx] if idx < len(self.latest) else None
            # The lower 8-poster rail uses static shell/rating artwork, so
            # could not hide its gray/black loading blocks. Keep all card chrome
            # invisible until the real poster decode succeeds.
            for _name in ("latestShell%d" % slot, "latestBadge%d" % slot,
                          "latestLabel%d" % slot, "latestRate%d" % slot):
                try:
                    self[_name].hide()
                except Exception:
                    try:
                        self[_name].setVisible(False)
                    except Exception:
                        pass
            self.setPlaceholder("latest%d" % slot, "poster_loading_transparent_r410.png")
            self._setCardMeta("latest", slot, item)
            if item:
                url = self.imageUrl(item, False)
                if url:
                    self.loadImage(url, "latest%d" % slot, 170, 205, fallback_item=item)
                else:
                    self._tmdbPosterFallback(item, "latest%d" % slot, 170, 205)
        # Visible eight posters load normally above. Prefetch only
        # the next two cards, instead of the entire Content Home list.
        _next = []
        for _item in list(self.latest or [])[self.latestStart + 8:self.latestStart + 10]:
            _url = self.imageUrl(_item, False)
            if _url:
                _next.append(_url)
        if _next:
            prefetch_artwork(_next, "posters", priority=2)
        if self.kind == "vod":
            # Five visible/nearby movies are enough to keep navigation instant
            # without flooding a small Enigma2 receiver with metadata requests.
            self._prefetchTmdbMetadata(self.latest, self.latestStart, 5)

    def _prefetchTmdbMetadata(self, items, start, count):
        """Warm cache for visible Movies metadata without touching Enigma2 widgets.

        TMDbClient already owns persistent search/details caches.  This method
        only advances those cache hits into the background and mirrors them in
        the small in-session details LRU used by More Info.
        """
        if self.kind != "vod":
            return
        rows = []
        for item in list(items or [])[start:start + max(0, int(count or 0))]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("name") or item.get("title") or item.get("original_title") or "").strip()
            if not title:
                continue
            year = self._year(item) or 0
            tid = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
            norm = self._normTitle(title)
            key = "%s|%s|%s" % (tid, norm, str(year or ""))
            if not key or key in self._metadataWarmKeys:
                continue
            self._metadataWarmKeys.add(key)
            rows.append((dict(item), title, year, tid, norm))
        if not rows:
            return

        def worker(batch=rows):
            try:
                tmdb = TMDbClient()
            except Exception:
                return
            for row, title, year, tid, norm in batch:
                try:
                    found = {}
                    resolved = tid
                    if not resolved:
                        found = tmdb.search_title(title, "vod", year or None) or {}
                        if not found:
                            found = tmdb.search_title(title, "vod", None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if not resolved:
                        continue
                    bundle = tmdb.details_bundle(resolved, "vod") or {}
                    if found:
                        seeded = dict(found)
                        seeded.update(bundle or {})
                        bundle = seeded
                    if not bundle:
                        continue
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("vod:%s" % resolved), bundle, _DETAILS_DATA_CACHE_LIMIT)
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("vod:title:%s:%s" % (norm, str(year or ""))), bundle, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue

        _submit_content_bg(worker, key=("movie-metadata-warm", id(self)))

    def _prefetchCards(self, items, start, count, backdrop=False, priority=5):
        """Warm only the next page at a low priority without decoding it yet.

        The queue writes the original JPEG/PNG response to disk, so this changes
        timing only; it never alters image dimensions, compression, or poster art.
        """
        for item in list(items or [])[start:start + count]:
            try:
                url = self.imageUrl(item, backdrop)
                if url:
                    request_artwork(url, "backdrops" if backdrop else "posters", None, priority=priority)
            except Exception:
                pass


    def _alignTopSelector(self):
        try:
            index = max(0, min(self.topIndex, len(self.TOP_X) - 1))
            cell_w = self.TOP_W[index]
            x = self.TOP_X[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
        except Exception:
            pass


    def updateFocus(self):
        try:
            self._alignTopSelector(); self["topSelector"].setVisible(self.focus == "top")
            self["backdropSelector"].instance.move(ePoint(sx(self.BACKDROP_X[self.backdropIndex]), sy(555))); self["backdropSelector"].setVisible(self.focus == "backdrops" and bool(self.backdrops))
            self["latestSelector"].instance.move(ePoint(sx(self.LATEST_X[self.latestIndex]), sy(825))); self["latestSelector"].setVisible(self.focus == "latest" and bool(self.latest))
        except Exception: pass

    def preview(self):
        item = self.current()
        if not item:
            return
        try:
            self["hero"].show()
        except Exception:
            pass
        # Every move gets a new token.  It guarantees that a slower lookup for
        # a previous poster cannot overwrite the backdrop of the current movie.
        self._previewRequestId += 1
        request_id = self._previewRequestId
        # Display-only cleanup for the selected title too. Do not mutate the
        # original server title used by playback/search.
        raw_title = item.get("name") or item.get("title") or ""
        title = self._backdropDisplayTitle(raw_title).upper()[:34]
        logo = ""  # Always fetch the official transparent TMDb logo.
        self["logoTitle"].setText(title)
        try:
            self["logoHintIcon"].setVisible(True)
            self["logoHint"].setVisible(True)
            self["logoImage"].setVisible(True)
        except Exception:
            pass
        try:
            self["logoImage"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "common/transparent.png"))
        except Exception:
            pass
        if logo:
            self.loadImage(logo, "logoImage", 260, 60)
        year = item.get("year") or item.get("releaseDate") or ""
        genre = item.get("genre") or ""
        if self.kind == "series":
            self["heroMeta"].setText("   •   ".join(x for x in [str(year), str(genre)] if x))
        else:
            rating = item.get("rating") or item.get("rating_5based") or ""
            self["heroMeta"].setText("   •   ".join(x for x in [str(year), ("★ " + str(rating)) if rating else "", str(genre)] if x))
        self["heroDesc"].setText(_hero_preview_summary(item.get("plot") or item.get("description") or ""))
        back = self.imageUrl(item, True)
        if back:
            self.loadImage(back, "hero", 1920, 520)
        if not back or not logo:
            self._previewBackdropPending = (dict(item), request_id, True, not bool(logo))
            if getattr(self, "_categorySwitchPreviewNow", False):
                self._categorySwitchPreviewNow = False
                try:
                    self._previewBackdropTimer.stop()
                except Exception:
                    pass
                self._beginPreviewBackdropLookup()
            else:
                try:
                    self._previewBackdropTimer.stop()
                    self._previewBackdropTimer.start(180, True)
                except Exception:
                    self._beginPreviewBackdropLookup()

    def _beginPreviewBackdropLookup(self):
        pending = self._previewBackdropPending
        self._previewBackdropPending = None
        if not pending:
            return
        item, request_id, need_backdrop, need_logo = pending
        if request_id != self._previewRequestId:
            return
        _submit_content_bg(
            self._lookupPreviewArtwork,
            args=(item, request_id, need_backdrop, need_logo),
            key=("preview-artwork", id(self))
        )

    def _movieBackdropUrl(self, data):
        data = data or {}
        return self.norm(
            data.get("backdrop_path") or data.get("backdrop") or
            data.get("backdrop_url") or data.get("movie_backdrop")
        )

    def _bundleLogoUrl(self, data):
        images = (data or {}).get("images") or {}
        return tmdb_logo_url(best_tmdb_logo(images.get("logos") or [], logo_language()), "w500")

    def _lookupPreviewArtwork(self, item, request_id, need_backdrop=True, need_logo=True, force_tmdb_backdrop=False):
        """Portal/server first, then TMDb enhancement without holding the UI.

        A server backdrop is applied as soon as it is available. If TMDb search
        provides a backdrop, that is also applied before the slower full details
        request used for transparent logos and richer metadata. Stale requests
        are discarded by request_id, matching EStalker's fast navigation model.
        """
        try:
            if request_id != getattr(self, "_previewRequestId", request_id):
                return
            # r233: do not block Movies hero navigation on provider vod_info().
            # TV Shows were already fast because they went straight from the
            # visible row to TMDb cache. Movies now use that same path. Existing
            # server metadata in the row remains an immediate fallback.
            details = dict(item or {})
            if isinstance(item.get("info"), dict):
                details.update(item.get("info") or {})

            server_backdrop = self._movieBackdropUrl(details) if (need_backdrop and not force_tmdb_backdrop) else ""
            # Resolve relative provider backdrops against the active server.
            if server_backdrop and not item.get("_tmdb"):
                server_backdrop = _server_asset_url(self.source, server_backdrop)
            server_logo = self._bundleLogoUrl(details) if need_logo else ""
            # Logo can still be shown immediately.  Do not paint the provider
            # backdrop first: the large preview must prefer the exact TMDb ID,
            # matching MovieDetailsScreen.  Provider backdrop remains fallback.
            if server_logo and (logo_language() == "en" or
                                has_language_logo((details.get("images") or {}).get("logos") or [], logo_language())):
                self._queueGui(self._applyPreviewArtwork, "", server_logo, request_id)
            if request_id != self._previewRequestId:
                return

            need_tmdb_backdrop = bool(need_backdrop)
            # A server English logo must not suppress a genuine Arabic logo.
            need_tmdb_logo = bool(need_logo)

            # Metadata is intentionally independent from artwork. Even when the
            # server already supplied backdrop/logo, Movies/Series metadata must
            # still prefer TMDb and use server fields only as fallback.
            tmdb = TMDbClient()
            tmdb_id = details.get("tmdb_id") or details.get("tmdb") or item.get("tmdb_id") or item.get("tmdb")
            found = {}
            if not tmdb_id:
                raw_title = (details.get("name") or details.get("title") or
                             item.get("name") or item.get("title") or "")
                item_year = self._year(details) or self._year(item) or None
                if raw_title:
                    try:
                        found = tmdb.search_title(raw_title, self.kind, item_year) or {}
                        if not found:
                            found = tmdb.search_title(raw_title, self.kind, None) or {}
                    except Exception:
                        found = {}
                tmdb_id = found.get("id") or found.get("tmdb_id")

            quick_backdrop = self._movieBackdropUrl(found) if need_tmdb_backdrop else ""
            if quick_backdrop:
                self._queueGui(self._applyPreviewArtwork, quick_backdrop, "", request_id)
                need_tmdb_backdrop = False
            if request_id != self._previewRequestId:
                return
            if not tmdb_id:
                if server_backdrop:
                    self._queueGui(self._applyPreviewArtwork, server_backdrop, "", request_id)
                return

            try:
                bundle = tmdb.details_bundle(tmdb_id, self.kind) or {}
            except Exception:
                bundle = {}
            if found:
                seed = dict(found)
                seed.update(bundle or {})
                bundle = seed

            # Apply TMDb text/meta first. Missing individual fields remain as the
            # already-visible server values, so a partial TMDb response is safe.
            if bundle:
                self._queueGui(self._applyPreviewMetadata, bundle, request_id)

            backdrop = self._movieBackdropUrl(bundle) if need_tmdb_backdrop else ""
            logo = localized_logo_url(tmdb, self.kind, tmdb_id,
                                      (bundle or {}).get("images") or {}) if need_tmdb_logo else ""
            final_backdrop = backdrop or (server_backdrop if need_backdrop else "")
            if final_backdrop or logo:
                self._queueGui(self._applyPreviewArtwork, final_backdrop, logo, request_id)
        except Exception:
            pass

    def _applyPreviewMetadata(self, data, request_id):
        if request_id != self._previewRequestId:
            return
        data = data or {}
        title = data.get("title") or data.get("name") or ""
        release = data.get("release_date") or data.get("first_air_date") or ""
        year = str(release or "")[:4]
        rating = data.get("vote_average")
        genres = data.get("genres") or []
        if isinstance(genres, list):
            genre = ", ".join(str(x.get("name") or "") for x in genres[:3] if isinstance(x, dict) and x.get("name"))
        else:
            genre = str(genres or "")
        overview = data.get("overview") or ""
        if title:
            current = self.current() or {}
            server_title = str(current.get("name") or current.get("title") or "").strip()
            selected_tmdb_language = TMDbClient().language.lower()
            shown_title = preferred_metadata_text(title, server_title, selected_tmdb_language)
            self["logoTitle"].setText(str(shown_title)[:34])
        meta = []
        if year:
            meta.append(year)
        if self.kind != "series" and rating not in (None, ""):
            try:
                meta.append("★ %.1f" % float(rating))
            except Exception:
                meta.append("★ " + str(rating))
        if genre:
            meta.append(genre)
        if meta:
            self["heroMeta"].setText("   •   ".join(meta))
        current = self.current() or {}
        provider_description = current.get("plot") or current.get("description") or current.get("overview") or ""
        selected_overview = preferred_metadata_text(overview, provider_description, TMDbClient().language)
        if selected_overview:
            self["heroDesc"].setText(_hero_preview_summary(selected_overview))

    def _applyPreviewArtwork(self, backdrop, logo, request_id):
        if request_id != self._previewRequestId:
            return
        if backdrop:
            self.loadImage(backdrop, "hero", 1920, 520)
        if logo:
            self.loadImage(logo, "logoImage", 260, 60)

    def left(self):
        if self.focus == "top": self.topIndex = max(0, self.topIndex - 1)
        elif self.focus == "backdrops":
            if self.backdropIndex > 0: self.backdropIndex -= 1
            elif self.backdropStart > 0: self.backdropStart = max(0, self.backdropStart - 4); self.renderBackdrops()
        else:
            if self.latestIndex > 0: self.latestIndex -= 1
            elif self.latestStart > 0: self.latestStart = max(0, self.latestStart - 8); self.renderLatest()
        self.updateFocus(); self.preview()

    def right(self):
        if self.focus == "top": self.topIndex = min(len(self.TOP) - 1, self.topIndex + 1)
        elif self.focus == "backdrops":
            if self.backdropIndex < 3 and self.backdropStart + self.backdropIndex + 1 < len(self.backdrops): self.backdropIndex += 1
            elif self.backdropStart + 4 < len(self.backdrops): self.backdropStart += 4; self.backdropIndex = 0; self.renderBackdrops()
        else:
            if self.latestIndex < 7 and self.latestStart + self.latestIndex + 1 < len(self.latest): self.latestIndex += 1
            elif self.latestStart + 8 < len(self.latest): self.latestStart += 8; self.latestIndex = 0; self.renderLatest()
        self.updateFocus(); self.preview()

    def up(self):
        if self.focus == "latest":
            self.focus = "backdrops"
        elif self.focus == "backdrops":
            self.focus = "top"
        else:
            self.focus = "top"
        self.updateFocus(); self.preview()



    def down(self):
        if self.focus == "top":
            # Backdrops are the first content level. If it is still loading,
            # stay on top rather than jumping directly to the lower poster row.
            if self.backdrops:
                self.focus = "backdrops"
            elif not self.latest:
                self.focus = "top"
            else:
                # Only fall back when Backdrops are genuinely unavailable.
                self.focus = "latest"
        elif self.focus == "backdrops":
            self.focus = "latest" if self.latest else "backdrops"
        else:
            self.focus = "latest"
        self.updateFocus()
        if self.focus != "top":
            self.preview()


    def _backdropDisplayTitle(self, value):
        """Clean provider tags for Backdrop labels only; never mutate server data."""
        text = str(value or "").strip()
        if not text:
            return ""
        # Repeated leading provider/quality/language tags. Examples:
        # TOP - Title, 4K-NF - Title, AR-SUBS | Title, FHD: Title.
        tag = r"(?:TOP|NEW|RECENT|4K|8K|UHD|FHD|FULL\s*HD|HD|SD|NF|NETFLIX|AMZN|PRIME|DSNP|DISNEY\+?|HULU|HBO|MAX|WEB[- ]?DL|BLURAY|HEVC|X26[45]|HDR|DV|DOLBY|AR|EN|FR|TR|SUBS?|DUB(?:BED)?)"
        # Strip compound prefixes such as '4K-NF - ' or 'AR-SUBS | '.
        for _ in range(4):
            new = re.sub(r"^\s*(?:" + tag + r")(?:\s*[-_|:/+]\s*(?:" + tag + r"))*\s*(?:[-|:/]\s*)+", "", text, flags=re.I)
            if new == text:
                break
            text = new.strip()
        # Also remove bracketed prefix groups like [4K NF] / (TOP).
        text = re.sub(r"^\s*[\[(](?:[^\])]{0,28})[\])]\s*[-|:]?\s*", lambda m: "" if re.search(tag, m.group(0), re.I) else m.group(0), text).strip()
        return text or str(value or "").strip()

    def _normTitle(self, value):
        text = (value or "").lower()
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray)\b", " ", text)
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return " ".join(text.split())

    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _serverTmdbId(self, item):
        item = item or {}
        for key in ("tmdb_id", "tmdb", "tmdbid"):
            value = item.get(key)
            if value not in (None, ""):
                try:
                    return str(int(value))
                except Exception:
                    value = str(value).strip()
                    if value:
                        return value
        info = item.get("info")
        if isinstance(info, dict):
            for key in ("tmdb_id", "tmdb", "tmdbid"):
                value = info.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _strictMatchFromRows(self, tmdbItem, rows):
        tmdbItem = tmdbItem or {}
        target_id = self._serverTmdbId(tmdbItem)
        target_year = self._year(tmdbItem)
        wanted = [
            self._normTitle(tmdbItem.get("name") or tmdbItem.get("title")),
            self._normTitle(tmdbItem.get("original_title") or tmdbItem.get("original_name"))
        ]
        wanted = [x for x in wanted if x]
        if not wanted and not target_id:
            return None

        # 1) Exact TMDb ID is authoritative.
        if target_id:
            for row in rows or []:
                if self._serverTmdbId(row) == target_id:
                    return row

        # 2) Title/year matching is intentionally strict.  A wrong movie is
        # worse than reporting "not available".
        best = None
        best_score = 0.0
        for row in rows or []:
            candidate = self._normTitle((row or {}).get("name") or (row or {}).get("title"))
            if not candidate:
                continue
            row_year = self._year(row)
            if target_year and row_year and target_year != row_year:
                continue

            score = max([self._title_score(w, candidate) for w in wanted] or [0.0])
            if score <= 0.0:
                continue

            # If either side lacks a year, accept only an exact/near-exact
            # normalized title.  This prevents remakes and similarly named films.
            if not (target_year and row_year) and score < 0.98:
                continue

            # With an exact year, still require a strong title identity.
            if target_year and row_year and score < 0.94:
                continue

            if score > best_score:
                best, best_score = row, score
        return best

    def matchServerItem(self, tmdbItem):
        match = self._strictMatchFromRows(tmdbItem, self.serverItems or [])
        if match:
            return match

        # Xtream serverItems already contains the full enabled catalogue.
        # Stalker landing mode contains only one package, so Backdrop
        # must search every enabled package before declaring the title absent.
        if self.source.get("type") != "stalker":
            return None
        try:
            client = get_source_client(self.source)
            categories, _origin = get_cached_categories(
                self.source, self.kind, client=client, wait_for_server=True
            )
            categories = filter_categories(self.source, self.kind, categories or [])
            for category in categories:
                category_id = str((category or {}).get("category_id") or "")
                if not category_id:
                    continue
                rows, _origin = get_category_streams(
                    self.source, self.kind, client, category_id,
                    use_cache=True, wait_for_server=True
                )
                match = self._strictMatchFromRows(tmdbItem, rows or [])
                if match:
                    return match
        except Exception:
            pass
        return None


    def _switchContentKind(self, new_kind):
        """Switch Movies/TV Shows inside this same Screen; never stack another ContentHomeScreen."""
        if new_kind == self.kind:
            self.focus = "top"
            self.updateFocus()
            return
        self.contentGeneration += 1
        self.categoryLoadToken += 1
        self.kind = new_kind
        self.contentMode = _content_default_mode(new_kind)
        self.topIndex = 3 if new_kind == "vod" else 4
        self.focus = "top"

        self.backdrops, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        self.backdropStart = self.backdropIndex = self.latestStart = self.latestIndex = 0

        # Keep the top hero/backdrop title fixed while switching content type.
        primary_title = "Movies You Might Like" if new_kind == "vod" else "TV Shows You Might Like"
        self["backdropTitle"].setText(tr(primary_title))
        self._updateLatestTitle()
        self["latestCategoryName"].setText("")
        self["heroDesc"].setText("")
        self["logoTitle"].setText("")
        self["heroMeta"].setText("")
        try:
            # Never hide the hero while switching Movies/TV Shows.
            # Keep a visible placeholder until the new backdrop is decoded.
            self["hero"].show()
            if self["hero"].instance:
                self["hero"].instance.setPixmapFromFile(
                    os.path.join(PLUGIN_PATH, "skins", "home/banner_placeholder.jpg")
                )
            self["logoImage"].hide()
        except Exception:
            pass
        self.renderBackdrops()
        self.renderLatest()
        self.updateFocus()

        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentSwitch")
        t.daemon = True
        t.start()

    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def ok(self):
        from .ui import TiviMateE2Search, TiviMateE2Home, MediaScreen, SeriesDetailsScreen, ServerHub, ContinueWatchingScreen, SettingsDashboard, FavoritesScreen
        from .tivimate_player import TiviMatePlayer
        if self.focus == "top":
            if self.topIndex == 0:
                self._openPageOnce(TiviMateE2Home)
                return
            if self.topIndex == 1:
                self._openPageOnce(TiviMateE2Search, self.source)
                return
            if self.topIndex == 2:
                self._openPageOnce(MediaScreen, self.source, "live")
                return
            if self.topIndex == 3:
                self._switchContentKind("vod")
                return
            if self.topIndex == 4:
                self._switchContentKind("series")
                return
            if self.topIndex == 5:
                from .ui import ContentPackagesScreen
                self._openPageOnce(ContentPackagesScreen, self.source)
                return
            if self.topIndex == 6:
                from .ui import MovieGenresScreen
                self._openPageOnce(MovieGenresScreen, dict(self.source), self.kind)
                return
            if self.topIndex == 7:
                self._openPageOnce(ContinueWatchingScreen, self.source)
                return
            if self.topIndex == 8:
                from .ui import TiviMateE2IPTVFinder
                self._openPageOnce(TiviMateE2IPTVFinder)
                return
            if self.topIndex == 9:
                self._openPageOnce(SettingsDashboard)
                return
            if self.topIndex == 10:
                self._openPageOnce(FavoritesScreen)
                return
            return
        item = self.current()
        if not item:
            return
        if self.kind == "series":
            if item.get("_tmdb"):
                chosen = dict(item)
                chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
                self.session.open(SeriesDetailsScreen, self.source, chosen)
                return
            self.session.open(SeriesDetailsScreen, self.source, item)
            return
        if item.get("_tmdb"):
            chosen = dict(item)
            chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
            chosen["_source_scope"]="content_home"
            self.session.open(
                MovieDetailsScreen, self.source, chosen, self.serverItems,
                {"scope":"content_home","category_id":str(chosen.get("category_id") or ""),"items":list(self.serverItems or [])}
            )
            return
        detail_item=dict(item or {})
        detail_item["_source_scope"]="content_home"
        self.session.open(
            MovieDetailsScreen, self.source, detail_item, self.serverItems,
            {"scope":"content_home","category_id":str(detail_item.get("category_id") or ""),"items":list(self.serverItems or [])}
        )
        return

    def _sortLabel(self):
        return {"default": "Date", "name": "Name", "rating": "Rating"}.get(self.sortMode, "Date")

    def _sortBadge(self):
        labels = {
            "default": "[🕒 %s]" % tr("Date"),
            "name": "[A-Z %s]" % tr("Name"),
            "rating": "[★ %s]" % tr("Rating"),
        }
        return labels.get(self.sortMode, labels["default"])

    def _addedSortValue(self, item):
        """Return the provider's real add/update timestamp for Latest rows.

        Movies use ``added``. Series use ``last_modified`` first and then
        ``added`` because many Xtream panels do not publish ``added`` for a
        series. Production year and TMDb release dates are deliberately not
        used here.
        """
        row = item or {}
        if self.kind == "series":
            raw = row.get("last_modified")
            if raw in (None, "", 0, "0"):
                raw = row.get("added")
        else:
            raw = row.get("added")
        if raw is None:
            return 0
        try:
            value = float(raw)
            # Some portals send Unix time in milliseconds rather than seconds.
            if value != value or value == float("inf") or value == float("-inf"):
                return 0
            if abs(value) >= 100000000000:
                value = value / 1000.0
            return value
        except Exception:
            pass
        try:
            text = str(raw).strip().replace("T", " ")
        except Exception:
            return 0
        # Stalker commonly returns e.g. "2015-08-21 18:35:31".  Parse the
        # standard date-time part and tolerate an optional time-zone suffix.
        for value, pattern in ((text[:19], "%Y-%m-%d %H:%M:%S"), (text[:10], "%Y-%m-%d")):
            try:
                return time.mktime(time.strptime(value, pattern))
            except (TypeError, ValueError, OverflowError):
                pass
        return 0

    def _sortedItems(self, items):
        rows = list(items or [])
        if self.sortMode == "name":
            rows.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
        elif self.sortMode == "newest":
            rows.sort(key=lambda x: str(x.get("last_modified") or x.get("added") or x.get("year") or x.get("releaseDate") or ""), reverse=True)
        elif self.sortMode == "year":
            rows.sort(key=lambda x: str(x.get("year") or x.get("releaseDate") or "")[:4], reverse=True)
        elif self.sortMode == "rating":
            def rating_value(x):
                try: return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception: return 0
            rows.sort(key=rating_value, reverse=True)
        else:
            # Sort timestamped entries newest-first. Keep entries for which the
            # provider exposes no usable timestamp in their original server
            # order instead of hiding the whole Series section.
            dated = []
            undated = []
            for position, item in enumerate(rows):
                stamp = self._addedSortValue(item)
                if stamp > 0:
                    dated.append((stamp, position, item))
                else:
                    undated.append((position, item))
            dated.sort(key=lambda entry: (entry[0], -entry[1]), reverse=True)
            rows = [entry[2] for entry in dated] + [entry[1] for entry in undated]
        return rows

    def _activeItems(self):
        return self.categoryItems if self.categoryIndex >= 0 else self.serverItems

    def _positionLatestCategoryName(self):
        """Keep the server package name directly beside the translated mode title."""
        try:
            if not self["latestTitle"].instance or not self["latestCategoryName"].instance:
                return
            lang = get_language()
            if lang == "ar":
                # Arabic heading is right-aligned in the block moved by
                # _applyArabicHeadingLayout. Put the package immediately to its left.
                title_x = 1110
                title_w = 730
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(220, min(700, len(self["latestTitle"].getText()) * 18))
                cat_w = 720
                x = max(80, title_x + title_w - rendered - cat_w - 18)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(cat_w), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(2)
                except Exception:
                    pass
            else:
                title_x = 80
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(180, min(700, len(self["latestTitle"].getText()) * 17))
                x = min(1020, title_x + rendered + 14)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(820), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(0)
                except Exception:
                    pass
        except Exception:
            pass

    def _updateLatestTitle(self):
        try:
            self["latestTitle"].setText(tr(_content_mode_title(self.kind, self.contentMode)))
        except Exception:
            pass
        try:
            category = str(getattr(self, "categoryName", "") or "").strip()

            # NONE disables only the optional automatic source label.
            # Keep server/package posters visible, but do not show the orphan
            # Date/Recent sort badge when no explicit package is selected.
            if self.contentMode == "none" and not category:
                self["latestCategoryName"].setText("")
                self._positionLatestCategoryName()
                return

            badge = self._sortBadge()
            if category:
                text = "  •  %s   %s" % (category, badge)
            else:
                text = "  •  %s" % badge
            self["latestCategoryName"].setText(text)
        except Exception:
            pass
        self._positionLatestCategoryName()

    def _changeCategory(self, direction):
        if not self.categoriesLoaded:
            self["heroDesc"].setText("")
            return
        if not self.categoriesList:
            self["heroDesc"].setText(tr("No enabled categories are available for this library."))
            return
        if direction < 0 and self.categoryIndex < 0:
            self.categoryIndex = len(self.categoriesList) - 1
        else:
            self.categoryIndex = (self.categoryIndex + direction) % len(self.categoriesList)
        category = self.categoriesList[self.categoryIndex]
        category_id = str(category.get("category_id") or "")
        self.categoryName = category.get("category_name") or "Other"
        _package_diag("CATEGORY_SWITCH", kind=self.kind, direction=direction, index=self.categoryIndex, category_id=category_id, category_name=self.categoryName)
        self._updateLatestTitle()
        if not category_id:
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken

        # Reuse ONLY a package that this screen previously loaded as a full
        # provider response. Never reuse a global/recent/partial category map.
        if category_id in self._fullPackageRows:
            rows = list(self._fullPackageRows.get(category_id) or [])
            _package_diag("PACKAGE_SCREEN_RAM_HIT", kind=self.kind, category_id=category_id, category_name=self.categoryName, item_count=len(rows))
            self.categoryItems = rows
            self.latest = self._sortedItems(rows)
            self.latestStart = self.latestIndex = 0
            self.focus = "latest"
            self._categorySwitchPreviewNow = True
            self._updateLatestTitle()
            self.renderLatest()
            if self.latest:
                self.preview()
            self.updateFocus()
            self["heroDesc"].setText("")
            return

        # Movies package switching: paint an existing per-package cache immediately.
        # Do not make the small-poster rail wait for the background provider request.
        # The normal worker below still runs, so a stale/missing cache is refreshed
        # without changing the established Series path.
        quick_rows = []
        quick_origin = "miss"
        if self.kind == "vod":
            try:
                quick_rows, quick_origin = peek_category_streams_cache(self.source, self.kind, category_id)
            except Exception:
                quick_rows, quick_origin = [], "miss"
        if quick_rows:
            self.categoryItems = list(quick_rows)
            self.latest = self._sortedItems(self.categoryItems)
            self.latestStart = self.latestIndex = 0
            self.focus = "latest"
            self._categorySwitchPreviewNow = True
            self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
            if self.latest:
                self.preview()
            _package_diag("PACKAGE_MOVIES_FAST_CACHE", kind=self.kind, category_id=category_id, category_name=self.categoryName, origin=quick_origin, item_count=len(quick_rows))
        else:
            # Cold package cache: keep the already-painted small-poster rail on
            # screen while the selected Movies/Series package is fetched by the
            # worker.  Do not blank the UI and make the package switch look even
            # slower. categoryReady() replaces it atomically when data arrives.
            self.focus = "latest"
            self._updateLatestTitle(); self.updateFocus()
        self["heroDesc"].setText("")
        name = "TiviMateNextCategory" if direction > 0 else "TiviMatePreviousCategory"
        is_stalker = self.source.get("type") == "stalker"
        if is_stalker:
            # Supersede any older unfinished category request.  The worker also
            # checks the token before storing a result, preventing an old reply
            # from overwriting a newer red/blue selection.
            self.stalkerCategoryLoadResult = None
            self.stalkerCategoryPendingToken = token
        submitted = _submit_content_bg(
            self._loadCategory,
            args=(token, category_id),
            key=("category-load", id(self))
        )
        _package_diag("PACKAGE_WORKER_SUBMIT", kind=self.kind, category_id=category_id, category_name=self.categoryName, token=token, submitted=submitted)
        if not submitted:
            self["heroDesc"].setText(tr("."))
        if is_stalker:
            try:
                self.stalkerCategoryLoadTimer.start(120, True)
            except Exception:
                pass

    def previousCategory(self):
        self._changeCategory(-1)

    def nextCategory(self):
        self._changeCategory(1)

    def _loadCategory(self, token, category_id):
        if token != getattr(self, "categoryLoadToken", token):
            return
        source = dict(self.source or {})
        try:
            client = get_source_client(source)
            cid = str(category_id or "").strip()
            # Package switch: use the per-package RAM/disk cache first.
            # On a real cache miss only, fetch this selected package from the
            # provider in the worker thread and persist it for the next visit.
            # This deliberately avoids the old direct client.streams() path,
            # which bypassed package cache and caused every switch to wait.
            _package_diag("PACKAGE_FETCH_BEGIN", kind=self.kind, category_id=cid, token=token, source_type=source.get("type") or "")
            items, origin = get_category_streams(
                source, self.kind, client, cid, use_cache=True, wait_for_server=True
            )
            _package_diag("PACKAGE_FETCH_DONE", kind=self.kind, category_id=cid, token=token, origin=origin, item_count=len(items or []))
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, items, origin, "")
                return
            self._queueGui(self.categoryReady, token, items, origin)
        except Exception as exc:
            _package_diag("PACKAGE_FETCH_ERROR", kind=self.kind, category_id=str(category_id or ""), token=token, error=repr(exc))
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, [], "error", str(exc))
                return
            self._queueGui(self.categoryFailed, token, str(exc))


    def _finishStalkerCategoryLoad(self):
        """Apply the newest Stalker category result only on the GUI thread."""
        expected = getattr(self, "stalkerCategoryPendingToken", None)
        if expected is None:
            return
        result = self.stalkerCategoryLoadResult
        if result is None:
            if expected == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        # A completion can race with this callback; erase only the same object
        # that was observed, never a newer result written by a newer worker.
        if self.stalkerCategoryLoadResult is result:
            self.stalkerCategoryLoadResult = None
        token, items, origin, error = result
        if token != getattr(self, "categoryLoadToken", 0) or token != expected:
            if getattr(self, "stalkerCategoryPendingToken", None) == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        self.stalkerCategoryPendingToken = None
        if error:
            self.categoryFailed(token, error)
        else:
            self.categoryReady(token, items, origin)

    def categoryReady(self, token, items, origin):
        if token != self.categoryLoadToken:
            _package_diag("CATEGORY_READY_STALE", kind=self.kind, token=token, current_token=self.categoryLoadToken, origin=origin, item_count=len(items or []))
            return
        self.categoryItems = list(items or [])
        _package_diag("CATEGORY_READY", kind=self.kind, token=token, category_name=self.categoryName, origin=origin, item_count=len(self.categoryItems))

        # Cache only this complete provider response.
        try:
            if 0 <= self.categoryIndex < len(self.categoriesList):
                current_cid = str((self.categoriesList[self.categoryIndex] or {}).get("category_id") or "")
                if current_cid:
                    self._fullPackageRows[current_cid] = list(self.categoryItems)
        except Exception:
            pass

        self.latest = self._sortedItems(self.categoryItems)
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()
        if not self.latest:
            if self.source.get("type") == "stalker" and origin == "empty":
                self["heroDesc"].setText("Stalker returned no items for %s. Try another package or refresh the source." % self.categoryName)
            else:
                self["heroDesc"].setText("No titles are available in %s." % self.categoryName)

    def categoryFailed(self, token, msg):
        if token != self.categoryLoadToken:
            _package_diag("CATEGORY_FAILED_STALE", kind=self.kind, token=token, current_token=self.categoryLoadToken, error=msg)
            return
        _package_diag("CATEGORY_FAILED", kind=self.kind, token=token, category_name=self.categoryName, error=msg)
        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("Unable to load %s: %s" % (self.categoryName, msg))

    def toggleSort(self):
        modes = ["newest", "name", "year", "default"] if self.kind == "series" else ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        self.latest = self._sortedItems(self._activeItems())
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()

    def serverList(self):
        from .ui import ServerManager
        self._openPageOnce(ServerHub)

    def openMovieGenres(self):
        if self.kind not in ("vod","series"):
            return
        try:
            from .ui import MovieGenresScreen
            self._openPageOnce(MovieGenresScreen, self.source, self.kind)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Movie Genres:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def categories(self):
        # Replace the legacy blue Movie/Series Categories screen with the
        # modern package browser; its artwork follows Movies vs Series.
        from .ui import HomePackageBrowserScreen
        self.session.openWithCallback(self.categoryChosen, HomePackageBrowserScreen, self.source, self.kind)

    def categoryChosen(self, selected=None):
        if not selected or not isinstance(selected, dict):
            return
        category_id = str(selected.get("id") or "")
        category_name = selected.get("name") or ""
        if not category_id:
            return
        # Green Packages is a launcher: after choosing a package, open the
        # large package/content page directly for that package. Do not filter
        # this Movies/TV Shows home page in-place.
        from .ui import MediaScreen
        if category_id == "__recent_added__":
            self._openPageOnce(MediaScreen, self.source, self.kind, category_id, category_name)
            return
        self._openPageOnce(MediaScreen, self.source, self.kind, category_id, category_name)

# Home-triggered metadata-only warm for Movies/TV Shows backdrop rails.
def warm_backdrop_metadata_from_home(source):
    """Prepare Movies + TV backdrop rail rows and TMDb metadata without artwork downloads."""
    source = dict(source or {})
    if not source:
        return
    try:
        tmdb = TMDbClient()
    except Exception:
        return
    for kind in ("vod", "series"):
        try:
            allowed = set(str(x) for x in (get_allowed_category_ids(source, kind) or []) if str(x))
            if not allowed:
                continue
            filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
            cache_mode = "backdrop_filtered_smart_v6_anyyear_warm_%s_%s" % (kind, filter_sig)
            rows = _home_feed_cache_get(cache_mode, source, allow_stale=False)
            if not rows:
                client = get_source_client(source)
                ordered_ids = list(allowed)
                random.shuffle(ordered_ids)
                candidates, seen = [], set()
                for offset in range(0, len(ordered_ids), 4):
                    batches = get_category_streams_batch(source, kind, client, ordered_ids[offset:offset + 4], use_cache=True, wait_for_server=True, max_workers=4)
                    for cid, items, _origin in batches:
                        for raw in items or []:
                            if not isinstance(raw, dict):
                                continue
                            title = str(raw.get("name") or raw.get("title") or "").strip()
                            year = str(raw.get("year") or raw.get("releaseDate") or raw.get("release_date") or "").strip()
                            if not title:
                                continue
                            clean = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
                            key = clean
                            if not clean or key in seen:
                                continue
                            seen.add(key)
                            row = dict(raw)
                            m = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", year or title)
                            if m:
                                row["_backdrop_year"] = m.group(1)
                            candidates.append(row)
                    if len(candidates) >= 36:
                        break
                random.shuffle(candidates)
                rows = candidates[:12]
                if rows:
                    _home_feed_cache_put(cache_mode, source, rows)
            for row in rows[:12]:
                try:
                    title = str(row.get("name") or row.get("title") or "").strip()
                    if not title:
                        continue
                    year = str(row.get("_backdrop_year") or row.get("year") or "").strip()[:4] or None
                    resolved = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
                    found = {}
                    if not resolved:
                        found = tmdb.search_title(title, kind, year) or tmdb.search_title(title, kind, None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if not resolved:
                        continue
                    bundle = tmdb.details_bundle(resolved, kind) or {}
                    merged = dict(found or {})
                    merged.update(bundle)
                    row["tmdb_id"] = resolved
                    bd = str(merged.get("backdrop_path") or "").strip()
                    ps = str(merged.get("poster_path") or "").strip()
                    if bd:
                        row["_tmdb_backdrop"] = bd
                    if ps:
                        row["_tmdb_poster"] = ps
                    norm = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("%s:%s" % (kind, resolved)), merged, _DETAILS_DATA_CACHE_LIMIT)
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("%s:title:%s:%s" % (kind, norm, str(year or ""))), merged, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue
            if rows:
                _home_feed_cache_put(cache_mode, source, rows[:12])
        except Exception:
            continue
