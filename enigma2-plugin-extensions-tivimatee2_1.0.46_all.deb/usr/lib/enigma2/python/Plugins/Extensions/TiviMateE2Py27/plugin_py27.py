# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import monotonic, thread_factory
# Load TiviMateE2's namespaced player keymap (Ultra/XStreamity-style TV key mapping).
try:
    import os
    import keymapparser
    _KEYMAP = os.path.join(os.path.dirname(__file__), "keymap.xml")
    if os.path.isfile(_KEYMAP):
        keymapparser.readKeymap(_KEYMAP)
except Exception:
    pass

# No Python 2.7 feature modules are loaded at Enigma2 boot.
# This experimental plugin initializes only after a user opens it.
from Plugins.Plugin import PluginDescriptor

# Do not import the complete UI, seven large UI source fragments, and 24-poster
# GENRE browser on every Enigma2 boot.  They are only needed when TiviMate
# itself opens, not for PluginDescriptor, web service or background EPG jobs.
# This cuts the plugin's idle baseline without disabling any menu or page.


# Start the existing LAN Web Access service after the Enigma session is ready.
# Keep network/service setup off the GUI thread and cancel retries on shutdown.
import threading as _web_boot_threading
_web_boot_lock = _web_boot_threading.RLock()
_web_boot_timer = None
_web_boot_enabled = False


def _web_boot_log(message):
    try:
        import os
        import time
        path = '/tmp/tivimate_web_access.log'
        if os.path.exists(path) and os.path.getsize(path) > 65536:
            os.remove(path)
        with open(path, 'a') as handle:
            handle.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), message))
    except Exception:
        pass


def _web_boot_attempt(attempt):
    global _web_boot_timer
    with _web_boot_lock:
        if not _web_boot_enabled:
            return
        _web_boot_timer = None
        try:
            from . import web_manager
            if web_manager.start_web_manager():
                port = getattr(web_manager._SERVER, 'server_port', web_manager.WEB_PORT)
                _web_boot_log('Web Access listening on port %s' % port)
                return
            _web_boot_log('Web Access start failed: %s' % web_manager._WEB_ERROR)
        except Exception as error:
            _web_boot_log('Web Access startup exception: %s: %s' % (type(error).__name__, str(error)[:240]))
        if attempt < 3 and _web_boot_enabled:
            _web_boot_timer = _web_boot_threading.Timer(5.0, _web_boot_attempt, args=(attempt + 1,))
            _web_boot_timer.setDaemon(True)
            _web_boot_timer.start()


def _web_boot_start():
    global _web_boot_enabled, _web_boot_timer
    with _web_boot_lock:
        if _web_boot_enabled:
            return
        _web_boot_enabled = True
        _web_boot_timer = _web_boot_threading.Timer(2.0, _web_boot_attempt, args=(1,))
        _web_boot_timer.setDaemon(True)
        _web_boot_timer.start()


def _web_boot_stop():
    global _web_boot_enabled, _web_boot_timer
    with _web_boot_lock:
        _web_boot_enabled = False
        if _web_boot_timer is not None:
            _web_boot_timer.cancel()
            _web_boot_timer = None


def _web_session_start(reason=0, session=None, **kwargs):
    """Python 2.7 build registers no general session hook; this one only
    restores Web Access (start) and closes it (shutdown)."""
    try:
        if reason in (0, None):
            _web_boot_start()
            try:
                from .stalker_bouquet_resolver import start_if_exported
                start_if_exported()
            except Exception:
                pass
        else:
            _web_boot_stop()
            import sys
            loaded = sys.modules.get(__name__.rsplit('.', 1)[0] + '.web_manager')
            if loaded is not None:
                loaded.stop_web_manager()
    except Exception:
        pass



def _run_home_maintenance(session, backup):
    """Start nonessential maintenance after Home has been visible for a while."""
    try:
        import threading
        worker = threading.Thread(target=backup, kwargs={"force": False})
        worker.daemon = True
        worker.start()
    except Exception:
        pass
    try:
        from .stalker_epgimport import start_export as export_stalker_epg
        export_stalker_epg()
    except Exception:
        pass


def main(session, **kwargs):
    """Open TiviMate E2 without duplicate source reads, and record stage timings."""
    # DreamOS/Merlin/Gemini crash (font.cpp ASSERTION) when a skin lacks a
    # font face used by the plugin XML ("Bold" on Default-FHD). Register
    # missing faces once, before any plugin screen is built.
    try:
        from .font_guard import ensure_fonts
        ensure_fonts()
    except Exception:
        pass
    import time
    started = monotonic()
    try:
        from .perf_watch import start as _perf_start
        _perf_start()
    except Exception:
        pass
    # SQLite is optional on Enigma2 images. Cache and category filters already
    # support persistent JSON; core selects the original legacy Stalker backend
    # if UltraStalker's SQLite-backed store is unavailable. Never block the
    # Home/Xtream/M3U UI or attempt a package-feed install on launch.
    # UI module imports once per Enigma process. The expensive UI fragment
    # compilation is prewarmed after session start, never in a GUI widget.
    # Only touch private Python2 temporary cache when the user opens this build.
    try:
        from .cache_manager import migrate_legacy_tmp_cache, cleanup_stale_temp_files
        migrate_legacy_tmp_cache()
        cleanup_stale_temp_files()
    except Exception:
        pass
    # Images without a CA bundle / python-requests (VTi, older OpenPLi/BH):
    # bundled CA for every TLS client, stdlib requests stand-in for subtitles.
    try:
        from .py27_ssl import install_ca_environment
        install_ca_environment()
    except Exception:
        pass
    try:
        from .requests_compat import install as install_requests_compat
        install_requests_compat()
    except Exception:
        pass
    # VTi: old PIL/Pillow lacks APIs used by actor circles, picons and logos.
    try:
        from .pil_compat import install_pil_compat
        install_pil_compat()
    except Exception:
        pass
    # VTi test: sanitize only our screens before the legacy skin parser.
    from .vti_compat import install_vti_skin_compat
    install_vti_skin_compat()
    from . import ui as _tivimate_ui
    imported = monotonic()
    from .genre_page import install_genre_page
    install_genre_page(_tivimate_ui)
    # Dreambox DM900/DM920 colour LCD: show TiviMate picons and cached VOD
    # posters on its separate 400x240 front panel (not the TV skin).
    try:
        from .dream_frontpanel import install_frontpanel
        install_frontpanel(_tivimate_ui)
    except Exception:
        # A missing display must never prevent TiviMate from opening.
        pass
    genre_ready = monotonic()
    # Normalize Python2 plugin-owned screen coordinate systems before creating
    # a window. Unlike global skin edits this never touches DreamOS skin.xml.
    from .font_preferences import refresh_loaded_screens
    refresh_loaded_screens()
    try:
        from .perf_watch import mark as _perf_mark
        _perf_mark("open: ui import %.2fs, genre/frontpanel %.2fs, fonts %.2fs" % (
            imported - started, genre_ready - imported, monotonic() - genre_ready))
    except Exception:
        pass
    try:
        from .TiviMateSubtitles.tivimate_subtitles import applySubtitleFontAsReplacement
        applySubtitleFontAsReplacement()          # chosen subtitle font: in TiviMate only
    except Exception:
        pass

    # Keep native exported channels available even before Home maintenance.
    try:
        from .stalker_bouquet_resolver import start_if_exported
        start_if_exported()
    except Exception:
        pass

    def _tivimate_closed(*args):
        try:
            from .memory_manager import ui_closed
            ui_closed()
        except Exception:
            pass
        try:
            from .TiviMateSubtitles.tivimate_subtitles import restoreSystemReplacementFont
            restoreSystemReplacementFont()        # receiver menus get their own font back
        except Exception:
            pass
    try:
        # TV key in the Live player returns to this satellite channel.
        from .quick_switch import remember_playing
        remember_playing(session)
    except Exception:
        pass
    from .memory_manager import ui_opened, ui_closed
    ui_opened()
    try:
        session.openWithCallback(_tivimate_closed, _tivimate_ui.TiviMateE2Home)
    except Exception:
        ui_closed()
        raise
    # Do not write startup diagnostics into /tmp.

def _py27_build_label():
    """Read this installed package's marker, not an obsolete hardcoded label."""
    try:
        import os
        marker = os.path.join(os.path.dirname(__file__), "PY27_BUILD.txt")
        with open(marker, "r") as handle:
            return handle.read().strip()[:72] or "PY27-1.0.46"
    except (IOError, OSError):
        return "PY27-1.0.46"


def safe_main(session, **kwargs):
    """Experimental branch: a failed import should show an error, not crash boot."""
    try:
        return main(session, **kwargs)
    except Exception as exc:
        where = ""
        try:
            import sys, os, traceback, time
            frames = traceback.extract_tb(sys.exc_info()[2])
            if frames:
                last = frames[-1]
                where = " (%s:%d)" % (os.path.basename(last[0]), last[1])
            with open("/home/root/tivimatee2_start_error.log", "a") as log:
                log.write("%s %s\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"),
                                             _py27_build_label(), traceback.format_exc()))
        except Exception:
            pass
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, "TiviMate E2 [%s] could not start: %s%s" % (_py27_build_label(), str(exc)[:150], where), MessageBox.TYPE_ERROR, timeout=15)
        except Exception:
            pass
        return None


def menu(menuid, **kwargs):
    """Expose TiviMate IPTV in the Enigma2 main menu."""
    if menuid != "mainmenu":
        return []
    return [("TiviMate E2", safe_main, "TiviMateE2Py27", 45)]


def Plugins(**kwargs):
    # DreamOS/Merlin/Gemini crash (font.cpp ASSERTION) when a skin lacks a
    # font face used by the plugin XML ("Bold" on Default-FHD). Register
    # missing faces once, before any plugin screen is built.
    try:
        from .font_guard import ensure_fonts
        ensure_fonts()
    except Exception:
        pass
    return [
        PluginDescriptor(
            name="TiviMate E2",
            description="TiviMate IPTV",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icons/plugin.png",
            fnc=safe_main,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=_web_session_start,
        ),
    ]
