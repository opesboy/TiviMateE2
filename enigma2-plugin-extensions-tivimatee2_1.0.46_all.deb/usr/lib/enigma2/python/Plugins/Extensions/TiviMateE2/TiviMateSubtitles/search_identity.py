"""Conservative subtitle search identity checks (no player or download changes)."""
import re
import unicodedata

YEAR = re.compile(r'(?<!\d)((?:19|20)\d{2})(?!\d)')
ID = re.compile(r'^tt\d{5,12}$', re.I)
TECH = re.compile(r'\b(?:480p|720p|1080p|2160p|4320p|web[ ._-]*(?:dl|rip)|bluray|blu[ ._-]*ray|brrip|dvdrip|hdtv|x26[45]|h[ ._-]*26[45]|remux|hevc|camrip|hdcam|hdrip|dvdscr)\b', re.I)
EP = re.compile(r'(?<![a-z0-9])s(\d{1,2})[ ._-]*e(\d{1,3})(?!\d)|(?<!\d)(\d{1,2})x(\d{1,3})(?!\d)', re.I)

def text(v):
    return str(v or '').strip()

def key(v):
    return ' '.join(re.findall(r'[^\W_]+', unicodedata.normalize('NFKC', text(v)).casefold(), re.UNICODE))

def year_value(v):
    m = YEAR.search(text(v))
    return m.group(1) if m else ''

def imdb_value(v):
    v = text(v).lower()
    return v if ID.fullmatch(v) else ''

def title_year(v, expected_title=''):
    # Only a year following a title, never the year-only title (1917, 2012).
    raw = re.sub(r'\.(?:srt|ass|ssa|vtt|sub|zip|rar)$', '', text(v), flags=re.I)
    raw = raw.replace('_',' ').replace('.', ' ')
    raw = re.sub(r'^\[[^\]]{1,50}\]\s*', '', raw)
    raw = TECH.split(raw, 1)[0].strip(' ._-')
    matches = list(YEAR.finditer(raw))
    for m in reversed(matches):
        prefix = raw[:m.start()].strip(' ._-([')
        suffix = raw[m.end():].strip(' ._-)])[')
        if not prefix or (suffix and not re.fullmatch(r'(?i)(?:ar|ara|arabic|en|eng|english|fr|fre|french|hi|sdh)', suffix)):
            continue
        if key(raw.strip(' ()[]')) == key(expected_title):
            continue
        return prefix, m.group(1)
    return '', ''

def metadata_identity(row, title='', year='', season='', episode='', imdb_id=''):
    """Return -1 for an explicit conflict, 1 for known identity, 0 for unknown.

    Release filenames may use translated titles; never reject unknown/ambiguous
    titles solely by fuzzy similarity. Explicit years/episode numbers are safer.
    """
    expected_year = year_value(year)
    expected_id = imdb_value(imdb_id)
    is_tv = str(season or '0') != '0' and str(episode or '0') != '0'
    expected_key = key(title)
    matching_id = False
    for field in ('imdb_id','imdbId','imdbID','imdb','imdbid'):
        actual_id = imdb_value(row.get(field))
        if actual_id and expected_id:
            if actual_id != expected_id:
                return -1
            matching_id = True
    values = [text(row.get(f)) for f in ('release','filename','title','release_name','movie_release') if row.get(f)]
    if is_tv:
        try:
            target = (int(season), int(episode))
        except (TypeError, ValueError):
            return 1 if matching_id else 0
        pairs = set()
        for v in values:
            for m in EP.finditer(v):
                pairs.add(tuple(int(x) for x in (m.group(1,2) if m.group(1) else m.group(3,4))))
        if pairs and target not in pairs:
            return -1
        return 1 if matching_id or target in pairs else 0
    if any(EP.search(v) for v in values):
        return -1
    if matching_id:
        return 1
    explicit = {year_value(row.get(f)) for f in ('movie_year','release_year','year','release_date') if row.get(f)} - {''}
    if expected_year and explicit and expected_year not in explicit:
        return -1
    candidates = [title_year(v, title) for v in values]
    candidates = [(key(t), y) for t,y in candidates if t and y]
    if expected_year and candidates:
        # Filename years may be ambiguous if a movie has a numeric title;
        # explicit same-title year mismatches or all clear years differing fail.
        years = {y for t,y in candidates}
        if expected_year not in years and not (explicit and expected_year in explicit):
            return -1
    # Known titles that strictly extend the requested title indicate a different
    # sequel or similarly named movie, not merely a translated alternate title.
    if expected_key and candidates:
        if any(t == expected_key for t,y in candidates):
            return 1 if expected_year and (expected_year in {y for t,y in candidates} or expected_year in explicit) else 0
        if all(t.startswith(expected_key + ' ') or expected_key.startswith(t + ' ') for t,y in candidates):
            return -1
    if expected_year and expected_year in explicit:
        return 1
    return 0
