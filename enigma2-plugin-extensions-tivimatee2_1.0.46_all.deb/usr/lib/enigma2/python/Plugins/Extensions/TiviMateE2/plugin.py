# Load TiviMateE2's namespaced player keymap (Ultra/XStreamity-style TV key mapping).
try:
    import os
    import keymapparser
    _KEYMAP = os.path.join(os.path.dirname(__file__), "keymap.xml")
    if os.path.isfile(_KEYMAP):
        keymapparser.readKeymap(_KEYMAP)
except Exception:
    pass

from .cache_manager import migrate_legacy_tmp_cache, cleanup_stale_temp_files
try:
    migrate_legacy_tmp_cache()
    cleanup_stale_temp_files()
except Exception:
    pass
import sys
from Plugins.Plugin import PluginDescriptor

# Do not import the complete UI, seven large UI source fragments, and 24-poster
# GENRE browser on every Enigma2 boot.  They are only needed when TiviMate
# itself opens, not for PluginDescriptor, web service or background EPG jobs.
# This cuts the plugin's idle baseline without disabling any menu or page.


# Start the existing LAN Web Access service after the Enigma session is ready.
# Keep network/service setup off the GUI thread and cancel retries on shutdown.
import threading as _web_boot_threading
_web_boot_lock = _web_boot_threading.RLock()
_web_boot_timer = None
_web_boot_enabled = False


def _web_boot_log(message):
    try:
        import os
        import time
        path = '/tmp/tivimate_web_access.log'
        if os.path.exists(path) and os.path.getsize(path) > 65536:
            os.remove(path)
        with open(path, 'a') as handle:
            handle.write('%s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), message))
    except Exception:
        pass


def _web_boot_attempt(attempt):
    global _web_boot_timer
    with _web_boot_lock:
        if not _web_boot_enabled:
            return
        _web_boot_timer = None
        try:
            from . import web_manager
            if web_manager.start_web_manager():
                port = getattr(web_manager._SERVER, 'server_port', web_manager.WEB_PORT)
                _web_boot_log('Web Access listening on port %s' % port)
                return
            _web_boot_log('Web Access start failed: %s' % web_manager._WEB_ERROR)
        except Exception as error:
            _web_boot_log('Web Access startup exception: %s: %s' % (type(error).__name__, str(error)[:240]))
        if attempt < 3 and _web_boot_enabled:
            _web_boot_timer = _web_boot_threading.Timer(5.0, _web_boot_attempt, args=(attempt + 1,))
            _web_boot_timer.setDaemon(True)
            _web_boot_timer.start()


def _web_boot_start():
    global _web_boot_enabled, _web_boot_timer
    with _web_boot_lock:
        if _web_boot_enabled:
            return
        _web_boot_enabled = True
        _web_boot_timer = _web_boot_threading.Timer(2.0, _web_boot_attempt, args=(1,))
        _web_boot_timer.setDaemon(True)
        _web_boot_timer.start()


def _web_boot_stop():
    global _web_boot_enabled, _web_boot_timer
    with _web_boot_lock:
        _web_boot_enabled = False
        if _web_boot_timer is not None:
            _web_boot_timer.cancel()
            _web_boot_timer = None


def _session_start(reason=0, session=None, **kwargs):
    """Session maintenance: EPG refresh plus the lightweight LAN web manager."""
    if reason not in (0, None):
        _web_boot_stop()
        try:
            from .memory_manager import stop as stop_memory_manager
            stop_memory_manager()
        except Exception:
            pass
        try:
            from .web_manager import stop_web_manager
            stop_web_manager()
        except Exception:
            pass
        return
    try:
        # EPG reminders (Live MENU > Remind me): check every 20 s.
        from .epg_reminders import start as start_epg_reminders
        start_epg_reminders(session)
    except Exception:
        pass
    # Compile only built-in UI fragment sources in a background worker after
    # the session starts. No Enigma widget is created/imported on that thread.
    # When the user opens the plugin, the GUI can execute the prepared code.
    try:
        from .ui_preload import start_prewarm
        start_prewarm()
    except Exception:
        pass
    # Never auto-download XMLTV for the configured server list at Enigma boot.
    # EPG remains cache-first and is refreshed only for the source opened in
    # Live (ensure_source_epg) or explicitly refreshed in its own settings.
    # In particular, adding ten servers must not cause ten XMLTV workers.
    try:
        from .memory_manager import start as start_memory_manager
        start_memory_manager()
    except Exception:
        pass
    _web_boot_start()
    # Native Stalker bouquets remain playable even when TiviMate UI is closed.
    try:
        from .stalker_bouquet_resolver import start_if_exported
        start_if_exported()
    except Exception:
        pass


def _run_home_maintenance(session, backup):
    """Start nonessential maintenance after Home has been visible for a while."""
    try:
        import threading
        worker = threading.Thread(target=backup, kwargs={"force": False})
        worker.daemon = True
        worker.start()
    except Exception:
        pass
    try:
        from .epgimport_export import start_export
        start_export()
    except Exception:
        pass
    try:
        from .stalker_epgimport import start_export as export_stalker_epg
        export_stalker_epg()
    except Exception:
        pass
    # Keep the existing GUI-thread dependency installer and its notifications.
    try:
        from .sqlite_dependency import ensure_optional_packages
        ensure_optional_packages(session)
    except Exception:
        pass


def main(session, **kwargs):
    """Open TiviMate E2 without duplicate source reads, and record stage timings."""
    # DreamOS/Merlin/Gemini crash (font.cpp ASSERTION) when a skin lacks a
    # font face used by the plugin XML ("Bold" on Default-FHD). Register
    # missing faces once, before any plugin screen is built.
    try:
        from .font_guard import ensure_fonts
        ensure_fonts()
    except Exception:
        pass
    import time
    started = time.monotonic()
    # SQLite is optional on Enigma2 images. Cache and category filters already
    # support persistent JSON; core selects the original legacy Stalker backend
    # if UltraStalker's SQLite-backed store is unavailable. Never block the
    # Home/Xtream/M3U UI or attempt a package-feed install on launch.
    # UI module imports once per Enigma process. The expensive UI fragment
    # compilation is prewarmed after session start, never in a GUI widget.
    from . import ui as _tivimate_ui
    imported = time.monotonic()
    from .genre_page import install_genre_page
    install_genre_page(_tivimate_ui)
    # Dreambox DM900/DM920 colour LCD: show TiviMate picons and cached VOD
    # posters on its separate 400x240 front panel (not the TV skin).
    try:
        from .dream_frontpanel import install_frontpanel
        install_frontpanel(_tivimate_ui)
    except Exception:
        # A missing display must never prevent TiviMate from opening.
        pass
    genre_ready = time.monotonic()
    try:
        from .TiviMateSubtitles.tivimate_subtitles import applySubtitleFontAsReplacement
        applySubtitleFontAsReplacement()          # chosen subtitle font: in TiviMate only
    except Exception:
        pass

    # Keep native exported channels available even before Home maintenance.
    try:
        from .stalker_bouquet_resolver import start_if_exported
        start_if_exported()
    except Exception:
        pass

    def _tivimate_closed(*args):
        try:
            from .memory_manager import ui_closed
            ui_closed()
        except Exception:
            pass
        try:
            from .TiviMateSubtitles.tivimate_subtitles import restoreSystemReplacementFont
            restoreSystemReplacementFont()        # receiver menus get their own font back
        except Exception:
            pass
    try:
        # TV key in the Live player returns to this satellite channel.
        from .quick_switch import remember_playing
        remember_playing(session)
    except Exception:
        pass
    from .memory_manager import ui_opened, ui_closed
    ui_opened()
    try:
        session.openWithCallback(_tivimate_closed, _tivimate_ui.TiviMateE2Home)
    except Exception:
        ui_closed()
        raise
    # Do not write startup diagnostics into /tmp.

def menu(menuid, **kwargs):
    """Expose TiviMate IPTV only on the matching Python 3 image."""
    if sys.version_info[0] != 3:
        return []
    if menuid != "mainmenu":
        return []
    return [("TiviMate IPTV", main, "TiviMateE2", 45)]


def Plugins(**kwargs):
    # The IPK also contains TiviMateE2Py27. Never register both entrances
    # on a VTi/Python 2.7 box even when postinst could not detect libpython.
    if sys.version_info[0] != 3:
        return []
    # DreamOS/Merlin/Gemini crash (font.cpp ASSERTION) when a skin lacks a
    # font face used by the plugin XML ("Bold" on Default-FHD). Register
    # missing faces once, before any plugin screen is built.
    try:
        from .font_guard import ensure_fonts
        ensure_fonts()
    except Exception:
        pass
    return [
        PluginDescriptor(
            name="TiviMate E2",
            description="Independent Xtream, M3U and Stalker client for Enigma2",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icons/plugin.png",
            fnc=main,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_SESSIONSTART,
            fnc=_session_start,
        ),
    ]
