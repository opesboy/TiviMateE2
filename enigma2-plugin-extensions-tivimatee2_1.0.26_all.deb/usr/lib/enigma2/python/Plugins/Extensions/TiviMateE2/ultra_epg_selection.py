# -*- coding: utf-8 -*-
"""EPG programme summarization copied unchanged from UltraStalker/ultra.py.

The selection algorithm is used in regular Live, Windows and the infobar.
This module has no Enigma2 imports; it does not perform network requests.
"""
import time
import re
import unicodedata

def one_line(value, max_chars=180):
    raw = unicodedata.normalize("NFKC", str(value or ""))
    chars=[]
    for ch in raw:
        cat=unicodedata.category(ch)
        if ch.isspace(): chars.append(" ")
        elif cat in ("Cc","Cf","Cs","Co","Cn"): continue
        else: chars.append(ch)
    text=re.sub(r"\s+", " ", "".join(chars)).strip(" -|•")
    if max_chars and len(text)>max_chars:
        text=text[:max_chars-1].rstrip()+"…"
    return text


def epg_title(row):
    if not isinstance(row,dict): return ""
    return one_line(row.get("name") or row.get("title") or row.get("descr") or row.get("description"), 100)


def _timestamp(value):
    try:
        if isinstance(value,(int,float)): return int(value)
        text=str(value or "").strip()
        if text.isdigit(): return int(text)
        # Most MAG portals use YYYY-MM-DD HH:MM:SS.
        import datetime
        for fmt in ("%Y-%m-%d %H:%M:%S","%Y-%m-%dT%H:%M:%S","%H:%M"):
            try:
                parsed=datetime.datetime.strptime(text[:19],fmt)
                if fmt=="%H:%M":
                    now=datetime.datetime.now(); parsed=parsed.replace(year=now.year,month=now.month,day=now.day)
                return int(time.mktime(parsed.timetuple()))
            except Exception: pass
    except Exception: pass
    return 0


def epg_summary(rows, now=None):
    now=int(now or time.time()); events=[]
    for row in rows if isinstance(rows,list) else []:
        if not isinstance(row,dict): continue
        start=_timestamp(row.get("start_timestamp") or row.get("start") or row.get("time"))
        stop=_timestamp(row.get("stop_timestamp") or row.get("stop") or row.get("end") or row.get("time_to"))
        if stop and start and stop<start: stop=start+stop
        events.append((start,stop,row))
    events.sort(key=lambda x:x[0] or 0)
    current=None; nxt=None
    for idx,event in enumerate(events):
        start,stop,row=event
        if start and stop and start<=now<stop:
            current=event; nxt=events[idx+1] if idx+1<len(events) else None; break
    if current is None and events:
        future=[e for e in events if not e[0] or e[0]>=now]
        current=events[0] if not future else future[0]
        pos=events.index(current); nxt=events[pos+1] if pos+1<len(events) else None
    percent=0
    if current and current[0] and current[1] and current[1]>current[0]:
        percent=max(0,min(100,int((now-current[0])*100.0/(current[1]-current[0]))))
    return {
        "now": epg_title(current[2]) if current else "",
        "next": epg_title(nxt[2]) if nxt else "",
        "percent": percent,
    }
