# -*- coding: utf-8 -*-
"""Language-aware transparent TMDb title logos for every Enigma2 screen.

Use the selected TMDb metadata language, not the device interface language.
Images are selected by TMDb's real iso_639_1 tag; no image translation.
All remote lookups in this module must run on an existing background worker.
"""
from . import artwork_queue as _queue
from collections import OrderedDict
import threading
import re
_PROVIDER_CONTEXTS = OrderedDict()
_CONTEXT_LOCK = threading.RLock()


def _provider_for(url):
    with _CONTEXT_LOCK:
        return _PROVIDER_CONTEXTS.get(_queue.normalise_url(url))


KIND = "logos"
PROVIDER_KEYS = ("logo", "title_logo", "logo_path", "clearlogo")
RASTER = (".png", ".jpg", ".jpeg", ".webp")


def provider_logo_url(source, item, extra=None):
    url = _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)
    if url and isinstance(source, dict):
        with _CONTEXT_LOCK:
            _PROVIDER_CONTEXTS.pop(url, None)
            _PROVIDER_CONTEXTS[url] = dict(source)
            while len(_PROVIDER_CONTEXTS) > 384:
                _PROVIDER_CONTEXTS.popitem(last=False)
    return url


def tmdb_logo_url(value, size="original"):
    value = str(value or "").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/%s" % size + value
    return value if value.startswith(("https://", "http://")) else ""


def logo_language(client=None):
    """Resolve locale from TMDb Settings (including Auto) to ISO-639-1."""
    if client is None:
        from .tmdb_client import TMDbClient
        client = TMDbClient()
    return str(getattr(client, "language", "en-US") or "en-US").split("-")[0].split("_")[0].strip().lower() or "en"


_ARAB_COUNTRIES = frozenset(('AE', 'SA', 'EG', 'BH', 'QA', 'OM', 'KW', 'IQ',
                             'JO', 'LB', 'SY', 'PS', 'YE', 'MA', 'DZ', 'TN', 'LY', 'SD'))


def preferred_logo_languages(client=None, details=None, item=None, title='', selected=None):
    """Prefer genuine Arabic clearlogos for Arabic originals, even in English UI.

    Do not change the TMDb metadata language: this concerns title artwork only.
    Always fall back to English, then the language-neutral gallery.
    """
    wanted = str(selected or logo_language(client)).split('-')[0].split('_')[0].lower() or 'en'
    d = details if isinstance(details, dict) else {}
    row = item if isinstance(item, dict) else {}
    original = str(d.get('original_language') or row.get('original_language') or '').split('-')[0].lower()
    countries = d.get('origin_country') or d.get('production_countries') or row.get('origin_country') or []
    if isinstance(countries, str):
        countries = [countries]
    codes = set()
    if isinstance(countries, (tuple, list)):
        for entry in countries:
            if isinstance(entry, dict):
                entry = entry.get('iso_3166_1') or ''
            codes.add(str(entry).upper())
    is_arabic = (original == 'ar' or
                 (not original and bool(codes & _ARAB_COUNTRIES)) or
                 (not original and not codes and
                  bool(re.search('[\u0600-\u06FF]', str(title or '')))))
    if wanted == 'en' and is_arabic:
        return ('ar', 'en')
    return tuple(dict.fromkeys((wanted, 'en')))


def image_languages(client=None, details=None, item=None, title=''):
    """Fetch actual requested/original language logos plus neutral fallbacks."""
    langs = preferred_logo_languages(client, details, item, title)
    return ",".join(dict.fromkeys(langs + ('null',)))


def _valid_logos(entries):
    return [row for row in (entries or []) if isinstance(row, dict) and
            str(row.get("file_path") or "").lower().split("?")[0].endswith(RASTER)]


def has_language_logo(entries, language=None):
    selected = str(language or "en").split("-")[0].lower()
    return any(str(row.get("iso_639_1") or "").lower() == selected
               for row in _valid_logos(entries))


def best_tmdb_logo(entries, language="en"):
    """Pick the best genuine logo by ordered language preference and votes.

    `language` may be a locale string or a tuple of preferred languages.
    Never infer a translation from a neutral image or relabel its language.
    """
    if isinstance(language, (tuple, list)):
        ordered = tuple(str(x or '').split('-')[0].lower() for x in language if x)
    else:
        ordered = (str(language or 'en').split('-')[0].lower(),)
    ordered = tuple(dict.fromkeys(ordered + ('en',)))
    def score(row):
        lang = str(row.get('iso_639_1') or '').lower()
        rank = len(ordered) - ordered.index(lang) + 1 if lang in ordered else (1 if not lang else 0)
        try:
            votes = float(row.get('vote_average') or 0)
        except (ValueError, TypeError):
            votes = 0.0
        try:
            width = int(row.get('width') or 0)
        except (ValueError, TypeError):
            width = 0
        return (rank, votes, width)
    rows = [row for row in _valid_logos(entries)
            if not row.get('iso_639_1') or str(row.get('iso_639_1')).lower() in ordered]
    return max(rows, key=score).get('file_path') if rows else ''


def localized_logo_url(client, media, tmdb_id, images=None, size="w500",
                       details=None, item=None, title=''):
    """Return a verified matching-language logo with English/neutral fallback.

    For Arabic originals use ar -> en even if TMDb interface language is en.
    Execute on a background worker: remote images metadata may be needed.
    """
    media = "tv" if str(media or "").lower() in ("tv", "series") else "movie"
    previous = _valid_logos(((images or {}).get("logos") or []) if isinstance(images, dict) else images)
    info = details if isinstance(details, dict) else {}
    if not info and isinstance(images, dict) and 'original_language' in images:
        info = images
    langs = preferred_logo_languages(client, info, item, title)
    # If callers know only the id and the interface is English, determine
    # the original language before treating an English logo as final.
    try:
        eligible = bool(tmdb_id and int(str(tmdb_id)) > 0 and client.configured())
    except (ValueError, TypeError, AttributeError):
        eligible = False
    if eligible and not info.get('original_language') and not (
            info.get('origin_country') or info.get('production_countries') or
            (isinstance(item, dict) and item.get('original_language'))):
        try:
            metadata = client._get('/%s/%s' % (media, tmdb_id), {'language': 'en-US'}) or {}
            if isinstance(metadata, dict):
                info = metadata
                langs = preferred_logo_languages(client, info, item, title)
        except Exception:
            pass
    if has_language_logo(previous, langs[0]):
        return tmdb_logo_url(best_tmdb_logo(previous, langs), size)
    if eligible:
        try:
            payload = client._get('/%s/%s/images' % (media, tmdb_id), {
                'include_image_language': ','.join(dict.fromkeys(langs + ('null',)))
            }) or {}
            previous.extend(_valid_logos(payload.get('logos') or []))
        except Exception:
            pass
    return tmdb_logo_url(best_tmdb_logo(previous, langs), size)


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None, source=None):
    from .unified_genre_artwork import request as genre_request
    return genre_request(url, KIND, callback=callback, priority=priority,
                         errback=errback, source=source)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
