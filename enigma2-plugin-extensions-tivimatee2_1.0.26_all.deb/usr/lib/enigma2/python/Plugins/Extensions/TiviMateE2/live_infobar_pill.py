# -*- coding: utf-8 -*-
"""Build a true capsule-shaped Live infobar thumbnail outside the GUI thread.

The PIL dependency is deliberately optional. On receivers without it, the
bundled alpha-overlay frame still masks the image corners while ePicLoad
handles decoding. This module does not alter the shared source artwork.
"""
import hashlib
import os

from .storage import data_path

CAPSULE_SIZE = (400, 224)


def prepare_pill_image(source_path):
    source_path = str(source_path or "")
    if not source_path or not os.path.isfile(source_path):
        return source_path
    try:
        from PIL import Image, ImageDraw, ImageFilter, ImageOps
    except Exception:
        return source_path
    try:
        info = os.stat(source_path)
        stamp = "%s|%s|%s|pill2" % (source_path, info.st_size, int(info.st_mtime))
        digest = hashlib.sha256(stamp.encode("utf-8")).hexdigest()[:24]
        target = data_path("live_infobar", "pill_%s.png" % digest)
        if os.path.isfile(target) and os.path.getsize(target) > 1000:
            return target
        resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.LANCZOS)
        with Image.open(source_path) as original:
            original.load()
            original = original.convert("RGB")
            width, height = CAPSULE_SIZE
            if original.width * height >= original.height * width * 0.65:
                # Landscape artwork: edge-to-edge centre crop, never letterbox.
                canvas = ImageOps.fit(original, CAPSULE_SIZE, method=resample, centering=(0.5, 0.5)).convert("RGBA")
            else:
                # Vertical poster fallback: retain the complete poster and
                # fill unused area using a softly blurred copy.
                bg = ImageOps.fit(original, CAPSULE_SIZE, method=resample).filter(ImageFilter.GaussianBlur(18)).convert("RGBA")
                inset = ImageOps.contain(original, (int(width * 0.90), height), method=resample).convert("RGBA")
                bg.alpha_composite(inset, ((width - inset.width) // 2, (height - inset.height) // 2))
                canvas = bg
            supersample = 2
            mask = Image.new("L", (width * supersample, height * supersample), 0)
            painter = ImageDraw.Draw(mask)
            painter.rounded_rectangle((0, 0, width * supersample - 1, height * supersample - 1),
                                      radius=height * supersample // 2, fill=255)
            mask = mask.resize(CAPSULE_SIZE, resample=resample)
            canvas.putalpha(mask)
            tmp = target + ".%d.tmp" % os.getpid()
            canvas.save(tmp, format="PNG", optimize=True)
            os.replace(tmp, target)
        return target
    except Exception:
        return source_path
