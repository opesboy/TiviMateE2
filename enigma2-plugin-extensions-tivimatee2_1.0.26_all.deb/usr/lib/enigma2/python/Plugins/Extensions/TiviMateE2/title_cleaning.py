# -*- coding: utf-8 -*-
"""Remove known IPTV package decorations from display/search labels only.

Never mutate source item dictionaries, playback names or TMDb IDs.
"""
import re
from .display_titles import clean_display_title, visible_title

# Strict prefixes only.  Do not strip legitimate media titles or subtitles.
_SOURCE_PREFIX = re.compile(
    r"^(?:(?:AR|EN|FR|TR)[-_](?:SHAM|MA|[A-Z]{2,8})|SH|AR)\s*[-|:–—]\s*",
    re.IGNORECASE,
)
_COMING_SOON = re.compile(
    r"[\(\[（]\s*قريب(?:اً|ً|ا)?(?:\s*[-–—:]\s*[^)\]）]*)?\s*[\)\]）]",
    re.IGNORECASE,
)
_TRAILING_CODE = re.compile(r"\s*[-–—]\s*(?:SH|AR-SHAM|AR-MA)\s*$", re.IGNORECASE)


def clean_series_label(value):
    """Clean safely-recognized source tags without losing the real title."""
    raw = str(value or "").strip()
    label = raw
    for _ in range(2):
        label = _SOURCE_PREFIX.sub("", label, count=1).strip()
    label = _COMING_SOON.sub(" ", label)
    label = _TRAILING_CODE.sub("", label)
    label = re.sub(r"\s+", " ", label).strip(" -|:–—\t")
    return clean_display_title(label) or raw


def compact_series_label(value, limit=56):
    """Single-line clipped title for the existing skin title slot."""
    return visible_title(clean_series_label(value), limit)


def fit_series_text(value, line_chars=68, lines=5):
    """Word-wrap to bounded visual lines; no marquee or skin geometry changes."""
    raw = re.sub(r"\s+", " ", str(value or "")).strip()
    if not raw:
        return ""
    words = raw.split(" ")
    out, current = [], ""
    for word in words:
        if len(word) > line_chars:
            word = word[:line_chars - 1] + "…"
        proposed = (current + " " + word) if current else word
        if len(proposed) <= line_chars:
            current = proposed
            continue
        out.append(current)
        if len(out) == lines:
            break
        current = word
    else:
        if current:
            out.append(current)
    if len(out) > lines:
        out = out[:lines]
    if len(out) == lines and (len(" ".join(out)) < len(raw)):
        out[-1] = out[-1].rstrip(" .،") + "…"
    return "\n".join(out)
