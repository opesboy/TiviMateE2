# -*- coding: utf-8 -*-
"""TiviMateE2 compatibility facade using the original UltraStalker protocol.

All wire requests, token/profile handling, link decisions, circuit-breaker and
transport cancellation use the vendored UltraStalker client. Existing TiviMate
widgets continue to use the legacy catalogue shape and local cached artwork.
"""
from .ultra_stalker_engine.core.session import PortalSession
from .ultra_stalker_engine.repositories.database import DB as ULTRA_DB
from .storage import get_data_root
import os

# Keep Ultra protocol cache on the same HDD/USB-first storage as TiviMate.
# Never touch the standalone UltraStalker database.
ULTRA_DB.path = os.path.join(get_data_root(), "ultra_stalker_protocol.db")
from .ultra_stalker_engine.core.errors import PluginError
from .ultra_stalker_engine.client import PortalCancelledError


def _assert_not_cancelled(cancel_event):
    if cancel_event is not None and getattr(cancel_event, 'is_set', lambda: False)():
        raise PortalCancelledError('Stalker request cancelled')


def build_ultra_client(LegacyClient):
    class UltraStalkerClient(LegacyClient):
        def _schedule_prefetch(self):
            # The original Ultra engine has its own bounded catalogue workers.
            # Never launch legacy Stalker warm-up jobs in parallel.
            return False

        def __init__(self, source):
            source = dict(source or {})
            super(UltraStalkerClient, self).__init__(source)
            profile = {
                'portal': str(source.get('url') or source.get('portal') or self.configured_portal),
                'mac': self.mac,
                'source_type': 'stalker',
                'device_profile': str(source.get('stb_type') or 'auto').lower(),
                'tls_mode': 'strict',
            }
            if profile['device_profile'] not in ('auto', 'mag250', 'mag254', 'mag256'):
                profile['device_profile'] = 'auto'
            self._ultra_session = PortalSession(profile, timeout=9)
            self._ultra_client = self._ultra_session.client
            self._sync_ultra_state()

        def _sync_ultra_state(self):
            ultra = self._ultra_client
            self.token = str(ultra.token or '')
            self._endpoint = str(ultra.endpoint or '')
            self.play_token = str(ultra.play_token or '')
            self._profile_ready = bool(ultra.profile_initialized)
            self.account_valid = bool(ultra.account_valid)
            if ultra.resolved_device_profile:
                self.stb_type = str(ultra.resolved_device_profile).upper()
            # Do not replace self.portal: legacy asset resolving depends on its path.

        def _ultra_authorize(self, cancel_event=None):
            _assert_not_cancelled(cancel_event)
            ultra = self._ultra_client
            if not ultra.token:
                ultra.authorize(cancel_event=cancel_event)
            _assert_not_cancelled(cancel_event)
            self._sync_ultra_state()
            return bool(ultra.token)

        def handshake(self):
            try:
                return self._ultra_authorize()
            except PluginError:
                return False

        def _ensure_token(self):
            return self._ultra_authorize()

        def _ensure_profile(self):
            self._ultra_authorize()
            self._sync_ultra_state()
            return bool(self._ultra_client.profile_initialized)

        def reauthorize(self):
            self._ultra_client.authorize()
            self._sync_ultra_state()
            return bool(self.token)

        def _drop_token(self):
            # An explicit auth reset affects only this Ultra portal session;
            # network errors must not use this as an automatic recovery step.
            self._ultra_client._reset_auth()
            self._sync_ultra_state()

        def call(self, _cancel_event=None, **query):
            self._ultra_authorize(cancel_event=_cancel_event)
            result = self._ultra_client._get(dict(query), cancel_event=_cancel_event)
            self._sync_ultra_state()
            return result

        def _call_retry(self, _cancel_event=None, **query):
            # UltraStalker's _get manages auth-only retries, request coalescing,
            # circuit backoff and timeout. Do not nest legacy retries around it.
            return self.call(_cancel_event=_cancel_event, **query)

        def _normalise_live(self, item):
            # Unlike the old normalizer, keep UltraStalker's provider-specific
            # Live link policy flags. Otherwise create_link would lose the
            # metadata that chooses temporary/load-balanced URLs correctly.
            row = super(UltraStalkerClient, self)._normalise_live(item)
            if isinstance(item, dict):
                for key in ('use_http_tmp_link', 'use_load_balancing',
                            'disable_ad', 'force_ch_link_check'):
                    if key in item:
                        row[key] = item[key]
            return row

        def live_categories(self):
            return self._ultra_categories('itv')

        def vod_categories(self):
            return self._ultra_categories('vod')

        def series_categories(self):
            return self._ultra_categories('series')

        def _ultra_categories(self, media_type):
            # Keep TiviMate's package row shape, not its old network stack.
            self._ultra_authorize()
            rows = self._ultra_client.genres(media_type)
            result, seen = [], set()
            for row in rows or []:
                if not isinstance(row, dict):
                    continue
                cid = row.get('id') or row.get('category_id') or row.get('genre_id') or row.get('value') or row.get('alias')
                if cid in (None, '') or str(cid) in seen:
                    continue
                cid = str(cid)
                seen.add(cid)
                title = row.get('title') or row.get('name') or row.get('category_name') or row.get('label') or 'Other'
                result.append({
                    'category_id':cid, 'genre_id':cid, 'category_name':title,
                    '_stalker_category_type':row.get('type') or row.get('content_type') or '',
                    '_stalker_is_series':row.get('is_series') or row.get('series') or '',
                })
            return result

        def live_page(self, category_id='', page=1, sortby='number', cancel_event=None, force_network=False):
            # Local TiviMate cache remains first for instant scrolling. Network
            # pages are fetched with UltraStalker's bounded ordered_page().
            if not force_network:
                cached = self.live_page_cached(category_id, page, sortby)
                if cached and cached.get('items'):
                    return cached
            self._ultra_authorize(cancel_event=cancel_event)
            payload = self._ultra_client.ordered_page('itv', category_id or '*', page,
                                                       cancel_event=cancel_event, force=force_network)
            rows = [self._normalise_live(x) for x in payload.get('items', []) if isinstance(x, dict)]
            total = int(payload.get('total') or 0)
            size = max(1, int(payload.get('page_size') or len(rows) or 1))
            return {
                'items': rows, 'page': max(1, int(page)), 'total_items': total,
                'has_more': (int(page) * size < total) if total else len(rows) >= size,
            }

        def stream_url(self, item, kind='live', cancel_event=None):
            _assert_not_cancelled(cancel_event)
            item = dict(item or {})
            media_type = 'itv' if kind == 'live' else 'series' if kind == 'series' else 'vod'
            if media_type == 'series' and item.get('_stalker_link_type') == 'vod':
                media_type = 'vod'
            if not (item.get('cmd') or item.get('command') or item.get('url')):
                # Old channel rows can store just the command in their ID.
                # Match legacy handling without inventing an address.
                raw = item.get('stream_id') or item.get('series_id') or item.get('vod_id') or item.get('id')
                if raw is not None:
                    item['cmd'] = str(raw)
            self._ultra_authorize(cancel_event=cancel_event)
            try:
                link = self._ultra_client.create_link(item, media_type=media_type,
                                                       series_id=item.get('series_id'), cancel_event=cancel_event)
                _assert_not_cancelled(cancel_event)
                return str(link or '')
            finally:
                self._sync_ultra_state()

        def create_vod_link(self, item):
            return self.stream_url(item, 'vod')

        def create_series_link(self, item):
            return self.stream_url(item, 'series')

        def create_catchup_link(self, item, event):
            self._ultra_authorize()
            return self._ultra_client.create_catchup_link(item, event)

        def _short_epg_request(self, ch_id, limit=10, timeout=6.0):
            """Keep TiviMateE2's native short_epg and short_epg_batch intact.

            Only route the actual MAG request through UltraStalker's already
            authenticated transport; TiviMate continues to own its own RAM/HDD
            cache, TTL, row normalization, list prefetch, and Live infobar.
            Bypass Ultra's generic EPG cache to avoid competing cached states.
            """
            channel_id = str(ch_id or '').strip()
            if not channel_id:
                return {}
            self._ultra_authorize()
            # Match the caller's requested guide depth. Windows requests
            # only the current/next events; do not silently fetch ten rows.
            try:
                requested = max(1, min(20, int(limit or 10)))
            except (TypeError, ValueError):
                requested = 10
            result = self._ultra_client._get({
                'type': 'itv', 'action': 'get_short_epg',
                'ch_id': channel_id, 'limit': requested, 'size': requested,
                'JsHttpRequest': '1-xml',
            }, use_cache=False)
            self._sync_ultra_state()
            return result or {}

        def watchdog(self):
            try:
                self.call(type='watchdog', action='get_events', init='0',
                          cur_play_type='1', event_active_id='0', JsHttpRequest='1-xml')
                return True
            except PluginError:
                return False

    UltraStalkerClient.__name__ = 'StalkerClient'
    UltraStalkerClient.__qualname__ = 'StalkerClient'
    return UltraStalkerClient
