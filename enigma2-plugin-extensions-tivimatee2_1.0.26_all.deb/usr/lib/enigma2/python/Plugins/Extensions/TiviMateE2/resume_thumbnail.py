# -*- coding: utf-8 -*-
"""Small circular artwork for Continue Watching's selected hero.

Only transforms an ALREADY downloaded backdrop; no HTTP or TMDb requests.
Optional Pillow support: callers keep the bundled circular play fallback if
Pillow is unavailable on a receiver.  Always executed off the GUI thread.
"""
import hashlib
import os
import threading

from .cache_manager import get_cache_dir, is_internal_cache_active

_LOCK = threading.RLock()


def cached_resume_circle(backdrop_file, image_url):
    if not backdrop_file or not os.path.isfile(backdrop_file):
        return None
    try:
        stat = os.stat(backdrop_file)
        if stat.st_size < 100:
            return None
        # Cache ID survives LRU mtime touches yet changes if the image size changes.
        identity = (str(image_url or backdrop_file) + "|" + str(stat.st_size)).encode("utf-8")
        key = hashlib.sha1(identity).hexdigest()
        root = os.path.join(get_cache_dir("resume_preview"), "circles")
        if not os.path.isdir(root):
            os.makedirs(root)
        target = os.path.join(root, key + ".png")
        if os.path.isfile(target) and os.path.getsize(target) > 128:
            return target
    except (OSError, ValueError, TypeError):
        return None
    # Pillow is optional on OpenATV/Pure2; don't make it a required package.
    try:
        from PIL import Image, ImageDraw, ImageOps
    except ImportError:
        return None
    temp = "%s.%d.part" % (target, threading.get_ident())
    try:
        with Image.open(backdrop_file) as source:
            if hasattr(source, "draft"):
                source.draft("RGB", (450, 450))
            rgb = source.convert("RGB")
            filt = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.BICUBIC)
            # High-resolution circle mask gives smooth edges without a square tile.
            canvas = ImageOps.fit(rgb, (292, 292), method=filt, centering=(0.55, 0.42))
            mask = Image.new("L", (292, 292), 0)
            ImageDraw.Draw(mask).ellipse((4, 4, 287, 287), fill=255)
            canvas.putalpha(mask)
            out = canvas.resize((146, 146), resample=filt)
            out.save(temp, "PNG", optimize=True)
        with _LOCK:
            if not os.path.isfile(target):
                os.replace(temp, target)
            # On receivers with internal flash, retain only the newest 24 tiny thumbnails.
            if is_internal_cache_active():
                try:
                    images = sorted((os.path.join(root, n) for n in os.listdir(root)
                                     if n.endswith('.png')),
                                    key=lambda f: os.path.getmtime(f), reverse=True)
                    for old in images[24:]:
                        try:
                            os.remove(old)
                        except OSError:
                            pass
                except OSError:
                    pass
        return target
    except Exception:
        return None
    finally:
        try:
            if os.path.isfile(temp):
                os.remove(temp)
        except OSError:
            pass
