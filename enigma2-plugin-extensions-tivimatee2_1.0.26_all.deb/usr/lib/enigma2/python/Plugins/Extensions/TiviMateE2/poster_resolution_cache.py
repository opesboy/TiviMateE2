# -*- coding: utf-8 -*-
"""Share ALREADY-DECODED VOD/series posters across independent Enigma screens.

A successful large-page poster decode records just its canonical image URL; no
image duplication, network calls, background TMDb searches or server lookups.
GENRE and the eight-card rail may reuse the url only if the original poster is
still present in the *existing* image cache. A server/account scope prevents
cross-portal artwork leaks and a bounded disk index survives page/app restarts.
"""
from __future__ import absolute_import

import hashlib
import json
import os
import re
import threading
import time
import unicodedata
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor

_LOCK = threading.RLock()
_CACHE = {}
_LOADED = set()
_DIRTY = set()
_PENDING = set()
_MAX_PER_SOURCE = 256
_MAX_SOURCES = 12
_SAVER = ThreadPoolExecutor(max_workers=1, thread_name_prefix="TiviPosterIndex")


def _scope(source, kind):
    source = source if isinstance(source, dict) else {}
    raw = "|".join(str(x or "") for x in (
        source.get("type"), source.get("url") or source.get("base_url") or
        source.get("portal") or source.get("host"),
        source.get("username") or source.get("user"), source.get("password"),
        source.get("mac") or source.get("mac_address"), kind))
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()[:32]


def _ids(item):
    if not isinstance(item, dict):
        return []
    result = []
    for key in ("series_id", "stream_id", "vod_id", "id"):
        value = str(item.get(key) or "").strip()
        if value and len(value) <= 120 and value.lower() not in ("none", "0"):
            token = "id:" + value
            if token not in result:
                result.append(token)
    titles = []
    for key in ("name", "title", "original_title", "original_name"):
        value = str(item.get(key) or "").strip()
        if not value:
            continue
        value = unicodedata.normalize("NFKC", value).casefold()
        value = re.sub(r"\s+", " ", value).strip()
        if value and value not in titles and len(value) < 250:
            titles.append(value)
    release = " ".join(str(item.get(key) or "") for key in
                       ("year", "releasedate", "releaseDate", "release_date", "first_air_date"))
    match = re.search(r"(?<!\d)((?:19|20)\d{2})(?!\d)", release)
    year = match.group(1) if match else ""
    for title in titles:
        # Match remakes by their release year when known. When absent, rely on
        # the server's own stream/series id first to avoid mismatched posters.
        result.append("title:" + title + (":" + year if year else ""))
    return result


def _index_path(scope):
    from .cache_manager import get_cache_dir
    return os.path.join(get_cache_dir("metadata"), "resolved_series_posters_%s.json" % scope)


def _load(scope):
    with _LOCK:
        if scope in _LOADED:
            return
        _LOADED.add(scope)
        if len(_CACHE) >= _MAX_SOURCES:
            for key in list(_CACHE)[:max(1, len(_CACHE) - _MAX_SOURCES + 1)]:
                if key not in _DIRTY and key not in _PENDING:
                    _CACHE.pop(key, None)
                    _LOADED.discard(key)
        try:
            with open(_index_path(scope), "r", encoding="utf-8") as stream:
                data = json.load(stream)
            rows = data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            rows = {}
        current = _CACHE.setdefault(scope, OrderedDict())
        # Memory entries may have been inserted while a delayed worker writes.
        for key, value in rows.items():
            if key not in current and isinstance(value, str) and value.startswith(("https://", "http://")):
                current[key] = value
        while len(current) > _MAX_PER_SOURCE:
            current.popitem(last=False)


def _flush(scope):
    # Runs only on the ONE low-priority index worker, never the ePicLoad GUI.
    time.sleep(0.4)  # Coalesce 5/8/24 poster decodes in one small disk update.
    with _LOCK:
        data = dict(_CACHE.get(scope) or {})
        dirty = scope in _DIRTY
        _DIRTY.discard(scope)
        _PENDING.discard(scope)
    if not dirty:
        return
    try:
        path = _index_path(scope)
        temp = "%s.%d.part" % (path, threading.get_ident())
        try:
            with open(temp, "w", encoding="utf-8") as stream:
                json.dump(data, stream, ensure_ascii=False, separators=(",", ":"))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, path)
        finally:
            if os.path.exists(temp):
                os.unlink(temp)
    except (OSError, TypeError, ValueError):
        pass
    with _LOCK:
        # New posters can arrive during disk I/O. Flush one extra batch.
        if scope in _DIRTY and scope not in _PENDING:
            _PENDING.add(scope)
            try:
                _SAVER.submit(_flush, scope)
            except RuntimeError:
                _PENDING.discard(scope)


def remember_decoded(source, kind, item, url):
    """Record a *displayed* valid poster URL; this never fetches any image."""
    if kind not in ("vod", "series") or not isinstance(item, dict):
        return
    url = str(url or "").strip().replace("\\/", "/")
    if not url.startswith(("https://", "http://")):
        return
    keys = _ids(item)
    if not keys:
        return
    scope = _scope(source, kind)
    _load(scope)
    with _LOCK:
        rows = _CACHE.setdefault(scope, OrderedDict())
        changed = False
        for key in keys:
            if rows.get(key) != url:
                rows[key] = url
                changed = True
            rows.move_to_end(key)
        while len(rows) > _MAX_PER_SOURCE:
            rows.popitem(last=False)
        if changed:
            _DIRTY.add(scope)
            if scope not in _PENDING:
                _PENDING.add(scope)
                try:
                    _SAVER.submit(_flush, scope)
                except RuntimeError:
                    _PENDING.discard(scope)


def cached_decoded_url(source, kind, item):
    """No network. Only a known image which remains in the poster cache wins."""
    if kind not in ("vod", "series"):
        return ""
    keys = _ids(item)
    if not keys:
        return ""
    scope = _scope(source, kind)
    _load(scope)
    with _LOCK:
        rows = _CACHE.get(scope) or {}
        urls = [rows[key] for key in keys if key in rows]
    if not urls:
        return ""
    try:
        from .artwork_queue import cached_artwork
        from .poster_manager import usable_poster_file
    except ImportError:
        return ""
    for url in dict.fromkeys(urls):
        try:
            path = cached_artwork(url, "posters")
            if path and usable_poster_file(path):
                return url
        except Exception:
            continue
    return ""
