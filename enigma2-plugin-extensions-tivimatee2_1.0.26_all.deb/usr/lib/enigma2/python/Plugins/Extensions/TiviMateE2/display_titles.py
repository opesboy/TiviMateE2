# -*- coding: utf-8 -*-
"""Single offline, display-only title cleaner for movie/series widgets.

Never change a provider row, ID, TMDb lookup key, subtitle query or playback URL.
One shared function serves all poster, backdrop and heading call sites.
"""
import re
import unicodedata

# Match longest composite tokens first. Delimiters are required before a prefix
# is removed, so real titles like 'New York' or 'The HD Story' stay intact.
_TAG = (
    r"(?:AR[\s._-]*SUBS?|EN[\s._-]*SUBS?|"
    r"ARABIC|ENGLISH|ENG|ARA|AR|EN|FR|TR|SUBTITLED|SUBS?|"
    r"DUB(?:BED)?|MULTI|مترجم|مدبلج|ترجمة|"
    r"NETFLIX|NF|AMAZON|AMZN?|PRIME(?:[\s._-]*VIDEO)?|"
    r"DISNEY\+?|DSNP|APPLE(?:[\s._-]*TV)?\+?|HBO|HULU|MAX|"
    r"PARAMOUNT\+?|OSN|SHAHID|شاهد|SHAM|SH|"
    r"2160P|1080P|720P|480P|4K|8K|UHD|FHD|FULL[\s._-]*HD|HD|SD|"
    r"WEB[\s._-]*DL|WEBRIP|HDRIP|BDRIP|BRRIP|BLU[\s._-]*RAY|"
    r"BLURAY|REMUX|HEVC|X26[45]|H[\s.]*26[45]|"
    r"HDR10?\+?|HDR|DOLBY(?:[\s._-]*VISION)?|DV|"
    r"AAC|AC3|EAC3|DDP?5[._ ]?1|ATMOS|"
    r"TOP|RECENT|NEW|VIP|VOD)"
)
# Country/language codes seen in IPTV filenames: only consume when delimited as
# prefix/suffix metadata. Never strip a standalone word from the middle.
_COUNTRY = r"(?:US|USA|UK|GB|IN|DO|BR|CA|AU|AE|SA|EG|FR|DE|ES|IT|JP|KR|TR|RU|CN|MX|MA|DZ|TN|PK|IR|ID|TH|PH|NG|ZA|SE|NO|DK|NL|BE)"
_LEADING_TAG = re.compile(r"^(?:" + _TAG + r"|" + _COUNTRY + r")(?![\w])", re.I | re.U)
_SEPARATOR = re.compile(r"^\s*(?:[-|:/+_–—]+\s*|\s+)", re.U)
_TAG_ONLY = re.compile(r"^(?:" + _TAG + r"|" + _COUNTRY + r")(?:[\s,|+._/\-]+(?:" + _TAG + r"|" + _COUNTRY + r"))*$", re.I | re.U)
_BRACKET = re.compile(r"[\[({（]\s*([^\[\]{}()（）]{1,54})\s*[\])}）]", re.U)
_TRAILING_COUNTRY = re.compile(r"\s*\(\s*(?:" + _COUNTRY + r")\s*\)\s*$", re.I | re.U)
# Optional tech junk at the end after real title: never match ordinary subtitles.
_TRAILING_TECH = re.compile(r"\s*[-|:/]\s*(?:" + _TAG + r")(?:\s*[-|:/]\s*(?:" + _TAG + r"))*\s*$", re.I | re.U)
_DOTTED_TECH = re.compile(r"(?:[._](?:" + _TAG + r"))+(?![\w])\s*$", re.I | re.U)


def clean_display_title(value):
    """Strip known IPTV decorations; do not guess the movie's actual name."""
    original = " ".join(str(value or "").split())
    if not original:
        return ""
    text = unicodedata.normalize("NFC", original)
    text = re.sub(r"[\u200b\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff]", "", text)
    text = " ".join(text.split())

    # Leading wrappers such as [4K NF] [AR-SUBS], (EN) (NF).
    for _ in range(8):
        m = re.match(r"^\s*[\[({（]\s*([^\[\]{}()（）]{1,54})\s*[\])}）]\s*[-|:/_ ]*", text)
        if not m or not _TAG_ONLY.fullmatch(m.group(1).strip()):
            break
        remainder = text[m.end():].strip()
        if not remainder:
            break
        text = remainder

    # Compound prefixes: '4K-AR-DO - 6 Days', 'AR-SUBS - Locke',
    # 'NEW 4K NF - Film'. Space-only separators are allowed strictly when
    # another known tag follows (never delete 'New York').
    for _ in range(12):
        tag = _LEADING_TAG.match(text)
        if not tag:
            break
        tail = text[tag.end():]
        separator = _SEPARATOR.match(tail)
        if not separator:
            break
        remaining = tail[separator.end():].lstrip()
        if not remaining:
            break
        # 'NEW YORK' should not become 'YORK', unless YORK were another tag.
        only_space = not re.search(r"[-|:/+_–—]", separator.group(0))
        if only_space and not _LEADING_TAG.match(remaining):
            break
        text = remaining

    # Only remove bracket metadata that is entirely tags. A real subtitle in
    # parentheses (The Final Chapter) and a release year (2025) are retained.
    def remove_tag_bracket(match):
        return " " if _TAG_ONLY.fullmatch(match.group(1).strip()) else match.group(0)

    text = _BRACKET.sub(remove_tag_bracket, text)
    for _ in range(3):
        suffix = _TRAILING_TECH.search(text)
        if not suffix:
            break
        candidate = text[:suffix.start()].strip()
        if not candidate:
            break
        text = candidate
    # Dotted/underscored release strings, e.g. 'Film.1080p.WEB-DL'.
    text = _DOTTED_TECH.sub("", text).strip()
    # Country code suffixes are administrative tags, not the film name.
    text = _TRAILING_COUNTRY.sub("", text).strip()
    text = re.sub(r"\s{2,}", " ", text).strip(" \t-|/:_–—")
    return text if any(ch.isalnum() for ch in text) else original


def visible_title(value, max_chars=0):
    """Clean once, then crop at the word boundary when the card is too narrow."""
    text = clean_display_title(value)
    try:
        limit = int(max_chars or 0)
    except (TypeError, ValueError):
        limit = 0
    if limit <= 0 or len(text) <= limit:
        return text
    part = text[:limit].rstrip()
    cut = part.rfind(" ")
    if cut >= max(4, limit // 2):
        part = part[:cut]
    return part.rstrip(" -_|:/,.؛،") + "…"
