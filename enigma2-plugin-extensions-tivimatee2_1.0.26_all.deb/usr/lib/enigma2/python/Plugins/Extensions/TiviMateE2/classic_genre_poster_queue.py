# -*- coding: utf-8 -*-
"""Visible Classic poster scheduler using GENRE's shared image resolver.

The screen owns at most six entries.  On a busy shared resolver queue, only
still-visible entries are retried by one Enigma2 GUI timer (like GENRE's
poster retry timer).  Old page/source/closed-screen callbacks never paint.
"""

from .shared_genre_posters import request_genre_poster


class ClassicGenrePosterQueue(object):
    RETRY_DELAY_MS = 950

    def __init__(self, screen, timer=None):
        self.screen = screen
        self.jobs = {}
        self.closed = False
        if timer is None:
            from enigma import eTimer
            timer = eTimer()
        self.timer = timer
        try:
            self.timer.timeout.connect(self._retry_busy)
        except (AttributeError, TypeError):
            self.timer.callback.append(self._retry_busy)

    def begin_page(self):
        """Invalidate only the six Classic card slots; preserve other artwork."""
        self.jobs.clear()
        try:
            self.timer.stop()
        except Exception:
            pass
        requests = getattr(self.screen, '_artwork_requests', {})
        for slot in range(6):
            requests.pop((slot, 'poster%d' % slot), None)

    def close(self):
        self.closed = True
        self.begin_page()

    def request(self, slot, primary, item, width, height):
        screen = self.screen
        if self.closed or slot < 0 or slot >= 6:
            return
        source = dict(getattr(screen, 'source', None) or {})
        generation = getattr(screen, '_sourceGeneration', 0)
        kind = screen._homePosterKind(item)
        snapshot = dict(item or {})
        widget = 'poster%d' % slot
        key = (slot, widget)
        # The same visible card should not spawn overlapping requests.
        identity = (generation, str(source), kind,
                    str(snapshot.get('stream_id') or snapshot.get('series_id') or
                        snapshot.get('tmdb_id') or snapshot.get('name') or ''),
                    str(primary or ''), int(width), int(height))
        existing = self.jobs.get(slot)
        if existing and existing['identity'] == identity:
            return
        ticket = object()
        if not hasattr(screen, '_artwork_requests'):
            screen._artwork_requests = {}
        screen._artwork_requests[key] = ticket
        job = dict(ticket=ticket, identity=identity, key=key, slot=slot,
                   widget=widget, primary=primary, item=snapshot, kind=kind,
                   source=source, generation=generation, width=width,
                   height=height, attempts=0, state='waiting')
        self.jobs[slot] = job
        self._start(job)

    def _stale(self, job):
        screen = self.screen
        return (self.closed or getattr(screen, '_homeClosed', True) or
                self.jobs.get(job['slot']) is not job or
                getattr(screen, '_artwork_requests', {}).get(job['key']) is not job['ticket'] or
                not screen._sourceJobValid(job['generation'], job['source']))

    def _start(self, job):
        if self._stale(job):
            return
        job['attempts'] += 1
        job['state'] = 'running'

        def resolved(path, winner):
            if self._stale(job):
                return
            job['state'] = 'ready'

            def decoded():
                if self._stale(job):
                    return
                try:
                    from .poster_resolution_cache import remember_decoded
                    remember_decoded(job['source'], job['kind'], job['item'], winner)
                except Exception:
                    pass

            self.screen.decodeImage(job['slot'], path, job['widget'],
                                    job['width'], job['height'],
                                    expected_token=job['ticket'], on_decoded=decoded)

        def failed():
            if not self._stale(job):
                # GENRE resolver has exhausted provider images, details and TMDb.
                # Do not repeatedly query a genuinely missing poster.
                job['state'] = 'missing'

        try:
            accepted = request_genre_poster(job['source'], job['item'], job['kind'],
                                            resolved, failed=failed,
                                            cancelled=lambda: self._stale(job),
                                            primary=job['primary'])
        except Exception:
            accepted = False
        if not accepted and not self._stale(job):
            # The shared GENRE pool is busy. Retry later without spawning a
            # new worker or falling back to the old, independent poster queue.
            job['state'] = 'waiting'
            self._arm_retry()

    def _arm_retry(self):
        if not self.closed and any(j['state'] == 'waiting' for j in self.jobs.values()):
            try:
                self.timer.start(self.RETRY_DELAY_MS, True)
            except Exception:
                pass

    def _retry_busy(self):
        if self.closed:
            return
        # Stable slot order matches GENRE's visible first-card behavior.
        for slot in sorted(self.jobs):
            job = self.jobs[slot]
            if job['state'] == 'waiting' and not self._stale(job):
                self._start(job)
