# -*- coding: utf-8 -*-
"""Privacy-safe mapping of playlist replies to local server status.

This module receives only an already-fetched reply.  It never stores, logs, or
renders credentials, endpoints, device IDs, or subscriber information.
"""


def _integer_or_none(value):
    try:
        text = str(value).strip()
        if not text:
            return None
        return int(text)
    except Exception:
        return None


def _xtream_usage(reply):
    """Return provider-reported active/max connections when available."""
    if not isinstance(reply, dict):
        return None, None
    info = reply.get("user_info")
    if not isinstance(info, dict):
        return None, None
    active = _integer_or_none(info.get("active_cons"))
    maximum = _integer_or_none(info.get("max_connections"))
    return active, maximum


def _reply_is_reachable(source_type, reply):
    if isinstance(reply, dict) and "ok" in reply:
        return bool(reply.get("ok"))
    if source_type == "xtream" and isinstance(reply, dict):
        return bool(reply.get("user_info") or reply.get("server_info") or reply.get("available_channels") is not None)
    return bool(reply)


def evaluate_reply(source_type, reply):
    """Map a successful provider reply to online/busy/offline.

    `active_cons` alone does not mean BUSY: it normally includes the user's
    own active session.  BUSY requires an explicit provider connection-limit
    error; other responses represent connectivity only.
    """
    reachable = _reply_is_reachable(source_type, reply)
    active = None
    maximum = None
    if source_type == "xtream":
        active, maximum = _xtream_usage(reply)

    error_text = ""
    if isinstance(reply, dict):
        error_text = str(reply.get("error") or reply.get("message") or "").lower()
    explicit_limit = (source_type == "xtream" and
                      ("max_connections reached" in error_text or
                       "connection limit reached" in error_text or
                       "too many connections" in error_text))
    if explicit_limit:
        state = "busy"
    elif not reachable:
        state = "offline"
    else:
        state = "online"

    return {
        "state": state,
        "active_connections": active,
        "max_connections": maximum,
        "usage_reported": active is not None,
    }
