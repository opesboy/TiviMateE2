# -*- coding: utf-8 -*-
"""Dreambox DM900/DM920 400x240 front LCD artwork (cached images only).

Uses Enigma2's *summary screen* on the front-panel desktop, not /dev/lcd0,
not an LCD4Linux file, and never steals the system InfoBar display.  Each
TiviMate2 summary is disposed by Enigma2 as soon as its page/player closes.
Nothing is downloaded here: all HTTP artwork stays with its original queue.
"""
from __future__ import absolute_import

import os

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePicLoad, eTimer


_IMAGES = ('.png', '.jpg', '.jpeg', '.webp', '.bmp')


def dream_lcd_available():
    """Use only the known 400x240 colour Dreambox displays, never Vu+/ATV."""
    machine = ''
    for file_name in ('/proc/stb/info/model', '/proc/stb/info/boxtype',
                      '/proc/stb/info/hwmodel'):
        try:
            with open(file_name, 'r') as stream:
                machine = stream.read(60).strip().lower()
            if machine:
                break
        except (IOError, OSError):
            pass
    if not machine:
        try:
            from Components.SystemInfo import BoxInfo
            machine = str(BoxInfo.getItem('model') or BoxInfo.getItem('machinebuild') or '').lower()
        except Exception:
            pass
    return machine in ('dm900', 'dm920', 'dreambox900', 'dreambox920',
                       'dm900uhd', 'dm920uhd')


def _local_image(path):
    try:
        path = str(path or '').strip()
        return (path if path.startswith('/') and
                path.lower().endswith(_IMAGES) and os.path.isfile(path) and
                os.path.getsize(path) > 128 else '')
    except (IOError, OSError, ValueError):
        return ''


def _cache_only_image(item, category, source=None):
    if not isinstance(item, dict):
        return ''
    if category == 'picons':
        try:
            from .estalker_picon import resolve_picon_url, cached_picon_path
            url = resolve_picon_url(item, source)
            if url:
                for size in ((240, 100), (280, 168), (220, 130)):
                    file_name = _local_image(cached_picon_path(url, size))
                    if file_name:
                        return file_name
        except Exception:
            pass
        for field in ('_picon_path', 'picon_path', 'cached_picon'):
            file_name = _local_image(item.get(field))
            if file_name:
                return file_name
        # Also support DreamOS's ordinary service-reference picon folders.
        # This is a read-only local fallback if TiviMate's picon cache is not
        # present in an older DreamOS branch.  Never trigger a download.
        ref = item.get('service_ref') or item.get('serviceref') or item.get('ref') or ''
        try:
            ref = ref.toString() if hasattr(ref, 'toString') else str(ref)
            ref = '_'.join(ref.split(':')[:10]).rstrip('_')
            if ref:
                for directory in ('/usr/share/enigma2/picon', '/media/hdd/picon',
                                  '/media/usb/picon', '/picon'):
                    hit = _local_image(os.path.join(directory, ref + '.png'))
                    if hit:
                        return hit
        except Exception:
            pass
        return ''

    for field in ('_player_cover_cache', '_player_cover_cache_fallback',
                  '_front_panel_poster_file', '_cached_poster',
                  '_resolved_poster_cache', 'local_poster'):
        file_name = _local_image(item.get(field))
        if file_name:
            return file_name

    urls = []
    for field in ('_resolved_server_poster', '_genre_poster_url',
                  '_player_cover', 'cover', 'poster', 'movie_image',
                  'poster_image', 'stream_icon', 'image_url', '_tmdb_poster',
                  'poster_path', 'thumbnail', 'series_poster'):
        raw = str(item.get(field) or '').strip().replace('\\/', '/')
        if raw and raw not in urls:
            if raw.startswith('/') and not os.path.isfile(raw) and len(raw) < 150:
                # TMDb stores relative paths like /abc123.jpg.
                urls.append('https://image.tmdb.org/t/p/w500' + raw)
            else:
                urls.append(raw)
    try:
        from .poster_manager import provider_poster_url
        if source:
            server = provider_poster_url(source, item)
            if server and server not in urls:
                urls.insert(0, server)
    except Exception:
        pass
    try:
        from .artwork_queue import cached_artwork
        for url in urls:
            hit = _local_image(url)
            if not hit and url.startswith(('http://', 'https://')):
                hit = _local_image(cached_artwork(url, 'posters'))
            if hit:
                return hit
    except Exception:
        pass
    return ''


def _selected(screen):
    """Return active kind, selected catalogue row and provider without I/O."""
    if screen is None:
        return ('', {}, {})
    source = getattr(screen, 'source', {}) or {}
    if not isinstance(source, dict):
        source = {}
    kind = str(getattr(screen, 'kind', '') or '').lower()
    cls = screen.__class__.__name__
    if cls == 'TiviMateLivePlayer':
        try:
            return 'picons', screen._current(), source
        except Exception:
            return 'picons', {}, source
    if cls == 'LiveWindowsScreen':
        if getattr(screen, '_packagesOpen', False):
            return 'picons', {}, source
        rows = getattr(screen, 'grid_items', ()) or ()
        idx = getattr(screen, 'focusIndex', 0)
        parent = getattr(screen, 'parentLive', None)
        return 'picons', (rows[idx] if 0 <= idx < len(rows) else {}), (getattr(parent, 'source', {}) or {})
    if kind == 'live':
        try:
            return 'picons', screen.current() or {}, source
        except Exception:
            return 'picons', {}, source
    if cls == 'TiviMatePlayer':
        return 'posters', (getattr(screen, 'item', None) or {}), source
    if cls == 'SeriesDetailsScreen':
        return 'posters', (getattr(screen, 'seriesItem', None) or {}), source
    if cls == 'MovieDetailsScreen':
        return 'posters', (getattr(screen, 'item', None) or {}), source
    if hasattr(screen, 'genre_items'):
        rows = getattr(screen, 'genre_items', ()) or ()
        idx = getattr(screen, 'index', 0)
        return 'posters', (rows[idx] if 0 <= idx < len(rows) else {}), source
    if callable(getattr(screen, 'current', None)):
        try:
            row = screen.current()
            if isinstance(row, dict):
                return 'posters', row, source
        except Exception:
            pass
    return '', {}, source


def _title(item):
    for field in ('name', 'title', 'stream_name', 'series_name', 'channel_name'):
        if item.get(field):
            return str(item[field]).strip()[:52]
    return ''


class TiviMateDreamFrontPanelSummary(Screen):
    """Show selected local picon or movie/series poster on Dream's front LCD."""
    # DreamOS DM900/DM920 use display-id 3 for their 400x240 front LCD.
    skin = '''<screen name="TiviMateDreamFrontPanelSummary" id="3" position="0,0" size="400,240" flags="wfNoBorder" backgroundColor="#000000">
        <eLabel position="0,0" size="400,240" backgroundColor="#000000" zPosition="0"/>
        <widget name="image" position="0,0" size="400,204" alphatest="blend" scale="1" zPosition="1"/>
        <widget name="caption" position="6,206" size="388,32" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#000000" transparent="0" halign="center" valign="center" noWrap="1" zPosition="2"/>
    </screen>'''

    def __init__(self, session, parent):
        Screen.__init__(self, session, parent=parent)
        self.parent_screen = parent
        self['image'] = Pixmap()
        self['caption'] = Label('')
        self._last_value = None
        self._decoder = None
        self._decoder_token = 0
        self._closed = False
        self._timer = eTimer()
        self._timer_connection = None
        try:
            # Keep OE2.5/Enigma2 eConnection alive until the summary closes.
            self._timer_connection = self._timer.timeout.connect(self._refresh)
        except Exception:
            self._timer.callback.append(self._refresh)
        self.onLayoutFinish.append(self._start)
        self.onShow.append(self._start)
        self.onHide.append(self._stop)
        self.onClose.append(self._close)

    def _start(self):
        if self._closed:
            return
        self._refresh()
        try:
            self._timer.start(900, False)
        except Exception:
            pass

    def _stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass

    def _close(self):
        self._closed = True
        self._stop()
        self._decoder_token += 1
        self._decoder = None
        self.parent_screen = None

    def _refresh(self):
        if self._closed:
            return
        try:
            category, item, source = _selected(self.parent_screen)
            label = _title(item) if isinstance(item, dict) else ''
            file_name = _cache_only_image(item, category, source) if category else ''
            key = (category, label, file_name)
            if key == self._last_value:
                return
            self._last_value = key
            self['caption'].setText(label)
            self._decoder_token += 1
            token = self._decoder_token
            if not file_name:
                self['image'].hide()
                return
            decoder = ePicLoad()
            self._decoder = decoder

            def ready(_=None):
                if self._closed or token != self._decoder_token or decoder is not self._decoder:
                    return
                try:
                    ptr = decoder.getData()
                    if ptr is not None and self['image'].instance:
                        self['image'].instance.setPixmap(ptr)
                        self['image'].show()
                except Exception:
                    pass

            try:
                decoder.PictureData.get().append(ready)
                decoder.setPara((400, 204, 1, 1, False, 1, '#00000000'))
                decoder.startDecode(file_name)
            except Exception:
                self['image'].hide()
        except Exception:
            # Unsupported DreamOS skins should fall back silently, never crash TV.
            pass


def install_frontpanel(ui_module):
    """Patch only TiviMateE2 screen classes; do not modify DreamOS global skin."""
    if not dream_lcd_available():
        return False
    classes = [
        'TiviMateE2Home', 'MediaScreen', 'LiveWindowsScreen',
        'MovieDetailsScreen', 'SeriesDetailsScreen', 'ContentHomeScreen',
        'FastMoviesContentScreen', 'FastSeriesContentScreen',
        'StandaloneGenreScreen', 'MovieGenresScreen', 'FavoritesScreen',
        'FavoritesLibraryScreen',
    ]
    def create_summary(self):
        return TiviMateDreamFrontPanelSummary

    for name in classes:
        cls = getattr(ui_module, name, None)
        if isinstance(cls, type) and issubclass(cls, Screen):
            cls.createSummary = create_summary
    try:
        from .cinematic_catalog import CinematicCatalogScreen
        CinematicCatalogScreen.createSummary = create_summary
    except Exception:
        pass
    try:
        from .tivimate_player import TiviMatePlayer
        TiviMatePlayer.createSummary = create_summary
    except Exception:
        pass
    try:
        from .live_player import TiviMateLivePlayer
        TiviMateLivePlayer.createSummary = create_summary
    except Exception:
        pass
    return True
