# -*- coding: utf-8 -*-
"""UltraStalker-owned external player cleanup adapted for Live navigation.

Source: UltraStalker/services/player_runtime.py and force_session_silence
from UltraStalker/services/player_core.py. TiviMateE2 differs in one critical
respect: Back returns to a live preview. Never stop Navigation here; callers
invoke cleanup only after switching/stopping the exact owned stream.
"""
from __future__ import absolute_import
import os
import signal
from .ultra_player_runtime import (
    _all_external_player_pids, _matching_external_player_pids, _descendant_pids,
    _proc_cmdline,
)

class UltraLiveDecoderGuard(object):
    def __init__(self):
        # Same baseline-versus-owned-process policy as Ultra player_golden57.
        self.baseline = set(_all_external_player_pids())
        self.owned = {}

    def _exact_stream_pids(self, url):
        # Ultra's host + basename fallback can match multiple channels on the
        # same provider (e.g. /123/index.m3u8 and /456/index.m3u8). Live zap
        # must NEVER kill a new channel merely because the URL tail matches.
        return set(pid for pid in _matching_external_player_pids(url)
                   if url in _proc_cmdline(pid))

    def capture(self, url):
        url = str(url or '').strip()
        if not url:
            return
        try:
            matches = self._exact_stream_pids(url) - self.baseline
            if matches:
                self.owned.setdefault(url, set()).update(matches)
        except Exception:
            pass

    def retire(self, url, force=False):
        """Stop only this retired stream's newly-owned external processes.

        Unlike Ultra force_session_silence(stop_native=True), the caller owns
        the Navigation lifecycle: normal Back must keep Live preview playing.
        Never terminate a PID that existed before opening this Live player.
        """
        url = str(url or '').strip()
        if not url:
            return
        owned = self.owned.pop(url, set())
        try:
            matched = self._exact_stream_pids(url) - self.baseline
            targets = (matched | owned | _descendant_pids(owned)) - self.baseline
        except Exception:
            targets = set(owned) - self.baseline
        sig = signal.SIGKILL if force else signal.SIGTERM
        for pid in targets:
            try:
                if int(pid) > 1 and int(pid) != os.getpid():
                    os.kill(int(pid), sig)
            except OSError:
                pass
            except Exception:
                pass
