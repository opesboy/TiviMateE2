# -*- coding: utf-8 -*-
"""Verified Live Recent Added snapshot, scoped to provider credentials.

A transient Live playlist/portal outage must never erase the last known list.
This cache is metadata on persistent storage, independent of poster caches.
"""
from __future__ import absolute_import
import hashlib
import json
import os
import threading
import time
from .storage import data_path
from .compat import ensure_dir, atomic_replace, open_text

_FILE = data_path("recent_live_view_cache.json")
_LOCK = threading.RLock()
_FRESH_SECONDS = 180


def _key(source):
    source = source or {}
    parts = [str(source.get(key) or "") for key in (
        "type", "url", "base_url", "host", "username", "user",
        "mac", "password", "path", "playlist_url", "m3u_url",
    )]
    return hashlib.sha256("\0".join(parts).encode("utf-8", "ignore")).hexdigest()


def _read_all():
    try:
        with open_text(_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def get_recent_live_snapshot(source):
    """Return (nonempty saved rows, fresh) with no provider calls."""
    try:
        with _LOCK:
            entry = _read_all().get(_key(source)) or {}
        rows = [dict(item) for item in (entry.get("items") or []) if isinstance(item, dict)]
        age = max(0, time.time() - float(entry.get("time") or 0))
        return rows[:50], bool(rows and age <= _FRESH_SECONDS)
    except Exception:
        return [], False


def save_recent_live_snapshot(source, items):
    """Only successful nonempty snapshots may overwrite existing content."""
    rows = [dict(item) for item in (items or []) if isinstance(item, dict)][:50]
    if not rows:
        return False
    with _LOCK:
        try:
            data = _read_all()
            data[_key(source)] = {"time": int(time.time()), "items": rows}
            if len(data) > 32:
                stale = sorted(data, key=lambda key: float((data.get(key) or {}).get("time") or 0))
                for key in stale[:-32]:
                    data.pop(key, None)
            ensure_dir(os.path.dirname(_FILE))
            temp = _FILE + ".tmp"
            with open_text(temp, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
            atomic_replace(temp, _FILE)
            return True
        except Exception:
            return False
