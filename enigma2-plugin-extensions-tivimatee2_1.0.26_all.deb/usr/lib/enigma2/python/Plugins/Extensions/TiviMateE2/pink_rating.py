# -*- coding: utf-8 -*-
"""Compact pink numerical rating for all Enigma2 content screens.

Replaces the old percentage-ring image family. Keep ratings on the native
0..10 scale; missing/non-TMDb scores are not silently presented as verified.
"""


def show_pink_rating(widget, vote_average):
    try:
        value = float(str(vote_average).strip().replace(",", "."))
        if not 0.0 < value <= 10.0:
            value = None
    except (TypeError, ValueError, OverflowError):
        value = None
    try:
        widget.setText("★ %.1f" % value if value is not None else "")
    except Exception:
        pass
