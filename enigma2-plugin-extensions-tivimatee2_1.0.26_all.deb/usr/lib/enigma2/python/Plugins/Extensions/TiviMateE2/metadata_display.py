# -*- coding: utf-8 -*-
"""One metadata display policy for TiviMateE2's movie/series pages.

Provider information is authoritative. Show it immediately and fill only
missing fields with matching TMDb data. Catalogue text remains a local fallback.
No network, artwork, or Enigma2 widget operations run in this module.
When a caller omits language, only the local TMDb language setting is read.
Callers own background fetching and stale-selection guards.
"""
import re

def _first(record, *names):
    if not isinstance(record, dict):
        return ""
    for name in names:
        value = record.get(name)
        if value is None or value == "":
            continue
        if isinstance(value, (dict, list)):
            continue
        text = str(value).strip()
        if text and text.lower() not in ("none", "null"):
            return text
    return ""


def _genre(record):
    if not isinstance(record, dict):
        return ""
    genres = record.get("genres")
    if isinstance(genres, list):
        names = []
        for entry in genres:
            name = _first(entry, "name") if isinstance(entry, dict) else str(entry or "").strip()
            if name:
                names.append(name)
        if names:
            return ", ".join(names[:3])
    return _first(record, "genre", "category", "genre_name")


def _year(record):
    value = _first(record, "release_date", "first_air_date", "releasedate", "releaseDate", "year")
    match = re.search(r"(?:19|20)\d{2}", value)
    return match.group(0) if match else ""


def _rating(record):
    value = _first(record, "vote_average", "rating", "rating_5based")
    return "" if value in ("0", "0.0", "-", "--") else value


def _runtime(record, kind="vod"):
    value = _first(record, "runtime", "duration")
    if value:
        return value
    if kind in ("series", "tv") and isinstance(record, dict):
        runs = record.get("episode_run_time") or []
        if runs:
            return str(runs[0] or "").strip()
    return ""


def extract_metadata(row):
    """Normalize flat/nested provider info; never mutate the source item."""
    if not isinstance(row, dict):
        return {}
    merged = dict(row)
    for key in ("data", "movie_data", "series_data", "info"):
        nested = row.get(key)
        if isinstance(nested, dict):
            # Nested detail fields are richer, but empty values must not erase
            # already useful catalogue fields.
            for name, value in nested.items():
                if value not in (None, "", [], {}):
                    merged[name] = value
    return merged


def _contains_arabic_letters(value):
    """Ignore punctuation and Arabic-Indic digits when identifying real text."""
    import unicodedata
    for char in str(value or ""):
        code = ord(char)
        if ((0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or
             0x08A0 <= code <= 0x08FF or 0xFB50 <= code <= 0xFDFF or
             0xFE70 <= code <= 0xFEFF) and unicodedata.category(char).startswith("L")):
            return True
    return False


def _text_options(record, *keys):
    return [_first(record, key) for key in keys if _first(record, key)]


def _genre_options(record):
    if not isinstance(record, dict):
        return []
    values = []
    genres = record.get("genres")
    if isinstance(genres, list):
        names = []
        for entry in genres:
            name = _first(entry, "name") if isinstance(entry, dict) else str(entry or "").strip()
            if name:
                names.append(name)
        if names:
            values.append(", ".join(names[:3]))
    values.extend(_text_options(record, "genre", "category", "genre_name"))
    return values


def _select_text(language, *sources):
    """Server order, with Arabic-script stability in Arabic TMDb mode.

    Providers may return English detail rows after an Arabic catalogue row was
    already shown. Never let those late English responses replace available
    Arabic metadata when the user explicitly selected Arabic. For other
    languages and fields, preserve strict provider -> catalogue -> TMDb order.
    """
    options = [str(value).strip() for group in sources for value in group if str(value or "").strip()]
    if str(language or "").lower().startswith("ar"):
        for value in options:
            if _contains_arabic_letters(value):
                return value
    return options[0] if options else ""


def keep_arabic_on_late_update(existing, incoming, language):
    """Never replace visible Arabic with a later English metadata response.

    Call only after verifying that the response belongs to the same selected
    media record.  A new selection must never inherit the previous title.
    """
    old = str(existing or "").strip()
    new = str(incoming or "").strip()
    if str(language or "").lower().startswith("ar") and _contains_arabic_letters(old) and not _contains_arabic_letters(new):
        return old
    return new or old


def contains_arabic_text(value):
    return _contains_arabic_letters(value)


def merge_metadata(catalog=None, provider=None, tmdb=None, language=None, kind="vod"):
    """Provide the same visible title, plot, year, genre and rating policy.

    Server/provider values win for factual fields (year, rating, runtime).
    Text fields are provider-first unless Arabic TMDb language is selected:
    in that case prefer Arabic-script text already available from provider,
    catalogue or TMDb, rather than replacing it with late English provider data.
    The separate
    ``official_rating`` is the genuine TMDb score used ONLY by the existing
    TMDb badge/circle, not as a replacement for server metadata text.
    Country, logos, banners, and backdrops keep their independent renderers.
    """
    # An omitted language must NEVER silently mean English. The user may have
    # set TMDb to Arabic/French/Turkish, and some screens build initial rows
    # without an explicit locale before their asynchronous callbacks arrive.
    if language is None:
        try:
            from .tmdb_client import load_settings
            language = load_settings().get("language") or "en-US"
        except Exception:
            language = "en-US"
    catalog = extract_metadata(catalog)
    provider = extract_metadata(provider)
    tmdb = extract_metadata(tmdb)
    title = _select_text(language,
                         _text_options(provider, "title", "name", "original_title"),
                         _text_options(catalog, "title", "name", "original_title"),
                         _text_options(tmdb, "title", "name"))
    # Arabic-original productions must retain their genuine Arabic title even
    # when the server's later detail row contains only the export/English name.
    # Keep the ordinary selected-language policy for all other films.
    original_language = (_first(provider, "original_language") or
                         _first(catalog, "original_language") or
                         _first(tmdb, "original_language")).lower()
    if original_language.startswith("ar"):
        for value in _text_options(provider, "title", "name") + \
                     _text_options(catalog, "title", "name") + \
                     _text_options(tmdb, "title", "name"):
            if _contains_arabic_letters(value):
                title = value
                break
    description = _select_text(language,
                               _text_options(provider, "description", "plot", "overview", "storyline", "plot_outline"),
                               _text_options(catalog, "description", "plot", "overview", "storyline", "plot_outline"),
                               _text_options(tmdb, "overview", "description", "plot"))
    genres = _select_text(language, _genre_options(provider), _genre_options(catalog), _genre_options(tmdb))
    official_rating = _rating(tmdb)
    # Facts remain server-first. In Arabic mode, only textual fields (title,
    # overview, genres) prefer available Arabic over a later English response.
    return {
        "title": title,
        "description": description,
        "year": _year(provider) or _year(catalog) or _year(tmdb),
        "rating": _rating(provider) or _rating(catalog) or official_rating,
        "official_rating": official_rating,
        "genre": genres,
        "runtime": _runtime(provider, kind) or _runtime(catalog, kind) or _runtime(tmdb, kind),
        "category": _first(catalog, "category", "category_name") or _first(provider, "category", "category_name"),
    }


def provider_cache_key(kind, item_id, source):
    """Scope provider-detail RAM/disk caches to the exact IPTV source.

    Stream IDs are *not* globally unique.  Two providers may both have movie
    123, so a cache keyed only by `vod:123` can display another film's plot.
    Do not expose URLs, credentials, or MACs in cache filenames.
    """
    import hashlib
    source = source if isinstance(source, dict) else {}
    identity = "\x1f".join(str(source.get(k) or "") for k in (
        "type", "id", "name", "url", "base_url", "portal", "host",
        "username", "user", "password", "mac"))
    source_hash = hashlib.sha256(identity.encode("utf-8", "ignore")).hexdigest()[:24]
    return "%s:%s:%s" % (str(kind or "vod"), source_hash, str(item_id or ""))
