# -*- coding: utf-8 -*-
"""Shared backdrop policy for TiviMateE2 backgrounds and landscape artwork."""
from . import artwork_queue as _queue
from collections import OrderedDict
import threading

KIND = "backdrops"
PROVIDER_KEYS = (
    "backdrop_path", "backdrop", "backdrop_url", "movie_backdrop",
    "fanart", "background", "screenshot_uri",
)
_PROVIDER_CONTEXTS = OrderedDict()
_CONTEXT_LOCK = threading.RLock()
_MAX_CONTEXTS = 384


def _remember_provider(url, source):
    if not url or not isinstance(source, dict):
        return
    key = _queue.normalise_url(url)
    if not key:
        return
    with _CONTEXT_LOCK:
        _PROVIDER_CONTEXTS.pop(key, None)
        _PROVIDER_CONTEXTS[key] = dict(source)
        while len(_PROVIDER_CONTEXTS) > _MAX_CONTEXTS:
            _PROVIDER_CONTEXTS.popitem(last=False)


def _provider_for(url):
    with _CONTEXT_LOCK:
        return _PROVIDER_CONTEXTS.get(_queue.normalise_url(url))


def provider_backdrop_url(source, item, extra=None):
    """Get genuine landscape artwork from common provider detail structures.

    Xtream and Stalker can nest backdrop fields under info/movie_data/data.
    Only check landscape-specific keys; never substitute a cover/poster.
    """
    for record in (item, extra):
        if not isinstance(record, dict):
            continue
        direct = _queue.find_provider_asset(source, record, PROVIDER_KEYS)
        if direct:
            _remember_provider(direct, source)
            return direct
        for key in ("movie_data", "metadata", "data", "details"):
            nested = record.get(key)
            if isinstance(nested, dict):
                found = _queue.find_provider_asset(source, nested, PROVIDER_KEYS)
                if found:
                    _remember_provider(found, source)
                    return found
    return ""


def tmdb_backdrop_url(value, size="original"):
    value = str(value or "").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/%s" % size + value
    return value if value.startswith(("https://", "http://")) else ""


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None, source=None):
    from .unified_genre_artwork import request as genre_request
    return genre_request(url, KIND, callback=callback, priority=priority,
                         errback=errback, source=source)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
