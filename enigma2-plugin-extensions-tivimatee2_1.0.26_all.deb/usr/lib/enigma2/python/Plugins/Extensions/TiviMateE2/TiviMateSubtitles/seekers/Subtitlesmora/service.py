# -*- coding: utf-8 -*-
import io
import os
import re
import unicodedata
from html import unescape as html_unescape
from six.moves.urllib.parse import quote
import requests
import time
import six
from six.moves.urllib.parse import quote_plus, unquote
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from ..user_agents import get_random_ua
from ..utilities import languageTranslate, log, getFileSize
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

# Suppress insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
# Constants
HEADERS = {
    'User-Agent': get_random_ua(),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'text/html; charset=UTF-8',
    'Host': 'archive.org',
    'Referer': 'https://archive.org',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
    'Accept-Encoding': 'gzip, deflate'
}

SESSION = requests.Session()
MAIN_URL = "https://archive.org"
DEBUG_PRETEXT = "archive.org_mora.25r"
def _tivimate_mora_cache_dir():
    for mount in ('/media/hdd', '/hdd', '/media/usb', '/usb'):
        if not os.path.ismount(mount):
            continue
        path = os.path.join(mount, '.tivimatee2-cache', 'subtitles')
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
            if os.access(path, os.W_OK):
                return path
        except Exception:
            pass
    return '/var/volatile/tmp'

CACHE_DIR = _tivimate_mora_cache_dir()
CACHE_FILE = os.path.join(CACHE_DIR, "archive_org_mora_25r.html")
CACHE_TIMEOUT = 86400  # 24 hours in seconds


def get_url(url, referer=None):
    headers = {'User-Agent': HEADERS['User-Agent']}
    if referer:
        headers['Referer'] = referer

    response = SESSION.get(url, headers=headers, verify=False, timeout=12)
    return response.text.replace('\n', '')


def get_rating(downloads):
    return min(10, max(1, downloads // 50 + 1))


ROMAN_NUMERAL_MAP = [
    (r'\bII\b', '2'), (r'\bIII\b', '3'), (r'\bIV\b', '4'), (r'\bV\b', '5'),
    (r'\bVI\b', '6'), (r'\bVII\b', '7'), (r'\bVIII\b', '8'), (r'\bIX\b', '9'),
    (r'\bX\b', '10'), (r'\bXI\b', '11'), (r'\bXII\b', '12'), (r'\bXIII\b', '13'),
    (r'\bXIV\b', '14'), (r'\bXV\b', '15'), (r'\bXVI\b', '16'), (r'\bXVII\b', '17'),
    (r'\bXVIII\b', '18'), (r'\bXIX\b', '19'), (r'\bXX\b', '20'), (r'\bI\b', '1')
]


def generate_title_variations(text):
    """
    Generate variations of a title with both Roman numerals and digits
    """
    variations = [text]

    # Convert Roman numerals to digits
    digit_version = text
    for roman, digit in ROMAN_NUMERAL_MAP:
        digit_version = re.sub(
            roman, digit, digit_version, flags=re.IGNORECASE)
    if digit_version != text:
        variations.append(digit_version)

    # Convert digits to Roman numerals (reverse mapping)
    for roman, digit in ROMAN_NUMERAL_MAP:
        roman_version = re.sub(r'\b' + digit + r'\b',
                               roman, text, flags=re.IGNORECASE)
        if roman_version != text and roman_version not in variations:
            variations.append(roman_version)

    return variations


def get_cached_content():
    """
    Get content from cache if available and not expired
    """
    if os.path.exists(CACHE_FILE):
        # Check if cache is still valid
        if time.time() - os.path.getmtime(CACHE_FILE) < CACHE_TIMEOUT:
            try:
                with io.open(CACHE_FILE, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                log(__name__, '{} Error reading cache: {}'.format(DEBUG_PRETEXT, e))

    return None


def save_content_to_cache(content):
    """
    Save content to cache file
    """
    try:
        if not os.path.exists(CACHE_DIR):
            os.makedirs(CACHE_DIR)
        with io.open(CACHE_FILE, 'w', encoding='utf-8') as f:
            f.write(content)
        log(__name__, '{} Content cached to {}'.format(DEBUG_PRETEXT, CACHE_FILE))
    except Exception as e:
        log(__name__, '{} Error saving cache: {}'.format(DEBUG_PRETEXT, e))


def _mora_text_type():
    try:
        return unicode
    except NameError:
        return str


def _mora_separator_for_value(value):
    sep = u'\u258e'
    text_type = _mora_text_type()
    if not isinstance(value, text_type):
        return sep.encode('utf-8')
    return sep


def _mora_skip_filename(filename):
    if not filename:
        return True
    if filename == 'subs4series':
        return True
    greek_label = u'\u0395\u03c1\u03b3\u03b1\u03c4\u03ae\u03c1\u03b9 \u03a5\u03c0\u03bf\u03c4\u03af\u03c4\u03bb\u03c9\u03bd'
    try:
        if filename == greek_label:
            return True
        if not isinstance(filename, _mora_text_type()) and filename == greek_label.encode('utf-8'):
            return True
    except Exception:
        pass
    return False


def search_subtitles(file_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    # Constraint 1: Skip if searching for a TV Show
    if tvshow or season or episode:
        log(__name__, '{} Provider supports MOVIES ONLY. Skipping TV show search.'.format(
            DEBUG_PRETEXT))
        return subtitles_list, "", msg

    # Constraint 2: Skip if Arabic is not among the requested languages
    requested_langs = [str(lang1).lower(), str(
        lang2).lower(), str(lang3).lower()]
    if not any(lang in requested_langs for lang in ['ar', 'ara', 'arabic']):
        log(__name__, '{} Provider supports ARABIC ONLY. Skipping search.'.format(
            DEBUG_PRETEXT))
        return subtitles_list, "", msg

    # Check if title is blank or empty
    if not title or title.strip() == "":
        log(__name__, '{} Title is blank, skipping search'.format(DEBUG_PRETEXT))
        return subtitles_list, "", msg

    sep = _mora_separator_for_value(title)
    title = re.sub(' ' + sep, sep, title)

    # Define bad strings to remove
    lang_codes = [
        "ae", "al", "ar", "at", "ba", "be", "bg", "br", "cg", "ch", "cz", "da", "de", "dk",
        "ee", "en", "es", "eu", "ex-yu", "fi", "fr", "gr", "hr", "hu", "in", "ir", "it", "lt",
        "mk", "mx", "nl", "no", "pl", "pt", "ro", "rs", "ru", "se", "si", "sk", "sp", "tr",
        "uk", "us", "yu"
    ]
    bad_strings = [code + "|" for code in lang_codes]
    bad_strings += [code + sep for code in lang_codes]
    bad_strings += ["1080p", "4k", "720p",
                    "hdrip", "hindi", "imdb", "vod", "x264"]

    # Remove bad strings from title
    for bad in bad_strings:
        title = title.replace(bad, "")

    title = re.sub(r'[:,"&!?\-]', '', title).replace("  ", " ").strip()
    title = re.sub(r"'", '', title)
    title = re.sub(r'\s*\(?\b(?:19|20)\d{2}\b\)?\s*$', '', title).strip()
    title_variations = generate_title_variations(title)

    log(__name__, '{} Original Title = {}'.format(DEBUG_PRETEXT, title))

    # TV Show parameters have been removed from get_subtitles_list since this is movies only
    for title_var in title_variations:
        get_subtitles_list(title_var, "ar", "Arabic", subtitles_list)

    return subtitles_list, "", msg


def _mora_normalized(value):
    value = unicodedata.normalize('NFKD', html_unescape(unquote(str(value or ''))))
    value = re.sub(r'[^\w]+', ' ', value.lower(), flags=re.UNICODE)
    return ' '.join(value.split())


def _mora_index_files(html):
    """Read both SubsSupportPro's <td> directory listing and Archive modern HTML.

    Old provider used '<td><a href="...">...' and a substring check after
    replacing spaces with dots; preserve that form while allowing all anchors.
    """
    pattern = re.compile(r'<a\b[^>]*href\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>', re.I | re.S)
    files = []
    seen = set()
    for href, label in pattern.findall(html or ''):
        if href.startswith(('/', 'http://', 'https://')):
            prefix = '/download/mora.25r/'
            if prefix not in href:
                continue
            href = href.split(prefix, 1)[1]
        name = unquote(html_unescape(href.split('?', 1)[0]))
        if not name.lower().endswith(('.srt', '.zip', '.rar', '.ass', '.vtt', '.sub')):
            continue
        if name.startswith(('../', './', '/')) or '/../' in name or '\\' in name:
            continue
        if name in seen:
            continue
        seen.add(name)
        files.append((name, html_unescape(re.sub('<[^>]*>', ' ', label)).strip()))
    return files


def _mora_match_title(filename, title):
    """Restore original dot-separated search and normalized phrase fallback."""
    normalized_filename = _mora_normalized(filename)
    normalized_title = _mora_normalized(title)
    if not normalized_title:
        return False
    if (' ' + normalized_title + ' ') in (' ' + normalized_filename + ' '):
        return True
    # For archives using dotted release names, the original matching algorithm
    # converted spaces to dots and compared a substring. Keep it as fallback.
    simple_name = unquote(filename).lower().replace('+', '.').replace('_','.')
    simple_title = quote_plus(title).replace('+', '.').lower()
    return bool(simple_title and re.search(r'(?:^|[.\s_-])' + re.escape(simple_title) + r'(?=$|[.\s_-])', simple_name))


def _mora_files_from_metadata():
    # Fallback to the official Archive metadata JSON only when directory HTML
    # could not be parsed. Never call the endpoint separately for each title.
    metadata_cache = os.path.join(CACHE_DIR, 'mora_25r_files.json')
    try:
        if os.path.isfile(metadata_cache) and time.time() - os.path.getmtime(metadata_cache) < CACHE_TIMEOUT:
            with io.open(metadata_cache, 'r', encoding='utf-8') as stream:
                return [(x,x) for x in __import__('json').load(stream)]
    except Exception:
        pass
    try:
        response = SESSION.get('https://archive.org/metadata/mora.25r',
                               headers=HEADERS, verify=False, timeout=15)
        response.raise_for_status()
        entries = response.json().get('files') or []
        names = [x['name'] for x in entries if isinstance(x, dict) and
                 x.get('name', '').lower().endswith(('.srt','.zip','.rar','.ass','.vtt','.sub'))]
        try:
            if not os.path.isdir(CACHE_DIR):
                os.makedirs(CACHE_DIR)
            with io.open(metadata_cache,'w',encoding='utf-8') as stream:
                __import__('json').dump(names, stream)
        except Exception:
            pass
        return [(x,x) for x in names]
    except Exception as err:
        log(__name__, '%s Metadata fallback unavailable: %s' % (DEBUG_PRETEXT, err))
        return []


def get_subtitles_list(title, lang_short, lang_long, subtitles_list):
    content = get_cached_content()
    if content is None:
        try:
            response = SESSION.get(MAIN_URL + '/download/mora.25r',
                                   headers=HEADERS, verify=False, timeout=12)
            response.raise_for_status()
            content = response.text
            if _mora_index_files(content):
                save_content_to_cache(content)
        except requests.RequestException as err:
            log(__name__, '%s Archive directory unavailable: %s' % (DEBUG_PRETEXT, err))
            content = ''
    items = _mora_index_files(content)
    if not items:
        items = _mora_files_from_metadata()
    if not _mora_normalized(title):
        return
    seen = set(x.get('id') for x in subtitles_list)
    for name, label in items:
        if not _mora_match_title(name, title):
            continue
        if name in seen or _mora_skip_filename(label):
            continue
        seen.add(name)
        subtitles_list.append({
            'no_files': 1, 'filename': os.path.basename(label or name),
            'sync': True, 'id': name, 'language_flag': 'flags/ar.gif',
            'language_name': lang_long})
    log(__name__, '%s Archive entries=%d matches=%d title=%s' %
        (DEBUG_PRETEXT, len(items), len(subtitles_list), title))


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_info = subtitles_list[pos]
    language = subtitle_info["language_name"]
    subtitle_id = subtitle_info["id"]
    # Archive file paths come from external HTML. Do not permit traversal or
    # absolute paths to control the local destination.
    if (not subtitle_id or '\\' in subtitle_id or
            subtitle_id.startswith(('.', '/')) or
            any(part in ('', '.', '..') for part in subtitle_id.split('/'))):
        log(__name__, '{} Invalid archive subtitle ID'.format(DEBUG_PRETEXT))
        return False, language, None

    # Updated to mora.25r
    download_link = '{}/download/mora.25r/{}'.format(MAIN_URL, quote(subtitle_id, safe='/'))

    log(__name__, '{} Downloading from: {}'.format(DEBUG_PRETEXT, download_link))

    try:
        response = SESSION.get(
            download_link, headers=HEADERS, verify=False, allow_redirects=True, timeout=12)
        response.raise_for_status()
    except requests.RequestException as e:
        log(__name__, '{} Download failed: {}'.format(DEBUG_PRETEXT, e))
        return False, language, None

    if not os.path.exists(tmp_sub_dir):
        os.makedirs(tmp_sub_dir)

    body = response.content or b''
    head = body[:1024].lstrip().lower()
    if (not body or head.startswith((b'<html', b'<!doctype html')) or
        not (body.startswith((b'PK\x03\x04', b'Rar!\x1a\x07')) or
             b'-->' in body[:8192] or body[:100].lstrip().upper().startswith(b'WEBVTT') or
             b'[Script Info]' in body[:8192])):
        log(__name__, '{} Invalid subtitle download response'.format(DEBUG_PRETEXT))
        return False, language, None
    local_tmp_file = os.path.join(tmp_sub_dir, os.path.basename(subtitle_id))
    try:
        with open(local_tmp_file, "wb") as file:
            file.write(body)
        log(__name__, '{} Subtitles saved to: {}'.format(
            DEBUG_PRETEXT, local_tmp_file))
    except Exception as e:
        log(__name__, '{} Error saving subtitle: {}'.format(DEBUG_PRETEXT, e))
        return False, language, None

    packed = False
    try:
        with open(local_tmp_file, "rb") as file:
            file_header = file.read(2)
            # Detect ZIP (PK) or RAR (Rar!)
            if file_header == b"PK" or file_header == b"Ra" or file_header.startswith(b"R"):
                packed = True
    except Exception as e:
        log(__name__, '{} Error checking file type: {}'.format(DEBUG_PRETEXT, e))

    log(__name__, '{} Returning: packed={}, language={}, subs_file={}'.format(
        DEBUG_PRETEXT, packed, language, local_tmp_file))
    return packed, language, local_tmp_file
