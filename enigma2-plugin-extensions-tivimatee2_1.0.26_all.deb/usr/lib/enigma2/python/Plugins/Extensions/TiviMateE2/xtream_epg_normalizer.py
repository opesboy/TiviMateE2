# -*- coding: utf-8 -*-
"""Xtream Live EPG decoding and timestamp conversion for all Live skins.

Do not manufacture a current event by shifting an unrelated schedule. Xtream
short EPG is supplied by its panel; UltraStalker's M3U adapter has no Xtream
EPG implementation (epg() returns []).
"""
import base64
import re
import time
from html import unescape

_B64 = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")


def decode_xtream_epg_text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        raw = value.decode('utf-8', 'replace').strip()
    else:
        raw = str(value).strip()
    if not raw:
        return ""
    encoded = "".join(raw.split())
    # Protect plain English labels like News, Film, SHOW and Star. Strict UTF-8
    # alone cannot distinguish some short ordinary titles from Base64 bytes.
    if len(encoded) >= 8 and len(encoded) % 4 != 1 and _B64.fullmatch(encoded):
        try:
            decoded_bytes = base64.b64decode(encoded + "=" * (-len(encoded) % 4), validate=True)
            decoded = decoded_bytes.decode('utf-8', 'strict').strip()
            if (len(decoded) >= 3 and any(ch.isalnum() for ch in decoded)
                    and all(ch.isprintable() or ch in '\n\t' for ch in decoded)):
                raw = decoded
        except (ValueError, UnicodeError, TypeError):
            # Only malformed candidate Base64 reaches here; the raw provider
            # title always remains available without a lossy replacement decode.
            pass
    return " ".join(unescape(raw).split())


def xtream_epg_epoch(value):
    if value is None or value == "":
        return 0
    try:
        stamp = float(value)
        if stamp >= 100000000000:
            stamp /= 1000.0
        return int(stamp) if stamp > 1000000000 else 0
    except (TypeError, ValueError, OverflowError):
        pass
    text = str(value).strip().replace('T',' ').rstrip('Z')
    for fmt, size in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%d %H:%M",16)):
        try:
            return int(time.mktime(time.strptime(text[:size], fmt)))
        except (ValueError, OverflowError):
            pass
    return 0
