# -*- coding: utf-8 -*-
"""Isolated UltraStalker protocol backend, no Enigma2 UI imports."""
