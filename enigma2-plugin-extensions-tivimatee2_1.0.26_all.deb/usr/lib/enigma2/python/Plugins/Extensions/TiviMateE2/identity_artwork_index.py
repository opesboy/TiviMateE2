# -*- coding: utf-8 -*-
"""Shared verified-TMDb image URL index, no network or second image copies.

Never key artwork using provider stream IDs or fuzzy title matches. The index
holds URLs only; artwork_queue remains responsible for checking real local files.
"""
import re
from .cache_manager import persistent_cache_get, persistent_cache_set, stable_cache_key
from .artwork_queue import cached_artwork

_TTL = 90 * 86400


def _identity(kind, tmdb_id):
    try:
        number = int(str(tmdb_id or '').strip())
    except (ValueError, TypeError):
        return ''
    if number <= 0:
        return ''
    media = 'tv' if str(kind).lower() in ('tv', 'series', 'episode') else 'movie'
    return stable_cache_key('tmdb_verified_artwork_v1', media, str(number))


def _valid_tmdb_url(url):
    url = str(url or '').strip()
    # This index accepts only TMDb file identity, never potentially credentialed
    # provider artwork or an arbitrary external host.
    if url.startswith('/') and not url.startswith('//') and re.match(r'^/[A-Za-z0-9_\-]+\.(?:jpg|jpeg|png|webp)$', url, re.I):
        return url
    if re.match(r'^https://image\.tmdb\.org/t/p/(?:original|w[0-9]+)/[A-Za-z0-9_\-]+\.(?:jpg|jpeg|png|webp)$', url, re.I):
        return url
    return ''


def remember(kind, tmdb_id, poster='', backdrop=''):
    key = _identity(kind, tmdb_id)
    if not key:
        return
    additions = {'poster': _valid_tmdb_url(poster), 'backdrop': _valid_tmdb_url(backdrop)}
    if not any(additions.values()):
        return
    previous = persistent_cache_get(key)
    data = dict(previous) if isinstance(previous, dict) else {}
    changed = False
    for label, value in additions.items():
        if value and data.get(label) != value:
            data[label] = value
            changed = True
    if changed:
        persistent_cache_set(key, 'tmdb_verified_artwork', data, _TTL)


def cached_url(kind, tmdb_id, media):
    key = _identity(kind, tmdb_id)
    if not key or media not in ('poster', 'backdrop'):
        return ''
    data = persistent_cache_get(key)
    if not isinstance(data, dict):
        return ''
    url = _valid_tmdb_url(data.get(media))
    if not url:
        return ''
    from .poster_manager import tmdb_poster_url
    from .backdrop_manager import tmdb_backdrop_url
    url = (tmdb_poster_url(url) if media == 'poster' else tmdb_backdrop_url(url))
    return url if cached_artwork(url, 'posters' if media == 'poster' else 'backdrops') else ''
