# -*- coding: utf-8 -*-
"""Shared remote actions for movie/series poster browsing (not Live/details)."""

def switch_server(screen, changed):
    if not isinstance(changed, dict) or not changed:
        return
    try:
        from .ui import HomeServerPopup
        if HomeServerPopup.sourceKey(changed) == HomeServerPopup.sourceKey(screen.source):
            return
        # A category ID belongs to one provider: never reuse it on another server.
        if screen.__class__.__name__ == 'MediaScreen':
            screen.session.open(screen.__class__, dict(changed), screen.kind)
        else:
            screen.session.open(screen.__class__, dict(changed), screen.kind)
        screen.close()
    except Exception as exc:
        from Screens.MessageBox import MessageBox
        screen.session.open(MessageBox, 'Server switch error: %s' % exc,
                            MessageBox.TYPE_ERROR, timeout=5)

def open_server(screen):
    from .ui import get_sources, HomeServerPopup
    from Screens.MessageBox import MessageBox
    sources = list(get_sources() or [])
    if not sources:
        screen.session.open(MessageBox, 'No servers available.',
                            MessageBox.TYPE_INFO, timeout=3)
        return
    screen.session.openWithCallback(lambda selected=None: switch_server(screen, selected),
                                   HomeServerPopup, sources, screen.source)

def open_filter(screen):
    """Long GREEN: existing provider category filter, scoped to Movies or Series."""
    from .ui import ServerCategoryFilter
    from Screens.MessageBox import MessageBox
    source = dict(screen.source or {})
    if str(source.get('type') or '').lower() not in ('xtream', 'stalker'):
        screen.session.open(MessageBox, 'Server package filtering is available for Xtream and Stalker.',
                            MessageBox.TYPE_INFO, timeout=4)
        return
    kind = screen.kind
    if kind not in ('vod', 'series'):
        return
    screen.session.openWithCallback(lambda changed=None: refresh_after_filter(screen, changed),
                                   ServerCategoryFilter, source, kind, True)

def refresh_after_filter(screen, changed):
    if not changed:
        return
    # Reopen only after filters are saved; the new screen uses the existing
    # server-first, cache-aware catalog and does not show stale excluded tiles.
    try:
        if screen.__class__.__name__ == 'MediaScreen':
            screen.session.open(screen.__class__, dict(screen.source), screen.kind,
                                str(getattr(screen, 'activeCategoryId', '') or
                                    getattr(screen, 'initialCategoryId', '') or '') or None,
                                str(getattr(screen, 'activeCategoryName', '') or
                                    getattr(screen, 'initialCategoryName', '') or ''))
        else:
            cid = getattr(screen, 'initial_category_id', None)
            if cid is not None:
                screen.session.open(screen.__class__, dict(screen.source), screen.kind, cid)
            else:
                screen.session.open(screen.__class__, dict(screen.source), screen.kind)
        screen.close()
    except Exception as exc:
        from Screens.MessageBox import MessageBox
        screen.session.open(MessageBox, 'Filter refresh error: %s' % exc,
                            MessageBox.TYPE_ERROR, timeout=5)
