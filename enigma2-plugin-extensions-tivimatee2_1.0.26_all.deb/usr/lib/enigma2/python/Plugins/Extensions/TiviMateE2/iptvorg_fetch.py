# -*- coding: utf-8 -*-
"""Fetch official IPTV-Org playlists without tying Finder to one GitHub host.

Only the official IPTV-Org GitHub Pages and the *same project's* gh-pages
branch are eligible sources. Cache keys always use the original public URL so
changing hosts does not split the artwork/source cache or create duplicate lists.
"""
import os
import time
import hashlib
import threading

from .cache_manager import get_cache_dir

_TTL = 2 * 60 * 60
_PRIMARY = "https://iptv-org.github.io/iptv/"
_MIRROR = "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/"
_MIRROR_PREFERENCE_SECONDS = 30 * 60
_mirror_preferred_until = 0.0
_preference_lock = threading.Lock()


def _is_m3u(body):
    return (isinstance(body, bytes) and
            body.lstrip().startswith(b"#EXTM3U") and
            b"#EXTINF" in body and
            (b"http://" in body or b"https://" in body))


def _cached_m3u(cache, max_bytes):
    try:
        if os.path.isfile(cache):
            with open(cache, "rb") as fh:
                body = fh.read(max_bytes + 1)
            if len(body) <= max_bytes and _is_m3u(body):
                return body
    except Exception:
        pass
    return None


def _official_candidates(url, now):
    """Only exact official .m3u paths may be routed to the official mirror."""
    if not url.startswith(_PRIMARY):
        return [url]
    rel = url[len(_PRIMARY):]
    if not rel or not rel.endswith(".m3u") or "?" in rel or "#" in rel or ".." in rel:
        return [url]
    mirror = _MIRROR + rel
    with _preference_lock:
        mirror_first = now < _mirror_preferred_until
    return [mirror, url] if mirror_first else [url, mirror]


def _fetch_one(url, timeout, max_bytes):
    """Try Enigma2's urllib transport, then requests with TLS verification on."""
    errors = []
    try:
        from .web_manager import _urlopen_text
        code, final, content = _urlopen_text(url, timeout=timeout, max_bytes=max_bytes + 1)
        if int(code or 0) == 200:
            raw = content.encode("utf-8") if isinstance(content, str) else content
            if isinstance(raw, bytes) and len(raw) <= max_bytes and _is_m3u(raw):
                return raw
            errors.append("urllib: incomplete/invalid M3U")
        else:
            errors.append("urllib HTTP %s: %s" % (code, str(content)[:100]))
    except Exception as exc:
        errors.append("urllib: %s" % str(exc)[:100])
    try:
        import requests
        resp = requests.get(url, timeout=(min(timeout, 5), timeout),
                            headers={"User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2",
                                     "Accept": "*/*"},
                            stream=True, allow_redirects=True)
        try:
            if resp.status_code != 200:
                raise RuntimeError("HTTP %s" % resp.status_code)
            parts = []
            size = 0
            for chunk in resp.iter_content(65536):
                if not chunk:
                    continue
                size += len(chunk)
                if size > max_bytes:
                    raise RuntimeError("M3U exceeds %d bytes" % max_bytes)
                parts.append(chunk)
            raw = b"".join(parts)
            if not _is_m3u(raw):
                raise RuntimeError("Invalid IPTV-Org M3U")
            return raw
        finally:
            resp.close()
    except Exception as exc:
        errors.append("requests: %s" % str(exc)[:110])
    raise RuntimeError("; ".join(errors)[:230])


def fetch_iptvorg_m3u(url, timeout=7, max_bytes=24 * 1024 * 1024):
    """Return (official M3U text, from_cache) or raise the real network error.

    Fresh cache takes priority. If GitHub Pages is blocked, try the official
    gh-pages branch on raw.githubusercontent.com; after a successful fallback,
    prefer that host temporarily to avoid repeated connection resets.
    An older, previously validated cache is used only when both hosts fail.
    """
    url = str(url or "").strip()
    name = "iptvorg_" + hashlib.sha1(url.encode("utf-8")).hexdigest() + ".m3u"
    cache = os.path.join(get_cache_dir("source_catalog"), name)
    now = time.time()
    cached = _cached_m3u(cache, max_bytes)
    try:
        if cached is not None and 0 <= now - os.path.getmtime(cache) < _TTL:
            return cached.decode("utf-8", "replace"), True
    except Exception:
        pass

    errors = []
    data = None
    for candidate in _official_candidates(url, now):
        try:
            data = _fetch_one(candidate, timeout, max_bytes)
            if candidate.startswith(_MIRROR):
                global _mirror_preferred_until
                with _preference_lock:
                    _mirror_preferred_until = time.time() + _MIRROR_PREFERENCE_SECONDS
            break
        except Exception as exc:
            errors.append("%s: %s" % ("GitHub mirror" if candidate.startswith(_MIRROR) else "GitHub Pages", str(exc)[:190]))

    if data is None:
        if cached is not None:  # network outage: last known GOOD playlist, never an empty/fake feed
            return cached.decode("utf-8", "replace"), True
        raise RuntimeError("; ".join(errors)[:320])

    try:
        folder = os.path.dirname(cache)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = cache + ".%s.%s.tmp" % (os.getpid(), threading.current_thread().ident)
        try:
            with open(tmp, "wb") as fh:
                fh.write(data)
            os.replace(tmp, cache)
        finally:
            if os.path.exists(tmp):
                try: os.unlink(tmp)
                except Exception: pass
    except Exception:
        pass
    return data.decode("utf-8", "replace"), False
