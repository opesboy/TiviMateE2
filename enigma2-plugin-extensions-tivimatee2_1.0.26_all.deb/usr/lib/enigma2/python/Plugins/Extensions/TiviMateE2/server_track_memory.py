# -*- coding: utf-8 -*-
"""Ultra-style remembered native audio/subtitle languages for VOD.

Remember languages explicitly chosen by the user, not track numbers.  Scope
preferences to a server and a movie or a series (all episodes).  No network,
no playback timer, and no background filesystem writes.
"""
from __future__ import absolute_import

import hashlib
import json
import os
import re
import threading
import time

from .storage import data_path

_LOCK = threading.RLock()
_STATE = None
_PATH = ""
_MAX_ROWS = 300
_MAX_AGE = 365 * 86400
_CANON = {
    'en': 'en', 'eng': 'en', 'english': 'en',
    'ar': 'ar', 'ara': 'ar', 'arb': 'ar', 'arabic': 'ar',
    'fr': 'fr', 'fra': 'fr', 'fre': 'fr', 'french': 'fr',
    'de': 'de', 'deu': 'de', 'ger': 'de', 'german': 'de',
    'es': 'es', 'spa': 'es', 'spanish': 'es',
    'it': 'it', 'ita': 'it', 'italian': 'it',
    'tr': 'tr', 'tur': 'tr', 'turkish': 'tr',
    'ru': 'ru', 'rus': 'ru', 'russian': 'ru',
    'hi': 'hi', 'hin': 'hi', 'hindi': 'hi',
    'ja': 'ja', 'jpn': 'ja', 'japanese': 'ja',
    'ko': 'ko', 'kor': 'ko', 'korean': 'ko',
    'zh': 'zh', 'zho': 'zh', 'chi': 'zh', 'chinese': 'zh',
    'fa': 'fa', 'fas': 'fa', 'per': 'fa', 'persian': 'fa',
    'pt': 'pt', 'por': 'pt', 'portuguese': 'pt',
    'nl': 'nl', 'nld': 'nl', 'dut': 'nl', 'dutch': 'nl',
    'pl': 'pl', 'pol': 'pl', 'polish': 'pl',
    'ur': 'ur', 'urd': 'ur', 'urdu': 'ur',
}


def language(value):
    raw = str(value or '').strip().lower()
    if not raw:
        return ''
    for sep in ('/', ',', ';', '|', '(', '[', '-', '_', ' '):
        raw = raw.split(sep, 1)[0]
    if raw in ('', 'und', 'unk', 'unknown', 'mul', 'zxx', 'qaa'):
        return ''
    return _CANON.get(raw, raw if 2 <= len(raw) <= 3 and raw.isalpha() else '')


def _path():
    return data_path('server_track_prefs_v1.json')


def _load():
    global _PATH, _STATE
    path = _path()
    if _STATE is not None and path == _PATH:
        return _STATE
    _PATH = path
    try:
        with open(path, 'r') as h:
            loaded = json.load(h)
    except (IOError, OSError, ValueError, TypeError):
        loaded = {}
    if not isinstance(loaded, dict):
        loaded = {}
    entries = loaded.get('items')
    if not isinstance(entries, dict):
        entries = {}
    now = time.time()
    clean = {}
    for key, row in entries.items():
        if not isinstance(row, dict):
            continue
        try:
            stamp = float(row.get('time', 0) or 0)
        except (ValueError, TypeError):
            continue
        if stamp <= 0 or now - stamp > _MAX_AGE:
            continue
        audio = language(row.get('audio'))
        sub = str(row.get('subtitle') or '')
        sub = 'off' if sub == 'off' else language(sub)
        if audio or sub:
            clean[str(key)] = {'audio': audio, 'subtitle': sub, 'time': stamp}
    _STATE = {'enabled': bool(loaded.get('enabled', True)), 'items': clean}
    return _STATE


def _save(data):
    path = _path()
    temp = path + '.tmp.%d' % os.getpid()
    try:
        parent = os.path.dirname(path)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        with open(temp, 'w') as h:
            json.dump(data, h, ensure_ascii=False, separators=(',', ':'))
            h.flush()
            os.fsync(h.fileno())
        os.rename(temp, path)
        return True
    except (IOError, OSError, ValueError, TypeError):
        try:
            os.unlink(temp)
        except OSError:
            pass
        return False


def enabled():
    with _LOCK:
        return bool(_load()['enabled'])


def set_enabled(value):
    with _LOCK:
        data = _load()
        new = bool(value)
        if data['enabled'] == new:
            return True
        data['enabled'] = new
        return _save(data)


def media_key(item):
    """A series shares a preference across episodes; servers never share it."""
    if not isinstance(item, dict):
        return ''
    source = str(item.get('_source_key') or item.get('server_id') or
                 item.get('source_id') or item.get('playlist_id') or '').strip()
    if not source:
        server = item.get('_episode_source') or {}
        if isinstance(server, dict):
            source = str(server.get('url') or server.get('portal') or server.get('host') or server.get('name') or '').strip()
    if not source:
        # Unknown source: do not leak a saved preference from another server.
        return ''
    series = str(item.get('series_name') or '').strip()
    kind = str(item.get('_kind') or '').strip().lower()
    if series or kind in ('episode', 'series', 'tv', 'show'):
        group = 'series'
        title = series or str(item.get('_series_title') or item.get('title') or item.get('name') or '')
        sid = str(item.get('_series_id') or item.get('series_id') or '').strip()
        identity = sid or re.sub(r'\s+', ' ', title.strip().lower())
    else:
        group = 'vod'
        identity = str(item.get('stream_id') or item.get('vod_id') or item.get('movie_id') or item.get('id') or '').strip()
        if not identity:
            identity = re.sub(r'\s+', ' ', str(item.get('name') or item.get('title') or '').strip().lower())
    if not identity:
        return ''
    raw = json.dumps([str(source).lower(), group, identity], separators=(',', ':'), ensure_ascii=False)
    return hashlib.sha1(raw.encode('utf-8', 'ignore')).hexdigest()


def get(item):
    key = media_key(item)
    if not key:
        return {}
    with _LOCK:
        return dict(_load()['items'].get(key) or {})


def put(item, audio=None, subtitle=None):
    key = media_key(item)
    if not key:
        return False
    with _LOCK:
        data = _load()
        if not data['enabled']:
            return False
        row = dict(data['items'].get(key) or {'audio': '', 'subtitle': ''})
        if audio is not None:
            value = language(audio)
            if value:
                row['audio'] = value
        if subtitle is not None:
            value = 'off' if str(subtitle).lower() == 'off' else language(subtitle)
            if value:
                row['subtitle'] = value
        if not (row.get('audio') or row.get('subtitle')):
            return False
        if data['items'].get(key) and all(row.get(k) == data['items'][key].get(k) for k in ('audio', 'subtitle')):
            return True
        row['time'] = time.time()
        data['items'][key] = row
        if len(data['items']) > _MAX_ROWS:
            ordered = sorted(data['items'].items(), key=lambda kv: kv[1].get('time', 0), reverse=True)
            data['items'] = dict(ordered[:_MAX_ROWS])
        return _save(data)
