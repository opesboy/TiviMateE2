# -*- coding: UTF-8 -*-
from __future__ import absolute_import, print_function, division
import os
import re
from html import unescape as html_unescape
import warnings
import requests
import six

from ..user_agents import get_session_ua
from ..utilities import log
from .MoviesubtitlesUtilities import get_language_info

# Safely suppress insecure request warnings without causing ImportErrors on strict images
try:
    from urllib3.exceptions import InsecureRequestWarning
    warnings.simplefilter('ignore', InsecureRequestWarning)
except ImportError:
    try:
        from requests.packages.urllib3.exceptions import InsecureRequestWarning
        warnings.simplefilter('ignore', InsecureRequestWarning)
    except ImportError:
        pass


def get_random_ua():
    return get_session_ua("moviesubtitles")


HDR = {'User-Agent': get_random_ua(),
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.',
       'Accept-Language': 'en-US,en;q=0.9,ar-EG;q=0.8,ar;q=0.7',
       'Upgrade-Insecure-Requests': '1',
       'Content-Type': 'application/x-www-form-urlencoded',
       'Referer': 'https://www.moviesubtitles.org/search.php',
       'Connection': 'keep-alive',
       'Accept-Encoding': 'gzip, deflate'}

s = requests.Session()

main_url = "https://www.moviesubtitles.org"
debug_pretext = "moviesubtitles.org"


def _simplify_title(value):
    value = html_unescape(re.sub(r'<[^>]+>', ' ', str(value or '')))
    value = re.sub(r'[^\w]+', ' ', value.lower(), flags=re.UNICODE)
    return ' '.join(value.split())


def _movie_links(html):
    # Accept double/single quotes and optional nested tags inside movie anchors.
    anchor = re.compile(r'<a\b[^>]*?href\s*=\s*[\"\'](?P<href>(?:https?://[^\"\']+)?/?movie-\d+\.html)[\"\'][^>]*>(?P<label>.*?)</a>',
                        re.I | re.S)
    return [(m.group('href'), html_unescape(re.sub('<[^>]*>', ' ', m.group('label'))).strip())
            for m in anchor.finditer(html)]


def _movie_candidate_score(title, candidate):
    """Compare search results while allowing 'The Film' / 'Film, The' site titles."""
    desired = _simplify_title(title)
    cleaned = re.sub(r'\(?\s*(?:19|20)\d{2}\s*\)', '', candidate or '')
    cleaned = re.sub(r'\b(?:19|20)\d{2}\b', '', cleaned).strip()
    normalized = _simplify_title(cleaned)
    if not normalized or not desired:
        return 0
    if normalized == desired:
        return 100
    def move_article(t):
        words = t.split()
        return ' '.join(words[1:] + words[:1]) if len(words)>1 and words[0] in ('the','a','an') else t
    if move_article(desired) == normalized or move_article(normalized) == desired:
        return 95
    if normalized.startswith(desired + ' ') or desired.startswith(normalized + ' '):
        return 84
    # The search form may return aka/alternative titles in parentheses.
    if len(desired) > 4 and (' ' + desired + ' ') in (' ' + normalized + ' '):
        return 81
    return 0


def getSearchTitle(title, year=None):
    """Follow SubsSupportPro's POST search, accept its valid matches, and try GET.

    Never silently accept an unrelated first film: a wrong subtitle can be much
    worse than no subtitle. Unlike previous TiviMate code, try both hosts when
    results from the first one don't match the requested film.
    """
    search_title = prepare_search_string(title)
    if not _simplify_title(search_title):
        return None
    from six.moves.urllib.parse import urljoin
    candidates = []
    errors = []
    for origin in ('https://www.moviesubtitles.org', 'https://moviesubtitles.org'):
        for method in ('post', 'get'):
            try:
                HDR['User-Agent'] = get_random_ua()
                kw = {'data': {'q': search_title}} if method == 'post' else {'params': {'q': search_title}}
                response = getattr(s, method)(origin+'/search.php', headers=HDR,
                                             verify=False, allow_redirects=True,
                                             timeout=12, **kw)
                response.raise_for_status()
                links = _movie_links(six.ensure_str(response.content,
                              encoding='utf-8', errors='ignore'))
                log(__name__, '%s %s search %s: %d movie links' %
                    (debug_pretext, method.upper(), origin, len(links)))
                for href, label in links:
                    score = _movie_candidate_score(search_title, label)
                    if score <= 0:
                        continue
                    candidate_years = re.findall(r'\b(?:19|20)\d{2}\b', label)
                    if year and candidate_years and str(year) not in candidate_years:
                        continue
                    candidates.append((score, urljoin(getattr(response,'url','') or origin, href)))
                if candidates:
                    candidates.sort(key=lambda x: x[0], reverse=True)
                    log(__name__, '%s Matched film %s via %s' %
                        (debug_pretext, search_title, method.upper()))
                    return candidates[0][1]
            except requests.RequestException as err:
                errors.append('%s %s: %s' % (method.upper(),origin,err))
    log(__name__, '%s No matching movie for %s, errors=%s' %
        (debug_pretext, search_title, '; '.join(errors[:2])))
    return None


def get_rating(downloads):
    rating = int(downloads)
    if (rating < 50):
        rating = 1
    elif (rating >= 50 and rating < 100):
        rating = 2
    elif (rating >= 100 and rating < 150):
        rating = 3
    elif (rating >= 150 and rating < 200):
        rating = 4
    elif (rating >= 200 and rating < 250):
        rating = 5
    elif (rating >= 250 and rating < 300):
        rating = 6
    elif (rating >= 300 and rating < 350):
        rating = 7
    elif (rating >= 350 and rating < 400):
        rating = 8
    elif (rating >= 400 and rating < 450):
        rating = 9
    elif (rating >= 450):
        rating = 10
    return rating


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    if tvshow or season or episode:
        return [], "", ""
    languagefound = next((lang for lang in (lang1, lang2, lang3)
                          if get_language_info(lang)), lang1)
    language_info = get_language_info(languagefound)
    if not language_info:
        log(__name__, '%s Unsupported language %s' % (debug_pretext, languagefound))
        return [], "", ""
    language_info1 = language_info['name']
    language_info2 = language_info['2et']

    subtitles_list = []
    msg = ""

    if len(tvshow) == 0 and year:
        searchstring = "%s (%s)" % (title, year)
    elif len(tvshow) > 0 and title == tvshow:
        searchstring = "%s (%02d%02d)" % (tvshow, int(season), int(episode))
    elif len(tvshow) > 0:
        searchstring = "%s S%02dE%02d" % (tvshow, int(season), int(episode))
    else:
        searchstring = title
    log(__name__, "%s Search string = %s" % (debug_pretext, searchstring))
    get_subtitles_list(title, year, language_info2,
                       language_info1, subtitles_list)
    return subtitles_list, "", msg


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    language = subtitles_list[pos]["language_name"]
    filename = subtitles_list[pos]["filename"]
    print(("filename", filename))
    id = subtitles_list[pos]["id"]
    print(("id1", id))
    id = id.replace("subtitle", "download")
    print(("id2", id))
    downloadlink = '%s%s' % (main_url, id)
    print(("downloadlink", downloadlink))
    packed = False
    subs_file = None

    if downloadlink:
        log(__name__, "%s Downloadlink: %s " % (debug_pretext, downloadlink))
        viewstate = 0
        previouspage = 0
        subtitleid = 0
        typeid = "zip"
        filmid = 0
        postparams = {'__EVENTTARGET': 's$lc$bcr$downloadLink', '__EVENTARGUMENT': '', '__VIEWSTATE': viewstate,
                      '__PREVIOUSPAGE': previouspage, 'subtitleId': subtitleid, 'typeId': typeid, 'filmId': filmid}
        print(("postparams", postparams))

        HDR['User-Agent'] = get_random_ua()

        response = s.get(downloadlink, data=postparams,
                         headers=HDR, verify=False, allow_redirects=True, timeout=12)
        local_tmp_file = zip_subs
        response.raise_for_status()
        body = response.content or b''
        stripped = body[:512].lstrip().lower()
        valid_archive = (body.startswith(b'PK\x03\x04') or
                         body.startswith(b'Rar!\x1a\x07'))
        valid_subtitle = (b'-->' in body[:8192] or
                          body[:100].lstrip().upper().startswith(b'WEBVTT') or
                          b'[Script Info]' in body[:8192] or
                          b'Dialogue:' in body[:8192])
        if (not body or stripped.startswith((b'<html', b'<!doctype html')) or
                not (valid_archive or valid_subtitle)):
            log(__name__, '%s Download did not return a valid subtitle/archive' % debug_pretext)
            return False, language, None
        try:
            log(__name__, "%s Saving subtitles to '%s'" %
                (debug_pretext, local_tmp_file))
            if not os.path.exists(tmp_sub_dir):
                os.makedirs(tmp_sub_dir)
            with open(local_tmp_file, 'wb') as local_file_handle:
                local_file_handle.write(body)

            myfile = open(local_tmp_file, "rb")
            myfile.seek(0)
            first_byte = myfile.read(1)
            first_char = six.ensure_str(
                first_byte, encoding='utf-8', errors='ignore') if first_byte else ''

            if (body.startswith(b'Rar!\x1a\x07')):
                typeid = "rar"
                packed = True
                log(__name__, "Discovered RAR Archive")
            else:
                if (body.startswith(b'PK\x03\x04')):
                    typeid = "zip"
                    packed = True
                    log(__name__, "Discovered ZIP Archive")
                else:
                    typeid = "srt"
                    packed = False
                    subs_file = local_tmp_file
                    log(__name__, "Discovered a non-archive file")
            myfile.close()
            log(__name__, "%s Saving to %s" % (debug_pretext, local_tmp_file))
        except Exception as e:
            log(__name__, "%s Failed to save subtitle to %s (%s)" %
                (debug_pretext, local_tmp_file, str(e)))
        if packed:
            subs_file = typeid
        log(__name__, "%s Subtitles saved to '%s'" %
            (debug_pretext, local_tmp_file))
        return packed, language, subs_file


def prepare_search_string(s):
    s = s.strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)
    return s


def get_subtitles_list(title, year, languageshort, languagelong, subtitles_list):
    search_string = prepare_search_string(title)
    movie_url = getSearchTitle(search_string, year)
    if not movie_url:
        return
    HDR['User-Agent'] = get_random_ua()
    response = s.get(movie_url, headers=HDR, verify=False, allow_redirects=True, timeout=12)
    response.raise_for_status()
    html = six.ensure_str(response.content, encoding='utf-8', errors='ignore')
    language_flag = languageshort.lower()
    # Site markup has changed over time: flags and subtitle anchors do not
    # always sit in the same div, and the download count may not be red.
    entry = re.compile(r'<a\b[^>]*href\s*=\s*[\"\'](?P<href>(?:https?://[^\"\']+)?/?subtitle-\d+\.html)[\"\'][^>]*>(?P<label>.*?)</a>',
                       re.I | re.S)
    flags = re.compile(r'(?:flags/|flag-)' + re.escape(language_flag) + r'(?:\.gif|\.png|\b)', re.I)
    matches = list(entry.finditer(html))
    log(__name__, '%s Movie page subtitle anchors=%d for %s' %
        (debug_pretext, len(matches), search_string))
    seen = set()
    for match in matches:
        # The language icon is beside the subtitle entry in both old and new layouts.
        before = html[max(0, match.start()-750):match.start()]
        after = html[match.end():match.end()+220]
        # Do not leak the previous subtitle's flag into this row when the page is
        # structured in separate <div class="subtitle"> blocks.
        row_start = max(before.lower().rfind('<div class="subtitle"'),
                        before.lower().rfind("<div class='subtitle'"))
        row = before[row_start:] + match.group(0) + after if row_start >= 0 else before[-260:] + match.group(0) + after
        if not flags.search(row):
            # Original SubsSupportPro looked for language flags on the subtitle
            # row. Keep this filter; do not relabel English subtitles as Arabic.
            continue
        href = match.group('href')
        if not href.startswith(('http://', 'https://', '/')):
            href = '/' + href
        filename = html_unescape(re.sub('<[^>]*>', ' ', match.group('label'))).strip()
        if not filename:
            continue
        if href.startswith('http'):
            from six.moves.urllib.parse import urlparse
            href = urlparse(href).path
        if href in seen:
            continue
        seen.add(href)
        count_match = re.search(r'color\s*:\s*red[^>]*>\s*(\d+)', after, re.I)
        count = int(count_match.group(1)) if count_match else 0
        subtitles_list.append({
            'rating': str(get_rating(str(count))), 'no_files': 1,
            'filename': filename, 'sync': True, 'id': href,
            'language_flag': languageshort, 'language_name': languagelong})
    log(__name__, '%s Arabic/language matches=%d for %s' %
        (debug_pretext, len(subtitles_list), search_string))

