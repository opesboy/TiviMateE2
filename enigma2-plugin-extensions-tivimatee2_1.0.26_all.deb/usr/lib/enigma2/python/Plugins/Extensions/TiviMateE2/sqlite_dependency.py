# -*- coding: utf-8 -*-
"""Handle optional Python sqlite3 packages on lean Enigma2 images.

The package manager installs Recommends when possible.  If a receiver image
omits it, try once when TiviMate opens (never inside opkg's postinst and never
on Enigma2 boot). The subprocess is asynchronous on the Enigma GUI loop.
"""
import shutil

_INSTALL_PROCESS = None
_INSTALL_ATTEMPTED = False


def sqlite_ready():
    """Check the actual sqlite extension, not merely an importable wrapper."""
    try:
        import sqlite3
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("SELECT 1").fetchone()
        finally:
            conn.close()
        return True
    except Exception:
        return False


def _notice(session, message, error=False):
    try:
        from Screens.MessageBox import MessageBox
        mtype = MessageBox.TYPE_ERROR if error else MessageBox.TYPE_INFO
        session.open(MessageBox, message, type=mtype, timeout=12 if not error else 0)
    except Exception:
        pass


def _stage(session, phase):
    global _INSTALL_PROCESS
    try:
        from enigma import eConsoleAppContainer
        proc = eConsoleAppContainer()
        _INSTALL_PROCESS = proc  # prevent GC while process is active

        def _finished(ret):
            global _INSTALL_PROCESS
            _INSTALL_PROCESS = None
            try:
                returncode = int(ret)
            except Exception:
                returncode = 1
            if sqlite_ready():
                _notice(session, "SQLite installed successfully. Open TiviMate E2 again.")
                return
            if phase == "install":
                # A new image may have no package lists until opkg update.
                _stage(session, "refresh")
                return
            if phase == "refresh" and returncode == 0:
                _stage(session, "retry")
                return
            _notice(session,
                    "TiviMate E2 cannot start because Python SQLite is missing.\n"
                    "Automatic install failed or the image does not provide python3-sqlite3.\n"
                    "Check the image's package feeds and install python3-sqlite3.",
                    error=True)

        try:
            proc.appClosed.append(_finished)
        except Exception:
            proc.appClosed.get().append(_finished)
        opkg_bin = shutil.which('opkg')
        if not opkg_bin:
            _INSTALL_PROCESS = None
            _notice(session, "opkg is no longer available on this image.", error=True)
            return False
        import shlex
        if phase == "refresh":
            command = shlex.quote(opkg_bin) + " update"
        else:
            command = shlex.quote(opkg_bin) + " install python3-sqlite3"
        # Return immediately; a broken feed never blocks the Enigma2 UI.
        try:
            rc = proc.execute('/bin/sh', 'sh', '-c', command)
        except (TypeError, AttributeError):
            rc = proc.execute(command)
        if rc not in (0, None, True):
            _INSTALL_PROCESS = None
            _notice(session, "Unable to start SQLite installation. Check opkg on the receiver.", error=True)
            return False
        return True
    except Exception:
        _INSTALL_PROCESS = None
        _notice(session, "Automatic SQLite installation could not start on this image.", error=True)
        return False


def ensure_sqlite(session):
    """True if it is safe to open the full UI, False otherwise."""
    global _INSTALL_ATTEMPTED
    if sqlite_ready():
        return True
    if _INSTALL_PROCESS is not None:
        _notice(session, "Installing Python SQLite in the background. Please check again shortly.")
        return False
    if _INSTALL_ATTEMPTED:
        _notice(session,
                "SQLite is still missing. Automatic installation was already tried.\n"
                "Check package feeds for python3-sqlite3 and reopen TiviMate E2.",
                error=True)
        return False
    _INSTALL_ATTEMPTED = True
    if not shutil.which('opkg'):
        _notice(session, "SQLite is missing and this image has no opkg package manager.", error=True)
        return False
    _notice(session, "Python SQLite is missing. TiviMate E2 is trying to install it automatically.")
    _stage(session, 'install')
    return False
