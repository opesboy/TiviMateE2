# -*- coding: utf-8 -*-
"""Safe, conservative display states for the Live server selector.

Connectivity is a result of a fresh validation, not a claim about whether
individual streams work. Account validity and connectivity are independent.
"""
from datetime import datetime
import time


def _expired(value, now=None):
    value = str(value or "").strip()
    if not value or value.lower() in ("0", "unlimited", "never", "lifetime", "unknown"):
        return False
    now = time.time() if now is None else now
    try:
        stamp = float(value)
        if stamp > 100000000000:
            stamp /= 1000.0
        if stamp >= 946684800:
            return stamp < now
    except (ValueError, TypeError, OverflowError):
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            return time.mktime(datetime.strptime(value, fmt).timetuple()) < now
        except (ValueError, TypeError, OverflowError):
            pass
    return False


def check_live_source(source_type, reply=None, expiry="", error=None):
    """Return account, connection, legacy status, expiry from a *fresh* test.

    Failures report FAILED (test failed), never pretend the actual streaming
    service is OFFLINE. In particular a nonzero Xtream active_cons is not BUSY.
    """
    stype = str(source_type or "").strip().lower()
    result = {"account": "unknown", "connection": "failed",
              "legacy_status": "unknown", "expiry": str(expiry or "")}
    if error is not None or not isinstance(reply, dict):
        return result

    if stype == "xtream":
        user = reply.get("user_info")
        user = user if isinstance(user, dict) else {}
        # A real panel reply is required, a non-empty arbitrary dict is not enough.
        if not user:
            return result
        result["connection"] = "online"
        status = str(user.get("status") or "").strip().lower()
        auth = str(user.get("auth") if "auth" in user else "").strip().lower()
        if _expired(expiry) or status in ("expired", "expire"):
            account = "expired"
        elif status in ("banned", "blocked", "disabled"):
            account = "blocked"
        elif status in ("inactive", "suspended", "deactivated") or auth in ("0", "false", "no"):
            account = "inactive"
        elif status in ("active", "enabled") or auth in ("1", "true", "yes"):
            account = "active"
        else:
            account = "unknown"
        result["account"] = account
        result["legacy_status"] = "online" if account == "active" else "expired" if account == "expired" else "unknown"
    elif stype == "stalker":
        if reply.get("ok") is True:
            result["connection"] = "online"
            result["account"] = "expired" if _expired(expiry) else "active"
            result["legacy_status"] = "expired" if result["account"] == "expired" else "online"
    elif stype in ("m3u", "fg"):
        if reply.get("ok") is True:
            result["connection"] = "valid"
            result["account"] = "na"
            result["legacy_status"] = "online"  # A readable playlist; not per-channel availability
    else:
        if reply.get("ok") is True:
            result["connection"] = "online"
            result["legacy_status"] = "online"
    return result
