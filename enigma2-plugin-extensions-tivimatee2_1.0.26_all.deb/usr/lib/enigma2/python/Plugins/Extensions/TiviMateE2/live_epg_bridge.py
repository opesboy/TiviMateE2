# -*- coding: utf-8 -*-
"""Small in-process EPG cache shared by the Live player and Windows/list UI.

Positive provider results only. Never writes IPTV details to internal flash and
never fetches anything on the Enigma2 GUI thread.
"""
import threading
import time
from .ultra_epg_selection import _timestamp as ultra_timestamp, epg_title as ultra_epg_title

_LOCK = threading.RLock()
_ROWS = {}
_MAX = 400


def _key(source, item):
    source = source or {}
    item = item or {}
    server = (str(source.get('type') or '').lower(),
              str(source.get('url') or source.get('host') or source.get('server') or
                  source.get('portal') or '').rstrip('/'),
              str(source.get('username') or ''), str(source.get('mac') or source.get('mac_address') or ''))
    kind = server[0]
    if kind == 'stalker':
        channel = item.get('ch_id') or item.get('stream_id') or item.get('id')
    else:
        channel = item.get('ch_id') or item.get('stream_id') or item.get('id')
    channel = str(channel or '').strip()
    return (server, channel) if channel else None


def remember(source, item, rows):
    key = _key(source, item)
    records = [dict(r) for r in (rows or []) if isinstance(r, dict)]
    if key is None or not records:
        return
    with _LOCK:
        _ROWS[key] = (time.monotonic(), records[:24])
        if len(_ROWS) > _MAX:
            expired = sorted(_ROWS.items(), key=lambda pair: pair[1][0])[:80]
            for old_key, _ in expired:
                _ROWS.pop(old_key, None)


def cached(source, item, max_age=900):
    key = _key(source, item)
    if key is None:
        return []
    with _LOCK:
        item = _ROWS.get(key)
        if not item or time.monotonic() - item[0] > max_age:
            return []
        return [dict(r) for r in item[1]]


def select_stalker_now_next(rows, now_ts=None):
    """Choose Stalker Now/Next using the source UltraStalker epg_summary policy.

    Ultra first sorts by start time, selects a running programme, otherwise
    picks the first future/untimed item (or the first returned programme).
    Adapt only the result shape for TiviMate: (begin, end, original_row).
    Neither timestamps nor progress are fabricated for untimed rows.
    """
    now = int(time.time() if now_ts is None else now_ts)
    events = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        begin = ultra_timestamp(row.get('start_timestamp') or row.get('start') or row.get('time'))
        end = ultra_timestamp(row.get('stop_timestamp') or row.get('stop') or row.get('end') or row.get('time_to'))
        # Ultra's MAG response can encode stop as seconds from the beginning.
        if end and begin and end < begin:
            end = begin + end
        # TiviMate handles additional provider fields and milliseconds; do not
        # lose their valid time ranges when an Ultra field is absent.
        if not begin:
            begin = ultra_timestamp(row.get('begin_timestamp') or row.get('begin'))
        if not end:
            end = ultra_timestamp(row.get('end_timestamp') or row.get('time_to'))
        if begin > 100000000000:
            begin //= 1000
        if end > 100000000000:
            end //= 1000
        if begin and not end:
            try:
                duration = max(0, int(float(row.get('duration') or 0)))
            except (TypeError, ValueError, OverflowError):
                duration = 0
            if duration:
                end = begin + duration
        events.append((begin, end, row))
    # UltraStalker/ultra.py: epg_summary sorts missing starts as zero.
    events.sort(key=lambda event: event[0] or 0)
    current = None
    following = None
    for index, event in enumerate(events):
        begin, end, row = event
        if begin and end and begin <= now < end:
            current = event
            following = events[index + 1] if index + 1 < len(events) else None
            break
    if current is None and events:
        # This is Ultra's exact fallback: keep programmes without timestamps.
        future = [event for event in events if not event[0] or event[0] >= now]
        current = events[0] if not future else future[0]
        index = events.index(current)
        following = events[index + 1] if index + 1 < len(events) else None
    return current, following


# Small transient single-flight registry. Ultra's page EPG can be in progress
# when the viewer opens the full-screen player. A background Infobar worker
# waits briefly for the result instead of immediately sending a duplicate
# portal request. Never wait on the Enigma2 UI thread.
_FLIGHTS = {}


def begin_many(source, items):
    with _LOCK:
        for item in items or ():
            key = _key(source, item)
            if key is not None and key not in _FLIGHTS:
                _FLIGHTS[key] = (time.monotonic(), threading.Event())
        if len(_FLIGHTS) > _MAX:
            for key, (started, event) in list(_FLIGHTS.items()):
                if time.monotonic() - started > 15:
                    event.set()
                    _FLIGHTS.pop(key, None)


def finish_many(source, items):
    with _LOCK:
        for item in items or ():
            key = _key(source, item)
            found = _FLIGHTS.pop(key, None) if key is not None else None
            if found:
                found[1].set()


def wait_for_visible_result(source, item, max_wait=0.7):
    """Worker-thread-only short wait for an in-flight Ultra batch result."""
    key = _key(source, item)
    if key is None:
        return []
    with _LOCK:
        inflight = _FLIGHTS.get(key)
        if inflight and time.monotonic() - inflight[0] > 12:
            _FLIGHTS.pop(key, None)
            inflight[1].set()
            inflight = None
    if inflight:
        inflight[1].wait(min(0.8, max(0.0, float(max_wait))))
    return cached(source, item)
