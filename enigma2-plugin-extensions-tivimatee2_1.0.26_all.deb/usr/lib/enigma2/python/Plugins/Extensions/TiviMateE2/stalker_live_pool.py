# -*- coding: utf-8 -*-
"""Share UltraStalker's original lazy executor implementation.

Playback link and catalogue pagination use separate finite worker lanes: a
broken catalogue must never queue ahead of the user-selected Play action.
"""
from .ultra_stalker_engine.core.executor import LazyThreadPoolExecutor
import json
import threading

STALKER_LIVE_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=3, thread_name_prefix="TiviStalkerLive")
STALKER_CATALOG_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=2, thread_name_prefix="TiviStalkerPages")
# Low-priority EPG only: must never queue ahead of live playback requests.
LIVE_EPG_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=2, thread_name_prefix="TiviLiveEPG")
# Low-frequency keepalive has its own single, reusable Ultra worker.
# A watchdog request must not block the channel-link or visible EPG lanes.
STALKER_WATCHDOG_EXECUTOR = LazyThreadPoolExecutor(
    max_workers=1, thread_name_prefix="TiviStalkerWatchdog")


# Reuse authenticated playback clients within one worker thread only.
# Each Ultra client owns mutable cookies, its own transport and auth state:
# sharing an instance between independent threads can serialise zaps behind
# an abandoned request. The thread-local, bounded cache avoids the repeated
# portal discovery and handshake on consecutive list/Windows previews without
# sharing connection state across executor workers or changing EPG clients.
_LIVE_PLAYBACK_CLIENTS = threading.local()
_LIVE_CLIENT_CACHE_LIMIT = 2


def _live_client_source_key(source):
    values = dict(source or {})
    # This is navigation state rather than portal identity and changes on zap.
    values.pop('_tivimate_current_live_id', None)
    return json.dumps(values, sort_keys=True, default=str, ensure_ascii=True)


def live_playback_client(source, factory):
    key = _live_client_source_key(source)
    cache = getattr(_LIVE_PLAYBACK_CLIENTS, 'cache', None)
    if cache is None:
        cache = []
        _LIVE_PLAYBACK_CLIENTS.cache = cache
    for index, (saved_key, client) in enumerate(cache):
        if saved_key == key:
            cache.append(cache.pop(index))
            return client
    client = factory(source)
    cache.append((key, client))
    while len(cache) > _LIVE_CLIENT_CACHE_LIMIT:
        cache.pop(0)
    return client


def invalidate_live_playback_client(source):
    # A transport/auth error can poison a session; allow the next zap to
    # construct a fresh client. Successful and cancelled requests keep cache.
    key = _live_client_source_key(source)
    cache = getattr(_LIVE_PLAYBACK_CLIENTS, 'cache', None)
    if cache is not None:
        cache[:] = [(saved, client) for saved, client in cache if saved != key]
