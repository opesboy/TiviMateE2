# -*- coding: utf-8 -*-
"""Exact Ultra task cancellation callbacks with an Event API adapter.

Ultra's bundled HTTP client probes ``is_set`` while TiviMate callers also use
``cancelled``. Keep the API compatible without copying the task implementation.
"""
from .ultra_stalker_engine.core.tasks import TaskHandle as _UltraTaskHandle

class TaskHandle(_UltraTaskHandle):
    def is_set(self):
        return self.cancelled()
