# -*- coding: utf-8 -*-
"""Shared GENRE cache-first media transport for all TiviMateE2 screens.

Presentation and per-page metadata/recovery stay with the owning screen.
The visible picture transfer is consistent across posters, backdrops and title
logos; all callbacks run on Enigma2's Twisted UI thread.  Existing generic
queue remains available for unsupported provider image responses.
"""
from . import artwork_queue as _queue


def _source_for(url, family, explicit):
    if isinstance(explicit, dict) and explicit:
        return dict(explicit)
    try:
        if family == "posters":
            from .poster_manager import _provider_for
            return dict(_provider_for(url) or {})
        if family == "backdrops":
            from .backdrop_manager import _provider_for
            return dict(_provider_for(url) or {})
        if family == "logos":
            from .logo_manager import _provider_for
            return dict(_provider_for(url) or {})
    except Exception:
        pass
    return {}


def _is_title_logo(url, family, transparent):
    if family != "logos":
        return False
    if transparent is not None:
        return bool(transparent)
    # TMDb images are title logos in this family, while provider/package logos
    # can legitimately be opaque PNG/JPEG (do NOT reject those).
    from urllib.parse import urlsplit
    try:
        host = (urlsplit(url).hostname or "").lower()
        return host == "image.tmdb.org"
    except (ValueError, TypeError):
        return False


def request(url, kind, callback=None, priority=0, errback=None,
            source=None, transparent=None):
    if _queue.is_app_exiting():
        return ""
    url = _queue.normalise_url(url)
    if not url:
        return ""
    family = _queue._media_cache_kind(kind)
    canonical, _ = _queue._canonical_tmdb_artwork(url, family)
    clearlogo = _is_title_logo(canonical, family, transparent)
    path = _queue.artwork_path(canonical, family)
    existing = _queue._cached_artwork_core(canonical, family)
    if existing and clearlogo:
        try:
            from .genre_ultra_artwork import _logo_cache_usable
            if not _logo_cache_usable(existing, canonical):
                existing = ""
        except Exception:
            existing = ""

    # Do not enter the generic queue if the identical artwork is already
    # being fetched by Ultra; this is only a dedupe check, never a queue change.
    if callback is None:
        try:
            from .genre_ultra_artwork import is_pending as ultra_is_pending
            if not clearlogo and ultra_is_pending(canonical, family):
                return path
        except Exception:
            pass
        return _queue._request_artwork_core(canonical, family, None, priority, errback)

    # Generic prefetch may already have queued this exact cache file before a
    # visible card appears. Attach to that existing job instead of issuing a
    # second network GET through Ultra. _request_artwork_core already promotes
    # a visible callback for a queued low-priority prefetch.
    # Stalker images may require MAG headers that the generic prefetch
    # downloader does not possess. Never join that unauthenticated request.
    provider = _source_for(url, family, source)
    auth_required = str(provider.get("type") or "").lower() == "stalker"
    if not clearlogo and not auth_required and path in getattr(_queue, "_jobs", {}):
        return _queue._request_artwork_core(canonical, family, callback,
                                            priority, errback)

    try:
        from twisted.internet import reactor
        if not getattr(reactor, "running", False):
            raise RuntimeError("Enigma2 reactor is not running")
    except (ImportError, RuntimeError):
        return _queue._request_artwork_core(canonical, family, callback,
                                            priority, errback)

    def on_main(fn, value):
        if not _queue.is_app_exiting() and callable(fn):
            reactor.callFromThread(fn, value)

    if existing:
        on_main(callback, existing)
        return existing

    def done(file_path):
        if callback and not _queue.is_app_exiting():
            callback(file_path)

    def fallback(_path):
        if _queue.is_app_exiting():
            return
        if clearlogo:
            # A failed transparency check must NEVER be replaced with an
            # opaque image by the legacy queue.
            if errback:
                errback(_path)
            return
        _queue._request_artwork_core(canonical, family, callback, priority, errback)

    try:
        from .genre_ultra_artwork import request as ultra_request, request_transparent_logo
        if clearlogo:
            request_transparent_logo(canonical, provider, done, fallback, on_main)
        else:
            ultra_request(canonical, family, provider, done, fallback, on_main)
    except Exception:
        if clearlogo:
            # Let the existing GIF/PNG title-logo loader run if the Ultra
            # component is not installed; do not interrupt the whole screen.
            return _queue._request_artwork_core(canonical, family, callback,
                                                priority, errback)
        return _queue._request_artwork_core(canonical, family, callback,
                                            priority, errback)
    return path
