# -*- coding: utf-8 -*-
from __future__ import absolute_import
import os, re, json, unicodedata

PLUGIN_PATH = os.path.dirname(__file__)
ALIASES_FILE = os.path.join(PLUGIN_PATH, "package_logo_aliases.json")
LOGO_DIR = os.path.join(PLUGIN_PATH, "skins", "genre", "package_badges")
_CACHE = None

def _norm(value):
    text = str(value or "").strip().lower()
    try:
        text = unicodedata.normalize("NFKC", text)
    except Exception:
        pass
    text = text.replace("_", " ").replace("-", " ").replace("|", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text

def load_aliases():
    global _CACHE
    if isinstance(_CACHE, dict):
        return _CACHE
    try:
        with open(ALIASES_FILE, "r") as handle:
            data = json.load(handle)
        _CACHE = data if isinstance(data, dict) else {}
    except Exception:
        _CACHE = {}
    return _CACHE

def resolve_package_logo(name, kind=None):
    text = _norm(name)
    k = str(kind or "").lower()
    is_series = k in ("series", "tv", "shows", "tvshows")
    is_movies = k in ("vod", "movies", "movie", "film")
    compact = re.sub(r"[^a-z0-9+\u0600-\u06ff]+", "", text)
    for key, spec in load_aliases().items():
        if not isinstance(spec, dict):
            continue
        for alias in spec.get("aliases") or []:
            a = _norm(alias)
            if not a:
                continue
            ac = re.sub(r"[^a-z0-9+\u0600-\u06ff]+", "", a)
            # Exact, token/phrase containment, then compact containment.
            if text == a or a in text or (ac and ac in compact):
                filename = str(spec.get("file") or "")
                # Protect series-specific branding in the legacy alias fallback
                # too; substring aliases like 'arabic movies' must not win merely
                # because they appear earlier in the aliases manifest.
                if is_series and key in ("movies", "recent_movies", "foreign", "indian", "asia"):
                    key = "series" if key != "recent_movies" else "recent_series"
                    filename = "badge_%s_full.png" % key
                elif is_movies and key in ("series", "recent_series"):
                    key = "movies" if key == "series" else "recent_movies"
                    filename = "badge_%s_full.png" % key
                path = os.path.join(LOGO_DIR, filename) if filename else ""
                return (key, path if path and os.path.isfile(path) else "")
    return ("", "")

def package_logo_path(name, kind=None):
    """Return GENRE's same asset for the same category label.

    Preserve legacy aliases as a fallback for atypical provider names that
    the common badge matcher does not recognize (e.g. provider abbreviations).
    """
    try:
        from .genre_package_badges import resolve_package_badge
        logo, _year = resolve_package_badge(name, kind)
        if logo:
            return logo
    except Exception:
        pass
    return resolve_package_logo(name, kind)[1]

def package_provider_key(name):
    return resolve_package_logo(name)[0]


def package_logo_for_key(key):
    """Return a logo path for a canonical manifest key."""
    spec = load_aliases().get(str(key or "").strip().lower()) or {}
    filename = str(spec.get("file") or "") if isinstance(spec, dict) else ""
    path = os.path.join(LOGO_DIR, filename) if filename else ""
    return path if path and os.path.isfile(path) else ""


# Packages-only vintage logos (220x84 original PNG files).  Leave GENRE badges
# and the default provider-logo API untouched for other screens.
_LEGACY_ALIASES_FILE = os.path.join(PLUGIN_PATH, "package_logo_aliases_legacy.json")
_LEGACY_LOGO_DIR = os.path.join(PLUGIN_PATH, "resources", "package_logos")
_LEGACY_CACHE = None


def _legacy_aliases():
    global _LEGACY_CACHE
    if _LEGACY_CACHE is None:
        try:
            with open(_LEGACY_ALIASES_FILE, "r") as handle:
                data = json.load(handle)
            _LEGACY_CACHE = data if isinstance(data, dict) else {}
        except Exception:
            _LEGACY_CACHE = {}
    return _LEGACY_CACHE


def _legacy_key_path(key):
    spec = _legacy_aliases().get(str(key or "").strip().lower()) or {}
    filename = str(spec.get("file") or "") if isinstance(spec, dict) else ""
    path = os.path.join(_LEGACY_LOGO_DIR, filename) if filename else ""
    return path if path and os.path.isfile(path) else ""


def _legacy_package_logo(name, kind=None):
    text = _norm(name)
    compact = re.sub(r"[^a-z0-9+\u0600-\u06ff]+", "", text)
    k = str(kind or "").strip().lower()
    series = k in ("series", "tv", "shows", "tvshows", "tv_shows")
    movies = k in ("vod", "movies", "movie", "films", "film")
    for key, spec in _legacy_aliases().items():
        if not isinstance(spec, dict):
            continue
        for alias in spec.get("aliases") or []:
            alias = _norm(alias)
            if not alias:
                continue
            ac = re.sub(r"[^a-z0-9+\u0600-\u06ff]+", "", alias)
            if text == alias or alias in text or (ac and ac in compact):
                # Never put a MOVIES-labelled logo on a TV-series package
                # or a SERIES-labelled logo on a movie collection.
                if series and key in ("movies", "recent_movies", "foreign", "asia", "indian"):
                    key = "recent_series" if key == "recent_movies" else "series"
                elif movies and key in ("series", "recent_series"):
                    key = "recent_movies" if key == "recent_series" else "movies"
                return _legacy_key_path(key)
    return ""


def package_browser_logo_path(name, kind=None):
    return _legacy_package_logo(name, kind)


def package_browser_logo_for_key(key):
    return _legacy_key_path(key)


def package_popup_logo_path(name, kind=None):
    return _legacy_package_logo(name, kind)
