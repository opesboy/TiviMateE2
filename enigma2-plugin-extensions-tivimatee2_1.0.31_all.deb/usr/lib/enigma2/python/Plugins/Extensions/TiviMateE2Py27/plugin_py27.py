# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import monotonic, thread_factory
# Load TiviMateE2's namespaced player keymap (Ultra/XStreamity-style TV key mapping).
try:
    import os
    import keymapparser
    _KEYMAP = os.path.join(os.path.dirname(__file__), "keymap.xml")
    if os.path.isfile(_KEYMAP):
        keymapparser.readKeymap(_KEYMAP)
except Exception:
    pass

# No Python 2.7 feature modules are loaded at Enigma2 boot.
# This experimental plugin initializes only after a user opens it.
from Plugins.Plugin import PluginDescriptor

# Do not import the complete UI, seven large UI source fragments, and 24-poster
# GENRE browser on every Enigma2 boot.  They are only needed when TiviMate
# itself opens, not for PluginDescriptor, web service or background EPG jobs.
# This cuts the plugin's idle baseline without disabling any menu or page.


def _sync_epgimport(background=True, refresh_local=True, **kwargs):
    """Refresh TiviMateE2 internal Xtream EPG only.

    r448: EPGImport integration is intentionally disabled.  The historical
    function name is kept to avoid changing callers/hooks, but it now only
    refreshes the plugin's own HDD/USB XMLTV -> epg.json cache.
    """
    try:
        if not refresh_local:
            return
        import json
        from .core import get_sources, _source_key
        from .storage import data_path
        from .epg_local import refresh_source_epg
        sources = get_sources()
        with open(data_path("active_source.json"), "r") as handle:
            active_key = str((json.load(handle) or {}).get("key") or "")
        # No fallback to the first source: a missing/stale selection should
        # never trigger a different server's XMLTV download.
        selected = next((src for src in sources if _source_key(src) == active_key), None)
        if selected:
            refresh_source_epg(selected, background=background)
    except Exception:
        pass



def _session_start(reason=0, session=None, **kwargs):
    """Session maintenance: EPG refresh plus the lightweight LAN web manager."""
    if reason not in (0, None):
        try:
            from .memory_manager import stop as stop_memory_manager
            stop_memory_manager()
        except Exception:
            pass
        try:
            from .web_manager import stop_web_manager
            stop_web_manager()
        except Exception:
            pass
        return
    # Compile only built-in UI fragment sources in a background worker after
    # the session starts. No Enigma widget is created/imported on that thread.
    # When the user opens the plugin, the GUI can execute the prepared code.
    try:
        from .ui_preload import start_prewarm
        start_prewarm()
    except Exception:
        pass
    # Never auto-download XMLTV for the configured server list at Enigma boot.
    # EPG remains cache-first and is refreshed only for the source opened in
    # Live (ensure_source_epg) or explicitly refreshed in its own settings.
    # In particular, adding ten servers must not cause ten XMLTV workers.
    try:
        from .memory_manager import start as start_memory_manager
        start_memory_manager()
    except Exception:
        pass
    # Web Manager targets port 80 for IP-only QR access. Do not reserve that
    # port at boot ahead of OpenWebif; launch on entering the web UI instead.


def main(session, **kwargs):
    """Open TiviMate E2 without duplicate source reads, and record stage timings."""
    # DreamOS/Merlin/Gemini crash (font.cpp ASSERTION) when a skin lacks a
    # font face used by the plugin XML ("Bold" on Default-FHD). Register
    # missing faces once, before any plugin screen is built.
    try:
        from .font_guard import ensure_fonts
        ensure_fonts()
    except Exception:
        pass
    import time
    started = monotonic()
    # SQLite is optional on Enigma2 images. Cache and category filters already
    # support persistent JSON; core selects the original legacy Stalker backend
    # if UltraStalker's SQLite-backed store is unavailable. Never block the
    # Home/Xtream/M3U UI or attempt a package-feed install on launch.
    # UI module imports once per Enigma process. The expensive UI fragment
    # compilation is prewarmed after session start, never in a GUI widget.
    # Only touch private Python2 temporary cache when the user opens this build.
    try:
        from .cache_manager import migrate_legacy_tmp_cache, cleanup_stale_temp_files
        migrate_legacy_tmp_cache()
        cleanup_stale_temp_files()
    except Exception:
        pass
    # Images without a CA bundle / python-requests (VTi, older OpenPLi/BH):
    # bundled CA for every TLS client, stdlib requests stand-in for subtitles.
    try:
        from .py27_ssl import install_ca_environment
        install_ca_environment()
    except Exception:
        pass
    try:
        from .requests_compat import install as install_requests_compat
        install_requests_compat()
    except Exception:
        pass
    # VTi: old PIL/Pillow lacks APIs used by actor circles, picons and logos.
    try:
        from .pil_compat import install_pil_compat
        install_pil_compat()
    except Exception:
        pass
    # VTi test: sanitize only our screens before the legacy skin parser.
    from .vti_compat import install_vti_skin_compat
    install_vti_skin_compat()
    from . import ui as _tivimate_ui
    imported = monotonic()
    from .genre_page import install_genre_page
    install_genre_page(_tivimate_ui)
    # Dreambox DM900/DM920 colour LCD: show TiviMate picons and cached VOD
    # posters on its separate 400x240 front panel (not the TV skin).
    try:
        from .dream_frontpanel import install_frontpanel
        install_frontpanel(_tivimate_ui)
    except Exception:
        # A missing display must never prevent TiviMate from opening.
        pass
    genre_ready = monotonic()
    # Normalize Python2 plugin-owned screen coordinate systems before creating
    # a window. Unlike global skin edits this never touches DreamOS skin.xml.
    from .font_preferences import refresh_loaded_screens
    refresh_loaded_screens()
    # Removed redundant _sync_epgimport(refresh_local=False): it did no EPG
    # update but read and mirrored the entire server list on every app launch.
    # Session-start maintenance remains responsible for background EPG refresh.
    try:
        import threading
        thread_factory(target=_tivimate_ui.run_auto_backup_if_due,
                         kwargs={"force": False}, daemon=True).start()
    except Exception:
        pass
    session.open(_tivimate_ui.TiviMateE2Home)
    # Do not write startup diagnostics into /tmp.

def _py27_build_label():
    """Read this installed package's marker, not an obsolete hardcoded label."""
    try:
        import os
        marker = os.path.join(os.path.dirname(__file__), "PY27_BUILD.txt")
        with open(marker, "r") as handle:
            return handle.read().strip()[:72] or "PY27-1.0.31"
    except (IOError, OSError):
        return "PY27-1.0.31"


def safe_main(session, **kwargs):
    """Experimental branch: a failed import should show an error, not crash boot."""
    try:
        return main(session, **kwargs)
    except Exception as exc:
        where = ""
        try:
            import sys, os, traceback, time
            frames = traceback.extract_tb(sys.exc_info()[2])
            if frames:
                last = frames[-1]
                where = " (%s:%d)" % (os.path.basename(last[0]), last[1])
            with open("/home/root/tivimatee2_start_error.log", "a") as log:
                log.write("%s %s\n%s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"),
                                             _py27_build_label(), traceback.format_exc()))
        except Exception:
            pass
        try:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, "TiviMate E2 [%s] could not start: %s%s" % (_py27_build_label(), str(exc)[:150], where), MessageBox.TYPE_ERROR, timeout=15)
        except Exception:
            pass
        return None


def menu(menuid, **kwargs):
    """Expose TiviMate IPTV in the Enigma2 main menu."""
    if menuid != "mainmenu":
        return []
    return [("TiviMate E2", safe_main, "TiviMateE2Py27", 45)]


def Plugins(**kwargs):
    # DreamOS/Merlin/Gemini crash (font.cpp ASSERTION) when a skin lacks a
    # font face used by the plugin XML ("Bold" on Default-FHD). Register
    # missing faces once, before any plugin screen is built.
    try:
        from .font_guard import ensure_fonts
        ensure_fonts()
    except Exception:
        pass
    return [
        PluginDescriptor(
            name="TiviMate E2",
            description="TiviMate IPTV",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icons/plugin.png",
            fnc=safe_main,
        ),
        PluginDescriptor(
            where=PluginDescriptor.WHERE_MENU,
            fnc=menu,
        ),
    ]
