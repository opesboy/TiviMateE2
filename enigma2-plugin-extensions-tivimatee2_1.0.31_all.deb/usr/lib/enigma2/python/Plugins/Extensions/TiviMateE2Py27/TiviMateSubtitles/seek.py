# -*- coding: UTF-8 -*-
#################################################################################
#
#    This module is part of SubsSupport plugin
#    Coded by mx3L (c) 2014
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#################################################################################

from __future__ import absolute_import
from Plugins.Extensions.TiviMateE2Py27.compat import ensure_dir
from Plugins.Extensions.TiviMateE2Py27.py27_compat import thread_factory
import os
import shutil
import socket
import threading
import time
import traceback
import zipfile
import re
try:
    from .parsers.ass2srt import Ass2srt
except (ValueError, ImportError):
    from parsers.ass2srt import Ass2srt


try:
    from .seekers import SubtitlesDownloadError, SubtitlesSearchError, \
        SubtitlesErrors, Addic7edSeeker, SubtitlesmoraSeeker, NovalermoraSeeker, ElsubtitleSeeker, SubtitlecatSeeker, OpenSubtitles2Seeker, OpenSubtitlesComFNCSeeker, TitulkyComSeeker, \
        PodnapisiSeeker, Subf2mSeeker, LocalDriveSeeker, IndexsubtitleSeeker, SubsytsSeeker, MoviesubtitlesSeeker, Sub_Scene_comSeeker, SubdlSeeker, \
         TitloviSeeker, MySubsSeeker, SubsourceSeeker, FoursubSeeker, YtssubsSeeker, WyzieSeeker, TvsubsSeeker
    from .seekers.seeker import BaseSeeker
    from .seekers.utilities import languageTranslate, langToCountry, \
        getCompressedFileType, detectSearchParams
    from .utils import SimpleLogger, toString
except (ValueError, ImportError):
    from seekers import SubtitlesDownloadError, SubtitlesSearchError, \
        SubtitlesErrors, Addic7edSeeker, SubtitlesmoraSeeker, NovalermoraSeeker, ElsubtitleSeeker, SubtitlecatSeeker, OpenSubtitles2Seeker, OpenSubtitlesComFNCSeeker, TitulkyComSeeker, \
        PodnapisiSeeker, Subf2mSeeker, LocalDriveSeeker, IndexsubtitleSeeker, SubsytsSeeker, MoviesubtitlesSeeker, Sub_Scene_comSeeker, SubdlSeeker, \
         TitloviSeeker, MySubsSeeker, SubsourceSeeker, FoursubSeeker, YtssubsSeeker, WyzieSeeker, TvsubsSeeker
    from seekers.seeker import BaseSeeker
    from seekers.utilities import languageTranslate, langToCountry, \
        getCompressedFileType, detectSearchParams
    from utils import SimpleLogger, toString

import six


SUBTITLES_SEEKERS = []
SUBTITLES_SEEKERS.append(LocalDriveSeeker)
# Current no-API providers first (2026 refresh).
SUBTITLES_SEEKERS.append(MoviesubtitlesSeeker)
SUBTITLES_SEEKERS.append(SubtitlesmoraSeeker)
SUBTITLES_SEEKERS.append(Subf2mSeeker)
SUBTITLES_SEEKERS.append(Addic7edSeeker)
SUBTITLES_SEEKERS.append(SubtitlecatSeeker)
SUBTITLES_SEEKERS.append(TvsubsSeeker)
SUBTITLES_SEEKERS.append(PodnapisiSeeker)
# Independent API providers.
SUBTITLES_SEEKERS.append(SubdlSeeker)
# Keep the legacy Os.org.fnc ID and settings intact.
SUBTITLES_SEEKERS.append(OpenSubtitles2Seeker)
# Additional Os.com.fnc entry, using the same maintained REST backend.
SUBTITLES_SEEKERS.append(OpenSubtitlesComFNCSeeker)
SUBTITLES_SEEKERS.append(WyzieSeeker)
SUBTITLES_SEEKERS.append(SubsourceSeeker)
# Remaining/legacy providers are still available, but searched after the current set.
SUBTITLES_SEEKERS.append(SubsytsSeeker)
SUBTITLES_SEEKERS.append(ElsubtitleSeeker)
SUBTITLES_SEEKERS.append(MySubsSeeker)
SUBTITLES_SEEKERS.append(FoursubSeeker)
SUBTITLES_SEEKERS.append(IndexsubtitleSeeker)
SUBTITLES_SEEKERS.append(TitulkyComSeeker)
SUBTITLES_SEEKERS.append(TitloviSeeker)
SUBTITLES_SEEKERS.append(Sub_Scene_comSeeker)
SUBTITLES_SEEKERS.append(NovalermoraSeeker)


def _safe_error_message(error):
    """Encode provider failure text safely for Python 2.7 IPC/logging."""
    for candidate in (getattr(error, 'msg', None), getattr(error, 'message', None)):
        if candidate:
            try:
                return toString(candidate)
            except Exception:
                pass
    try:
        return toString(six.text_type(error))
    except Exception:
        return error.__class__.__name__


class ErrorSeeker(BaseSeeker):
    def __init__(self, wseeker_cls, *args, **kwargs):
        self.id = wseeker_cls.id
        self.error = wseeker_cls.error
        self.provider_name = wseeker_cls.provider_name
        self.supported_langs = wseeker_cls.supported_langs
        self.description = getattr(wseeker_cls, 'description', "")
        self.tvshow_search = getattr(wseeker_cls, 'tvshow_search', True)
        self.movie_search = getattr(wseeker_cls, 'movie_search', True)
        self.default_settings = getattr(wseeker_cls, 'default_settings', dict())
        BaseSeeker.__init__(self, *args, **kwargs)

    def close(self):
        pass


class SubsSeeker(object):
    SUBTILES_EXTENSIONS = ['.srt', '.sub', '.ass']

    def __init__(self, download_path, tmp_path, captcha_cb, delay_cb, message_cb, settings=None, settings_provider_cls=None, settings_provider_args=None, debug=False, providers=None):
        self.log = SimpleLogger(self.__class__.__name__, log_level=debug and SimpleLogger.LOG_DEBUG or SimpleLogger.LOG_INFO)
        self.download_path = toString(download_path)
        self.tmp_path = toString(tmp_path)
        self.seekers = []
        providers = providers or SUBTITLES_SEEKERS
        for seeker in providers:
            provider_id = seeker.id
            default_settings = seeker.default_settings
            default_settings['enabled'] = {'type': 'yesno', 'default': True, 'label': 'Enabled', 'pos': -1}
            if provider_id == 'opensubtitles':
                default_settings = {'user_agent': {'default': 'subssupportuseragent', 'type': 'text', 'pos': 0, 'label': 'User_agent'}, 'enabled': {'default': True, 'type': 'yesno', 'pos': -1, 'label': 'Enabled'}}
            if settings_provider_cls is not None:
                settings = None
                settings_provider = settings_provider_cls(provider_id, default_settings, settings_provider_args)
                if hasattr(seeker, 'error') and seeker.error is not None:
                    # An import failure must not rewrite the user's enabled choice.
                    # ErrorSeeker keeps this provider unavailable until the import succeeds.
                    self.seekers.append(ErrorSeeker(seeker, tmp_path, download_path, settings, settings_provider, captcha_cb, delay_cb, message_cb))
                else:
                    self.seekers.append(seeker(tmp_path, download_path, settings, settings_provider, captcha_cb, delay_cb, message_cb))
            elif settings is not None and provider_id in settings:
                settings_provider = None
                if hasattr(seeker, 'error') and seeker.error is not None:
                    self.seekers.append(ErrorSeeker(seeker, tmp_path, download_path, settings, settings_provider, captcha_cb, delay_cb, message_cb))
                else:
                    self.seekers.append(seeker(tmp_path, download_path, settings[provider_id], settings_provider, captcha_cb, delay_cb, message_cb))
            else:
                settings = None
                settings_provider = None
                if hasattr(seeker, 'error') and seeker.error is not None:
                    self.seekers.append(ErrorSeeker(seeker, tmp_path, download_path, settings, settings_provider, captcha_cb, delay_cb, message_cb))
                else:
                    self.seekers.append(seeker(tmp_path, download_path, settings, settings_provider, captcha_cb, delay_cb, message_cb))


    def getSubtitlesSimple(self, updateCB=None, title=None, filepath=None, langs=None):
        title, year, tvshow, season, episode = detectSearchParams(title or filepath)
        seekers = self.getProviders(langs)
        return self.getSubtitles(seekers, updateCB, title, filepath, langs, year, tvshow, season, episode)

    def getSubtitles(self, providers, updateCB=None, title=None, filepath=None, langs=None, year=None, tvshow=None, season=None, episode=None, timeout=10):
        self.log.info('getting subtitles list - title: %s, filepath: %s, year: %s, tvshow: %s, season: %s, episode: %s' % (
            toString(title), toString(filepath), toString(year), toString(tvshow), toString(season), toString(episode)))
        subtitlesDict = {}
        threads = []
        # r306: protect low-powered Enigma2 receivers from a network storm.
        # BLUE search still queries the same providers, but at most four provider
        # workers may perform network/parser work at the same time.  The search
        # already runs in the external tivimate_provider_search.py process, so
        # this cap reduces CPU/TLS/socket pressure without touching the GUI/player.
        # r337: honor the caller/provider timeout.  The previous hard 8-second
        # ceiling caused slower providers to be cut off before returning results.
        try:
            timeout = float(timeout)
        except Exception:
            timeout = 10.0
        previous_socket_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(timeout)
        lock = threading.Lock()
        provider_slots = threading.BoundedSemaphore(4)

        def _boundedSearch(*args):
            provider_slots.acquire()
            try:
                return self._searchSubtitles(*args)
            finally:
                provider_slots.release()
        if len(providers) == 1:
            provider = providers[0]
            if isinstance(provider, six.string_types):
                provider = self.getProvider(providers[0])
            if provider is None:
                self.log.error('unknown subtitle provider ID, skipping')
                return subtitlesDict
            if provider.error is not None:
                self.log.debug("provider '%s' has 'error' flag set, skipping...", provider)
                return subtitlesDict
            else:
                self._searchSubtitles(lock, subtitlesDict, updateCB, provider, title, filepath, langs, season, episode, tvshow, year)
        else:
            for provider in providers:
                if isinstance(provider, six.string_types):
                    provider = self.getProvider(provider)
                if provider is None:
                    self.log.error('unknown subtitle provider ID, skipping')
                    continue
                if provider.error is not None:
                    self.log.debug("provider '%s' has 'error' flag set, skipping...", provider)
                else:
                    threads.append(thread_factory(target=_boundedSearch, args=(lock, subtitlesDict, updateCB, provider, title, filepath, langs, season, episode, tvshow, year)))
            for t in threads:
                t.setDaemon(True)
                t.start()
            working = True
            while working:
                working = False
                time.sleep(0.5)
                for t in threads:
                    working = working or t.is_alive()
        socket.setdefaulttimeout(previous_socket_timeout)
        return subtitlesDict

    def getSubtitlesList(self, subtitles_dict, provider=None, langs=None, synced=False, nonsynced=False):
        """Merge provider results, tolerating incomplete legacy FNC metadata.

        Some providers return language_name without country (or the reverse),
        omit sync, or send malformed entries.  One incomplete row should not
        cause the entire search-result screen to fail.
        """
        subtitles_list = []
        for provider_id, payload in (subtitles_dict or {}).items():
            if provider and provider != provider_id:
                continue
            if not isinstance(payload, dict):
                continue
            for sub in payload.get('list', []) or []:
                if not isinstance(sub, dict):
                    continue
                if not sub.get('provider'):
                    sub['provider'] = provider_id
                if not sub.get('language_name'):
                    sub['language_name'] = sub.get('language') or sub.get('lang') or sub.get('country') or 'Unknown'
                if not sub.get('country'):
                    sub['country'] = (langToCountry(languageTranslate(sub.get('language_name'), 0, 2)) or
                                      sub.get('lang') or '')
                sub.setdefault('sync', False)
                subtitles_list.append(sub)
        if synced:
            subtitles_list = [sub for sub in subtitles_list if sub.get('sync')]
        elif nonsynced:
            subtitles_list = [sub for sub in subtitles_list if not sub.get('sync')]
        if langs:
            valid_languages = [languageTranslate(lang, 0, 2) for lang in langs]
            subtitles_list = [sub for sub in subtitles_list
                              if languageTranslate(sub.get('language_name'), 0, 2) in valid_languages]
        return subtitles_list

    def sortSubtitlesList(self, subtitles_list, langs=None, sort_langs=False, sort_rank=False, sort_sync=False, sort_provider=False):
        def sortLangs(x):
            for idx, lang in enumerate(langs):
                if languageTranslate(x['language_name'], 0, 2) == lang:
                    return idx
            return len(langs)
        if langs and sort_langs:
            return sorted(subtitles_list, key=sortLangs)
        if sort_provider:
            return sorted(subtitles_list, key=lambda x: x['provider'])
        if sort_rank:
            return subtitles_list
        if sort_sync:
            return sorted(subtitles_list, key=lambda x: x['sync'], reverse=True)
        return subtitles_list

    def downloadSubtitle(self, selected_subtitle, subtitles_dict, choosefile_cb, path=None, fname=None, overwrite_cb=None, settings=None):
        self.log.info('downloading subtitle "%s" with settings "%s"' % (selected_subtitle['filename'], toString(settings) or {}))
        if settings is None:
            settings = {}
        seeker = None
        for provider_id in subtitles_dict.keys():
            if selected_subtitle in subtitles_dict[provider_id]['list']:
                seeker = self.getProvider(provider_id)
                break
        if seeker is None:
            self.log.error('provider for "%s" subtitle was not found', selected_subtitle['filename'])
        lang, filepath = seeker.download(subtitles_dict[provider_id], selected_subtitle)[1:3]
        if not filepath or not os.path.isfile(filepath):
            raise SubtitlesDownloadError("download failed (invalid temp file path): %s" % toString(filepath))
        compressed = getCompressedFileType(filepath)
        if compressed:
            subfiles = self._unpack_subtitles(filepath, self.tmp_path)
        else:
            subfiles = [filepath]
        subfiles = [toString(s) for s in subfiles]
        if len(subfiles) == 0:
            self.log.error("no subtitles were downloaded!")
            raise SubtitlesDownloadError(msg="[error] no subtitles were downloaded")
        elif len(subfiles) == 1:
            self.log.debug('found one subtitle: "%s"', str(subfiles))
            subfile = subfiles[0]
        else:
            self.log.debug('found more subtitles: "%s"', str(subfiles))
            subfile = choosefile_cb(subfiles)
            if subfile is None:
                self.log.debug('no subtitles file choosed!')
                return
            self.log.debug('selected subtitle: "%s"', subfile)
        ext = os.path.splitext(subfile)[1]
        # if ext == '.ass':
            # conv = Ass2srt(subfile)
            # srt_path = conv.output_name()       # same base name, .srt
            # conv.to_srt(name=srt_path)          # write .srt
            # subfile = srt_path
            # ext = '.srt'
        if ext not in self.SUBTILES_EXTENSIONS:
            ext = os.path.splitext(toString(selected_subtitle['filename']))[1]
            if ext not in self.SUBTILES_EXTENSIONS:
                ext = '.srt'
        if fname is None:
            filename = os.path.basename(subfile)
            save_as = settings.get('save_as', 'default')
            if save_as == 'version':
                self.log.debug('filename creating by "version" setting')
                filename = toString(selected_subtitle['filename'])
				# Sanitize the filename to remove slashes and double dots
                filename = re.sub(r'[\\/]', '_', filename)  # Replace slashes with underscores
                filename = re.sub(r'\.\.', '.', filename)  # Replace double dots with a single dot
                if os.path.splitext(filename)[1] not in self.SUBTILES_EXTENSIONS:
                    filename = os.path.splitext(filename)[0] + ext
            elif save_as == 'video':
                self.log.debug('filename creating by "video" setting')
                videopath = toString(subtitles_dict[seeker.id]['params'].get('filepath'))
                filename = os.path.splitext(os.path.basename(videopath))[0] + ext

            if settings.get('lang_to_filename', False):
                lang_iso639_1_2 = toString(languageTranslate(lang, 0, 2))
                self.log.debug('appending language "%s" to filename', lang_iso639_1_2)
                filename, ext = os.path.splitext(filename)
                filename = "%s.%s%s" % (filename, lang_iso639_1_2, ext)
        else:
            self.log.debug('using provided filename')
            filename = toString(fname) + ext
        self.log.debug('filename: "%s"', filename)
        download_path = os.path.join(toString(self.download_path), filename)
        if path is not None:
            self.log.debug('using custom download path: "%s"', path)
            download_path = os.path.join(toString(path), filename)
        self.log.debug('download path: "%s"', download_path)

		# Ensure the destination directory exists
        ensure_dir(os.path.dirname(download_path))

        if os.path.isfile(download_path) and overwrite_cb is not None:
            ret = overwrite_cb(download_path)
            if ret is None:
                self.log.debug('overwrite cancelled, returning temp path')
                return subfile
            elif not ret:
                self.log.debug('not overwriting, returning temp path')
                return subfile
            elif ret:
                self.log.debug('overwriting')
                try:
                    shutil.move(subfile, download_path)
                    return download_path
                except Exception as e:
                    self.log.error('moving "%s" to "%s" - %s' % (
						os.path.split(subfile)[-2:],
						os.path.split(download_path)[-2:], str(e)))
                    return subfile
        try:
            shutil.move(subfile, download_path)
        except Exception as e:
            self.log.error('moving "%s" to "%s" - %s', (
				os.path.split(subfile)[-2:],
				os.path.split(download_path)[-2:]), str(e))
            return subfile
        return download_path

    def getProvider(self, provider_id):
        for s in self.seekers:
            if s.id == provider_id:
                return s

    def getProviders(self, langs=None, movie=True, tvshow=True):
        """Stable provider priority, excluding disabled or broken imports.

        Preserve SUBTITLES_SEEKERS registration order. A set used to reshuffle
        the search order at each run and could push slow/legacy sites ahead of
        providers with working APIs. ErrorSeeker cannot deliver callbacks, so
        it must not be counted among the active jobs.
        """
        wanted = set(langs or ())
        providers = []
        for provider in self.seekers:
            if getattr(provider, 'error', None) is not None:
                continue
            try:
                if not provider.settings_provider.getSetting('enabled'):
                    continue
            except Exception:
                continue
            if wanted and not wanted.intersection(provider.supported_langs):
                continue
            if (movie and provider.movie_search) or (tvshow and provider.tvshow_search):
                providers.append(provider)
        # Os.org.fnc and Os.com.fnc use the same OpenSubtitles.com API.
        # Never issue two copies of a search, especially on slow Enigma2 boxes.
        legacy = next((p for p in providers if p.id == 'opensubtitles.com'), None)
        modern = next((p for p in providers if p.id == 'os.com.fnc'), None)
        if legacy is not None and modern is not None:
            def has_key(p):
                try:
                    return bool(str(p.settings_provider.getSetting('OpenSubtitles_API_KEY')).strip())
                except Exception:
                    return False
            # Prefer the modern entry when it has a key.  Otherwise preserve
            # the existing API settings and searches of the older entry.
            if has_key(modern) or not has_key(legacy):
                providers.remove(legacy)
            else:
                providers.remove(modern)
        return providers


    def _filterWrongMovieYear(self, subtitles, requested_year, tvshow):
        """Preserve real provider matches even when their release year differs.

        Providers frequently put a video *release* year rather than the film
        year in filenames.  Year is used for ranking in the result screen;
        dropping rows here made successful Arabic provider searches look empty.
        """
        return subtitles

    def _searchSubtitles(self, lock, subtitlesDict, updateCB, seeker, title, filepath, langs, season, episode, tvshow, year):
        # r488 diagnostic only: record each provider start/result/failure in the
        # existing /tmp/tivimatesubtitles.log owned by tivimate_provider_search.py.
        # No extra HTTP calls, timers, hooks, retries or search-path changes.
        started = time.time()
        try:
            print("[TiviMateProviderDiag] START id=%s name=%s title=%r year=%r tvshow=%r season=%r episode=%r langs=%r" % (
                getattr(seeker, 'id', ''), getattr(seeker, 'provider_name', ''),
                title, year, tvshow, season, episode, langs))
        except Exception:
            pass
        try:
            subtitles = seeker.search(title, filepath, langs, season, episode, tvshow, year)
            subtitles = self._filterWrongMovieYear(subtitles, year, tvshow)
        except Exception as e:
            elapsed = time.time() - started
            try:
                print("[TiviMateProviderDiag] FAIL id=%s name=%s elapsed=%.2fs error=%s: %s" % (
                    getattr(seeker, 'id', ''), getattr(seeker, 'provider_name', ''),
                    elapsed, e.__class__.__name__, str(e)))
            except Exception:
                pass
            traceback.print_exc()
            with lock:
                subtitlesDict[seeker.id] = {'message': _safe_error_message(e), 'status': False, 'list': []}
                if updateCB is not None:
                    updateCB(seeker.id, False, e)
        else:
            elapsed = time.time() - started
            try:
                items = subtitles.get('list') or [] if isinstance(subtitles, dict) else []
                message = (subtitles.get('msg') or subtitles.get('message') or '') if isinstance(subtitles, dict) else ''
                print("[TiviMateProviderDiag] DONE id=%s name=%s elapsed=%.2fs results=%d message=%r" % (
                    getattr(seeker, 'id', ''), getattr(seeker, 'provider_name', ''),
                    elapsed, len(items), message))
            except Exception:
                pass
            with lock:
                subtitles['status'] = True
                subtitlesDict[seeker.id] = subtitles
                if updateCB is not None:
                    updateCB(seeker.id, True, subtitles)

    def _unpack_subtitles(self, filepath, dest_dir, max_recursion=3):
        compressed = getCompressedFileType(filepath)
        if compressed == 'zip':
            self.log.debug('found "zip" archive, unpacking...')
            subfiles = self._unpack_zipsub(filepath, dest_dir)
        elif compressed == 'rar':
            self.log.debug('found "rar" archive, unpacking...')
            subfiles = self._unpack_rarsub(filepath, dest_dir)
        else:
            self.log.error('unsupported archive - %s', compressed)
            raise Exception(_("unsupported archive %s", compressed))
        for s in subfiles:
            if os.path.splitext(s)[1] in ('.rar', '.zip') and max_recursion > 0:
                subfiles.extend(self._unpack_subtitles(s, dest_dir, max_recursion - 1))
        subfiles = filter(lambda x: os.path.splitext(x)[1] in self.SUBTILES_EXTENSIONS, subfiles)
        return subfiles

    def _unpack_zipsub(self, zippath, destdir):
        zf = zipfile.ZipFile(zippath)
        namelist = zf.namelist()

        subsfiles = []
        allowed_exts = self.SUBTILES_EXTENSIONS + ['.rar', '.zip']

        for subsfn in namelist:
            # Skip directories (zip entries ending with "/")
            if subsfn.endswith('/'):
                continue

            ext = os.path.splitext(subsfn)[1].lower()
            if ext not in allowed_exts:
                continue

            # Keep path info to avoid overwriting (episode folders, etc.)
            safe_name = subsfn.replace('\\', '/').strip('/').replace('/', '_')
            outpath = os.path.join(destdir, safe_name)

            with open(outpath, "wb") as outfile:
                outfile.write(zf.read(subsfn))

            subsfiles.append(outpath)

        subsfiles.sort()
        return subsfiles

    def _unpack_rarsub(self, rar_path, dest_dir):
        try:
            import rarfile
        except ImportError:
            self.log.error('rarfile lib not available -  pip install rarfile')
            raise
        rf = rarfile.RarFile(rar_path)
        namelist = rf.namelist()
        subsfiles = []
        for subsfn in namelist:
            if os.path.splitext(subsfn)[1] in self.SUBTILES_EXTENSIONS + ['.rar', '.zip']:
                filename = os.path.basename(subsfn)
                outfile = open(os.path.join(dest_dir, filename), 'wb')
                outfile.write(rf.read(subsfn))
                outfile.flush()
                outfile.close()
                subsfiles.append(os.path.join(dest_dir, filename))
        return subsfiles
