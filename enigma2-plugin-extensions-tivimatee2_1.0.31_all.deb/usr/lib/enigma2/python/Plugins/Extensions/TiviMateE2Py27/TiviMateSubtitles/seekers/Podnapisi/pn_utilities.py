# -*- coding: utf-8 -*-

from __future__ import absolute_import
from __future__ import print_function
import urllib2  # Python 2.7 provider HTTP transport
import os
import re
import zlib
from xml.dom import minidom

from ..seeker import SubtitlesDownloadError, SubtitlesErrors
from ..utilities import log, getFileSize, hashFile, LANGUAGES
import six
from six.moves import urllib


from six.moves import xmlrpc_client


try:
    # Python 2.6 +
    from hashlib import md5 as md5
    from hashlib import sha256
except ImportError:
    # Python 2.5 and earlier
    from md5 import md5
    from .sha256 import sha256

__scriptid__ = 'podnapisi'
__scriptname__ = 'XBMC Subtitles'
__version__ = '3.9.18'

USER_AGENT = "%s_v%s" % (__scriptname__.replace(" ", "_"), __version__)
SEARCH_URL = "https://www.podnapisi.net/subtitles/search/old?tbsl=1&sK=%s&sJ=%s&sY=%s&sTS=%s&sTE=%s&sXML=1&lang=0"
SEARCH_URL_HASH = "https://www.podnapisi.net/subtitles/search/old?tbsl=1&sK=%s&sJ=%s&sY=%s&sTS=%s&sTE=%s&sMH=%s&sXML=1&lang=0"

DOWNLOAD_URL = "https://www.podnapisi.net/subtitles/%s/download"


def OpensubtitlesHash(item):
    try:
        return hashFile(item["file_original_path"], item["rar"])[1]
    except Exception as e:
        log(__name__, "[OpensubtitlesHash] error: %s" % str(e))
        return "000000000000"


def dec2hex(n, l=0):
    # return the hexadecimal string representation of integer n
    s = "%X" % n
    if (l > 0):
        while len(s) < l:
            s = "0" + s
    return s


def invert(_basestring):
    asal = [_basestring[i:i + 2]
            for i in range(0, len(_basestring), 2)]
    asal.reverse()
    return ''.join(asal)


def calculateSublightHash(filename):

    DATA_SIZE = 128 * 1024

    if not os.path.exists(filename):
        return "000000000000"

    filesize = getFileSize(filename)

    if filesize < DATA_SIZE:
        return "000000000000"
    fileToHash = open(filename, 'r')

    sum = 0
    hash = ""

    number = 2
    sum = sum + number
    hash = hash + dec2hex(number, 2)

    sum = sum + (filesize & 0xff) + ((filesize & 0xff00) >> 8) + ((filesize & 0xff0000) >> 16) + ((filesize & 0xff000000) >> 24)
    hash = hash + dec2hex(filesize, 12)

    buffer = fileToHash.read(DATA_SIZE)
    begining = zlib.adler32(buffer) & 0xffffffff
    sum = sum + (begining & 0xff) + ((begining & 0xff00) >> 8) + ((begining & 0xff0000) >> 16) + ((begining & 0xff000000) >> 24)
    hash = hash + invert(dec2hex(begining, 8))

    fileToHash.seek(filesize / 2, 0)
    buffer = fileToHash.read(DATA_SIZE)
    middle = zlib.adler32(buffer) & 0xffffffff
    sum = sum + (middle & 0xff) + ((middle & 0xff00) >> 8) + ((middle & 0xff0000) >> 16) + ((middle & 0xff000000) >> 24)
    hash = hash + invert(dec2hex(middle, 8))

    fileToHash.seek(filesize - DATA_SIZE, 0)
    buffer = fileToHash.read(DATA_SIZE)
    end = zlib.adler32(buffer) & 0xffffffff
    sum = sum + (end & 0xff) + ((end & 0xff00) >> 8) + ((end & 0xff0000) >> 16) + ((end & 0xff000000) >> 24)
    hash = hash + invert(dec2hex(end, 8))

    fileToHash.close()
    hash = hash + dec2hex(sum % 256, 2)

    return hash.lower()


class PNServer:
    def Create(self):
        self.subtitles_list = []
        self.connected = False

    def Login(self):
        self.podserver = xmlrpc_client.Server('https://ssp.podnapisi.net:8000')
        init = self.podserver.initiate(USER_AGENT)
        hash = md5()
        hash.update(settings_provider.getSetting("PNpass"))
        self.password = sha256(str(hash.hexdigest()) + str(init['nonce'])).hexdigest()
        self.user = settings_provider.getSetting("PNuser")
        if init['status'] == 200:
            self.pod_session = init['session']
            auth = self.podserver.authenticate(self.pod_session, self.user, self.password)
            if auth['status'] == 300:
                log(__name__, "Authenticate [%s]" % "InvalidCredentials")
                raise SubtitlesDownloadError(SubtitlesErrors.INVALID_CREDENTIALS_ERROR, "provided invalid credentials")
                self.connected = False
            else:
                log(__scriptid__, "Connected to Podnapisi server")
                self.connected = True
        else:
            self.connected = False

    def SearchSubtitlesWeb(self, item):
        """Search using Podnapisi numeric language IDs, preserving client-side language checks.

        A single no-year fallback helps when the remote release year differs;
        never label unknown-language responses as Arabic.
        """
        title = str(item.get('tvshow') or item.get('title') or '').strip()
        if not title:
            return self.subtitles_list
        languages = []
        for lang in (item.get('3et_language') or []):
            lang = str(lang or '').strip()
            if lang.isdigit() and int(lang) > 0 and lang not in languages:
                languages.append(lang)
        id_to_iso = dict((str(rec[1]), str(rec[2]).lower()) for rec in LANGUAGES
                         if rec[1] and rec[1] != '0')
        iso_to_id = dict((v, k) for k, v in id_to_iso.items())
        iso_languages = [id_to_iso[x] for x in languages if x in id_to_iso]
        params = {'sXML': '1', 'sK': title}
        if languages:
            params['sL'] = ','.join(languages)
        year = str(item.get('year') or '').strip()
        if len(year) == 4 and year.isdigit():
            params['sY'] = year
        if item.get('tvshow'):
            season = str(item.get('season') or '').strip()
            episode = str(item.get('episode') or '').strip()
            if season.isdigit() and episode.isdigit() and int(episode) > 0:
                params['sTS'] = season
                params['sTE'] = episode
        # IPTV cannot have a local video hash, so hash matching is optional.
        try:
            use_hash = str(settings_provider.getSetting('PNmatch')).lower() in ('1', 'true', 'yes')
        except Exception:
            use_hash = False
        oshash = str(item.get('OShash') or '')
        if use_hash and re.match(r'^[0-9a-fA-F]{16}$', oshash) and oshash != '0000000000000000':
            params['sMH'] = 'opensubtitles:' + oshash

        allowed = set(languages)
        lang_names = dict((str(rec[1]), rec[0]) for rec in LANGUAGES if rec[1] and rec[1] != '0')
        lang_names.update({'12': 'Arabic', '2': 'English'})

        def parse_entries(entries):
            result = []
            for subtitle in entries:
                pid = str(self.get_element(subtitle, 'pid') or self.get_element(subtitle, 'id') or '').strip()
                if not re.match(r'^[A-Za-z0-9_-]{1,80}$', pid):
                    continue
                raw = self.get_element(subtitle, 'language').strip().lower()
                name = self.get_element(subtitle, 'languageName').strip()
                if raw.isdigit():
                    lang_id = raw
                elif raw in iso_to_id:
                    lang_id = iso_to_id[raw]
                elif len(raw) == 3:
                    lang_id = next((str(rec[1]) for rec in LANGUAGES
                                    if rec[3].lower() == raw and str(rec[1]) != '0'), '')
                else:
                    lang_id = ''
                if not lang_id and name:
                    lang_id = next((str(rec[1]) for rec in LANGUAGES
                                    if rec[0].lower() == name.lower() and str(rec[1]) != '0'), '')
                # Missing/unknown language is not safe to label as Arabic.
                if not lang_id or (allowed and lang_id not in allowed):
                    continue
                if not name:
                    name = lang_names.get(lang_id, '')
                if not name:
                    continue
                filename = self.get_element(subtitle, 'release') or self.get_element(subtitle, 'title') or ('Podnapisi_' + pid)
                filename = re.sub(r'[\/\\\x00-\x1f]+', '_', str(filename)).strip()[:160]
                if not filename or filename in ('.', '..'):
                    filename = 'Podnapisi_' + pid
                exact_hashes = self.get_element(subtitle, 'exactHashes')
                hash_match = bool(oshash and oshash in exact_hashes and oshash not in ('000000000000', '0000000000000000'))
                try:
                    rating = str(int(float(self.get_element(subtitle, 'rating') or 0)) * 2)
                except (TypeError, ValueError):
                    rating = '0'
                result.append({
                    'filename': filename,
                    'link': pid,
                    'movie_id': self.get_element(subtitle, 'movieId'),
                    'season': self.get_element(subtitle, 'tvSeason'),
                    'episode': self.get_element(subtitle, 'tvEpisode'),
                    'language_name': name,
                    'language_flag': lang_id,
                    'rating': rating,
                    'sync': hash_match,
                    'hearing_imp': 'n' in self.get_element(subtitle, 'flags'),
                    'hash': oshash,
                })
            return result

        def lookup(query, label):
            url = 'https://www.podnapisi.net/subtitles/search/old?' + py27_urllib.urlencode(query)
            entries = self.fetch(url) or []
            found = parse_entries(entries)
            # The subprocess stdout is captured in /tmp/tivimatesubtitles.log.
            # Do not log full search URLs, server paths, usernames or passwords.
            print('[TiviMatePodnapisi] %s xml=%d accepted=%d lang=%s year=%s' % (
                label, len(entries), len(found), bool(query.get('sL')), bool(query.get('sY'))))
            return found

        # Podnapisi's XML client uses numeric language IDs (Arabic=12).
        # An incorrectly tagged release year may eliminate valid subtitles.
        # Retry only once without the year, and only after a valid empty result.
        found = lookup(params, 'primary')
        if not found and 'sY' in params:
            no_year = dict(params)
            no_year.pop('sY', None)
            found = lookup(no_year, 'no_year')
        elif not found and languages and iso_languages:
            iso = dict(params)
            iso['sL'] = ','.join(iso_languages)
            found = lookup(iso, 'iso')
        self.subtitles_list.extend(found)
        return self.subtitles_list

    def Download(self, params):
        # The old XML-RPC hash-feedback service on port 8000 is not required
        # for subtitle downloading, and can fail on modern Enigma2/Python3.
        # Use the subtitle ID returned by the XML search directly.
        pid = str((params or {}).get('link') or '').strip()
        if not re.match(r'^[A-Za-z0-9_-]{1,80}$', pid):
            raise SubtitlesDownloadError(SubtitlesErrors.UNKNOWN_ERROR,
                                         'Podnapisi subtitle ID is invalid')
        return DOWNLOAD_URL % pid

    def get_element(self, element, tag):
        # Optional XML fields (rating/exactHashes/etc.) must never abort the
        # complete Podnapisi result set when the provider omits a field.
        try:
            nodes = element.getElementsByTagName(tag)
            if nodes and nodes[0].firstChild:
                return nodes[0].firstChild.data or ""
        except Exception:
            pass
        return ""

    def fetch(self, url):
        request = urllib2.Request(url, headers={
            'User-Agent': 'TiviMateE2-Podnapisi/1.0',
            'Accept': 'application/xml,text/xml;q=0.9,*/*;q=0.4',
        })
        response = urllib2.urlopen(request, timeout=12)
        try:
            # Bound memory and avoid interpreting HTML (e.g. a rate-limit
            # interstitial) as XML subtitle search results.
            result = response.read(2097153)
        finally:
            response.close()
        if not result or len(result) > 2097152:
            return []
        sample = result.lstrip()[:256].lower()
        if sample.startswith(b'<!doctype html') or sample.startswith(b'<html'):
            return []
        if b'<!doctype' in result[:2048].lower() or b'<!entity' in result[:2048].lower():
            return []
        xmldoc = minidom.parseString(result)
        return xmldoc.getElementsByTagName('subtitle')

    def compare_columns(self, b, a):
        return cmp(b["language_name"], a["language_name"]) or cmp(a["sync"], b["sync"])

    def mergesubtitles(self):
        if len(self.subtitles_list) > 0:
            self.subtitles_list = sorted(self.subtitles_list, key=self.compare_columns)
