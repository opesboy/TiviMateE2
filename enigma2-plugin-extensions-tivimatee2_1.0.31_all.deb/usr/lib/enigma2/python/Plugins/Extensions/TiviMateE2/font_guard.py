# -*- coding: utf-8 -*-
"""Make sure every font face the plugin skins use exists.

The plugin XML uses the face names "Regular", "Bold" and "Subs". Most
skins define them, but some do not (for example Default-FHD on DreamOS /
Merlin / Gemini for DM920). OpenATV/OpenPLi then fall back to another face,
while DreamOS stops Enigma2 with
"There is no font face called Bold!" -> font.cpp ASSERTION -> crash.

A missing face is registered once at plugin start, using the best matching
font file found on the receiver. A face the active skin already defines is
never touched, so the skin keeps its own look. Works on Python 2.7 and 3.
"""
import os

REQUIRED_FACES = ("Regular", "Bold", "Subs")

_FONT_DIRS = (
    "/usr/share/fonts",
    "/usr/share/enigma2/fonts",
    "/usr/share/fonts/truetype",
    "/usr/share/fonts/truetype/dejavu",
    "/usr/share/fonts/truetype/noto",
)

_BOLD_CANDIDATES = (
    "nmsbd.ttf", "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf",
    "Roboto-Bold.ttf", "OpenSans-Bold.ttf", "NotoSans-Bold.ttf",
    "FreeSansBold.ttf", "arialbd.ttf", "verdanab.ttf", "tahomabd.ttf",
    "SourceSansPro-Bold.ttf", "Lato-Bold.ttf",
)
_REGULAR_CANDIDATES = (
    "nmsbd.ttf", "DejaVuSans.ttf", "LiberationSans-Regular.ttf",
    "Roboto-Regular.ttf", "OpenSans-Regular.ttf", "NotoSans-Regular.ttf",
    "FreeSans.ttf", "arial.ttf", "verdana.ttf", "tahoma.ttf",
    "SourceSansPro-Regular.ttf", "Lato-Regular.ttf", "md_khmurabi_10.ttf",
)

_DONE = [False]


def _log(message):
    try:
        print("[TiviMateE2][fonts] %s" % message)
    except Exception:
        pass


def _skin_fonts():
    """Return {face_name: font_file} for every <font> the loaded skins define."""
    found = {}
    try:
        import skin
    except Exception:
        return None
    doms = getattr(skin, "dom_skins", None) or getattr(skin, "domSkins", None)
    if not doms:
        return _skin_fonts_from_files()
    for entry in doms:
        try:
            path, dom = entry[0], entry[1]
        except Exception:
            continue
        try:
            nodes = dom.findall("fonts/font")
        except Exception:
            nodes = []
        for node in nodes:
            try:
                name = node.attrib.get("name")
                filename = node.attrib.get("filename") or ""
            except Exception:
                continue
            if not name:
                continue
            resolved = _resolve_font_file(filename, path)
            found.setdefault(name, resolved or filename)
    return found


def _skin_fonts_from_files():
    """Fallback: read <font name=.. filename=..> from the active skin files."""
    import re
    files = []
    try:
        from Components.config import config
        primary = config.skin.primary_skin.value
        if primary:
            files.append(os.path.join("/usr/share/enigma2", primary))
    except Exception:
        pass
    for name in ("skin_default.xml", "skin_subtitles.xml", "skin_user.xml",
                 "skin_default/skin_default.xml"):
        files.append(os.path.join("/usr/share/enigma2", name))
    found = {}
    readable = False
    pattern = re.compile(r'<font\b[^>]*>', re.I)
    for path in files:
        try:
            with open(path, "rb") as handle:
                data = handle.read().decode("utf-8", "replace")
        except Exception:
            continue
        readable = True
        for tag in pattern.findall(data):
            name = re.search(r'\bname\s*=\s*"([^"]+)"', tag)
            filename = re.search(r'\bfilename\s*=\s*"([^"]+)"', tag)
            if name:
                found.setdefault(name.group(1), _resolve_font_file(filename.group(1) if filename else "", path))
    return found if readable else None


def _resolve_font_file(filename, skin_path=""):
    if not filename:
        return ""
    if os.path.isabs(filename) and os.path.isfile(filename):
        return filename
    candidates = []
    try:
        from Tools.Directories import resolveFilename, SCOPE_FONTS
        candidates.append(resolveFilename(SCOPE_FONTS, filename))
    except Exception:
        pass
    if skin_path:
        candidates.append(os.path.join(os.path.dirname(str(skin_path)), filename))
        candidates.append(os.path.join(os.path.dirname(str(skin_path)), "fonts", filename))
    for folder in _FONT_DIRS:
        candidates.append(os.path.join(folder, filename))
    for candidate in candidates:
        try:
            if candidate and os.path.isfile(candidate):
                return candidate
        except Exception:
            pass
    return ""


def _find_file(names, keyword=None, near=None):
    folders = []
    if near:
        folders.append(os.path.dirname(near))
    folders.extend(_FONT_DIRS)
    for name in names:
        for folder in folders:
            path = os.path.join(folder, name)
            if os.path.isfile(path):
                return path
    if keyword:
        for folder in folders:
            try:
                for name in sorted(os.listdir(folder)):
                    low = name.lower()
                    if low.endswith((".ttf", ".otf")) and keyword in low:
                        return os.path.join(folder, name)
            except Exception:
                pass
    return ""


def _any_font():
    for folder in _FONT_DIRS:
        try:
            for name in sorted(os.listdir(folder)):
                if name.lower().endswith((".ttf", ".otf")):
                    return os.path.join(folder, name)
        except Exception:
            pass
    return ""


def _is_dreamos():
    return os.path.exists("/etc/opendreambox") or os.path.exists("/usr/lib/enigma2/python/Components/DreamInfoHandler.py")


def _add_font(path, name):
    from enigma import addFont
    try:
        addFont(path, name, 100, False)
    except TypeError:
        addFont(path, name, 100, False, 0)


def ensure_fonts():
    """Register any of REQUIRED_FACES the active skin lacks. Never raises."""
    if _DONE[0]:
        return
    _DONE[0] = True
    try:
        defined = _skin_fonts()
        if defined is None:
            # Skin not readable at all: only DreamOS crashes on a missing
            # face, so only there register Bold defensively. Regular and
            # Subs exist in every system skin and are left untouched.
            if not _is_dreamos():
                return
            defined = {"Regular": "", "Subs": ""}
        regular_file = defined.get("Regular") or ""
        for face in REQUIRED_FACES:
            if face in defined:
                continue
            if face == "Bold":
                path = (_find_file(_BOLD_CANDIDATES, "bold", regular_file)
                        or regular_file or _find_file(_REGULAR_CANDIDATES) or _any_font())
            else:
                path = (regular_file or _find_file(_REGULAR_CANDIDATES, "regular")
                        or _any_font())
            if not path:
                _log("no font file for missing face %s" % face)
                continue
            try:
                _add_font(path, face)
                defined[face] = path
                if face == "Regular" and not regular_file:
                    regular_file = path
                _log("skin has no '%s' face; registered %s" % (face, path))
            except Exception as exc:
                _log("could not register %s: %s" % (face, exc))
    except Exception as exc:
        _log("font check skipped: %s" % exc)
