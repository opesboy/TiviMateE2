# -*- coding: utf-8 -*-
"""GUI-thread-only native PNG paint for every Python 2.7 Enigma2 image.

The Python2 ePicLoad resize path can fill fully transparent PNG pixels with
black, so transparent artwork is painted with LoadPixmap + alphatest=blend.

Several images (VTi, older OpenPLi/DreamOS drivers) cannot *scale* a pixmap
while alpha-blending it: setScale(1) + blend then paints nothing at all, which
left title logos invisible (GENRE poster page). The pixmap is therefore fitted
to the exact widget size once (aspect kept, transparent padding) and cached on
disk next to the source, so no hardware scaling is needed. When no fitting is
possible (no PIL) and the sizes differ, None is returned and every caller
falls back to its ePicLoad path, which scales in software.
"""
from __future__ import absolute_import
import os
import struct


def _png_size(path):
    try:
        with open(path, 'rb') as handle:
            head = handle.read(24)
        if head[:8] != b'\x89PNG\r\n\x1a\n' or head[12:16] != b'IHDR':
            return None
        return struct.unpack('>II', head[16:24])
    except (IOError, OSError, struct.error):
        return None


def _fitted_path(path, width, height):
    stem = path[:-4] if path.lower().endswith('.png') else path
    return '%s.fit%dx%d.png' % (stem, width, height)


def _fit(path, width, height):
    """Aspect-fit into an exact WxH transparent canvas (cached)."""
    target = _fitted_path(path, width, height)
    try:
        if (os.path.isfile(target) and os.path.getsize(target) > 64 and
                os.path.getmtime(target) >= os.path.getmtime(path)):
            return target
    except OSError:
        pass
    try:
        from .pil_compat import install_pil_compat
        install_pil_compat()
        from PIL import Image
    except Exception:
        return ''
    temp = target + '.%d.tmp' % os.getpid()
    try:
        image = Image.open(path)
        try:
            w, h = image.size
            if w < 1 or h < 1 or w * h > 4000000:
                return ''
            frame = image.convert('RGBA')
        finally:
            try:
                image.close()
            except Exception:
                pass
        ratio = min(float(width) / w, float(height) / h)
        size = (max(1, int(round(w * ratio))), max(1, int(round(h * ratio))))
        if size != (w, h):
            resample = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
            frame = frame.resize(size, resample)
        canvas = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        canvas.paste(frame, ((width - size[0]) // 2, (height - size[1]) // 2))
        canvas.save(temp, 'PNG')
        if os.path.getsize(temp) < 64:
            return ''
        try:
            os.rename(temp, target)
        except OSError:
            if os.path.exists(target):
                os.unlink(target)
            os.rename(temp, target)
        return target
    except Exception:
        return ''
    finally:
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except OSError:
            pass


def _cached_fit(path, width, height):
    target = _fitted_path(path, width, height)
    try:
        if (os.path.isfile(target) and os.path.getsize(target) > 64 and
                os.path.getmtime(target) >= os.path.getmtime(path)):
            return target
    except OSError:
        pass
    return ''


_SYNC_FIT_MAX_PIXELS = 1000000  # e.g. a 2000x500 TMDb clearlogo

_PENDING = set()
_STATE = {}


def _schedule_fit(path, width, height):
    """Queue one fit for a single low-priority background worker (bounded)."""
    try:
        import threading
        try:
            from Queue import Queue
        except ImportError:  # pragma: no cover
            from queue import Queue
        if 'queue' not in _STATE:
            _STATE['lock'] = threading.Lock()
            _STATE['queue'] = Queue()

            def worker():
                while True:
                    key = _STATE['queue'].get()
                    try:
                        _fit(*key)
                    except Exception:
                        pass
                    finally:
                        with _STATE['lock']:
                            _PENDING.discard(key)
            thread = threading.Thread(target=worker, name='TiviMateFitPixmap')
            thread.daemon = True
            thread.start()
        key = (path, width, height)
        with _STATE['lock']:
            if key in _PENDING or len(_PENDING) > 64:
                return
            _PENDING.add(key)
        _STATE['queue'].put(key)
    except Exception:
        pass


def show(screen, widget_name, path):
    if not path or not path.lower().endswith('.png') or not os.path.isfile(path):
        return None
    try:
        widget = screen[widget_name]
    except Exception:
        return None
    return show_widget(widget, path)


def show_widget(widget, path):
    """Paint a transparent PNG on a Pixmap widget object (alpha kept)."""
    if not path or not path.lower().endswith('.png') or not os.path.isfile(path):
        return None
    try:
        from Tools.LoadPixmap import LoadPixmap
        if widget.instance is None:
            return None
        paint = path
        try:
            wsize = widget.instance.size()
            width, height = int(wsize.width()), int(wsize.height())
        except Exception:
            width = height = 0
        dims = _png_size(path)
        if width > 0 and height > 0 and dims and tuple(dims) != (width, height):
            paint = _cached_fit(path, width, height)
            if not paint:
                if dims[0] * dims[1] <= _SYNC_FIT_MAX_PIXELS:
                    # Logos / actor circles: fitting takes a few ms and runs
                    # once per size (cached on disk). Doing it now keeps the
                    # alpha channel; the ePicLoad fallback paints Python 2.7
                    # PNG transparency as a black box.
                    paint = _fit(path, width, height)
                else:
                    # Large images only: never stall the GUI thread. Prepare
                    # the fitted copy in the background for the next paint.
                    _schedule_fit(path, width, height)
                    return None
                if not paint:
                    return None
        ptr = LoadPixmap(path=paint)
        if ptr is None:
            return None
        try:
            # Exact-size pixmap: no scaling, which is what breaks alpha blend.
            widget.instance.setScale(0)
        except (AttributeError, TypeError):
            pass
        widget.instance.setPixmap(ptr)
        widget.show()
        return ptr
    except Exception:
        return None
