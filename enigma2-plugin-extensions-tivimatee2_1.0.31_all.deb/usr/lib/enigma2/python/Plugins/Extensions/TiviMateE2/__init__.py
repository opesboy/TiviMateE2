# -*- coding: utf-8 -*-

# Compatibility helpers are imported locally by the program modules that need
# them.  No Python builtins or os functions are changed at package import time.

# Lean images (OpenPLi, ...) ship without python3-requests. The Stalker
# engine and the subtitle seekers need it, so register a small stdlib
# stand-in BEFORE any module imports "requests". Images that have the real
# package keep using it unchanged.
try:
    from .requests_compat import install as _install_requests_compat
    _install_requests_compat()
except Exception:
    pass
