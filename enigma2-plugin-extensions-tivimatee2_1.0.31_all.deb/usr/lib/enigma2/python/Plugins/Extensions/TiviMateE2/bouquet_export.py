# -*- coding: utf-8 -*-
"""Safe, opt-in export of stable Live URLs to native Enigma2 bouquets.

Only direct Xtream and M3U URL providers are supported here.  Stalker
create_link URLs are short-lived and MUST NOT be written to a native bouquet
without a verified live resolver.  No changes to existing user bouquets.
"""
from __future__ import absolute_import

import hashlib
import io
import os
import re
import tempfile
try:
    from urllib.parse import quote, urlsplit
except ImportError:  # DreamOS Python 2.7
    from urllib import quote
    from urlparse import urlsplit


def _text(v):
    if v is None:
        return u''
    try:
        return v if isinstance(v, type(u'')) else v.decode('utf-8', 'replace')
    except AttributeError:
        return str(v)


def _digest(v):
    return hashlib.sha256(_text(v).encode('utf-8', 'replace')).hexdigest()[:14]


def _label(v):
    # Keep only one line and disallow markup injection in #SERVICE / #NAME.
    value = re.sub(r'[\r\n\x00-\x1f]+', ' ', _text(v)).strip()
    return value[:150] or 'Channel'


def _valid_url(value):
    url = _text(value).strip()
    if not url or any(x in url for x in ('\n', '\r', '\x00')):
        return ''
    try:
        split = urlsplit(url)
        if split.scheme.lower() not in ('http', 'https') or not split.netloc:
            return ''
    except Exception:
        return ''
    return url


def _item_url(source, item):
    source_type = _text((source or {}).get('type')).lower()
    if source_type == 'm3u':
        return _valid_url((item or {}).get('url') or (item or {}).get('stream_url'))
    if source_type == 'xtream':
        # Xtream's own production URL builder; don't guess extensions or paths.
        from .core import XtreamClient
        return _valid_url(XtreamClient(source).stream_url(item, 'live'))
    raise ValueError('Export requires a stable M3U or Xtream URL; Stalker needs a renewable link resolver.')


def _item_key(item):
    return _text((item or {}).get('stream_id') or (item or {}).get('id') or
                 (item or {}).get('ch_id') or (item or {}).get('url') or
                 (item or {}).get('name') or '').strip()


def _service_prefix(source, item, service_type):
    # Native Enigma2 picons are keyed by service-reference *fields*, not URL.
    # Old exports used all-zero IDs and therefore shared ONE picon across
    # every IPTV service. Keep stable source + channel IDs across updates.
    secret = _text((source or {}).get('url') or (source or {}).get('host') or '') + '|' + _text((source or {}).get('username') or '')
    namespace = hashlib.sha1(secret.encode('utf-8')).hexdigest()[:8]
    channel_hash = hashlib.sha1(_item_key(item).encode('utf-8')).hexdigest()
    sid = channel_hash[:4] if int(channel_hash[:4], 16) else '0001'
    tsid = channel_hash[4:8]
    onid = channel_hash[8:12]
    return '%d:0:1:%X:%X:%X:%X:0:0:0' % (int(service_type), int(sid,16), int(tsid,16), int(onid,16), int(namespace,16))


def _rows(source, items, service_type):
    from .service_compat import compatible_service_type
    service_type = compatible_service_type(service_type)
    if str((source or {}).get('type', '')).lower() not in ('m3u', 'xtream'):
        raise ValueError('Only M3U and Xtream can be exported safely.')
    if int(service_type) not in (1, 4097, 5001, 5002, 8193, 8903):
        service_type = 4097
    result = []
    seen = set()
    for item in (items or []):
        if not isinstance(item, dict):
            continue
        name = _label(item.get('name') or item.get('title') or '')
        key = _item_key(item)
        if not key or item.get('_placeholder'):
            continue
        url = _item_url(source, item)
        if not url:
            continue
        ident = _digest(key)
        if ident in seen:
            continue
        seen.add(ident)
        prefix = _service_prefix(source, item, service_type)
        ref = '%s:%s:%s' % (prefix,
                    quote(url.encode('utf-8'), safe='/'),
                    quote(name.encode('utf-8'), safe=''))
        result.append((ident, u'#TIVIMATE_ID %s\n#SERVICE %s\n#DESCRIPTION %s\n' % (ident, ref, name)))
    return result


def _read(path):
    with io.open(path, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()


def _atomic(path, content):
    folder = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(prefix='.tivimate-write-', dir=folder)
    try:
        with io.open(fd, 'w', encoding='utf-8') as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp, 0o644)
        os.rename(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def export_bouquet(source, category_id, category_name, items, selection='package',
                   service_type=4097, directory='/etc/enigma2'):
    """Create or refresh ONLY our own bouquets. Does not touch userbouquet.*.tv.

    selection: 'channel' appends/replaces only the specified channel in a stable
    per-provider export file; 'package' replaces our own package file atomically.
    Returns (exported_channel_count, bouquet_filename).
    """
    if selection not in ('channel', 'package'):
        raise ValueError('Unsupported export selection')
    if not os.path.isdir(directory):
        raise IOError('Enigma2 settings directory not found')
    typ = _text((source or {}).get('type')).lower()
    # Avoid leaking plaintext provider credentials into the export filename.
    identity = (_text(source.get('url') or source.get('path') or source.get('m3u_path') or source.get('host') or source.get('portal') or '') + '|' +
                _text(source.get('username') or source.get('user') or '') + '|' +
                _text(source.get('password') or '') + '|' + typ)
    sid = _digest(identity)
    cid = _digest(category_id or category_name or 'default')
    filename = 'userbouquet.tivimatee2_%s_%s.tv' % (sid, 'selected' if selection=='channel' else cid)
    path = os.path.join(directory, filename)
    if os.path.lexists(path) and (os.path.islink(path) or not os.path.isfile(path)):
        raise IOError('Unsafe existing bouquet path')
    results = _rows(source, items, service_type)
    if not results:
        raise ValueError('No playable Live URLs available to export.')
    # Enigma2's native bouquet list displays #NAME, not the internal hashed filename.
    # Use the original package name only; never prepend server/plugin branding.
    title = _label('Selected Channels' if selection == 'channel' else category_name or 'Live')
    original = _read(path) if os.path.exists(path) else ''
    header = u'#NAME %s\n' % title
    if selection == 'channel' and original:
        # Keep previously exported channels. Refresh the same channel by ID,
        # not URL (which can change when Xtream providers rotate endpoints).
        existing = re.split(r'(?=#TIVIMATE_ID )', original)[1:]
        additions = dict(results)
        body = []
        for block in existing:
            match = re.match(r'#TIVIMATE_ID ([a-f0-9]{14})\n', block)
            if match:
                key = match.group(1)
                if key in additions:
                    body.append(additions.pop(key))
                else:
                    body.append(block)
        body.extend(additions.values())
        content = header + u''.join(body)
    else:
        content = header + u''.join(row for _id, row in results)
    bouquet_list = os.path.join(directory, 'bouquets.tv')
    if not os.path.isfile(bouquet_list) or os.path.islink(bouquet_list):
        raise IOError('Original bouquets.tv missing or unsafe; no changes made.')
    current = _read(bouquet_list)
    marker = '#SERVICE 1:7:1:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % filename
    updated = current if marker in current else current.rstrip('\n') + '\n' + marker + '\n'
    # Export file first; if a later registration fails, restore the old content.
    _atomic(path, content)
    if updated != current:
        try:
            _atomic(bouquet_list, updated)
        except Exception:
            if original:
                _atomic(path, original)
            else:
                try: os.unlink(path)
                except OSError: pass
            raise
    return len(re.findall(r'^#SERVICE ', content, re.M)), filename


def reload_enigma_bouquets():
    # Enigma2 refresh only: never reboot/kill the currently playing channel.
    try:
        from enigma import eDVBDB
        db = eDVBDB.getInstance()
        db.reloadBouquets()
        return True
    except Exception:
        return False
