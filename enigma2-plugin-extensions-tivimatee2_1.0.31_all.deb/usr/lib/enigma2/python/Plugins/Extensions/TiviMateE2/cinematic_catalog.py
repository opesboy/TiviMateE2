# -*- coding: utf-8 -*-
"""Cinematic 6 x 4 title browser, reusing the GENRE cache and poster pipeline."""
import threading
import time
import os
import hashlib
import json
from concurrent.futures import ThreadPoolExecutor

_CINE_BACKDROP_COVER_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix="TiviCinemaCover")
_CINE_ACTOR_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviCinemaActor")

# Persist preview choice across different posters, packages and screen reopenings.
_CINE_TRAILER_SETTING = '/etc/enigma2/tivimatee2/cinematic_trailer.json'

def _cinema_trailer_enabled():
    try:
        with open(_CINE_TRAILER_SETTING, 'r', encoding='utf-8') as handle:
            return json.load(handle).get('auto', True) is not False
    except (OSError, ValueError, TypeError, AttributeError):
        return True

def _cinema_save_trailer_enabled(value):
    try:
        folder = os.path.dirname(_CINE_TRAILER_SETTING)
        os.makedirs(folder, exist_ok=True)
        temp = _CINE_TRAILER_SETTING + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump({'auto': bool(value)}, handle)
        os.replace(temp, _CINE_TRAILER_SETTING)
    except OSError:
        pass


def _right_cover_backdrop(path):
    """Crop a cached backdrop to the right-panel aspect without distorting faces."""
    from PIL import Image, ImageOps
    folder = os.path.join(os.path.dirname(path), "cinematic_right_cover")
    os.makedirs(folder, exist_ok=True)
    stat = os.stat(path)
    identity = (os.path.realpath(path), stat.st_size, getattr(stat, "st_mtime_ns", int(stat.st_mtime*1e9)))
    key = hashlib.sha1(repr(identity).encode("utf-8")).hexdigest()
    result = os.path.join(folder, key + ".jpg")
    if os.path.isfile(result) and os.path.getsize(result) > 100:
        return result
    temp = result + ".%s.tmp" % threading.get_ident()
    try:
        with Image.open(path) as original:
            frame = ImageOps.fit(original.convert("RGB"), (670, 1080), method=Image.Resampling.LANCZOS if hasattr(Image, "Resampling") else Image.LANCZOS, centering=(0.5,0.5))
            frame.save(temp, format="JPEG", quality=84)
        os.replace(temp, result)
    finally:
        try:
            if os.path.isfile(temp): os.remove(temp)
        except OSError:
            pass
    return result

def _trailer_backdrop_lower(path):
    """Keep the real cached backdrop visible *below* the video viewport.

    A separate rectangle never covers the hardware video plane.
    """
    from PIL import Image
    result = path + '.trailer_lower.png'
    if os.path.isfile(result) and os.path.getsize(result) > 100:
        return result
    tmp = result + '.%s.tmp' % threading.get_ident()
    try:
        with Image.open(path) as source:
            source.crop((0,400,670,1080)).save(tmp, format='PNG')
        os.replace(tmp,result)
    finally:
        try:
            if os.path.isfile(tmp): os.unlink(tmp)
        except OSError: pass
    return result

def _circular_actor_in_actor_cache(path):
    """Round portrait beside the existing actor image, no extra /tmp cache."""
    from PIL import Image, ImageOps, ImageDraw
    st = os.stat(path)
    seed = '%s_%s_%s' % (os.path.realpath(path),st.st_size,st.st_mtime)
    fingerprint=hashlib.sha1(seed.encode('utf-8','replace')).hexdigest()[:14]
    result=os.path.join(os.path.dirname(path), 'actor_circle_'+fingerprint+'.png')
    if os.path.isfile(result) and os.path.getsize(result)>100:
        return result
    tmp=result+'.%s.tmp' % threading.get_ident()
    try:
        with Image.open(path) as original:
            try: method=Image.Resampling.LANCZOS
            except AttributeError: method=Image.LANCZOS
            portrait=ImageOps.fit(original.convert('RGBA'),(134,134),method=method,centering=(0.5,0.32))
            alpha=Image.new('L',(134,134),0)
            d=ImageDraw.Draw(alpha)
            d.ellipse((2,2,131,131),fill=255)
            portrait.putalpha(alpha)
            portrait.save(tmp,format='PNG')
        os.replace(tmp,result)
    finally:
        try:
            if os.path.isfile(tmp): os.unlink(tmp)
        except OSError: pass
    return result

from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from Screens.MessageBox import MessageBox
from enigma import ePoint, eTimer
from .display_scale import scale_skin, sx, sy
from .rtl_text import RisingOverviewLabel
from .genre_page import StandaloneGenreScreen, POSTER_PLACEHOLDER, POSTER_SHELL, POSTER_FOCUS, PAGE_SIZE
from .tmdb_client import TMDbClient
from .genre_ultra_artwork import request as fetch_artwork
from .resolution_badge import badge_widget, extract_resolution, extract_rating, _year_genre_from_sources, _clean_genres, _actual_media_genre

COLS = 6
ROWS = 4
X = (36, 238, 440, 642, 844, 1046)
Y = (156, 372, 588, 804)
POSTER_W = 177
POSTER_H = 214
CAST_CIRCLE_MASK = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_cast_mask.png"
POSTER_FOCUS_WIDE = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_poster_focus.png"
POSTER_SHELL_CINEMATIC = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_poster_edge_clip.png"

def build_skin():
    rows = [
      # The underlying OSD window must be transparent over the trailer video plane.
      # A fullscreen opaque screen/eLabel obscures the decoder even when the
      # heroBackdrop and fade widgets are hidden.
      '<screen name="CinematicCatalogScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent">',
      # Opaque base only outside the video viewport (1270,45 .. 1900,400).
      '<eLabel position="0,0" size="1270,1080" backgroundColor="#080D16" zPosition="0" />',
      '<eLabel position="1270,0" size="650,45" backgroundColor="#080D16" zPosition="0" />',
      '<eLabel position="1900,45" size="20,355" backgroundColor="#080D16" zPosition="0" />',
      '<eLabel position="1270,400" size="650,680" backgroundColor="#080D16" zPosition="0" />',
      # Opaque backing while browsing; hidden ONLY during an active trailer.
      '<widget name="cinemaVideoBacking" position="1270,45" size="630,355" backgroundColor="#0B1420" zPosition="0" />',
      '<widget name="cinemaRightPanel" position="1250,0" size="670,1080" backgroundColor="#0B1420" zPosition="1" />',
      '<widget name="heroBackdrop" position="1250,0" size="670,1080" alphatest="off" scale="1" zPosition="2" />',
      '<widget name="rightBackdropShade" position="1250,0" size="670,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_right_fade.png" alphatest="blend" zPosition="3" />',
      '<widget name="cinemaTrailerBackdropLower" position="1250,400" size="670,680" alphatest="blend" scale="1" zPosition="3" />',
      '<eLabel position="1242,0" size="4,1022" backgroundColor="#C9A44A" zPosition="50" />',
      '<widget name="heroLogo" position="1280,208" size="610,218" alphatest="blend" scale="1" zPosition="5" />',
      '<widget name="heroInfo" position="0,0" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" />',
      '<widget name="heroTitle" position="1280,445" size="595,47" font="Regular;29" foregroundColor="#F4F6FA" transparent="1" halign="center" valign="center" zPosition="7" />',
      '<widget name="heroMeta" position="1280,499" size="595,36" font="Regular;22" foregroundColor="#E6BD67" transparent="1" zPosition="7" />',
      '<widget name="heroPlot" position="1280,499" size="595,154" font="Regular;22" foregroundColor="#DFE6F0" transparent="1" zPosition="7" />',
      badge_widget('cinemaQuality',1280,658,z=9,width=85,font_size=18),
      badge_widget('cinemaYear',1373,658,z=9,width=86,color='#287BCB',text_color='#FFFFFF',font_size=18),
      badge_widget('cinemaGenres',1467,658,z=9,width=173,color='#19866A',text_color='#FFFFFF',font_size=16),
      badge_widget('cinemaDuration',1648,658,z=9,width=119,color='#7457A6',text_color='#FFFFFF',font_size=17),
      badge_widget('cinemaRating',1775,658,z=9,width=91,color='#AD3368',text_color='#FFFFFF',font_size=17),
      '<widget name="castHeading" position="1280,697" size="590,34" font="Regular;24" foregroundColor="#E6C57D" transparent="1" zPosition="7" />',
      '<widget name="heading" position="215,14" size="575,73" font="Regular;57" foregroundColor="#F6F5F3" transparent="1" zPosition="47" />',
      '<widget name="subheading" position="0,0" size="1,1" font="Regular;1" foregroundColor="#E6D6B4" transparent="1" zPosition="47" />',
      '<widget name="page" position="1028,99" size="124,38" font="Regular;25" foregroundColor="#FFCF48" halign="center" valign="center" transparent="1" zPosition="47" />',
      '<widget name="status" position="360,99" size="178,38" font="Regular;23" foregroundColor="#F0C14C" halign="left" valign="center" transparent="1" noWrap="1" zPosition="47" />',
      '<widget name="cinemaCategory" position="577,99" size="376,38" font="Regular;22" foregroundColor="#F5EEE0" halign="center" valign="center" transparent="1" noWrap="1" zPosition="47" />',
      # No hidden 0-key bitmap here: the visible footer already has that key.
      # Negative offscreen coordinates can draw at 0,0 on older Pure2.
      '<widget name="trailerKeyHint" position="1810,1050" size="72,26" font="Regular;17" foregroundColor="#F8D278" transparent="1" halign="center" zPosition="38" />',
      '<widget name="packageLogo" position="0,0" size="1,1" alphatest="blend" />',
      '<widget name="selector" position="36,156" size="177,214" pixmap="%s" alphatest="blend" zPosition="10" />' % POSTER_FOCUS_WIDE,
      # Hide the previous mini-color legend, but preserve widget names as the
      # class refreshes their text. The bottom toolbar replaces that legend.
      '<widget name="redHint" position="1920,1080" size="1,1" font="Regular;1" transparent="1" />',
      '<widget name="greenHint" position="1920,1080" size="1,1" font="Regular;1" transparent="1" />',
      '<widget name="blueHint" position="1920,1080" size="1,1" font="Regular;1" transparent="1" />',
      '<widget name="yellowHint" position="1920,1080" size="1,1" font="Regular;1" transparent="1" />',
      '<widget name="menuHint" position="1920,1080" size="1,1" font="Regular;1" transparent="1" />',
      # The 24-poster PLAY button stays visible just above the new toolbar.
      '<widget name="playFocus" position="1280,967" size="584,49" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_play_button.png" alphatest="blend" zPosition="8" />',
      '<widget name="playText" position="1280,973" size="584,36" font="Regular;26" halign="center" foregroundColor="#FFFFFF" transparent="1" zPosition="9" />',
      '<ePixmap position="20,1027" size="1880,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_actions_toolbar_gold_newsort.png" alphatest="blend" zPosition="35" />',
      '<widget name="footerServerName" position="523,1052" size="140,22" font="Regular;15" foregroundColor="#DCE6F0" backgroundColor="#00000000" transparent="1" halign="left" valign="center" noWrap="1" zPosition="38" />',
      '<widget name="footerSortValue" position="746,1051" size="170,23" font="Regular;17" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="38" />',
      '<widget name="menuText" position="0,0" size="1,1" font="Regular;1" foregroundColor="#CAD5E1" transparent="1" halign="center" zPosition="1" />',
      # Embedded trailer covers only the upper right; no full screen takeover.
      '<widget name="cinemaTrailerVideo" position="1270,45" size="630,355" backgroundColor="transparent" zPosition="11" />',
      '<widget name="trailerCountdownShadow" position="1709,89" size="154,100" font="Regular;78" foregroundColor="#0B1725" backgroundColor="#0D1A2A" halign="center" valign="center" zPosition="12" />',
      '<widget name="trailerCountdown" position="1706,85" size="154,100" font="Regular;78" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="13" />',
      '<widget name="trailerCountdownCaption" position="1694,184" size="180,29" font="Regular;17" foregroundColor="#E7C56B" transparent="1" halign="center" zPosition="13" />',

    ]
    rows.append('<ePixmap position="0,0" size="1920,155" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/cinematic_header_approved_gold.png" alphatest="blend" zPosition="40" />')
    for i in range(10):
        rows.append('<widget name="nav%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />'%i)
    for i in range(8):
        rows.append('<widget name="genre%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />'%i)
    for i in range(24):
        x,y=X[i%COLS],Y[i//COLS]
        rows.extend([
            '<widget name="poster%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="6" />'%(i,x,y,POSTER_W,POSTER_H,POSTER_PLACEHOLDER),
            '<widget name="shell%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="7" />'%(i,x,y,POSTER_W,POSTER_H,POSTER_SHELL_CINEMATIC),
            '<widget name="meta%d" position="%d,%d" size="%d,20" font="Regular;12" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="8" />'%(i,x,y+190,POSTER_W),
        ])
        rows.append('<widget name="title%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />'%i)
    for i in range(4):
        x=1282+i*153
        rows.append('<widget name="cast%d" position="%d,746" size="134,134" alphatest="blend" scale="1" zPosition="7" />'%(i,x))
        rows.append('<widget name="castMask%d" position="%d,746" size="134,134" pixmap="%s" alphatest="blend" zPosition="9" />'%(i,x,CAST_CIRCLE_MASK))
        rows.append('<widget name="castName%d" position="%d,891" size="144,45" font="Regular;16" foregroundColor="#ECF2F8" transparent="1" halign="center" zPosition="8" />'%(i,x-5))
    rows.append('</screen>')
    return scale_skin('\n'.join(rows))

class CinematicCatalogScreen(StandaloneGenreScreen):
    skin = build_skin()

    def _normalise_categories(self, rows):
        """Movie/TV Cinematic uses the provider's package order, not GENRE sort.

        GENRE and PACKAGES still open their explicitly selected category, with
        their existing sort/order and picker behaviour.  On the Movies and TV
        Shows page the first eligible provider category must be the first one
        displayed after changing to Cinematic; no artwork/network changes.
        """
        context = str((self.source or {}).get('_view_picker_context') or '').lower()
        if context in ('genre', 'package'):
            return StandaloneGenreScreen._normalise_categories(self, rows)
        from .filters import filter_categories
        from .genre_page import _category_id, _category_name
        try:
            rows = filter_categories(self.source, self.kind, rows or [])
        except Exception:
            rows = list(rows or [])
        ordered, seen = [], set()
        for row in rows:
            if isinstance(row, (tuple, list)) and len(row) >= 2:
                row = {'category_name': row[0], 'category_id': row[1]}
            if not isinstance(row, dict):
                continue
            cid, name = _category_id(row), _category_name(row)
            if not cid or not name or cid in seen:
                continue
            seen.add(cid)
            ordered.append({'id': cid, 'name': name})
        return ordered

    def show_movies(self):
        if self.kind != 'vod':
            # A previous series selection must not be reused as movie index.
            self.initial_category_id = ''
            self.category_index = 0
            self.categories = []
        return StandaloneGenreScreen.show_movies(self)

    def show_series(self):
        if self.kind != 'series':
            # Start on the first TV package even after browsing last movie one.
            self.initial_category_id = ''
            self.category_index = 0
            self.categories = []
        return StandaloneGenreScreen.show_series(self)

    def __init__(self, session, source, initial_kind='vod', initial_category_id=''):
        super().__init__(session, source, initial_kind, initial_category_id)
        # Cinematic 24-poster view: full synopsis scrolls upward once past two lines.
        self["heroPlot"] = RisingOverviewLabel("")
        # Only Cinematic gets a taller five-line synopsis viewport.  Other
        # screen instances retain their original two-line scrolling window.
        self["heroPlot"]._rise_target_lines = 5
        self['castHeading']=Label('CAST')
        self['rightBackdropShade']=Pixmap()
        self['cinemaTrailerBackdropLower']=Pixmap()
        self['cinemaTrailerBackdropLower'].hide()
        self._cinema_backdrop_lower_path = None
        self['cinemaRightPanel']=Label('')
        self['cinemaVideoBacking']=Label('')
        self._cinema_trailer_hidden_layers = None
        for _badge in ('cinemaQuality','cinemaYear','cinemaGenres','cinemaDuration','cinemaRating'):
            self[_badge]=Label('')
            self[_badge].hide()
        self._focus_on_play = False
        self._last_grid_index = 0
        self['playFocus']=Pixmap()
        self.onLayoutFinish.append(self._refresh_play_focus)
        self.onLayoutFinish.append(self._compact_cinema_badges)
        self['playText']=Label('▶  PLAY MOVIE' if self.kind=='vod' else '▶  SELECT EPISODE')
        # Selection-keyed, ten second trailer countdown. Enigma2 GUI timers only.
        self._cinema_trailer_key = None
        self._cinema_manual_pending = False
        self._cinema_manual_stopped_key = None
        self._cinema_trailer_auto = _cinema_trailer_enabled()
        self._cinema_trailer_token = 0
        self._cinema_trailer_seconds = 10
        self._cinema_trailer_playing = False
        self._cinema_trailer_ref = None
        self._cinema_trailer_previous = None
        self._cinema_trailer_cache = {}
        self._cinema_trailer_timer = eTimer()
        self._cinema_trailer_anim = eTimer()
        self._cinema_trailer_end = eTimer()
        self._cinema_trailer_connections = []
        for timer, callback in ((self._cinema_trailer_timer,self._cinema_trailer_tick),
                                (self._cinema_trailer_anim,self._cinema_trailer_animation),
                                (self._cinema_trailer_end,self._cinema_trailer_stop)):
            try: self._cinema_trailer_connections.append(timer.timeout.connect(callback))
            except Exception:
                try: timer.callback.append(callback)
                except Exception: pass
        self._cinema_trailer_phase = 0
        self['trailerCountdown']=Label('')
        self['trailerCountdownShadow']=Label('')
        self['trailerCountdownCaption']=Label('')
        if VideoWindow is None:
            self['cinemaTrailerVideo']=Pixmap()
        else:
            try: self['cinemaTrailerVideo']=VideoWindow(decoder=0,fb_width=1920,fb_height=1080)
            except TypeError: self['cinemaTrailerVideo']=VideoWindow(decoder=0)
        self['cinemaTrailerVideo'].hide()
        for w in ('trailerCountdown','trailerCountdownShadow','trailerCountdownCaption'):
            self[w].hide()
        self.onClose.append(self._cinema_trailer_stop)
        self.onHide.append(self._cinema_trailer_stop)
        self['cinemaCategory']=Label('')
        self['menuText']=Label('')
        self['menuHint']=Label('Menu')
        self['trailerKeyHint']=Label('ON' if self._cinema_trailer_auto else 'OFF')
        # Update the OFF color once the actual Enigma2 label exists.
        self.onLayoutFinish.append(self._refresh_trailer_key_hint)
        for i in range(4):
            self['cast%d'%i]=Pixmap()
            self['castMask%d'%i]=Pixmap()
            self['castMask%d'%i].hide()
            self['castName%d'%i]=Label('')
        self._cast_token=None
        # Cinematic alone prioritizes its 24 visible posters before actor,
        # TMDb hero and other secondary network requests. The GENRE/Ultra
        # worker counts and queue sizes remain completely unchanged.
        self._cinema_poster_gate = False
        self._cinema_poster_gate_key = None
        self._cinema_poster_gate_started = 0.0
        self._cinema_poster_failed = set()
        self._cinema_deferred_cast = None
        self._cinema_poster_gate_timer = eTimer()
        self._cinema_poster_gate_timer.callback.append(self._cinema_check_poster_gate)
        self.onClose.append(self._cinema_stop_poster_gate)
        self['redHint']=Label('Back')
        self['greenHint']=Label('Server')
        self['blueHint']=Label('Next')
        self['yellowHint']=Label('Sort')
        self['actions']=ActionMap(['OkCancelActions','DirectionActions','ColorActions','MenuActions','InfoActions','NumberActions'],
          {'ok':self.activate_focused,'green':self.play_selected,'info':self.open_selected,
           'cancel':self.close,'left':self.left,'right':self.right,'up':self.up,'down':self.down,
           'pageUp':self.page_up,'pageDown':self.page_down,'red':self.previous_genre,
           'blue':self.next_genre,'green':self.open_poster_server,'yellow':self.sort_posters,
           'yellowlong':self.toggle_favorite,'greenlong':self.filter_poster_server,
           '0':self.toggle_trailer_preview,'menu':self.open_view_style_menu},-1)

    def _cinema_trailer_layers(self, preview):
        """Temporarily clear artwork and dark overlays above the video plane."""
        names = ('cinemaVideoBacking', 'cinemaRightPanel', 'heroBackdrop', 'rightBackdropShade', 'heroLogo')
        if preview:
            if self._cinema_trailer_hidden_layers is not None:
                return
            saved = {}
            for name in names:
                try:
                    widget = self[name]
                    was_visible = widget.instance.isVisible() if widget.instance is not None else getattr(widget, "visible", True)
                    saved[name] = bool(was_visible)
                    widget.hide()
                except Exception:
                    pass
            self._cinema_trailer_hidden_layers = saved
            if self._cinema_backdrop_lower_path:
                try: self['cinemaTrailerBackdropLower'].show()
                except Exception: pass
        else:
            saved = self._cinema_trailer_hidden_layers
            self._cinema_trailer_hidden_layers = None
            try: self['cinemaTrailerBackdropLower'].hide()
            except Exception: pass
            if not saved:
                return
            for name, was_visible in saved.items():
                if was_visible:
                    try: self[name].show()
                    except Exception: pass

    def _cinema_trailer_stop(self):
        """Hide preview and restore its previous service only if ours is still active."""
        self._cinema_trailer_token += 1
        for timer in (self._cinema_trailer_timer,self._cinema_trailer_anim,self._cinema_trailer_end):
            try: timer.stop()
            except Exception: pass
        self._cinema_trailer_key = None
        self._cinema_manual_pending = False
        for widget in ('trailerCountdown','trailerCountdownShadow','trailerCountdownCaption','cinemaTrailerVideo'):
            try: self[widget].hide()
            except Exception: pass
        if self._cinema_trailer_playing:
            try:
                nav = self.session.nav
                current = nav.getCurrentlyPlayingServiceReference()
                ours = self._cinema_trailer_ref
                if current is not None and ours is not None and current.toString()==ours.toString():
                    nav.stopService()
                    if self._cinema_trailer_previous is not None:
                        nav.playService(self._cinema_trailer_previous)
            except Exception: pass
        self._cinema_trailer_playing = False
        self._cinema_trailer_ref = None
        self._cinema_trailer_previous = None
        self._cinema_trailer_layers(False)

    def _cinema_trailer_selection(self):
        """Restart only on a genuinely new highlighted title, never async TMDb redraw."""
        item = self._selected_item()
        if not self._cinema_trailer_auto or not item or self._focus_on_play or VideoWindow is None:
            if self._cinema_trailer_key is not None: self._cinema_trailer_stop()
            return
        category = self.categories[self.category_index] if self.categories else {}
        key = (self.kind, str(category.get('id') or category.get('category_id') or ''),
               str(item.get('stream_id') or item.get('series_id') or item.get('id') or ''),
               str(item.get('name') or item.get('title') or ''), self.index)
        if key == self._cinema_trailer_key: return
        if key == self._cinema_manual_stopped_key:
            return
        self._cinema_manual_stopped_key = None
        self._cinema_trailer_stop()
        self._cinema_trailer_key = key
        self._cinema_trailer_seconds = 10
        self._cinema_trailer_phase = 0
        if self._cinema_trailer_auto:
            self._cinema_trailer_animate_number()
        try: self._cinema_trailer_timer.start(1000, True) if self._cinema_trailer_auto else None
        except Exception: pass

    def _refresh_trailer_key_hint(self):
        """Keep ON gold; show OFF in red without changing the 0-key layout."""
        enabled = bool(self._cinema_trailer_auto)
        hint = self['trailerKeyHint']
        hint.setText('ON' if enabled else 'OFF')
        try:
            from skin import parseColor
            if hint.instance is not None:
                hint.instance.setForegroundColor(
                    parseColor('#F8D278' if enabled else '#FF3B3B'))
        except Exception:
            pass

    def toggle_trailer_preview(self):
        """0 toggles persistent automatic trailers, not immediate playback.

        OFF stops active preview/countdown and prevents it on all other titles.
        ON starts a fresh 10-second countdown for the highlighted title.
        """
        if self._closed:
            return
        self._cinema_trailer_auto = not self._cinema_trailer_auto
        _cinema_save_trailer_enabled(self._cinema_trailer_auto)
        self._refresh_trailer_key_hint()
        # Stop invalidates asynchronous lookups and the running video service.
        self._cinema_trailer_stop()
        self._cinema_manual_stopped_key = None
        if self._cinema_trailer_auto:
            self._cinema_trailer_selection()

    def _cinema_trailer_animate_number(self):
        """White countdown numerals rise and settle; 4 lightweight GUI frames/second."""
        text = str(self._cinema_trailer_seconds)
        self['trailerCountdown'].setText(text)
        self['trailerCountdownShadow'].setText(text)
        self['trailerCountdownCaption'].setText('TRAILER IN')
        for w in ('trailerCountdown','trailerCountdownShadow','trailerCountdownCaption'):
            self[w].show()
        self._cinema_trailer_phase = 0
        self._cinema_trailer_animation()

    def _cinema_trailer_animation(self):
        if self._cinema_trailer_key is None or self._cinema_trailer_playing: return
        try:
            # Slide upwards 16 px per numeral, then hold at the final position.
            shift = (3-self._cinema_trailer_phase)*5
            self['trailerCountdown'].instance.move(ePoint(sx(1706),sy(85+shift)))
            self['trailerCountdownShadow'].instance.move(ePoint(sx(1709),sy(89+shift)))
        except Exception: pass
        self._cinema_trailer_phase += 1
        if self._cinema_trailer_phase < 4:
            try: self._cinema_trailer_anim.start(85,True)
            except Exception: pass

    def _cinema_trailer_tick(self):
        if not self._cinema_trailer_auto or self._cinema_trailer_key is None or self._focus_on_play or self._closed:
            return
        self._cinema_trailer_seconds -= 1
        if self._cinema_trailer_seconds <= 0:
            for w in ('trailerCountdown','trailerCountdownShadow','trailerCountdownCaption'):
                try: self[w].hide()
                except Exception: pass
            self._cinema_trailer_resolve()
            return
        self._cinema_trailer_animate_number()
        try: self._cinema_trailer_timer.start(1000,True)
        except Exception: pass

    def _cinema_trailer_resolve(self):
        if not self._cinema_trailer_auto: return
        item = dict(self._selected_item() or {})
        token = self._cinema_trailer_token
        key = self._cinema_trailer_key
        if not item or key is None: return
        cached = self._cinema_trailer_cache.get(key)
        if cached is not None:
            self._cinema_trailer_ready(token,key,cached)
            return
        def work():
            result = {'state':'missing'}
            try:
                from .content_home import _resolve_movie_trailer_stream
                client = TMDbClient(language='en-US')
                raw = item.get('tmdb_id') or item.get('tmdb') or item.get('tmdbId')
                media_id = int(str(raw)) if str(raw or '').isdigit() else 0
                if not media_id:
                    title = str(item.get('name') or item.get('title') or '').strip()
                    year = str(item.get('year') or '')[:4] or None
                    if title:
                        found = client.search_title(title,self.kind,year) or {}
                        media_id = int(found.get('id') or 0)
                if media_id and token==self._cinema_trailer_token:
                    result = _resolve_movie_trailer_stream(media_id,self.kind)
            except Exception: pass
            self._post_to_gui(self._cinema_trailer_ready, token, key, result)
        # Bounded worker; the UI is never blocked by YouTube/TMDb.
        try: _CINE_BACKDROP_COVER_POOL.submit(work)
        except RuntimeError: pass

    def _cinema_trailer_ready(self, token, key, result):
        if self._closed or not self._cinema_trailer_auto or token != self._cinema_trailer_token or key != self._cinema_trailer_key or self._focus_on_play:
            return
        if len(self._cinema_trailer_cache) > 24:
            self._cinema_trailer_cache.clear()
        self._cinema_trailer_cache[key] = result
        self._cinema_manual_pending = False
        if not isinstance(result,dict) or result.get('state')!='ready': return
        url = str(result.get('url') or '')
        if not url.startswith(('http://','https://')): return
        try:
            from .content_home import _trailer_reference, _trailer_has_serviceapp
            nav = self.session.nav
            old = nav.getCurrentlyPlayingServiceReference()
            ref = _trailer_reference(url,str(result.get('name') or 'Trailer'),
                                     5002 if result.get('split') and _trailer_has_serviceapp() else 4097)
            self._cinema_trailer_previous = old
            self._cinema_trailer_ref = ref
            self._cinema_trailer_playing = True
            # Hide Cinematic's artwork, logo and fade while the movie preview plays.
            # On hardware video planes, GUI artwork can otherwise dim the stream.
            self._cinema_trailer_layers(True)
            self['cinemaTrailerVideo'].show()
            nav.playService(ref)
            self._cinema_trailer_end.start(110000,True)
        except Exception:
            self._cinema_trailer_stop()

    def open_view_style_menu(self):
        # The 24-poster catalog is shared by both page layouts and category
        # browsing.  A catalog reached through PACKAGES or GENRE must keep
        # its own original four-poster-style picker, not the three page layouts.
        context = ''
        if isinstance(self.source, dict):
            context = str(self.source.get('_view_picker_context') or '').lower()
        if context in ('package', 'genre'):
            return StandaloneGenreScreen.open_view_style_menu(self)
        from .movies_page_picker import MoviesPagePicker
        self.session.openWithCallback(self._movie_page_design_chosen,
                                      MoviesPagePicker, self.kind)

    def _movie_page_design_chosen(self, chosen=None):
        if chosen not in ('current', 'new', 'grid24'):
            return
        from .movies_layout_choice import save_content_layout, configured_movies_screen
        if not save_content_layout(self.kind, chosen) or chosen == 'grid24':
            return
        from .content_home import FastMoviesContentScreen
        self._cinema_trailer_stop()
        target = configured_movies_screen(FastMoviesContentScreen, self.kind)
        self.session.openWithCallback(self._movie_page_design_return,
                                      target, dict(self.source), self.kind)

    def _movie_page_design_return(self, _result=None):
        self.close()

    def toggle_movies_series(self):
        """Swap catalogs via GENRE's existing provider/cache pipeline."""
        self._cinema_trailer_stop()
        self._focus_on_play = False
        self._cast_token = None
        other_kind = 'series' if self.kind == 'vod' else 'vod'
        from .movies_layout_choice import configured_movies_screen
        from .content_home import FastMoviesContentScreen
        target = configured_movies_screen(FastMoviesContentScreen, other_kind)
        if target is not CinematicCatalogScreen:
            self.session.open(target, dict(self.source), other_kind)
            return
        if other_kind == 'series':
            self.show_series()
        else:
            self.show_movies()
        self['yellowHint'].setText('Sort')

    def _show_hero_image(self, token, name, path):
        if name != 'heroBackdrop':
            return super()._show_hero_image(token, name, path)
        if self._closed or token != self._hero_token or not path or not os.path.isfile(path):
            return
        # Cropping is done off the GUI thread; GENRE artwork remains untouched.
        def job():
            try:
                target = _right_cover_backdrop(path)
                try:
                    lower = _trailer_backdrop_lower(target)
                except Exception:
                    lower = None
                self._post_to_gui(self._display_right_cover, token, target, lower)
            except Exception:
                # Prefer the original rather than a blank image when Pillow is missing.
                self._post_to_gui(self._display_right_cover, token, path, None)
        try:
            _CINE_BACKDROP_COVER_POOL.submit(job)
        except RuntimeError:
            pass

    def _display_right_cover(self, token, path, lower=None):
        if self._closed or token != self._hero_token or not os.path.isfile(path):
            return
        super()._show_hero_image(token, 'heroBackdrop', path)
        self._cinema_backdrop_lower_path = lower if lower and os.path.isfile(lower) else None
        try:
            if self._cinema_backdrop_lower_path:
                self['cinemaTrailerBackdropLower'].instance.setPixmapFromFile(self._cinema_backdrop_lower_path)
                if self._cinema_trailer_playing:
                    self['cinemaTrailerBackdropLower'].show()
            else:
                self['cinemaTrailerBackdropLower'].hide()
        except Exception: pass

    def _adjust_movie_logo_size(self):
        # Keep the original GENRE callback from moving the logo into the left poster grid.
        try:
            from enigma import eSize
            widget=self['heroLogo'].instance
            if widget:
                widget.move(ePoint(sx(1280),sy(208)))
                widget.resize(eSize(sx(610),sy(218)))
        except Exception:
            pass

    def _set_cinema_badge(self, widget_name, value):
        try:
            widget=self[widget_name]
            text=str(value or '').strip()
            widget.setText(text)
            if text: widget.show()
            else: widget.hide()
        except (KeyError, AttributeError, TypeError):
            pass

    def _refresh_cinema_badges(self, info=None):
        # The highlighted item wins over older provider records. Never use a
        # generic 4K badge when the current stream quality is unknown.
        item=self._selected_item() or {}
        source_info=info if isinstance(info,dict) else {}
        cat=self.categories[self.category_index] if self.categories else {}
        quality=extract_resolution(item, source_info)
        year, genres=_year_genre_from_sources([source_info,item])
        sources = getattr(self, '_hero_text_sources', {}) or {}
        genres = _actual_media_genre(sources.get('tmdb_verified') or {}, sources.get('tmdb') or {},
                                     sources.get('tmdb_search') or {}, sources.get('provider') or {},
                                     source_info, item)
        self._set_cinema_badge('cinemaQuality', quality)
        self._set_cinema_badge('cinemaYear', year)
        self._set_cinema_badge('cinemaGenres', genres)
        from .resolution_badge import extract_duration
        self._set_cinema_badge('cinemaDuration', extract_duration(source_info, item))
        self._set_cinema_badge('cinemaRating', extract_rating(sources.get('tmdb_verified') or {},
                                                             source_info, item))
        self._compact_cinema_badges()

    def _compact_cinema_badges(self):
        """No blank gaps when quality or runtime is unavailable.

        The selected film's visible pills retain their original colour and size.
        This is a geometry-only change, not a claim that a stream is HD/4K.
        """
        x = 1280
        widths = (85, 86, 173, 119, 91)
        for name, width in zip(('cinemaQuality', 'cinemaYear', 'cinemaGenres',
                                'cinemaDuration', 'cinemaRating'), widths):
            try:
                label = self[name]
                if not str(label.getText() or '').strip():
                    continue
                instance = getattr(label, 'instance', None)
                if instance is not None:
                    instance.move(ePoint(sx(x), sy(658)))
                x += width + 8
            except (KeyError, AttributeError, TypeError):
                continue

    def _render_empty(self,message):
        super()._render_empty(message)
        self._clear_cast()
    def _clear_cast(self):
        self._cast_token=None
        for i in range(4):
            try: self['cast%d'%i].hide(); self['castMask%d'%i].hide(); self['castName%d'%i].setText('')
            except Exception: pass

    def _set_hero_text(self, info):
        # Keep all GENRE metadata/language logic; only restore the full plot
        # in this 24-poster screen instead of GENRE's 210-char preview.
        super(CinematicCatalogScreen, self)._set_hero_text(info)
        # Only this (effective) override runs.  Render all five pills after
        # GENRE's provider/TMDb text update, then hide repeated plain metadata.
        self._refresh_cinema_badges(info)
        self['heroMeta'].setText('')
        try:
            desc = str((info or {}).get('description') or '').strip()
            self['heroPlot'].setText(desc[:700])
        except Exception:
            pass

    # A page starts with visible poster downloads, including their GENRE
    # cache/validation/fallback pipeline. Hero/cast HTTP requests begin only
    # when those posters have painted or exhausted their fallback attempts.
    # Do not change the shared queues or the order of visible poster slots.
    def _cinema_start_poster_gate(self, key):
        self._cinema_poster_gate_timer.stop()
        self._cinema_poster_gate = True
        self._cinema_poster_gate_key = key
        self._cinema_poster_gate_started = time.monotonic()
        self._cinema_poster_failed.clear()
        self._cinema_deferred_cast = None

    def _cinema_stop_poster_gate(self):
        timer = getattr(self, '_cinema_poster_gate_timer', None)
        if timer is not None:
            timer.stop()
        self._cinema_poster_gate = False
        self._cinema_poster_gate_key = None
        self._cinema_poster_failed.clear()
        self._cinema_deferred_cast = None

    def _cinema_check_poster_gate(self):
        if self._closed or not self._cinema_poster_gate:
            return
        key = self._cinema_poster_gate_key
        if key != self._rendered_page_key:
            self._cinema_stop_poster_gate()
            return
        total = len(self.genre_items)
        visible = min(24, max(0, total - self.page_start))
        # _poster_resolved_priority becomes positive ONLY after the ePicLoad
        # callback paints the correct poster. An exhausted GENRE fallback is
        # marked separately, so a truly missing poster cannot block actors.
        complete = all(slot in self._cinema_poster_failed or
                       self._poster_resolved_priority.get(slot, 0) > 0
                       for slot in range(visible))
        # A broken portal must not suppress the selected actor/hero indefinitely.
        # Slow poster requests continue normally; only secondary work is gated.
        expired = time.monotonic() - self._cinema_poster_gate_started >= 18.0
        if not complete and not expired:
            self._cinema_poster_gate_timer.start(200, True)
            return
        self._cinema_poster_gate_timer.stop()
        self._cinema_poster_gate = False
        self._cinema_poster_gate_key = None
        deferred = self._cinema_deferred_cast
        self._cinema_deferred_cast = None
        if deferred and deferred[1] == self._cast_token:
            self._request_cast(deferred[0], deferred[1])
        # Cached hero artwork was already rendered immediately by GENRE.
        # Launch any postponed server/TMDb work for the CURRENT selection.
        if self.genre_items and not self._closed:
            entry = self._hero_cache.get(self._hero_token) or {}
            if not entry.get('complete'):
                self._hero_timer.stop()
                self._hero_timer.start(1, True)

    def _keep_default_poster(self, slot, token):
        # This is the final GENRE failure stage (server + TMDb exhausted).
        super(CinematicCatalogScreen, self)._keep_default_poster(slot, token)
        if (self._cinema_poster_gate and
                self._poster_tokens.get(slot) == token and
                self._poster_resolved_priority.get(slot, 0) == 0):
            self._cinema_poster_failed.add(slot)

    def _request_hero_artwork(self, token, url, category, widget, origin='provider'):
        if self._cinema_poster_gate:
            # GENRE's _schedule_hero still shows cached images immediately.
            # The deferred _load_hero will retry the provider image afterward.
            return
        return super(CinematicCatalogScreen, self)._request_hero_artwork(
            token, url, category, widget, origin)

    def _load_hero(self):
        if self._cinema_poster_gate:
            return
        return super(CinematicCatalogScreen, self)._load_hero()

    def render(self):
        cat=self.categories[self.category_index] if self.categories else {}
        total=len(self.genre_items)
        self.page_start=(self.index//24)*24 if total else 0
        pages=max(1,(total+23)//24)
        self['page'].setText('%d / %d'%(self.page_start//24+1,pages))
        self['heading'].setText('TV SHOWS' if self.kind=='series' else 'MOVIES')
        self['yellowHint'].setText('Sort')
        self['subheading'].setText('')
        self['status'].setText('TITLES: %d' % total)
        self['cinemaCategory'].setText(str(cat.get('name') or '')[:29])
        self['playText'].setText('▶  PLAY MOVIE' if self.kind=='vod' else '▶  SELECT EPISODE')
        item=self._selected_item() or {}
        page_key=(self._generation,self.page_start,total)
        if page_key!=self._rendered_page_key and total:
            self._cinema_start_poster_gate(page_key)
        self._refresh_cinema_badges()
        self._schedule_hero()
        self._update_hero_info(self._hero_token,{
            'title':str(item.get('name') or item.get('title') or ''),
            'year':str(item.get('year') or item.get('release_date') or '')[:4],
            'rating':str(item.get('rating') or item.get('vote_average') or ''),
            'description':str(item.get('plot') or item.get('description') or item.get('overview') or ''),
            'category':str(cat.get('name') or '')}, 'catalog')
        selected_token=(self.kind,str(item.get('stream_id') or item.get('series_id') or item.get('id') or ''),self.index)
        if selected_token!=self._cast_token:
            self._cast_token=selected_token
            for j in range(4):
                self['cast%d'%j].hide();self['castMask%d'%j].hide();self['castName%d'%j].setText('')
            if self._cinema_poster_gate:
                self._cinema_deferred_cast = (dict(item), selected_token)
            else:
                self._request_cast(item,selected_token)
        if page_key!=self._rendered_page_key:
            self._cancel_poster_jobs()
            self._rendered_page_key=page_key
            self._poster_resolved_priority.clear();self._poster_tmdb_started.clear()
            for slot in range(24):
                idx=self.page_start+slot
                row=self.genre_items[idx] if idx<total else None
                if row is None:
                    self._poster_tokens.pop(slot,None)
                    self['poster%d'%slot].hide();self['shell%d'%slot].hide();self['meta%d'%slot].setText('')
                    continue
                self['poster%d'%slot].show();self['shell%d'%slot].show()
                self['meta%d'%slot].setText('')
                self._set_placeholder(slot)
                self._load_poster(slot,row,idx)
            if self._cinema_poster_gate:
                self._cinema_poster_gate_timer.start(200, True)
        if total:
            slot=self.index-self.page_start
            self['selector'].instance.move(ePoint(sx(X[slot%COLS]),sy(Y[slot//COLS])))
            if self._focus_on_play:self['selector'].hide()
            else:self['selector'].show()
        else:
            self['selector'].hide()
        self._refresh_play_focus()
        self._cinema_trailer_selection()

    def _refresh_play_focus(self):
        try:
            image='cinematic_play_selected.png' if self._focus_on_play else 'cinematic_play_button.png'
            self['playFocus'].instance.setPixmapFromFile('/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skin/images/'+image)
            self['playFocus'].show()
        except Exception:
            pass

    def activate_focused(self):
        if self._focus_on_play:
            self.play_selected()
        else:
            self.open_selected()

    def left(self):
        if self._focus_on_play:
            self._focus_on_play=False
            self.index=min(self._last_grid_index,max(0,len(self.genre_items)-1))
            self.render()
        elif self.index%COLS and self.genre_items:
            self.index-=1;self.render()
    def right(self):
        if self._focus_on_play:return
        if self.index%COLS==COLS-1 or self.index+1>=len(self.genre_items):
            if self.genre_items:
                self._last_grid_index=self.index
                self._focus_on_play=True
                self.render()
        else:
            self.index+=1;self.render()
    def up(self):
        if self._focus_on_play:return
        if self.index>=COLS:self.index-=COLS;self.render()
    def down(self):
        if self._focus_on_play:return
        if self.index+COLS<len(self.genre_items):self.index+=COLS;self.render()

    def next_item(self):
        if not self.genre_items:
            return
        if self._focus_on_play:
            self._focus_on_play=False
            self.index=min(self._last_grid_index, max(0, len(self.genre_items)-1))
        self.index = (self.index + 1) % len(self.genre_items)
        self.render()

    def play_selected(self):
        self._cinema_trailer_stop()
        item=self._selected_item()
        if not item:return
        if self.kind=='series':
            self.open_selected()  # Series must resolve season/episode before playback.
            return
        try:
            from .content_home import _movie_continue_row
            from .ui import play_vod_exact_continue_path
            row=_movie_continue_row(self.source,dict(item))
            if not row:raise ValueError('Missing playable stream')
            play_vod_exact_continue_path(self.session,row,current_source=dict(self.source),callback=None)
        except Exception:
            # Allow detail screen's server-specific URL resolver to handle portal variants.
            self.open_selected()

    def _request_cast(self,item,token):
        if not item:return
        title=str(item.get('name') or item.get('title') or '')
        year=str(item.get('year') or '')[:4]
        kind=self.kind
        def worker():
            try:
                client=TMDbClient()
                media_id=item.get('tmdb_id') or item.get('tmdb') or item.get('tmdbId')
                if not media_id:
                    found=client.search_artwork(title,kind,year or None) or {}
                    media_id=found.get('id')
                if not media_id:return
                credits=client.media_credits(media_id,kind) or {}
                cast=[x for x in credits.get('cast',[]) if isinstance(x,dict)][:4]
                if self._closed or token!=self._cast_token:return
                self._post_to_gui(self._apply_cast,token,cast)
            except Exception:pass
        threading.Thread(target=worker,name='TiviMateCinematicCast',daemon=True).start()

    def _apply_cast(self,token,actors):
        if self._closed or token!=self._cast_token:return
        for i,actor in enumerate(actors[:4]):
            self['castName%d'%i].setText(str(actor.get('name') or '')[:24])
            path=str(actor.get('profile_path') or '')
            if not path:continue
            url=path if path.startswith('http') else 'https://image.tmdb.org/t/p/w342'+path
            def ready(local,i=i,token=token):
                if self._closed or self._cast_token!=token or not local:return
                def prepare():
                    try: portrait = _circular_actor_in_actor_cache(local)
                    except Exception: portrait = local
                    self._post_to_gui(display,portrait)
                def display(portrait):
                    if self._closed or self._cast_token!=token: return
                    try:
                        self['cast%d'%i].instance.setPixmapFromFile(portrait)
                        self['cast%d'%i].show()
                        self['castMask%d'%i].hide()
                    except Exception:pass
                try: _CINE_ACTOR_POOL.submit(prepare)
                except RuntimeError: pass
            fetch_artwork(url,'actor',dict(self.source),ready,lambda unused:None,self._post_to_gui)
