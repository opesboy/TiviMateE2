# -*- coding: utf-8 -*-
import os
import tempfile

from PIL import Image
from twisted.web.client import downloadPage
from .cache_manager import get_cache_dir

from urllib.parse import urlparse

try:
    from twisted.internet import ssl
    from twisted.internet._sslverify import ClientTLSOptions
    _SSLVERIFY = True
except Exception:
    ssl = None
    ClientTLSOptions = None
    _SSLVERIFY = False


if _SSLVERIFY:
    class SNIFactory(ssl.ClientContextFactory):
        def __init__(self, hostname=None):
            self.hostname = hostname
        def getContext(self):
            ctx = self._contextFactory(self.method)
            if self.hostname:
                ClientTLSOptions(self.hostname, ctx)
            return ctx
else:
    SNIFactory = None


def _remove(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def direct_picon(url, size, request_id, current_request_id, apply_path, prefix='xst_live_picon_'):
    """EStalker 1.45 Picon lifecycle: one temporary file, no persistent cache."""
    try:
        url = str(url or '').strip().replace('\\/', '/')
    except Exception:
        return None

    if not url or url.lower() == 'n/a':
        return None
    if not url.startswith(('http://', 'https://')):
        return None

    temp_root = "/var/volatile/tmp"
    if not os.path.isdir(temp_root):
        temp_root = "/tmp"

    fd = None
    temp = None
    # Keep at most one temporary Live Picon around. Remove leftovers from
    # older/stale requests before starting a new download.
    try:
        live_prefix = str(prefix or 'xst_live_picon_')
        for old_name in os.listdir(temp_root):
            if old_name.startswith(live_prefix):
                old_path = os.path.join(temp_root, old_name)
                try:
                    if os.path.isfile(old_path):
                        os.remove(old_path)
                except Exception:
                    pass
    except Exception:
        pass

    try:
        fd, temp = tempfile.mkstemp(
            prefix=str(prefix or 'xst_live_picon_'),
            suffix='.png',
            dir=temp_root
        )
        try:
            os.close(fd)
        except Exception:
            pass
        fd = None

        parsed = urlparse(url)
        domain = parsed.hostname
        scheme = parsed.scheme

        try:
            dl_url = url.encode('utf-8')
        except Exception:
            dl_url = url

        def _cleanup_temp():
            try:
                if temp and os.path.exists(temp):
                    os.remove(temp)
            except Exception:
                pass

        def _stale():
            try:
                return int(current_request_id()) != int(request_id)
            except Exception:
                return True

        def _resize_and_show():
            if _stale():
                _cleanup_temp()
                return

            image = None
            bg = None
            try:
                image = Image.open(temp)
                if image.mode != 'RGBA':
                    image = image.convert('RGBA')

                if image.size[0] == 0 or image.size[1] == 0:
                    raise ValueError('Image has zero dimension')

                width, height = int(size[0]), int(size[1])
                ratio = min(
                    width / float(image.size[0]),
                    height / float(image.size[1])
                )
                new_size = (
                    max(1, int(image.size[0] * ratio)),
                    max(1, int(image.size[1] * ratio))
                )

                try:
                    image = image.resize(new_size, Image.Resampling.LANCZOS)
                except Exception:
                    try:
                        image = image.resize(new_size, Image.LANCZOS)
                    except Exception:
                        image = image.resize(new_size, Image.ANTIALIAS)

                bg = Image.new('RGBA', (width, height), (255, 255, 255, 0))
                left = (width - image.size[0]) // 2
                top = (height - image.size[1]) // 2
                bg.paste(image, (left, top), mask=image)

                # EStalker resizes the SAME temporary file.
                bg.save(temp, 'PNG')

                if not _stale():
                    # Enigma2 reads the resized temporary file directly.
                    apply_path(temp)

            except Exception:
                pass
            finally:
                try:
                    if image is not None:
                        image.close()
                except Exception:
                    pass
                try:
                    if bg is not None:
                        bg.close()
                except Exception:
                    pass

                # EStalker removes the temporary Picon after setPixmapFromFile().
                _cleanup_temp()

        def _ok(_data=None):
            if _stale():
                _cleanup_temp()
                return
            _resize_and_show()

        def _err(_failure=None):
            _cleanup_temp()

        if scheme == 'https' and _SSLVERIFY and SNIFactory is not None:
            factory = SNIFactory(domain)
            d = downloadPage(dl_url, temp, factory, timeout=2)
        else:
            d = downloadPage(dl_url, temp, timeout=2)

        d.addCallback(_ok)
        d.addErrback(_err)
        return d

    except Exception:
        try:
            if fd:
                os.close(fd)
        except Exception:
            pass
        try:
            if temp and os.path.exists(temp):
                os.remove(temp)
        except Exception:
            pass
        return None
