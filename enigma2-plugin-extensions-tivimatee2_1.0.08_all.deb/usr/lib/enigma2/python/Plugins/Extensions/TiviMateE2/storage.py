# -*- coding: utf-8 -*-
from __future__ import absolute_import

import glob
import os
import threading

ETC_DIR = "/etc/enigma2/tivimatee2"
PLAYLISTS_FILE = os.path.join(ETC_DIR, "playlists.txt")
TMP_ROOT = "/tmp/tivimatee2-cache"
APP_FOLDER = "tivimatee2-cache"

_LOCK = threading.RLock()
_DATA_ROOT = ""


def _mounted_paths():
    paths = set()
    try:
        with open("/proc/mounts", "r") as handle:
            for raw in handle:
                parts = raw.split()
                if len(parts) >= 2:
                    paths.add(os.path.realpath(parts[1].replace("\\040", " ")))
    except Exception:
        pass
    return paths


def _is_usable_mount(path, mounted=None):
    """Accept only a real writable mount; never create a fake HDD/USB folder."""
    try:
        if not path or not os.path.isdir(path):
            return False
        real = os.path.realpath(path)
        mounted = mounted if mounted is not None else _mounted_paths()
        if not (os.path.ismount(path) or os.path.ismount(real) or real in mounted):
            return False
        return os.access(path, os.W_OK | os.X_OK)
    except Exception:
        return False


def _candidate_mounts():
    mounted = _mounted_paths()
    out = []

    # 1) HDD first.
    if _is_usable_mount("/media/hdd", mounted):
        out.append("/media/hdd")

    # 2) USB / removable media.
    for path in (
        "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3",
        "/media/mmc", "/media/sdcard"
    ):
        if path not in out and _is_usable_mount(path, mounted):
            out.append(path)

    # Custom /media mount names used by some Enigma2 images.
    try:
        for path in sorted(glob.glob("/media/*")):
            if path in out or path == "/media/hdd":
                continue
            real = os.path.realpath(path)
            name = os.path.basename(path).lower()
            if real in ("/", "/media") or "net" in name:
                continue
            if _is_usable_mount(path, mounted):
                out.append(path)
    except Exception:
        pass

    return out


def _ensure(path):
    try:
        if not os.path.isdir(path):
            os.makedirs(path)
    except OSError:
        if not os.path.isdir(path):
            raise
    return path


def _resolve_data_root():
    for mount in _candidate_mounts():
        try:
            return _ensure(os.path.join(mount, APP_FOLDER))
        except Exception:
            pass

    # 3) No HDD/USB available -> temporary fallback only.
    return _ensure(TMP_ROOT)


def get_data_root():
    global _DATA_ROOT
    with _LOCK:
        if not _DATA_ROOT or not os.path.isdir(_DATA_ROOT):
            _DATA_ROOT = _resolve_data_root()
        return _DATA_ROOT


def data_path(*parts):
    root = get_data_root()
    path = os.path.join(root, *[str(p) for p in parts if p not in (None, "")])
    parent = os.path.dirname(path)
    if parent:
        try:
            _ensure(parent)
        except Exception:
            pass
    return path


def get_playlists_file():
    """playlists.txt is the only TiviMateE2 data file kept under /etc/enigma2."""
    try:
        _ensure(ETC_DIR)
    except Exception:
        pass
    return PLAYLISTS_FILE


def storage_mode():
    root = get_data_root()
    if root == TMP_ROOT or root.startswith(TMP_ROOT + os.sep):
        return "tmp"
    if root.startswith("/media/hdd/"):
        return "hdd"
    return "usb"
