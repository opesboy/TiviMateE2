# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
from urllib.request import Request, urlopen

from .compat import atomic_replace, ensure_dir, open_text, python_command

import os
import sys
import tempfile
import hashlib
import json
import base64
import threading
import time
import re
from datetime import datetime, timedelta

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import MoviePlayer
try:
    from Screens.AudioSelection import AudioSelection
except Exception:
    AudioSelection = None
from Components.ActionMap import ActionMap as _E2ActionMap
from .action_trace import make_traced_actionmap
ActionMap = make_traced_actionmap(_E2ActionMap)
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigPassword, ConfigSelection, ConfigYesNo, getConfigListEntry, config, configfile
from enigma import (eServiceReference, ePicLoad, eTimer, eConsoleAppContainer, ePoint,
    eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eEPGCache, eSize)
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from .live_service import live_reference, live_reference_string, epg_reference_string
from .epg_local import lookup_channel_epg, refresh_source_epg
try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .content_home import ContentHomeScreen, MovieDetailsScreen

HOME_TMDb_CACHE_FILE = data_path("home_tmdb_cache.json")
_HOME_TMDb_CACHE_LOCK = threading.Lock()

def _home_tmdb_cache_load():
    try:
        with _HOME_TMDb_CACHE_LOCK:
            with open(HOME_TMDb_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _home_tmdb_cache_get(mode):
    row = _home_tmdb_cache_load().get(str(mode or "popular_movies")) or {}
    items = row.get("items") if isinstance(row, dict) else []
    return [dict(x) for x in (items or []) if isinstance(x, dict)]

def _home_tmdb_cache_put(mode, items):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)]
    if not rows:
        return False
    try:
        data = _home_tmdb_cache_load()
        data[str(mode or "popular_movies")] = {
            "updated": int(time.time()),
            "items": rows[:12],
        }
        with _HOME_TMDb_CACHE_LOCK:
            folder = os.path.dirname(HOME_TMDb_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = HOME_TMDb_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, HOME_TMDb_CACHE_FILE)
        return True
    except Exception:
        return False

HOME_SERVER_2026_ROTATION_FILE = data_path("home_server_2026_rotation.json")
_HOME_SERVER_2026_ROTATION_LOCK = threading.Lock()
_HOME_SERVER_2026_SLOT_SECONDS = 6 * 60 * 60
_HOME_SERVER_TRENDING_SLOT_SECONDS = 6 * 60 * 60


def _home_server_filter_cache_mode(source, mode):
    """Bind server-backed Home caches to the current package-filter selection.

    This prevents Popular/You Might Like rows built before a filter change from
    leaking hidden packages back into Home. TMDb-only feeds are unaffected.
    """
    mode = str(mode or "popular_movies")
    kind = "series" if mode in ("popular_series", "trending_series") else "vod"
    try:
        allowed = get_allowed_category_ids(source or {}, kind)
    except Exception:
        allowed = None
    if allowed is None:
        sig_raw = "ALL"
    else:
        sig_raw = ",".join(sorted(str(x) for x in allowed if str(x))) or "NONE"
    try:
        sig = hashlib.sha1(sig_raw.encode("utf-8", "ignore")).hexdigest()[:10]
    except Exception:
        sig = str(abs(hash(sig_raw)))[:10]
    return "%s_pf_%s" % (mode, sig)

def _home_server_2026_source_key(source):
    source = source or {}
    raw = "|".join([
        str(source.get("type") or ""),
        str(source.get("name") or ""),
        str(source.get("url") or source.get("portal") or ""),
        str(source.get("username") or source.get("mac") or ""),
    ])
    try:
        return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()
    except Exception:
        return raw

def _home_server_2026_slot(mode=None):
    seconds = _HOME_SERVER_TRENDING_SLOT_SECONDS if str(mode or "").startswith("trending_") else _HOME_SERVER_2026_SLOT_SECONDS
    return int(time.time() // seconds)

def _home_server_2026_cache_file(source):
    # r183: every IPTV source owns a physical Home cache file. This prevents
    # a server switch from reusing/overwriting another server's 2026 rotation.
    key = _home_server_2026_source_key(source)
    folder = data_path("home_server_2026")
    try:
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
    except Exception:
        pass
    return os.path.join(folder, "%s.json" % key)

def _home_server_2026_cache_load(source):
    path = _home_server_2026_cache_file(source)
    try:
        with _HOME_SERVER_2026_ROTATION_LOCK:
            with open(path, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def _home_server_2026_cache_get(source, mode):
    try:
        key = str(mode or "popular_movies")
        row = _home_server_2026_cache_load(source).get(key) or {}
        if int(row.get("slot", -1)) != _home_server_2026_slot(key):
            return []
        items = row.get("items") or []
        return [dict(x) for x in items if isinstance(x, dict)][:6]
    except Exception:
        return []

def _home_server_2026_cache_get_any(source, mode):
    """Return the last saved row even when its rotation slot is stale.

    Used only for instant first paint.  The caller still refreshes in the
    background and replaces this stale row when the current slot is ready.
    """
    try:
        key = str(mode or "popular_movies")
        row = _home_server_2026_cache_load(source).get(key) or {}
        items = row.get("items") or []
        return [dict(x) for x in items if isinstance(x, dict)][:6]
    except Exception:
        return []

def _home_server_2026_cache_put(source, mode, items):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)][:6]
    if not rows:
        return False
    try:
        path = _home_server_2026_cache_file(source)
        key = str(mode or "popular_movies")
        data = _home_server_2026_cache_load(source)
        data[key] = {"slot": _home_server_2026_slot(key), "updated": int(time.time()), "items": rows}
        with _HOME_SERVER_2026_ROTATION_LOCK:
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = path + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            try:
                os.replace(tmp, path)
            except Exception:
                os.rename(tmp, path)
        return True
    except Exception:
        return False



from .cache_manager import get_cache_dir, get_cache_root, get_settings as get_cache_settings, save_settings as save_cache_settings, clear_cache, cache_status, cleanup_cache
from .artwork_queue import request_artwork, cached_artwork, prefetch_artwork
from .estalker_picon import direct_picon
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, sx, sy, scale_size

from .package_logos import package_logo_path, package_provider_key, package_logo_for_key
from .core import (
    get_sources, set_sources, write_playlists, PLAYLISTS_FILE,
    XtreamClient, M3UClient, StalkerClient, get_source_client, get_cached_catalog, clear_catalog_memory,
    BASE, load_json, save_json, load_stalker_compat, get_stalker_account_state
)
from .server_status import evaluate_reply

from .artwork_queue import request_artwork, cached_artwork, prefetch_artwork
from .tmdb_client import load_settings as load_tmdb_settings, save_settings as save_tmdb_settings, TMDbClient, IMAGE_BASE, backdrop_url
from .rating_cache import split_ranked, enrich_missing
from .subdl_client import (
    load_settings as load_subdl_settings,
    save_settings as save_subdl_settings,
    LANGUAGE_CHOICES as SUBDL_LANGUAGE_CHOICES,
)
from .filters import (source_filter_key as _source_filter_key, load_all_filters as _load_all_filters,
    save_all_filters as _save_all_filters, get_allowed_category_ids, filter_items as filter_items_for_source,
    filter_categories, get_filtered_streams, get_category_streams, get_category_streams_batch, prefetch_allowed_series,
    prefetch_selected_categories, get_cached_categories, get_recent_preview_items, get_stalker_landing_items, get_stalker_home_items)
from .favorites import (add_favourite, toggle_favourite, is_favourite, list_favourites,
    source_for_record, remove_record, source_id as favourite_source_id, count as favourites_count)
from .update_manager import check_for_update, download_package, install_command
from .i18n import tr, get_language, nav_label, save_language, nav_label


def _sync_native_subtitle_language(language_code):
    """Write Settings #5 language into Enigma2 Auto Language subtitle priority."""
    mapping = {
        "ar": "ara",
        "en": "eng",
        "fr": "fra fre",
        "de": "deu ger",
        "es": "spa",
        "it": "ita",
        "pt": "por",
        "tr": "tur",
        "ru": "rus",
        "fa": "fas per",
    }
    target = mapping.get(str(language_code or "").strip().lower(), "---")
    try:
        auto = getattr(config, "autolanguage", None)
        setting = getattr(auto, "subtitle_autoselect1", None) if auto is not None else None
        if setting is None:
            return False

        # Prefer the canonical value used by Enigma2. If this image exposes a
        # slightly different choice list, choose the first compatible token.
        value = target
        try:
            choices = getattr(setting, "choices", None) or []
            available = []
            for entry in choices:
                raw = entry[0] if isinstance(entry, (tuple, list)) else entry
                available.append(str(raw))
            if available and value not in available:
                tokens = value.split()
                matched = None
                for option in available:
                    option_tokens = set(option.split())
                    if any(tok in option_tokens for tok in tokens):
                        matched = option
                        break
                if matched:
                    value = matched
        except Exception:
            pass

        setting.value = value
        try:
            setting.save()
        except Exception:
            pass

        # Use Enigma2's native cached subtitle selection after the user chooses a track.
        try:
            # Do not reuse a cached subtitle from another title. The preferred language
            # from Settings #5 is applied fresh by Enigma2 Auto Language.
            usecache = getattr(auto, "subtitle_usecache", None)
            if usecache is not None:
                usecache.value = False
                try:
                    usecache.save()
                except Exception:
                    pass
        except Exception:
            pass

        # Allow Arabic subtitles even when the audio language is also Arabic.
        try:
            equal = getattr(auto, "equal_languages", None)
            if equal is not None and str(getattr(equal, "value", "0")) == "0":
                equal.value = "1"
                try:
                    equal.save()
                except Exception:
                    pass
        except Exception:
            pass

        try:
            configfile.save()
        except Exception:
            pass
        return True
    except Exception:
        return False


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
CATCHUP_VERIFY_CACHE_FILE = data_path("catchup_verified.json")
HOME_RECENT_CACHE_MAX_AGE = 21600  # 6 hours; stale data can still paint instantly while background refresh runs.

def _home_cache_root():
    """Prefer persistent HDD, then USB/MMC, then internal flash."""
    candidates = (
        "/media/hdd",
        "/media/usb",
        "/media/usb1",
        "/media/usb2",
        "/media/mmc",
    )
    for mount in candidates:
        try:
            real = os.path.realpath(mount)
            if os.path.isdir(mount) and (os.path.ismount(mount) or os.path.ismount(real)) and os.access(mount, os.W_OK | os.X_OK):
                root = data_path("home")
                ensure_dir(root)
                return root
        except Exception:
            pass
    root = data_path("home")
    try:
        ensure_dir(root)
    except Exception:
        pass
    return root

def _home_recent6_file(source, mode):
    """One tiny cache file per source/mode; it contains at most six rows."""
    raw = "%s|%s" % (_source_identity(source or {}), str(mode or "recent_movies"))
    try:
        key = hashlib.sha1(raw.encode("utf-8")).hexdigest()
    except Exception:
        key = hashlib.sha1(str(raw).encode("utf-8")).hexdigest()
    folder = os.path.join(_home_cache_root(), "recent6")
    try:
        ensure_dir(folder)
    except Exception:
        pass
    return os.path.join(folder, "%s.json" % key)

def _home_movie_index_file():
    return os.path.join(_home_cache_root(), "home_movie_index_cache.json")
SUBDL_IMPORT_FILES = [
    "/media/hdd/tivimatee2/key.txt",
    "/media/hdd/key.txt",
    "/media/usb/tivimatee2/key.txt",
    "/media/usb/key.txt",
    "/media/usb2/tivimatee2/key.txt",
    "/media/usb2/key.txt",
    "/media/usb3/tivimatee2/key.txt",
    "/media/usb3/key.txt",
    "/media/mmc/tivimatee2/key.txt",
    "/media/mmc/key.txt",
    "/media/sdcard/tivimatee2/key.txt",
    "/media/sdcard/key.txt",
    "/mnt/hdd/tivimatee2/key.txt",
    "/mnt/hdd/key.txt",
    "/mnt/usb/tivimatee2/key.txt",
    "/mnt/usb/key.txt",
    "/mnt/mmc/tivimatee2/key.txt",
    "/mnt/mmc/key.txt",
    data_path("key.txt"),
    data_path("subdl.key"),
    data_path("key.txt"),
    data_path("subdl.key"),
    "/tmp/tivimatee2/key.txt",
]
SUBDL_LAST_IMPORT_FILE = ""
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
INFO_FETCH = os.path.join(PLUGIN_PATH, "info_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()

# Process-local currently playing Live channel identity. This survives closing
# the fullscreen player back to the Live list, unlike a per-screen variable.
_CURRENT_LIVE_CHANNEL = {"source": "", "channel": ""}



def _read_subdl_key_file(path):
    with open_text(path, "rb") as handle:
        raw = handle.read(1025)
    if len(raw) > 1024:
        raise ValueError("too_long")
    try:
        value = raw.decode("utf-8", "ignore")
    except Exception:
        value = str(raw)
    lines = [line.strip() for line in value.replace("\ufeff", "").splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("invalid_content")
    return lines[0]


def _read_subdl_import_key():
    """Read the first valid SubDL key from common HDD/USB/MMC/config locations."""
    global SUBDL_LAST_IMPORT_FILE
    SUBDL_LAST_IMPORT_FILE = ""
    invalid = None
    for path in SUBDL_IMPORT_FILES:
        if not os.path.isfile(path):
            continue
        try:
            value = _read_subdl_key_file(path)
            SUBDL_LAST_IMPORT_FILE = path
            return value
        except ValueError as exc:
            invalid = exc
    if invalid is not None:
        raise invalid
    raise IOError("missing")


def _remove_subdl_import_file():
    path = SUBDL_LAST_IMPORT_FILE
    if not path:
        return False
    try:
        os.remove(path)
        return True
    except Exception:
        return False
# Artwork is now processed by artwork_queue with two background transfers.
# Keep this switch false so legacy screen paths can show cached/queued artwork.
SAFE_TABLE_MODE = False
CHANNEL_SETTINGS_FILE = data_path("channel_settings.json")
LIVE_SOURCE_FILE = data_path("live_source.json")
MAIN_SOURCE_FILE = data_path("active_source.json")
STALKER_HIDDEN_FILE = data_path("stalker_hidden.json")
STALKER_PIN_FILE = data_path("stalker_pin.json")
STALKER_RECENT_FILE = data_path("resume.json")
XTREAM_HIDDEN_FILE = data_path("xtream_hidden.json")
XTREAM_PIN_FILE = data_path("xtream_pin.json")
XTREAM_SERVICE_TYPES_FILE = data_path("xtream_service_types.json")


def _load_xtream_hidden(source):
    data = load_json(XTREAM_HIDDEN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_xtream_hidden(source, state):
    data = load_json(XTREAM_HIDDEN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(XTREAM_HIDDEN_FILE, data)


def _load_xtream_pin(source):
    data = load_json(XTREAM_PIN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "pin": str(state.get("pin") or "0000"),
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_xtream_pin(source, state):
    data = load_json(XTREAM_PIN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "pin": str(state.get("pin") or "0000"),
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(XTREAM_PIN_FILE, data)


def _load_xtream_service_types(source):
    defaults = {"live": 4097, "vod": 4097, "series": 4097}
    data = load_json(XTREAM_SERVICE_TYPES_FILE, {}) or {}
    saved = data.get(_source_identity(source), {}) if isinstance(data, dict) else {}
    for key in defaults:
        try:
            value = int(saved.get(key, defaults[key]))
            if value in STALKER_SERVICE_TYPE_CHOICES:
                defaults[key] = value
        except Exception:
            pass
    return defaults


def _save_xtream_service_types(source, values):
    data = load_json(XTREAM_SERVICE_TYPES_FILE, {}) or {}
    clean = {}
    for key in ("live", "vod", "series"):
        try: value = int((values or {}).get(key, 4097))
        except Exception: value = 4097
        clean[key] = value if value in STALKER_SERVICE_TYPE_CHOICES else 4097
    data[_source_identity(source)] = clean
    return save_json(XTREAM_SERVICE_TYPES_FILE, data)


def _xtream_service_type(source, kind):
    return int(_load_xtream_service_types(source).get(kind, 4097))


def _load_stalker_recent(source, limit=30):
    data = load_json(STALKER_RECENT_FILE, {}) or {}
    source_key = _source_identity(source)
    rows = []
    for resume_key, row in data.items():
        if not isinstance(row, dict) or row.get("source_type") != "stalker":
            continue
        if row.get("source_key") != source_key:
            continue
        item = row.get("item") or {}
        if not isinstance(item, dict):
            continue
        rows.append((resume_key, row))
    rows.sort(key=lambda pair: int((pair[1] or {}).get("updated", 0)), reverse=True)
    return rows[:max(1, int(limit or 30))]


def _hidden_source_key(source):
    raw = _source_identity(source).encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()


def _load_stalker_hidden(source):
    data = load_json(STALKER_HIDDEN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_stalker_hidden(source, state):
    data = load_json(STALKER_HIDDEN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(STALKER_HIDDEN_FILE, data)



def _load_stalker_pin(source):
    data = load_json(STALKER_PIN_FILE, {}) or {}
    state = data.get(_hidden_source_key(source)) or {}
    return {
        "pin": str(state.get("pin") or "0000"),
        "categories": set(str(x) for x in (state.get("categories") or [])),
        "channels": set(str(x) for x in (state.get("channels") or [])),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }


def _save_stalker_pin(source, state):
    data = load_json(STALKER_PIN_FILE, {}) or {}
    data[_hidden_source_key(source)] = {
        "pin": str(state.get("pin") or "0000"),
        "categories": sorted(state.get("categories") or []),
        "channels": sorted(state.get("channels") or []),
        "category_names": dict(state.get("category_names") or {}),
        "channel_names": dict(state.get("channel_names") or {}),
    }
    return save_json(STALKER_PIN_FILE, data)


def _adult_source_enabled(source):
    raw = (source or {}).get("adult_enabled", False)
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "enabled")

def _adult_live_name(name):
    text = str(name or "").strip().lower()
    if not text:
        return False
    # Explicit provider markers only. Any 3+ consecutive X catches XXX/XXXX/etc.
    if re.search(r"(^|[^a-z0-9])x{3,}([^a-z0-9]|$)", text, re.I):
        return True
    markers = (
        "adult", "adults only", "adult only", "porn", "porno",
        "pornography", "erotic", "erotica", "playboy", "brazzers",
        "redlight", "red light", u"اباحي", u"إباحي", u"إباحية",
    )
    return any(marker in text for marker in markers)

def _live_item_id(item):
    item = item or {}
    return str(item.get("ch_id") or item.get("stream_id") or item.get("id") or item.get("cmd") or item.get("url") or item.get("name") or "")




def _source_identity(source):
    source = source or {}
    return u"%s|%s|%s|%s" % (
        source.get("type", ""),
        (source.get("url") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
        source.get("username", ""),
        source.get("mac", ""),
    )


def _load_live_source(fallback=None):
    sources = get_sources()
    if not sources:
        return fallback
    try:
        with open_text(LIVE_SOURCE_FILE, "r") as handle:
            saved_key = (json.load(handle) or {}).get("key", "")
        for candidate in sources:
            if _source_identity(candidate) == saved_key:
                return candidate
    except Exception:
        pass
    fallback_key = _source_identity(fallback)
    for candidate in sources:
        if _source_identity(candidate) == fallback_key:
            return candidate
    return sources[0]


def _save_live_source(source):
    try:
        ensure_dir(os.path.dirname(LIVE_SOURCE_FILE))
        with open_text(LIVE_SOURCE_FILE, "w") as handle:
            json.dump({"key": _source_identity(source)}, handle)
        return True
    except Exception:
        return False


def _load_main_source(fallback=None):
    """Return the Home/VOD provider independently from the remembered Live provider."""
    sources = get_sources()
    if not sources:
        return fallback
    try:
        with open_text(MAIN_SOURCE_FILE, "r") as handle:
            saved_key = (json.load(handle) or {}).get("key", "")
        for candidate in sources:
            if _source_identity(candidate) == saved_key:
                return candidate
    except Exception:
        pass
    fallback_key = _source_identity(fallback)
    for candidate in sources:
        if _source_identity(candidate) == fallback_key:
            return candidate
    for candidate in sources:
        if candidate.get("type") == "xtream":
            return candidate
    return sources[0]

LIVE_POSTER_INDEX_FILE = data_path("live_poster_index.json")
BEIN_CACHE_FILE = data_path("bein_cache.json")
BEIN_CACHE_MAX_AGE = 1800
_LIVE_POSTER_URLS = None

def _bein_base_source(source):
    source = source or {}
    if source.get("_virtual_bein"):
        if isinstance(source.get("_bein_provider"), dict):
            return dict(source.get("_bein_provider") or {})
        if isinstance(source.get("base_source"), dict):
            return dict(source.get("base_source") or {})
    return dict(source)


def _bein_cache_key(source):
    return _source_identity(_bein_base_source(source))


def _load_bein_cache(source, max_age=BEIN_CACHE_MAX_AGE):
    data = load_json(BEIN_CACHE_FILE, {}) or {}
    row = data.get(_bein_cache_key(source)) or {}
    try:
        stamp = int(row.get("timestamp") or 0)
    except Exception:
        stamp = 0
    items = row.get("items") or []
    if not isinstance(items, list):
        items = []
    fresh = bool(items and stamp and (int(time.time()) - stamp) <= int(max_age))
    return items, fresh, stamp


def _save_bein_cache(source, items):
    data = load_json(BEIN_CACHE_FILE, {}) or {}
    data[_bein_cache_key(source)] = {
        "timestamp": int(time.time()),
        "items": list(items or []),
    }
    # Keep only a small number of server caches on compact receivers.
    if len(data) > 8:
        ordered = sorted(data.items(), key=lambda kv: int((kv[1] or {}).get("timestamp") or 0), reverse=True)[:8]
        data = dict(ordered)
    return save_json(BEIN_CACHE_FILE, data)


def _make_bein_virtual_source(source):
    # Keep the beIN view completely separate from the real provider object.
    # Only the private provider copy is used for fetching/playing channels.
    base = _bein_base_source(source)
    virtual = {
        "type": "bein",
        "name": "beIN SPORTS",
        "service_type": base.get("service_type", 4097),
        "_virtual_bein": True,
        "_bein_provider": base,
    }
    return virtual


def _load_live_poster_urls():
    global _LIVE_POSTER_URLS
    if isinstance(_LIVE_POSTER_URLS, dict):
        return _LIVE_POSTER_URLS
    data = {}
    try:
        with open_text(LIVE_POSTER_INDEX_FILE, "r") as handle:
            raw = json.load(handle) or {}
        if isinstance(raw, dict):
            data = {str(k): str(v) for k, v in raw.items() if k and v}
    except Exception:
        pass
    _LIVE_POSTER_URLS = data
    return _LIVE_POSTER_URLS

def _save_live_poster_url(key, url):
    if not key or not url:
        return
    data = _load_live_poster_urls()
    if data.get(key) == url:
        return
    data[key] = url
    # Keep the index bounded for compact receivers.
    if len(data) > 1200:
        for old_key in list(data.keys())[:len(data) - 1000]:
            data.pop(old_key, None)
    try:
        tmp = LIVE_POSTER_INDEX_FILE + ".tmp"
        with open_text(tmp, "w") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        atomic_replace(tmp, LIVE_POSTER_INDEX_FILE)
    except Exception:
        pass

def _live_poster_key(title):
    return re.sub(r"\s+", " ", str(title or "").strip().lower())

def _load_channel_settings():
    # These settings belong strictly to Live playback and the visual interface.
    defaults = {"auto_zap": True, "picon": True, "service_type": 4097, "live_color": "#008080", "live_theme": "turquoise"}
    try:
        with open_text(CHANNEL_SETTINGS_FILE, "r") as f:
            data = json.load(f) or {}
        defaults.update({k: bool(data.get(k, defaults[k])) for k in ("auto_zap", "picon")})
        try:
            defaults["service_type"] = int(data.get("service_type", 4097))
        except Exception:
            defaults["service_type"] = 4097
        color = str(data.get("live_color", defaults["live_color"]) or defaults["live_color"]).strip()
        if color.startswith("#") and len(color) in (7, 9):
            defaults["live_color"] = color
        theme = str(data.get("live_theme", defaults["live_theme"]) or defaults["live_theme"]).strip().lower()
        if theme in ("turquoise", "blue", "green", "gold", "purple", "silver"):
            defaults["live_theme"] = theme
    except Exception:
        pass
    return defaults

def _save_channel_settings(data):
    try:
        folder = os.path.dirname(CHANNEL_SETTINGS_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        tmp = CHANNEL_SETTINGS_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump(data, f)
        os.rename(tmp, CHANNEL_SETTINGS_FILE)
        return True
    except Exception:
        return False



STALKER_SERVICE_TYPES_FILE = data_path("stalker_service_types.json")
STALKER_SERVICE_TYPE_CHOICES = (1, 4097, 5001, 5002)
STREAM_TYPE_CONFIG_CHOICES = [("1", "DVB service (1)"), ("4097", "GStreamer (4097)"), ("5001", "GstPlayer (5001)"), ("5002", "ExtePlayer3 (5002)")]

def _clean_stream_type(value, default=4097):
    try:
        parsed = int(value)
    except Exception:
        parsed = int(default)
    return parsed if parsed in STALKER_SERVICE_TYPE_CHOICES else 4097

def _stalker_service_key(source):
    try:
        return _source_identity(source or {})
    except Exception:
        source = source or {}
        return "%s|%s" % (source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _load_stalker_service_types(source):
    defaults = {"live": 4097, "vod": 4097, "series": 4097}
    try:
        with open_text(STALKER_SERVICE_TYPES_FILE, "r") as handle:
            raw = json.load(handle) or {}
        saved = raw.get(_stalker_service_key(source), {}) if isinstance(raw, dict) else {}
        for name in defaults:
            value = int(saved.get(name, defaults[name]))
            if value in STALKER_SERVICE_TYPE_CHOICES:
                defaults[name] = value
    except Exception:
        pass
    return defaults

def _save_stalker_service_types(source, values):
    try:
        folder = os.path.dirname(STALKER_SERVICE_TYPES_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        raw = {}
        try:
            with open_text(STALKER_SERVICE_TYPES_FILE, "r") as handle:
                loaded = json.load(handle) or {}
                if isinstance(loaded, dict):
                    raw = loaded
        except Exception:
            pass
        clean = {}
        for name in ("live", "vod", "series"):
            value = int((values or {}).get(name, 4097))
            clean[name] = value if value in STALKER_SERVICE_TYPE_CHOICES else 4097
        raw[_stalker_service_key(source)] = clean
        tmp = STALKER_SERVICE_TYPES_FILE + ".tmp"
        with open_text(tmp, "w") as handle:
            json.dump(raw, handle, separators=(",", ":"))
        atomic_replace(tmp, STALKER_SERVICE_TYPES_FILE)
        return True
    except Exception:
        return False

def _stalker_service_type(source, kind):
    return int(_load_stalker_service_types(source).get(kind, 4097))


def _connect_timer(timer, callback):
    """Connect eTimer on DreamOS and OE-A images without duplicate callbacks."""
    try:
        timer.timeout.connect(callback)
        return
    except Exception:
        pass
    try:
        timer.callback.append(callback)
        return
    except Exception:
        pass
    try:
        timer.timeout.get().append(callback)
    except Exception:
        pass


class LiveCategoryMenuList(MenuList):
    """Live packages list with a permanently gold Favorites star.

    The rest of each row keeps the active skin's normal and selected colors,
    so switching Live styles does not alter the existing icons or theme logic.
    """
    def __init__(self, entries=None):
        MenuList.__init__(self, entries or [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 21))
            self.l.setItemHeight(48)
            self.l.setBuildFunc(self._build_entry)
        except Exception:
            pass

    def _build_entry(self, name, category_id):
        name = str(name or "")
        category_id = str(category_id or "")
        result = [(name, category_id)]
        if category_id == "__favorites__":
            result.append(MultiContentEntryText(
                pos=(4, 0), size=(34, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=u"★", color=0x00FFD700,
                color_sel=0x00FFD700
            ))
            label = name.replace(u"★", "").strip()
            result.append(MultiContentEntryText(
                pos=(42, 0), size=(270, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=label
            ))
        else:
            result.append(MultiContentEntryText(
                pos=(4, 0), size=(308, 48), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=name
            ))
        return result

HOME_APPEARANCE_FILE = data_path("home_appearance.json")

def _load_home_appearance():
    # Popular is the default everywhere on a fresh installation.
    data = {
        "skin": "skin2_dark",
        "content": "popular_movies",
        "movies_content": "none",
        "series_content": "none",
        "show_netflix_package": False,
        "show_prime_package": False,
    }
    try:
        with open_text(HOME_APPEARANCE_FILE, "r") as f:
            saved = json.load(f)
        _saved_skin = saved.get("skin")
        if _saved_skin == "skin3_accessibility":
            # Accessibility Skin 3 was retired; migrate existing users to Skin 2.
            data["skin"] = "skin2_dark"
        elif _saved_skin in ("reference_home", "skin2_dark"):
            data["skin"] = _saved_skin
        if saved.get("content") in (
            "popular_movies", "popular_series", "trending_movies", "trending_series"
        ):
            data["content"] = saved.get("content")
        if saved.get("movies_content") == "none":
            data["movies_content"] = "none"
        if saved.get("series_content") == "none":
            data["series_content"] = "none"
        data["show_netflix_package"] = bool(saved.get("show_netflix_package", False))
        data["show_prime_package"] = bool(saved.get("show_prime_package", False))
    except Exception:
        pass
    return data

def _save_home_appearance(skin_name, content_mode=None, movies_content=None, series_content=None, show_netflix_package=None, show_prime_package=None):
    try:
        folder = os.path.dirname(HOME_APPEARANCE_FILE)
        if not os.path.isdir(folder): os.makedirs(folder)
        current = _load_home_appearance()
        payload = {
            "skin": skin_name or current.get("skin", "skin2_dark"),
            "content": content_mode or current.get("content", "popular_movies"),
            "movies_content": movies_content or current.get("movies_content", "none"),
            "series_content": series_content or current.get("series_content", "none"),
            "show_netflix_package": current.get("show_netflix_package", False) if show_netflix_package is None else bool(show_netflix_package),
            "show_prime_package": current.get("show_prime_package", False) if show_prime_package is None else bool(show_prime_package),
        }
        tmp = HOME_APPEARANCE_FILE + ".tmp"
        with open_text(tmp, "w") as f:
            json.dump(payload, f)
        os.rename(tmp, HOME_APPEARANCE_FILE)
        return True
    except Exception:
        return False


UPDATE_SETTINGS_FILE = data_path("update_settings.json")

def _load_update_settings():
    defaults = {"auto_check": True}
    try:
        with open_text(UPDATE_SETTINGS_FILE, "r") as handle:
            stored = json.load(handle) or {}
        defaults["auto_check"] = bool(stored.get("auto_check", defaults["auto_check"]))
    except Exception:
        pass
    return defaults


def _save_update_settings(auto_check):
    try:
        folder = os.path.dirname(UPDATE_SETTINGS_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = UPDATE_SETTINGS_FILE + ".tmp"
        with open_text(temporary, "w") as handle:
            json.dump({"auto_check": bool(auto_check)}, handle)
        os.rename(temporary, UPDATE_SETTINGS_FILE)
        return True
    except Exception:
        return False

HOME_SKIN1 = '''<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050C14">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home_reference_v4_bg_r77_1920x1080.png" alphatest="blend" zPosition="0" />
		<widget name="homeBrandLogo" position="62,10" size="300,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="6" />
	<ePixmap position="13,320" size="64,273" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/sidebar_classic_icons_v2.png" alphatest="blend" zPosition="6" />
	<widget name="headline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="subheadline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="logo" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <ePixmap position="335,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="5" />
    <widget name="nav0" position="364,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="490,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="5" />
    <widget name="nav1" position="519,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="645,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="5" />
    <widget name="nav2" position="674,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="800,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="5" />
    <widget name="nav3" position="829,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="955,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="5" />
    <widget name="nav4" position="984,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="1110,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="5" />
    <widget name="nav5" position="1139,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="1265,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="5" />
    <widget name="nav6" position="1294,27" size="111,58" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
    <ePixmap position="1420,44" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="5" />
    <widget name="nav7" position="1449,27" size="111,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
	<widget name="navSelector" position="520,27" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
	<widget name="clock" position="1595,16" size="275,28" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
	<widget name="date" position="1595,48" size="275,20" font="Regular;14" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />

	<widget name="banner" position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder_v4.jpg" alphatest="blend" scale="1" zPosition="1" />
<ePixmap position="108,120" size="1704,454" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_overlay_v4.png" alphatest="blend" zPosition="2" />
<widget name="quality" position="155,151" size="330,30" font="Regular;20" foregroundColor="#27C8FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureTitle" position="155,194" size="720,112" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureMeta" position="155,324" size="700,36" font="Regular;23" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="featureDesc" position="155,371" size="720,84" font="Regular;22" foregroundColor="#DDE5EF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="playNow" position="155,498" size="240,60" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" zPosition="4" />
<widget name="recentTitle" position="100,610" size="500,42" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="poster0" position="114,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="116,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate0" position="116,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle0" position="184,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster1" position="406,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="398,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="408,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate1" position="408,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle1" position="476,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster2" position="698,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="690,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="700,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate2" position="700,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle2" position="768,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster3" position="990,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="982,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="992,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate3" position="992,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle3" position="1060,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster4" position="1282,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1274,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1284,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate4" position="1284,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle4" position="1352,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="poster5" position="1574,684" size="232,276" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1566,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_248x338.png" alphatest="blend" zPosition="3" />
<ePixmap position="1576,969" size="58,34" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_58x34.png" alphatest="blend" zPosition="5" />
<widget name="posterMetaRate5" position="1576,969" size="58,34" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="posterMetaTitle5" position="1644,958" size="160,56" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" halign="left" valign="center" zPosition="5" transparent="1" />
<widget name="posterSelector" position="106,676" size="248,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_248x338.png" alphatest="blend" zPosition="8" />
<widget name="status" position="520,1038" size="880,26" font="Regular;17" foregroundColor="#95A2B5" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

HOME_SKIN3_ACCESSIBILITY = '''<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05080D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#05080D" zPosition="0" />
    <eLabel position="0,0" size="1920,92" backgroundColor="#090D12" zPosition="1" />

    <widget name="banner" position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_global_hero_r70.png" alphatest="blend" scale="1" zPosition="1" />
    <ePixmap position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_cinema_hero_overlay.png" alphatest="blend" zPosition="2" />

    <widget name="logo" position="-20,-20" size="1,1" font="Regular;5" transparent="1" />
    <widget name="homeBrandLogo" position="28,10" size="285,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="7" />
    <eLabel position="269,48" size="82,26" text="v1.0.08" font="Regular;21" foregroundColor="#E2B84B" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="9" />
    <widget name="headline" position="-20,-20" size="1,1" font="Regular;5" transparent="1" />
    <widget name="subheadline" position="-20,-20" size="1,1" font="Regular;5" transparent="1" />

        <ePixmap position="335,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="8" />
    <widget name="nav0" position="364,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="490,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="8" />
    <widget name="nav1" position="519,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="645,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="8" />
    <widget name="nav2" position="674,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="800,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="8" />
    <widget name="nav3" position="829,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="955,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="8" />
    <widget name="nav4" position="984,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1110,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="8" />
    <widget name="nav5" position="1139,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1265,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="8" />
    <widget name="nav6" position="1294,15" size="111,64" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1420,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="8" />
    <widget name="nav7" position="1449,15" size="111,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <widget name="navSelector" position="467,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
    <widget name="clock" position="1595,18" size="210,34" font="Regular;36" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="7" />
    <widget name="date" position="1575,56" size="230,24" font="Regular;24" foregroundColor="#A9B3BD" transparent="1" halign="right" zPosition="7" />

    <widget name="quality" position="48,148" size="680,32" font="Regular;25" foregroundColor="#E2B84B" transparent="1" zPosition="7" />
    <widget name="featureTitle" position="48,180" size="760,72" font="Regular;42" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="7" />
    <widget name="featureMeta" position="48,258" size="700,42" font="Regular;28" foregroundColor="#E5EAF0" transparent="1" valign="center" zPosition="7" />
    <widget name="featureDesc" position="48,305" size="680,82" font="Regular;26" foregroundColor="#D5DCE4" transparent="1" zPosition="7" />
    <eLabel position="48,395" size="245,56" backgroundColor="#B7181F" cornerRadius="12" zPosition="6" />
    <widget name="playNow" position="48,395" size="245,56" font="Regular;29" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="7" />
    <eLabel position="315,395" size="245,56" text="ⓘ  More Info" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" cornerRadius="12" zPosition="7" />

    <widget name="recentTitle" position="55,468" size="560,40" font="Regular;30" foregroundColor="#F1C84C" transparent="1" halign="left" zPosition="8" />

    <widget name="poster0" position="62,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="55,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate0" position="67,770" size="58,36" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle0" position="66,819" size="193,43" font="Regular;24" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster1" position="382,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="375,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate1" position="387,770" size="58,36" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle1" position="386,819" size="193,43" font="Regular;24" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster2" position="702,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="695,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate2" position="707,770" size="58,36" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle2" position="706,819" size="193,43" font="Regular;24" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster3" position="1022,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1015,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate3" position="1027,770" size="58,36" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle3" position="1026,819" size="193,43" font="Regular;24" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster4" position="1342,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1335,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate4" position="1347,770" size="58,36" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle4" position="1346,819" size="193,43" font="Regular;24" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster5" position="1662,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1655,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate5" position="1667,770" size="58,36" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle5" position="1666,819" size="193,43" font="Regular;24" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="posterSelector" position="53,508" size="219,364" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_card_focus_reference_215x360.png" alphatest="blend" zPosition="10" />

<!-- Akcioni dugmadi -->
<eLabel position="45,888" size="1830,74" backgroundColor="#0F151C" zPosition="5" />

<!-- Zeleno dugme -->
<eLabel position="55,898" size="425,54"
        backgroundColor="#176B3A"
        cornerRadius="12"
        zPosition="6" />

<!-- Zlatno dugme -->
<eLabel position="505,898" size="425,54"
        backgroundColor="#B07A00"
        cornerRadius="12"
        zPosition="6" />

<!-- Plavo dugme - ostaje kako je dobro -->
<eLabel position="955,898" size="425,54"
        backgroundColor="#13568C"
        cornerRadius="12"
        zPosition="6" />

<!-- Crveno dugme - ostaje kako je dobro -->
<eLabel position="1405,898" size="425,54"
        backgroundColor="#A61D24"
        cornerRadius="12"
        zPosition="6" />


<!-- Zeleno dugme -->
<widget name="actionLabel0"
        position="55,898"
        size="425,54"
        font="Regular;36"
        foregroundColor="#FFF4C7"
        transparent="1"
        halign="center"
        valign="center"
        zPosition="8" />

<!-- Zlatno dugme -->
<widget name="actionLabel1"
        position="505,898"
        size="425,54"
        font="Regular;36"
        foregroundColor="#0D2A35"
        transparent="1"
        halign="center"
        valign="center"
        zPosition="8" />

<!-- Plavo dugme -->
<widget name="actionLabel2"
        position="955,898"
        size="425,54"
        font="Regular;36"
        foregroundColor="#FFFFFF"
        transparent="1"
        halign="center"
        valign="center"
        zPosition="8" />

<!-- Crveno dugme -->
<widget name="actionLabel3"
        position="1405,898"
        size="425,54"
        font="Regular;36"
        foregroundColor="#FFFFFF"
        transparent="1"
        halign="center"
        valign="center"
        zPosition="8" />

    <eLabel position="45,974" size="575,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <eLabel position="645,974" size="620,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <ePixmap position="853,979" size="204,63" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/developed_by_opesboy_badge.png" alphatest="blend" scale="1" zPosition="9" />
    <eLabel position="1290,974" size="540,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <widget name="skin2HelpTitle" position="68,985" size="225,28" font="Regular;26" foregroundColor="#E2B84B" transparent="1" zPosition="8" />
    <widget name="skin2HelpBody" position="68,1014" size="520,28" font="Regular;21" foregroundColor="#C4CED8" transparent="1" zPosition="8" />
    <widget name="skin2LangTitle" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#E2B84B" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2LangBody" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#C4CED8" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2Key5" position="1310,986" size="500,54" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="status" position="510,1048" size="900,28" font="Regular;21" foregroundColor="#B8C3CD" transparent="1" halign="center" valign="center" zPosition="8" />
</screen>'''

SEARCH_SCREEN = '''<screen name="TiviMateE2Search" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#070A0F">
<eLabel position="0,0" size="1920,1080" backgroundColor="#070A0F" zPosition="0" />
<ePixmap position="36,82" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
<ePixmap position="46,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="76,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="231,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="261,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="416,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="446,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="601,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="631,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="786,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="816,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="971,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="1001,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1156,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1186,18" size="314,46" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1516,29" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1546,18" size="139,46" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="topSelector" position="45,66" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
<widget name="back" position="30,104" size="70,70" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<eLabel position="394,91" size="1132,94" backgroundColor="#3A3020" zPosition="1" />
<eLabel position="398,95" size="1124,86" backgroundColor="#0B1017" zPosition="2" />
<ePixmap position="400,97" size="1120,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_bar.png" alphatest="blend" zPosition="3" />
<widget name="searchText" position="460,112" size="900,52" font="Regular;30" foregroundColor="#F3F4F8" backgroundColor="#00000000" transparent="1" valign="center" zPosition="2" />
<widget name="mic" position="1365,97" size="70,82" font="Regular;36" foregroundColor="#F5C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="closeIcon" position="1445,97" size="70,82" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" />
<widget name="moviesTitle" position="70,202" size="1160,46" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" />
<widget name="showsTitle" position="70,950" size="1160,28" font="Regular;21" foregroundColor="#AAB3C1" backgroundColor="#00000000" transparent="1" />
<widget name="poster0" position="70,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate0" position="78,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel0" position="78,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster1" position="315,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="315,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate1" position="323,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel1" position="323,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster2" position="560,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="560,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate2" position="568,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel2" position="568,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster3" position="805,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate3" position="813,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel3" position="813,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster4" position="1050,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1050,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate4" position="1058,463" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel4" position="1058,500" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster5" position="70,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate5" position="78,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel5" position="78,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster6" position="315,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="315,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate6" position="323,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel6" position="323,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster7" position="560,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="560,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate7" position="568,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel7" position="568,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster8" position="805,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="805,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate8" position="813,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel8" position="813,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="poster9" position="1050,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1050,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_200x285.png" alphatest="blend" zPosition="3" />
<widget name="posterRate9" position="1058,791" size="52,30" font="Regular;15" foregroundColor="#FFFFFF" backgroundColor="#1C222B" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel9" position="1058,828" size="188,32" font="Regular;17" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="5" />
<widget name="movieSelector" position="70,257" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_200x285.png" alphatest="blend" zPosition="8" />
<widget name="showSelector" position="70,585" size="200,285" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_200x285.png" alphatest="blend" zPosition="8" />
<eLabel position="1310,165" size="545,765" backgroundColor="#0C1118" zPosition="1" />
<eLabel position="1310,165" size="4,765" backgroundColor="#E2B84B" zPosition="2" />
<eLabel position="1467,187" size="231,321" backgroundColor="#E2B84B" zPosition="2" />
<eLabel position="1471,191" size="223,313" backgroundColor="#111821" zPosition="3" />
<widget name="detailPoster" position="1475,195" size="215,305" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="4" />
<widget name="selectedTitle" position="1350,520" size="465,90" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" valign="center" zPosition="3" />
<widget name="selectedMeta" position="1350,610" size="465,180" font="Regular;21" foregroundColor="#D6DBE3" backgroundColor="#00000000" transparent="1" valign="top" zPosition="3" />
<widget name="selectedOverview" position="1350,790" size="465,105" font="Regular;18" foregroundColor="#AEB7C5" backgroundColor="#00000000" transparent="1" valign="top" zPosition="3" />
<widget name="play" position="1350,900" size="215,48" font="Regular;22" foregroundColor="#111318" backgroundColor="#E2B84B" halign="center" valign="center" zPosition="3" />
<widget name="favorite" position="1580,900" size="235,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#2A313B" halign="center" valign="center" zPosition="3" />
<widget name="pageInfo" position="500,980" size="400,40" font="Regular;22" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" />
<widget name="status" position="330,1022" size="750,32" font="Regular;19" foregroundColor="#D2D8E1" backgroundColor="#00000000" transparent="1" halign="center" />
<eLabel position="95,1002" size="290,54" backgroundColor="#111821" zPosition="3" />
<eLabel position="98,1005" size="54,48" text="←" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
<eLabel position="160,1007" size="210,42" text="نتائج أكثر يسار" font="Regular;20" foregroundColor="#E7ECF2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
<widget name="guideBar" position="-10,-10" size="1,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/search_guide_r69.png" alphatest="blend" zPosition="1" />
<eLabel position="1535,1002" size="290,54" backgroundColor="#111821" zPosition="3" />
<eLabel position="1768,1005" size="54,48" text="→" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
<eLabel position="1548,1007" size="210,42" text="نتائج أكثر يمين" font="Regular;20" foregroundColor="#E7ECF2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
</screen>'''

EDITOR = '''<screen name="TiviMateE2PlaylistEditor" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <!-- RGB PNG base: one opaque navy colour, with no alpha channel or panel overlays. -->
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_web_blue_r28.png" alphatest="blend" zPosition="0" />
    <widget name="settingsLogo" position="78,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNavSelector" position="1215,27" size="165,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_classic_focus_v5.png" alphatest="blend" zPosition="3" />
    <widget name="settingsNav0" position="450,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav1" position="603,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav2" position="756,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav3" position="909,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav4" position="1062,27" size="153,58" font="Regular;25" foregroundColor="#D8DEE8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsNav5" position="1215,27" size="165,58" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="4" />
    <widget name="settingsClock" position="1430,28" size="160,34" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsDate" position="1430,67" size="190,26" font="Regular;17" foregroundColor="#91A0B4" backgroundColor="#00000000" transparent="1" halign="left" zPosition="4" />
    <widget name="settingsSideTitle" position="92,182" size="330,54" font="Regular;32" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <ePixmap position="190,242" size="140,140" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/control_center_gear_r31.png" alphatest="blend" zPosition="4" />
    <widget name="settingsSideText" position="98,350" size="318,72" font="Regular;20" foregroundColor="#D6E4F2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <widget name="settingsSideHint" position="100,736" size="316,78" font="Regular;20" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="3" />
    <ePixmap position="110,430" size="286,270" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_card_r64.png" alphatest="blend" zPosition="2" />
    <ePixmap position="130,447" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_globe_r64.png" alphatest="blend" zPosition="4" />
    <widget name="languageTitle" position="170,446" size="205,36" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="languageSelector" position="124,492" size="258,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_row_focus_r64.png" alphatest="blend" zPosition="3" />
    <widget name="language0" position="146,498" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="language1" position="146,562" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="language2" position="146,626" size="174,44" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
    <widget name="languageRadio0" position="334,504" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="languageRadio1" position="334,568" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="languageRadio2" position="334,632" size="32,32" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_radio_off_r64.png" alphatest="blend" zPosition="5" />
    <widget name="title" position="500,196" size="1260,52" font="Regular;39" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />
    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />
    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
    <widget name="settingsGuide" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_guide_keyboard_save_r69.png" alphatest="blend" zPosition="4" />
</screen>'''

XTREAM_EDITOR_SKIN = EDITOR
STALKER_EDITOR_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="StalkerPortalEditor"')

# Server Manager keeps the existing menu, navigation and action bar intact.  Only
# the unused lower space becomes a general connection-status card; no account or
# subscriber information is displayed here.
SERVER_MANAGER_SKIN = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ServerManager"').replace(
    '''    <widget name="config" position="500,294" size="1230,480" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <widget name="hint" position="500,878" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="3" />''',
    '''    <widget name="config" position="500,294" size="1230,380" itemHeight="68" foregroundColor="#F5F8FC" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" zPosition="3" />
    <eLabel position="500,792" size="1230,132" backgroundColor="#10233A" zPosition="1" />
    <eLabel position="502,794" size="1226,128" backgroundColor="#142B46" zPosition="2" />
    <ePixmap position="1298,796" size="430,124" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_network_r123.png" alphatest="blend" zPosition="3" />
    <widget name="serverStatusTitle" position="536,808" size="650,28" font="Regular;24" foregroundColor="#F2FBFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="serverStatusText" position="536,844" size="650,26" font="Regular;20" foregroundColor="#B9CDE0" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOnlineIcon" position="536,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_online_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOnline" position="562,875" size="170,26" font="Regular;18" foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendCheckingIcon" position="740,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_busy_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendChecking" position="766,875" size="185,26" font="Regular;18" foregroundColor="#FFD669" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="statusLegendOfflineIcon" position="960,878" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_status_offline_r123.png" alphatest="blend" zPosition="4" />
    <widget name="statusLegendOffline" position="986,875" size="185,26" font="Regular;18" foregroundColor="#FF8C95" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="hint" position="500,892" size="1230,34" font="Regular;22" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" zPosition="5" />'''
)
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '</screen>',
    '    <widget name="settingsActionButtons" position="500,944" size="1230,108" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_action_buttons_poster_r133.png" alphatest="blend" zPosition="4" />\n</screen>'
)

# r111: visible experimental-settings entry in the existing Settings / Server Manager screen.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '</screen>',
    '    <eLabel position="92,696" size="300,82" backgroundColor="#241D0B" cornerRadius="14" zPosition="5" />\n'
    '    <eLabel position="96,700" size="292,74" backgroundColor="#0C1A28" cornerRadius="12" zPosition="6" />\n'
    '    <widget name="settingsNewButton" position="108,710" size="268,54" font="Regular;22" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="7" />\n'
    '</screen>'
)


# Test73: enlarge only the Server Manager list area. Keep the simple list style
# and leave editors, language card, navigation, and action buttons unchanged.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(
    '<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n'
    '    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n'
    '    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />',
    '<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />\n'
    '    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />\n'
    '    <widget name="config" position="495,286" size="1135,410" itemHeight="88" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_row_focus_dark_cyan_r126.png" selectionForegroundColor="#FFFFFF" zPosition="4" />'
)

def _setup_settings_chrome(screen):
    labels = [tr("Search"), tr("Home"), tr("Live"), tr("Movies"), tr("TV Shows"), tr("Settings")]
    screen["settingsBrand"] = Label(tr("TiViMate"))
    screen["settingsTagline"] = Label(tr("IPTV EXPERIENCE"))
    screen["settingsLogo"] = Pixmap()
    screen["settingsSideTitle"] = Label(tr("CONTROL CENTER"))
    screen["settingsSideText"] = Label(tr("Manage playlists,\nconnections and metadata,\nand appearance settings."))
    screen["settingsSideHint"] = Label(tr("Use the colour keys below\nfor quick actions."))
    screen["settingsNavSelector"] = Pixmap()
    screen["settingsGuide"] = Pixmap()
    screen["settingsActionButtons"] = Pixmap()
    try:
        screen["settingsNavSelector"].hide()
        screen["settingsGuide"].hide()
        screen["settingsActionButtons"].hide()
    except Exception:
        pass
    for index, label in enumerate(labels):
        screen["settingsNav%d" % index] = Label(label)
    now = time.localtime()
    screen["settingsClock"] = Label(time.strftime("%H:%M", now))
    screen["settingsDate"] = Label(time.strftime("%a, %d %b", now))
    screen["languageTitle"] = Label(tr("APPLICATION LANGUAGE"))
    screen["languageSelector"] = Pixmap()
    screen["language0"] = Label(tr("English"))
    screen["language1"] = Label(tr("Arabic"))
    screen["language2"] = Label(tr("French"))
    screen["languageRadio0"] = Pixmap()
    screen["languageRadio1"] = Pixmap()
    screen["languageRadio2"] = Pixmap()


def _show_settings_guide(screen):
    try:
        screen["settingsGuide"].show()
    except Exception:
        pass



# Skin 2 is the optional cinematic Home dashboard selected in Home Appearance.
# It intentionally preserves every widget TiviMateE2Home manages at runtime.
HOME_SKIN2 = """<screen name="TiviMateE2Home" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05080D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#05080D" zPosition="0" />
    <eLabel position="0,0" size="1920,92" backgroundColor="#090D12" zPosition="1" />

    <widget name="banner" position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_global_hero_r70.png" alphatest="blend" scale="1" zPosition="1" />
    <ePixmap position="0,92" size="1920,370" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_cinema_hero_overlay.png" alphatest="blend" zPosition="2" />

    <widget name="logo" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="homeBrandLogo" position="28,10" size="285,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="7" />
    <eLabel position="269,48" size="82,26" text="v1.0.08" font="Regular;17" foregroundColor="#E2B84B" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="9" />
    <widget name="headline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="subheadline" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />

        <ePixmap position="335,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="8" />
    <widget name="nav0" position="364,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="490,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="8" />
    <widget name="nav1" position="519,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="645,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="8" />
    <widget name="nav2" position="674,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="800,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="8" />
    <widget name="nav3" position="829,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="955,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="8" />
    <widget name="nav4" position="984,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1110,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="8" />
    <widget name="nav5" position="1139,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1265,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="8" />
    <widget name="nav6" position="1294,15" size="111,64" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <ePixmap position="1420,35" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="8" />
    <widget name="nav7" position="1449,15" size="111,64" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="7" />
    <widget name="navSelector" position="467,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
    <widget name="clock" position="1595,10" size="275,28" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="7" />
    <widget name="date" position="1595,45" size="275,20" font="Regular;14" foregroundColor="#A9B3BD" transparent="1" halign="right" zPosition="7" />

    <widget name="quality" position="48,148" size="680,32" font="Regular;21" foregroundColor="#E2B84B" transparent="1" zPosition="7" />
    <widget name="featureTitle" position="48,180" size="760,72" font="Regular;42" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="7" />
    <widget name="featureMeta" position="48,258" size="700,42" font="Regular;24" foregroundColor="#E5EAF0" transparent="1" valign="center" zPosition="7" />
    <widget name="featureDesc" position="48,305" size="680,82" font="Regular;22" foregroundColor="#D5DCE4" transparent="1" zPosition="7" />
    <eLabel position="48,395" size="245,56" backgroundColor="#B7181F" cornerRadius="12" zPosition="6" />
    <widget name="playNow" position="48,395" size="245,56" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="7" />
    <eLabel position="315,395" size="245,56" text="ⓘ  More Info" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#24292F" halign="center" valign="center" cornerRadius="12" zPosition="7" />

    <widget name="recentTitle" position="55,468" size="560,40" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="left" zPosition="8" />

    <widget name="poster0" position="62,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="55,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate0" position="67,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle0" position="66,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster1" position="382,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="375,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate1" position="387,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle1" position="386,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster2" position="702,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="695,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate2" position="707,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle2" position="706,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster3" position="1022,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1015,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate3" position="1027,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle3" position="1026,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster4" position="1342,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1335,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate4" position="1347,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle4" position="1346,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="poster5" position="1662,517" size="201,296" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" scale="1" zPosition="4" />
    <ePixmap position="1655,510" size="215,360" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_215x360.png" alphatest="blend" zPosition="5" />
    <widget name="posterMetaRate5" position="1667,770" size="58,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0797D5" transparent="0" halign="center" valign="center" cornerRadius="9" zPosition="12" />
    <widget name="posterMetaTitle5" position="1666,819" size="193,43" font="Regular;20" foregroundColor="#F7FBFF" transparent="1" halign="center" valign="center" zPosition="12" />
    <widget name="posterSelector" position="53,508" size="219,364" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_card_focus_reference_215x360.png" alphatest="blend" zPosition="10" />

    <eLabel position="45,888" size="1830,74" backgroundColor="#0F151C" zPosition="5" />
    <eLabel position="55,898" size="425,54" backgroundColor="#137A35" cornerRadius="12" zPosition="6" />
    <eLabel position="505,898" size="425,54" backgroundColor="#A87800" cornerRadius="12" zPosition="6" />
    <eLabel position="955,898" size="425,54" backgroundColor="#13568C" cornerRadius="12" zPosition="6" />
    <eLabel position="1405,898" size="425,54" backgroundColor="#A61D24" cornerRadius="12" zPosition="6" />
    <widget name="actionLabel0" position="55,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="actionLabel1" position="505,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="actionLabel2" position="955,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="actionLabel3" position="1405,898" size="425,54" font="Regular;24" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />

    <eLabel position="45,974" size="575,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <eLabel position="645,974" size="620,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <ePixmap position="853,979" size="204,63" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/developed_by_opesboy_badge.png" alphatest="blend" scale="1" zPosition="9" />
    <eLabel position="1290,974" size="540,72" backgroundColor="#0F151C" cornerRadius="12" zPosition="5" />
    <widget name="skin2HelpTitle" position="68,985" size="225,28" font="Regular;22" foregroundColor="#E2B84B" transparent="1" zPosition="8" />
    <widget name="skin2HelpBody" position="68,1014" size="520,28" font="Regular;17" foregroundColor="#C4CED8" transparent="1" zPosition="8" />
    <widget name="skin2LangTitle" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#E2B84B" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2LangBody" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#C4CED8" transparent="1" halign="center" zPosition="8" />
    <widget name="skin2Key5" position="1310,986" size="500,54" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="8" />
    <widget name="status" position="510,1048" size="900,28" font="Regular;17" foregroundColor="#B8C3CD" transparent="1" halign="center" valign="center" zPosition="8" />
</screen>"""

LIVE_CLASSIC = """<screen name="MediaScreen" position="0,0" size="1920,1080" backgroundColor="#00101214" flags="wfNoBorder">
    <!-- Test10: opaque Live layout with a real receiver PIG preview. -->
    <eLabel position="0,0" size="1920,1080" backgroundColor="#00101214" zPosition="0" />

    <widget name="brand" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="rail" position="-20,-20" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />

    <!-- Header -->
    <widget name="title" position="42,24" size="1180,50" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="10" />
    <widget name="clockTitle" position="1505,26" size="360,42" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="10" />
    <eLabel position="34,84" size="920,3" backgroundColor="#20262D" zPosition="4" />

    <!-- Packages: narrow Aglare-style list -->
    <eLabel position="28,104" size="355,850" backgroundColor="#D8171A1C" cornerRadius="18" zPosition="1" />
    <eLabel position="38,114" size="335,48" backgroundColor="#00131313" cornerRadius="12" zPosition="2" />
    <eLabel position="54,121" size="220,36" text="PACKAGES" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="categoryTitle" position="278,123" size="78,32" font="Regular;17" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <widget name="category" position="42,176" size="327,760" itemHeight="48" foregroundColor="#F1F3F5" foregroundColorSelected="#008080" backgroundColor="#00000000" backgroundColorSelected="#00000000" transparent="1" itemGradientSelected="#003F3F3F,#002F2F2F,#003F3F3F,vertical" itemCornerRadius="10" itemCornerRadiusSelected="10" scrollbarMode="showOnDemand" zPosition="7" />

    <!-- Channels: main list, matching ChannelSelection proportions -->
    <eLabel position="402,104" size="610,850" backgroundColor="#D8171A1C" cornerRadius="18" zPosition="1" />
    <eLabel position="412,114" size="590,48" backgroundColor="#00131313" cornerRadius="12" zPosition="2" />
    <eLabel position="430,121" size="300,36" text="CHANNELS" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="pageInfo" position="826,123" size="154,32" font="Regular;17" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <widget name="list" position="478,176" size="510,760" itemHeight="50" foregroundColor="#FFFFFF" foregroundColorSelected="#008080" backgroundColor="#00000000" backgroundColorSelected="#00000000" transparent="1" itemGradientSelected="#003F3F3F,#002F2F2F,#003F3F3F,vertical" itemCornerRadius="10" itemCornerRadiusSelected="10" scrollbarMode="showOnDemand" zPosition="7" />

    <!-- Right details area inspired by Aglare ChannelSelectionPIG -->
    <eLabel position="1032,104" size="860,850" backgroundColor="#B8171A1C" cornerRadius="18" zPosition="1" />
    <widget name="channelPicon" position="1045,126" size="220,130" alphatest="blend" scale="1" zPosition="8" />
    <widget name="channelTitle" position="1290,126" size="560,48" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="meta" position="1290,180" size="560,34" font="Regular;20" foregroundColor="#D4D9DE" backgroundColor="#00000000" transparent="1" zPosition="8" />

    <!-- Real receiver PIG preview window -->
    <widget source="session.VideoPicture" render="Pig" position="1318,232" size="540,306" backgroundColor="transparent" transparent="0" zPosition="8" />
        <eLabel position="1318,548" size="540,9" backgroundColor="#5A5A5A" cornerRadius="4" zPosition="7" />
    <widget name="liveProgress" position="1318,548" size="540,9" borderWidth="0" foregroundColor="#00B77A" backgroundColor="#5A5A5A" zPosition="9" />

    <!-- Current and next EPG from Enigma2 EPG cache -->
    <eLabel position="1060,578" size="798,342" backgroundColor="#85131313" cornerRadius="16" zPosition="2" />
    <eLabel position="1084,600" size="750,3" backgroundColor="#6A6F75" zPosition="4" />
    <widget name="livePoster" position="1080,265" size="200,300" alphatest="blend" zPosition="9" />
    <widget name="epgNowTime" position="1084,614" size="170,34" font="Regular;20" foregroundColor="#00D7C7" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="epgNowTitle" position="1254,610" size="576,42" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="8" />
    <widget name="epgProgressText" position="1680,652" size="150,30" font="Regular;18" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="8" />
    <eLabel position="1084,684" size="750,2" backgroundColor="#4A4F55" zPosition="4" />
    <widget name="epgNextTime" position="1084,696" size="170,34" font="Regular;20" foregroundColor="#E5B243" backgroundColor="#00000000" transparent="1" valign="center" zPosition="8" />
    <widget name="epgNextTitle" position="1254,692" size="576,42" font="Regular;23" foregroundColor="#F0F2F4" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="8" />
    <widget name="desc" position="1084,746" size="746,150" font="Regular;20" foregroundColor="#D8DDE2" backgroundColor="#00000000" transparent="1" valign="top" zPosition="8" />

    <!-- Visible hint so every user knows how to change the full Live style -->
    <widget name="styleHint" position="1580,62" size="280,34" font="Regular;18" foregroundColor="#BFC7CF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="12" />

    <!-- Keep original plugin footer exactly as-is -->
    <widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live_guide_r120.png" alphatest="blend" zPosition="12" />

    <widget name="nowLabel" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
    <widget name="keys" position="-20,-20" size="1,1" font="Regular;1" transparent="1" />
</screen>"""
VOD = '''<screen name="TiviMateE2Vod" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/vod_cinematic_overlay.png" alphatest="blend" zPosition="1" />
<ePixmap position="46,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="76,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="231,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="261,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="416,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="446,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="601,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="631,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="786,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="816,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="971,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="1001,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1156,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1186,24" size="314,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<ePixmap position="1516,36" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1546,24" size="139,48" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="topSelector" position="45,75" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
<!-- compatibility widgets kept off-screen: categories are opened through FILTER only -->
<widget name="brand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="rail" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="category" position="-10,-10" size="1,1" font="Regular;1" itemHeight="1" scrollbarMode="showNever" />
<widget name="sectionTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
<widget name="contentProviderNetflix" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/provider_netflix.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderPrime" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/provider_prime.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderDisney" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_disney.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderMax" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_max.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderApple" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_apple.png" alphatest="blend" zPosition="10" />
<widget name="contentProviderParamount" position="1550,380" size="250,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/resources/package_logos/package_paramount.png" alphatest="blend" zPosition="10" />
<!-- Dynamic TMDb title logo for the currently selected movie/series. -->
<widget name="titleLogo" position="1390,120" size="430,180" alphatest="blend" zPosition="11" />
<widget name="currentCategory" position="80,450" size="700,42" font="Regular;31" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="searchIcon" position="1650,55" size="85,55" font="Regular;36" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="filterIcon" position="1740,55" size="110,55" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
<widget name="title" position="80,92" size="1500,44" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="channelTitle" position="80,137" size="1500,70" font="Regular;54" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="80,212" size="1470,44" font="Regular;31" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="80,272" size="1180,185" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="nowLabel" position="1650,450" size="190,42" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="poster0" position="70,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster1" position="450,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="450,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster2" position="830,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="830,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster3" position="1210,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1210,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="poster4" position="1590,525" size="270,380" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" />
<ePixmap position="1590,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_270x435.png" alphatest="blend" zPosition="3" />
<widget name="posterRate0" position="82,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate1" position="462,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate2" position="842,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate3" position="1222,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterRate4" position="1602,916" size="82,34" font="Regular;21" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="posterLabel0" position="146,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel1" position="526,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel2" position="906,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel3" position="1286,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="posterLabel4" position="1666,905" size="183,55" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="selector" position="70,525" size="270,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_270x435.png" alphatest="blend" zPosition="8" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="80,1015" size="1760,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/vod_guide_r115.png" alphatest="blend" zPosition="6" />
</screen>'''

SERIES_DETAILS = '''<screen name="TiviMateE2SeriesDetails" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#11151d">
<widget name="backdrop" position="0,0" size="1920,1080" alphatest="blend" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_overlay.png" alphatest="blend" zPosition="1" />
<widget name="title" position="80,52" size="1500,82" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rating" position="84,143" size="150,42" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
<widget name="ratingStars" position="84,181" size="170,27" font="Regular;22" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
<eLabel position="84,207" size="150,22" text="RATING" font="Regular;14" foregroundColor="#D9DEE5" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
<widget name="meta" position="250,145" size="1250,60" font="Regular;35" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="providerLogo" position="1540,145" size="250,62" alphatest="blend" zPosition="12" />
<widget name="cast" position="85,220" size="1320,112" font="Regular;31" foregroundColor="#F7F7F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="85,334" size="1340,205" font="Regular;33" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="seasonInfo" position="1420,560" size="430,52" font="Regular;33" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="4" />
<widget name="episode0" position="80,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode1" position="440,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode2" position="800,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode3" position="1160,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episode4" position="1520,640" size="330,186" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_placeholder.png" alphatest="blend" zPosition="2" />
<widget name="episodeLabel0" position="80,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel1" position="440,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel2" position="800,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel3" position="1160,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeLabel4" position="1520,835" size="330,70" font="Regular;22" foregroundColor="#ffffff" backgroundColor="#5a6472" halign="center" valign="center" zPosition="3" />
<widget name="episodeSelector" position="72,632" size="346,282" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/episode_select.png" alphatest="blend" zPosition="5" />
<widget name="episodeInfo" position="85,925" size="1500,58" font="Regular;23" foregroundColor="#dce3eb" backgroundColor="#11151d" transparent="1" zPosition="3" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="85,1005" size="1740,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_details_guide_r69.png" alphatest="blend" zPosition="5" />
</screen>'''

# Test74: keep Server Manager simple, use a calmer selected-row colour, and
# make both Edit screens match the manager panel proportions.
SERVER_MANAGER_SKIN = SERVER_MANAGER_SKIN.replace(
    'selectionBackgroundColor="#1E9FDF"',
    'selectionBackgroundColor="#17679E"'
)

_editor_old = """<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />
    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />
    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />"""
_editor_new_xtream = """<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />
    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />
    <widget name="config" position="495,286" size="1135,410" itemHeight="58" foregroundColor="#F5F8FC" backgroundColor="#12385F" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#17679E" selectionForegroundColor="#FFFFFF" zPosition="4" />"""
_editor_new_stalker = _editor_new_xtream.replace('itemHeight="58"', 'itemHeight="70"')

XTREAM_EDITOR_SKIN = XTREAM_EDITOR_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(_editor_old, _editor_new_xtream)

STALKER_EDITOR_SKIN = STALKER_EDITOR_SKIN.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(_editor_old, _editor_new_stalker)

# The standard settings action artwork has no Stalker diagnostic button.
# Add a real, visible BLUE TEST control above the footer so users can see
# the feature and press the blue remote key on every supported skin/image.
STALKER_EDITOR_SKIN = STALKER_EDITOR_SKIN.replace(
    '</screen>',
    '    <widget name="testButton" position="1390,884" size="300,48" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#147FC1" transparent="0" halign="center" valign="center" zPosition="10" />\n</screen>'
)

# r29: use the Server Manager content geometry as the master layout for all
# standard Settings pages. This changes layout only; screen logic/actions are untouched.
EDITOR = EDITOR.replace(
    '<widget name="title" position="500,196" size="1260,52" font="Regular;39"',
    '<widget name="title" position="470,184" size="1290,60" font="Regular;43"'
).replace(
    '<eLabel position="500,282" size="700,408" backgroundColor="#0B2440" zPosition="2" />\n'
    '    <eLabel position="508,290" size="684,392" backgroundColor="#12385F" zPosition="3" />\n'
    '    <widget name="config" position="520,312" size="660,350" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#1268B3" selectionForegroundColor="#FFFFFF" zPosition="4" />',
    '<eLabel position="455,252" size="1215,500" backgroundColor="#07121D" zPosition="2" />\n'
    '    <eLabel position="463,260" size="1199,484" backgroundColor="#0D1C2A" zPosition="3" />\n'
    '    <widget name="config" position="495,286" size="1135,410" itemHeight="76" foregroundColor="#F5F8FC" backgroundColor="#0D1C2A" transparent="0" scrollbarMode="showOnDemand" selectionBackgroundColor="#17679E" selectionForegroundColor="#FFFFFF" zPosition="4" />'
)


# r109: unified Add Server editor identity for Xtream / Stalker / M3U.
def _premium_server_editor_skin(xml):
    xml = xml.replace('backgroundColor="#06101D"', 'backgroundColor="#070C13"', 1)
    xml = xml.replace('pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_web_blue_r28.png"',
                      'pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_solid_navy_r64.png"')
    xml = xml.replace('foregroundColor="#6DD8FF"', 'foregroundColor="#F1C84C"')
    xml = xml.replace('selectionBackgroundColor="#17679E"', 'selectionBackgroundColor="#8A6819"')
    xml = xml.replace('selectionBackgroundColor="#1268B3"', 'selectionBackgroundColor="#8A6819"')
    xml = xml.replace('backgroundColor="#12385F"', 'backgroundColor="#111A24"')
    xml = xml.replace('backgroundColor="#0D1C2A"', 'backgroundColor="#0D141E"')
    xml = xml.replace('backgroundColor="#07121D"', 'backgroundColor="#050A10"')
    # Gold accent rail on the main form, visually matching the approved mock-up.
    xml = xml.replace('</screen>',
        '    <eLabel position="455,252" size="5,500" backgroundColor="#E2B84B" zPosition="8" />\\n'
        '    <eLabel position="463,252" size="1199,2" backgroundColor="#E2B84B" zPosition="8" />\\n'
        '</screen>')
    return xml

EDITOR = _premium_server_editor_skin(EDITOR)
XTREAM_EDITOR_SKIN = _premium_server_editor_skin(XTREAM_EDITOR_SKIN)
STALKER_EDITOR_SKIN = _premium_server_editor_skin(STALKER_EDITOR_SKIN)
# The XML uses a 1920x1080 design canvas.  Convert it once at import time
# when the active Enigma2 desktop is WQHD, before any Screen is constructed.
HOME_SKIN1 = scale_skin(HOME_SKIN1)
HOME_SKIN2 = scale_skin(HOME_SKIN2)
HOME_SKIN3_ACCESSIBILITY = scale_skin(HOME_SKIN3_ACCESSIBILITY)
SEARCH_SCREEN = scale_skin(SEARCH_SCREEN)
EDITOR = scale_skin(EDITOR)
XTREAM_EDITOR_SKIN = scale_skin(XTREAM_EDITOR_SKIN)
STALKER_EDITOR_SKIN = scale_skin(STALKER_EDITOR_SKIN)
SERVER_MANAGER_SKIN = scale_skin(SERVER_MANAGER_SKIN)

# Wide dark settings layout used by TMDb.
# r235: visual-only redesign built from the stable r233 screen contract.
# Keep the exact widget names used by TMDbSettings and shared settings chrome.
TMDB_SETTINGS_SKIN = r"""<screen name="TMDbSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050708">
    <!-- r264: user-approved cinematic TMDb artwork as a skin background only. -->
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tmdb_settings_cinematic_r270.png" scale="1" zPosition="0" />

    <!-- Real Enigma2 settings stay live and editable over the empty center rows. -->
    <widget name="config" position="330,304" size="1260,548" itemHeight="84" font="Regular;27" foregroundColor="#F4F7FA" backgroundColor="#00000000" transparent="1" scrollbarMode="showOnDemand" selectionBackgroundColor="#163745" selectionForegroundColor="#FFFFFF" zPosition="8" />

    <!-- Functional key hints only; deliberately subtle so the cinematic design stays clean. -->
    <widget name="keys" position="410,900" size="1100,42" font="Regular;19" foregroundColor="#AAB5BE" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />

    <!-- Existing screen contract: keep title/hint and shared Settings chrome widgets alive but visually hidden. -->
    <widget name="title" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="hint" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsLogo" position="-10,-10" size="1,1" transparent="1" />
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNavSelector" position="-10,-10" size="1,1" transparent="1" />
    <widget name="settingsNav0" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav1" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav2" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav3" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav4" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsNav5" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsClock" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsDate" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsSideTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsSideText" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsSideHint" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="settingsGuide" position="-10,-10" size="1,1" transparent="1" />
    <widget name="settingsActionButtons" position="-10,-10" size="1,1" transparent="1" />
    <widget name="languageTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="languageSelector" position="-10,-10" size="1,1" transparent="1" />
    <widget name="language0" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="language1" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="language2" position="-10,-10" size="1,1" font="Regular;1" transparent="1" />
    <widget name="languageRadio0" position="-10,-10" size="1,1" transparent="1" />
    <widget name="languageRadio1" position="-10,-10" size="1,1" transparent="1" />
    <widget name="languageRadio2" position="-10,-10" size="1,1" transparent="1" />
</screen>"""
TMDB_SETTINGS_SKIN = scale_skin(TMDB_SETTINGS_SKIN)

LIVE_CLASSIC = scale_skin(LIVE_CLASSIC)

LIVE_STYLE_CHOICES = [
    ("تركوازي", "turquoise"),
    ("أزرق", "blue"),
    ("أخضر", "green"),
    ("ذهبي", "gold"),
    ("بنفسجي", "purple"),
    ("فضي", "silver"),
]

LIVE_STYLE_PALETTES = {
    "turquoise": {
        "accent": "#008F95", "bg": "#00101214", "panel": "#D8171A1C", "panel2": "#B8171A1C",
        "header": "#00131313", "line": "#263B40", "progress": "#00BFC7", "soft": "#B8DDE0",
    },
    "blue": {
        "accent": "#168CFF", "bg": "#000B1422", "panel": "#D8101A2B", "panel2": "#B80D1727",
        "header": "#00101D31", "line": "#244C78", "progress": "#168CFF", "soft": "#BBD8FF",
    },
    "green": {
        "accent": "#19C878", "bg": "#000C1712", "panel": "#D812211A", "panel2": "#B80E1C16",
        "header": "#0013231B", "line": "#285D45", "progress": "#19C878", "soft": "#BCEBD4",
    },
    "gold": {
        "accent": "#E5B243", "bg": "#0017130B", "panel": "#D8221B10", "panel2": "#B81D170D",
        "header": "#00261E10", "line": "#6B5525", "progress": "#E5B243", "soft": "#F2DEB0",
    },
    "purple": {
        "accent": "#935CFF", "bg": "#00120D1B", "panel": "#D81C1428", "panel2": "#B8171022",
        "header": "#0020152F", "line": "#5B3A86", "progress": "#935CFF", "soft": "#D8C4FF",
    },
    "silver": {
        "accent": "#E5E7EB", "bg": "#00121315", "panel": "#D81C1E21", "panel2": "#B8181A1D",
        "header": "#00232629", "line": "#5F666D", "progress": "#D8DDE2", "soft": "#E8EAED",
    },
}

def _live_skin_with_style(theme):
    theme = theme if theme in LIVE_STYLE_PALETTES else "turquoise"
    p = LIVE_STYLE_PALETTES[theme]
    skin = LIVE_CLASSIC
    replacements = {
        '#00101214': p['bg'],
        '#D8171A1C': p['panel'],
        '#B8171A1C': p['panel2'],
        '#00131313': p['header'],
        '#20262D': p['line'],
        '#6A6F75': p['line'],
        '#5A5A5A': p['line'],
        '#00B77A': p['progress'],
        '#008080': p['accent'],
        '#BFC7CF': p['soft'],
        '#D4D9DE': p['soft'],
    }
    for old, new in replacements.items():
        skin = skin.replace(old, new)
    return skin

VOD = scale_skin(VOD)
SERIES_DETAILS = scale_skin(SERIES_DETAILS)



UNIFIED_SERVER_EDITOR_SKIN = r"""<screen name="UnifiedServerEditor" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#03070B">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#03070B" zPosition="0"/>
    <eLabel position="0,0" size="1920,112" backgroundColor="#07101A" zPosition="1"/>
    <eLabel position="0,110" size="1920,2" backgroundColor="#1D6E9B" zPosition="2"/>

    <widget name="brandLabel" position="58,22" size="350,55" font="Regular;36" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="sectionLive" position="520,32" size="155,42" font="Regular;21" foregroundColor="#9FAEBD" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="sectionMovies" position="680,32" size="155,42" font="Regular;21" foregroundColor="#9FAEBD" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="sectionSeries" position="840,32" size="155,42" font="Regular;21" foregroundColor="#9FAEBD" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="sectionSettings" position="1000,32" size="185,42" font="Regular;21" foregroundColor="#55C7FF" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="settingsClock" position="1590,22" size="230,38" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="5"/>
    <widget name="settingsDate" position="1510,65" size="310,28" font="Regular;17" foregroundColor="#8797A8" transparent="1" halign="right" zPosition="5"/>

    <!-- hidden compatibility widgets used by shared Settings chrome -->
    <widget name="settingsBrand" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsTagline" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsLogo" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsSideTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsSideText" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsSideHint" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNavSelector" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsGuide" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsActionButtons" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="settingsNav0" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav1" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav2" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav3" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav4" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="settingsNav5" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="languageTitle" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="languageSelector" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="language0" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="language1" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="language2" position="-10,-10" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="languageRadio0" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="languageRadio1" position="-10,-10" size="1,1" transparent="1"/>
    <widget name="languageRadio2" position="-10,-10" size="1,1" transparent="1"/>

    <widget name="title" position="475,132" size="1370,56" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="5"/>
    <widget name="hint" position="475,190" size="1370,34" font="Regular;18" foregroundColor="#93A7B9" transparent="1" halign="left" valign="center" zPosition="5"/>

    <!-- protocol cards: same motion/logo idea as Server Manager -->
    <ePixmap position="65,250" size="360,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_editor_xtream_card_r203.png" alphatest="blend" zPosition="3"/>
    <ePixmap position="65,450" size="360,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_editor_m3u_card_r203.png" alphatest="blend" zPosition="3"/>
    <ePixmap position="65,650" size="360,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_editor_stalker_card_r203.png" alphatest="blend" zPosition="3"/>
    <eLabel position="185,284" size="205,38" text="XTREAM" font="Regular;30" foregroundColor="#6ED2FF" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,326" size="205,30" text="CODES API" font="Regular;19" foregroundColor="#2F9FFF" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,484" size="205,38" text="M3U" font="Regular;30" foregroundColor="#7AF09D" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,526" size="205,30" text="PLAYLIST" font="Regular;19" foregroundColor="#36D66A" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,684" size="205,38" text="STALKER" font="Regular;30" foregroundColor="#FFBE59" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="185,726" size="205,30" text="PORTAL" font="Regular;19" foregroundColor="#FF941F" transparent="1" halign="center" valign="center" zPosition="5"/>
    <ePixmap position="__FOCUS_X__,__FOCUS_Y__" size="360,180" pixmap="__FOCUS_PIX__" alphatest="blend" zPosition="7"/>

    <!-- main connection panel -->
    <eLabel position="455,245" size="1390,620" backgroundColor="#07131D" zPosition="2"/>
    <eLabel position="463,253" size="1374,604" backgroundColor="#0A1925" zPosition="3"/>
    <eLabel position="495,278" size="1308,52" backgroundColor="#0D2232" zPosition="4"/>
    <eLabel position="520,286" size="580,36" text="CONNECTION DETAILS" font="Regular;24" foregroundColor="__ACCENT__" transparent="1" valign="center" zPosition="5"/>
    <widget name="typeBadge" position="1190,282" size="570,36" font="Regular;22" foregroundColor="__ACCENT__" transparent="1" halign="right" valign="center" zPosition="5"/>
    <widget name="config" position="500,350" size="1290,420" itemHeight="60" font="Regular;23" foregroundColor="#EEF4F8" backgroundColor="#0A1925" transparent="0" scrollbarMode="showOnDemand" zPosition="8"/>

    <eLabel position="500,790" size="1290,2" backgroundColor="#263B49" zPosition="5"/>
    <widget name="typeDesc" position="515,805" size="530,50" font="Regular;19" foregroundColor="#D4DEE7" transparent="1" valign="center" zPosition="6"/>
    <widget name="typeHint" position="1080,805" size="700,50" font="Regular;18" foregroundColor="__ACCENT__" transparent="1" halign="right" valign="center" zPosition="6"/>

    <widget name="statusLine" position="440,885" size="1420,38" font="Regular;19" foregroundColor="#AEBBC7" transparent="1" halign="center" valign="center" zPosition="5"/>
    <eLabel position="440,940" size="1420,72" backgroundColor="#07131D" zPosition="2"/>
    <widget name="keys" position="470,952" size="1360,46" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#0B1B28" transparent="0" halign="center" valign="center" zPosition="5"/>
</screen>"""

XTREAM_EDITOR_R203_SKIN = (UNIFIED_SERVER_EDITOR_SKIN
    .replace('__FOCUS_X__','65').replace('__FOCUS_Y__','250')
    .replace('__FOCUS_PIX__','/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_editor_xtream_focus_r203.png')
    .replace('__ACCENT__','#55C7FF').replace('__SELECT__','#123D5A'))
M3U_EDITOR_R203_SKIN = (UNIFIED_SERVER_EDITOR_SKIN
    .replace('__FOCUS_X__','65').replace('__FOCUS_Y__','450')
    .replace('__FOCUS_PIX__','/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_editor_m3u_focus_r203.png')
    .replace('__ACCENT__','#54E381').replace('__SELECT__','#123D2A'))
STALKER_EDITOR_R203_SKIN = (UNIFIED_SERVER_EDITOR_SKIN
    .replace('__FOCUS_X__','65').replace('__FOCUS_Y__','650')
    .replace('__FOCUS_PIX__','/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_editor_stalker_focus_r203.png')
    .replace('__ACCENT__','#FFAA35').replace('__SELECT__','#533414'))
class PlaylistEditor(Screen, ConfigListScreen):
    skin = XTREAM_EDITOR_R203_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        self["brandLabel"] = Label("TiviMate E2")
        self["sectionLive"] = Label("LIVE TV")
        self["sectionMovies"] = Label("MOVIES")
        self["sectionSeries"] = Label("SERIES")
        self["sectionSettings"] = Label("SETTINGS")
        self["typeBadge"] = Label('XTREAM CODES')
        self["typeDesc"] = Label('Username + Password\nAPI connection')
        self["typeHint"] = Label('Live TV • Movies • Series')
        self["statusLine"] = Label("Use OK to edit • GREEN to save • RED to cancel • EXIT to go back")
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr(("EDIT SERVER" if self.original else "ADD NEW SERVER") + "  •  XTREAM CODES"))
        self["hint"] = Label("Playlist file: %s" % PLAYLISTS_FILE)
        self["keys"] = Label("OK  KEYBOARD      GREEN  SAVE      BLUE  TEST      RED  CANCEL      EXIT  BACK")
        self.provider = ConfigText(default=self.original.get("name", "IPTV"), fixed_size=False)
        self.protocol = ConfigSelection(default=self._protocol(), choices=[("http://", "http://"), ("https://", "https://")])
        host, port = self._host_port()
        self.server = ConfigText(default=host, fixed_size=False)
        self.port = ConfigText(default=port, fixed_size=False)
        self.username = ConfigText(default=self.original.get("username", ""), fixed_size=False)
        self.password = ConfigPassword(default=self.original.get("password", ""), fixed_size=False)
        self.output = ConfigSelection(default=self.original.get("output", "ts"), choices=[("ts", "TS"), ("m3u8", "M3U8")])
        saved_xtream_types = _load_xtream_service_types(self.original) if self.original else {"live": 4097}
        xtream_live_type = _clean_stream_type(self.original.get("service_type", saved_xtream_types.get("live", 4097)))
        self.liveStreamType = ConfigSelection(default=str(xtream_live_type), choices=STREAM_TYPE_CONFIG_CHOICES)
        self.epgOffset = ConfigSelection(default=str(self.original.get("epg_offset", "-1")), choices=[
            ("auto", "Auto (XMLTV timezone)"), ("0", "No correction"),
            ("-2", "-2 hours"), ("-1", "-1 hour"),
            ("1", "+1 hour"), ("2", "+2 hours")
        ])
        poster_raw = self.original.get("show_live_poster", False)
        poster_enabled = str(poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.livePoster = ConfigYesNo(default=bool(poster_enabled))
        infobar_poster_raw = self.original.get("show_live_infobar_poster", False)
        infobar_poster_enabled = str(infobar_poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.liveInfobarPoster = ConfigYesNo(default=bool(infobar_poster_enabled))
        adult_raw = self.original.get("adult_enabled", False)
        adult_enabled = str(adult_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.adultContent = ConfigYesNo(default=not bool(adult_enabled))
        catchup_raw = self.original.get("catchup_enabled", False)
        catchup_enabled = str(catchup_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.catchupEnabled = ConfigYesNo(default=bool(catchup_enabled))
        entries = [
            getConfigListEntry(tr("Playlist Name"), self.provider),
            getConfigListEntry(tr("Protocol"), self.protocol),
            getConfigListEntry(tr("Server URL"), self.server),
            getConfigListEntry(tr("Port"), self.port),
            getConfigListEntry(tr("Username"), self.username),
            getConfigListEntry(tr("Password"), self.password),
            getConfigListEntry(tr("Stream Format"), self.output),
            getConfigListEntry(tr("Live Stream Type"), self.liveStreamType),
            getConfigListEntry(tr("EPG Time Offset"), self.epgOffset),
            getConfigListEntry(tr(u"★ TMDb Poster in Live"), self.livePoster),
            getConfigListEntry(tr(u"★ Small Poster in Live Infobar"), self.liveInfobarPoster),
            getConfigListEntry(tr("Hide Adult Content"), self.adultContent),
            getConfigListEntry(tr("Enable Catch-up Package"), self.catchupEnabled),
        ]
        ConfigListScreen.__init__(self, entries, session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testPortal,
            "red": self.close, "cancel": self.close,
            "left": self.keyLeft, "right": self.keyRight
        }, -1)

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass

    def _protocol(self):
        return "https://" if self.original.get("url", "").startswith("https://") else "http://"

    def _host_port(self):
        url = self.original.get("url", "").replace("http://", "").replace("https://", "").rstrip("/")
        return tuple(url.rsplit(":", 1)) if ":" in url else (url, "")


    def addTmdbKey(self):
        # Import from any Enigma2 path. The shared built-in credential is never
        # shown or written to the browser. Only a user-selected text file is read.
        self.session.openWithCallback(self.tmdbKeyImported, TMDbKeyImportBrowser, start_path="/")

    def tmdbKeyImported(self, value=None):
        if not value:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key imported. Press GREEN to save.")
        except Exception:
            pass

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.livePoster or cfg is self.liveInfobarPoster or cfg is self.adultContent or cfg is self.catchupEnabled:
            try:
                cfg.value = not bool(cfg.value)
                cfg.changed()
            except Exception:
                return
            try:
                self["config"].invalidateCurrent()
            except Exception:
                pass
            return
        if not isinstance(cfg, (ConfigText, ConfigPassword)):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def testPortal(self):
        host = (self.server.value or "").strip().replace("http://", "").replace("https://", "").rstrip("/")
        port = (self.port.value or "").strip()
        if not host or not self.username.value or not self.password.value:
            self.session.open(MessageBox, "Enter the server URL, username, and password first.", MessageBox.TYPE_ERROR); return
        url = self.protocol.value + host + ((":" + port) if port else "")
        source = {
            "type": "xtream", "name": self.provider.value or "IPTV", "url": url,
            "username": self.username.value, "password": self.password.value,
            "output": self.output.value
        }
        self["hint"].setText("Testing Xtream connection...")
        def worker():
            try:
                report = XtreamClient(source).test()
                ok = bool(report)
                message = "Xtream connection successful." if ok else "Xtream connection failed."
            except Exception as exc:
                ok = False
                message = "Xtream connection failed: %s" % exc
            def done():
                try:
                    self["hint"].setText(message)
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=7)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        threading.Thread(target=worker).start()

    def save(self):
        host = (self.server.value or "").strip().replace("http://", "").replace("https://", "").rstrip("/")
        port = (self.port.value or "").strip()
        if not host or not self.username.value or not self.password.value:
            self.session.open(MessageBox, "Enter the server URL, username, and password.", MessageBox.TYPE_ERROR); return
        url = self.protocol.value + host + ((":" + port) if port else "")
        src = dict(self.original or {})
        src.update({
            "type": "xtream", "name": self.provider.value or "IPTV", "url": url,
            "username": self.username.value, "password": self.password.value,
            "output": self.output.value, "epg_offset": self.epgOffset.value,
            "service_type": _clean_stream_type(self.liveStreamType.value),
            "show_live_poster": bool(self.livePoster.value),
            "show_live_infobar_poster": bool(self.liveInfobarPoster.value),
            "adult_enabled": not bool(self.adultContent.value),
            "catchup_enabled": bool(self.catchupEnabled.value)
        })
        xtream_types = _load_xtream_service_types(src)
        xtream_types["live"] = _clean_stream_type(self.liveStreamType.value)
        _save_xtream_service_types(src, xtream_types)
        self.close(src)



SOURCE_TYPE_PICKER_R128_SKIN = r"""<screen name="SourceTypePicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/add_server_picker_r128.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="cardFocus" position="140,300" size="480,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/add_server_picker_focus_r177.png" alphatest="blend" zPosition="9"/>
    <widget name="brand" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="side" position="0,0" size="1,1" transparent="1" zPosition="1"/>
    <widget name="title" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="subtitle" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="menu" position="0,0" size="1,1" transparent="1" zPosition="1"/>
    <widget name="cardTitle0" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardTitle1" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardTitle2" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardText0" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardText1" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="cardText2" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="info" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="keys" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="guideBar" position="0,0" size="1,1" transparent="1" zPosition="1"/>
</screen>"""

class SourceTypePicker(Screen):
    """Premium three-card source chooser."""
    skin = SOURCE_TYPE_PICKER_R128_SKIN
    CARD_X = [140, 715, 1290]
    TYPES = ["xtream", "stalker", "m3u"]

    def __init__(self, session):
        Screen.__init__(self, session)
        self.choice = 0
        self["brand"] = Label(tr("TiViMate"))
        self["side"] = MenuList([])
        self["title"] = Label(tr("ADD NEW SERVER"))
        self["subtitle"] = Label(tr("Choose the type of IPTV connection you want to add"))
        self["menu"] = MenuList([])
        self["cardFocus"] = Pixmap()
        self["cardTitle0"] = Label("Xtream Codes")
        self["cardTitle1"] = Label("Stalker Portal")
        self["cardTitle2"] = Label("Import M3U")
        self["cardText0"] = Label(tr("Live TV  •  Movies  •  TV Shows\nUsername and password login"))
        self["cardText1"] = Label(tr("Portal based connection\nPortal URL and MAC address"))
        self["cardText2"] = Label(tr("Import M3U / M3U8 playlist\nHDD • USB • receiver storage"))
        self["info"] = Label(tr("Select a server type. You can edit it later from Server Manager."))
        self["keys"] = Label(tr("◀  ▶  CHOOSE SERVER TYPE        OK  SELECT        EXIT  BACK"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close,
            "left": self.left, "right": self.right,
            "up": self.left, "down": self.right
        }, -1)
        self.onLayoutFinish.append(self._render)

    def _render(self):
        try:
            self["cardFocus"].instance.move(ePoint(sx(self.CARD_X[self.choice]), sy(300)))
        except Exception:
            pass

    def left(self):
        self.choice = (self.choice - 1) % 3
        self._render()

    def right(self):
        self.choice = (self.choice + 1) % 3
        self._render()

    def choose(self):
        self.close(self.TYPES[self.choice])





class M3UFileImportBrowser(Screen):
    """Lightweight file browser for local M3U/M3U8 import.

    Avoids ChoiceBox so receivers with tight graphics memory do not allocate an
    extra large selection surface before the playlist is even chosen.
    """
    skin = r"""<screen name="M3UFileImportBrowser" position="center,center" size="1500,850" flags="wfNoBorder" backgroundColor="#070A0E">
        <eLabel position="0,0" size="1500,92" backgroundColor="#0B1118" zPosition="1"/>
        <widget name="title" position="48,18" size="900,54" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="2"/>
        <widget name="path" position="48,102" size="1404,46" font="Regular;25" foregroundColor="#9CB6C9" transparent="1" zPosition="2"/>
        <widget name="list" position="48,162" size="1404,570" font="Regular;28" itemHeight="48" scrollbarMode="showOnDemand" backgroundColor="#090E14" foregroundColor="#FFFFFF" zPosition="2"/>
        <eLabel position="48,752" size="1404,2" backgroundColor="#244256" zPosition="2"/>
        <widget name="hint" position="48,770" size="1404,52" font="Regular;24" foregroundColor="#DDE8F0" transparent="1" halign="center" valign="center" zPosition="2"/>
    </screen>"""

    def __init__(self, session, start_path="/"):
        Screen.__init__(self, session)
        self.current_path = self._safe_dir(start_path)
        self.entries = []
        self["title"] = Label("IMPORT M3U / M3U8")
        self["path"] = Label("")
        self["list"] = MenuList([])
        self["hint"] = Label("OK  OPEN / IMPORT     BACK  PARENT     RED  CANCEL")
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.back, "red": self.close,
            "up": self.up, "down": self.down, "left": self.pageUp, "right": self.pageDown,
        }, -1)
        self._reload()

    def _safe_dir(self, path):
        try:
            path = os.path.abspath(path or "/")
            if os.path.isdir(path): return path
        except Exception: pass
        return "/"

    def _reload(self):
        path = self._safe_dir(self.current_path); self.current_path = path
        rows, entries = [], []
        if path != "/":
            rows.append("[..]  Parent folder"); entries.append(("parent", os.path.dirname(path.rstrip("/")) or "/"))
        try: names = os.listdir(path)
        except Exception: names = []
        dirs, files = [], []
        for name in names:
            if not name or name in (".", ".."): continue
            full = os.path.join(path, name)
            try:
                if os.path.isdir(full): dirs.append((name.lower(), name, full))
                elif os.path.isfile(full) and name.lower().endswith((".m3u", ".m3u8")): files.append((name.lower(), name, full))
            except Exception: continue
        dirs.sort(key=lambda x:x[0]); files.sort(key=lambda x:x[0])
        for _,name,full in dirs:
            rows.append("[DIR]  %s" % name); entries.append(("dir", full))
        for _,name,full in files:
            rows.append("       %s" % name); entries.append(("file", full))
        if not rows:
            rows=["(no M3U files in this folder)"]; entries=[("empty", path)]
        self.entries=entries; self["list"].setList(rows); self["path"].setText(path)

    def _index(self):
        try: return int(self["list"].getSelectedIndex())
        except Exception:
            try: return int(self["list"].l.getCurrentSelectionIndex())
            except Exception: return 0
    def _selected(self):
        i=self._index(); return self.entries[i] if 0 <= i < len(self.entries) else None
    def up(self):
        try:self["list"].up()
        except Exception:pass
    def down(self):
        try:self["list"].down()
        except Exception:pass
    def pageUp(self):
        try:self["list"].pageUp()
        except Exception:pass
    def pageDown(self):
        try:self["list"].pageDown()
        except Exception:pass
    def back(self):
        if self.current_path == "/": self.close(None); return
        self.current_path = os.path.dirname(self.current_path.rstrip("/")) or "/"; self._reload()
    def ok(self):
        selected=self._selected()
        if not selected:return
        kind,path=selected
        if kind in ("parent","dir"):
            self.current_path=self._safe_dir(path); self._reload(); return
        if kind == "file": self.close(path)

class M3UPlaylistEditor(Screen, ConfigListScreen):
    """Add a standard M3U playlist from a URL or a local .m3u/.m3u8 file."""
    skin = M3U_EDITOR_R203_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        self["brandLabel"] = Label("TiviMate E2")
        self["sectionLive"] = Label("LIVE TV")
        self["sectionMovies"] = Label("MOVIES")
        self["sectionSeries"] = Label("SERIES")
        self["sectionSettings"] = Label("SETTINGS")
        self["typeBadge"] = Label('IMPORT M3U')
        self["typeDesc"] = Label('Local playlist import\nM3U / M3U8')
        self["typeHint"] = Label('Full local playlist source')
        self["statusLine"] = Label("Use OK to edit • GREEN to save • RED to cancel • EXIT to go back")
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr(("EDIT M3U" if self.original else "IMPORT M3U PLAYLIST") + "  •  M3U / M3U8"))
        self["hint"] = Label(tr("Import a ready-made M3U/M3U8 file. Existing URL playlists remain supported when editing."))
        self["keys"] = Label("OK  EDIT      GREEN  IMPORT/SAVE      BLUE  IMPORT FILE      RED  CANCEL      EXIT  BACK")

        original_mode = str(self.original.get("m3u_mode") or "").strip().lower()
        if original_mode not in ("url", "file"):
            original_mode = "file" if (self.original.get("path") or not self.original) else "url"

        self.provider = ConfigText(default=self.original.get("name", "M3U Playlist"), fixed_size=False)
        self.mode = ConfigSelection(default=original_mode, choices=[
            ("url", "M3U URL"),
            ("file", "Local M3U File"),
        ])
        self.location = ConfigText(
            default=(self.original.get("path") if original_mode == "file" else self.original.get("url", "")) or "",
            fixed_size=False
        )
        self.liveStreamType = ConfigSelection(
            default=str(_clean_stream_type(self.original.get("service_type", 4097))),
            choices=STREAM_TYPE_CONFIG_CHOICES
        )

        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Playlist Name"), self.provider),
            getConfigListEntry(tr("Source Type"), self.mode),
            getConfigListEntry(tr("URL / File Path"), self.location),
            getConfigListEntry(tr("Live Stream Type"), self.liveStreamType),
        ], session=session)

        self["actions"] = ActionMap(["OkCancelActions","ColorActions","DirectionActions"], {
            "ok": self.openEditor,
            "green": self.save,
            "blue": self.findLocalFile,
            "red": self.close,
            "cancel": self.close,
            "left": self.keyLeft,
            "right": self.keyRight,
        }, -1)

    def keyLeft(self):
        try: ConfigListScreen.keyLeft(self)
        except Exception: pass

    def keyRight(self):
        try: ConfigListScreen.keyRight(self)
        except Exception: pass

    def openEditor(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.mode or cfg is self.liveStreamType:
            try: ConfigListScreen.keyRight(self)
            except Exception: pass
            return
        if not isinstance(cfg, ConfigText):
            return
        self.session.openWithCallback(
            lambda value, c=cfg: self._keyboardDone(c, value),
            VirtualKeyBoard, title=current[0], text=cfg.value or ""
        )

    def _keyboardDone(self, cfg, value=None):
        if value is None:
            return
        cfg.value = str(value).strip()
        try:self["config"].invalidateCurrent()
        except Exception:pass

    def _scanM3UFiles(self):
        roots = ["/media/hdd", "/media/usb", "/media/mmc", "/media", "/home/root", "/tmp", "/etc/enigma2"]
        found = []
        seen = set()
        for root in roots:
            if not os.path.isdir(root):
                continue
            for dirpath, dirnames, filenames in os.walk(root):
                # Keep scans bounded; receiver media trees can be huge.
                depth = dirpath[len(root):].count(os.sep)
                if depth >= 3:
                    dirnames[:] = []
                for name in filenames:
                    if not name.lower().endswith((".m3u", ".m3u8")):
                        continue
                    path = os.path.join(dirpath, name)
                    if path not in seen:
                        seen.add(path)
                        found.append(path)
                    if len(found) >= 80:
                        return found
        return found

    def findLocalFile(self):
        # Open the lightweight browser directly.  Do not build/open a ChoiceBox:
        # on some receivers that extra surface can exhaust graphics memory.
        self.session.openWithCallback(self._fileSelected, M3UFileImportBrowser, "/")

    def _fileSelected(self, choice=None):
        if not choice:
            return
        self.mode.value = "file"
        self.location.value = str(choice)
        try:self["config"].invalidateCurrent()
        except Exception:pass
        self["hint"].setText("Selected: %s" % self.location.value)

    def _importPlaylistCopy(self, path):
        """Copy an imported playlist into plugin data so removable media is no longer required."""
        path = os.path.abspath(os.path.expanduser(str(path or "")))
        if not os.path.isfile(path):
            raise IOError("M3U file not found: %s" % path)
        with open(path, "rb") as handle:
            data = handle.read()
        if b"#EXTM3U" not in data[:4096]:
            raise ValueError("The selected file is not a valid M3U playlist.")
        import_dir = data_path("imported_m3u")
        ensure_dir(import_dir)
        digest = hashlib.sha1(data).hexdigest()[:12]
        ext = ".m3u8" if path.lower().endswith(".m3u8") else ".m3u"
        target = os.path.join(import_dir, "playlist_%s%s" % (digest, ext))
        if not os.path.exists(target):
            tmp = target + ".tmp"
            with open(tmp, "wb") as handle:
                handle.write(data)
            atomic_replace(tmp, target)
        return target

    def save(self):
        name = str(self.provider.value or "M3U Playlist").strip()
        mode = str(self.mode.value or "url").strip()
        value = str(self.location.value or "").strip()
        if not value:
            self.session.open(MessageBox, "Enter an M3U URL or select a local file.", MessageBox.TYPE_ERROR)
            return

        src = dict(self.original or {})
        src.update({
            "type": "m3u",
            "name": name,
            "m3u_mode": mode,
            "service_type": _clean_stream_type(self.liveStreamType.value),
        })

        if mode == "file":
            try:
                path = self._importPlaylistCopy(value)
            except Exception as exc:
                self.session.open(MessageBox, "Unable to import M3U file:\n%s" % exc, MessageBox.TYPE_ERROR)
                return
            src["path"] = path
            src["url"] = ""
            src["imported"] = True
            try:
                parsed = M3UClient(src).entries() or []
                epg_url = next((str(row.get("epg_url") or "").strip() for row in parsed if str(row.get("epg_url") or "").strip()), "")
                if epg_url:
                    src["epg_url"] = epg_url
                src["catchup_enabled"] = any(bool(str(row.get("catchup") or row.get("catchup_source") or row.get("timeshift") or "").strip()) for row in parsed)
                src["entry_count"] = len(parsed)
            except Exception:
                pass
        else:
            if not value.lower().startswith(("http://", "https://")):
                self.session.open(MessageBox, "M3U URL must start with http:// or https://", MessageBox.TYPE_ERROR)
                return
            src["url"] = value
            src.pop("path", None)

        self.close(src)


class StalkerPortalEditor(Screen, ConfigListScreen):
    """Private local editor for a user-supplied Stalker/Ministra VOD portal."""
    skin = STALKER_EDITOR_R203_SKIN

    def __init__(self, session, source=None, callback=None):
        Screen.__init__(self, session)
        self["brandLabel"] = Label("TiviMate E2")
        self["sectionLive"] = Label("LIVE TV")
        self["sectionMovies"] = Label("MOVIES")
        self["sectionSeries"] = Label("SERIES")
        self["sectionSettings"] = Label("SETTINGS")
        self["typeBadge"] = Label('STALKER PORTAL')
        self["typeDesc"] = Label('Portal URL + MAC\nMinistra / MAG')
        self["typeHint"] = Label('Portal based IPTV source')
        self["statusLine"] = Label("Use OK to edit • GREEN to save • RED to cancel • EXIT to go back")
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        self.callback = callback
        self.original = source or {}
        self["title"] = Label(tr(("EDIT SERVER" if self.original else "ADD NEW SERVER") + "  •  STALKER PORTAL"))
        self["hint"] = Label(tr("Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate."))
        self["keys"] = Label("OK  KEYBOARD      GREEN  SAVE      BLUE  TEST      RED  CANCEL      EXIT  BACK")
        self["testButton"] = Label(tr("BLUE  TEST PORTAL"))
        self.provider = ConfigText(default=self.original.get("name", "Stalker Portal"), fixed_size=False)
        self.portal = ConfigText(default=self.original.get("url", ""), fixed_size=False)
        self._mac_formatting = False
        self.mac = ConfigText(default=self._initialMacList(self.original), fixed_size=False)
        self.epgOffset = ConfigSelection(default=str(self.original.get("epg_offset", "auto")), choices=[
            ("auto", "Auto (portal/XMLTV timezone)"), ("0", "No correction"),
            ("-2", "-2 hours"), ("-1", "-1 hour"),
            ("1", "+1 hour"), ("2", "+2 hours")
        ])
        poster_raw = self.original.get("show_live_poster", False)
        poster_enabled = str(poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.livePoster = ConfigYesNo(default=bool(poster_enabled))
        infobar_poster_raw = self.original.get("show_live_infobar_poster", False)
        infobar_poster_enabled = str(infobar_poster_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.liveInfobarPoster = ConfigYesNo(default=bool(infobar_poster_enabled))
        adult_raw = self.original.get("adult_enabled", False)
        adult_enabled = str(adult_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.adultContent = ConfigYesNo(default=not bool(adult_enabled))
        catchup_raw = self.original.get("catchup_enabled", False)
        catchup_enabled = str(catchup_raw).strip().lower() in ("1", "true", "yes", "on", "enabled")
        self.catchupEnabled = ConfigYesNo(default=bool(catchup_enabled))
        saved_stalker_types = _load_stalker_service_types(self.original) if self.original else {"live": 4097}
        stalker_live_type = _clean_stream_type(self.original.get("service_type", saved_stalker_types.get("live", 4097)))
        self.liveStreamType = ConfigSelection(default=str(stalker_live_type), choices=STREAM_TYPE_CONFIG_CHOICES)
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Portal Name"), self.provider),
            getConfigListEntry(tr("Portal URL"), self.portal),
            getConfigListEntry(tr("MAG MACs / Alias"), self.mac),
            getConfigListEntry(tr("Live Stream Type"), self.liveStreamType),
            getConfigListEntry(tr("EPG Time Offset"), self.epgOffset),
            getConfigListEntry(tr(u"★ TMDb Poster in Live"), self.livePoster),
            getConfigListEntry(tr(u"★ Small Poster in Live Infobar"), self.liveInfobarPoster),
            getConfigListEntry(tr("Hide Adult Content"), self.adultContent),
            getConfigListEntry(tr("Enable Catch-up Package"), self.catchupEnabled),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testPortal, "red": self.close, "cancel": self.close,
            "left": self.keyLeft, "right": self.keyRight
        }, -1)

    def keyLeft(self):
        try:
            ConfigListScreen.keyLeft(self)
        except Exception:
            pass

    def keyRight(self):
        try:
            ConfigListScreen.keyRight(self)
        except Exception:
            pass


    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if not current:
            return
        cfg = current[1]
        if cfg is self.livePoster or cfg is self.liveInfobarPoster or cfg is self.adultContent or cfg is self.catchupEnabled:
            try:
                cfg.value = not bool(cfg.value)
                cfg.changed()
            except Exception:
                return
            try:
                self["config"].invalidateCurrent()
            except Exception:
                pass
            return
        if not isinstance(cfg, ConfigText):
            return
        self.session.openWithCallback(self.keyboardCallback, VirtualKeyBoard, title=current[0], text=cfg.value or "")

    @staticmethod
    def _formatMacValue(value):
        raw = str(value or "").upper()
        hexchars = "".join(ch for ch in raw if ch in "0123456789ABCDEF")[:12]
        return ":".join(hexchars[i:i + 2] for i in range(0, len(hexchars), 2))

    @classmethod
    def _parseMacList(cls, value):
        entries = []
        seen = set()
        raw = str(value or "").replace("\n", ",").replace(";", ",")
        for part in raw.split(","):
            part = part.strip()
            if not part:
                continue
            if "=" in part:
                mac_raw, alias = part.split("=", 1)
            elif "|" in part:
                mac_raw, alias = part.split("|", 1)
            else:
                mac_raw, alias = part, ""
            mac = cls._formatMacValue(mac_raw)
            bits = mac.split(":")
            try:
                valid = len(bits) == 6 and all(len(bit) == 2 and int(bit, 16) >= 0 for bit in bits)
            except Exception:
                valid = False
            if valid and mac not in seen:
                seen.add(mac)
                entries.append({"mac": mac, "alias": str(alias or "").strip()})
        return entries

    @classmethod
    def _initialMacList(cls, source):
        source = source or {}
        entries = []
        raw = source.get("macs")
        if isinstance(raw, list):
            for row in raw:
                if isinstance(row, dict):
                    mac = cls._formatMacValue(row.get("mac", ""))
                    alias = str(row.get("alias") or "").strip()
                    if mac:
                        entries.append("%s=%s" % (mac, alias) if alias else mac)
        if not entries:
            mac = cls._formatMacValue(source.get("mac", ""))
            alias = str(source.get("mac_alias") or source.get("alias") or "").strip()
            if mac:
                entries.append("%s=%s" % (mac, alias) if alias else mac)
        return ", ".join(entries)

    def keyboardCallback(self, value=None):
        if value is None:
            return
        current = self["config"].getCurrent()
        if current:
            cfg = current[1]
            if cfg is self.mac:
                parsed = self._parseMacList(value)
                cfg.value = ", ".join(
                    ("%s=%s" % (row["mac"], row["alias"])) if row.get("alias") else row["mac"]
                    for row in parsed
                )
            else:
                cfg.value = value
            self["config"].invalidateCurrent()

    def _normalisePortal(self):
        portal = (self.portal.value or "").strip().rstrip("/")
        if portal and "://" not in portal:
            portal = "http://" + portal
        return portal

    def _normaliseMacs(self):
        return self._parseMacList(self.mac.value)

    def _normaliseMac(self):
        rows = self._normaliseMacs()
        return rows[0]["mac"] if rows else ""

    def _diagnosticText(self, report):
        report = report or {}
        endpoint = report.get("endpoint") or "Not detected"
        quick = bool(report.get("quick_test"))
        lines = [
            "Portal path: %s" % endpoint,
            "Handshake: %s" % ("OK" if report.get("handshake") else "FAILED"),
            "Profile: %s" % ("OK" if report.get("profile") else "FAILED"),
            "Live categories: %s" % int(report.get("categories") or 0),
            "Live channels: %s" % ("SKIPPED" if quick else int(report.get("channels") or 0)),
            "Create live link: %s" % ("SKIPPED" if quick else ("OK" if report.get("live_link") else "FAILED")),
        ]
        if report.get("error"):
            lines.append("Error: %s" % report.get("error"))
        lines.append("Player engine is tested during playback; try 4097, 5002 or 5001 if video is black.")
        return "\n".join(lines)

    def testPortal(self):
        portal = self._normalisePortal()
        macs = self._normaliseMacs()
        mac = macs[0]["mac"] if macs else ""
        parts = mac.split(":")
        try:
            valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
        except Exception:
            valid_mac = False
        if not ((portal.startswith("http://") or portal.startswith("https://")) and valid_mac):
            self.session.open(MessageBox, "Enter a valid Portal URL and MAC first.", MessageBox.TYPE_ERROR); return
        self["hint"].setText("Testing portal with first MAC (%d saved): handshake, profile and categories..." % len(macs))
        source = {"type": "stalker", "name": self.provider.value or "Stalker Portal", "url": portal, "mac": mac}
        def worker():
            try:
                report = StalkerClient(source).test()
            except Exception as exc:
                report = {"ok": False, "error": str(exc), "stage": "test"}
            message = self._diagnosticText(report)
            def done():
                try:
                    self["hint"].setText("Portal test completed.")
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if report.get("ok") else MessageBox.TYPE_ERROR, timeout=15)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        thread = threading.Thread(target=worker, name="TiviMateStalkerTest")
        thread.daemon = True
        thread.start()

    def save(self):
        portal = self._normalisePortal()
        macs = self._normaliseMacs()
        mac = macs[0]["mac"] if macs else ""
        valid_portal = portal.startswith("http://") or portal.startswith("https://")
        parts = mac.split(":")
        try:
            valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
        except Exception:
            valid_mac = False
        if not valid_portal or not valid_mac:
            self.session.open(MessageBox, "Enter a valid Portal URL and a MAG MAC address in the format 00:1A:79:12:34:56.", MessageBox.TYPE_ERROR); return
        src = dict(self.original or {})
        src.update({
            "type": "stalker",
            "name": (self.provider.value or "Stalker Portal").strip() or "Stalker Portal",
            "url": portal,
            "macs": list(macs),
            "mac": mac,
            "epg_offset": self.epgOffset.value,
            "service_type": _clean_stream_type(self.liveStreamType.value),
            "show_live_poster": bool(self.livePoster.value),
            "show_live_infobar_poster": bool(self.liveInfobarPoster.value),
            "adult_enabled": not bool(self.adultContent.value),
            "catchup_enabled": bool(self.catchupEnabled.value)
        })
        stalker_types = _load_stalker_service_types(src)
        stalker_types["live"] = _clean_stream_type(self.liveStreamType.value)
        _save_stalker_service_types(src, stalker_types)
        src.pop("mac_alias", None)
        src.pop("alias", None)
        self.close(src)


class TMDbKeyImportBrowser(Screen):
    """Tiny local file browser used only to import a private TMDb credential.

    The shared credential is never displayed here.  The browser starts at / so
    users can reach HDD, USB, /tmp, /home/root and any other mounted Enigma2
    path with the remote control.
    """
    skin = r"""<screen name="TMDbKeyImportBrowser" position="center,center" size="1500,850" flags="wfNoBorder" backgroundColor="#070A0E">
        <eLabel position="0,0" size="1500,92" backgroundColor="#0B1118" zPosition="1"/>
        <widget name="title" position="48,18" size="900,54" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="2"/>
        <widget name="path" position="48,102" size="1404,46" font="Regular;25" foregroundColor="#9CB6C9" transparent="1" zPosition="2"/>
        <widget name="list" position="48,162" size="1404,570" font="Regular;28" itemHeight="48" scrollbarMode="showOnDemand" backgroundColor="#090E14" foregroundColor="#FFFFFF" zPosition="2"/>
        <eLabel position="48,752" size="1404,2" backgroundColor="#244256" zPosition="2"/>
        <widget name="hint" position="48,770" size="1404,52" font="Regular;24" foregroundColor="#DDE8F0" transparent="1" halign="center" valign="center" zPosition="2"/>
    </screen>"""

    def __init__(self, session, start_path="/"):
        Screen.__init__(self, session)
        self.current_path = self._safe_dir(start_path)
        self.entries = []
        self["title"] = Label("IMPORT TMDb KEY")
        self["path"] = Label("")
        self["list"] = MenuList([])
        self["hint"] = Label("OK  OPEN / IMPORT     BACK  PARENT     RED  CANCEL")
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok,
            "cancel": self.back,
            "red": self.close,
            "up": self.up,
            "down": self.down,
            "left": self.pageUp,
            "right": self.pageDown,
        }, -1)
        self._reload()

    def _safe_dir(self, path):
        try:
            path = os.path.abspath(path or "/")
            if os.path.isdir(path):
                return path
        except Exception:
            pass
        return "/"

    def _reload(self):
        path = self._safe_dir(self.current_path)
        self.current_path = path
        rows = []
        entries = []
        if path != "/":
            rows.append("[..]  Parent folder")
            entries.append(("parent", os.path.dirname(path.rstrip("/")) or "/"))
        try:
            names = os.listdir(path)
        except Exception:
            names = []
        dirs, files = [], []
        for name in names:
            if not name or name in (".", ".."):
                continue
            full = os.path.join(path, name)
            try:
                if os.path.isdir(full):
                    dirs.append((name.lower(), name, full))
                elif os.path.isfile(full):
                    files.append((name.lower(), name, full))
            except Exception:
                continue
        dirs.sort(key=lambda x: x[0])
        files.sort(key=lambda x: x[0])
        for _, name, full in dirs:
            rows.append("[DIR]  %s" % name)
            entries.append(("dir", full))
        for _, name, full in files:
            try:
                size = os.path.getsize(full)
                size_txt = self._fmt_size(size)
            except Exception:
                size_txt = ""
            rows.append("       %s%s" % (name, ("   (%s)" % size_txt) if size_txt else ""))
            entries.append(("file", full))
        if not rows:
            rows = ["(empty folder)"]
            entries = [("empty", path)]
        self.entries = entries
        self["list"].setList(rows)
        self["path"].setText(path)

    def _fmt_size(self, size):
        try:
            size = int(size)
        except Exception:
            return ""
        if size < 1024:
            return "%d B" % size
        if size < 1024 * 1024:
            return "%.1f KB" % (size / 1024.0)
        return "%.1f MB" % (size / (1024.0 * 1024.0))

    def _index(self):
        try:
            return int(self["list"].getSelectedIndex())
        except Exception:
            try:
                return int(self["list"].l.getCurrentSelectionIndex())
            except Exception:
                return 0

    def _selected(self):
        idx = self._index()
        if 0 <= idx < len(self.entries):
            return self.entries[idx]
        return None

    def up(self):
        try: self["list"].up()
        except Exception: pass

    def down(self):
        try: self["list"].down()
        except Exception: pass

    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: pass

    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: pass

    def back(self):
        if self.current_path == "/":
            self.close(None)
            return
        self.current_path = os.path.dirname(self.current_path.rstrip("/")) or "/"
        self._reload()

    def ok(self):
        selected = self._selected()
        if not selected:
            return
        kind, path = selected
        if kind in ("parent", "dir"):
            self.current_path = self._safe_dir(path)
            self._reload()
            return
        if kind != "file":
            return
        try:
            key = self._read_key(path)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to import this file: %s" % exc, MessageBox.TYPE_ERROR, timeout=6)
            return
        if not key:
            self.session.open(MessageBox, "No valid TMDb key was found in this file.", MessageBox.TYPE_ERROR, timeout=6)
            return
        self.close(key)

    def _read_key(self, path):
        # Keys are tiny text values.  Refuse huge/binary files so selecting a
        # movie, database or image cannot stall the receiver.
        try:
            size = os.path.getsize(path)
        except Exception:
            size = 0
        if size > 65536:
            raise ValueError("file is too large")
        with open(path, "rb") as handle:
            raw = handle.read(65536)
        if b"\x00" in raw:
            raise ValueError("file is not plain text")
        try:
            text = raw.decode("utf-8-sig")
        except Exception:
            text = raw.decode("latin-1", "ignore")
        text = text.strip()
        if not text:
            return ""

        # JSON export support, e.g. {"tmdb_key":"..."}.
        try:
            obj = json.loads(text)
            if isinstance(obj, dict):
                for name in ("tmdb_key", "tmdb_api_key", "api_key", "access_token", "token", "key"):
                    value = obj.get(name)
                    if isinstance(value, str) and value.strip():
                        return self._clean_value(value)
        except Exception:
            pass

        wanted = set(("tmdb_key", "tmdb_api_key", "api_key", "access_token", "token", "key"))
        raw_candidates = []
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith(";"):
                continue
            raw_candidates.append(line)
            for sep in ("=", ":"):
                if sep in line:
                    left, right = line.split(sep, 1)
                    left = left.strip().lower().replace("-", "_").replace(" ", "_")
                    if left in wanted and right.strip():
                        return self._clean_value(right)
        if len(raw_candidates) == 1:
            return self._clean_value(raw_candidates[0])
        # If a normal key/token appears among comments or metadata, accept the
        # first credential-looking line only; never display it in the browser.
        for value in raw_candidates:
            cleaned = self._clean_value(value)
            if self._looks_like_key(cleaned):
                return cleaned
        return ""

    def _clean_value(self, value):
        value = str(value or "").strip().strip('"').strip("'").strip()
        if value.lower().startswith("bearer "):
            value = value[7:].strip()
        return value

    def _looks_like_key(self, value):
        if not value or len(value) < 16 or len(value) > 4096:
            return False
        if any(ch.isspace() for ch in value):
            return False
        return True


class TMDbSettings(Screen, ConfigListScreen):
    skin = TMDB_SETTINGS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = load_tmdb_settings()
        self["title"] = Label(tr("TMDb TRENDING SETTINGS"))
        self["hint"] = Label(tr("Built-in TMDb access is active. Enter your own key only to override it."))
        self["keys"] = Label("GREEN SAVE    BLUE TEST    YELLOW IMPORT TMDB KEY    RED CANCEL")
        self.mode = ConfigSelection(default=cfg.get("mode", "auto"), choices=[
            ("auto", "Auto (Shared key / Custom key)"),
            ("disabled", "Disabled"),
        ])
        # Keep the three legacy credential fields out of the visible UI. A single
        # masked override is easier to use and preserves the shared built-in key
        # when left empty. Existing v3/v4 overrides are migrated into this field.
        existing_custom = (cfg.get("custom_api_key") or cfg.get("custom_api_key2") or cfg.get("custom_access_token") or "")
        self.customTmdbKey = ConfigPassword(default=existing_custom, fixed_size=False)
        self.language = ConfigSelection(default=cfg.get("language_setting", cfg.get("language", "auto")), choices=[("auto", "Device language (Auto)"), ("en-US", "English"), ("ar-AE", "Arabic")])
        self.backdropQuality = ConfigSelection(default=cfg.get("backdrop_quality", "w1280"), choices=[
            ("w1280", "Balanced (1280)"),
            ("w1920", "High (1920)"),
            ("original", "Original"),
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry("TMDb Mode", self.mode),
            getConfigListEntry(tr("Metadata language"), self.language),
            getConfigListEntry("Backdrop Quality", self.backdropQuality),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyboard, "green": self.save, "blue": self.testConnection,
            "yellow": self.addTmdbKey, "red": self.close, "cancel": self.close
        }, -1)


    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        current = self["config"].getCurrent()
        if current and isinstance(current[1], ConfigText):
            self.session.openWithCallback(self.keyboardDone, VirtualKeyBoard, title=current[0], text=current[1].value or "")

    def keyboardDone(self, value=None):
        if value is None: return
        current = self["config"].getCurrent()
        if current:
            current[1].value = value
            self["config"].invalidateCurrent()

    def _credentialsValid(self):
        # Enabled modes always have shared built-in credentials; fields here are
        # optional user overrides.
        return True

    def _splitCustomCredential(self):
        value = (self.customTmdbKey.value or "").strip()
        if not value:
            return "", ""
        # TMDb v4 read-access tokens are long bearer/JWT-like strings. Standard
        # v3 API keys are short hex-like values. Keep detection deliberately
        # simple so pasted keys continue to work without another mode selector.
        lower = value.lower()
        if len(value) > 64 or lower.startswith("eyj") or value.count(".") >= 2:
            return "", value
        return value, ""

    def save(self):
        if not self._credentialsValid():
            self.session.open(MessageBox, "Enter the credential required by the selected TMDb mode.", MessageBox.TYPE_ERROR); return
        custom_key, custom_token = self._splitCustomCredential()
        # One visible custom key replaces the three legacy override fields. The
        # second custom API key is intentionally cleared; shared fallback remains.
        if save_tmdb_settings(custom_key, self.language.value, self.mode.value, custom_token, "", self.backdropQuality.value):
            self.session.open(MessageBox, "TMDb settings saved.", MessageBox.TYPE_INFO, timeout=4)
            self.close()
        else:
            self.session.open(MessageBox, "Unable to save settings.", MessageBox.TYPE_ERROR)

    def testConnection(self):
        if not self._credentialsValid():
            self.session.open(MessageBox, "Enter the credential required by the selected TMDb mode.", MessageBox.TYPE_ERROR); return
        self["hint"].setText("Testing TMDb connection...")
        mode = self.mode.value
        custom_key, custom_token = self._splitCustomCredential()
        key = custom_key or None
        token = custom_token or None
        key2 = None
        language = self.language.value
        def worker():
            ok, message = False, ""
            try:
                client = TMDbClient(api_key=key, api_key2=key2, access_token=token, mode=mode,
                    language=None if language == "auto" else language)
                client._get("/configuration", {})
                ok, message = True, "TMDb connection successful."
            except Exception as exc:
                message = "TMDb connection failed: %s" % exc
            def done():
                try:
                    self["hint"].setText(message)
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=6)
                except Exception:
                    pass
            try:
                reactor.callFromThread(done) if reactor is not None else done()
            except Exception:
                done()
        t = threading.Thread(target=worker, name="TiviMateTMDbTest")
        t.daemon = True
        t.start()


SERVER_CATEGORY_FILTER_SKIN = r"""<screen name="ServerCategoryFilter" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#02060B">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_cinematic_bg_r209.jpg" alphatest="blend" zPosition="0"/>
<eLabel position="0,0" size="1920,128" backgroundColor="#050A10" zPosition="1"/>
<eLabel position="48,126" size="1824,2" backgroundColor="#153653" zPosition="2"/>
<ePixmap position="64,26" size="306,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="4"/>
<widget name="brand" position="1,1" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" zPosition="1"/>
<widget name="title" position="430,25" size="900,52" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" zPosition="4"/>
<eLabel position="432,78" size="720,30" text="Select and filter server packages" font="Regular;22" foregroundColor="#8EA7BA" transparent="1" zPosition="4"/>
<widget name="page" position="1460,36" size="390,46" font="Regular;27" foregroundColor="#D7E8F5" transparent="1" halign="right" zPosition="4"/>

<eLabel position="102,150" size="548,112" backgroundColor="#071A2B" zPosition="1"/>
<eLabel position="686,150" size="548,112" backgroundColor="#21112F" zPosition="1"/>
<eLabel position="1270,150" size="548,112" backgroundColor="#07282E" zPosition="1"/>
<ePixmap position="132,168" size="76,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_tab_live_r209.png" alphatest="blend" zPosition="4"/>
<ePixmap position="716,168" size="76,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_tab_vod_r209.png" alphatest="blend" zPosition="4"/>
<ePixmap position="1300,168" size="76,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_tab_series_r209.png" alphatest="blend" zPosition="4"/>
<widget name="tabLive" position="218,177" size="405,56" font="Regular;32" foregroundColor="#59C8FF" transparent="1" halign="center" valign="center" zPosition="4"/>
<widget name="tabMovies" position="802,177" size="405,56" font="Regular;32" foregroundColor="#C987FF" transparent="1" halign="center" valign="center" zPosition="4"/>
<widget name="tabSeries" position="1386,177" size="405,56" font="Regular;32" foregroundColor="#54E4D6" transparent="1" halign="center" valign="center" zPosition="4"/>
<widget name="tabFocus" position="102,258" size="548,5" backgroundColor="#59C8FF" zPosition="5"/>

<widget name="card0" position="102,286" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon0" position="124,325" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name0" position="228,320" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta0" position="228,376" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state0" position="508,346" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card1" position="700,286" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon1" position="722,325" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name1" position="826,320" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta1" position="826,376" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state1" position="1106,346" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card2" position="1298,286" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon2" position="1320,325" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name2" position="1424,320" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta2" position="1424,376" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state2" position="1704,346" size="92,42" alphatest="blend" zPosition="5"/>

<widget name="card3" position="102,470" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon3" position="124,509" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name3" position="228,504" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta3" position="228,560" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state3" position="508,530" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card4" position="700,470" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon4" position="722,509" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name4" position="826,504" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta4" position="826,560" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state4" position="1106,530" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card5" position="1298,470" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon5" position="1320,509" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name5" position="1424,504" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta5" position="1424,560" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state5" position="1704,530" size="92,42" alphatest="blend" zPosition="5"/>

<widget name="card6" position="102,654" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon6" position="124,693" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name6" position="228,688" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta6" position="228,744" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state6" position="508,714" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card7" position="700,654" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon7" position="722,693" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name7" position="826,688" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta7" position="826,744" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state7" position="1106,714" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="card8" position="1298,654" size="520,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="icon8" position="1320,693" size="84,84" alphatest="blend" zPosition="4"/>
<widget name="name8" position="1424,688" size="280,54" font="Regular;30" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="meta8" position="1424,744" size="255,34" font="Regular;20" foregroundColor="#90A7B9" transparent="1" valign="center" zPosition="4"/>
<widget name="state8" position="1704,714" size="92,42" alphatest="blend" zPosition="5"/>
<widget name="cardFocus" position="96,280" size="532,174" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_focus_r208.png" alphatest="blend" zPosition="7"/>

<widget name="summary" position="190,836" size="1540,42" font="Regular;26" foregroundColor="#B9D7EA" transparent="1" halign="center" zPosition="4"/>
<widget name="hint" position="190,879" size="1540,32" font="Regular;20" foregroundColor="#8299AA" transparent="1" halign="center" zPosition="4"/>
<eLabel position="58,930" size="1804,2" backgroundColor="#17324B" zPosition="2"/>

<ePixmap position="90,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_red_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="150,964" size="205,42" text="Disable All" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="370,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_yellow_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="430,964" size="205,42" text="Enable All" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="650,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_green_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="710,964" size="190,42" text="Save Filters" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="930,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_blue_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="990,964" size="220,42" text="Change Category" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="1240,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_nav_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="1300,964" size="185,42" text="Navigate" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<ePixmap position="1510,958" size="54,54" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_ok_r209.png" alphatest="blend" zPosition="4"/>
<eLabel position="1570,964" size="245,42" text="Select / Toggle" font="Regular;21" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<widget name="keys" position="1,1" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" zPosition="1"/>
</screen>"""

class ServerCategoryFilter(Screen):
    skin = SERVER_CATEGORY_FILTER_SKIN
    ALL_KINDS = [("live", "LIVE TV"), ("vod", "MOVIES"), ("series", "TV SHOWS")]
    PAGE_SIZE = 9
    CARD_POSITIONS = [
        (102,286),(700,286),(1298,286),
        (102,470),(700,470),(1298,470),
        (102,654),(700,654),(1298,654),
    ]

    def __init__(self, session, source, initial_kind=None, fixed_kind=False):
        Screen.__init__(self, session)
        self.source = source or {}
        self.fixed_kind = bool(fixed_kind)
        requested = str(initial_kind or "").strip().lower()
        if self.fixed_kind and requested in ("vod", "series"):
            self.KINDS = [(requested, "MOVIES" if requested == "vod" else "TV SHOWS")]
        elif self.source.get("type") in ("stalker", "xtream"):
            self.KINDS = list(self.ALL_KINDS)
        else:
            self.KINDS = [("live", "LIVE TV")]
        self.kindIndex = 0
        if requested:
            for i, item in enumerate(self.KINDS):
                if item[0] == requested:
                    self.kindIndex = i
                    break
        self.pageIndex = 0
        self.cursorIndex = 0
        self.rows = []
        self.selected = {}
        self.loaded = {}
        self["brand"] = Label("TiViMate E2")
        self["title"] = Label("")
        self["page"] = Label("")
        self["tabLive"] = Label("LIVE TV")
        self["tabMovies"] = Label("MOVIES")
        self["tabSeries"] = Label("TV SHOWS")
        self["tabFocus"] = Label("")
        for i in range(9):
            self["card%d" % i] = Pixmap()
            self["icon%d" % i] = Pixmap()
            self["name%d" % i] = Label("")
            self["meta%d" % i] = Label("")
            self["state%d" % i] = Pixmap()
        self["cardFocus"] = Pixmap()
        self["summary"] = Label("")
        self["hint"] = Label("")
        self["keys"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "ok": self.toggle, "cancel": self.close, "green": self.save,
            "yellow": self.selectAll, "red": self.clearAll, "blue": self.nextKind,
            "left": self.moveLeft, "right": self.moveRight,
            "up": self.moveUp, "down": self.moveDown,
            "pageUp": self.prevPage, "pageDown": self.nextPage,
        }, -1)
        self.onLayoutFinish.append(self.loadCurrent)

    def _kind(self):
        return self.KINDS[self.kindIndex][0]

    def _updateTabs(self):
        kind = self._kind()
        pos = {"live": (102,258), "vod": (686,258), "series": (1270,258)}.get(kind, (102,258))
        color = {"live":"#58C0FF", "vod":"#C68BFF", "series":"#52E7D8"}.get(kind, "#58C0FF")
        try:
            self["tabFocus"].instance.move(ePoint(pos[0], pos[1]))
            self["tabFocus"].instance.resize(eSize(548,5))
            self["tabFocus"].instance.setBackgroundColor(parseColor(color))
        except Exception:
            pass

    def _updateFocus(self):
        if not self.rows:
            try: self["cardFocus"].hide()
            except Exception: pass
            return
        self.cursorIndex = max(0, min(self.cursorIndex, len(self.rows)-1))
        x, y = self.CARD_POSITIONS[self.cursorIndex]
        try:
            self["cardFocus"].show()
            self["cardFocus"].instance.move(ePoint(x-6, y-6))
        except Exception:
            pass

    def loadCurrent(self):
        kind, label = self.KINDS[self.kindIndex]
        self.pageIndex = 0
        self.cursorIndex = 0
        self["title"].setText("PACKAGE FILTER  •  %s" % label)
        self["hint"].setText("Loading %s packages..." % label)
        self._updateTabs()
        try:
            source_type = self.source.get("type")
            if source_type == "xtream":
                cats = XtreamClient(self.source).categories(kind) or []
                candidates = [(c.get("category_id", ""), c.get("category_name") or "Other") for c in cats]
            elif source_type == "stalker":
                cats = StalkerClient(self.source).categories(kind) or []
                candidates = [(c.get("category_id", ""), c.get("category_name") or "Other") for c in cats]
            else:
                entries = M3UClient(self.source).entries() or []
                candidates = [(e.get("group", "Other"), e.get("group", "Other")) for e in entries]
            clean, seen = [], set()
            for raw_id, raw_name in candidates:
                cid = str(raw_id or "").strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                clean.append({"id": cid, "name": str(raw_name or "Other").strip()})
            self.loaded[kind] = clean
            if kind not in self.selected:
                configured = get_allowed_category_ids(self.source, kind)
                self.selected[kind] = set(x["id"] for x in clean) if configured is None else set(configured)
            self.render()
        except Exception as exc:
            self.rows = []
            self["page"].setText("PAGE 0 / 0")
            self["summary"].setText("")
            self["hint"].setText("Unable to load packages: %s" % exc)
            for i in range(9):
                self["name%d" % i].setText("")
                self["meta%d" % i].setText("")
                try:
                    self["card%d" % i].hide(); self["icon%d" % i].hide(); self["state%d" % i].hide()
                except Exception:
                    pass
            self._updateFocus()

    def render(self):
        kind, label = self.KINDS[self.kindIndex]
        selected = self.selected.get(kind, set())
        allrows = self.loaded.get(kind, [])
        pages = max(1, (len(allrows) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        self.pageIndex = max(0, min(self.pageIndex, pages - 1))
        a = self.pageIndex * self.PAGE_SIZE
        b = a + self.PAGE_SIZE
        self.rows = allrows[a:b]
        self.cursorIndex = max(0, min(self.cursorIndex, max(0, len(self.rows)-1)))
        accent = {"live": ("LIVE", "#0E3150", "#59C8FF"), "vod": ("MOV", "#2B1840", "#C987FF"), "series": ("TV", "#08343A", "#54E4D6")}.get(kind, ("PKG", "#123149", "#59C8FF"))
        for i in range(9):
            card = self["card%d" % i]
            icon = self["icon%d" % i]
            name_w = self["name%d" % i]
            meta = self["meta%d" % i]
            state = self["state%d" % i]
            if i < len(self.rows):
                row = self.rows[i]
                number = a + i + 1
                name = row.get("name") or "Other"
                if len(name) > 30:
                    name = name[:27] + "..."
                name_w.setText(name)
                meta.setText("PACKAGE %02d" % number)
                enabled = row.get("id") in selected
                try:
                    icon_path = os.path.join(PLUGIN_PATH, "skins/package_filter_icon_%s_r208.png" % kind)
                    switch_path = os.path.join(PLUGIN_PATH, "skins/package_filter_switch_%s_r208.png" % ("on" if enabled else "off"))
                    icon.instance.setPixmap(LoadPixmap(icon_path))
                    state.instance.setPixmap(LoadPixmap(switch_path))
                    card.show(); icon.show(); state.show()
                except Exception:
                    pass
            else:
                name_w.setText("")
                meta.setText("")
                try:
                    card.hide(); icon.hide(); state.hide()
                except Exception:
                    pass
        self["page"].setText("PAGE %d / %d" % (self.pageIndex + 1, pages))
        shown_from = 0 if not allrows else a + 1
        shown_to = min(b, len(allrows))
        self["summary"].setText("%s   •   %d / %d ENABLED   •   %d-%d" % (label, len(selected), len(allrows), shown_from, shown_to))
        self["hint"].setText("Use arrows to navigate • OK toggles package • edge left/right changes page")
        self._updateTabs()
        self._updateFocus()

    def toggle(self):
        if not self.rows or self.cursorIndex >= len(self.rows):
            return
        kind = self._kind()
        cid = str(self.rows[self.cursorIndex].get("id") or "")
        selected = self.selected.setdefault(kind, set())
        if cid in selected:
            selected.remove(cid)
        else:
            selected.add(cid)
        self.render()

    def selectAll(self):
        self.selected[self._kind()] = set(x["id"] for x in self.loaded.get(self._kind(), []))
        self.render()

    def clearAll(self):
        self.selected[self._kind()] = set()
        self.render()

    def prevPage(self):
        if self.pageIndex > 0:
            self.pageIndex -= 1
            self.cursorIndex = 0
            self.render()

    def nextPage(self):
        total = len(self.loaded.get(self._kind(), []))
        pages = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        if self.pageIndex + 1 < pages:
            self.pageIndex += 1
            self.cursorIndex = 0
            self.render()

    def moveLeft(self):
        if not self.rows:
            return
        col = self.cursorIndex % 3
        if col > 0:
            self.cursorIndex -= 1
            self._updateFocus()
        elif self.pageIndex > 0:
            self.pageIndex -= 1
            self.cursorIndex = min(2, len(self.loaded.get(self._kind(), [])) - self.pageIndex * self.PAGE_SIZE - 1)
            self.render()

    def moveRight(self):
        if not self.rows:
            return
        col = self.cursorIndex % 3
        if col < 2 and self.cursorIndex + 1 < len(self.rows):
            self.cursorIndex += 1
            self._updateFocus()
        else:
            total = len(self.loaded.get(self._kind(), []))
            pages = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
            if self.pageIndex + 1 < pages:
                self.pageIndex += 1
                self.cursorIndex = 0
                self.render()

    def moveUp(self):
        if not self.rows:
            return
        if self.cursorIndex >= 3:
            self.cursorIndex -= 3
            self._updateFocus()
        elif self.pageIndex > 0:
            self.pageIndex -= 1
            self.cursorIndex = min(self.cursorIndex + 6, 8)
            self.render()

    def moveDown(self):
        if not self.rows:
            return
        if self.cursorIndex + 3 < len(self.rows):
            self.cursorIndex += 3
            self._updateFocus()
        else:
            total = len(self.loaded.get(self._kind(), []))
            pages = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
            if self.pageIndex + 1 < pages:
                self.pageIndex += 1
                self.cursorIndex = self.cursorIndex % 3
                self.render()

    def nextKind(self):
        if len(self.KINDS) > 1:
            self.kindIndex = (self.kindIndex + 1) % len(self.KINDS)
            self.loadCurrent()

    def prevKind(self):
        if len(self.KINDS) > 1:
            self.kindIndex = (self.kindIndex - 1) % len(self.KINDS)
            self.loadCurrent()

    def save(self):
        data = _load_all_filters()
        key = _source_filter_key(self.source)
        entry = dict(data.get(key, {}) or {})
        for kind, _label in self.KINDS:
            if kind not in self.selected:
                continue
            selected = set(str(x) for x in self.selected.get(kind, set()))
            available = set(str(x.get("id") or "") for x in self.loaded.get(kind, []))
            if available and selected == available:
                entry.pop(kind, None)
            else:
                entry[kind] = sorted(selected)
        if entry:
            data[key] = entry
        else:
            data.pop(key, None)
        if _save_all_filters(data):
            try:
                prefetch_selected_categories(self.source, entry)
            except Exception:
                pass
            try:
                from .epg_local import refresh_source_epg
                refresh_source_epg(self.source, force=True, background=True)
            except Exception:
                pass
            try:
                from .epgimport_sync import sync_epgimport_sources
                sync_epgimport_sources(get_sources(), background=True)
            except Exception:
                pass
            self.session.open(MessageBox, "Packages saved. EPG for selected packages is updating in the background.", MessageBox.TYPE_INFO)
            self.close(True)
        else:
            self.session.open(MessageBox, "Unable to save the filter.", MessageBox.TYPE_ERROR)






PROFESSIONAL_PACKAGE_BROWSER_SKIN = r"""<screen name="HomePackageBrowserScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#030508">
<widget name="background" position="0,0" size="1920,1080" alphatest="blend" scale="1" zPosition="0"/>
<eLabel position="0,0" size="390,1080" backgroundColor="#050608" zPosition="3"/>
<eLabel position="389,0" size="2,1080" backgroundColor="#D9DDE2" zPosition="4"/>
<ePixmap position="28,24" size="325,96" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_e2_gold_logo.png" alphatest="blend" scale="1" zPosition="6"/>
<widget name="sideSelector" position="15,389" size="360,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages_nav_focus_r52.png" alphatest="blend" zPosition="7"/>

<widget name="nav0" position="78,130" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav1" position="78,215" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav2" position="78,300" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav3" position="78,402" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav4" position="78,500" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<widget name="nav5" position="78,585" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="8"/>
<ePixmap position="35,928" size="320,90" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/developed_by_opesboy_signature_r212.png" alphatest="blend" scale="1" zPosition="8"/>

<widget name="title" position="500,80" size="930,70" font="Regular;50" foregroundColor="#E5B243" transparent="1" zPosition="8"/>
<widget name="subtitle" position="505,160" size="1000,34" font="Regular;22" foregroundColor="#E0D8EE" transparent="1" zPosition="8"/>
<widget name="count" position="1430,110" size="320,40" font="Regular;24" foregroundColor="#E5B243" transparent="1" halign="right" zPosition="8"/>
<widget name="serverNameBold" position="1281,148" size="470,48" font="Regular;32" foregroundColor="#FF3030" transparent="1" halign="right" valign="center" zPosition="8"/>
<widget name="serverName" position="1280,148" size="470,48" font="Regular;32" foregroundColor="#FF3030" transparent="1" halign="right" valign="center" zPosition="9"/>
<widget name="clock" position="1500,36" size="250,38" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="right" zPosition="8"/>
<widget name="date" position="1465,80" size="285,26" font="Regular;18" foregroundColor="#B3BDC7" transparent="1" halign="right" zPosition="8"/>

<eLabel position="475,225" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,318" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,411" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,504" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,597" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>
<eLabel position="475,690" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>

<widget name="logo0" position="500,237" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo1" position="500,330" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo2" position="500,423" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo3" position="500,516" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo4" position="500,609" size="150,58" alphatest="blend" scale="1" zPosition="7"/>
<widget name="logo5" position="500,702" size="150,58" alphatest="blend" scale="1" zPosition="7"/>

<widget name="row0" position="675,232" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row1" position="675,325" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row2" position="675,418" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row3" position="675,511" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row4" position="675,604" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>
<widget name="row5" position="675,697" size="760,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" valign="center" shadowColor="#000000" shadowOffset="2,2" zPosition="7"/>

<widget name="desc0" position="675,269" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc1" position="675,362" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc2" position="675,455" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc3" position="675,548" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc4" position="675,641" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>
<widget name="desc5" position="675,734" size="700,27" font="Regular;18" foregroundColor="#A997BD" transparent="1" zPosition="7"/>

<widget name="meta0" position="1460,242" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta1" position="1460,335" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta2" position="1460,428" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta3" position="1460,521" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta4" position="1460,614" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>
<widget name="meta5" position="1460,707" size="250,42" font="Regular;20" foregroundColor="#D7D0E1" transparent="1" halign="right" valign="center" zPosition="7"/>

<widget name="packageTextFocusBg" position="655,232" size="1080,66" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_text_focus_bg_r180.png" alphatest="blend" zPosition="6"/>
<widget name="packageSelector" position="475,225" size="1340,84" alphatest="blend" zPosition="9"/>

<eLabel position="475,820" size="1340,82" backgroundColor="#07080B" cornerRadius="16" zPosition="4"/>
<ePixmap position="510,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_red_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="back" position="575,839" size="185,48" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="805,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_ok_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="open" position="870,839" size="180,48" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="1085,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_yellow_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="sort" position="1150,839" size="210,48" font="Regular;22" foregroundColor="#E5B243" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="1380,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_green_r209.png" alphatest="blend" scale="1" zPosition="8"/>
<widget name="info" position="1445,839" size="280,48" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="8"/>
<ePixmap position="1715,832" size="56,56" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_filter_key_blue_r209.png" alphatest="blend" scale="1" zPosition="8"/>
</screen>"""


PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SKIN
PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN.replace('<eLabel position="475,225" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,225" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_package_glass_row_r68.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN.replace('<eLabel position="475,318" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,318" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_package_glass_row_r68.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN.replace('<eLabel position="475,411" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,411" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_package_glass_row_r68.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN.replace('<eLabel position="475,504" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,504" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_package_glass_row_r68.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN.replace('<eLabel position="475,597" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,597" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_package_glass_row_r68.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN.replace('<eLabel position="475,690" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,690" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/series_package_glass_row_r68.png" alphatest="blend" zPosition="4"/>')

PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_SKIN
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN.replace('<eLabel position="475,225" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,225" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN.replace('<eLabel position="475,318" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,318" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN.replace('<eLabel position="475,411" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,411" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN.replace('<eLabel position="475,504" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,504" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN.replace('<eLabel position="475,597" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,597" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>')
PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN.replace('<eLabel position="475,690" size="1340,84" backgroundColor="#0B0C11" cornerRadius="14" zPosition="4"/>', '<ePixmap position="475,690" size="1340,84" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movie_package_glass_row_r67.png" alphatest="blend" zPosition="4"/>')

class HomePackageBrowserScreen(Screen):
    skin = PROFESSIONAL_PACKAGE_BROWSER_SKIN
    CARD_ROW_Y = [225,318,411,504,597,690]
    NAV_Y = [119,204,289,391,489,574]

    def __init__(self, session, source, kind):
        self.kind="series" if str(kind)=="series" else "vod"
        # Glass package bars are an MOVIES-only experiment; Series remains exactly as r66.
        self.skin = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN if self.kind=="vod" else PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN
        Screen.__init__(self, session)
        self.source=dict(source or {})
        self.rows=[]
        self.index=0
        self.pageStart=0
        self.sortMode="latest"
        self.focusMode="packages"
        self.navIndex=3
        self["background"]=Pixmap()
        self["sideSelector"]=Pixmap()
        self["packageSelector"]=Pixmap()
        self["packageTextFocusBg"]=Pixmap()
        self["clock"]=Label("")
        self["date"]=Label("")
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["count"]=Label("LOADING")
        self["serverName"]=Label("")
        self["serverNameBold"]=Label("")
        self["back"]=Label("BACK")
        self["open"]=Label("SELECT")
        self["info"]=Label("PACKAGE FILTER      SERVER")
        self["sort"]=Label("LATEST")
        for i,name in enumerate(["LIVE TV","MOVIES","TV SHOWS","PACKAGES","FAVORITES","SETTINGS"]):
            self["nav%d"%i]=Label(name)
        for i in range(6):
            self["row%d"%i]=Label("")
            self["meta%d"%i]=Label("")
            self["logo%d"%i]=Pixmap()
            self["desc%d"%i]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "ok":self.choose,"cancel":self.close,"red":self.close,
            "up":self.up,"down":self.down,"left":self.left,"right":self.right,
            "pageUp":self.pageUp,"pageDown":self.pageDown,
            "green":self.openPackageFilter,
            "yellow":self.togglePackageSort,"blue":self.serverSwitch
        },-1)
        self._loadToken=0
        self._loadResult=None
        self._loadTimer=eTimer()
        _connect_timer(self._loadTimer,self._finishLoad)
        # r284: package list paints text first. Logos are decoded only after the
        # page is already visible, one slot at a time, and then kept in a tiny
        # in-memory slot/path cache so navigation does not decode the same PNG
        # repeatedly. This keeps package opening independent from logo work.
        self._logoTimer=eTimer()
        _connect_timer(self._logoTimer,self._loadNextVisibleLogo)
        self._logoPathCache={}
        self._slotLogoState={}
        self._logoQueue=[]
        self.clockTimer=eTimer()
        _connect_timer(self.clockTimer,self.updateClock)
        self.onLayoutFinish.append(self.start)

    def start(self):
        bg=os.path.join(PLUGIN_PATH,"skins","home_packages_luxury_movies.jpg" if self.kind=="vod" else "home_packages_luxury_series.jpg")
        focus=os.path.join(PLUGIN_PATH,"skins","movie_package_card_focus_r60.png" if self.kind=="vod" else "series_package_card_focus_r60.png")
        try:self["background"].instance.setPixmapFromFile(bg)
        except Exception:pass
        try:self["packageSelector"].instance.setPixmapFromFile(focus)
        except Exception:pass
        try:self["packageTextFocusBg"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","package_text_focus_bg_r180.png"))
        except Exception:pass
        if self.kind=="series":
            try:self["title"].instance.setForegroundColor(parseColor("#B48CFF"))
            except Exception:pass
            try:self["count"].instance.setForegroundColor(parseColor("#B48CFF"))
            except Exception:pass
        else:
            try:self["title"].instance.setForegroundColor(parseColor("#E5B243"))
            except Exception:pass
            try:self["count"].instance.setForegroundColor(parseColor("#E5B243"))
            except Exception:pass
        # Show only the currently active server name on both Movies and TV Shows package pages.
        try:
            active_name = str(self.source.get("name") or self.source.get("title") or "").strip()
            self["serverName"].setText(active_name[:32])
            self["serverNameBold"].setText(active_name[:32])
        except Exception:
            pass
        self.updateClock()
        try:self.clockTimer.start(30000)
        except Exception:pass
        self._renderNavFocus()
        self.load()

    def _renderNavFocus(self):
        try:
            y=self.NAV_Y[self.navIndex]
            self["sideSelector"].instance.move(ePoint(sx(15),sy(y)))
            self["sideSelector"].show()
        except Exception:
            pass
        # Same text color everywhere; the moving gold glass bar is the only focus.
        for i in range(6):
            try:
                self["nav%d"%i].instance.setForegroundColor(parseColor("#FFFFFF" if i==self.navIndex and self.focusMode=="nav" else "#E8E8E8"))
            except Exception:
                pass

    def _openNavItem(self):
        if self.navIndex==0:
            self.session.open(MediaScreen,self.source,"live"); return
        if self.navIndex==1:
            self.session.open(ContentHomeScreen,self.source,"vod"); return
        if self.navIndex==2:
            self.session.open(ContentHomeScreen,self.source,"series"); return
        if self.navIndex==3:
            self.focusMode="packages"
            self._renderNavFocus()
            self.render()
            return
        if self.navIndex==4:
            self.session.open(FavoritesScreen); return
        if self.navIndex==5:
            self.session.open(SettingsDashboard); return

    def left(self):
        self.focusMode="nav"
        self._renderNavFocus()

    def right(self):
        self.focusMode="packages"
        self._renderNavFocus()
        self.render()

    def updateClock(self):
        now=datetime.now()
        try:self["clock"].setText(now.strftime("%I:%M %p").lstrip("0"))
        except Exception:pass
        try:self["date"].setText(now.strftime("%A, %d %b %Y"))
        except Exception:pass

    def _brandLogo(self,name):
        # r284: only resolve lightweight package assets. Do not fall back to the
        # old server/filter television icons; unknown collections use the new
        # Movies / TV Shows collection mark instead. Resolution is cached.
        cache_key=(self.kind,str(name or ""))
        if cache_key in self._logoPathCache:
            return self._logoPathCache.get(cache_key) or None
        branded = package_logo_path(name)
        if not branded:
            branded = package_logo_for_key("movies" if self.kind == "vod" else "series")
        if branded and not os.path.exists(branded):
            branded=None
        self._logoPathCache[cache_key]=branded or ""
        return branded

    def _rowLogo(self,row):
        try:
            name,cid=row[0],str(row[1] or "")
        except Exception:
            return None
        if cid == "__recent_added__":
            return package_logo_for_key("recent_movies" if self.kind == "vod" else "recent_series")
        if cid == "__netflix__":
            return package_logo_for_key("netflix")
        if cid == "__prime_video__":
            return package_logo_for_key("prime")
        return self._brandLogo(name)

    def _queueVisibleLogos(self,delay=180):
        # Text/cards are already visible when this starts. Only visible slots are
        # decoded, then further slots are handled after navigation.
        q=[]
        for slot in range(6):
            pos=self.pageStart+slot
            if 0 <= pos < len(self.rows):
                q.append((slot,pos))
        self._logoQueue=q
        try:
            self._logoTimer.stop()
        except Exception:
            pass
        if q:
            try:self._logoTimer.start(int(delay),True)
            except Exception:pass

    def _loadNextVisibleLogo(self):
        if not self._logoQueue:
            return
        slot,pos=self._logoQueue.pop(0)
        try:
            if pos < 0 or pos >= len(self.rows) or pos != self.pageStart+slot:
                raise ValueError("stale logo slot")
            row=self.rows[pos]
            path=self._rowLogo(row)
            state=(str(row[1] or ""),path or "")
            if self._slotLogoState.get(slot) != state:
                if path:
                    self["logo%d"%slot].instance.setPixmapFromFile(path)
                    self["logo%d"%slot].show()
                else:
                    self["logo%d"%slot].hide()
                self._slotLogoState[slot]=state
        except Exception:
            try:self["logo%d"%slot].hide()
            except Exception:pass
        if self._logoQueue:
            try:self._logoTimer.start(55,True)
            except Exception:pass

    def load(self):
        self._loadToken+=1
        token=self._loadToken
        source=dict(self.source)
        kind=self.kind
        self._loadResult=None
        def worker():
            try:
                cats,origin=get_cached_categories(source,kind,get_source_client(source),wait_for_server=True)
                cats=filter_categories(source,kind,cats or [])
                rows=[(
                    "RECENT ADDED",
                    "__recent_added__",
                    "",
                    "LATEST " + ("MOVIES" if kind=="vod" else "SERIES"),
                    10**18,
                    -1
                )]
                appearance=_load_home_appearance()

                def _provider_score(_name,_provider):
                    _text=str(_name or "").strip().lower()
                    _compact=re.sub(r"[^a-z0-9]+"," ",_text).strip()
                    _tokens=[_x for _x in _compact.split() if _x]
                    _resolved=package_provider_key(_name)

                    _base=-1
                    if _provider=="netflix":
                        if "netflix" in _compact:_base=700
                        elif _resolved=="netflix":_base=660
                        elif "nf" in _tokens:_base=620
                    elif _provider=="prime":
                        if "prime video" in _compact:_base=700
                        elif "amazon prime" in _compact:_base=680
                        elif _resolved=="prime":_base=660
                        elif "prime" in _tokens or "amz" in _tokens or "amzn" in _tokens:_base=620

                    if _base<0:
                        return -1

                    _movie_tokens=("movie","movies","film","films","vod","cinema")
                    _series_tokens=("series","tv","show","shows","serial")
                    _has_movie=any(_x in _tokens for _x in _movie_tokens)
                    _has_series=any(_x in _tokens for _x in _series_tokens)

                    if kind=="vod":
                        if _has_movie:_base+=140
                        if _has_series:_base-=220
                    elif kind=="series":
                        if _has_series:_base+=140
                        if _has_movie:_base-=220
                    return _base

                def _best_real_provider(_provider):
                    _client=get_source_client(source)
                    _best=None
                    for _cat in cats:
                        _name=str((_cat or {}).get("category_name") or "")
                        _cid=str((_cat or {}).get("category_id") or "")
                        _score=_provider_score(_name,_provider)
                        if _score<0 or not _cid:
                            continue
                        try:
                            _items,_o=get_category_streams(
                                source,kind,_client,_cid,
                                use_cache=True,wait_for_server=True
                            )
                            _count=len(_items or [])
                        except Exception:
                            _count=0
                        if _count<=0:
                            continue
                        # Correct provider/section match first.
                        # Count is only a tie-breaker.
                        _candidate=(_score,_count,_cid,_name)
                        if _best is None or _candidate[:2] > _best[:2]:
                            _best=_candidate
                    return _best

                _netflix_target=_best_real_provider("netflix") if appearance.get("show_netflix_package") else None
                _prime_target=_best_real_provider("prime") if appearance.get("show_prime_package") else None

                if appearance.get("show_netflix_package"):
                    rows.append((
                        "NETFLIX",
                        "__netflix__",
                        "",
                        "SERVER • TMDB ORDER" if _netflix_target else "NOT FOUND",
                        10**17,
                        -2,
                        (_netflix_target[2] if _netflix_target else ""),
                        (_netflix_target[3] if _netflix_target else "NETFLIX")
                    ))
                if appearance.get("show_prime_package"):
                    rows.append((
                        "PRIME VIDEO",
                        "__prime_video__",
                        "",
                        "SERVER • TMDB ORDER" if _prime_target else "NOT FOUND",
                        10**16,
                        -3,
                        (_prime_target[2] if _prime_target else ""),
                        (_prime_target[3] if _prime_target else "PRIME VIDEO")
                    ))
                for order,x in enumerate(cats):
                    name=x.get("category_name") or "Other"
                    cid=str(x.get("category_id") or "")
                    raw=x.get("count") or x.get("num") or x.get("total") or x.get("items_count") or ""
                    meta=(str(raw)+" "+("MOVIES" if kind=="vod" else "SHOWS")) if raw not in ("",None) else ""
                    # Numeric category IDs normally increase as providers add new groups.
                    # Keep the original provider order as a fallback for non-numeric IDs.
                    try: newest_key=int(cid)
                    except Exception: newest_key=-1
                    # r284: do not decode or even resolve row logos while the
                    # package catalogue is being built. Text opens first.
                    rows.append((name,cid,"",meta,newest_key,order))
                self._loadResult=(token,rows,"")
            except Exception as exc:
                self._loadResult=(token,[],str(exc))
        t=threading.Thread(target=worker,name="TiviMatePackagesCards")
        t.daemon=True
        t.start()
        try:self._loadTimer.start(100,False)
        except Exception:pass

    def _finishLoad(self):
        result=self._loadResult
        if not result:
            try:self._loadTimer.start(100,False)
            except Exception:pass
            return
        self._loadResult=None
        token,rows,error=result
        if token!=self._loadToken:return
        if error:
            self.rows=[]
            self["count"].setText("0 PACKAGES")
            self["row0"].setText("Unable to load packages")
            return
        self.rows=rows or []
        self._applyPackageSort(reset=True)
        self["count"].setText("%d PACKAGE%s"%(len(self.rows),"" if len(self.rows)==1 else "S"))
        self.render()

    def _applyPackageSort(self, reset=False):
        pin_order={"__recent_added__":0, "__netflix__":1, "__prime_video__":2}
        pinned = [row for row in self.rows if str(row[1]) in pin_order]
        pinned.sort(key=lambda row: pin_order.get(str(row[1]), 99))
        normal = [row for row in self.rows if str(row[1]) not in pin_order]
        if self.sortMode=="az":
            normal.sort(key=lambda row: str(row[0] or "").casefold())
            self["sort"].setText("A-Z")
        else:
            # Latest first: higher numeric category IDs first. When a provider
            # uses non-numeric IDs, newly appended provider rows are shown first.
            normal.sort(key=lambda row: (row[4] if row[4] >= 0 else row[5]), reverse=True)
            self["sort"].setText("LATEST")
        self.rows = pinned + normal
        if reset:
            self.index=0
            self.pageStart=0

    def togglePackageSort(self):
        self.sortMode="az" if self.sortMode=="latest" else "latest"
        self._applyPackageSort(reset=True)
        self.render()

    def render(self):
        if self.rows:
            if self.index<self.pageStart:self.pageStart=self.index
            if self.index>=self.pageStart+6:self.pageStart=self.index-5
        for slot in range(6):
            pos=self.pageStart+slot
            row=self.rows[pos] if 0<=pos<len(self.rows) else None
            if row:
                name,cid,logo,meta=row[:4]
                self["row%d"%slot].setText(name)
                self["meta%d"%slot].setText(meta or ("MOVIES" if self.kind=="vod" else "SERIES"))
                if cid=="__netflix__":
                    self["desc%d"%slot].setText("Netflix Collection")
                elif cid=="__prime_video__":
                    self["desc%d"%slot].setText("Prime Video Collection")
                else:
                    self["desc%d"%slot].setText("Movies Collection" if self.kind=="vod" else "Series Collection")
                # r284: never make the initial card paint wait on PNG decode.
                # Keep an already-cached logo only if this exact row still owns
                # the slot; otherwise paint text first and defer the logo.
                expected=(str(cid or ""),)
                state=self._slotLogoState.get(slot)
                if not state or state[:1] != expected:
                    self["logo%d"%slot].hide()
            else:
                self["row%d"%slot].setText("")
                self["meta%d"%slot].setText("")
                self["desc%d"%slot].setText("")
                self["logo%d"%slot].hide()
        # Keep every non-selected package quiet and readable.  The focused row
        # gets a local dark glass strip, slightly larger title and brighter meta.
        for slot in range(6):
            try:
                self["row%d"%slot].instance.setFont(gFont("Regular",27))
                self["row%d"%slot].instance.setForegroundColor(parseColor("#F0F0F0"))
                self["desc%d"%slot].instance.setForegroundColor(parseColor("#C8BFD2"))
                self["meta%d"%slot].instance.setForegroundColor(parseColor("#D7D0E1"))
            except Exception:
                pass
        if self.rows and self.focusMode=="packages":
            slot=self.index-self.pageStart
            try:
                self["packageSelector"].instance.move(ePoint(sx(475),sy(self.CARD_ROW_Y[slot])))
            except Exception:pass
            try:
                self["packageTextFocusBg"].instance.move(ePoint(sx(655),sy(self.CARD_ROW_Y[slot]+7)))
                self["packageTextFocusBg"].show()
            except Exception:pass
            try:
                self["row%d"%slot].instance.setFont(gFont("Regular",31))
                self["row%d"%slot].instance.setForegroundColor(parseColor("#FFFFFF"))
                self["desc%d"%slot].instance.setForegroundColor(parseColor("#FFFFFF"))
                self["meta%d"%slot].instance.setForegroundColor(parseColor("#FFFFFF"))
            except Exception:
                pass
            self["packageSelector"].show()
        else:
            self["packageSelector"].hide()
            try:self["packageTextFocusBg"].hide()
            except Exception:pass
        self._queueVisibleLogos(180)

    def up(self):
        if self.focusMode=="nav":
            self.navIndex=(self.navIndex-1)%6
            self._renderNavFocus()
            return
        if not self.rows:return
        self.index=(self.index-1)%len(self.rows)
        self.render()

    def down(self):
        if self.focusMode=="nav":
            self.navIndex=(self.navIndex+1)%6
            self._renderNavFocus()
            return
        if not self.rows:return
        self.index=(self.index+1)%len(self.rows)
        self.render()

    def pageUp(self):
        if self.focusMode=="nav":return
        if not self.rows:return
        self.index=max(0,self.index-6)
        self.render()

    def pageDown(self):
        if self.focusMode=="nav":return
        if not self.rows:return
        self.index=min(len(self.rows)-1,self.index+6)
        self.render()

    def choose(self):
        if self.focusMode=="nav":
            self._openNavItem()
            return
        if not self.rows:return
        row=self.rows[self.index]
        name,cid,logo,meta=row[:4]
        result={"name":name,"id":cid,"_source":dict(self.source)}
        if cid in ("__netflix__","__prime_video__"):
            result["target_id"]=str(row[6] or "") if len(row)>6 else ""
            result["target_name"]=str(row[7] or name) if len(row)>7 else name
        if cid:
            # Keep the package browser underneath the content screen so BACK
            # from a package returns directly to this package list.
            try:
                target_id = str(result.get("target_id") or cid)
                target_name = result.get("target_name") or name
                self.session.open(MediaScreen, dict(self.source), self.kind, target_id, target_name)
            except Exception:
                self.close(result)

    def openPackageFilter(self):
        # GREEN filters the currently open package kind for THIS server.
        # Movies -> VOD categories, TV Shows -> Series categories.
        stype = str((self.source or {}).get("type") or "").lower()
        if stype not in ("xtream", "stalker"):
            label = "Movie" if self.kind == "vod" else "TV Shows"
            self.session.open(MessageBox, "%s package filtering is available for Xtream Codes and Stalker Portal." % label, MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(
            self._packageFilterClosed,
            ServerCategoryFilter,
            dict(self.source),
            self.kind,
            True
        )

    # Compatibility alias for older callers.
    def openMoviePackageFilter(self):
        return self.openPackageFilter()

    def _packageFilterClosed(self, changed=None):
        # Reload the visible package list after saving; filter data itself is
        # persisted per-server by ServerCategoryFilter / filters.py.
        try:
            clear_catalog_memory()
        except Exception:
            pass
        self.rows=[]
        self.index=0
        self.pageStart=0
        try:self["count"].setText("LOADING")
        except Exception:pass
        self.load()

    def _moviePackageFilterClosed(self, changed=None):
        return self._packageFilterClosed(changed)

    def _serverChoices(self):
        rows=[]
        current_key=_source_identity(self.source)
        for source in list(get_sources() or []):
            if not isinstance(source,dict):
                continue
            # Package browsing is meaningful for providers with VOD/Series APIs.
            stype=str(source.get("type") or "").lower()
            if stype not in ("xtream","stalker"):
                continue
            name=str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            kind="Xtream" if stype=="xtream" else "Stalker"
            prefix="✓ " if _source_identity(source)==current_key else ""
            rows.append(("%s%s  [%s]"%(prefix,name,kind),dict(source)))
        return rows

    def serverSwitch(self):
        choices=self._serverChoices()
        if not choices:
            self.session.open(MessageBox,"No compatible IPTV servers found.",MessageBox.TYPE_INFO,timeout=3)
            return
        self.session.openWithCallback(
            self._serverSwitchSelected,
            ChoiceBox,
            title="SERVER SWITCH",
            list=choices
        )

    def _serverSwitchSelected(self,choice=None):
        if not choice:
            return
        try:
            source=choice[1]
        except Exception:
            return
        if not isinstance(source,dict):
            return
        self.source=dict(source)
        try:
            save_json(MAIN_SOURCE_FILE,{"key":_source_identity(self.source)})
        except Exception:
            pass
        self.rows=[]
        self.index=0
        self.pageStart=0
        self["count"].setText("LOADING")
        for slot in range(6):
            self["row%d"%slot].setText("")
            self["meta%d"%slot].setText("")
            self["desc%d"%slot].setText("")
            try:self["logo%d"%slot].hide()
            except Exception:pass
        self.load()

    def showInfo(self):
        if not self.rows:return
        name,cid,logo,meta=self.rows[self.index][:4]
        self.session.open(MessageBox,name,MessageBox.TYPE_INFO,timeout=3)


PACKAGE_SELECTOR_SKIN = r"""<screen name="ContentPackagesScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages_selector_fullscreen.png" alphatest="blend" scale="1" zPosition="0"/>
<eLabel position="0,135" size="390,610" backgroundColor="#050608" zPosition="2"/>
<widget name="navFocus" position="0,174" size="360,72" alphatest="blend" zPosition="4"/>
<widget name="nav0" position="78,183" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="nav1" position="78,268" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="nav2" position="78,353" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="nav3" position="78,438" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="nav4" position="78,523" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="nav5" position="78,608" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="cardFocus" position="520,320" size="470,545" alphatest="blend" zPosition="6"/>

<!-- Real package clock: generated hands update from receiver local time. -->
<widget name="packageClockFace" position="1578,18" size="116,116" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/package_clock_r108/face.png" alphatest="blend" zPosition="8"/>
<widget name="packageClockHour" position="1578,18" size="116,116" alphatest="blend" zPosition="9"/>
<widget name="packageClockMinute" position="1578,18" size="116,116" alphatest="blend" zPosition="10"/>
<widget name="packageDate" position="1712,42" size="190,64" font="Regular;20" foregroundColor="#F4F4F0" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="10"/>
</screen>"""

class ContentPackagesScreen(Screen):
    skin = PACKAGE_SELECTOR_SKIN
    NAV_Y = [174,259,344,429,514,599]
    CARD_X = [520,1010]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source=dict(source or {})
        self.choice=0
        self.navIndex=3
        self.mode="cards"
        self["navFocus"]=Pixmap(); self["cardFocus"]=Pixmap()
        self["packageClockFace"]=Pixmap()
        self["packageClockHour"]=Pixmap()
        self["packageClockMinute"]=Pixmap()
        self["packageDate"]=Label("")
        for i,name in enumerate(["LIVE TV","MOVIES","TV SHOWS","PACKAGES","FAVORITES","SETTINGS"]): self["nav%d"%i]=Label(name)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "left":self.left,"right":self.right,"up":self.up,"down":self.down,"ok":self.ok,"cancel":self.close,"red":self.close
        },-1)
        self._packageClockTimer=eTimer()
        _connect_timer(self._packageClockTimer,self._updatePackageClock)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._stopPackageClock)

    def _ready(self):
        try:self["navFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages_nav_focus_r52.png"))
        except Exception:pass
        try:self["cardFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages_card_focus_r52.png"))
        except Exception:pass
        self._updatePackageClock()
        try:self._packageClockTimer.start(30000, False)
        except Exception:pass
        self._renderFocus()

    def _stopPackageClock(self):
        try:self._packageClockTimer.stop()
        except Exception:pass

    def _updatePackageClock(self):
        now=datetime.now()
        minute=int(now.minute)
        hour=int(now.hour)%12
        # Hour hand advances every five minutes, not only once per hour.
        hour_slot=(hour*12 + int(minute/5)) % 144
        clock_root=os.path.join(PLUGIN_PATH,"skins","package_clock_r108")
        try:
            self["packageClockHour"].instance.setPixmapFromFile(
                os.path.join(clock_root,"h%03d.png"%hour_slot)
            )
        except Exception:pass
        try:
            self["packageClockMinute"].instance.setPixmapFromFile(
                os.path.join(clock_root,"m%02d.png"%minute)
            )
        except Exception:pass
        try:
            self["packageDate"].setText(now.strftime("%A\n%d %b %Y"))
        except Exception:pass

    def _renderFocus(self):
        try:self["navFocus"].instance.move(ePoint(sx(0),sy(self.NAV_Y[self.navIndex])))
        except Exception:pass
        if self.mode=="cards":
            self["cardFocus"].show()
            try:self["cardFocus"].instance.move(ePoint(sx(self.CARD_X[self.choice]),sy(320)))
            except Exception:pass
        else:self["cardFocus"].hide()

    def up(self):
        self.mode="nav"; self.navIndex=(self.navIndex-1)%6; self._renderFocus()
    def down(self):
        self.mode="nav"; self.navIndex=(self.navIndex+1)%6; self._renderFocus()
    def left(self):
        if self.mode=="cards": self.choice=0
        else: self.mode="cards"; self.choice=0
        self._renderFocus()
    def right(self):
        if self.mode=="cards": self.choice=1
        else: self.mode="cards"; self.choice=1
        self._renderFocus()

    def ok(self):
        if self.mode=="nav":
            if self.navIndex==0:self.session.open(MediaScreen,self.source,"live"); return
            if self.navIndex==1:self.session.open(ContentHomeScreen,self.source,"vod"); return
            if self.navIndex==2:self.session.open(ContentHomeScreen,self.source,"series"); return
            if self.navIndex==3:self.mode="cards"; self._renderFocus(); return
            if self.navIndex==4:self.session.open(FavoritesScreen); return
            if self.navIndex==5:self.session.open(SettingsDashboard); return
        kind="vod" if self.choice==0 else "series"
        self._homePackageKind=kind
        try:
            self.source=dict(_load_main_source(self.source) or self.source)
        except Exception:
            pass
        self.session.openWithCallback(self._homePackageBrowserClosed,HomePackageBrowserScreen,self.source,kind)

    def _homePackageBrowserClosed(self, selected=None, *args):
        self._packageSelected(getattr(self,"_homePackageKind","vod"),selected)
    def _packageSelected(self,kind,selected=None):
        if not selected or not isinstance(selected,dict):return
        selected_source=selected.get("_source")
        if isinstance(selected_source,dict):
            self.source=dict(selected_source)
        cid=str(selected.get("id") or ""); name=selected.get("name") or ""
        if cid in ("__netflix__","__prime_video__"):
            target_id=str(selected.get("target_id") or "")
            target_name=str(selected.get("target_name") or name)
            if not target_id:
                self.session.open(
                    MessageBox,
                    "%s package with content was not found on this server." % name,
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
                return
            provider="netflix" if cid=="__netflix__" else "prime"
            routed_source=dict(self.source or {})
            routed_source["_package_provider_override"]=provider
            routed_source["_package_provider_category_id"]=target_id
            self.session.open(MediaScreen,routed_source,kind,target_id,target_name)
            return
        if cid=="__recent_added__":
            self.session.open(MediaScreen,self.source,kind,cid,name)
            return
        if cid:self.session.open(MediaScreen,self.source,kind,cid,name)



class ImageCacheSettings(Screen, ConfigListScreen):
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="ImageCacheSettings"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_cache_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = get_cache_settings()
        self["title"] = Label(tr("IMAGE CACHE"))
        self["hint"] = Label("")
        self["keys"] = Label(tr("GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK"))
        self.location = ConfigSelection(default=str(cfg.get("location", "auto")), choices=[
            ("auto", "Auto: HDD, then USB"),
            ("hdd", "HDD /media/hdd"),
            ("usb", "USB /media/usb"),
            ("mmc", "MMC /media/mmc"),
            ("internal", "Internal Enigma2 /etc/enigma2"),
            ("tmp", "Temporary /tmp"),
        ])
        self.retention = ConfigSelection(default=str(cfg.get("retention_days", 0)), choices=[
            ("0", "Unlimited — Never delete automatically"),
            ("7", "7 days"), ("14", "14 days"), ("30", "30 days"),
            ("60", "60 days"), ("90", "90 days")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Cache Location"), self.location),
            getConfigListEntry(tr("Automatic Deletion"), self.retention),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "blue": self.clearNow, "yellow": self.cleanNow,
            "red": self.close, "cancel": self.close
        }, -1)
        self.onLayoutFinish.append(self.updateHint)

    def updateHint(self):
        root, size, files = cache_status()
        self["hint"].setText("Current location: %s  •  %.1f MB  •  %d files" % (root, size / 1048576.0, files))

    def save(self):
        if save_cache_settings(self.location.value, 0, int(self.retention.value)):
            cleanup_cache()
            self.updateHint()
            self.session.open(MessageBox, "Cache settings saved. New images will use the selected location.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save cache settings.", MessageBox.TYPE_ERROR)

    def clearNow(self):
        if clear_cache():
            try:
                clear_catalog_memory()
            except Exception:
                pass
            self.updateHint()
            self.session.open(MessageBox, "Image and list cache cleared.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to clear image cache.", MessageBox.TYPE_ERROR)

    def cleanNow(self):
        cleanup_cache()
        self.updateHint()
        self.session.open(MessageBox, "Image cache cleaned according to the selected number of days. Unlimited keeps all files.", MessageBox.TYPE_INFO)


POSTER_SETTINGS_R199_SKIN = r'''<screen name="HomeAppearanceSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#030811">
 <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_settings_cards_r199.jpg" alphatest="blend" zPosition="0"/>
 <widget name="focus" position="55,300" size="410,550" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r199.png" alphatest="blend" zPosition="8"/>
 <widget name="title0" position="85,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="title1" position="530,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="title2" position="975,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="title3" position="1420,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="desc0" position="92,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="desc1" position="537,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="desc2" position="982,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="desc3" position="1427,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="value0" position="88,765" size="344,44" font="Regular;25" foregroundColor="#1FA8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="value1" position="533,765" size="344,44" font="Regular;25" foregroundColor="#A847F5" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="value2" position="978,765" size="344,44" font="Regular;25" foregroundColor="#00D2CC" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="value3" position="1423,765" size="344,44" font="Regular;25" foregroundColor="#FF6B2D" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="hint" position="510,1012" size="900,30" font="Regular;19" foregroundColor="#8795A3" transparent="1" halign="center" zPosition="5"/>
</screen>'''

class HomeAppearanceSettings(Screen):
    skin = POSTER_SETTINGS_R199_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        current = _load_home_appearance()
        tmdb = load_tmdb_settings()
        self.index = 0
        self.skinChoices = [("reference_home", "Skin 1 — Reference"),("skin2_dark", "Skin 2 — Default")]
        self.contentChoices = [("popular_movies", "Popular Movies"),("popular_series", "Popular TV Shows"),("trending_movies", "Movies You Might Like"),("trending_series", "TV Shows You Might Like")]
        self.backdropChoices = [("w1280", "1280px (Default)"),("w1920", "1920px"),("original", "Original")]
        self.displayChoices = [("none", "Default"),("netflix", "Netflix"),("prime", "Prime Video"),("both", "Netflix + Prime")]
        self.homeSkin = current.get("skin", "skin2_dark")
        self.homeContent = current.get("content", "popular_movies")
        self.backdropQuality = tmdb.get("backdrop_quality", "w1280")
        nf = bool(current.get("show_netflix_package", False)); pr = bool(current.get("show_prime_package", False))
        self.displayMode = "both" if nf and pr else ("netflix" if nf else ("prime" if pr else "none"))
        self["focus"] = Pixmap()
        self["title0"] = Label("SKIN STYLE"); self["title1"] = Label("HOME CONTENT"); self["title2"] = Label("BACKDROP QUALITY"); self["title3"] = Label("DISPLAY OPTIONS")
        self["desc0"] = Label("Choose your preferred\nskin style")
        self["desc1"] = Label("Choose the content shown\non Home")
        self["desc2"] = Label("Choose backdrop\nquality level")
        self["desc3"] = Label("Show optional provider\npackages")
        for i in range(4): self["value%d"%i] = Label("")
        self["hint"] = Label("UP / DOWN  CARD     LEFT / RIGHT  CHANGE     OK  SAVE     BACK  CANCEL")
        self["actions"] = ActionMap(["OkCancelActions","DirectionActions","ColorActions"], {"up": self.prevCard, "down": self.nextCard, "left": self.prevValue, "right": self.nextValue, "ok": self.save, "green": self.save, "cancel": self.close, "red": self.close}, -1)
        self.onLayoutFinish.append(self._refresh)

    def _pairs(self):
        return [(self.skinChoices,"homeSkin"),(self.contentChoices,"homeContent"),(self.backdropChoices,"backdropQuality"),(self.displayChoices,"displayMode")]
    def _label(self, choices, value):
        for k,v in choices:
            if k == value: return v
        return choices[0][1]
    def _refresh(self):
        xs=[55,500,945,1390]
        try:self["focus"].instance.move(ePoint(sx(xs[self.index]),sy(300)))
        except Exception:pass
        self["value0"].setText("‹  %s  ›" % self._label(self.skinChoices,self.homeSkin))
        self["value1"].setText("‹  %s  ›" % self._label(self.contentChoices,self.homeContent))
        self["value2"].setText("‹  %s  ›" % self._label(self.backdropChoices,self.backdropQuality))
        self["value3"].setText("‹  %s  ›" % self._label(self.displayChoices,self.displayMode))
    def prevCard(self): self.index=(self.index-1)%4; self._refresh()
    def nextCard(self): self.index=(self.index+1)%4; self._refresh()
    def _step(self, delta):
        choices, attr = self._pairs()[self.index]; cur=getattr(self,attr); keys=[x[0] for x in choices]
        try:i=keys.index(cur)
        except Exception:i=0
        setattr(self,attr,keys[(i+delta)%len(keys)]); self._refresh()
    def prevValue(self): self._step(-1)
    def nextValue(self): self._step(1)
    def save(self):
        nf=self.displayMode in ("netflix","both"); pr=self.displayMode in ("prime","both")
        ok1=_save_home_appearance(self.homeSkin,self.homeContent,"none","none",nf,pr)
        cfg=load_tmdb_settings()
        ok2=save_tmdb_settings(cfg.get("api_key",""), cfg.get("language_setting",cfg.get("language","auto")), cfg.get("mode","auto"), cfg.get("access_token",""), cfg.get("api_key2",""), self.backdropQuality)
        if ok1 and ok2: self.session.open(MessageBox,"Skin & Poster settings saved.",MessageBox.TYPE_INFO)
        else: self.session.open(MessageBox,"Unable to save one or more appearance settings.",MessageBox.TYPE_ERROR)


class UpdateSettingsScreen(Screen, ConfigListScreen):
    """Settings and user-confirmed manual update flow for verified packages."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="UpdateSettingsScreen"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = _load_update_settings()
        self.autoCheck = ConfigSelection(default="on" if cfg.get("auto_check", True) else "off", choices=[
            ("on", "On"), ("off", "Off")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Automatic update check"), self.autoCheck)
        ], session=session)
        self["title"] = Label(tr("SOFTWARE UPDATES"))
        self["hint"] = Label(tr("Automatic checks only read a small verified update manifest. Press YELLOW to check now."))
        self["keys"] = Label(tr("GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "yellow": self.manualCheck, "ok": self.save,
            "red": self.close, "cancel": self.close
        }, -1)
        self._checkPending = None
        self._downloadPending = None
        self._candidate = None
        self._installProcess = None
        self._checkInProgress = False
        self._downloadInProgress = False
        self._checkTimer = eTimer()
        self._downloadTimer = eTimer()
        _connect_timer(self._checkTimer, self._pollCheck)
        _connect_timer(self._downloadTimer, self._pollDownload)
        self.onClose.append(self._stopTimers)

    def _stopTimers(self):
        for timer in (getattr(self, "_checkTimer", None), getattr(self, "_downloadTimer", None)):
            try:
                timer.stop()
            except Exception:
                pass

    def save(self):
        enabled = self.autoCheck.value == "on"
        if _save_update_settings(enabled):
            state = "enabled" if enabled else "disabled"
            self["hint"].setText("Automatic update checks are %s. Press YELLOW to check now." % state)
            self.session.open(MessageBox, "Update settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save update settings.", MessageBox.TYPE_ERROR)

    def manualCheck(self):
        if self._checkInProgress or self._downloadInProgress or self._installProcess:
            return
        self._checkInProgress = True
        self._checkPending = None
        self["hint"].setText(tr("Checking for a verified update..."))

        def worker():
            try:
                self._checkPending = check_for_update()
            except Exception:
                self._checkPending = {}

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateCheck")
            thread.daemon = True
            thread.start()
            self._checkTimer.start(200, True)
        except Exception:
            self._checkPending = {}
            self._pollCheck()

    def _pollCheck(self):
        if self._checkPending is None:
            try:
                self._checkTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._checkPending or {}
        self._checkPending = None
        self._checkInProgress = False
        if not result.get("available"):
            if result.get("reason") == "current":
                self["hint"].setText(tr("TiViMate E2 is already up to date."))
                self.session.open(MessageBox, "No update is available. TiViMate E2 is already up to date.", MessageBox.TYPE_INFO)
            else:
                self["hint"].setText(tr("Unable to verify updates right now. You can try again later."))
                self.session.open(MessageBox, "Unable to check for updates. Please try again later.", MessageBox.TYPE_ERROR)
            return
        self._candidate = result
        version = result.get("version") or "1.0.3"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A verified TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        self.session.openWithCallback(self._confirmUpdate, MessageBox, text, type=MessageBox.TYPE_YESNO, default=False)

    def _confirmUpdate(self, answer):
        if not answer or not self._candidate:
            return
        package = self._candidate.get("package")
        if not package:
            return
        self._downloadInProgress = True
        self._downloadPending = None
        self["hint"].setText(tr("Downloading and verifying the update package..."))

        def worker():
            self._downloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateDownload")
            thread.daemon = True
            thread.start()
            self._downloadTimer.start(200, True)
        except Exception:
            self._downloadPending = {"ok": False, "message": "Unable to start download"}
            self._pollDownload()

    def _pollDownload(self):
        if self._downloadPending is None:
            try:
                self._downloadTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._downloadPending or {}
        self._downloadPending = None
        self._downloadInProgress = False
        if not result.get("ok"):
            self["hint"].setText(tr("Update download failed."))
            self.session.open(MessageBox, "Update download failed.\n\n%s" % (result.get("message") or "Please try again later."), MessageBox.TYPE_ERROR); return
        command = install_command(result)
        if not command:
            self["hint"].setText(tr("The verified package could not be installed."))
            self.session.open(MessageBox, "The verified update package could not be installed.", MessageBox.TYPE_ERROR); return
        self["hint"].setText(tr("Installing TiViMate E2 update..."))
        try:
            process = eConsoleAppContainer()
            self._installProcess = process
            try:
                process.appClosed.append(self._installFinished)
            except Exception:
                process.appClosed.get().append(self._installFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            self["hint"].setText(tr("Unable to start the update installer."))
            self.session.open(MessageBox, "Unable to start the update installer.", MessageBox.TYPE_ERROR)

    def _installFinished(self, status):
        self._installProcess = None
        if status == 0:
            self["hint"].setText(tr("Update completed. Restart the Enigma2 GUI to use the new version."))
            self.session.open(MessageBox, "TiViMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.", MessageBox.TYPE_INFO)
        else:
            self["hint"].setText(tr("The update installer returned an error."))
            self.session.open(MessageBox, "The update installer returned an error. Your current installation has not been changed.", MessageBox.TYPE_ERROR)


class SubDLSubtitleLanguageSettings(Screen, ConfigListScreen):
    """Preferred subtitle language for server tracks, SubsSupport fallback and SubDL."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="SubDLSubtitleLanguageSettings"').replace(
        'settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png'
    )

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        current = load_subdl_settings()
        self.targetLanguage = ConfigSelection(
            default=current.get("language", "ar"),
            choices=SUBDL_LANGUAGE_CHOICES,
        )
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Preferred Subtitle Language"), self.targetLanguage),
        ], session=session)
        self["title"] = Label(tr("SUBTITLE LANGUAGE"))
        self["hint"] = Label(tr(
            "This language is used for automatic server subtitles first, then SubsSupport fallback, and for manual SubDL searches."
        ))
        self["keys"] = Label(tr("GREEN  SAVE    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close,
        }, -1)

    def save(self):
        try:
            current = load_subdl_settings()
            save_subdl_settings(
                current.get("api_key", ""),
                self.targetLanguage.value,
                current.get("kind", "standard"),
            )
            _sync_native_subtitle_language(self.targetLanguage.value)
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save the SubDL subtitle language.", MessageBox.TYPE_ERROR, timeout=5)


WEB_ACCESS_SKIN = scale_skin(r'''<screen name="TiviMateE2WebAccess" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_web_blue_r28.png" alphatest="blend" zPosition="0" />
    <ePixmap position="72,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="title" position="500,126" size="1320,58" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="subtitle" position="500,188" size="1320,34" font="Regular;22" foregroundColor="#56E5FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <ePixmap position="84,284" size="430,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/web_mobile_device_r67.png" alphatest="blend" zPosition="3" />
    <widget name="leftTitle" position="92,794" size="414,42" font="Regular;30" foregroundColor="#48E4FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="leftHint" position="82,838" size="434,62" font="Regular;20" foregroundColor="#E5F2FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <widget name="qrTitle" position="610,264" size="420,42" font="Regular;30" foregroundColor="#53E7FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <eLabel position="626,326" size="388,388" backgroundColor="#FFFFFF" zPosition="3" />
    <widget name="qr" position="654,354" size="332,332" alphatest="blend" zPosition="5" />
    <widget name="qrHint" position="620,742" size="400,68" font="Regular;20" foregroundColor="#DCEBFA" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <eLabel position="1160,305" size="22,22" backgroundColor="#24E882" zPosition="4" />
    <widget name="status" position="1195,288" size="560,48" font="Regular;31" foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="addressLabel" position="1195,358" size="560,32" font="Regular;22" foregroundColor="#57E1FF" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="url" position="1195,416" size="560,54" font="Regular;29" foregroundColor="#71E4FF" backgroundColor="#00000000" transparent="1" zPosition="5" valign="center" />
    <widget name="help" position="1195,522" size="560,230" font="Regular;24" foregroundColor="#E5F2FF" backgroundColor="#00000000" transparent="1" valign="top" zPosition="5" />
    <widget name="hint" position="1195,788" size="560,60" font="Regular;21" foregroundColor="#82DFFF" backgroundColor="#00000000" transparent="1" zPosition="5" halign="left" valign="center" />
    <widget name="footer" position="560,932" size="1270,48" font="Regular;22" foregroundColor="#C9D8E8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
</screen>''')

class WebAccessScreen(Screen):
    skin = WEB_ACCESS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label("WEB CONTROL  •  MOBILE ACCESS")
        self["subtitle"] = Label("Scan the QR code with your phone to open TiviMateE2 Web Manager")
        self["leftTitle"] = Label("Control your IPTV")
        self["leftHint"] = Label("Manage servers and playlists from your mobile phone or computer.")
        self["qrTitle"] = Label("SCAN QR CODE")
        self["qrHint"] = Label("Point your phone camera at the QR code")
        self["addressLabel"] = Label("Web Address")
        self["qr"] = Pixmap()
        self["status"] = Label("Web Server: STARTING")
        self["url"] = Label("")
        self["help"] = Label("Manage servers from your phone:\n• Add / edit Xtream\n• Add / edit Stalker + MAC\n• M3U playlists\n• IPTV Finder and maintenance")
        self["hint"] = Label("Phone and receiver must be on the same local network.")
        self["footer"] = Label("EXIT / BACK  •  Return to Settings")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close, "ok": self.close, "red": self.close,
            "green": self.refreshAccess
        }, -1)
        self._qrPath = "/tmp/tivimatee2/web_access_qr.png"
        self.onLayoutFinish.append(self.refreshAccess)

    def refreshAccess(self):
        try:
            from .web_manager import start_web_manager, web_manager_status
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get("ip") or "127.0.0.1")
            port = int(status.get("port") or 8088)
            running = bool(status.get("running"))
            url = "http://%s:%d" % (ip, port)
            self["status"].setText("Web Server: %s" % ("ON" if running else "OFF"))
            self["url"].setText(url)
            if running and ip not in ("127.0.0.1", "0.0.0.0"):
                from .web_qr import make_qr_png
                make_qr_png(url, self._qrPath, scale=9, border=4)
                try:
                    self["qr"].instance.setPixmap(LoadPixmap(self._qrPath))
                    self["qr"].show()
                except Exception:
                    pass
            else:
                self["hint"].setText("No LAN address detected. Connect the receiver to your network and press GREEN to refresh.")
        except Exception as error:
            self["status"].setText("Web Server: ERROR")
            self["url"].setText("")
            self["hint"].setText("Could not start Web Manager: %s" % error)



def _format_server_expiry(value):
    """Return a compact human-readable subscription expiry or em dash."""
    raw = str(value or "").strip()
    if not raw or raw.lower() in ("0", "none", "null", "false", "unknown", "n/a", "-"):
        return "—"
    if raw.lower() in ("unlimited", "never", "lifetime"):
        return "Unlimited"
    # Xtream normally returns Unix seconds.
    try:
        number = int(float(raw))
        if 946684800 <= number <= 4102444800:
            return datetime.fromtimestamp(number).strftime("%d/%m/%Y")
    except Exception:
        pass
    # Common Stalker / panel date formats.
    match = re.search(r"((?:19|20)\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", raw)
    if match:
        return "%02d/%02d/%04d" % (int(match.group(3)), int(match.group(2)), int(match.group(1)))
    match = re.search(r"(\d{1,2})[-/.](\d{1,2})[-/.]((?:19|20)\d{2})", raw)
    if match:
        return "%02d/%02d/%04d" % (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    return "—"

class ServerStatusList(MenuList):
    """MenuList that preserves source rows while drawing a local health dot.

    The source dictionary remains the first element of every row, so ServerManager
    keeps the same selection, scrolling, action-key and source-editing behaviour.
    """
    STATUS_PIXMAPS = {
        "online": os.path.join(PLUGIN_PATH, "skins/server_status_online_r123.png"),
        "busy": os.path.join(PLUGIN_PATH, "skins/server_status_busy_r123.png"),
        "checking": os.path.join(PLUGIN_PATH, "skins/server_status_checking_r123.png"),
        "offline": os.path.join(PLUGIN_PATH, "skins/server_status_offline_r123.png"),
    }
    TYPE_PIXMAPS = {
        "xtream": os.path.join(PLUGIN_PATH, "skins/web_xtream_icon.png"),
        "stalker": os.path.join(PLUGIN_PATH, "skins/web_stalker_icon.png"),
    }

    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 36))
            self.l.setItemHeight(88)
        except Exception:
            pass
        self._pixmaps = {}
        for name, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._pixmaps[name] = None
        self._type_pixmaps = {}
        for name, path in self.TYPE_PIXMAPS.items():
            try:
                self._type_pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._type_pixmaps[name] = None

    def setSources(self, sources, states, expiries=None):
        expiries = expiries or {}
        rows = [self._makeRow(
            source,
            states.get(self._key(source), "checking"),
            expiries.get(self._key(source), "")
        ) for source in sources]
        self.setList(rows)

    @staticmethod
    def _display_name(source):
        source = source or {}
        name = str(source.get("name") or "").strip()
        url = str(source.get("url") or source.get("portal") or "").strip()
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    @staticmethod
    def _key(source):
        endpoint = source.get("url") or source.get("host") or source.get("server") or source.get("portal") or ""
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("name", ""), endpoint, source.get("username", ""))

    def _makeRow(self, source, state, expiry=""):
        source = source or {}
        source_type = str(source.get("type") or "").lower()
        name = self._display_name(source)
        alias = str(source.get("mac_alias") or "").strip()
        if alias and alias.lower() not in name.lower():
            name = "%s • %s" % (name, alias)

        title = "%s  •  %s" % (name, source_type.upper() if source_type else "SERVER")
        expiry_text = "Expire: %s" % _format_server_expiry(expiry)
        status_pixmap = self._pixmaps.get(state) or self._pixmaps.get("checking")
        type_pixmap = self._type_pixmaps.get(source_type)

        row = [
            source,
            MultiContentEntryPixmapAlphaBlend(
                pos=(0, 8), size=(1000, 78),
                png=LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server_row_r67.png"))
            ),
        ]
        if type_pixmap is not None:
            row.append(MultiContentEntryPixmapAlphaBlend(
                pos=(22, 16), size=(56, 56), png=type_pixmap
            ))

        row.extend([
            MultiContentEntryText(
                pos=(100, 0), size=(590, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=title,
                color=0x00F5F8FC, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(700, 0), size=(300, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=expiry_text,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(1075, 28), size=(32, 32), png=status_pixmap
            ),
        ])
        return row



class LiveServerChoiceList(MenuList):
    STATUS_PIXMAPS = {
        "active": os.path.join(PLUGIN_PATH, "skins/estalker_led_green.png"),
        "unknown": os.path.join(PLUGIN_PATH, "skins/estalker_led_yellow.png"),
        "inactive": os.path.join(PLUGIN_PATH, "skins/estalker_led_red.png"),
        "blocked": os.path.join(PLUGIN_PATH, "skins/estalker_led_red.png"),
        "expired": os.path.join(PLUGIN_PATH, "skins/estalker_led_blue.png"),
        "unchecked": os.path.join(PLUGIN_PATH, "skins/estalker_led_grey.png"),
    }

    def __init__(self, rows=None):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 24))
            self.l.setItemHeight(78)
        except Exception:
            pass
        self._pixmaps = {}
        for state, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[state] = LoadPixmap(path)
            except Exception:
                self._pixmaps[state] = None
        try:
            self._type_pixmap_xtream = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/web_xtream_icon.png"))
        except Exception:
            self._type_pixmap_xtream = None
        try:
            self._type_pixmap_stalker = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/web_stalker_icon.png"))
        except Exception:
            self._type_pixmap_stalker = None
        self.setRows(rows or [])

    @staticmethod
    def _display_name(source):
        source = source or {}
        name = str(source.get("name") or "").strip()
        url = str(source.get("url") or source.get("portal") or "").strip()
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    @staticmethod
    def _format_estalker_expiry(value):
        raw = str(value or "").strip()
        if not raw:
            return ""
        if raw.lower() in ("unknown", "none", "null", "0", "-"):
            return "Unknown"
        if raw.lower() in ("unlimited", "never", "lifetime"):
            return "Unlimited"
        try:
            number = int(float(raw))
            # EStalker treats bare numeric expiry as unknown in its list.
            if number > 0:
                return "Unknown"
        except Exception:
            pass
        return raw

    @staticmethod
    def _parse_estalker_expiry(value):
        raw = str(value or "").strip()
        if not raw:
            return None
        for fmt in (
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d",
            "%d/%m/%Y", "%m/%d/%Y",
            "%B %d, %Y, %I:%M %p", "%B %d, %Y"
        ):
            try:
                return datetime.strptime(raw, fmt)
            except Exception:
                pass
        return None

    def _estalker_row_info(self, source):
        source = source or {}
        stype = str(source.get("type") or "").lower()
        name = self._display_name(source)
        mac = str(source.get("mac") or "").strip().upper()
        expiry = str(source.get("_last_expiry") or "").strip()
        status = str(source.get("_last_status") or "").strip().lower()
        blocked = str(source.get("_last_blocked") or "0")
        portal = str(source.get("portal") or source.get("url") or "")

        # Xtream uses its own health state and shows the real account expiry.
        if stype == "xtream":
            xt_expiry = str(source.get("_last_expiry") or "").strip()
            if not xt_expiry:
                # Server Manager persists exp_date here after background/Test checks.
                xt_expiry = str(source.get("expiry") or source.get("exp_date") or "").strip()

            display_expiry = _format_server_expiry(xt_expiry)
            if display_expiry == "—":
                display_expiry = "Unknown"

            if status == "offline":
                return {
                    "type": "xtream", "name": name, "mac": "", "expiry": display_expiry,
                    "message": "OFFLINE", "led": "inactive"
                }

            return {
                "type": "xtream", "name": name, "mac": "", "expiry": display_expiry,
                "message": "ONLINE", "led": "active"
            }

        # Stalker display state comes from one authoritative local helper.
        compat = {}
        if stype == "stalker":
            try:
                compat = get_stalker_account_state(source) or {}
            except Exception:
                compat = {}

            expiry = str(compat.get("expiry") or expiry or "").strip()
            blocked = str(compat.get("blocked") or blocked or "0")
            portal = str(compat.get("portal") or portal or "")
            if compat.get("status") not in (None, ""):
                status = str(compat.get("status"))

        expires = self._format_estalker_expiry(expiry)
        message = "Active"
        led = "active"

        parsed_date = self._parse_estalker_expiry(expiry)
        if parsed_date and parsed_date < datetime.now():
            message = "Expired"
            led = "expired"
        elif blocked == "1":
            message = "Blocked"
            led = "blocked"
        elif str(source.get("_last_status") or "").lower() == "offline":
            message = "Not active"
            led = "inactive"
        elif stype == "stalker" and not compat:
            message = "Unknown"
            led = "unknown"
        elif "stalker" not in portal.lower() and str(status) not in ("", "0", "None") and expiry:
            message = "Unknown"
            led = "unknown"

        return {
            "type": stype, "name": name, "mac": mac, "expiry": expires,
            "message": message, "led": led
        }

    def _row(self, source, selected_here=False):
        info = self._estalker_row_info(source)
        pixmap = self._pixmaps.get(info["led"]) or self._pixmaps.get("unchecked")
        selected_text = u"✓" if selected_here else ""

        # Compact neon layout used by the professional Live Server screen.
        status_color = 0x0067E89A
        if info["led"] == "unknown":
            status_color = 0x00FFD44A
        elif info["led"] in ("inactive", "blocked"):
            status_color = 0x00FF6B78
        elif info["led"] == "expired":
            status_color = 0x0056B8FF

        if info["type"] == "xtream":
            return [
                source,
                MultiContentEntryText(
                    pos=(12, 0), size=(36, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=selected_text, color=0x00FFD34A, color_sel=0x00FFD34A
                ),
                MultiContentEntryPixmapAlphaBlend(
                    pos=(56, 12), size=(52, 52), png=self._type_pixmap_xtream
                ),
                MultiContentEntryText(
                    pos=(122, 0), size=(360, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=info["name"], color=0x00F5F8FC, color_sel=0x00FFFFFF
                ),
                MultiContentEntryText(
                    pos=(500, 0), size=(250, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=info["expiry"], color=0x00D5DDE8, color_sel=0x00FFFFFF
                ),
                MultiContentEntryText(
                    pos=(770, 0), size=(150, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=info["message"], color=status_color, color_sel=status_color
                ),
                MultiContentEntryPixmapAlphaBlend(
                    pos=(944, 27), size=(23, 24), png=pixmap
                ),
            ]

        return [
            source,
            MultiContentEntryText(
                pos=(12, 0), size=(36, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=selected_text, color=0x00FFD34A, color_sel=0x00FFD34A
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(56, 12), size=(52, 52), png=self._type_pixmap_stalker
            ),
            MultiContentEntryText(
                pos=(122, 5), size=(360, 32), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["name"], color=0x00F5F8FC, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(122, 38), size=(360, 29), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["mac"], color=0x008FA8C0, color_sel=0x00BFD7EA
            ),
            MultiContentEntryText(
                pos=(500, 0), size=(250, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["expiry"], color=0x00D5DDE8, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(770, 0), size=(150, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["message"], color=status_color, color_sel=status_color
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(944, 27), size=(23, 24), png=pixmap
            ),
        ]

    def setRows(self, rows):
        self.setList([self._row(source, selected) for source, selected in rows])


class LiveServerChoiceScreen(Screen):
    skin = """
    <screen name="LiveServerChoiceScreen" position="center,center" size="1540,820"
            title="Switch Live server" backgroundColor="#050D18">

        <!-- outer glow / frame -->
        <eLabel position="0,0" size="1540,820" backgroundColor="#07111F" zPosition="0" />
        <eLabel position="2,2" size="1536,816" backgroundColor="#0A1A2D" zPosition="1" />

        <!-- header -->
        <eLabel position="26,24" size="1018,112" backgroundColor="#081522" zPosition="2" />
        <widget name="title" position="62,42" size="720,48" font="Regular;36"
                foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="subtitle" position="62,92" size="920,28" font="Regular;20"
                foregroundColor="#9FB5C9" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <eLabel position="28,134" size="1014,2" backgroundColor="#148CFF" zPosition="4" />

        <!-- left server card -->
        <eLabel position="26,150" size="1018,592" backgroundColor="#071522" zPosition="2" />
        <eLabel position="42,162" size="986,52" backgroundColor="#0A1D31" zPosition="3" />
        <widget name="columns" position="66,172" size="930,32" font="Regular;19"
                foregroundColor="#A9BDD0" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="servers" position="48,220" size="978,468"
                backgroundColor="#071522" backgroundColorSelected="#12345A"
                foregroundColor="#FFFFFF" foregroundColorSelected="#FFFFFF"
                itemHeight="78" scrollbarMode="showOnDemand"
                itemCornerRadius="10" itemCornerRadiusSelected="10" zPosition="5" />

        <!-- footer controls -->
        <eLabel position="42,700" size="986,1" backgroundColor="#173451" zPosition="4" />
        <widget name="hint" position="62,710" size="940,28" font="Regular;18"
                foregroundColor="#D8E6F2" backgroundColor="#00000000" transparent="1" zPosition="5" />

        <!-- right web QR card -->
        <eLabel position="1064,24" size="450,718" backgroundColor="#071522" zPosition="2" />
        <eLabel position="1066,26" size="446,714" backgroundColor="#08192A" zPosition="3" />
        <widget name="qrTitle" position="1100,62" size="380,34" font="Regular;25"
                foregroundColor="#48CFFF" backgroundColor="#00000000" transparent="1"
                halign="center" zPosition="5" />
        <widget name="qrSubtitle" position="1100,102" size="380,28" font="Regular;18"
                foregroundColor="#DCEAF5" backgroundColor="#00000000" transparent="1"
                halign="center" zPosition="5" />

        <eLabel position="1121,156" size="338,338" backgroundColor="#FFFFFF" zPosition="4" />
        <widget name="qr" position="1141,176" size="298,298" alphatest="blend" zPosition="6" />

        <eLabel position="1110,522" size="18,18" backgroundColor="#24E882" zPosition="5" />
        <widget name="webStatus" position="1140,510" size="330,40" font="Regular;22"
                foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="webUrl" position="1094,560" size="390,62" font="Regular;20"
                foregroundColor="#70DFFF" backgroundColor="#00000000" transparent="1"
                halign="center" valign="center" zPosition="5" />
        <widget name="webHint" position="1100,632" size="380,58" font="Regular;17"
                foregroundColor="#9FB5C9" backgroundColor="#00000000" transparent="1"
                halign="center" valign="center" zPosition="5" />

        <!-- clock -->
        <widget name="clock" position="1198,758" size="286,34" font="Regular;27"
                foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1"
                halign="right" zPosition="5" />
        <widget name="date" position="1120,792" size="364,22" font="Regular;17"
                foregroundColor="#91A8BB" backgroundColor="#00000000" transparent="1"
                halign="right" zPosition="5" />
    </screen>
    """

    def __init__(self, session, rows):
        Screen.__init__(self, session)
        self["title"] = Label("LIVE SERVER")
        self["subtitle"] = Label("Select the best live server for smooth streaming")
        self["columns"] = Label("SERVER NAME                                      EXPIRY                         STATUS")
        self["servers"] = LiveServerChoiceList(rows)
        self["hint"] = Label("OK  Select        RED  Delete        YELLOW  Switch server        BLUE  Test server        EXIT  Close")

        self["qrTitle"] = Label("SCAN TO CONNECT")
        self["qrSubtitle"] = Label("WEB SERVER")
        self["qr"] = Pixmap()
        self["webStatus"] = Label("Web server: STARTING")
        self["webUrl"] = Label("")
        self["webHint"] = Label("Phone and receiver must be on the same local network.")
        self["clock"] = Label("")
        self["date"] = Label("")

        self._qrPath = "/var/volatile/tmp/tivimatee2_live_server_qr.png"
        self._clockTimer = eTimer()
        _connect_timer(self._clockTimer, self._refreshClock)

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.ok,
                "cancel": self.close,
                "up": self["servers"].up,
                "down": self["servers"].down,
                "pageUp": self["servers"].pageUp,
                "pageDown": self["servers"].pageDown,
                "red": self.deleteCurrent,
                "yellow": self.ok,
                "blue": self.testCurrent,
            }, -1
        )

        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._cleanupProfessionalUI)

    def _layoutReady(self):
        self._refreshClock()
        try:
            self._clockTimer.start(30000, False)
        except Exception:
            pass
        self._refreshWebCard()

    def _refreshClock(self):
        try:
            now = datetime.now()
            self["clock"].setText(now.strftime("%I:%M %p").lstrip("0"))
            self["date"].setText(now.strftime("%d %B %Y"))
        except Exception:
            pass

    def _refreshWebCard(self):
        try:
            from .web_manager import start_web_manager, web_manager_status
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get("ip") or "127.0.0.1")
            port = int(status.get("port") or 8088)
            running = bool(status.get("running"))
            url = "http://%s:%d" % (ip, port)

            self["webStatus"].setText("Web server %s" % ("ON" if running else "OFF"))
            self["webUrl"].setText(url if running else "")

            if running and ip not in ("127.0.0.1", "0.0.0.0"):
                from .web_qr import make_qr_png
                folder = os.path.dirname(self._qrPath)
                if folder and not os.path.isdir(folder):
                    os.makedirs(folder)
                make_qr_png(url, self._qrPath, scale=8, border=4)
                try:
                    if self["qr"].instance:
                        self["qr"].instance.setPixmap(LoadPixmap(self._qrPath))
                    self["qr"].show()
                except Exception:
                    pass
            else:
                self["webHint"].setText("Connect the receiver to LAN/Wi-Fi to enable QR access.")
        except Exception:
            self["webStatus"].setText("Web server OFF")
            self["webUrl"].setText("")
            self["webHint"].setText("Web Manager is unavailable on this receiver.")

    def _cleanupProfessionalUI(self):
        try:
            self._clockTimer.stop()
        except Exception:
            pass
        try:
            if os.path.exists(self._qrPath):
                os.remove(self._qrPath)
        except Exception:
            pass

    def _currentSource(self):
        row = self["servers"].getCurrent()
        return row[0] if row and isinstance(row[0], dict) else None

    def deleteCurrent(self):
        source = self._currentSource()
        if not source:
            return
        self.close(("delete", dict(source)))

    def testCurrent(self):
        source = self._currentSource()
        if not source:
            return
        self.close(("test", dict(source)))

    def ok(self):
        row = self["servers"].getCurrent()
        source = row[0] if row else None
        self.close(dict(source) if isinstance(source, dict) else None)



BACKUP_SCHEMA_VERSION = 1
BACKUP_FOLDER = data_path("backups")

_BACKUP_FILE_GROUPS = {
    "filters": [
        data_path("category_filters.json"),
        data_path("stalker_hidden.json"),
        data_path("xtream_hidden.json"),
        data_path("stalker_pin.json"),
        data_path("xtream_pin.json"),
    ],
    "favorites": [data_path("favorites.json")],
    "app_settings": [
        data_path("channel_settings.json"), data_path("live_source.json"),
        data_path("home_appearance.json"), data_path("update_settings.json"),
        data_path("active_source.json"), data_path("language.json"),
        data_path("tmdb.json"), data_path("tmdb_settings.json"),
        data_path("cache_settings.json"), data_path("recording.json"),
    ],
    "continue": [data_path("resume.json")],
    "player": [
        data_path("player.json"), data_path("player_preferences.json"),
        data_path("xtream_service_types.json"),
    ],
}


def _backup_read_file(path):
    try:
        if not os.path.exists(path):
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            raw = handle.read()
        try:
            return {"format": "json", "value": json.loads(raw)}
        except Exception:
            return {"format": "text", "value": raw}
    except Exception:
        return None


def _backup_write_file(path, record):
    if not isinstance(record, dict):
        return False
    try:
        ensure_dir(os.path.dirname(path))
        tmp = path + ".restore.tmp"
        if record.get("format") == "json":
            raw = json.dumps(record.get("value"), ensure_ascii=False, indent=2, sort_keys=True)
        else:
            raw = str(record.get("value") or "")
        with open_text(tmp, "w", encoding="utf-8") as handle:
            handle.write(raw)
        atomic_replace(tmp, path)
        return True
    except Exception:
        return False


def _backup_group_count(group):
    try:
        if group == "servers":
            return len(get_sources() or [])
        if group == "filters":
            total = 0
            for path in _BACKUP_FILE_GROUPS["filters"]:
                data = load_json(path, {}) or {}
                if isinstance(data, dict):
                    for value in data.values():
                        if isinstance(value, dict):
                            for key in ("live", "vod", "series", "categories", "channels"):
                                rows = value.get(key)
                                if isinstance(rows, (list, tuple, set)):
                                    total += len(rows)
                        elif isinstance(value, list):
                            total += len(value)
            return total
        if group == "favorites":
            try:
                return int(favourites_count() or 0)
            except Exception:
                data = load_json(data_path("favorites.json"), {}) or {}
                return len(data.get("items") or []) if isinstance(data, dict) else 0
        if group == "continue":
            data = load_json(data_path("resume.json"), {}) or {}
            return len(data) if isinstance(data, dict) else 0
        if group in ("app_settings", "player"):
            return sum(1 for path in _BACKUP_FILE_GROUPS.get(group, []) if os.path.exists(path))
    except Exception:
        pass
    return 0


def _create_selected_backup(selected):
    ensure_dir(BACKUP_FOLDER)
    payload = {
        "schema": BACKUP_SCHEMA_VERSION,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "groups": {},
    }
    for group in selected:
        if group == "servers":
            payload["groups"][group] = {"servers": get_sources() or []}
            continue
        files = {}
        for path in _BACKUP_FILE_GROUPS.get(group, []):
            record = _backup_read_file(path)
            if record is not None:
                files[os.path.basename(path)] = record
        payload["groups"][group] = {"files": files}
    stamp = time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_FOLDER, "tivimatee2-backup-%s.json" % stamp)
    tmp = path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    atomic_replace(tmp, path)
    return path


def _latest_backup_file():
    try:
        rows = [os.path.join(BACKUP_FOLDER, name) for name in os.listdir(BACKUP_FOLDER)
                if name.startswith("tivimatee2-backup-") and name.endswith(".json")]
        rows = [path for path in rows if os.path.isfile(path)]
        return max(rows, key=os.path.getmtime) if rows else ""
    except Exception:
        return ""


def _restore_selected_backup(path, selected):
    with open_text(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle) or {}
    groups = payload.get("groups") or {}
    restored = []
    for group in selected:
        record = groups.get(group)
        if not isinstance(record, dict):
            continue
        if group == "servers":
            servers = record.get("servers") or []
            set_sources(servers)
            write_playlists(servers)
            restored.append(group)
            continue
        by_name = record.get("files") or {}
        for target in _BACKUP_FILE_GROUPS.get(group, []):
            saved = by_name.get(os.path.basename(target))
            if saved is not None:
                _backup_write_file(target, saved)
        restored.append(group)
    return restored



class BackupSectionList(MenuList):
    """Two-line backup section rows with real checkbox/count columns."""
    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 27))
            self.l.setFont(1, gFont("Regular", 19))
            self.l.setFont(2, gFont("Regular", 24))
            self.l.setItemHeight(84)
            self.l.setBuildFunc(self._buildRow)
        except Exception:
            pass

    def currentKey(self):
        try:
            current = self.getCurrent()
        except Exception:
            current = None
        if not current:
            return None

        # eListboxPythonMultiContent may return either the original source tuple
        # or the built row whose first element is that tuple.
        try:
            if isinstance(current, (tuple, list)):
                if current and isinstance(current[0], (tuple, list)):
                    source = current[0]
                    return source[0] if source else None
                return current[0] if current else None
        except Exception:
            pass
        return None

    def _buildRow(self, key, label, description, icon, count, selected, index):
        checked = bool(selected)
        row = [(key, label, description, icon, count, checked, index)]

        # Number badge.
        row.append(MultiContentEntryText(
            pos=(14, 14), size=(64, 54), font=2,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text="%02d" % int(index),
            color=0x00D9E8F4, color_sel=0x00FFFFFF
        ))

        # Section icon.
        row.append(MultiContentEntryText(
            pos=(98, 8), size=(56, 68), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=str(icon or ""),
            color=0x006FD6FF, color_sel=0x00FFFFFF
        ))

        # Title + description.
        row.append(MultiContentEntryText(
            pos=(172, 4), size=(720, 38), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=str(label or ""),
            color=0x00FFFFFF, color_sel=0x00FFFFFF
        ))
        row.append(MultiContentEntryText(
            pos=(172, 42), size=(780, 32), font=1,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=str(description or ""),
            color=0x009BB5C9, color_sel=0x00E6F4FF
        ))

        # Checkbox and item count.
        row.append(MultiContentEntryText(
            pos=(980, 12), size=(68, 60), font=2,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=("[X]" if checked else "[ ]"),
            color=(0x004DA3FF if checked else 0x006D8498),
            color_sel=0x00FFFFFF
        ))
        row.append(MultiContentEntryText(
            pos=(1080, 10), size=(145, 62), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=str(int(count)),
            color=0x0073D4FF, color_sel=0x00FFFFFF
        ))
        row.append(MultiContentEntryText(
            pos=(1245, 12), size=(38, 58), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            text=u"›",
            color=0x00B9D0E1, color_sel=0x00FFFFFF
        ))
        return row


BACKUP_AUTO_SETTINGS_FILE = data_path("backup_auto_settings.json")

def _backup_files():
    try:
        ensure_dir(BACKUP_FOLDER)
        rows = [os.path.join(BACKUP_FOLDER, name) for name in os.listdir(BACKUP_FOLDER)
                if name.startswith("tivimatee2-backup-") and name.endswith(".json")]
        rows = [path for path in rows if os.path.isfile(path)]
        return sorted(rows, key=os.path.getmtime, reverse=True)
    except Exception:
        return []

def _backup_all_groups():
    return set(["servers", "filters", "favorites", "app_settings", "continue", "player"])

def _backup_auto_settings():
    data = load_json(BACKUP_AUTO_SETTINGS_FILE, {}) or {}
    return {
        "enabled": bool(data.get("enabled", False)),
        "last_run": int(data.get("last_run", 0) or 0),
    }

def _save_backup_auto_settings(settings):
    try:
        save_json(BACKUP_AUTO_SETTINGS_FILE, settings)
        return True
    except Exception:
        return False

def _backup_validate_file(path):
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle) or {}
        return isinstance(payload, dict) and isinstance(payload.get("groups"), dict)
    except Exception:
        return False

def _backup_import_candidates():
    roots = ["/media/hdd", "/media/usb", "/media/mmc", "/media/net", "/tmp"]
    rows = []
    seen = set()
    for root in roots:
        if not os.path.isdir(root):
            continue
        try:
            for name in os.listdir(root):
                path = os.path.join(root, name)
                if os.path.isfile(path) and name.endswith(".json") and ("backup" in name.lower()):
                    if path not in seen and _backup_validate_file(path):
                        seen.add(path); rows.append(path)
        except Exception:
            pass
    return rows

BACKUP_DASHBOARD_R135_SKIN = r"""<screen name="TiviMateBackupRestore" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#01060B">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/backup_dashboard_r198.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus" position="234,292" size="476,344" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/backup_focus_r198.png" alphatest="blend" zPosition="10"/>
    <widget name="status0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


class BackupRestoreScreen(Screen):
    skin = scale_skin(BACKUP_DASHBOARD_R135_SKIN)

    POSITIONS = [(234,292), (729,292), (1225,292), (234,634), (729,634), (1225,634)]

    def __init__(self, session):
        Screen.__init__(self, session)
        self.index = 0
        self["focus"] = Pixmap()
        for i in range(6):
            self["status%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.openCurrent, "cancel": self.close,
                "left": self.left, "right": self.right,
                "up": self.up, "down": self.down,
                "green": self.openCurrent,
                "yellow": self.showInfo,
                "blue": self.manageBackups,
                "red": self.close,
            }, -1
        )
        self.onLayoutFinish.append(self._layoutReady)

    def _layoutReady(self):
        self._maybeAutoBackup()
        self.refresh()
        self._focus()

    def _focus(self):
        try:
            x, y = self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x), sy(y)))
            self["focus"].show()
        except Exception:
            pass

    def left(self):
        row = self.index // 3
        col = self.index % 3
        self.index = row * 3 + ((col - 1) % 3)
        self._focus()

    def right(self):
        row = self.index // 3
        col = self.index % 3
        self.index = row * 3 + ((col + 1) % 3)
        self._focus()

    def up(self):
        self.index = (self.index - 3) % 6
        self._focus()

    def down(self):
        self.index = (self.index + 3) % 6
        self._focus()

    def _backupCount(self):
        return len(_backup_files())

    def _latestText(self):
        path = _latest_backup_file()
        if not path:
            return "No backup yet"
        try:
            return "Last: " + time.strftime("%d %b %Y", time.localtime(os.path.getmtime(path)))
        except Exception:
            return "Backup available"

    def _externalStorageText(self):
        for path, label in (
            ("/media/usb", "USB Ready"),
            ("/media/hdd", "HDD Ready"),
            ("/media/mmc", "MMC Ready"),
            ("/media/net", "Network Ready"),
        ):
            try:
                if os.path.ismount(path) or os.path.isdir(path):
                    return label
            except Exception:
                pass
        return "No External Storage"

    def refresh(self):
        count = self._backupCount()
        auto = _backup_auto_settings()
        self["status0"].setText("%d Backup%s" % (count, "" if count == 1 else "s"))
        self["status1"].setText(self._latestText())
        self["status2"].setText("AUTO  %s" % ("ON" if auto.get("enabled") else "OFF"))
        self["status3"].setText("%d Backup%s" % (count, "" if count == 1 else "s"))
        self["status4"].setText(self._externalStorageText())
        self["status5"].setText("%d Available" % count)

    def openCurrent(self):
        actions = (
            self.createBackup,
            self.restoreBackup,
            self.toggleAutoBackup,
            self.manageBackups,
            self.importBackup,
            self.deleteBackup,
        )
        actions[self.index]()

    def createBackup(self):
        try:
            path = _create_selected_backup(_backup_all_groups())
            auto = _backup_auto_settings()
            if auto.get("enabled"):
                auto["last_run"] = int(time.time())
                _save_backup_auto_settings(auto)
            self.refresh()
            self.session.open(MessageBox, "Backup created successfully.\n\n%s" % path, MessageBox.TYPE_INFO, timeout=7)
        except Exception as exc:
            self.session.open(MessageBox, "Backup failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def _backupChoices(self):
        choices = []
        for path in _backup_files():
            try:
                stamp = time.strftime("%d %b %Y  %H:%M", time.localtime(os.path.getmtime(path)))
            except Exception:
                stamp = os.path.basename(path)
            choices.append(("%s   •   %s" % (stamp, os.path.basename(path)), path))
        return choices

    def restoreBackup(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backup file is available yet.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._restoreSelected, ChoiceBox, title="RESTORE BACKUP", list=choices)

    def _restoreSelected(self, selected=None):
        if not selected:
            return
        path = selected[1]
        self.session.openWithCallback(
            lambda answer, p=path: self._restoreConfirmed(p) if answer else None,
            MessageBox,
            "Restore all available settings from:\n%s ?" % os.path.basename(path),
            MessageBox.TYPE_YESNO
        )

    def _restoreConfirmed(self, path):
        try:
            restored = _restore_selected_backup(path, _backup_all_groups())
            self.refresh()
            self.session.open(
                MessageBox,
                "Restore completed: %s\n\nRestart TiviMateE2 / Enigma2 to reload restored settings." %
                (", ".join(restored) if restored else "no matching sections"),
                MessageBox.TYPE_INFO, timeout=8
            )
        except Exception as exc:
            self.session.open(MessageBox, "Restore failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def toggleAutoBackup(self):
        settings = _backup_auto_settings()
        settings["enabled"] = not bool(settings.get("enabled"))
        if settings["enabled"] and not settings.get("last_run"):
            settings["last_run"] = 0
        _save_backup_auto_settings(settings)
        self._maybeAutoBackup(force=False)
        self.refresh()
        self.session.open(
            MessageBox,
            "Automatic daily backup is %s." % ("ON" if settings["enabled"] else "OFF"),
            MessageBox.TYPE_INFO, timeout=4
        )

    def _maybeAutoBackup(self, force=False):
        settings = _backup_auto_settings()
        if not settings.get("enabled"):
            return
        now = int(time.time())
        last_run = int(settings.get("last_run", 0) or 0)
        if not force and last_run and (now - last_run) < 86400:
            return
        try:
            _create_selected_backup(_backup_all_groups())
            settings["last_run"] = now
            _save_backup_auto_settings(settings)
        except Exception:
            pass

    def manageBackups(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backups to manage.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._manageSelected, ChoiceBox, title="MANAGE BACKUPS", list=choices)

    def _manageSelected(self, selected=None):
        if not selected:
            return
        path = selected[1]
        choices = [
            ("RESTORE", ("restore", path)),
            ("INFO", ("info", path)),
            ("DELETE", ("delete", path)),
        ]
        self.session.openWithCallback(self._manageAction, ChoiceBox, title=os.path.basename(path), list=choices)

    def _manageAction(self, selected=None):
        if not selected:
            return
        action, path = selected[1]
        if action == "restore":
            self._restoreSelected(("restore", path))
        elif action == "delete":
            self._deletePathAsk(path)
        else:
            self._showBackupInfo(path)

    def _showBackupInfo(self, path):
        try:
            with open_text(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle) or {}
            groups = sorted((payload.get("groups") or {}).keys())
            created = payload.get("created_at") or "Unknown"
            text = "File: %s\nCreated: %s\nSections: %s" % (
                os.path.basename(path), created, ", ".join(groups) if groups else "None"
            )
        except Exception:
            text = "Unable to read backup information."
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=8)

    def importBackup(self):
        candidates = _backup_import_candidates()
        if not candidates:
            self.session.open(
                MessageBox,
                "No compatible backup JSON was found on HDD, USB, MMC, network storage or /tmp.",
                MessageBox.TYPE_INFO, timeout=6
            )
            return
        choices = [(os.path.basename(path) + "   •   " + os.path.dirname(path), path) for path in candidates]
        self.session.openWithCallback(self._importSelected, ChoiceBox, title="IMPORT BACKUP", list=choices)

    def _importSelected(self, selected=None):
        if not selected:
            return
        src = selected[1]
        if not _backup_validate_file(src):
            self.session.open(MessageBox, "Invalid backup file.", MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            ensure_dir(BACKUP_FOLDER)
            name = os.path.basename(src)
            if not name.startswith("tivimatee2-backup-"):
                name = "tivimatee2-backup-import-%s.json" % time.strftime("%Y%m%d-%H%M%S")
            dst = os.path.join(BACKUP_FOLDER, name)
            if os.path.exists(dst):
                dst = os.path.join(BACKUP_FOLDER, "tivimatee2-backup-import-%s.json" % time.strftime("%Y%m%d-%H%M%S"))
            with open(src, "rb") as rf:
                data = rf.read()
            tmp = dst + ".tmp"
            with open(tmp, "wb") as wf:
                wf.write(data)
            atomic_replace(tmp, dst)
            self.refresh()
            self.session.open(MessageBox, "Backup imported successfully.", MessageBox.TYPE_INFO, timeout=5)
        except Exception as exc:
            self.session.open(MessageBox, "Import failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=6)

    def deleteBackup(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backups to delete.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._deleteSelected, ChoiceBox, title="DELETE BACKUP", list=choices)

    def _deleteSelected(self, selected=None):
        if selected:
            self._deletePathAsk(selected[1])

    def _deletePathAsk(self, path):
        self.session.openWithCallback(
            lambda answer, p=path: self._deletePath(p) if answer else None,
            MessageBox,
            "Delete backup?\n%s" % os.path.basename(path),
            MessageBox.TYPE_YESNO
        )

    def _deletePath(self, path):
        try:
            os.remove(path)
            self.refresh()
            self.session.open(MessageBox, "Backup deleted.", MessageBox.TYPE_INFO, timeout=4)
        except Exception as exc:
            self.session.open(MessageBox, "Delete failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def showInfo(self):
        descriptions = [
            "Create a full backup of servers, filters, favourites, application settings, history and player preferences.",
            "Restore all matching settings from a selected backup file.",
            "Toggle automatic backup. When enabled, one backup is created per day when this screen is opened.",
            "Browse existing backups and restore, inspect or delete them.",
            "Import a compatible backup JSON from external storage.",
            "Choose and permanently delete an existing backup file.",
        ]
        self.session.open(MessageBox, descriptions[self.index], MessageBox.TYPE_INFO, timeout=7)



SUBTITLE_DASHBOARD_SKIN = r"""<screen name="SubtitleDashboard" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/subtitle_dashboard_r119.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus" position="53,278" size="895,310" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/subtitle_focus_r177.png" alphatest="blend" zPosition="8"/>
</screen>"""

class SubtitleDashboard(Screen):
    skin = SUBTITLE_DASHBOARD_SKIN
    POSITIONS=[(53,278),(972,278),(53,610),(972,610)]

    def __init__(self,session):
        Screen.__init__(self,session)
        self.index=0
        self["focus"]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "ok":self.openCurrent,"cancel":self.close,
            "left":self.left,"right":self.right,"up":self.up,"down":self.down,
        },-1)
        self.onLayoutFinish.append(self._focus)

    def _focus(self):
        try:
            x,y=self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:pass

    def left(self):
        self.index=self.index-1 if self.index%2 else self.index+1
        self._focus()
    def right(self):
        self.left()
    def up(self):
        self.index=(self.index-2)%4; self._focus()
    def down(self):
        self.index=(self.index+2)%4; self._focus()

    def openCurrent(self):
        if self.index==0:
            self.importSubDLKey(); return
        if self.index==1:
            self.session.open(SubDLSubtitleLanguageSettings); return
        if self.index==2:
            self.openServerSubtitleFont(); return
        if self.index==3:
            self.openExternalSubtitleFont(); return

    def importSubDLKey(self):
        try:
            value=_read_subdl_import_key()
            current=load_subdl_settings()
            save_subdl_settings(value,current.get("language","ar"),current.get("kind","standard"))
            removed=_remove_subdl_import_file()
            msg=("SubDL key imported and saved. Temporary key file removed." if removed else
                 "SubDL key imported and saved. Remove the imported key file manually to protect your key.")
            self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=6)
        except IOError:
            self.session.open(MessageBox,
                "Put one SubDL API key in key.txt on HDD, USB, MMC or /etc/enigma2, then select Import Subtitle.",
                MessageBox.TYPE_INFO,timeout=7)
        except ValueError:
            self.session.open(MessageBox,"Invalid SubDL key file. It must contain exactly one API key.",MessageBox.TYPE_ERROR,timeout=7)
        except Exception:
            self.session.open(MessageBox,"Could not import the SubDL key.",MessageBox.TYPE_ERROR,timeout=7)

    def openServerSubtitleFont(self):
        try:
            subtitles=getattr(config,"subtitles",None)
            setting=getattr(subtitles,"subtitle_fontsize",None) if subtitles is not None else None
            if setting is None: raise RuntimeError("native subtitle font setting unavailable")
            current=str(getattr(setting,"value","") or "")
            sizes=[]
            try:
                for entry in (getattr(setting,"choices",None) or []):
                    value=entry[0] if isinstance(entry,(tuple,list)) else entry
                    value=str(value)
                    if value.isdigit() and value not in sizes:sizes.append(value)
            except Exception:sizes=[]
            if not sizes:sizes=[str(x) for x in range(16,50,2)]
            choices=[("%s px%s"%(v,"  •  Current" if v==current else ""),v) for v in sizes]
            self.session.openWithCallback(self._serverFontSelected,ChoiceBox,title="SERVER SUBTITLE FONT",list=choices)
        except Exception:
            self.session.open(MessageBox,"Native Enigma2 subtitle font settings are not available on this image.",MessageBox.TYPE_ERROR,timeout=6)

    def _serverFontSelected(self,choice=None):
        if not choice:return
        try:
            value=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
            setting=config.subtitles.subtitle_fontsize
            setting.value=str(value)
            try:setting.save()
            except Exception:pass
            try:configfile.save()
            except Exception:pass
            self.session.open(MessageBox,"Server subtitle font size saved: %s"%value,MessageBox.TYPE_INFO,timeout=3)
        except Exception:
            self.session.open(MessageBox,"Could not save the native subtitle font size.",MessageBox.TYPE_ERROR,timeout=5)

    def openExternalSubtitleFont(self):
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings, SubsSetupExternal
            settings=initSubsSettings(); external=getattr(settings,"external",None)
            if external is None: raise RuntimeError("missing external subtitle settings")
            self.session.open(SubsSetupExternal,external); return
        except ImportError:
            self.session.open(MessageBox,"External subtitle font settings require SubsSupport.",MessageBox.TYPE_INFO,timeout=7); return
        except Exception:
            try:
                from Plugins.Extensions.SubsSupport.plugin import openSubsSupportSettings
                return openSubsSupportSettings(self.session)
            except Exception:
                self.session.open(MessageBox,"Could not open the SubsSupport font settings on this receiver image.",MessageBox.TYPE_ERROR,timeout=7)



SERVER_HUB_SKIN = r"""<screen name="ServerHub" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_cards_bg_r123.jpg" alphatest="blend" scale="1" zPosition="0"/>

    <widget name="brand" position="72,42" size="390,52" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="title" position="600,38" size="720,46" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
    <widget name="subtitle" position="550,86" size="820,30" font="Regular;19" foregroundColor="#B8C2CB" transparent="1" halign="center" zPosition="5"/>
    <widget name="clock" position="1580,38" size="220,42" font="Regular;33" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
    <widget name="date" position="1550,80" size="280,28" font="Regular;17" foregroundColor="#C8D0D8" transparent="1" halign="center" zPosition="5"/>

    <widget name="focus" position="60,185" size="560,320" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_card_focus_r123.png" alphatest="blend" zPosition="20"/>

    <widget name="bg0" position="60,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon0" position="92,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name0" position="265,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type0" position="265,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state0" position="265,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry0" position="265,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host0" position="265,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions0" position="90,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg1" position="680,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon1" position="712,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name1" position="885,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type1" position="885,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state1" position="885,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry1" position="885,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host1" position="885,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions1" position="710,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg2" position="1300,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon2" position="1332,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name2" position="1505,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type2" position="1505,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state2" position="1505,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry2" position="1505,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host2" position="1505,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions2" position="1330,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg3" position="60,545" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon3" position="92,598" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name3" position="265,575" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type3" position="265,616" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state3" position="265,662" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry3" position="265,704" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host3" position="265,746" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions3" position="90,814" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg4" position="680,545" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon4" position="712,598" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name4" position="885,575" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type4" position="885,616" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state4" position="885,662" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry4" position="885,704" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host4" position="885,746" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions4" position="710,814" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg5" position="1300,545" size="560,320" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_card_add_r123.png" alphatest="blend" zPosition="2"/>
    <widget name="icon5" position="1332,598" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/icon_add_r123.png" alphatest="blend" zPosition="4"/>
    <widget name="name5" position="1505,590" size="320,38" font="Regular;27" foregroundColor="#F1C84C" transparent="1" zPosition="5"/>
    <widget name="type5" position="1505,648" size="300,78" font="Regular;18" foregroundColor="#D5DEE6" transparent="1" valign="top" zPosition="5"/>
    <widget name="state5" position="1505,744" size="290,30" font="Regular;17" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>

    <widget name="pageText" position="780,896" size="360,32" font="Regular;18" foregroundColor="#D9E1E8" transparent="1" halign="center" zPosition="5"/>
    <widget name="footer" position="85,985" size="1750,42" font="Regular;19" foregroundColor="#E8EDF2" transparent="1" halign="center" valign="center" zPosition="5"/>
</screen>"""

class ServerHub(Screen):
    skin = SERVER_HUB_SKIN
    POSITIONS=[(60,185),(680,185),(1300,185),(60,545),(680,545),(1300,545)]
    PAGE_SIZE=5

    CARD_BG={
        "xtream":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_card_xtream_r123.png",
        "stalker":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_card_stalker_r123.png",
        "m3u":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_card_m3u_r123.png",
        "generic":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_card_generic_r123.png"
    }
    CARD_ICON={
        "xtream":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/icon_xtream_r123.png",
        "stalker":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/icon_stalker_r123.png",
        "m3u":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/icon_m3u_r123.png",
        "generic":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/icon_generic_r123.png"
    }

    def __init__(self,session):
        Screen.__init__(self,session)
        self.index=0
        self.page=0
        self.sources=[]
        self["brand"]=Label("TiviMate")
        self["title"]=Label("SERVER & PLAYLISTS")
        self["subtitle"]=Label("Manage your IPTV servers and playlists")
        self["clock"]=Label("")
        self["date"]=Label("")
        self["focus"]=Pixmap()
        for i in range(5):
            self["bg%d"%i]=Pixmap()
            self["icon%d"%i]=Pixmap()
            self["name%d"%i]=Label("")
            self["type%d"%i]=Label("")
            self["state%d"%i]=Label("")
            self["expiry%d"%i]=Label("")
            self["host%d"%i]=Label("")
            self["actions%d"%i]=Label("")
        self["bg5"]=Pixmap()
        self["icon5"]=Pixmap()
        self["name5"]=Label("ADD NEW SERVER")
        self["type5"]=Label("Xtream Codes\nStalker Portal\nM3U Playlist")
        self["state5"]=Label("OK  •  Select")
        self["pageText"]=Label("")
        self["footer"]=Label("RED  Delete    YELLOW  Edit    GREEN  Add Server    BLUE  Packages Filter    OK  Open    BACK  Exit")

        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "ok":self.openCurrent,
            "cancel":self.close,
            "left":self.left,
            "right":self.right,
            "up":self.up,
            "down":self.down,
            "green":self.openAdd,
            "yellow":self.editSelected,
            "red":self.deleteSelected,
            "blue":self.openSelectedServerFilter
        },-1)

        self._clockTimer=eTimer()
        _connect_timer(self._clockTimer,self.updateClock)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._cleanup)

    def _ready(self):
        self.refresh()
        self.updateClock()
        try:self._clockTimer.start(30000,False)
        except Exception:pass

    def _cleanup(self):
        try:self._clockTimer.stop()
        except Exception:pass

    def updateClock(self):
        try:
            import time
            now=time.localtime()
            self["clock"].setText(time.strftime("%H:%M",now))
            self["date"].setText(time.strftime("%a, %d %b %Y",now))
        except Exception:pass

    @staticmethod
    def _sourceKey(source):
        source=source or {}
        return "%s|%s|%s|%s"%(
            source.get("type",""),
            (source.get("url") or source.get("path") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
            source.get("username",""),
            source.get("mac","")
        )

    def _setPixmap(self,widget,path):
        try:
            pix=LoadPixmap(path)
            if pix is not None:
                widget.instance.setPixmap(pix)
        except Exception:pass

    def _hideServerCard(self,i):
        for key in ("bg","icon","name","type","state","expiry","host","actions"):
            try:self["%s%d"%(key,i)].hide()
            except Exception:pass

    def _showServerCard(self,i):
        for key in ("bg","icon","name","type","state","expiry","host","actions"):
            try:self["%s%d"%(key,i)].show()
            except Exception:pass

    def refresh(self):
        self.sources=list(get_sources() or [])
        max_page=max(0,(len(self.sources)-1)//self.PAGE_SIZE)
        if self.page>max_page:self.page=max_page
        self._render()

    @staticmethod
    def _formatExpiry(value):
        raw=str(value or "").strip()
        if not raw or raw in ("0", "—", "None"):
            return "—"
        try:
            import time
            num=float(raw)
            if num > 100000000000:
                num /= 1000.0
            if num > 1000000000:
                return time.strftime("%d %b %Y", time.localtime(num))
        except Exception:
            pass
        return raw[:22]

    def _render(self):
        start=self.page*self.PAGE_SIZE
        visible=self.sources[start:start+self.PAGE_SIZE]

        for i in range(5):
            if i>=len(visible):
                self._hideServerCard(i)
                continue

            self._showServerCard(i)
            src=visible[i]
            stype=str(src.get("type") or "generic").strip().lower()
            if stype not in ("xtream","stalker","m3u"):
                stype="generic"

            self._setPixmap(self["bg%d"%i],self.CARD_BG[stype])
            self._setPixmap(self["icon%d"%i],self.CARD_ICON[stype])

            name=str(src.get("name") or ("Server %d"%(start+i+1)))
            pretty={"xtream":"Xtream Codes","stalker":"Stalker Portal","m3u":"M3U Playlist","generic":"IPTV Source"}[stype]
            expiry=str(src.get("_last_expiry") or src.get("expiry") or src.get("exp_date") or "—")
            host=str(src.get("url") or src.get("host") or src.get("server") or src.get("portal") or "")
            host=host.replace("http://","").replace("https://","").split("/")[0]

            self["name%d"%i].setText(name[:25])
            self["type%d"%i].setText(pretty)
            self["state%d"%i].setText("●  Configured")
            self["expiry%d"%i].setText("Expires: %s"%self._formatExpiry(expiry))
            self["host%d"%i].setText(host[:34] if host else "Local / configured source")
            self["actions%d"%i].setText("YELLOW Edit   •   RED Delete   •   OK Open")

        pages=max(1,(len(self.sources)+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["pageText"].setText("Page %d / %d"%(self.page+1,pages))
        self._focus()

    def _focus(self):
        try:
            x,y=self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:pass

    def left(self):
        row=self.index//3
        col=(self.index%3-1)%3
        self.index=row*3+col
        self._focus()

    def right(self):
        row=self.index//3
        col=(self.index%3+1)%3
        self.index=row*3+col
        self._focus()

    def up(self):
        if self.index>=3:
            self.index-=3
            self._focus()
            return
        if self.page>0:
            self.page-=1
            self.index=min(self.index+3,5)
            self._render()
            return
        self.index=min(self.index+3,5)
        self._focus()

    def down(self):
        if self.index<3:
            self.index+=3
            self._focus()
            return
        max_page=max(0,(len(self.sources)-1)//self.PAGE_SIZE)
        if self.page<max_page:
            self.page+=1
            self.index=max(0,self.index-3)
            self._render()
            return
        self.index=max(0,self.index-3)
        self._focus()

    def _selectedIndex(self):
        if self.index==5:return -1
        pos=self.page*self.PAGE_SIZE+self.index
        return pos if 0<=pos<len(self.sources) else -1

    def _selected(self):
        pos=self._selectedIndex()
        return self.sources[pos] if pos>=0 else None

    def openCurrent(self):
        if self.index==5:
            self.openAdd()
            return
        if self._selected() is not None:
            self.editSelected()

    def openAdd(self):
        self.session.openWithCallback(self._chooseSourceType,SourceTypePicker)

    def _chooseSourceType(self,source_type=None):
        if source_type=="xtream":
            self.session.openWithCallback(self._saveNew,PlaylistEditor,None)
        elif source_type=="stalker":
            self.session.openWithCallback(self._saveNew,StalkerPortalEditor,None)
        elif source_type=="m3u":
            self.session.openWithCallback(self._saveNew,M3UPlaylistEditor,None)

    def _saveNew(self,source=None):
        if not isinstance(source,dict):return
        srcs=list(get_sources() or [])
        srcs.append(source)
        set_sources(srcs)
        write_playlists(srcs)
        self.refresh()
        try:self.session.open(MessageBox,"Server saved.",MessageBox.TYPE_INFO,timeout=3)
        except Exception:pass

    def editSelected(self):
        source=self._selected()
        if not source:return
        pos=self._selectedIndex()
        callback=lambda edited=None:self._replaceAt(pos,source,edited)
        stype=str(source.get("type") or "").lower()
        if stype=="xtream":
            self.session.openWithCallback(callback,PlaylistEditor,source)
        elif stype=="stalker":
            self.session.openWithCallback(callback,StalkerPortalEditor,source)
        elif stype=="m3u":
            self.session.openWithCallback(callback,M3UPlaylistEditor,source)

    def _replaceAt(self,pos,old,new=None):
        if not isinstance(new,dict):return
        srcs=list(get_sources() or [])
        replaced=False
        if 0<=pos<len(srcs) and (srcs[pos]==old or self._sourceKey(srcs[pos])==self._sourceKey(old)):
            srcs[pos]=new
            replaced=True
        if not replaced:
            old_key=self._sourceKey(old)
            for i,item in enumerate(srcs):
                if item==old or self._sourceKey(item)==old_key:
                    srcs[i]=new
                    replaced=True
                    break
        if not replaced:srcs.append(new)
        set_sources(srcs)
        write_playlists(srcs)
        self.refresh()

    def openSelectedServerFilter(self):
        source=self._selected()
        if not isinstance(source,dict):
            self.session.open(
                MessageBox,
                "Select a server card first.",
                MessageBox.TYPE_INFO,
                timeout=3
            )
            return
        stype=str(source.get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self.session.open(
                MessageBox,
                "Packages/channel filtering is available for Xtream Codes and Stalker Portal.",
                MessageBox.TYPE_INFO,
                timeout=5
            )
            return
        self.session.openWithCallback(
            self._serverFilterClosed,
            ServerCategoryFilter,
            dict(source)
        )

    def _serverFilterClosed(self, changed=None):
        if changed:
            try:
                clear_catalog_memory()
            except Exception:
                pass
        self.refresh()

    def deleteSelected(self):
        source=self._selected()
        if not source:return
        name=str(source.get("name") or "server")
        self.session.openWithCallback(
            lambda answer:self._deleteConfirmed(answer,source),
            MessageBox,
            "Delete %s?"%name,
            MessageBox.TYPE_YESNO
        )

    def _deleteConfirmed(self,answer,source):
        if not answer:return
        key=self._sourceKey(source)
        srcs=[item for item in list(get_sources() or []) if not (item==source or self._sourceKey(item)==key)]
        set_sources(srcs)
        write_playlists(srcs)
        self.index=0
        self.refresh()



CACHE_STORAGE_PICKER_SKIN = r"""<screen name="CacheStoragePicker" position="600,280" size="720,470" flags="wfNoBorder" backgroundColor="#07101A">
    <eLabel position="0,0" size="720,470" backgroundColor="#07101A" zPosition="0"/>
    <eLabel position="0,0" size="720,5" backgroundColor="#31B4FF" zPosition="2"/>
    <widget name="title" position="45,35" size="630,46" font="Regular;31" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="4"/>
    <widget name="subtitle" position="45,85" size="630,30" font="Regular;18" foregroundColor="#8FA2B1" transparent="1" halign="center" zPosition="4"/>
    <widget name="focus" position="70,145" size="580,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/cache_picker_focus_r223.png" alphatest="blend" zPosition="5"/>
    <widget name="row0" position="92,158" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="row1" position="92,238" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="row2" position="92,318" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="hint" position="45,410" size="630,28" font="Regular;17" foregroundColor="#7E909F" transparent="1" halign="center" zPosition="4"/>
</screen>"""

class CacheStoragePicker(Screen):
    skin = CACHE_STORAGE_PICKER_SKIN
    CHOICES = [("hdd", "HDD  •  /media/hdd"), ("usb", "USB  •  removable storage"), ("internal", "INTERNAL  •  receiver flash")]
    def __init__(self, session, current="hdd"):
        Screen.__init__(self, session)
        keys=[x[0] for x in self.CHOICES]
        try:self.index=keys.index(str(current or "hdd"))
        except Exception:self.index=0
        self["title"]=Label("CACHE STORAGE")
        self["subtitle"]=Label("Choose where TiviMateE2 keeps cached artwork and data")
        self["focus"]=Pixmap()
        for i,(_k,label) in enumerate(self.CHOICES): self["row%d"%i]=Label(label)
        self["hint"]=Label("UP / DOWN  SELECT     OK  SAVE     BACK  CANCEL")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"], {"up":self.up,"down":self.down,"ok":self.ok,"cancel":self.close}, -1)
        self.onLayoutFinish.append(self._focus)
    def _focus(self):
        try:self["focus"].instance.move(ePoint(sx(70),sy(145 + self.index*80)))
        except Exception:pass
    def up(self): self.index=(self.index-1)%len(self.CHOICES); self._focus()
    def down(self): self.index=(self.index+1)%len(self.CHOICES); self._focus()
    def ok(self): self.close(self.CHOICES[self.index][0])

SETTINGS_DASHBOARD_SKIN = r"""<screen name="SettingsDashboard" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_dashboard_default.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus0" position="64,340" size="667,212" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_dashboard_focus_0.png" alphatest="blend" zPosition="8"/>
    <widget name="focus1" position="752,340" size="658,215" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_dashboard_focus_1.png" alphatest="blend" zPosition="8"/>
    <widget name="focus2" position="64,569" size="667,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_dashboard_focus_2.png" alphatest="blend" zPosition="8"/>
    <widget name="focus3" position="752,570" size="658,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_dashboard_focus_3.png" alphatest="blend" zPosition="8"/>
    <widget name="focus4" position="65,772" size="1345,155" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_dashboard_focus_4.png" alphatest="blend" zPosition="8"/>
    <widget name="langFocus0" position="208,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus1" position="506,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus2" position="823,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus3" position="1121,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="statusTitle" position="1500,88" size="330,34" font="Regular;24" foregroundColor="#F1C84C" transparent="1" zPosition="9"/>
    <eLabel position="1500,128" size="72,3" backgroundColor="#E2B84B" zPosition="9"/>
    <widget name="serverName" position="1500,150" size="220,32" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" zPosition="9"/>
    <widget name="serverTypeIcon" position="1500,181" size="40,40" transparent="1" alphatest="blend" scale="1" zPosition="10"/>
    <widget name="serverType" position="1548,190" size="172,26" font="Regular;16" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <widget name="serverState" position="1725,153" size="105,30" font="Regular;16" foregroundColor="#71E65A" transparent="1" halign="right" zPosition="9"/>
    <widget name="expiryText" position="1500,224" size="330,30" font="Regular;17" foregroundColor="#74E95C" transparent="1" zPosition="9"/>
    <eLabel position="1500,266" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="serverCount" position="1500,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <widget name="favoriteCount" position="1612,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <widget name="bouquetCount" position="1725,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <eLabel position="1500,348" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="ramText" position="1500,368" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,402" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="ramBar" position="1500,402" size="330,10" borderWidth="0" foregroundColor="#57D55A" backgroundColor="#202932" zPosition="9"/>
    <widget name="cpuText" position="1500,436" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,470" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="cpuBar" position="1500,470" size="330,10" borderWidth="0" foregroundColor="#35A9E7" backgroundColor="#202932" zPosition="9"/>
    <widget name="storageText" position="1500,504" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,538" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="storageBar" position="1500,538" size="330,10" borderWidth="0" foregroundColor="#F0B63D" backgroundColor="#202932" zPosition="9"/>
    <widget name="cacheFocus" position="1492,586" size="346,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings_cache_focus_r223.png" alphatest="blend" zPosition="10"/>
    <widget name="cacheTitle" position="1500,558" size="330,24" font="Regular;16" foregroundColor="#90A0AE" transparent="1" zPosition="9"/>
    <widget name="cacheStorage" position="1503,591" size="324,34" font="Regular;18" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="cacheInfo" position="1500,632" size="330,24" font="Regular;15" foregroundColor="#A9B5BF" transparent="1" zPosition="9"/>
    <widget name="cacheClear" position="1503,668" size="324,34" font="Regular;18" foregroundColor="#FF7676" transparent="1" valign="center" zPosition="11"/>
    <widget name="connectionsText" position="1500,722" size="330,28" font="Regular;17" foregroundColor="#4EB8FF" transparent="1" zPosition="9"/>
    <widget name="ipText" position="1500,756" size="330,27" font="Regular;16" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <widget name="uptimeText" position="1500,788" size="330,27" font="Regular;16" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <eLabel position="1500,826" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="serverDetail" position="1500,844" size="330,92" font="Regular;16" foregroundColor="#D9E1E8" transparent="1" valign="top" zPosition="9"/>
</screen>"""

class SettingsDashboard(Screen):
    skin = SETTINGS_DASHBOARD_SKIN
    ITEMS=[("servers","Server & Playlists"),("skin","Skin & Poster View"),("subtitle","Subtitle"),("backup","Backup & System"),("tmdb","TMDb Settings")]
    def __init__(self,session):
        Screen.__init__(self,session); self.index=0; self.focusZone="cards"
        self.languageIndex={"en":0,"ar":1,"fr":2,"tr":3}.get(get_language(),0)
        for i in range(5): self["focus%d"%i]=Pixmap()
        for i in range(4): self["langFocus%d"%i]=Pixmap()
        self["statusTitle"]=Label("SERVER STATUS")
        for n in ("serverName","serverType","serverState","expiryText","serverCount","favoriteCount","bouquetCount","ramText","cpuText","storageText","connectionsText","ipText","uptimeText","serverDetail","cacheTitle","cacheStorage","cacheInfo","cacheClear"): self[n]=Label("")
        self["serverTypeIcon"]=Pixmap()
        self["cacheFocus"]=Pixmap()
        self["ramBar"]=ProgressBar(); self["cpuBar"]=ProgressBar(); self["storageBar"]=ProgressBar()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{"ok":self.openCurrent,"cancel":self.close,"red":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,"green":self.openAddServer,"yellow":self.openServerHub,"blue":self.refreshStatus},-1)
        self._timer=eTimer(); _connect_timer(self._timer,self.refreshStatus); self._lastCpu=None
        self.cacheIndex=0; self._cacheStatusAt=0.0; self._cacheSize=0; self._cacheFiles=0
        self.onLayoutFinish.append(self._ready); self.onClose.append(self._cleanup)
    def _ready(self):
        self._focus(); self.refreshStatus()
        try:self._timer.start(3000,False)
        except Exception:pass
    def _cleanup(self):
        try:self._timer.stop()
        except Exception:pass
    def _focus(self):
        for i in range(5):
            try:self["focus%d"%i].hide()
            except Exception:pass
            try:self["langFocus%d"%i].hide()
            except Exception:pass
        try:self["cacheFocus"].hide()
        except Exception:pass
        if self.focusZone == "language":
            try:self["langFocus%d"%self.languageIndex].show()
            except Exception:pass
        elif self.focusZone == "cache":
            try:
                y=586 if self.cacheIndex==0 else 663
                self["cacheFocus"].instance.move(ePoint(sx(1492),sy(y)))
                self["cacheFocus"].show()
            except Exception:pass
        else:
            try:self["focus%d"%self.index].show()
            except Exception:pass
    def left(self):
        if self.focusZone == "language": self.languageIndex=(self.languageIndex-1)%4
        elif self.focusZone == "cache":
            self.focusZone="cards"; self.index=1 if self.cacheIndex==0 else 3
        else:
            if self.index == 4: return
            self.index=self.index-1 if self.index%2 else self.index+1
        self._focus()
    def right(self):
        if self.focusZone == "language": self.languageIndex=(self.languageIndex+1)%4
        elif self.focusZone == "cache": return
        elif self.index in (1,3):
            self.focusZone="cache"; self.cacheIndex=0 if self.index==1 else 1
        elif self.index == 4: return
        else: self.index=self.index+1
        self._focus()
    def up(self):
        if self.focusZone == "language": return
        if self.focusZone == "cache":
            self.cacheIndex=max(0,self.cacheIndex-1); self._focus(); return
        if self.index < 2: self.focusZone="language"
        elif self.index == 4: self.index=2
        else: self.index-=2
        self._focus()
    def down(self):
        if self.focusZone == "language":
            self.focusZone="cards"; self.index=0
        elif self.focusZone == "cache":
            self.cacheIndex=min(1,self.cacheIndex+1)
        elif self.index < 2: self.index+=2
        elif self.index in (2,3): self.index=4
        self._focus()
    @staticmethod
    def _read(path,default=""):
        try:
            with open(path,"r") as h:return h.read().strip()
        except Exception:return default
    def _memory(self):
        vals={}
        try:
            with open("/proc/meminfo","r") as h:
                for line in h:
                    if ":" in line:
                        k,v=line.split(":",1); vals[k]=int(v.strip().split()[0])
        except Exception:pass
        total=int(vals.get("MemTotal",0)); avail=int(vals.get("MemAvailable",vals.get("MemFree",0))); used=max(0,total-avail); pct=int(round(100.0*used/total)) if total else 0
        return total,avail,pct
    def _cpu_usage(self):
        try:
            vals=[int(x) for x in self._read("/proc/stat","").splitlines()[0].split()[1:]]; idle=vals[3]+(vals[4] if len(vals)>4 else 0); total=sum(vals); now=(idle,total)
            if self._lastCpu is None:self._lastCpu=now; return 0
            idle_d=idle-self._lastCpu[0]; total_d=total-self._lastCpu[1]; self._lastCpu=now
            return max(0,min(100,int(round(100.0*(1.0-idle_d/float(total_d)))))) if total_d>0 else 0
        except Exception:return 0
    def _storage(self):
        try:
            target="/media/hdd" if os.path.ismount("/media/hdd") else "/"; st=os.statvfs(target); total=float(st.f_blocks*st.f_frsize); free=float(st.f_bavail*st.f_frsize); used=max(0.0,total-free); pct=int(round(100.0*used/total)) if total else 0; return total,free,pct
        except Exception:return 0.0,0.0,0
    def _ip(self):
        try:
            import socket; sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            try:sock.connect(("8.8.8.8",80)); return sock.getsockname()[0]
            finally:sock.close()
        except Exception:return "n/a"
    def _uptime(self):
        try:
            sec=int(float(self._read("/proc/uptime","0").split()[0])); d,r=divmod(sec,86400); h,r=divmod(r,3600); m=r//60; return ("%dd %dh %dm"%(d,h,m)) if d else ("%dh %dm"%(h,m))
        except Exception:return "n/a"
    def _connections(self):
        c=0
        for p in ("/proc/net/tcp","/proc/net/tcp6"):
            try:
                for line in self._read(p,"").splitlines()[1:]:
                    cols=line.split(); c += 1 if len(cols)>3 and cols[3]=="01" else 0
            except Exception:pass
        return c
    def _cacheDisplay(self):
        cfg=get_cache_settings() or {}; loc=str(cfg.get("location") or "auto").lower()
        labels={"hdd":"HDD","usb":"USB","internal":"INTERNAL","auto":"AUTO","mmc":"MMC","tmp":"TMP"}
        self["cacheTitle"].setText("CACHE STORAGE")
        self["cacheStorage"].setText("%s   •   OK to change" % labels.get(loc,loc.upper()))
        self["cacheClear"].setText("CLEAR CACHE   •   OK")
        try:
            root=get_cache_root(); st=os.statvfs(root); free=float(st.f_bavail*st.f_frsize)/(1024.0**3)
        except Exception:
            root=""; free=0.0
        now=time.time()
        if (not self._cacheStatusAt) or now-self._cacheStatusAt>60:
            try:
                _r,size,files=cache_status(); self._cacheSize=size; self._cacheFiles=files; self._cacheStatusAt=now
            except Exception:pass
        self["cacheInfo"].setText("Cache %.1f MB   •   Free %.1f GB" % (float(self._cacheSize)/1048576.0, free))
    def _openCacheStorage(self):
        cfg=get_cache_settings() or {}; current=str(cfg.get("location") or "hdd").lower()
        if current not in ("hdd","usb","internal"): current="hdd"
        self.session.openWithCallback(self._cacheStorageSelected, CacheStoragePicker, current)
    def _cacheStorageSelected(self, value=None):
        if value not in ("hdd","usb","internal"): return
        cfg=get_cache_settings() or {}
        if save_cache_settings(value,0,int(cfg.get("retention_days",0) or 0)):
            self._cacheStatusAt=0.0; self._cacheDisplay()
            self.session.open(MessageBox, "Cache storage saved. New cached files will use %s." % value.upper(), MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to save cache storage.", MessageBox.TYPE_ERROR)
    def _askClearCache(self):
        self.session.openWithCallback(self._clearCacheConfirmed, MessageBox, "Are you sure you want to clear the cache?", type=MessageBox.TYPE_YESNO, default=False)
    def _clearCacheConfirmed(self, answer=False):
        if not answer:return
        ok=clear_cache()
        if ok:
            try:clear_catalog_memory()
            except Exception:pass
            self._cacheStatusAt=0.0; self._cacheSize=0; self._cacheFiles=0; self._cacheDisplay()
            self.session.open(MessageBox, "Cache cleared successfully.", MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to clear cache.", MessageBox.TYPE_ERROR)

    @staticmethod
    def _formatDashboardExpiry(value):
        raw = str(value or "").strip()
        low = raw.lower()
        if not raw or low in ("0", "none", "null", "—"):
            return "—"
        if low in ("unlimited", "never", "lifetime"):
            return "Unlimited"
        try:
            num = float(raw)
            if num > 100000000000:
                num /= 1000.0
            if num > 1000000000:
                return time.strftime("%d %b %Y", time.localtime(num))
        except Exception:
            pass
        for fmt, size in (("%Y-%m-%d %H:%M:%S",19),("%Y-%m-%d",10),("%d/%m/%Y",10),("%d-%m-%Y",10)):
            try:
                dt = datetime.strptime(raw[:size], fmt)
                return dt.strftime("%d %b %Y")
            except Exception:
                pass
        return raw[:22]

    def _setDashboardType(self, active):
        stype = str((active or {}).get("type") or "").strip().lower()
        labels = {"xtream":"Xtream", "stalker":"Stalker", "m3u":"M3U", "fg":"M3U"}
        icons = {
            "xtream": os.path.join(PLUGIN_PATH,"skins","icon_xtream_r123.png"),
            "stalker": os.path.join(PLUGIN_PATH,"skins","icon_stalker_r123.png"),
            "m3u": os.path.join(PLUGIN_PATH,"skins","icon_m3u_r123.png"),
            "fg": os.path.join(PLUGIN_PATH,"skins","icon_m3u_r123.png"),
        }
        self["serverType"].setText(labels.get(stype, "IPTV" if stype else "NOT CONFIGURED"))
        try:
            path = icons.get(stype)
            if path and os.path.exists(path):
                self["serverTypeIcon"].instance.setPixmapFromFile(path)
                self["serverTypeIcon"].show()
            else:
                self["serverTypeIcon"].hide()
        except Exception:
            try:self["serverTypeIcon"].hide()
            except Exception:pass

    def refreshStatus(self):
        sources=list(get_sources() or []); active=sources[0] if sources else {}
        if active:
            self["serverName"].setText(str(active.get("name") or "Server")[:22])
            self._setDashboardType(active)
            self["serverState"].setText("CONNECTED")
            expiry=str(active.get("_last_expiry") or active.get("expiry") or active.get("exp_date") or "").strip()
            self["expiryText"].setText("Expires: %s" % self._formatDashboardExpiry(expiry))
        else:
            self["serverName"].setText("No server")
            self._setDashboardType({})
            self["serverState"].setText("")
            self["expiryText"].setText("Expires: —")
        self["serverCount"].setText("%d\nSERVERS"%len(sources))
        try:fav=int(favourites_count() or 0)
        except Exception:fav=0
        self["favoriteCount"].setText("%d\nFAVORITES"%fav)
        try:bq=len([x for x in os.listdir("/etc/enigma2") if x.startswith("userbouquet.") and x.endswith(".tv")])
        except Exception:bq=0
        self["bouquetCount"].setText("%d\nBOUQUETS"%bq)
        total,free,ram=self._memory(); self["ramText"].setText("RAM Usage  %d%%   •   Free %d MB"%(ram,free//1024 if free else 0)); self["ramBar"].setValue(ram)
        cpu=self._cpu_usage(); self["cpuText"].setText("CPU Usage  %d%%"%cpu); self["cpuBar"].setValue(cpu)
        tb,fb,sp=self._storage(); self["storageText"].setText("Storage  %d%%   •   Free %.1f GB"%(sp,fb/(1024**3) if fb else 0)); self["storageBar"].setValue(sp)
        self._cacheDisplay()
        self["connectionsText"].setText("Connections  %d Active"%self._connections()); self["ipText"].setText("IP Address  %s"%self._ip()); self["uptimeText"].setText("Uptime  %s"%self._uptime())
        if active:
            host=str(active.get("url") or active.get("host") or active.get("server") or active.get("portal") or ""); details=[]
            local_path=str(active.get("path") or "")
            if host: details.append("Host: %s"%host.replace("http://","").replace("https://","").split("/")[0][:34])
            elif local_path: details.append("Source: Imported M3U")
            details.append("Type: %s"%str(active.get("type") or "").upper())
            self["serverDetail"].setText("\n".join(details))
        else:self["serverDetail"].setText("Press GREEN to add a server.")
    def openAddServer(self): self.session.openWithCallback(self._sourceType,SourceTypePicker)
    def _sourceType(self,t=None):
        if t=="xtream":self.session.open(PlaylistEditor,None)
        elif t=="stalker":self.session.open(StalkerPortalEditor,None)
        elif t=="m3u":self.session.open(M3UPlaylistEditor,None)
    def openServerHub(self): self.session.open(ServerHub)
    def openCurrent(self):
        if self.focusZone == "cache":
            if self.cacheIndex==0:self._openCacheStorage()
            else:self._askClearCache()
            return
        if self.focusZone == "language":
            code=("en","ar","fr","tr")[self.languageIndex]
            if save_language(code):
                try:self.session.open(MessageBox, "Language saved. Reopen the app to apply it.", MessageBox.TYPE_INFO, timeout=3)
                except Exception:pass
            return
        a=self.ITEMS[self.index][0]
        if a=="servers": self.session.open(ServerHub); return
        if a=="skin": self.session.open(HomeAppearanceSettings); return
        if a=="subtitle": self.session.open(SubtitleDashboard); return
        if a=="backup": self.session.open(BackupRestoreScreen); return
        if a=="tmdb": self.session.open(TMDbSettings); return
class ServerManager(Screen):
    skin = SERVER_MANAGER_SKIN
    NAV_X = [450, 603, 756, 909, 1062, 1215]

    def __init__(self, session, selectCallback=None):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        self["settingsSideTitle"].setText(tr("SERVERS & WEB"))
        self["settingsSideText"].setText(tr("Manage IPTV servers,\nStalker / Xtream and\nmobile Web Control."))
        self["settingsSideHint"].setText(tr("Press 4 WEB QR\nPress 7 BACKUP & RESTORE\nPress 8 SETTINGS (NEW)"))
        self.selectCallback = selectCallback
        self.sources = []
        self._serverStates = {}
        self._serverExpiries = {}
        self._statusResult = None
        self._statusToken = 0
        self._statusClosed = False
        self.settingsFocus = "list"
        self.settingsNavIndex = 5
        self.languageIndex = {"en": 0, "ar": 1, "fr": 2}.get(get_language(), 0)
        self["title"] = Label(tr("SETTINGS  •  SERVER MANAGER"))
        self["config"] = ServerStatusList()
        self["languageTitle"] = Label(tr("APPLICATION LANGUAGE"))
        self["languageSelector"] = Pixmap()
        self["language0"] = Label(tr("English"))
        self["language1"] = Label(tr("Arabic"))
        self["language2"] = Label(tr("French"))
        self["languageRadio0"] = Pixmap()
        self["languageRadio1"] = Pixmap()
        self["languageRadio2"] = Pixmap()
        self["serverStatusTitle"] = Label(tr("SERVER STATUS  •  CONNECTION & ACTIVE USE"))
        self["serverStatusText"] = Label(tr("Yellow appears only when the server reports active use."))
        self["statusLegendOnlineIcon"] = Pixmap()
        self["statusLegendOnline"] = Label(tr("ONLINE"))
        self["statusLegendCheckingIcon"] = Pixmap()
        self["statusLegendChecking"] = Label(tr("IN USE"))
        self["statusLegendOfflineIcon"] = Pixmap()
        self["statusLegendOffline"] = Label(tr("OFFLINE"))
        self["hint"] = Label(tr("BLUE  CHOOSE SERVER & FILTER   •   0  TEST SERVER   •   4 WEB QR   •   8 SETTINGS"))
        self["settingsNewButton"] = Label("SETTINGS (NEW)  ▶")
        self["keys"] = Label("")
        self._statusTimer = eTimer()
        _connect_timer(self._statusTimer, self._finishStatusRefresh)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions", "MenuActions", "NumberActions"], {
            "ok": self.ok, "cancel": self.close, "green": self.addSource,
            "yellow": self.editSource, "red": self.delSource, "blue": self.openFilter,
            "menu": self.openTMDb, "0": self.testSource, "1": self.openCacheSettings, "2": self.openAppearanceSettings, "3": self.openUpdateSettings, "4": self.openWebAccess, "5": self.openSubDLSettingsMenu, "6": self.openAppearanceSettings, "7": self.openBackupRestore, "8": self.openSettingsDashboard,
            "up": self.up, "down": self.down, "left": self.left, "right": self.right
        }, -1)
        self.onLayoutFinish.append(self._settingsLayoutReady)
        self.onLayoutFinish.append(self._startStatusRefresh)
        self.onClose.append(self._stopStatusRefresh)
        self.reload()

    def _settingsLayoutReady(self):
        self._statusReady = True
        try:
            self["settingsGuide"].hide()
        except Exception:
            pass
        try:
            self["settingsActionButtons"].show()
        except Exception:
            pass
        self._updateSettingsFocus()

    def _updateSettingsFocus(self):
        try:
            if self["settingsNavSelector"].instance:
                self["settingsNavSelector"].instance.move(ePoint(sx(self.NAV_X[self.settingsNavIndex]), sy(27)))
            self["settingsNavSelector"].show() if self.settingsFocus == "nav" else self["settingsNavSelector"].hide()
        except Exception:
            pass
        try:
            self["settingsNewButton"].setText(
                u"▶  SETTINGS (NEW)  ◀" if self.settingsFocus == "newsettings"
                else u"SETTINGS (NEW)  ▶"
            )
            self["settingsNewButton"].instance.setForegroundColor(
                parseColor("#FFFFFF" if self.settingsFocus == "newsettings" else "#F1C84C")
            )
        except Exception:
            pass
        try:
            if self["languageSelector"].instance:
                self["languageSelector"].instance.move(ePoint(sx(124), sy(492 + (self.languageIndex * 64))))
            self["languageSelector"].show() if self.settingsFocus == "language" else self["languageSelector"].hide()
            radio_on = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/language_radio_on_r64.png"))
            radio_off = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/language_radio_off_r64.png"))
            for i in range(3):
                widget = self["languageRadio%d" % i]
                if widget.instance:
                    widget.instance.setPixmap(radio_on if i == self.languageIndex else radio_off)
        except Exception:
            pass

    def up(self):
        if self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
            self.languageIndex = 2
        elif self.settingsFocus == "language":
            self.languageIndex = (self.languageIndex - 1) % 3
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        else:
            try:
                at_top = self["config"].getSelectedIndex() <= 0
            except Exception:
                at_top = True
            if at_top:
                self.settingsFocus = "nav"
            else:
                self["config"].up()
        self._updateSettingsFocus()

    def down(self):
        if self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
            self.languageIndex = 0
        elif self.settingsFocus == "language":
            if self.languageIndex >= 2:
                self.settingsFocus = "newsettings"
            else:
                self.languageIndex += 1
        elif self.settingsFocus == "nav":
            self.settingsFocus = "list"
        else:
            self["config"].down()
        self._updateSettingsFocus()

    def left(self):
        if self.settingsFocus == "list":
            self.settingsFocus = "language"
        elif self.settingsFocus == "language":
            self.settingsFocus = "newsettings"
        elif self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex - 1) % len(self.NAV_X)
        self._updateSettingsFocus()

    def right(self):
        if self.settingsFocus == "newsettings":
            self.settingsFocus = "language"
        elif self.settingsFocus == "language":
            self.settingsFocus = "list"
        elif self.settingsFocus == "nav":
            self.settingsNavIndex = (self.settingsNavIndex + 1) % len(self.NAV_X)
        self._updateSettingsFocus()

    def ok(self):
        if self.settingsFocus == "newsettings":
            self.openSettingsDashboard(); return
        if self.settingsFocus == "language":
            code = ("en", "ar", "fr")[self.languageIndex]
            if save_language(code):
                self.session.open(MessageBox, tr("Language saved. Reopen the app to apply it."), MessageBox.TYPE_INFO, timeout=5); return
            self.session.open(MessageBox, tr("Unable to save settings."), MessageBox.TYPE_ERROR); return
        if self.settingsFocus == "nav":
            self.openTopMenu(); return
        self.select(); return

    def openTopMenu(self):
        index = self.settingsNavIndex
        if index == 5:
            self.settingsFocus = "list"
            self._updateSettingsFocus(); return
        source = self.current()
        if index == 1:
            self.session.open(TiviMateE2Home); return
        if not source:
            self.session.open(MessageBox, "Select a server first.", MessageBox.TYPE_INFO); return
        if index == 0:
            self.session.open(TiviMateE2Search, source); return
        if index == 2 and source.get("type") in ("xtream", "stalker", "m3u", "fg"):
            self.session.open(MediaScreen, source, "live"); return
        if index == 3 and source.get("type") in ("xtream", "stalker"):
            self.session.open(ContentHomeScreen, source, "vod"); return
        if index == 4 and source.get("type") in ("xtream", "stalker"):
            self.session.open(ContentHomeScreen, source, "series"); return
        self.session.open(MessageBox, "The selected source does not provide this section.", MessageBox.TYPE_INFO); return

    def openTMDb(self):
        self.session.open(TMDbSettings)

    def openCacheSettings(self):
        self.session.open(ImageCacheSettings)

    def openAppearanceSettings(self):
        self.session.open(HomeAppearanceSettings)

    def openUpdateSettings(self):
        self.session.open(UpdateSettingsScreen)

    def openWebAccess(self):
        self.session.open(WebAccessScreen)

    def openBackupRestore(self):
        self.session.open(BackupRestoreScreen)

    def openSettingsDashboard(self):
        self.session.open(SettingsDashboard)

    def openSubDLSubtitleLanguage(self):
        self.session.open(SubDLSubtitleLanguageSettings)

    def openServerSubtitleFont(self):
        """Change Enigma2's native/server subtitle font size.

        This writes config.subtitles.subtitle_fontsize, the same receiver-owned
        setting used by InfoBarSubtitleSupport. It does not touch SubsSupport.
        """
        try:
            subtitles = getattr(config, "subtitles", None)
            setting = getattr(subtitles, "subtitle_fontsize", None) if subtitles is not None else None
            if setting is None:
                raise RuntimeError("native subtitle font setting unavailable")

            current = str(getattr(setting, "value", "") or "")
            sizes = []
            try:
                choices = getattr(setting, "choices", None) or []
                for entry in choices:
                    value = entry[0] if isinstance(entry, (tuple, list)) else entry
                    value = str(value)
                    if value.isdigit() and value not in sizes:
                        sizes.append(value)
            except Exception:
                sizes = []
            if not sizes:
                sizes = [str(x) for x in range(16, 50, 2)]

            choices = []
            for value in sizes:
                label = "%s px%s" % (value, "  •  Current" if value == current else "")
                choices.append((label, value))
            self.session.openWithCallback(
                self._serverSubtitleFontSelected,
                ChoiceBox,
                title="SERVER SUBTITLE FONT  •  ENIGMA2",
                list=choices,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Native Enigma2 subtitle font settings are not available on this image.",
                MessageBox.TYPE_ERROR,
                timeout=6,
            )

    def _serverSubtitleFontSelected(self, choice=None):
        if not choice:
            return
        try:
            value = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
            setting = config.subtitles.subtitle_fontsize
            setting.value = str(value)
            try:
                setting.save()
            except Exception:
                pass
            try:
                configfile.save()
            except Exception:
                pass
            self.session.open(
                MessageBox,
                "Server subtitle font size saved: %s" % value,
                MessageBox.TYPE_INFO,
                timeout=3,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Could not save the native subtitle font size.",
                MessageBox.TYPE_ERROR,
                timeout=5,
            )

    def openSubDLSubtitleFont(self):
        """Open the external-SRT font configuration owned by SubsSupport."""
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings, SubsSetupExternal
            settings = initSubsSettings()
            external = getattr(settings, "external", None)
            if external is None:
                raise RuntimeError("missing external subtitle settings")
            self.session.open(SubsSetupExternal, external); return
        except ImportError:
            self.session.open(
                MessageBox,
                "Font settings require SubsSupport. Install or update SubsSupport from your receiver plugin feed, then open 5 > Font again.",
                MessageBox.TYPE_INFO,
                timeout=7,
            ); return
        except Exception:
            try:
                from Plugins.Extensions.SubsSupport.plugin import openSubsSupportSettings
                return openSubsSupportSettings(self.session)
            except Exception:
                self.session.open(
                    MessageBox,
                    "Could not open the SubsSupport font settings on this receiver image.",
                    MessageBox.TYPE_ERROR,
                    timeout=7,
                ); return

    def openSubDLSettingsMenu(self):
        """Show the agreed Import, Language and Font actions under settings key 5."""
        current = load_subdl_settings()
        language_code = current.get("language", "ar")
        language_name = dict((code, name) for name, code in SUBDL_LANGUAGE_CHOICES).get(language_code, language_code)
        choices = [
            ("Import SubDL API Key  •  HDD / USB / MMC / etc", "import"),
            ("Subtitle Language  •  %s" % language_name, "language"),
            ("Server Subtitle Font  •  Enigma2 Native", "server_font"),
            ("External Subtitle Font  •  SubsSupport / SubDL", "font"),
        ]
        self.session.openWithCallback(
            self._subdlSettingsSelected,
            ChoiceBox,
            title="SUBDL SETTINGS  •  IMPORT / LANGUAGE / FONT",
            list=choices,
        )

    def _subdlSettingsSelected(self, choice=None):
        if not choice:
            return
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == "import":
            return self.importSubDLKey()
        if action == "language":
            return self.openSubDLSubtitleLanguage()
        if action == "server_font":
            return self.openServerSubtitleFont()
        if action == "font":
            return self.openSubDLSubtitleFont()

    def importSubDLKey(self):
        """Import the local SubDL key while preserving the chosen language and type."""
        try:
            value = _read_subdl_import_key()
            current = load_subdl_settings()
            save_subdl_settings(
                value,
                current.get("language", "ar"),
                current.get("kind", "standard"),
            )
            removed = _remove_subdl_import_file()
            message = (
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Press 5 and choose SubDL Subtitle Language. Remove the imported key file manually to protect your key."
            )
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=6)
        except IOError:
            self.session.open(
                MessageBox,
                "Put one SubDL API key in key.txt on HDD/USB/MMC or /etc/enigma2, then press 5 and choose Import SubDL API Key.",
                MessageBox.TYPE_INFO,
                timeout=7,
            )
        except ValueError:
            self.session.open(
                MessageBox,
                "Invalid SubDL key file. It must contain exactly one SubDL API key.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )
        except Exception:
            self.session.open(
                MessageBox,
                "Could not import the SubDL key from /tmp/tivimatee2/key.txt.",
                MessageBox.TYPE_ERROR,
                timeout=7,
            )

    def openFilter(self):
        # BLUE always starts by choosing the server. This makes filtering
        # accessible even when focus is on language/nav/new-settings rather
        # than on the server list itself.
        compatible=[]
        current=self.current()
        current_key=self._sourceKey(current) if current else ""
        for source in list(get_sources() or []):
            if not isinstance(source,dict):
                continue
            if str(source.get("type") or "").lower() not in ("xtream","stalker"):
                continue
            name=ServerStatusList._display_name(source)
            stype=str(source.get("type") or "").upper()
            prefix="✓ " if current_key and self._sourceKey(source)==current_key else ""
            compatible.append(("%s%s  [%s]" % (prefix,name,stype),dict(source)))

        if not compatible:
            self.session.open(
                MessageBox,
                "No Xtream or Stalker server is available for filtering.",
                MessageBox.TYPE_INFO,
                timeout=5
            )
            return

        if len(compatible)==1:
            self.session.openWithCallback(
                self._filterClosed,
                ServerCategoryFilter,
                compatible[0][1]
            )
            return

        self.session.openWithCallback(
            self._filterServerSelected,
            ChoiceBox,
            title="SELECT SERVER TO FILTER",
            list=compatible
        )

    def _filterServerSelected(self, choice=None):
        if not choice:
            return
        try:
            source=choice[1]
        except Exception:
            return
        if not isinstance(source,dict):
            return
        self.session.openWithCallback(
            self._filterClosed,
            ServerCategoryFilter,
            source
        )

    def _filterClosed(self, changed=None):
        if not changed:
            return
        # Redraw manager state after filter save; content screens will consume
        # the new allowed-category set on their next load.
        try:
            clear_catalog_memory()
        except Exception:
            pass
        try:
            self.reload()
        except Exception:
            pass

    def _sourceKey(self, source):
        return ServerStatusList._key(source)

    def _displaySources(self):
        """Show only real user servers; SubDL actions live under settings key 5."""
        return list(self.sources)

    def _refreshSourceRows(self):
        """Redraw server status while preserving the selected real server."""
        selected_key = None
        try:
            current = self.current()
            selected_key = self._sourceKey(current) if current else None
        except Exception:
            pass
        display_sources = self._displaySources()
        self["config"].setSources(display_sources, self._serverStates, self._serverExpiries)
        if selected_key:
            for index, source in enumerate(display_sources):
                if self._sourceKey(source) == selected_key:
                    try:
                        self["config"].moveToIndex(index)
                    except Exception:
                        pass
                    break

    def _updateStatusCard(self):
        total = len(self.sources)
        if not total:
            text = "Add a playlist to see connection and active-use status."
        else:
            checking = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source), "checking") == "checking"])
            online = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "online"])
            busy = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "busy"])
            offline = len([source for source in self.sources if self._serverStates.get(self._sourceKey(source)) == "offline"])
            if checking:
                text = "Checking %d server%s in the background…" % (checking, "" if checking == 1 else "s")
            else:
                text = "%d ready  •  %d in use  •  %d offline  •  BLUE: filter selected server" % (online, busy, offline)
        try:
            self["serverStatusText"].setText(text)
        except Exception:
            pass

    def _connectionTest(self, source):
        """Return privacy-safe server state plus subscription expiry when supplied."""
        try:
            source_type = source.get("type")
            if source_type == "xtream":
                reply = XtreamClient(source).test()
            elif source_type in ("m3u", "fg"):
                reply = M3UClient(source).test()
            else:
                reply = StalkerClient(source).test()
            report = evaluate_reply(source_type, reply)
            expiry = ""
            if source_type == "xtream" and isinstance(reply, dict):
                user_info = reply.get("user_info") if isinstance(reply.get("user_info"), dict) else {}
                expiry = user_info.get("exp_date") or reply.get("exp_date") or ""
            elif source_type == "stalker" and isinstance(reply, dict):
                expiry = reply.get("expiry") or ""
            report["expiry"] = str(expiry or "")
            return report, ""
        except Exception as exc:
            return {"state": "offline", "active_connections": None, "max_connections": None, "usage_reported": False, "expiry": ""}, str(exc)

    def _startStatusRefresh(self):
        if self._statusClosed or self._statusResult is not None:
            return
        self._statusToken += 1
        token = self._statusToken
        sources = [dict(source) for source in self.sources]
        self._serverStates = {self._sourceKey(source): "checking" for source in sources}
        self._refreshSourceRows()
        self._updateStatusCard()
        if not sources:
            return

        def worker():
            states = {}
            expiries = {}
            for source in sources:
                report, _error = self._connectionTest(source)
                key = self._sourceKey(source)
                states[key] = report.get("state", "offline")
                expiries[key] = report.get("expiry") or ""
            self._statusResult = (token, states, expiries)

        thread = threading.Thread(target=worker, name="TiviMateServerStatus")
        thread.daemon = True
        thread.start()
        try:
            self._statusTimer.start(120, False)
        except Exception:
            pass

    def _finishStatusRefresh(self):
        result = self._statusResult
        if not result:
            try:
                self._statusTimer.start(120, False)
            except Exception:
                pass
            return
        self._statusResult = None
        token, states, expiries = result
        if self._statusClosed or token != self._statusToken:
            return
        self._serverStates.update(states)
        self._serverExpiries.update(expiries)
        try:
            changed = False
            for source in self.sources:
                key = self._sourceKey(source)
                if key in states:
                    source["_last_status"] = states.get(key) or "offline"
                    source["_last_status_at"] = int(time.time())
                    new_expiry = str(expiries.get(key) or "").strip()
                    if new_expiry:
                        source["_last_expiry"] = new_expiry
                    changed = True
            if changed:
                set_sources(self.sources)
        except Exception:
            pass
        self._refreshSourceRows()
        self._updateStatusCard()

    def _stopStatusRefresh(self):
        self._statusClosed = True
        self._statusToken += 1
        try:
            self._statusTimer.stop()
        except Exception:
            pass

    def reload(self):
        self.sources = get_sources()
        keys = set([self._sourceKey(source) for source in self.sources])
        self._serverStates = {key: state for key, state in self._serverStates.items() if key in keys}
        self._serverExpiries = {key: value for key, value in self._serverExpiries.items() if key in keys}
        for source in self.sources:
            self._serverStates.setdefault(self._sourceKey(source), "checking")
        self._refreshSourceRows()
        self._updateStatusCard()
        if getattr(self, "_statusReady", False):
            self._startStatusRefresh()

    def current(self):
        row = self["config"].getCurrent()
        return row[0] if row else None

    def select(self):
        source = self.current()
        if not source:
            return
        if self.selectCallback:
            self.selectCallback(source)
            self.close()
            return

        # Selecting a server means selecting ONE Movies / TV Shows source.
        # Never open the old intermediary MOVIES / TV SHOWS screen.
        try:
            active_file = data_path("active_source.json")
            ensure_dir(os.path.dirname(active_file))
            key = "%s|%s|%s|%s" % (
                source.get("type", ""),
                source.get("url", "").rstrip("/"),
                source.get("username", ""),
                source.get("mac", "")
            )
            with open_text(active_file, "w") as handle:
                json.dump({"key": key}, handle)
        except Exception:
            pass
        self.close()

    def addSource(self):
        self.session.openWithCallback(self._chooseSourceType, SourceTypePicker)

    def _chooseSourceType(self, source_type=None):
        if source_type == "xtream":
            self.session.openWithCallback(self._saveNew, PlaylistEditor, None)
        elif source_type == "stalker":
            self.session.openWithCallback(self._saveNew, StalkerPortalEditor, None)
        elif source_type == "m3u":
            self.session.openWithCallback(self._saveNew, M3UPlaylistEditor, None)

    @staticmethod
    def _storageSourceKey(source):
        source = source or {}
        return "%s|%s|%s|%s" % (
            source.get("type", ""),
            (source.get("url") or source.get("path") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
            source.get("username", ""),
            source.get("mac", ""),
        )

    def _saveNew(self, source=None):
        if not isinstance(source, dict):
            return
        srcs = get_sources()

        # Group Stalker MACs under an existing portal when possible.
        if source.get("type") == "stalker":
            portal = str(source.get("url") or "").rstrip("/").lower()
            incoming = list(source.get("macs") or [])
            if incoming:
                srcs = [
                    item for item in srcs
                    if not (
                        item.get("type") == "stalker" and
                        str(item.get("url") or "").rstrip("/").lower() == portal
                    )
                ]
                srcs.append(source)
            else:
                srcs.append(source)
        else:
            srcs.append(source)

        set_sources(srcs)
        write_playlists(srcs)
        self.reload()
        self.session.open(MessageBox, "Server saved.", MessageBox.TYPE_INFO, timeout=3)

    def editSource(self):
        source = self.current()
        if not source:
            return
        try:
            source_index = int(self["config"].getSelectedIndex())
        except Exception:
            source_index = -1
        callback = lambda edited=None: self._replaceAt(source_index, source, edited)
        if source.get("type") == "xtream":
            self.session.openWithCallback(callback, PlaylistEditor, source); return
        if source.get("type") == "stalker":
            self.session.openWithCallback(callback, StalkerPortalEditor, source); return
        if source.get("type") == "m3u":
            self.session.openWithCallback(callback, M3UPlaylistEditor, source); return
        self.session.open(MessageBox, "This source type cannot be edited here.", MessageBox.TYPE_INFO); return

    def _replaceAt(self, source_index, old, new=None):
        if not isinstance(new, dict):
            return
        srcs = get_sources()
        replaced_index = -1
        if 0 <= source_index < len(srcs):
            candidate = srcs[source_index]
            if self._storageSourceKey(candidate) == self._storageSourceKey(old) or candidate == old:
                srcs[source_index] = new
                replaced_index = source_index
        if replaced_index < 0:
            old_key = self._storageSourceKey(old)
            for i, item in enumerate(srcs):
                if item == old or self._storageSourceKey(item) == old_key:
                    srcs[i] = new
                    replaced_index = i
                    break
        if replaced_index < 0:
            srcs.append(new)
            replaced_index = len(srcs) - 1
        set_sources(srcs)
        write_playlists(srcs)
        self.reload()
        try:
            self["config"].moveToIndex(replaced_index)
        except Exception:
            pass
        self.session.open(MessageBox, "Name and settings saved.", MessageBox.TYPE_INFO, timeout=3)

    def delSource(self):
        source = self.current()
        if not source:
            return
        srcs = [x for x in get_sources() if x != source]
        set_sources(srcs); write_playlists(srcs)
        self.reload()

    def testSource(self):
        source = self.current()
        if not source:
            return
        key = self._sourceKey(source)
        self._serverStates[key] = "checking"
        self._refreshSourceRows()
        self._updateStatusCard()

        if source.get("type") == "stalker":
            source_copy = dict(source)
            def worker():
                try:
                    details = StalkerClient(source_copy).test()
                except Exception as exc:
                    details = {"ok": False, "error": str(exc), "quick_test": True}

                def done():
                    try:
                        state = "online" if details.get("ok") else "offline"
                        self._serverStates[key] = state
                        self._serverExpiries[key] = details.get("expiry") or ""
                        try:
                            for saved_source in self.sources:
                                if self._sourceKey(saved_source) == key:
                                    saved_source["_last_status"] = state
                                    saved_source["_last_status_detail"] = str(details.get("error") or "")[:160]
                                    saved_source["_last_status_at"] = int(time.time())
                                    if details.get("expiry"):
                                        saved_source["_last_expiry"] = str(details.get("expiry"))
                                    break
                            set_sources(self.sources)
                        except Exception:
                            pass
                        self._refreshSourceRows()
                        self._updateStatusCard()

                        endpoint = details.get("endpoint") or "Not detected"
                        message = "Portal path: %s\nHandshake: %s\nProfile: %s\nLive categories: %s\nLive channels: SKIPPED\nCreate live link: SKIPPED" % (
                            endpoint,
                            "OK" if details.get("handshake") else "FAILED",
                            "OK" if details.get("profile") else "FAILED",
                            int(details.get("categories") or 0),
                        )
                        if details.get("error"):
                            message += "\nError: %s" % details.get("error")
                        message += "\n\nQuick test completed. Channel/link validation runs when Live is opened."
                        self.session.open(
                            MessageBox, message,
                            MessageBox.TYPE_INFO if details.get("ok") else MessageBox.TYPE_ERROR,
                            timeout=15
                        )
                    except Exception:
                        pass

                try:
                    if reactor is not None:
                        reactor.callFromThread(done)
                    else:
                        done()
                except Exception:
                    done()

            thread = threading.Thread(target=worker, name="TiviMateStalkerQuickTest")
            thread.daemon = True
            thread.start()
            return

        report, error = self._connectionTest(source)
        state = report.get("state", "offline")
        self._serverStates[key] = state
        self._serverExpiries[key] = report.get("expiry") or ""
        self._refreshSourceRows()
        self._updateStatusCard()
        if state == "online":
            self.session.open(MessageBox, "Connection successful. No active use was reported by the server.", MessageBox.TYPE_INFO)
        elif state == "busy":
            self.session.open(MessageBox, "Connection successful. The server reports active use for this subscription.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Connection failed.\n%s" % (error or "Please verify the server details."), MessageBox.TYPE_ERROR)


class TiviMateE2Search(Screen):
    skin = SEARCH_SCREEN
    PAGE_SIZE = 10
    GRID_X = [70, 315, 560, 805, 1050]
    GRID_Y = [257, 585]


    def __init__(self, session, source):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source = source
        self.query = ""
        self.results = []
        self.page = 0
        self.index = 0
        self.loaders = []
        self.downloaders = []
        self._artwork_requests = {}
        self._detail_request = None
        self._searchGeneration = 0
        self.topNames = [nav_label("Search"), nav_label("Home"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("Continue Watching"), nav_label("Settings")]
        self.topX = [40, 225, 410, 595, 780, 965, 1150, 1510]
        self.topW = [175, 175, 175, 175, 175, 175, 350, 175]
        self.topIndex = 0
        self.navFocus = "top"
        for i, name in enumerate(self.topNames):
            self["top%d" % i] = Label(name)
        self["topSelector"] = Pixmap()
        self["back"] = Label("‹")
        self["searchText"] = Label(tr("Search for a movie or series..."))
        self["mic"] = Label("◉")
        self["closeIcon"] = Label("×")
        self["moviesTitle"] = Label(tr("Search results"))
        self["showsTitle"] = Label("")
        for i in range(10):
            self["poster%d" % i] = Pixmap()
            self["posterLabel%d" % i] = Label("")
            self["posterRate%d" % i] = Label("")
        self["movieSelector"] = Pixmap()
        self["showSelector"] = Pixmap()
        self["detailPoster"] = Pixmap()
        self["selectedTitle"] = Label("")
        self["selectedMeta"] = Label("")
        self["selectedOverview"] = Label("")
        self["play"] = Label("▷  " + tr("Play"))
        self["favorite"] = Label("☆  " + tr("Add to My List"))
        self["pageInfo"] = Label("")
        self["status"] = Label(tr("Press OK to start searching"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "green": self.openKeyboard, "yellow": self.prevPage, "blue": self.nextPage,
            "yellowlong": self.addCurrentFavourite
        }, -1)
        self.onLayoutFinish.append(self.layoutReady)

    def layoutReady(self):
        self["status"].setText(tr("Press OK to start searching"))
        self._updateSearchTopFocus()
        try:
            self["movieSelector"].hide(); self["showSelector"].hide()
        except Exception:
            pass


    def _updateSearchTopFocus(self):
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(66)))
            self["topSelector"].setVisible(self.navFocus == "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openSearchTop(self):
        if self.topIndex == 0:
            self.navFocus = "content"; self._updateSearchTopFocus(); self.openKeyboard(); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.source, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(ContentHomeScreen, self.source, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(ContentHomeScreen, self.source, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.source); return
        if self.topIndex == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source); return
        if self.topIndex == 7:
            self._openPageOnce(SettingsDashboard); return



    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        try:
            self.session.openWithCallback(self.searchReady, VirtualKeyBoard, title="Search", text=self.query)
        except RuntimeError:
            self["status"].setText(tr("Press OK again to open the search keyboard"))

    def searchReady(self, value=None):
        if value is None:
            if not self.query:
                self.close()
            return
        self.query = (value or "").strip()
        self["searchText"].setText(self.query or tr("Search for a movie or series..."))
        if not self.query:
            return

        # Every search owns a generation id. Older workers are ignored if the
        # user starts another search before they finish.
        self._searchGeneration = int(getattr(self, "_searchGeneration", 0) or 0) + 1
        generation = self._searchGeneration
        query = self.query
        self["status"].setText(tr("Searching..."))
        t = threading.Thread(target=self._worker, args=(generation, query), name="TiviMateSearch")
        t.daemon = True
        t.start()

    def _tag(self, rows, kind):
        out = []
        for item in rows:
            try:
                row = dict(item or {})
            except Exception:
                row = item or {}
            row["_search_kind"] = kind
            out.append(row)
        return out

    def _strictFilteredSearchRows(self, kind, client):
        """Return rows ONLY from packages explicitly selected by the user for this kind.

        Movies (vod) and Series have independent filter scopes. There is deliberately
        no provider-wide fallback: an unselected package is never queried by Search.
        """
        if kind not in ("vod", "series"):
            return []
        allowed = get_allowed_category_ids(self.source, kind)
        # Strict means explicit selection is required. None/no selection must not
        # silently turn into "search the whole server".
        if not allowed:
            return []

        allowed = set(str(x) for x in allowed if str(x))
        if not allowed:
            return []

        # Preserve the user's filtered package order when category metadata is available.
        ordered_ids = []
        try:
            categories, _origin = get_cached_categories(
                self.source, kind, client=client, wait_for_server=False
            )
            for row in categories or []:
                cid = str((row or {}).get("category_id") or "")
                if cid and cid in allowed and cid not in ordered_ids:
                    ordered_ids.append(cid)
        except Exception:
            pass
        for cid in allowed:
            if cid not in ordered_ids:
                ordered_ids.append(cid)

        output = []
        seen = set()
        for cid in ordered_ids:
            try:
                rows, _origin = get_category_streams(
                    self.source, kind, client, cid,
                    use_cache=True, wait_for_server=True
                )
            except Exception:
                rows = []
            for item in rows or []:
                if not isinstance(item, dict):
                    continue
                # Extra guard against broken portals returning cross-package rows.
                item_cid = str(
                    item.get("category_id") or item.get("categoryId") or
                    item.get("genre_id") or item.get("genre-id") or ""
                )
                if item_cid and item_cid not in allowed:
                    continue
                unique = (
                    str(item.get("stream_id") or item.get("series_id") or item.get("id") or ""),
                    str(item.get("name") or item.get("title") or ""),
                    cid
                )
                if unique in seen:
                    continue
                seen.add(unique)
                output.append(item)
        return output

    def _worker(self, generation, query):
        try:
            q = str(query or "").strip().lower()
            source_type = self.source.get("type")
            results = []

            if source_type in ("xtream", "stalker"):
                client = XtreamClient(self.source) if source_type == "xtream" else StalkerClient(self.source)

                # STRICT FILTER SEARCH:
                # Movies search only user-selected VOD packages.
                # Series search only user-selected Series packages.
                # No "all server" fallback exists in this Search screen.
                movies_all = self._strictFilteredSearchRows("vod", client)
                shows_all = self._strictFilteredSearchRows("series", client)

                def match(rows):
                    return [
                        x for x in (rows or [])
                        if q in str((x or {}).get("name") or (x or {}).get("title") or "").lower()
                    ]

                results = (
                    self._tag(match(movies_all), "vod") +
                    self._tag(match(shows_all), "series")
                )
            else:
                # Main Search intentionally excludes Live channels.
                results = []

            results = results[:500]

            # Never let an older search overwrite a newer query.
            if generation != int(getattr(self, "_searchGeneration", 0) or 0):
                return
            if reactor:
                reactor.callFromThread(self._readySearchGeneration, generation, results)
            else:
                self._readySearchGeneration(generation, results)
        except Exception as exc:
            if generation != int(getattr(self, "_searchGeneration", 0) or 0):
                return
            if reactor:
                reactor.callFromThread(self._failedSearchGeneration, generation, str(exc))
            else:
                self._failedSearchGeneration(generation, str(exc))

    def _readySearchGeneration(self, generation, results):
        if generation != int(getattr(self, "_searchGeneration", 0) or 0):
            return
        self._ready(results)

    def _failedSearchGeneration(self, generation, err):
        if generation != int(getattr(self, "_searchGeneration", 0) or 0):
            return
        self._failed(err)

    def _failed(self, err):
        self["status"].setText("Search failed: %s" % err)

    def short_title(self, item):
        title = str((item or {}).get("name") or (item or {}).get("title") or "").strip()
        return title[:24] + ("…" if len(title) > 24 else "")

    def _ready(self, results):
        self.results = results or []
        self.page = 0
        self.index = 0
        self.renderPage()

    def pageItems(self):
        start = self.page * self.PAGE_SIZE
        return self.results[start:start + self.PAGE_SIZE]

    def pageCount(self):
        if not self.results:
            return 1
        return (len(self.results) + self.PAGE_SIZE - 1) // self.PAGE_SIZE

    def renderPage(self):
        items = self.pageItems()
        self._artwork_requests = {}
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png")
        for i in range(10):
            try:
                self["poster%d" % i].hide()
                self["posterLabel%d" % i].hide()
                self["posterRate%d" % i].hide()
            except Exception:
                pass
        for i, item in enumerate(items):
            try:
                self["poster%d" % i].instance.setPixmapFromFile(placeholder)
                self["poster%d" % i].show()
                self["posterLabel%d" % i].setText(self.short_title(item))
                rating = item.get("rating") or item.get("rating_5based") or item.get("vote_average") or ""
                self["posterRate%d" % i].setText(str(rating)[:4])
                self["posterLabel%d" % i].show()
                self["posterRate%d" % i].show()
            except Exception:
                pass
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or item.get("poster_path") or "", item)
        # Warm every poster already returned by Search in the background.
        prefetch_artwork([
            (row or {}).get("stream_icon") or (row or {}).get("cover") or (row or {}).get("poster_path") or ""
            for row in list(self.results or [])
        ], "search", priority=2)
        self.index = min(self.index, max(0, len(items) - 1))
        total = len(self.results)
        self["moviesTitle"].setText("%s: %s" % (tr("Search results"), self.query))
        self["showsTitle"].setText("%d %s" % (total, tr("results")))
        self["pageInfo"].setText("‹   %s %d / %d   ›" % (tr("Page"), self.page + 1, self.pageCount()))
        self["status"].setText("%d %s" % (total, tr("results")))
        self.updateSelection()

    def current(self):
        items = self.pageItems()
        return items[self.index] if items and self.index < len(items) else None

    def currentGlobalIndex(self):
        return self.page * self.PAGE_SIZE + self.index

    def updateSelection(self):
        items = self.pageItems()
        if not items:
            try:
                self["movieSelector"].hide(); self["showSelector"].hide()
            except Exception:
                pass
            self["selectedTitle"].setText("")
            self["selectedMeta"].setText("")
            self["selectedOverview"].setText("")
            return
        self.index = min(self.index, len(items) - 1)
        col = self.index % 5
        row = self.index // 5
        x = self.GRID_X[col]
        y = self.GRID_Y[row]
        try:
            self["showSelector"].hide()
            self["movieSelector"].instance.move(ePoint(sx(x), sy(y)))
            self["movieSelector"].show()
        except Exception:
            pass
        item = self.current() or {}
        title = item.get("name") or item.get("title") or ""
        year = item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or ""
        if isinstance(year, str) and len(year) >= 4:
            year = year[:4]
        rating = item.get("rating") or item.get("rating_5based") or item.get("vote_average") or "-"
        kind = item.get("_search_kind", "vod")
        kind_label = tr("TV Show") if kind == "series" else (tr("Channel") if kind == "live" else tr("Movie"))
        self["selectedTitle"].setText(str(title))
        self["selectedMeta"].setText("%s: %s\n%s: %s\n%s: %s" % (tr("Type"), kind_label, tr("Year"), year or "-", tr("Rating"), rating))
        overview = item.get("plot") or item.get("description") or item.get("overview") or ""
        if len(str(overview)) > 220:
            overview = str(overview)[:217] + "..."
        self["selectedOverview"].setText(str(overview))
        self["favorite"].setText(("★  " + tr("Remove from My List")) if is_favourite(self.source, kind, item) else ("☆  " + tr("Add to My List")))
        detail_url = item.get("stream_icon") or item.get("cover") or item.get("poster_path") or ""
        self.loadDetailImage(detail_url, item)

    def left(self):
        if self.navFocus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateSearchTopFocus()
            return
        if not self.results:
            return
        if self.index > 0:
            self.index -= 1
            self.updateSelection()
        elif self.page > 0:
            self.page -= 1
            self.index = min(self.PAGE_SIZE - 1, len(self.pageItems()) - 1)
            self.renderPage()

    def right(self):
        if self.navFocus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateSearchTopFocus()
            return
        items = self.pageItems()
        if not items:
            return
        if self.index < len(items) - 1:
            self.index += 1
            self.updateSelection()
        elif self.page < self.pageCount() - 1:
            self.page += 1
            self.index = 0
            self.renderPage()

    def up(self):
        if self.navFocus == "top":
            return
        if self.index >= 5:
            self.index -= 5
            self.updateSelection()
        else:
            self.navFocus = "top"
            self._updateSearchTopFocus()


    def down(self):
        if self.navFocus == "top":
            self.navFocus = "content"
            self._updateSearchTopFocus()
            return
        items = self.pageItems()
        candidate = self.index + 5
        if candidate < len(items):
            self.index = candidate
            self.updateSelection()


    def prevPage(self):
        if self.page > 0:
            self.page -= 1
            self.index = 0
            self.renderPage()

    def nextPage(self):
        if self.page < self.pageCount() - 1:
            self.page += 1
            self.index = 0
            self.renderPage()

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        kind = item.get("_search_kind", "vod")
        added, saved = toggle_favourite(self.source, kind, item)
        if not saved:
            self["status"].setText(tr("Unable to save favorite"))
        elif added:
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Removed from favorites"))
        self.updateSelection()

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            return
        kind = item.get("_search_kind", "vod")
        if kind not in ("vod", "series"):
            return
        if is_favourite(self.source, kind, item):
            self["status"].setText(tr("Item is already in favorites"))
        elif add_favourite(self.source, kind, item):
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))
        self.updateSelection()

    def ok(self):
        if self.navFocus == "top":
            self._openSearchTop()
            return
        item = self.current()
        if not item:
            self.openKeyboard()
            return
        kind = item.get("_search_kind", "vod")
        if kind == "live":
            rows = [x for x in self.results if x.get("_search_kind") == "live"]
            idx = 0
            try:
                idx = rows.index(item)
            except Exception:
                pass
            self.session.open(TiviMateLivePlayer, self.source, rows, idx)
            return
        if kind == "series":
            self.session.open(SeriesDetailsScreen, self.source, item)
            return
        if self.source.get("type") == "stalker":
            url = StalkerClient(self.source).stream_url(item, "vod")
        else:
            ext = item.get("container_extension") or self.source.get("output", "ts")
            url = "%s/movie/%s/%s/%s.%s" % (self.source.get("url", "").rstrip("/"), self.source.get("username", ""), self.source.get("password", ""), item.get("stream_id", ""), ext)
        if not url:
            self.session.open(MessageBox, "Unable to resolve a playable movie URL.", MessageBox.TYPE_ERROR)
            return
        play_item = dict(item or {})
        play_item["_source_type"] = self.source.get("type", "")
        play_item["_source_key"] = _source_identity(self.source)
        play_item["_kind"] = "vod"
        self.session.open(TiviMatePlayer, eServiceReference(_stalker_service_type(self.source, "vod") if self.source.get("type") == "stalker" else 4097, 0, url), play_item)

    def _searchPosterFileUsable(self, path):
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n")
        except Exception:
            return False

    def _searchPosterFallback(self, slot, item, detail=False):
        item = item or {}
        kind = item.get("_search_kind", "vod")
        if kind not in ("vod", "series"):
            return
        title = item.get("name") or item.get("title") or item.get("original_title") or ""
        if not title:
            return
        token = "tmdb:%s:%s:%s" % (kind, slot, str(title))
        if detail:
            self._detail_request = token
        else:
            self._artwork_requests[slot] = token

        def worker():
            try:
                raw_year = item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                found = TMDbClient().search_artwork(title, kind, year, required_key="poster_path") or {}
                poster = found.get("poster_path") or ""
                if not poster:
                    return
                url = poster if str(poster).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(poster)

                def apply():
                    if detail:
                        if getattr(self, "_detail_request", None) != token:
                            return
                        self.loadDetailImage(url, item, allow_fallback=False)
                    else:
                        if getattr(self, "_artwork_requests", {}).get(slot) != token:
                            return
                        self.loadImage(slot, url, item, allow_fallback=False)

                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMateSearchPosterTMDB")
        t.daemon = True
        t.start()

    def loadImage(self, slot, url, item=None, allow_fallback=True):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            if allow_fallback and item is not None:
                self._searchPosterFallback(slot, item, detail=False)
            return
        self._artwork_requests[slot] = url

        def done(path, s=slot, expected=url, fallback_item=item):
            if getattr(self, "_artwork_requests", {}).get(s) != expected:
                return
            if not self._searchPosterFileUsable(path):
                if allow_fallback and fallback_item is not None:
                    self._searchPosterFallback(s, fallback_item, detail=False)
                return
            self.decode(s, path)
            try:
                if s == self.index:
                    self._detail_request = expected
                    self.decodeDetail(path)
            except Exception:
                pass

        def failed(_path, s=slot, fallback_item=item):
            if allow_fallback and fallback_item is not None:
                self._searchPosterFallback(s, fallback_item, detail=False)

        request_artwork(url, "search", done, priority=55, errback=failed)

    def loadDetailImage(self, url, item=None, allow_fallback=True):
        url = (url or "").strip().replace("\\/", "/")
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png")
        try:
            self["detailPoster"].instance.setPixmapFromFile(placeholder)
        except Exception:
            pass
        if not url:
            if allow_fallback and item is not None:
                self._searchPosterFallback(self.index, item, detail=True)
            return
        self._detail_request = url

        def done(path, expected=url, fallback_item=item):
            if getattr(self, "_detail_request", None) != expected:
                return
            if not self._searchPosterFileUsable(path):
                if allow_fallback and fallback_item is not None:
                    self._searchPosterFallback(self.index, fallback_item, detail=True)
                return
            self.decodeDetail(path)

        def failed(_path, fallback_item=item):
            if allow_fallback and fallback_item is not None:
                self._searchPosterFallback(self.index, fallback_item, detail=True)

        request_artwork(url, "search", done, priority=58, errback=failed)

    def decode(self, slot, path):
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, s=slot, ll=loader):
            try:
                ptr = ll.getData()
                widget = self["poster%d" % s]
                if ptr and widget.instance:
                    widget.instance.setPixmap(ptr)
                    widget.show()
            except Exception:
                pass
            try:
                if ll in self.loaders:
                    self.loaders.remove(ll)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(200, 285)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def decodeDetail(self, path):
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, ll=loader):
            try:
                ptr = ll.getData()
                if ptr and self["detailPoster"].instance:
                    self["detailPoster"].instance.setPixmap(ptr)
                    self["detailPoster"].show()
            except Exception:
                pass
            try:
                if ll in self.loaders:
                    self.loaders.remove(ll)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(215, 305)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)



HOME_SERVER_POPUP_SKIN = r"""
<screen name="HomeServerPopup" position="600,315" size="720,450" flags="wfNoBorder" backgroundColor="#101820" title="Select Server">
    <ePixmap position="0,0" size="720,450" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server_popup_bg_r182.png" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="title" position="42,30" size="636,52" font="Regular;32" foregroundColor="#FFFFFF" backgroundColor="#101820" transparent="1" zPosition="3"/>
    <widget name="subtitle" position="42,83" size="636,34" font="Regular;19" foregroundColor="#AEB9C5" backgroundColor="#101820" transparent="1" zPosition="3"/>
    <widget name="servers" position="42,135" size="636,228" itemHeight="57" font="Regular;25" foregroundColor="#EAF0F5" backgroundColor="#101820" selectionForegroundColor="#FFFFFF" selectionBackgroundColor="#203847" scrollbarMode="showOnDemand" zPosition="4"/>
    <widget name="hint" position="42,386" size="636,34" font="Regular;18" foregroundColor="#91A1AF" backgroundColor="#101820" transparent="1" halign="center" zPosition="3"/>
</screen>
"""

class HomeServerPopup(Screen):
    skin = HOME_SERVER_POPUP_SKIN

    def __init__(self, session, sources, active_source=None):
        Screen.__init__(self, session)
        self.sources = [dict(x or {}) for x in (sources or []) if x]
        self.active_source = dict(active_source or {})
        self["title"] = Label(tr("Select Server"))
        self["subtitle"] = Label(tr("Choose the server for Home"))
        self["hint"] = Label(tr("UP/DOWN  Navigate     OK  Select     EXIT  Cancel"))
        rows = []
        active_key = self._key(self.active_source)
        active_index = 0
        for i, source in enumerate(self.sources):
            name = str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            stype = str(source.get("type") or "IPTV").upper()
            marker = u"✓  " if self._key(source) == active_key else u"   "
            rows.append(u"%s%s    •    %s" % (marker, name[:34], stype[:12]))
            if self._key(source) == active_key:
                active_index = i
        self["servers"] = MenuList(rows, enableWrapAround=True)
        try:
            self["servers"].moveToIndex(active_index)
        except Exception:
            pass
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close,
            "up": self["servers"].up, "down": self["servers"].down,
            "left": self["servers"].pageUp, "right": self["servers"].pageDown,
        }, -1)

    def _key(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def choose(self):
        try:
            index = self["servers"].getSelectionIndex()
        except Exception:
            index = 0
        if 0 <= index < len(self.sources):
            self.close(self.sources[index])
        else:
            self.close(None)


class TiviMateE2Home(Screen):
    skin = HOME_SKIN1
    NAV = ["Search", "Home", "Live", "Movies", "TV Shows", "Packages", "Continue Watching", "Settings"]
    NAV_X = [312, 467, 622, 777, 932, 1087, 1242, 1397]
    NAV_Y = [210] * 8
    POSTER_X = [216, 461, 706, 951, 1196, 1441]
    POSTER_Y = 701
    ACTIVE_FILE = data_path("active_source.json")


    def __init__(self, session):
        self.homeAppearance = _load_home_appearance()
        self.homeSkinName = self.homeAppearance.get("skin", "skin2_dark")
        self.isReferenceHome = self.homeSkinName == "reference_home"
        self.posterSize = (248, 338)
        self.bannerSize = (1704, 454)
        if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
            self.skin = HOME_SKIN3_ACCESSIBILITY if self.homeSkinName == "skin3_accessibility" else HOME_SKIN2
            self.NAV = ["Search", "Home", "Live", "Movies", "TV Shows", "Packages", "Continue Watching", "Settings"]
            self.NAV_X = [312, 467, 622, 777, 932, 1087, 1242, 1397]
            self.NAV_Y = [79] * 8
            self.POSTER_X = [55, 375, 695, 1015, 1335, 1655]
            self.POSTER_Y = 510
            self.posterSize = (215, 360)
            self.bannerSize = (1920, 370)
        else:
            self.homeSkinName = "reference_home"
            self.isReferenceHome = True
            self.skin = HOME_SKIN1
            self.NAV_X = [312, 467, 622, 777, 932, 1087, 1242, 1397]
            self.NAV_Y = [27] * 8
            self.POSTER_X = [106, 398, 690, 982, 1274, 1566]
            self.POSTER_Y = 676
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source = self._loadActiveSource()
        self.homeContentMode = _load_home_appearance().get("content", "popular_movies")
        # Home no longer exposes Recent Added. Migrate any stale saved Home mode
        # left by older builds to Popular Movies and persist the correction.
        if self.homeContentMode in ("recent_movies", "recent_series"):
            self.homeContentMode = "popular_movies"
            try:
                cfg = _load_home_appearance()
                _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
            except Exception:
                pass
        self.focus = "nav"
        self.navIndex = 1
        self.posterIndex = 0
        self.recent = []
        # Warm VOD index used by Home Popular/Trending movie cards. It is filled
        # in the background while TMDb posters are shown, so WATCH does not start
        # a full server scan after the user opens a movie.
        self.homeMovieServerItems = []
        self.homeMovieIndexLoading = False
        self.imageLoaders = [None] * 7
        self.imageDownloaders = [None] * 7
        self.featureRequestId = 0
        # Every asynchronous Home job belongs to the server generation that
        # created it. Switching server invalidates older workers/callbacks.
        self._sourceGeneration = 1
        self._homeClosed = False
        # The dashboard hero is part of the application identity, never of a specific IPTV source.
        self.globalHero = True
        self["headline"] = Label(tr("TiViMate IPTV EXPERIENCE"))
        self["subheadline"] = Label(tr("Live TV  •  Movies  •  Series  •  beIN SPORTS"))
        self["logo"] = Label(tr("TiviMate E2"))
        self["homeBrandLogo"] = Pixmap()
        self["poweredBy"] = Label("Developed by opesboy")
        for i in range(8): self["nav%d" % i] = Label(nav_label(self.NAV[i]) if i < len(self.NAV) else "")
        self["navSelector"] = Pixmap()
        self["clock"] = Label("")
        self["date"] = Label("")
        self["banner"] = Pixmap()
        self["quality"] = Label(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"] = Label(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"] = Label(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"] = Label("")
        self["playNow"] = Label(tr("WATCH NOW"))
        self["recentTitle"] = Label(tr("Popular Movies"))
        for i in range(6):
            self["poster%d" % i] = Pixmap()
            self["posterMetaTitle%d" % i] = Label("")
            self["posterMetaRate%d" % i] = Label("")
        self["posterSelector"] = Pixmap()
        self["status"] = Label("")
        if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
            self["actionLabel0"] = Label(tr("PACKAGES"))
            self["actionLabel1"] = Label(tr("UPDATE PLAYLIST"))
            self["actionLabel2"] = Label(tr("Favorites"))
            self["actionLabel3"] = Label(tr("SWITCH SERVER"))
            lang = get_language()
            if lang == "ar":
                self["skin2HelpTitle"] = Label("أزرار الريموت")
                self["skin2HelpBody"] = Label("الأخضر: الباقات   الأصفر: تحديث القائمة\nالأزرق: المفضلة   الأحمر: تغيير السيرفر")
                self["skin2LangTitle"] = Label("اللغة العربية")
                self["skin2LangBody"] = Label("واجهة وقوائم عربية متناسقة وواضحة")
                self["skin2Key5"] = Label("المفتاح 5\nإعدادات الترجمة")
            elif lang == "fr":
                self["skin2HelpTitle"] = Label("Touches de la télécommande")
                self["skin2HelpBody"] = Label("Vert: Packages   Jaune: Actualiser\nBleu: Favoris   Rouge: Changer serveur")
                self["skin2LangTitle"] = Label("Interface française")
                self["skin2LangBody"] = Label("Menus et informations adaptés à la langue")
                self["skin2Key5"] = Label("Touche 5\nRéglages des sous-titres")
            else:
                self["skin2HelpTitle"] = Label("REMOTE SHORTCUTS")
                self["skin2HelpBody"] = Label("Green: Packages   Yellow: Refresh playlist\nBlue: Favorites   Red: Switch server")
                self["skin2LangTitle"] = Label("LANGUAGE")
                self["skin2LangBody"] = Label("Menus and information follow the selected language")
                self["skin2Key5"] = Label("KEY 5\nSubtitle settings")
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "menu": self.openFavorites,
            "red": self.openHomeServerPopup, "green": self.openContentPackages, "yellow": self.chooseHomeContent,
            "yellowlong": self.addRecentFavourite, "blue": self.openFavorites
        }, -1)
        self.clockTimer = eTimer()
        _connect_timer(self.clockTimer, self.updateClock)
        self.loadTimer = eTimer()
        _connect_timer(self.loadTimer, self.startLoad)
        # Stalker/Ministra portals can complete the network request in a worker
        # while a Twisted reactor is unavailable or not integrated with Enigma2.
        # Deliver their Home result through an eTimer, the same UI-thread pattern
        # used by ContentHome.  This remains completely generic: it carries only
        # a source snapshot, a request token, and normalized items.
        self.stalkerRecentToken = 0
        self.stalkerRecentResult = None
        self.stalkerRecentTimer = eTimer()
        _connect_timer(self.stalkerRecentTimer, self._finishStalkerRecentLoad)

        # Update work happens only after the Home screen is visible and always
        # in a background thread, so it never delays loading IPTV content.
        self.updateCheckTimer = eTimer()
        self.updateCheckPollTimer = eTimer()
        self.updateDownloadPollTimer = eTimer()
        _connect_timer(self.updateCheckTimer, self._beginUpdateCheck)
        _connect_timer(self.updateCheckPollTimer, self._pollUpdateCheck)
        _connect_timer(self.updateDownloadPollTimer, self._pollUpdateDownload)
        self._updateCheckPending = None
        self._updateDownloadPending = None
        self._updateCandidate = None
        self._updateInstallProcess = None
        self._updateCheckStarted = False
        try: self.onClose.append(self._stopUpdateTimers)
        except Exception: pass
        try: self.onClose.append(self._stopStalkerRecentTimer)
        except Exception: pass
        try: self.onClose.append(self._invalidateHomeJobs)
        except Exception: pass
        self.onLayoutFinish.append(self.layoutReady)

    def _applyRecentTitleLayout(self):
        """Keep the Home content heading on the right edge only for Arabic.
        Do not mirror the whole screen; only reposition this heading."""
        try:
            widget = self["recentTitle"]
            if not widget or not widget.instance:
                return
            lang = get_language()
            if self.isReferenceHome:
                x, y, w, h = (100, 610, 500, 42)
                if lang == "ar":
                    # Arabic heading sits at the far-right edge above the last poster.
                    x, w = (1650, 220)
            else:
                x, y, w, h = (55, 468, 560, 40)
                if lang == "ar":
                    # Skin 2: keep only this heading RTL-positioned; do not mirror Home.
                    x, w = (1650, 220)
            widget.instance.move(ePoint(sx(x), sy(y)))
            widget.instance.resize(eSize(sx(w), sy(h)))
        except Exception:
            pass

    def layoutReady(self):
        # Both Home skins scale their decoded hero at the Pixmap level.
        # This keeps Skin 1's backdrop stretched across its full panoramic frame.
        try:
            self["banner"].instance.setScale(1)
        except Exception:
            pass
        self.applyGlobalHero()
        self._applyRecentTitleLayout()
        self.updateFocus(); self.updateClock()
        try: self.clockTimer.start(30000, False)
        except Exception: pass
        try: self.loadTimer.start(250, True)
        except Exception: self.startLoad()
        # Delay the request slightly so a slow or unavailable update endpoint
        # never affects the first paint of the home interface.
        if _load_update_settings().get("auto_check", True):
            try: self.updateCheckTimer.start(1500, True)
            except Exception: self._beginUpdateCheck()

    def _stopUpdateTimers(self):
        for timer in (getattr(self, "updateCheckTimer", None),
                      getattr(self, "updateCheckPollTimer", None),
                      getattr(self, "updateDownloadPollTimer", None)):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _stopStalkerRecentTimer(self):
        # Invalidate a finishing worker before the screen is destroyed.
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass

    def _invalidateHomeJobs(self):
        self._homeClosed = True
        self._sourceGeneration = getattr(self, "_sourceGeneration", 0) + 1
        self.featureRequestId = getattr(self, "featureRequestId", 0) + 1
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None

    def _sourceJobValid(self, generation, source):
        if getattr(self, "_homeClosed", False):
            return False
        if generation != getattr(self, "_sourceGeneration", -1):
            return False
        try:
            return _source_identity(source or {}) == _source_identity(self.source or {})
        except Exception:
            return False

    def _beginUpdateCheck(self):
        if not _load_update_settings().get("auto_check", True):
            return
        if self._updateCheckStarted:
            return
        self._updateCheckStarted = True
        self._updateCheckPending = None

        def worker():
            try:
                self._updateCheckPending = check_for_update()
            except Exception:
                self._updateCheckPending = {}

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateCheckPollTimer.start(200, True)
        except Exception:
            self._updateCheckPending = {}

    def _pollUpdateCheck(self):
        if self._updateCheckPending is None:
            try: self.updateCheckPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateCheckPending or {}
        self._updateCheckPending = None
        if not result.get("available"):
            return
        self._updateCandidate = result
        version = result.get("version") or "1.0.3"
        revision = result.get("revision") or "?"
        notes = result.get("notes") or ""
        text = "A new TiviMate E2 update is available.\n\nVersion: %s (revision %s)" % (version, revision)
        if notes:
            text += "\n\n" + notes
        text += "\n\nDownload and install it now?"
        try:
            self.session.openWithCallback(self._onUpdatePrompt, MessageBox, text,
                type=MessageBox.TYPE_YESNO, timeout=20, default=False)
        except Exception:
            pass

    def _onUpdatePrompt(self, answer):
        if not answer or not self._updateCandidate:
            return
        package = self._updateCandidate.get("package")
        if not package:
            return
        self._updateDownloadPending = None
        try: self["status"].setText(tr("Downloading TiviMate E2 update..."))
        except Exception: pass

        def worker():
            self._updateDownloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker)
            thread.daemon = True
            thread.start()
            self.updateDownloadPollTimer.start(200, True)
        except Exception:
            self._updateDownloadPending = {"ok": False, "message": "Unable to start download"}

    def _pollUpdateDownload(self):
        if self._updateDownloadPending is None:
            try: self.updateDownloadPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateDownloadPending or {}
        self._updateDownloadPending = None
        if not result.get("ok"):
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Update download failed.\n\n%s" % (result.get("message") or "Please try again later."))
            return
        command = install_command(result)
        if not command:
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("The verified update package could not be installed.")
            return
        try: self["status"].setText(tr("Installing TiviMate E2 update..."))
        except Exception: pass
        try:
            process = eConsoleAppContainer()
            self._updateInstallProcess = process
            try: process.appClosed.append(self._onUpdateInstallFinished)
            except Exception: process.appClosed.get().append(self._onUpdateInstallFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Unable to start the update installer.")

    def _onUpdateInstallFinished(self, status):
        self._updateInstallProcess = None
        try: self["status"].setText(tr(""))
        except Exception: pass
        if status == 0:
            self._showUpdateMessage("TiviMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.")
        else:
            self._showUpdateMessage("The update installer returned an error.\n\nYour current TiviMate E2 installation has not been changed.")

    def _showUpdateMessage(self, text):
        try:
            self.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=12)
        except Exception:
            pass

    def _sourceKey(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def _loadActiveSource(self):
        sources = get_sources()
        if not sources: return None
        try:
            with open_text(self.ACTIVE_FILE, "r") as f: key = json.load(f).get("key", "")
            for source in sources:
                if self._sourceKey(source) == key: return source
        except Exception: pass
        for source in sources:
            if source.get("type") == "xtream": return source
        return sources[0]

    def _saveActiveSource(self):
        try:
            ensure_dir(os.path.dirname(self.ACTIVE_FILE))
            with open_text(self.ACTIVE_FILE, "w") as f: json.dump({"key": self._sourceKey(self.source)}, f)
        except Exception: pass

    def updateClock(self):
        now = time.localtime()
        self["clock"].setText(time.strftime("%H:%M", now))
        self["date"].setText(time.strftime("%d.%m.%Y", now))

    def _heroRating(self, row):
        item = row.get("item") or {}
        raw = row.get("rating") or item.get("rating") or item.get("vote_average") or item.get("rating_5based") or 0
        try:
            value = float(str(raw).replace(",", "."))
            if value > 10.0:
                value = value / 10.0
            return max(0.0, min(10.0, value))
        except Exception:
            return 0.0

    def _heroYear(self, row):
        item = row.get("item") or {}
        raw = " ".join(str(x or "") for x in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match = re.search(r"\b(19|20)\d{2}\b", raw)
        return match.group(0) if match else ""

    def _heroOverview(self, row):
        item = row.get("item") or {}
        return str(
            row.get("overview") or item.get("plot") or item.get("description") or
            item.get("overview") or ""
        ).strip()

    def _heroGenre(self, row):
        item = row.get("item") or {}
        return str(row.get("genre") or item.get("genre") or "").strip()

    def _enrichHeroAsync(self, key, row):
        generation = self._generation
        title = self._title(row)
        kind = "series" if self._isSeries(row) else "vod"
        item = row.get("item") or {}
        year = self._heroYear(row) or item.get("year") or ""
        def worker():
            try:
                found = TMDbClient().search_artwork(title, kind=kind, year=year) or {}
            except Exception:
                found = {}
            if generation != self._generation or not found:
                return
            data = self._load()
            rec = data.get(key)
            if not isinstance(rec, dict):
                return
            rec["rating"] = found.get("vote_average") or rec.get("rating") or ""
            rec["year"] = str(found.get("release_date") or found.get("first_air_date") or rec.get("year") or "")[:4]
            rec["overview"] = found.get("overview") or rec.get("overview") or ""
            path = found.get("backdrop_path") or ""
            if path and not rec.get("backdrop"):
                rec["backdrop"] = IMAGE_BASE + "w1280" + path
            data[key] = rec
            self._save(data)
            # Update only if this exact item is still selected.
            selected = self._selected()
            if not selected or selected[0] != key or generation != self._generation:
                return
            rating = self._heroRating(rec)
            stars = int(round(rating / 2.0)) if rating else 0
            star_text = ("★" * stars) + ("☆" * (5 - stars)) if rating else "☆☆☆☆☆"
            year_text = self._heroYear(rec)
            self["heroStars"].setText("%s   %.1f/10%s" % (
                star_text, rating, ("  •  " + year_text) if year_text else ""
            ) if rating else star_text)
            overview = self._heroOverview(rec)
            if overview:
                self["heroDesc"].setText(overview[:280])
            backdrop = self._asset(rec)
            if backdrop:
                self._loadArtwork(backdrop, "hero", generation)
        t = threading.Thread(target=worker, name="TiviMateContinueHeroInfo")
        t.daemon = True
        t.start()


    def updateFocus(self):
        if self["navSelector"].instance:
            try:
                if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
                    widths = [145] * len(self.NAV)
                    x = self.NAV_X[self.navIndex] + ((widths[self.navIndex] - 180) // 2)
                    y = 79
                else:
                    x = self.NAV_X[self.navIndex]
                    y = self.NAV_Y[self.navIndex]
                self["navSelector"].instance.move(ePoint(sx(x), sy(y)))
                self["navSelector"].show() if self.focus == "nav" else self["navSelector"].hide()
            except Exception:
                pass
        if self["posterSelector"].instance:
            selector_x = self.POSTER_X[self.posterIndex]
            selector_y = self.POSTER_Y
            if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
                selector_x -= 2
                selector_y -= 2
            self["posterSelector"].instance.move(ePoint(sx(selector_x), sy(selector_y)))
            focused = (self.focus == "posters" and bool(self.recent))
            self["posterSelector"].show() if focused else self["posterSelector"].hide()
            if self.homeSkinName in ("skin2_dark", "skin3_accessibility"):
                for i in range(6):
                    try:
                        color = "#111820" if (focused and i == self.posterIndex) else "#F7FBFF"
                        self["posterMetaTitle%d" % i].instance.setForegroundColor(parseColor(color))
                    except Exception:
                        pass


    def left(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex - 1) % len(self.NAV)
        else:
            self.posterIndex = max(0, self.posterIndex - 1)
            self.updateFeature()
        self.updateFocus()

    def right(self):
        if self.focus == "nav":
            self.navIndex = (self.navIndex + 1) % len(self.NAV)
        else:
            self.posterIndex = min(max(0, len(self.recent) - 1), self.posterIndex + 1)
            self.updateFeature()
        self.updateFocus()

    def up(self):
        self.focus = "nav"
        self.updateFocus()

    def down(self):
        if self.recent:
            self.focus = "posters"
            self.updateFeature()
        self.updateFocus()


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def ok(self):
        if self.focus == "posters":
            self.playRecent()
            return
        index = self.navIndex
        if index == 0:
            self._openPageOnce(TiviMateE2Search, self.source)
            return
        if index == 1:
            return
        if index == 2:
            self.openMedia("live")
            return
        if index == 3:
            self.openContentHome("vod")
            return
        if index == 4:
            self.openContentHome("series")
            return
        if index == 5:
            self.openContentPackages()
            return
        if index == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source)
            return
        if index == 7:
            self.openSettings()
            return


    def addRecentFavourite(self):
        if self.focus != "posters" or not self.recent:
            self["status"].setText(tr("Select a movie poster first"))
            return
        item = self.recent[min(self.posterIndex, len(self.recent) - 1)]
        if is_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie is already in favorites"))
        elif add_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))

    def openHomeServerPopup(self):
        sources = [x for x in (get_sources() or []) if (x or {}).get("type") in ("xtream", "stalker")]
        if not sources:
            self.session.open(MessageBox, tr("No IPTV servers found."), MessageBox.TYPE_INFO, timeout=3)
            return
        self.session.openWithCallback(self._homeServerPopupClosed, HomeServerPopup, sources, self.source)

    def _homeServerPopupClosed(self, source=None):
        if not source:
            return
        try:
            if self._sourceKey(source) == self._sourceKey(self.source or {}):
                return
        except Exception:
            pass
        self.selectServer(source)

    def openContinueWatching(self):
        self._openPageOnce(ContinueWatchingScreen, self.source)

    def chooseHomeContent(self):
        choices = [
            (tr("Popular Movies"), "popular_movies"),
            (tr("Popular TV Shows"), "popular_series"),
            (tr("Movies You Might Like"), "trending_movies"),
            (tr("TV Shows You Might Like"), "trending_series"),
        ]
        def selected(answer):
            if not answer:
                return
            value = answer[1] if isinstance(answer, (tuple, list)) and len(answer) > 1 else None
            if not value:
                return
            self.homeContentMode = value
            try:
                cfg = _load_home_appearance()
                _save_home_appearance(cfg.get("skin", "skin2_dark"), value)
            except Exception:
                pass
            self.globalHero = True
            self.posterIndex = 0
            self.recent = []
            self.resetPosters()
            self.startLoad()
        from Screens.ChoiceBox import ChoiceBox
        self.session.openWithCallback(selected, ChoiceBox, title=tr("Home Content"), list=choices)

    def refreshHome(self):
        # YELLOW must refresh only the current Home feed. Invalidate every older
        # worker first so a late Recent/Trending result cannot overwrite Popular.
        current_mode = getattr(self, "homeContentMode", None)
        if not current_mode:
            try:
                current_mode = _load_home_appearance().get("content", "popular_movies")
            except Exception:
                current_mode = "popular_movies"
        self.homeContentMode = current_mode or "popular_movies"
        self.globalHero = True
        try:
            self._sourceGeneration += 1
        except Exception:
            self._sourceGeneration = 1
        try:
            self.stalkerRecentToken += 1
            self.stalkerRecentResult = None
            self.stalkerRecentTimer.stop()
        except Exception:
            pass
        self.posterIndex = 0
        self.recent = []
        self.resetPosters()
        self.startLoad()

    def openContentHome(self, kind):
        if not self.source:
            self.openSettings()
            return
        source_type = self.source.get("type")
        if source_type in ("xtream", "stalker"):
            self._openPageOnce(ContentHomeScreen, self.source, kind)
            return
        self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)

    def openMedia(self, kind):
        if not self.source:
            self.openSettings()
            return
        if kind in ("vod", "series") and self.source.get("type") not in ("xtream", "stalker"):
            self.session.open(MessageBox, "This section requires a server with Movies and TV Shows.", MessageBox.TYPE_INFO)
            return
        self._openPageOnce(MediaScreen, self.source, kind)

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def openLiveTools(self):
        if self.kind != "live":
            self.openFavorites(); return
        choices = [(tr("Favorites"), "favorites")]
        if self.source.get("type") == "stalker":
            pin_state = _load_stalker_pin(self.source)
            if self.focus == "category":
                choices.append((tr("Hide this package"), "hide_category"))
                row = self["category"].getCurrent()
                cid = str(row[1] or "") if row else ""
                if cid and not cid.startswith("__"):
                    if cid in pin_state["categories"]:
                        choices.append((tr("Unlock this package"), "unlock_category"))
                    else:
                        choices.append((tr("Lock this package"), "lock_category"))
            elif self.current():
                choices.append((tr("Hide this channel"), "hide_channel"))
                channel_id = _live_item_id(self.current())
                if channel_id in pin_state["channels"]:
                    choices.append((tr("Unlock this channel"), "unlock_channel"))
                else:
                    choices.append((tr("Lock this channel"), "lock_channel"))
            choices.append((tr("Change parental PIN"), "change_pin"))
            choices.append((tr("Stalker player engines"), "stalker_engines"))
            choices.append((tr("Recently watched"), "stalker_recent"))
            state = _load_stalker_hidden(self.source)
            if state["categories"]:
                choices.append((tr("Show hidden packages"), "show_hidden_packages"))
            if state["channels"]:
                choices.append((tr("Show hidden channels"), "show_hidden_channels"))
        self.session.openWithCallback(self._liveToolSelected, ChoiceBox, title=tr("Live options"), list=choices)

    def _liveToolSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if action == "favorites":
            self.openFavorites(); return
        if action == "hide_category":
            self._hideCurrentStalkerCategory(); return
        if action == "hide_channel":
            self._hideCurrentStalkerChannel(); return
        if action == "show_hidden_packages":
            self._showHiddenStalkerPackages(); return
        if action == "show_hidden_channels":
            self._showHiddenStalkerChannels(); return
        if action == "catchup":
            self._openStalkerCatchup(); return
        if action in ("lock_category", "lock_channel"):
            self._lockCurrentStalkerItem(action == "lock_category"); return
        if action in ("unlock_category", "unlock_channel"):
            self._requestStalkerPin(("unlock", action == "unlock_category")); return
        if action == "change_pin":
            self._requestStalkerPin(("change_pin", None)); return
        if action == "stalker_engines":
            self._openStalkerEngineSettings(); return
        if action == "stalker_recent":
            self._openStalkerRecentlyWatched(); return

    def _openStalkerRecentlyWatched(self):
        if self.source.get("type") != "stalker":
            return
        rows = _load_stalker_recent(self.source, 30)
        choices = []
        for resume_key, row in rows:
            title = str(row.get("title") or tr("Untitled"))
            position = int(row.get("position", 0) or 0)
            length = int(row.get("length", 0) or 0)
            if length > 0:
                pct = max(0, min(99, int(position * 100 / length)))
                label = "%s  •  %d%%" % (title, pct)
            else:
                label = "%s  •  %02d:%02d" % (title, position // 60, position % 60)
            choices.append((label, (resume_key, row)))
        if not choices:
            self.session.open(MessageBox, tr("No recently watched Stalker items."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerRecentlyWatched, ChoiceBox, title=tr("Recently watched"), list=choices)

    def _playStalkerRecentlyWatched(self, selected=None):
        if not selected:
            return
        try:
            _resume_key_value, row = selected[1]
            item = dict(row.get("item") or {})
            kind = str(row.get("kind") or "vod")
            if kind not in ("vod", "series"):
                kind = "vod"
            item["_source_type"] = "stalker"
            item["_source_key"] = _source_identity(self.source)
            item["_kind"] = kind
            url = StalkerClient(dict(self.source)).stream_url(item, kind)
            if not url:
                raise RuntimeError(tr("Portal returned no playable URL"))
            ref = eServiceReference(_stalker_service_type(self.source, kind), 0, url)
            ref.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, ref, item)
        except Exception as exc:
            self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)

    def _openStalkerEngineSettings(self):
        if self.source.get("type") != "stalker":
            return
        self._stalkerEngineValues = _load_stalker_service_types(self.source)
        self._chooseStalkerEngine("live")

    def _chooseStalkerEngine(self, kind):
        labels = {"live": tr("Stalker Live player"), "vod": tr("Stalker Movies player"), "series": tr("Stalker Series player")}
        current = int(self._stalkerEngineValues.get(kind, 4097))
        choices = []
        for value in STALKER_SERVICE_TYPE_CHOICES:
            choices.append(((u"✓ " if value == current else u"") + str(value), value))
        self.session.openWithCallback(lambda selected, k=kind: self._stalkerEngineSelected(k, selected), ChoiceBox, title=labels.get(kind, kind), list=choices)

    def _stalkerEngineSelected(self, kind, selected=None):
        if not selected:
            return
        try:
            value = int(selected[1])
        except Exception:
            return
        if value not in STALKER_SERVICE_TYPE_CHOICES:
            return
        self._stalkerEngineValues[kind] = value
        order = ("live", "vod", "series")
        try:
            next_kind = order[order.index(kind) + 1]
        except Exception:
            next_kind = None
        if next_kind:
            return self._chooseStalkerEngine(next_kind)
        if _save_stalker_service_types(self.source, self._stalkerEngineValues):
            self.session.open(MessageBox, tr("Stalker player engines saved."), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, tr("Unable to save Stalker player engines."), MessageBox.TYPE_ERROR)

    def _lockCurrentStalkerItem(self, is_category=False):
        if self.source.get("type") != "stalker":
            return
        state = _load_stalker_pin(self.source)
        if is_category:
            row = self["category"].getCurrent()
            if not row:
                return
            item_id = str(row[1] or "")
            if not item_id or item_id.startswith("__"):
                self.session.open(MessageBox, tr("This package cannot be locked."), MessageBox.TYPE_INFO); return
            state["categories"].add(item_id)
            state["category_names"][item_id] = str(row[0] or item_id)
            message = tr("Package locked.")
        else:
            item = self.current()
            if not item:
                return
            item_id = _live_item_id(item)
            if not item_id:
                return
            state["channels"].add(item_id)
            state["channel_names"][item_id] = str(item.get("name") or item.get("title") or item_id)
            message = tr("Channel locked.")
        _save_stalker_pin(self.source, state)
        try: self["desc"].setText(message)
        except Exception: pass

    def _requestStalkerPin(self, action):
        if time.time() < getattr(self, "_pinBlockedUntil", 0):
            wait = max(1, int(self._pinBlockedUntil - time.time()))
            self.session.open(MessageBox, "%s %s" % (tr("Try again in"), wait), MessageBox.TYPE_ERROR); return
        self._pinPendingAction = action
        self.session.openWithCallback(self._stalkerPinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _stalkerPinEntered(self, value=None):
        if value is None:
            self._pinPendingAction = None
            return
        state = _load_stalker_pin(self.source)
        if str(value).strip() != str(state.get("pin") or "0000"):
            self._pinFailures = getattr(self, "_pinFailures", 0) + 1
            if self._pinFailures >= 3:
                self._pinBlockedUntil = time.time() + 30
                self._pinFailures = 0
            self._pinPendingAction = None
            self.session.open(MessageBox, tr("Incorrect PIN"), MessageBox.TYPE_ERROR); return
        self._pinFailures = 0
        action = self._pinPendingAction
        self._pinPendingAction = None
        if not action:
            return
        kind, payload = action
        if kind == "play":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLivePlayerNow()
        if kind == "category":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLockedCategoryNow()
        if kind == "unlock":
            is_category = bool(payload)
            state = _load_stalker_pin(self.source)
            if is_category:
                row = self["category"].getCurrent()
                item_id = str(row[1] or "") if row else ""
                state["categories"].discard(item_id)
                state["category_names"].pop(item_id, None)
            else:
                item_id = _live_item_id(self.current())
                state["channels"].discard(item_id)
                state["channel_names"].pop(item_id, None)
            _save_stalker_pin(self.source, state)
            try: self["desc"].setText(tr("Lock removed."))
            except Exception: pass
            return
        if kind == "change_pin":
            self.session.openWithCallback(self._stalkerNewPinEntered, VirtualKeyBoard, title=tr("Enter new 4-digit PIN"), text="")

    def _stalkerNewPinEntered(self, value=None):
        value = str(value or "").strip()
        if not (len(value) == 4 and value.isdigit()):
            self.session.open(MessageBox, tr("PIN must contain exactly 4 digits."), MessageBox.TYPE_ERROR); return
        state = _load_stalker_pin(self.source)
        state["pin"] = value
        _save_stalker_pin(self.source, state)
        self.stalkerPinUnlockedUntil = time.time() + 300
        self.session.open(MessageBox, tr("Parental PIN changed."), MessageBox.TYPE_INFO)

    def _isCurrentStalkerCategoryLocked(self):
        if self.source.get("type") != "stalker":
            return False
        row = self["category"].getCurrent()
        cid = str(row[1] or "") if row else ""
        return bool(cid and cid in _load_stalker_pin(self.source)["categories"])

    def _isCurrentStalkerChannelLocked(self):
        if self.source.get("type") != "stalker":
            return False
        return _live_item_id(self.current()) in _load_stalker_pin(self.source)["channels"]

    def _hideCurrentStalkerCategory(self):
        row = self["category"].getCurrent()
        if not row:
            return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        state = _load_stalker_hidden(self.source)
        state["categories"].add(cid)
        state["category_names"][cid] = str(name or cid)
        _save_stalker_hidden(self.source, state)
        try:
            rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
            self["category"].setList(rows)
            self["list"].setList([])
            self.focus = "category"
            self["desc"].setText(tr("Package hidden. Use MENU to restore it."))
        except Exception:
            pass

    def _hideCurrentStalkerChannel(self):
        item = self.current()
        if not item:
            return
        channel_id = _live_item_id(item)
        if not channel_id:
            return
        state = _load_stalker_hidden(self.source)
        state["channels"].add(channel_id)
        state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id)
        _save_stalker_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        try: self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))
        except Exception: pass

    def _showHiddenStalkerPackages(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["category_names"].get(cid, cid), ("category", cid)) for cid in sorted(state["categories"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden packages."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden packages"), list=choices)

    def _showHiddenStalkerChannels(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["channel_names"].get(chid, chid), ("channel", chid)) for chid in sorted(state["channels"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden channels."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden channels"), list=choices)

    def _restoreHiddenStalkerItem(self, selected=None):
        if not selected:
            return
        try:
            kind, item_id = selected[1]
        except Exception:
            return
        state = _load_stalker_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        _save_stalker_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _openStalkerCatchup(self):
        item = self.current()
        if not item or self.source.get("type") != "stalker":
            return
        self._catchupItem = dict(item)
        self._catchupResult = None
        try: self["desc"].setText(tr("Loading catch-up programmes..."))
        except Exception: pass
        source = dict(self.source)
        channel_id = _live_item_id(item)
        def worker():
            rows, error = [], ""
            try:
                rows = StalkerClient(source).short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchupResult = (rows, error)
        threading.Thread(target=worker, name="TiviMateStalkerCatchup", daemon=True).start()
        self._catchupTimer = eTimer()
        _connect_timer(self._catchupTimer, self._finishStalkerCatchupLoad)
        try: self._catchupTimer.start(150, False)
        except Exception: pass

    def _finishStalkerCatchupLoad(self):
        result = getattr(self, "_catchupResult", None)
        if result is None:
            try: self._catchupTimer.start(150, False)
            except Exception: pass
            return
        try: self._catchupTimer.stop()
        except Exception: pass
        self._catchupResult = None
        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            channel = getattr(self, "_catchupItem", {}) or {}
            channel_archive = (
                channel.get("has_archive") or channel.get("archive") or
                channel.get("allow_archive") or channel.get("tv_archive") or
                channel.get("archive_duration") or channel.get("tv_archive_duration")
            )
            event_archived = str(archive or "").strip().lower() in ("1", "true", "yes", "on")
            channel_archived = str(channel_archive or "").strip().lower() not in ("", "0", "false", "no", "off")
            if begin and end and end <= now and title and (event_archived or channel_archived):
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))
        if not choices:
            message = tr("No catch-up programmes are available for this channel.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerCatchup, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _playStalkerCatchup(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = getattr(self, "_catchupItem", {}) or {}
        try:
            client = StalkerClient(dict(self.source))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))

            service_type = _stalker_service_type(self.source, "live")
            title = self._decodeEpgText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up"
            ref = eServiceReference(service_type, 0, url)
            ref.setName(title)

            play_item = dict(item)
            play_item["_source_type"] = "stalker"
            play_item["_source_key"] = _source_identity(self.source)
            play_item["_kind"] = "live"
            play_item["_catchup"] = True
            play_item["name"] = title

            self.session.openWithCallback(
                self.playerClosed, TiviMatePlayer, ref, play_item
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, source, "live")
        except Exception:
            pass


    def openContentPackages(self):
        if not self.source:
            self.session.open(MessageBox, tr("Add an IPTV source first."), MessageBox.TYPE_INFO, timeout=4)
            return
        if self.source.get("type") not in ("xtream", "stalker"):
            self.session.open(MessageBox, tr("Movies and TV Shows packages are available for Xtream and Stalker sources."), MessageBox.TYPE_INFO, timeout=5)
            return
        self._openPageOnce(ContentPackagesScreen, self.source)

    def openSettings(self):
        self._openPageOnce(SettingsDashboard)

    def selectServer(self, source):
        # r183: a Home server switch is a clean source boundary. Invalidate all
        # old async work and clear only in-memory state; persistent caches stay
        # isolated per source and are reused when switching back.
        self._sourceGeneration = getattr(self, "_sourceGeneration", 0) + 1
        self.featureRequestId = getattr(self, "featureRequestId", 0) + 1
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass
        self.homeMovieServerItems = []
        self.homeMovieIndexLoading = False
        # Server switching always lands on the Home default feed. This prevents
        # stale legacy Recent Added state from being revived for the new source.
        self.homeContentMode = "popular_movies"
        try:
            cfg = _load_home_appearance()
            _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
        except Exception:
            pass
        self.source = dict(source or {})
        self._saveActiveSource()
        self.recent = []
        self.posterIndex = 0
        self.globalHero = True
        self.resetPosters()
        self.startLoad()

    def resetPosters(self):
        for i in range(6):
            try: self["poster%d" % i].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "poster_placeholder.png"))
            except Exception: pass
            try:
                self["posterMetaTitle%d" % i].setText(tr(""))
                self["posterMetaRate%d" % i].setText(tr(""))
            except Exception: pass
        self.applyGlobalHero()

    def applyGlobalHero(self):
        """Render the application hero only until a selected poster supplies its own backdrop."""
        self.featureRequestId += 1
        request_id = self.featureRequestId
        self["quality"].setText(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"].setText(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"].setText(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"].setText(tr(""))
        self["playNow"].setText(tr("WATCH NOW"))
        # The Home row is never Recent Added anymore. While a feed is loading,
        # show the active Home feed title instead of the removed legacy label.
        home_labels = {
            "popular_movies": tr("Popular Movies"),
            "popular_series": tr("Popular TV Shows"),
            "trending_movies": tr("Movies You Might Like"),
            "trending_series": tr("TV Shows You Might Like"),
        }
        self["recentTitle"].setText(home_labels.get(getattr(self, "homeContentMode", "popular_movies"), tr("Popular Movies")))
        self._applyRecentTitleLayout()
        hero = os.path.join(PLUGIN_PATH, "skins", "tivimate_global_hero_r70.png")
        try:
            self.decodeImage(6, hero, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            try: self["banner"].instance.setPixmapFromFile(hero)
            except Exception: pass

    def _homeRecentCacheKey(self, source=None, mode=None):
        mode = str(mode or getattr(self, "homeContentMode", "recent_movies") or "recent_movies")
        raw = "%s|%s" % (_source_identity(source or self.source or {}), mode)
        try:
            return hashlib.sha1(raw.encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(raw).encode("utf-8")).hexdigest()

    def _loadHomeRecentCache(self):
        """Read only the six cached Recent rows for this source/mode."""
        path = _home_recent6_file(self.source or {}, getattr(self, "homeContentMode", "recent_movies"))
        try:
            if not os.path.isfile(path):
                return []
            with open_text(path, "r") as handle:
                payload = json.load(handle) or {}
            items = payload.get("items") or []
            if not isinstance(items, list):
                return []
            return items[:6]
        except Exception:
            return []

    def _saveHomeRecentCache(self, items, source=None):
        """Store only the final six Recent rows; never save a full provider index."""
        source = source or self.source or {}
        mode = getattr(self, "homeContentMode", "recent_movies")
        path = _home_recent6_file(source, mode)
        try:
            ensure_dir(os.path.dirname(path))
            payload = {
                "saved": int(time.time()),
                "mode": str(mode),
                "items": list(items or [])[:6],
            }
            tmp = path + ".tmp"
            with open_text(tmp, "w") as handle:
                json.dump(payload, handle)
            try:
                atomic_replace(tmp, path)
            except Exception:
                os.rename(tmp, path)
        except Exception:
            pass

    def _paintCachedRecent(self):
        cached = self._loadHomeRecentCache()
        if not cached:
            return False
        self._recentReady(cached, save_cache=False, background=False)
        return True

    def _homeMovieIndexCacheKey(self, source=None):
        try:
            return hashlib.sha1(_source_identity(source or self.source or {}).encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(_source_identity(source or self.source or {})).encode("utf-8")).hexdigest()

    def _loadCachedHomeMovieIndex(self):
        try:
            if not os.path.isfile(_home_movie_index_file()):
                return []
            with open_text(_home_movie_index_file(), "r") as handle:
                payload = json.load(handle) or {}
            row = (payload.get("sources") or {}).get(self._homeMovieIndexCacheKey(), {})
            items = row.get("items") or []
            return list(items or [])
        except Exception:
            return []

    def _saveCachedHomeMovieIndex(self, rows, source=None):
        try:
            ensure_dir(os.path.dirname(_home_movie_index_file()))
            payload = {}
            if os.path.isfile(_home_movie_index_file()):
                try:
                    with open_text(_home_movie_index_file(), "r") as handle:
                        payload = json.load(handle) or {}
                except Exception:
                    payload = {}
            sources = payload.get("sources")
            if not isinstance(sources, dict):
                sources = {}
            # Keep enough rows for fast in-memory matching, but not an unlimited catalog.
            sources[self._homeMovieIndexCacheKey(source)] = {
                "saved": int(time.time()),
                "items": list(rows or [])[:2500],
            }
            payload["sources"] = sources
            with open_text(_home_movie_index_file(), "w") as handle:
                json.dump(payload, handle)
        except Exception:
            pass

    def _scheduleHomeMovieIndexWarmup(self):
        # Never block initial Home rendering. Wait briefly until the TMDb cards
        # are already on screen, then warm the provider index in the background.
        def delayed():
            try:
                time.sleep(0.8)
            except Exception:
                pass
            self._preloadHomeMovieIndex()
        t = threading.Thread(target=delayed, name="TiviMateHomeMovieIndexDelay")
        t.daemon = True
        t.start()

    def _preloadHomeMovieIndex(self):
        if not self.source:
            return

        # Paint/use last known index immediately if available.
        if not self.homeMovieServerItems:
            try:
                cached = self._loadCachedHomeMovieIndex()
                if cached:
                    self.homeMovieServerItems = cached
            except Exception:
                pass

        if self.homeMovieIndexLoading:
            return

        self.homeMovieIndexLoading = True
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)

        def worker():
            rows = []
            try:
                rows = list(get_filtered_streams(source, "vod", get_source_client(source)) or [])
            except Exception:
                rows = []
            def finish():
                self.homeMovieIndexLoading = False
                if self._sourceJobValid(generation, source) and rows:
                    self.homeMovieServerItems = rows
                    try:
                        self._saveCachedHomeMovieIndex(rows, source)
                    except Exception:
                        pass
            try:
                if reactor:
                    reactor.callFromThread(finish)
                else:
                    finish()
            except Exception:
                try:
                    finish()
                except Exception:
                    pass

        t = threading.Thread(target=worker, name="TiviMateHomeMovieIndex")
        t.daemon = True
        t.start()

    def _homeCategoryText(self, category):
        row = category or {}
        return str(
            row.get("category_name") or row.get("name") or
            row.get("title") or row.get("genre") or ""
        ).strip().lower()

    def _homeCategoryAllowed(self, category, kind):
        """Keep Home server rails movie/series-only without doing network work."""
        text = self._homeCategoryText(category)
        if not text:
            return True
        # These are provider packages that are often exposed through VOD even
        # though they are not films/series.  Reject them before fetching rows.
        blocked = (
            "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
            "wwe", "wrestling", "raw", "smackdown", "nxt",
            "sport", "sports", "football", "soccer", "match", "matches", "event", "events",
            "anime", "animation", "cartoon", "kids", "children", "child",
            "theater", "theatre", "plays", "stage",
            "music", "songs", "concert", "karaoke",
            "program", "programs", "xxx", "adult", "18+",
            "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
            "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
            "اغاني", "أغاني", "برامج"
        )
        if any(token in text for token in blocked):
            return False
        if kind == "vod":
            wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
        else:
            wrong = ("movie", "movies", "film", "films", "cinema", "افلام", "أفلام")
        return not any(token in text for token in wrong)

    def _homeItemAllowed(self, item, kind, category_name=""):
        row = item or {}
        text = " ".join(str(row.get(k) or "") for k in (
            "name", "title", "genre", "category_name", "description"
        )).lower()
        if category_name:
            text += " " + str(category_name).lower()
        blocked = (
            "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
            "wwe", "wrestling", "smackdown", "nxt",
            "sport", "sports", "football", "soccer", "match", "matches",
            "anime", "animation", "cartoon", "kids", "children",
            "theater", "theatre", "stage", "music", "concert", "karaoke",
            "program", "programs", "xxx", "adult",
            "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
            "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
            "اغاني", "أغاني", "برامج"
        )
        if any(token in text for token in blocked):
            return False
        if kind == "vod":
            wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
        else:
            wrong = ("movie", "movies", "film", "cinema", "افلام", "أفلام")
        return not any(token in text for token in wrong)

    def _homeCanonicalKey(self, item, kind):
        """Collapse the same title across 4K/FHD/language/provider copies."""
        row = item or {}
        tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
        if tmdb_id and tmdb_id not in ("0", "None", "none"):
            return "tmdb:%s:%s" % (str(kind or "vod"), tmdb_id)
        raw = str(row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or "")
        year_text = " ".join(str(row.get(k) or "") for k in (
            "year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"
        ))
        m = re.search(r"\b(?:19|20)\d{2}\b", year_text)
        year = m.group(0) if m else ""
        text = raw.lower()
        text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
        text = re.sub(
            r"(?i)\b(?:8k|4k|uhd|fhd|fullhd|hd|sd|2160p|1080p|720p|hdr|hdr10|dv|dolby|atmos|"
            r"hevc|x265|x264|h265|h264|web[- ]?dl|webrip|bluray|blu[- ]?ray|remux|"
            r"nf|netflix|amz|amzn|amazon|prime|prime video|ar|ara|arabic|en|eng|english|fr|french|"
            r"sub|subs|dub|dubbed|multi)\b", " ", text
        )
        text = re.sub(r"[\[\]{}()_.|:+/\\-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            sid = str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or "").strip()
            return "id:%s:%s" % (str(kind or "vod"), sid)
        return "%s|%s|%s" % (str(kind or "vod"), text, year)

    def _homeQualityScore(self, item):
        text = " ".join(str((item or {}).get(k) or "") for k in ("name", "title", "quality", "container_extension")).lower()
        score = 0
        if "8k" in text:
            score = 80
        elif "4k" in text or "2160" in text:
            score = 70
        elif "uhd" in text:
            score = 65
        elif "fhd" in text or "1080" in text:
            score = 50
        elif re.search(r"\bhd\b|720", text):
            score = 30
        elif re.search(r"\bsd\b", text):
            score = 10
        # Prefer the copy with richer artwork/metadata when quality is tied.
        meta = sum(1 for k in ("stream_icon", "cover_big", "cover", "movie_image", "poster", "backdrop_path", "rating", "plot") if (item or {}).get(k))
        return score * 100 + meta

    def _homeDeduplicate(self, items, kind):
        best = {}
        order = []
        for raw in list(items or []):
            if not isinstance(raw, dict):
                continue
            row = dict(raw)
            key = self._homeCanonicalKey(row, kind)
            if not key:
                continue
            if key not in best:
                best[key] = row
                order.append(key)
            elif self._homeQualityScore(row) > self._homeQualityScore(best[key]):
                best[key] = row
        return [best[k] for k in order if k in best]

    def _homeStampSource(self, row, source, kind, cid="", category_name=""):
        item = dict(row or {})
        cid = str(cid or item.get("category_id") or item.get("categoryId") or "").strip()
        if cid:
            item["category_id"] = cid
            item["_source_category_id"] = cid
        if category_name:
            item["_source_category_name"] = str(category_name)
        item["_source_scope"] = "home_category" if cid else "home"
        item["_source_server_id"] = _source_identity(source or {})
        item["_tivimate_home_kind"] = kind
        return item

    def _homeContextItems(self, item, kind):
        """Resolve the selected Home item's real package from RAM/disk only."""
        row = dict(item or {})
        cid = str(row.get("_source_category_id") or row.get("category_id") or row.get("categoryId") or "").strip()
        if not cid or not self.source:
            return list(self.recent or [])
        rows = []
        try:
            rows, _origin = get_category_streams(
                self.source, kind, get_source_client(self.source), cid,
                use_cache=True, wait_for_server=False
            )
        except Exception:
            rows = []
        if not rows:
            candidates = list(self.homeMovieServerItems or []) + list(self.recent or [])
            rows = [x for x in candidates if str((x or {}).get("category_id") or (x or {}).get("categoryId") or "").strip() == cid]
        cname = str(row.get("_source_category_name") or "")
        stamped = [self._homeStampSource(x, self.source, kind, cid, cname) for x in list(rows or []) if isinstance(x, dict)]
        return self._homeDeduplicate(stamped, kind) or [row]

    def _startHomeServer2026Rotating(self, mode):
        """Home rows use the exact normal Search path with an internal fixed query: 2026."""
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        mode = str(mode or "popular_movies")
        kind = "series" if mode in ("popular_series", "trending_series") else "vod"
        self.stalkerRecentResult = None

        # Separate cache namespace so older pool/rotation results can never leak in.
        # Popular rows are plain/random from enabled packages only.
        # You Might Like rows are random 2026 matches from enabled packages only.
        if mode in ("popular_movies", "popular_series"):
            base_cache_mode = "%s_any_v2" % mode
        else:
            base_cache_mode = "exact_search_2026_random_v2_%s" % mode
        cache_mode = _home_server_filter_cache_mode(source, base_cache_mode)
        cached = _home_server_2026_cache_get(source, cache_mode)
        if cached:
            try:
                self._recentReady(cached, save_cache=False)
            except Exception:
                pass
            return

        try:
            self["status"].setText(tr("Loading Home content..."))
        except Exception:
            pass

        def worker():
            try:
                import random
                client = get_source_client(source)
                q = "2026"

                # Exact normal-Search semantics for You Might Like: local title match on 2026.
                # Popular Movies/TV Shows are different by design: any enabled item is eligible.
                # selected package ids only -> cache-backed package streams ->
                # local title/name substring match. No secondary catalog/fallback.
                allowed = get_allowed_category_ids(source, kind)
                if not allowed:
                    raise RuntimeError("No enabled packages are selected")
                allowed = set(str(x) for x in allowed if str(x))
                if not allowed:
                    raise RuntimeError("No enabled packages are selected")

                ordered_ids = []
                category_names = {}
                try:
                    categories, _origin = get_cached_categories(
                        source, kind, client=client, wait_for_server=False
                    )
                    for cat in categories or []:
                        if not isinstance(cat, dict):
                            continue
                        cid = str(cat.get("category_id") or "")
                        if cid:
                            category_names[cid] = str(cat.get("category_name") or cat.get("name") or "")
                        if cid and cid in allowed and cid not in ordered_ids:
                            ordered_ids.append(cid)
                except Exception:
                    pass
                for cid in allowed:
                    if cid not in ordered_ids:
                        ordered_ids.append(cid)

                # For both Popular rows, randomize enabled packages before fetching so
                # the fast early-stop does not always favor the first packages.
                if mode in ("popular_movies", "popular_series"):
                    random.shuffle(ordered_ids)

                pool = []
                seen = set()
                # Early-stop Search 2026: fetch enabled packages in small bounded batches
                # and stop as soon as Home has enough FINAL candidates. This avoids waiting
                # for every enabled package on very large providers.
                target_count = 8
                batch_size = 4
                for offset in range(0, len(ordered_ids), batch_size):
                    package_batches = get_category_streams_batch(
                        source, kind, client, ordered_ids[offset:offset + batch_size],
                        use_cache=True, wait_for_server=True, max_workers=4
                    )
                    for cid, rows, _origin in package_batches:
                        for raw in rows or []:
                            if not isinstance(raw, dict):
                                continue
                            item_cid = str(
                                raw.get("category_id") or raw.get("categoryId") or
                                raw.get("genre_id") or raw.get("genre-id") or ""
                            )
                            if item_cid and item_cid not in allowed:
                                continue
                            title = str(raw.get("name") or raw.get("title") or "")
                            if mode not in ("popular_movies", "popular_series") and q not in title.lower():
                                continue
                            row = dict(raw)
                            cname = category_names.get(cid, "")
                            row = self._homeStampSource(row, source, kind, cid, cname)
                            key = self._homeCanonicalKey(row, kind)
                            if not key:
                                continue
                            if key in seen:
                                for idx, existing in enumerate(pool):
                                    if self._homeCanonicalKey(existing, kind) == key and self._homeQualityScore(row) > self._homeQualityScore(existing):
                                        pool[idx] = row
                                        break
                                continue
                            seen.add(key)
                            row["_home_server_2026"] = True
                            row["_home_rotation_mode"] = mode
                            pool.append(row)

                    pool = self._homeDeduplicate(pool, kind)
                    if mode in ("popular_movies", "popular_series"):
                        if len(pool) >= target_count:
                            break
                    elif len(pool) >= target_count:
                        break

                pool = self._homeDeduplicate(pool, kind)
                if not pool:
                    if mode in ("popular_movies", "popular_series"):
                        raise RuntimeError("No content is available in enabled packages")
                    raise RuntimeError("Search 2026 returned no matching content")

                # One final selection only. TMDb must never repaint the row.
                # Final Home selection is random for all four rows.
                # Popular: any enabled content. You Might Like: only 2026 title matches.
                random.shuffle(pool)
                rows = pool[:8]

                if not rows:
                    if mode in ("popular_movies", "popular_series"):
                        raise RuntimeError("No usable content is available")
                    raise RuntimeError("Search 2026 returned no usable content")
                _home_server_2026_cache_put(source, cache_mode, rows)
                if self._sourceJobValid(generation, source):
                    self.stalkerRecentResult = (-100, rows, "")
            except Exception as exc:
                if self._sourceJobValid(generation, source):
                    self.stalkerRecentResult = (-100, [], str(exc))

        thread = threading.Thread(target=worker, name="TiviMateHomeExactSearch2026_%s" % mode)
        thread.daemon = True
        thread.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            pass

    def _startHomePopularServer2026(self):
        # Backward-compatible wrapper kept for older internal callers.
        return self._startHomeServer2026Rotating("popular_movies")

    def startLoad(self):
        if not self.source:
            self["status"].setText(tr("No server selected • Press SETTINGS"))
            return

        mode = getattr(self, "homeContentMode", "popular_movies") or "popular_movies"
        # Recent Added is intentionally NOT a Home startup feed anymore.
        # Old saved configs are migrated at runtime without starting any provider scan.
        if mode in ("recent_movies", "recent_series"):
            mode = "popular_movies"
            self.homeContentMode = mode
            try:
                cfg = _load_home_appearance()
                _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
            except Exception:
                pass

        # Home rows are server-only. Popular Movies/TV Shows are fully random
        # across enabled packages. You Might Like rows are random 2026 matches.
        # All four feeds remain fixed for 6 hours via the per-server cache.
        if mode in ("popular_movies", "popular_series", "trending_movies", "trending_series"):
            return self._startHomeServer2026Rotating(mode)

        # Legacy TMDb branch retained for compatibility with older/custom modes.
        # Refresh still happens in the background, but cached Home never shows Loading.
        if mode.startswith(("popular_", "trending_")):
            source = dict(self.source or {})
            generation = getattr(self, "_sourceGeneration", 0)
            cached_rows = _home_tmdb_cache_get(mode)
            if not cached_rows and mode != "popular_movies":
                cached_rows = _home_tmdb_cache_get("popular_movies")

            if cached_rows:
                try:
                    self._recentReady(cached_rows[:6], save_cache=False)
                except Exception:
                    pass
            else:
                self["status"].setText(tr("Loading Home content..."))

            def tmdb_worker():
                try:
                    rows = TMDbClient().home_feed(mode, 6)
                    if not rows and mode != "popular_movies":
                        rows = TMDbClient().home_feed("popular_movies", 6)
                    if rows:
                        _home_tmdb_cache_put(mode, rows)
                    if self._sourceJobValid(generation, source):
                        # Repaint only when there was no cache or the feed changed.
                        if (not cached_rows) or rows != cached_rows[:len(rows)]:
                            self.stalkerRecentResult = (-100, rows, "")
                        else:
                            self.stalkerRecentResult = (-101, [], "")
                except Exception as exc:
                    # Keep cached Home visible on transient TMDb failures.
                    if cached_rows:
                        self.stalkerRecentResult = (-101, [], "")
                    else:
                        try:
                            rows = TMDbClient().home_feed("popular_movies", 6)
                            if rows:
                                _home_tmdb_cache_put("popular_movies", rows)
                            self.stalkerRecentResult = (-100, rows, "")
                        except Exception:
                            self.stalkerRecentResult = (-100, [], str(exc))
            thread = threading.Thread(target=tmdb_worker, name="TiviMateHomeTMDb")
            thread.daemon = True
            thread.start()
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return

        # Home has no Recent Added feed. Recent Added remains available only
        # inside the Movies / TV Shows package browser. Any legacy/custom Home
        # mode falls back to Popular Movies instead of starting a Recent scan.
        if mode in ("recent_movies", "recent_series"):
            self.homeContentMode = "popular_movies"
            return self._startHomeServer2026Rotating("popular_movies")

        # Home supports only Popular/Trending feeds. Any unknown/custom legacy
        # mode falls back to Popular Movies; it must never start a Recent scan.
        self.homeContentMode = "popular_movies"
        return self._startHomeServer2026Rotating("popular_movies")

    def _startHomePopularFallback(self):
        self.homeContentMode = "popular_movies"
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        cached_rows = _home_tmdb_cache_get("popular_movies")
        if cached_rows:
            try:
                self._recentReady(cached_rows[:6], save_cache=False)
            except Exception:
                pass
        def worker():
            try:
                rows = TMDbClient().home_feed("popular_movies", 6)
                if rows:
                    _home_tmdb_cache_put("popular_movies", rows)
                if self._sourceJobValid(generation, source):
                    if (not cached_rows) or rows != cached_rows[:len(rows)]:
                        self.stalkerRecentResult = (-100, rows, "")
                    else:
                        self.stalkerRecentResult = (-101, [], "")
            except Exception as exc:
                self.stalkerRecentResult = (-101, [], "") if cached_rows else (-100, [], str(exc))
        t = threading.Thread(target=worker, name="TiviMateHomePopularFallback")
        t.daemon = True
        t.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            pass

    def _finishStalkerRecentLoad(self):
        result = self.stalkerRecentResult
        if result is None:
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return
        # Do not erase a newer worker result that may have arrived while this
        # UI callback was being scheduled for an older request token.
        if self.stalkerRecentResult is result:
            self.stalkerRecentResult = None
        token, items, error = result
        if token == -101:
            # Background refresh found no visible change; keep current Home untouched.
            return
        if token == -100:
            if error or not items:
                self._recentFailed(error or "TMDb returned no Home content")
                return
            self._recentReady(items, save_cache=False)
            mode = getattr(self, "homeContentMode", "") or ""
            if mode.endswith("_movies") and not any((x or {}).get("_home_server_2026") for x in list(items or [])):
                try:
                    self._scheduleHomeMovieIndexWarmup()
                except Exception:
                    pass
            return
        if token != self.stalkerRecentToken:
            return
        if error or not items:
            self._startHomePopularFallback()
            return
        self._recentReady(items)

    def _recentFailed(self, error):
        self["status"].setText("Unable to load Home content: %s" % error)

    def _recentReady(self, items, save_cache=True, background=True):
        items = list(items or [])[:6]
        if save_cache:
            self._saveHomeRecentCache(items, self.source)
        # If cached content is already visible and the background refresh found
        # exactly the same six entries, keep the existing pixmaps/hero untouched.
        try:
            old_ids = [str((x or {}).get("stream_id") or (x or {}).get("vod_id") or (x or {}).get("name") or "") for x in self.recent]
            new_ids = [str((x or {}).get("stream_id") or (x or {}).get("vod_id") or (x or {}).get("name") or "") for x in items]
            if background and self.recent and old_ids == new_ids:
                return
        except Exception:
            pass
        self.recent = items
        heading = tr("Popular Movies")
        status_label = tr("%d Home picks") % len(self.recent)
        mode = getattr(self, "homeContentMode", "popular_movies")
        labels = {
            "popular_movies": tr("Popular Movies"),
            "popular_series": tr("Popular TV Shows"),
            "trending_movies": tr("Movies You Might Like"),
            "trending_series": tr("TV Shows You Might Like"),
        }
        heading = labels.get(mode, heading)
        status_label = tr("%d Home picks") % len(self.recent)
        self["recentTitle"].setText(heading)
        self._applyRecentTitleLayout()
        self["status"].setText(tr("Server: %s  •  %s") % (self.source.get("name", "SERVER"), status_label))
        for i, item in enumerate(self.recent[:6]):
            pw, ph = self.posterSize
            poster_url = item.get("stream_icon") or item.get("cover_big") or item.get("cover") or item.get("movie_image") or item.get("poster") or ""
            if poster_url:
                self.loadImage(i, poster_url, "poster%d" % i, pw, ph, fallback_item=item)
            else:
                self._homePosterFallback(item, i, "poster%d" % i, pw, ph)
            title = str(item.get("name") or item.get("title") or "").strip()
            rating = str(item.get("rating") or item.get("rating_5based") or "").strip()
            self["posterMetaTitle%d" % i].setText(title[:22] + ("…" if len(title) > 22 else ""))
            self["posterMetaRate%d" % i].setText(rating[:4])
        prefetch_artwork([
            (row or {}).get("stream_icon") or (row or {}).get("cover_big") or (row or {}).get("cover") or
            (row or {}).get("movie_image") or (row or {}).get("poster") or ""
            for row in list(self.recent or [])
        ], "home", priority=2)
        prefetch_artwork([
            self._normaliseBackdrop((row or {}).get("backdrop_path") or (row or {}).get("backdrop") or (row or {}).get("backdrop_url"))
            for row in list(self.recent or [])
        ], "backdrops", priority=1)
        self.posterIndex = 0
        self.globalHero = not bool(self.recent)
        if self.globalHero:
            self.applyGlobalHero()
        else:
            self.updateFeature()
        self.updateFocus()

    def updateFeature(self):
        # The selected poster owns the banner once the library row is ready.
        if not self.recent: return
        item = self.recent[min(self.posterIndex, len(self.recent)-1)]
        self["featureTitle"].setText((item.get("name") or item.get("title") or "MOVIE").upper())
        year = str(item.get("year") or item.get("releaseDate") or "")
        rating = str(item.get("rating") or "")
        genre = str(item.get("genre") or "")
        self["featureMeta"].setText("  •  ".join(x for x in [year, ("★ " + rating) if rating else "", genre] if x))
        self["featureDesc"].setText((item.get("plot") or item.get("description") or "From the selected server.")[:180])

        # Use a true backdrop in the middle banner. Do not stretch the poster.
        self.featureRequestId += 1
        request_id = self.featureRequestId
        stream_id = item.get("stream_id") or item.get("vod_id")
        direct_backdrop = self._normaliseBackdrop(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        if direct_backdrop:
            self.loadImage(6, direct_backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        elif stream_id:
            source = dict(self.source or {})
            generation = getattr(self, "_sourceGeneration", 0)
            item_snapshot = dict(item or {})
            thread = threading.Thread(target=self._loadFeatureBackdrop, args=(stream_id, request_id, source, generation, item_snapshot), name="TiviMateBackdrop")
            thread.daemon = True
            thread.start()

    def _normaliseBackdrop(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if not isinstance(value, str):
            return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("["):
            try:
                arr = json.loads(value)
                value = arr[0] if arr else ""
            except Exception:
                pass
        if value.startswith("/") and not value.startswith("//"):
            value = "https://image.tmdb.org/t/p/w1280" + value
        return value if value.startswith(("http://", "https://")) else ""

    def _cleanRecentTitle(self, value):
        import re
        text = str(value or "")
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray|top)\b", " ", text, flags=re.I)
        text = re.sub(r"[\[\]{}()_.|:+-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _recentYear(self, item):
        import re
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        match = re.search(r"\b(?:19|20)\d{2}\b", raw)
        return int(match.group(0)) if match else None

    def _loadFeatureBackdrop(self, stream_id, request_id, source=None, generation=None, item_snapshot=None):
        source = dict(source or self.source or {})
        generation = getattr(self, "_sourceGeneration", 0) if generation is None else generation
        item_snapshot = dict(item_snapshot or {})
        try:
            if not self._sourceJobValid(generation, source):
                return
            data = XtreamClient(source).vod_info(stream_id) or {}
            info = {}
            if isinstance(data.get("movie_data"), dict): info.update(data.get("movie_data") or {})
            if isinstance(data.get("info"), dict): info.update(data.get("info") or {})
            backdrop = self._normaliseBackdrop(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                data.get("backdrop_path") or data.get("backdrop")
            )
            # Home Movies sometimes contains only a poster. Resolve the movie on
            # TMDb and use its true backdrop without changing any other section.
            if not backdrop:
                current = item_snapshot
                tmdb = TMDbClient()
                tid = info.get("tmdb_id") or info.get("tmdb") or current.get("tmdb_id") or current.get("tmdb")
                if not tid:
                    title = info.get("name") or current.get("name") or current.get("title") or ""
                    found = tmdb.search_artwork(title, "vod", self._recentYear(info or current), required_key="backdrop_path") if str(title or "").strip() else None
                    tid = (found or {}).get("id")
                bundle = tmdb.details_bundle(tid, "vod") if tid else {}
                backdrop = self._normaliseBackdrop(bundle.get("backdrop_path"))
            if backdrop and request_id == self.featureRequestId and self._sourceJobValid(generation, source):
                if reactor is not None:
                    reactor.callFromThread(self._applyFeatureBackdropForSource, generation, source, request_id, backdrop)
                else:
                    self._applyFeatureBackdropForSource(generation, source, request_id, backdrop)
        except Exception:
            pass

    def _applyFeatureBackdropForSource(self, generation, source, request_id, backdrop):
        if not self._sourceJobValid(generation, source):
            return
        if request_id != getattr(self, "featureRequestId", -1):
            return
        self.loadImage(6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)

    def _homePosterYear(self, item):
        try:
            raw = " ".join(str((item or {}).get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
            match = re.search(r"\b(?:19|20)\d{2}\b", raw)
            return int(match.group(0)) if match else None
        except Exception:
            return None

    def _homePosterKind(self, item):
        marker = str((item or {}).get("_tivimate_home_kind") or "").lower()
        if marker in ("series", "tv", "shows", "tvshows"):
            return "series"
        if (item or {}).get("series_id") is not None and not (item or {}).get("stream_id"):
            return "series"
        return "vod"

    def _homePosterFallback(self, item, slot, widget, width, height, failed_url=""):
        snapshot = dict(item or {})
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        key = (slot, widget)

        def worker():
            try:
                if not self._sourceJobValid(generation, source):
                    return
                title = snapshot.get("name") or snapshot.get("title") or snapshot.get("original_name") or snapshot.get("original_title") or ""
                if not str(title or "").strip():
                    return
                found = TMDbClient().search_artwork(
                    title,
                    self._homePosterKind(snapshot),
                    self._homePosterYear(snapshot),
                    required_key="poster_path"
                ) or {}
                poster = str(found.get("poster_path") or "").strip()
                if not poster:
                    return
                if poster.startswith("/"):
                    poster = "https://image.tmdb.org/t/p/w500" + poster

                def apply():
                    if not self._sourceJobValid(generation, source):
                        return
                    current = getattr(self, "_artwork_requests", {}).get(key)
                    if failed_url and current != (failed_url, None):
                        return
                    self.loadImage(slot, poster, widget, width, height)

                if reactor is not None:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMateHomePosterFallback")
        t.daemon = True
        t.start()

    def _homePosterFileValid(self, path):
        """Cheap Home-card validation matching the working Movies/Series path."""
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return bool(head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n"))
        except Exception:
            return False

    def loadImage(self, slot, url, widget, width, height, request_id=None, fallback_item=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url or (request_id is not None and request_id != self.featureRequestId):
            return
        # One token per visual slot prevents a prior selection from painting over
        # the current poster or backdrop after the user moves the selection.
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        token = (slot, widget)
        requests[token] = (url, request_id)
        priority = 120 if widget == "banner" else 75

        def done(path, s=slot, w=widget, x=width, y=height, rid=request_id, expected=(url, request_id), key=token, item=fallback_item):
            if getattr(self, "_artwork_requests", {}).get(key) != expected:
                return
            # Home used to treat HTTP-200 error bodies as posters.  The working
            # Movies/Series cards validate these bytes and immediately fall back
            # to TMDb, so use the exact same policy here.
            if item is not None and rid is None and not self._homePosterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._homePosterFallback(item, s, w, x, y, url)
                return
            self.decodeImage(s, path, w, x, y, request_id=rid)

        def failed(_path, s=slot, w=widget, x=width, y=height, expected_url=url, item=fallback_item):
            if item is not None and request_id is None:
                self._homePosterFallback(item, s, w, x, y, expected_url)

        request_artwork(url, "home", done, priority=priority, errback=failed if fallback_item is not None else None)

    def decodeImage(self, slot, path, widget, width, height, request_id=None):
        if request_id is not None and request_id != self.featureRequestId:
            return
        loader = ePicLoad(); self.imageLoaders[slot] = loader
        def ready(_info=None, slot=slot, widget=widget, request_id=request_id, l=loader):
            try:
                if request_id is not None and request_id != self.featureRequestId:
                    return
                ptr = l.getData()
                if ptr and self[widget].instance: self[widget].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.imageLoaders[slot] is l:
                        self.imageLoaders[slot] = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        # A zero aspect ratio makes ePicLoad fill the complete panorama.
        # Both remaining Home skins use this decoding path.
        # so selected movie backdrops cannot be letterboxed with black side areas.
        render_width, render_height = scale_size(width, height)
        if widget == "banner" and self.homeSkinName in ("reference_home", "skin2_dark"):
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        else:
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def playRecent(self):
        if not self.recent or not self.source:
            return
        item = dict(self.recent[self.posterIndex] or {})
        if item.get("_home_tmdb_feed") or item.get("_tmdb"):
            kind = str(item.get("_tivimate_home_kind") or item.get("media_type") or "vod")
            item["_home_tmdb_feed"] = item.get("_home_tmdb_feed") or getattr(self, "homeContentMode", "popular_movies")
            if kind == "series":
                self.session.open(SeriesDetailsScreen, self.source, item)
            else:
                # Home never checks server availability before opening details.
                # The details screen performs the provider search after entry.
                item["_source_scope"] = str(item.get("_source_scope") or "home")
                item["_source_server_id"] = _source_identity(self.source)
                cid = str(item.get("_source_category_id") or item.get("category_id") or "").strip()
                context_items = self._homeContextItems(item, "vod") if cid else list(self.homeMovieServerItems or [])
                self.session.open(
                    MovieDetailsScreen, self.source, item, context_items,
                    {"scope":item.get("_source_scope") or "home", "category_id":cid, "items":list(context_items or [])}
                )
            return

        kind = str(item.get("_tivimate_home_kind") or "vod")
        item["_recent_home"] = True
        if kind == "series":
            self.session.open(SeriesDetailsScreen, self.source, item)
        else:
            item["_source_scope"] = str(item.get("_source_scope") or "home_category")
            item["_source_server_id"] = _source_identity(self.source)
            cid = str(item.get("_source_category_id") or item.get("category_id") or "").strip()
            context_items = self._homeContextItems(item, "vod") if cid else list(self.recent or [])
            self.session.open(
                MovieDetailsScreen, self.source, item, context_items,
                {"scope":item.get("_source_scope") or "home_category", "category_id":cid, "items":list(context_items or [])}
            )

from .tivimate_player import TiviMatePlayer, _load_player_type


class ContinueWatchingScreen(Screen):
    skin = '<screen name="ContinueWatchingScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">\n<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />\n<widget name="hero" position="0,0" size="1920,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/continue_default_hero.jpg" alphatest="blend" scale="1" zPosition="1" />\n<ePixmap position="0,0" size="1920,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_overlay.png" alphatest="blend" zPosition="2" />\n<ePixmap position="46,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />\n<widget name="top0" position="76,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="231,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />\n<widget name="top1" position="261,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="416,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />\n<widget name="top2" position="446,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="601,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />\n<widget name="top3" position="631,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="786,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />\n<widget name="top4" position="816,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="971,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />\n<widget name="top5" position="1001,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="1156,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />\n<widget name="top6" position="1186,32" size="314,52" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<ePixmap position="1516,46" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />\n<widget name="top7" position="1546,32" size="139,52" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />\n<widget name="topSelector" position="900,88" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />\n<widget name="heroTitle" position="95,142" size="940,82" font="Regular;50" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroMeta" position="100,240" size="940,42" font="Regular;27" foregroundColor="#5ADAF4" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroStars" position="100,278" size="940,34" font="Regular;24" foregroundColor="#FFD34E" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="heroDesc" position="100,322" size="980,70" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroProgress" position="100,418" size="650,12" borderWidth="0" backgroundColor="#38424D" foregroundColor="#FFFFFF" zPosition="5" />\n<widget name="heroPercent" position="770,402" size="130,36" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />\n<widget name="moviesTitle" position="80,468" size="720,38" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="moviesPage" position="1480,470" size="360,34" font="Regular;21" foregroundColor="#9ADFED" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />\n<widget name="seriesTitle" position="80,724" size="720,38" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="seriesPage" position="1480,726" size="360,34" font="Regular;21" foregroundColor="#9ADFED" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" /><widget name="card0" position="82,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="80,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title0" position="94,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta0" position="94,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card1" position="537,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="535,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title1" position="549,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta1" position="549,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card2" position="992,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="990,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title2" position="1004,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta2" position="1004,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card3" position="1447,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="1445,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title3" position="1459,688" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta3" position="1459,711" size="360,20" font="Regular;16" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card4" position="82,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="80,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title4" position="94,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta4" position="94,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card5" position="537,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="535,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title5" position="549,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta5" position="549,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card6" position="992,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="990,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title6" position="1004,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta6" position="1004,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card7" position="1447,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<ePixmap position="1445,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />\n<widget name="title7" position="1459,933" size="360,24" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta7" position="1459,956" size="360,20" font="Regular;16" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="focus" position="80,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_410x210.png" alphatest="blend" scale="1" zPosition="8" />\n<widget name="empty" position="365,620" size="1190,70" font="Regular;28" foregroundColor="#AAB6C2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />\n\n\n\n<widget name="posterBottomControl" position="730,970" size="460,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/continue_poster_backdrop_menu.png" alphatest="blend" scale="1" zPosition="30" />\n<widget name="backdropBottomControl" position="730,970" size="460,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/continue_poster_backdrop_menu.png" alphatest="blend" scale="1" zPosition="30" />\n</screen>'

    RESUME_FILE = data_path("resume.json")
    VIEW_FILE = data_path("continue_view.json")
    CARD_COUNT = 4
    X = [80, 535, 990, 1445]
    MOVIE_Y = 525
    SERIES_Y = 770


    def __init__(self, session, current_source=None):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.currentSource = dict(current_source or {})
        self["hero"] = Pixmap(); self["heroTitle"] = Label(tr("YOUR STORY CONTINUES HERE")); self["heroMeta"] = Label(tr("Movies  •  TV Shows")); self["heroDesc"] = Label(tr("Start watching and unfinished titles will appear here automatically."))
        self["heroPercent"] = Label(""); self["heroStars"] = Label(""); self["heroProgress"] = ProgressBar(); self["moviesTitle"] = Label(tr("Continue Watching") + "  •  " + tr("Movies")); self["seriesTitle"] = Label(tr("Continue Watching") + "  •  " + tr("TV Shows"))
        self.topNames = [nav_label("Search"), nav_label("Home"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("Continue Watching"), nav_label("Settings")]
        for i, name in enumerate(self.topNames):
            self["top%d" % i] = Label(name)
        self["topSelector"] = Pixmap()
        self["moviesPage"] = Label(""); self["seriesPage"] = Label(""); self["focus"] = Pixmap(); self["empty"] = Label(""); self["posterBottomControl"] = Pixmap(); self["backdropBottomControl"] = Pixmap()
        try: self["heroProgress"].setRange((0,100))
        except Exception: pass
        for i in range(8):
            self["card%d" % i] = Pixmap(); self["title%d" % i] = Label(""); self["meta%d" % i] = Label(""); self["prog%d" % i] = ProgressBar()
            try: self["prog%d" % i].setRange((0,100))
            except Exception: pass
        self.movies=[]; self.series=[]; self.moviePage=0; self.seriesPage=0; self.row=0; self.index=0; self._generation=0; self._heroUrl=""; self._loaders=[]
        self.viewMode = self._loadViewMode()
        self.navFocus = "top"
        self.topIndex = 6
        self.topX = [40, 225, 410, 595, 780, 965, 1150, 1510]
        self.topW = [175, 175, 175, 175, 175, 175, 350, 175]
        self["actions"] = ActionMap(["OkCancelActions","DirectionActions","MenuActions","ColorActions"], {"ok":self.ok,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,"menu":self.openOptions,"red":self.removeSelected,"yellow":self.clearAll,"blue":self.toggleViewMode}, -1)
        self.onLayoutFinish.append(self._applyContinueViewLayout); self.onLayoutFinish.append(self._updatePosterBottomControl); self.onLayoutFinish.append(self.reload); self.onLayoutFinish.append(self._updateTopFocus)

    def _loadViewMode(self):
        try:
            with open(self.VIEW_FILE, "r") as h:
                data = json.load(h) or {}
            mode = str(data.get("mode") or "").lower()
            if mode in ("poster", "backdrop"):
                return mode
        except Exception:
            pass
        return "backdrop"

    def _saveViewMode(self):
        try:
            folder = os.path.dirname(self.VIEW_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = self.VIEW_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump({"mode": self.viewMode}, h, separators=(",", ":"))
            os.rename(tmp, self.VIEW_FILE)
        except Exception:
            pass

    def _load(self):
        try:
            with open(self.RESUME_FILE,"r") as h: data=json.load(h)
            return data if isinstance(data,dict) else {}
        except Exception: return {}
    def _save(self,data):
        try:
            folder=os.path.dirname(self.RESUME_FILE)
            if folder and not os.path.isdir(folder): os.makedirs(folder)
            tmp=self.RESUME_FILE+".tmp"
            with open(tmp,"w") as h: json.dump(data,h,separators=(",",":"),sort_keys=True)
            os.rename(tmp,self.RESUME_FILE)
        except Exception: pass
    def _isSeries(self,row):
        item = row.get("item") or {}
        kind = str(row.get("kind") or item.get("_kind") or "").lower()
        if kind in ("series", "tv", "show"):
            return True
        has_episode_identity = bool(
            row.get("episode") not in (None, "") or
            item.get("episode_num") not in (None, "") or
            item.get("episode_number") not in (None, "") or
            item.get("_subdl_episode") not in (None, "") or
            ((row.get("season") not in (None, "") or item.get("season") not in (None, "") or item.get("season_number") not in (None, "")) and
             (item.get("episode") not in (None, "") or row.get("episode") not in (None, "")))
        )
        if kind == "episode":
            return has_episode_identity
        if item.get("_tmdb_kind") == "series" and has_episode_identity:
            return True
        return False

    def _seriesIdentity(self,key,row):
        item = row.get("item") or {}
        # Group Continue Watching by the parent show name first.  Do not use
        # series_id as the primary key: some providers change or duplicate it
        # between episode records, which used to create repeated cards.
        title = (
            row.get("series_title") or item.get("series_name") or
            item.get("_tmdb_title") or row.get("title") or
            item.get("name") or item.get("title") or ""
        )
        value = str(title or "").strip().lower()
        # Strip episode markers and common IPTV decorations so e.g.
        # "AR - Suits - S01E05" and "Suits S01 E05" collapse to "suits".
        value = re.sub(r"(?i)\bS(?:EASON)?\s*\d{1,2}\s*[- .]*E(?:P(?:ISODE)?)?\s*\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\bS\d{1,2}E\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\b\d{1,2}X\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\b(?:4k|uhd|fhd|hd|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|ar|ara|arabic|en|eng|english)\b", " ", value)
        value = re.sub(r"[\[\]\(\)\{\}_|:/\-]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        if value:
            return "name:" + value
        sid = str(row.get("series_id") or item.get("series_id") or "").strip().lower()
        return "id:" + sid if sid else "key:" + str(key)
    def _contentIdentity(self, row):
        item = row.get("item") or {}
        series_name = row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or ""
        title = series_name or row.get("title") or item.get("name") or item.get("title") or ""
        text = str(title or "").lower()
        text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
        text = re.sub(r"(?i)\b(?:4k|8k|uhd|fhd|hd|sd|2160p|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|bluray|ar|ara|arabic|en|eng|english)\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        text = " ".join(text.split())
        season = str(row.get("season") or item.get("season") or item.get("season_number") or "")
        episode = str(row.get("episode") or item.get("episode_num") or item.get("episode_number") or "")
        if self._isSeries(row):
            return "series|%s|s%s|e%s" % (text, season, episode)
        year_raw = " ".join(str(x or "") for x in (item.get("year"), item.get("releaseDate"), item.get("release_date"), row.get("title")))
        m = re.search(r"\b(19|20)\d{2}\b", year_raw)
        return "movie|%s|%s" % (text, m.group(0) if m else "")

    def _serverKeyFromStreamUrl(self, streamurl):
        url = str(streamurl or "").strip()
        if not url:
            return ""
        try:
            parsed = urlparse(url)
            stream_host = (parsed.netloc or "").lower()
            stream_path = parsed.path or ""
        except Exception:
            stream_host = ""
            stream_path = url

        best = ""
        for source in (get_sources() or []):
            try:
                source_key = _source_identity(source)
                base = str(source.get("url") or source.get("portal") or source.get("host") or source.get("server") or "").strip()
                if "://" not in base and base:
                    base = "http://" + base
                bp = urlparse(base)
                source_host = (bp.netloc or "").lower()
                username = str(source.get("username") or "")
                # Exact server host is the strongest direct match.
                if source_host and stream_host and source_host == stream_host:
                    if username and (("/" + username + "/") in stream_path or username in stream_path):
                        return source_key
                    best = source_key
            except Exception:
                pass
        return best

    def _migrateMultiServerRows(self, data):
        groups = {}
        changed = False
        for key, row in list(data.items()):
            if not isinstance(row, dict):
                continue
            ident = str(row.get("content_id") or self._contentIdentity(row))
            if not ident:
                continue
            if ident not in groups:
                groups[ident] = (key, row)
                row["content_id"] = ident
            else:
                keep_key, keep = groups[ident]
                # Newest progress/visuals win.
                if int(row.get("updated") or 0) > int(keep.get("updated") or 0):
                    old_keep_key, old_keep = keep_key, keep
                    keep_key, keep = key, row
                    groups[ident] = (keep_key, keep)
                    donor_key, donor = old_keep_key, old_keep
                else:
                    donor_key, donor = key, row

                keep_servers = dict(keep.get("servers") or {})
                donor_servers = dict(donor.get("servers") or {})
                for skey, sentry in donor_servers.items():
                    if skey:
                        keep_servers[skey] = sentry
                for source_row in (keep, donor):
                    skey = str(source_row.get("source_key") or "")
                    if not skey and source_row.get("streamurl"):
                        skey = self._serverKeyFromStreamUrl(source_row.get("streamurl"))
                        if skey:
                            source_row["source_key"] = skey
                            changed = True
                    if skey and source_row.get("streamurl"):
                        keep_servers[skey] = {
                            "source_key": skey,
                            "source_type": source_row.get("source_type") or "xtream",
                            "streamurl": source_row.get("streamurl"),
                            "service_type": int(source_row.get("service_type") or 4097),
                            "item": dict(source_row.get("item") or {}),
                        }
                keep["servers"] = keep_servers
                keep["content_id"] = ident
                data[keep_key] = keep
                if donor_key in data and donor_key != keep_key:
                    del data[donor_key]
                changed = True

        # Migrate single legacy rows too.
        for key, row in list(data.items()):
            if not isinstance(row, dict):
                continue
            row["content_id"] = str(row.get("content_id") or self._contentIdentity(row))
            servers = dict(row.get("servers") or {})
            skey = str(row.get("source_key") or "")
            if not skey and row.get("streamurl"):
                skey = self._serverKeyFromStreamUrl(row.get("streamurl"))
                if skey:
                    row["source_key"] = skey
                    changed = True
            if skey and row.get("streamurl") and skey not in servers:
                servers[skey] = {
                    "source_key": skey,
                    "source_type": row.get("source_type") or "xtream",
                    "streamurl": row.get("streamurl"),
                    "service_type": int(row.get("service_type") or 4097),
                    "item": dict(row.get("item") or {}),
                }
                row["servers"] = servers
                changed = True
            data[key] = row
        return changed

    def reload(self):
        data = self._load()
        try:
            if self._migrateMultiServerRows(data):
                self._save(data)
        except Exception:
            pass
        rows = sorted(data.items(), key=lambda p: int((p[1] or {}).get("updated", 0) or 0), reverse=True)
        self.movies = []
        self.series = []
        seen = set()
        duplicate_keys = []
        for key, row in rows:
            if not isinstance(row, dict):
                continue
            try:
                pos = int(row.get("position") or 0)
                length = int(row.get("length") or 0)
                if length > 0 and pos >= int(length * 0.95):
                    continue
            except Exception:
                pass
            if self._isSeries(row):
                ident = self._seriesIdentity(key, row)
                if ident in seen:
                    # Keep only the newest unfinished episode/card for a show.
                    duplicate_keys.append(key)
                    continue
                seen.add(ident)
                self.series.append((key, row))
            else:
                self.movies.append((key, row))

        # Also clean duplicate legacy records from disk, so reopening Continue
        # Watching cannot make the same show reappear again.
        if duplicate_keys:
            changed = False
            for key in duplicate_keys:
                if key in data:
                    try:
                        del data[key]
                        changed = True
                    except Exception:
                        pass
            if changed:
                self._save(data)

        if self.row == 0 and not self.movies and self.series:
            self.row = 1
        elif self.row == 1 and not self.series and self.movies:
            self.row = 0
        self.index = 0
        self.renderRows()
        self.updateFocus()
    def _pageRows(self,row=None):
        row=self.row if row is None else row; items=self.movies if row==0 else self.series; page=self.moviePage if row==0 else self.seriesPage; s=page*self.CARD_COUNT
        return items[s:s+self.CARD_COUNT]
    def _pct(self,row):
        try:
            pos=int(row.get("position") or 0); length=int(row.get("length") or 0); return max(0,min(100,int(pos*100.0/length))) if length>0 else 0
        except Exception: return 0
    def _title(self,row):
        item=row.get("item") or {}
        if self._isSeries(row): return str(row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or row.get("title") or item.get("name") or item.get("title") or tr("TV Show"))
        return str(row.get("title") or item.get("name") or item.get("title") or tr("Movie"))
    def _updatePosterBottomControl(self):
        try:
            if self.viewMode == "poster":
                self["posterBottomControl"].show()
                self["backdropBottomControl"].hide()
            else:
                self["posterBottomControl"].hide()
                self["backdropBottomControl"].show()
        except Exception:
            pass

    def toggleViewMode(self):
        self.viewMode = "poster" if self.viewMode == "backdrop" else "backdrop"
        self._saveViewMode()
        self._updatePosterBottomControl()
        self._applyContinueViewLayout()
        self.renderRows()
        self.updateFocus()

    def _posterAsset(self,row):
        item=row.get("item") or {}
        value=(item.get("stream_icon") or item.get("movie_image") or item.get("cover") or
               item.get("cover_big") or item.get("poster") or item.get("poster_url") or
               item.get("poster_path") or row.get("poster") or "")
        value=str(value or "").strip().replace("\\/","/")
        if value.startswith("/") and not value.startswith("//"):
            return IMAGE_BASE+"w500"+value
        return value

    def _resolvePosterAsync(self, key, row, widget):
        title = self._title(row)
        kind = "series" if self._isSeries(row) else "vod"
        item = row.get("item") or {}
        year = item.get("year") or row.get("year") or ""
        generation = self._generation
        def worker():
            try:
                result = TMDbClient().search_artwork(title, kind=kind, year=year, required_key="poster_path") or {}
                path = result.get("poster_path") or ""
                url = IMAGE_BASE + "w500" + path if path else ""
            except Exception:
                url = ""
            if not url or generation != self._generation:
                return
            data = self._load()
            rec = data.get(key)
            if isinstance(rec, dict):
                rec["poster"] = url
                data[key] = rec
                self._save(data)
            self._loadPosterArtwork(url, widget, generation)
        t = threading.Thread(target=worker, name="TiviMateContinuePoster")
        t.daemon = True
        t.start()

    def _applyContinueViewLayout(self):
        poster = self.viewMode == "poster"
        # The large Continue Watching hero is independent from card view mode.
        # Never hide it when switching Poster/Backdrop.
        try:
            self["hero"].show()
        except Exception:
            pass
        # Cards become portrait in Poster mode.
        for slot in range(8):
            col=slot if slot<4 else slot-4
            base_x=self.X[col]
            base_y=self.MOVIE_Y if slot<4 else self.SERIES_Y
            try:
                w=self["card%d"%slot]
                if poster:
                    w.instance.move(ePoint(sx(base_x+125),sy(base_y+2)))
                    w.instance.resize(eSize(sx(160),sy(205)))
                else:
                    w.instance.move(ePoint(sx(base_x+2),sy(base_y+2)))
                    w.instance.resize(eSize(sx(406),sy(160)))
            except Exception:
                pass

    def _asset(self,row):
        item=row.get("item") or {}; value=row.get("backdrop") or item.get("_player_backdrop") or item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or ""
        value=str(value or "").strip().replace("\\/","/")
        if value.startswith("/") and not value.startswith("//"): return IMAGE_BASE+"w1280"+value
        return value
    def _resolveBackdropAsync(self,key,row,widget):
        title=self._title(row); kind="series" if self._isSeries(row) else "vod"; item=row.get("item") or {}; year=item.get("year") or row.get("year") or ""; generation=self._generation
        def worker():
            try:
                result=TMDbClient().search_artwork(title,kind=kind,year=year,required_key="backdrop_path") or {}; path=result.get("backdrop_path") or ""; url=backdrop_url(path) if path else ""
            except Exception: url=""
            if not url or generation!=self._generation: return
            data=self._load(); rec=data.get(key)
            if isinstance(rec,dict): rec["backdrop"]=url; data[key]=rec; self._save(data)
            self._loadArtwork(url,widget,generation)
        t=threading.Thread(target=worker,name="TiviMateContinueBackdrop"); t.daemon=True; t.start()
    def _loadArtwork(self,url,widget,generation):
        if not url: return
        if widget=="hero": self._heroUrl=url
        def done(path,expected=widget,g=generation,u=url):
            if g!=self._generation or not path: return
            if expected=="hero" and u!=self._heroUrl: return
            try:
                w=self[expected]
                if w.instance: w.instance.setPixmapFromFile(path); w.show(); return
            except Exception: pass
            loader=ePicLoad(); self._loaders.append(loader)
            def ready(_=None,ll=loader,name=expected):
                try:
                    ptr=ll.getData(); w=self[name]
                    if ptr and w.instance: w.instance.setPixmap(ptr); w.show()
                except Exception: pass
                try:self._loaders.remove(ll)
                except Exception: pass
            connect_picture_data(loader,ready,self); size=(1920,500) if expected=="hero" else ((160,205) if self.viewMode=="poster" else (406,206)); rw,rh=scale_size(*size); loader.setPara((rw,rh,0,0,False,1,"#00000000")); loader.startDecode(path)
        # Share the exact same backdrop cache used by Movies/TV Shows/details.
        # Same URL => same HDD file; Continue Watching never downloads it twice.
        try: request_artwork(url,"backdrops",done,priority=35)
        except Exception: pass
    def _loadPosterArtwork(self,url,widget,generation):
        if not url:return
        def done(path,expected=widget,g=generation):
            if g!=self._generation or not path or self.viewMode!="poster":return
            try:
                w=self[expected]
                if w.instance:
                    w.instance.setPixmapFromFile(path); w.show()
            except Exception:
                pass
        try:request_artwork(url,"posters",done,priority=40)
        except Exception:pass

    def renderRows(self):
        self._generation+=1; g=self._generation; ph=os.path.join(PLUGIN_PATH,"skins","banner_placeholder.jpg"); m=self._pageRows(0); s=self._pageRows(1)
        mp=((len(self.movies)+3)//4) if self.movies else 0; sp=((len(self.series)+3)//4) if self.series else 0
        self["moviesPage"].setText("%d  •  %d/%d"%(len(self.movies),self.moviePage+1 if self.movies else 0,mp)); self["seriesPage"].setText("%d  •  %d/%d"%(len(self.series),self.seriesPage+1 if self.series else 0,sp))
        for slot in range(8):
            rows=m if slot<4 else s; idx=slot if slot<4 else slot-4; image=self["card%d"%slot]; title=self["title%d"%slot]; meta=self["meta%d"%slot]
            if idx>=len(rows):
                is_movies = slot < 4
                default_path = os.path.join(
                    PLUGIN_PATH, "skins",
                    "continue_default_movies.jpg" if is_movies else "continue_default_series.jpg"
                )
                title.setText("")
                meta.setText("")
                try:
                    if image.instance and os.path.exists(default_path):
                        image.instance.setPixmapFromFile(default_path)
                    image.show()
                except Exception:
                    pass
                continue
            key,row=rows[idx]; title.setText(self._title(row)[:38]); pct=self._pct(row); meta.setText(("%d%%"%pct) if pct else tr("Resume"))
            try:
                image.show()
                if image.instance and os.path.exists(ph): image.instance.setPixmapFromFile(ph)
            except Exception: pass
            if self.viewMode == "poster":
                url = self._posterAsset(row)
                if url:
                    self._loadPosterArtwork(url, "card%d" % slot, g)
                else:
                    self._resolvePosterAsync(key, row, "card%d" % slot)
            else:
                url = self._asset(row)
                if url:
                    self._loadArtwork(url, "card%d" % slot, g)
                else:
                    self._resolveBackdropAsync(key, row, "card%d" % slot)
        all_resume_rows = [row for _key, row in list(self.movies or []) + list(self.series or [])]
        if self.viewMode == "poster":
            prefetch_artwork([self._posterAsset(row) for row in all_resume_rows if self._posterAsset(row)], "posters", priority=2)
        prefetch_artwork([self._asset(row) for row in all_resume_rows if self._asset(row)], "backdrops", priority=1)
        self["empty"].setText(tr("Your unfinished movies and TV shows will appear here.") if not self.movies and not self.series else "")
    def _selected(self):
        rows=self._pageRows(); self.index=min(max(0,self.index),len(rows)-1) if rows else 0; return rows[self.index] if rows else None
    def updateFocus(self):
        rows=self._pageRows()
        if not rows:
            x = self.X[0]
            y = self.MOVIE_Y if self.row == 0 else self.SERIES_Y
            try:
                self["focus"].instance.move(ePoint(sx(x), sy(y)))
                self["focus"].show()
            except Exception:
                pass
            default_hero = os.path.join(PLUGIN_PATH, "skins", "continue_default_hero.jpg")
            try:
                if self["hero"].instance and os.path.exists(default_hero):
                    self["hero"].instance.setPixmapFromFile(default_hero)
                    self["hero"].show()
            except Exception:
                pass
            self["heroTitle"].setText(tr("YOUR STORY CONTINUES HERE"))
            self["heroMeta"].setText(tr("Movies  •  TV Shows"))
            try:
                self["heroStars"].setText("★★★★★")
            except Exception:
                pass
            self["heroDesc"].setText(tr("Pick up where you left off. Your movies and TV shows will appear here automatically."))
            self["heroProgress"].setValue(0)
            self["heroPercent"].setText("")
            return

        self.index=min(max(0,self.index),len(rows)-1)
        x=self.X[self.index]
        y=self.MOVIE_Y if self.row==0 else self.SERIES_Y
        try:
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:
            pass

        key,row=self._selected()
        pct=self._pct(row)
        self["heroTitle"].setText(self._title(row)[:55])

        try:
            pos=int(row.get("position") or 0)
            total=int(row.get("length") or 0)
        except Exception:
            pos=total=0

        def clock(v):
            h=v//3600
            m=(v%3600)//60
            return ("%dh %02dm"%(h,m)) if h else ("%d min"%m)

        item=row.get("item") or {}
        year=""
        raw_year=" ".join(str(x or "") for x in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match=re.search(r"\b(19|20)\d{2}\b", raw_year)
        if match:
            year=match.group(0)

        genre=str(row.get("genre") or item.get("genre") or "").strip()
        media_label=tr("TV Show") if self._isSeries(row) else tr("Movie")
        parts=[media_label]
        if year: parts.append(year)
        if genre: parts.append(genre[:38])
        if pos: parts.append(clock(pos))
        if total: parts.append(clock(total))
        self["heroMeta"].setText("  •  ".join(parts))

        raw_rating=row.get("rating") or item.get("rating") or item.get("vote_average") or 0
        try:
            rating=float(str(raw_rating).replace(",", "."))
            if rating>10.0:
                rating=rating/10.0
            rating=max(0.0,min(10.0,rating))
        except Exception:
            rating=0.0
        stars=int(round(rating/2.0)) if rating else 0
        star_text=("★"*stars)+("☆"*(5-stars)) if rating else "☆☆☆☆☆"
        try:
            self["heroStars"].setText(("%s   %.1f/10"%(star_text,rating)) if rating else star_text)
        except Exception:
            pass

        overview=str(row.get("overview") or item.get("plot") or item.get("description") or item.get("overview") or "").strip()
        self["heroDesc"].setText(overview[:280] if overview else tr("OK Play   •   MENU Options"))

        self["heroProgress"].setValue(pct)
        self["heroPercent"].setText("%d%%"%pct if pct else "")
        url=self._asset(row)
        if url:
            self._loadArtwork(url,"hero",self._generation)
        else:
            self._resolveBackdropAsync(key,row,"hero")


    def _updateTopFocus(self):
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(88)))
            self["topSelector"].setVisible(self.navFocus == "top")
        except Exception:
            pass
        try:
            self["focus"].setVisible(self.navFocus != "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openTop(self):
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Search, self.currentSource); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.currentSource, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(ContentHomeScreen, self.currentSource, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(ContentHomeScreen, self.currentSource, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.currentSource); return
        if self.topIndex == 6:
            self.navFocus = "content"; self._updateTopFocus(); return
        if self.topIndex == 7:
            self._openPageOnce(SettingsDashboard); return


    def left(self):
        if self.navFocus == "top":
            self.topIndex = (self.topIndex - 1) % len(self.topNames)
            self._updateTopFocus()
            return
        rows=self._pageRows()
        if not rows:return
        if self.index>0:self.index-=1
        else:
            page=self.moviePage if self.row==0 else self.seriesPage
            if page>0:
                if self.row==0:self.moviePage-=1
                else:self.seriesPage-=1
                self.index=min(3,len(self._pageRows())-1); self.renderRows()
        self.updateFocus()

    def right(self):
        if self.navFocus == "top":
            self.topIndex = (self.topIndex + 1) % len(self.topNames)
            self._updateTopFocus()
            return
        rows=self._pageRows()
        if not rows:return
        if self.index+1<len(rows):self.index+=1
        else:
            allrows=self.movies if self.row==0 else self.series; page=self.moviePage if self.row==0 else self.seriesPage
            if (page+1)*self.CARD_COUNT<len(allrows):
                if self.row==0:self.moviePage+=1
                else:self.seriesPage+=1
                self.index=0; self.renderRows()
        self.updateFocus()

    def up(self):
        if self.navFocus == "top":
            return
        if self.row == 1:
            self.row = 0
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self.updateFocus()
            return
        self.navFocus = "top"
        self._updateTopFocus(); self.updateFocus()


    def down(self):
        if self.navFocus == "top":
            self.navFocus = "content"
            self.row = 0
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self._updateTopFocus(); self.updateFocus()
            return
        if self.row == 0 and self.series:
            self.row = 1
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self.updateFocus()


    def _sourceForRow(self,row):
        key=str(row.get("source_key") or ((row.get("item") or {}).get("_source_key")) or ""); source_type=str(row.get("source_type") or ((row.get("item") or {}).get("_source_type")) or ""); sources=get_sources() or []
        if key:
            for source in sources:
                try:
                    if _source_identity(source)==key:return source
                except Exception:pass
        if source_type:
            for source in sources:
                if str(source.get("type") or "")==source_type:return source
        return sources[0] if sources else None
    def _normSeriesName(self, value):
        value = str(value or "").strip().lower()
        value = re.sub(r"\b(?:19|20)\d{2}\b", " ", value)
        value = re.sub(r"(?i)\b(?:4k|uhd|fhd|hd|sd|1080p|720p|2160p|amz|amzn|nf|netflix|web[- ]?dl|webrip|bluray|ar|ara|arabic|en|eng|english)\b", " ", value)
        value = re.sub(r"[\[\]\(\)\{\}_\-|:/.]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        return value

    def _seriesIdLooksValid(self, row):
        item = row.get("item") or {}
        sid = str(row.get("series_id") or item.get("series_id") or "").strip()
        return sid if sid else ""

    def _resolveSeriesItemAsync(self, row):
        source = self._sourceForRow(row)
        if not source:
            self.session.open(
                MessageBox, tr("The original server is not available."),
                MessageBox.TYPE_INFO, timeout=5
            )
            return

        current = self._seriesIdLooksValid(row)
        if current:
            self.session.open(SeriesDetailsScreen, source, self._seriesItem(row))
            return

        wanted = self._normSeriesName(self._title(row))
        self["heroDesc"].setText(tr("Finding the series on the server..."))

        def worker():
            match = None
            try:
                client = get_source_client(dict(source))
                rows = get_filtered_streams(source, "series", client, use_cache=True) or []
                best_score = -1
                for candidate in rows:
                    name = candidate.get("name") or candidate.get("title") or ""
                    norm = self._normSeriesName(name)
                    if not norm:
                        continue
                    if norm == wanted:
                        match = candidate
                        best_score = 1000
                        break
                    score = 0
                    if wanted and (wanted in norm or norm in wanted):
                        score = 800 - abs(len(wanted) - len(norm))
                    else:
                        # Token overlap is safer than guessing by episode stream_id.
                        a = set(wanted.split())
                        b = set(norm.split())
                        if a and b:
                            score = int(100.0 * len(a & b) / max(len(a), len(b)))
                    if score > best_score:
                        best_score = score
                        match = candidate
                if best_score < 55:
                    match = None
            except Exception:
                match = None

            def finish():
                if not match:
                    self["heroDesc"].setText(tr("Could not match this series to the server catalog."))
                    return
                data = self._load()
                selected = self._selected()
                key = selected[0] if selected else None
                if key and key in data and isinstance(data[key], dict):
                    rec = data[key]
                    rec["series_id"] = match.get("series_id") or match.get("stream_id") or match.get("id") or ""
                    rec["series_title"] = match.get("name") or match.get("title") or self._title(row)
                    saved_item = dict(rec.get("item") or {})
                    saved_item["series_id"] = rec["series_id"]
                    saved_item["series_name"] = rec["series_title"]
                    rec["item"] = saved_item
                    data[key] = rec
                    self._save(data)
                merged = dict(row)
                merged["series_id"] = match.get("series_id") or match.get("stream_id") or match.get("id") or ""
                merged["series_title"] = match.get("name") or match.get("title") or self._title(row)
                merged_item = dict(merged.get("item") or {})
                merged_item["series_id"] = merged["series_id"]
                merged_item["series_name"] = merged["series_title"]
                merged["item"] = merged_item
                self.session.open(SeriesDetailsScreen, source, self._seriesItem(merged))

            try:
                if reactor:
                    reactor.callFromThread(finish)
                else:
                    finish()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMateContinueSeriesResolver")
        t.daemon = True
        t.start()

    def _seriesItem(self,row):
        item = dict(row.get("item") or {})
        item["name"] = row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or self._title(row)
        item["series_name"] = item["name"]
        sid = row.get("series_id") or item.get("series_id") or ""
        item["series_id"] = sid
        # Remove episode-only stream identity so SeriesDetailsScreen can never
        # mistake an episode stream_id for the parent series_id.
        item.pop("stream_id", None)
        item.pop("episode_id", None)
        item["_tmdb_kind"] = "series"
        return item
    def ok(self):
        if self.navFocus == "top":
            self._openTop()
            return
        selected = self._selected()
        if not selected:
            return
        _key, row = selected
        self.playMovie(row)

    def playMovie(self,row):
        try:
            play_vod_exact_continue_path(
                self.session,
                row,
                current_source=dict(self.currentSource or {}),
                callback=lambda *a: self.reload()
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s\n%s" % (tr("Unable to play this item."), exc),
                MessageBox.TYPE_ERROR
            )

    def removeSelected(self):
        selected=self._selected()
        if not selected:return
        data=self._load(); data.pop(selected[0],None); self._save(data); self.reload()
    def clearAll(self):self.session.openWithCallback(self._clearConfirm,MessageBox,tr("Clear all Continue Watching history?"),MessageBox.TYPE_YESNO)
    def _clearConfirm(self,yes):
        if yes:self._save({}); self.moviePage=0; self.seriesPage=0; self.reload()
    def openOptions(self):
        selected=self._selected(); choices=[]
        if selected: choices.append((tr("Play"),"open")); choices.extend([(tr("Remove from Continue Watching"),"remove"),(tr("Mark as Watched"),"remove")])
        choices.append((tr("Clear Continue Watching"),"clear")); self.session.openWithCallback(self._optionChosen,ChoiceBox,title=tr("Continue Watching"),list=choices)
    def _optionChosen(self,choice):
        if not choice:return
        action=choice[1]
        if action=="open":self.ok()
        elif action=="remove":self.removeSelected()
        elif action=="clear":self.clearAll()



def play_vod_exact_continue_path(session, row, current_source=None, callback=None):
    """Exact Continue Watching VOD playback path shared by Continue and Movies."""
    current_source = dict(current_source or {})
    current_key = ""
    try:
        current_key = _source_identity(current_source)
    except Exception:
        current_key = ""

    servers = dict((row or {}).get("servers") or {})
    selected = None

    # Exact Continue Watching server-selection order.
    if current_key:
        selected = servers.get(current_key)

    if not selected:
        legacy_key = str((row or {}).get("source_key") or "")
        if legacy_key and legacy_key in servers:
            selected = servers.get(legacy_key)

    if not selected:
        for skey, sentry in list(servers.items()):
            if isinstance(sentry, dict) and sentry.get("streamurl"):
                selected = sentry
                break

    if selected:
        item = dict(selected.get("item") or {})
        url = str(selected.get("streamurl") or "")
        source_type = selected.get("source_type") or (row or {}).get("source_type") or current_source.get("type") or "xtream"
        source_key = selected.get("source_key") or (row or {}).get("source_key") or current_key
        saved_service_type = selected.get("service_type") or (row or {}).get("service_type")
    else:
        item = dict((row or {}).get("item") or {})
        url = str((row or {}).get("streamurl") or item.get("_streamurl") or "")
        source_type = (row or {}).get("source_type") or item.get("_source_type") or current_source.get("type") or "xtream"
        source_key = (row or {}).get("source_key") or item.get("_source_key") or ""
        saved_service_type = (row or {}).get("service_type")

    if not url:
        raise RuntimeError("Playback link is not available for this item.")

    # Keep the same payload shape as Continue Watching, but do not force Resume.
    item.pop("_continue_resume", None)
    item.pop("_continue_position", None)
    item["_source_type"] = source_type
    item["_source_key"] = source_key
    item.setdefault("name", (row or {}).get("title") or item.get("title") or "MOVIE")

    # Exact Continue Watching service-type logic.
    try:
        st = int(_load_player_type())
    except Exception:
        try:
            st = int(saved_service_type or 4097)
        except Exception:
            st = 4097

    ref = eServiceReference(st, 0, url)
    ref.setName((row or {}).get("title") or item.get("name") or item.get("title") or "MOVIE")

    if callback is not None:
        session.openWithCallback(callback, TiviMatePlayer, ref, item)
    else:
        session.open(TiviMatePlayer, ref, item)


from .live_player import TiviMateLivePlayer


class SeriesDetailsScreen(Screen):
    skin = SERIES_DETAILS
    EPISODE_X = [80, 440, 800, 1160, 1520]


    def __init__(self, session, source, seriesItem):
        Screen.__init__(self, session)
        self.source = source
        self._vodSelectedSource = dict(self.source or {})
        self.seriesItem = seriesItem or {}
        self._serverPackageProvider = str(self.seriesItem.get("_server_package_provider") or self.seriesItem.get("_tmdb_provider") or "")
        self.seriesData = {}
        self.episodesBySeason = {}
        self.seasonItems = []
        self.episodeItems = []
        self.seasonIndex = 0
        self.episodePage = 0
        self.episodeIndex = 0
        self.downloads = []
        self.picloads = []
        self.backdropLoader = None
        self.backdropDownloader = None
        self.seriesFallbackPoster = ""
        self.seriesBackdrop = ""
        self["backdrop"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["title"] = Label(self.seriesItem.get("name") or self.seriesItem.get("title") or (tr("TV Show") if get_language() != "ar" else "مسلسل"))
        self["rating"] = Label("")
        self["ratingStars"] = Label("")
        self["meta"] = Label("")
        self["cast"] = Label("")
        self["desc"] = Label(tr("Loading series details..."))
        self["seasonInfo"] = Label("")
        self["episodeInfo"] = Label("")
        for i in range(5):
            self["episode%d" % i] = Pixmap()
            self["episodeLabel%d" % i] = Label("")
        self["episodeSelector"] = Pixmap()
        self["keys"] = Label(tr("LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addSeriesFavourite
        }, -1)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self._startSeriesArtworkFirst)


    def _updateProviderLogo(self):
        try:
            provider = str((self.seriesItem or {}).get("_server_package_provider") or (self.seriesItem or {}).get("_tmdb_provider") or self._serverPackageProvider or "").strip().lower()
            if provider == "prime_video":
                provider = "prime"
            path = package_logo_for_key(provider)
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _normImage(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if isinstance(value, str):
            v = value.strip().replace("\\/", "/")
            if v.startswith("["):
                try:
                    arr = json.loads(v)
                    v = arr[0] if arr else ""
                except Exception:
                    pass
            if v.startswith("/") and not v.startswith("//"):
                v = "https://image.tmdb.org/t/p/w1280" + v
            return v
        return ""

    def _normSeriesTitle(self, value):
        text = str(value or "").lower()
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"\b(?:4k|uhd|fhd|hd|sd|1080p|720p|2160p|ar|en|eng|arabic|english|netflix|amz|amzn|web[- ]?dl|webrip)\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())

    def _startSeriesArtworkFirst(self):
        try:
            poster = self._normImage(
                self.seriesItem.get("cover") or self.seriesItem.get("stream_icon") or
                self.seriesItem.get("poster_path") or ""
            )
            backdrop = self._normImage(
                self.seriesItem.get("backdrop_path") or self.seriesItem.get("backdrop") or
                self.seriesItem.get("backdrop_url") or ""
            )
            self.seriesFallbackPoster = poster
            self.seriesBackdrop = backdrop or poster
            if self.seriesBackdrop:
                self.loadBackdrop(self.seriesBackdrop)
        except Exception:
            pass
        try:
            timer = eTimer()
            self._seriesDeferredLoadTimer = timer
            def go():
                try: timer.stop()
                except Exception: pass
                self.loadSeries()
            try:
                self._seriesDeferredLoadConn = timer.timeout.connect(go)
            except Exception:
                timer.callback.append(go)
            timer.start(120, True)
        except Exception:
            self.loadSeries()


    def loadSeries(self):
        sid = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id")
        self["desc"].setText(tr("Loading series details..."))

        def worker():
            try:
                source = dict(self._vodSelectedSource or {})
                chosen = dict(self.seriesItem or {})
                resolved_sid = sid

                # Popular/Trending never checks availability in the list.
                # Search the provider only after this details screen has opened.
                if not resolved_sid and chosen.get("_home_tmdb_feed"):
                    wanted_id = str(chosen.get("tmdb_id") or chosen.get("id") or "").strip()
                    wanted = self._normSeriesTitle(chosen.get("name") or chosen.get("title") or "")
                    wanted_year_match = re.search(r"\b(19|20)\d{2}\b", str(chosen.get("year") or chosen.get("first_air_date") or ""))
                    wanted_year = wanted_year_match.group(0) if wanted_year_match else ""
                    best = None

                    def row_tmdb_id(row):
                        row = row or {}
                        for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                            for key in ("tmdb_id", "tmdb", "tmdbid"):
                                value = mapping.get(key)
                                if value not in (None, ""):
                                    try:
                                        return str(int(value))
                                    except Exception:
                                        value = str(value).strip()
                                        if value:
                                            return value
                        return ""

                    def match_rows(rows):
                        if wanted_id:
                            for candidate in rows or []:
                                if row_tmdb_id(candidate) == wanted_id:
                                    return dict(candidate)
                        selected = None
                        selected_score = 0.0
                        for candidate in rows or []:
                            cand = self._normSeriesTitle(candidate.get("name") or candidate.get("title") or "")
                            if not cand or not wanted:
                                continue
                            raw_year = candidate.get("year") or candidate.get("releaseDate") or candidate.get("first_air_date") or ""
                            ym = re.search(r"\b(19|20)\d{2}\b", str(raw_year))
                            row_year = ym.group(0) if ym else ""
                            if wanted_year and row_year and wanted_year != row_year:
                                continue
                            a=set(wanted.split()); b=set(cand.split())
                            overlap=a & b
                            coverage=float(len(overlap))/float(min(len(a),len(b))) if a and b else 0.0
                            union=float(len(a | b)) if a or b else 0.0
                            jaccard=float(len(overlap))/union if union else 0.0
                            ratio=SequenceMatcher(None,wanted,cand).ratio()
                            score=1.0 if wanted == cand else 0.0
                            if not score and coverage == 1.0 and min(len(a),len(b)) >= 2 and abs(len(a)-len(b)) <= 1:
                                score=0.98
                            elif not score and min(len(a),len(b)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
                                score=ratio
                            threshold=0.94 if wanted_year and row_year else 0.98
                            if score >= threshold and score > selected_score:
                                selected=dict(candidate); selected_score=score
                        return selected

                    try:
                        client = get_source_client(source)
                        if source.get("type") == "xtream":
                            best = match_rows(list(get_filtered_streams(source, "series", client) or []))
                        elif source.get("type") == "stalker":
                            cats,_ = get_cached_categories(source, "series", client=client, wait_for_server=True)
                            cats = filter_categories(source, "series", cats or [])
                            for cat in cats:
                                cid = str((cat or {}).get("category_id") or "")
                                if not cid:
                                    continue
                                rows,_origin = get_category_streams(source, "series", client, cid, use_cache=True, wait_for_server=True)
                                best = match_rows(rows or [])
                                if best:
                                    break
                        if best is not None:
                            chosen.update(best)
                            resolved_sid = best.get("series_id") or best.get("stream_id") or best.get("id")
                            self.seriesItem.update(best)
                            if self._serverPackageProvider:
                                self.seriesItem["_server_package_provider"] = self._serverPackageProvider
                                self.seriesItem["_tmdb_provider"] = self._serverPackageProvider
                    except Exception:
                        pass

                data = (get_source_client(source).series_info(resolved_sid) or {}) if resolved_sid else {}

                try:
                    info = data.get("info") or {}
                    raw_title = info.get("name") or chosen.get("name") or chosen.get("title") or ""
                    raw_year = info.get("releaseDate") or info.get("releasedate") or info.get("year") or chosen.get("year") or ""
                    year_match = re.search(r"\b(19|20)\d{2}\b", str(raw_year))
                    tmdb = TMDbClient()
                    search_year = year_match.group(0) if year_match else None
                    found = tmdb.search_title(raw_title, "series", search_year) if raw_title else None
                    if not found and raw_title:
                        found = tmdb.search_title(raw_title, "series", None)
                    tid = (found or {}).get("id") or chosen.get("tmdb_id") or chosen.get("tmdb")
                    bundle = tmdb.details_bundle(tid, "series") if tid else {}
                    if found:
                        seed = dict(found); seed.update(bundle or {}); bundle = seed
                    if tid:
                        self.seriesItem["tmdb_id"] = str(tid)
                        data["_tmdb_id"] = str(tid)
                    data["_tmdb_bundle"] = bundle or {}
                except Exception:
                    pass

                if reactor:
                    reactor.callFromThread(self._seriesReady, data)
                else:
                    self._seriesReady(data)
            except Exception as exc:
                if reactor:
                    reactor.callFromThread(self._seriesFailed, str(exc))
                else:
                    self._seriesFailed(str(exc))

        thread = threading.Thread(target=worker, name="TiviMateSeriesDetails")
        thread.daemon = True
        thread.start()


    def _seriesReady(self, data):
        try:
            self.seriesData = data or {}
            info = self.seriesData.get("info") or {}
            tmdb_data = self.seriesData.get("_tmdb_bundle") or {}
            # Metadata policy: TMDb first; provider/server only fills missing fields.
            title = tmdb_data.get("name") or info.get("name") or self.seriesItem.get("name") or (tr("TV Show") if get_language() != "ar" else "مسلسل")
            year = (tmdb_data.get("first_air_date") or info.get("releaseDate") or
                    info.get("releasedate") or info.get("year") or "")
            rating = tmdb_data.get("vote_average") or info.get("rating") or info.get("rating_5based") or ""
            tmdb_genre = ", ".join(x.get("name", "") for x in (tmdb_data.get("genres") or [])[:3] if x.get("name"))
            genre = tmdb_genre or info.get("genre") or ""
            cast = ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("cast") or [])[:8] if x.get("name"))
            if not cast:
                cast = info.get("cast") or info.get("actors") or ""
            director = ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("crew") or []) if x.get("job") in ("Director", "Creator"))
            if not director:
                director = info.get("director") or ""
            self["title"].setText(title)
            rating_text = "--"
            stars_text = "☆☆☆☆☆"
            try:
                rating_value = float(str(rating).replace(",", "."))
                if rating_value > 10.0:
                    rating_value = rating_value / 10.0
                rating_value = max(0.0, min(10.0, rating_value))
                rating_text = "%.1f" % rating_value
                star_value = rating_value / 2.0
                full = int(star_value)
                if (star_value - full) >= 0.5 and full < 5:
                    full += 1
                full = max(0, min(5, full))
                stars_text = ("★" * full) + ("☆" * (5 - full))
            except Exception:
                if rating:
                    rating_text = str(rating)[:4]
            self["rating"].setText(rating_text)
            self["ratingStars"].setText(stars_text)
            self["meta"].setText("  •  ".join(x for x in [str(year), str(genre)] if x))
            cast_text = []
            if cast:
                cast_text.append("طاقم الممثلين: %s" % str(cast)[:150])
            if director:
                cast_text.append("المخرج: %s" % str(director)[:90])
            self["cast"].setText("\n".join(cast_text))
            self["desc"].setText((tmdb_data.get("overview") or info.get("plot") or info.get("description") or "لا توجد معلومات")[:720])
            # Poster policy stays fast: provider/server first; TMDb only fallback.
            self.seriesFallbackPoster = self._normImage(
                info.get("cover_big") or info.get("cover") or self.seriesItem.get("cover") or
                self.seriesItem.get("stream_icon") or tmdb_data.get("poster_path") or ""
            )
            self.seriesBackdrop = self._normImage(
                tmdb_data.get("backdrop_path") or
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                self.seriesItem.get("backdrop_path") or self.seriesItem.get("backdrop") or ""
            )
            if not self.seriesBackdrop:
                self.seriesBackdrop = self.seriesFallbackPoster
            if self.seriesBackdrop:
                self.loadBackdrop(self.seriesBackdrop)

            raw = self.seriesData.get("episodes") or {}
            self.episodesBySeason = {str(key): (value or []) for key, value in raw.items() if value}
            seasons = self.seriesData.get("seasons") or []
            self.seasonItems = []
            if seasons:
                for season in seasons:
                    number = str(season.get("season_number") if season.get("season_number") is not None else season.get("season") or "")
                    if self.episodesBySeason.get(number):
                        row = dict(season)
                        row["_num"] = number
                        self.seasonItems.append(row)
            if not self.seasonItems:
                for number in sorted(self.episodesBySeason.keys(), key=lambda value: int(value) if str(value).isdigit() else 999):
                    self.seasonItems.append({"_num": number, "name": (("Season %s" % number) if get_language() == "en" else (("Saison %s" % number) if get_language() == "fr" else ("الموسم %s" % number)))})
            self.seasonIndex = 0
            self.selectSeason()
        except Exception as exc:
            self._seriesFailed(str(exc))

    def _seriesFailed(self, error):
        self["desc"].setText("تعذر تحميل المسلسل\n%s" % error)

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def selectSeason(self):
        if not self.seasonItems:
            self.episodeItems = []
            self["seasonInfo"].setText(tr("No seasons"))
            self.renderEpisodes()
            return
        self.seasonIndex = max(0, min(self.seasonIndex, len(self.seasonItems) - 1))
        season = self.seasonItems[self.seasonIndex]
        num = str(season.get("_num", ""))
        self.episodeItems = self.episodesBySeason.get(num, []) or []
        lang = get_language()
        if lang == "en":
            season_name = "Season %s" % num
            self["seasonInfo"].setText("SEASON %s / %d" % (num, len(self.seasonItems)))
        elif lang == "fr":
            season_name = "Saison %s" % num
            self["seasonInfo"].setText("SAISON %s / %d" % (num, len(self.seasonItems)))
        else:
            season_name = season.get("name") or "الموسم %s" % num
            self["seasonInfo"].setText("%s  /  %d حلقة" % (season_name, len(self.episodeItems)))
        self.episodePage = 0
        self.episodeIndex = 0
        self.renderEpisodes()

    def renderEpisodes(self):
        self.downloads = []
        self.picloads = []
        for slot in range(5):
            idx = self.episodePage + slot
            item = self.episodeItems[idx] if idx < len(self.episodeItems) else None
            self._setVisible("episode%d" % slot, bool(item))
            self._setVisible("episodeLabel%d" % slot, bool(item))
            if not item:
                self["episodeLabel%d" % slot].setText(tr(""))
                continue
            ep = item.get("episode_num") or item.get("episode_number") or (idx + 1)
            lang = get_language()
            fallback_title = ("Episode %s" % ep) if lang == "en" else (("Épisode %s" % ep) if lang == "fr" else ("الحلقة %s" % ep))
            title = item.get("title") or item.get("name") or fallback_title
            prefix = ("EPISODE %s" % ep) if lang == "en" else (("ÉPISODE %s" % ep) if lang == "fr" else ("الحلقة %s" % ep))
            self["episodeLabel%d" % slot].setText("%s  •  %s" % (prefix, title[:24]))
            self._placeholder(slot)
            inf = item.get("info") or {}
            episode_url = self._normImage(
                item.get("movie_image") or item.get("cover") or item.get("stream_icon") or
                inf.get("movie_image") or inf.get("cover_big") or inf.get("cover")
            )
            fallback_url = self.seriesBackdrop or self.seriesFallbackPoster
            url = episode_url or fallback_url
            if url:
                self._loadThumb(slot, url, (330, 186), fallback_url=(fallback_url if episode_url and fallback_url != episode_url else ""))
        episode_prefetch = []
        for row in list(self.episodeItems or []):
            try:
                inf = (row or {}).get("info") or {}
                u = self._normImage(
                    (row or {}).get("movie_image") or (row or {}).get("cover") or (row or {}).get("stream_icon") or
                    inf.get("movie_image") or inf.get("cover_big") or inf.get("cover")
                ) or self.seriesBackdrop or self.seriesFallbackPoster
                if u:
                    episode_prefetch.append(u)
            except Exception:
                pass
        prefetch_artwork(episode_prefetch, "episodes", priority=2)
        self._setVisible("episodeSelector", bool(self.episodeItems))
        self._moveSelector()
        self.previewEpisode()

    def _placeholder(self, slot):
        try:
            self["episode%d" % slot].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "episode_placeholder.png"))
        except Exception:
            pass

    def _loadThumb(self, slot, url, size, fallback_url="", retry=1):
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_url:
                return self._loadThumb(slot, fallback_url, size, fallback_url="", retry=0)
            return
        requests = getattr(self, "_episode_artwork_requests", None)
        if requests is None:
            requests = {}
            self._episode_artwork_requests = requests
        token = "%s|%s" % (slot, url)
        requests[slot] = token

        def done(path, s=slot, sz=size, expected=token):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != expected:
                return
            self._decodeThumb(s, path, sz)

        def failed(_path, s=slot, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != token:
                return
            if retries > 0:
                self._loadThumb(s, primary, size, fallback_url=fb, retry=retries - 1)
            elif fb and fb != primary:
                self._loadThumb(s, fb, size, fallback_url="", retry=0)

        request_artwork(url, "episodes", done, priority=45, errback=failed)

    def _decodeThumb(self, slot, path, size):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["episode%d" % s].instance:
                    self["episode%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def _moveSelector(self):
        try:
            self["episodeSelector"].instance.move(ePoint(sx(self.EPISODE_X[self.episodeIndex] - 8), sy(632)))
        except Exception:
            pass

    def left(self):
        idx = self.episodePage + self.episodeIndex
        if idx <= 0:
            return
        if self.episodeIndex > 0:
            self.episodeIndex -= 1
        else:
            self.episodePage = max(0, self.episodePage - 5)
            self.episodeIndex = min(4, len(self.episodeItems) - self.episodePage - 1)
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def right(self):
        idx = self.episodePage + self.episodeIndex
        if idx + 1 >= len(self.episodeItems):
            return
        if self.episodeIndex < 4 and self.episodeIndex + 1 < len(self.episodeItems) - self.episodePage:
            self.episodeIndex += 1
        else:
            self.episodePage += 5
            self.episodeIndex = 0
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def up(self):
        if self.seasonIndex > 0:
            self.seasonIndex -= 1
            self.selectSeason()

    def down(self):
        if self.seasonIndex + 1 < len(self.seasonItems):
            self.seasonIndex += 1
            self.selectSeason()

    def previewEpisode(self):
        idx = self.episodePage + self.episodeIndex
        ep = self.episodeItems[idx] if 0 <= idx < len(self.episodeItems) else None
        if not ep:
            self["episodeInfo"].setText(tr(""))
            return
        inf = ep.get("info") or {}
        num = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        lang = get_language()
        fallback_title = ("Episode %s" % num) if lang == "en" else (("Épisode %s" % num) if lang == "fr" else ("الحلقة %s" % num))
        title = ep.get("title") or ep.get("name") or fallback_title
        duration = inf.get("duration") or ep.get("duration") or ""
        plot = inf.get("plot") or inf.get("description") or ep.get("plot") or ""
        prefix = ("Episode %s" % num) if lang == "en" else (("Épisode %s" % num) if lang == "fr" else ("الحلقة %s" % num))
        info = "%s  •  %s" % (prefix, title)
        if duration:
            info += "  •  %s" % duration
        if plot:
            info += "    %s" % str(plot)[:180]
        self["episodeInfo"].setText(info)

    def toggleFavourite(self):
        added, saved = toggle_favourite(self.source, "series", self.seriesItem)
        title = self.seriesItem.get("name") or self.seriesItem.get("title") or "المسلسل"
        if not saved:
            self["keys"].setText(tr("Unable to save favorite"))
        elif added:
            self["keys"].setText("★ تمت إضافة %s إلى المفضلات" % title)
        else:
            self["keys"].setText("☆ تمت إزالة %s من المفضلات" % title)

    def addSeriesFavourite(self):
        if is_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series is already in favorites"))
        elif add_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series added to favorites"))
        else:
            self["keys"].setText(tr("Unable to save favorite"))

    def ok(self):
        idx = self.episodePage + self.episodeIndex
        if not (0 <= idx < len(self.episodeItems)):
            return
        ep = dict(self.episodeItems[idx] or {})
        series_title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
        episode_info = ep.get("info") or {}
        if not isinstance(episode_info, dict):
            episode_info = {}
        episode_cover = self._normImage(
            ep.get("movie_image") or ep.get("cover") or ep.get("stream_icon") or ep.get("poster_path") or
            episode_info.get("movie_image") or episode_info.get("cover_big") or episode_info.get("cover") or
            episode_info.get("poster_path") or self.seriesFallbackPoster
        )
        if episode_cover:
            # The player consumes this normalised value before generic artwork fields.
            ep["_player_cover"] = episode_cover
        if self.seriesItem.get("tmdb_id"):
            ep["tmdb_id"] = self.seriesItem.get("tmdb_id")
        if self.seriesFallbackPoster and not ep.get("_player_cover"):
            ep["_player_cover"] = self.seriesFallbackPoster
        ep["_tmdb_title"] = series_title
        ep["_tmdb_kind"] = "series"
        ep["series_name"] = series_title
        ep["series_id"] = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id") or ep.get("series_id") or ""
        try:
            ep["_source_key"] = _source_identity(self.source)
        except Exception:
            ep["_source_key"] = ""
        ep["_source_type"] = self.source.get("type") or ""
        ep["_subdl_type"] = "tv"
        ep["_subdl_title"] = series_title
        ep["_subdl_season"] = self.seasonItems[self.seasonIndex].get("_num", "") if self.seasonItems else ""
        ep["_subdl_episode"] = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        ep["_episode_items"] = list(self.episodeItems or [])
        ep["_episode_index"] = int(idx)
        ep["_episode_source"] = dict(self.source or {})
        try:
            if self.source.get("type") == "stalker":
                url = StalkerClient(self.source).stream_url(ep, "series")
            else:
                url = XtreamClient(self.source).episode_url(ep)
            service = eServiceReference(4097, 0, url)
            service.setName(ep.get("title") or ep.get("name") or "حلقة")
            ep["_kind"] = "episode"
            self.session.open(TiviMatePlayer, service, ep)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)

    def loadBackdrop(self, url):
        url = self._normImage(url)
        if not url:
            return
        self._series_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_series_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        def failed(_path, expected=url):
            if getattr(self, "_series_backdrop_request", "") != expected:
                return
            retries = getattr(self, "_series_backdrop_retries", {})
            count = retries.get(expected, 0)
            if count < 1:
                retries[expected] = count + 1
                self._series_backdrop_retries = retries
                request_artwork(expected, "backdrops", done, priority=115, errback=lambda p: None)

        request_artwork(url, "backdrops", done, priority=115, errback=failed)

    def decodeBackdrop(self, path):
        loader = ePicLoad()
        self.backdropLoader = loader
        def ready(_info=None, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["backdrop"].instance:
                    self["backdrop"].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if self.backdropLoader is l:
                        self.backdropLoader = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(1920, 1080)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)


def _is_bein_sports_channel(item):
    """Return True for channels that clearly identify as beIN SPORTS.

    This is a local filter only. It never creates or resolves stream URLs.
    """
    item = item or {}
    parts = []
    for key in ("name", "title", "stream_display_name", "channel_name", "tvg_name", "epg_channel_name"):
        value = item.get(key)
        if value not in (None, ""):
            try:
                parts.append(str(value))
            except Exception:
                pass
    text = " ".join(parts).lower().replace("_", " ").replace("-", " ")
    compact = " ".join(text.split())
    return (
        "bein sports" in compact or "bein sport" in compact or
        "be in sports" in compact or "be in sport" in compact or
        u"بي ان سبورت" in compact or u"بي إن سبورت" in compact or u"بين سبورت" in compact
    )



RECENT_MEDIA_CACHE_FILE = data_path("recent_media_cache.json")
RECENT_MEDIA_CACHE_TTL = 1800  # 30 minutes

def _recent_media_cache_key(source, kind):
    try:
        raw = (_source_identity(source) + "|" + str(kind or "")).encode("utf-8", "ignore")
    except Exception:
        raw = (str(source) + "|" + str(kind or "")).encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()

def _load_recent_media_cache(source, kind):
    try:
        data = load_json(RECENT_MEDIA_CACHE_FILE, {}) or {}
        row = data.get(_recent_media_cache_key(source, kind)) or {}
        saved = int(row.get("saved") or 0)
        if not saved or int(time.time()) - saved > RECENT_MEDIA_CACHE_TTL:
            return []
        items = row.get("items") or []
        return [dict(x) for x in items if isinstance(x, dict)]
    except Exception:
        return []

def _save_recent_media_cache(source, kind, items):
    try:
        data = load_json(RECENT_MEDIA_CACHE_FILE, {}) or {}
        data[_recent_media_cache_key(source, kind)] = {
            "saved": int(time.time()),
            "items": [dict(x) for x in (items or [])[:100] if isinstance(x, dict)],
        }
        save_json(RECENT_MEDIA_CACHE_FILE, data)
    except Exception:
        pass

class MediaScreen(Screen):
    POSTER_X = [70, 450, 830, 1210, 1590]


    def __init__(self, session, source, kind, initialCategoryId=None, initialCategoryName=None):
        if kind == "live":
            # Live has its own remembered server. Movies and TV Shows continue
            # using the Home/server-manager selection independently.
            # Keep the virtual beIN source selected instead of replacing it with
            # the persisted real provider.  The real provider is refreshed only
            # inside the private beIN wrapper so ChoiceBox selection/check state
            # remains active after opening the new MediaScreen.
            if isinstance(source, dict) and source.get("_virtual_bein"):
                base = _load_live_source(_bein_base_source(source))
                source = _make_bein_virtual_source(base)
            else:
                source = _load_live_source(source)
            # Home skins do not change Live: keep the stable, Picon-enabled list.
            # This layout intentionally has no visible EPG grid.
            self.skin = _live_skin_with_style(_load_channel_settings().get("live_theme", "turquoise"))
        else:
            self.skin = VOD
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source = source
        self.kind = kind
        self.initialCategoryId = str(initialCategoryId or "")
        self.initialCategoryName = initialCategoryName or ""
        # Title logos are intentionally limited to the large pages opened from
        # Packages, so Home/other media flows remain untouched.
        self.packageTitleLogoEnabled = bool(kind in ("vod", "series") and self.initialCategoryId)
        self.activeCategoryName = self.initialCategoryName
        self.activePackageProvider = self._providerFromPackageName(self.initialCategoryName) if self.initialCategoryName else ""
        self.activeCategoryName = self.initialCategoryName
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.categories = []
        self.focus = "rail" if kind == "live" else "top"
        self.posterIndex = 0
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.pageStart = 0
        self.downloads = []
        self.picloads = []
        # r264: always initialize poster request tracking before Recent Add/category rendering.
        self._poster_artwork_requests = {}
        self["brand"] = Label("tv")
        self["rail"] = MenuList([("▣  تلفاز", "live"), ("▤  أفلام", "vod"), ("▥  مسلسلات", "series")])
        self["title"] = Label("%s  •  %s" % (source.get("name", "IPTV"), {"live":tr("LIVE TV"), "vod":tr("MOVIES"), "series":tr("TV SHOWS")}.get(kind, kind)))
        self["category"] = LiveCategoryMenuList([]) if kind == "live" else MenuList([])
        if kind != "live":
            self.topNames = [nav_label("Search"), nav_label("Home"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("Continue Watching"), nav_label("Settings")]
            self.topIndex = 3 if kind == "vod" else 4
            self.topX = [40, 225, 410, 595, 780, 965, 1150, 1510]
            self.topW = [175, 175, 175, 175, 175, 175, 350, 175]
            for _i, _name in enumerate(self.topNames):
                self["top%d" % _i] = Label(_name)
            self["topSelector"] = Pixmap()
            self["sectionTitle"] = Label(tr("MOVIE CATEGORIES") if kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"] = Label("⌕")
            self["filterIcon"] = Label("☰")
            self["currentCategory"] = Label("")
            self["titleLogo"] = Pixmap()
            try:
                self["titleLogo"].hide()
            except Exception:
                pass
            self._titleLogoToken = ""
            self._titleLogoLoader = None
        self["channelTitle"] = Label(tr("Select a package") if kind == "live" else tr("Select a category"))
        self["nowLabel"] = Label(tr("CONTENT"))
        self["meta"] = Label("")
        self["desc"] = Label(tr("Loading packages...") if kind == "live" else tr("Loading categories..."))
        if kind == "live":
            self["epgNowTime"] = Label("")
            self["epgNowTitle"] = Label("")
            self["epgNextTime"] = Label("")
            self["epgNextTitle"] = Label("")
            self["epgProgressText"] = Label("")
            from Components.ProgressBar import ProgressBar
            self["liveProgress"] = ProgressBar()
            self["livePoster"] = Pixmap()
            self["list"] = MenuList([])
            self["channelPicon"] = Pixmap()
            self["pageInfo"] = Label("")
            self["styleHint"] = Label("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
            
            # Small channel-row picons. They load only once per visible 15-row
            # page and use the existing direct_picon cache, so navigation stays fast.
            self.rowPiconLoaders = []
            self.rowPiconPaths = {}
            self.rowPiconPending = False
            self.rowPiconToken = 0
            self.rowPiconPage = -1
            self.rowPiconTimer = eTimer()
            self["clockTitle"] = Label("")
            self["categoryTitle"] = Label(tr("PACKAGES"))
            # Live browsing stays focused on channel lists, logos, and playback.
            self.channelSettings = _load_channel_settings()
            self.zapTimer = eTimer()
            _connect_timer(self.zapTimer, self._autoZapCurrent)
            self.livePiconLoader = ePicLoad()
            try: connect_picture_data(self.livePiconLoader, self._livePiconDecoded, self)
            except Exception: pass
            self.livePiconDownload = None
            self.livePiconToken = 0
            self.livePiconTimer = eTimer()
            _connect_timer(self.livePiconTimer, self._finishLivePicon)
            # TMDb Live poster is isolated from playback/EPG and starts only after a long idle.
            self.livePosterToken = 0
            self.livePosterResult = None
            self.livePosterTimer = eTimer()
            _connect_timer(self.livePosterTimer, self._startLivePosterLookup)
            self.livePosterPoll = eTimer()
            _connect_timer(self.livePosterPoll, self._finishLivePosterLookup)
            self.livePosterLoader = ePicLoad()
            try: connect_picture_data(self.livePosterLoader, self._livePosterDecoded, self)
            except Exception: pass
            self.livePosterPath = ""
            try: self["livePoster"].hide()
            except Exception: pass
            # Test30: provider-direct EPG fallback for every Xtream server.
            self.directEpgToken = 0
            self.directEpgResult = None
            self.directEpgTimer = eTimer()
            _connect_timer(self.directEpgTimer, self._finishDirectEpg)
            self.stalkerEpgDownloadedChannels = set()
            self.stalkerShortEpgResults = {}
            self.stalkerEpgPending = []
            self.stalkerEpgBatchRunning = False
            self.stalkerEpgGeneration = 0
            self.stalkerEpgClient = None
            self.stalkerEpgLock = threading.RLock()
            self.stalkerEpgApplyTimer = eTimer()
            _connect_timer(self.stalkerEpgApplyTimer, self._drainStalkerEpgUpdates)
            # EStalker 1.45 Live compatibility state.
            self.stalkerLivePageSize = 14
            self.stalkerLiveCategoryId = ""
            self.stalkerLiveTotal = 0
            self.stalkerLiveSlots = []
            self.stalkerLiveLoadedPages = set()
            self.stalkerLivePendingPages = set()
            self.stalkerLivePageResult = None
            self.stalkerLivePageGeneration = 0
            self.stalkerLiveCancelEvent = threading.Event()
            self.stalkerLivePageTimer = eTimer()
            _connect_timer(self.stalkerLivePageTimer, self._finishStalkerLivePage)
            self.onClose.append(self._cancelStalkerCatalogueRequests)
            self.stalkerSelectionEpgTimer = eTimer()
            _connect_timer(self.stalkerSelectionEpgTimer, self._runStalkerSelectionEpg)
            try: self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
            except Exception: self.oldService = None
            self.lastZappedLiveId = None
            self.keepCurrentLiveService = False
            self._playingLiveItem = None
            self._playingLiveUrl = ""
            self.stalkerWatchdogClient = None
            self.stalkerWatchdogPending = False
            self.stalkerWatchdogTimer = eTimer()
            _connect_timer(self.stalkerWatchdogTimer, self._runStalkerWatchdog)
            try:
                shared_id = str((self.source or {}).get("_tivimate_current_live_id") or "").strip()
                if shared_id:
                    self.lastZappedLiveId = shared_id
                    self.keepCurrentLiveService = True
                    _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
                    _CURRENT_LIVE_CHANNEL["channel"] = shared_id
                elif _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source):
                    self.lastZappedLiveId = _CURRENT_LIVE_CHANNEL.get("channel") or None
                    self.keepCurrentLiveService = bool(self.lastZappedLiveId)
            except Exception:
                pass
            self.stalkerPinUnlockedUntil = 0
            self._pinPendingAction = None
            self._pinFailures = 0
            self._pinBlockedUntil = 0
        else:
            self["backdrop"] = Pixmap()
            self["contentProviderNetflix"] = Pixmap()
            self["contentProviderPrime"] = Pixmap()
            self["contentProviderDisney"] = Pixmap()
            self["contentProviderMax"] = Pixmap()
            self["contentProviderApple"] = Pixmap()
            self["contentProviderParamount"] = Pixmap()
            for i in range(5):
                self["poster%d" % i] = Pixmap()
                self["posterLabel%d" % i] = Label("")
                self["posterRate%d" % i] = Label("")
            self["selector"] = Pixmap()
            self.backdropLoader = None
            self.backdropDownloader = None
            self.infoTimer = eTimer()
            _connect_timer(self.infoTimer, self.loadSelectedInfo)
            self.fullInfoCache = {}
            self.infoProcesses = {}
            self.pendingInfoId = ""
        self.categoryLoadToken = 0
        self.categoryLoadResult = None
        self.catchupPackageActive = False
        self.catchupPackageResult = None
        self.catchupPackageToken = 0
        self.catchupPackageTimer = eTimer()
        _connect_timer(self.catchupPackageTimer, self._finishCatchupPackageLoad)
        self.categoryLoadTimer = eTimer()
        _connect_timer(self.categoryLoadTimer, self._finishCategoryLoad)
        # Catalog requests are independent from category item requests.  This keeps
        # opening any table responsive even when a provider is slow or unavailable.
        self.catalogLoadToken = 0
        self.catalogLoadResult = None
        self.catalogLoadPolls = 0
        self.catalogFirstOpenRetry = 0
        self.catalogRetryTimer = eTimer()
        _connect_timer(self.catalogRetryTimer, self._retryCatalogFirstOpen)
        self.catalogLoadTimer = eTimer()
        _connect_timer(self.catalogLoadTimer, self._finishCatalogLoad)
        self["keys"] = Label(tr("LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back")) if kind != "live" else Label("")
        self["guideBar"] = Pixmap()
        if kind == "live": self._updateLiveKeys()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions", "NumberActions", "ChannelSelectBaseActions", "InfobarChannelSelection"], {
            "ok": self.ok, "cancel": self.cancelAction, "up": self.up, "down": self.down,
            "left": self.left, "right": self.right,
            "red": self.toggleCurrentFavourite if kind == "live" else self.previousCategory,
            "blue": self.openLiveColorMenu if kind == "live" else self.nextCategory,
            "green": self.openLiveFilter if kind == "live" else self.openCategoryMenu,
            "yellow": self.openLiveServerMenu if kind == "live" else self.toggleSort,
            "yellowlong": self.addCurrentFavourite,
            "menu": self.openLiveTools if kind == "live" else self.openFavorites,
            "info": self.openLiveTools if kind == "live" else self.openFavorites,
            "pageUp": self.pageUp, "pageDown": self.pageDown,
            "channelUp": self.liveFastUp, "channelDown": self.liveFastDown,
            "nextBouquet": self.liveFastDown, "prevBouquet": self.liveFastUp,
            "0": self.restartCurrentLiveStream
        }, -1)
        self.onLayoutFinish.append(self._prepareScreen)
        if kind != "live":
            self.onLayoutFinish.append(self._updateServerPackageGridLogo)

    def noAction(self):
        return

    def openBeinSports(self):
        """Open the dedicated beIN SPORTS view from Live without changing servers."""
        if self.kind != "live":
            return
        try:
            self._loadBeinSports()
        except Exception as exc:
            try:
                self["desc"].setText("beIN SPORTS: %s" % exc)
            except Exception:
                pass

    def _liveServerStatusLabel(self, source):
        state = str((source or {}).get("_last_status") or "").strip().lower()
        if state == "busy":
            return u"🟡"
        if state == "online":
            return u"🟢"
        if state == "offline":
            return u"🔴"
        return u"⚪"

    def _compactLiveServerName(self, source):
        name = str((source or {}).get("name") or "").strip()
        url = str((source or {}).get("url") or (source or {}).get("portal") or "").strip()
        # Finder's old post-title names are noisy. Prefer provider host/IP for them.
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    def _sameLiveServer(self, left, right):
        left = left or {}
        right = right or {}
        if str(left.get("type") or "").lower() != str(right.get("type") or "").lower():
            return False

        source_type = str(left.get("type") or "").lower()
        if source_type == "stalker":
            left_mac = str(left.get("mac") or "").strip().upper()
            right_mac = str(right.get("mac") or "").strip().upper()
            if left_mac and right_mac and left_mac != right_mac:
                return False

            def hostport(source):
                raw = str(source.get("url") or source.get("portal") or source.get("host") or "").strip()
                try:
                    parsed = urlparse(raw if "://" in raw else "http://" + raw)
                    host = (parsed.hostname or "").lower()
                    port = parsed.port
                    if not port:
                        port = 443 if parsed.scheme == "https" else 80
                    return host, int(port)
                except Exception:
                    return raw.rstrip("/").lower(), 0

            return hostport(left) == hostport(right) and bool(left_mac or right_mac)

        return _source_identity(left) == _source_identity(right)

    def openLiveServerMenu(self):
        if self.kind != "live":
            return
        sources = get_sources()
        if not sources:
            self.session.open(MessageBox, tr("No server selected • Press SETTINGS"), MessageBox.TYPE_INFO)
            return
        base_current = _bein_base_source(self.source)
        current_key = _source_identity(base_current)
        rows = []
        for candidate in sources:
            selected_here = (
                not self.source.get("_virtual_bein") and
                self._sameLiveServer(candidate, base_current)
            )
            rows.append((dict(candidate), selected_here))
        self.session.openWithCallback(
            self._liveServerSelected, LiveServerChoiceScreen, rows
        )

    def _liveServerSelected(self, selected=None):
        if not selected:
            return
        if isinstance(selected, tuple) and len(selected) == 2 and selected[0] in ("delete", "test"):
            action, source = selected
            if action == "delete":
                try:
                    sources = get_sources()
                    target = _source_identity(source)
                    kept = [item for item in sources if _source_identity(item) != target]
                    if len(kept) != len(sources):
                        set_sources(kept)
                        write_playlists(kept)
                except Exception:
                    pass
                return
            if action == "test":
                try:
                    source_type = source.get("type")
                    if source_type == "stalker":
                        details = StalkerClient(source).test()
                    elif source_type == "xtream":
                        details = XtreamClient(source).test()
                    else:
                        details = get_source_client(source).test()
                    msg = "ONLINE" if details else "Test completed"
                    self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
                except Exception as exc:
                    self.session.open(MessageBox, "Test failed: %s" % exc, MessageBox.TYPE_ERROR, timeout=6)
                return
        if isinstance(selected, dict):
            source = selected
        else:
            try:
                source = selected[1]
            except Exception:
                return
        if not isinstance(source, dict):
            return
        # Persist only a real provider.  beIN SPORTS is a view over that provider.
        if source.get("_virtual_bein"):
            _save_live_source(_bein_base_source(source))
        else:
            _save_live_source(source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, dict(source), "live")
        except Exception:
            pass

    def openLiveTools(self):
        if self.kind != "live":
            self.openFavorites(); return
        choices = [(tr("Favorites"), "favorites")]
        source_type = self.source.get("type")
        if source_type in ("stalker", "xtream"):
            pin_state = _load_stalker_pin(self.source) if source_type == "stalker" else _load_xtream_pin(self.source)
            if self.focus == "category":
                choices.append((tr("Hide this package"), "hide_category"))
                row = self["category"].getCurrent()
                cid = str(row[1] or "") if row else ""
                if cid and not cid.startswith("__"):
                    if cid in pin_state["categories"]:
                        choices.append((tr("Unlock this package"), "unlock_category"))
                    else:
                        choices.append((tr("Lock this package"), "lock_category"))
            elif self.current():
                choices.append((tr("Hide this channel"), "hide_channel"))
                channel_id = _live_item_id(self.current())
                if channel_id in pin_state["channels"]:
                    choices.append((tr("Unlock this channel"), "unlock_channel"))
                else:
                    choices.append((tr("Lock this channel"), "lock_channel"))
            choices.append((tr("Change parental PIN"), "change_pin"))
            choices.append(((tr("Stalker player engines") if source_type == "stalker" else tr("Xtream player engines")), "player_engines"))
            if source_type == "stalker":
                choices.append((tr("Recently watched"), "stalker_recent"))
            state = _load_stalker_hidden(self.source) if source_type == "stalker" else _load_xtream_hidden(self.source)
            if state["categories"]:
                choices.append((tr("Show hidden packages"), "show_hidden_packages"))
            if state["channels"]:
                choices.append((tr("Show hidden channels"), "show_hidden_channels"))
        self.session.openWithCallback(self._liveToolSelected, ChoiceBox, title=tr("Live options"), list=choices)

    def _liveToolSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        source_type = self.source.get("type")
        prefix = "stalker" if source_type == "stalker" else "xtream"
        if action == "favorites": self.openFavorites(); return
        if action == "hide_category": self._hideCurrentLiveCategory(prefix); return
        if action == "hide_channel": self._hideCurrentLiveChannel(prefix); return
        if action == "show_hidden_packages": self._showHiddenLiveItems(prefix, "category"); return
        if action == "show_hidden_channels": self._showHiddenLiveItems(prefix, "channel"); return
        if action in ("lock_category", "lock_channel"):
            self._lockCurrentLiveItem(prefix, action == "lock_category"); return
        if action in ("unlock_category", "unlock_channel"):
            self._requestLivePin(prefix, ("unlock", action == "unlock_category")); return
        if action == "change_pin": self._requestLivePin(prefix, ("change_pin", None)); return
        if action == "player_engines":
            return self._openStalkerEngineSettings() if source_type == "stalker" else self._openXtreamEngineSettings()
        if action == "stalker_recent": self._openStalkerRecentlyWatched(); return

    def _liveStateFns(self, prefix):
        if prefix == "stalker":
            return _load_stalker_hidden, _save_stalker_hidden, _load_stalker_pin, _save_stalker_pin
        return _load_xtream_hidden, _save_xtream_hidden, _load_xtream_pin, _save_xtream_pin

    def _hideCurrentLiveCategory(self, prefix):
        row = self["category"].getCurrent()
        if not row: return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source); state["categories"].add(cid); state["category_names"][cid] = str(name or cid); save_hidden(self.source, state)
        rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
        self["category"].setList(rows); self["list"].setList([]); self.focus = "category"
        self["desc"].setText(tr("Package hidden. Use MENU to restore it."))

    def _hideCurrentLiveChannel(self, prefix):
        item = self.current()
        if not item: return
        channel_id = _live_item_id(item)
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source); state["channels"].add(channel_id); state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id); save_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))

    def _showHiddenLiveItems(self, prefix, kind):
        load_hidden, _save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source)
        choices = []
        if kind == "category":
            for cid in sorted(state["categories"]):
                choices.append((state["category_names"].get(cid, cid), (prefix, "category", cid)))
            title = tr("Show hidden packages")
            empty = tr("No hidden packages.")
        else:
            for chid in sorted(state["channels"]):
                choices.append((state["channel_names"].get(chid, chid), (prefix, "channel", chid)))
            title = tr("Show hidden channels")
            empty = tr("No hidden channels.")
        if not choices:
            self.session.open(MessageBox, empty, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenLiveItem, ChoiceBox, title=title, list=choices)

    def _restoreHiddenLiveItem(self, selected=None):
        if not selected: return
        try:
            prefix, kind, item_id = selected[1]
        except Exception:
            return
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        save_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _lockCurrentLiveItem(self, prefix, is_category=False):
        _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source)
        if is_category:
            row=self["category"].getCurrent(); item_id=str(row[1] or "") if row else ""
            if not item_id or item_id.startswith("__"): return
            state["categories"].add(item_id); state["category_names"][item_id]=str(row[0] or item_id)
        else:
            item=self.current(); item_id=_live_item_id(item) if item else ""
            if not item_id: return
            state["channels"].add(item_id); state["channel_names"][item_id]=str(item.get("name") or item.get("title") or item_id)
        save_pin(self.source,state); self["desc"].setText(tr("Content locked."))

    def _requestLivePin(self, prefix, action):
        self._pinSourcePrefix=prefix; self._pinPendingAction=action
        self.session.openWithCallback(self._livePinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _livePinEntered(self, value=None):
        if value is None: return
        prefix=getattr(self,"_pinSourcePrefix","xtream"); _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source)
        if str(value).strip()!=str(state.get("pin") or "0000"): self.session.open(MessageBox,tr("Incorrect PIN"),MessageBox.TYPE_ERROR); return
        kind,payload=self._pinPendingAction
        if kind=="unlock":
            is_category=bool(payload)
            if is_category:
                row=self["category"].getCurrent(); item_id=str(row[1] or "") if row else ""; state["categories"].discard(item_id); state["category_names"].pop(item_id,None)
            else:
                item_id=_live_item_id(self.current()); state["channels"].discard(item_id); state["channel_names"].pop(item_id,None)
            save_pin(self.source,state); self["desc"].setText(tr("Lock removed."))
        elif kind=="change_pin":
            self.session.openWithCallback(lambda v,p=prefix:self._liveNewPinEntered(p,v),VirtualKeyBoard,title=tr("Enter new 4-digit PIN"),text="")

    def _liveNewPinEntered(self, prefix, value=None):
        value=str(value or "").strip()
        if not(len(value)==4 and value.isdigit()): self.session.open(MessageBox,tr("PIN must contain exactly 4 digits."),MessageBox.TYPE_ERROR); return
        _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source); state["pin"]=value; save_pin(self.source,state); self.session.open(MessageBox,tr("Parental PIN changed."),MessageBox.TYPE_INFO)

    def _openXtreamEngineSettings(self):
        self._xtreamEngineValues=_load_xtream_service_types(self.source); self._chooseXtreamEngine("live")

    def _chooseXtreamEngine(self, kind):
        labels={"live":tr("Xtream Live player"),"vod":tr("Xtream Movies player"),"series":tr("Xtream Series player")}; current=int(self._xtreamEngineValues.get(kind,4097)); choices=[((u"✓ " if v==current else u"")+str(v),v) for v in STALKER_SERVICE_TYPE_CHOICES]
        self.session.openWithCallback(lambda selected,k=kind:self._xtreamEngineSelected(k,selected),ChoiceBox,title=labels[kind],list=choices)

    def _xtreamEngineSelected(self, kind, selected=None):
        if not selected:return
        try:value=int(selected[1])
        except Exception:return
        self._xtreamEngineValues[kind]=value; order=("live","vod","series")
        try:next_kind=order[order.index(kind)+1]
        except Exception:next_kind=None
        if next_kind:return self._chooseXtreamEngine(next_kind)
        _save_xtream_service_types(self.source,self._xtreamEngineValues); self.channelSettings["service_type"]=self._xtreamEngineValues["live"]; _save_channel_settings(self.channelSettings); self.session.open(MessageBox,tr("Xtream player engines saved."),MessageBox.TYPE_INFO,timeout=3)

    def _openXtreamCatchup(self):
        item = self.current()
        if not item:
            return
        if not (item.get("tv_archive") or item.get("archive") or item.get("has_archive") or item.get("tv_archive_duration")):
            self.session.open(MessageBox, tr("This channel does not advertise catch-up support."), MessageBox.TYPE_INFO); return

        self._xtreamCatchupItem = dict(item)
        self._xtreamCatchupResult = None
        try:
            self["desc"].setText(tr("Loading catch-up programmes..."))
        except Exception:
            pass
        source = dict(self.source)
        stream_id = str(item.get("stream_id") or item.get("id") or "")
        epg_id = str(item.get("epg_channel_id") or item.get("epg_id") or "")

        def worker():
            rows, error = [], ""
            try:
                rows = XtreamClient(source).catchup_epg(stream_id, epg_channel_id=epg_id) or []
            except Exception as exc:
                error = str(exc)
            self._xtreamCatchupResult = (rows, error)

        t = threading.Thread(target=worker, name="TiviMateXtreamCatchup")
        t.daemon = True
        t.start()
        self._xtreamCatchupTimer = eTimer()
        _connect_timer(self._xtreamCatchupTimer, self._finishXtreamCatchupLoad)
        try:
            self._xtreamCatchupTimer.start(120, False)
        except Exception:
            pass

    def _parseXtreamCatchupDate(self, value):
        text = str(value or "").strip().replace("T", " ")
        if not text:
            return None
        # XStreamity parses the provider's raw EPG wall-clock value and uses
        # that same wall-clock for the timeshift URL. Do not convert through
        # receiver localtime/UTC here.
        for fmt in (
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H-%M-%S",
            "%Y-%m-%d-%H:%M:%S",
            "%Y-%m-%d %H:%M",
        ):
            try:
                return datetime.strptime(text[:19] if "%S" in fmt else text[:16], fmt)
            except Exception:
                pass
        return None

    def _finishXtreamCatchupLoad(self):
        result = getattr(self, "_xtreamCatchupResult", None)
        if result is None:
            try:
                self._xtreamCatchupTimer.start(120, False)
            except Exception:
                pass
            return
        try:
            self._xtreamCatchupTimer.stop()
        except Exception:
            pass

        self._xtreamCatchupResult = None
        rows, error = result
        now = int(time.time())
        item = getattr(self, "_xtreamCatchupItem", {}) or {}

        # Xtream tv_archive_duration is the provider's archive window in days.
        try:
            archive_days = int(float(str(item.get("tv_archive_duration") or "0")))
        except Exception:
            archive_days = 0
        if archive_days <= 0:
            self.session.open(
                MessageBox,
                tr("This channel has no provider catch-up window."),
                MessageBox.TYPE_INFO
            )
            return

        cutoff = now - (archive_days * 86400)
        choices = []

        for row in rows or []:
            if not isinstance(row, dict):
                continue

            title = self._decodeEpgText(
                row.get("title") or row.get("name") or row.get("programme")
            )
            if not title:
                continue

            begin = self._epgTimestamp(row, True)
            finish = self._epgTimestamp(row, False)

            # Catch-up = a completed historical programme only.
            # Never show current or future EPG rows.
            if not begin or not finish:
                continue
            if finish > now:
                continue
            if begin < cutoff:
                continue
            if finish <= begin:
                continue

            raw_start = row.get("start") or row.get("begin") or ""
            raw_end = row.get("end") or row.get("stop") or ""
            start_dt = self._parseXtreamCatchupDate(raw_start)
            end_dt = self._parseXtreamCatchupDate(raw_end)

            if start_dt:
                catchup_date = start_dt.strftime("%Y-%m-%d:%H-%M")
            else:
                catchup_date = time.strftime(
                    "%Y-%m-%d:%H-%M", time.localtime(begin)
                )

            if start_dt and end_dt and end_dt > start_dt:
                duration = max(
                    1, int((end_dt - start_dt).total_seconds() / 60.0)
                )
            else:
                duration = max(1, int((finish - begin + 59) / 60))

            payload = dict(row)
            payload["_begin"] = begin
            payload["_end"] = finish
            payload["_catchup_date"] = catchup_date
            payload["_catchup_duration"] = duration
            payload["_catchup_raw_start"] = str(raw_start or "")
            payload["_catchup_raw_end"] = str(raw_end or "")

            label = "%s  %s" % (
                time.strftime("%d/%m %H:%M", time.localtime(begin)),
                title
            )
            choices.append((label, payload))

        # Newest archived programme first.
        try:
            choices.sort(
                key=lambda x: int((x[1] or {}).get("_begin") or 0),
                reverse=True
            )
        except Exception:
            pass

        if not choices:
            message = tr("No archived programmes are available inside this channel's catch-up window.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
            return

        self.session.openWithCallback(
            self._playXtreamCatchup,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )


    def _playXtreamCatchup(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = getattr(self, "_xtreamCatchupItem", {}) or {}
        try:
            begin = int(event.get("_begin") or self._epgTimestamp(event, True) or 0)
            end = int(event.get("_end") or self._epgTimestamp(event, False) or 0)
            if not begin:
                raise RuntimeError(tr("Programme start time is missing"))
            if not end or end <= begin:
                end = begin + 3600

            # Match XStreamity: duration is minutes and catch-up playback uses
            # the VOD/Series player engine rather than the Live engine.
            duration = int(event.get("_catchup_duration") or 0)
            if duration <= 0:
                duration = max(1, int((end - begin + 59) / 60))
            source = self.source or {}
            base = str(source.get("url") or "").rstrip("/")
            user = str(source.get("username") or "")
            password = str(source.get("password") or "")
            sid = str(item.get("stream_id") or item.get("id") or "").strip()
            if not (base and user and password and sid):
                raise RuntimeError(tr("Xtream archive credentials are incomplete"))

            # XStreamity keeps the final stream component including its real
            # extension. Preserve .ts/.m3u8 from the provider instead of
            # hard-coding .ts.
            stream_name = ""
            for candidate in (
                item.get("url"), item.get("stream_url"), item.get("direct_source"),
                item.get("cmd")
            ):
                candidate = str(candidate or "").strip()
                if candidate and "/live/" in candidate:
                    stream_name = candidate.rsplit("/", 1)[-1].split("?", 1)[0]
                    if stream_name:
                        break

            if not stream_name:
                output = str(
                    source.get("output") or source.get("stream_format") or
                    source.get("format") or "ts"
                ).strip().lstrip(".")
                if not output:
                    output = "ts"
                stream_name = "%s.%s" % (sid, output)

            start_text = str(event.get("_catchup_date") or "").strip()
            if not start_text:
                start_text = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))

            # Build conservative fallbacks for provider timezone differences.
            # The first URL is unchanged. Alternatives are tried only if the
            # first one never actually starts playback.
            start_variants = []
            def add_start(value):
                value = str(value or "").strip()
                if value and value not in start_variants:
                    start_variants.append(value)

            add_start(start_text)
            add_start(time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin)))
            add_start(time.strftime("%Y-%m-%d:%H-%M", time.gmtime(begin)))
            try:
                base_dt = datetime.strptime(start_text, "%Y-%m-%d:%H-%M")
                add_start((base_dt - timedelta(hours=1)).strftime("%Y-%m-%d:%H-%M"))
                add_start((base_dt + timedelta(hours=1)).strftime("%Y-%m-%d:%H-%M"))
            except Exception:
                pass

            catchup_urls = []
            for candidate_start in start_variants:
                # Modern/common Xtream path form.
                candidate_url = "%s/timeshift/%s/%s/%d/%s/%s" % (
                    base, user, password, duration, candidate_start, stream_name
                )
                if candidate_url not in catchup_urls:
                    catchup_urls.append(candidate_url)

                # Older/classic Xtream endpoint used by a number of panels.
                # Keep stream as the numeric stream id, not filename.
                try:
                    query_url = (
                        "%s/streaming/timeshift.php?username=%s&password=%s"
                        "&stream=%s&start=%s&duration=%d"
                    ) % (
                        base, user, password, sid,
                        candidate_start.replace(":", "%3A"),
                        duration
                    )
                    if query_url not in catchup_urls:
                        catchup_urls.append(query_url)
                except Exception:
                    pass

            if not catchup_urls:
                raise RuntimeError(tr("Unable to build catch-up URL"))

            # Probe candidates before entering the player. Some providers publish
            # archive metadata but accept only one Xtream timeshift endpoint.
            def candidate_works(candidate):
                try:
                    req = Request(candidate)
                    try:
                        req.add_header("Range", "bytes=0-1023")
                    except Exception:
                        pass
                    response = urlopen(req, timeout=5)
                    try:
                        code = int(getattr(response, "getcode", lambda: 200)() or 200)
                    except Exception:
                        code = 200
                    try:
                        chunk = response.read(1024)
                    finally:
                        try:
                            response.close()
                        except Exception:
                            pass
                    return code in (200, 206) and bool(chunk)
                except Exception:
                    return False

            working_url = ""
            ordered_urls = []
            for candidate in catchup_urls:
                if candidate_works(candidate):
                    working_url = candidate
                    ordered_urls.append(candidate)
                    break

            if working_url:
                for candidate in catchup_urls:
                    if candidate != working_url:
                        ordered_urls.append(candidate)
                catchup_urls = ordered_urls
                url = working_url
            else:
                # Keep player retry as final fallback for unusual servers that
                # reject Range/probe requests but still play through Enigma2.
                url = catchup_urls[0]

            try:
                service_type = int(_load_xtream_service_types(self.source).get("vod", 4097))
            except Exception:
                service_type = 4097

            title = self._decodeEpgText(
                event.get("title") or event.get("name")
            ) or item.get("name") or "Catch-up"

            ref = eServiceReference(service_type, 0, url)
            ref.setName(title)

            play_item = dict(item)
            play_item["_source_type"] = "xtream"
            play_item["_source_key"] = _source_identity(self.source)
            play_item["_kind"] = "vod"
            play_item["_catchup"] = True
            play_item["_catchup_begin"] = begin
            play_item["_catchup_end"] = end
            play_item["_catchup_url"] = url
            play_item["_catchup_candidates"] = catchup_urls
            play_item["_catchup_service_type"] = service_type
            play_item["name"] = title

            self.session.openWithCallback(
                self.playerClosed, TiviMatePlayer, ref, play_item
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )


    def _openStalkerRecentlyWatched(self):
        if self.source.get("type") != "stalker":
            return
        rows = _load_stalker_recent(self.source, 30)
        choices = []
        for resume_key, row in rows:
            title = str(row.get("title") or tr("Untitled"))
            position = int(row.get("position", 0) or 0)
            length = int(row.get("length", 0) or 0)
            if length > 0:
                pct = max(0, min(99, int(position * 100 / length)))
                label = "%s  •  %d%%" % (title, pct)
            else:
                label = "%s  •  %02d:%02d" % (title, position // 60, position % 60)
            choices.append((label, (resume_key, row)))
        if not choices:
            self.session.open(MessageBox, tr("No recently watched Stalker items."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerRecentlyWatched, ChoiceBox, title=tr("Recently watched"), list=choices)

    def _playStalkerRecentlyWatched(self, selected=None):
        if not selected:
            return
        try:
            _resume_key_value, row = selected[1]
            item = dict(row.get("item") or {})
            kind = str(row.get("kind") or "vod")
            if kind not in ("vod", "series"):
                kind = "vod"
            item["_source_type"] = "stalker"
            item["_source_key"] = _source_identity(self.source)
            item["_kind"] = kind
            url = StalkerClient(dict(self.source)).stream_url(item, kind)
            if not url:
                raise RuntimeError(tr("Portal returned no playable URL"))
            ref = eServiceReference(_stalker_service_type(self.source, kind), 0, url)
            ref.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, ref, item)
        except Exception as exc:
            self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)

    def _openStalkerEngineSettings(self):
        if self.source.get("type") != "stalker":
            return
        self._stalkerEngineValues = _load_stalker_service_types(self.source)
        self._chooseStalkerEngine("live")

    def _chooseStalkerEngine(self, kind):
        labels = {"live": tr("Stalker Live player"), "vod": tr("Stalker Movies player"), "series": tr("Stalker Series player")}
        current = int(self._stalkerEngineValues.get(kind, 4097))
        choices = []
        for value in STALKER_SERVICE_TYPE_CHOICES:
            choices.append(((u"✓ " if value == current else u"") + str(value), value))
        self.session.openWithCallback(lambda selected, k=kind: self._stalkerEngineSelected(k, selected), ChoiceBox, title=labels.get(kind, kind), list=choices)

    def _stalkerEngineSelected(self, kind, selected=None):
        if not selected:
            return
        try:
            value = int(selected[1])
        except Exception:
            return
        if value not in STALKER_SERVICE_TYPE_CHOICES:
            return
        self._stalkerEngineValues[kind] = value
        order = ("live", "vod", "series")
        try:
            next_kind = order[order.index(kind) + 1]
        except Exception:
            next_kind = None
        if next_kind:
            return self._chooseStalkerEngine(next_kind)
        if _save_stalker_service_types(self.source, self._stalkerEngineValues):
            self.session.open(MessageBox, tr("Stalker player engines saved."), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, tr("Unable to save Stalker player engines."), MessageBox.TYPE_ERROR)

    def _lockCurrentStalkerItem(self, is_category=False):
        if self.source.get("type") != "stalker":
            return
        state = _load_stalker_pin(self.source)
        if is_category:
            row = self["category"].getCurrent()
            if not row:
                return
            item_id = str(row[1] or "")
            if not item_id or item_id.startswith("__"):
                self.session.open(MessageBox, tr("This package cannot be locked."), MessageBox.TYPE_INFO); return
            state["categories"].add(item_id)
            state["category_names"][item_id] = str(row[0] or item_id)
            message = tr("Package locked.")
        else:
            item = self.current()
            if not item:
                return
            item_id = _live_item_id(item)
            if not item_id:
                return
            state["channels"].add(item_id)
            state["channel_names"][item_id] = str(item.get("name") or item.get("title") or item_id)
            message = tr("Channel locked.")
        _save_stalker_pin(self.source, state)
        try: self["desc"].setText(message)
        except Exception: pass

    def _requestStalkerPin(self, action):
        if time.time() < getattr(self, "_pinBlockedUntil", 0):
            wait = max(1, int(self._pinBlockedUntil - time.time()))
            self.session.open(MessageBox, "%s %s" % (tr("Try again in"), wait), MessageBox.TYPE_ERROR); return
        self._pinPendingAction = action
        self.session.openWithCallback(self._stalkerPinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _stalkerPinEntered(self, value=None):
        if value is None:
            self._pinPendingAction = None
            return
        state = _load_stalker_pin(self.source)
        if str(value).strip() != str(state.get("pin") or "0000"):
            self._pinFailures = getattr(self, "_pinFailures", 0) + 1
            if self._pinFailures >= 3:
                self._pinBlockedUntil = time.time() + 30
                self._pinFailures = 0
            self._pinPendingAction = None
            self.session.open(MessageBox, tr("Incorrect PIN"), MessageBox.TYPE_ERROR); return
        self._pinFailures = 0
        action = self._pinPendingAction
        self._pinPendingAction = None
        if not action:
            return
        kind, payload = action
        if kind == "play":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLivePlayerNow()
        if kind == "category":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLockedCategoryNow()
        if kind == "unlock":
            is_category = bool(payload)
            state = _load_stalker_pin(self.source)
            if is_category:
                row = self["category"].getCurrent()
                item_id = str(row[1] or "") if row else ""
                state["categories"].discard(item_id)
                state["category_names"].pop(item_id, None)
            else:
                item_id = _live_item_id(self.current())
                state["channels"].discard(item_id)
                state["channel_names"].pop(item_id, None)
            _save_stalker_pin(self.source, state)
            try: self["desc"].setText(tr("Lock removed."))
            except Exception: pass
            return
        if kind == "change_pin":
            self.session.openWithCallback(self._stalkerNewPinEntered, VirtualKeyBoard, title=tr("Enter new 4-digit PIN"), text="")

    def _stalkerNewPinEntered(self, value=None):
        value = str(value or "").strip()
        if not (len(value) == 4 and value.isdigit()):
            self.session.open(MessageBox, tr("PIN must contain exactly 4 digits."), MessageBox.TYPE_ERROR); return
        state = _load_stalker_pin(self.source)
        state["pin"] = value
        _save_stalker_pin(self.source, state)
        self.stalkerPinUnlockedUntil = time.time() + 300
        self.session.open(MessageBox, tr("Parental PIN changed."), MessageBox.TYPE_INFO)

    def _isCurrentStalkerCategoryLocked(self):
        if self.source.get("type") != "stalker":
            return False
        row = self["category"].getCurrent()
        cid = str(row[1] or "") if row else ""
        return bool(cid and cid in _load_stalker_pin(self.source)["categories"])

    def _isCurrentStalkerChannelLocked(self):
        if self.source.get("type") != "stalker":
            return False
        return _live_item_id(self.current()) in _load_stalker_pin(self.source)["channels"]

    def _hideCurrentStalkerCategory(self):
        row = self["category"].getCurrent()
        if not row:
            return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        state = _load_stalker_hidden(self.source)
        state["categories"].add(cid)
        state["category_names"][cid] = str(name or cid)
        _save_stalker_hidden(self.source, state)
        try:
            rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
            self["category"].setList(rows)
            self["list"].setList([])
            self.focus = "category"
            self["desc"].setText(tr("Package hidden. Use MENU to restore it."))
        except Exception:
            pass

    def _hideCurrentStalkerChannel(self):
        item = self.current()
        if not item:
            return
        channel_id = _live_item_id(item)
        if not channel_id:
            return
        state = _load_stalker_hidden(self.source)
        state["channels"].add(channel_id)
        state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id)
        _save_stalker_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        try: self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))
        except Exception: pass

    def _showHiddenStalkerPackages(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["category_names"].get(cid, cid), ("category", cid)) for cid in sorted(state["categories"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden packages."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden packages"), list=choices)

    def _showHiddenStalkerChannels(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["channel_names"].get(chid, chid), ("channel", chid)) for chid in sorted(state["channels"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden channels."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden channels"), list=choices)

    def _restoreHiddenStalkerItem(self, selected=None):
        if not selected:
            return
        try:
            kind, item_id = selected[1]
        except Exception:
            return
        state = _load_stalker_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        _save_stalker_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _openStalkerCatchup(self):
        item = self.current()
        if not item or self.source.get("type") != "stalker":
            return
        self._catchupItem = dict(item)
        self._catchupResult = None
        try: self["desc"].setText(tr("Loading catch-up programmes..."))
        except Exception: pass
        source = dict(self.source)
        channel_id = _live_item_id(item)
        def worker():
            rows, error = [], ""
            try:
                rows = StalkerClient(source).short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchupResult = (rows, error)
        threading.Thread(target=worker, name="TiviMateStalkerCatchup", daemon=True).start()
        self._catchupTimer = eTimer()
        _connect_timer(self._catchupTimer, self._finishStalkerCatchupLoad)
        try: self._catchupTimer.start(150, False)
        except Exception: pass

    def _finishStalkerCatchupLoad(self):
        result = getattr(self, "_catchupResult", None)
        if result is None:
            try: self._catchupTimer.start(150, False)
            except Exception: pass
            return
        try: self._catchupTimer.stop()
        except Exception: pass
        self._catchupResult = None
        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            if begin and begin < now and title and (archive not in (0, "0", False) or end <= now):
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, dict(row)))
        if not choices:
            message = tr("No catch-up programmes are available for this channel.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerCatchup, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _playStalkerCatchup(self, selected=None):
        if not selected:
            return
        event = selected[1]
        item = getattr(self, "_catchupItem", {}) or {}
        try:
            client = StalkerClient(dict(self.source))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))
            service_type = _stalker_service_type(self.source, "live")
            ref = eServiceReference(service_type, 0, url)
            ref.setName(self._decodeEpgText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up")
            self.session.nav.playService(ref)
            self["meta"].setText(tr("Playing catch-up"))
        except Exception as exc:
            self.session.open(MessageBox, "%s: %s" % (tr("Unable to play catch-up"), exc), MessageBox.TYPE_ERROR)

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, source, "live")
        except Exception:
            pass

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def _moveCategory(self, direction):
        """Move through VOD/series categories without reopening or redesigning the screen."""
        if self.kind == "live":
            return
        try:
            rows = list(self["category"].list or [])
        except Exception:
            rows = []
        if not rows:
            try:
                self["meta"].setText(tr("Loading packages/categories..."))
            except Exception:
                pass
            return
        try:
            current = int(self["category"].getSelectedIndex())
        except Exception:
            current = 0
        target = (current + int(direction)) % len(rows)
        try:
            self["category"].moveToIndex(target)
        except Exception:
            return
        try:
            selected = rows[target]
            self.initialCategoryName = selected[0] or ""
            self.initialCategoryId = str(selected[1] or "")
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def previousCategory(self):
        self._moveCategory(-1)

    def nextCategory(self):
        self._moveCategory(1)

    def toggleCurrentFavourite(self):
        # Red toggles the highlighted Live channel: add when absent, remove when saved.
        item = None
        try:
            current_row = self["list"].getCurrent()
            item = current_row[1] if current_row else None
        except Exception:
            item = self.current()
        if not isinstance(item, dict):
            try:
                self["meta"].setText(tr("Open a package, select a channel, then press RED"))
            except Exception:
                pass
            return
        title = item.get("name") or item.get("title") or "Channel"
        try:
            added, saved = toggle_favourite(self.source, "live", item)
            if not saved:
                message = "Unable to update favorites"
            elif added:
                message = "★ Added %s to FAVORITES" % title
            else:
                message = "☆ Removed %s from FAVORITES" % title
                # When the user removes a row while viewing FAVORITES, refresh the
                # local list immediately. The provider package remains untouched.
                try:
                    if self.selectedCategory() == "__favorites__":
                        self.loadSelectedCategory()
                except Exception:
                    pass
            self["meta"].setText(message)
        except Exception as exc:
            try:
                self["meta"].setText("Favorites error: %s" % exc)
            except Exception:
                pass

    def addCurrentFavourite(self):
        # Long yellow is add-only for Movies and TV Shows.  The normal yellow key
        # remains sorting, and the Live action map deliberately stays untouched.
        if self.kind not in ("vod", "series"):
            return
        item = self.current()
        if not item:
            try:
                self["meta"].setText(tr("Select a movie or TV show first"))
            except Exception:
                pass
            return
        if is_favourite(self.source, self.kind, item):
            message = "Item is already in favorites"
        elif add_favourite(self.source, self.kind, item):
            message = "Added to favorites"
        else:
            message = "Unable to save favorite"
        try:
            self["meta"].setText(message)
        except Exception:
            pass


    def _updateTopFocus(self):
        if self.kind == "live":
            return
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(75)))
            self["topSelector"].setVisible(self.focus == "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openTopItem(self):
        if self.kind == "live":
            return
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Search, self.source); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.source, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(ContentHomeScreen, self.source, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(ContentHomeScreen, self.source, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.source); return
        if self.topIndex == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source); return
        if self.topIndex == 7:
            self._openPageOnce(SettingsDashboard); return

    def openCategoryMenu(self):
        if self.kind == "live":
            return
        try:
            self.session.openWithCallback(
                self._categoryMenuSelected, HomePackageBrowserScreen,
                self.source, self.kind
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open packages:\n%s" % exc, MessageBox.TYPE_ERROR)






    def _categoryMenuSelected(self, selected=None):
        if not selected:
            return
        cid = str(selected.get("id") or "")
        name = selected.get("name") or ""
        self.initialCategoryId = cid
        self.initialCategoryName = name
        self.activeCategoryName = name
        self.activePackageProvider = self._providerFromPackageName(name)
        self._updateServerPackageGridLogo()
        try:
            for pos, row in enumerate(self["category"].list):
                if str(row[1]) == cid:
                    self["category"].moveToIndex(pos)
                    break
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def _prepareScreen(self):
        try:
            idx = {"live": 0, "vod": 1, "series": 2}.get(self.kind, 0)
            self["rail"].moveToIndex(idx)
        except Exception:
            pass
        self.updateSectionLabels()
        if self.kind != "live":
            self._updateTopFocus()
        if self.kind in ("vod","series") and self.initialCategoryId in ("__server_netflix__","__server_prime__"):
            provider="netflix" if self.initialCategoryId=="__server_netflix__" else "prime"
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self.activePackageProvider=provider
            self._updateServerPackageGridLogo()
            self._loadMergedServerProvider(provider)
            return
        if self.kind == "live":
            self._updateLiveClock()
            try: self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
            except Exception: pass
            self._startStalkerWatchdog()
        self.loadCategories()

    def currentRailSection(self):
        current = self["rail"].getCurrent()
        return current[1] if current else self.kind

    def updateSectionLabels(self):
        label = {"live": "LIVE TV", "vod": "MOVIES", "series": "TV SHOWS"}.get(self.kind, self.kind)
        self["title"].setText("%s  •  %s" % (("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "IPTV")), label))
        if self.kind != "live":
            self["sectionTitle"].setText(tr("MOVIE CATEGORIES") if self.kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"].setText(tr(""))

    def switchSection(self, section):
        if section == self.kind:
            self.focus = "category"
            return
        if section == "live":
            self._openPageOnce(MediaScreen, self.source, "live")
            return
        # LIVE and VOD/Series use different widget sets/skins.  Do not mutate
        # a LIVE screen into a VOD/Series screen in-place: widgets such as
        # currentCategory/sectionTitle do not exist on the LIVE skin and
        # DreamOS raises KeyError when navigation tries to access them.
        if self.kind == "live":
            # Live has an independent remembered provider.  When leaving Live for
            # Movies/TV Shows, always restore the Home/VOD provider instead of
            # carrying the currently selected Live server into every section.
            fallback = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            target_source = _load_main_source(fallback)
            self._openPageOnce(MediaScreen, target_source, section)
            return
        self.kind = section
        self.focus = "category"
        self.searchQuery = ""
        self.sortMode = "default"
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.lastCategoryItems = []
        self.categories = []
        self.pageStart = 0
        self.posterIndex = 0
        try:
            self.infoTimer.stop()
        except Exception:
            pass
        self["category"].setList([])
        self["channelTitle"].setText(tr("Select a category"))
        self["meta"].setText(tr(""))
        self["desc"].setText(tr("Loading categories..."))
        try:
            self["currentCategory"].setText(tr(""))
        except Exception:
            pass
        self.updateSectionLabels()
        self.loadCategories()

    def loadCategories(self):
        """Load provider catalog data outside Enigma2's UI thread.

        Category lists are shared by LIVE, VOD, and Series.  The former direct
        provider calls could block every table while DNS/HTTP/M3U parsing ran.
        r87 shows a lightweight loading message and applies the ready result from
        a timer callback only after the worker has completed.
        """
        # Optional Netflix / Prime packages are true TMDb provider catalogs.
        # They intentionally bypass IPTV-server categories.
        _special_id=str(getattr(self,"initialCategoryId","") or "")
        if _special_id in ("__tmdb_netflix__", "__tmdb_prime__") and self.kind in ("vod","series"):
            self.catalogLoadToken += 1
            token=self.catalogLoadToken
            provider="netflix" if _special_id=="__tmdb_netflix__" else "prime"
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self.activePackageProvider=provider
            self.catalogLoadResult=None
            try:
                self["desc"].setText("Loading %s from TMDb..." % self.activeCategoryName)
                self["currentCategory"].setText(self.activeCategoryName)
            except Exception:
                pass
            self._updateServerPackageGridLogo()
            def _tmdb_provider_worker():
                try:
                    client=TMDbClient()
                    if not client.configured():
                        result=(token,"tmdb_provider",[],[],"TMDb is not configured",provider)
                    else:
                        items=client.provider_catalog(self.kind,provider,limit=50) or []
                        for _item in items:
                            if isinstance(_item,dict):
                                _item["_tmdb_provider"]=provider
                                _item["_server_package_provider"]=provider
                                _item["_server_package_name"]=self.activeCategoryName
                        result=(token,"tmdb_provider",[],items,"",provider)
                except Exception as exc:
                    result=(token,"tmdb_provider",[],[],str(exc),provider)
                self.catalogLoadResult=result
            threading.Thread(target=_tmdb_provider_worker,name="TiviMateTMDbProvider",daemon=True).start()
            try:self.catalogLoadTimer.start(120,True)
            except Exception:pass
            return

        self.catalogLoadToken += 1
        token = self.catalogLoadToken
        self.catalogLoadPolls = 0
        source = dict(self.source)
        kind = self.kind
        self.catalogLoadResult = None
        try:
            self["category"].setList([])
            self["list"].setList([])
        except Exception:
            pass
        try:
            self["desc"].setText("Loading catalog in background..." if kind == "live" else "Preparing the list in background...")
        except Exception:
            pass

        def worker():
            try:
                source_type = source.get("type")
                if kind == "live" and source.get("_virtual_bein"):
                    cached, fresh, stamp = _load_bein_cache(source)
                    if cached:
                        result = (token, "bein_virtual", [], cached, "", "cache")
                    else:
                        base = _bein_base_source(source)
                        client = get_source_client(base)
                        all_items = client.streams("live", "") or []
                        bein_items = [item for item in all_items if _is_bein_sports_channel(item)]
                        _save_bein_cache(base, bein_items)
                        result = (token, "bein_virtual", [], bein_items, "", "server")
                elif source_type in ("xtream", "stalker"):
                    if kind == "live":
                        categories, origin = get_cached_categories(
                            source, "live", client=None, wait_for_server=True
                        )
                        result = (token, source_type, categories or [], [], "", origin)
                    else:
                        categories, origin = get_cached_categories(
                            source, kind, get_source_client(source), wait_for_server=True
                        )
                        result = (token, source_type, categories or [], [], "", origin)
                elif source_type == "m3u":
                    entries, origin = get_cached_catalog(source, "live", lambda: M3UClient(source).entries(), wait_for_server=True)
                    result = (token, "m3u", [], entries or [], "", origin)
                elif source_type == "fg":
                    result = (token, "error", [], [], "FG Code test support was removed. Use Xtream, Stalker, or M3U.", "")
                else:
                    entries, origin = get_cached_catalog(source, "live", lambda: StalkerClient(source).channels(), wait_for_server=True)
                    result = (token, "stalker", [], entries or [], "", origin)
            except Exception as exc:
                result = (token, "error", [], [], str(exc), "")
            self.catalogLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2Catalog", daemon=True).start()
        try:
            self.catalogLoadTimer.start(120, True)
        except Exception:
            pass

    def _retryCatalogFirstOpen(self):
        # Xtream/Stalker can be cold on the very first request after plugin start.
        # Retry once inside the same screen instead of forcing the user to Exit and re-enter.
        try:
            self.loadCategories()
        except Exception:
            pass

    def _finishCatalogLoad(self):
        result = self.catalogLoadResult
        if not result:
            try:
                self.catalogLoadTimer.start(120, True)
            except Exception:
                pass
            return
        self.catalogLoadResult = None
        token, mode, categories, items, error, origin = result
        if token != self.catalogLoadToken:
            return
        if mode == "tmdb_provider":
            provider=str(origin or "").strip().lower()
            self.activePackageProvider=provider
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self._updateServerPackageGridLogo()
            if error:
                try:
                    self["desc"].setText("TMDb error:\n%s" % error)
                    self["currentCategory"].setText(self.activeCategoryName)
                except Exception:
                    pass
                self.mediaItems=[]
                self.mediaItemsCurrent=[]
                return
            self.categories=[]
            self.lastCategoryItems=list(items or [])
            self.mediaItems=list(items or [])
            try:self["currentCategory"].setText(self.activeCategoryName)
            except Exception:pass
            self.focus="items"
            self.showItems(self.lastCategoryItems)
            return
        if mode == "retry_series":
            try:
                self["desc"].setText(tr("Preparing series categories in the background..."))
                self.catalogLoadTimer.start(500, False)
                self.catalogLoadResult = (token, "restart", [], [], "", "")
            except Exception:
                pass
            return
        if mode == "restart":
            self.loadCategories()
            return
        if mode == "error":
            if self.source.get("type") in ("xtream", "stalker") and self.catalogFirstOpenRetry < 1:
                self.catalogFirstOpenRetry += 1
                try:
                    self["desc"].setText(tr("Connecting to server..."))
                    self.catalogRetryTimer.start(700, True)
                except Exception:
                    self._retryCatalogFirstOpen()
                return
            try:
                self["desc"].setText(("Unable to load catalog:\\n%s" % error) if self.kind == "live" else ("خطأ في التحميل:\\n%s" % error))
            except Exception:
                pass
            return
        if mode == "bein_virtual":
            self.mediaItems = items or []
            self.mediaItemsCurrent = items or []
            self.categories = [{"category_name": u"⚽  beIN SPORTS", "category_id": "__bein_virtual__"}]
            self["category"].setList([(u"⚽  beIN SPORTS", "__bein_virtual__")])
            self._applyCategoryItems(items or [], "beIN SPORTS", origin or "cache")
            self.focus = "items"
            if not items:
                self["desc"].setText("No beIN SPORTS channels found in the selected server.")
            return
        if mode in ("xtream", "stalker"):
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all movies", "all films", "all vod", "all series", "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            rows = []
            filtered = []
            for entry in categories:
                name = (entry.get("category_name") or "Other").strip()
                cid = str(entry.get("category_id", ""))
                if allowed_ids is not None and cid not in allowed_ids:
                    continue
                if self.kind == "live" and not _adult_source_enabled(self.source) and _adult_live_name(name):
                    continue
                if self.kind in ("vod", "series") and name.lower() in blocked:
                    continue
                filtered.append(entry)
                rows.append((name, cid))
            if self.kind == "live":
                if self.source.get("type") in ("stalker", "xtream"):
                    hidden_state = _load_stalker_hidden(self.source) if self.source.get("type") == "stalker" else _load_xtream_hidden(self.source)
                    filtered = [entry for entry in filtered if str(entry.get("category_id", "")) not in hidden_state["categories"]]
                special = [
                    {"category_name": u"★  " + tr("FAVORITES"), "category_id": "__favorites__"},
                    {"category_name": u"＋  " + tr("RECENTLY ADDED"), "category_id": "__recent_added__"},
                ]
                if bool((self.source or {}).get("catchup_enabled", False)):
                    special.append({"category_name": u"↶  " + tr("CATCH-UP / ARCHIVE"), "category_id": "__catchup__"})
                filtered = special + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            elif self.kind in ("vod", "series"):
                recent = {"category_name": tr("RECENTLY ADDED"), "category_id": "__recent_added__"}
                filtered = [recent] + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            # Recent keeps the full filtered package list so RED/BLUE can
            # move to previous/next real packages.
            if self.kind in ("vod", "series") and self.initialCategoryId == "__recent_added__":
                pass
            self.categories = filtered
            if rows:
                self.catalogFirstOpenRetry = 0
            try:
                self["category"].setList(rows)
            except Exception:
                return
            if not rows:
                if self.catalogFirstOpenRetry < 1:
                    self.catalogFirstOpenRetry += 1
                    try:
                        self["desc"].setText(tr("Connecting to server..."))
                        self.catalogRetryTimer.start(700, True)
                    except Exception:
                        self._retryCatalogFirstOpen()
                    return
                if self.source.get("type") == "stalker" and origin == "empty":
                    self["desc"].setText(tr("Stalker returned no packages. Check Portal URL and MAG MAC, then retry."))
                else:
                    self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
                return
            had_initial_category = bool(self.initialCategoryId)
            if self.initialCategoryId:
                for pos, row in enumerate(rows):
                    if str(row[1]) == self.initialCategoryId:
                        try:
                            self["category"].moveToIndex(pos)
                        except Exception:
                            pass
                        break
                self.initialCategoryId = ""
            if self.kind == "series" and not had_initial_category:
                self.focus = "category"
                self["channelTitle"].setText(tr("Select a series category"))
                self["desc"].setText(tr("Select the category then press OK. Only this category will be loaded."))
            elif self.kind == "live":
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
                self._prewarmBeinSportsCache()
            else:
                self.loadSelectedCategory()
                self.focus = "items"
            return
        if mode == "m3u":
            self.mediaItems = items
            groups = sorted(set(entry.get("group", "Other") for entry in self.mediaItems))
            self.categories = [{"category_name": group, "category_id": group} for group in groups]
            rows = [(group, group) for group in groups]
            if self.kind == "live":
                rows = [(u"★  " + tr("FAVORITES"), "__favorites__"), (u"＋  " + tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [
                    {"category_name": name, "category_id": cid} for name, cid in rows
                ]
            elif self.kind in ("vod", "series"):
                rows = [(tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [{"category_name": name, "category_id": cid} for name, cid in rows]
            if self.kind in ("vod", "series") and self.initialCategoryId == "__recent_added__":
                pass
            self["category"].setList(rows)
            if self.kind == "live" and rows:
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
                self._prewarmBeinSportsCache()
            elif rows:
                self.loadSelectedCategory()
                self.focus = "items"
            else:
                self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
            return
        # Stalker has a single, already-built channel group.
        self.mediaItems = items
        self["category"].setList([("All Channels", "")])
        self.showItems(self.mediaItems)

    def _catchupVerifyCacheKey(self):
        try:
            return hashlib.sha1(_source_identity(self.source or {}).encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(_source_identity(self.source or {})).encode("utf-8")).hexdigest()

    def _loadCatchupVerifyCache(self):
        try:
            if not os.path.isfile(CATCHUP_VERIFY_CACHE_FILE):
                return {}
            with open_text(CATCHUP_VERIFY_CACHE_FILE, "r") as handle:
                payload = json.load(handle) or {}
            row = (payload.get("sources") or {}).get(self._catchupVerifyCacheKey(), {})
            saved = int(row.get("saved") or 0)
            if not saved or int(time.time()) - saved > 43200:
                return {}
            channels = row.get("channels") or {}
            return channels if isinstance(channels, dict) else {}
        except Exception:
            return {}

    def _saveCatchupVerifyCache(self, channels):
        try:
            ensure_dir(os.path.dirname(CATCHUP_VERIFY_CACHE_FILE))
            payload = {}
            if os.path.isfile(CATCHUP_VERIFY_CACHE_FILE):
                try:
                    with open_text(CATCHUP_VERIFY_CACHE_FILE, "r") as handle:
                        payload = json.load(handle) or {}
                except Exception:
                    payload = {}
            sources = payload.get("sources")
            if not isinstance(sources, dict):
                sources = {}
            sources[self._catchupVerifyCacheKey()] = {
                "saved": int(time.time()),
                "channels": channels or {}
            }
            payload["sources"] = sources
            with open_text(CATCHUP_VERIFY_CACHE_FILE, "w") as handle:
                json.dump(payload, handle)
        except Exception:
            pass

    def _verifyXtreamCatchupChannel(self, source, item):
        try:
            days = int(float(str(item.get("tv_archive_duration") or "0")))
        except Exception:
            days = 0
        if str(item.get("tv_archive") or "").strip() != "1" or days <= 0:
            return False

        sid = str(item.get("stream_id") or item.get("id") or "")
        epgid = str(item.get("epg_channel_id") or item.get("epg_id") or "")
        try:
            events = XtreamClient(source).catchup_epg(sid, epg_channel_id=epgid) or []
        except Exception:
            return False

        now = int(time.time())
        cutoff = now - days * 86400
        usable = []
        for event in events:
            if not isinstance(event, dict):
                continue
            begin = self._epgTimestamp(event, True)
            end = self._epgTimestamp(event, False)
            if begin and end and end <= now and begin >= cutoff and end > begin:
                usable.append((begin, event))
        usable.sort(key=lambda x: x[0], reverse=True)

        # Use the same dual-endpoint logic already proven by the player.
        base = str(source.get("url") or "").rstrip("/")
        user = str(source.get("username") or "")
        password = str(source.get("password") or "")
        output = str(source.get("output") or source.get("stream_format") or source.get("format") or "ts").strip().lstrip(".") or "ts"
        stream_name = "%s.%s" % (sid, output)

        for begin, event in usable[:3]:
            finish = self._epgTimestamp(event, False)
            duration = max(1, int((finish - begin + 59) / 60))
            raw_start = event.get("start") or event.get("begin") or ""
            start_dt = self._parseXtreamCatchupDate(raw_start)
            if start_dt:
                primary = start_dt.strftime("%Y-%m-%d:%H-%M")
            else:
                primary = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))

            starts = []
            for value in (
                primary,
                time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin)),
                time.strftime("%Y-%m-%d:%H-%M", time.gmtime(begin))
            ):
                if value and value not in starts:
                    starts.append(value)

            for start_text in starts:
                urls = [
                    "%s/timeshift/%s/%s/%d/%s/%s" % (base, user, password, duration, start_text, stream_name),
                    ("%s/streaming/timeshift.php?username=%s&password=%s&stream=%s&start=%s&duration=%d" %
                     (base, user, password, sid, start_text.replace(":", "%3A"), duration))
                ]
                for url in urls:
                    try:
                        req = Request(url)
                        try:
                            req.add_header("Range", "bytes=0-1023")
                        except Exception:
                            pass
                        resp = urlopen(req, timeout=4)
                        try:
                            code = int(getattr(resp, "getcode", lambda: 200)() or 200)
                        except Exception:
                            code = 200
                        try:
                            chunk = resp.read(1024)
                        finally:
                            try:
                                resp.close()
                            except Exception:
                                pass
                        if code in (200, 206) and chunk:
                            return True
                    except Exception:
                        pass
        return False

    def _loadCatchupPackage(self):
        """Show only channels whose Catch-up was confirmed playable."""
        if self.kind != "live" or self.source.get("type") not in ("xtream", "stalker"):
            return

        self.catchupPackageActive = True
        self.catchupPackageToken += 1
        token = self.catchupPackageToken
        source = dict(self.source or {})
        source_type = source.get("type")

        self["channelTitle"].setText(tr("Catch-up / Archive"))
        self["desc"].setText(tr("Checking playable catch-up channels..."))
        try:
            self["list"].setList([])
        except Exception:
            pass
        self.catchupPackageResult = None

        def advertises_archive(row):
            row = row or {}
            if source_type == "xtream":
                try:
                    days = int(float(str(row.get("tv_archive_duration") or "0")))
                except Exception:
                    days = 0
                return str(row.get("tv_archive") or "").strip() == "1" and days > 0
            archive = row.get("tv_archive") or row.get("archive") or row.get("has_archive")
            duration = row.get("tv_archive_duration") or row.get("archive_duration") or 0
            if str(archive or "").strip().lower() in ("1", "true", "yes", "on"):
                return True
            try:
                return int(float(str(duration or "0"))) > 0
            except Exception:
                return False

        def worker():
            rows = []
            error = ""
            try:
                client = get_source_client(source)
                all_rows = list(get_filtered_streams(source, "live", client) or [])
                candidates = [dict(x or {}) for x in all_rows if advertises_archive(x)]

                # Open Catch-up immediately from channels that advertise archive support.
                # Actual programme availability/playback is checked only after the user selects a channel.
                rows = candidates
            except Exception as exc:
                error = str(exc)

            self.catchupPackageResult = (token, rows, error)

        t = threading.Thread(target=worker, name="TiviMateCatchupPackage")
        t.daemon = True
        t.start()

        try:
            self.catchupPackageTimer.stop()
        except Exception:
            pass
        try:
            self.catchupPackageTimer.start(120, True)
        except Exception:
            pass


    def _finishCatchupPackageLoad(self):
        result = self.catchupPackageResult
        if result is None:
            try:
                self.catchupPackageTimer.start(120, True)
            except Exception:
                pass
            return

        self.catchupPackageResult = None
        try:
            self.catchupPackageTimer.stop()
        except Exception:
            pass

        try:
            token, items, error = result
        except Exception:
            return

        if token != self.catchupPackageToken or not self.catchupPackageActive:
            return

        self.mediaItems = list(items or [])
        self.mediaItemsCurrent = list(items or [])
        self.showItems(self.mediaItemsCurrent)
        self.focus = "items"
        self["channelTitle"].setText(tr("Catch-up / Archive"))

        if self.mediaItemsCurrent:
            try:
                self["desc"].setText("%d %s" % (
                    len(self.mediaItemsCurrent), tr("catch-up channels")
                ))
            except Exception:
                pass
        else:
            message = tr("No catch-up channels are available on this server.")
            if error:
                message += "\n" + error
            try:
                self["desc"].setText(message)
            except Exception:
                pass


    def selectedCategory(self):
        # LIVE categories are always selected from the left category widget.
        c = self["category"].getCurrent()
        return c[1] if c else ""


    def _stalkerLivePlaceholder(self, index):
        return {
            "name": "",
            "title": "",
            "number": str(index + 1),
            "stream_id": "",
            "id": "",
            "ch_id": "",
            "stream_icon": "",
            "logo": "",
            "cmd": "",
            "category_id": str(self.stalkerLiveCategoryId or ""),
            "_stalker_live": True,
            "_stalker_placeholder": True,
        }

    def _renderStalkerLiveSlots(self, keep_index=None):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        rows = []
        for index, entry in enumerate(self.stalkerLiveSlots or []):
            entry = entry or self._stalkerLivePlaceholder(index)
            if entry.get("_stalker_placeholder"):
                rows.append((" ", entry))
            else:
                number = entry.get("number") or str(index + 1)
                name = entry.get("name") or entry.get("title") or "CHANNEL"
                rows.append(("%s   %s" % (number, name), entry))
        self.mediaItemsCurrent = list(self.stalkerLiveSlots or [])
        self["list"].setList(rows)
        if keep_index is None:
            keep_index = 0
        try:
            self["list"].moveToIndex(max(0, min(int(keep_index), max(0, len(rows)-1))))
        except Exception:
            pass
        self.focus = "items"
        try:
            self["pageInfo"].setText("%d / %d" % (
                (int(keep_index) + 1) if rows else 0,
                int(self.stalkerLiveTotal or len(rows))
            ))
        except Exception:
            pass

    def _cancelStalkerCatalogueRequests(self):
        event = getattr(self, "stalkerLiveCancelEvent", None)
        if event is not None:
            try: event.set()
            except Exception: pass
        try: self.stalkerLivePageGeneration += 1
        except Exception: pass
        try: self.stalkerLivePageTimer.stop()
        except Exception: pass
        try: self.stalkerLivePendingPages.clear()
        except Exception: pass
        self.stalkerLivePageResult = None

    def _beginStalkerLiveCategory(self, category_id, name):
        old_event = getattr(self, "stalkerLiveCancelEvent", None)
        if old_event is not None:
            try: old_event.set()
            except Exception: pass
        self.stalkerLiveCancelEvent = threading.Event()
        self.stalkerLivePageGeneration += 1
        generation = self.stalkerLivePageGeneration
        self.stalkerLiveCategoryId = str(category_id or "")
        self.stalkerLiveTotal = 0
        self.stalkerLiveSlots = []
        self.stalkerLiveLoadedPages = set()
        self.stalkerLivePendingPages = set()
        self.stalkerLivePageResult = None
        self._resetStalkerVisibleEpg()

        try:
            self["list"].setList([])
            self["channelTitle"].setText(name or tr("Select a channel"))
            self["desc"].setText(tr(""))
        except Exception:
            pass

        # Fast path: if page 1 is already cached, render it synchronously.
        # This avoids clearing the bouquet and then waiting for a worker + timer
        # even when no network request is needed.
        try:
            client = get_source_client(dict(self.source))
            cached_payload = client.live_page_cached(self.stalkerLiveCategoryId, 1, sortby="number")
        except Exception:
            cached_payload = None
        if isinstance(cached_payload, dict) and isinstance(cached_payload.get("items"), list):
            self.stalkerLivePageResult = (generation, 1, cached_payload, "")
            self._finishStalkerLivePage()
            return

        self._requestStalkerLivePage(1, generation)

    def _requestStalkerLivePage(self, page, generation=None):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        try:
            page = max(1, int(page or 1))
        except Exception:
            page = 1
        if generation is None:
            generation = self.stalkerLivePageGeneration
        if generation != self.stalkerLivePageGeneration:
            return
        if page in self.stalkerLiveLoadedPages or page in self.stalkerLivePendingPages:
            return

        self.stalkerLivePendingPages.add(page)
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        cancel_event = getattr(self, "stalkerLiveCancelEvent", None)

        def worker():
            payload = None
            error = ""
            try:
                if cancel_event is not None and cancel_event.is_set():
                    return
                client = get_source_client(source)
                payload = client.live_page(category_id, page, sortby="number", cancel_event=cancel_event)
                if cancel_event is not None and cancel_event.is_set():
                    return
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            if generation != self.stalkerLivePageGeneration:
                return
            self.stalkerLivePageResult = (generation, page, payload or {}, error)

        threading.Thread(
            target=worker,
            name="TiviMateEStalkerPage%d" % page,
            daemon=True
        ).start()
        try:
            self.stalkerLivePageTimer.start(60, False)
        except Exception:
            pass

    def _finishStalkerLivePage(self):
        result = self.stalkerLivePageResult
        if not result:
            if self.stalkerLivePendingPages:
                try:
                    self.stalkerLivePageTimer.start(60, False)
                except Exception:
                    pass
            return

        self.stalkerLivePageResult = None
        generation, page, payload, error = result
        self.stalkerLivePendingPages.discard(page)
        if generation != self.stalkerLivePageGeneration:
            return

        if error:
            try:
                self["desc"].setText(tr("Unable to load package:\n%s") % error)
            except Exception:
                pass
            return

        items = list((payload or {}).get("items") or [])
        total = int((payload or {}).get("total_items") or 0)
        has_more = bool((payload or {}).get("has_more"))

        if total <= 0:
            total = max(len(self.stalkerLiveSlots), (page - 1) * 14 + len(items))
            if has_more:
                total = max(total, page * 14 + 14)

        if total > len(self.stalkerLiveSlots):
            self.stalkerLiveSlots.extend(
                self._stalkerLivePlaceholder(i)
                for i in range(len(self.stalkerLiveSlots), total)
            )

        start = (page - 1) * 14
        needed = start + len(items)
        if needed > len(self.stalkerLiveSlots):
            self.stalkerLiveSlots.extend(
                self._stalkerLivePlaceholder(i)
                for i in range(len(self.stalkerLiveSlots), needed)
            )

        for offset, item in enumerate(items):
            pos = start + offset
            if pos < len(self.stalkerLiveSlots):
                self.stalkerLiveSlots[pos] = dict(item or {})

        self.stalkerLiveTotal = max(total, needed)
        self.stalkerLiveLoadedPages.add(page)

        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0

        self._renderStalkerLiveSlots(current_index)
        self.previewLive()

    def _ensureStalkerLiveCurrentPage(self):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        try:
            index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            index = 0
        page = (index // 14) + 1
        if page not in self.stalkerLiveLoadedPages:
            self._requestStalkerLivePage(page)

    def _runStalkerSelectionEpg(self):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        self._prefetchStalkerVisibleEpg()

    def _providerCategoryScore(self, name, provider):
        text=str(name or "").strip().lower()
        compact=re.sub(r"[^a-z0-9]+"," ",text).strip()
        tokens=[x for x in compact.split() if x]
        resolved=package_provider_key(name)
        if provider=="netflix":
            if "netflix" in compact:
                return 500
            if resolved=="netflix":
                return 450
            if "nf" in tokens:
                return 420
            if compact.startswith("nf ") or compact.endswith(" nf"):
                return 400
        elif provider=="prime":
            if "prime video" in compact:
                return 500
            if "amazon prime" in compact:
                return 480
            if resolved=="prime":
                return 450
            if "prime" in tokens:
                return 420
        return -1

    def _tmdbSortServerPackageItems(self, items, package_name, category_id=""):
        forced_provider=""
        try:
            forced_cid=str((self.source or {}).get("_package_provider_category_id") or "")
            if forced_cid and forced_cid==str(category_id or ""):
                forced_provider=str((self.source or {}).get("_package_provider_override") or "").strip().lower()
        except Exception:
            forced_provider=""
        provider=forced_provider or package_provider_key(package_name)
        if provider not in ("netflix","prime"):
            name=str(package_name or "").lower()
            if "netflix" in name or re.search(r"(^|[^a-z0-9])nf([^a-z0-9]|$)",name):
                provider="netflix"
            elif "prime" in name or "amazon" in name:
                provider="prime"
        if provider not in ("netflix","prime"):
            return list(items or [])

        rows=list(items or [])
        if not rows:
            return rows

        try:
            ranked=TMDbClient().provider_catalog(self.kind,provider,limit=200) or []
        except Exception:
            return rows

        def _norm_title(value):
            value=str(value or "").lower()
            value=value.replace("&"," and ")
            # Remove provider/source prefixes and common IPTV decorations.
            value=re.sub(r"\b(?:netflix|nf|prime video|amazon prime|prime)\b"," ",value)
            value=re.sub(r"\b(?:4k|uhd|fhd|hd|sd|hdr|dolby|atmos|hevc|x265|x264)\b"," ",value)
            value=re.sub(r"\b(?:multi|dual|audio|arabic|english|eng|ar|sub|subs|dub|dubbed)\b"," ",value)
            value=re.sub(r"\b(?:19|20)\d{2}\b"," ",value)
            value=re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}"," ",value)
            value=re.sub(r"[^a-z0-9]+"," ",value)
            return " ".join(value.split())

        rank_by_id={}
        rank_by_title={}
        ranked_titles=[]
        for pos,row in enumerate(ranked):
            tid=str(row.get("tmdb_id") or row.get("tmdb") or row.get("id") or "").strip()
            if tid and tid not in rank_by_id:
                rank_by_id[tid]=pos
            title=row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or ""
            key=_norm_title(title)
            if key and key not in rank_by_title:
                rank_by_title[key]=pos
                ranked_titles.append((key,pos))

        matched=[]
        unmatched=[]
        for original_pos,item in enumerate(rows):
            item=item or {}
            _info=item.get("info") if isinstance(item.get("info"),dict) else {}
            tid=str(
                item.get("tmdb_id") or item.get("tmdb") or item.get("tmdbid") or
                _info.get("tmdb_id") or _info.get("tmdb") or _info.get("tmdbid") or ""
            ).strip()
            score=None
            if tid and tid in rank_by_id:
                score=rank_by_id[tid]
            else:
                title=item.get("name") or item.get("title") or item.get("original_name") or ""
                key=_norm_title(title)
                if key in rank_by_title:
                    score=rank_by_title[key]
                elif key:
                    # Conservative containment fallback for decorated server titles.
                    candidates=[]
                    for rk,rpos in ranked_titles:
                        if len(key)>=6 and len(rk)>=6 and (key in rk or rk in key):
                            candidates.append((abs(len(key)-len(rk)),rpos))
                    if candidates:
                        candidates.sort()
                        score=candidates[0][1]
            if score is None:
                unmatched.append((original_pos,item))
            else:
                matched.append((score,original_pos,item))

        matched.sort(key=lambda x:(x[0],x[1]))
        ordered=[x[2] for x in matched] + [x[1] for x in unmatched]
        # Provider package contract: Netflix / Prime never expose more than
        # 200 items in this curated view, even if the server category has
        # hundreds or thousands of entries.
        return ordered[:200]

    def _loadMergedServerProvider(self, provider):
        provider=str(provider or "").strip().lower()
        label="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
        self.categoryLoadToken += 1
        token=self.categoryLoadToken
        self.categoryLoadResult=None
        source=dict(self.source or {})
        kind=self.kind

        try:self["desc"].setText("Loading %s packages from server..." % label)
        except Exception:pass

        def worker():
            try:
                cats,origin=get_cached_categories(
                    source,kind,get_source_client(source),wait_for_server=True
                )
                cats=filter_categories(source,kind,cats or [])
                matches=[]
                for cat in cats:
                    cname=str(cat.get("category_name") or "")
                    cid=str(cat.get("category_id") or "")
                    score=self._providerCategoryScore(cname,provider)
                    if score>=0 and cid:
                        matches.append((score,cid,cname))
                matches.sort(key=lambda x:x[0],reverse=True)

                merged=[]
                seen=set()
                used_names=[]
                # Merge all matching Netflix/Prime server packages, capped at 200.
                for score,cid,cname in matches:
                    try:
                        package_items,_origin=get_category_streams(
                            source,kind,get_source_client(source),cid,
                            use_cache=True,wait_for_server=(kind!="series")
                        )
                    except Exception:
                        package_items=[]
                    if package_items:
                        used_names.append(cname)
                    for item in list(package_items or []):
                        key=str(
                            (item or {}).get("stream_id") or
                            (item or {}).get("series_id") or
                            (item or {}).get("id") or
                            (item or {}).get("tmdb_id") or
                            ((item or {}).get("name") or (item or {}).get("title") or "")
                        )
                        if key and key in seen:
                            continue
                        if key:
                            seen.add(key)
                        merged.append(item)
                        if len(merged)>=200:
                            break
                    if len(merged)>=200:
                        break

                if merged:
                    merged=self._tmdbSortServerPackageItems(merged,label)
                    result=(token,merged,"server_tmdb_sorted","",label)
                elif matches:
                    result=(token,[],"server_empty","",label)
                else:
                    result=(token,[],"provider_not_found","",label)
            except Exception as exc:
                result=(token,[],"error",str(exc),label)
            self.categoryLoadResult=result

        threading.Thread(target=worker,name="TiviMateProviderMerge",daemon=True).start()
        try:self.categoryLoadTimer.start(120,False)
        except Exception:pass


    def loadSelectedCategory(self):
        cid=self.selectedCategory()
        if cid=="__server_netflix__":
            self._loadMergedServerProvider("netflix")
            return
        if cid=="__server_prime__":
            self._loadMergedServerProvider("prime")
            return
        c = self["category"].getCurrent()
        name = c[0] if c else (self.activeCategoryName or self.initialCategoryName or "")
        if name:
            self.activeCategoryName = name
        if self.kind == "live" and cid == "__favorites__":
            source_key = favourite_source_id(self.source)
            items = []
            for record in list_favourites("live"):
                if record.get("source_id") != source_key:
                    continue
                item = dict(record.get("item") or {})
                if item:
                    items.append(item)
            self._applyCategoryItems(items, tr("FAVORITES"), "local")
            if not items:
                self["desc"].setText(tr("No favorite channels yet. Add channels with the red button."))
            return
        if self.kind == "live" and cid in ("__bein_sports__", "__bein_virtual__"):
            self._loadBeinSports()
            return
        if self.kind == "live" and cid == "__recent_added__":
            self.catchupPackageActive = False
            self._loadRecentlyAdded()
            return
        if self.kind in ("vod", "series") and cid == "__recent_added__":
            self._loadRecentlyAddedMedia()
            return
        if self.kind == "live" and cid == "__catchup__":
            if bool((self.source or {}).get("catchup_enabled", False)):
                self._loadCatchupPackage()
            return
        self.catchupPackageActive = False

        # EStalker 1.45: Stalker Live never downloads the whole package here.
        # Open page 1 (14 rows) and fetch later pages only when selection enters them.
        if self.kind == "live" and self.source.get("type") == "stalker":
            if not cid:
                return
            self._beginStalkerLiveCategory(cid, name)
            return

        if not cid and self.source.get("type") in ("xtream", "stalker"):
            return
        self["desc"].setText(("Loading %s..." % name) if self.kind == "live" else ("جاري تحميل %s..." % name))
        if self.source.get("type") in ("xtream", "stalker") and self.kind in ("live", "vod", "series"):
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            source = dict(self.source)
            kind = self.kind
            def worker():
                try:
                    items, origin = get_category_streams(source, kind, get_source_client(source), cid, use_cache=True, wait_for_server=(kind != "series"))
                    items = self._tmdbSortServerPackageItems(items or [], name, cid)
                    result = (token, items or [], origin, "", name)
                except Exception as exc:
                    result = (token, [], "error", str(exc), name)
                self.categoryLoadResult = result
            threading.Thread(target=worker, name="TiviMateE2Category", daemon=True).start()
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"): items=get_source_client(self.source).streams(self.kind,cid)
            elif self.source.get("type")=="m3u": items=[x for x in self.mediaItems if x.get("group")==cid]
            else: items=self.mediaItems
            self._applyCategoryItems(items or [], name, "server")
        except Exception as e:
            self.mediaItemsCurrent=[]
            if self.kind=="live": self["list"].setList([])
            self["desc"].setText(("Unable to load package:\n%s" % e) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % e))

    def _prewarmBeinSportsCache(self):
        """Build/refresh the beIN view quietly while the normal Live UI is open."""
        if self.kind != "live" or self.source.get("_virtual_bein"):
            return
        source = _bein_base_source(self.source)
        source_type = source.get("type")
        if source_type == "m3u":
            try:
                items = [item for item in (self.mediaItems or []) if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
            except Exception:
                pass
            return
        if source_type not in ("xtream", "stalker"):
            return
        cached, fresh, stamp = _load_bein_cache(source)
        if fresh:
            return
        def worker():
            try:
                client = get_source_client(source)
                all_items = client.streams("live", "") or []
                items = [item for item in all_items if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateE2BeinPrewarm", daemon=True).start()

    def _loadBeinSports(self):
        """Open beIN SPORTS from a fast per-server cache, refreshing in background."""
        source = _bein_base_source(self.source)
        source_type = source.get("type")
        cached, fresh, stamp = _load_bein_cache(source)
        if cached:
            self._applyCategoryItems(cached, "beIN SPORTS", "cache")
            if not fresh:
                self["desc"].setText("beIN SPORTS • cached • refreshing in background")
                self._prewarmBeinSportsCache()
            return
        self["desc"].setText("Loading beIN SPORTS for the first time...")
        if source_type == "m3u":
            items = [item for item in (self.mediaItems or []) if _is_bein_sports_channel(item)]
            _save_bein_cache(source, items)
            self._applyCategoryItems(items, "beIN SPORTS", "local")
            if not items:
                self["desc"].setText("No beIN SPORTS channels found in this source.")
            return
        if source_type not in ("xtream", "stalker"):
            self._applyCategoryItems([], "beIN SPORTS", "local")
            self["desc"].setText("beIN SPORTS is available for Xtream, Stalker and M3U sources.")
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        def worker():
            try:
                client = get_source_client(source)
                items = client.streams("live", "") or []
                items = [item for item in items if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
                result = (token, items, "server", "", "beIN SPORTS")
            except Exception as exc:
                result = (token, [], "error", str(exc), "beIN SPORTS")
            self.categoryLoadResult = result
        threading.Thread(target=worker, name="TiviMateE2BeinSports", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, False)
        except Exception:
            pass

    def _recentAddedTimestamp(self, item):
        keys = ("last_modified", "added", "added_at", "created_at", "date_added", "timestamp") if self.kind == "series" else ("added", "added_at", "created_at", "date_added", "timestamp")
        for key in keys:
            value = item.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                pass
            try:
                import datetime
                value = str(value).replace("Z", "").split(".")[0]
                return int(time.mktime(datetime.datetime.strptime(value[:19], "%Y-%m-%d %H:%M:%S").timetuple()))
            except Exception:
                pass
        return 0

    def _recentStateKey(self, source):
        raw = "%s|%s|%s|%s" % (
            source.get("type", ""), source.get("url", "").rstrip("/"),
            source.get("username", ""), source.get("mac", ""))
        try:
            raw = raw.encode("utf-8")
        except Exception:
            pass
        return hashlib.sha1(raw).hexdigest()

    def _recentIdentity(self, item, order=0):
        return str(item.get("stream_id") or item.get("id") or item.get("url") or
                   item.get("cmd") or item.get("name") or order)

    def _loadRecentlyAdded(self):
        """Load genuinely recent Live channels for the active server.

        Xtream is fetched in one complete request so category cache gaps cannot
        corrupt the result. Provider ``added`` timestamps are preferred when
        present; snapshot comparison is the fallback for Stalker/M3U providers.
        """
        self["desc"].setText(tr("Loading recently added channels..."))
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        source = dict(self.source)
        current_items = list(self.mediaItems or [])

        def worker():
            try:
                client = get_source_client(source)
                stype = source.get("type")
                if stype in ("m3u", "fg"):
                    merged = current_items
                elif stype == "xtream":
                    merged = client.streams("live", "") or []
                elif stype == "stalker":
                    try:
                        merged = client.streams("live", "") or []
                    except Exception:
                        merged = client.live_streams("") or []
                else:
                    merged = current_items

                dedup = {}
                ordered_ids = []
                for order, item in enumerate(merged or []):
                    if not isinstance(item, dict):
                        continue
                    key = self._recentIdentity(item, order)
                    if key in dedup:
                        continue
                    dedup[key] = dict(item)
                    ordered_ids.append(key)

                state_path = os.path.join(BASE, "recent_live_state.json")
                all_state = load_json(state_path, {}) or {}
                state_key = self._recentStateKey(source)
                previous = all_state.get(state_key) or {}
                # Schema 2 invalidates snapshots produced by the old category-by-
                # category implementation, which could silently miss channels.
                if int(previous.get("schema", 0) or 0) != 2:
                    previous = {}
                known = set(str(value) for value in (previous.get("known") or []))
                existing_recent = previous.get("recent") or {}
                now = int(time.time())
                max_age = 30 * 24 * 60 * 60
                cutoff = now - max_age

                recent = {}
                # Provider timestamps are the most faithful source for Xtream.
                timestamped = 0
                for key in ordered_ids:
                    stamp = self._recentAddedTimestamp(dedup[key])
                    if stamp > 0:
                        timestamped += 1
                        if stamp >= cutoff and stamp <= now + 86400:
                            recent[key] = stamp

                # Preserve still-valid snapshot additions and detect new IDs on
                # providers that do not publish reliable timestamps.
                for key, seen_at in existing_recent.items():
                    try:
                        seen_at = int(seen_at)
                    except Exception:
                        continue
                    if key in dedup and now - seen_at <= max_age:
                        recent.setdefault(key, seen_at)
                if known:
                    for key in ordered_ids:
                        if key not in known and key not in recent:
                            recent[key] = now

                all_state[state_key] = {
                    "schema": 2,
                    "known": ordered_ids,
                    "recent": recent,
                    "updated": now,
                    "timestamped": timestamped,
                }
                save_json(state_path, all_state)

                recent_ids = [key for key in ordered_ids if key in recent]
                order_map = dict((key, pos) for pos, key in enumerate(ordered_ids))
                recent_ids.sort(key=lambda key: (recent.get(key, 0), order_map.get(key, 0)), reverse=True)
                items = [dedup[key] for key in recent_ids[:50]]
                result = (token, items, "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                result = (token, [], "error", str(exc), tr("RECENTLY ADDED"))
            self.categoryLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2RecentAdded", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, False)
        except Exception:
            pass

    def _loadRecentlyAddedMedia(self):
        """Load recent Movies / Series from ENABLED/FILTERED packages only.

        Fast path: use a per-server, per-kind cache.
        Cold path: scan only categories allowed by the user's server-content filter.
        """
        cached = _load_recent_media_cache(self.source, self.kind)
        if cached:
            self._applyCategoryItems(cached, tr("RECENTLY ADDED"), "cache")
            try:
                self["desc"].setText(tr("RECENTLY ADDED") + " • cache")
            except Exception:
                pass
            return

        self["desc"].setText(tr("Loading recently added from enabled packages..."))
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        source = dict(self.source)
        kind = self.kind
        current_items = list(self.mediaItems or [])

        def worker():
            try:
                stype = source.get("type")
                allowed_ids = get_allowed_category_ids(source, kind)

                # Build only the enabled category list.
                categories = []
                if stype in ("xtream", "stalker"):
                    client = get_source_client(source)
                    cats, _origin = get_cached_categories(source, kind, client, wait_for_server=True)
                    cats = filter_categories(source, kind, cats or [])
                    categories = [
                        c for c in cats
                        if str(c.get("category_id") or "")
                        and (allowed_ids is None or str(c.get("category_id") or "") in allowed_ids)
                    ]

                    merged = []
                    for category in categories:
                        cid = str(category.get("category_id") or "")
                        if not cid:
                            continue
                        try:
                            rows, _ = get_category_streams(
                                source, kind, client, cid,
                                use_cache=True,
                                wait_for_server=(kind != "series")
                            )
                            merged.extend(rows or [])
                        except Exception:
                            pass
                elif stype == "m3u":
                    merged = current_items
                    if allowed_ids is not None:
                        merged = [
                            row for row in merged
                            if str(row.get("group") or row.get("category_id") or "") in allowed_ids
                        ]
                else:
                    merged = current_items

                # De-duplicate, then sort by real provider added/modified timestamps.
                dedup = {}
                for order, item in enumerate(merged or []):
                    if not isinstance(item, dict):
                        continue
                    key = str(
                        item.get("stream_id")
                        or item.get("series_id")
                        or item.get("vod_id")
                        or item.get("id")
                        or ""
                    )
                    if not key:
                        key = "%s:%s:%s" % (
                            item.get("name") or item.get("title") or "",
                            item.get("category_id") or item.get("group") or "",
                            order
                        )
                    if key not in dedup:
                        dedup[key] = dict(item)

                items = list(dedup.values())
                items.sort(key=lambda row: self._recentAddedTimestamp(row), reverse=True)

                # Keep timestamped recent content only.
                items = [row for row in items if self._recentAddedTimestamp(row) > 0][:100]
                _save_recent_media_cache(source, kind, items)

                result = (token, items, "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                result = (token, [], "error", str(exc), tr("RECENTLY ADDED"))
            self.categoryLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2RecentMediaFiltered", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, False)
        except Exception:
            pass


    def _finishCategoryLoad(self):
        result = self.categoryLoadResult
        if not result:
            try: self.categoryLoadTimer.start(120, False)
            except Exception: pass
            return
        self.categoryLoadResult = None
        token, items, origin, error, name = result
        if token != self.categoryLoadToken:
            return
        if origin == "categories_loading":
            rows, cat_origin = get_cached_categories(self.source, "series")
            if not rows:
                self.categoryLoadResult = (token, [], "categories_loading", "", "")
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            self.categories = rows
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all series", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            menu=[]; filtered=[]
            for x in rows:
                cname=(x.get("category_name") or "Other").strip(); ccid=str(x.get("category_id", ""))
                if allowed_ids is not None and ccid not in allowed_ids: continue
                if self.kind == "live" and not _adult_source_enabled(self.source) and _adult_live_name(cname): continue
                if cname.lower() in blocked: continue
                filtered.append(x); menu.append((cname, ccid))
            if self.kind == "live" and self.source.get("type") == "stalker":
                hidden_state = _load_stalker_hidden(self.source)
                filtered = [x for x in filtered if str(x.get("category_id", "")) not in hidden_state["categories"]]
                menu = [(x.get("category_name") or "Other", str(x.get("category_id", ""))) for x in filtered]
            self.categories=filtered; self["category"].setList(menu)
            self["desc"].setText(tr("Select a series category then press OK.")) if menu else self["desc"].setText(tr("No categories available."))
            return
        if origin == "stalker_search_all":
            self.showItems(items or [])
            try:
                self["meta"].setText("Search All • %d" % len(items or []))
            except Exception:
                pass
            return
        if origin=="provider_not_found":
            self.mediaItemsCurrent=[]
            try:
                self["desc"].setText("%s package was not found on this server." % name)
                self["currentCategory"].setText(name)
            except Exception:pass
            return
        if origin=="server_empty":
            self.mediaItemsCurrent=[]
            try:
                self["desc"].setText("%s packages were found, but they returned no content." % name)
                self["currentCategory"].setText(name)
            except Exception:pass
            return
        if error:
            self.mediaItemsCurrent=[]
            self["desc"].setText(("Unable to load package:\n%s" % error) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % error))
            return
        if self.source.get("type") == "stalker" and origin == "empty":
            self.mediaItemsCurrent=[]
            if self.kind == "live":
                self["list"].setList([])
            self["desc"].setText(tr("Stalker returned no items for this package. Try another package or refresh the source."))
            return
        if origin == "loading" and self.kind == "series":
            cid = self.selectedCategory()
            cached, new_origin = get_category_streams(self.source, "series", get_source_client(self.source), cid, use_cache=True, wait_for_server=False)
            if not cached and new_origin == "loading":
                self["desc"].setText(tr("The category is preparing in the background... the interface will not freeze."))
                self.categoryLoadResult = (token, [], "loading", "", name)
                try: self.categoryLoadTimer.start(500, False)
                except Exception: pass
                return
            items, origin = cached, new_origin
        self._applyCategoryItems(items, name, origin)








    def _applyCategoryItems(self, items, name, origin="server"):
        self.activeCategoryName = name or self.initialCategoryName or ""
        self.activePackageProvider = self._providerFromPackageName(self.activeCategoryName)
        self._updateServerPackageGridLogo()
        items = self._tagPackageProvider(items, self.activeCategoryName)
        self.lastCategoryItems = items or []
        if self.kind != "live":
            try:
                suffix = {"ram":" • ذاكرة", "disk":" • HDD", "stale":" • HDD • تحديث بالخلفية", "server":""}.get(origin, "")
                self["currentCategory"].setText(name + suffix)
            except Exception:
                pass
        if self.searchQuery:
            self.applySearch(self.searchQuery)
        else:
            self.showItems(self.lastCategoryItems)


    def _providerFromPackageName(self, name):
        return package_provider_key(name)

    def _updateServerPackageGridLogo(self):
        if self.kind == "live":
            return
        mapping = {
            "netflix": "contentProviderNetflix",
            "prime": "contentProviderPrime",
            "disney": "contentProviderDisney",
            "max": "contentProviderMax",
            "apple": "contentProviderApple",
            "paramount": "contentProviderParamount",
        }
        provider = str(getattr(self, "activePackageProvider", "") or "").strip().lower()
        if not provider:
            try:
                package_name = str(getattr(self, "activeCategoryName", "") or
                                   getattr(self, "initialCategoryName", "") or "")
                provider = self._providerFromPackageName(package_name)
            except Exception:
                provider = ""
        active = mapping.get(provider, "")
        for widget_name in mapping.values():
            try:
                if widget_name == active:
                    self[widget_name].show()
                else:
                    self[widget_name].hide()
            except Exception:
                pass


    def _tagPackageProvider(self, items, package_name):
        if self.kind == "live":
            return list(items or [])
        provider = str(getattr(self, "activePackageProvider", "") or "").strip().lower()
        if not provider:
            provider = self._providerFromPackageName(package_name)

        tagged = []
        for item in list(items or []):
            if not isinstance(item, dict):
                tagged.append(item)
                continue
            row = dict(item)
            if provider:
                row["_tmdb_provider"] = provider
                row["_server_package_provider"] = provider
                row["_server_package_name"] = str(package_name or "")
            # Explicit source context: detail recommendations/backdrops must not
            # infer their origin from whatever page happens to be visible later.
            try:
                _cid=str(self.selectedCategory() or row.get("category_id") or "").strip()
            except Exception:
                _cid=str(row.get("category_id") or "").strip()
            if _cid:
                row["_source_category_id"]=_cid
            row["_source_scope"]="movies_package" if self.kind=="vod" else "series_package"
            row["_source_server_id"]=_source_identity(self.source)
            tagged.append(row)
        return tagged


    def showItems(self, items):
        if self.kind == "live" and self.source.get("type") in ("stalker", "xtream"):
            hidden_state = _load_stalker_hidden(self.source) if self.source.get("type") == "stalker" else _load_xtream_hidden(self.source)
            items = [x for x in (items or []) if _live_item_id(x) not in hidden_state["channels"]]
        self.mediaItemsCurrent = items or []
        self.pageStart = 0
        self.posterIndex = 0
        if self.kind == "live":
            self._resetStalkerVisibleEpg()
            rows = []
            for index, entry in enumerate(self.mediaItemsCurrent):
                name = entry.get("name") or entry.get("title") or "Unnamed Channel"
                rows.append(("%03d   %s" % (index + 1, name), entry))
            self["list"].setList(rows)
            try:
                self["list"].moveToIndex(0)
            except Exception:
                pass
            self.focus = "items"
            try:
                current = next((entry for entry in self.categories if str(entry.get("category_id", "")) == str(self.selectedCategory())), None)
                if current:
                    self["categoryTitle"].setText(current.get("category_name") or "القنوات")
                self["pageInfo"].setText("1 / %d" % len(self.mediaItemsCurrent) if self.mediaItemsCurrent else "0 / 0")
            except Exception:
                pass
            self.previewLive()
        else:
            self.renderPosterPage()


    def current(self):
        if self.kind=="live":
            if self.focus != "items": return None
            c=self["list"].getCurrent(); return c[1] if c else None
        idx=self.pageStart+self.posterIndex
        return self.mediaItemsCurrent[idx] if 0 <= idx < len(self.mediaItemsCurrent) else None

    def previewLive(self):
        item = self.current()
        if not item:
            return

        # EStalker progressive page load.
        if self.source.get("type") == "stalker":
            self._ensureStalkerLiveCurrentPage()
            if item.get("_stalker_placeholder"):
                try:
                    self["channelTitle"].setText(tr("Loading..."))
                    self["meta"].setText(tr(""))
                    self["desc"].setText(tr(""))
                    self["channelPicon"].hide()
                except Exception:
                    pass
                return

        self["channelTitle"].setText(item.get("name") or item.get("title") or "Unnamed Channel")
        self["meta"].setText(tr(""))

        # EStalker: clear old Picon then debounce current one for 250 ms.
        self._showLivePicon(item)

        if self.source.get("type") == "stalker":
            # Display already-cached short EPG immediately if available.
            self._updateLiveEpg(item)

            # Then exactly like EStalker selectionChanged: 260 ms debounce for
            # the visible 14-channel page.
            try:
                self.stalkerSelectionEpgTimer.stop()
                self.stalkerSelectionEpgTimer.start(260, True)
            except Exception:
                self._runStalkerSelectionEpg()

            # EStalker does not run TMDb artwork while scrolling Stalker Live.
            try:
                self["livePoster"].hide()
            except Exception:
                pass
        else:
            self._updateLiveEpg(item)
            self._scheduleLivePoster(item)

        try:
            index = self["list"].getSelectedIndex() + 1
            total = self.stalkerLiveTotal if self.source.get("type") == "stalker" and self.stalkerLiveTotal else len(self.mediaItemsCurrent)
            self["pageInfo"].setText("%d / %d" % (index, total))
        except Exception:
            pass

        try:
            self.zapTimer.stop()
        except Exception:
            pass

    def _resetStalkerVisibleEpg(self):
        if self.kind != "live": return
        self.stalkerEpgGeneration = int(getattr(self, "stalkerEpgGeneration", 0) or 0) + 1
        self.stalkerEpgDownloadedChannels = set()
        self.stalkerShortEpgResults = {}
        self.stalkerEpgPending = []
        self.stalkerEpgBatchRunning = False
        try: self.stalkerEpgApplyTimer.stop()
        except Exception: pass

    def _stalkerEpgChannelId(self, item):
        return str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or "").strip()

    def _stalkerVisibleChannelIds(self):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return []
        rows = self.mediaItemsCurrent or []
        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0
        start = (current_index // 14) * 14
        visible = []
        seen = set()
        for item in rows[start:start + 14]:
            if not isinstance(item, dict) or item.get("_stalker_placeholder"):
                continue
            ch_id = str(item.get("id") or item.get("ch_id") or item.get("stream_id") or "")
            if ch_id and ch_id not in seen:
                seen.add(ch_id)
                visible.append(ch_id)
        return visible

    def _stalkerCleanDescription(self, descr):
        value=str(descr or "").replace("\\r\\n","\\n")
        match=re.search(r"Description:\\s*(.+)",value,re.DOTALL)
        if not match: return value.strip()
        description=match.group(1)
        for label in ("Credits:","Director:","Producer:","Actor:","Category:"):
            pos=description.find(label)
            if pos!=-1:
                description=description[:pos]; break
        return description.strip()

    def _stalkerPortalLocalTimestamp(self, value):
        if value in (None,""): return 0
        try:
            if isinstance(value,(int,float)): return int(value)
        except Exception: pass
        raw=str(value or "").strip()
        try: return int(float(raw))
        except Exception: pass
        try: return int(time.mktime(time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S")))
        except Exception: return 0

    def _storeStalkerShortEpg(self, entries):
        grouped={}
        for entry in entries or []:
            if not isinstance(entry,dict): continue
            ch_id=str(entry.get("ch_id") or "").strip()
            if not ch_id or ch_id=="None": continue
            grouped.setdefault(ch_id,[]).append(dict(entry))
        for ch_id,rows in grouped.items():
            self.stalkerShortEpgResults[ch_id]=rows
        return bool(grouped)

    def _stalkerCurrentNext(self, rows):
        now=int(time.time()); events=[]
        for row in rows or []:
            if not isinstance(row,dict): continue
            start=self._stalkerPortalLocalTimestamp(row.get("time") or row.get("start_timestamp") or row.get("start") or row.get("begin"))
            stop=self._stalkerPortalLocalTimestamp(row.get("time_to") or row.get("stop_timestamp") or row.get("stop") or row.get("end"))
            if not stop and start and row.get("duration"):
                try: stop=start+int(float(row.get("duration")))
                except Exception: pass
            if start and stop: events.append((start,stop,row))
        events.sort(key=lambda x:x[0])
        for i,event in enumerate(events):
            if event[0] < now < event[1]:
                return event, events[i+1] if i+1<len(events) else None
        if events:
            for i,event in enumerate(events):
                if event[0]>now:
                    return event, events[i+1] if i+1<len(events) else None
            return events[0], events[1] if len(events)>1 else None
        return None,None

    def _applyStalkerShortEpg(self, item, fallback=""):
        rows=self.stalkerShortEpgResults.get(self._stalkerEpgChannelId(item)) or []
        current,upcoming=self._stalkerCurrentNext(rows)
        if not current: return False
        now=int(time.time()); begin,stop,row=current; duration=max(0,stop-begin)
        title=str(row.get("name") or row.get("title") or "").strip()
        desc=self._stalkerCleanDescription(row.get("descr") or row.get("description") or row.get("desc") or "")
        self["epgNowTime"].setText(str(row.get("t_time") or "").strip() or self._formatEpgTime(begin,duration))
        self["epgNowTitle"].setText(title)
        percent=min(100,max(0,int(((now-begin)*100)/duration))) if duration>0 else 0
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self["epgProgressText"].setText("%d%%"%percent)
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            nb,ns,nrow=upcoming; nd=max(0,ns-nb)
            self["epgNextTime"].setText(str(nrow.get("t_time") or "").strip() or self._formatEpgTime(nb,nd))
            self["epgNextTitle"].setText(str(nrow.get("name") or nrow.get("title") or "").strip())
        else:
            self["epgNextTime"].setText(tr("")); self["epgNextTitle"].setText(tr(""))
        return True

    def _queueStalkerEpgUpdate(self, kind, payload, generation):
        try:
            with self.stalkerEpgLock:
                self.stalkerEpgPending.append((kind,payload,generation))
        except Exception: pass

    def _drainStalkerEpgUpdates(self):
        try:
            with self.stalkerEpgLock:
                pending=list(self.stalkerEpgPending); self.stalkerEpgPending[:]=[]
        except Exception: pending=[]
        changed=False; done_seen=False
        for kind,payload,generation in pending:
            if generation != self.stalkerEpgGeneration: continue
            if kind=="partial":
                changed = self._storeStalkerShortEpg((payload or {}).get("js",[])) or changed
            elif kind=="done":
                done_seen=True
                for ch_id in (payload or {}).get("failed_ids",[]):
                    self.stalkerEpgDownloadedChannels.discard(str(ch_id))
                changed = self._storeStalkerShortEpg((payload or {}).get("js",[])) or changed
                self.stalkerEpgBatchRunning=False
        if changed or done_seen:
            item=self.current()
            if item and self.source.get("type")=="stalker":
                fallback=(item.get("plot") or item.get("description") or "").strip()
                if self._applyStalkerShortEpg(item,fallback):
                    self._scheduleLivePoster(item)
        if done_seen: self._prefetchStalkerVisibleEpg()
        if self.stalkerEpgBatchRunning or self.stalkerEpgPending:
            try: self.stalkerEpgApplyTimer.start(100,True)
            except Exception: pass

    def _prefetchStalkerVisibleEpg(self):
        if self.kind!="live" or self.source.get("type")!="stalker": return False
        if self.stalkerEpgBatchRunning: return True
        visible=self._stalkerVisibleChannelIds()
        fetch=[x for x in visible if x not in self.stalkerEpgDownloadedChannels]
        if not fetch: return bool(visible)
        for x in fetch: self.stalkerEpgDownloadedChannels.add(x)
        if self.stalkerEpgClient is None:
            try: self.stalkerEpgClient=StalkerClient(dict(self.source))
            except Exception: self.stalkerEpgClient=None
        if self.stalkerEpgClient is None:
            for x in fetch: self.stalkerEpgDownloadedChannels.discard(x)
            return False
        generation=self.stalkerEpgGeneration; self.stalkerEpgBatchRunning=True
        def partial(payload): self._queueStalkerEpgUpdate("partial",payload or {},generation)
        def done(payload): self._queueStalkerEpgUpdate("done",payload or {},generation)
        try:
            self.stalkerEpgClient.short_epg_batch(fetch,limit=10,done_callback=done,partial_callback=partial)
            self.stalkerEpgApplyTimer.start(100,True)
            return True
        except Exception:
            self.stalkerEpgBatchRunning=False
            for x in fetch: self.stalkerEpgDownloadedChannels.discard(x)
            return False

    def _formatEpgTime(self, begin, duration=0):
        try:
            start = time.strftime("%H:%M", time.localtime(int(begin)))
            if duration:
                end = time.strftime("%H:%M", time.localtime(int(begin) + int(duration)))
                return "%s - %s" % (start, end)
            return start
        except Exception:
            return ""

    def _decodeEpgText(self, value):
        value = value or ""
        if not isinstance(value, str):
            try: value = str(value)
            except Exception: return ""
        # Xtream panels commonly return title/description as base64, but some
        # providers already return plain UTF-8. Decode only when it is valid.
        try:
            raw = value.strip()
            if raw and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw).decode("utf-8", "replace").strip()
                if decoded and any(ch.isalnum() for ch in decoded):
                    return decoded
        except Exception:
            pass
        return value.strip()

    def _epgTimestamp(self, row, start=True):
        keys = ("start_timestamp", "start", "begin_timestamp", "begin") if start else ("stop_timestamp", "end", "end_timestamp", "stop")
        for key in keys:
            value = row.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                try:
                    # Common panel format: 2026-08-02 03:30:00
                    return int(time.mktime(time.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")))
                except Exception:
                    pass
        return 0

    def _startDirectEpg(self, item, fallback=""):
        effective_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        source_type = effective_source.get("type")
        if source_type not in ("xtream", "stalker"):
            return False
        stream_id = str(item.get("ch_id") or item.get("stream_id") or item.get("id") or "").strip()
        if not stream_id:
            return False
        self.directEpgToken += 1
        token = self.directEpgToken
        self.directEpgResult = None
        source = dict(effective_source)
        def worker():
            result = []
            error = ""
            try:
                if source_type == "stalker":
                    client = self.stalkerEpgClient
                    if client is None:
                        client = StalkerClient(source)
                        self.stalkerEpgClient = client
                    result = client.short_epg(stream_id, limit=10)
                else:
                    client = XtreamClient(source)
                    epg_channel_id = str(item.get("epg_channel_id") or item.get("tvg_id") or "").strip()
                    result = client.short_epg(stream_id, limit=10, epg_channel_id=epg_channel_id)
                if not isinstance(result, list):
                    result = []
            except Exception as exc:
                error = str(exc)
            self.directEpgResult = (token, result, fallback, error)
        threading.Thread(target=worker, name="TiviMateDirectEPG", daemon=True).start()
        try: self.directEpgTimer.start(120, False)
        except Exception: pass
        return True

    def _finishDirectEpg(self):
        result = self.directEpgResult
        if result is None:
            try: self.directEpgTimer.start(120, False)
            except Exception: pass
            return
        self.directEpgResult = None
        token, rows, fallback, error = result
        if token != self.directEpgToken:
            return
        now_ts = int(time.time())
        parsed = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            duration = max(0, end - begin)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            desc = self._decodeEpgText(row.get("description") or row.get("desc") or row.get("plot"))
            if begin and title:
                parsed.append((begin, duration, title, desc))
        parsed.sort(key=lambda x: x[0])
        current = None
        upcoming = None
        for event in parsed:
            begin, duration, title, desc = event
            finish = begin + duration if duration else begin + 3600
            if begin <= now_ts < finish:
                current = event
            elif begin > now_ts and upcoming is None:
                upcoming = event
        if current is None and parsed:
            # Some panels return only the nearest entries without reliable clock
            # offsets. Prefer the first entry rather than showing another channel.
            current = parsed[0]
            upcoming = parsed[1] if len(parsed) > 1 else upcoming
        if current:
            begin, duration, title, desc = current
            self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
            self["epgNowTitle"].setText(title)
            elapsed = max(0, now_ts - begin)
            percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
            self["epgProgressText"].setText("%d%%" % percent)
            self["desc"].setText((desc or fallback or "No programme description.")[:600])
            if upcoming:
                ub, ud, ut, _ = upcoming
                self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
                self["epgNextTitle"].setText(ut)
        else:
            self["epgNowTitle"].setText(tr("No EPG data"))
            self["desc"].setText(fallback or ("Provider EPG unavailable" if not error else "Provider EPG unavailable"))

    def _applyLocalEpgEvent(self, current, upcoming, fallback=""):
        now_ts = int(time.time())
        begin, duration, title, desc = current
        self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
        self["epgNowTitle"].setText(title or "")
        elapsed = max(0, now_ts - int(begin))
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        self["epgProgressText"].setText("%d%%" % percent)
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            ub, ud, ut, _ = upcoming
            self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
            self["epgNextTitle"].setText(ut or "")

    def _updateLiveEpg(self, item):
        """Provider-specific Live EPG; Stalker follows EStalker 1.45."""
        for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
            try:
                self[key].setText(tr(""))
            except Exception:
                pass
        fallback = (item.get("plot") or item.get("description") or "").strip()

        if self.source.get("type") == "stalker":
            # EStalker uses portal short EPG for Stalker Live.
            if self._applyStalkerShortEpg(item, fallback):
                return
            try:
                self["liveProgress"].setValue(0)
                self["desc"].setText(tr(""))
            except Exception:
                pass
            return

        # Non-Stalker providers keep the existing local/XMLTV/eEPG behavior.
        try:
            current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
            if current:
                self._applyLocalEpgEvent(current, upcoming, fallback)
                return
        except Exception:
            pass

        try:
            cache = eEPGCache.getInstance()
            ref_string = epg_reference_string(self.source, item)
            events = ["IBDTEX", (ref_string, -1, -1, -1)]
            rows = [] if cache is None else (cache.lookupEvent(events) or [])
            if rows:
                def event(row):
                    return (int(row[1] or 0), int(row[2] or 0), row[3] or "", row[4] or "")
                current = event(rows[0])
                upcoming = event(rows[1]) if len(rows) > 1 else None
                self._applyLocalEpgEvent(current, upcoming, fallback)
                return
        except Exception:
            pass

        if self._startDirectEpg(item, fallback):
            self["epgNowTitle"].setText(tr("Loading EPG..."))
            self["desc"].setText(fallback or tr("Loading programme information from the portal..."))
            return

        self["epgNowTitle"].setText(tr("No EPG data"))
        try:
            self["liveProgress"].setValue(0)
        except Exception:
            pass
        self["desc"].setText(fallback or tr(""))

    def _cleanLiveProgrammeTitle(self, title):
        value = str(title or "").strip()
        value = re.sub(r"\s*[\-–—:]?\s*[Ss]\d{1,2}[Ee]\d{1,3}.*$", "", value)
        value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", value)
        value = re.sub(r"\s+", " ", value).strip(" -:|")
        return value

    def _scheduleLivePoster(self, item):
        self.livePosterToken += 1
        self._livePosterItem = dict(item or {})
        self.livePosterResult = None
        try: self.livePosterTimer.stop()
        except Exception: pass
        try: self.livePosterPoll.stop()
        except Exception: pass
        try: self["livePoster"].hide()
        except Exception: pass
        poster_enabled = str(self.source.get("show_live_poster", "0")).strip().lower() in ("1", "true", "yes", "on", "enabled")
        if not poster_enabled:
            return

        # A known programme must never wait for TMDb again.  Resolve its stable
        # URL from the tiny title index, then decode the already cached file
        # immediately.  Only a first-time title uses the delayed TMDb lookup.
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        key = _live_poster_key(title)
        url = _load_live_poster_urls().get(key, "") if key else ""
        token = self.livePosterToken
        if url:
            cached = cached_artwork(url, "live_tmdb_poster")
            if cached:
                self._showLivePosterPath(cached, token)
                return
            # The URL is known but its file was removed.  Re-fetch directly in
            # the artwork queue without repeating a TMDb search or 12s delay.
            def ready(path):
                self._showLivePosterPath(path, token)
            request_artwork(url, kind="live_tmdb_poster", callback=ready, priority=55)
            return

        # First encounter: start the TMDb lookup almost immediately after the
        # EPG title arrives. A short debounce avoids firing requests while the
        # user is rapidly scrolling, but there is no long 12-second wait.
        try: self.livePosterTimer.start(350, True)
        except Exception: self.livePosterTimer.start(350)

    def _startLivePosterLookup(self):
        item = getattr(self, "_livePosterItem", {}) or {}
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        if not title or title in ("No EPG data", "Loading EPG..."):
            return
        token = self.livePosterToken
        def worker():
            url = ""
            try:
                client = TMDbClient()
                result = client.search_artwork(title, "vod", required_key="poster_path") or client.search_artwork(title, "series", required_key="poster_path")
                path = (result or {}).get("poster_path") or ""
                if path:
                    url = IMAGE_BASE + "w342" + path
            except Exception:
                pass
            self.livePosterResult = (token, url)
        t = threading.Thread(target=worker, name="TiviMateLivePosterTMDb")
        t.daemon = True
        t.start()
        try: self.livePosterPoll.start(250, False)
        except Exception: pass

    def _showLivePosterPath(self, path, token=None):
        if token is not None and token != self.livePosterToken:
            return
        if not path or not os.path.exists(path):
            return
        self.livePosterPath = path
        try:
            self.livePosterLoader.setPara((200, 300, 1, 1, False, 1, "#00000000"))
            self.livePosterLoader.startDecode(path)
        except Exception:
            pass

    def _finishLivePosterLookup(self):
        result = self.livePosterResult
        if result is None:
            try: self.livePosterPoll.start(250, False)
            except Exception: pass
            return
        self.livePosterResult = None
        token, url = result
        if token != self.livePosterToken or not url:
            return
        title = self._cleanLiveProgrammeTitle(self["epgNowTitle"].getText())
        key = _live_poster_key(title)
        if key:
            _save_live_poster_url(key, url)
        def ready(path):
            self._showLivePosterPath(path, token)
        request_artwork(url, kind="live_tmdb_poster", callback=ready, priority=55)

    def _livePosterDecoded(self, picInfo=None):
        try:
            ptr = self.livePosterLoader.getData()
            if ptr is not None:
                self["livePoster"].instance.setPixmap(ptr)
                self["livePoster"].show()
        except Exception:
            pass

    def cancelAction(self):
        if self.kind == "live" and self.focus == "items":
            if self.source.get("type") == "stalker":
                self._cancelStalkerCatalogueRequests()
                self.stalkerLiveCancelEvent = threading.Event()
            self.focus = "category"
            self["list"].setList([])
            self["categoryTitle"].setText(tr("PACKAGES"))
            self["channelTitle"].setText(tr("Select a package"))
            self["meta"].setText(tr(""))
            self["desc"].setText(tr("Select a package") + " - OK")
            self._hideRowPicons()
            return
        if self.kind == "live":
            try:
                self.stalkerWatchdogTimer.stop()
            except Exception:
                pass
            self.stalkerWatchdogPending = False
            self.stalkerWatchdogClient = None
        self.close()

    def _hideRowPicons(self):
        return


    def _refreshVisibleRowPicons(self):
        return


    def _finishRowPicons(self):
        return


    def _rowPiconDecoded(self, idx):
        return


    def _updateLiveClock(self):
        try:
            self["clockTitle"].setText(time.strftime("%Y/%m/%d   %H:%M", time.localtime()))
        except Exception:
            pass

    def _visibleLiveItems(self):
        items = self.mediaItemsCurrent or []
        if not items:
            return []
        try:
            idx = self["list"].getSelectedIndex()
        except Exception:
            idx = 0
        start = max(0, min(idx - 4, max(0, len(items) - 10)))
        return items[start:start + 10]

    def _updateLiveKeys(self):
        if self.kind != "live":
            return
        try:
            self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
        except Exception:
            pass

    def toggleAutoZap(self):
        if self.kind != "live": return
        self.channelSettings["auto_zap"] = not self.channelSettings.get("auto_zap", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys()
        if self.channelSettings["auto_zap"]:
            try: self.zapTimer.stop()
            except Exception: pass
            self._autoZapCurrent()

    def toggleLivePicon(self):
        if self.kind != "live": return
        self.channelSettings["picon"] = not self.channelSettings.get("picon", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys(); self.previewLive()

    def _zapLiveItem(self, item, force=False):
        if not item or self.kind != "live":
            return False
        try:
            def channel_identity(row):
                row = row or {}
                return str(
                    row.get("stream_id") or row.get("ch_id") or row.get("id") or
                    row.get("url") or row.get("cmd") or row.get("name") or ""
                ).strip()

            live_id = channel_identity(item)

            # Same currently playing channel = NO OP.
            # Must return before stream_url/create_link/playService.
            if not force and live_id:
                try:
                    shared_id = str((self.source or {}).get("_tivimate_current_live_id") or "").strip()
                    current_id = str(getattr(self, "lastZappedLiveId", "") or "").strip()
                    global_same = (
                        _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source) and
                        _CURRENT_LIVE_CHANNEL.get("channel") == live_id
                    )
                    if shared_id == live_id or current_id == live_id or global_same:
                        if self.session.nav.getCurrentlyPlayingServiceReference() is not None:
                            self.lastZappedLiveId = live_id
                            self.keepCurrentLiveService = True
                            return True
                except Exception:
                    pass

            play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            if play_source.get("type") in ("xtream", "stalker"):
                url = get_source_client(play_source).stream_url(item, "live")
            elif play_source.get("type") in ("m3u", "fg"):
                url = item.get("url", "")
            else:
                url = ""
            if not url:
                return False

            service_type = (
                _xtream_service_type(play_source, "live")
                if play_source.get("type") == "xtream"
                else int(play_source.get("service_type", self.channelSettings.get("service_type", 4097)))
            )
            ref = live_reference(
                play_source, item, service_type, url,
                item.get("name") or item.get("title") or "IPTV"
            )
            self.session.nav.playService(ref)
            self.lastZappedLiveId = live_id
            self._playingLiveItem = dict(item or {})
            self._playingLiveUrl = str(url or "")
            _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
            _CURRENT_LIVE_CHANNEL["channel"] = live_id
            try:
                self.source["_tivimate_current_live_id"] = live_id
            except Exception:
                pass
            self.keepCurrentLiveService = True
            self["meta"].setText(tr("Channel changed"))
            return True
        except Exception as exc:
            try:
                self["meta"].setText("Unable to change channel: %s" % exc)
            except Exception:
                pass
            return False


    def _stalkerPlaySource(self):
        if self.kind != "live":
            return None
        source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        return source if isinstance(source, dict) else None

    def _startStalkerWatchdog(self):
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            return
        try:
            self.stalkerWatchdogTimer.stop()
        except Exception:
            pass
        try:
            self.stalkerWatchdogTimer.start(30000, False)
        except Exception:
            pass

    def _runStalkerWatchdog(self):
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            return
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference() is not None
        except Exception:
            active = False
        if not active or not getattr(self, "keepCurrentLiveService", False):
            try:
                self.stalkerWatchdogTimer.start(30000, False)
            except Exception:
                pass
            return
        if getattr(self, "stalkerWatchdogPending", False):
            try:
                self.stalkerWatchdogTimer.start(30000, False)
            except Exception:
                pass
            return

        self.stalkerWatchdogPending = True
        if self.stalkerWatchdogClient is None:
            try:
                self.stalkerWatchdogClient = get_source_client(source)
            except Exception:
                self.stalkerWatchdogClient = None

        client = self.stalkerWatchdogClient

        def worker():
            try:
                if client is not None:
                    client.watchdog()
            except Exception:
                pass
            self.stalkerWatchdogPending = False

        thread = threading.Thread(target=worker, name="TiviMateStalkerWatchdog")
        thread.daemon = True
        thread.start()
        try:
            self.stalkerWatchdogTimer.start(30000, False)
        except Exception:
            pass

    def restartCurrentLiveStream(self):
        """Manual restart for the active Stalker Live channel."""
        if self.kind != "live":
            return
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            self.openBeinSports()
            return

        item = getattr(self, "_playingLiveItem", None) or self.current()
        if not item:
            try:
                self["meta"].setText(tr("No active channel to restart"))
            except Exception:
                pass
            return

        try:
            self["meta"].setText(tr("Restarting stream..."))
        except Exception:
            pass

        if self._zapLiveItem(dict(item), True):
            try:
                self["meta"].setText(tr("Stream restarted"))
            except Exception:
                pass
        else:
            try:
                self["meta"].setText(tr("Unable to restart stream"))
            except Exception:
                pass


    def _autoZapCurrent(self):
        if not self.channelSettings.get("auto_zap", True):
            return
        if self._isCurrentStalkerChannelLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
            return
        self._zapLiveItem(self.current(), False)

    def _showLivePicon(self, item):
        """One Live Picon path for every provider."""
        try:
            self._sidePiconReqId = int(getattr(self, "_sidePiconReqId", 0) or 0) + 1
        except Exception:
            self._sidePiconReqId = 1
        req_id = self._sidePiconReqId

        blank = os.path.join(PLUGIN_PATH, "skins", "transparent.png")
        try:
            if self["channelPicon"].instance and os.path.exists(blank):
                self["channelPicon"].instance.setPixmapFromFile(blank)
            self["channelPicon"].show()
        except Exception:
            pass

        item = item or {}
        url = str(
            item.get("stream_icon") or
            item.get("logo") or
            item.get("icon") or
            item.get("channel_icon") or
            item.get("picon") or
            ""
        ).strip().replace("\\/", "/")

        # General normalization for providers that return relative logo URLs.
        if url and not url.startswith(("http://", "https://")):
            try:
                base = str(
                    self.source.get("url") or
                    self.source.get("portal") or
                    self.source.get("host") or
                    self.source.get("server") or
                    ""
                ).strip().rstrip("/")

                if url.startswith("//"):
                    scheme = "https" if base.startswith("https://") else "http"
                    url = scheme + ":" + url
                elif url.startswith("/") and base:
                    url = base + url
                elif base:
                    url = base + "/" + url.lstrip("/")
            except Exception:
                pass

        if not url.startswith(("http://", "https://")):
            self._sidePiconPending = None
            return

        self._sidePiconPending = (req_id, url)
        try:
            self.livePiconTimer.stop()
            self.livePiconTimer.start(250, True)
        except Exception:
            self._finishLivePicon()

    def _finishLivePicon(self):
        pending = getattr(self, '_sidePiconPending', None)
        self._sidePiconPending = None
        if not pending:
            return

        req_id, url = pending
        if req_id != int(getattr(self, '_sidePiconReqId', 0) or 0):
            return

        def current_id():
            return int(getattr(self, '_sidePiconReqId', 0) or 0)

        def apply_path(path):
            if req_id != current_id() or not path:
                return
            try:
                if self['channelPicon'].instance:
                    self['channelPicon'].instance.setPixmapFromFile(path)
                    self['channelPicon'].show()
            except Exception:
                pass

        direct_picon(
            url,
            (220, 130),
            req_id,
            current_id,
            apply_path,
            prefix='xst_live_picon_'
        )

    def _livePiconDecoded(self, picInfo=None):
        return



    def renderPosterPage(self):
        self.downloads=[]; self.picloads=[]
        for slot in range(5):
            idx=self.pageStart+slot
            item=self.mediaItemsCurrent[idx] if idx < len(self.mediaItemsCurrent) else None
            self._setVisibleWidget("poster%d"%slot, bool(item))
            self._setVisibleWidget("posterLabel%d"%slot, bool(item))
            self._setVisibleWidget("posterRate%d"%slot, bool(item))
            self["posterLabel%d"%slot].setText(((item.get("name") or item.get("title") or "")[:22]) if item else "")
            rate = ""
            if item:
                rate = item.get("rating") or item.get("rating_5based") or ""
                rate = str(rate)[:4]
            self["posterRate%d"%slot].setText(("★ " + rate) if rate else "")
            self._setPlaceholder(slot)
            if item:
                url=item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("poster_path") or ""
                if url:
                    # Package poster grid: reveal disk/RAM cached posters immediately.
                    # Do not send already-cached artwork back through the shared queue;
                    # that made the whole row appear together after a short wait.
                    cached = cached_artwork(url, "posters")
                    if cached:
                        self._poster_artwork_requests[slot] = (url or "").strip().replace("\\/", "/")
                        self._decodeSlot(slot, cached)
                    else:
                        self._loadPosterSlot(slot, url, item)
                else:
                    self._tmdbPosterSlotFallback(slot, item)
        self._setVisibleWidget("selector", bool(self.mediaItemsCurrent))
        self.moveSelector(); self.previewVod()
        # Poster speed test: after the five visible cards are queued at high
        # priority, prefetch a bounded part of the current category in the
        # background. request_artwork deduplicates existing/running files and
        # keeps only four network transfers active, so navigation stays usable.
        self._prefetchCategoryPosters()

    def _prefetchCategoryPosters(self):
        if self.kind not in ("vod", "series"):
            return
        # Package grids only prefetch a small window around the current page.
        # Prefetching an entire large package can saturate disk/network and delays
        # the five posters the user is actually looking at. Cached files are skipped
        # by prefetch_artwork automatically.
        start = max(0, int(self.pageStart or 0))
        stop = min(len(self.mediaItemsCurrent or []), start + 15)
        urls = []
        for item in list((self.mediaItemsCurrent or [])[start:stop]):
            try:
                url = item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("poster_path") or ""
                if url:
                    urls.append(url)
            except Exception:
                pass
        prefetch_artwork(urls, "posters", priority=2)


    def _setVisibleWidget(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d"%slot].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png")
        except Exception: pass

    def _posterFileUsable(self, path):
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n")
        except Exception:
            return False

    def _tmdbPosterSlotFallback(self, slot, item):
        title = (item or {}).get("name") or (item or {}).get("title") or (item or {}).get("original_title") or ""
        if not title:
            return
        token = "%s:%s:%s" % (self.kind, str((item or {}).get("stream_id") or (item or {}).get("series_id") or ""), str(title))
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = token
        def worker():
            try:
                raw_year = (item or {}).get("year") or (item or {}).get("releaseDate") or (item or {}).get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                found = TMDbClient().search_artwork(title, self.kind, year, required_key="poster_path") or {}
                path = found.get("poster_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(path)
                def apply():
                    if getattr(self, "_poster_artwork_requests", {}).get(slot) != token:
                        return
                    self._loadPosterSlot(slot, url, None)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateCategoryPosterTMDB")
        thread.daemon = True
        thread.start()

    def _loadPosterSlot(self, slot, url, fallback_item=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_item is not None:
                self._tmdbPosterSlotFallback(slot, fallback_item)
            return
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = url

        def done(path, s=slot, expected=url, item=fallback_item):
            if getattr(self, "_poster_artwork_requests", {}).get(s) != expected:
                return
            if item is not None and not self._posterFileUsable(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._tmdbPosterSlotFallback(s, item)
                return
            self._decodeSlot(s, path)

        def failed(_path, s=slot, item=fallback_item):
            if item is not None:
                self._tmdbPosterSlotFallback(s, item)

        request_artwork(url, "posters", done, priority=55, errback=failed if fallback_item is not None else None)

    def _decodeSlot(self, slot, path):
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader):
            try:
                ptr = l.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(270, 380)
        # Fill the existing poster widget exactly.  Aspect-fit (1,1) leaves
        # black side edges on common 2:3 artwork inside this 270x380 card.
        loader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        loader.startDecode(path)

    def moveSelector(self):
        # Lightweight focus: poster pixmaps stay completely fixed.
        # Only the original focus frame moves; selected metadata is emphasized.
        try:
            if self["selector"].instance:
                self["selector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(525)))
                self["selector"].show()
            for i in range(5):
                try:
                    selected = (i == self.posterIndex)
                    self["posterLabel%d" % i].instance.setForegroundColor(
                        parseColor("#FFFFFF" if selected else "#C7CDD4")
                    )
                    self["posterRate%d" % i].instance.setForegroundColor(
                        parseColor("#F1C84C" if selected else "#8D8059")
                    )
                except Exception:
                    pass
        except Exception:
            pass

    def scheduleSelectedInfo(self):
        if self.kind not in ("vod", "series") or self.source.get("type") not in ("xtream", "stalker"):
            return
        try: self.infoTimer.stop()
        except Exception: pass
        try: self.infoTimer.start(900, True)
        except Exception: self.loadSelectedInfo()

    def loadSelectedInfo(self):
        if SAFE_TABLE_MODE:
            return
        item = self.current()
        if not item:
            return
        mid = str(item.get("stream_id") or item.get("series_id") or "")
        if not mid:
            self._loadSelectedTmdbInfo(item)
            return
        key = self.kind + ":" + mid
        cached = self.fullInfoCache.get(key)
        if cached is not None:
            self.applySelectedInfo(mid, cached)
            return
        if key in self.infoProcesses:
            return
        try:
            if self.source.get("type") == "stalker":
                self._loadSelectedTmdbInfo(item)
                return
            client = XtreamClient(self.source)
            action = "get_vod_info" if self.kind == "vod" else "get_series_info"
            try:
                from urllib.parse import urlencode
            except ImportError:
                from urllib import urlencode
            url = client.base + "/player_api.php?" + urlencode({
                "username": client.user,
                "password": client.password,
                "action": action,
                ("vod_id" if self.kind == "vod" else "series_id"): mid,
            })
            cache_dir = get_cache_dir("info")
            try:
                ensure_dir(cache_dir)
            except Exception:
                pass
            path = os.path.join(cache_dir, hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            proc = eConsoleAppContainer()
            self.infoProcesses[key] = proc
            self.pendingInfoId = mid
            def done(ret, k=key, m=mid, p=path):
                self.infoProcesses.pop(k, None)
                if ret != 0 or not os.path.exists(p):
                    current = self.current()
                    if current:
                        self._loadSelectedTmdbInfo(current)
                    return
                try:
                    with open_text(p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    self.fullInfoCache[k] = data or {}
                    self.applySelectedInfo(m, data or {})
                except Exception:
                    pass
            try:
                proc.appClosed.append(done)
            except Exception:
                proc.appClosed.get().append(done)
            proc.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, INFO_FETCH, url, path)
        except Exception:
            return

    def _loadSelectedTmdbInfo(self, item):
        """Enrich the selected movie/series from title alone when server info is sparse."""
        title = (item or {}).get("name") or (item or {}).get("title") or (item or {}).get("original_title") or ""
        if not title:
            return
        expected = "%s:%s" % (self.kind, title)
        self._tmdb_selected_token = expected
        def worker():
            try:
                raw_year = (item or {}).get("year") or (item or {}).get("releaseDate") or (item or {}).get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                client = TMDbClient()
                found = client.search_artwork(title, self.kind, year) or {}
                tid = found.get("id") or (item or {}).get("tmdb_id") or (item or {}).get("tmdb")
                bundle = client.details_bundle(tid, self.kind) if tid else found
                def apply():
                    if getattr(self, "_tmdb_selected_token", "") != expected:
                        return
                    current = self.current() or {}
                    current_title = current.get("name") or current.get("title") or current.get("original_title") or ""
                    if str(current_title) != str(title):
                        return
                    merged = dict(item or {})
                    data = bundle or {}
                    display_title = data.get("title") or data.get("name") or title
                    date = data.get("release_date") or data.get("first_air_date") or merged.get("year") or ""
                    rating = data.get("vote_average") or merged.get("rating") or ""
                    genres = ", ".join(x.get("name", "") for x in (data.get("genres") or [])[:3])
                    runtime = data.get("runtime") or ""
                    self["channelTitle"].setText(str(display_title))
                    self["meta"].setText("   ".join(x for x in [str(date)[:4], ("★ %s" % str(rating)[:4]) if rating else "", str(runtime), genres] if x))
                    self["desc"].setText((data.get("overview") or merged.get("plot") or merged.get("description") or "لا توجد أية معلومات")[:650])
                    back = data.get("backdrop_path") or ""
                    if back:
                        if not str(back).startswith(("http://", "https://")):
                            back = backdrop_url(str(back))
                        self.loadBackdrop(back)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateSelectedTMDB")
        thread.daemon = True
        thread.start()

    def applySelectedInfo(self, mid, data):
        current = self.current()
        current_id = str((current or {}).get("stream_id") or (current or {}).get("series_id") or "")
        if current_id != str(mid):
            return
        item = current or {}
        info = (data or {}).get("info") or {}
        movie = (data or {}).get("movie_data") or {}
        merged = {}
        merged.update(item)
        merged.update(movie)
        merged.update(info)
        title = merged.get("name") or merged.get("title") or ""
        year = merged.get("releasedate") or merged.get("releaseDate") or merged.get("year") or ""
        rating = merged.get("rating") or merged.get("rating_5based") or ""
        genre = merged.get("genre") or ""
        duration = merged.get("duration") or merged.get("duration_secs") or ""
        self["channelTitle"].setText(title)
        self["meta"].setText("   ".join(x for x in [str(year), ("★ %s" % rating) if rating else "", str(duration), str(genre)] if x))
        self["desc"].setText((merged.get("plot") or merged.get("description") or merged.get("overview") or "لا توجد أية معلومات")[:650])
        back = merged.get("backdrop_path") or merged.get("backdrop") or merged.get("backdrop_url") or []
        if isinstance(back, list):
            back = back[0] if back else ""
        if isinstance(back, str):
            back = back.strip().replace(chr(92) + "/", "/")
            if back.startswith("["):
                try:
                    arr = json.loads(back)
                    back = arr[0] if arr else ""
                except Exception:
                    pass
            if back.startswith("/") and not back.startswith("//"):
                back = backdrop_url(back)
        if back:
            self.loadBackdrop(back)
        else:
            self._loadSelectedTmdbInfo(merged)

    def _hideTitleLogo(self):
        if self.kind not in ("vod", "series"):
            return
        try:
            self["titleLogo"].hide()
        except Exception:
            pass

    def _tmdbLogoUrl(self, bundle):
        try:
            logos = ((bundle or {}).get("images") or {}).get("logos") or []
        except Exception:
            logos = []
        if not logos:
            return ""
        raster_logos = [x for x in logos if isinstance(x, dict) and str(x.get("file_path") or "").lower().endswith((".png", ".jpg", ".jpeg", ".webp"))]
        if not raster_logos:
            return ""
        wanted = str(getattr(TMDbClient(), "language", "") or "").split("-")[0].lower()
        # Prefer the device/TMDb language, then English, then language-neutral,
        # then any raster logo. TMDb title logos are normally transparent PNGs.
        def score(row):
            lang = str((row or {}).get("iso_639_1") or "").lower()
            ext = str((row or {}).get("file_path") or "").lower()
            raster = 1 if ext.endswith((".png", ".jpg", ".jpeg", ".webp")) else 0
            if lang and wanted and lang == wanted:
                pref = 4
            elif lang == "en":
                pref = 3
            elif not lang:
                pref = 2
            else:
                pref = 1
            vote = float((row or {}).get("vote_average") or 0)
            width = int((row or {}).get("width") or 0)
            return (raster, pref, vote, width)
        try:
            chosen = sorted(raster_logos, key=score, reverse=True)[0]
        except Exception:
            chosen = raster_logos[0] if raster_logos else {}
        path = str((chosen or {}).get("file_path") or "").strip()
        if not path:
            return ""
        if path.startswith(("http://", "https://")):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return "https://image.tmdb.org/t/p/w500" + path

    def _loadSelectedTitleLogo(self, item):
        if self.kind not in ("vod", "series") or not getattr(self, "packageTitleLogoEnabled", False):
            self._hideTitleLogo()
            return
        row = dict(item or {})
        title = row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or ""
        if not str(title or "").strip():
            self._titleLogoToken = ""
            self._hideTitleLogo()
            return
        media_id = str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or "")
        token = "%s:%s:%s" % (self.kind, media_id, str(title))
        self._titleLogoToken = token
        self._hideTitleLogo()
        snapshot = dict(row)

        def worker():
            try:
                client = TMDbClient()
                tid = snapshot.get("tmdb_id") or snapshot.get("tmdb") or ""
                if not tid:
                    raw_year = " ".join(str(snapshot.get(k) or "") for k in ("year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"))
                    match = re.search(r"\b(?:19|20)\d{2}\b", raw_year)
                    year = match.group(0) if match else None
                    found = client.search_artwork(title, self.kind, year) or {}
                    tid = found.get("id") or ""
                if not tid or getattr(self, "_titleLogoToken", "") != token:
                    return
                bundle = client.details_bundle(tid, self.kind) or {}
                url = self._tmdbLogoUrl(bundle)
                if not url or getattr(self, "_titleLogoToken", "") != token:
                    return

                def downloaded(path, expected=token):
                    if getattr(self, "_titleLogoToken", "") != expected or not path:
                        return
                    self._decodeTitleLogo(path, expected)

                request_artwork(url, "logos", downloaded, priority=110)
            except Exception:
                pass

        thread = threading.Thread(target=worker, name="TiviMateTitleLogoTMDB")
        thread.daemon = True
        thread.start()

    def _decodeTitleLogo(self, path, token):
        if self.kind not in ("vod", "series") or not getattr(self, "packageTitleLogoEnabled", False) or getattr(self, "_titleLogoToken", "") != token:
            return
        loader = ePicLoad()
        self._titleLogoLoader = loader

        def ready(_info=None, expected=token, ref=loader):
            if getattr(self, "_titleLogoToken", "") != expected or self._titleLogoLoader is not ref:
                return
            try:
                ptr = ref.getData()
                if ptr and self["titleLogo"].instance:
                    self["titleLogo"].instance.setPixmap(ptr)
                    self["titleLogo"].show()
            except Exception:
                self._hideTitleLogo()

        connect_picture_data(loader, ready, self)
        width, height = scale_size(430, 180)
        loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def loadBackdrop(self, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._media_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_media_backdrop_request", "") != expected:
                return
            self.decodeBackdrop(path)

        request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        self.backdropLoader=ePicLoad()
        def ready(_info=None):
            try:
                ptr=self.backdropLoader.getData()
                if ptr and self["backdrop"].instance: self["backdrop"].instance.setPixmap(ptr)
            except Exception: pass
        connect_picture_data(self.backdropLoader, ready, self)
        render_width, render_height = scale_size(1920, 1080)
        self.backdropLoader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        self.backdropLoader.startDecode(path)

    def previewVod(self):
        item=self.current()
        if not item:
            self._titleLogoToken = ""
            self._hideTitleLogo()
            self["channelTitle"].setText(tr("No content")); self["meta"].setText(tr("")); self["desc"].setText(tr("")); self["nowLabel"].setText(tr("0/0")); return
        self._loadSelectedTitleLogo(item)
        title=item.get("name") or item.get("title") or ""
        year=item.get("releaseDate") or item.get("year") or ""; rating=item.get("rating") or item.get("rating_5based") or ""; genre=item.get("genre") or ""; dur=item.get("duration") or ""; typ=item.get("container_extension") or item.get("stream_type") or ""
        self["channelTitle"].setText(title)
        rating_text = ("★ " + str(rating)) if rating else ""
        self["meta"].setText("  •  ".join(x for x in [str(genre), rating_text, str(year), str(dur)] if x))
        self["desc"].setText((item.get("plot") or item.get("description") or "لا توجد أية معلومات")[:600])
        self["nowLabel"].setText("%d / %d" % (self.pageStart+self.posterIndex+1, len(self.mediaItemsCurrent)))
        self.scheduleSelectedInfo()


    def left(self):
        if self.focus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateTopFocus()
            return

        if self.kind == "live":
            # LIVE is column-based:
            # Channels -> Packages -> left rail.
            # LEFT must never behave like UP.
            if self.focus == "items":
                self.cancelAction()
                return
            if self.focus == "category":
                self.focus = "rail"
                self._updateTopFocus()
                return
            if self.focus == "rail":
                return
            return

        # Movies / TV Shows: horizontal movement inside the poster row only.
        if self.focus != "items":
            return
        if self.posterIndex > 0:
            self.posterIndex -= 1
            self.moveSelector(); self.previewVod()
        elif self.pageStart >= 5:
            self.pageStart -= 5
            self.posterIndex = 4
            self.renderPosterPage()



    def right(self):
        if self.focus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateTopFocus()
            return

        if self.kind == "live":
            # LIVE is column-based:
            # left rail -> Packages -> Channels.
            # RIGHT must never behave like DOWN.
            if self.focus == "rail":
                self.switchSection(self.currentRailSection())
                return
            if self.focus == "category":
                self.loadSelectedCategory()
                self.focus = "items"
                self._updateTopFocus()
                return
            if self.focus == "items":
                return
            return

        # Movies / TV Shows: horizontal movement inside the poster row only.
        if self.focus != "items":
            return
        if self.pageStart + self.posterIndex + 1 >= len(self.mediaItemsCurrent):
            return
        if self.posterIndex < 4:
            self.posterIndex += 1
            self.moveSelector(); self.previewVod()
        else:
            self.pageStart += 5
            self.posterIndex = 0
            self.renderPosterPage()


    def up(self):
        if self.kind == "live":
            if self.focus == "rail":
                self["rail"].up()
            elif self.focus == "category":
                self["category"].up()
            else:
                self["list"].up(); self.previewLive()
            return
        if self.focus == "items":
            self.focus = "top"
            self._updateTopFocus()


    def down(self):
        if self.kind == "live":
            if self.focus == "rail":
                self["rail"].down()
            elif self.focus == "category":
                self["category"].down()
            else:
                self["list"].down(); self.previewLive()
            return
        if self.focus == "top":
            self.focus = "items"
            self._updateTopFocus()
            self.moveSelector(); self.previewVod()


    def liveFastUp(self):
        if self.kind != "live":
            return
        widget = self["list"] if self.focus == "items" else self["category"]
        try:
            widget.pageDown()
        except Exception:
            pass
        if self.focus == "items":
            self.previewLive()

    def liveFastDown(self):
        if self.kind != "live":
            return
        widget = self["list"] if self.focus == "items" else self["category"]
        try:
            widget.pageUp()
        except Exception:
            pass
        if self.focus == "items":
            self.previewLive()


    def channelPageUp(self):
        if self.kind != "live" or self.focus != "items":
            return
        try: self["list"].pageUp()
        except Exception:
            for _ in range(10): self["list"].up()
        self.previewLive()

    def channelPageDown(self):
        if self.kind != "live" or self.focus != "items":
            return
        try: self["list"].pageDown()
        except Exception:
            for _ in range(10): self["list"].down()
        self.previewLive()

    def pageUp(self):
        if self.kind != "live": return
        widget = self["list"] if self.focus == "items" else self["category"]
        try: widget.pageUp()
        except Exception:
            for _ in range(10): widget.up()
        if self.focus == "items": self.previewLive()

    def pageDown(self):
        if self.kind != "live": return
        widget = self["list"] if self.focus == "items" else self["category"]
        try: widget.pageDown()
        except Exception:
            for _ in range(10): widget.down()
        if self.focus == "items": self.previewLive()

    def openLiveSearch(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard,
            title="Search channels", text=self.searchQuery or "")

    def openLiveFilter(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self._liveFilterClosed, ServerCategoryFilter, self.source)

    def _liveFilterClosed(self, changed=False):
        if not changed or self.kind != "live":
            return
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.mediaItemsCurrent = []
        self.focus = "category"
        try:
            pass
        except Exception:
            pass
        self.loadCategories()

    def toggleLiveSort(self):
        if self.kind != "live":
            return
        modes = ["default", "name", "added"]
        try:
            position = modes.index(self.sortMode)
        except Exception:
            position = 0
        self.sortMode = modes[(position + 1) % len(modes)]
        items = list(self.lastCategoryItems or [])
        if self.searchQuery and not (self.source.get("type") == "stalker"):
            query = self.searchQuery.lower()
            items = [entry for entry in items if query in (entry.get("name") or entry.get("title") or "").lower()]
        if self.sortMode == "name":
            items.sort(key=lambda entry: (entry.get("name") or entry.get("title") or "").lower())
            label = "A-Z"
        elif self.sortMode == "added":
            def added_value(entry):
                try:
                    return int(float(entry.get("added") or entry.get("added_timestamp") or 0))
                except Exception:
                    return 0
            items.sort(key=added_value, reverse=True)
            label = "Added"
        else:
            label = "Original"
        try:
            self["meta"].setText("Sort: %s" % label)
        except Exception:
            pass
        self.showItems(items)


    def toggleSort(self):
        if self.kind == "live":
            self.toggleLiveSort()
            return
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        items = list(self.mediaItemsCurrent or self.lastCategoryItems or [])
        if self.sortMode == "name":
            items.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
            self["filterIcon"].setText(tr("Name"))
        elif self.sortMode == "rating":
            def rating_value(x):
                try:
                    return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception:
                    return 0
            items.sort(key=rating_value, reverse=True)
            self["filterIcon"].setText(tr("Rating"))
        else:
            items = list(self.lastCategoryItems or [])
            if self.searchQuery:
                q = self.searchQuery.lower()
                items = [x for x in items if q in (x.get("name") or x.get("title") or "").lower()]
            self["filterIcon"].setText(tr("Filter"))
        self.showItems(items)

    def openSearch(self):
        if self.kind == "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title="Search content", text=self.searchQuery or "")

    def searchCallback(self, value=None):
        if value is None:
            return
        value = (value or "").strip()
        self.searchQuery = value
        if not value:
            self.showItems(self.lastCategoryItems)
            return
        self.applySearch(value)

    def applySearch(self, value):
        q = (value or "").strip().lower()
        if self.kind == "live" and self.source.get("type") == "stalker" and q:
            # Match EStalker level-2 Search All: query the portal-wide channel
            # list rather than filtering only the currently opened bouquet.
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            try:
                self["meta"].setText("Search All...")
            except Exception:
                pass
            source = dict(self.source)
            def worker():
                try:
                    rows = StalkerClient(source).search_all_live(q)
                    self.categoryLoadResult = (token, rows, "stalker_search_all", "", "Search All")
                except Exception as exc:
                    self.categoryLoadResult = (token, [], "error", str(exc), "Search All")
            t = threading.Thread(target=worker, name="TiviMateStalkerSearchAll")
            t.daemon = True
            t.start()
            try:
                self.categoryLoadTimer.start(120, False)
            except Exception:
                pass
            return

        items = []
        for x in (self.lastCategoryItems or []):
            name = (x.get("name") or x.get("title") or "").lower()
            plot = (x.get("plot") or x.get("description") or "").lower()
            if q in name or q in plot:
                items.append(x)
        self.showItems(items)
        try:
            caption = self["currentCategory"].getText() or ""
            if q:
                self["currentCategory"].setText((caption.split("  •  ")[0] if "  •  " in caption else caption) + "  •  Search")
        except Exception:
            pass

    def close(self, *args, **kwargs):
        if self.kind == "live":
            try:
                self.zapTimer.stop(); self.livePiconTimer.stop(); self.rowPiconTimer.stop(); self.directEpgTimer.stop()
                pass
                if self.oldService: self.session.nav.playService(self.oldService)
            except Exception:
                pass
        return Screen.close(self, *args, **kwargs)

    def livePlayerClosed(self, result=None):
        index = None
        live_id = ""
        try:
            if isinstance(result, (tuple, list)) and len(result) >= 2:
                index = result[0]
                live_id = str(result[1] or "").strip()
            else:
                index = result
        except Exception:
            index = result

        try:
            if index is not None and self.mediaItemsCurrent:
                index = max(0, min(int(index), len(self.mediaItemsCurrent) - 1))
                self["list"].moveToIndex(index)
                if not live_id:
                    item = self.mediaItemsCurrent[index] or {}
                    live_id = str(
                        item.get("stream_id") or item.get("ch_id") or item.get("id") or
                        item.get("url") or item.get("cmd") or item.get("name") or ""
                    ).strip()

                self._playingLiveIndex = index
                self._playingLiveId = live_id
                if live_id:
                    self.lastZappedLiveId = live_id
                    self.keepCurrentLiveService = True
                    try:
                        self.source["_tivimate_current_live_id"] = live_id
                        _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
                        _CURRENT_LIVE_CHANNEL["channel"] = live_id
                    except Exception:
                        pass

                # Refresh only EPG/Picon preview. Same-channel auto-zap is blocked below.
                self.previewLive()
        except Exception:
            pass

        try:
            self.show()
        except Exception:
            pass


    def _openLockedCategoryNow(self):
        self.loadSelectedCategory()
        self.focus = "items"

    def _reopenCurrentLivePlayer(self):
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = 0
        self._playingLiveIndex = index
        try:
            item = self.mediaItemsCurrent[index] or {}
            self._playingLiveId = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            self._playingLiveId = ""
        self.keepCurrentLiveService = True
        try:
            self.zapTimer.stop()
        except Exception:
            pass
        play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        self.session.openWithCallback(
            self.livePlayerClosed, TiviMateLivePlayer,
            play_source, list(self.mediaItemsCurrent or []), index, True
        )

    def _openLivePlayerNow(self):
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = 0
        self._playingLiveIndex = index
        try:
            start_item = self.mediaItemsCurrent[index] or {}
            self._playingLiveId = str(
                start_item.get("stream_id") or start_item.get("ch_id") or start_item.get("id") or
                start_item.get("url") or start_item.get("cmd") or start_item.get("name") or ""
            ).strip()
        except Exception:
            self._playingLiveId = ""
        self.keepCurrentLiveService = True
        try:
            self.zapTimer.stop()
        except Exception:
            pass
        play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        self.session.openWithCallback(self.livePlayerClosed, TiviMateLivePlayer,
                                      play_source, list(self.mediaItemsCurrent or []), index)

    def playerClosed(self, *args):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def ok(self):
        if self.focus == "top":
            self._openTopItem(); return
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus=="category":
            if self.kind == "live" and self._isCurrentStalkerCategoryLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
                self._requestStalkerPin(("category", None)); return
            self.loadSelectedCategory(); self.focus="items"; return
        item=self.current()
        if not item: return
        if self.kind == "live":
            if getattr(self, "catchupPackageActive", False):
                if self.source.get("type") == "stalker":
                    self._openStalkerCatchup()
                elif self.source.get("type") == "xtream":
                    self._openXtreamCatchup()
                return
            if self._isCurrentStalkerChannelLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
                self._requestStalkerPin(("play", None)); return

            # Explicit OK must always attempt a real channel start.
            # Do not reuse the current service merely because IDs/index match:
            # Enigma2 can still hold a service reference after the stream died.
            self._openLivePlayerNow(); return
        try:
            # Re-detect the platform from the active SERVER package at the
            # exact moment we open details. This guarantees the provider mark
            # survives even if the cached row was created before filtering.
            detail_item = dict(item or {})
            package_name = str(getattr(self, "activeCategoryName", "") or
                               getattr(self, "initialCategoryName", "") or
                               detail_item.get("_server_package_name") or "")
            provider = str(getattr(self, "activePackageProvider", "") or
                           detail_item.get("_server_package_provider") or
                           detail_item.get("_tmdb_provider") or "").strip().lower()
            if not provider:
                provider = self._providerFromPackageName(package_name)
            if provider:
                detail_item["_tmdb_provider"] = provider
                detail_item["_server_package_provider"] = provider
                detail_item["_server_package_name"] = package_name

            if self.kind == "series":
                self.session.open(SeriesDetailsScreen, self.source, detail_item)
                return

            if self.kind == "vod":
                # Server-package movies now open the SAME rich details page
                # used elsewhere (poster, metadata, actors, recommendations).
                # RECENT ADDED alone uses the user's saved movie-package filter
                # as its random recommendation pool. Normal packages are unchanged.
                _selected_cid=str(self.selectedCategory() or "").strip()
                _is_recent=(_selected_cid == "__recent_added__")
                _cid="" if _is_recent else str(detail_item.get("_source_category_id") or _selected_cid or "").strip()
                _scope="movies_recent_filtered" if _is_recent else "movies_package"
                detail_item["_source_scope"]=_scope
                detail_item["_source_server_id"]=_source_identity(self.source)
                if _cid:
                    detail_item["_source_category_id"]=_cid
                elif _is_recent:
                    detail_item.pop("_source_category_id", None)
                self.session.open(
                    MovieDetailsScreen,
                    self.source,
                    detail_item,
                    list(self.mediaItemsCurrent or []),
                    {"scope":_scope,"category_id":_cid,"items":list(self.mediaItemsCurrent or [])}
                )
                return

            # Non-VOD/Series fallback.
            if self.source.get("type") in ("xtream", "stalker"):
                url=get_source_client(self.source).stream_url(detail_item,self.kind)
            elif self.source.get("type")=="m3u":
                url=detail_item.get("url","")
            else:
                url=""
            if not url:
                raise Exception("لا يوجد رابط تشغيل")
            service_type = _stalker_service_type(self.source, self.kind) if self.source.get("type") == "stalker" else 4097
            service=eServiceReference(service_type,0,url)
            service.setName(detail_item.get("name") or detail_item.get("title") or "IPTV")
            detail_item["_source_type"] = self.source.get("type", "")
            detail_item["_source_key"] = _source_identity(self.source)
            detail_item["_kind"] = self.kind
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, service, detail_item)
        except Exception as e:
            self.session.open(MessageBox,"تعذر التشغيل:\n%s"%e,MessageBox.TYPE_ERROR)



FAVOURITES_SKIN = '''<screen name="TiviMateFavorites" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#10151D">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#10151D" zPosition="0" />
    <eLabel position="0,0" size="1920,108" backgroundColor="#182330" zPosition="1" />
    <eLabel position="0,107" size="1920,2" backgroundColor="#65D7F3" zPosition="2" />
    <widget name="title" position="72,24" size="600,60" font="Regular;42" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="filter" position="1350,35" size="500,42" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="featuredTitle" position="75,160" size="1050,54" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="status" position="75,216" size="1725,52" font="Regular;25" foregroundColor="#C7D3DF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="75,278" size="1725,34" text="TIP: ON A MOVIE OR TV SHOW POSTER, HOLD YELLOW TO ADD TO FAVORITES" font="Regular;21" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="list" position="-20,-20" size="1,1" itemHeight="1" scrollbarMode="showNever" />
    <widget name="poster0" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle0" position="105,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster1" position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="367,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle1" position="367,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster2" position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="629,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle2" position="629,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster3" position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="891,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle3" position="891,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster4" position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1153,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle4" position="1153,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster5" position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <ePixmap position="1415,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/skin2_poster_frame.png" alphatest="blend" zPosition="5" />
    <widget name="posterTitle5" position="1415,654" size="230,55" font="Regular;21" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="posterSelector" position="105,344" size="230,300" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_focus_r121.png" alphatest="blend" zPosition="12" />
    <eLabel position="0,936" size="1920,144" backgroundColor="#182330" zPosition="2" />
    <eLabel position="72,966" size="330,50" text="OK  OPEN / PLAY" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="455,966" size="305,50" text="RED  REMOVE" font="Regular;25" foregroundColor="#FF8A87" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="825,966" size="350,50" text="YELLOW  FILTER" font="Regular;25" foregroundColor="#FFE383" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1240,966" size="340,50" text="BLUE  REFRESH" font="Regular;25" foregroundColor="#8EE7FF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <eLabel position="1640,966" size="220,50" text="EXIT  BACK" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="keys" position="75,1026" size="1770,34" font="Regular;21" foregroundColor="#9EAFBF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="4" />
</screen>'''

FAVOURITES_SKIN = scale_skin(FAVOURITES_SKIN)


class FavoritesScreen(Screen):
    """Full-screen local Favorite library for live channels, movies, and series."""
    skin = FAVOURITES_SKIN
    FILTERS = ((tr("ALL"), ""), (tr("LIVE"), "live"), (tr("MOVIES"), "vod"), (tr("TV SHOWS"), "series"))
    KIND_LABELS = {"live": tr("LIVE"), "vod": tr("MOVIE"), "series": tr("SERIES")}
    POSTER_X = (105, 367, 629, 891, 1153, 1415)
    POSTER_Y = 344
    PAGE_SIZE = 6

    def __init__(self, session):
        Screen.__init__(self, session)
        self.filterIndex = 0
        self.records = []
        self.pageStart = 0
        self.posterIndex = 0
        self.picloads = []
        self._poster_artwork_requests = {}
        self["title"] = Label(tr("Favorite"))
        self["filter"] = Label("")
        self["featuredTitle"] = Label(tr("YOUR SAVED CONTENT"))
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["keys"] = Label(tr("ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES"))
        for slot in range(self.PAGE_SIZE):
            self["poster%d" % slot] = Pixmap()
            self["posterTitle%d" % slot] = Label("")
        self["posterSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.openCurrent, "cancel": self.close,
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "red": self.removeCurrent, "yellow": self.nextFilter, "blue": self.reload,
            "menu": self.nextFilter
        }, -1)
        self.onLayoutFinish.append(self.reload)

    def _currentRecord(self):
        index = self.pageStart + self.posterIndex
        if 0 <= index < len(self.records):
            return self.records[index]
        return None

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(
                "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png"
            )
        except Exception:
            pass

    def _recordTitle(self, record):
        item = record.get("item") or {}
        return item.get("name") or record.get("title") or item.get("title") or "IPTV"

    def _recordArtwork(self, record):
        item = record.get("item") or {}
        return item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("cover_big") or ""

    def reload(self):
        label, kind = self.FILTERS[self.filterIndex]
        self.records = list_favourites(kind or None)
        self.pageStart = 0
        self.posterIndex = 0
        rows = [(self._recordTitle(record), record) for record in self.records]
        self["list"].setList(rows)
        self["filter"].setText("%s: %s" % (tr("Filter"), label))
        self.renderPosterPage()

    def renderPosterPage(self):
        for slot in range(self.PAGE_SIZE):
            index = self.pageStart + slot
            record = self.records[index] if index < len(self.records) else None
            self._setVisible("poster%d" % slot, bool(record))
            self._setVisible("posterTitle%d" % slot, bool(record))
            if not record:
                try:
                    self["posterTitle%d" % slot].setText(tr(""))
                except Exception:
                    pass
                continue
            title = self._recordTitle(record)
            kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
            self["posterTitle%d" % slot].setText(("%s\n%s" % (kind, title))[:42])
            self._setPlaceholder(slot)
            artwork = self._recordArtwork(record)
            if artwork:
                self._loadPoster(slot, artwork)
            else:
                self._loadFavouriteTmdbPoster(slot, record)
        prefetch_artwork([self._recordArtwork(record) for record in list(self.records or []) if self._recordArtwork(record)], "posters", priority=2)
        self._setVisible("posterSelector", bool(self.records))
        self._moveSelector()
        self._updateStatus()

    def _loadFavouriteTmdbPoster(self, slot, record):
        item = (record or {}).get("item") or {}
        title = self._recordTitle(record or {})
        kind = "series" if (record or {}).get("kind") == "series" else "vod"
        if not title:
            return
        token = "tmdb:%s:%s" % (kind, title)
        self._poster_artwork_requests[slot] = token
        def worker():
            try:
                raw_year = item.get("year") or item.get("releaseDate") or item.get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                found = TMDbClient().search_artwork(title, kind, match.group(0) if match else None, required_key="poster_path") or {}
                path = found.get("poster_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(path)
                def apply():
                    if self._poster_artwork_requests.get(slot) != token:
                        return
                    self._loadPoster(slot, url)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateFavouriteTMDB")
        thread.daemon = True
        thread.start()

    def _loadPoster(self, slot, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._poster_artwork_requests[slot] = url
        def done(path, s=slot, expected=url):
            if self._poster_artwork_requests.get(s) != expected:
                return
            self._decodePoster(s, path)
        request_artwork(url, "posters", done, priority=55)

    def _decodePoster(self, slot, path):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, current=loader):
            try:
                ptr = current.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
            except Exception:
                pass
            try:
                if current in self.picloads:
                    self.picloads.remove(current)
            except Exception:
                pass
        try:
            connect_picture_data(loader, ready, self)
        except Exception:
            try:
                loader.PictureData.connect(ready)
            except Exception:
                pass
        try:
            render_width, render_height = scale_size(230, 300)
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def _moveSelector(self):
        if not self.records:
            return
        try:
            self["posterSelector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(self.POSTER_Y)))
            self["posterSelector"].show()
        except Exception:
            pass

    def _updateStatus(self):
        total = len(self.records)
        record = self._currentRecord()
        if not record:
            self["status"].setText(tr("No saved items in this filter. Open a title and choose Add to My List."))
            return
        title = self._recordTitle(record)
        kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
        self["status"].setText("%s  •  %s     %d / %d" % (kind, title, self.pageStart + self.posterIndex + 1, total))

    def left(self):
        index = self.pageStart + self.posterIndex
        if index <= 0:
            return
        index -= 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def right(self):
        index = self.pageStart + self.posterIndex
        if index >= len(self.records) - 1:
            return
        index += 1
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def up(self):
        index = self.pageStart + self.posterIndex
        if index < self.PAGE_SIZE:
            return
        index -= self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def down(self):
        index = self.pageStart + self.posterIndex
        if index + self.PAGE_SIZE >= len(self.records):
            return
        index += self.PAGE_SIZE
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def nextFilter(self):
        self.filterIndex = (self.filterIndex + 1) % len(self.FILTERS)
        self.reload()

    def removeCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        if remove_record(record.get("id", "")):
            self.reload()
        else:
            self["status"].setText(tr("Unable to remove this Favorite."))

    def openCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        source = source_for_record(record, get_sources())
        if not source:
            self.session.open(MessageBox, "This item's source no longer exists. Press RED to remove it.", MessageBox.TYPE_INFO); return
        item = dict(record.get("item") or {})
        kind = record.get("kind")
        try:
            if kind == "live":
                self.session.open(TiviMateLivePlayer, source, [item], 0); return
            if kind == "series":
                if source.get("type") != "xtream":
                    raise Exception("Series require an Xtream Codes source")
                self.session.open(SeriesDetailsScreen, source, item); return
            if source.get("type") == "xtream":
                url = XtreamClient(source).stream_url(item, "vod")
            elif source.get("type") in ("m3u", "fg"):
                url = item.get("url", "")
            else:
                url = StalkerClient(source).stream_url(item, "vod")
            if not url:
                raise Exception("No playable URL")
            service = eServiceReference(4097, 0, url)
            service.setName(item.get("name") or item.get("title") or "IPTV")
            self.session.open(TiviMatePlayer, service, item); return
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)

