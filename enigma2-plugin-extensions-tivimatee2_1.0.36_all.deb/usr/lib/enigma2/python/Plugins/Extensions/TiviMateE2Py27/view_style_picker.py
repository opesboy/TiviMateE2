# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
"""Four poster styles as 2x2 cards with a gold focus (same look as page design)."""
import os
import json
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from .display_scale import scale_skin, sx, sy
from enigma import ePoint

_STYLE_FILE = '/etc/enigma2/tivimatee2/view_style_choices.json'
_CHOICES = ('circle', 'poster', 'genre', 'cinematic')
_BASE = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/view_picker'
_UI = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker'
_CARDS = ((210, 150), (990, 150), (210, 620), (990, 620))
_CW, _CH = 720, 405

def get_style(context, kind):
    try:
        with open(_STYLE_FILE, 'r') as handle:
            values = json.load(handle)
        style = values.get('%s:%s' % (context, kind), 'genre' if context == 'genre' else 'poster')
        return style if style in _CHOICES else 'poster'
    except Exception:
        return 'genre' if context == 'genre' else 'poster'


def save_style(context, kind, style):
    if style not in _CHOICES:
        return False
    try:
        try:
            with open(_STYLE_FILE, 'r') as handle:
                values = json.load(handle)
            if not isinstance(values, dict):
                values = {}
        except Exception:
            values = {}
        values['%s:%s' % (context, kind)] = style
        folder = os.path.dirname(_STYLE_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = _STYLE_FILE + '.tmp'
        with open(temporary, 'w') as handle:
            json.dump(values, handle)
        atomic_replace(temporary, _STYLE_FILE)
        return True
    except Exception:
        return False


class PosterViewPicker(Screen):
    """2x2 poster-style cards: gold glowing focus, dimmed others, ACTIVE badge."""
    skin = scale_skin(
        '<screen name="PosterViewPicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05060A">'
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s/style_picker_bg.jpg" alphatest="off" scale="1" zPosition="1" />' % _BASE
        + ''.join('<widget name="dim%d" position="%d,%d" size="%d,%d" pixmap="%s/picker_dim.png" alphatest="blend" scale="1" zPosition="2" />'
                  % (i, x, y, _CW, _CH, _UI) for i, (x, y) in enumerate(_CARDS))
        + '<widget name="selectionGold" position="%d,%d" size="%d,%d" pixmap="%s/picker_focus.png" alphatest="blend" scale="1" zPosition="3" />'
          % (_CARDS[0][0] - 20, _CARDS[0][1] - 20, _CW + 40, _CH + 40, _UI)
        + '<widget name="activeBadge" position="%d,%d" size="150,40" pixmap="%s/picker_active.png" alphatest="blend" scale="1" zPosition="4" />'
          % (_CARDS[0][0] + _CW - 166, _CARDS[0][1] + 16, _UI)
        + '</screen>')

    def __init__(self, session, context='genre', kind='vod'):
        Screen.__init__(self, session)
        self.context = context
        self.kind = kind
        self.index = _CHOICES.index(get_style(context, kind))
        self.active = self.index
        self._closing = False
        for i in range(len(_CARDS)):
            self['dim%d' % i] = Pixmap()
        self['selectionGold'] = Pixmap()
        self['activeBadge'] = Pixmap()
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions',
            'ChannelSelectBaseActions', 'InfobarChannelSelection'], {
            'ok': self.accept, 'cancel': self.cancel,
            'left': self.left, 'right': self.right, 'up': self.up, 'down': self.down,
            'pageUp': self.previous, 'pageDown': self.next,
            'channelUp': self.previous, 'channelDown': self.next,
            'prevBouquet': self.previous, 'nextBouquet': self.next
        }, -1)
        self.onLayoutFinish.append(self.prepare)

    def prepare(self):
        if self._closing:
            return
        try:
            x, y = _CARDS[self.active]
            self['activeBadge'].instance.move(ePoint(sx(x + _CW - 166), sy(y + 16)))
            self['activeBadge'].show()
        except Exception:
            pass
        self.refresh()

    def refresh(self):
        if self._closing:
            return
        try:
            x, y = _CARDS[self.index]
            self['selectionGold'].instance.move(ePoint(sx(x - 20), sy(y - 20)))
            self['selectionGold'].show()
            for i in range(len(_CARDS)):
                if i == self.index:
                    self['dim%d' % i].hide()
                else:
                    self['dim%d' % i].show()
        except Exception:
            pass

    def left(self):
        self.previous()

    def right(self):
        self.next()

    def up(self):
        self.index = (self.index - 2) % len(_CHOICES)
        self.refresh()

    def down(self):
        self.index = (self.index + 2) % len(_CHOICES)
        self.refresh()

    def previous(self):
        self.index = (self.index - 1) % len(_CHOICES)
        self.refresh()

    def next(self):
        self.index = (self.index + 1) % len(_CHOICES)
        self.refresh()

    def cancel(self):
        if self._closing:
            return
        self._closing = True
        self.close(None)

    def accept(self):
        if self._closing:
            return
        self._closing = True
        chosen = _CHOICES[self.index]
        save_style(self.context, self.kind, chosen)
        self.close(chosen)
