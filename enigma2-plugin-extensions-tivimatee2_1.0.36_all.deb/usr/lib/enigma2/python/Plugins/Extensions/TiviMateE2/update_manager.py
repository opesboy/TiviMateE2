# -*- coding: utf-8 -*-
"""Safe, optional update checks for TiviMateE2 on Enigma2 images.

The updater retrieves only a small public JSON manifest over HTTPS.  It never
reads playlists, account data, API keys, favourites, or any local settings.
Package installation is started only after the user explicitly confirms it.
"""

import hashlib
import json
import os
import re

from urllib.request import Request, urlopen, build_opener, HTTPRedirectHandler
from urllib.parse import urlparse

from shlex import quote as shell_quote

text_type = str

PLUGIN_VERSION = "1.0.36"
# Internal update sequence only; the user-facing plugin version is PLUGIN_VERSION.
CURRENT_REVISION = 145
MANIFEST_URL = "https://raw.githubusercontent.com/opesboy/TiviMateE2/main/update.json"
MANIFEST_MAX_BYTES = 64 * 1024
PACKAGE_MAX_BYTES = 100 * 1024 * 1024
REQUEST_TIMEOUT = 10
USER_AGENT = "TiviMateE2/%s" % PLUGIN_VERSION
REPOSITORY_PREFIX = "https://github.com/opesboy/TiviMateE2/"
RAW_REPOSITORY_PREFIX = "https://raw.githubusercontent.com/opesboy/TiviMateE2/"


def _text(value):
    if value is None:
        return ""
    if isinstance(value, text_type):
        return value
    try:
        return value.decode("utf-8")
    except Exception:
        try:
            return text_type(value)
        except Exception:
            return ""


def _clean_message(value, limit=800):
    value = _text(value).replace("\r", " ").replace("\x00", " ")
    value = "\n".join([line.strip() for line in value.split("\n") if line.strip()])
    return value[:limit]


def _read_url(url, maximum):
    if url != MANIFEST_URL:
        raise ValueError("Untrusted update URL")
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    response = build_opener(_NoRedirect()).open(request, timeout=REQUEST_TIMEOUT)
    try:
        data = response.read(maximum + 1)
    finally:
        try:
            response.close()
        except Exception:
            pass
    if len(data) > maximum:
        raise ValueError("Update response is too large")
    return data


def _normalise_url(value):
    value = _text(value).strip()
    try:
        parsed = urlparse(value)
    except Exception:
        return ""
    if parsed.scheme != "https" or not parsed.netloc or parsed.username or parsed.password:
        return ""
    if parsed.port or parsed.params or parsed.query or parsed.fragment:
        return ""
    return value


class _NoRedirect(HTTPRedirectHandler):
    """Do not follow an update-server redirect to an untrusted host/path."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Update redirect rejected")


def _trusted_package_url(value):
    value = _normalise_url(value)
    if not value:
        return ""
    parsed = urlparse(value)
    if ".." in [part for part in parsed.path.split("/") if part]:
        return ""
    if parsed.hostname == "github.com" and parsed.path.startswith("/opesboy/TiviMateE2/"):
        return value
    if parsed.hostname == "raw.githubusercontent.com" and parsed.path.startswith("/opesboy/TiviMateE2/"):
        return value
    return ""


def package_type():
    """Return the package format used by the current Enigma2 image."""
    if os.path.exists("/usr/bin/dpkg") or os.path.exists("/bin/dpkg"):
        return "deb"
    if os.path.exists("/usr/bin/opkg") or os.path.exists("/bin/opkg"):
        return "ipk"
    return ""


def _package_from_manifest(manifest, fmt):
    packages = manifest.get("packages") or {}
    package = packages.get(fmt) or {}
    if not isinstance(package, dict):
        return None
    url = _trusted_package_url(package.get("url"))
    checksum = _text(package.get("sha256")).lower().strip()
    if not url or not re.match(r"^[a-f0-9]{64}$", checksum):
        return None
    return {
        "format": fmt,
        "url": url,
        "sha256": checksum,
        "filename": "tivimatee2_update_%s.%s" % (int(manifest["revision"]), fmt),
    }


def check_for_update():
    """Fetch and validate the public manifest without raising user-facing errors."""
    result = {"available": False, "reason": "unavailable"}
    try:
        raw = _read_url(MANIFEST_URL, MANIFEST_MAX_BYTES)
        try:
            raw = raw.decode("utf-8")
        except Exception:
            pass
        manifest = json.loads(raw)
        if not isinstance(manifest, dict):
            return result
        revision = int(manifest.get("revision", 0))
        # A newer revision may offer an update under the same public version.
        # Skip only when the manifest revision is not newer than installed.
        if revision <= CURRENT_REVISION:
            result["reason"] = "current"
            return result
        fmt = package_type()
        package = _package_from_manifest(manifest, fmt)
        if not package:
            result["reason"] = "no_package"
            return result
        result.update({
            "available": True,
            "reason": "available",
            "revision": revision,
            "version": _clean_message(manifest.get("version") or "1.0.3", 64),
            "notes": _clean_message(manifest.get("notes") or "", 800),
            "package": package,
        })
    except Exception:
        # No popup is shown for transient network, TLS, or server errors.
        pass
    return result


def cleanup_update_package(result=None):
    """Delete only our own temporary update packages (never playlist/cache files)."""
    allowed = ("/tmp/tivimatee2_update.ipk", "/tmp/tivimatee2_update.deb")
    path = _text((result or {}).get("path")) if isinstance(result, dict) else ""
    if path and path not in allowed:
        return
    for target in ((path,) if path else allowed):
        for current in (target, target + ".part"):
            try:
                os.unlink(current)
            except OSError:
                pass


def download_package(package):
    """Download a selected package to /tmp and verify its SHA-256 digest."""
    destination = ""
    temporary = ""
    try:
        if not isinstance(package, dict):
            raise ValueError("Invalid update package")
        url = _trusted_package_url(package.get("url"))
        expected = _text(package.get("sha256")).lower().strip()
        fmt = _text(package.get("format")).lower().strip()
        if not url or fmt not in ("deb", "ipk") or not re.match(r"^[a-f0-9]{64}$", expected):
            raise ValueError("Invalid update package")
        destination = os.path.join("/tmp", "tivimatee2_update.%s" % fmt)
        temporary = destination + ".part"
        # A previous failed install must not leave an obsolete package behind.
        cleanup_update_package({"path": destination})
        request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/octet-stream"})
        response = build_opener(_NoRedirect()).open(request, timeout=REQUEST_TIMEOUT)
        digest = hashlib.sha256()
        total = 0
        try:
            handle = open(temporary, "wb")
            try:
                while True:
                    block = response.read(65536)
                    if not block:
                        break
                    total += len(block)
                    if total > PACKAGE_MAX_BYTES:
                        raise ValueError("Update package is too large")
                    handle.write(block)
                    digest.update(block)
            finally:
                handle.close()
        finally:
            try:
                response.close()
            except Exception:
                pass
        if total < 1024 or digest.hexdigest().lower() != expected:
            try:
                os.unlink(temporary)
            except OSError:
                pass
            raise ValueError("Update verification failed")
        try:
            os.unlink(destination)
        except OSError:
            pass
        os.rename(temporary, destination)
        return {"ok": True, "path": destination, "format": fmt}
    except Exception as error:
        if destination:
            cleanup_update_package({"path": destination})
        return {"ok": False, "message": _clean_message(error, 160) or "Download failed"}


def install_command(result):
    """Create the forced reinstall command for the already verified package."""
    path = _text((result or {}).get("path"))
    fmt = _text((result or {}).get("format")).lower()
    if not path or not os.path.isfile(path):
        return ""
    quoted = shell_quote(path)
    if fmt == "deb":
        installer = "dpkg -i %s" % quoted
    elif fmt == "ipk":
        installer = "opkg install --force-reinstall %s" % quoted
    else:
        return ""
    # eConsoleAppContainer executes this in /bin/sh. Preserve the installer
    # exit status but always remove the verified archive afterwards, even when
    # installation fails; the package is never needed again after it exits.
    return '%s; update_status=$?; rm -f %s; exit "$update_status"' % (installer, quoted)


UPDATE_STATUS_FILE = "/tmp/tivimatee2_update.status"

_CONSOLE_BANNER = (
    " _____  _         _  __  __         _\n"
    "|_   _|(_)__   __(_)|  \\/  |  __ _ | |_   ___\n"
    "  | |  | |\\ \\ / /| || |\\/| | / _` || __| / _ \\\n"
    "  | |  | | \\ V / | || |  | || (_| || |_ |  __/\n"
    "  |_|  |_|  \\_/  |_||_|  |_| \\__,_| \\__| \\___|\n"
    "        _____  ____\n"
    "       | ____||___ \\\n"
    "       |  _|    __) |\n"
    "       | |___  / __/\n"
    "       |_____||_____|\n"
    "\n"
    "     TiviMate - online installer\n"
    "--------------------------------------------\n"
)


def console_install_command(result, version=""):
    """r146: the same install as install_command(), printed step by step in
    the Enigma2 Console screen (TiviMate banner, image, space, version)."""
    command = install_command(result)
    if not command:
        return ""
    path = _text((result or {}).get("path"))
    quoted = shell_quote(path)
    status = shell_quote(UPDATE_STATUS_FILE)
    version = _clean_message(version or PLUGIN_VERSION, 40) or PLUGIN_VERSION
    banner = shell_quote(_CONSOLE_BANNER)
    lines = [
        "rm -f %s" % status,
        "printf '%%s' %s" % banner,
        'IMG=""',
        'if [ -f /etc/image-version ]; then D=$(grep -i "^distro=" /etc/image-version | head -n1 | cut -d= -f2); '
        'V=$(grep -iE "^(imageversion|version)=" /etc/image-version | head -n1 | cut -d= -f2); [ -n "$D" ] && IMG="$D $V"; fi',
        '[ -z "$IMG" ] && [ -f /etc/vtiversion.info ] && IMG="VTi $(head -n1 /etc/vtiversion.info)"',
        '[ -z "$IMG" ] && [ -f /etc/issue ] && IMG=$(head -n1 /etc/issue | sed \'s/[\\\\].//g\' | tr -s " ")',
        '[ -z "$IMG" ] && IMG="Enigma2"',
        'printf "%s\\n" "[ OK ] Image: ${IMG% }  (supported)"',
        'echo "[ .. ] Free space: download area $(df -k /tmp | awk \'NR>1{v=$(NF-2)} END{print v+0}\') kB, '
        'receiver flash $(df -k /usr | awk \'NR>1{v=$(NF-2)} END{print v+0}\') kB"',
        'echo "[ .. ] Latest version: %s"' % version.replace('"', ''),
        'echo "[ OK ] Package downloaded and verified ($(( $(wc -c < %s) / 1024 )) kB)"' % quoted,
        'echo "[ .. ] Installing the package ..."',
        "( %s ) >/dev/null 2>&1; update_status=$?" % command,
        'if [ "$update_status" = "0" ]; then echo "[ OK ] TiviMate %s installed"; '
        'echo "--------------------------------------------"; '
        'echo "[ .. ] Restarting Enigma2 in 3 seconds ..."; sleep 3; '
        'else echo "[FAIL] Install failed - your current version was not changed"; fi' % version.replace('"', ''),
        'echo "$update_status" > %s' % status,
    ]
    return "\n".join(lines)


def read_update_status():
    try:
        with open(UPDATE_STATUS_FILE) as handle:
            value = int((handle.read() or "1").strip() or 1)
    except Exception:
        value = 1
    try:
        os.unlink(UPDATE_STATUS_FILE)
    except OSError:
        pass
    return value


def open_update_console(session, result, candidate, finished):
    """r146: show the install in Enigma2's Console screen, styled like the
    online installer. finished(status) runs once when the commands end."""
    candidate = candidate if isinstance(candidate, dict) else {}
    version = _text(candidate.get("version") or PLUGIN_VERSION)
    revision = candidate.get("revision")
    if revision and ("-r" not in version):
        version = "%s-r%s" % (version, revision)
    command = console_install_command(result, version)
    if not command:
        return False
    from Screens.Console import Console
    title = "Updating TiviMate to %s - please wait" % version
    state = {"done": False}

    def done(*args):
        if state["done"]:
            return
        state["done"] = True
        finished(read_update_status())
    try:
        session.open(Console, title=title, cmdlist=[command],
                     finishedCallback=done, closeOnSuccess=False)
    except TypeError:
        session.open(Console, title, [command], done, False)
    return True
