# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import json_dump_text
import io
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
"""Optional genuine fanart.tv *banner* artwork for Movies and TV Shows.

Only `moviebanner` and `tvbanner` are accepted. We deliberately never use
TMDb backdrop_path, image stills, moviebackground or fanart as replacements.
Fetch functions are called only on the existing content-home worker thread.
"""
import hashlib
import json
import os
import time
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode, urlsplit
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import HTTPError

from .storage import data_path
from .cache_manager import get_cache_dir

KEY_FILE = data_path("fanart_tv.json")
API_BASE = "https://webservice.fanart.tv/v3"


def read_key():
    try:
        with io.open(KEY_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        return str(data.get("api_key") or "").strip() if isinstance(data, dict) else ""
    except Exception:
        return ""


def save_key(value):
    value = str(value or "").strip()
    if value and (len(value) > 256 or any(ch.isspace() for ch in value)):
        return False
    try:
        parent = os.path.dirname(KEY_FILE)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        temp = KEY_FILE + ".tmp"
        with io.open(temp, "w", encoding="utf-8") as fh:
            json_dump_text({"api_key": value}, fh)
        os.chmod(temp, 0o600)
        atomic_replace(temp, KEY_FILE)
        return True
    except Exception:
        return False


def _valid_banner_url(value):
    """Reject non-http URLs and unrecognised hosts from JSON payloads."""
    try:
        url = str(value or "").strip()
        parsed = urlsplit(url)
        host = str(parsed.hostname or "").lower()
        if parsed.scheme not in ("https", "http") or not host:
            return ""
        if host not in ("assets.fanart.tv", "fanart.tv") and not host.endswith(".fanart.tv"):
            return ""
        return url
    except Exception:
        return ""


def pick_banner(payload, media, language="en"):
    """Select a genuine banner by source field and preferred image language."""
    key = "tvbanner" if str(media).lower() in ("tv", "series") else "moviebanner"
    rows = (payload or {}).get(key) or [] if isinstance(payload, dict) else []
    wanted = str(language or "en").split("-")[0].split("_")[0].lower()
    options = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        url = _valid_banner_url(row.get("url"))
        if not url:
            continue
        lang = str(row.get("lang") or "").lower()
        rank = 3 if lang == wanted else 2 if lang == "en" else 1 if lang in ("00", "", "null") else 0
        try:
            likes = int(row.get("likes") or 0)
        except (TypeError, ValueError):
            likes = 0
        options.append(((rank, likes), url))
    return max(options, key=lambda value: value[0])[1] if options else ""


def _metadata_file(media, media_id, key):
    family = "tv" if media == "tv" else "movie"
    # A key change must invalidate old negative lookups without persisting the key.
    key_id = hashlib.sha256(key.encode("utf-8")).hexdigest()[:12]
    return os.path.join(get_cache_dir("metadata"),
                        "fanart_banner_%s_%s_%s.json" % (family, media_id, key_id))


def _read_cache(path):
    try:
        with io.open(path, "r", encoding="utf-8") as fh:
            entry = json.load(fh)
        url = _valid_banner_url(entry.get("url")) if isinstance(entry, dict) else ""
        max_age = 7 * 86400 if url else 86400
        if time.time() - float(entry.get("checked") or 0) <= max_age:
            return url
    except Exception:
        pass
    return None


def _write_cache(path, url):
    try:
        with io.open(path + ".tmp", "w", encoding="utf-8") as fh:
            json_dump_text({"checked": time.time(), "url": url}, fh)
        atomic_replace(path + ".tmp", path)
    except Exception:
        pass


def _get_json(url):
    # Callers run on a background worker. Never log the URL: it contains a key.
    req = Request(url, headers={"User-Agent": "TiviMateE2/1.0.32", "Accept": "application/json"})
    with urlopen(req, timeout=7) as response:
        data = response.read(1024 * 1024 + 1)
    if len(data) > 1024 * 1024:
        return None
    return json.loads(data.decode("utf-8"))


def fetch_banner(client, kind, tmdb_id, bundle=None, language="en"):
    """Fetch banner by TMDb movie ID, or TVDB series ID via TMDb external_ids."""
    api_key = read_key()
    if not api_key:
        return ""
    try:
        tid = int(str(tmdb_id or "").strip())
        if tid <= 0:
            return ""
    except (ValueError, TypeError):
        return ""
    media = "tv" if str(kind or "").lower() in ("tv", "series") else "movie"
    external = (bundle or {}).get("external_ids") or {}
    external = external if isinstance(external, dict) else {}
    if media == "tv":
        tvdb_id = (bundle or {}).get("tvdb_id") or external.get("tvdb_id")
        if not tvdb_id:
            # Fanart.tv indexes TV by TVDB ID, *not* TMDb TV ID.
            try:
                ext = client._get("/tv/%d/external_ids" % tid, {}) or {}
                tvdb_id = ext.get("tvdb_id")
            except Exception:
                return ""
        try:
            media_id = str(int(str(tvdb_id).strip()))
        except (ValueError, TypeError):
            return ""
    else:
        media_id = str(tid)
    cache_path = _metadata_file(media, media_id, api_key)
    cached = _read_cache(cache_path)
    if cached is not None:
        return cached
    endpoint = "%s/%s/%s?" % (API_BASE, "tv" if media == "tv" else "movies", media_id)
    # Fanart.tv supports personal keys as client_key and project keys as api_key.
    try:
        try:
            payload = _get_json(endpoint + urlencode({"client_key": api_key}))
        except HTTPError as exc:
            if getattr(exc, "code", 0) not in (401, 403):
                raise
            payload = _get_json(endpoint + urlencode({"api_key": api_key}))
        if not isinstance(payload, dict):
            return ""
        selected = pick_banner(payload, media, language)
        _write_cache(cache_path, selected)
        return selected
    except Exception:
        # Network and authentication failures never poison the negative cache.
        return ""
