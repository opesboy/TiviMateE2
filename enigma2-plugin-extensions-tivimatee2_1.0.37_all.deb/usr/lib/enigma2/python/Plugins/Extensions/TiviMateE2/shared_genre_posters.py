# -*- coding: utf-8 -*-
"""GENRE poster discovery shared by Classic, Search and Movies/TV Shows.

Use GENRE's exact provider candidates, placeholder checks, detail extraction,
verified TMDb matching, download transport and persistent image cache.
Only visible cards are scheduled; no new log files or unbounded threads.
"""
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor

from .artwork_queue import cached_artwork, is_app_exiting
from .genre_ultra_artwork import _download as genre_download, _clean_url
from .poster_manager import tmdb_poster_url

_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix='TiviSharedGenrePosters')
_DETAIL_LIMIT = threading.BoundedSemaphore(2)
_QUEUE_LIMIT = threading.BoundedSemaphore(36)


def _usable(path, placeholder_test, portrait_only=False):
    try:
        if not path or not os.path.isfile(path) or os.path.getsize(path) < 128:
            return False
        with open(path, 'rb') as handle:
            header = handle.read(12)
        if not (header.startswith(b'\xff\xd8\xff') or
                header.startswith(b'\x89PNG\r\n\x1a\n') or
                (header[:4] == b'RIFF' and header[8:12] == b'WEBP')):
            return False
        if portrait_only:
            from .artwork_orientation import portrait_file
            if not portrait_file(path):
                return False
        return not placeholder_test(path)
    except Exception:
        return False


def _tmdb_artwork(item, kind):
    from .genre_page import StandaloneGenreScreen
    from .tmdb_client import TMDbClient
    from .title_cleaning import clean_series_label
    row = item or {}
    title = clean_series_label(str(row.get('name') or row.get('title') or '').strip())
    if not title:
        return ''
    year_text = ' '.join(str(row.get(key) or '') for key in
                         ('year', 'releaseDate', 'release_date', 'first_air_date'))
    match = re.search(r'\b(?:19|20)\d{2}\b', year_text)
    year = match.group(0) if match else ''
    client = TMDbClient()
    url = StandaloneGenreScreen._verified_tmdb_poster(client, row, kind, title, year)
    if not url:
        found = client.search_artwork(title, kind, year or None, required_key='poster_path') or {}
        url = found.get('poster_path') or ''
    if not url:
        found = client.search_title(title, kind, year or None) or {}
        tmdb_id = str(found.get('id') or found.get('tmdb_id') or '').strip()
        if tmdb_id.isdigit():
            url = StandaloneGenreScreen._verified_tmdb_poster(
                client, {'tmdb_id': tmdb_id}, kind, title, year)
    return tmdb_poster_url(url)


def _detail_candidate(source, item, kind):
    from .genre_page import _genre_provider_artwork
    from .core import get_source_client
    source = source or {}
    if str(source.get('type') or '').lower() not in ('xtream', 'stalker'):
        return ''
    media_id = str(item.get('series_id' if kind == 'series' else 'stream_id') or
                   item.get('vod_id') or item.get('id') or '').strip()
    if not media_id or not _DETAIL_LIMIT.acquire(False):
        return ''
    try:
        client = get_source_client(source)
        if str(source.get('type') or '').lower() == 'stalker' and callable(
                getattr(client, 'genre_fresh_artwork_info', None)):
            data = client.genre_fresh_artwork_info(media_id, kind)
        else:
            data = client.series_info(media_id) if kind == 'series' else client.vod_info(media_id)
        poster, unused_backdrop = _genre_provider_artwork(source, data or {})
        return poster
    except Exception:
        return ''
    finally:
        _DETAIL_LIMIT.release()


_WINNERS = {}


def _winner_key(provider, item, kind, primary, portrait_only):
    try:
        ident = (item.get('stream_id') or item.get('series_id') or item.get('id') or
                 item.get('_tmdb_id') or item.get('tmdb_id') or item.get('name') or item.get('title'))
        if not ident:
            return None
        return (str(provider.get('url') or provider.get('path') or ''), kind,
                u'%s' % ident, u'%s' % (primary or ''), bool(portrait_only))
    except Exception:
        return None


def request_genre_poster(source, item, kind, ready, failed=None,
                         cancelled=None, primary='', callback_gui=None,
                         portrait_only=False):
    """Search exactly as GENRE; ready(path, winning_url) runs on GUI thread.

    cancelled must reject stale page/slot/selection without touching widgets.
    callback_gui may be an owning screen's _queueGui dispatcher.
    """
    snapshot = dict(item or {})
    provider = dict(source or {})
    kind = 'series' if kind == 'series' else 'vod'
    cancelled = cancelled if callable(cancelled) else (lambda: False)

    def on_gui(callback, *args):
        if cancelled() or is_app_exiting():
            return
        if callable(callback_gui):
            callback_gui(callback, *args)
            return
        try:
            from twisted.internet import reactor
            reactor.callFromThread(callback, *args)
        except Exception:
            # Painting Enigma2 from a worker thread is unsafe.
            return

    def worker():
        from .genre_page import (_genre_provider_poster_urls,
                                 _provider_image_is_placeholder)
        def dead():
            return cancelled() or is_app_exiting()
        try:
            if dead():
                return
            candidates = list(_genre_provider_poster_urls(provider, snapshot, kind))
            # TMDb Home picks already have an identity-matched TMDb poster.
            # A relative TMDb poster_path must NEVER become an IPTV-server URL.
            tmdb_feed = bool(snapshot.get('_home_tmdb_feed') or snapshot.get('_tmdb'))
            direct_tmdb = tmdb_poster_url(snapshot.get('_tmdb_poster')) if tmdb_feed else ''
            if tmdb_feed and not direct_tmdb:
                direct_tmdb = tmdb_poster_url(snapshot.get('poster_path'))
            if primary:
                from .artwork_queue import provider_asset_url
                resolved = (tmdb_poster_url(primary) if (tmdb_feed and
                            str(primary).startswith('/')) else
                            provider_asset_url(provider, primary))
                if resolved and resolved not in candidates:
                    candidates.insert(0, resolved)
            if direct_tmdb and direct_tmdb in candidates:
                candidates.remove(direct_tmdb)
            if direct_tmdb:
                candidates.insert(0, direct_tmdb)
            from urllib.parse import urlsplit
            candidates = [candidate for candidate in candidates if not re.fullmatch(
                r'(?:no[_-]?(?:poster|image|title)|nopic|placeholder|default[_-]?poster)(?:[_-][a-z0-9]+)?\.(?:jpe?g|png|webp)',
                (urlsplit(candidate).path.rsplit('/', 1)[-1] or '').lower())]
            checked = set()
            candidates = [_clean_url(candidate) for candidate in candidates]
            candidates = [candidate for candidate in candidates if candidate]
            # All on-disk candidates first, before any HTTP requests.
            for url in candidates:
                if dead():
                    return
                cached = cached_artwork(url, 'posters')
                if cached and _usable(cached, _provider_image_is_placeholder, portrait_only):
                    on_gui(ready, cached, url)
                    return
            for url in candidates[:8]:
                if dead():
                    return
                if url in checked:
                    continue
                checked.add(url)
                try:
                    path = genre_download(url, 'posters', provider)
                    if _usable(path, _provider_image_is_placeholder, portrait_only):
                        on_gui(ready, path, url)
                        return
                except Exception:
                    continue
            if dead():
                return
            detail_url = _detail_candidate(provider, snapshot, kind)
            if detail_url and detail_url not in checked:
                try:
                    path = genre_download(detail_url, 'posters', provider)
                    if _usable(path, _provider_image_is_placeholder, portrait_only):
                        on_gui(ready, path, detail_url)
                        return
                except Exception:
                    pass
            if dead():
                return
            tmdb_url = _tmdb_artwork(snapshot, kind)
            if tmdb_url:
                path = genre_download(tmdb_url, 'posters', {})
                if _usable(path, _provider_image_is_placeholder, portrait_only):
                    on_gui(ready, path, tmdb_url)
                    return
        except Exception:
            pass
        if failed and not dead():
            on_gui(failed)

    if is_app_exiting() or cancelled():
        return False
    # Session memo: a poster already resolved for this title is shown again
    # at once instead of re-running the search on the 2-worker pool.
    memo_key = _winner_key(provider, snapshot, kind, primary, portrait_only)
    hit = _WINNERS.get(memo_key) if memo_key else None
    if hit:
        try:
            if os.path.isfile(hit[0]):
                on_gui(ready, hit[0], hit[1])
                return True
        except Exception:
            pass
        _WINNERS.pop(memo_key, None)
    if memo_key:
        user_ready = ready

        def ready(path, url, _key=memo_key, _ready=user_ready):
            if len(_WINNERS) > 3000:
                _WINNERS.clear()
            _WINNERS[_key] = (path, url)
            _ready(path, url)
    if not _QUEUE_LIMIT.acquire(blocking=False):
        return False
    def run():
        try:
            worker()
        finally:
            _QUEUE_LIMIT.release()
    try:
        _POOL.submit(run)
        return True
    except RuntimeError:
        _QUEUE_LIMIT.release()
        return False
