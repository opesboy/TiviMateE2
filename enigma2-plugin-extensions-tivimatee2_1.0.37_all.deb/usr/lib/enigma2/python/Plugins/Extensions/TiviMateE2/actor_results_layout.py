# -*- coding: utf-8 -*-
"""Keep actor-scoped provider results intact across poster style switches.

Actor results are already filtered against the active server's content.  A
change of visual skin must NOT convert this virtual result into a provider
category or start a new category download.

A real actor search (Movie/Series Details -> actor) passes the TMDb person
and opens the Actor Spotlight page by default.  Movie Parts and Other Sources
reuse this opener without a person and keep the four poster styles.
"""

_POSTER_STYLES = ('circle', 'poster', 'genre', 'cinematic')


def _actor_person(value, name):
    """Minimal TMDb person record for the Spotlight page, or None."""
    if not isinstance(value, dict):
        return None
    person_id = str(value.get('id') or '').strip()
    if not person_id.isdigit() or person_id == '0':
        return None
    return {'id': person_id, 'name': name,
            'profile_path': str(value.get('profile_path') or '')}


def open_actor_results(session, source, kind, actor_name, rows, style=None, actor=None):
    from .view_style_picker import get_style, get_actor_style
    kind = 'series' if kind == 'series' else 'vod'
    entries = [dict(row) for row in (rows or ()) if isinstance(row, dict)]
    if not entries:
        return False
    name = str(actor_name or 'Actor').strip() or 'Actor'
    view_source = dict(source or {})
    person = _actor_person(actor, name)
    if person is None:
        # Style switches pass the same source again.  A person left over from
        # an earlier actor page (Details -> Movie Parts) has another name.
        carried = view_source.get('_actor_search_person')
        if isinstance(carried, dict) and carried.get('name') == name:
            person = _actor_person(carried, name)
    if person is None:
        view_source.pop('_actor_search_person', None)
    else:
        view_source['_actor_search_person'] = person
    if style in _POSTER_STYLES or (style == 'spotlight' and person is not None):
        mode = style
    elif person is not None:
        mode = get_actor_style(kind)
    else:
        mode = get_style('actor', kind)
    view_source['_actor_search_rows'] = entries
    view_source['_actor_search_name'] = name
    view_source['_view_picker_context'] = 'actor'
    if mode == 'spotlight':
        try:
            from .actor_spotlight import ActorSpotlightScreen
        except Exception as exc:
            # Never lose the results because the new page cannot load.
            print("[TiviMateE2] Actor Spotlight unavailable: %s" % exc)
            mode = 'poster'
        else:
            session.open(ActorSpotlightScreen, view_source, kind, '')
            return True
    if mode == 'cinematic':
        from .cinematic_catalog import CinematicCatalogScreen
        session.open(CinematicCatalogScreen, view_source, kind, '')
    elif mode == 'genre':
        from .genre_page import StandaloneGenreScreen
        session.open(StandaloneGenreScreen, view_source, kind, '')
    else:
        from .ui import MediaScreen
        view_source['_view_style_override'] = 'circle' if mode == 'circle' else 'original'
        # The exact actor results are given to the original poster browser;
        # no replacement stream/catalogue fetch and no changes to its queue.
        session.open(MediaScreen, view_source, kind, None, name, entries)
    return True
