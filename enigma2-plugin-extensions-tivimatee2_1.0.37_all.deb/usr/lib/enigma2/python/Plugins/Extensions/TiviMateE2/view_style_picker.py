# -*- coding: utf-8 -*-
"""Four poster styles as 2x2 cards with a gold focus (same look as page design)."""
import os
import json
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from .display_scale import scale_skin, sx, sy
from enigma import ePoint

_STYLE_FILE = '/etc/enigma2/tivimatee2/view_style_choices.json'
_CHOICES = ('circle', 'poster', 'genre', 'cinematic')
_BASE = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/view_picker'
_UI = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/design_picker'
_CARDS = ((210, 150), (990, 150), (210, 620), (990, 620))
_CW, _CH = 720, 405
# Actor results only: a fifth choice in the header, the Actor Spotlight page.
_SPOT = 'spotlight'
_SPOT_ART = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor'
_SPOT_X, _SPOT_Y, _SPOT_W, _SPOT_H = 700, 46, 480, 60

def get_style(context, kind):
    try:
        with open(_STYLE_FILE, 'r') as handle:
            values = json.load(handle)
        style = values.get('%s:%s' % (context, kind), 'genre' if context == 'genre' else 'poster')
        return style if style in _CHOICES else 'poster'
    except Exception:
        return 'genre' if context == 'genre' else 'poster'


def get_actor_style(kind):
    """Real actor searches open Spotlight unless a poster style was chosen."""
    try:
        with open(_STYLE_FILE, 'r') as handle:
            values = json.load(handle)
        style = values.get('actor:%s' % kind)
    except Exception:
        style = None
    return style if style in _CHOICES else _SPOT


def save_style(context, kind, style):
    if style not in _CHOICES and not (style == _SPOT and context == 'actor'):
        return False
    try:
        try:
            with open(_STYLE_FILE, 'r') as handle:
                values = json.load(handle)
            if not isinstance(values, dict):
                values = {}
        except Exception:
            values = {}
        values['%s:%s' % (context, kind)] = style
        folder = os.path.dirname(_STYLE_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = _STYLE_FILE + '.tmp'
        with open(temporary, 'w') as handle:
            json.dump(values, handle)
        os.replace(temporary, _STYLE_FILE)
        return True
    except Exception:
        return False


class PosterViewPicker(Screen):
    """2x2 poster-style cards: gold glowing focus, dimmed others, ACTIVE badge."""
    skin = scale_skin(
        '<screen name="PosterViewPicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05060A">'
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s/style_picker_bg.jpg" alphatest="off" scale="1" zPosition="1" />' % _BASE
        + ''.join('<widget name="dim%d" position="%d,%d" size="%d,%d" pixmap="%s/picker_dim.png" alphatest="blend" scale="1" zPosition="2" />'
                  % (i, x, y, _CW, _CH, _UI) for i, (x, y) in enumerate(_CARDS))
        + '<widget name="selectionGold" position="%d,%d" size="%d,%d" pixmap="%s/picker_focus.png" alphatest="blend" scale="1" zPosition="3" />'
          % (_CARDS[0][0] - 20, _CARDS[0][1] - 20, _CW + 40, _CH + 40, _UI)
        + '<widget name="activeBadge" position="%d,%d" size="150,40" pixmap="%s/picker_active.png" alphatest="blend" scale="1" zPosition="4" />'
          % (_CARDS[0][0] + _CW - 166, _CARDS[0][1] + 16, _UI)
        + '<widget name="spotPill" position="%d,%d" size="%d,%d" pixmap="%s/picker_spot_pill.png" alphatest="blend" scale="1" zPosition="2" />'
          % (_SPOT_X, _SPOT_Y, _SPOT_W, _SPOT_H, _SPOT_ART)
        + '<widget name="spotFocus" position="%d,%d" size="%d,%d" pixmap="%s/picker_spot_focus.png" alphatest="blend" scale="1" zPosition="3" />'
          % (_SPOT_X - 16, _SPOT_Y - 16, _SPOT_W + 32, _SPOT_H + 32, _SPOT_ART)
        + '</screen>')

    def __init__(self, session, context='genre', kind='vod', spotlight=False):
        Screen.__init__(self, session)
        self.context = context
        self.kind = kind
        # The Spotlight entry exists only for a real actor search.
        self.spotlight = bool(spotlight) and context == 'actor'
        self.choices = _CHOICES + (_SPOT,) if self.spotlight else _CHOICES
        current = get_actor_style(kind) if self.spotlight else get_style(context, kind)
        self.index = self.choices.index(current) if current in self.choices else 1
        self.active = self.index
        self._closing = False
        for i in range(len(_CARDS)):
            self['dim%d' % i] = Pixmap()
        self['selectionGold'] = Pixmap()
        self['activeBadge'] = Pixmap()
        self['spotPill'] = Pixmap()
        self['spotFocus'] = Pixmap()
        self['spotFocus'].hide()
        if not self.spotlight:
            self['spotPill'].hide()
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions',
            'ChannelSelectBaseActions', 'InfobarChannelSelection'], {
            'ok': self.accept, 'cancel': self.cancel,
            'left': self.left, 'right': self.right, 'up': self.up, 'down': self.down,
            'pageUp': self.previous, 'pageDown': self.next,
            'channelUp': self.previous, 'channelDown': self.next,
            'prevBouquet': self.previous, 'nextBouquet': self.next
        }, -1)
        self.onLayoutFinish.append(self.prepare)

    def prepare(self):
        if self._closing:
            return
        try:
            if self.active < len(_CARDS):
                x, y = _CARDS[self.active]
                self['activeBadge'].instance.move(ePoint(sx(x + _CW - 166), sy(y + 16)))
            else:
                self['activeBadge'].instance.move(ePoint(sx(_SPOT_X + _SPOT_W + 16), sy(_SPOT_Y + 10)))
            self['activeBadge'].show()
        except Exception:
            pass
        self.refresh()

    def refresh(self):
        if self._closing:
            return
        try:
            if self.index < len(_CARDS):
                x, y = _CARDS[self.index]
                self['selectionGold'].instance.move(ePoint(sx(x - 20), sy(y - 20)))
                self['selectionGold'].show()
                self['spotFocus'].hide()
            else:
                # Spotlight entry in the header: all four cards stay dimmed.
                self['selectionGold'].hide()
                self['spotFocus'].show()
            for i in range(len(_CARDS)):
                if i == self.index:
                    self['dim%d' % i].hide()
                else:
                    self['dim%d' % i].show()
        except Exception:
            pass

    def left(self):
        self.previous()

    def right(self):
        self.next()

    def up(self):
        if self.spotlight:
            # Header entry above the top row; UP on it wraps to the bottom row.
            cards = len(_CARDS)
            if self.index >= cards:
                self.index = 2
            elif self.index < 2:
                self.index = cards
            else:
                self.index -= 2
        else:
            self.index = (self.index - 2) % len(_CHOICES)
        self.refresh()

    def down(self):
        if self.spotlight:
            cards = len(_CARDS)
            if self.index >= cards:
                self.index = 0
            elif self.index < 2:
                self.index += 2
            else:
                self.index = cards
        else:
            self.index = (self.index + 2) % len(_CHOICES)
        self.refresh()

    def previous(self):
        self.index = (self.index - 1) % len(self.choices)
        self.refresh()

    def next(self):
        self.index = (self.index + 1) % len(self.choices)
        self.refresh()

    def cancel(self):
        if self._closing:
            return
        self._closing = True
        self.close(None)

    def accept(self):
        if self._closing:
            return
        self._closing = True
        chosen = self.choices[self.index]
        save_style(self.context, self.kind, chosen)
        self.close(chosen)
