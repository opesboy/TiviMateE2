# -*- coding: utf-8 -*-
"""Small local Python 3 runtime helpers for TiviMate E2."""

import io
import os


def open_text(path, mode="r", encoding="utf-8", errors="strict"):
    """Open a UTF-aware text file on Python 3."""
    if "b" in mode:
        return io.open(path, mode)
    return io.open(path, mode, encoding=encoding or "utf-8", errors=errors or "strict")


_DIR_MEMO = {}


def ensure_dir(path, mode=511):
    """Create a directory if absent; equivalent to exist_ok=True."""
    if not path:
        return
    # r146: called for every cached image; skip the stat for 30 s once seen.
    import time as _time
    now = _time.time()
    seen = _DIR_MEMO.get(path)
    if seen is not None and 0 <= now - seen < 30.0:
        return
    if os.path.isdir(path):
        if len(_DIR_MEMO) > 256:
            _DIR_MEMO.clear()
        _DIR_MEMO[path] = now
        return
    try:
        os.makedirs(path, mode)
    except OSError:
        if not os.path.isdir(path):
            raise


def atomic_replace(source, destination):
    """Use os.replace where available and rename safely on legacy Python."""
    replace = getattr(os, "replace", None)
    if replace is not None:
        return replace(source, destination)
    if os.path.exists(destination):
        try:
            os.unlink(destination)
        except OSError:
            pass
    return os.rename(source, destination)


def python_command():
    """Return a usable interpreter path and argv[0] on common Enigma2 images."""
    for path, command in (
        ("/usr/bin/python3", "python3"),
        ("/usr/bin/python", "python"),
    ):
        if os.path.exists(path):
            return path, command
    return "python", "python"
