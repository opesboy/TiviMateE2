# -*- coding: utf-8 -*-
"""Persistent loopback stream resolver for exported Stalker Enigma2 bouquets.

Native bouquets keep a stable localhost URI, not a short-lived create_link URL.
At every zap we ask the *currently configured* Stalker portal for a fresh link
and hand off transport, MAG headers, HLS rewriting and token reauthorization to
the existing stream_relay. No external port, provider credentials or web login.
Compatible with Python 2.7 and 3; the metadata remains on flash after reboot.
"""
from __future__ import absolute_import
import hashlib
import io
import json
import os
import re
import tempfile
import threading
try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn

HOST = '127.0.0.1'
PORT = 19787
_FILE_NAME = 'tivimatee2_stalker_bouquet_resolver.json'
_LOCK = threading.RLock()
_SERVER = None
_ROWS = {}
_ROWS_PATH = None
_ROWS_MTIME = None
_HEX = re.compile(r'^/s/([0-9a-f]{32})$')


def _text(value):
    if value is None:
        return u''
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    try:
        return unicode(value)  # Python 2
    except NameError:
        return str(value)


def _identity(source):
    src = source or {}
    return _text(src.get('url') or src.get('portal')).strip().rstrip('/').lower() + u'|' + _text(src.get('mac')).strip().lower()


def _sha(value):
    return hashlib.sha256(_text(value).encode('utf-8')).hexdigest()


def service_key(source, item):
    item = item or {}
    key = _text(item.get('stream_id') or item.get('id') or item.get('ch_id') or item.get('cmd') or '').strip()
    if not key or not _identity(source).split('|')[0]:
        return ''
    return _sha(_identity(source) + u'|' + key)[:32]


def service_url(source, item):
    token = service_key(source, item)
    return 'http://%s:%d/s/%s' % (HOST, PORT, token) if token else ''


def _path(directory):
    return os.path.join(directory, _FILE_NAME)


def _load(directory):
    global _ROWS, _ROWS_PATH, _ROWS_MTIME
    path = _path(directory)
    try:
        stamp = (os.stat(path).st_mtime, os.stat(path).st_size)
    except OSError:
        stamp = None
    with _LOCK:
        if path == _ROWS_PATH and stamp == _ROWS_MTIME:
            return dict(_ROWS)
        try:
            with io.open(path, 'r', encoding='utf-8') as handle:
                raw = json.load(handle)
            rows = raw.get('channels', {}) if isinstance(raw, dict) else {}
            if not isinstance(rows, dict):
                rows = {}
        except (IOError, OSError, ValueError, TypeError):
            rows = {}
        _ROWS, _ROWS_PATH, _ROWS_MTIME = rows, path, stamp
        return dict(rows)


def _save(directory, rows):
    global _ROWS_PATH, _ROWS_MTIME
    path = _path(directory)
    fd, tmp = tempfile.mkstemp(prefix='.tivimate-stalker-', dir=directory)
    try:
        os.fchmod(fd, 0o600)
        with io.open(fd, 'w', encoding='utf-8') as f:
            json.dump({'format': 1, 'channels': rows}, f, ensure_ascii=False, separators=(',', ':'))
            f.flush()
            os.fsync(f.fileno())
        os.rename(tmp, path)
        with _LOCK:
            _ROWS_PATH, _ROWS_MTIME = None, None
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def register(source, items, directory='/etc/enigma2'):
    """Persist only channel metadata, never Stalker login secrets or tokens."""
    if (source or {}).get('type') != 'stalker':
        return 0
    if not os.path.isdir(directory):
        raise IOError('Enigma2 bouquet folder not found')
    count = 0
    with _LOCK:
        rows = _load(directory)
        for item in items or []:
            if not isinstance(item, dict) or item.get('_placeholder'):
                continue
            key = service_key(source, item)
            if not key:
                continue
            saved = {}
            for field in ('stream_id', 'id', 'ch_id', 'cmd', 'name'):
                if item.get(field) is not None:
                    saved[field] = _text(item.get(field))
            rows[key] = {'source': _sha(_identity(source)), 'item': saved}
            count += 1
        if not count:
            raise ValueError('No Stalker channel IDs found to export')
        _save(directory, rows)
    start(directory)
    return count


def _resolve(key, directory):
    row = _load(directory).get(key)
    if not isinstance(row, dict):
        return ''
    from .core import get_sources, get_source_client
    source = None
    for src in get_sources():
        if src.get('type') == 'stalker' and _sha(_identity(src)) == row.get('source'):
            source = src
            break
    if source is None:
        return ''  # Source was deleted or its portal/MAC was changed.
    item = row.get('item') or {}
    if not isinstance(item, dict):
        return ''
    url = _text(get_source_client(source).stream_url(item, 'live')).strip()
    if not url.lower().startswith(('http://', 'https://')):
        return ''
    from .live_service import _stalker_refresher
    from .stream_relay import stalker_play_url
    relay = stalker_play_url(url, refresher=_stalker_refresher(source, item), force=True)
    # Never redirect the native service to an expiring provider link.
    if not relay.startswith('http://127.0.0.1:') or '/r/' not in relay:
        return ''
    return relay


class _Handler(BaseHTTPRequestHandler):
    server_version = 'TiviMateStalkerBouquet/1'
    sys_version = ''
    protocol_version = 'HTTP/1.0'

    def log_message(self, *args):
        return

    def do_GET(self):
        self._handle()

    def do_HEAD(self):
        self._handle()

    def _handle(self):
        if self.client_address[0] not in ('127.0.0.1', '::1', '::ffff:127.0.0.1'):
            self.send_error(403)
            return
        match = _HEX.match(self.path.split('?', 1)[0])
        if not match:
            self.send_error(404)
            return
        try:
            target = _resolve(match.group(1), self.server.export_directory)
        except Exception:
            target = ''
        if not target:
            self.send_error(502, 'Stalker link unavailable; check portal connection')
            return
        self.send_response(302)
        self.send_header('Location', target)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', '0')
        self.end_headers()


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        return


def start(directory='/etc/enigma2'):
    global _SERVER
    with _LOCK:
        if _SERVER is not None:
            return True
        if not _load(directory):
            return False
        server = _Server((HOST, PORT), _Handler)
        server.export_directory = directory
        worker = threading.Thread(target=server.serve_forever, name='TiviMateStalkerBouquet')
        worker.daemon = True
        try:
            worker.start()
        except Exception:
            server.server_close()
            raise
        _SERVER = server
    return True


def start_if_exported():
    """Cheap Enigma2 session-start hook; no portal/network calls at boot."""
    try:
        return start()
    except Exception:
        return False
