# -*- coding: utf-8 -*-
"""Local stream relay (idea and protocol rules from Ultra Stalker 9.3).

Why it exists
-------------
* Stalker/Ministra portals mint single-use ``play_token`` links on
  ``/play/live.php`` and ``/play/movie.php``. The first request is answered
  (often with a 302 to the real CDN address); every later request with the
  same token gets HTTP 458/462/4XX. Media players make several requests per
  stream (HEAD/probe, Range for seeking, reconnect), so the second one fails
  and the channel/movie "does not play".
* DreamOS GStreamer cannot send a User-Agent ("GStreamer souphttpsrc"),
  which many IPTV servers refuse with 401/403.

How it works
------------
The receiver plays ``http://127.0.0.1:<port>/r/<token>/<original path>``.
The relay (loopback only) fetches the real address with the MAG/player
User-Agent, passes Range through so seeking works, remembers where the
portal redirected the token (later requests go straight there), and when a
used token is refused it asks the portal for a fresh link once (refresher =
the plugin's own create_link) and continues - the player never sees the 4XX.
Only one upstream connection per stream is kept (one-connection providers).

Works on Python 2.7 and 3; no external packages.
"""
from __future__ import absolute_import, division, print_function

import binascii
import os
import socket
import threading
import time

try:  # Python 3
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    from urllib.parse import urlsplit, urljoin
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    _PY2 = False
except ImportError:  # Python 2.7
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    from urlparse import urlsplit, urljoin
    from urllib2 import Request, urlopen, HTTPError
    _PY2 = True

HOST = '127.0.0.1'
_CHUNK = 64 * 1024
_CONNECT_TIMEOUT = 15.0
_UA_RETRY_CODES = (401, 403, 407, 451, 456, 460)
_TOKEN_REFRESH_CODES = (401, 403, 404, 410, 451, 456, 458, 459, 460, 462, 502, 503, 504)
_REDIRECT_TTL = 3600.0
MAG_AGENT = ('Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 '
             '(KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3')
USER_AGENTS = (
    MAG_AGENT,
    'Enigma2 HbbTV/1.1.1 (+PVR+RTSP+DL;OpenATV;;;)',
    'VLC/3.0.20 LibVLC/3.0.20',
    'Lavf/58.76.100',
)

_LOCK = threading.RLock()
_REFRESH_LOCK = threading.RLock()
_STATE = {'server': None, 'port': None}
_TOKENS = {}
_BY_KEY = {}
_ACTIVE = {}
_ACTIVE_RESP = {}
_HOST_UA = {}
_REDIRECT_CACHE = {}
_FRESH_URLS = {}
_CONSUMED = []
_REFRESHERS = {}
_STATS = {'requests': 0, 'ua_retries': 0, 'errors': 0, 'refreshes': 0, 'last_error': ''}


def _log(message):
    return None


def _text(value):
    if value is None:
        return ''
    if _PY2 and isinstance(value, unicode):  # noqa: F821
        return value.encode('utf-8')
    if not _PY2 and isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return str(value)


def has_play_token(url):
    low = _text(url).lower()
    return 'play_token=' in low and '/play/' in low


def is_dreamos():
    return (os.path.exists('/etc/opendreambox') or
            os.path.exists('/usr/lib/enigma2/python/Components/DreamInfoHandler.py'))


def _cached_redirect(url):
    with _LOCK:
        row = _REDIRECT_CACHE.get(url)
        if not row:
            return ''
        if time.time() - row[1] > _REDIRECT_TTL:
            _REDIRECT_CACHE.pop(url, None)
            return ''
        return row[0]


def _store_redirect(origins, final_url):
    final_url = _text(final_url).strip()
    if not final_url.lower().startswith(('http://', 'https://')):
        return
    now = time.time()
    with _LOCK:
        for origin in origins:
            if origin and origin != final_url:
                _REDIRECT_CACHE[origin] = (final_url, now)
        while len(_REDIRECT_CACHE) > 256:
            oldest = min(_REDIRECT_CACHE.items(), key=lambda kv: kv[1][1])[0]
            _REDIRECT_CACHE.pop(oldest, None)


def _evict_redirect(origins):
    with _LOCK:
        for origin in origins:
            _REDIRECT_CACHE.pop(origin, None)


def _mark_consumed(url):
    with _LOCK:
        if url not in _CONSUMED:
            _CONSUMED.append(url)
            del _CONSUMED[:-512]


def _is_consumed(url):
    with _LOCK:
        return url in _CONSUMED


class _UpstreamError(Exception):
    def __init__(self, code, text):
        Exception.__init__(self, text)
        self.code = code


class _Handler(BaseHTTPRequestHandler):
    server_version = 'TiviMateRelay/1'
    sys_version = ''
    protocol_version = 'HTTP/1.0'

    def log_message(self, *args):
        return

    def do_HEAD(self):
        self._relay(head=True)

    def do_GET(self):
        self._relay(head=False)

    def _fail(self, code, text):
        try:
            body = text.encode('utf-8') if not isinstance(text, bytes) else text
            self.send_response(code)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception:
            pass

    def _relay(self, head=False):
        client_host = self.client_address[0] if self.client_address else ''
        if client_host not in ('127.0.0.1', '::1', '::ffff:127.0.0.1'):
            self._fail(403, 'loopback only')
            return
        parts = self.path.split('/', 3)
        if len(parts) < 3 or parts[1] != 'r':
            self._fail(404, 'not found')
            return
        token = parts[2]
        rest = parts[3] if len(parts) > 3 else ''
        stop = threading.Event()
        with _LOCK:
            entry = _TOKENS.get(token)
            previous = _ACTIVE.get(token) if not head else None
            prev_resp = _ACTIVE_RESP.get(token) if not head else None
            if not head:
                _ACTIVE[token] = stop
            _STATS['requests'] += 1
        if entry is None:
            self._fail(404, 'unknown stream')
            return
        if previous is not None and not previous.is_set():
            # Seek/reconnect: stop the old transfer first (one connection).
            previous.set()
            if prev_resp is not None:
                try:
                    prev_resp.close()
                except Exception:
                    pass
            time.sleep(0.15)
        upstream = entry['base'] + '/' + rest
        try:
            response = self._open(entry, upstream, head, token)
        except _UpstreamError as exc:
            _STATS['errors'] += 1
            _STATS['last_error'] = str(exc)
            _log('upstream error %s' % exc)
            self._fail(exc.code or 502, 'upstream error')
            return
        if not head:
            with _LOCK:
                if _ACTIVE.get(token) is stop:
                    _ACTIVE_RESP[token] = response
        try:
            self._send(response, head, stop, entry)
        finally:
            try:
                response.close()
            except Exception:
                pass
            if not head:
                with _LOCK:
                    if _ACTIVE.get(token) is stop:
                        _ACTIVE.pop(token, None)
                        _ACTIVE_RESP.pop(token, None)

    def _open_single_url(self, entry, target_url, head):
        netloc = urlsplit(target_url).netloc or urlsplit(entry['base']).netloc
        first = _HOST_UA.get(netloc, 0)
        order = [first] + [i for i in range(len(USER_AGENTS)) if i != first]
        if entry['headers'].get('User-Agent'):
            order = [None] + order
        last = None
        for position, index in enumerate(order):
            headers = dict(entry['headers'])
            if index is not None:
                headers['User-Agent'] = USER_AGENTS[index]
            headers.setdefault('Accept', '*/*')
            headers['Connection'] = 'close'
            rng = self.headers.get('Range')
            if rng:
                headers['Range'] = rng
            request = Request(target_url, headers=headers)
            if head:
                request.get_method = lambda: 'HEAD'
            try:
                response = urlopen(request, timeout=_CONNECT_TIMEOUT)
                if index is not None:
                    _HOST_UA[netloc] = index
                return response
            except HTTPError as exc:
                last = _UpstreamError(exc.code, 'HTTP %s' % exc.code)
                try:
                    exc.close()
                except Exception:
                    pass
                if exc.code in _UA_RETRY_CODES and position + 1 < len(order):
                    _STATS['ua_retries'] += 1
                    time.sleep(0.15)
                    continue
                raise last
            except Exception as exc:
                raise _UpstreamError(502, '%s' % (exc,))
        raise last or _UpstreamError(502, 'no response')

    def _refresh_upstream(self, token, original_upstream, active_upstream):
        with _LOCK:
            refresher = _REFRESHERS.get(token)
        if not callable(refresher):
            return ''
        with _REFRESH_LOCK:
            try:
                fresh = _text(refresher() or '').strip()
            except Exception as exc:
                _log('link refresh failed: %s' % exc)
                return ''
            if not fresh.lower().startswith(('http://', 'https://')):
                return ''
            fresh = fresh.split('#', 1)[0]
            with _LOCK:
                _FRESH_URLS[original_upstream] = fresh
                _FRESH_URLS[active_upstream] = fresh
                _STATS['refreshes'] += 1
            _log('fresh stream link from portal')
            return fresh

    def _open(self, entry, upstream, head, token):
        with _LOCK:
            active_upstream = _FRESH_URLS.get(upstream, upstream)
        cached_final = _cached_redirect(active_upstream) or _cached_redirect(upstream)
        if cached_final and cached_final != active_upstream:
            try:
                response = self._open_single_url(entry, cached_final, head)
                final_url = response.geturl() or ''
                if final_url and final_url != cached_final:
                    _store_redirect((upstream, active_upstream), final_url)
                return response
            except _UpstreamError:
                _evict_redirect((upstream, active_upstream))
        if _is_consumed(active_upstream) and has_play_token(active_upstream):
            refreshed = self._refresh_upstream(token, upstream, active_upstream)
            if refreshed:
                active_upstream = refreshed
        last_error = None
        for attempt in range(2):
            if has_play_token(active_upstream):
                _mark_consumed(active_upstream)
            try:
                response = self._open_single_url(entry, active_upstream, head)
                final_url = response.geturl() or ''
                if final_url and final_url != active_upstream:
                    _store_redirect((upstream, active_upstream), final_url)
                return response
            except _UpstreamError as exc:
                last_error = exc
                _evict_redirect((upstream, active_upstream))
                if attempt == 0 and exc.code in _TOKEN_REFRESH_CODES:
                    refreshed = self._refresh_upstream(token, upstream, active_upstream)
                    if refreshed and refreshed != active_upstream:
                        active_upstream = refreshed
                        continue
                break
        raise last_error or _UpstreamError(502, 'no response')

    def _send(self, response, head, stop, entry):
        status = response.getcode() or 200
        info = response.info()
        ctype = info.get('Content-Type') or 'application/octet-stream'
        final_url = response.geturl() or ''
        if _is_playlist(final_url, ctype) and not head:
            body = response.read(4 * 1024 * 1024)
            body = _rewrite_playlist(body, final_url, entry['headers'])
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_response(int(status))
        for name in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges',
                     'Last-Modified', 'ETag'):
            value = info.get(name)
            if value:
                self.send_header(name, value)
        self.end_headers()
        if head:
            return
        while not stop.is_set():
            try:
                chunk = response.read(_CHUNK)
            except Exception:
                break
            if not chunk:
                break
            try:
                self.wfile.write(chunk)
            except (socket.error, IOError, OSError, ValueError):
                break


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        return


def _is_playlist(url, ctype):
    if 'mpegurl' in (ctype or '').lower():
        return True
    path = urlsplit(url).path.lower()
    return path.endswith('.m3u8') or path.endswith('.m3u')


def _rewrite_playlist(body, playlist_url, headers):
    try:
        text = body.decode('utf-8', 'replace')
    except Exception:
        return body
    out = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            absolute = urljoin(playlist_url, stripped)
            if absolute.startswith(('http://', 'https://')):
                line = wrap(absolute, headers=headers)
        elif 'URI="' in line:
            head, _sep, tail = line.partition('URI="')
            uri, _q, after = tail.partition('"')
            absolute = urljoin(playlist_url, uri)
            if absolute.startswith(('http://', 'https://')):
                line = head + 'URI="' + wrap(absolute, headers=headers) + '"' + after
        out.append(line)
    return ('\n'.join(out) + '\n').encode('utf-8')


def _ensure_server():
    with _LOCK:
        if _STATE['server'] is not None:
            return _STATE['port']
        server = _Server((HOST, 0), _Handler)
        _STATE['port'] = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, name='tivimate-stream-relay')
        thread.daemon = True
        thread.start()
        _STATE['server'] = server
        _log('started on port %s' % _STATE['port'])
        return _STATE['port']


def is_relay_url(url):
    port = _STATE['port']
    return bool(port) and _text(url).startswith('http://%s:%d/r/' % (HOST, port))


def wrap(url, headers=None, refresher=None):
    """Return a relay URL for an http(s) stream (or the URL unchanged)."""
    url = _text(url)
    if not url.lower().startswith(('http://', 'https://')):
        return url
    if is_relay_url(url):
        return url
    url = url.split('#', 1)[0]
    try:
        port = _ensure_server()
    except Exception as exc:
        _log('unavailable: %s' % exc)
        return url
    parts = urlsplit(url)
    base = '%s://%s' % (parts.scheme, parts.netloc)
    hdrs = dict(headers or {})
    # One relay token per stream (play_token ignored), so two streams from
    # the same server (record + watch) never stop each other, while the
    # same stream reconnecting/seeking keeps its single upstream connection.
    query = '&'.join(p for p in (parts.query or '').split('&')
                     if not p.lower().startswith('play_token='))
    key = (base, parts.path, query, tuple(sorted(hdrs.items())))
    with _LOCK:
        token = _BY_KEY.get(key)
        if token is None:
            token = binascii.hexlify(os.urandom(8)).decode('ascii')
            if _PY2:
                token = str(token)
            _BY_KEY[key] = token
            _TOKENS[token] = {'base': base, 'headers': hdrs, 'key': key}
            if len(_TOKENS) > 400:
                for old in list(_TOKENS)[:100]:
                    if old in _ACTIVE or old == token:
                        continue
                    row = _TOKENS.pop(old, None)
                    if row:
                        _BY_KEY.pop(row.get('key'), None)
                    _REFRESHERS.pop(old, None)
        if callable(refresher):
            _REFRESHERS[token] = refresher
        _FRESH_URLS.pop(url, None)
    tail = parts.path.lstrip('/')
    if parts.query:
        tail += '?' + parts.query
    return 'http://%s:%d/r/%s/%s' % (HOST, port, token, tail)


def unwrap(url):
    """Original URL for a relay URL (for display, favourites, recording)."""
    url = _text(url)
    if not url.startswith('http://%s:' % HOST) or '/r/' not in url:
        return url
    token, _sep, rest = url.split('/r/', 1)[1].partition('/')
    entry = _TOKENS.get(token)
    if entry is None:
        return url
    return entry['base'] + '/' + rest


def status():
    data = dict(_STATS)
    data.update(port=_STATE['port'], streams=len(_TOKENS))
    return data


def stalker_play_url(url, refresher=None, force=False):
    """Relay a Stalker stream when it needs it, else return it unchanged.

    * any image: links with a single-use play_token (fixes 4XX on the
      player's second request / seek / reconnect);
    * DreamOS: every Stalker http(s) stream (its player cannot send the
      MAG User-Agent the portal expects).
    """
    url = _text(url).strip()
    if not url.lower().startswith(('http://', 'https://')) or is_relay_url(url):
        return url
    if not (force or has_play_token(url) or is_dreamos()):
        return url
    try:
        return wrap(url, headers={'User-Agent': MAG_AGENT}, refresher=refresher)
    except Exception as exc:
        _log('wrap failed: %s' % exc)
        return url
