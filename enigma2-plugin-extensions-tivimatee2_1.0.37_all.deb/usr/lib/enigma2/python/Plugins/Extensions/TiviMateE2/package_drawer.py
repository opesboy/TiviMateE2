# -*- coding: utf-8 -*-
"""Sliding PACKAGES menu (same look as Apple) for every poster style.

Shown as an instantiated dialog ON TOP of the current poster screen (never
session.open, which would hide the posters behind it). Keys are captured by a
high-priority ActionMap while the menu is visible.
"""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Label import Label
from enigma import ePoint, eTimer
from .display_scale import sx, sy, scale_skin

_ASSET = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/'
_ROWS = 8
_STEPS = 6
_X0, _Y0, _PW, _PH = 0, 126, 350, 824


def _text(value):
    if value is None:
        return u''
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return u'%s' % value


def _label(name, x, y, w, h, size, color, align='left'):
    return ('<widget name="%s" position="%d,%d" size="%d,%d" font="Bold;%d" '
            'foregroundColor="%s" halign="%s" valign="center" noWrap="1" '
            'transparent="1" zPosition="5" />' % (name, x, y, w, h, size, color, align))


class PackageDrawerScreen(Screen):
    skin = scale_skin(
        # Opaque window exactly the size of the menu: a transparent full-screen
        # window would erase the poster screen below it down to the video.
        '<screen name="PackageDrawerScreen" position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="#0B0C11" zPosition="99">' % (_X0, _Y0, _PW, _PH)
        + '<widget name="drawer" position="0,0" size="%d,%d" alphatest="blend" scale="1" zPosition="1" />' % (_PW, _PH)
        + '<widget name="selection" position="14,155" size="322,68" pixmap="%sapple_pkg_drawer_selection.png" alphatest="blend" scale="1" zPosition="3" />' % _ASSET
        + _label('heading', 30, 32, 290, 52, 27, '#FFFFFF', 'center')
        + '<widget name="counterPill" position="105,84" size="140,38" pixmap="%sapple_pkg_counter_pill.png" alphatest="blend" scale="1" zPosition="4" />' % _ASSET
        + _label('counter', 105, 84, 140, 38, 19, '#E8B84A', 'center')
        + ''.join(_label('row%d' % i, 42, 159 + 75 * i, 280, 60, 22, '#FFFFFF') for i in range(_ROWS))
        + '</screen>')

    def __init__(self, session, names, current=0, title='PACKAGES'):
        Screen.__init__(self, session)
        # Heading = the poster style's own name (APPLE, CINEMATIC, ...).
        self.title_text = _text(title or 'PACKAGES').strip().upper() or u'PACKAGES'
        self.names = [_text(n).strip() for n in (names or [])]
        self.index = max(0, min(int(current or 0), len(self.names) - 1)) if self.names else 0
        self._frame = 0
        self._target = _STEPS
        self._result = None
        self._done = False
        self['drawer'] = Pixmap()
        self['selection'] = Pixmap()
        self['counterPill'] = Pixmap()
        self['heading'] = Label('')
        self['counter'] = Label('')
        for i in range(_ROWS):
            self['row%d' % i] = Label('')
        self.finished = None  # set by the controller: finished(result)
        self._timer = eTimer()
        self._conn = None
        try:
            self._conn = self._timer.timeout.connect(self._tick)
        except Exception:
            self._timer.callback.append(self._tick)
        self.onClose.append(self._stop)

    def _stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass

    def _labels(self, visible):
        for key in ['heading', 'counter', 'counterPill', 'selection'] + ['row%d' % i for i in range(_ROWS)]:
            try:
                if visible:
                    self[key].show()
                else:
                    self[key].hide()
            except Exception:
                pass

    def start(self):
        # Loaded at runtime exactly like Apple's own menu (works on VTi too).
        try:
            self['drawer'].instance.setPixmapFromFile(_ASSET + 'apple_pkg_drawer_6.png')
            self['drawer'].show()
        except Exception:
            pass
        self._labels(False)
        self._place()
        self._tick()

    def _place(self):
        # Slide by moving the whole (opaque) window in from the left edge.
        x = _X0 - _PW + int(_PW * self._frame / float(_STEPS))
        try:
            self.instance.move(ePoint(sx(x), sy(_Y0)))
        except Exception:
            pass

    def _tick(self):
        if self._frame < self._target:
            self._frame += 1
        elif self._frame > self._target:
            self._frame -= 1
        self._place()
        if self._frame == _STEPS and self._target == _STEPS:
            self._refresh()
        if self._frame != self._target:
            try:
                self._timer.start(45, True)
            except Exception:
                pass
        elif self._target == 0 and not self._done:
            self._done = True
            self._stop()
            if self.finished:
                self.finished(self._result)

    def _refresh(self):
        total = len(self.names)
        if not total:
            self['heading'].setText(self.title_text)
            self['counter'].setText('0 / 0')
            self['heading'].show()
            self['counter'].show()
            self['counterPill'].show()
            return
        start = max(0, min(self.index - 3, max(0, total - _ROWS)))
        for i in range(_ROWS):
            idx = start + i
            label = self['row%d' % i]
            if idx < total:
                name = self.names[idx]
                if len(name) > 20:
                    name = name[:19] + u'…'
                label.setText(name)
                label.show()
            else:
                label.setText('')
                label.hide()
        self['heading'].setText(self.title_text)
        self['counter'].setText('%d / %d' % (self.index + 1, total))
        self['heading'].show()
        self['counter'].show()
        self['counterPill'].show()
        try:
            self['selection'].instance.move(ePoint(sx(14), sy(155 + 75 * (self.index - start))))
            self['selection'].show()
        except Exception:
            pass

    def _leave(self, result):
        if self._target == 0:
            return
        self._result = result
        self._target = 0
        self._labels(False)
        self._tick()

    def ok(self):
        self._leave(self.index if self.names else None)

    def back(self):
        self._leave(None)

    def _move(self, delta):
        if not self.names or self._target == 0:
            return
        self.index = max(0, min(len(self.names) - 1, self.index + delta))
        if self._frame == _STEPS:
            self._refresh()

    def up(self):
        self._move(-1)

    def down(self):
        self._move(1)

    def page_up(self):
        self._move(-_ROWS)

    def page_down(self):
        self._move(_ROWS)


class _DrawerController(object):
    """Keeps the poster screen visible; routes remote keys to the menu."""

    def __init__(self, screen, names, current, callback, title='PACKAGES'):
        self.screen = screen
        self.current = current
        self.callback = callback
        self._open = False
        self.dialog = screen.session.instantiateDialog(PackageDrawerScreen, names, current, title)
        self.dialog.finished = self._finished
        d = self.dialog
        # Lower prio value wins over the poster screen's own ActionMap (-1).
        self.actions = ActionMap(['OkCancelActions', 'DirectionActions', 'ChannelSelectBaseActions',
            'InfobarChannelSelection', 'ColorActions', 'MenuActions', 'InfobarActions',
            'InfobarEPGActions', 'NumberActions'], {
            'ok': d.ok, 'cancel': d.back, 'left': d.back, 'right': d.back,
            'red': d.back, 'green': self._swallow, 'yellow': self._swallow, 'blue': self._swallow,
            'menu': d.back, 'showEPGList': self._swallow, 'showMovies': self._swallow,
            'up': d.up, 'down': d.down,
            'pageUp': d.page_up, 'pageDown': d.page_down,
            'channelUp': d.page_up, 'channelDown': d.page_down,
            'prevBouquet': d.page_up, 'nextBouquet': d.page_down}, -20)
        self.actions.execBegin()
        self._open = True
        try:
            screen.onClose.append(self.destroy)
        except Exception:
            pass
        d.show()
        d.start()

    def _swallow(self):
        return

    def _finished(self, result):
        self.destroy()
        if result is None or result == self.current:
            return
        try:
            self.callback(result)
        except Exception:
            pass

    def destroy(self):
        if not self._open:
            return
        self._open = False
        try:
            self.actions.execEnd()
        except Exception:
            pass
        try:
            self.dialog.hide()
            self.screen.session.deleteDialog(self.dialog)
        except Exception:
            pass
        try:
            self.screen.onClose.remove(self.destroy)
        except Exception:
            pass
        if getattr(self.screen, '_package_drawer', None) is self:
            self.screen._package_drawer = None


def _log_error(where):
    return None


class _FallbackDrawerScreen(PackageDrawerScreen):
    """Old behaviour (separate screen) if the overlay cannot be created."""

    def __init__(self, session, names, current=0, title='PACKAGES'):
        PackageDrawerScreen.__init__(self, session, names, current, title)
        self.finished = self.close
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'ChannelSelectBaseActions',
            'InfobarChannelSelection', 'ColorActions', 'MenuActions'], {
            'ok': self.ok, 'cancel': self.back, 'left': self.back, 'right': self.back,
            'red': self.back, 'menu': self.back, 'up': self.up, 'down': self.down,
            'pageUp': self.page_up, 'pageDown': self.page_down,
            'channelUp': self.page_up, 'channelDown': self.page_down,
            'prevBouquet': self.page_up, 'nextBouquet': self.page_down}, -1)
        self.onLayoutFinish.append(self.start)


def _screen_visible(screen):
    """Only open over a poster screen that is really on screen (never over the
    player / fullscreen video while the poster screen is hidden behind it)."""
    try:
        if not getattr(screen, 'shown', True):
            return False
        if getattr(screen, 'execing', True) is False:
            return False
        session = getattr(screen, 'session', None)
        current = getattr(session, 'current_dialog', None)
        if current is not None and current is not screen:
            return False
    except Exception:
        pass
    return True


def open_package_drawer(screen, names, current, callback, title='PACKAGES'):
    """Show the menu over `screen`; callback(index) runs only for a new choice."""
    if not _screen_visible(screen):
        return False
    old = getattr(screen, '_package_drawer', None)
    if old is not None and old._open:
        return False
    names = list(names or [])
    try:
        screen._package_drawer = _DrawerController(screen, names, current, callback, title)
        return True
    except Exception:
        _log_error('overlay')
        screen._package_drawer = None

    def done(result=None):
        if result is None or result == current:
            return
        try:
            callback(result)
        except Exception:
            _log_error('callback')
    try:
        screen.session.openWithCallback(done, _FallbackDrawerScreen, names, current, title)
        return True
    except Exception:
        _log_error('fallback')
        return False

