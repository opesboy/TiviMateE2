# -*- coding: utf-8 -*-
"""Small speed diagnostics: /tmp/tivimate_speed.log (Python 2.7 and 3).

One line per image download, TMDb request and page open, with the time it
took. The first line describes the receiver (image, Python, Pillow, /tmp),
so logs from two images can be compared side by side. Bounded to ~400 KB.
"""
import os
import sys
import threading
import time

LOG = "/tmp/tivimate_speed.log"
_MAX = 400 * 1024
_LOCK = threading.Lock()
_STATE = {"header": False}


def _image_name():
    for path in ("/etc/issue", "/etc/image-version", "/etc/os-release"):
        try:
            with open(path, "r") as handle:
                for line in handle.read().splitlines():
                    line = line.strip()
                    if line and "\\" not in line:
                        return line[:60]
        except Exception:
            pass
    return "unknown"


def _header():
    try:
        import PIL
        pil = getattr(PIL, "__version__", getattr(PIL, "PILLOW_VERSION", "yes"))
    except Exception:
        pil = "missing"
    try:
        tmp_fs = "?"
        with open("/proc/mounts", "r") as handle:
            for line in handle:
                parts = line.split()
                if len(parts) > 2 and parts[1] == "/tmp":
                    tmp_fs = parts[2]
    except Exception:
        tmp_fs = "?"
    try:
        with open("/proc/cpuinfo", "r") as handle:
            cpu = [l.split(":", 1)[1].strip() for l in handle
                   if l.lower().startswith(("model name", "cpu model", "hardware", "system type"))
                   and ":" in l][:1]
    except Exception:
        cpu = []
    return "=== %s | image=%s | python=%s | pillow=%s | /tmp=%s | cpu=%s" % (
        time.strftime("%Y-%m-%d %H:%M:%S"), _image_name(),
        sys.version.split()[0], pil, tmp_fs, (cpu[0] if cpu else "?")[:40])


def _enabled():
    # Off by default (release). Create /tmp/tivimate_speed.on to switch on.
    now = time.time()
    if now - _STATE.get("checked", 0) > 10:
        _STATE["checked"] = now
        _STATE["on"] = False
    return _STATE.get("on", False)


def log(kind, what, seconds, ok=True, size=0, extra=""):
    """kind: IMG / TMDB / PAGE. Never raises."""
    if not _enabled():
        return
    try:
        text = "%s %-4s %6.2fs %-4s %7s %s %s" % (
            time.strftime("%H:%M:%S"), kind, float(seconds), "ok" if ok else "FAIL",
            ("%dKB" % (int(size) // 1024)) if size else "-",
            str(what)[:110], str(extra)[:60])
        with _LOCK:
            try:
                if os.path.getsize(LOG) > _MAX:
                    os.rename(LOG, LOG + ".old")
                    _STATE["header"] = False
            except OSError:
                pass
            with open(LOG, "a") as handle:
                if not _STATE["header"]:
                    handle.write(_header() + "\n")
                    _STATE["header"] = True
                handle.write(text + "\n")
    except Exception:
        pass


def short_url(url):
    try:
        text = str(url or "")
        if "://" in text:
            text = text.split("://", 1)[1]
        host, _, path = text.partition("/")
        return "%s/..%s" % (host, path[-40:])
    except Exception:
        return "?"
