# -*- coding: utf-8 -*-
"""One actor-search matcher for Movies and TV Shows (Python 3 and 2.7).

TMDb credits are fetched in the TMDb language, English and Arabic, so a
provider title in any of these (or the original title) is found.  Provider
rows are matched first by their TMDb id, then by a normalised title that
understands Arabic spelling variants and common IPTV prefixes/suffixes.
"""
import re
import threading
import time
import unicodedata

try:
    _text = unicode  # Python 2.7
except NameError:
    _text = str

_FLAGS = re.I | re.U

# "AR - ", "|EN|", "[4K]", "NF: " ... at the start of a provider title.
_PREFIX = re.compile(
    u"^\\s*[\\[\\(\\|]?\\s*(?:ar|ara|arab|en|eng|tr|tur|fr|de|es|it|in|hi|ind|kr|ko|kor|jp|"
    u"us|uk|gb|eg|sa|ksa|sy|lb|kw|ae|gcc|ma|dz|tn|iq|osn|nf|netflix|shahid|amz|"
    u"4k|uhd|fhd|hd|sd|vip|multi|sub|dub|عربي|مترجم|مدبلج|تركي|هندي|كوري)"
    u"\\s*[\\]\\)\\|:\\-–—]+\\s*", _FLAGS)
_LEAD_WORD = re.compile(u"^(?:مسلسل|فيلم|برنامج|انمي|افلام|مسلسلات)\\s+", _FLAGS)
_BRACKETS = re.compile(u"\\([^)]*\\)|\\[[^\\]]*\\]|\\{[^}]*\\}", _FLAGS)
_QUALITY = re.compile(
    u"\\b(?:4k|uhd|fhd|fullhd|hd|sd|hdr|dv|hevc|x265|x264|1080p|720p|2160p|"
    u"multi|dual|audio|sub|subs|subbed|dub|dubbed|vip)\\b", _FLAGS)
_AR_TAGS = re.compile(u"(?:^|\\s)(?:مترجم|مترجمة|مدبلج|مدبلجة|كامل|كاملة|حصري|حصريا|"
                      u"اونلاين|بجودة|عالية)(?=\\s|$)", _FLAGS)
_SEASON = re.compile(
    u"(?:\\bs\\d{1,2}(?:\\s*e\\d{1,3})?\\b|\\bseason\\s*\\d+.*$|\\bpart\\s*\\d+\\s*$|"
    u"(?:^|\\s)(?:الموسم|الجزء|موسم|جزء)(?:\\s+.*)?$)", _FLAGS)
_YEAR = re.compile(u"\\b(?:19|20)\\d{2}\\b", _FLAGS)
_AR_MAP = {u"ة": u"ه", u"ى": u"ي", u"ـ": u"", u"ٱ": u"ا"}


def _as_text(value):
    if isinstance(value, bytes) and not isinstance(value, _text):
        return value.decode("utf-8", "ignore")
    return _text(value if value is not None else u"")


def _fold(value):
    text = _as_text(value or u"").strip().lower()
    if not text:
        return u""
    text = text.replace(u"\\/", u"/").replace(u"&", u" and ")
    try:
        # Removes Latin accents and Arabic harakat/hamza seats: أإآ -> ا, ؤ -> و, ئ -> ي.
        text = u"".join(ch for ch in unicodedata.normalize("NFKD", text)
                        if unicodedata.category(ch) != "Mn")
    except Exception:
        pass
    for src, dst in _AR_MAP.items():
        text = text.replace(src, dst)
    return text


_KEY_MEMO = {}
_KEY_MEMO_LIMIT = 60000
_CREDITS_MEMO = {}
_CREDITS_TTL = 6 * 3600
_CREDITS_LOCK = threading.Lock()


def title_key(value):
    """Normalised key, memoised: catalogue and package caches repeat titles."""
    if not value:
        return u""
    try:
        cached = _KEY_MEMO.get(value)
    except TypeError:
        return _title_key(value)
    if cached is None:
        cached = _title_key(value)
        if len(_KEY_MEMO) >= _KEY_MEMO_LIMIT:
            _KEY_MEMO.clear()
        _KEY_MEMO[value] = cached
    return cached


def _title_key(value):
    text = _fold(value)
    if not text:
        return u""
    for _ in range(3):
        stripped = _PREFIX.sub(u"", text, count=1)
        if stripped == text:
            break
        text = stripped
    text = _BRACKETS.sub(u" ", text)
    text = _LEAD_WORD.sub(u"", text.strip())
    text = re.sub(u"[\\W_]+", u" ", text, flags=re.U)
    text = _QUALITY.sub(u" ", text)
    text = _AR_TAGS.sub(u" ", text)
    text = _SEASON.sub(u" ", text.strip())
    text = _YEAR.sub(u" ", text)
    text = u" ".join(text.split())
    if text.startswith(u"the "):
        text = text[4:]
    return text


def loose_key(key):
    """Spelling-tolerant key: no spaces and no Arabic article (ال)."""
    words = []
    for word in (key or u"").split():
        if word == u"و":
            continue
        if len(word) > 5 and word.startswith(u"وال"):
            word = word[3:]
        elif len(word) > 4 and word.startswith(u"ال"):
            word = word[2:]
        words.append(word)
    return u"".join(words)


def _row_tmdb_id(row):
    for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
        for key in ("tmdb_id", "tmdb", "tmdbid", "tmdbId"):
            value = _as_text(mapping.get(key) or u"").strip()
            if value.isdigit() and value != u"0":
                return value
    return u""


def _languages(client):
    out = []
    for lang in (getattr(client, "language", "") or "", "en-US", "ar"):
        lang = _text(lang or u"").strip()
        if lang and lang.split(u"-")[0].lower() not in [x.split(u"-")[0].lower() for x in out]:
            out.append(lang)
    return out


class ActorCredits(object):
    """TMDb acting credits of one person for one content kind."""

    def __init__(self, person_id, kind):
        self.ids = set()
        self.keys = set()
        self.loose = set()
        self.count = 0
        self.ok = False
        from .tmdb_client import TMDbClient
        client = TMDbClient()
        endpoint = "/person/%s/%s" % (
            int(_text(person_id).strip()),
            "tv_credits" if kind == "series" else "movie_credits")
        languages = _languages(client)
        memo_key = (endpoint, tuple(languages))
        now = time.time()
        with _CREDITS_LOCK:
            hit = _CREDITS_MEMO.get(memo_key)
        if hit and now - hit[0] < _CREDITS_TTL:
            self.ids, self.keys, self.loose, self.count = hit[1], hit[2], hit[3], hit[4]
            self.ok = True
            return
        # Disk copy (24 h, one small file per actor; survives a GUI restart).
        disk_key = u"actor_credits|%s|%s" % (endpoint, u",".join(languages))
        try:
            from .tmdb_client import _load_search_cache
            saved = _load_search_cache("person", u"", disk_key, None) or {}
            if saved.get("count"):
                self.ids = set(_as_text(x) for x in saved.get("ids") or [])
                self.keys = set(_as_text(x) for x in saved.get("keys") or [])
                self.loose = set(_as_text(x) for x in saved.get("loose") or [])
                self.count = int(saved.get("count") or 0)
                self.ok = True
                with _CREDITS_LOCK:
                    _CREDITS_MEMO[memo_key] = (now, self.ids, self.keys, self.loose, self.count)
                return
        except Exception:
            pass
        # The three languages are requested in parallel (one round trip).
        payloads = [None] * len(languages)

        def fetch(index, lang):
            try:
                payloads[index] = client._get(endpoint, {"language": lang}) or {}
            except Exception:
                payloads[index] = None

        workers = []
        for index, lang in enumerate(languages):
            worker = threading.Thread(target=fetch, args=(index, lang),
                                      name="TiviActorCredits")
            worker.daemon = True
            worker.start()
            workers.append(worker)
        deadline = time.time() + 15
        for worker in workers:
            worker.join(max(0.1, deadline - time.time()))
        seen = set()
        for payload in payloads:
            if not isinstance(payload, dict):
                continue
            self.ok = True
            for credit in payload.get("cast") or []:
                if not isinstance(credit, dict):
                    continue
                cid = _as_text(credit.get("id") or u"").strip()
                if cid and cid not in seen:
                    seen.add(cid)
                    self.count += 1
                if cid:
                    self.ids.add(cid)
                for field in ("title", "original_title", "name", "original_name"):
                    key = title_key(credit.get(field))
                    if key:
                        self.keys.add(key)
                        self.loose.add(loose_key(key))
        if self.ok:
            with _CREDITS_LOCK:
                if len(_CREDITS_MEMO) > 200:
                    _CREDITS_MEMO.clear()
                _CREDITS_MEMO[memo_key] = (now, self.ids, self.keys, self.loose, self.count)
            if self.count:
                try:
                    from .tmdb_client import _save_search_cache
                    _save_search_cache("person", u"", disk_key, None, {"ids": sorted(self.ids),
                                         "keys": sorted(self.keys), "loose": sorted(self.loose),
                                         "count": self.count})
                except Exception:
                    pass

    def matches(self, row):
        if not isinstance(row, dict):
            return False
        tid = _row_tmdb_id(row)
        if tid and tid in self.ids:
            return True
        for field in ("name", "title", "original_name", "original_title", "o_name"):
            key = title_key(row.get(field))
            if not key:
                continue
            if key in self.keys:
                return True
            loose = loose_key(key)
            if len(loose) >= 3 and loose in self.loose:
                return True
        return False
