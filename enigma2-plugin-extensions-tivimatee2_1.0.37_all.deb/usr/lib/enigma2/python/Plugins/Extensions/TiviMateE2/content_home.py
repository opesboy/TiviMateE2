# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path, ETC_DIR
from .package_logos import package_logo_path, package_provider_key, package_logo_for_key
import os, time, json, hashlib, threading, random, itertools
from collections import OrderedDict
import queue as _queue
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from .rtl_text import DirectionalLabel, SynopsisLabel, AdaptiveOverviewLabel, CenteredArabicMetadataLabel, RisingOverviewLabel
from .display_titles import clean_display_title, visible_title
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
try:
    from Components.ServiceEventTracker import ServiceEventTracker
    from enigma import iPlayableService
except Exception:
    ServiceEventTracker = None
    iPlayableService = None
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from enigma import eServiceReference, ePicLoad, eConsoleAppContainer, ePoint, eTimer, eSize
from .alpha_picload import ePicLoad  # PNG logos keep alpha on every image
try:
    from twisted.internet import reactor
except Exception:
    reactor = None
from .core import get_source_client, get_cached_catalog
try:
    from skin import parseColor
except Exception:  # pragma: no cover
    from enigma import gRGB
    def parseColor(value):
        return gRGB(int(str(value).lstrip("#"), 16))
from .core import XtreamClient, StalkerClient, M3UClient
from .filters import filter_items as filter_items_for_source
from .metadata_display import merge_metadata, extract_metadata, provider_cache_key
from .tmdb_client import (TMDbClient, load_settings, backdrop_url, preferred_metadata_text,
                          _tmdb_identity_anchor, _tmdb_identity_row_score)
from .logo_manager import (logo_language, image_languages, best_tmdb_logo, preferred_logo_languages,
                           tmdb_logo_url, has_language_logo, localized_logo_url)
from .banner_artwork import fetch_banner, read_key as read_fanart_banner_key
from .rating_cache import split_ranked, enrich_missing
from .pink_rating import show_pink_rating
from .country_flags import show_country_flag, country_code as verified_country_code
# Full VOD catalog kept per server after an Other Sources search (30 min).
_OTHER_SOURCES_CATALOG = {}
from .filters import get_filtered_streams, get_allowed_category_ids, filter_categories, get_category_streams, get_category_streams_batch, get_cached_categories, get_stalker_landing_items, peek_category_streams_cache
from concurrent.futures import ThreadPoolExecutor, as_completed
from difflib import SequenceMatcher
import re
from urllib.parse import urlparse, quote

from .cache_manager import get_cache_dir, get_cache_root
from .artwork_queue import request_artwork, prefetch_artwork, artwork_path, cached_artwork, cached_candidates_first
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, sx, sy, scale_size
from .i18n import tr, get_language, nav_label
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"

# GUI-thread-only shared index: flags found on the Cinema entry remain available
# when the same film/series is opened via another top-navigation entry point.
# These are VERIFIED TMDb/provider country codes, not guesses from poster names.
_BACKDROP_FLAG_COUNTRIES = OrderedDict()
_BACKDROP_FLAG_COUNTRIES_LIMIT = 256


def _stable_backdrop_order(rows, seed=""):
    """Return a deterministic order for featured Backdrop candidates.

    Featured rails are cached, so random.shuffle/random.sample made the order
    change whenever the selection cache was rebuilt or the page was reopened.
    Keep the diversity of the old sampling without changing order between
    opens for the same server, content kind and package.
    """
    values = list(rows or [])
    seed = str(seed or "")
    values.sort(key=lambda row: hashlib.sha1(
        (seed + "\x1f" + str(
            (row or {}).get("stream_id") or (row or {}).get("series_id") or
            (row or {}).get("vod_id") or (row or {}).get("id") or
            (row or {}).get("name") or (row or {}).get("title") or ""
        )).encode("utf-8", "ignore")).hexdigest())
    return values


def _tmdb_backdrop_identity(url):
    """TMDb artwork key independent of w780/w1280/original image size."""
    url = str(url or "").strip().replace("\\/", "/")
    match = re.search(r"(?:image\.tmdb\.org/t/p/)(?:w\d+|original)(/[^?#]+)", url, re.I)
    if match:
        return match.group(1).lower()
    if url.startswith("/") and not url.startswith("//"):
        return url.split("?", 1)[0].lower()
    return url.lower()


def _tmdb_same_movie_backdrops(bundle):
    """Rank real TMDb backdrops for ONE already-resolved movie/series ID.

    The primary detail image stays first, followed by other images from that
    exact media record. Excludes poster/logo fields even on older caches.
    """
    bundle = bundle if isinstance(bundle, dict) else {}
    images = bundle.get("images") or {}
    rows = images.get("backdrops") or [] if isinstance(images, dict) else []
    ordered = []
    seen = set()

    def add(path):
        path = str(path or "").strip().replace("\\/", "/")
        if not (path.startswith("/") and not path.startswith("//") or
                path.startswith("https://image.tmdb.org/t/p/")):
            return
        key = _tmdb_backdrop_identity(path)
        if key not in seen:
            seen.add(key)
            ordered.append(path)

    add(bundle.get("backdrop_path"))

    def rank(row):
        try:
            votes = float(row.get("vote_average") or 0)
            count = int(row.get("vote_count") or 0)
            width = int(row.get("width") or 0)
        except (TypeError, ValueError, OverflowError):
            votes, count, width = 0.0, 0, 0
        # Actual TMDb rating is a better signal than array insertion order.
        return (votes, count, width)

    valid_rows = [r for r in rows if isinstance(r, dict) and r.get("file_path")]
    for row in sorted(valid_rows, key=rank, reverse=True):
        add(row.get("file_path"))
    for row in rows:
        if isinstance(row, str):
            add(row)
    return ordered


# Per-server movie recommendation backdrop paths. Persist on the configured
# artwork cache drive, not in /tmp or in IPTV server configuration files.
_RECOMMEND_BACKDROP_LOCK = threading.RLock()
_RECOMMEND_BACKDROP_INDEX = {}
_RECOMMEND_BACKDROP_ROOT = None


def _recommend_backdrop_key(source, row):
    source = source or {}
    row = row or {}
    identity = [
        str(source.get(k) or "") for k in ("type", "url", "portal", "username", "mac")
    ]
    identity.extend(str(row.get(k) or "") for k in (
        "stream_id", "vod_id", "id", "category_id", "name", "title", "year", "release_date"
    ))
    return hashlib.sha1("\x1f".join(identity).encode("utf-8", "ignore")).hexdigest()


def _recommend_backdrop_index():
    global _RECOMMEND_BACKDROP_ROOT, _RECOMMEND_BACKDROP_INDEX
    try:
        folder = os.path.join(get_cache_dir(), "recommendations")
    except Exception:
        return {}
    with _RECOMMEND_BACKDROP_LOCK:
        if _RECOMMEND_BACKDROP_ROOT != folder:
            _RECOMMEND_BACKDROP_ROOT = folder
            try:
                with open(os.path.join(folder, "backdrops.json"), "r") as handle:
                    loaded = json.load(handle)
                _RECOMMEND_BACKDROP_INDEX = loaded if isinstance(loaded, dict) else {}
            except Exception:
                _RECOMMEND_BACKDROP_INDEX = {}
        return _RECOMMEND_BACKDROP_INDEX


def _recommend_backdrop_get(source, row):
    key = _recommend_backdrop_key(source, row)
    with _RECOMMEND_BACKDROP_LOCK:
        data = _recommend_backdrop_index().get(key) or {}
        return dict(data) if isinstance(data, dict) else {}


def _recommend_backdrop_put(source, row, backdrop, tmdb_id):
    if not isinstance(backdrop, str) or not backdrop.strip():
        return
    key = _recommend_backdrop_key(source, row)
    with _RECOMMEND_BACKDROP_LOCK:
        cache = _recommend_backdrop_index()
        if not _RECOMMEND_BACKDROP_ROOT:
            return
        cache[key] = {"backdrop_path": backdrop.strip(), "tmdb_id": str(tmdb_id or ""), "at": int(time.time())}
        if len(cache) > 1500:
            keep = sorted(cache.items(), key=lambda x: int((x[1] or {}).get("at") or 0), reverse=True)[:1200]
            cache.clear()
            cache.update(keep)
        try:
            os.makedirs(_RECOMMEND_BACKDROP_ROOT, exist_ok=True)
            destination = os.path.join(_RECOMMEND_BACKDROP_ROOT, "backdrops.json")
            tmp = destination + ".tmp"
            with open(tmp, "w") as handle:
                json.dump(cache, handle, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, destination)
        except Exception:
            pass

def _recommend_genre_provider_backdrop(source, row):
    """GENRE-style provider detail lookup for a missing recommendation backdrop.

    Check the shared GENRE persistent detail cache and Movie Details' exact
    provider-info cache before requesting VOD info. Never use a poster as a
    horizontal backdrop. The caller runs in a bounded worker, never GUI.
    """
    source = dict(source or {})
    row = row if isinstance(row, dict) else {}
    if str(source.get("type") or "").lower() not in ("xtream", "stalker"):
        return ""
    item_id = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "").strip()
    if not item_id:
        return ""
    try:
        from .cache_manager import stable_cache_key, persistent_cache_get
        genre_key = stable_cache_key(
            "genre_provider_details_v1", source.get("type"),
            source.get("url") or source.get("base_url") or source.get("host"),
            source.get("username") or source.get("user"), source.get("password"),
            "vod", item_id)
        genre_metadata = persistent_cache_get(genre_key)
        if isinstance(genre_metadata, dict) and "_genre_backdrop_url" in genre_metadata:
            return str(genre_metadata.get("_genre_backdrop_url") or "").strip()
    except Exception:
        pass

    payload = {}
    path = ""
    try:
        cache_key = provider_cache_key("vod", item_id, source)
        folder = get_cache_dir("metadata")
        path = os.path.join(folder, "provider_info_" +
                            hashlib.md5(cache_key.encode("utf-8")).hexdigest() + ".json")
        if os.path.isfile(path) and os.path.getsize(path) > 2:
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            payload = loaded if isinstance(loaded, dict) else {}
    except Exception:
        payload = {}
    if not payload:
        try:
            reply = get_source_client(source).vod_info(item_id) or {}
            payload = reply if isinstance(reply, dict) else {}
        except Exception:
            return ""
        if payload and path:
            temp = path + ".tmp.%d.%d" % (os.getpid(), threading.get_ident())
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(temp, "w", encoding="utf-8") as f:
                    json.dump(payload, f, ensure_ascii=False)
                os.replace(temp, path)
            except Exception:
                try:
                    os.unlink(temp)
                except OSError:
                    pass

    for record in (payload, payload.get("info"), payload.get("movie_data"),
                   payload.get("series_data"), payload.get("metadata"),
                   payload.get("data"), payload.get("details")):
        if isinstance(record, dict):
            url = _server_backdrop_url(source, record)
            if url:
                return url
    return ""


# Identity-verified cinematic backdrops share the Movie/TV Details artwork bytes.
# This SMALL index only remembers which verified TMDb image belongs to each
# server item; actual artwork remains in the normal "backdrops" image directory.
_CINEMATIC_VERIFIED_LOCK = threading.RLock()
_CINEMATIC_VERIFIED_ROOT = None
_CINEMATIC_VERIFIED_INDEX = {}
_CINEMATIC_VERIFIED_MAX = 2000


def _cinematic_verified_key(source, kind, row):
    row = row or {}
    source_key = _home_feed_cache_key("cinematic", source)
    title = str(row.get("_display_title") or row.get("name") or row.get("title") or "").strip()
    identity = [source_key, str(kind or ""),
                str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or ""),
                str(row.get("_source_category_id") or row.get("category_id") or ""),
                title.casefold(), str(row.get("_backdrop_year") or row.get("year") or "")]
    return hashlib.sha256("\x1f".join(identity).encode("utf-8", "ignore")).hexdigest()


def _cinematic_verified_index():
    global _CINEMATIC_VERIFIED_ROOT, _CINEMATIC_VERIFIED_INDEX
    folder = get_cache_dir("cinematic_metadata")
    with _CINEMATIC_VERIFIED_LOCK:
        if folder != _CINEMATIC_VERIFIED_ROOT:
            _CINEMATIC_VERIFIED_ROOT = folder
            try:
                with open(os.path.join(folder, "verified_backdrops.json"), "r") as stream:
                    raw = json.load(stream)
                _CINEMATIC_VERIFIED_INDEX = raw if isinstance(raw, dict) else {}
            except Exception:
                _CINEMATIC_VERIFIED_INDEX = {}
        return _CINEMATIC_VERIFIED_INDEX


def _cinematic_verified_get(source, kind, row):
    if not isinstance(row, dict):
        return {}
    key = _cinematic_verified_key(source, kind, row)
    with _CINEMATIC_VERIFIED_LOCK:
        data = _cinematic_verified_index().get(key) or {}
        if not isinstance(data, dict):
            return {}
        url = str(data.get("url") or "").strip()
        # Only TMDb backdrops that have passed the cinematic identity check.
        # Reject stale or unverified provider URLs from old metadata files.
        if not url.startswith("https://image.tmdb.org/t/p/"):
            return {}
        return dict(data)


def _cinematic_backdrop_temporarily_missing(source, kind, row):
    """Do not suppress a real title because an earlier image request failed.

    Older packages persisted 30-minute misses. An offline provider, timeout,
    unavailable flash cache or a TMDb error is not evidence of no artwork.
    In-session request deduplication still throttles repeated navigation.
    """
    return False


def _cinematic_backdrop_record_missing(source, kind, row):
    """Legacy entry point: never write persistent negative artwork results."""
    return False


def _cinematic_verified_put(source, kind, row, url, tmdb_id, country=""):
    url = str(url or "").strip()
    if not (url.startswith("https://image.tmdb.org/t/p/") and
            str(tmdb_id or "").isdigit() and isinstance(row, dict)):
        return False
    key = _cinematic_verified_key(source, kind, row)
    with _CINEMATIC_VERIFIED_LOCK:
        index = _cinematic_verified_index()
        existing = index.get(key) or {}
        if (existing.get("url") == url and
                existing.get("tmdb_id") == str(tmdb_id) and
                (not country or existing.get("country") == str(country))):
            return True  # Avoid disk writes on repeat navigation.
        record = {"url": url, "tmdb_id": str(tmdb_id),
                  "country": str(country or existing.get("country") or "")[:2],
                  "updated": int(time.time())}
        if (existing.get("tmdb_id") == str(tmdb_id) and
                isinstance(existing.get("presentation"), dict)):
            record["presentation"] = existing["presentation"]
        index[key] = record
        if len(index) > _CINEMATIC_VERIFIED_MAX:
            kept = sorted(index.items(), key=lambda x: int((x[1] or {}).get("updated") or 0),
                          reverse=True)[:1600]
            index.clear()
            index.update(kept)
        try:
            folder = _CINEMATIC_VERIFIED_ROOT
            destination = os.path.join(folder, "verified_backdrops.json")
            tmp = destination + ".tmp"
            with open(tmp, "w") as stream:
                json.dump(index, stream, separators=(",", ":"))
            os.replace(tmp, destination)
            return True
        except Exception:
            return False


def _cinematic_presentation_get(source, kind, row, language):
    """Return verified, language-specific compact hero metadata, if cached."""
    entry = _cinematic_verified_get(source, kind, row)
    data = entry.get("presentation") or {}
    if isinstance(data, dict) and data.get("language") == language:
        return dict(data)
    return {}


def _cinematic_presentation_put(source, kind, row, tmdb_id, language, bundle, logo):
    """Store logo URL and small display fields only; share existing image files."""
    if not isinstance(row, dict) or not str(tmdb_id or "").isdigit():
        return False
    fields = ("title", "name", "vote_average", "release_date", "first_air_date",
              "runtime", "episode_run_time", "genres", "overview")
    reduced = {k: bundle[k] for k in fields if isinstance(bundle, dict) and k in bundle}
    if "overview" in reduced:
        reduced["overview"] = str(reduced["overview"] or "")[:600]
    if isinstance(reduced.get("genres"), list):
        reduced["genres"] = reduced["genres"][:3]
    logo = str(logo or "").strip()
    if logo and not logo.startswith(("https://", "http://")):
        logo = ""
    record = {"language": language, "logo": logo, "metadata": reduced,
              "updated": int(time.time())}
    key = _cinematic_verified_key(source, kind, row)
    with _CINEMATIC_VERIFIED_LOCK:
        cache = _cinematic_verified_index()
        entry = cache.get(key)
        if not isinstance(entry, dict) or str(entry.get("tmdb_id") or "") != str(tmdb_id):
            return False
        previous = entry.get("presentation") or {}
        # Timestamps are bookkeeping, not content. Avoid reserializing the
        # entire verified index every time the cursor revisits this movie.
        if (isinstance(previous, dict) and
                previous.get("language") == language and
                previous.get("logo") == logo and
                previous.get("metadata") == reduced):
            return True
        entry["presentation"] = record
        try:
            folder = _CINEMATIC_VERIFIED_ROOT
            destination = os.path.join(folder, "verified_backdrops.json")
            tmp = destination + ".tmp"
            with open(tmp, "w") as stream:
                json.dump(cache, stream, ensure_ascii=False, separators=(",", ":"))
            os.replace(tmp, destination)
            return True
        except Exception:
            return False


CONTENT_LANDING_CACHE_DIR = data_path("content_landing")
TITLE_MATCH_CACHE_FILE = data_path("title_matches.json")
HOME_FEED_CACHE_FILE = data_path("home_feeds.json")
_HOME_FEED_CACHE_LOCK = threading.RLock()
_HOME_FEED_CACHE_MAX_AGE = 7 * 24 * 3600
# GENRE Latest artwork selection is reconstructed from the *existing* per-package
# cache at most once every five hours. Actual image-cache lifetimes and page
# download queues are intentionally unchanged.
_GENRE_LATEST_SELECTION_INTERVAL = 5 * 60 * 60
_PACKAGE_LATEST_SELECTION_INTERVAL = 5 * 60 * 60
# Parse the shared feed JSON once while its on-disk identity is unchanged.
# On internal Enigma flash even a warm read repeatedly decodes the entire file.
_HOME_FEED_RAM = {"signature": None, "value": None}


def _home_feed_file_signature():
    try:
        st = os.stat(HOME_FEED_CACHE_FILE)
        return (getattr(st, "st_mtime_ns", int(st.st_mtime * 1000000000)), st.st_size)
    except OSError:
        return None


def _genre_latest_file_stamp():
    """Read only latest-order file metadata; never walk all category caches."""
    try:
        from .ui import _genre_cache_file
        st = os.stat(_genre_cache_file("latest_order.json"))
        return (getattr(st, "st_mtime_ns", int(st.st_mtime * 1000000000)), st.st_size)
    except OSError:
        # An installation with no GENRE Latest file still has a valid
        # stable (empty) revision; it must not rescan 36 caches forever.
        return (-1, 0)
    except Exception:
        return None


def _genre_backdrop_cache_scope():
    """Identify the actual image-cache root, and TMP's current boot.

    Home-feed selection snapshots survive on the data drive. A previous HDD
    selection or a prior boot's TMP selection must not suppress the first
    latest-package scan when current TMP artwork/catalogues are empty.
    """
    root = get_cache_root()
    if root.startswith("/tmp/"):
        try:
            with open("/proc/sys/kernel/random/boot_id", "r") as handle:
                return root + "|" + handle.read().strip()
        except Exception:
            # If unavailable, the cache root still separates TMP from HDD.
            pass
    return root


def _genre_snapshot_matches_cache(mode, source):
    """Only reuse a warm selection from this exact cache root / TMP boot."""
    try:
        row = _home_feed_cache_load().get(_home_feed_cache_key(mode, source)) or {}
        return row.get("selection_cache_scope") == _genre_backdrop_cache_scope()
    except Exception:
        return False


def _genre_snapshot_is_fresh(mode, source, expected_count):
    """Skip expensive rail rebuild on warm opens, but not changed GENRE Latest.

    Small/incomplete rails retry shortly. The source and enabled package filter
    are already included in 'mode'; the stored metadata detects GENRE updates.
    """
    try:
        row = _home_feed_cache_load().get(_home_feed_cache_key(mode, source)) or {}
        items = row.get("items") or []
        if not items:
            return False  # old-format snapshot: validate once and upgrade
        if str(mode).startswith(("backdrop_all_enabled_v52_two_per_package_vod_",
                                 "backdrop_all_enabled_v53_two_per_package_series_")):
            if row.get("selection_cache_scope") != _genre_backdrop_cache_scope():
                return False
        age = time.time() - float(row.get("updated") or 0)
        if str(mode).startswith("backdrop_all_enabled_v48_multirow_"):
            stamp = row.get("latest_file_stamp")
            return (stamp is not None and
                    tuple(stamp) == _genre_latest_file_stamp() and
                    age >= 0 and age < (6 * 60 * 60 if len(items) >= expected_count else 120))
        if row.get("latest_file_stamp") is None:
            return False  # old-format snapshot: validate once and upgrade
        # The two-per-package Latest rail is refreshed from the existing GENRE
        # package cache every five hours, even when temporarily incomplete.
        # Earlier partial-rail 120s retries generated repeated work on TMP.
        if str(mode).startswith(("backdrop_all_enabled_v52_two_per_package_vod_",
                                 "backdrop_all_enabled_v53_two_per_package_series_")):
            max_age = _GENRE_LATEST_SELECTION_INTERVAL
        elif str(mode).startswith("backdrop_all_enabled_v51_series_newest_"):
            max_age = 10 * 60 if len(items) >= expected_count else 120
        else:
            max_age = 6 * 60 * 60 if len(items) >= expected_count else 120
        if age < 0 or age > max_age:
            return False
        return tuple(row.get("latest_file_stamp")) == _genre_latest_file_stamp()
    except Exception:
        return False

def _package_diag(event, **fields):
    return None

def _home_feed_cache_load():
    with _HOME_FEED_CACHE_LOCK:
        signature = _home_feed_file_signature()
        if (_HOME_FEED_RAM["value"] is not None and
                signature == _HOME_FEED_RAM["signature"]):
            # Callers may modify the outer dictionary before saving it.
            return dict(_HOME_FEED_RAM["value"])
        try:
            with open(HOME_FEED_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
            data = data if isinstance(data, dict) else {}
        except Exception:
            data = {}
        _HOME_FEED_RAM["signature"] = signature
        _HOME_FEED_RAM["value"] = data
        return dict(data)


def _home_feed_cache_save(data):
    with _HOME_FEED_CACHE_LOCK:
        try:
            folder = os.path.dirname(HOME_FEED_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = HOME_FEED_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, HOME_FEED_CACHE_FILE)
            _HOME_FEED_RAM["signature"] = _home_feed_file_signature()
            _HOME_FEED_RAM["value"] = dict(data)
            return True
        except Exception:
            return False


def _home_feed_cache_key(mode, source=None):
    source = source or {}
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source) or "")
    except Exception:
        source_key = str(source.get("name") or source.get("url") or "")
    return "%s|%s" % (str(mode or "popular_movies"), source_key)


def _home_feed_cache_get(mode, source=None, allow_stale=True):
    data = _home_feed_cache_load()
    row = data.get(_home_feed_cache_key(mode, source)) or {}
    if not isinstance(row, dict):
        return []
    try:
        age = int(time.time()) - int(row.get("updated") or 0)
    except Exception:
        age = _HOME_FEED_CACHE_MAX_AGE + 1
    mode_text = str(mode or "")
    if mode_text.startswith(("backdrop_all_enabled_v52_two_per_package_vod_",
                             "backdrop_all_enabled_v53_two_per_package_series_",
                             "backdrop_package_two_v3_vod_",
                             "backdrop_package_two_v4_series_",
                             "backdrop_all_enabled_v54_package_cache_vod_",
                             "backdrop_all_enabled_v55_package_cache_series_",
                             "backdrop_all_enabled_v56_progressive_vod_",
                             "backdrop_all_enabled_v57_progressive_series_",
                             "backdrop_all_enabled_v58_fill_vod_",
                             "backdrop_all_enabled_v59_fill_series_",
                             "backdrop_all_enabled_v60_multi_vod_",
                             "backdrop_all_enabled_v61_multi_series_",
                             "backdrop_all_enabled_v62_added_series_")):
        # Both the last-good snapshot and its GENRE-signature selection share
        # the five-hour TTL; no 7-day old selection can shadow new cache data.
        max_age = _GENRE_LATEST_SELECTION_INTERVAL
    elif mode_text.startswith("backdrop_filtered_smart_") or mode_text.startswith("backdrop_all_enabled_"):
        # Unrelated old rails retain their original expiry policy.
        max_age = 6 * 60 * 60
        if mode_text.startswith("backdrop_all_enabled_") and len(row.get("items") or []) < 9:
            max_age = 10 * 60
    elif mode_text.startswith("backdrop_package_unique_v2_series_"):
        # Series featured ordering uses added/last_modified timestamps. A
        # short selection TTL prevents yesterday's cached choice hiding a
        # newly updated show; actual image and per-package caches are intact.
        max_age = 10 * 60 if len(row.get("items") or []) >= 9 else 120
    elif mode_text.startswith("backdrop_package_unique_v1_"):
        # Movies retain their existing six-hour featured selection policy.
        max_age = 6 * 60 * 60 if len(row.get("items") or []) >= 9 else 10 * 60
    elif mode_text.startswith("backdrop_package_first_movie_v2_"):
        max_age = 3 * 60
    elif mode_text.startswith("backdrop_updated_package_v1_"):
        max_age = 2 * 60
    elif mode_text.startswith("you_might_like_server_"):
        max_age = 12 * 60 * 60
    else:
        max_age = _HOME_FEED_CACHE_MAX_AGE
    if not allow_stale and age > max_age:
        return []
    items = row.get("items") or []
    return [dict(x) for x in items if isinstance(x, dict)]


def _home_feed_cache_put(mode, source, items, genre_order_stamp=None,
                         package_complete=None, package_retry_at=0, package_revision=None):
    rows = [dict(x) for x in (items or []) if isinstance(x, dict)]
    if not rows:
        return False
    with _HOME_FEED_CACHE_LOCK:
        data = _home_feed_cache_load()
        entry = {"updated": int(time.time()), "items": rows[:30]}
        if str(mode).startswith(("backdrop_all_enabled_v45_firstpaint_",
                                 "backdrop_all_enabled_v48_multirow_",
                                 "backdrop_all_enabled_v51_series_newest_",
                                 "backdrop_all_enabled_v52_two_per_package_vod_",
                                 "backdrop_all_enabled_v53_two_per_package_series_")):
            # Preserve the exact GENRE order revision that was validated.
            # A newer revision invalidates this warm-open fast path immediately.
            entry["latest_file_stamp"] = (genre_order_stamp if genre_order_stamp is not None
                                          else _genre_latest_file_stamp())
            if str(mode).startswith(("backdrop_all_enabled_v52_two_per_package_vod_",
                                     "backdrop_all_enabled_v53_two_per_package_series_")):
                entry["selection_cache_scope"] = _genre_backdrop_cache_scope()
        if str(mode).startswith(("backdrop_all_enabled_v54_package_cache_vod_",
                                 "backdrop_all_enabled_v55_package_cache_series_",
                                 "backdrop_all_enabled_v56_progressive_vod_",
                                 "backdrop_all_enabled_v57_progressive_series_",
                                 "backdrop_all_enabled_v58_fill_vod_",
                                 "backdrop_all_enabled_v59_fill_series_",
                                 "backdrop_all_enabled_v60_multi_vod_",
                                 "backdrop_all_enabled_v61_multi_series_",
                                 "backdrop_all_enabled_v62_added_series_")):
            entry["selection_cache_scope"] = _genre_backdrop_cache_scope()
            if package_complete is not None:
                entry["selection_complete"] = bool(package_complete)
                entry["selection_retry_at"] = int(package_retry_at or 0)
            if (str(mode).startswith(("backdrop_all_enabled_v62_added_series_",
                                      "backdrop_all_enabled_v60_multi_vod_"))
                    and package_revision is not None):
                entry["selection_packages_revision"] = package_revision
        data[_home_feed_cache_key(mode, source)] = entry
        if len(data) > 100:
            ordered = sorted(
                data.items(),
                key=lambda kv: int((kv[1] or {}).get("updated") or 0),
                reverse=True
            )[:80]
            data = dict(ordered)
        return _home_feed_cache_save(data)


def _package_backdrop_snapshot_mode(source, kind):
    """Separate cache for Latest artwork chosen from PACKAGES contents.

    This must not reuse GENRE-selected artwork from v52/v53.  Package
    filters and server identity remain part of the cache key.
    """
    allowed = get_allowed_category_ids(source, kind)
    if allowed is None:
        signature = "all"
    else:
        ids = sorted(str(cid) for cid in allowed if str(cid))
        signature = hashlib.sha1(",".join(ids).encode("utf-8")).hexdigest()[:14]
    # New key: never treat a v54/v55 two-item partial result as a full 5h rail.
    # v58/v59 invalidate partial v56/v57 rails mistakenly kept as complete.
    tag = "v62_added_series" if kind == "series" else "v60_multi_vod"
    return "backdrop_all_enabled_%s_%s_%s" % (tag, kind, signature)


def _series_packages_cache_revision(source, kind="series"):
    """Cheap revision of per-package SERIES cache used by Packages Latest.

    File mtime/size check only: do not parse every catalogue, download artwork,
    or start provider streams requests.  None means the category list has not
    been cached yet; keep the current last-good snapshot while it loads.
    """
    try:
        from .filters import _cache_path
        categories, _origin = get_cached_categories(
            source, kind, client=None, wait_for_server=False)
        if not categories:
            return None
        allowed = get_allowed_category_ids(source, kind)
        enabled = None if allowed is None else set(str(x) for x in allowed if str(x))
        identifiers = set()
        for category in filter_categories(source, kind, categories):
            if isinstance(category, dict):
                cid = str(category.get("category_id") or category.get("id") or "").strip()
            elif isinstance(category, (list, tuple)) and len(category) >= 2:
                cid = str(category[1] or "").strip()
            else:
                continue
            if cid and (enabled is None or cid in enabled):
                identifiers.add(cid)
        if not identifiers:
            return None
        digest = hashlib.sha1()
        for cid in sorted(identifiers):
            path = _cache_path(source, kind, cid)
            try:
                stat = os.stat(path)
                sig = "%s:%s" % (
                    getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1000000000)),
                    stat.st_size)
            except OSError:
                sig = "missing"
            digest.update((cid + "|" + sig + "\n").encode("utf-8"))
        return digest.hexdigest()
    except Exception:
        return None


def _package_backdrop_snapshot_is_fresh(mode, source):
    """No GENRE file dependency: validate only 5h age and cache-root scope."""
    try:
        entry = _home_feed_cache_load().get(_home_feed_cache_key(mode, source)) or {}
        if not entry.get("items"):
            return False
        if entry.get("selection_cache_scope") != _genre_backdrop_cache_scope():
            return False
        # Only a complete selection is reusable for five hours.
        if not entry.get("selection_complete"):
            return False
        age = time.time() - float(entry.get("updated") or 0)
        return 0 <= age < _PACKAGE_LATEST_SELECTION_INTERVAL
    except Exception:
        return False


_TITLE_MATCH_CACHE_LOCK = threading.Lock()


def _title_match_cache_load():
    try:
        with _TITLE_MATCH_CACHE_LOCK:
            with open(TITLE_MATCH_CACHE_FILE, "r") as h:
                data = json.load(h) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _title_match_cache_save(data):
    try:
        with _TITLE_MATCH_CACHE_LOCK:
            folder = os.path.dirname(TITLE_MATCH_CACHE_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = TITLE_MATCH_CACHE_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump(data, h, separators=(",", ":"), sort_keys=True)
            os.replace(tmp, TITLE_MATCH_CACHE_FILE)
        return True
    except Exception:
        return False


def _title_match_key(source, item):
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source or {}) or "")
    except Exception:
        source_key = str((source or {}).get("name") or (source or {}).get("url") or "")
    item = item or {}
    tid = str(item.get("tmdb_id") or item.get("id") or "").strip()
    title = str(item.get("_tmdb_title") or item.get("name") or item.get("title") or item.get("original_title") or "").strip().lower()
    year = str(item.get("year") or item.get("release_date") or item.get("releaseDate") or "")[:4]
    key = "%s|%s|%s|%s" % (source_key, tid, title, year)
    # Arabic "فيلم / مسلسل ..." titles: r144 cached wrong one-word matches.
    if re.match(u"^\\s*(?:[a-z]{2,3}\\s*[-|:]\\s*)?(?:فيلم|الفيلم|فلم|الفلم|افلام|أفلام|مسلسل|المسلسل|مسلسلات|برنامج|انمي|أنمي|كرتون)\\s", title if not isinstance(title, bytes) else title.decode("utf-8", "ignore")):
        key += "|label2"
    return key


def _title_match_cache_status(source, item):
    """Return (cached, match).

    cached=True with match=None is a real cached miss. This prevents the same
    unsuccessful automatic title search from running again every time details open.
    """
    key = _title_match_key(source, item)
    data = _title_match_cache_load()
    if key not in data:
        return False, None
    row = data.get(key)
    if not isinstance(row, dict):
        return False, None
    if row.get("miss") is True:
        return True, None
    match = row.get("match")
    if isinstance(match, dict):
        return True, dict(match)
    return False, None


def _title_match_cache_get(source, item):
    cached, match = _title_match_cache_status(source, item)
    return match if cached and isinstance(match, dict) else None


def _title_match_cache_put(source, item, match):
    data = _title_match_cache_load()
    key = _title_match_key(source, item)
    if isinstance(match, dict):
        data[key] = {"match": dict(match), "miss": False, "updated": int(time.time())}
    elif match is None:
        # Cache "not found" too. The poster/details placeholder can therefore stay
        # stable without repeating an expensive server search on every open.
        data[key] = {"match": None, "miss": True, "updated": int(time.time())}
    else:
        return False
    if len(data) > 1200:
        ordered = sorted(data.items(), key=lambda kv: int((kv[1] or {}).get("updated") or 0), reverse=True)[:1000]
        data = dict(ordered)
    return _title_match_cache_save(data)



# Unified artwork policies; preserve old helper names for other modules.
from .artwork_queue import provider_asset_url as _server_asset_url
from .poster_manager import provider_poster_url as _server_poster_url
from .backdrop_manager import provider_backdrop_url as _server_backdrop_url

def _content_landing_cache_path(source, kind):
    try:
        raw = "%s|%s|%s|%s|%s" % (
            source.get("type") or "", source.get("url") or source.get("portal") or "",
            source.get("username") or "", source.get("mac") or "", kind or ""
        )
        digest = hashlib.md5(raw.encode("utf-8")).hexdigest()
        return os.path.join(CONTENT_LANDING_CACHE_DIR, digest + ".json")
    except Exception:
        return ""

def _load_content_landing_cache(source, kind):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path or not os.path.exists(path):
            return []
        with open(path, "r") as fh:
            data = json.load(fh)
        return list(data.get("items") or [])[:64] if isinstance(data, dict) else []
    except Exception:
        return []

def _save_content_landing_cache(source, kind, items):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path:
            return
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({"saved": int(time.time()), "items": list(items or [])[:64]}, fh)
        try:
            os.replace(tmp, path)
        except AttributeError:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
    except Exception:
        pass

# Fixed-size background pool for frequent ContentHome artwork/category jobs.
# Navigation can generate requests much faster than slow portals/TMDb can answer;
# a thread-per-keypress design eventually exhausts Enigma2.  Keep only four
# workers and coalesce stale jobs by logical key instead.
_CONTENT_BG_QUEUE = _queue.Queue(maxsize=64)
# Selected-film hero work must not wait behind several slow featured-card,
# poster-warming or stale category workers.  Keep a separate bounded lane;
# it shares the same stale-ticket guard and does not create a thread per press.
_CONTENT_HERO_QUEUE = _queue.Queue(maxsize=12)
# Two workers reserved for visible backdrop resolution / verified alternatives.
# Keeping these separate from provider scans prevents a full general queue from
# silently losing three of four visible cards.  Stale tickets are coalesced.
_CONTENT_BACKDROP_QUEUE = _queue.Queue(maxsize=64)
# Country identity lookup must not sit behind slow image/poster work when
# entering Movies/TV Shows through a different navigation route.
_CONTENT_COUNTRY_QUEUE = _queue.Queue(maxsize=24)
_CONTENT_BG_LOCK = threading.RLock()
_CONTENT_BG_LATEST = {}
_CONTENT_BG_TICKETS = itertools.count(1)
_CONTENT_BG_STARTED = [False]
_CONTENT_BG_WORKERS = 4

def _content_bg_worker(index, work_queue=None):
    work_queue = work_queue or _CONTENT_BG_QUEUE
    while True:
        try:
            target, args, key, generation = work_queue.get()
        except Exception:
            continue
        try:
            if key is not None:
                try:
                    with _CONTENT_BG_LOCK:
                        if _CONTENT_BG_LATEST.get(key) != generation:
                            continue
                except Exception:
                    pass
            try:
                target(*args)
            except Exception:
                pass
        finally:
            # Each screen uses its own task key (often including id(self)).
            # Release the completed generation or the lookup grows forever
            # across repeated Movies/TV Shows openings and hero navigation.
            if key is not None:
                with _CONTENT_BG_LOCK:
                    if _CONTENT_BG_LATEST.get(key) == generation:
                        _CONTENT_BG_LATEST.pop(key, None)
            try:
                work_queue.task_done()
            except (ValueError, AttributeError):
                pass

def _ensure_content_bg_workers():
    with _CONTENT_BG_LOCK:
        if _CONTENT_BG_STARTED[0]:
            return
        _CONTENT_BG_STARTED[0] = True
        for index in range(_CONTENT_BG_WORKERS):
            worker = threading.Thread(target=_content_bg_worker, args=(index, _CONTENT_BG_QUEUE), name="TiviMateContentPool-%d" % (index + 1))
            worker.daemon = True
            worker.start()
        # Only one additional worker, dedicated to selected-film hero metadata.
        hero_worker = threading.Thread(target=_content_bg_worker,
                                       args=("hero", _CONTENT_HERO_QUEUE),
                                       name="TiviMateSelectedHero")
        hero_worker.daemon = True
        hero_worker.start()
        for index in range(4):  # r146: one per visible backdrop card
            backdrop_worker = threading.Thread(
                target=_content_bg_worker,
                args=("backdrop-%d" % index, _CONTENT_BACKDROP_QUEUE),
                name="TiviMateVisibleBackdrops-%d" % (index + 1))
            backdrop_worker.daemon = True
            backdrop_worker.start()
        country_worker = threading.Thread(
            target=_content_bg_worker,
            args=("country", _CONTENT_COUNTRY_QUEUE),
            name="TiviMateBackdropCountries")
        country_worker.daemon = True
        country_worker.start()

def _submit_content_bg(target, args=(), key=None, hero=False, backdrop=False, country=False):
    _ensure_content_bg_workers()
    # Admit and update the latest ticket together. A full queue must not
    # invalidate work it already accepted; unique tickets also avoid reuse
    # of generation 1 after a key's previous job has completed.
    with _CONTENT_BG_LOCK:
        generation = next(_CONTENT_BG_TICKETS) if key is not None else 0
        try:
            ( _CONTENT_COUNTRY_QUEUE if country else
              _CONTENT_HERO_QUEUE if hero else
              _CONTENT_BACKDROP_QUEUE if backdrop else
              _CONTENT_BG_QUEUE ).put_nowait(
                (target, tuple(args or ()), key, generation))
        except _queue.Full:
            return False
        if key is not None:
            _CONTENT_BG_LATEST[key] = generation
    return True

IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")

# Keep recently decoded pixmaps alive in RAM. This avoids ePicLoad decoding again
# when the user reopens the same movie during the current Enigma2 session.
_DETAILS_PIXMAP_CACHE = OrderedDict()
# Decoded pixmaps consume RAM on the receiver.  Keep a small LRU only while a
# details page is open; the full-quality source remains in the disk cache.
_DETAILS_PIXMAP_CACHE_LIMIT = 4
_DETAILS_DATA_CACHE = OrderedDict()
_DETAILS_DATA_CACHE_LIMIT = 12

def _tmdb_details_memory_key(key):
    """Isolate in-memory metadata by the user's configured TMDb language."""
    try:
        lang = TMDbClient().language
    except Exception:
        lang = "en-US"
    return "%s:%s" % (str(lang), str(key))

def _memory_get(cache, key):
    try:
        value = cache.pop(key)
        cache[key] = value
        return value
    except Exception:
        return None

def _memory_put(cache, key, value, limit):
    try:
        if key in cache:
            cache.pop(key)
        cache[key] = value
        while len(cache) > limit:
            cache.popitem(last=False)
    except Exception:
        pass


HOME_APPEARANCE_FILE = os.path.join(ETC_DIR, "home_appearance.json")

def _content_default_mode(kind):
    """Movies and TV Shows default to no lower poster feed."""
    try:
        with open(HOME_APPEARANCE_FILE, "r") as handle:
            data = json.load(handle) or {}
        key = "movies_content" if kind == "vod" else "series_content"
        return "none"
    except Exception:
        return "none"


def _content_mode_title(kind, mode):
    is_movies = kind == "vod"
    mode = str(mode or "none").strip().lower()
    if mode == "none":
        return ""
    if mode == "prime":
        return "Prime Video Movies" if is_movies else "Prime Video TV Shows"
    return "Netflix Movies" if is_movies else "Netflix TV Shows"


def _hero_preview_summary(value, limit=175):
    """Keep the Movies/Series hero summary above its action buttons.

    Full metadata is retained for the details screen.  Only the short preview
    shown on the banner is compacted, without changing text language or order.
    """
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    text = text[:limit].rsplit(" ", 1)[0].rstrip()
    return (text or str(value or "")[:limit]).rstrip(" .,؛،") + "…"


CONTENT_HOME = '''<screen name="ContentHomeScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">
<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />
<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/content_overlay.png" alphatest="blend" zPosition="2" />
<ePixmap position="0,0" size="1920,125" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/vod_nav_wave85_only.png" alphatest="blend" zPosition="3" />
<ePixmap position="20,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/home.png" alphatest="blend" zPosition="7" />
<widget name="top0" position="46,15" size="140,64" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="190,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/search.png" alphatest="blend" zPosition="7" />
<widget name="top1" position="216,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="360,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="7" />
<widget name="top2" position="386,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="530,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="7" />
<widget name="top3" position="556,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="700,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="7" />
<widget name="top4" position="726,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="870,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="7" />
<widget name="top5" position="896,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1040,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/genre.png" alphatest="blend" zPosition="7" />
<widget name="top6" position="1066,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1210,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="7" />
<widget name="top7" position="1236,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1380,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/server_finder.png" alphatest="blend" zPosition="7" />
<widget name="top8" position="1406,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1550,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="7" />
<widget name="top9" position="1576,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<ePixmap position="1720,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/favorites.png" alphatest="blend" zPosition="7" />
<widget name="top10" position="1746,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />
<widget name="topSelector" position="312,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />
<widget name="promoFrame" position="1500,398" size="300,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_logo_badge_wide.png" alphatest="blend" zPosition="5" />
<widget name="logoHintIcon" position="1522,420" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/logo_hint_icon.png" alphatest="blend" zPosition="6" />
<widget name="logoHint" position="1580,410" size="190,64" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="promoBanner" position="1506,414" size="288,54" alphatest="blend" scale="1" zPosition="7" />
<widget name="logoImage" position="330,112" size="600,104" alphatest="blend" scale="1" zPosition="7" />
<widget name="logoTitle" position="65,132" size="1040,82" font="Regular;52" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4" />
<widget name="heroMeta" position="100,226" size="1050,40" font="Regular;26" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4" />
<widget name="heroDesc" position="100,276" size="1060,112" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="100,398" size="254,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_play_c.png" alphatest="blend" zPosition="5" />
<widget name="heroPlay" position="112,410" size="230,64" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<ePixmap position="368,398" size="284,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/hero_info_c.png" alphatest="blend" zPosition="5" />
<widget name="heroInfo" position="380,410" size="260,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="backdropTitle" position="80,500" size="720,45" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4"  halign="left" />
<widget name="backdrop0" position="82,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/backdrop_placeholder_transparent_406x206.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_frame_410x210.png" alphatest="blend" zPosition="5" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_shade_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="92,561" size="54,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_badge_54x40.png" alphatest="blend" zPosition="6" />
<widget name="rank0" position="96,560" size="46,42" font="Bold;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />
<widget name="backdropRate0" position="356,562" size="118,30" font="Regular;18" foregroundColor="#EEE3CA" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="7" />
<widget name="backdropFlag0" position="98,712" size="28,28" alphatest="blend" zPosition="7" scale="1" cornerRadius="14" />
<widget name="backdropLabel0" position="134,710" size="252,34" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="7" />
<widget name="backdrop1" position="537,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/backdrop_placeholder_transparent_406x206.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_frame_410x210.png" alphatest="blend" zPosition="5" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_shade_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="547,561" size="54,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_badge_54x40.png" alphatest="blend" zPosition="6" />
<widget name="rank1" position="551,560" size="46,42" font="Bold;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />
<widget name="backdropRate1" position="811,562" size="118,30" font="Regular;18" foregroundColor="#EEE3CA" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="7" />
<widget name="backdropFlag1" position="553,712" size="28,28" alphatest="blend" zPosition="7" scale="1" cornerRadius="14" />
<widget name="backdropLabel1" position="589,710" size="252,34" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="7" />
<widget name="backdrop2" position="992,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/backdrop_placeholder_transparent_406x206.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_frame_410x210.png" alphatest="blend" zPosition="5" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_shade_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1002,561" size="54,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_badge_54x40.png" alphatest="blend" zPosition="6" />
<widget name="rank2" position="1006,560" size="46,42" font="Bold;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />
<widget name="backdropRate2" position="1266,562" size="118,30" font="Regular;18" foregroundColor="#EEE3CA" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="7" />
<widget name="backdropFlag2" position="1008,712" size="28,28" alphatest="blend" zPosition="7" scale="1" cornerRadius="14" />
<widget name="backdropLabel2" position="1044,710" size="252,34" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="7" />
<widget name="backdrop3" position="1447,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/backdrop_placeholder_transparent_406x206.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_frame_410x210.png" alphatest="blend" zPosition="5" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_shade_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1457,561" size="54,40" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_badge_54x40.png" alphatest="blend" zPosition="6" />
<widget name="rank3" position="1461,560" size="46,42" font="Bold;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />
<widget name="backdropRate3" position="1721,562" size="118,30" font="Regular;18" foregroundColor="#EEE3CA" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="7" />
<widget name="backdropFlag3" position="1463,712" size="28,28" alphatest="blend" zPosition="7" scale="1" cornerRadius="14" />
<widget name="backdropLabel3" position="1499,710" size="252,34" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="7" />
<widget name="backdropSelector" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/fast_backdrop_focus_410x210.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="latestTitle" position="80,772" size="720,45" font="Regular;32" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4"  halign="left" />
<widget name="latestCategoryName" position="80,772" size="1000,45" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="8" />
	<widget name="latest0" position="82,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell0" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge0" position="88,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate0" position="88,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel0" position="142,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest1" position="297,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell1" position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge1" position="303,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate1" position="303,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel1" position="357,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest2" position="512,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell2" position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge2" position="518,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate2" position="518,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel2" position="572,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest3" position="727,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell3" position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge3" position="733,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate3" position="733,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel3" position="787,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest4" position="942,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell4" position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge4" position="948,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate4" position="948,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel4" position="1002,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest5" position="1157,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell5" position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge5" position="1163,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate5" position="1163,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel5" position="1217,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest6" position="1372,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell6" position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge6" position="1378,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate6" position="1378,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel6" position="1432,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest7" position="1587,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="latestShell7" position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<widget name="latestBadge7" position="1593,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate7" position="1593,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel7" position="1647,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latestSelector" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_170x205.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="footer" position="85,1042" size="1750,35" font="Regular;20" foregroundColor="#D4D7DD" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
</screen>'''

# Movie Details background in Movies / TV Shows: the fullscreen backdrop and
# its dim layer are background-only.  Both poster rails must have a strictly
# HIGHER zPosition than the dim layer.  The original Movie Details artwork
# is preserved; its opacity is toned down ONLY for the full-screen content
# home because the original 84-96% opaque PNG obscures the film backdrop.
# Never move the dim overlay to the front: Enigma2 zPosition is global within
# this Screen and source XML order is not a reliable replacement for zPosition.
_FAST_HERO_OLD = '<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />'
_FAST_HERO_NEW = '<widget name="hero" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="1" />'
_FAST_SHADE_OLD = '<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/content_overlay.png" alphatest="blend" zPosition="2" />'
_FAST_SHADE_NEW = '<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/movies_hero_partial_gradient_85.png" alphatest="blend" zPosition="2" />'


def _fast_movies_skin(original):
    assert original.count(_FAST_HERO_OLD) == 1, 'Fullscreen hero source definition changed'
    assert original.count(_FAST_SHADE_OLD) == 1, 'Fullscreen overlay source definition changed'
    xml = original.replace('name="ContentHomeScreen"', 'name="FastMoviesContentScreen"', 1)
    xml = xml.replace(_FAST_HERO_OLD, _FAST_HERO_NEW, 1)
    xml = xml.replace(_FAST_HERO_NEW, _FAST_HERO_NEW + '\n<widget name="trailerPreview" position="1160,126" size="700,394" backgroundColor="transparent" zPosition="3" />', 1)
    xml = xml.replace(_FAST_SHADE_OLD, _FAST_SHADE_NEW, 1)
    # In the original (Current) Movies page, replace only the featured Movies
    # heading; preserve the existing backdrop/rail layouts and overlay.
    xml = xml.replace('</screen>', (
        '<widget name="oldLatestMoviesLogo" position="80,497" size="300,50" '
        'alphatest="blend" scale="1" zPosition="8" />'
        # Show the actual active mode below the existing SORT title on
        # Current, Classic/Backdrop and New layouts; no floating hero badge.
        '<widget name="moviesSortIndicator" position="746,1051" size="170,23" '
        'font="Regular;17" foregroundColor="#E8EDF3" backgroundColor="#00000000" '
        'transparent="1" halign="left" valign="center" zPosition="38" />'
        '</screen>'), 1)
    # Cinematic-style trailer countdown and persistent 0 ON/OFF legend, on
    # Movies and TV Shows' shared backdrop browser only.
    xml = xml.replace('</screen>', (
        '<widget name="backdropTrailerCount" position="1660,132" size="184,120" font="Regular;84" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="12" />'
        '<widget name="backdropTrailerCaption" position="1660,247" size="184,30" font="Regular;20" foregroundColor="#E7C56B" transparent="1" halign="center" zPosition="12" />'
        # The footer toolbar already contains the 0 key legend.  Do not
        # create an offscreen ePixmap: Pure2 may clamp negative coordinates
        # to the top-left corner and draw the icon there.
        '<widget name="backdropTrailerToggleHint" position="1810,1050" size="72,26" font="Regular;17" foregroundColor="#F8D278" transparent="1" halign="center" zPosition="38" />'
        '</screen>'), 1)

    # Preserve the existing footer Label instance for dynamic status calls, but
    # remove the old small bottom hints in favor of the approved unified bar.
    xml = xml.replace('name="footer" position="85,1042" size="1750,35"',
                      'name="footer" position="1920,1080" size="1,1"', 1)
    # Backdrop cards and posters originally shared z=2 with the fullscreen
    # overlay, so some Enigma2 builds drew the dim above these images.
    # Keep all 12 original card positions, sizes, frames, labels and buttons.
    for index in range(4):
        key = 'name="backdrop%d"' % index
        matches = re.findall(r'<widget\s+[^>]*?%s[^>]*?/>' % key, xml)
        assert len(matches) == 1, ('backdrop widget missing',key,len(matches))
        old = matches[0]
        assert 'zPosition="2"' in old
        xml = xml.replace(old, old.replace('zPosition="2"','zPosition="3"'),1)
    for index in range(8):
        key = 'name="latest%d"' % index
        matches = re.findall(r'<widget\s+[^>]*?%s[^>]*?/>' % key, xml)
        assert len(matches) == 1, ('poster widget missing',key,len(matches))
        old = matches[0]
        assert 'zPosition="2"' in old
        xml = xml.replace(old, old.replace('zPosition="2"','zPosition="3"'),1)
        # Move the card shell above the artwork, but below badges and text.
        shell = re.findall(r'<widget\s+[^>]*?name="latestShell%d"[^>]*?/>' % index, xml)
        assert len(shell) == 1
        assert 'zPosition="3"' in shell[0]
        xml = xml.replace(shell[0],shell[0].replace('zPosition="3"','zPosition="4"'),1)
    # Lower recommendation posters already hide their shell until artwork is
    # decoded. Cinematic backdrop cards need that same lifecycle: an ePixmap
    # cannot be hidden dynamically, so register its decorations as Pixmaps.
    for suffix, filename in (
        ("Frame", "fast_backdrop_frame_410x210.png"),
        ("Shade", "fast_backdrop_shade_410x210.png"),
        ("Badge", "fast_backdrop_badge_54x40.png"),
    ):
        matches = re.findall(
            r'<ePixmap[^>]*pixmap="[^"]*/' + re.escape(filename) + r'"[^>]*/>',
            xml)
        assert len(matches) == 4, (filename, len(matches))
        for slot, original in enumerate(matches):
            dynamic = original.replace(
                "<ePixmap ", '<widget name="backdrop%s%d" ' % (suffix, slot), 1)
            assert original in xml
            xml = xml.replace(original, dynamic, 1)
    # Current (old) Movies + TV Shows: enlarge only the eight Latest posters
    # by about 7%. Keep the lower edge at 1030 to preserve the footer, and
    # leave the Backdrop rail, upper content, labels, flags and queues alone.
    for index, left in enumerate((80, 295, 510, 725, 940, 1155, 1370, 1585)):
        poster_old = ('name="latest%d" position="%d,827" size="166,201"' % (index, left+2))
        poster_new = ('name="latest%d" position="%d,813" size="178,215"' % (index, left+2))
        shell_old = ('name="latestShell%d" position="%d,825" size="170,205"' % (index, left))
        shell_new = ('name="latestShell%d" position="%d,811" size="182,219"' % (index, left))
        assert xml.count(poster_old) == 1 and xml.count(shell_old) == 1
        xml = xml.replace(poster_old, poster_new, 1).replace(shell_old, shell_new, 1)
    old_shell = '/skins/poster/poster_card_shell_r75_170x205.png'
    new_shell = '/skins/poster/poster_card_shell_r135_182x219.png'
    assert xml.count(old_shell) == 8
    xml = xml.replace(old_shell, new_shell)
    old_focus = ('name="latestSelector" position="80,825" size="170,205"')
    new_focus = ('name="latestSelector" position="80,811" size="182,219"')
    assert xml.count(old_focus) == 1
    xml = xml.replace(old_focus, new_focus, 1)
    old_focus_file = '/skins/poster/poster_card_focus_r75_170x205.png'
    new_focus_file = '/skins/poster/poster_card_focus_r135_182x219.png'
    assert xml.count(old_focus_file) == 1
    xml = xml.replace(old_focus_file, new_focus_file, 1)
    # Seven-key legend: shared graphic reused by Current Movies, New Movies,
    # and Series. The old buttons are not rendered underneath it.
    xml = xml.replace('</screen>',
        '<ePixmap position="20,1027" size="1880,52" '
        'pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/poster_actions_toolbar_trailer_newsort.png" '
        'alphatest="blend" zPosition="35" />\n'
        '<widget name="footerServerName" position="523,1052" size="140,22" font="Regular;15" foregroundColor="#DCE6F0" backgroundColor="#00000000" transparent="1" halign="left" valign="center" noWrap="1" zPosition="38" />' + '\n</screen>', 1)
    return xml



def _classic_package_tile_rail_skin(xml):
    """Replace the old Backdrop + Latest lower rail with the NEW lower rail.

    This copies the six bottom cards from movies_new_layout._new_skin() at their
    ORIGINAL positions, sizes, layers and asset paths. Only runtime widget IDs
    are adapted to ContentHomeScreen's existing rendering/caching pipeline.
    The upper Backdrop, provider requests, six-slot paging and navigation stay
    separate from the selectable New Movies screen.
    """
    import xml.etree.ElementTree as ET
    root = ET.fromstring(xml)
    root.set('name', 'FastMoviesContentScreen')
    movie_root = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/'

    # Canonical values from movies_new_layout: _MOVIE_X, _MOVIE_Y/W/H.
    poster_x = (312, 579, 846, 1113, 1380, 1647)
    y, w, h = 778, 165, 248

    # Remove the OLD lower artwork from the render tree, not merely recolor
    # or stack it behind the new rail. Runtime names required by the original
    # image callbacks remain registered as offscreen 1x1 compatibility widgets.
    for node in list(root):
        name = node.get('name', '')
        if name in ('latestTitle', 'latestCategoryName'):
            node.set('position', '1920,1080')
            node.set('size', '1,1')
            continue
        # The old poster shell and rating badge were still in the skin, then
        # shown again by the original image callback after every poster decode.
        # They are NOT part of the approved New Movies rail. Remove their XML
        # nodes entirely; the Python compatibility components stay registered
        # so existing hide() calls on legacy names remain harmless.
        if re.fullmatch(r'latest(?:Shell|Badge)[0-7]', name):
            root.remove(node)
            continue
        match = re.fullmatch(r'latest(?:Rate|Label)?([0-7])', name)
        if not match:
            continue
        slot = int(match.group(1))
        is_poster = name == 'latest%d' % slot and slot < 6
        if is_poster:
            # Exact clone of the new lower poster (backdropMovie%d):
            # widget(..., x, _MOVIE_Y, _MOVIE_W, _MOVIE_H, 18, scale=1).
            node.set('position', '%d,%d' % (poster_x[slot], y))
            node.set('size', '%d,%d' % (w, h))
            node.set('pixmap', movie_root+'movies_new_portrait_placeholder.jpg')
            node.set('alphatest', 'blend')
            node.set('scale', '1')
            node.set('zPosition', '18')
        elif name == 'latestRate%d' % slot and slot < 6:
            # New rail: firstMovieRate%d over the lower fade.
            node.set('position', '%d,%d' % (poster_x[slot]+46, y+210))
            node.set('size', '%d,28' % (w-54))
            node.set('font', 'Bold;20')
            node.set('foregroundColor', '#F7D47A')
            node.set('backgroundColor', '#00000000')
            node.set('transparent', '1')
            node.set('halign', 'left')
            node.set('zPosition', '24')
        else:
            # Old shell, badge, floating title, and unused 7th/8th cards.
            node.set('position', '1920,1080')
            node.set('size', '1,1')
            node.set('zPosition', '0')

    # Same focus image, location and layer as NewMoviesContentScreen.
    selector = next(n for n in root if n.get('name') == 'latestSelector')
    selector.set('position', '%d,%d' % (poster_x[0]-5, y-5))
    selector.set('size', '%d,%d' % (w+10, h+10))
    selector.set('pixmap', movie_root+'movies_cinema_poster_focus_portrait.png')
    selector.set('alphatest', 'blend')
    selector.set('scale', '1')
    selector.set('zPosition', '27')

    def panel(filename, x, yy, width, height, z, scale=False):
        props = {'position':'%d,%d' % (x,yy), 'size':'%d,%d' % (width,height),
                 'pixmap':movie_root+filename, 'alphatest':'blend',
                 'zPosition':str(z)}
        if scale:
            props['scale'] = '1'
        ET.SubElement(root, 'ePixmap', props)

    def widget(name, x, yy, width, height, z, **props):
        values = {'name':name, 'position':'%d,%d' % (x,yy),
                  'size':'%d,%d' % (width,height), 'zPosition':str(z)}
        values.update({k:str(v) for k,v in props.items()})
        ET.SubElement(root, 'widget', values)

    # The exact NEW lower row, with only names mapped to classic aliases.
    # Same assets, layers, aspect ratios, positions and no extra silver shell.
    panel('movies_cinema_category_single.png', 80, y, w, h, 19, scale=True)
    widget('classicPackageName', 88, y+76, w-16, 100, 24,
           font='Bold;22', halign='center', valign='center',
           foregroundColor='#FFFFFF', transparent='1')
    widget('classicPackageLogo', 80+(w-204)//2, y+(h-34)//2,
           204, 34, 25, alphatest='blend', scale='1')
    widget('classicPackageYear', 80+(w-92)//2, y+h-47,
           92, 32, 26, alphatest='blend', scale='1')

    for slot, x in enumerate(poster_x):
        # ePixmap ordering is identical to _new_skin()'s lower poster loop.
        panel('movies_cinema_poster_frame.png', x-4, y-4,
              w+8, h+8, 19, scale=True)
        panel('movies_gallery_lower_fade.png', x, y+175,
              w, 73, 20, scale=True)
        # New lower title widget is intentionally empty. Original latestLabel
        # remains parked, preserving ContentHomeScreen callbacks without text.
        widget('classicMovieFlag%d' % slot, x+9, y+210,
               30, 30, 24, alphatest='blend', scale='1', cornerRadius='15')

    return ET.tostring(root, encoding='unicode')

FAST_MOVIES_CONTENT_HOME = scale_skin(_fast_movies_skin(CONTENT_HOME))
# TV shows use the same class in parts of the UI: retain their original dim.
FAST_MOVIES_CONTENT_HOME_SERIES = FAST_MOVIES_CONTENT_HOME.replace(
    '/skins/movies/movies_hero_partial_gradient_85.png',
    '/skins/movies/details_overlay_content_safe.png', 1)

# Use a separate skin ONLY for the classic/old page.  The selectable New
# Movies and 24-grid designs keep the original FAST_MOVIES_CONTENT_HOME.
FAST_MOVIES_CLASSIC_PACKAGE_RAIL = scale_skin(
    _classic_package_tile_rail_skin(_fast_movies_skin(CONTENT_HOME)))
FAST_MOVIES_CLASSIC_PACKAGE_RAIL_SERIES = FAST_MOVIES_CLASSIC_PACKAGE_RAIL.replace(
    '/skins/movies/movies_hero_partial_gradient_85.png',
    '/skins/movies/details_overlay_content_safe.png', 1)

CONTENT_HOME = scale_skin(CONTENT_HOME)

# Retired accessibility ContentHome skin removed.

CATEGORY_POPUP = '''<screen name="ServerCategoryList" position="300,120" size="1320,840" flags="wfNoBorder" backgroundColor="#071A2B">
<widget name="panel" position="0,0" size="1320,840" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/category_popup_panel.png" alphatest="blend" zPosition="0" />
<widget name="brand" position="28,28" size="230,48" font="Regular;35" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="brandTagline" position="31,78" size="220,26" font="Regular;15" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideTitle" position="28,150" size="230,32" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideText" position="28,192" size="230,120" font="Regular;24" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="packageLogo" position="47,390" size="186,64" alphatest="blend" zPosition="4" />
<widget name="sectionBadge" position="42,696" size="196,35" font="Regular;19" foregroundColor="#FFFFFF" backgroundColor="#0D324A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="sideHint" position="40,778" size="200,22" font="Regular;15" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="title" position="350,26" size="700,46" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="subtitle" position="350,74" size="650,28" font="Regular;26" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="count" position="1030,38" size="225,34" font="Regular;24" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="2" />
<widget name="listHeader" position="367,134" size="400,25" font="Regular;27" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="list" position="350,192" size="890,472" font="Regular;27" itemHeight="58" scrollbarMode="showOnDemand" backgroundColor="#0A2134" foregroundColor="#F5F8FC" selectionBackgroundColor="#E8B83F" selectionForegroundColor="#071A2B" zPosition="2" />
<widget name="keys" position="350,720" size="910,62" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="actionButtons" position="350,733" size="910,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/category_popup_buttons_r67.png" alphatest="blend" zPosition="3" />
</screen>'''

CATEGORY_POPUP = scale_skin(CATEGORY_POPUP)


# ---------------------------------------------------------------------------
# Content category list
# ---------------------------------------------------------------------------

_ACTOR_DEFAULT = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/actor_default_%d.png"


class ServerCategoryList(Screen):
    skin = CATEGORY_POPUP
    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self.source, self.kind = source, kind
        self.rows = []
        is_movies = kind == "vod"
        self["panel"] = Pixmap()
        self["brand"] = Label(tr("TiViMate"))
        self["brandTagline"] = Label(tr("IPTV EXPERIENCE"))
        self["sideTitle"] = Label(tr("YOUR LIBRARY"))
        self["sideText"] = Label(tr("Choose a collection\nto browse titles from\nyour selected server."))
        self["sectionBadge"] = Label(tr("MOVIES") if is_movies else tr("TV SHOWS"))
        self["sideHint"] = Label(tr("Press OK to open"))
        self["packageLogo"] = Pixmap()
        self["title"] = Label(tr("MOVIE CATEGORIES") if is_movies else tr("TV SHOW CATEGORIES"))
        self["subtitle"] = Label(tr("Browse the collections available on your server"))
        self["count"] = Label(tr(""))
        self["listHeader"] = Label(tr("AVAILABLE COLLECTIONS"))
        self["list"] = MenuList([])
        self["keys"] = Label("")
        self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close, "up": self.up, "down": self.down,
            "pageUp": self.pageUp, "pageDown": self.pageDown
        }, -1)
        self._categoryLoadToken = 0
        self._categoryLoadResult = None
        self._categoryLoadClosed = False
        self._categoryLoadStartedAt = 0.0
        self._categoryLoadTimer = eTimer()
        self._packageLogoTimer = eTimer()
        self._packageLogoLoader = None
        self._packageLogoPath = ""
        self._packageLogoPixmapCache = {}
        try:
            self._packageLogoTimer_conn = self._packageLogoTimer.timeout.connect(self._updatePackageLogo)
        except Exception:
            try:
                self._packageLogoTimer.callback.append(self._updatePackageLogo)
            except Exception:
                self._packageLogoTimer.timeout.get().append(self._updatePackageLogo)
        try:
            self._categoryLoadTimer_conn = self._categoryLoadTimer.timeout.connect(self._finishCategoryLoad)
        except Exception:
            try:
                self._categoryLoadTimer.callback.append(self._finishCategoryLoad)
            except Exception:
                self._categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        try:
            self["list"].onSelectionChanged.append(self._updatePackageLogo)
        except Exception:
            pass
        self.onLayoutFinish.append(self.load)
        self.onClose.append(self._stopCategoryLoader)

    def _stopCategoryLoader(self):
        self._categoryLoadClosed = True
        self._categoryLoadToken += 1
        try:
            self._categoryLoadTimer.stop()
            self._packageLogoTimer.stop()
        except Exception:
            pass

    def load(self):
        self._categoryLoadToken += 1
        token = self._categoryLoadToken
        source = dict(self.source)
        kind = self.kind
        self._categoryLoadResult = None
        self._categoryLoadStartedAt = time.monotonic()
        self["count"].setText(tr(""))

        def worker():
            try:
                cats, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                cats = filter_categories(source, kind, cats or [])
                rows = [(entry.get("category_name") or "Other", str(entry.get("category_id") or "")) for entry in cats]
                result = (token, rows, origin, "")
            except Exception as exc:
                result = (token, [], "error", str(exc))
            if not self._categoryLoadClosed and token == self._categoryLoadToken:
                self._categoryLoadResult = result

        _submit_content_bg(worker, key=("category-popup", id(self)))
        try:
            self._categoryLoadTimer.start(200, True)
        except Exception:
            pass

    def _finishCategoryLoad(self):
        if self._categoryLoadClosed:
            return
        result = self._categoryLoadResult
        if not result:
            if time.monotonic() - self._categoryLoadStartedAt > 12.0:
                self._categoryLoadToken += 1
                self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
                self["subtitle"].setText(tr("Check the selected server and try again"))
                self["count"].setText(tr("NO COLLECTIONS"))
                return
            try:
                self._categoryLoadTimer.start(250, True)
            except Exception:
                pass
            return
        self._categoryLoadResult = None
        token, rows, origin, error = result
        if token != self._categoryLoadToken:
            return
        if error:
            self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
            self["subtitle"].setText(tr("Check the selected server and try again"))
            self["count"].setText(tr("NO COLLECTIONS"))
            self["keys"].setText(error[:120])
            return
        self.rows = rows or []
        self["list"].setList(self.rows)
        self._updatePackageLogo()
        try:
            self._packageLogoTimer.start(120, True)
        except Exception:
            pass
        count = len(self.rows)
        self["count"].setText("%d COLLECTION%s" % (count, "" if count == 1 else "S"))
        if not count:
            self["subtitle"].setText(tr("No enabled collections are available for this server"))


    def _packageBrand(self, name):
        _key, path = package_provider_key(name), package_logo_path(name, self.kind)
        return os.path.basename(path) if path else ""

    def _drawPackageLogo(self, path):
        widget = self["packageLogo"]
        self._packageLogoPath = str(path or "")
        if not path or not os.path.exists(path):
            try: widget.hide()
            except Exception: pass
            return
        try:
            size = widget.instance.size() if widget.instance else None
            width = max(1, int(size.width())) if size is not None else 220
            height = max(1, int(size.height())) if size is not None else 84
        except Exception:
            width, height = 220, 84
        try:
            stamp = int(os.path.getmtime(path))
        except Exception:
            stamp = 0
        cache_key = (path, width, height, stamp)
        cached = self._packageLogoPixmapCache.get(cache_key)
        if cached is not None:
            try:
                if self._packageLogoPath == path and widget.instance:
                    widget.instance.setPixmap(cached)
                    widget.show()
                return
            except Exception:
                pass
        loader = ePicLoad()
        self._packageLogoLoader = loader
        def ready(_=None, current=loader, expected=path, expected_key=cache_key):
            try:
                if self._packageLogoLoader is not current or self._packageLogoPath != expected:
                    return
                pix = current.getData()
                if pix and widget.instance:
                    self._packageLogoPixmapCache[expected_key] = pix
                    if len(self._packageLogoPixmapCache) > 32:
                        try:
                            oldest = next(iter(self._packageLogoPixmapCache))
                            if oldest != expected_key:
                                self._packageLogoPixmapCache.pop(oldest, None)
                        except Exception:
                            pass
                    widget.instance.setPixmap(pix)
                    widget.show()
                else:
                    widget.hide()
            except Exception:
                try: widget.hide()
                except Exception: pass
            finally:
                if self._packageLogoLoader is current:
                    self._packageLogoLoader = None
        try:
            connect_picture_data(loader, ready, self, oneshot=True)
            loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
            result = loader.startDecode(path)
            if isinstance(result, int) and result < 0:
                raise RuntimeError("decode-failed")
        except Exception:
            try:
                self._packageLogoLoader = None
            except Exception:
                pass
            try:
                if self._packageLogoPath == path and widget.instance:
                    widget.instance.setPixmapFromFile(path)
                    widget.show()
                else:
                    widget.hide()
            except Exception:
                try: widget.hide()
                except Exception: pass

    def _updatePackageLogo(self):
        try:
            current = self["list"].getCurrent()
            name = current[0] if current else ""
            from .package_logos import package_popup_logo_path
            path = package_popup_logo_path(name, self.kind) if current else ''
            if current and not path:
                path = package_logo_for_key("movies" if self.kind == "vod" else "series")
            if not path or not os.path.exists(path):
                self._packageLogoPath = ""
                self["packageLogo"].hide()
                return
            self._drawPackageLogo(path)
        except Exception:
            try:
                self._packageLogoPath = ""
                self["packageLogo"].hide()
            except Exception:
                pass


    def choose(self):
        current = self["list"].getCurrent()
        if current:
            self.close({"name": current[0], "id": current[1]})

    def up(self):
        self["list"].up()
        self._updatePackageLogo()

    def down(self):
        self["list"].down()
        self._updatePackageLogo()

    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: self["list"].up()
        self._updatePackageLogo()

    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: self["list"].down()
        self._updatePackageLogo()


MOVIE_DETAILS = '''<screen name="MovieDetailsScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="backdrop" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="poster" position="65,55" size="350,525" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" scale="1" />
<widget name="providerLogo" position="100,590" size="280,72" alphatest="blend" scale="1" zPosition="12" />
<widget name="title" position="600,72" size="760,132" font="Regular;48" halign="center" valign="center" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="logoImage" position="475,24" size="760,132" alphatest="blend" scale="1" zPosition="8" />
<widget name="meta" position="480,164" size="830,42" font="Regular;24" valign="center" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="countryFlag" position="335,491" size="64,64" alphatest="blend" scale="1" cornerRadius="32" zPosition="12" />
<widget name="ratingText" position="-1000,-1000" size="1,1" zPosition="0" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" noWrap="1" />
<widget name="ageIcon" position="1080,209" size="50,50" alphatest="blend" scale="1" zPosition="13" />
<widget name="desc" position="480,270" size="1000,135" font="Regular;29" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
	<widget name="watch" position="480,425" size="250,62" font="Regular;27" foregroundColor="#17191D" backgroundColor="#E8B83F" halign="center" valign="center" zPosition="5" />
	<widget name="sources" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0" />
	<widget name="trailer" position="770,425" size="250,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#6B3FA0" halign="center" valign="center" zPosition="5" />
	<widget name="moreInfo" position="1060,425" size="250,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#3C4652" halign="center" valign="center" zPosition="5" />
	<widget name="buttonSelector" position="475,420" size="260,72" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_action_selector_clean_cyan.png" alphatest="blend" zPosition="6" />
<widget name="actorsTitle" position="475,520" size="500,40" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="480,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel0" position="445,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor1" position="690,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel1" position="655,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor2" position="900,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel2" position="865,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor3" position="1110,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel3" position="1075,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor4" position="1320,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorLabel4" position="1285,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor5" position="1530,575" size="120,120" alphatest="blend" cornerRadius="60" zPosition="3" />
<widget name="actorSelector" position="474,569" size="132,132" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/actor_focus_r122.png" alphatest="blend" zPosition="7" />
<widget name="actorLabel5" position="1495,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="recommendTitle" position="65,774" size="510,62" alphatest="blend" zPosition="5" />
<widget name="rec0" position="65,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel0" position="65,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell0" position="65,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec1" position="530,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel1" position="530,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell1" position="530,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec2" position="995,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel2" position="995,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell2" position="995,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec3" position="1460,840" size="400,190" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel3" position="1460,1010" size="400,50" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" transparent="1" />
<widget name="recShell3" position="1460,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_400x220.png" alphatest="blend" zPosition="5" />
<widget name="rec4" position="1920,840" size="1,1" transparent="1" zPosition="0" />
<widget name="recLabel4" position="1920,840" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="0" />
<widget name="recShell4" position="1920,840" size="1,1" transparent="1" zPosition="0" />
	<widget name="recSelector" position="65,840" size="400,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r75_400x220.png" alphatest="blend" zPosition="8" scale="1" />
</screen>'''

MOVIE_DETAILS = scale_skin(MOVIE_DETAILS)


def _movie_continue_row(source, item):
    """Return a real Continue row for this movie, or build the same row shape once."""
    item = dict(item or {})
    # Never allow an embedded trailer item/URL into the movie Watch path.
    if item.get("_is_trailer") or str(item.get("_kind") or "").lower() == "trailer":
        return {}
    for _k in ("url", "stream_url"):
        _u = str(item.get(_k) or "").lower()
        if "youtube.com" in _u or "youtu.be" in _u or "googlevideo.com" in _u:
            item.pop(_k, None)
    try:
        from .ui import _source_identity
        source_key = str(_source_identity(source) or "")
    except Exception:
        source_key = ""

    wanted_id = str(
        (item or {}).get("stream_id") or
        (item or {}).get("vod_id") or
        (item or {}).get("id") or ""
    )
    wanted_title = str((item or {}).get("name") or (item or {}).get("title") or "").strip().lower()

    # Prefer the actual Continue Watching record if one exists.
    try:
        with open(data_path("resume.json"), "r") as handle:
            rows = json.load(handle) or {}
    except Exception:
        rows = {}

    if isinstance(rows, dict):
        for row in rows.values():
            if not isinstance(row, dict):
                continue
            saved_item = row.get("item") or {}
            servers = row.get("servers") or {}
            if source_key and isinstance(servers, dict) and source_key in servers:
                candidate = servers.get(source_key) or {}
                saved_item = candidate.get("item") or saved_item

            saved_id = str(
                saved_item.get("stream_id") or
                saved_item.get("vod_id") or
                saved_item.get("id") or ""
            )
            saved_title = str(
                saved_item.get("name") or saved_item.get("title") or row.get("title") or ""
            ).strip().lower()

            same = bool(wanted_id and saved_id and wanted_id == saved_id)
            if not same and wanted_title and saved_title:
                same = wanted_title == saved_title
            if same:
                return dict(row)

    # No Continue record yet: resolve the VOD URL once, then build the exact row shape.
    url = get_source_client(source).stream_url(item, "vod")
    if not url:
        return {}

    play_item = dict(item or {})
    play_item.pop("_continue_resume", None)
    play_item.pop("_continue_position", None)
    play_item["_source_type"] = (source or {}).get("type") or ""
    play_item["_source_key"] = source_key
    play_item["_kind"] = "vod"

    try:
        from .ui import _media_service_type
        service_type = int(_media_service_type(source, "vod"))
    except Exception:
        service_type = 4097

    server_entry = {
        "source_key": source_key,
        "source_type": (source or {}).get("type") or "",
        "streamurl": url,
        "service_type": service_type,
        "item": play_item,
    }
    return {
        "title": play_item.get("name") or play_item.get("title") or "MOVIE",
        "source_key": source_key,
        "source_type": (source or {}).get("type") or "",
        "streamurl": url,
        "service_type": service_type,
        "item": play_item,
        "servers": ({source_key: server_entry} if source_key else {}),
    }



# ---------------------------------------------------------------------------
# Movie details screen
# ---------------------------------------------------------------------------

MORE_INFO_SKIN = '''<screen name="MovieMoreInfoScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="hero" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/home/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="movieLogo" position="150,66" size="560,102" alphatest="blend" scale="1" zPosition="5" />
<widget name="title" position="150,90" size="1500,70" font="Regular;48" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="150,175" size="1500,42" font="Regular;25" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="stars" position="150,230" size="900,48" font="Regular;31" foregroundColor="#F5C542" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="1060,236" size="72,30" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/tmdb_badge.png" alphatest="blend" scale="1" zPosition="5" />
<widget name="rating" position="1165,235" size="395,40" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="150,300" size="1450,180" font="Regular;29" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="director" position="150,500" size="1450,40" font="Regular;23" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="cast" position="150,548" size="1550,34" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="150,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor1" position="410,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor2" position="670,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor3" position="930,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor4" position="1190,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actor5" position="1450,590" size="120,120" alphatest="blend" zPosition="4" />
<widget name="actorLabel0" position="278,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel1" position="538,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel2" position="798,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel3" position="1058,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel4" position="1318,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="actorLabel5" position="1578,590" size="125,120" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4" />
<widget name="otherSources" position="820,500" size="280,56" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#315976" halign="center" valign="center" zPosition="5" />
<widget name="partsButton" position="1120,500" size="280,56" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#2E7D4F" halign="center" valign="center" zPosition="5" />
<widget name="sourceSelector" position="810,490" size="300,76" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/more_info_source_selector_clean_cyan.png" alphatest="blend" zPosition="6" />
<widget name="counter" position="1570,748" size="200,34" font="Regular;20" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<widget name="thumb0" position="150,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb1" position="480,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb2" position="810,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb3" position="1140,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="thumb4" position="1470,790" size="300,142" alphatest="blend" zPosition="3" />
<widget name="selector" position="140,780" size="320,162" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/more_info_backdrop_selector_clean_cyan.png" alphatest="blend" zPosition="6" />
<widget name="hint" position="150,970" size="500,45" font="Regular;21" foregroundColor="#B9C0C9" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="4" />
</screen>'''
MORE_INFO_SKIN = scale_skin(MORE_INFO_SKIN)

class MovieMoreInfoScreen(Screen):
    skin = MORE_INFO_SKIN
    X = [140, 470, 800, 1130, 1460]
    def __init__(self, session, item, tmdb_id, bundle=None, sources_callback=None):
        Screen.__init__(self, session)
        self.sources_callback = sources_callback
        self.focus = "backdrops"
        self.item = dict(item or {})
        self.tmdb_id = str(tmdb_id or "").strip()
        self.bundle = dict(bundle or {})
        self.urls = []
        self.index = 0
        self.picloads = []
        self._closed = False
        self["hero"] = Pixmap()
        self["movieLogo"] = Pixmap()
        try: self["movieLogo"].hide()
        except Exception: pass
        self["title"] = DirectionalLabel(""); self["meta"] = CenteredArabicMetadataLabel(""); self["stars"] = Label("")
        self["rating"] = Label(""); self["desc"] = AdaptiveOverviewLabel(""); self["director"] = DirectionalLabel("")
        self["cast"] = Label(""); self["counter"] = Label(""); self["selector"] = Pixmap()
        from .resolution_badge import install_information_badge
        # The coloured pills replace the duplicate plain year/runtime/genre line.
        # Centre the entire four-pill row in the 1920px More Info canvas.
        install_information_badge(self, "meta", position=(682, 175), badges_only=True)
        self["otherSources"] = Label(tr("Other Sources")); self["sourceSelector"] = Pixmap()
        self["partsButton"] = Label(tr("Movie Parts")); self.sourceIndex = 0
        try: self["sourceSelector"].hide()
        except Exception: pass
        self["hint"] = Label("◀  Backdrop  ▶     GREEN  Movie Parts")
        for i in range(6):
            self["actor%d" % i] = Pixmap(); self["actorLabel%d" % i] = Label("")
            try: self["actor%d" % i].hide()
            except Exception: pass
        for i in range(5):
            self["thumb%d" % i] = Pixmap()
            try: self["thumb%d" % i].hide()
            except Exception: pass
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "cancel": self.close, "ok": self.ok, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "green": self.openParts
        }, -1)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._onClose)

    def _onClose(self):
        self._closed = True
        self.picloads[:] = []

    def _imageUrl(self, path):
        path = str(path or "").strip()
        if not path: return ""
        if path.startswith(("http://", "https://")): return path
        # Full-screen gallery: w1280 on FHD, w780 is already sharp on 720p.
        try:
            from .display_scale import desktop_size
            size = "w1280" if int(desktop_size()[0] or 1920) >= 1600 else "w780"
        except Exception:
            size = "w1280"
        return "https://image.tmdb.org/t/p/" + size + (path if path.startswith("/") else "/" + path)

    def _collect(self, data):
        rows = ((data or {}).get("images") or {}).get("backdrops") or []
        # TMDb can return many near-identical variants next to each other.
        # First remove exact file-path duplicates, then spread the selection over
        # the full TMDb backdrop set instead of taking the first adjacent rows.
        candidates=[]; seen=set()
        for row in rows:
            path = row.get("file_path") if isinstance(row, dict) else row
            url = self._imageUrl(path)
            key = str(path or url).strip().lower()
            if url and key and key not in seen:
                seen.add(key); candidates.append(url)

        # Keep the More Info rail intentionally diverse.  Adjacent TMDb rows are
        # commonly alternate crops/language variants of the same scene.
        out=[]
        limit=5
        if len(candidates) <= limit:
            out.extend(candidates)
        elif candidates:
            # Evenly sample from the complete result set, always including the
            # first and last candidates. This avoids clusters of repeated scenes.
            last=len(candidates)-1
            picked=set()
            for i in range(limit):
                idx=int(round((float(i)*last)/float(limit-1)))
                if idx not in picked:
                    picked.add(idx); out.append(candidates[idx])

        # Provider/current backdrop is only a fallback and never duplicates an
        # already selected TMDb image.
        for path in (self.bundle.get("backdrop_path"), self.item.get("_tmdb_backdrop"), self.item.get("backdrop_path"), self.item.get("backdrop")):
            url=self._imageUrl(path)
            if url and url not in out and len(out) < limit:
                out.append(url)
        return out

    def _year(self, data):
        value=(data or {}).get("release_date") or self.item.get("releaseDate") or self.item.get("release_date") or self.item.get("year") or ""
        return str(value)[:4]

    def _applyInfo(self, data):
        if self._closed: return
        data=dict(data or {})
        display = merge_metadata(self.item,
                                 provider=self.item.get("_detail_provider_info") or {},
                                 tmdb=data, language=TMDbClient().language, kind="vod")
        title = display["title"] or "Movie"
        year = display["year"]
        runtime = display["runtime"]
        from .resolution_badge import format_duration
        try:
            runtime=format_duration(runtime)
        except Exception:
            runtime=format_duration(runtime)
        genre_text = display["genre"]
        self["title"].setText(visible_title(title, 72))
        self["meta"].setText("  •  ".join(x for x in [year,runtime,genre_text] if x))
        # Server plot first. If absent, use TMDb; never replace valid server
        # text with a longer English synopsis simply because it is longer.
        self["desc"].setText((display["description"] or "No description available")[:900])
        rating = display["rating"]
        votes=data.get("vote_count") or ""
        try:
            rv=float(rating); filled=max(0,min(5,int(round(rv/2.0))))
            self["stars"].setText(("★"*filled)+("☆"*(5-filled)))
            # Score now appears in the shared pink pill. Keep votes only.
            self["rating"].setText(("%s votes" % votes) if votes else "")
        except Exception:
            self["stars"].setText(""); self["rating"].setText("")
        credits=data.get("credits") or {}
        crew=credits.get("crew") or []
        directors=[]
        for row in crew:
            if isinstance(row,dict) and str(row.get("job") or "").lower()=="director" and row.get("name"):
                if row.get("name") not in directors: directors.append(row.get("name"))
        self["director"].setText(("Director: " + ", ".join(directors[:2])) if directors else "")
        cast=[row for row in (credits.get("cast") or []) if isinstance(row,dict) and row.get("name")][:6]
        self["cast"].setText("Cast" if cast else "")
        self._renderCast(cast)
        self._applyMovieLogo(data)

    def _applyMovieLogo(self, data):
        # One logo path for every page: the shared identity/locale/alpha
        # resolver used by GENRE, Cinematic, Apple, Movie and Series Details.
        details = data if isinstance(data, dict) else {}
        tmdb_id = str(details.get('id') or details.get('tmdb_id') or
                      getattr(self, 'tmdb_id', '') or '').strip()
        from .logo_manager import logo_language
        token = '%s:%s' % (tmdb_id, logo_language())
        self._moreInfoLogoToken = token
        if not tmdb_id:
            try: self["movieLogo"].hide(); self["title"].show()
            except Exception: pass
            return
        item = getattr(self, 'item', {}) or {}
        def worker():
            path = ''
            try:
                from .title_logo_ultra_bridge import resolve_title_logo
                path = resolve_title_logo(TMDbClient(), 'vod', tmdb_id,
                    title=str(item.get('name') or item.get('title') or ''),
                    details=details, item=item, canvas=(560, 102),
                    cancelled=lambda: self._closed or self._moreInfoLogoToken != token)
            except Exception:
                path = ''
            if self._closed or self._moreInfoLogoToken != token:
                return
            if path:
                if reactor:
                    reactor.callFromThread(self._showMoreInfoIdentityLogo, path, token)
                return
            # Last resort (no alpha canvas could be prepared): transparent PNG.
            try:
                from .logo_manager import localized_logo_url
                url = localized_logo_url(TMDbClient(), 'movie', tmdb_id,
                    details.get('images') or {}, details=details, item=item)
                if not url:
                    return
                from .genre_ultra_artwork import request_transparent_logo
                def done(local):
                    if local and reactor:
                        reactor.callFromThread(self._showMoreInfoIdentityLogo, local, token)
                request_transparent_logo(url, {}, done, lambda _path: None,
                    lambda fn, value: reactor.callFromThread(fn, value) if reactor else None)
            except Exception:
                pass
        threading.Thread(target=worker, name='TiviMateMoreInfoClearlogo', daemon=True).start()

    def _showMoreInfoIdentityLogo(self, path, token):
        if self._closed or token != getattr(self, '_moreInfoLogoToken', None):
            return
        if path and os.path.isfile(path):
            self._decode(path, 'movieLogo', 560, 102)
            try: self["title"].hide()
            except Exception: pass

    def _profileUrl(self, path):
        path=str(path or "").strip()
        if not path: return ""
        if path.startswith(("http://","https://")): return path
        return "https://image.tmdb.org/t/p/w185" + (path if path.startswith("/") else "/"+path)

    def _renderCast(self, cast):
        for i in range(6):
            row=cast[i] if i < len(cast) else {}
            name=str(row.get("name") or "")
            character=str(row.get("character") or "")
            label=name + (("\n" + character) if character else "")
            self["actorLabel%d"%i].setText(label[:70])
            url=self._profileUrl(row.get("profile_path"))
            if url:
                self._load(url,"actor%d"%i,120,120,25,"posters")
            elif name:
                # No TMDb photo: neutral default portrait.
                try:
                    self["actor%d"%i].instance.setPixmapFromFile(_ACTOR_DEFAULT % 120)
                    self["actor%d"%i].show()
                except Exception: pass
            else:
                try: self["actor%d"%i].hide()
                except Exception: pass

    def start(self):
        self._applyInfo(self.bundle)
        self.urls = self._collect(self.bundle)
        if self.urls: self._applyUrls(self.urls)
        threading.Thread(target=self._fetchDetailsAndImages, name="TiviMateMoreInfo", daemon=True).start()

    def _fetchDetailsAndImages(self):
        try:
            tmdb=TMDbClient()
            if not tmdb.configured() or not self.tmdb_id: return
            details={}
            try: details=tmdb.details_bundle(self.tmdb_id, "vod") or {}
            except Exception: details={}
            try: images=tmdb._get("/movie/%s/images" % self.tmdb_id, {"include_image_language": image_languages(tmdb, self.bundle, self.item)}) or {}
            except Exception: images={}
            merged_data=dict(self.bundle); merged_data.update(details or {})
            if images: merged_data["images"]=images

            # More Info enrichment: TMDb often has a much fuller English overview
            # than the localized record used by Movie Details. Fetch it only on
            # this background More Info path and use it only when it is genuinely
            # longer, leaving the normal Movie Details metadata untouched.
            try:
                current_plot = str(merged_data.get("overview") or self.item.get("plot") or self.item.get("description") or "").strip()
                english = tmdb._get("/movie/%s" % self.tmdb_id, {"language":"en-US"}) or {}
                english_plot = str(english.get("overview") or "").strip()
                # Do not insert an English expansion over an available
                # French/Turkish/Arabic TMDb synopsis. Use it only if the
                # localized record has no description, or English is selected.
                if (english_plot and english_plot != current_plot and
                        len(english_plot) >= len(current_plot) + 60 and
                        (tmdb.language.lower().startswith("en") or not str(details.get("overview") or "").strip())):
                    merged_data["_more_info_overview"] = english_plot
            except Exception:
                pass
            self._lastMoreInfoData = dict(merged_data)
            urls=self._collect(merged_data)
            merged=[]
            for u in list(self.urls)+list(urls):
                if u and u not in merged: merged.append(u)
            if reactor is not None:
                reactor.callFromThread(self._applyInfo, merged_data)
                reactor.callFromThread(self._applyUrls, merged)
        except Exception: return

    def _applyUrls(self, urls):
        if self._closed: return
        self.urls=list(urls or [])
        if not self.urls: return
        if self.index >= len(self.urls): self.index=0
        self._render()

    def _load(self, url, widget, width, height, priority=50, bucket="backdrops"):
        if not url or self._closed: return
        def done(path, w=widget, x=width, y=height):
            if self._closed: return
            self._decode(path,w,x,y)
        request_artwork(url, bucket, done, priority=priority)

    def _decode(self, path, widget, width, height):
        if self._closed: return
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget):
            try:
                ptr=l.getData()
                if ptr and not self._closed and self[w].instance:
                    self[w].instance.setPixmap(ptr); self[w].show()
            except Exception: pass
            try: self.picloads.remove(l)
            except Exception: pass
        rw,rh=scale_size(width,height)
        connect_picture_data(loader,ready,self,oneshot=True)
        loader.setPara((rw,rh,0,0,False,1,"#00000000")); loader.startDecode(path)

    def _render(self):
        if not self.urls: return
        self["counter"].setText("%d / %d" % (self.index+1,len(self.urls)))
        self._load(self.urls[self.index],"hero",1920,1080,100)
        start=max(0,min(self.index-2,max(0,len(self.urls)-5)))
        visible=self.urls[start:start+5]
        for i in range(5):
            if i < len(visible): self._load(visible[i],"thumb%d"%i,300,142,30)
            else:
                try: self["thumb%d"%i].hide()
                except Exception: pass
        try:
            slot=self.index-start
            self["selector"].instance.move(ePoint(sx(self.X[max(0,min(4,slot))]),sy(780)))
        except Exception: pass

    def _focus(self):
        try:
            self["sourceSelector"].setVisible(self.focus == "sources")
            self["selector"].setVisible(self.focus == "backdrops" and bool(self.urls))
            if self.focus == "sources":
                x = 810 if int(getattr(self, "sourceIndex", 0) or 0) == 0 else 1110
                self["sourceSelector"].instance.move(ePoint(sx(x), sy(490)))
        except Exception:
            pass

    def left(self):
        if self.focus == "sources":
            self.sourceIndex = 0; self._focus(); return
        if self.focus == "backdrops" and self.urls:
            self.index=(self.index-1)%len(self.urls); self._render()
    def right(self):
        if self.focus == "sources":
            self.sourceIndex = 1; self._focus(); return
        if self.focus == "backdrops" and self.urls:
            self.index=(self.index+1)%len(self.urls); self._render()
    def up(self):
        self.focus = "sources"; self._focus()
    def down(self):
        self.focus = "backdrops"; self._focus()
    def openParts(self):
        """GREEN / Movie Parts: every part of this film's TMDb collection
        that exists on the server, shown like an actor's movies."""
        callback = getattr(self, "parts_callback", None)
        if not callable(callback):
            return
        def status(text):
            try:
                self["partsButton"].setText(text)
            except Exception:
                pass
        try:
            callback(self.tmdb_id, status)
        except Exception:
            pass
    def ok(self):
        if self.focus == "sources" and int(getattr(self, "sourceIndex", 0) or 0) == 1:
            self.openParts()
            return
        if self.focus == "sources" and callable(self.sources_callback):
            # Open the real Other Sources chooser above More Info.  Do not close
            # this screen first, otherwise Enigma2 falls back to Movie Details.
            try: self.sources_callback()
            except Exception: pass
            return
        self._render()

TRAILER_POPUP = scale_skin(r'''<screen name="TrailerPopupScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<widget name="trailerBackdrop" position="0,0" size="1920,1080" zPosition="0" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/details_overlay.png" alphatest="blend" zPosition="1" />
<eLabel position="398,223" size="1124,4" backgroundColor="#D7E3FF" zPosition="4" />
<eLabel position="398,852" size="1124,4" backgroundColor="#D7E3FF" zPosition="4" />
<eLabel position="398,223" size="4,633" backgroundColor="#D7E3FF" zPosition="4" />
<eLabel position="1518,223" size="4,633" backgroundColor="#D7E3FF" zPosition="4" />
<widget name="video" position="402,227" size="1116,625" backgroundColor="transparent" zPosition="2" />
<widget name="movieLogo" position="680,861" size="560,116" alphatest="blend" zPosition="5" />
<widget name="movieTitleFallback" position="610,875" size="700,80" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="4" />
<widget name="hint" position="410,1000" size="1100,30" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="4" />
</screen>''')

def _trailer_has_serviceapp():
    """Only select ServiceApp/5002 when its backend really is installed.

    Built-in 4097 remains the default. Never force exteplayer3 onto receivers
    without that Enigma2 service registered.
    """
    try:
        if not any(os.path.isfile(path) for path in (
                "/usr/bin/exteplayer3", "/usr/local/bin/exteplayer3")):
            return False
        plugin_dir = "/usr/lib/enigma2/python/Plugins"
        return any(os.path.isfile(os.path.join(plugin_dir, category,
                                            "ServiceApp", "plugin" + suffix))
                   for category in ("SystemPlugins", "Extensions")
                   for suffix in (".py", ".pyc", ".pyo"))
    except Exception:
        return False


def _trailer_reference(url, title, backend=4097):
    ref = eServiceReference(int(backend), 0, str(url or "").strip())
    try:
        ref.setName(str(title or "Trailer"))
    except Exception:
        pass
    return ref


class TrailerPopupScreen(Screen):
    skin = TRAILER_POPUP
    def __init__(self, session, service_ref, title="Trailer", parent_screen=None):
        Screen.__init__(self, session)
        self.parent_screen = parent_screen
        self.service_ref = service_ref
        self._trailer_backend_retried = False
        self["trailerBackdrop"] = Pixmap()
        self._backdrop_loader = None
        self._backdrop_url = ""
        if parent_screen is not None:
            try:
                item = parent_screen.item or {}
                self._backdrop_url = parent_screen._norm(
                    item.get("_tmdb_backdrop") or item.get("backdrop_path") or
                    item.get("backdrop") or item.get("backdrop_url"), "w780")
            except Exception:
                pass
        self.old_service = None
        try:
            self.old_service = session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass
        if VideoWindow is None:
            raise RuntimeError("VideoWindow is not available on this image")
        try:
            self["video"] = VideoWindow(decoder=0, fb_width=1920, fb_height=1080)
        except TypeError:
            self["video"] = VideoWindow(decoder=0)
        self["movieLogo"] = Pixmap()
        self["movieTitleFallback"] = Label(visible_title(title, 64))
        self._trailer_logo_loader = None
        self._trailer_logo_url = ""
        if parent_screen is not None:
            try:
                item = parent_screen.item or {}
                shared_path = getattr(parent_screen, "_movieTitleLogoPath", "") or ""
                self._trailer_logo_path = shared_path if shared_path and os.path.isfile(shared_path) else ""
                self._trailer_logo_url = str(item.get("_player_movie_logo") or "").strip()
                if not self._trailer_logo_url:
                    self._trailer_logo_url = parent_screen._movieLogoUrl(getattr(parent_screen, "_tmdb_bundle", {}) or {})
                self["movieTitleFallback"].setText(visible_title(item.get("name") or item.get("title") or title or "", 64))
            except Exception:
                pass
        self["movieLogo"].hide()
        self.onLayoutFinish.append(self._load_trailer_logo)
        self["hint"] = Label("BACK  Close Trailer")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close, "ok": self.close, "red": self.close
        }, -1)
        self.onLayoutFinish.append(self._load_trailer_backdrop)
        self.onLayoutFinish.append(self._play)
        if ServiceEventTracker is not None and iPlayableService is not None:
            failed = getattr(iPlayableService, "evTuneFailed", None)
            if failed is not None:
                self._trailer_events = ServiceEventTracker(
                    screen=self, eventmap={failed: self._trailer_tune_failed})
        self.onClose.append(self._restore)
        self.onClose.append(self._clear_parent)

    def _load_trailer_backdrop(self):
        if not self._backdrop_url:
            return
        def done(path):
            try:
                loader = ePicLoad()
                self._backdrop_loader = loader
                def ready(_=None):
                    try:
                        ptr = loader.getData()
                        if ptr and self["trailerBackdrop"].instance:
                            self["trailerBackdrop"].instance.setPixmap(ptr)
                            self["trailerBackdrop"].show()
                    except Exception:
                        pass
                connect_picture_data(loader, ready, self, oneshot=True)
                loader.setPara((1920,1080,0,0,False,1,"#000000"))
                loader.startDecode(path)
            except Exception:
                pass
        request_artwork(self._backdrop_url, "backdrops", done, priority=90)

    def _load_trailer_logo(self):
        shared_path = getattr(self, "_trailer_logo_path", "")
        if not self._trailer_logo_url and not shared_path:
            return
        def done(path):
            try:
                loader = ePicLoad()
                self._trailer_logo_loader = loader
                def ready(_=None):
                    try:
                        ptr = loader.getData()
                        if ptr and self["movieLogo"].instance:
                            self["movieLogo"].instance.setPixmap(ptr)
                            self["movieLogo"].show()
                            self["movieTitleFallback"].hide()
                    except Exception:
                        pass
                connect_picture_data(loader, ready, self, oneshot=True)
                loader.setPara((560,116,0,0,False,1,"#000000"))
                loader.startDecode(path)
            except Exception:
                pass
        if shared_path:
            # Same identity logo the Details page already shows (one path).
            done(shared_path)
            return
        request_artwork(self._trailer_logo_url, "logos", done, priority=90)

    def _clear_parent(self):
        parent = self.parent_screen
        if parent is not None:
            try:
                if getattr(parent, "_trailerOverlay", None) is self:
                    parent._trailerOverlay = None
            except Exception:
                pass

    def _play(self):
        try:
            response = self.session.nav.playService(self.service_ref)
            if response not in (None, 0):
                self._trailer_tune_failed()
        except Exception:
            self._trailer_tune_failed()

    def _trailer_tune_failed(self):
        """Try alternate receiver player only after native playback fails."""
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            if (current is not None and self.service_ref is not None and
                    current.toString() != self.service_ref.toString() and
                    (self.old_service is None or
                     current.toString() != self.old_service.toString())):
                return  # Do not touch another video playing on this receiver.
        except Exception:
            pass
        if (not self._trailer_backend_retried and
                getattr(self.service_ref, "type", 4097) != 5002 and
                _trailer_has_serviceapp()):
            self._trailer_backend_retried = True
            try:
                self.service_ref = _trailer_reference(
                    self.service_ref.getPath(), "Trailer", 5002)
                self.session.nav.playService(self.service_ref)
                return
            except Exception:
                pass
        try:
            self["hint"].setText("Trailer playback failed on this Enigma2 image  •  BACK to close")
        except Exception:
            pass

    def _restore(self):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        if self.old_service:
            try:
                self.session.nav.playService(self.old_service)
            except Exception:
                pass


def _resolve_movie_trailer_stream(tmdb_id, kind="vod"):
    """Resolve the same English official YouTube trailer as Movie Details.

    NETWORK WORKER ONLY. Never call from the GUI thread. Each response is
    either a direct progressive MP4 with audio/video or a harmless miss.
    """
    try:
        tmdb = TMDbClient(language="en-US")
        payload = tmdb.media_videos(int(tmdb_id), "series" if kind == "series" else "vod") or {}
        rows = (payload.get("results") or []) if isinstance(payload, dict) else []
        candidates = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            if str(row.get("site") or "").strip().lower() != "youtube":
                continue
            if str(row.get("type") or "").strip().lower() != "trailer":
                continue
            key = str(row.get("key") or "").strip()
            if not key or str(row.get("iso_639_1") or "").strip().lower() != "en":
                continue
            name = str(row.get("name") or "Trailer").strip() or "Trailer"
            score = 100 if bool(row.get("official")) else 0
            score += 40 if "official trailer" in name.lower() else (20 if "official" in name.lower() else 0)
            try:
                score += min(6, max(0, int(row.get("size") or 0) // 360))
            except Exception:
                pass
            candidates.append((score, str(row.get("published_at") or ""), row))
        if not candidates:
            return {"state": "missing"}
        candidates.sort(key=lambda val: (val[0], val[1]), reverse=True)
        from .services.ultrastalker_youtube import UltraYouTubeResolver
        resolver = UltraYouTubeResolver()
        # Prefer a self-contained MP4. If YouTube exposes only DASH audio +
        # video or HLS, use the same native fallback used by UltraStalker.
        # Do not download/transcode the trailer onto internal flash.
        failure = ""
        for _score, _published, chosen in candidates[:2]:
            try:
                direct = str(resolver.extract_receiver_ready(
                    str(chosen.get("key") or "").strip(), timeout=8) or "").strip()
                if direct.startswith(("https://", "http://")):
                    return {"state": "ready", "url": direct,
                            "split": "&suburi=" in direct,
                            "name": str(chosen.get("name") or "Trailer")}
            except Exception as exc:
                failure = str(exc)
        return {"state": "no_stream", "error": failure}
    except Exception as exc:
        return {"state": "error", "error": str(exc)}



def _tmdb_year_conflict(row, item_year, minutes_fn=None, tolerance=2):
    """True when a TMDb movie clearly is another film than the provider's.

    Providers often show the upload year (A Southern Haunting 2023 listed as
    2026), so a year gap alone is not enough: the runtime decides ("6 أيام"
    2025, 110 min vs "6 Days" 2017, 94 min). Without a runtime only an
    impossible case counts: TMDb released the film after the provider year.
    """
    try:
        wanted = int(str(item_year or "")[:4])
        found = int(str((row or {}).get("release_date") or (row or {}).get("first_air_date") or "")[:4])
    except Exception:
        return False
    if abs(found - wanted) <= tolerance:
        return False
    try:
        from .tmdb_client import _tmdb_runtime_minutes
        tm = _tmdb_runtime_minutes((row or {}).get("runtime"))
        pm = minutes_fn() if (tm and minutes_fn) else 0
    except Exception:
        tm = pm = 0
    if tm and pm:
        return abs(tm - pm) > 10
    return found > wanted + 1


def _tmdb_art_file(url):
    """TMDb file name of an image URL/path ("" when not TMDb-hosted)."""
    text = (u"%s" % (url or u"")).strip()
    if not text:
        return u""
    if text.startswith(u"/") and u"/" not in text[1:]:
        return text[1:].split(u"?", 1)[0].lower()
    if u"/t/p/" not in text:
        return u""
    return text.rsplit(u"/", 1)[-1].split(u"?", 1)[0].lower()


def _tmdb_art_files(data):
    """All poster/backdrop file names of one TMDb record, plus whether the
    full image list was present (details_bundle requests every language)."""
    data = data if isinstance(data, dict) else {}
    files = set()
    for key in ("poster_path", "backdrop_path"):
        name = _tmdb_art_file(data.get(key))
        if name:
            files.add(name)
    images = data.get("images") or {}
    full = False
    if isinstance(images, dict):
        for group in ("posters", "backdrops"):
            rows = images.get(group) or []
            if rows:
                full = True
            for row in rows:
                if isinstance(row, dict):
                    name = _tmdb_art_file(row.get("file_path"))
                    if name:
                        files.add(name)
    return files, full


def _provider_art_wrong(url, data):
    """True when a provider poster/backdrop is TMDb art of ANOTHER film.

    Providers often reuse TMDb image URLs; a wrong copy (e.g. Avengers art
    on an Arabic film) is detected by its TMDb file name.
    """
    name = _tmdb_art_file(url)
    if not name or not isinstance(data, dict):
        return False
    if name in set(data.get("_wrong_art_files") or []):
        return True
    if data.get("id"):
        files, full = _tmdb_art_files(data)
        if full and name not in files:
            return True
    return False


def _details_dual_title(title, tmdb_data=None, item=None, provider=None):
    """r146: details heading "عربي • English" when both names are known."""
    shown = visible_title(title, 72)
    try:
        if not re.search(u"[\u0600-\u06ff]", shown or u""):
            return shown
        def latin(value):
            text = visible_title(value or u"", 60)
            text = re.sub(u"\\s*[\\(\\[]?(?:19|20)\\d{2}[\\)\\]]?\\s*$", u"", text).strip()
            letters = [ch for ch in text if ch.isalpha()]
            if not letters:
                return u""
            ascii_letters = [ch for ch in letters if ord(ch) < 128]
            return text if len(ascii_letters) * 10 >= len(letters) * 9 else u""
        data = tmdb_data if isinstance(tmdb_data, dict) else {}
        english = u""
        for value in (data.get("original_title"), data.get("original_name"),
                      (provider or {}).get("o_name") if isinstance(provider, dict) else None,
                      (item or {}).get("o_name") if isinstance(item, dict) else None,
                      (item or {}).get("name") if isinstance(item, dict) else None):
            english = latin(value)
            if english:
                break
        if english and english.lower() not in shown.lower():
            return visible_title(shown + u"  \u2022  " + english, 80)
    except Exception:
        pass
    return shown


class MovieDetailsScreen(Screen):
    skin = MOVIE_DETAILS
    REC_X = [65, 530, 995, 1460]
    ACTOR_X = [474, 684, 894, 1104, 1314, 1524]
    def __init__(self, session, source, item, server_items=None, source_context=None):
        Screen.__init__(self, session)
        self.source = source
        self.item = item or {}
        # Untouched copy for MENU > Fix TMDb match (reopen with fresh data).
        self._manualMatchArgs = (source, dict(self.item), server_items, source_context)
        self._serverPackageProvider = str(self.item.get("_server_package_provider") or self.item.get("_tmdb_provider") or "")
        self.server_items = list(server_items or [])
        # Recommendations must never follow whichever page/list happens to be
        # current after the details screen opens. Keep a dedicated immutable
        # source context, separate from the provider-wide catalog used by Watch
        # and Other Sources.
        self.source_context = dict(source_context or {})
        self.recommendation_items = list(self.source_context.get("items") or server_items or [])
        self._recommendationCategoryId = str(
            self.source_context.get("category_id") or
            self.item.get("_source_category_id") or self.item.get("category_id") or ""
        ).strip()
        self._recommendationScope = str(
            self.source_context.get("scope") or self.item.get("_source_scope") or "details"
        ).strip()
        self._sourceTitleIndex = None
        self.sources_list = []
        self.recommendations = []
        self._recommendDecoded = set()
        self._recommendFallbackTried = set()
        self._recommendWatchAt = 0.0
        self._recommendWatchPass = 0
        self.actors = []
        self._primaryArtworkReady = False
        self._watchResolveStarted = False
        self._watchReady = bool(self.item.get("stream_id") or self.item.get("vod_id"))
        self._sourcesSearchRunning = False
        self._sourcesSearchDone = False
        self._fastVodRowsCache = None
        self._fullVodRowsCache = None
        self._vodSelectedSource = dict(self.source or {})
        # Exact-server VOD details must never be merged into the TMDb cache.
        # These provider values override only the visible text/facts; TMDb
        # artwork, official score and actor photos remain independent.
        self._serverMovieInfo = {}
        self._tmdb_bundle = {}
        self._movieProviderToken = ""
        self.focus = "buttons"
        self.button_index = 0
        self.rec_index = 0
        self.actor_index = 0
        self.downloads, self.picloads = [], []
        self._detail_pixmap_keys = set()
        self._image_requests = {}
        # Worker threads never touch Enigma2 widgets directly.  A small GUI
        # poller drains completed work on the main thread; the workers only
        # append plain Python call records to this queue.  This remains safe on
        # Python 3 Enigma2 and does not depend on Twisted reactor integration.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        self["backdrop"] = Pixmap(); self["poster"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["logoImage"] = Pixmap()
        try: self["logoImage"].hide()
        except Exception: pass
        self["title"] = DirectionalLabel(self.item.get("name") or self.item.get("title") or "Movie")
        self["meta"] = CenteredArabicMetadataLabel(""); self["desc"] = RisingOverviewLabel(tr(""))
        from .resolution_badge import install_information_badge
        install_information_badge(self, "meta", position=(480, 216), details_deduplicate=True)
        self["ratingText"] = Label("")
        self["ratingText"].setText("")
        self["countryFlag"] = Pixmap()
        self["countryFlag"].hide()
        self["ageIcon"] = Pixmap()
        self["ageIcon"].hide()
        self._movieAgeToken = ""
        self["watch"] = Label(tr("▶  Watch") if self._watchReady else tr("Searching...")); self["sources"] = Label(tr("Press for Other Sources")); self["trailer"] = Label("▶  Trailer"); self["moreInfo"] = Label("ⓘ  " + tr("More Info"))
        self["buttonSelector"] = Pixmap(); self["actorsTitle"] = Label(tr("Actors")); self["actorSelector"] = Pixmap()
        for i in range(6):
            self["actor%d" % i] = Pixmap()
            self["actorLabel%d" % i] = Label("")
            try:
                self["actor%d" % i].hide()
            except Exception:
                pass
        self["recommendTitle"] = Pixmap()
        for i in range(5):
            self["rec%d" % i] = Pixmap(); self["recLabel%d" % i] = Label("")
            self["recShell%d" % i] = Pixmap()
            # Keep the whole recommendation card hidden until its real backdrop
            # has decoded successfully: image + label + geometric shell appear together.
            for _name in ("rec%d" % i, "recLabel%d" % i, "recShell%d" % i):
                try:
                    self[_name].hide()
                except Exception:
                    pass
        self["recSelector"] = Pixmap()
        self._trailerOverlay = None
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.ok, "cancel": self._cancelOrCloseTrailer, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "green": self.watchSelected, "yellow": self.playTrailer,
            "menu": self._openManualTmdbMatch
        }, -1)
        self.onLayoutFinish.append(self._startGuiDispatch)
        self.onLayoutFinish.append(self._showRecommendationHeading)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._closeTrailerOverlay)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkMemory)


    def _updateProviderLogo(self):
        try:
            from .details_branding import detail_brand_logo
            path = detail_brand_logo(self.item, self.source_context)
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(120, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        # A full poster queue may discard a lower-priority recommendation
        # transfer without invoking a callback. Re-request missing visible cards
        # at most twice; successful decodes and unresolved metadata are skipped.
        try:
            watch_at = getattr(self, "_recommendWatchAt", 0.0)
            if watch_at and time.monotonic() >= watch_at and self._recommendWatchPass < 2:
                self._recommendWatchPass += 1
                self._recommendWatchAt = time.monotonic() + 7.0
                for index, row in enumerate(self.recommendations[:4]):
                    if index in self._recommendDecoded or index in self._recommendFallbackTried:
                        continue
                    raw = row.get("backdrop_path") or row.get("backdrop") or row.get("backdrop_url")
                    url = self._norm(raw, "w780")
                    if url:
                        self.loadImage(url, "rec%d" % index, 400, 190, retry=0)
        except Exception:
            pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(120, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _releaseArtworkMemory(self):
        # The local widgets are destroyed with the screen; release the LRU refs
        # too so large backdrops never accumulate between detail pages.
        self._image_requests = {}
        self.downloads = []
        self.picloads = []
        for key in list(getattr(self, "_detail_pixmap_keys", set())):
            _DETAILS_PIXMAP_CACHE.pop(key, None)
        self._detail_pixmap_keys = set()


    def _deferredServerMatch(self):
        """Resolve a TMDb discovery movie only after its details screen opens."""
        wanted_id = str(self.item.get("tmdb_id") or self.item.get("id") or "").strip()
        wanted = [self._title_norm(self.item.get(field)) for field in ("name", "title", "original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)

        def row_tmdb_id(row):
            row = row or {}
            for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                for key in ("tmdb_id", "tmdb", "tmdbid"):
                    value = mapping.get(key)
                    if value not in (None, ""):
                        try:
                            return str(int(value))
                        except Exception:
                            value = str(value).strip()
                            if value:
                                return value
            return ""

        def match_rows(rows):
            if wanted_id:
                for row in rows or []:
                    if row_tmdb_id(row) == wanted_id:
                        return dict(row)
            best = None
            best_score = 0.0
            for row in rows or []:
                row_year = self._year(row)
                if target_year and row_year and target_year != row_year:
                    continue
                candidates = [self._title_norm((row or {}).get(field)) for field in ("name", "title", "original_title")]
                score = max([self._title_score(a, b) for a in wanted for b in candidates] or [0.0])
                if target_year and row_year:
                    if score < 0.94:
                        continue
                elif score < 0.98:
                    continue
                if score > best_score:
                    best, best_score = dict(row), score
            return best

        # First use the already loaded full Xtream catalogue / warmed Home index.
        match = match_rows(self.server_items or [])
        if match:
            return match

        source = dict(self._vodSelectedSource or {})
        try:
            client = get_source_client(source)
            if source.get("type") == "xtream":
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                return match_rows(rows)
            if source.get("type") == "stalker":
                categories, _origin = get_cached_categories(source, "vod", client=client, wait_for_server=True)
                categories = filter_categories(source, "vod", categories or [])
                for category in categories:
                    category_id = str((category or {}).get("category_id") or "")
                    if not category_id:
                        continue
                    rows, _origin = get_category_streams(
                        source, "vod", client, category_id,
                        use_cache=True, wait_for_server=True
                    )
                    match = match_rows(rows or [])
                    if match:
                        return match
        except Exception:
            pass
        return None



    def _openManualTmdbMatch(self):
        """MENU: search TMDb and pin the correct movie (Ultra manual match)."""
        title = self.item.get("name") or self.item.get("title") or self.item.get("original_title") or ""
        if not title:
            return
        from .manual_match import open_menu, reopen_later

        def reopen():
            args = getattr(self, "_manualMatchArgs", None) or (self.source, dict(self.item), self.server_items, self.source_context)
            source, item, server_items, context = args
            item = dict(item)
            for key in ("tmdb_id", "tmdb"):
                if key in item and not (self._manualMatchArgs[1].get(key)):
                    item.pop(key, None)
            reopen_later(self.session, self, MovieDetailsScreen, source, item, server_items, context)
        open_menu(self, title, "vod", reopen)

    def _loadDeferredTmdbMovie(self):
        self.loadDetails()



    def start(self):
        self["ageIcon"].hide()
        self.applyInitialDetails()
        if self._watchReady:
            self._setWatchReady()
        else:
            self._setWatchSearching()
        self.updateFocus()
        # Show cached same-package recommendations immediately; never wait for
        # TMDb cast, plot or provider VOD info before drawing this separate rail.
        self._startServerRecommendationResolve({})
        # Artwork/details first. No provider-wide Watch/Sources scan here.
        # Two independent background workers: a dead Stalker/Xtream server
        # never blocks the TMDb fallback or freezes the details page. Text is
        # always merged server-first regardless of which response completes first.
        source_worker = threading.Thread(target=self._loadProviderMovieInfoTracked,
                                         name="TiviMateMovieProviderInfo")
        source_worker.daemon = True
        source_worker.start()
        t = threading.Thread(target=self.loadDetails, name="TiviMateMovieDetails")
        t.daemon = True
        t.start()


    def _loadProviderMovieInfoTracked(self):
        try:
            self._loadProviderMovieInfo()
        finally:
            # Time stamp: the GUI applies the payload a moment later.
            self._providerInfoDone = time.time()

    def _loadProviderMovieInfo(self):
        """Use the exact provider's saved VOD info before requesting the server.

        Share the existing per-provider metadata cache with the large pages.
        Never cache provider information under a TMDb title/id (which is global
        and can be the same on unrelated IPTV sources).
        """
        source = dict(self.source or {})
        source_type = str(source.get("type") or "").lower()
        if source_type not in ("xtream", "stalker"):
            return
        mid = str(self.item.get("stream_id") or self.item.get("vod_id") or "").strip()
        if not mid:
            return  # TMDb-only discovery row: no provider VOD id to request.
        key = provider_cache_key("vod", mid, source)
        self._movieProviderToken = key
        payload = {}
        path = ""
        try:
            folder = get_cache_dir("metadata")
            path = os.path.join(folder, "provider_info_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            if os.path.isfile(path) and os.path.getsize(path) > 2:
                with open(path, "r", encoding="utf-8") as handle:
                    value = json.load(handle)
                if isinstance(value, dict):
                    payload = value
        except Exception:
            payload = {}
        if not payload:
            try:
                reply = get_source_client(source).vod_info(mid) or {}
                if isinstance(reply, dict):
                    payload = reply
            except Exception:
                payload = {}
            if payload and path:
                temp = path + ".tmp.%s.%s" % (os.getpid(), threading.get_ident())
                try:
                    folder = os.path.dirname(path)
                    if not os.path.isdir(folder):
                        os.makedirs(folder)
                    with open(temp, "w", encoding="utf-8") as handle:
                        json.dump(payload, handle, ensure_ascii=False)
                    os.replace(temp, path)
                except Exception:
                    try:
                        if os.path.isfile(temp):
                            os.remove(temp)
                    except Exception:
                        pass
        if payload:
            self._queueGui(self._applyProviderMovieInfo, key, payload)

    def _applyProviderMovieInfo(self, expected_key, payload):
        """Update facts without triggering backdrop/poster/clearlogo reloading."""
        current_id = str(self.item.get("stream_id") or self.item.get("vod_id") or "").strip()
        if not current_id or provider_cache_key("vod", current_id, self.source) != expected_key:
            return
        if not isinstance(payload, dict) or not payload:
            return
        self._serverMovieInfo = dict(payload)
        # More Info gets the same verified provider details (not another
        # unrelated title lookup). This never replaces the playable item ID.
        self.item["_detail_provider_info"] = dict(payload)
        # The catalogue row often has no backdrop, while vod_info supplies it
        # under `info` or `movie_data`. Load it only if a verified TMDb
        # backdrop has not already been requested; never turn a provider's
        # slash-relative path into an image.tmdb.org URL.
        provider_art = _server_backdrop_url(self.source, self.item, extra=payload)
        if not provider_art and isinstance(payload.get("movie_data"), dict):
            provider_art = _server_backdrop_url(self.source, payload["movie_data"],
                                                extra=payload.get("info"))
        if provider_art and _provider_art_wrong(provider_art, getattr(self, "_tmdb_bundle", {}) or {}):
            provider_art = ""
        if provider_art and not getattr(self, "_detailBackdropLocked", False):
            self._detailBackdropLocked = True
            self._detailBackdropSource = "provider"
            self._detailBackdropUrl = provider_art
            self.loadImage(provider_art, "backdrop", 1920, 1080)
        self._renderMovieInfoText(getattr(self, "_tmdb_bundle", {}) or {})

    def _renderMovieInfoText(self, tmdb_data=None):
        """One UI-only server-first renderer, shared by both async callbacks."""
        language = TMDbClient().language.lower()
        display = merge_metadata(self.item,
                                 provider=getattr(self, "_serverMovieInfo", {}) or {},
                                 tmdb=tmdb_data or {},
                                 language=language, kind="vod")
        title = display["title"] or "Movie"
        year = str(display["year"] or "")
        genres = str(display["genre"] or "")
        runtime = str(display["runtime"] or "").strip()
        # Xtream often returns a duration clock rather than TMDb's minutes.
        # Don't render values such as "01:35:00 min".
        if ":" in runtime:
            pieces = runtime.split(":")
            if len(pieces) in (2, 3) and all(x.isdigit() for x in pieces):
                if len(pieces) == 3:
                    minutes = int(pieces[0]) * 60 + int(pieces[1]) + (1 if int(pieces[2]) >= 30 else 0)
                else:
                    minutes = int(pieces[0]) * 60 + int(pieces[1])
                runtime = str(minutes)
        from .resolution_badge import format_duration
        runtime_label = format_duration(runtime)
        self["title"].setText(_details_dual_title(title, tmdb_data, self.item,
                                                  getattr(self, "_serverMovieInfo", {}) or {}))
        self["meta"].setText("  •  ".join(x for x in (year, genres, runtime_label) if x))
        synopsis = display["description"] or "No description available"
        self["desc"].setText(synopsis[:700])
        # Keep the same displayed facts in the existing player hand-off, but
        # leave posters/backdrops/stream metadata alone.
        self.item["_tmdb_metadata_locale"] = language
        self.item["_tmdb_metadata_title"] = title
        self.item["_tmdb_metadata_overview"] = synopsis
        try:
            self._centerDetailsLogo(True)  # again 0.4 s later for late badges
        except Exception:
            pass

    def applyInitialDetails(self):
        title = self.item.get("name") or self.item.get("title") or "Movie"
        year = str(self.item.get("releaseDate") or self.item.get("release_date") or self.item.get("year") or "")[:4]
        genre = self.item.get("genre") or ""
        self["title"].setText(visible_title(title, 72))
        # The verified TMDb rating is shown as pink text.  Do not
        # label a provider rating as an official TMDb rating.
        self["ratingText"].setText("")
        show_country_flag(self["countryFlag"], {}, "movie")
        self["meta"].setText("  •  ".join(x for x in [year, str(genre)] if x))
        self["desc"].setText((self.item.get("plot") or self.item.get("description") or "")[:700])
        poster = self.item.get("_resolved_server_poster") or _server_poster_url(self.source, self.item)
        # Details backdrop: paint one already-resolved/current backdrop immediately
        # and keep it stable for this page. Do not repaint a second, different
        # backdrop when TMDb metadata arrives later.
        backdrop = (self._norm(self.item.get("_tmdb_backdrop"), "w780") or
                    _server_backdrop_url(self.source, self.item))
        self._detailBackdropLocked = bool(backdrop)
        self._detailBackdropUrl = backdrop
        self._detailBackdropSource = ("tmdb" if self.item.get("_tmdb_backdrop") else
                                      ("provider" if backdrop else ""))
        if poster:
            self.loadImage(poster, "poster", 350, 525)
        else:
            self._genreDetailMissing('poster')
        if backdrop:
            self.loadImage(backdrop, "backdrop", 1920, 1080)
        else:
            self._genreDetailMissing('backdrop')
        # GENRE's transparent clearlogo provider fallback runs independently.
        self._genreDetailMissing('logoImage')

    def _norm(self, value, size="w780"):
        if isinstance(value, list): value = value[0] if value else ""
        if not isinstance(value, str): return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("/"): value = "https://image.tmdb.org/t/p/%s%s" % (size, value)
        return value


    def _title_norm(self, value):
        # Normalize movie titles across provider packages. Package branding,
        # quality/language tags and year must never stop the same movie matching.
        text = str(value or "").lower().replace("&", " and ")
        text = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", text)

        # Strip common platform/package labels first.
        text = re.sub(r"\bamazon\s+prime(?:\s+video)?\b", " ", text)
        text = re.sub(r"\bprime\s+video\b", " ", text)
        text = re.sub(r"\bapple\s+tv\+?\b", " ", text)
        text = re.sub(r"\bdisney\+?\b", " ", text)
        text = re.sub(r"\bhbo\s+max\b", " ", text)
        text = re.sub(r"\bparamount\+?\b", " ", text)
        text = re.sub(r"\bnetflix\b", " ", text)

        text = re.sub(
            r"\b(nf|amz|amzn|ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|8k|uhd|fhd|hd|sd|"
            r"hevc|x265|x264|hdr|web[- ]?dl|bluray|brrip|webrip|remux|top|"
            r"2160p|1080p|720p|576p|480p|vod|movies?)\b",
            " ", text
        )
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())


    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _title_score(self, wanted, candidate):
        """Return a score only for genuinely matching release titles."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens, candidate_tokens = set(wanted.split()), set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0
        # Partial title containment is safe only when every significant token matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94
        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0

    def _playable_item(self):
        if self.item.get("stream_id"):
            return self.item
        return self.sources_list[0] if self.sources_list else None


    def _fullServerVodCatalog(self):
        """Return the complete movie catalog for Other Sources on this server."""
        source = dict(self._vodSelectedSource or {})
        client = get_source_client(source)
        rows = []

        if source.get("type") == "xtream":
            # One provider-wide request includes every VOD package/category.
            # Disk/RAM catalog cache first; one provider request only if empty.
            try:
                rows = list(get_filtered_streams(source, "vod", client, use_cache=True) or [])
            except Exception:
                rows = []
            if not rows:
                try:
                    rows = list(client.streams("vod") or [])
                except Exception:
                    rows = []

        elif source.get("type") == "stalker":
            # Search every real VOD package. Do not restrict to the package
            # from which the details screen was opened.
            try:
                categories = list(client.categories("vod") or [])
            except Exception:
                categories = []

            for category in categories:
                cid = str((category or {}).get("category_id") or
                          (category or {}).get("id") or "").strip()
                if not cid:
                    continue
                try:
                    cat_rows, _origin = get_category_streams(
                        source, "vod", client, cid,
                        use_cache=True, wait_for_server=True
                    )
                    rows.extend(list(cat_rows or []))
                except Exception:
                    try:
                        rows.extend(list(client.streams("vod", cid) or []))
                    except Exception:
                        pass

            if not rows:
                try:
                    rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                except Exception:
                    rows = []
        else:
            try:
                rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
            except Exception:
                rows = []

        # Deduplicate provider rows while preserving provider/category order.
        out = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            key = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if key in seen:
                continue
            seen.add(key)
            out.append(dict(row))
        return out


    def _matchingServerSources(self, rows, exclude_primary=True):
        title_fields = ("name", "title", "original_title")
        wanted = [self._title_norm(self.item.get(field)) for field in title_fields]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        primary_id = str(self.item.get("stream_id") or self.item.get("vod_id") or "")
        matches, seen = [], set()

        for row in rows or []:
            row_id = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            if exclude_primary and primary_id and row_id and row_id == primary_id:
                continue
            unique = row_id or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue
            candidate_titles = [self._title_norm(row.get(field)) for field in title_fields]
            score = max([self._title_score(w, c) for w in wanted for c in candidate_titles] or [0.0])
            if score < 0.90:
                continue
            row_year = self._year(row)
            if target_year and row_year and abs(target_year-row_year) > 1:
                continue
            matches.append((score, 1 if target_year and row_year == target_year else 0, dict(row)))
            seen.add(unique)

        matches.sort(key=lambda value: (value[0], value[1]), reverse=True)
        return [value[2] for value in matches]


    def _buildSourceTitleIndex(self):
        """Index server rows by normalized title once, avoiding a full fuzzy scan every time."""
        if self._sourceTitleIndex is not None:
            return self._sourceTitleIndex
        index = {}
        for row in self.server_items:
            try:
                seen = set()
                for field in ("name", "title", "original_title"):
                    norm = self._title_norm(row.get(field))
                    if norm and norm not in seen:
                        seen.add(norm)
                        index.setdefault(norm, []).append(row)
            except Exception:
                continue
        self._sourceTitleIndex = index
        return index


    def _cachedOtherSourceRows(self):
        """Read VOD package RAM/disk cache only; never contact the provider."""
        source = dict(self._vodSelectedSource or {})
        allowed = get_allowed_category_ids(source, "vod")
        category_ids = []

        if allowed is not None:
            category_ids = [str(cid) for cid in allowed if str(cid)]
        else:
            try:
                categories, _origin = get_cached_categories(source, "vod", wait_for_server=False)
            except Exception:
                categories = []
            for category in list(categories or []):
                cid = str((category or {}).get("category_id") or
                          (category or {}).get("id") or "").strip()
                if cid:
                    category_ids.append(cid)

        rows, seen = [], set()
        for cid in category_ids:
            try:
                cached, _origin = peek_category_streams_cache(source, "vod", cid)
            except Exception:
                cached = []
            for row in list(cached or []):
                if not isinstance(row, dict):
                    continue
                sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
                key = sid or (
                    self._title_norm(row.get("name") or row.get("title") or ""),
                    str(row.get("category_id") or cid),
                    str(row.get("container_extension") or "")
                )
                if key in seen:
                    continue
                seen.add(key)
                rows.append(dict(row))
        return rows

    def _otherSourcesKey(self):
        source = dict(self._vodSelectedSource or {})
        return "%s|%s|%s" % (source.get("type") or "", source.get("url") or "",
                             source.get("username") or source.get("mac") or "")

    def _stalkerNativeVodSearch(self):
        """One portal search request instead of walking every VOD package."""
        source = dict(self._vodSelectedSource or {})
        if source.get("type") != "stalker":
            return []
        title = str(self.item.get("name") or self.item.get("title") or "").strip()
        title = re.sub(r"\s*[\(\[]\s*(19|20)\d{2}\s*[\)\]]\s*$", "", title).strip()
        if len(title) < 2:
            return []
        try:
            client = get_source_client(source)
            engine = getattr(client, "_ultra_client", None)
            search = getattr(engine, "search_category_fast", None)
            if not callable(search):
                return []
            rows = search(title, "vod", "*", limit=80, max_pages=3, time_budget=4) or []
            return [dict(row) for row in rows if isinstance(row, dict)]
        except Exception:
            return []

    def findSources(self):
        """Other Sources, fastest first; the server is the last resort.

        1. package RAM/disk cache   2. rows this screen already holds
        3. full catalog kept from an earlier search (30 min)
        4. Stalker: one native portal search
        5. full server catalog (then kept for the next movie)
        """
        try:
            cached_rows = self._cachedOtherSourceRows()
            sources = self._matchingServerSources(cached_rows)
            if sources:
                self._queueGui(self.applySources, sources[:24])
                return

            held = []
            for pool in (getattr(self, "server_items", None), getattr(self, "recommendation_items", None)):
                held.extend(row for row in list(pool or []) if isinstance(row, dict))
            sources = self._matchingServerSources(held)
            if sources:
                self._queueGui(self.applySources, sources[:24])
                return

            key = self._otherSourcesKey()
            kept = _OTHER_SOURCES_CATALOG.get(key)
            if kept and time.time() - kept[1] < 1800:
                self._queueGui(self.applySources, self._matchingServerSources(kept[0])[:24])
                return

            sources = self._matchingServerSources(self._stalkerNativeVodSearch())
            if sources:
                self._queueGui(self.applySources, sources[:24])
                return

            rows = self._fullServerVodCatalog()
            sources = self._matchingServerSources(rows)
            if rows:
                self.server_items = list(rows)
                self._sourceTitleIndex = None
                _OTHER_SOURCES_CATALOG[key] = (list(rows), time.time())
                while len(_OTHER_SOURCES_CATALOG) > 4:
                    oldest = min(_OTHER_SOURCES_CATALOG, key=lambda k: _OTHER_SOURCES_CATALOG[k][1])
                    _OTHER_SOURCES_CATALOG.pop(oldest, None)

            self._queueGui(self.applySources, sources[:24])
        except Exception:
            self._queueGui(self.applySources, [])





    def applySources(self, sources):
        # Keep the movie copy we are currently viewing in Other Sources too.
        # The alternate-source search normally excludes the primary stream_id,
        # which made the original playable link disappear from the chooser.
        # Prepend a clean copy of the resolved current VOD, then append matches.
        primary = None
        try:
            current = dict(self.item or {})
            if current.get("stream_id") or current.get("vod_id"):
                primary = current
            else:
                cached = self._cachedServerMatch()
                if cached and (cached.get("stream_id") or cached.get("vod_id")):
                    primary = dict(cached)
        except Exception:
            primary = None

        combined = []
        seen = set()
        if primary:
            primary["_other_sources_current"] = True
            combined.append(primary)
            pid = str(primary.get("stream_id") or primary.get("vod_id") or primary.get("id") or "")
            if pid:
                seen.add(pid)

        for row in list(sources or []):
            if not isinstance(row, dict):
                continue
            candidate = dict(row)
            rid = str(candidate.get("stream_id") or candidate.get("vod_id") or candidate.get("id") or "")
            if rid and rid in seen:
                continue
            if rid:
                seen.add(rid)
            combined.append(candidate)

        self.sources_list = combined
        count = len(self.sources_list)
        if count:
            self["sources"].setText("Other Sources (%d)" % count)
        else:
            self["sources"].setText(tr("No Other Sources"))


    def _showRecommendationHeading(self):
        """Local transparent heading; follow the app language, not the title language."""
        try:
            from .i18n import get_language
            lang = 'ar' if get_language() == 'ar' else 'en'
            image = os.path.join(os.path.dirname(__file__), 'skins', 'movies',
                                 'recommendation_heading_' + lang + '.png')
            if os.path.isfile(image) and self['recommendTitle'].instance:
                self['recommendTitle'].instance.setPixmapFromFile(image)
                self['recommendTitle'].show()
        except Exception:
            pass

    def _recommendationPool(self):
        """Return rows from the movie's real source context, never the current UI page.

        Other Sources is allowed to warm/replace ``self.server_items`` with the
        whole provider catalog. Recommendations deliberately use the separate
        ``recommendation_items`` snapshot and, when possible, lock it to the
        movie's real category_id.
        """
        rows=[dict(x) for x in list(self.recommendation_items or []) if isinstance(x,dict)]
        cid=str(self._recommendationCategoryId or "").strip()

        # RECENT ADDED (Movies) special rule:
        # Only when the movie was opened from RECENT ADDED, keep the
        # recommendation backdrop rail inside that exact Recent Added snapshot.
        # Normal movie packages keep their existing behaviour unchanged.
        if self._recommendationScope == "movies_recent_filtered":
            return rows

        # If Home opened a TMDb card, identify the real server row/category from
        # the warmed catalog once. This removes the old 'Home list = context' bug.
        if not cid and self.server_items:
            try:
                matches=self._matchingServerSources(self.server_items, exclude_primary=False)
                if matches:
                    matched=dict(matches[0] or {})
                    cid=str(matched.get("category_id") or matched.get("categoryId") or "").strip()
                    if cid:
                        self._recommendationCategoryId=cid
                        # Preserve the playable server identity on the current item.
                        for key in ("stream_id","vod_id","container_extension","category_id"):
                            if matched.get(key) not in (None,"") and self.item.get(key) in (None,""):
                                self.item[key]=matched.get(key)
            except Exception:
                pass

        if cid:
            # Recommendation rail is package-cache first: use the exact current
            # movie package from RAM/HDD cache before the normal package path.
            # On a cache miss, preserve the existing same-package behaviour.
            try:
                cached,_origin=peek_category_streams_cache(self.source,"vod",cid)
                if cached:
                    return [dict(x) for x in cached if isinstance(x,dict)]
            except Exception:
                pass

            filtered=[r for r in rows if str(r.get("category_id") or r.get("categoryId") or "").strip()==cid]
            if filtered:
                return filtered
            # Cache miss: keep the original path for this exact package only.
            try:
                client=get_source_client(self.source)
                fetched,_origin=get_category_streams(
                    self.source,"vod",client,cid,use_cache=True,wait_for_server=True
                )
                if fetched:
                    return [dict(x) for x in fetched if isinstance(x,dict)]
            except Exception:
                pass

        return rows


    def _serverOnlyTmdbRecommendations(self, data):
        """Fast recommendations from the item's explicit source context only."""
        import random

        rows=self._recommendationPool()
        if not rows:
            return []

        current_id=str(
            self.item.get("stream_id") or
            self.item.get("vod_id") or
            self.item.get("id") or ""
        ).strip()
        current_title=self._recommendTitleNorm(
            self.item.get("name") or self.item.get("title") or ""
        )

        pool=[]
        seen=set()

        for row in rows:
            sid=str(
                row.get("stream_id") or
                row.get("vod_id") or
                row.get("id") or ""
            ).strip()
            title=self._recommendTitleNorm(
                row.get("name") or row.get("title") or ""
            )

            if current_id and sid and sid==current_id:
                continue
            if not current_id and current_title and title==current_title:
                continue

            unique=("id:"+sid) if sid else ("title:"+title)
            if not unique or unique in seen:
                continue
            seen.add(unique)

            # Same-package server row stays fully playable.
            row["_recommend_server_match"]=True
            pool.append(row)

        if not pool:
            return []

        # Stable daily random picks: reopening details uses the same cached
        # artwork rather than choosing four new uncached films every time.
        seed = "%s|%s|%s|%s" % (
            _recommend_backdrop_key(self.source, self.item),
            str(self._recommendationCategoryId or ""),
            str(self._recommendationScope or ""),
            time.strftime("%Y-%m-%d"),
        )
        random.Random(seed).shuffle(pool)

        # Prefer real same-package backdrops already present in the provider
        # row or our persistent per-movie backdrop metadata cache. Never prefer
        # a poster in the horizontal recommendation rail.
        image_cached, metadata_known, missing = [], [], []
        # Inspect only a bounded random sample for existing backdrop files and
        # saved TMDb paths. Large provider packages may contain 10,000+ rows.
        for row in pool[:120]:
            url = row.get("backdrop_path") or row.get("backdrop") or row.get("backdrop_url")
            if not url:
                # Same provider backdrop parsing used by Movie Details. Some
                # servers nest fanart/background under info or movie_data.
                try:
                    url = _server_backdrop_url(self.source, row)
                except Exception:
                    url = ""
                if url:
                    row["backdrop_url"] = url
            if not url:
                known = _recommend_backdrop_get(self.source, row)
                url = known.get("backdrop_path") or ""
                if url:
                    row["backdrop_path"] = url
                    if known.get("tmdb_id") and not row.get("tmdb_id"):
                        row["tmdb_id"] = known["tmdb_id"]
            if url:
                try:
                    local = cached_artwork(self._norm(url, "w780"), "backdrops")
                except Exception:
                    local = None
                (image_cached if local else metadata_known).append(row)
            else:
                missing.append(row)
        # Already-downloaded HDD/USB images win over URL-only candidates. A
        # missing image never stops the four cards from being selected.
        return (image_cached + metadata_known + missing + pool[120:])[:4]



    def _providerRuntimeMinutes(self):
        """Provider duration in minutes (verifies short Arabic TMDb titles)."""
        cached = getattr(self, "_providerRuntimeCache", None)
        if cached is not None:
            return cached
        from .tmdb_client import _tmdb_runtime_minutes
        minutes = 0
        waited = 0
        while True:
            for record in (getattr(self, "_serverMovieInfo", None), self.item.get("_detail_provider_info"), self.item):
                if not isinstance(record, dict):
                    continue
                for holder in (record, record.get("info"), record.get("movie_data")):
                    if isinstance(holder, dict):
                        for name in ("duration_secs", "duration", "runtime", "episode_run_time"):
                            minutes = _tmdb_runtime_minutes(holder.get(name))
                            if minutes:
                                break
                    if minutes:
                        break
                if minutes:
                    break
            # Provider info loads in parallel; wait at most ~2.5 s, only on
            # this rare fallback path, and never after the provider answered.
            if minutes or waited >= 25 or (getattr(self, "_providerInfoDone", 0) and time.time() - self._providerInfoDone > 0.4):
                break
            time.sleep(0.1)
            waited += 1
        self._providerRuntimeCache = minutes
        return minutes

    def loadDetails(self):
        try:
            # Details are cache-first, identical in spirit to the fast TV
            # Shows path.  Opening More Info must never wait on provider vod_info.
            tmdb = TMDbClient()
            raw_title = self.item.get("name") or self.item.get("title") or self.item.get("original_title") or ""
            item_year = self._year(self.item) or None
            provider_tid = self.item.get("tmdb_id") or self.item.get("tmdb")
            # A TMDb match pinned by the user (MENU) beats provider/auto ids.
            try:
                from .manual_match import pinned_id as _pinned_tmdb_id
                _pin = _pinned_tmdb_id(raw_title, "vod")
            except Exception:
                _pin = ""
            if _pin:
                provider_tid = _pin
            title_key = "vod:title:%s:%s" % (self._title_norm(raw_title), str(item_year or ""))
            if _pin:
                title_key += ":pin%s" % _pin
            id_key = "vod:%s" % str(provider_tid or "") if provider_tid else ""

            cached = _memory_get(_DETAILS_DATA_CACHE, _tmdb_details_memory_key(id_key)) if id_key else None
            if not cached:
                cached = _memory_get(_DETAILS_DATA_CACHE, _tmdb_details_memory_key(title_key))
            # A cached details row is final only when its actor cards are complete.
            # Older cache records can contain provider name-only cast rows; returning
            # here used to bypass the normal TMDb credits enrichment below entirely.
            data = dict(cached) if cached else {}
            if data.get("id") and _tmdb_year_conflict(data, item_year, self._providerRuntimeMinutes) and not _pin:
                data = {}      # cached match from another year (old builds)
                cached = None
            if data.get("id"):
                self.item["tmdb_id"] = str(data.get("id"))
            cached_cast = ((data.get("credits") or {}).get("cast") or [])
            cached_visible = list(cached_cast[:6])
            cached_cast_complete = bool(cached_visible) and all(
                isinstance(x, dict) and x.get("id") and x.get("profile_path")
                for x in cached_visible
            )
            # An actor-complete cache may still contain an English overview
            # from older builds. Complete localization by TMDb id before using it.
            needs_arabic = (str(tmdb.language or "").lower().startswith("ar")
                            and not any("\u0600" <= ch <= "\u06ff" for ch in str(data.get("overview") or ""))
                            and bool(provider_tid or data.get("id")))
            if cached and cached_cast_complete and not needs_arabic and data.get("backdrop_path"):
                self._queueGui(self.applyDetails, data)
                return

            # Keep cached metadata/artwork, but allow incomplete actor rows to pass
            # through the exact same credits path used by a normal working movie.
            tid = provider_tid or data.get("id") or data.get("tmdb_id")
            found = None
            wrong_art_files = list(data.get("_wrong_art_files") or [])

            # details_bundle and search_title both have persistent disk caches, so
            # repeated visits normally stay local even after a GUI restart.
            if tid:
                try:
                    data = tmdb.details_bundle(tid, "vod") or {}
                except Exception:
                    data = {}

            # A provider can carry a wrong TMDb id (another film, or the TV
            # id of a movie). Then the page showed no backdrop/logo/actors.
            # Check the record against the title; if it does not belong to it,
            # search by title (language prefix and [Original Title] aware).
            if (tid and provider_tid and not _pin and raw_title and
                    str(tid) == str(provider_tid) and
                    (not tmdb.title_matches(raw_title, data, "vod") or
                     _tmdb_year_conflict(data, item_year, self._providerRuntimeMinutes))):
                try:
                    alt = tmdb.search_title(raw_title, "vod", item_year, runtime=self._providerRuntimeMinutes()) or {}
                    if not alt and item_year:
                        alt = tmdb.search_title(raw_title, "vod", None, runtime=self._providerRuntimeMinutes()) or {}
                except Exception:
                    alt = {}
                alt_id = (alt or {}).get("id")
                alt_year = str((alt or {}).get("release_date") or "")[:4]
                if item_year and alt_year and _tmdb_year_conflict(alt, item_year):
                    alt_id = None      # same name, different film: keep provider id
                if alt_id and str(alt_id) != str(tid):
                    try:
                        fetched = tmdb.details_bundle(alt_id, "vod") or {}
                    except Exception:
                        fetched = {}
                    if fetched:
                        tid = alt_id
                        data = fetched
                        self.item["tmdb_id"] = str(alt_id)
                if str(tid) == str(provider_tid):
                    # No better film was found. Drop the provider id when its
                    # runtime/year clearly belong to another film; remember
                    # its art so a copied provider poster/backdrop is hidden.
                    try:
                        from .tmdb_client import _tmdb_runtime_minutes
                        pm = self._providerRuntimeMinutes()
                        tm = _tmdb_runtime_minutes((data or {}).get("runtime"))
                        ty = str((data or {}).get("release_date") or "")[:4]
                        bad = bool(pm and tm and abs(pm - tm) > 10)
                        if item_year and ty.isdigit() and str(item_year).isdigit():
                            bad = bad or _tmdb_year_conflict(data, item_year, self._providerRuntimeMinutes)
                    except Exception:
                        bad = False
                    if bad:
                        wrong_art_files = sorted(_tmdb_art_files(data)[0])
                        data = {}
                        tid = None
                        self.item.pop("tmdb_id", None)

            # Provider VOD facts are fetched independently by _loadProviderMovieInfo
            # and merged on the GUI thread. Never inject provider plot/rating
            # into TMDb's global id/title cache, which could leak values between
            # servers sharing the same TMDb id or title.

            # Actors fallback/enrichment: provider vod_info often supplies only
            # comma-separated actor names, without TMDb profile_path images.
            # Treat a name-only cast as incomplete: resolve TMDb cast for this same
            # movie and merge profile images/characters by actor name.  This keeps
            # provider names when present and changes no poster/backdrop/metadata.
            current_cast = ((data.get("credits") or {}).get("cast") or [])
            visible_cast = list(current_cast[:6])
            cast_needs_profiles = (
                not visible_cast or
                any(not (isinstance(x, dict) and x.get("profile_path")) for x in visible_cast) or
                len(visible_cast) < 6
            )
            if cast_needs_profiles:
                try:
                    # Reuse the TMDb movie already resolved for this details page.
                    # Old/Arabic provider titles can be transliterated differently, so
                    # searching the title again may resolve no movie even though this
                    # page already has the correct TMDb metadata/backdrop.
                    cast_found = {}
                    cast_tid = (data or {}).get("id") or (data or {}).get("tmdb_id") or self.item.get("tmdb_id")
                    if not cast_tid and raw_title:
                        cast_found = tmdb.search_title(raw_title, "vod", item_year, runtime=self._providerRuntimeMinutes()) or {}
                        if not cast_found:
                            cast_found = tmdb.search_title(raw_title, "vod", None, runtime=self._providerRuntimeMinutes()) or {}
                        if cast_found and _tmdb_year_conflict(cast_found, item_year):
                            cast_found = {}
                        cast_tid = (cast_found or {}).get("id") or (cast_found or {}).get("tmdb_id")
                    if cast_tid:
                        # Use the normal TMDb credits rows (id/name/profile_path).
                        # details_bundle may legitimately return an older cache that has
                        # metadata/artwork but no credits, so fall back to the dedicated
                        # credits endpoint only when actor cards are incomplete.
                        cast_bundle = tmdb.details_bundle(cast_tid, "vod") or {}
                        if cast_found and _tmdb_year_conflict(cast_bundle, item_year, self._providerRuntimeMinutes):
                            cast_bundle, cast_tid = {}, None
                            raise LookupError("cast belongs to another film")
                        tmdb_cast = ((cast_bundle.get("credits") or {}).get("cast") or [])
                        if not tmdb_cast or any(not (isinstance(x, dict) and x.get("profile_path")) for x in tmdb_cast[:6]):
                            credits_data = tmdb.media_credits(cast_tid, "vod") or {}
                            if credits_data.get("cast"):
                                tmdb_cast = credits_data.get("cast") or []
                        if tmdb_cast:
                            # TMDb credits are authoritative for actor cards because
                            # provider cast strings commonly contain names only.  Build
                            # the six visible cards from TMDb so every available actor
                            # carries id/profile_path; preserve provider character text
                            # only when the actor name matches.
                            provider_by_name = {}
                            for row in current_cast:
                                if isinstance(row, dict):
                                    key = self._title_norm(row.get("name") or "")
                                    if key:
                                        provider_by_name[key] = row
                            merged = []
                            for row in tmdb_cast:
                                if len(merged) >= 6:
                                    break
                                if not isinstance(row, dict):
                                    continue
                                base = dict(row)
                                key = self._title_norm(base.get("name") or "")
                                provider_row = provider_by_name.get(key) or {}
                                if provider_row.get("character") and not base.get("character"):
                                    base["character"] = provider_row.get("character")
                                merged.append(base)
                            if merged:
                                data["credits"] = {"cast": merged}
                            if not self.item.get("tmdb_id"):
                                self.item["tmdb_id"] = str(cast_tid)
                except Exception:
                    pass

            # If this provider movie cannot be resolved to a TMDb movie ID, do not
            # leave name-only Actor cards behind. Resolve each provider actor name
            # directly to a TMDb person so the normal cards receive id/profile_path.
            final_cast = ((data.get("credits") or {}).get("cast") or [])
            if final_cast and any(not (isinstance(x, dict) and x.get("id") and x.get("profile_path")) for x in final_cast[:6]):
                resolved_people = []
                for actor in final_cast[:6]:
                    if not isinstance(actor, dict):
                        continue
                    if actor.get("id") and actor.get("profile_path"):
                        resolved_people.append(dict(actor))
                        continue
                    actor_name = str(actor.get("name") or "").strip()
                    if not actor_name:
                        continue
                    try:
                        person = tmdb.search_person(actor_name) or {}
                    except Exception:
                        person = {}
                    if person.get("id"):
                        row = dict(person)
                        row["name"] = person.get("name") or actor_name
                        if actor.get("character") and not row.get("character"):
                            row["character"] = actor.get("character")
                        resolved_people.append(row)
                # Do not display unusable name-only cards. Every visible actor must
                # be a real TMDb person and therefore open Actor information normally.
                if resolved_people:
                    data["credits"] = {"cast": resolved_people[:6]}
                else:
                    data["credits"] = {"cast": []}

            useful = bool(
                data.get("poster_path") or data.get("backdrop_path") or data.get("overview") or
                ((data.get("credits") or {}).get("cast") or []) or
                ((data.get("recommendations") or {}).get("results") or []) or
                ((data.get("similar") or {}).get("results") or [])
            )

            if not useful and raw_title:
                found = tmdb.search_title(raw_title, "vod", item_year, runtime=self._providerRuntimeMinutes()) or {}
                if not found:
                    found = tmdb.search_title(raw_title, "vod", None, runtime=self._providerRuntimeMinutes()) or {}
                if found and _tmdb_year_conflict(found, item_year):
                    found = {}
                resolved = (found or {}).get("id") or (found or {}).get("tmdb_id")
                if resolved:
                    try:
                        fetched = tmdb.details_bundle(resolved, "vod") or {}
                    except Exception:
                        fetched = {}
                    if fetched and _tmdb_year_conflict(fetched, item_year, self._providerRuntimeMinutes):
                        found = {}          # same name, other film (runtime differs)
                    else:
                        tid = resolved
                        data = fetched

            if found:
                seed = dict(found)
                seed.update(data or {})
                data = seed

            # A missing primary TMDb backdrop is common on provider movie
            # pages. The bundle's `images.backdrops` belong to this exact ID;
            # choose one before triggering a separate artwork-title search.
            if not (data or {}).get("backdrop_path"):
                alternate = _tmdb_same_movie_backdrops(data)
                if alternate:
                    data = dict(data or {})
                    data["backdrop_path"] = alternate[0]
            if not (data or {}).get("backdrop_path") and raw_title:
                try:
                    # At most one expensive negative lookup per title per 20
                    # minutes. Positive artwork remains in the normal cache.
                    miss_key = (str(tid or ""), self._title_norm(raw_title), str(item_year or ""))
                    misses = getattr(MovieDetailsScreen, "_backdropMisses", {})
                    if misses.get(miss_key, 0) > time.monotonic():
                        raise LookupError("recent TMDb backdrop miss")
                    back_row = tmdb.search_artwork(raw_title, kind="vod",
                                                  year=item_year,
                                                  required_key="backdrop_path") or {}
                    existing_id = str((data or {}).get("id") or tid or "").strip()
                    found_id = str(back_row.get("id") or "").strip()
                    if (back_row.get("backdrop_path") and found_id and
                            (not existing_id or existing_id == found_id)):
                        data = dict(data or {})
                        data["backdrop_path"] = back_row["backdrop_path"]
                        if not existing_id:
                            data["id"] = back_row["id"]
                    else:
                        misses[miss_key] = time.monotonic() + 1200
                        if len(misses) > 96:
                            for expired in list(misses)[:32]:
                                misses.pop(expired, None)
                        MovieDetailsScreen._backdropMisses = misses
                except Exception:
                    pass

            # Poster-only recovery: use the same title-cleaning artwork search
            # used by the player when the normal details bundle has no poster.
            # This is especially useful for Arabic/provider-tagged titles.
            if raw_title and not (data or {}).get("poster_path"):
                try:
                    artwork = tmdb.search_artwork(raw_title, kind="vod", year=item_year, required_key="poster_path") or {}
                    same_id = str((data or {}).get("id") or tid or "").strip()
                    if same_id and str(artwork.get("id") or "").strip() != same_id:
                        artwork = {}
                    if artwork.get("poster_path"):
                        seed = dict(artwork)
                        seed.update(data or {})
                        seed["poster_path"] = artwork.get("poster_path")
                        data = seed
                except Exception:
                    pass

            if tid:
                self.item["tmdb_id"] = str(tid)
            data = dict(data or {})
            if wrong_art_files:
                data["_wrong_art_files"] = list(wrong_art_files)
            if data:
                if tid:
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("vod:%s" % str(tid)), data, _DETAILS_DATA_CACHE_LIMIT)
                _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key(title_key), data, _DETAILS_DATA_CACHE_LIMIT)

            self._queueGui(self.applyDetails, data)
        except Exception:
            self._queueGui(self.applyDetails, {})


    def _startServerRecommendationResolve(self, data):
        snapshot=dict(data or {})
        token="%s:%s" % (
            str(self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("tmdb_id") or ""),
            str(self.item.get("name") or self.item.get("title") or "")
        )
        self._recommendResolveToken=token

        def worker():
            try:
                recs=self._serverOnlyTmdbRecommendations(snapshot)
            except Exception:
                recs=[]
            self._queueGui(self._applyServerRecommendations,token,recs)

        threading.Thread(
            target=worker,
            name="TiviMateServerRecommendations",
            daemon=True
        ).start()

    def _applyServerRecommendations(self, token, recs):
        if token != getattr(self,"_recommendResolveToken",""):
            return
        self.recommendations=list(recs or [])[:4]
        self._recommendDecoded = set()
        self._recommendFallbackTried = set()
        self._recommendWatchPass = 0
        self._recommendWatchAt = time.monotonic() + 7.0 if self.recommendations else 0.0
        for i in range(4):
            item=self.recommendations[i] if i<len(self.recommendations) else None
            self["recLabel%d" % i].setText((item.get("name") or item.get("title") or "")[:34] if item else "")
            if item:
                # Backdrop only. Never show poster/cover in recommendation cards.
                # Keep the placeholder until a real backdrop is available.
                url=self._norm(
                    _server_backdrop_url(self.source, item) or
                    item.get("backdrop_path") or item.get("backdrop") or
                    item.get("backdrop_url"), "w780")
                if url:
                    item["backdrop_path"] = url
                    self.loadImage(url,"rec%d" % i,400,190)
        self.updateFocus()
        # Download only the missing backdrop metadata. Existing backdrop URLs
        # already use the artwork queue's HDD/USB/RAM cache via loadImage.
        self._startRecommendationBackdropResolve(token, self.recommendations)


    def _recommendImageFailed(self, widget, failed_url):
        """Try alternate TMDb backdrop if a recommendation URL is unusable."""
        value = str(widget or "")
        if not (value.startswith("rec") and value[3:].isdigit()):
            return
        index = int(value[3:])
        if index >= len(self.recommendations) or index in self._recommendFallbackTried:
            return
        # A fallback may have switched w780 -> original or provider -> TMDb.
        # Compare with the currently requested widget URL, not an old row field.
        current = str(failed_url or "")
        if not current or getattr(self, "_image_requests", {}).get(value) != (value + "|" + current):
            return
        self._recommendFallbackTried.add(index)
        self._startRecommendationBackdropResolve(
            getattr(self, "_recommendResolveToken", ""), self.recommendations,
            force_indices=(index,), failed_urls={index: current})

    def _startRecommendationBackdropResolve(self, token, items, force_indices=(), failed_urls=None):
        # Ordinary pass searches metadata only for missing images. Forced pass
        # also handles broken provider/old-cache URLs, skipping the bad URL.
        forced = set(force_indices or ())
        rejected = dict(failed_urls or {})
        rows = [
            (index, dict(row)) for index, row in enumerate(list(items or [])[:4])
            if isinstance(row, dict) and (index in forced or not (
                row.get("backdrop_path") or row.get("backdrop") or row.get("backdrop_url")
            ))
        ]
        if not rows or not token:
            return
        source_snapshot = dict(self.source or {})

        def resolve(index, row):
            title = str(row.get("name") or row.get("title") or "").strip()
            if not title:
                return None
            is_forced = index in forced
            rejected_id = _tmdb_backdrop_identity(rejected.get(index)) if is_forced else ""

            def acceptable(candidate):
                candidate = str(candidate or "").strip()
                return bool(candidate) and (not rejected_id or
                    _tmdb_backdrop_identity(self._norm(candidate, "w780")) != rejected_id)

            def from_details(details):
                # Use other backdrops belonging to this exact movie ID when
                # the original one was missing/expired, never substitute posters.
                return next((p for p in _tmdb_same_movie_backdrops(details)
                             if acceptable(p)), "")

            # A cached provider URL is already server-first: avoid repeated
            # VOD info calls for recommendations on every screen entry.
            if not is_forced:
                known = _recommend_backdrop_get(source_snapshot, row)
                known_url = str(known.get("backdrop_path") or "")
                if acceptable(known_url) and "image.tmdb.org/t/p/" not in known_url:
                    return index, known_url, known.get("tmdb_id") or ""
            # A cached TMDb fallback must not outrank the provider's own
            # landscape image. Broken primary URLs are excluded below so
            # the same broken link cannot keep the card blank.
            try:
                provider = _recommend_genre_provider_backdrop(source_snapshot, row)
            except Exception:
                provider = ""
            if acceptable(provider):
                _recommend_backdrop_put(source_snapshot, row, provider, row.get("tmdb_id") or "")
                return index, provider, str(row.get("tmdb_id") or "")
            if not is_forced:
                known = _recommend_backdrop_get(source_snapshot, row)
                if acceptable(known.get("backdrop_path")):
                    return index, known["backdrop_path"], known.get("tmdb_id") or ""
            tmdb = TMDbClient()
            tid = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbid") or "").strip()
            backdrop = ""
            resolved_id = tid
            if tid:
                try:
                    details = tmdb.details_bundle(tid, "vod") or {}
                    backdrop = from_details(details)
                except Exception:
                    pass
            if not backdrop:
                year = self._year(row) or None
                try:
                    found = tmdb.search_artwork(title, kind="vod", year=year,
                                                required_key="backdrop_path") or {}
                except Exception:
                    found = {}
                candidate = found.get("backdrop_path") or ""
                resolved_id = str(found.get("tmdb_id") or found.get("id") or resolved_id or "").strip()
                if acceptable(candidate):
                    backdrop = candidate
                if not backdrop:
                    try:
                        found = tmdb.search_artwork(title, kind="vod", year=year) or {}
                    except Exception:
                        found = {}
                    resolved_id = str(found.get("tmdb_id") or found.get("id") or resolved_id or "").strip()
                    if resolved_id:
                        try:
                            backdrop = from_details(tmdb.details_bundle(resolved_id, "vod") or {})
                        except Exception:
                            pass
            if not backdrop:
                return None
            # Metadata index shares the normal HDD/USB artwork file cache.
            _recommend_backdrop_put(source_snapshot, row, backdrop, resolved_id)
            return index, backdrop, resolved_id

        def worker():
            with ThreadPoolExecutor(max_workers=2) as executor:
                futures = [executor.submit(resolve, index, row) for index, row in rows]
                for future in as_completed(futures):
                    try:
                        result = future.result()
                        if result:
                            self._queueGui(self._applyRecommendationBackdrops, token, [result])
                    except Exception:
                        pass

        threading.Thread(target=worker, name="TiviMateRecommendationBackdrops",
                         daemon=True).start()

    def _applyRecommendationBackdrops(self, token, updates):
        if token != getattr(self,"_recommendResolveToken",""):
            return
        for index,backdrop,tid in list(updates or []):
            if not (0 <= int(index) < len(self.recommendations)):
                continue
            try:
                item=self.recommendations[index]
                item["backdrop_path"]=backdrop
                if tid and not item.get("tmdb_id"):
                    item["tmdb_id"]=tid
                url=self._norm(backdrop,"w780")
                if url:
                    fallback_url=""
                    if isinstance(backdrop, str) and backdrop.startswith("/"):
                        fallback_url=self._norm(backdrop,"original")
                    self.loadImage(url,"rec%d" % index,400,190, fallback_url=fallback_url, retry=2)
            except Exception:
                pass


    def _movieLogoUrl(self, data):
        logos = ((data or {}).get("images") or {}).get("logos") or []
        return tmdb_logo_url(best_tmdb_logo(logos, preferred_logo_languages(details=data, item=self.item)), "w500")

    def _applyMovieTitleLogoUrl(self, url):
        url = str(url or "").strip()
        if not url:
            return
        self.item["_player_movie_logo"] = url
        self.item["_player_movie_logo_lang"] = logo_language()
        self.loadImage(url, "logoImage", 760, 132)

    def _loadMovieTitleLogo(self, data):
        # The ID comes from verified TMDb details, not the portal stream id.
        tid = str((data or {}).get("id") or "").strip()
        token = "%s:%s" % (tid, logo_language())
        self._movieTitleLogoToken = token
        if not tid:
            return
        def worker():
            try:
                from .title_logo_ultra_bridge import resolve_title_logo
                client = TMDbClient()
                title = str(self.item.get("name") or self.item.get("title") or "")
                path = resolve_title_logo(client, "vod", tid, title=title,
                                          details=data, item=self.item, canvas=(760, 132),
                                          cancelled=lambda: getattr(self, "_movieTitleLogoToken", "") != token)
                if path and getattr(self, "_movieTitleLogoToken", "") == token:
                    self._queueGui(self._applyMovieTitleLogoPath, path, token)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateMovieDetailsLogo", daemon=True).start()

    def _applyMovieTitleLogoPath(self, path, token):
        if token != getattr(self, "_movieTitleLogoToken", "") or not os.path.isfile(path):
            return
        self._movieTitleLogoPath = path   # same file for the trailer window
        self.decode(path, "logoImage", 760, 132)

    def _showMovieAgeCertification(self, token, certification):
        """Only show genuine German FSK pictograms, never text age badges.

        Other regional certificates such as R (US) have no suitable
        pictogram, so leave this space empty instead of showing a rectangle.
        The separate circular TMDb score stays untouched.
        """
        if token != getattr(self, "_movieAgeToken", ""):
            return
        self["ageIcon"].hide()
        value = str((certification or {}).get("certification") or "").strip()
        region = str((certification or {}).get("region") or "").upper()
        if region != "DE":
            return
        match = re.match(r"^(?:FSK\s*)?(0|6|12|16|18)\s*\+?$", value, re.I)
        if not match:
            return
        image = os.path.join(PLUGIN_PATH, "skins", "movies", "parental", "FSK_%s.png" % match.group(1))
        if os.path.isfile(image):
            try:
                self["ageIcon"].instance.setPixmapFromFile(image)
                self["ageIcon"].show()
            except Exception:
                pass

    def _loadMovieAgeCertification(self, data):
        # Opening Details must not block artwork, navigation or the video player.
        tmdb_id = str((data or {}).get("id") or self.item.get("tmdb_id") or self.item.get("tmdb") or "").strip()
        if not tmdb_id or tmdb_id == getattr(self, "_movieAgeToken", ""):
            return
        self._movieAgeToken = tmdb_id
        appended = (data or {}).get("release_dates")
        def worker():
            try:
                rating = TMDbClient().movie_age_certification(tmdb_id, appended)
            except Exception:
                rating = {}
            self._queueGui(self._showMovieAgeCertification, tmdb_id, rating)
        threading.Thread(target=worker, name="TiviMateMovieAgeCertification", daemon=True).start()

    def applyDetails(self, data):
        self._tmdb_bundle = dict(data or {})
        self._loadMovieAgeCertification(data)
        # Provider details and TMDb responses may arrive in either order.
        # Recompute visible facts from the same server-first policy every time.
        self._renderMovieInfoText(data)
        self._loadMovieTitleLogo(data)
        self["ratingText"].setText("")
        show_country_flag(self["countryFlag"], data, "movie", self.item.get("tmdb_id") or self.item.get("tmdb"))
        tmdb_poster = self._norm(data.get("poster_path"), "w500")
        server_poster = self.item.get("_resolved_server_poster") or _server_poster_url(self.source, self.item)
        tmdb_backdrop = self._norm(data.get("backdrop_path"), "w780")
        server_backdrop = (_server_backdrop_url(self.source, self.item,
                           extra=getattr(self, "_serverMovieInfo", {}) or {}) or "")
        # r146: provider art copied from another TMDb film is not used.
        wrong_poster = _provider_art_wrong(server_poster, data)
        if wrong_poster:
            server_poster = ""
        wrong_backdrop = _provider_art_wrong(server_backdrop, data) or (
            getattr(self, "_detailBackdropSource", "") == "provider" and
            _provider_art_wrong(getattr(self, "_detailBackdropUrl", ""), data))
        if wrong_backdrop:
            server_backdrop = ""
            if getattr(self, "_detailBackdropSource", "") == "provider":
                self._detailBackdropUrl = ""
                self._detailBackdropLocked = False
        if wrong_poster and not tmdb_poster:
            self.item.pop("_resolved_server_poster", None)
            try:
                self["poster"].hide()
            except Exception:
                pass
        if wrong_backdrop and not tmdb_backdrop:
            try:
                self["backdrop"].hide()
            except Exception:
                pass
        # Server poster is primary. TMDb is used only when the server
        # poster is missing/unavailable; the player itself performs no network lookup.
        poster = server_poster or tmdb_poster
        backdrop = server_backdrop or tmdb_backdrop
        if poster:
            self.item["_player_cover"] = poster
            self.item["poster_path"] = poster
            try:
                self.item["_player_cover_cache"] = artwork_path(poster, "posters")
            except Exception:
                self.item["_player_cover_cache"] = ""
            try:
                if server_poster and tmdb_poster and server_poster != tmdb_poster:
                    self.item["_player_cover_cache_fallback"] = artwork_path(tmdb_poster, "posters")
                else:
                    self.item["_player_cover_cache_fallback"] = ""
            except Exception:
                self.item["_player_cover_cache_fallback"] = ""
        if tmdb_backdrop:
            # Do not label an arbitrary provider background as verified TMDb.
            self.item["_tmdb_backdrop"] = tmdb_backdrop
        if data.get("id"):
            self.item["tmdb_id"] = str(data.get("id"))
        if data.get("title"):
            self.item["_tmdb_title"] = data.get("title")
        # Logo handoff is tagged with the TMDb locale so the native player
        # never reuses an English URL after switching to Arabic (or vice versa).
        try:
            _logos = ((data.get("images") or {}).get("logos") or [])
            _wanted = preferred_logo_languages(details=data, item=self.item)
            _path = best_tmdb_logo(_logos, _wanted)
            if _path and has_language_logo(_logos, _wanted[0]):
                self.item["_player_movie_logo"] = tmdb_logo_url(_path, "w500")
                self.item["_player_movie_logo_lang"] = logo_language()
            else:
                self.item.pop("_player_movie_logo", None)
                self.item.pop("_player_movie_logo_lang", None)
        except Exception:
            pass
        if poster:
            self.loadImage(
                poster, "poster", 350, 525,
                fallback_url=(tmdb_poster if server_poster and tmdb_poster and poster == server_poster else "")
            )
        else:
            self._primaryArtworkComplete()
        # Same server-first order as GENRE. TMDb is a fallback for a missing
        # or invalid provider backdrop, never an automatic later override.
        if backdrop and getattr(self, "_detailBackdropUrl", "") != backdrop:
            self._detailBackdropLocked = True
            self._detailBackdropSource = "provider" if server_backdrop else "tmdb"
            self._detailBackdropUrl = backdrop
            self.loadImage(backdrop, "backdrop", 1920, 1080,
                           fallback_url=(tmdb_backdrop if server_backdrop and
                                         tmdb_backdrop != backdrop else ""))
        cast = ((data.get("credits") or {}).get("cast") or [])[:6]
        self.actors = [dict(x) for x in cast if isinstance(x, dict)]
        if self.actor_index >= len(self.actors):
            self.actor_index = 0
        for i in range(6):
            if i < len(cast):
                name = cast[i].get("name") or ""
                character = cast[i].get("character") or ""
                self["actorLabel%d" % i].setText((name + ("\n" + character if character else ""))[:45])
                profile = self._norm(cast[i].get("profile_path"), "w185")
                if profile:
                    self.loadImage(profile, "actor%d" % i, 120, 120)
                else:
                    # No TMDb photo: neutral default portrait, not an empty gap.
                    try:
                        self["actor%d" % i].instance.setPixmapFromFile(_ACTOR_DEFAULT % 120)
                        self["actor%d" % i].show()
                    except Exception:
                        pass
            else:
                self["actorLabel%d" % i].setText(tr(""))
                try:
                    self["actor%d" % i].hide()
                except Exception:
                    pass
        # Recommendation rail is independent and started on page entry.
        # Never hide cached cards when a slower TMDb details callback arrives.
        self.updateFocus()
        if not getattr(self, "_recommendResolveToken", None):
            self._startServerRecommendationResolve(data)

    def _genreDetailMissing(self, widget, failed_url=''):
        if widget not in ('poster', 'backdrop', 'logoImage') or \
                getattr(self, '_guiDispatchClosed', False):
            return
        attempts = getattr(self, '_genreDetailAttempts', None)
        if attempts is None:
            attempts = set()
            self._genreDetailAttempts = attempts
        token = (widget, str(failed_url or ''))
        if token in attempts:
            return
        attempts.add(token)
        # A URL is not a successful backdrop. Unlock a failed candidate so
        # provider details / TMDb can still supply the real background.
        if widget == 'backdrop' and failed_url and (failed_url == getattr(self, '_detailBackdropUrl', '')):
            self._detailBackdropLocked = False
            self._detailBackdropSource = ''
        media = 'logo' if widget == 'logoImage' else widget
        dimensions = {'poster':(350,525), 'backdrop':(1920,1080), 'logoImage':(760,132)}
        expected = self._image_requests.get(widget)
        def still_current():
            return (not getattr(self, '_guiDispatchClosed', False) and
                    self._image_requests.get(widget) == expected)
        def ready(path):
            if (not still_current() or widget in getattr(self, '_genreDetailSuccess', set())
                    or not path or not os.path.isfile(path)):
                return
            if media == 'backdrop' and not _cinematic_is_landscape_image(path):
                return
            self._image_requests[widget] = 'genre-hero|' + path
            w,h = dimensions[widget]
            self.decode(path,widget,w,h)
        def failed(_path):
            return
        try:
            from .hero_shared import recover
            recover(dict(self.source or {}), dict(self.item or {}), 'vod',
                    media, ready, failed, self._queueGui,
                    excluded=(failed_url,) if failed_url else (),
                    canvas=(500,90), cancelled=lambda: not still_current())
        except Exception:
            attempts.discard(token)

    def loadImage(self, url, widget, width, height, fallback_url="", retry=1):
        """Render detail artwork reliably: primary URL, one retry, then fallback."""
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_url:
                return self.loadImage(fallback_url, widget, width, height, fallback_url="", retry=0)
            # GENRE/Hero also resolves artwork when the provider supplies no URL.
            # Keep the identity marker stable so asynchronous recovery can finish.
            if widget in ('poster', 'backdrop', 'logoImage'):
                requests = getattr(self, '_image_requests', None)
                if requests is None:
                    requests = {}
                    self._image_requests = requests
                requests[widget] = '%s|missing' % widget
                self._genreDetailMissing(widget)
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        # If a known fallback has already been downloaded, show it before
        # queuing the uncached primary. Preserve the original URL as its
        # fallback, so genuine missing-artwork recovery remains available.
        if fallback_url and fallback_url != url and widget != 'backdrop':
            bucket = 'logos' if widget == 'logoImage' else ('posters' if widget == 'poster' else 'backdrops')
            if cached_artwork(fallback_url, bucket) and not cached_artwork(url, bucket):
                url, fallback_url = fallback_url, url
        token = "%s|%s" % (widget, url)
        requests[widget] = token
        # Give visible recommendation cards priority above background fetches
        # without starving the primary poster/backdrop or page poster grid.
        priority = 100 if widget in ("poster", "backdrop") else (95 if str(widget).startswith("rec") else 45)
        def done(path, w=widget, x=width, y=height, expected=token):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            key = "%s|%sx%s" % (path, x, y)
            self.decode(path, w, x, y, key)

        def failed(_path, w=widget, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_image_requests", {}).get(w) != token:
                return
            if retries > 0 and not (str(w).startswith('rec') and str(w)[3:].isdigit()):
                # Retry other details artwork; GENRE already remembers failed
                # recommendation URLs temporarily, so do not request them again.
                self.loadImage(primary, w, width, height, fallback_url=fb, retry=retries - 1)
            elif fb and fb != primary:
                self.loadImage(fb, w, width, height, fallback_url="", retry=0)
            elif w in ('poster', 'backdrop', 'logoImage'):
                self._genreDetailMissing(w, primary)
            elif w.startswith("rec"):
                self._recommendImageFailed(w, primary)


        if widget in ("backdrop", "hero") or str(widget).startswith(("trend", "rec")):
            cache_kind = "backdrops"
        elif widget == "logoImage":
            cache_kind = "logos"
        elif widget == "promoBanner":
            cache_kind = "backdrops"
        else:
            cache_kind = "posters"
        if widget in ('poster', 'backdrop', 'logoImage') or (str(widget).startswith('rec') and str(widget)[3:].isdigit()):
            try:
                from .genre_ultra_artwork import request as genre_ultra_request, request_transparent_logo
                if widget == 'logoImage':
                    request_transparent_logo(url, dict(self.source or {}), done, failed, self._queueGui)
                else:
                    genre_ultra_request(url, cache_kind, dict(self.source or {}), done, failed, self._queueGui)
                return
            except Exception:
                pass
        request_artwork(url, cache_kind, done, priority=priority, errback=failed,
                        source=dict(self.source or {}))

    def _setWatchSearching(self):
        self._watchState = "searching"
        try:
            self["watch"].setText(tr("Searching..."))
        except Exception:
            pass
        self._applyWatchColor()

    def _setWatchReady(self):
        self._watchState = "ready"
        try:
            self["watch"].setText(tr("▶  Watch"))
        except Exception:
            pass
        self._applyWatchColor()

    def _setWatchUnavailable(self):
        self._watchState = "unavailable"
        try:
            self["watch"].setText(tr("Watch unavailable"))
        except Exception:
            pass
        self._applyWatchColor()

    def _applyWatchColor(self):
        """Watch is yellow; green while the cursor is on it; grey if unavailable."""
        try:
            instance = self["watch"].instance
            if instance is None:
                return
            if getattr(self, "_watchState", "") == "unavailable":
                back, fore = "#555B63", "#FFFFFF"
            elif getattr(self, "focus", "") == "buttons" and int(getattr(self, "button_index", 0) or 0) == 0:
                back, fore = "#2E9D57", "#FFFFFF"
            else:
                back, fore = "#E8B83F", "#17191D"
            instance.setBackgroundColor(parseColor(back))
            instance.setForegroundColor(parseColor(fore))
            instance.invalidate()
        except Exception:
            pass

    def _setSourcesSearching(self):
        try:
            self["sources"].setText(tr("Searching Sources..."))
        except Exception:
            pass



    def _primaryArtworkComplete(self):
        if self._primaryArtworkReady:
            return
        self._primaryArtworkReady = True
        if self._watchReady:
            self._setWatchReady()
            return
        self._startWatchResolve()




    def _fastSearchMovieRows(self):
        """Fast first pass: use the complete warmed catalog, not cached query results."""
        if self._fastVodRowsCache is not None:
            return list(self._fastVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or {})
            client = XtreamClient(source) if source.get("type") == "xtream" else StalkerClient(source)
            rows = list(get_filtered_streams(source, "vod", client, use_cache=True) or [])
        except Exception:
            rows = []
        self._fastVodRowsCache = list(rows or [])
        return list(self._fastVodRowsCache)


    def _fullServerMovieRowsFallback(self):
        """Filtered-only fallback.

        Never expand a movie search into disabled/hidden packages. Both automatic
        and manual resolution obey exactly the same saved category filter.
        """
        if self._fullVodRowsCache is not None:
            return list(self._fullVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or self.source or {})
            client = get_source_client(source)
            rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
        except Exception:
            rows = []
        self._fullVodRowsCache = list(rows or [])
        return list(self._fullVodRowsCache)


    def _fastTitleCandidates(self, rows):
        raw_title = (
            self.item.get("_tmdb_title") or self.item.get("name") or
            self.item.get("title") or self.item.get("original_title") or ""
        )
        query = self._title_norm(raw_title)
        if not query:
            return []

        exact = []
        loose = []
        qtokens = [x for x in query.split() if len(x) > 1]

        for row in rows or []:
            name = self._title_norm(row.get("name") or row.get("title") or row.get("original_title") or "")
            if not name:
                continue
            if name == query:
                exact.append(row)
                continue
            ntokens = [x for x in name.split() if len(x) > 1]
            if query in name or name in query:
                loose.append(row)
                continue
            if qtokens and ntokens and all(token in ntokens for token in qtokens):
                loose.append(row)

        return exact + loose





    def _cachedServerMatch(self):
        cached = _title_match_cache_get(self._vodSelectedSource or self.source, self.item)
        if cached:
            return cached
        return None

    def _cachedServerMatchStatus(self):
        return _title_match_cache_status(self._vodSelectedSource or self.source, self.item)

    def _mergeResolvedMatch(self, match):
        original = dict(self.item or {})
        match = dict(match or {})
        for key in (
            "tmdb_id", "_tmdb_title", "backdrop_path", "rating",
            "plot", "description", "year", "_home_tmdb_feed",
            "_tmdb_provider", "_server_package_provider",
            "_server_package_name", "_source_category_name", "category_name"
        ):
            if not match.get(key) and original.get(key):
                match[key] = original.get(key)
        self.item = match
        self._watchReady = True
        self._setWatchReady()
        try:
            self._updateProviderLogo()
        except Exception:
            pass

    def _forceWatchResolve(self):
        """Manual deep search from WATCH after an automatic miss."""
        if self._watchResolveStarted:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # Manual retry may bypass a cached miss, but it must NEVER bypass
                # the user's package/category filter.
                cached, cached_match = self._cachedServerMatchStatus()
                if cached_match is not None:
                    match = cached_match
                else:
                    source = dict(self._vodSelectedSource or self.source or {})
                    client = get_source_client(source)
                    rows = list(get_filtered_streams(source, "vod", client, use_cache=False) or [])
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    _title_match_cache_put(self._vodSelectedSource or self.source, self.item, None)
                    try:
                        self["watch"].setText(tr("▶  Watch / Search"))
                        if self["watch"].instance:
                            self._applyWatchColor()
                    except Exception:
                        pass
                    return
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, match)
                self._mergeResolvedMatch(match)

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchForceSearch")
        t.daemon = True
        t.start()


    def _startWatchResolve(self):
        if self._watchResolveStarted or self._watchReady:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # 0. Persistent cache includes both successful matches and real misses.
                # A cached miss stops automatic searching immediately.
                cache_known, cache_match = self._cachedServerMatchStatus()
                match = cache_match

                # 1. Already loaded FILTERED page/package data: essentially free.
                if not cache_known and match is None:
                    rows = list(self.server_items or [])
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 2. Enabled/filtered VOD catalog used by Search.
                if not cache_known and match is None:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 3. Full server VOD only when the fast filtered paths failed.
                if not cache_known and match is None:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    if not cache_known:
                        _title_match_cache_put(self._vodSelectedSource or self.source, self.item, None)
                    try:
                        self["watch"].setText(tr("▶  Watch / Search"))
                        if self["watch"].instance:
                            self._applyWatchColor()
                    except Exception:
                        pass
                    return
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, match)
                self._mergeResolvedMatch(match)

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchFilteredFirst")
        t.daemon = True
        t.start()




    def _otherSourcesMatcher(self):
        """Fast exact-title matcher for Other Sources (all copies, no cap)."""
        wanted = []
        for field in ("_tmdb_title", "name", "title", "original_title", "original_name"):
            norm = self._title_norm(self.item.get(field))
            if norm and norm not in wanted:
                wanted.append(norm)
        target_year = self._year(self.item)
        probe = set()
        for key in wanted:
            words = [w for w in key.split() if len(w) >= 3] or key.split()
            if words:
                probe.add(max(words, key=len))
        found, seen = [], set()

        def match(rows):
            for row in rows or []:
                if not isinstance(row, dict):
                    continue
                raw = " ".join(str(row.get(f) or "") for f in ("name", "title", "original_title")).lower()
                if probe and not any(w in raw for w in probe):
                    continue
                rid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or row.get("cmd") or "")
                if rid and rid in seen:
                    continue
                names = [self._title_norm(row.get(f)) for f in ("name", "title", "original_title")]
                score = max([self._title_score(w, n) for w in wanted for n in names if n] or [0.0])
                if score < 0.90:
                    continue
                row_year = self._year(row)
                if target_year and row_year and abs(target_year - row_year) > 1:
                    continue
                if rid:
                    seen.add(rid)
                found.append(dict(row))
        return match, found

    def _searchSourcesOnDemand(self):
        if self._sourcesSearchRunning:
            return
        if self._sourcesSearchDone:
            self.showSources()
            return

        self._sourcesSearchRunning = True
        self._setSourcesSearching()
        from . import search_result_cache
        source = dict(self._vodSelectedSource or self.source or {})
        movie_id = str(self.item.get("tmdb_id") or "").strip()
        if not movie_id or movie_id in ("0", "None"):
            movie_id = "%s|%s" % (self._title_norm(self.item.get("name") or self.item.get("title") or ""), self._year(self.item))
        sources_key = search_result_cache.make_key("sources2", source, movie_id)

        def worker():
            sources = []
            try:
                saved = search_result_cache.get(sources_key)
                if isinstance(saved, dict) and saved.get("rows"):
                    sources = [dict(r) for r in saved.get("rows") if isinstance(r, dict)]
                else:
                    match, found = self._otherSourcesMatcher()
                    # 1. Rows this screen already holds.
                    held = []
                    for pool in (self.server_items, self.recommendation_items,
                                 (self.source_context or {}).get("items")):
                        held.extend(list(pool or []))
                    match(held)
                    # 2. Enabled packages: RAM catalog, else package RAM/disk cache.
                    kept = _OTHER_SOURCES_CATALOG.get(self._otherSourcesKey())
                    if kept:
                        match(kept[0])
                    else:
                        match(self._cachedOtherSourceRows())
                    # 3. Nothing cached: one quick server lookup, never a full scan.
                    if not found and source.get("type") == "stalker":
                        match(self._stalkerNativeVodSearch())
                    elif not found and not kept:
                        try:
                            rows = list(get_filtered_streams(source, "vod", get_source_client(source), use_cache=True) or [])
                            if rows:
                                _OTHER_SOURCES_CATALOG[self._otherSourcesKey()] = (rows, time.time())
                            match(rows)
                        except Exception:
                            pass
                    sources = list(found)
                    try:
                        search_result_cache.put(sources_key, {"rows": sources})
                    except Exception:
                        pass
            except Exception:
                sources = []

            def finish():
                self._sourcesSearchRunning = False
                self._sourcesSearchDone = True
                self.applySources(sources)
                self.showSources()

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateSourcesFilteredFirst")
        t.daemon = True
        t.start()


    def _centerDetailsLogo(self, ptr=None):
        """r146: name text (Arabic + English) on top, clearlogo centred over
        the information badges just under it."""
        try:
            logo = self["logoImage"].instance
            title = self["title"].instance
            if logo is None:
                return
            centre = None
            left = right = None
            for name in ("infoResolution", "infoYear", "infoGenre", "infoDuration",
                         "infoRating", "ageIcon"):
                try:
                    widget = self[name]
                    inst = widget.instance
                    if inst is None or not inst.isVisible():
                        continue
                    if hasattr(widget, "getText") and name != "ageIcon" and \
                            not str(widget.getText() or "").strip():
                        continue
                    pos, size = inst.position(), inst.size()
                    if pos.x() < 0 or size.width() <= 2:
                        continue
                    a, b = pos.x(), pos.x() + size.width()
                    left = a if left is None else min(left, a)
                    right = b if right is None else max(right, b)
                except Exception:
                    continue
            if left is not None and right is not None and right > left:
                centre = (left + right) // 2
            if centre is None:
                centre = sx(980)
            # The prepared logo canvas is 760x132 with the logo centred in it.
            width = sx(760)
            x = max(sx(430), centre - width // 2)
            logo.resize(eSize(width, sy(132)))
            logo.move(ePoint(x, sy(72)))
            # r146: the film name (when there is no logo) uses the logo's place.
            if title is not None:
                title.resize(eSize(width, sy(132)))
                title.move(ePoint(x, sy(72)))
        except Exception:
            pass
        if ptr is not None and reactor is not None:
            def _again(screen=self):
                try:
                    if not getattr(screen, "_guiDispatchClosed", False):
                        screen._centerDetailsLogo()
                except Exception:
                    pass
            try:
                reactor.callLater(0.4, _again)
            except Exception:
                pass

    def decode(self,path,widget,width,height,mem_key=None):
        key = mem_key or ("%s|%sx%s" % (path, width, height))
        ptr = _memory_get(_DETAILS_PIXMAP_CACHE, key)
        if ptr is not None:
            try:
                self._detail_pixmap_keys.add(key)
                if self[widget].instance: self[widget].instance.setPixmap(ptr)
                if widget in ('poster', 'backdrop', 'logoImage'):
                    good = getattr(self, '_genreDetailSuccess', None)
                    if good is None:
                        good = set(); self._genreDetailSuccess = good
                    good.add(widget)
                if widget == "logoImage":
                    try:
                        self._centerDetailsLogo(ptr)
                        self["logoImage"].show()
                        self["title"].hide()
                    except Exception:
                        pass
                if str(widget).startswith("actor"):
                    self[widget].show()
                if str(widget).startswith("rec") and str(widget)[3:].isdigit():
                    try:
                        _idx = str(widget)[3:]
                        self._recommendDecoded.add(int(_idx))
                        self["rec%s" % _idx].show()
                        self["recLabel%s" % _idx].show()
                        self["recShell%s" % _idx].show()
                    except Exception:
                        pass
                if widget == "poster":
                    self._primaryArtworkComplete()
                return
            except Exception:
                pass
        l=ePicLoad(); self.picloads.append(l)
        expected_image = self._image_requests.get(widget)
        def ready(_=None,loader=l,w=widget,k=key,expected=expected_image):
            try:
                ptr=loader.getData()
                if ptr and (w not in ('poster', 'backdrop', 'logoImage') and
                            not (str(w).startswith('rec') and str(w)[3:].isdigit()) or
                            self._image_requests.get(w) == expected):
                    self._detail_pixmap_keys.add(k)
                    _memory_put(_DETAILS_PIXMAP_CACHE, k, ptr, _DETAILS_PIXMAP_CACHE_LIMIT)
                    if self[w].instance: self[w].instance.setPixmap(ptr)
                    if w in ('poster', 'backdrop', 'logoImage'):
                        good = getattr(self, '_genreDetailSuccess', None)
                        if good is None:
                            good = set(); self._genreDetailSuccess = good
                        good.add(w)
                    if w == "logoImage":
                        try:
                            self._centerDetailsLogo(ptr)
                            self["logoImage"].show()
                            self["title"].hide()
                        except Exception:
                            pass
                    if str(w).startswith("actor"):
                        self[w].show()
                    if str(w).startswith("rec") and str(w)[3:].isdigit():
                        try:
                            _idx = str(w)[3:]
                            self._recommendDecoded.add(int(_idx))
                            self["rec%s" % _idx].show()
                            self["recLabel%s" % _idx].show()
                            self["recShell%s" % _idx].show()
                        except Exception:
                            pass
                    if w == "poster":
                        self._primaryArtworkComplete()
                elif (str(w).startswith("rec") and str(w)[3:].isdigit() and
                      expected == self._image_requests.get(w)):
                    # ePicLoad can reject a downloaded but undecodable image.
                    index = int(str(w)[3:])
                    if 0 <= index < len(self.recommendations):
                        row = self.recommendations[index]
                        active = str(self._image_requests.get(w) or "")
                        if active.startswith(str(w) + "|"):
                            self._recommendImageFailed(w, active.split("|", 1)[1])
            except Exception:
                pass
            try:
                if loader in self.picloads:
                    self.picloads.remove(loader)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(l, ready, self, oneshot=True); l.setPara((render_width,render_height,0,0,False,1,"#00000000")); l.startDecode(path)

    def updateFocus(self):
        try:
            self["buttonSelector"].setVisible(self.focus=="buttons")
            self["actorSelector"].setVisible(self.focus=="actors" and bool(self.actors))
            self["recSelector"].setVisible(self.focus=="recommend" and bool(self.recommendations))
            if self.focus=="buttons": self["buttonSelector"].instance.move(ePoint(sx((475,765,1055)[max(0,min(2,self.button_index))]), sy(420)))
            if self.focus=="actors": self["actorSelector"].instance.move(ePoint(sx(self.ACTOR_X[self.actor_index]), sy(569)))
            if self.focus=="recommend": self["recSelector"].instance.move(ePoint(sx(self.REC_X[self.rec_index]), sy(840)))
        except Exception: pass
        self._applyWatchColor()

    def left(self):
        if self.focus=="buttons": self.button_index=max(0,self.button_index-1)
        elif self.focus=="actors": self.actor_index=max(0,self.actor_index-1)
        elif self.focus=="recommend": self.rec_index=max(0,self.rec_index-1)
        self.updateFocus()
    def right(self):
        if self.focus=="buttons": self.button_index=min(2,self.button_index+1)
        elif self.focus=="actors": self.actor_index=min(max(0,len(self.actors)-1),self.actor_index+1)
        elif self.focus=="recommend": self.rec_index=min(max(0,len(self.recommendations)-1),self.rec_index+1)
        self.updateFocus()
    def up(self):
        if self.focus=="recommend" and self.actors:
            self.focus="actors"
        else:
            self.focus="buttons"
        self.updateFocus()
    def down(self):
        if self.focus=="buttons" and self.actors:
            self.focus="actors"
        elif self.focus=="actors" and self.recommendations:
            self.focus="recommend"
        elif self.recommendations:
            self.focus="recommend"
        self.updateFocus()

    def _rowTmdbId(self, row):
        row = row or {}
        for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
            for key in ("tmdb_id", "tmdb", "tmdbid", "tmdbId"):
                value = mapping.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _recommendTitleNorm(self, value):
        text=str(value or "").lower()
        text=text.replace("&"," and ")
        text=re.sub(r"\b(?:netflix|nf|prime video|amazon prime|prime|amz|amzn)\b"," ",text)
        text=re.sub(r"\b(?:4k|uhd|fhd|fullhd|hd|sd|hdr|dv|dolby|atmos|hevc|x265|x264)\b"," ",text)
        text=re.sub(r"\b(?:multi|dual|audio|arabic|english|eng|ar|sub|subs|dub|dubbed)\b"," ",text)
        text=re.sub(r"\b(?:19|20)\d{2}\b"," ",text)
        text=re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}"," ",text)
        text=re.sub(r"[^a-z0-9]+"," ",text)
        return " ".join(text.split())

    def _recommendationMatches(self, target, rows):
        target = target or {}
        wanted_id = str(target.get("tmdb_id") or target.get("id") or "").strip()
        wanted_titles = [
            self._recommendTitleNorm(target.get(field))
            for field in ("name", "title", "original_title")
        ]
        wanted_titles = list(dict.fromkeys(x for x in wanted_titles if x))
        target_year = self._year(target)

        ranked = []
        seen = set()
        for row in rows or []:
            if not isinstance(row, dict):
                continue

            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            unique = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue

            exact_tmdb = bool(wanted_id and self._rowTmdbId(row) == wanted_id)
            candidate_titles = [
                self._recommendTitleNorm(row.get(field))
                for field in ("name", "title", "original_title")
            ]
            score = max(
                [self._title_score(w, c) for w in wanted_titles for c in candidate_titles] or [0.0]
            )

            if score < 0.90:
                for wanted in wanted_titles:
                    wanted_tokens = set(wanted.split())
                    if not wanted_tokens:
                        continue
                    for candidate in candidate_titles:
                        candidate_tokens = set(candidate.split())
                        if not candidate_tokens:
                            continue
                        overlap = wanted_tokens & candidate_tokens
                        coverage = float(len(overlap)) / float(max(1, min(len(wanted_tokens), len(candidate_tokens))))
                        if coverage >= 0.90 and len(overlap) >= 2:
                            score = max(score, 0.91)

            if not exact_tmdb and score < 0.84:
                continue

            row_year = self._year(row)
            exact_year = bool(target_year and row_year and target_year == row_year)
            if target_year and row_year and abs(target_year - row_year) > 1 and not exact_tmdb:
                continue

            ranked.append((1 if exact_tmdb else 0, 1 if exact_year else 0, score, dict(row)))
            seen.add(unique)

        ranked.sort(key=lambda value: (value[0], value[1], value[2]), reverse=True)
        return [value[3] for value in ranked]


    def ok(self):
        if self.focus=="actors" and self.actors:
            self._openActorMovies(self.actors[self.actor_index])
            return
        if self.focus=="buttons":
            if self.button_index==0:
                self.watchSelected()
            elif self.button_index==1:
                self.playTrailer()
            else:
                self.openMoreInfo()
            return
        if self.focus=="recommend" and self.recommendations:
            next_item=dict(self.recommendations[self.rec_index] or {})
            next_item["_source_scope"]=self._recommendationScope
            if self._recommendationCategoryId:
                next_item["_source_category_id"]=self._recommendationCategoryId
            self.session.open(
                MovieDetailsScreen,self.source,next_item,self.server_items,
                {"scope":self._recommendationScope,"category_id":self._recommendationCategoryId,"items":list(self.recommendation_items or [])}
            )
            return

    def _openActorMovies(self, actor):
        actor = dict(actor or {})
        person_id = str(actor.get("id") or "").strip()
        actor_name = str(actor.get("name") or "Actor").strip()
        if not person_id:
            self.session.open(MessageBox, tr("Actor information is unavailable."), MessageBox.TYPE_INFO)
            return
        if getattr(self, "_actorMoviesLoading", False):
            return
        self._actorMoviesLoading = True
        self["meta"].setText("Movies featuring %s" % actor_name)

        current_sid = str(self.item.get("stream_id") or self.item.get("vod_id") or self.item.get("id") or "")
        current_tmdb = str(self.item.get("tmdb_id") or self.item.get("tmdb") or "")
        category_id = str(
            self.source_context.get("category_id") or
            self.item.get("_source_category_id") or
            self.item.get("category_id") or self.item.get("categoryId") or
            self._recommendationCategoryId or ""
        ).strip()
        context_rows = list(self.source_context.get("items") or [])

        def worker():
            matches = []
            from_cache = [False]
            actor_key = ""
            try:
                # Saved result (RAM + disk, 12 h): a repeated actor search
                # on the same server opens at once, even after a GUI restart.
                from . import search_result_cache as _actor_cache
                actor_key = _actor_cache.make_key("actor_vod", self.source, person_id)
                saved = _actor_cache.get(actor_key) or {}
                for row in (saved.get("rows") or []):
                    if not isinstance(row, dict):
                        continue
                    sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
                    rtmdb = str(self._rowTmdbId(row) or "")
                    if (current_sid and sid == current_sid) or (current_tmdb and rtmdb and rtmdb == current_tmdb):
                        continue
                    matches.append(dict(row))
                if matches:
                    from_cache[0] = True
            except Exception:
                pass
            try:
                if from_cache[0]:
                    raise StopIteration()
                # Shared matcher (also used by TV Shows): credits in the TMDb
                # language + English + Arabic; TMDb id first, then titles that
                # understand Arabic spelling and IPTV prefixes/suffixes.
                from .actor_match import ActorCredits
                credits = ActorCredits(person_id, "vod")
                seen_rows = set()

                def collect_exact(rows, result_category_id):
                    before = len(matches)
                    for row in (rows or []):
                        if not isinstance(row, dict) or not credits.matches(row):
                            continue
                        sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
                        rtmdb = str(self._rowTmdbId(row) or "")
                        if (current_sid and sid == current_sid) or (current_tmdb and rtmdb and rtmdb == current_tmdb):
                            continue
                        marker = sid or id(row)
                        if marker in seen_rows:
                            continue
                        seen_rows.add(marker)
                        result = dict(row)
                        result["_source_category_id"] = str(result_category_id or row.get("category_id") or "")
                        matches.append(result)
                    return len(matches) - before

                # Scope: current package first, then every enabled movie package.
                categories, _origin = get_cached_categories(self.source, "vod", wait_for_server=False)
                allowed_ids = get_allowed_category_ids(self.source, "vod")
                allowed_set = None if allowed_ids is None else set(str(x) for x in allowed_ids)
                blocked = {
                    "all", "all movies", "all films", "all vod",
                    "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المحتوى"
                }
                package_ids = []
                if category_id:
                    package_ids.append(category_id)
                for entry in (categories or []):
                    if not isinstance(entry, dict):
                        continue
                    cid = str(entry.get("category_id") or "").strip()
                    name = str(entry.get("category_name") or "").strip()
                    if not cid or cid in package_ids or cid == "__recent_added__":
                        continue
                    if allowed_set is not None and cid not in allowed_set:
                        continue
                    if name.lower() in blocked:
                        continue
                    package_ids.append(cid)

                # Current package rows already on screen are the fastest source.
                current_rows = []
                for row in (context_rows + list(self.server_items or [])):
                    if not isinstance(row, dict):
                        continue
                    rcid = str(row.get("category_id") or row.get("categoryId") or "").strip()
                    if not category_id or rcid == category_id:
                        current_rows.append(dict(row))
                cache_misses = []
                for cid in package_ids:
                    if cid == category_id and current_rows:
                        collect_exact(current_rows, cid)
                        continue
                    rows, cache_origin = peek_category_streams_cache(self.source, "vod", cid)
                    if cache_origin == "miss":
                        cache_misses.append(cid)
                        continue
                    collect_exact(rows, cid)

                # Every enabled package is searched from cache; the full movie
                # catalogue cache covers packages that were never opened.
                catalog = []
                try:
                    from .filters import peek_filtered_streams_cache
                    catalog, _catalog_origin = peek_filtered_streams_cache(self.source, "vod")
                    collect_exact(catalog, "")
                except Exception:
                    pass
                # Server requests are the slow part: only when the cached full
                # catalogue is missing or nothing was found in the caches.
                # Then uncached packages are fetched (current one first, max 12).
                if cache_misses and (not catalog or not matches):
                    client = get_source_client(self.source)
                    for cid in cache_misses[:12]:
                        try:
                            rows, _server_origin = get_category_streams(
                                self.source, "vod", client, cid,
                                use_cache=True, wait_for_server=True
                            )
                        except Exception:
                            continue  # one slow/broken package must not hide the others
                        collect_exact(rows, cid)
            except Exception:
                pass  # keep the matches already found
            if matches and not from_cache[0] and actor_key:
                try:
                    from . import search_result_cache as _actor_cache
                    _actor_cache.put(actor_key, {"rows": [dict(r) for r in matches[:300]]})
                except Exception:
                    pass

            def finish():
                self._actorMoviesLoading = False
                self["meta"].setText("")
                if not matches:
                    self.session.open(MessageBox, "No movies for %s were found." % actor_name, MessageBox.TYPE_INFO)
                    return
                from .actor_results_layout import open_actor_results
                open_actor_results(self.session, self.source, "vod", actor_name, matches, style="spotlight", actor=actor)
            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateActorCacheMovies")
        t.daemon = True
        t.start()

    def _openCollectionParts(self, tmdb_id=None, status=None):
        """All parts of this movie's TMDb collection that the server has.

        Fast path: rows already in memory, the Other Sources catalog, the
        package RAM/disk cache. Only parts still missing are looked up on the
        server (Stalker: one native search per part, Xtream: cached catalog).
        """
        if getattr(self, "_partsLoading", False):
            return
        bundle = dict(getattr(self, "_tmdb_bundle", {}) or {})
        tid = str(tmdb_id or self.item.get("tmdb_id") or bundle.get("id") or "").strip()
        if not tid:
            self.session.open(MessageBox, tr("Movie details are still loading."), MessageBox.TYPE_INFO)
            return
        source = dict(self._vodSelectedSource or self.source or {})
        from . import search_result_cache
        parts_key = search_result_cache.make_key("parts", source, tid)
        saved = search_result_cache.get(parts_key)
        if isinstance(saved, dict):
            if saved.get("error") == "none":
                self.session.open(MessageBox, tr("This movie has no other parts."), MessageBox.TYPE_INFO, timeout=5)
                return
            if saved.get("rows"):
                from .actor_results_layout import open_actor_results
                if open_actor_results(self.session, source, "vod", saved.get("name") or tr("Movie Parts"), saved.get("rows")):
                    return
        self._partsLoading = True

        def say(text):
            if callable(status):
                try:
                    status(text)
                except Exception:
                    pass
        say(tr("Searching..."))

        def worker():
            result = {"name": "", "rows": [], "error": "", "missing": 0}
            try:
                client = TMDbClient()
                collection = bundle.get("belongs_to_collection")
                if not isinstance(collection, dict) or not collection.get("id"):
                    details = client._get("/movie/%s" % tid, {}) or {}
                    collection = details.get("belongs_to_collection")
                if not isinstance(collection, dict) or not collection.get("id"):
                    result["error"] = "none"
                    raise StopIteration()
                cid = collection.get("id")
                english_box = {}

                def fetch_english():
                    try:
                        english_box["data"] = client._get("/collection/%s" % cid, {"language": "en-US"}) or {}
                    except Exception:
                        english_box["data"] = {}
                english_thread = threading.Thread(target=fetch_english, name="TiviMatePartsEN")
                english_thread.daemon = True
                english_thread.start()
                data = client._get("/collection/%s" % cid, {}) or {}
                result["name"] = data.get("name") or collection.get("name") or ""
                parts = [p for p in (data.get("parts") or []) if isinstance(p, dict)]
                english_thread.join(6)
                try:
                    english = english_box.get("data") or {}
                    by_id = dict((p.get("id"), p) for p in (english.get("parts") or []) if isinstance(p, dict))
                    for p in parts:
                        alt = by_id.get(p.get("id")) or {}
                        if alt.get("title"):
                            p["_en_title"] = alt.get("title")
                except Exception:
                    pass
                parts.sort(key=lambda p: str(p.get("release_date") or "9999"))
                if not parts:
                    result["error"] = "none"
                    raise StopIteration()

                def titles(p):
                    out = []
                    for field in ("title", "original_title", "_en_title", "name"):
                        norm = self._title_norm(p.get(field))
                        if norm and norm not in out:
                            out.append(norm)
                    return out

                wanted = [(p, titles(p), self._year(p)) for p in parts]
                # Cheap pre-filter: a row is normalised (slow regex work) only
                # when its raw name contains a word of some part title.
                probe = set()
                for _part, keys, _year in wanted:
                    for key in keys:
                        words = [w for w in key.split() if len(w) >= 3] or key.split()
                        if words:
                            probe.add(max(words, key=len))
                found = {}          # part index -> every copy on the server
                seen_rows = set()

                def match(rows):
                    for row in rows or []:
                        if not isinstance(row, dict):
                            continue
                        raw = " ".join(str(row.get(f) or "") for f in ("name", "title", "original_title")).lower()
                        if probe and not any(w in raw for w in probe):
                            continue
                        rid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or row.get("cmd") or "")
                        if rid and rid in seen_rows:
                            continue
                        names = [self._title_norm(row.get(f)) for f in ("name", "title", "original_title")]
                        names = [n for n in names if n]
                        if not names:
                            continue
                        row_year = self._year(row)
                        best, best_score = None, 0.0
                        for index, (part, keys, year) in enumerate(wanted):
                            score = max([self._title_score(k, n) for k in keys for n in names] or [0.0])
                            if score < 0.92:
                                continue
                            if year and row_year and abs(year - row_year) > 1:
                                continue
                            if score > best_score:
                                best, best_score = index, score
                        if best is None:
                            continue
                        if rid:
                            seen_rows.add(rid)
                        hit = dict(row)
                        hit["_collection_part"] = wanted[best][0].get("title") or ""
                        hit["_keep_copy"] = True
                        found.setdefault(best, []).append(hit)

                held = []
                for pool in (self.server_items, self.recommendation_items,
                             (self.source_context or {}).get("items")):
                    held.extend(list(pool or []))
                match(held)
                kept = _OTHER_SOURCES_CATALOG.get(self._otherSourcesKey())
                if kept:
                    match(kept[0])
                else:
                    match(self._cachedOtherSourceRows())
                missing = [i for i in range(len(wanted)) if i not in found]
                if missing and source.get("type") == "stalker":
                    try:
                        engine = getattr(get_source_client(source), "_ultra_client", None)
                        search = getattr(engine, "search_category_fast", None)
                    except Exception:
                        search = None
                    if callable(search):
                        # Missing parts searched at the same time, not one by one.
                        boxes = []

                        def one(query, box):
                            try:
                                box.extend(search(query, "vod", "*", limit=60, max_pages=3, time_budget=4) or [])
                            except Exception:
                                pass
                        threads = []
                        for index in missing[:10]:
                            part = wanted[index][0]
                            query = part.get("_en_title") or part.get("title") or ""
                            if not query:
                                continue
                            box = []
                            boxes.append(box)
                            worker_thread = threading.Thread(target=one, args=(query, box), name="TiviMatePartsSearch")
                            worker_thread.daemon = True
                            worker_thread.start()
                            threads.append(worker_thread)
                        for worker_thread in threads:
                            worker_thread.join(6)
                        for box in boxes:
                            match(list(box))
                elif missing and source.get("type") == "xtream" and not kept:
                    try:
                        rows = list(get_filtered_streams(source, "vod", get_source_client(source), use_cache=True) or [])
                        if rows:
                            _OTHER_SOURCES_CATALOG[self._otherSourcesKey()] = (rows, time.time())
                        match(rows)
                    except Exception:
                        pass
                ordered = []
                for index in sorted(found):
                    ordered.extend(found[index])
                result["rows"] = ordered
                result["missing"] = len(wanted) - len(found)
            except StopIteration:
                pass
            except Exception as exc:
                result["error"] = str(exc)

            if result["error"] in ("", "none"):
                try:
                    search_result_cache.put(parts_key, {"name": result["name"], "rows": result["rows"],
                                                        "error": result["error"]})
                except Exception:
                    pass

            def finish():
                self._partsLoading = False
                say(tr("Movie Parts"))
                if result["error"] == "none":
                    self.session.open(MessageBox, tr("This movie has no other parts."), MessageBox.TYPE_INFO, timeout=5)
                    return
                if not result["rows"]:
                    self.session.open(MessageBox, tr("No parts of this movie were found on this server."), MessageBox.TYPE_INFO, timeout=5)
                    return
                from .actor_results_layout import open_actor_results
                open_actor_results(self.session, source, "vod", result["name"] or tr("Movie Parts"), result["rows"])
            self._queueGui(finish)

        thread = threading.Thread(target=worker, name="TiviMateCollectionParts")
        thread.daemon = True
        thread.start()

    def _actorMovieChosen(self, item=None):
        if not item:
            return
        next_item = dict(item or {})
        self.session.open(
            MovieDetailsScreen, self.source, next_item, self.server_items,
            {"scope": self._recommendationScope, "category_id": self._recommendationCategoryId, "items": list(self.recommendation_items or [])}
        )

    def showSources(self):
        if not self.sources_list:
            self.session.open(MessageBox,"No exact alternate source is available for this movie.",MessageBox.TYPE_INFO)
            return
        # Posters, like Movie Parts / actor movies.
        try:
            from .actor_results_layout import open_actor_results
            entries = [dict(x) for x in self.sources_list if isinstance(x, dict)]
            for entry in entries:
                entry["_keep_copy"] = True
            if open_actor_results(self.session, dict(self._vodSelectedSource or self.source or {}),
                                  "vod", tr("Other Sources"), entries):
                return
        except Exception:
            pass
        rows = []
        for x in self.sources_list:
            label = x.get("name") or x.get("title") or "Source"
            if x.get("_other_sources_current"):
                label = "Current Source  •  %s" % label
            rows.append((label, x))
        self.session.openWithCallback(self.sourceChosen, SourceChoiceScreen, rows, "EXACT MATCHING SOURCES", self.source, self.item)
    def sourceChosen(self,item=None):
        if item: self.playItem(item)
    def toggleFavourite(self):
        item = self._playable_item() or self.item
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, "vod", item)
            title = item.get("name") or item.get("title") or "الفيلم"
            if not saved:
                self["meta"].setText(tr("Unable to save favorite"))
            elif added:
                self["meta"].setText("★ تمت إضافة %s إلى المفضلات" % title)
            else:
                self["meta"].setText("☆ تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["meta"].setText("تعذر تحديث المفضلة: %s" % exc)


    def _resolveHomeMovieForPlay(self):
        if getattr(self, "_homePlayResolving", False):
            return

        cached = self._cachedServerMatch()
        if cached:
            self.sources_list = [cached]
            self.playItem(cached)
            return

        # Home passes a warmed server VOD index. Resolve synchronously in memory
        # first; this avoids the visible search delay for Backdrop movies.
        if self.server_items:
            wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
            wanted = list(dict.fromkeys(x for x in wanted if x))
            target_year = self._year(self.item)
            best = None
            best_score = 0.0
            for row in self.server_items:
                candidate_titles = [self._title_norm((row or {}).get(field)) for field in ("name","title","original_title")]
                score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                if not score:
                    continue
                row_year = self._year(row or {})
                if target_year and row_year and abs(target_year-row_year) > 1:
                    continue
                if target_year and row_year == target_year:
                    score += 0.02
                if score > best_score:
                    best, best_score = dict(row), score
            if best is not None and best_score >= 0.90:
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                _title_match_cache_put(self._vodSelectedSource or self.source, self.item, best)
                self.sources_list = [best]
                self.playItem(best)
                return

        self._homePlayResolving = True
        # Keep WATCH label stable; the lookup is background-only.
        # This avoids a visible loading/search state for short cache misses.
        wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        source = dict(self.source or {})

        def worker():
            best = None
            best_score = 0.0
            try:
                client = get_source_client(source)
                rows = list(self._fullServerVodCatalog() or [])
                for row in rows:
                    candidate_titles = [self._title_norm(row.get(field)) for field in ("name","title","original_title")]
                    score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                    if not score:
                        continue
                    row_year = self._year(row)
                    if target_year and row_year and abs(target_year-row_year)>1:
                        continue
                    bonus = 0.02 if target_year and row_year == target_year else 0.0
                    if score + bonus > best_score:
                        best = dict(row); best_score = score + bonus
                if best_score < 0.90:
                    best = None
            except Exception:
                best = None

            def finish():
                self._homePlayResolving = False
                self["watch"].setText(tr("▶  Watch"))
                if not best:
                    self.session.open(MessageBox, tr("This movie is not available on the current server."), MessageBox.TYPE_INFO)
                    return
                # Keep the rich TMDb artwork/details while provider identity drives playback.
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                self.sources_list = [best]
                self.playItem(best)
            self._queueGui(finish)

        t=threading.Thread(target=worker,name="TiviMateHomeMoviePlayResolve")
        t.daemon=True; t.start()


    def openMoreInfo(self):
        # Same-movie artwork only. Reuse the already resolved TMDb id/bundle;
        # the More Info screen performs an images-only fallback when needed.
        tmdb_id = str(self.item.get("tmdb_id") or self.item.get("tmdb") or "").strip()
        bundle = dict(getattr(self, "_tmdb_bundle", {}) or {})
        if not tmdb_id:
            tmdb_id = str(bundle.get("id") or "").strip()
        if not tmdb_id:
            self.session.open(MessageBox, tr("Movie images are still loading."), MessageBox.TYPE_INFO)
            return
        screen = self.session.open(MovieMoreInfoScreen, self.item, tmdb_id, bundle, self._searchSourcesOnDemand)
        try:
            screen.parts_callback = self._openCollectionParts
        except Exception:
            pass

    def playTrailer(self):
        # Self-contained path: TMDb exact trailer ID -> bundled YouTube resolver -> Enigma2 player.
        # No Browser plugin and no external yt-dlp package are required.
        if getattr(self, "_trailerResolving", False):
            return
        item = dict(self.item or {})
        bundle = dict(getattr(self, "_tmdb_bundle", {}) or {})
        tid = item.get("tmdb_id") or item.get("_locked_tmdb_id") or bundle.get("id") or bundle.get("tmdb_id")
        try:
            tid = int(str(tid or "0").strip())
        except Exception:
            tid = 0
        if tid <= 0:
            self.session.open(MessageBox, "Trailer details are not available for this title yet.", MessageBox.TYPE_INFO)
            return
        self._trailerResolving = True
        try: self["trailer"].setText("▶  Trailer")
        except Exception: pass

        def worker():
            result = _resolve_movie_trailer_stream(tid)

            def finish():
                self._trailerResolving = False
                try: self["trailer"].setText("▶  Trailer")
                except Exception: pass
                state = result.get("state")
                if state == "missing":
                    self.session.open(MessageBox, "No English trailer available for this movie.", MessageBox.TYPE_INFO); return
                if state != "ready":
                    msg = "YouTube did not provide a playable MP4, DASH or HLS trailer."
                    if result.get("error"): msg += "\n\n" + str(result.get("error"))[:350]
                    self.session.open(MessageBox, msg, MessageBox.TYPE_ERROR); return
                try:
                    # Keep the proven 4097 + single progressive MP4 path, but
                    # render it in a centered popup over Movie Details instead of
                    # replacing the details screen with the full movie player.
                    trailer_url = str(result.get("url") or "").strip()
                    trailer_name = str(result.get("name") or "Trailer").strip() or "Trailer"
                    ref = _trailer_reference(
                        trailer_url, trailer_name,
                        5002 if result.get("split") and _trailer_has_serviceapp() else 4097)
                    # Open Trailer as a real popup screen, exactly like the Other Sources
                    # flow: Movie Details remains underneath and BACK closes only the popup.
                    # Do not reuse/attach an overlay dialog to the Watch action.
                    self.session.open(TrailerPopupScreen, ref, trailer_name, self)
                except Exception as exc:
                    self.session.open(MessageBox, "Trailer player failed:\n%s" % exc, MessageBox.TYPE_ERROR)
            if reactor is not None:
                try:
                    reactor.callFromThread(finish); return
                except Exception: pass
            self._queueGui(finish)

        try:
            t = threading.Thread(target=worker, name="TiviMateTrailerEmbeddedYT")
            t.daemon = True; t.start()
        except Exception as exc:
            self._trailerResolving = False
            try: self["trailer"].setText("▶  Trailer")
            except Exception: pass
            self.session.open(MessageBox, "Trailer failed:\n%s" % exc, MessageBox.TYPE_ERROR)

    def _closeTrailerOverlay(self):
        dlg = getattr(self, "_trailerOverlay", None)
        if dlg is None:
            return False
        self._trailerOverlay = None
        try:
            if self.session.current_dialog is dlg:
                dlg.close()
            else:
                self.session.deleteDialog(dlg)
        except Exception:
            pass
        return True

    def _cancelOrCloseTrailer(self):
        if self._closeTrailerOverlay():
            return
        self.close()

    def watchSelected(self):
        item = dict(self.item or {})
        # Watch is movie-only. Trailer playback must stay on the Trailer action.
        if item.get("_is_trailer") or str(item.get("_kind") or "").lower() == "trailer":
            self._forceWatchResolve()
            return
        for _k in ("url", "stream_url"):
            _u = str(item.get(_k) or "").lower()
            if "youtube.com" in _u or "youtu.be" in _u or "googlevideo.com" in _u:
                item.pop(_k, None)
        if not self._watchReady or not (item.get("stream_id") or item.get("vod_id")):
            self._forceWatchResolve()
            return
        item["_kind"] = "vod"
        item.pop("_is_trailer", None)
        self.playItem(item)


    def playItem(self,item):
        try:
            row = _movie_continue_row(self.source, item)
            if not row:
                raise Exception("No playable URL")
            from .ui import play_vod_exact_continue_path
            play_vod_exact_continue_path(
                self.session,
                row,
                current_source=dict(self.source or {}),
                callback=None
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to play:\n%s" % exc, MessageBox.TYPE_ERROR)

SOURCE_CHOICE = '''<screen name="SourceChoiceScreen" position="330,160" size="1260,760" flags="wfNoBorder" backgroundColor="#20242A">
<widget name="movieLogo" position="45,28" size="330,82" alphatest="blend" zPosition="3" />
<widget name="movieTitle" position="45,35" size="330,65" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="poster" position="65,120" size="290,435" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<widget name="title" position="405,30" size="805,55" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" />
<widget name="list" position="405,110" size="805,500" font="Regular;27" itemHeight="54" scrollbarMode="showOnDemand" backgroundColor="#20242A" foregroundColor="#FFFFFF" selectionBackgroundColor="#3A414B" selectionForegroundColor="#F2D36B" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="405,632" size="805,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/source_choice_guide_r69.png" alphatest="blend" zPosition="3" />
</screen>'''

SOURCE_CHOICE = scale_skin(SOURCE_CHOICE)

class SourceChoiceScreen(Screen):
    skin=SOURCE_CHOICE
    def __init__(self,session,rows,title="EXACT MATCHING SOURCES",source=None,movie_item=None):
        Screen.__init__(self,session); self.rows=rows or []
        self.source=dict(source or {}); self.movie_item=dict(movie_item or {})
        self["title"]=Label(title)
        self["list"]=MenuList([(x[0],x[1]) for x in self.rows])
        self["keys"]=Label(tr("OK Play     EXIT Back"))
        self["guideBar"]=Pixmap(); self["poster"]=Pixmap(); self["movieLogo"]=Pixmap()
        self["movieTitle"]=Label(self.movie_item.get("name") or self.movie_item.get("title") or "")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.ok,"cancel":self.close,"up":lambda:self["list"].up(),"down":lambda:self["list"].down()},-1)
        self.onLayoutFinish.append(self._loadMovieArtwork)

    def _loadMovieArtwork(self):
        item=self.movie_item or {}
        poster=str(item.get("_tmdb_poster") or item.get("stream_icon") or item.get("cover") or item.get("poster") or item.get("poster_path") or "").strip()
        if poster and poster.startswith("/") and item.get("_tmdb"):
            poster="https://image.tmdb.org/t/p/w500" + poster
        elif poster:
            poster=_server_asset_url(self.source, poster)
        logo=str(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "").strip()
        if logo and logo.startswith("/") and item.get("_tmdb"):
            logo="https://image.tmdb.org/t/p/w500" + logo
        elif logo:
            logo=_server_asset_url(self.source, logo)

        def set_image(widget, url, kind):
            if not url:
                return
            def done(path):
                try:
                    if path and os.path.exists(path):
                        self[widget].instance.setPixmapFromFile(path); self[widget].show()
                        if widget == "movieLogo": self["movieTitle"].hide()
                except Exception:
                    pass
            try: request_artwork(url, kind, done, priority=0, source=dict(self.source or {}))
            except Exception: pass
        set_image("poster", poster, "posters")
        set_image("movieLogo", logo, "logos")

    def ok(self):
        c=self["list"].getCurrent()
        if c:self.close(c[1])



def _screen_content_dedupe_key(item, kind=""):
    row = item or {}
    tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
    if tmdb_id and tmdb_id not in ("0", "None", "none"):
        return "tmdb:%s:%s" % (str(kind or ""), tmdb_id)
    title = str(row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or "").lower().strip()
    title = re.sub(r"[\[\(][^\]\)]*(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264|arabic|english|multi)[^\]\)]*[\]\)]", " ", title, flags=re.I)
    title = re.sub(r"(?<![a-z0-9])(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264)(?![a-z0-9])", " ", title, flags=re.I)
    title = re.sub(r"\s+", " ", re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", title)).strip()
    year = str(row.get("year") or row.get("release_date") or row.get("releaseDate") or row.get("first_air_date") or "").strip()
    m = re.search(r"(?:19|20)\d{2}", year)
    year = m.group(0) if m else ""
    if title:
        return "title:%s:%s:%s" % (str(kind or ""), title, year)
    provider_id = str(row.get("series_id") or row.get("stream_id") or row.get("vod_id") or row.get("id") or "").strip()
    return "id:%s:%s" % (str(kind or ""), provider_id) if provider_id else ""


def _screen_dedupe_content(items, kind=""):
    out, seen = [], set()
    for item in list(items or []):
        key = _screen_content_dedupe_key(item, kind)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        out.append(item)
    return out



# Featured Backdrops use the currently enabled server categories without
# provider, language, country, year or genre whitelists. Online country lookup
# below is decorative only and is not used to exclude catalogue content.


def _featured_country_details(tmdb_id, kind):
    """A small disk-cached country lookup; never block Enigma's GUI thread."""
    try:
        tmdb_id = str(int(str(tmdb_id or "0")))
        media = "movie" if kind == "vod" else "tv"
        folder = get_cache_dir("metadata")
        path = os.path.join(folder, "featured_country_v1_%s_%s.json" % (media, tmdb_id)) if folder else ""
        if path and os.path.isfile(path):
            try:
                with open(path, "r") as handle:
                    cached = json.load(handle) or {}
                if time.time() - float(cached.get("ts") or 0) < 30 * 86400:
                    return str(cached.get("country") or ""), str(cached.get("backdrop") or "")
            except Exception:
                pass
        tmdb = TMDbClient(language="en-US")
        if not tmdb.configured():
            return "", ""
        details = tmdb._get("/%s/%s" % (media, tmdb_id), {"language": "en-US"}) or {}
        if not isinstance(details, dict):
            return "", ""
        countries = (details.get("origin_country") if media == "tv" else
                     details.get("production_countries")) or []
        first = countries[0] if isinstance(countries, (list, tuple)) and countries else ""
        if isinstance(first, dict):
            first = first.get("iso_3166_1") or ""
        code = str(first or "").upper().strip()
        if not re.match(r"^[A-Z]{2}$", code):
            code = ""
        backdrop = str(details.get("backdrop_path") or "")
        if path:
            try:
                with open(path + ".tmp", "w") as handle:
                    json.dump({"ts": time.time(), "country": code,
                               "backdrop": backdrop}, handle)
                os.replace(path + ".tmp", path)
            except Exception:
                pass
        return code, backdrop
    except Exception:
        return "", ""


# WWE/UFC/pro-wrestling belong in their original packages, not in the 12
# featured Backdrop tiles on Movies and TV Shows.  Check actual item titles as
# well as provider category metadata: a generic "Latest" package can contain
# wrestling broadcasts.  Never examine plot descriptions (a real movie can
# merely mention wrestling).  This is intentionally limited to the featured
# rail, not normal packages, GENRE, Search, favourites or playback.
_FEATURED_BACKDROP_WRESTLING_RE = re.compile(
    r"(?<!\w)(?:"
    r"w[\W_]*w[\W_]*e|u[\W_]*f[\W_]*c|a[\W_]*e[\W_]*w|"
    r"nxt|wrestl(?:e|ing|er|ers|emania)|wrestle[\s_.-]*mania|"
    r"smack[\s_.-]*down|monday[\s_.-]*night[\s_.-]*raw|"
    r"friday[\s_.-]*night[\s_.-]*smackdown|"
    r"tna[\s_.-]*impact|mma|mixed[\s_.-]*martial[\s_.-]*arts|"
    r"مصارعة|المصارعة|مصارعين|مصارع|راسل[\s_-]*مانيا|راسلمينيا|"
    r"سماك[\s_-]*داون|دبليو[\s_-]*دبليو[\s_-]*(?:اي|إي)|"
    r"يو[\s_-]*[اإ]ف[\s_-]*سي|قتال[\s_-]*مختلط|"
    r"فنون[\s_-]*قتالية[\s_-]*مختلطة"
    r")(?!\w)", re.IGNORECASE
)


def _featured_backdrop_wrestling_blocked(row, package_name=""):
    """Exclude WWE/UFC/wrestling from the 12-tile Movies/TV Shows rail only.

    Evaluate cached and uncached rows identically, including metadata nested
    under info.  Avoid content descriptions and numeric category IDs.
    """
    if not isinstance(row, dict):
        return True
    values = [str(package_name or "")]
    fields = (
        "name", "title", "original_name", "original_title", "series_name",
        "_display_title", "category_name", "_source_category_name",
        "group", "group-title", "genre", "genres", "subcategory", "tags",
        "keywords", "stream_display_name"
    )
    for metadata in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
        for field in fields:
            val = metadata.get(field)
            if isinstance(val, (tuple, list)):
                val = " ".join(str(v.get("name") or v.get("title") or "")
                               if isinstance(v, dict) else str(v) for v in val[:20])
            elif isinstance(val, dict):
                val = str(val.get("name") or val.get("title") or "")
            if val:
                values.append(str(val)[:240])
    return bool(_FEATURED_BACKDROP_WRESTLING_RE.search(" ".join(values)))


# Only the featured MOVIES backdrop rail uses these exclusions.  The series
# rail, provider catalogue, Genre, normal packages and user filters are intact.
_FEATURED_NONMOVIE_CATEGORY_RE = re.compile(
    r"(?<!\w)(?:"
    r"xxx|adult|porn|porno|18\+|18\s*plus|"
    r"ufc|wwe|aew|nxt|tna|mma|efc|boxing|wrestling|wrestle|wrestlemania|smackdown|combat|fighting|"
    r"sports?|football|soccer|matches|match|ppv|events?|"
    r"programs?|programmes?|reality|talk[\s_-]*shows?|game[\s_-]*shows?|quiz[\s_-]*shows?|variety[\s_-]*shows?|"
    r"tv[\s_-]*shows?|series|seasons?|episodes?|"
    r"documentar(?:y|ies)|docuseries|docu[\s_-]*series|"
    r"anime|animes|animation|animated|cartoons?|kids|children|child|"
    r"music|concerts?|karaoke|clips?|trailers?|"
    r"theat(?:re|er)|stage|news|interviews?|live[\s_-]*tv|"
    r"اباحي|إباحي|اباحية|إباحية|للكبار|بالغين|"
    r"رياضة|رياضي|رياضية|مباريات|مباراة|مصارعة|ملاكمة|قتال|"
    r"برامج|برنامج|وثائقي|وثائقية|وثائقيات|"
    r"مسلسل|مسلسلات|موسم|مواسم|حلقة|حلقات|"
    r"انمي|أنمي|كرتون|كرتوني|كرتونية|رسوم[\s_-]*متحركة|"
    r"أطفال|اطفال|موسيقى|اغاني|أغاني|حفلات|حفلة|"
    r"اخبار|أخبار|مقابلات|مسرح|مسرحية|مسرحيات"
    r")(?!\w)", re.IGNORECASE
)
_FEATURED_EXPLICIT_NONMOVIE_TITLE_RE = re.compile(
    r"(?<!\w)(?:"
    r"xxx|porn|porno|ufc|wwe|aew|nxt|wrestlemania|smackdown|mma|ppv|"
    r"documentary|docuseries|cartoon|anime|"
    r"episode[\s_-]*\d+|season[\s_-]*\d+|s\d{1,2}e\d{1,3}|"
    r"tv[\s_-]*shows?|"
    r"مصارعة|مباريات|اباحي|إباحي|وثائقي|وثائقية|"
    r"حلقات|حلقة[\s_-]*\d+|موسم[\s_-]*\d+"
    r")(?!\w)", re.IGNORECASE
)


def _featured_movie_allowed(raw, package_name=""):
    """Reject clear non-movies on Movies featured rail, without guessing country/year.

    Do not screen plot/description: real movies can be *about* music, sports,
    TV presenters etc.  Country, language, year and provider are unrestricted.
    """
    if not isinstance(raw, dict):
        return False
    declared = [str(raw.get(k) or "").strip().lower() for k in (
        "media_type", "content_type", "stream_type"
    )]
    if any(v in ("series", "tv", "tvshow", "tv_show", "episode", "live", "channel", "radio", "program", "programme")
           for v in declared):
        return False
    if raw.get("is_episode") is True or raw.get("is_live") is True:
        return False

    fragments = [str(package_name or ""), str(raw.get("category_name") or "")]
    for key in ("genre", "genres", "group", "group-title"):
        value = raw.get(key)
        if isinstance(value, (list, tuple)):
            value = " ".join(str(v.get("name") or "") if isinstance(v, dict) else str(v) for v in value)
        elif isinstance(value, dict):
            value = str(value.get("name") or "")
        fragments.append(str(value or ""))
    if _FEATURED_NONMOVIE_CATEGORY_RE.search(" ".join(fragments)):
        return False

    title = str(raw.get("name") or raw.get("title") or "")
    if _FEATURED_EXPLICIT_NONMOVIE_TITLE_RE.search(title):
        return False
    # Program labels at the beginning identify a show; film titles such as
    # "The Program" are not excluded solely because they contain that word.
    if re.match(r"^\s*(?:programs?|programmes?|برنامج|برامج)\b", title, re.IGNORECASE):
        return False
    return True



# Scripted TV series only in the featured TV Shows BACKDROP rail.
# Do not use descriptions/plots as blockers: a genuine drama may discuss
# sports, reality television, a concert or documentary filmmaking.
_FEATURED_NONDRAMA_SERIES_CATEGORY_RE = re.compile(
    r"(?<!\w)(?:"
    r"xxx|adult|porn|porno|18\+|18[\s_-]*plus|"
    r"wwe|ufc|aew|nxt|mma|boxing|wrestling|wrestlemania|smackdown|"
    r"fight[\s_-]*night|combat[\s_-]*sports?|sports?|football|soccer|"
    r"matches|match|ppv|events?|"
    r"reality(?:[\s_-]*tv|[\s_-]*shows?)?|unscripted|"
    r"talk(?:[\s_-]*shows?)?|chat[\s_-]*shows?|variety[\s_-]*shows?|"
    r"game[\s_-]*shows?|quiz[\s_-]*shows?|"
    r"programs?|programmes?|"
    r"documentar(?:y|ies)|docuseries|docu[\s_-]*series|"
    r"news|interviews?|current[\s_-]*affairs|"
    r"live[\s_-]*tv|live[\s_-]*channels?|"
    r"anime|animation|animated|cartoons?|kids|children|child|"
    r"music|concerts?|karaoke|"
    r"رياضة|رياضي|رياضية|مباريات|مباراة|مصارعة|ملاكمة|قتال|"
    r"برامج|برنامج|برنامج[\s_-]*واقعي|تلفزيون[\s_-]*الواقع|واقع|"
    r"وثائقي|وثائقية|وثائقيات|اخبار|أخبار|حواري|حوارات|مقابلات|"
    r"انمي|أنمي|كرتون|كرتوني|كرتونية|رسوم[\s_-]*متحركة|"
    r"أطفال|اطفال|موسيقى|اغاني|أغاني|حفلات|حفلة|"
    r"اباحي|إباحي|اباحية|إباحية|للكبار|بالغين"
    r")(?!\w)", re.IGNORECASE
)
_FEATURED_NONDRAMA_SERIES_TITLE_RE = re.compile(
    r"(?<!\w)(?:"
    r"wwe|ufc|aew|wrestlemania|smackdown|"
    r"(?:wwe[\s_-]*)?nxt|monday[\s_-]*night[\s_-]*raw|"
    r"friday[\s_-]*night[\s_-]*smackdown|"
    r"(?:all[\s_-]*elite[\s_-]*)?wrestling|"
    r"(?:tna[\s_-]*)?impact[\s_-]*wrestling|"
    r"mma|boxing[\s_-]*night|fight[\s_-]*night|"
    r"ppv|porn|xxx|"
    r"documentary|docuseries|talk[\s_-]*show|"
    r"reality[\s_-]*show|cartoon|anime|"
    r"برامج|برنامج|مصارعة|مباريات|وثائقي|وثائقية|كرتون|أنمي|انمي"
    r")(?!\w)", re.IGNORECASE
)


def _featured_series_allowed(raw, package_name=""):
    """Allow a provider's actual TV series, not wrestling, reality or programmes.

    Does not change series packages, playable catalogue or other screens.
    Check explicit metadata and category/title only, never arbitrary plot text.
    """
    if not isinstance(raw, dict):
        return False
    if raw.get("is_live") is True or raw.get("is_episode") is True:
        return False
    declared = [str(raw.get(k) or "").strip().lower() for k in
                ("media_type", "content_type", "stream_type")]
    if any(v in ("live", "channel", "radio", "movie", "vod", "film", "episode",
                 "program", "programme", "reality", "documentary", "sports", "sport")
           for v in declared):
        return False
    info = raw.get("info") if isinstance(raw.get("info"), dict) else {}
    fragments = [str(package_name or ""), str(raw.get("category_name") or "")]
    # The provider may store the classification in a nested info dictionary.
    # TV Shows / Series are generic container names and stay permitted.
    for data in (raw, info):
        for key in ("genre", "genres", "group", "group-title", "category", "subcategory"):
            val = data.get(key)
            if isinstance(val, (tuple, list)):
                val = " ".join(str(x.get("name") or "") if isinstance(x, dict) else str(x)
                               for x in val)
            elif isinstance(val, dict):
                val = str(val.get("name") or "")
            fragments.append(str(val or ""))
    if _FEATURED_NONDRAMA_SERIES_CATEGORY_RE.search(" ".join(fragments)):
        return False
    title = str(raw.get("name") or raw.get("title") or "")
    if _FEATURED_NONDRAMA_SERIES_TITLE_RE.search(title):
        return False
    # A standalone wrestling broadcast may be simply called RAW / Dynamite.
    if re.match(r"^\s*(?:raw|dynamite|wrestling|wrestlemania)\s*(?:\(\d{4}\))?\s*$",
                title, re.IGNORECASE):
        return False
    return True


def _balanced_featured_select(package_pools, target_count, preferred_cids=()):
    """Choose one item from each enabled package per pass, preferred first.

    A package can provide more than one backdrop only after other eligible
    packages have had a chance. With fewer available packages, later passes
    naturally fill the remaining cards. No release-year bias.
    """
    preferred_cids = set(str(x) for x in (preferred_cids or ()))
    pools = {}
    for cid, items in (package_pools or {}).items():
        if items:
            copy = list(items)
            random.shuffle(copy)
            pools[str(cid)] = copy
    priority = [cid for cid in pools if cid in preferred_cids]
    rest = [cid for cid in pools if cid not in preferred_cids]
    random.shuffle(priority)
    random.shuffle(rest)
    ordered = priority + rest
    result = []
    seen = set()
    while len(result) < target_count and any(pools.values()):
        advanced = False
        for cid in ordered:
            items = pools[cid]
            while items:
                item = items.pop()
                # Backdrop items have provider IDs or normalized display titles.
                key = str(item.get("_display_title") or item.get("name") or
                          item.get("title") or "").strip().lower()
                if key and key in seen:
                    continue
                if key:
                    seen.add(key)
                result.append(item)
                advanced = True
                break
            if len(result) >= target_count:
                break
        if not advanced:
            break
    return result


# ---------------------------------------------------------------------------
# Content home screen
# ---------------------------------------------------------------------------

def _restore_backdrop_cursor(previous, current, start, index):
    """Keep the selected package when a refreshed backdrop rail is painted.

    The absolute card is mapped back to a page and in-page index, so a
    background refresh cannot unexpectedly jump the user to card #1.
    """
    if not current or not previous:
        return (0, 0)
    old_absolute = max(0, int(start or 0) + int(index or 0))
    old_absolute = min(len(previous) - 1, old_absolute)
    old = previous[old_absolute] or {}

    def identity(row):
        row = row if isinstance(row, dict) else {}
        category = str(row.get("_source_category_id") or row.get("category_id") or "")
        item_id = str(row.get("stream_id") or row.get("series_id") or
                      row.get("id") or row.get("tmdb_id") or "")
        title = str(row.get("name") or row.get("title") or "").strip().casefold()
        return (category, item_id, title)

    old_identity = identity(old)
    new_absolute = min(old_absolute, len(current) - 1)
    if any(old_identity):
        for idx, candidate in enumerate(current):
            if identity(candidate) == old_identity:
                new_absolute = idx
                break
    return ((new_absolute // 4) * 4, new_absolute % 4)


class ContentHomeScreen(Screen):
    _tivimateLogoAlign = 'center'  # movies/series hero logo sits in the middle
    # Independent fixed limits: top backdrop row is always 12,
    # while Backdrop poster content remains 50.
    BACKDROP_ITEM_LIMIT = 12
    POSTER_ITEM_LIMIT = 50

    skin = CONTENT_HOME

    TOP = ["Home", "Search", "Live", "Movies", "TV Shows", "Packages", "GENRE", "Resume", "Server Finder", "Settings", "Favorites"]
    TOP_X = [20, 190, 360, 530, 700, 870, 1040, 1210, 1380, 1550, 1720]
    TOP_W = [170] * 11
    BACKDROP_X = [80, 535, 990, 1445]
    LATEST_X = [80, 295, 510, 725, 940, 1155, 1370, 1585]

    def _title_score(self, wanted, candidate):
        """Strict normalized title score used by Backdrop server matching."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens = set(wanted.split())
        candidate_tokens = set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0

        # Safe containment only when nearly the whole meaningful title matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94

        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0



    def _speedLayoutDone(self):
        # Bound method on purpose: OpenATV exec()s non-method onLayoutFinish
        # entries (a lambda crashed with "exec() arg 1 must be a string").
        try:
            from .speed_log import log as _speed_log
            _speed_log("PAGE", getattr(self, "_speedLabel", ""),
                       __import__("time").time() - float(getattr(self, "_speedT0", 0) or 0))
        except Exception:
            pass

    def __init__(self, session, source, kind, initialMode=None, actorRows=None, actorName=""):
        _speed_t0 = time.time()
        Screen.__init__(self, session)
        self._speedT0 = _speed_t0
        self._speedLabel = "ContentHome %s" % kind
        self.onLayoutFinish.append(self._speedLayoutDone)
        self._pageOpenBusy = False
        self.source, self.kind = source, kind
        self._actorRows = list(actorRows or [])
        self._actorName = str(actorName or "").strip()
        self._actorMode = bool(self._actorRows and self._actorName)
        self.contentGeneration = 0
        self.contentMode = _content_default_mode(kind)

        # Recent has its own request generation and stable last-good result.
        # An old/empty response is never allowed to erase a newer visible row.
        self.recentRequestToken = 0
        self.recentStable = []
        # Focus Packages at initial entry; the user must explicitly navigate
        # into the Backdrops rail before its optional YouTube preview can start.
        # Actor-scoped results still begin in their poster row below.
        self.focus = "top"
        self.topIndex = 5 if getattr(self, "_preferPackageInitialFocus", False) and not self._actorMode else (3 if kind == "vod" else 4)
        self.backdrops, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        # Fast package switching: build category indexes once, then every
        # red/blue package change is RAM-only with no timer/network wait.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        # Complete package responses loaded in this screen only.
        # Key = exact provider category_id, value = full provider response.
        self._fullPackageRows = OrderedDict()
        self._fullPackageLock = threading.RLock()
        # Only two recent, successful first-package results are retained during
        # this screen lifetime. Re-entering the other content kind must not
        # refetch/sort the same catalogue on every remote-control press.
        self._landingSnapshots = {}
        self._usingLandingSnapshot = False
        self._contentScreenDisposed = False
        self._categorySwitchPreviewNow = False
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        self.categoryLoadToken = 0
        # Stalker category requests run in a worker.  Do not rely on Twisted
        # being integrated with Enigma2: the eTimer below is the only route that
        # applies a finished red/blue category request to the GUI thread.
        self.stalkerCategoryLoadResult = None
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadTimer = eTimer()
        try:
            self._stalkerCategoryLoadTimer_conn = self.stalkerCategoryLoadTimer.timeout.connect(self._finishStalkerCategoryLoad)
        except Exception:
            try:
                self.stalkerCategoryLoadTimer.callback.append(self._finishStalkerCategoryLoad)
            except Exception:
                self.stalkerCategoryLoadTimer.timeout.get().append(self._finishStalkerCategoryLoad)
        self.sortMode = "default"
        self.backdropStart = self.backdropIndex = self.latestStart = self.latestIndex = 0
        self.downloads, self.picloads = [], []
        self._image_requests = {}
        # Short-lived, per-screen selected artwork cache. Keep only successful
        # decoded Hero/clearlogo pointers, never provider lists or new files.
        # These pointers are owned by Enigma2 and released on screen close.
        self._previewPixmapCache = OrderedDict()
        self._previewPixmapBytes = 0
        self._previewMetadataCache = OrderedDict()
        self._previewMetadataLock = threading.RLock()
        # One main-thread dispatcher is used for every worker result on Movies
        # and TV Shows.  Network/poster work stays in the background exactly as
        # before; only the final widget update is serialized on Enigma2's GUI
        # thread.  This prevents red/blue/yellow/navigation restarts on images
        # where Twisted exists but is not integrated with the Enigma2 mainloop.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        # VOD list rows frequently contain only poster art.  Delay the richer
        # backdrop lookup briefly so rapid navigation never starts one network
        # request per key press, then discard every stale result by token.
        self._previewRequestId = 0
        self._previewBackdropPending = None
        # Movies metadata uses the same cache-first path as TV Shows.
        # Visible movie cards are warmed quietly so hero/details navigation does
        # not wait for a fresh TMDb search on every key press.
        self._metadataWarmKeys = set()
        self._previewBackdropTimer = eTimer()
        try:
            self._previewBackdropTimer_conn = self._previewBackdropTimer.timeout.connect(self._beginPreviewBackdropLookup)
        except Exception:
            try:
                self._previewBackdropTimer.callback.append(self._beginPreviewBackdropLookup)
            except Exception:
                self._previewBackdropTimer.timeout.get().append(self._beginPreviewBackdropLookup)
        # Cold /tmp category-cache misses must not be mistaken for a user
        # disabling every package. Retry quietly after the provider cooldown,
        # without changing filters or starting extra artwork workers.
        self._coldCategoryRetryAttempts = 0
        self._coldCategoryRetryGeneration = self.contentGeneration
        self._coldCategoryRetryTimer = eTimer()
        try:
            self._coldCategoryRetryConn = self._coldCategoryRetryTimer.timeout.connect(
                self._retryColdCategories)
        except Exception:
            try:
                self._coldCategoryRetryTimer.callback.append(self._retryColdCategories)
            except Exception:
                self._coldCategoryRetryTimer.timeout.get().append(self._retryColdCategories)
        # Backdrop cards paint in provider order first. A delayed reorder uses
        # the timestamps already attached to the rows and never downloads art
        # again, so the first paint is fast while the final rail is newest-first.
        self._backdropNewestSortTimer = eTimer()
        try:
            self._backdropNewestSortTimer_conn = self._backdropNewestSortTimer.timeout.connect(self._applyDelayedBackdropNewestOrder)
        except Exception:
            try:
                self._backdropNewestSortTimer.callback.append(self._applyDelayedBackdropNewestOrder)
            except Exception:
                self._backdropNewestSortTimer.timeout.get().append(self._applyDelayedBackdropNewestOrder)
        for i, text in enumerate(self.TOP): self["top%d" % i] = Label(nav_label(text))
        self["topSelector"] = Pixmap()
        self["hero"] = Pixmap(); self["logoImage"] = Pixmap(); self["promoBanner"] = Pixmap(); self["promoFrame"] = Pixmap(); self["logoHintIcon"] = Pixmap(); self["logoHint"] = Label("LOGO"); self["logoTitle"] = DirectionalLabel(""); self["heroMeta"] = CenteredArabicMetadataLabel(""); self["heroDesc"] = SynopsisLabel("")
        from .resolution_badge import install_information_badge
        install_information_badge(self, "heroMeta", position=(330, 226), badges_only=True)
        self["heroPlay"] = Label("▶  " + tr("Play")); self["heroInfo"] = Label("ⓘ  " + tr("More Info"))
        self["promoBanner"].hide()
        self["promoFrame"].hide()
        self["logoImage"].hide()
        self["logoHintIcon"].hide()
        self["logoHint"].hide()
        # Fixed top hero/backdrop title. Setting #6 only changes the lower row.
        primary_title = "Movies You Might Like" if kind == "vod" else "TV Shows You Might Like"
        self["backdropTitle"] = DirectionalLabel((self._actorName + (" - TV SHOWS" if kind == "series" else " - MOVIES")) if self._actorMode else tr(primary_title))
        self["latestTitle"] = DirectionalLabel(tr("TV Shows" if kind == "series" else "Movies") if self._actorMode else tr(_content_mode_title(kind, self.contentMode)))
        self["latestCategoryName"] = DirectionalLabel("")
        for i in range(4):
            self["backdrop%d" % i] = Pixmap(); self["rank%d" % i] = Label("")
            self["backdropLabel%d" % i] = Label(""); self["backdropRate%d" % i] = Label("")
            self["backdropFlag%d" % i] = Pixmap()
            try:
                self["backdropFlag%d" % i].hide()
            except Exception:
                pass
        for i in range(8):
            self["latest%d" % i] = Pixmap()
            self["latestShell%d" % i] = Pixmap()
            self["latestBadge%d" % i] = Pixmap()
            self["latestLabel%d" % i] = Label(""); self["latestRate%d" % i] = Label("")
        self["backdropSelector"] = Pixmap(); self["latestSelector"] = Pixmap()
        self["footer"] = Label(""); self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "red": self.previousCategory, "green": self.serverList, "yellow": self.toggleSort,
            "yellowlong": self.addCurrentFavourite, "greenlong": self.openPosterServerFilter, "blue": self.nextCategory
        }, -1)
        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkResources)
        self.onClose.append(self._stopStalkerCategoryLoadTimer)
        self.onClose.append(self._stopBackdropNewestSortTimer)
        self.onClose.append(self._stopColdCategoryRetry)


    def _stopColdCategoryRetry(self):
        try:
            self._coldCategoryRetryTimer.stop()
        except Exception:
            pass

    def _retryColdCategories(self):
        # Called only by an Enigma2 GUI eTimer. Network work stays off the GUI.
        if (getattr(self, "_contentScreenDisposed", True) or
                getattr(self, "_coldCategoryRetryGeneration", -1) != self.contentGeneration):
            return
        generation = self.contentGeneration
        worker = threading.Thread(target=self._loadServer, args=(generation,),
                                  name="TiviMateColdPackagesRetry")
        worker.daemon = True
        worker.start()

    def _coldCategoriesUnavailable(self, generation, origin):
        """Treat absent provider metadata as temporary, NOT an empty filter.

        filters.get_cached_categories returns 'loading', 'retry_later', 'empty'
        or 'error' during cold-cache recovery; 'retry_later' also uses a 30s
        network throttle. This method is GUI-only, with two bounded attempts.
        """
        if (self._contentScreenDisposed or generation != self.contentGeneration or
                getattr(self, "_actorMode", False)):
            return
        if self._coldCategoryRetryGeneration != generation:
            self._coldCategoryRetryGeneration = generation
            self._coldCategoryRetryAttempts = 0
        if not self.categoriesLoaded and not self.latest:
            self["heroDesc"].setText("Loading movie packages from the server..." if
                                     self.kind == "vod" else
                                     "Loading TV show packages from the server...")
        if self._coldCategoryRetryAttempts >= 2:
            if not self.categoriesLoaded and not self.latest:
                self["heroDesc"].setText(
                    "Package list temporarily unavailable. Please reopen this page to retry.")
            return
        self._coldCategoryRetryAttempts += 1
        # The category reader throttles empty/error replies for 30 seconds;
        # a premature attempt returns retry_later without contacting provider.
        delay_ms = 3000 if origin == "loading" else 32000
        self._coldCategoryRetryTimer.start(delay_ms, True)

    def _coldCategoriesReady(self, generation):
        if self._contentScreenDisposed or generation != self.contentGeneration:
            return
        self._stopColdCategoryRetry()
        self._coldCategoryRetryGeneration = generation
        self._coldCategoryRetryAttempts = 0

    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(120, True)
        except Exception:
            pass

    def _stopBackdropNewestSortTimer(self):
        try:
            self._backdropNewestSortTimer.stop()
        except Exception:
            pass

    def _scheduleBackdropNewestOrder(self, generation=None):
        """Start the one-shot newest-order pass after the fast first paint."""
        try:
            self._backdropNewestSortGeneration = (self.contentGeneration
                                                  if generation is None else generation)
            self._backdropNewestSortTimer.stop()
            self._backdropNewestSortTimer.start(10000, True)
        except Exception:
            pass

    def _applyDelayedBackdropNewestOrder(self):
        """Reorder loaded Backdrop rows only; never start another download."""
        if (getattr(self, "_contentScreenDisposed", False) or
                getattr(self, "_backdropNewestSortGeneration", self.contentGeneration) != self.contentGeneration):
            return
        rows = list(getattr(self, "backdrops", []) or [])
        if len(rows) < 2:
            return
        def stamp(row):
            try:
                return int(row.get("_genre_latest_package_stamp") or 0)
            except (AttributeError, TypeError, ValueError, OverflowError):
                return 0
        def item_stamp(row):
            try:
                return int(row.get("_genre_item_stamp") or 0)
            except (AttributeError, TypeError, ValueError, OverflowError):
                return 0
        # Series must put the genuinely most recently added/updated shows
        # first, not an older show merely because its package is ranked high.
        # Films keep the original package-first order unchanged.
        if self.kind == "series" and any(item_stamp(row) > 0 for row in rows):
            ordered = sorted(enumerate(rows),
                             key=lambda pair: (-item_stamp(pair[1]), -stamp(pair[1]), pair[0]))
        else:
            ordered = sorted(enumerate(rows),
                             key=lambda pair: (-stamp(pair[1]), -item_stamp(pair[1]), pair[0]))
        reordered = [row for _index, row in ordered]
        if [id(row) for row in reordered] == [id(row) for row in rows]:
            return
        previous = rows
        previous_start = getattr(self, "backdropStart", 0)
        previous_index = getattr(self, "backdropIndex", 0)
        self.backdrops = reordered
        try:
            self.backdropStart, self.backdropIndex = _restore_backdrop_cursor(
                previous, reordered, previous_start, previous_index)
            self.renderBackdrops()
            self.updateFocus()
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(120, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except RuntimeError:
                pass

    def _applyArabicHeadingLayout(self):
        if get_language() != "ar":
            return
        try:
            for name, y in (("trendingTitle", 500), ("latestTitle", 772)):
                widget = self[name]
                if widget and widget.instance:
                    widget.instance.move(ePoint(sx(1110), sy(y)))
                    widget.instance.resize(eSize(sx(730), sy(45)))
                    try:
                        widget.instance.setHAlign(2)
                    except Exception:
                        pass
        except Exception:
            pass

    def _setMovieLogoGeometry(self):
        """Scale only film clearlogos; restore original TV Shows geometry."""
        try:
            logo = self["logoImage"].instance
            if logo is None:
                return
            # Movies and TV Shows share the large, left-aligned hero clearlogo.
            # Keep its bottom above the metadata row (y=226) and its right edge
            # away from the trailer area on the right.
            x, y, w, h = (330, 112, 600, 104)   # normal size, centred above the synopsis
            logo.move(ePoint(sx(x), sy(y)))
            logo.resize(eSize(sx(w), sy(h)))
        except Exception:
            pass

    def _layoutReady(self):
        self._applyArabicHeadingLayout()
        self._positionLatestCategoryName()
        self._setMovieLogoGeometry()
        self._startGuiDispatch()
        self.start()

    def _rememberPackageRows(self, category_id, rows):
        """Keep at most two modest-size package lists in page RAM.

        Larger lists are already in the disk-backed category cache and are
        still displayed normally.  No package, source or saved data is removed.
        """
        cid = str(category_id or "")
        if not cid or self._contentScreenDisposed:
            return
        with self._fullPackageLock:
            if self._contentScreenDisposed:
                return
            if cid in self._fullPackageRows:
                self._fullPackageRows.pop(cid, None)
            if not rows or len(rows) > 5000:
                return
            self._fullPackageRows[cid] = rows if isinstance(rows, list) else list(rows)
            while len(self._fullPackageRows) > 2:
                self._fullPackageRows.popitem(last=False)

    def _landingFilterSignature(self, kind):
        """Bind the short-lived landing cache to this exact enabled package set."""
        try:
            allowed = get_allowed_category_ids(self.source, kind)
        except Exception:
            return None
        if allowed is None:
            return (kind, "all")
        return (kind, tuple(sorted(str(cid) for cid in allowed if str(cid))))

    def _rememberLandingSnapshot(self, latest, allItems, categories, landingCategory):
        """Hold only bounded, already-loaded provider rows; no new disk cache.

        Large provider catalogues stay in the existing category cache, not in
        another screen-owned RAM copy. Recent Added always refreshes through
        its dedicated cache/worker and is intentionally excluded.
        """
        if (self._contentScreenDisposed or self.kind not in ("vod", "series") or
                self.contentMode == "recent" or not categories or not landingCategory):
            return
        rows = allItems if allItems is not None else latest
        if (not isinstance(rows, (list, tuple)) or len(rows) > 3000 or
                len(categories) > 800):
            return
        signature = self._landingFilterSignature(self.kind)
        if signature is None:
            return
        # These are existing references, not copies of thousands of movie dicts.
        self._landingSnapshots[self.kind] = (
            time.monotonic(), signature,
            (latest, rows, categories, landingCategory)
        )

    def _recentLandingSnapshot(self, kind):
        if self._contentScreenDisposed or _content_default_mode(kind) == "recent":
            return None
        entry = self._landingSnapshots.get(kind)
        if not entry:
            return None
        created, signature, payload = entry
        if (time.monotonic() - created > 90 or
                signature != self._landingFilterSignature(kind)):
            self._landingSnapshots.pop(kind, None)
            return None
        return payload

    def _releaseArtworkResources(self):
        # Invalidate callbacks/workers before dropping long provider lists.
        self._contentScreenDisposed = True
        self.contentGeneration += 1
        self.categoryLoadToken += 1
        self._previewRequestId += 1
        try:
            self._previewBackdropTimer.stop()
        except Exception:
            pass
        self._image_requests = {}
        self._previewPixmapCache.clear()
        self._previewPixmapBytes = 0
        with self._previewMetadataLock:
            self._previewMetadataCache.clear()
        self._backdropMetadataToken = None
        self._backdrop_fallback_tokens = {}
        self._sameMovieBackdropRetries = {}
        self._cardFlagKeys = {}
        self.downloads = []
        self.picloads = []
        self._previewBackdropPending = None
        self._metadataWarmKeys.clear()
        self._landingSnapshots.clear()
        if getattr(self, "_fastMoviesPerformance", False):
            self._fastRenderedArtwork.clear()
            self._fastBackdropSlots.clear()
            self._fastPosterSlots.clear()
        with self._fullPackageLock:
            self._fullPackageRows.clear()
        self._categoryRowsIndex.clear()
        self._categorySortedIndex.clear()
        self.serverItems = []
        self.categoryItems = []
        self.categoriesList = []
        self.backdrops = []
        self.latest = []
        self.recentStable = []

    def _previewCacheKey(self, item):
        # Object identity is deliberately screen-local: a different server,
        # category or Movie/Series switch can never reuse a stale pixmap.
        if not isinstance(item, dict):
            return None
        # Include row identity as well as Python object identity: refreshed
        # catalogues may release row objects and reuse their numerical id().
        return (self.kind, id(item),
                str(item.get('stream_id') or item.get('series_id') or item.get('id') or ''),
                str(item.get('name') or item.get('title') or ''),
                str(item.get('year') or item.get('release_date') or ''))

    def _keepPreviewPixmap(self, widget, item, pixmap, url):
        if widget not in ('hero', 'logoImage') or pixmap is None:
            return
        key = self._previewCacheKey(item)
        if key is None:
            return
        cache = self._previewPixmapCache
        slot = (key, widget)
        # 1920x1080 hero is approximately 8MiB; logos are much smaller.
        # Never allow eight large entries to consume unbounded box memory.
        estimate = 1920 * 1080 * 4 if widget == 'hero' else 680 * 106 * 4
        previous = cache.pop(slot, None)
        if previous:
            self._previewPixmapBytes -= previous[2]
        cache[slot] = (pixmap, url, estimate)
        self._previewPixmapBytes += estimate
        # At most eight decoded images of either kind, never an unbounded LRU.
        same_kind = [name for name in cache if name[1] == widget]
        if len(same_kind) > 8:
            oldest_kind = same_kind[0]
            removed = cache.pop(oldest_kind)
            self._previewPixmapBytes -= removed[2]
        while len(cache) > 16 or self._previewPixmapBytes > 72 * 1024 * 1024:
            _, oldest = cache.popitem(last=False)
            self._previewPixmapBytes -= oldest[2]

    def _restorePreviewPixmap(self, widget, item):
        key = self._previewCacheKey(item)
        if key is None:
            return False
        slot = (key, widget)
        cache = self._previewPixmapCache
        entry = cache.get(slot)
        if not entry:
            return False
        pixmap, url, _size = entry
        try:
            target = self[widget]
            if not target.instance:
                return False
            target.instance.setPixmap(pixmap)
            target.show()
        except Exception:
            removed = cache.pop(slot, None)
            if removed:
                self._previewPixmapBytes = max(0, self._previewPixmapBytes - removed[2])
            return False
        cache.move_to_end(slot)
        self._image_requests[widget] = url
        identity = self._genreHeroIdentity(widget, item)
        if identity is not None:
            decoded = getattr(self, '_genreHeroDecoded', None)
            if decoded is None:
                decoded = {}
                self._genreHeroDecoded = decoded
            decoded[widget] = identity
        if getattr(self, '_fastMoviesPerformance', False):
            self._fastRenderedArtwork[widget] = url
        if widget == 'logoImage':
            try:
                self['logoTitle'].hide()
                self['logoHintIcon'].hide()
                self['logoHint'].hide()
            except Exception:
                pass
        return True

    def _getPreviewMetadata(self, item):
        key = self._previewCacheKey(item)
        if key is None:
            return None
        with self._previewMetadataLock:
            cached = self._previewMetadataCache.get(key)
            if not cached:
                return None
            timestamp, data = cached
            if time.monotonic() - timestamp > 900:
                self._previewMetadataCache.pop(key, None)
                return None
            self._previewMetadataCache.move_to_end(key)
            return data

    def _keepPreviewMetadata(self, item, data):
        key = self._previewCacheKey(item)
        if key is None or not isinstance(data, dict) or not data:
            return
        with self._previewMetadataLock:
            self._previewMetadataCache.pop(key, None)
            self._previewMetadataCache[key] = (time.monotonic(), data)
            while len(self._previewMetadataCache) > 40:
                self._previewMetadataCache.popitem(last=False)

    def _stopStalkerCategoryLoadTimer(self):
        # Invalidate workers before screen teardown, so a late portal reply
        # cannot attempt to repaint a screen that no longer exists.
        self.categoryLoadToken = getattr(self, "categoryLoadToken", 0) + 1
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadResult = None
        try:
            self.stalkerCategoryLoadTimer.stop()
        except Exception:
            pass

    def _restoreCachedBackdropRail(self):
        """Paint this source AND content kind's last-good featured rail.

        _loadBackdrops may return without emitting backdropsReady when the
        GENRE snapshot is fresh: both start() and _switchContentKind() must
        therefore paint that snapshot before launching the background worker.
        This method never makes a provider/TMDb request or changes focus.
        """
        if (not getattr(self, "_fastMoviesPerformance", False) or
                self.kind not in ("vod", "series") or
                getattr(self, "_contentScreenDisposed", False)):
            return False
        try:
            snapshot_mode = _package_backdrop_snapshot_mode(self.source, self.kind)
            snapshot = (_home_feed_cache_get(snapshot_mode, self.source, allow_stale=True)
                        if _genre_snapshot_matches_cache(snapshot_mode, self.source) else [])
            snapshot = [row for row in (snapshot or [])
                        if (not _cinematic_backdrop_temporarily_missing(self.source, self.kind, row)
                            and not _featured_backdrop_wrestling_blocked(row))]
            if snapshot:
                self.backdropsReady(snapshot[:self.BACKDROP_ITEM_LIMIT], self.contentGeneration, [])
                return True
        except Exception:
            pass
        return False

    def start(self):
        if self._actorMode:
            self.serverItems = list(self._actorRows)
            self.categoryItems = list(self._actorRows)
            self.latest = list(self._actorRows)
            self.backdrops = []
            self.latestStart = self.latestIndex = 0
            self.categoryName = self._actorName
            self.focus = "latest"
            self["latestCategoryName"].setText("")
            self["heroDesc"].setText("%d movies available on this server" % len(self.latest))
            self.renderBackdrops()
            self.renderLatest()
            self.updateFocus()
            self.preview()
            return
        # Recent opens from a dedicated last-good cache. Keep it visible while
        # the server refresh runs; never blank the row during a second request.
        if self.contentMode == "recent":
            cache_mode = "recent_%s" % self.kind
            cached_latest = _home_feed_cache_get(cache_mode, self.source, allow_stale=True)
            # The large Recent Added page uses a separate, stricter cache key
            # (provider credentials + enabled package filter). Reuse those
            # verified rows if the Movies/Series page's own 25-row cache is
            # empty. Do not reuse arbitrary first-package landing data.
            if not cached_latest:
                try:
                    from .ui import _recent_media_cache_state
                    cached_latest, _fresh = _recent_media_cache_state(self.source, self.kind)
                except Exception:
                    cached_latest = []
            # A generic first-package landing cache is not a Recent feed.
            # Only reuse this source/kind's validated last-good Recent rows.
            if cached_latest:
                self.recentStable = self._sortedItems(cached_latest)
                self.latest = _screen_dedupe_content(self.recentStable, self.kind)
                self.latestStart = self.latestIndex = 0
                self.categoryName = "RECENT ADDED"
                self._updateLatestTitle()
                self.renderLatest()
        # Reuse the exact same cached first-paint path on cold screen entry
        # and when switching Movies <-> TV Shows inside the existing screen.
        self._restoreCachedBackdropRail()
        self.updateFocus()
        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentHome"); t.daemon = True; t.start()

    def worker(self, generation=None, reuse_landing=False):
        if generation is None:
            generation = self.contentGeneration

        # Movies and TV Shows request their featured Backdrops immediately.
        # The server/package rail loads independently, without forcing the
        # first visible scene to the portrait posters while featured art loads.
        # Share the existing cache/network paths; do not add repeated polling.
        trend_thread = threading.Thread(target=self._loadBackdrops, args=(generation,), name="TiviMateBackdrops")
        trend_thread.daemon = True
        trend_thread.start()
        if not reuse_landing and generation == self.contentGeneration:
            self._loadServer(generation)
            # The first package may only have reached the RAM/disk cache after
            # the parallel backdrop pass. Recheck without stalling the GUI.
            if (generation == self.contentGeneration and
                    not self._contentScreenDisposed and
                    getattr(self, "_fastMoviesPerformance", False)):
                self._loadBackdrops(generation)

    def _loadServer(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        # A slow server can finish after several Movies/TV Shows switches.
        # Stop obsolete workers before they start another provider request.
        if generation != self.contentGeneration or self._contentScreenDisposed:
            return
        source = dict(self.source or {})
        kind = self.kind
        try:
            client = get_source_client(source)

            # FILTER IS AUTHORITATIVE.
            _package_diag("LOAD_SERVER_BEGIN", source=source.get("name") or source.get("url") or "", source_type=source.get("type") or "", kind=kind, mode=self.contentMode)
            raw_categories, _origin = get_cached_categories(
                source, kind, client=client, wait_for_server=True
            )
            if generation != self.contentGeneration or self._contentScreenDisposed:
                return
            filtered = filter_categories(source, kind, raw_categories or [])
            _package_diag("CATEGORIES", kind=kind, origin=_origin, raw_count=len(raw_categories or []), filtered_count=len(filtered or []))

            # Keep provider category rows untouched.  Only accept rows that have
            # a real provider id usable by the same endpoint as the big page.
            categories = []
            seen = set()
            for row in filtered:
                if not isinstance(row, dict):
                    continue
                cid = str(
                    row.get("category_id")
                    or row.get("id")
                    or row.get("genre_id")
                    or row.get("group_id")
                    or ""
                ).strip()
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                entry = dict(row)
                entry["category_id"] = cid
                if not entry.get("category_name"):
                    entry["category_name"] = (
                        entry.get("name")
                        or entry.get("title")
                        or entry.get("genre")
                        or "Other"
                    )
                categories.append(entry)
                _package_diag("CATEGORY_ENABLED", kind=kind, category_id=cid, category_name=entry.get("category_name") or "")

            _package_diag("CATEGORIES_READY", kind=kind, count=len(categories))
            if not categories:
                if not raw_categories:
                    # Cold /tmp cache can be empty while a provider request is
                    # still loading or in its retry cooldown. This does NOT
                    # mean that the user's saved package filter is empty.
                    _package_diag("CATEGORIES_TEMPORARY_MISS", kind=kind, origin=_origin)
                    self._queueGui(self._coldCategoriesUnavailable, generation,
                                   str(_origin or "loading"))
                    return
                # The provider did return a real catalogue but the saved
                # package filter excludes every category. Only this case is
                # evidence that no packages are enabled.
                raise RuntimeError("No enabled packages are available for this library.")
            self._queueGui(self._coldCategoriesReady, generation)

            # Recent Added remains its own setting/feed.  It does not modify the
            # normal package list or package navigation.
            if self.contentMode == "recent":
                # Recent Added is intentionally simple. Build the Recent
                # ordering, keep only the newest twenty-five rows, and resolve TMDb
                # metadata for those twenty-five only. No partial first-package paint,
                # no progressive 5+5 worker, and no metadata work for the rest.
                self.recentRequestToken += 1
                recent_token = self.recentRequestToken

                # Both the visible Recent Add page and the notification watcher
                # use this single enabled-package feed. Other package pages are
                # unaffected and Recent retains its latest-25 presentation.
                from .recent_feed import recent_added_items
                try:
                    recent = recent_added_items(source, kind, client, categories, 25)
                except Exception:
                    recent = []

                # Shared Recent fast-path for Movies + TV Shows:
                # Paint the newest 25 from provider rows immediately. Do not block
                # either Recent page on synchronous TMDb/details enrichment. Normal
                # lazy poster/details fallback remains available after the GUI paints.

                self._queueGui(
                    self.recentReady,
                    recent_token, recent, categories, generation, False
                )
                return

            # NORMAL PACKAGES:
            # Xtream: use the same provider-wide catalogue path that Recent uses.
            # Group that fresh catalogue back into the user's enabled packages,
            # then sort each package by the provider add/update timestamp. This
            # keeps package navigation unchanged while avoiding provider category
            # responses whose order may be stale or arbitrary.
            if generation != self.contentGeneration or self._contentScreenDisposed:
                return
            first = categories[0]
            first_id = str(first.get("category_id") or "")
            first_name = first.get("category_name") or "Other"
            first_items = []
            if kind in ("vod", "series") and source.get("type") == "xtream":
                # Fast package landing for BOTH Movies and Series.  Never download
                # the provider-wide catalogue just to paint the first small-poster
                # row: that request can be very large on Xtream servers.  Use the
                # selected package RAM/disk cache first, and on a real miss fetch
                # only that package.  The same per-package cache is then reused by
                # Prev/Next package navigation.
                _package_diag("FIRST_PACKAGE_FAST_FETCH_BEGIN", kind=kind, category_id=first_id, category_name=first_name)
                first_items, first_origin = get_category_streams(
                    source, kind, client, first_id, use_cache=True, wait_for_server=True
                )
                first_items = self._sortedItems(first_items)
                if first_items:
                    self._rememberPackageRows(first_id, first_items)
                _package_diag("FIRST_PACKAGE_FAST_FETCH_DONE", kind=kind, category_id=first_id, category_name=first_name, origin=first_origin, item_count=len(first_items))
            else:
                _package_diag("FIRST_PACKAGE_FETCH_BEGIN", kind=kind, category_id=first_id, category_name=first_name)
                first_items, first_origin = get_category_streams(
                    source, kind, client, first_id,
                    use_cache=True, wait_for_server=True
                )
                first_items = self._sortedItems(first_items)
                _package_diag("FIRST_PACKAGE_FETCH_DONE", kind=kind, category_id=first_id, category_name=first_name, item_count=len(first_items))

            # Pass the full first package to GUI. Other packages are fetched only
            # when Prev/Next selects them.
            self._queueGui(
                self.serverReady,
                first_items, first_items, categories,
                {"category_id": first_id, "category_name": first_name},
                generation
            )
        except Exception as exc:
            _package_diag("LOAD_SERVER_ERROR", kind=kind, error=repr(exc))
            self._queueGui(self.serverFailed, str(exc), generation)


    def _loadBackdrops(self, generation=None):
        """Fast random Backdrop rail from enabled packages only.

        The rail never leaves the user's active Movies/TV Shows package filter.
        Every package enabled in the active Package Filter can contribute,
        regardless of provider name, language, country or release year.
        Both rails exclude wrestling, sports, programmes, documentaries,
        unscripted reality, anime and cartoons. Both rails deduplicate titles.
        Prefer diverse packages, provider artwork and cached responses;
        never block each card on TMDb verification.
        """
        if generation is None:
            generation = self.contentGeneration
        kind = self.kind
        page_kind = "vod" if self.kind == "vod" else "series"
        source = dict(self.source or {})
        try:
            saved_allowed = get_allowed_category_ids(source, page_kind)
            client = get_source_client(source)
            category_names = {}
            category_order = []
            m3u_entries = None
            categories_seed = None

            # Fast Backdrop startup:
            # - Existing saved package filters use RAM/disk metadata immediately.
            # - A brand-new image/server may read categories once to discover the
            #   currently enabled package IDs.
            # - An empty result stays silent and never triggers a blocking retry.
            if saved_allowed is None:
                cache_version = "v43_kind_verified_image_recovery"
                cache_mode = "backdrop_all_enabled_%s_%s_all" % (cache_version, page_kind)
                self._featuredBackdropCacheMode = cache_mode
                fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
                if fresh_cached:
                    self._queueGui(
                        self.backdropsReady,
                        fresh_cached[:self.BACKDROP_ITEM_LIMIT],
                        generation, fresh_cached[self.BACKDROP_ITEM_LIMIT:]
                    )
                    return

                if source.get("type") in ("m3u", "fg"):
                    try:
                        m3u_entries, _m3u_origin = get_cached_catalog(
                            source, "live", lambda: M3UClient(source).entries(),
                            wait_for_server=True
                        )
                    except Exception:
                        m3u_entries = []
                    allowed = set(
                        str((row or {}).get("group") or (row or {}).get("category_id") or "").strip()
                        for row in (m3u_entries or [])
                        if isinstance(row, dict) and M3UClient._entry_kind(row) == page_kind
                    )
                else:
                    try:
                        categories_seed, _cat_origin = get_cached_categories(
                            source, page_kind, client=client, wait_for_server=True
                        )
                    except Exception:
                        categories_seed = []
                    allowed = set(
                        str((cat or {}).get("category_id") or (cat or {}).get("id") or
                            (cat or {}).get("genre_id") or (cat or {}).get("group_id") or "").strip()
                        for cat in (categories_seed or [])
                        if isinstance(cat, dict)
                    )
            else:
                allowed = set(str(x) for x in (saved_allowed or []) if str(x))
                if not allowed:
                    self._queueGui(self.backdropsReady, [], generation, [])
                    return

                filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
                cache_version = "v43_kind_verified_image_recovery"
                cache_mode = "backdrop_all_enabled_%s_%s_%s" % (cache_version, page_kind, filter_sig)
                self._featuredBackdropCacheMode = cache_mode
                fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
                if fresh_cached:
                    self._queueGui(
                        self.backdropsReady,
                        fresh_cached[:self.BACKDROP_ITEM_LIMIT],
                        generation, fresh_cached[self.BACKDROP_ITEM_LIMIT:]
                    )
                    return
            if source.get("type") in ("m3u", "fg"):
                try:
                    if m3u_entries is None:
                        m3u_entries, _m3u_origin = get_cached_catalog(
                            source, "live", lambda: M3UClient(source).entries(),
                            wait_for_server=True
                        )
                    # M3U "Movies" group labels often identify live TV genres.
                    # Match M3UClient.streams(kind) classification exactly.
                    m3u_entries = [r for r in (m3u_entries or [])
                                   if isinstance(r, dict) and
                                   M3UClient._entry_kind(r) == page_kind]
                except Exception:
                    m3u_entries = []
                for raw in list(m3u_entries or []):
                    if not isinstance(raw, dict):
                        continue
                    cid = str(raw.get("group") or raw.get("category_id") or "").strip()
                    if not cid or cid not in allowed:
                        continue
                    if cid not in category_names:
                        category_names[cid] = cid
                        category_order.append(cid)
            try:
                if m3u_entries is not None:
                    categories, _origin = [], "m3u"
                elif categories_seed is not None:
                    categories, _origin = list(categories_seed or []), "seed"
                else:
                    categories, _origin = get_cached_categories(
                        source, page_kind, client=client, wait_for_server=True
                    )

                # With a saved package filter, an empty metadata cache means the
                # background category refresh has only just started. Do not wait
                # here and do not compete with the normal Series page loading.


                for cat in categories or []:
                    if not isinstance(cat, dict):
                        continue
                    cid = str(cat.get("category_id") or "")
                    if not cid or cid not in allowed:
                        continue
                    name = str(
                        cat.get("category_name") or cat.get("name") or
                        cat.get("title") or ""
                    )
                    category_names[cid] = name
                    if cid not in category_order:
                        category_order.append(cid)
            except Exception:
                pass

            # Keep only the user's enabled package IDs. Categories of any name
            # (VOD, Netflix, HBO, Apple, Prime, etc.) are eligible; no brand,
            # region, language, year or 20-package whitelist. Movies then
            # exclude non-movie categories only in prepare_row().
            category_order = [cid for cid in category_order if cid in allowed]
            if not category_order:
                # Package IDs remain usable before category-name metadata arrives.
                category_order = list(allowed)
            ordered_ids = list(dict.fromkeys(category_order))
            stable_seed = "%s|%s|%s" % (
                str(source.get("url") or source.get("host") or source.get("portal") or ""),
                str(source.get("username") or source.get("mac") or ""),
                page_kind,
            )
            ordered_ids = [str(row.get("id") or "") for row in
                           _stable_backdrop_order(
                               [{"id": cid} for cid in ordered_ids], stable_seed)]
            if not ordered_ids:
                raise RuntimeError("No enabled packages for Backdrop")

            target_count = self.BACKDROP_ITEM_LIMIT
            seen = set()

            def prepare_row(raw, cid):
                if not isinstance(raw, dict):
                    return None
                # Defense-in-depth for mixed M3U groups and imported lists.
                if m3u_entries is not None and M3UClient._entry_kind(raw) != page_kind:
                    return None
                item_cid = str(
                    raw.get("category_id") or raw.get("categoryId") or
                    raw.get("genre_id") or raw.get("genre-id") or cid
                )
                if item_cid and item_cid not in allowed:
                    return None
                # Keep Movies and TV Shows separate. Exclude broadcasts and
                # non-scripted categories in BOTH featured rails, not packages.
                declared_type = str(raw.get("media_type") or raw.get("content_type") or "").lower().strip()
                if page_kind == "vod" and declared_type in ("series", "tv", "tvshow", "episode", "live", "channel"):
                    return None
                if page_kind == "series" and declared_type in ("movie", "vod", "film", "live", "channel"):
                    return None
                if page_kind == "vod" and not _featured_movie_allowed(raw, category_names.get(str(cid), "")):
                    return None
                if page_kind == "series" and not _featured_series_allowed(raw, category_names.get(str(cid), "")):
                    return None
                title = str(raw.get("name") or raw.get("title") or "").strip()
                if not title:
                    return None
                row = dict(raw)
                display_title = self._backdropDisplayTitle(title)
                dedupe_title = re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", display_title.lower()).strip()
                if not dedupe_title:
                    return None
                key = "title:%s" % dedupe_title
                if key in seen:
                    return None
                seen.add(key)
                row["_display_title"] = display_title
                row["_you_might_like"] = True
                row["_source_category_id"] = str(cid)
                row["_source_category_name"] = category_names.get(str(cid), "")
                try:
                    year_value = str(self._year(raw) or "").strip()[:4]
                except Exception:
                    year_value = ""
                if year_value:
                    row["_backdrop_year"] = year_value
                return row

            # Gather candidates from several independent enabled packages,
            # not just the first batch yielding target_count films.
            package_pools = {}
            batch_size = 4
            for offset in range(0, len(ordered_ids), batch_size):
                batch_ids = ordered_ids[offset:offset + batch_size]
                if m3u_entries is not None:
                    package_batches = []
                    for cid in batch_ids:
                        rows = [
                            raw for raw in list(m3u_entries or [])
                            if isinstance(raw, dict)
                            and str(raw.get("group") or raw.get("category_id") or "").strip() == str(cid)
                        ]
                        package_batches.append((cid, rows, "m3u"))
                else:
                    package_batches = get_category_streams_batch(
                        source, page_kind, client, batch_ids,
                        use_cache=True, wait_for_server=True, max_workers=4
                    )
                for cid, rows, _origin in package_batches:
                    # A bounded random sample per package avoids a very large
                    # catalogue dominating memory/CPU and gives diversity.
                    rows = list(rows or [])
                    rows = _stable_backdrop_order(
                        rows,
                        "%s|%s|%s" % (stable_seed, str(cid), page_kind)
                    )[:120]
                    accepted = []
                    for raw in rows:
                        row = prepare_row(raw, cid)
                        if row is not None:
                            accepted.append(row)
                            if len(accepted) >= target_count:
                                break
                    if accepted:
                        package_pools[str(cid)] = accepted

                # Get diverse choices without scanning every active category
                # unnecessarily. If the first batch has few valid pictures,
                # subsequent batches are attempted automatically.
                pictured_packages = 0
                pictured_rows = 0
                for rows in package_pools.values():
                    count = sum(bool(self.imageUrl(row, True)) for row in rows)
                    pictured_rows += count
                    pictured_packages += bool(count)
                if pictured_rows >= target_count + 3 and (pictured_packages >= min(5, len(ordered_ids)) or
                                                           offset + batch_size >= min(len(ordered_ids), 12)):
                    break

            if not package_pools:
                raise RuntimeError("No usable Backdrop content in enabled packages")

            # No blocking TMDb country/year/language validation. Such checks
            # caused the rail to shrink or show nothing with legitimate VOD.
            # Select balanced content from active packages using artwork already
            # provided by the server or metadata cache.
            candidates = _balanced_featured_select(package_pools, target_count * 6)
            with_art = []
            without_art = []
            for item in candidates:
                has_landscape_url = bool(self.imageUrl(item, True))
                (with_art if has_landscape_url else without_art).append(item)
            # A source may supply only poster URLs even when TMDb has several
            # proper backdrops. Keep those titles eligible for asynchronous
            # TMDb backdrop resolution, but NEVER show their posters here.
            verified_rows = with_art + without_art
            if not verified_rows:
                raise RuntimeError("No featured titles in enabled packages")
            selected = verified_rows[:target_count]
            reserve = verified_rows[target_count:target_count + 3]
            # Cache all displayed artwork choices and three backups. Cache key
            # changed above so old restrictive selections cannot reappear.
            _home_feed_cache_put(cache_mode, source, selected + reserve)
            self._queueGui(self.backdropsReady, selected, generation, reserve)
        except Exception as exc:
            self._queueGui(self.backdropsFailed, str(exc), generation)



    def recentReady(self, token, recent, categories, generation=None, partial=False):
        """Apply a Recent Added result once, without losing last-good content.

        Provider failures and incomplete scans can return no items.  An empty
        response is never evidence that previously verified titles vanished.
        Enigma2 widgets are updated via _queueGui, never from the worker.
        """
        if (getattr(self, "_contentScreenDisposed", False) or
                self.contentMode != "recent" or
                token != self.recentRequestToken or
                (generation is not None and generation != self.contentGeneration)):
            return
        if categories:
            self.categoriesList = list(categories)
            self.categoriesLoaded = True
        rows = self._sortedItems(recent or [])
        rows = _screen_dedupe_content(rows, self.kind)[:25]
        if not rows:
            # Preserve existing posters/cursor on temporary provider failures,
            # empty cooldown and incomplete Stalker/Xtream catalogues.
            if self.recentStable or self.latest:
                return
            rows = _screen_dedupe_content(
                _home_feed_cache_get("recent_%s" % self.kind, self.source,
                                     allow_stale=True), self.kind)[:25]
            if not rows:
                self["heroDesc"].setText(
                    "Recent content is temporarily unavailable. The server will be retried on the next visit.")
                return
        previous = list(self.latest or [])
        previous_ids = [str((r or {}).get("stream_id") or
                            (r or {}).get("series_id") or
                            (r or {}).get("id") or "") for r in previous]
        new_ids = [str((r or {}).get("stream_id") or
                       (r or {}).get("series_id") or
                       (r or {}).get("id") or "") for r in rows]
        self.recentStable = list(rows)
        self.categoryName = "RECENT ADDED"
        self.categoryIndex = -1
        self.categoryItems = list(rows)
        if new_ids == previous_ids and len(previous) == len(rows):
            return  # Avoid blinking and re-decoding unchanged posters.
        self.latest = rows
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle()
        self.renderLatest()
        self.updateFocus()
        # Cache only successful, nonempty results, separated by source/kind.
        if recent:
            _submit_content_bg(
                _home_feed_cache_put,
                args=("recent_%s" % self.kind, dict(self.source), list(rows)),
                key=("recent-cache", id(self), self.kind))

    def serverReady(self, latest, allItems=None, categories=None, landingCategory=None, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        if not self._usingLandingSnapshot:
            self._rememberLandingSnapshot(latest, allItems, categories, landingCategory)
        self.serverItems = list(allItems or [])
        self.categoryItems = []
        self.categoriesList = list(categories or [])

        # Build one in-memory category map once. This removes the repeated
        # full-catalog scan that used to happen on every package key press.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        # _categoryRowsIndex had no readers; it duplicated the provider
        # catalogue's row references on every page open for no benefit.
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        landing_id = str((landingCategory or {}).get("category_id") or "")
        landing_name = (landingCategory or {}).get("category_name") or ""
        if landing_id == "__recent_added__":
            self.categoryIndex = -1
            self.categoryName = landing_name or "RECENT ADDED"
            self.categoryItems = list(allItems or [])
            self._updateLatestTitle()
        elif landing_id:
            for index, category in enumerate(self.categoriesList):
                if str(category.get("category_id") or "") == landing_id:
                    self.categoryIndex = index
                    self.categoryName = category.get("category_name") or landing_name or "Other"
                    self._updateLatestTitle()
                    self.categoryItems = list(allItems or [])
                    if landing_id:
                        self._rememberPackageRows(landing_id, self.categoryItems)
                    break
        # The worker already sorts package rows before handing them to the GUI.
        # Do not sort a potentially large cached catalogue on the GUI thread.
        server_latest = latest or []

        # SERVER/PACKAGE POSTERS ARE A SEPARATE PERMANENT PATH.
        # NONE means: no automatic Netflix/Prime/Trending lower feed.
        # It does NOT disable server packages, Recent Added, or their posters.
        if self.contentMode in ("none", "recent"):
            self.latest = _screen_dedupe_content(server_latest, self.kind)
            self.latestStart = self.latestIndex = 0
            if self.latest and not self._usingLandingSnapshot:
                _submit_content_bg(_save_content_landing_cache,
                                   args=(dict(self.source), self.kind, list(self.latest)[:64]),
                                   key=("landing-cache", id(self), self.kind))
            self._updateLatestTitle()
            self.renderLatest()
        elif not self.latest:
            # Automatic provider modes are supplied later by TMDb.
            self.latest = []
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()
        if self.source.get("type") == "stalker" and not self.latest:
            self["heroDesc"].setText(tr("Stalker packages are ready. Open Categories and select a package to load its titles."))
        if not self.backdrops:
            # Keep the opening focus on the top navigation. Once the user presses
            # DOWN, focus goes to Backdrops first (or Latest only if Trending is unavailable).
            if self.focus != "top":
                self.focus = "backdrops" if self.backdrops else ("latest" if self.latest else "backdrops")
                self.preview()
            self.updateFocus()


    def backdropsReady(self, backdrops, generation=None, lower_items=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Keep the cached Backdrop selection in a stable order on every page
        # open. _loadBackdrops() already randomises the provider selection before
        # storing it in the 6-hour cache, so re-shuffling here only makes Movies
        # jump around unnecessarily between opens.
        previous = self.backdrops
        previous_focus = self.focus
        previous_start = self.backdropStart
        previous_index = self.backdropIndex
        self.backdrops = _screen_dedupe_content(backdrops or [], self.kind)[:self.BACKDROP_ITEM_LIMIT]

        # Movies intentionally keep the cached order unchanged until the
        # backdrop cache is refreshed/expired.

        # Keep the package under the selector during background refreshes.
        # Only a genuinely new page starts on the first backdrop.
        if self.backdrops:
            self.backdropStart, self.backdropIndex = _restore_backdrop_cursor(
                previous, self.backdrops, previous_start, previous_index)
            # An artwork callback is NOT a navigation event. Never move
            # initial focus onto Backdrops (which starts YouTube preview).
            self.focus = previous_focus

        self.renderBackdrops()
        self._scheduleBackdropNewestOrder(generation)

        if self.focus == "backdrops":
            self.preview()
        self.updateFocus()


    def serverFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Recent is sticky-last-good: a retry/network failure cannot make the
        # row disappear after it was already visible.
        if self.contentMode == "recent" and self.recentStable:
            self.latest = _screen_dedupe_content(self.recentStable, self.kind)
            self.latestStart = self.latestIndex = 0
            self.categoryName = "RECENT ADDED"
            self._updateLatestTitle()
            self.renderLatest()
            self.updateFocus()
            return

        # Keep a previously painted, verified package/Recent list on failure.
        # No spinner or network error may clear last-good provider content.
        if self.latest:
            return
        self.serverItems, self.categoryItems, self.categoriesList = [], [], []
        self.categoriesLoaded = True
        self.latest = []
        self._updateLatestTitle()
        self["heroDesc"].setText("Unable to load the selected server library: %s" % msg)
        self.renderLatest(); self.updateFocus()


    def backdropsFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        # An expired/retrying provider must not erase a cached Backdrop rail.
        if self.backdrops:
            return
        self.backdrops = []
        self.renderBackdrops()
        if self.latest:
            if self.focus != "top":
                self.focus = "latest"
                self.preview()
            self["heroDesc"].setText("Backdrops unavailable. Server content is still available.\n%s" % msg)
        else:
            self["heroDesc"].setText("Unable to load Backdrops: %s" % msg)
        self.updateFocus()


    def current(self):
        arr = self.backdrops if self.focus == "backdrops" else self.latest
        idx = self.backdropStart + self.backdropIndex if self.focus == "backdrops" else self.latestStart + self.latestIndex
        return arr[idx] if 0 <= idx < len(arr) else None

    def _withServerTarget(self, item, callback):
        """r146: TMDb rows are matched to a server row off the GUI thread.

        Stalker had to scan every package from the server here, freezing the
        screen while adding a favourite."""
        if not item:
            callback(item, None)
            return
        if not item.get("_tmdb"):
            callback(item, item)
            return
        quick = self._strictMatchFromRows(item, self.serverItems or [])
        if quick or self.source.get("type") != "stalker":
            callback(item, quick)
            return
        try:
            self["footer"].setText(tr("Searching..."))
        except Exception:
            pass
        snapshot = dict(item)

        def worker():
            try:
                found = self.matchServerItem(snapshot)
            except Exception:
                found = None
            self._queueGui(callback, snapshot, found)
        thread = threading.Thread(target=worker, name="TiviFavouriteMatch")
        thread.daemon = True
        thread.start()

    def toggleFavourite(self):
        self._withServerTarget(self.current(), self._toggleFavouriteTarget)

    def _toggleFavouriteTarget(self, item, target):
        if not item:
            return
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, self.kind, target)
            title = target.get("name") or target.get("title") or "العنصر"
            if not saved:
                self["footer"].setText(tr("Unable to save favorite"))
            elif added:
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText("تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["footer"].setText("تعذر تحديث المفضلة: %s" % exc)

    def addCurrentFavourite(self):
        self._withServerTarget(self.current(), self._addCurrentFavouriteTarget)

    def _addCurrentFavouriteTarget(self, item, target):
        if not item:
            self["footer"].setText(tr("Select a movie or TV show first"))
            return
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import is_favourite, add_favourite
            title = target.get("name") or target.get("title") or "العنصر"
            if is_favourite(self.source, self.kind, target):
                self["footer"].setText("%s موجود بالفعل في المفضلات" % title)
            elif add_favourite(self.source, self.kind, target):
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText(tr("Unable to save favorite"))
        except Exception as exc:
            self["footer"].setText("Unable to save favorite: %s" % exc)

    def norm(self, value):
        if isinstance(value, list): value = value[0] if value else ""
        if isinstance(value, str):
            value = value.strip().replace("\\/", "/")
            if value.startswith("["):
                try: value = (json.loads(value) or [""])[0]
                except Exception: pass
            if value.startswith("/"): value = backdrop_url(value)
        return value or ""

    def imageUrl(self, item, backdrop=False):
        item = item or {}
        if backdrop:
            # TMDb feed rows use TMDb-relative image paths. Server rows use
            # the shared provider policy, including nested info/movie_data,
            # fanart/background/screenshot_uri and source-relative URLs.
            # Never substitute a poster/cover for a landscape backdrop.
            if item.get("_tmdb"):
                return self.norm(item.get("backdrop_path") or item.get("backdrop") or
                                 item.get("backdrop_url") or "")
            return _server_backdrop_url(self.source, item)

        # TMDb provider rows already contain complete TMDb artwork URLs.
        # Do not send them through the connected-server poster resolver.
        if item.get("_tmdb"):
            return self.norm(
                item.get("stream_icon")
                or item.get("cover")
                or item.get("poster")
                or item.get("poster_path")
            )

        # The large page may already have decoded the exact poster. Its URL
        # is saved by source+kind+stream identity and is usable only if the
        # original image remains cached. This check never talks to the network.
        try:
            from .poster_resolution_cache import cached_decoded_url
            winner = cached_decoded_url(self.source, self.kind, item)
            if winner:
                return winner
        except Exception:
            pass

        # Home rows that were resolved by the TMDb warm pass already carry a
        # poster and backdrop from the same TMDb movie id. Prefer that exact
        # poster here instead of a provider poster that may belong to another
        # title while the hero backdrop is correct. This is display-only and
        # does not change package/server data or other artwork lookup paths.
        exact_tmdb_poster = self.norm(item.get("_tmdb_poster") or "")
        if exact_tmdb_poster:
            return exact_tmdb_poster

        # Server/package rows without a resolved Home TMDb poster continue to
        # use the existing server-aware resolver unchanged.
        return _server_poster_url(self.source, item)

    def logoUrl(self, item):
        return self.norm(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "")

    def setPlaceholder(self, widget, name):
        try: self[widget].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", name))
        except Exception: pass

    def _tmdbTitleCandidates(self, *values):
        """Return safe TMDb title candidates without changing server list labels.

        IPTV providers often prefix names with bouquet/group tags such as
        ``FRI |`` or ``EN |``.  Those labels are useful in the UI but can make
        TMDb return no result.  Only the fallback lookup uses these cleaned
        variants, so the fast server-artwork path remains untouched.
        """
        out = []
        for value in values:
            raw = str(value or "").strip()
            if not raw:
                continue
            variants = [raw]
            if "|" in raw:
                tail = raw.split("|")[-1].strip()
                if tail:
                    variants.insert(0, tail)
            # Remove a leading [GROUP] / (GROUP) tag only for TMDb lookup.
            variants.append(re.sub(r"^\s*[\[(][^\])]{1,16}[\])]\s*", "", raw).strip())
            for candidate in variants:
                clean = self._normTitle(candidate)
                if clean and clean not in out:
                    out.append(clean)
        return out

    def _tmdbSearchArtwork(self, item, extra=None, required_key="poster_path"):
        """One TMDb artwork path for every Movies/TV Shows surface.

        Always let the shared TMDb client see the original provider title
        first.  Its global title normalizer handles 4K/NF/language/provider
        prefixes consistently on every server.  Local legacy candidates remain
        only as a final compatibility fallback.
        """
        tmdb = TMDbClient()
        data = dict(item or {})
        if isinstance(extra, dict):
            merged = dict(extra)
            merged.update(data)
            data = merged
        values = [data.get("name"), data.get("title"), data.get("original_title"), data.get("original_name")]
        year = self._year(data) or None
        # A provider TMDb id is the most reliable identity, especially for Arabic
        # titles. Use it before any title search so poster/backdrop fallback cannot
        # miss because of translated/transliterated names.
        resolved_id = str(data.get("tmdb_id") or data.get("tmdb") or data.get("tmdbid") or "").strip()
        if resolved_id:
            try:
                bundle = tmdb.details_bundle(resolved_id, self.kind) or {}
                if bundle.get(required_key):
                    return bundle
            except Exception:
                pass
        seen = set()
        # Original labels first: TMDbClient.search_artwork() owns the canonical
        # All-server normalization.
        for value in values:
            candidate = str(value or "").strip()
            key = candidate.lower()
            if not candidate or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        # Keep old local variants for unusual bouquet labels, but never make
        # them the primary lookup path.
        for candidate in self._tmdbTitleCandidates(*values):
            key = str(candidate or "").strip().lower()
            if not key or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        return {}

    def _sameMovieBackdropPaths(self, tmdb, tmdb_id, bundle=None, kind=None):
        """Real alternate backdrops for this exact TMDb media ID only.

        Called only on missing/failed art, never for an already-rendered image.
        No GUI/network work here; caller runs on the background worker.
        """
        if not str(tmdb_id or "").strip().isdigit() or int(tmdb_id) <= 0:
            return []
        details = bundle if isinstance(bundle, dict) else {}
        paths = _tmdb_same_movie_backdrops(details)
        if len(paths) >= 2:
            return paths
        # Older cached details may not contain images.backdrops; request the
        # images endpoint only during recovery, not on every navigation.
        media = "tv" if (kind or self.kind) == "series" else "movie"
        try:
            # Don't restrict recovery images by the UI language. TMDb may
            # host the only landscape still without a language tag, or in a
            # locale absent from our UI. Identity remains this same media ID.
            extra = tmdb._get("/%s/%s/images" % (media, tmdb_id), {}) or {}
            combined = dict(details)
            images = dict(combined.get("images") or {})
            images["backdrops"] = list(images.get("backdrops") or []) + list(extra.get("backdrops") or [])
            combined["images"] = images
            paths = _tmdb_same_movie_backdrops(combined)
        except Exception:
            pass
        return paths

    def _backdropRecoveryTarget(self, widget):
        """Capture an exact visible item identity; reject late worker results."""
        if widget == "hero":
            item = self.current()
            if not isinstance(item, dict):
                return None
            return (self.contentGeneration, self.kind, "hero",
                    self._previewRequestId, id(item)), item
        match = re.fullmatch(r"backdrop([0-3])", str(widget or ""))
        if not match:
            return None
        index = self.backdropStart + int(match.group(1))
        if not (0 <= index < len(self.backdrops)):
            return None
        item = self.backdrops[index]
        if not isinstance(item, dict):
            return None
        return (self.contentGeneration, self.kind, index, id(item)), item

    def _recoverCinematicCardBackdrop(self, widget, failed_url, width, height):
        self._recoverSameMovieBackdrop(widget, failed_url, width, height)

    def _recoverCinematicHeroBackdrop(self, failed_url):
        size = (1920, 1080) if getattr(self, "_fastMoviesPerformance", False) else (1920, 520)
        self._recoverSameMovieBackdrop("hero", failed_url, *size)

    def _recoverSameMovieBackdrop(self, widget, failed_url, width, height):
        """Try at most four OTHER TMDb backdrops for the same film/series.

        Cache and GUI tokens are kept per visible item/slot, so delayed responses
        cannot paint a film selected after the failed image.
        """
        if getattr(self, "_contentScreenDisposed", False):
            return
        target = self._backdropRecoveryTarget(widget)
        if target is None:
            return
        identity, item = target
        current = getattr(self, "_image_requests", {}).get(widget)
        if current != failed_url:
            return
        states = getattr(self, "_sameMovieBackdropRetries", None)
        if states is None:
            states = {}
            self._sameMovieBackdropRetries = states
        state = states.get(widget)
        if state is None or state.get("identity") != identity:
            state = {"identity": identity, "tried": set(), "candidates": None,
                     "pending": False, "tmdb_id": ""}
            states[widget] = state
        state["tried"].add(_tmdb_backdrop_identity(failed_url))
        try:
            cached = str(item.get("_tmdb_backdrop") or "")
            if cached and _tmdb_backdrop_identity(cached) == _tmdb_backdrop_identity(failed_url):
                item.pop("_tmdb_backdrop", None)
        except Exception:
            pass
        # Bound failure cost even when a provider/TMDb CDN keeps rejecting data.
        if len(state["tried"]) >= 5:
            if getattr(self, "_fastMoviesPerformance", False) and widget != "hero":
                self._skipEmptyBackdropCard(widget, failed_url)
            return

        def paint_next():
            if states.get(widget) is not state or self._backdropRecoveryTarget(widget) is None:
                return False
            if self._backdropRecoveryTarget(widget)[0] != identity:
                return False
            if self._image_requests.get(widget) != failed_url:
                return False
            for path in state.get("candidates") or []:
                candidate = self.norm(path)
                if not candidate:
                    continue
                key = _tmdb_backdrop_identity(candidate)
                if key in state["tried"]:
                    continue
                if widget != "hero" and "image.tmdb.org/t/p/" in candidate:
                    candidate = re.sub(r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                                       r"\1w780\2", candidate, count=1)
                state["tried"].add(key)
                self.loadImage(candidate, widget, width, height)
                return True
            return False

        if state["candidates"] is not None:
            if not paint_next() and widget != "hero" and getattr(self, "_fastMoviesPerformance", False):
                self._skipEmptyBackdropCard(widget, failed_url)
            return
        if state["pending"]:
            return
        state["pending"] = True
        snapshot = dict(item)
        kind = self.kind
        title = str(snapshot.get("name") or snapshot.get("title") or
                    snapshot.get("original_title") or snapshot.get("original_name") or "").strip()
        year = self._year(snapshot) or None
        known_id = str(snapshot.get("tmdb_id") or snapshot.get("tmdb") or
                       snapshot.get("tmdbid") or "").strip()

        def worker():
            candidates = []
            tmdb_id = known_id
            try:
                tmdb = TMDbClient()
                if not (tmdb_id.isdigit() and int(tmdb_id) > 0):
                    # search_title verifies title similarity/year >=0.80;
                    # a same-year but unrelated movie is never acceptable.
                    match = tmdb.search_title(title, kind, year) if title else None
                    tmdb_id = str((match or {}).get("id") or
                                  (match or {}).get("tmdb_id") or "").strip()
                if tmdb_id.isdigit() and int(tmdb_id) > 0:
                    details = tmdb.details_bundle(tmdb_id, kind) or {}
                    # A provider-supplied ID is authoritative; other identities
                    # come only from the title/year-verified search above.
                    candidates = self._sameMovieBackdropPaths(tmdb, tmdb_id, details, kind=kind)
            except Exception:
                candidates = []

            def apply():
                if states.get(widget) is not state or state.get("identity") != identity:
                    # The state was superseded; the old pending flag is no
                    # longer live and must not block a later request.
                    state["pending"] = False
                    return
                state["pending"] = False
                state["candidates"] = candidates
                state["tmdb_id"] = tmdb_id
                if not paint_next() and widget != "hero" and getattr(self, "_fastMoviesPerformance", False):
                    self._skipEmptyBackdropCard(widget, failed_url)
            self._queueGui(apply)

        try:
            accepted = _submit_content_bg(worker,
                key=("tmdb-same-movie-backdrop", id(self), widget, identity),
                hero=(widget == "hero"), backdrop=(widget != "hero"))
        except Exception:
            accepted = False
        if not accepted:
            state["pending"] = False

    def _tmdbBackdropFallback(self, item, widget, width, height, server_fallback=""):
        """Find an exact-title TMDb alternative after the server backdrop fails.

        The caller must have already tried the provider's landscape image.
        Do not retry a broken provider URL ahead of its TMDb fallback.
        """
        item = item or {}
        raw_title = str(item.get("name") or item.get("title") or item.get("original_title") or item.get("original_name") or "").strip()
        if not raw_title:
            if server_fallback:
                self.loadImage(server_fallback, widget, width, height)
            elif getattr(self, "_fastMoviesPerformance", False) and widget != "hero":
                self._skipEmptyBackdropCard(widget)
            return
        # The URL and visible-item identity prevent an old TMDb reply from
        # replacing another card after fast left/right navigation.
        visible_identity = self._backdropRecoveryTarget(widget)
        expected_url = getattr(self, "_image_requests", {}).get(widget)
        token = (raw_title, str(item.get("stream_id") or item.get("series_id") or item.get("id") or ""),
                 visible_identity[0] if visible_identity else None, expected_url)
        if not hasattr(self, "_backdrop_fallback_tokens"):
            self._backdrop_fallback_tokens = {}
        self._backdrop_fallback_tokens[widget] = token

        # Reuse an already-resolved TMDb backdrop immediately.
        cached_backdrop = self.norm(item.get("_tmdb_backdrop") or "")
        if cached_backdrop:
            self.loadImage(cached_backdrop, widget, width, height)
            return

        def worker():
            backdrop = ""
            resolved_id = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
            try:
                tmdb = TMDbClient()
                kind = self.kind
                year = self._year(item) or None
                data = {}

                # Same fast path as More Info: a provider TMDb ID wins when valid.
                if resolved_id:
                    try:
                        data = tmdb.details_bundle(resolved_id, kind) or {}
                    except Exception:
                        data = {}
                    backdrop = self.norm(data.get("backdrop_path") or "")
                    if not backdrop:
                        paths = self._sameMovieBackdropPaths(tmdb, resolved_id, data)
                        backdrop = self.norm(paths[0]) if paths else ""

                # Same title/year resolver as More Info when no useful ID/backdrop.
                if not backdrop:
                    found = {}
                    try:
                        found = tmdb.search_title(raw_title, kind, year) or {}
                    except Exception:
                        found = {}
                    if not found:
                        try:
                            found = tmdb.search_title(raw_title, kind, None) or {}
                        except Exception:
                            found = {}
                    rid = str((found or {}).get("id") or (found or {}).get("tmdb_id") or "").strip()
                    if rid:
                        resolved_id = rid
                        # TMDb title-search results already contain the genuine
                        # backdrop_path: show it immediately like GENRE. Only
                        # request the full bundle when that artwork is missing.
                        backdrop = self.norm((found or {}).get("backdrop_path") or "")
                        if not backdrop:
                            try:
                                data = tmdb.details_bundle(resolved_id, kind) or {}
                            except Exception:
                                data = {}
                    backdrop = backdrop or self.norm((data or {}).get("backdrop_path") or "")
            except Exception:
                backdrop = ""

            final_url = backdrop or server_fallback

            def apply():
                if getattr(self, "_backdrop_fallback_tokens", {}).get(widget) != token:
                    return
                if (visible_identity is not None and
                        (self._backdropRecoveryTarget(widget) or (None,))[0] != visible_identity[0]):
                    return
                if getattr(self, "_image_requests", {}).get(widget) != expected_url:
                    return
                if not final_url:
                    if getattr(self, "_fastMoviesPerformance", False) and widget != "hero":
                        self._skipEmptyBackdropCard(widget, expected_url)
                    return
                try:
                    if backdrop:
                        item["_tmdb_backdrop"] = backdrop
                        # Keep provider backdrop untouched; this key makes future
                        # rail renders prefer the exact TMDb artwork without another match.
                        if resolved_id:
                            item["tmdb_id"] = resolved_id
                except Exception:
                    pass
                self.loadImage(final_url, widget, width, height)

            # apply() submits the one high-priority visible image request.
            # A second low-priority prefetch of the same image is unnecessary.
            self._queueGui(apply)

        _submit_content_bg(worker, key=("backdrop-exact-tmdb", id(self), str(widget), token), backdrop=True)

    def _tmdbPosterFallback(self, item, widget, width, height, failed_url=""):
        """Find a TMDb poster only when the server poster is missing or failed."""
        # A reused card may already be loading another item. Never let an old
        # server failure replace the artwork of the new card.
        if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
            return
        def worker():
            try:
                if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
                    return
                found = self._tmdbSearchArtwork(item or {}, required_key="poster_path")
                poster = self.norm(found.get("poster_path") or "")
                if not poster:
                    return
                def apply():
                    # The slot may have been reused while TMDb was queried.
                    current = getattr(self, "_image_requests", {}).get(widget)
                    if failed_url and current != failed_url:
                        return
                    self.loadImage(poster, widget, width, height)
                self._queueGui(apply)
            except Exception:
                pass
        _submit_content_bg(worker, key=("poster-fallback", id(self), str(widget)))

    def _posterFileValid(self, path):
        """Cheap local validation for server posters before decoding.

        This deliberately does not touch the downloader/queue.  It only catches
        server URLs that return an HTML/error body or a tiny/broken file, so the
        existing TMDb fallback can take over without affecting artwork speed.
        """
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return True
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return True
            if head.startswith(b"RIFF") and head[8:12] == b"WEBP":
                return True
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return True
            return False
        except Exception:
            return False

    def _genreHeroIdentity(self, widget, item):
        """Bound a GENRE artwork response to an exact current slot and source."""
        if not isinstance(item, dict):
            return None
        base = (self.contentGeneration, self.kind, id(self.source))
        if widget in ('hero', 'logoImage'):
            if self.current() is not item:
                return None
            # A delayed metadata lookup may advance _previewRequestId for the
            # SAME title. Do not cancel its already-running backdrop recovery.
            # Both Hero and Logo remain attached to the same selected row.
            # Metadata-only refreshes may increment previewRequestId without
            # changing the selected work; do not discard valid logo downloads.
            token = id(item)
            return base + ('preview', token, id(item))
        match = re.fullmatch(r'latest([0-7])', str(widget))
        if match:
            idx = self.latestStart + int(match.group(1))
            if 0 <= idx < len(self.latest) and self.latest[idx] is item:
                return base + ('latest', idx, id(item))
        match = re.fullmatch(r'backdrop([0-3])', str(widget))
        if match:
            idx = self.backdropStart + int(match.group(1))
            if 0 <= idx < len(self.backdrops) and self.backdrops[idx] is item:
                return base + ('backdrop', idx, id(item))
        return None

    def _genreHeroRecover(self, widget, item, media, width, height, failed_url=''):
        """Run the REAL GENRE image resolver for one poster/backdrop/clearlogo.

        Only replace absent or broken images. Selection/slot tokens suppress
        old server/title callbacks; images that decoded successfully win.
        """
        if self._contentScreenDisposed or self.kind not in ('vod', 'series'):
            return False
        identity = self._genreHeroIdentity(widget, item)
        if identity is None:
            return False
        if (getattr(self, '_genreHeroWins', {}).get(widget) == identity or
                getattr(self, '_genreHeroDecoded', {}).get(widget) == identity):
            return True
        attempts = getattr(self, '_genreHeroAttempts', None)
        if attempts is None:
            attempts = set()
            self._genreHeroAttempts = attempts
        if str(failed_url or '').startswith('genre-hero|'):
            return True
        key = (widget, identity, str(failed_url or ''))
        # A failed attempt can be retried after 30 seconds; do not freeze a
        # missing image for the lifetime of a long-running Enigma2 session.
        retry_at = getattr(self, '_genreHeroRetryAt', None)
        if retry_at is None:
            retry_at = {}
            self._genreHeroRetryAt = retry_at
        now = time.monotonic()
        if key in attempts and now < retry_at.get(key, now + 1):
            return True
        if len(attempts) >= 160:
            attempts.clear()
            retry_at.clear()
        attempts.add(key)
        retry_at[key] = now + 30
        source, row = dict(self.source or {}), dict(item)

        def current():
            if self._contentScreenDisposed:
                return False
            if self._genreHeroIdentity(widget, item) != identity:
                return False
            if (getattr(self, '_genreHeroWins', {}).get(widget) == identity or
                    getattr(self, '_genreHeroDecoded', {}).get(widget) == identity):
                return False
            # An unrelated successful URL may have been selected while the
            # fallback was running. Never overwrite its decoded pixmap.
            # A later TMDb candidate may replace the request URL before the
            # GENRE provider/details fallback has returned. Do not cancel a
            # valid recovery for the SAME selected browse title solely because
            # of that URL change. Successful decoded artwork is already
            # protected by _genreHeroDecoded above.
            if widget != 'hero' and not (getattr(self, '_fastMoviesPerformance', False) and
                    widget == 'logoImage'):
                if failed_url and self._image_requests.get(widget) not in (failed_url, '', None):
                    return False
            # For hero, the same title may receive a new failing URL from a
            # parallel metadata lookup. The decoded-success guard above keeps
            # that result safe while allowing the original fallback to finish.
            return True

        def ready(path):
            if not current() or not path or not os.path.isfile(path):
                return
            # The downloader and genre image validators run on workers; guard
            # against portrait backdrops without substituting the poster.
            if media == 'backdrop' and not _cinematic_is_landscape_image(path):
                return
            if media == 'poster' and not self._posterFileValid(path):
                return
            marker = 'genre-hero|' + path
            self._image_requests[widget] = marker
            pending = getattr(self, '_genreHeroPending', None)
            if pending is None:
                pending = {}
                self._genreHeroPending = pending
            pending[widget] = (identity, marker)
            if widget == 'logoImage':
                # The recovery callback already verified row identity. Decode
                # directly: _applyPreviewTitleLogoPath checks a different,
                # short-lived request ID and could discard a valid Ultra logo.
                self.decode(path, widget, width, height)
            else:
                self.decode(path, widget, width, height)

        def failed(_path):
            # Existing fallback paths are left intact. This resolver only
            # supplies additional GENRE candidates on missing media.
            return
        try:
            from .hero_shared import recover
            recover(source, row, self.kind, media, ready, failed,
                    self._queueGui, excluded=(failed_url,) if failed_url else (),
                    canvas=(680, 106) if self.kind == 'vod' else (620, 96),
                    cancelled=lambda: self._genreHeroIdentity(widget, item) != identity
                              or self._contentScreenDisposed)
            return True
        except Exception:
            attempts.discard(key)
            return False

    def loadImage(self, url, widget, width, height, fallback_item=None):
        """Show cached artwork fast; hero backdrops recover through TMDb if needed."""
        if (str(widget).startswith('latest') and isinstance(fallback_item, dict)
                and self.kind in ('vod', 'series')):
            from .shared_genre_posters import request_genre_poster
            source = dict(self.source or {})
            # Retain exact URL when decoded; the existing fast-page redraw
            # suppression and verified shared resolution cache depend on it.
            ticket = 'genre-pending:%s:%s:%s:%s' % (id(fallback_item), widget, str(url or ''), self.latestStart)
            self._image_requests[widget] = ticket
            def stale():
                return (getattr(self, '_contentScreenDisposed', True) or
                        getattr(self, '_image_requests', {}).get(widget) != ticket)
            def resolved(path, winner):
                if stale():
                    return
                # Latest must never stretch a landscape screenshot into a poster.
                from .artwork_orientation import portrait_file
                if not portrait_file(path):
                    return
                self._image_requests[widget] = winner
                # Existing decoder handles native success, poster labels,
                # focus, shells, and remember_decoded on a true decode hit.
                self.decode(path, widget, width, height)
            if request_genre_poster(source, fallback_item, self.kind, resolved,
                                    cancelled=stale, primary=url,
                                    callback_gui=self._queueGui, portrait_only=True):
                return
        url = (url or "").strip().replace("\\/", "/")
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        requests[widget] = url

        if widget == "hero":
            priority = 150
        elif widget in ("logoImage", "promoBanner"):
            priority = 100
        elif re.fullmatch(r"backdrop[0-3]", str(widget)):
            # Visible hero-rail cards must not be evicted behind background
            # posters when the artwork queue reaches its RAM limit.
            priority = 135
        elif widget.startswith("backdrop"):
            priority = 75
        elif widget.startswith("latest"):
            priority = 85
        else:
            priority = 50

        def force_hero_tmdb(expected=url):
            if getattr(self, "_image_requests", {}).get("hero") != expected:
                return
            item = self.current()
            if not item:
                return
            self._previewRequestId += 1
            request_id = self._previewRequestId
            # The provider backdrop already failed at download time. Bypass it on
            # this retry; otherwise _lookupPreviewArtwork sees the same non-empty
            # URL and keeps selecting it forever instead of reaching TMDb.
            _submit_content_bg(
                self._lookupPreviewArtwork,
                args=(dict(item), request_id, True, False, True),
                key=("hero-tmdb-fallback", id(self)),
                hero=bool(getattr(self, "_fastMoviesPerformance", False))
            )

        def done(path, w=widget, x=width, y=height, expected=url, item=fallback_item):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            # Some providers put a wide screenshot into stream_icon/cover.
            # Keep cache bytes untouched (another screen may use the image),
            # but do not decode that landscape image into the Latest poster.
            if re.fullmatch(r"latest[0-7]", str(w)):
                from .artwork_orientation import portrait_file
                if not self._posterFileValid(path) or not portrait_file(path):
                    if item is not None:
                        self._tmdbPosterFallback(item, w, x, y, expected)
                    return
            elif item is not None and not self._posterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except OSError:
                    pass
                self._genreHeroRecover(w, item, 'poster', x, y, expected)
                return
            if w == "hero" or re.fullmatch(r"backdrop[0-3]", w):
                # Some movie AND series providers store portrait posters in
                # the backdrop field. Validate just the four horizontal rail
                # cards; preserve the real small poster row and hero image.
                if (self.kind in ("vod", "series") and
                        re.fullmatch(r"backdrop[0-3]", w) and
                        self._posterFileValid(path) and
                        not _cinematic_is_landscape_image(path)):
                    # Mark the provider URL as portrait on this row. A cached
                    # reopening must bypass it, not repeatedly fetch/recover it.
                    target = self._backdropRecoveryTarget(w)
                    if target is not None:
                        rail_item = target[1]
                        if isinstance(rail_item, dict):
                            rail_item["_fast_invalid_backdrop_url"] = expected
                            self._genreHeroRecover(w, rail_item, 'backdrop', x, y, expected)
                            return
                    target = self._backdropRecoveryTarget(w)
                    self._genreHeroRecover(w, target[1] if target else None,
                                           'backdrop', x, y, expected)
                    return
                if not self._posterFileValid(path):
                    # Only remove a broken managed-cache file. Do not touch
                    # server data, saved originals or any unrelated cache.
                    try:
                        artwork_cache = get_cache_dir("backdrops")
                        if (path and artwork_cache and
                                os.path.realpath(path).startswith(
                                    os.path.realpath(artwork_cache) + os.sep)):
                            os.remove(path)
                    except (OSError, TypeError, ValueError):
                        pass
                    target = self._backdropRecoveryTarget(w)
                    self._genreHeroRecover(w, target[1] if target else None,
                                           'backdrop', x, y, expected)
                    return
            self.decode(path, w, x, y)

        def failed(_path, w=widget, expected=url, item=fallback_item, x=width, y=height):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            if w == "hero":
                self._genreHeroRecover(w, self.current(), 'backdrop', x, y, expected)
                return
            if re.fullmatch(r"backdrop[0-3]", w):
                target = self._backdropRecoveryTarget(w)
                self._genreHeroRecover(w, target[1] if target else None,
                                       'backdrop', x, y, expected)
                return
            if w == 'logoImage':
                self._genreHeroRecover(w, self.current(), 'logo', x, y, expected)
                return
            if item is not None:
                self._genreHeroRecover(w, item, 'poster', x, y, expected)


        if str(widget).startswith("backdrop") or widget == "hero" or str(widget).startswith("rec"):
            # Movie Details, TV Details, cinematic hero and three rail cards
            # share one cache file per original backdrop URL / TMDb path.
            cache_kind = "backdrops"
        elif widget in ("logoImage", "promoBanner"):
            # Both are small graphic artwork; share the existing logo cache
            # so HDD/USB/internal-flash cleanup policies remain unchanged.
            cache_kind = "logos"
        else:
            cache_kind = "posters"
        # GENRE-style cache-first display: decode the existing disk image on
        # the UI path instead of scheduling another downloader callback.  The
        # shared artwork queue remains responsible only for missing assets.
        # Keep the normal validation/recovery in done() for corrupt entries.
        try:
            local_artwork = cached_artwork(url, cache_kind)
        except Exception:
            local_artwork = None
        if local_artwork and os.path.isfile(local_artwork):
            done(local_artwork)
            return
        # r146: Latest backdrop cards fetch TMDb's small w300 copy (the
        # full w780 above is still used when it is already cached).
        if (re.fullmatch(r"backdrop[0-3]", str(widget)) and
                "image.tmdb.org/t/p/" in str(url)):
            cache_kind = "backdrop_cards"
            try:
                local_artwork = cached_artwork(url, cache_kind)
            except Exception:
                local_artwork = None
            if local_artwork and os.path.isfile(local_artwork):
                done(local_artwork)
                return

        if (self.kind in ('vod', 'series') and
                (widget == 'hero' or widget == 'logoImage' or
                 re.fullmatch(r'backdrop[0-3]|latest[0-7]', str(widget)))):
            # r146: TMDb images need no provider login. They go straight to
            # the shared 6-slot queue (Twisted, plain-http TMDb) instead of
            # waiting in Ultra's 3-thread pool behind the provider posters
            # (that queue + 3.5 s HTTPS timeouts made Latest slow/empty while
            # Recommendations on the details page loaded instantly).
            if widget != 'logoImage' and "image.tmdb.org/t/p/" in str(url):
                try:
                    from .artwork_queue import _request_artwork_core
                    _request_artwork_core(url, cache_kind, done,
                                          priority=max(int(priority or 0), 120),
                                          errback=failed)
                    return
                except Exception:
                    pass
            def ultra_failed(_path, _url=url, _kind=cache_kind):
                # Retry once through the shared queue before the placeholder.
                try:
                    from .artwork_queue import _request_artwork_core
                    _request_artwork_core(_url, _kind, done, priority=110, errback=failed)
                except Exception:
                    failed(_path)
            try:
                from .genre_ultra_artwork import request as genre_ultra_request, request_transparent_logo
                if widget == 'logoImage':
                    request_transparent_logo(url, dict(self.source or {}), done, failed, self._queueGui)
                else:
                    genre_ultra_request(url, cache_kind, dict(self.source or {}),
                                        done, ultra_failed, self._queueGui)
                return
            except Exception:
                # No packaging/import failure may break the original images.
                pass
        request_artwork(
            url, cache_kind, done, priority=priority,
            errback=failed if (fallback_item is not None or widget == "hero" or widget == 'logoImage' or
                               (widget.startswith("backdrop") and widget[8:].isdigit())) else None,
            source=dict(self.source or {})
        )

    def decode(self, path, widget, width, height):
        if getattr(self, "_contentScreenDisposed", False):
            return
        expected_url = getattr(self, "_image_requests", {}).get(widget)
        selected_key = self._previewCacheKey(self.current()) if widget in ('hero', 'logoImage') else None
        loader = ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget, expected=expected_url, key=selected_key):
            try:
                valid = not getattr(self, "_contentScreenDisposed", False)
                if expected is not None:
                    valid = valid and getattr(self, "_image_requests", {}).get(w) == expected
                if key is not None:
                    valid = valid and self._previewCacheKey(self.current()) == key
                ptr = l.getData() if valid else None
                if ptr and self[w].instance:
                    if w == 'logoImage':
                        # A previous exact-size alpha paint turned scaling off;
                        # a decoder pixmap must be scaled into the box again
                        # (VTi otherwise draws it unscaled, off to the left).
                        try: self[w].instance.setScale(1)
                        except Exception: pass
                    self[w].instance.setPixmap(ptr)
                    current_item = None
                    if w in ('hero', 'logoImage'):
                        current_item = self.current()
                    elif re.fullmatch(r'latest[0-7]', str(w)):
                        index = self.latestStart + int(w[6:])
                        current_item = self.latest[index] if index < len(self.latest) else None
                    elif re.fullmatch(r'backdrop[0-3]', str(w)):
                        index = self.backdropStart + int(w[8:])
                        current_item = self.backdrops[index] if index < len(self.backdrops) else None
                    if current_item is not None:
                        identity = self._genreHeroIdentity(w, current_item)
                        if identity is not None:
                            decoded = getattr(self, '_genreHeroDecoded', None)
                            if decoded is None:
                                decoded = {}
                                self._genreHeroDecoded = decoded
                            decoded[w] = identity
                    pending = getattr(self, '_genreHeroPending', {}).get(w)
                    if pending and pending[1] == expected:
                        wins = getattr(self, '_genreHeroWins', None)
                        if wins is None:
                            wins = {}
                            self._genreHeroWins = wins
                        wins[w] = pending[0]
                    if getattr(self, "_fastMoviesPerformance", False) and expected is not None:
                        self._fastRenderedArtwork[w] = expected
                        if w in ('hero', 'logoImage') and current_item is not None:
                            self._keepPreviewPixmap(w, current_item, ptr, expected)
                    try:
                        self[w].show()
                    except Exception:
                        pass
                    if (getattr(self, "_fastMoviesPerformance", False) and
                            re.fullmatch(r"backdrop[0-3]", str(w))):
                        self._setBackdropCardVisual(int(w[-1]), True)
                    if str(w).startswith("latest") and str(w)[6:].isdigit():
                        _slot = int(str(w)[6:])
                        # Store only a native-decoder success. The index write
                        # is coalesced on its own background worker.
                        try:
                            from .poster_resolution_cache import remember_decoded
                            _index = self.latestStart + _slot
                            _row = self.latest[_index]
                            remember_decoded(self.source, self.kind, _row, expected)
                        except Exception:
                            pass
                        if getattr(self, "_classicPackageRailReady", False) and _slot < 6:
                            try:
                                self._syncClassicMovieFlag(_slot)
                            except Exception:
                                pass
                        # Current Backdrop+Latest uses the exact New Movies
                        # lower rail artwork. Never revive the old tiny shell
                        # or badge when a poster finishes decoding.
                        if not getattr(self, "_classicPackageRail", False):
                            for _name in ("latestShell%d" % _slot,
                                          "latestBadge%d" % _slot,
                                          "latestLabel%d" % _slot):
                                try:
                                    self[_name].show()
                                except Exception:
                                    try:
                                        self[_name].setVisible(True)
                                    except Exception:
                                        pass
                        try:
                            if str(self["latestRate%d" % _slot].getText() or "").strip():
                                self["latestRate%d" % _slot].show()
                        except Exception:
                            pass
                    if w == "logoImage":
                        try:
                            self["logoTitle"].hide()
                            self["logoHintIcon"].hide()
                            self["logoHint"].hide()
                        except Exception:
                            pass
                    elif w == "promoBanner":
                        try:
                            self["promoFrame"].show()
                            self["promoBanner"].show()
                        except Exception:
                            pass
                    if w == "hero" or re.fullmatch(r"backdrop[0-3]", w):
                        target = self._backdropRecoveryTarget(w)
                        state = getattr(self, "_sameMovieBackdropRetries", {}).get(w)
                        # Images are committed only after a successful ePicLoad,
                        # including normal TMDb links (not just retry links).
                        if (target and expected and
                                "image.tmdb.org/t/p/" in str(expected)):
                            item = target[1]
                            verified_id = str(item.get("tmdb_id") or item.get("tmdb") or "")
                            if (state and target[0] == state.get("identity") and
                                    state.get("tmdb_id")):
                                verified_id = str(state["tmdb_id"])
                            if verified_id.isdigit() and int(verified_id) > 0:
                                item["_tmdb_backdrop"] = re.sub(
                                    r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                                    r"\1w1280\2", str(expected), count=1)
                                item["tmdb_id"] = verified_id
                                # GENRE-speed reopening: persist only the exact
                                # successfully decoded TMDb image and verified ID.
                                # The write happens on a background worker, not
                                # the Enigma2 GUI thread; actual image bytes stay
                                # in the existing shared backdrop cache.
                                if getattr(self, "_fastMoviesPerformance", False):
                                    persisted_key = (verified_id, item["_tmdb_backdrop"])
                                    if item.get("_fast_verified_saved") != persisted_key:
                                        item["_fast_verified_saved"] = persisted_key
                                        _submit_content_bg(
                                            _cinematic_verified_put,
                                            args=(dict(self.source or {}), self.kind,
                                                  dict(item), item["_tmdb_backdrop"],
                                                  verified_id, str(item.get("_country_code") or "")),
                                            key=("cached-rail-backdrop", id(self),
                                                 _cinematic_verified_key(self.source, self.kind, item)))
                elif valid and (w == "hero" or re.fullmatch(r"backdrop[0-3]", w)
                                or re.fullmatch(r"latest[0-7]", w) or w == 'logoImage'):
                    if w == 'hero':
                        self._genreHeroRecover(w, self.current(), 'backdrop', width, height, expected)
                    elif w.startswith('backdrop'):
                        target = self._backdropRecoveryTarget(w)
                        self._genreHeroRecover(w, target[1] if target else None,
                                               'backdrop', width, height, expected)
                    elif w.startswith('latest'):
                        index = self.latestStart + int(w[6:])
                        item = self.latest[index] if index < len(self.latest) else None
                        self._genreHeroRecover(w, item, 'poster', width, height, expected)
                    else:
                        self._genreHeroRecover(w, self.current(), 'logo', width, height, expected)
            except Exception:
                pass
            # A late ePicLoad callback may arrive after Enigma2 has torn down
            # the screen attributes.  Never crash while releasing its loader.
            try:
                loaders = getattr(self, "picloads", None)
                if loaders is not None and l in loaders:
                    loaders.remove(l)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(loader, ready, self, oneshot=True); loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000")); loader.startDecode(path)

    def _setCardMeta(self, prefix, slot, item):
        # Large Movies/TV page: clean provider/quality/language prefixes for
        # every visible card label (Backdrop row and lower poster row) while
        # preserving the original server name inside the item for playback,
        # source matching and TMDb lookup.
        raw_title = str((item or {}).get("_display_title") or (item or {}).get("name") or (item or {}).get("title") or "").strip()
        limit = 30 if prefix == "backdrop" else 22
        title = visible_title(raw_title, limit) if raw_title else ""
        # Paint only valid ratings on the original Backdrop/Poster rails.
        # Do not allow provider "0" placeholders onto the original design.
        from .resolution_badge import extract_rating
        rating = extract_rating(item).replace("★", "").strip() if item else ""
        if prefix == "backdrop":
            self["%sLabel%d" % (prefix, slot)].setText("")
        elif prefix == "latest" and getattr(self, "_classicPackageRail", False):
            # Match new layout's _packageLabels(): title hidden, full ★ rating.
            self["%sLabel%d" % (prefix, slot)].setText("")
            self["%sRate%d" % (prefix, slot)].setText(extract_rating(item) if item else "")
            return
        else:
            self["%sLabel%d" % (prefix, slot)].setText(title)
        self["%sRate%d" % (prefix, slot)].setText(rating[:4])

    def _backdropFlagMemoryKey(self, item):
        """Scope reused country identities by source, media kind and film title/year."""
        item = item if isinstance(item, dict) else {}
        source = self.source if isinstance(self.source, dict) else {}
        title = self._backdropDisplayTitle(item.get("name") or item.get("title") or "")
        title = re.sub(r"\s+", " ", title).strip().casefold()
        if not title:
            return None
        year = str(self._year(item) or "")
        source_id = (str(source.get("type") or ""),
                     str(source.get("url") or source.get("portal") or
                         source.get("name") or ""),
                     str(source.get("username") or source.get("mac") or ""))
        return (source_id, self.kind, title, year)

    def _rememberBackdropFlagCountry(self, item, code):
        code = str(code or "").upper().strip()
        key = self._backdropFlagMemoryKey(item)
        if not key or not re.fullmatch(r"[A-Z]{2}", code) or code in ("XX", "GL"):
            return
        item["_country_code"] = code
        # This cache is in-process only. It never changes server lists/data.
        _BACKDROP_FLAG_COUNTRIES[key] = code
        _BACKDROP_FLAG_COUNTRIES.move_to_end(key)
        while len(_BACKDROP_FLAG_COUNTRIES) > _BACKDROP_FLAG_COUNTRIES_LIMIT:
            _BACKDROP_FLAG_COUNTRIES.popitem(last=False)

    def _countryCodeFromBackdropItem(self, item):
        item = item if isinstance(item, dict) else {}
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        vals = []
        for key in ("_country_code", "country_code", "origin_country", "country", "production_country", "production_countries"):
            v = item.get(key)
            if v:
                vals.append(v)
        for key in ("country_code", "origin_country", "country", "production_country", "production_countries"):
            v = info.get(key)
            if v:
                vals.append(v)
        names = {
            "united states":"US","usa":"US","us":"US","america":"US",
            "united kingdom":"GB","uk":"GB","great britain":"GB","england":"GB","britain":"GB",
            "france":"FR","germany":"DE","deutschland":"DE","spain":"ES","españa":"ES",
            "italy":"IT","canada":"CA","australia":"AU","ireland":"IE","netherlands":"NL",
            "belgium":"BE","sweden":"SE","norway":"NO","denmark":"DK","switzerland":"CH","austria":"AT",
            "mexico":"MX","brazil":"BR","argentina":"AR","japan":"JP","south korea":"KR","korea":"KR","china":"CN",
            "hong kong":"HK","taiwan":"TW","india":"IN","turkey":"TR","russia":"RU","ukraine":"UA",
            "saudi arabia":"SA","united arab emirates":"AE","egypt":"EG"
        }
        def norm_one(v):
            if isinstance(v, dict):
                v = v.get("iso_3166_1") or v.get("name") or v.get("iso") or ""
            v = str(v or "").strip()
            if re.match(r'^[A-Za-z]{2}$', v):
                return v.upper()
            return names.get(v.lower(), "")
        for v in vals:
            if isinstance(v, (list, tuple)):
                for sub in v:
                    code = norm_one(sub)
                    if code:
                        return code
            else:
                code = norm_one(v)
                if code:
                    return code
        return ""

    def _setBackdropFlag(self, slot, item, force=False):
        try:
            slot = int(slot)
            if not 0 <= slot < 4:
                return
            widget = self["backdropFlag%d" % slot]
            row = item if isinstance(item, dict) else {}
            code = self._countryCodeFromBackdropItem(row) if row else ""
            if not re.match(r"^[A-Z]{2}$", code or "") or code in ("XX", "GL"):
                code = ""
            # Same movie opened from a different tab: use the country verified
            # while the first screen was shown; do not launch a second lookup.
            if not code:
                memory_key = self._backdropFlagMemoryKey(row)
                code = _BACKDROP_FLAG_COUNTRIES.get(memory_key, "") if memory_key else ""
                if code:
                    row["_country_code"] = code
            if code:
                self._rememberBackdropFlagCountry(row, code)
            # Keep the card identity stable when TMDb resolves a movie/series ID
            # after the provider list is displayed.  Previously tmdb_id won
            # over stream_id; the transition falsely looked like a new card,
            # forcing show_country_flag() to hide and decode an existing flag.
            identity = str(row.get("stream_id") or row.get("series_id") or
                           row.get("id") or row.get("name") or
                           row.get("title") or row.get("tmdb_id") or
                           row.get("tmdb") or "")
            # An item can acquire its verified TMDb ID *after* its provider
            # backdrop has painted. Include the ID in the flag identity so
            # this important metadata change retries the flag lookup. Without
            # it, a first render with no country/ID permanently suppresses the
            # flag even after the ID is resolved in the background.
            info_data = row.get("info") if isinstance(row.get("info"), dict) else {}
            tmdb_id = str(row.get("tmdb_id") or row.get("_locked_tmdb_id") or
                          row.get("_tmdb_id") or row.get("tmdb") or row.get("tmdbid") or
                          info_data.get("tmdb_id") or info_data.get("tmdb") or "").strip()
            token = (identity, code, self.kind, tmdb_id)
            keys = getattr(self, "_cardFlagKeys", None)
            if keys is None:
                keys = {}
                self._cardFlagKeys = keys
            old_token = keys.get(slot)
            if old_token == token and not force:
                # A previous request may already have decoded the correct flag.
                # A late result must never be replaced with an older card.
                return
            if old_token and old_token[0] == identity and old_token[2] == self.kind:
                # A second, partial provider/cache update is not evidence that
                # the country changed. Keep its displayed flag instead of
                # unnecessarily hiding it and starting a TMDb request.
                if old_token[1] and not code:
                    return
                if not old_token[1] and code:
                    # The background lookup may already have produced this
                    # exact flag.  Don't clear a visible, correctly resolved
                    # flag just because the metadata now includes its code.
                    rendered = getattr(widget, "_tivimate_flag_rendered", None)
                    active = getattr(widget, "_tivimate_flag_token", None)
                    if rendered is not None and rendered == active:
                        keys[slot] = token
                        return
            keys[slot] = token
            info = {"origin_country": [code]} if code else {}
            # Pass the verified country back to the SAME row and shared
            # navigation index only after the current flag token is accepted.
            def remember_verified(resolved_code, source_row=row, slot_identity=identity):
                index = self.backdropStart + slot
                if (self._contentScreenDisposed or index >= len(self.backdrops) or
                        self.backdrops[index] is not source_row):
                    return
                current_name = str(source_row.get("stream_id") or source_row.get("series_id") or
                                   source_row.get("id") or source_row.get("name") or
                                   source_row.get("title") or source_row.get("tmdb_id") or
                                   source_row.get("tmdb") or "")
                if current_name == slot_identity:
                    self._rememberBackdropFlagCountry(source_row, resolved_code)

            show_country_flag(widget, info, ("tv" if self.kind == "series" else "movie"), tmdb_id,
                              visible_when=lambda w=widget, s=slot: (
                                  getattr(w, "_tivimate_flag_token", None) is not None
                                  and (not getattr(self, "_fastMoviesPerformance", False)
                                       or s in getattr(self, "_backdropCardReadySlots", set()))),
                              gui_dispatch=self._queueGui, on_resolved=remember_verified)
        except Exception:
            try:
                self["backdropFlag%d" % int(slot)].hide()
            except Exception:
                pass

    def renderBackdrops(self):
        visible = []
        # The same fallback image is reused across cards from local plugin
        # storage. It is never downloaded or stored in the image cache.
        fallback_slots = getattr(self, "_backdropFallbackSlots", None)
        if fallback_slots is None:
            fallback_slots = {}
            self._backdropFallbackSlots = fallback_slots
        fallback_file = os.path.join(PLUGIN_PATH, "skins", "movies",
                                     "latest_backdrop_fallback_406x206.jpg")
        for slot in range(4):
            idx = self.backdropStart + slot
            item = self.backdrops[idx] if idx < len(self.backdrops) else None
            # Backdrop ranking badge: #1 .. #12 follows the actual rail order.
            self["rank%d" % slot].setText((("#%d" if idx < 9 else "%d") % (idx + 1)) if item else "")  # r146: "#10" wrapped to "#1"
            if getattr(self, "_fastMoviesPerformance", False):
                # Item+slot identity survives repeated rail renders.  Leave the
                # already decoded pixmap (or in-flight request) in place.
                identity = (idx, str((item or {}).get("stream_id") or
                    (item or {}).get("series_id") or (item or {}).get("id") or
                    (item or {}).get("name") or (item or {}).get("title") or ""))
                if self._fastBackdropSlots.get(slot) != identity:
                    self._fastBackdropSlots[slot] = identity
                    self._fastRenderedArtwork.pop("backdrop%d" % slot, None)
                    self._setBackdropCardVisual(slot, False)
                    # Invalidate callbacks still downloading the previous slot.
                    self._image_requests.pop("backdrop%d" % slot, None)
                    # Check the *selected real backdrop* in the shared cache
                    # BEFORE painting a local fallback. The normal visible-art
                    # loader below will decode a cache hit immediately: do not
                    # flash the placeholder over an already downloaded image.
                    # This local-only check never starts another artwork job.
                    cached_real = False
                    if item:
                        try:
                            art_url = self.imageUrl(item, True)
                            if art_url and "image.tmdb.org/t/p/" in str(art_url):
                                art_url = re.sub(
                                    r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                                    r"\1w780\2", str(art_url), count=1)
                            art_file = cached_artwork(art_url, "backdrops") if art_url else None
                            if not (art_file and os.path.isfile(art_file)) and art_url and "image.tmdb.org/t/p/" in str(art_url):
                                art_file = cached_artwork(art_url, "backdrop_cards")
                            cached_real = bool(art_file and os.path.isfile(art_file))
                        except Exception:
                            cached_real = False
                    # Missing/remote-only images keep the instant, tiny local
                    # fallback until a real backdrop finishes decoding.
                    if item and not cached_real and os.path.isfile(fallback_file):
                        self.setPlaceholder("backdrop%d" % slot,
                                            "movies/latest_backdrop_fallback_406x206.jpg")
                        fallback_slots[slot] = (idx, id(item))
                    else:
                        fallback_slots.pop(slot, None)
                        self.setPlaceholder("backdrop%d" % slot,
                                            "trend_transparent_placeholder.png")
            else:
                fallback_slots.pop(slot, None)
                self.setPlaceholder("backdrop%d" % slot, "trend_transparent_placeholder.png")
            self._setCardMeta("backdrop", slot, item)
            if (getattr(self, "_fastMoviesPerformance", False) and item and
                    fallback_slots.get(slot) == (idx, id(item))):
                # Only a real movie/series slot can display its default picture.
                self._setBackdropCardVisual(slot, True)
            if getattr(self, "_fastMoviesPerformance", False) and not item:
                self._setBackdropCardVisual(slot, False)
            try:
                if item:
                    self._setBackdropFlag(slot, item)
                else:
                    self["backdropFlag%d" % slot].hide()
                    self["backdropFlag%d" % slot]._tivimate_flag_token = None
                    self._cardFlagKeys.pop(slot, None)
            except Exception:
                pass
            if item:
                visible.append((slot, item))

        # A rail page change must also get a fresh recovery window; don't
        # only schedule retries for the first four cards on initial entry.
        if getattr(self, "_fastMoviesPerformance", False):
            view = (self.contentGeneration, self.kind, self.backdropStart,
                    tuple(id(item) for _slot, item in visible))
            if visible and view != getattr(self, "_backdropFlagRetryView", None):
                self._backdropFlagRetryView = view
                self._scheduleBackdropFlagRetry()
            elif not visible:
                self._backdropFlagRetryView = None
                self._stopBackdropFlagRetry()

        # Resolve TMDb information strictly one-by-one.  As soon as each item
        # has its final backdrop URL, hand the image to the normal artwork
        # queue; image downloads themselves remain parallel/fast.
        self._startBackdropMetadataResolve(visible)

    def _startBackdropMetadataResolve(self, visible):
        rows = [(int(slot), item) for slot, item in list(visible or []) if isinstance(item, dict)]
        if not rows:
            return
        lookup_generation = self.contentGeneration
        lookup_start = self.backdropStart

        token = "%s:%s:%s:%s" % (
            str(self.contentGeneration),
            str(self.kind or ""),
            str(self.backdropStart),
            "|".join(str(
                (item or {}).get("stream_id") or
                (item or {}).get("series_id") or
                (item or {}).get("id") or
                (item or {}).get("name") or
                (item or {}).get("title") or ""
            ) for _slot, item in rows)
        )
        # Fast Movies and TV Shows resolve each card independently. A failed
        # card can be replaced without cancelling TMDb responses for the other
        # three visible cards. Non-fast pages keep their original group token.
        fast_tokens = None
        if getattr(self, "_fastMoviesPerformance", False):
            fast_tokens = getattr(self, "_backdropMetadataSlotTokens", None)
            if fast_tokens is None:
                fast_tokens = {}
                self._backdropMetadataSlotTokens = fast_tokens
            for slot, item in rows:
                fast_tokens[slot] = (lookup_generation, self.kind,
                                     lookup_start + slot, id(item))
        else:
            self._backdropMetadataToken = token

        def slot_valid(slot, item):
            if (self._contentScreenDisposed or
                    self.contentGeneration != lookup_generation or
                    self.backdropStart != lookup_start):
                return False
            index = lookup_start + int(slot)
            if not (0 <= index < len(self.backdrops) and
                    self.backdrops[index] is item):
                return False
            if fast_tokens is not None:
                return fast_tokens.get(slot) == (lookup_generation, self.kind,
                                                 index, id(item))
            return token == getattr(self, "_backdropMetadataToken", "")

        def apply_one(slot, item, backdrop, resolved_id, server_fallback, country_code=""):
            if not slot_valid(slot, item):
                return
            index = lookup_start + int(slot)
            if (index < 0 or index >= len(self.backdrops) or
                    self.backdrops[index] is not item):
                return
            try:
                if backdrop and resolved_id:
                    item["tmdb_id"] = resolved_id
                if country_code:
                    item["_country_code"] = country_code
            except Exception:
                pass
            try:
                self._setBackdropFlag(slot, item)
            except Exception:
                pass

            final_url = server_fallback or backdrop
            if not final_url:
                # This candidate has neither a provider landscape image nor
                # a matched TMDb backdrop. Do not waste one of the visible
                # rail slots on a permanently empty picture. Remove only
                # this *screen instance*; never write negative image results
                # to disk (a temporary TMDb outage must not blacklist titles).
                if getattr(self, "_fastMoviesPerformance", False):
                    self._skipEmptyBackdropCard("backdrop%d" % slot)
                return
            if final_url:
                # Small Movies/Series cards are only 410x210.  Use TMDb w780
                # here to reduce transfer size; large/details backdrops keep w780.
                if "image.tmdb.org/t/p/" in str(final_url):
                    final_url = re.sub(
                        r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                        r"\1w780\2",
                        str(final_url),
                        count=1
                    )
                # Keep the first visible image if metadata has the same URL.
                widget = "backdrop%d" % slot
                if getattr(self, "_image_requests", {}).get(widget) != final_url:
                    self.loadImage(final_url, widget, 520, 260)

        def worker(single_row=None):
            try:
                tmdb = TMDbClient()
            except Exception:
                tmdb = None

            # Fast Movies checks the four displayed titles independently;
            # slow TMDb lookup of #1 must not block image #2/#3/#4.
            # All screens other than Fast Movies retain the old serial path.
            for slot, item in ([single_row] if single_row is not None else rows):
                if not slot_valid(slot, item):
                    # Do not cancel the sibling cards when this one is replaced.
                    if single_row is not None:
                        return
                    continue

                backdrop = self.norm(item.get("_tmdb_backdrop") or "")
                resolved_id = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
                server_fallback = self.imageUrl(item, True)
                if item.get("_backdrop_metadata_checked") and (backdrop or server_fallback):
                    self._queueGui(
                        apply_one, slot, item, backdrop, resolved_id,
                        server_fallback, self._countryCodeFromBackdropItem(item)
                    )
                    continue
                # A missing/not-yet-reachable artwork source is not a successful
                # image cache. Bound repeated TMDb work on this screen only;
                # retry after a short window or on the next screen opening.
                if (getattr(self, "_fastMoviesPerformance", False) and
                        not backdrop and not server_fallback and
                        time.time() < float(item.get("_backdrop_retry_after") or 0)):
                    continue

                # Server-first for both Movies and TV Shows.  Resolve TMDb
                # metadata independently for ID/country; never let a later
                # TMDb response replace a usable provider landscape image.

                # Cached TMDb backdrop needs no metadata request.
                if backdrop:
                    self._queueGui(
                        apply_one, slot, item, backdrop, resolved_id, server_fallback, self._countryCodeFromBackdropItem(item)
                    )
                    continue
                # r146: the provider's own landscape image is downloaded NOW.
                # TMDb below only adds the id/country flag; the picture used
                # to wait for 1-3 TMDb requests per card (Recommendations
                # never waited, so they appeared much faster).
                if server_fallback:
                    self._queueGui(apply_one, slot, item, "", resolved_id, server_fallback, "")

                raw_title = str(
                    item.get("name") or item.get("title") or
                    item.get("original_title") or item.get("original_name") or ""
                ).strip()

                if tmdb is not None and raw_title:
                    try:
                        kind = self.kind
                        year = self._year(item) or None
                        data = {}

                        # Fast path: provider already supplied a TMDb ID.
                        if resolved_id:
                            try:
                                data = tmdb.details_bundle(resolved_id, kind) or {}
                            except Exception:
                                data = {}
                            backdrop = self.norm(data.get("backdrop_path") or "")
                            if not backdrop:
                                alternatives = self._sameMovieBackdropPaths(
                                    tmdb, resolved_id, data)
                                if alternatives:
                                    backdrop = self.norm(alternatives[0])

                        # Otherwise resolve title/year, then fetch the exact details.
                        if not backdrop:
                            found = {}
                            try:
                                found = tmdb.search_title(raw_title, kind, year) or {}
                            except Exception:
                                found = {}
                            if not found:
                                try:
                                    found = tmdb.search_title(raw_title, kind, None) or {}
                                except Exception:
                                    found = {}

                            rid = str(
                                (found or {}).get("id") or
                                (found or {}).get("tmdb_id") or ""
                            ).strip()
                            if rid:
                                resolved_id = rid
                                # A verified TMDb search row already carries
                                # its real landscape backdrop. Exactly like
                                # GENRE, request the image immediately rather
                                # than waiting for an extra details_bundle HTTP
                                # request for each of the visible four cards.
                                if getattr(self, "_fastMoviesPerformance", False):
                                    backdrop = self.norm((found or {}).get("backdrop_path") or "")
                                if not backdrop:
                                    try:
                                        data = tmdb.details_bundle(resolved_id, kind) or {}
                                    except Exception:
                                        data = {}

                            backdrop = backdrop or self.norm(
                                (data or {}).get("backdrop_path") or
                                (found or {}).get("backdrop_path") or ""
                            )
                        if not backdrop and resolved_id:
                            alternates = self._sameMovieBackdropPaths(
                                tmdb, resolved_id, data)
                            if alternates:
                                backdrop = self.norm(alternates[0])
                    except Exception:
                        backdrop = ""

                # Reusing this row in the carousel must not repeat a failed
                # title search on every keypress.
                item["_backdrop_metadata_checked"] = True
                if not backdrop and not server_fallback and getattr(self, "_fastMoviesPerformance", False):
                    item["_backdrop_retry_after"] = time.time() + 150
                else:
                    item.pop("_backdrop_retry_after", None)
                # Queue image immediately, then continue resolving metadata for
                # the next item.  Image downloading is not serialized.
                country_code = ""
                try:
                    pc = (data or {}).get("production_countries") or []
                    if isinstance(pc, list) and pc:
                        first = pc[0]
                        if isinstance(first, dict):
                            country_code = str(first.get("iso_3166_1") or "").upper().strip()
                    if not country_code:
                        oc = (data or {}).get("origin_country") or []
                        if isinstance(oc, list) and oc:
                            country_code = str(oc[0] or "").upper().strip()
                except Exception:
                    country_code = ""
                self._queueGui(
                    apply_one, slot, item, backdrop, resolved_id, server_fallback, country_code
                )

        if getattr(self, "_fastMoviesPerformance", False):
            for slot, item in rows:
                _submit_content_bg(
                    worker, args=((slot, item),),
                    key=("fast-backdrop-meta", id(self), slot, token),
                    backdrop=True
                )
        else:
            _submit_content_bg(
                worker,
                key=("backdrop-metadata-seq", id(self), token)
            )

    def renderLatest(self):
        # Exactly six cards in the Current backdrop+package rail. The other
        # (new/grid) designs retain their own paging and image queues.
        visible = 6 if getattr(self, "_classicPackageRail", False) else 8
        for slot in range(visible):
            idx = self.latestStart + slot
            item = self.latest[idx] if idx < len(self.latest) else None
            if getattr(self, "_fastMoviesPerformance", False):
                # Avoid clearing and downloading the same poster for an
                # unchanged visible slot. New pages still render normally.
                url = self.imageUrl(item, False) if item else ""
                identity = (idx, str((item or {}).get("stream_id") or
                    (item or {}).get("series_id") or (item or {}).get("id") or
                    (item or {}).get("name") or (item or {}).get("title") or ""), url)
                if self._fastPosterSlots.get(slot) == identity:
                    continue
                self._fastPosterSlots[slot] = identity
                self._fastRenderedArtwork.pop("latest%d" % slot, None)
                self._image_requests.pop("latest%d" % slot, None)
            # The lower 8-poster rail uses static shell/rating artwork, so
            # could not hide its gray/black loading blocks. Keep all card chrome
            # invisible until the real poster decode succeeds.
            for _name in ("latestShell%d" % slot, "latestBadge%d" % slot,
                          "latestLabel%d" % slot, "latestRate%d" % slot):
                try:
                    self[_name].hide()
                except Exception:
                    try:
                        self[_name].setVisible(False)
                    except Exception:
                        pass
            if getattr(self, '_classicPackageRailReady', False):
                self._classicFlagsIdentity.pop(slot, None)
                self['classicMovieFlag%d' % slot].hide()
            if getattr(self, "_classicPackageRail", False):
                # Match NewMoviesContentScreen.renderLatest(): while a new
                # poster is pending, hide the previous pixmap. The old
                # transparent PNG placeholder could leave a small ghost box
                # during a page change on some Enigma2 renderers.
                try:
                    self["latest%d" % slot].hide()
                except Exception:
                    pass
            else:
                self.setPlaceholder("latest%d" % slot, "poster_loading_transparent_r410.png")
            self._setCardMeta("latest", slot, item)
            if item:
                url = self.imageUrl(item, False)
                self.loadImage(url, "latest%d" % slot,
                               165 if getattr(self, "_classicPackageRail", False) else
                               (182 if getattr(self, "OLD_LATEST_RAIL_TOP", 0) == 811 else 170),
                               248 if getattr(self, "_classicPackageRail", False) else
                               (219 if getattr(self, "OLD_LATEST_RAIL_TOP", 0) == 811 else 205),
                               fallback_item=item)
        # Visible eight posters load normally above. Prefetch only
        # the next two cards, instead of the entire Content Home list.
        if not getattr(self, "_fastMoviesPerformance", False):
            _next = []
            for _item in (self.latest or [])[self.latestStart + 8:self.latestStart + 10]:
                _url = self.imageUrl(_item, False)
                if _url:
                    _next.append(_url)
            if _next:
                prefetch_artwork(_next, "posters", priority=2)
        if self.kind == "vod" and not getattr(self, "_fastMoviesPerformance", False):
            # Fast Movies resolves visible backdrops independently and sends
            # the selected hero through a dedicated worker. Extra background
            # TMDb warm searches compete with cards and offer no immediate UI
            # benefit; leave them enabled on other ContentHome layouts only.
            self._prefetchTmdbMetadata(self.latest, self.latestStart, 2)

    def _prefetchTmdbMetadata(self, items, start, count):
        """Warm cache for visible Movies metadata without touching Enigma2 widgets.

        TMDbClient already owns persistent search/details caches.  This method
        only advances those cache hits into the background and mirrors them in
        the small in-session details LRU used by More Info.
        """
        if self.kind != "vod":
            return
        rows = []
        for item in (items or [])[start:start + max(0, int(count or 0))]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("name") or item.get("title") or item.get("original_title") or "").strip()
            if not title:
                continue
            year = self._year(item) or 0
            tid = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
            norm = self._normTitle(title)
            key = "%s|%s|%s" % (tid, norm, str(year or ""))
            if not key or key in self._metadataWarmKeys:
                continue
            # The warm-key set is per page and otherwise grows without limit
            # while paging thousands of movie titles. Disk TMDb cache persists.
            if len(self._metadataWarmKeys) >= 128:
                self._metadataWarmKeys.clear()
            self._metadataWarmKeys.add(key)
            rows.append((dict(item), title, year, tid, norm))
        if not rows:
            return

        def worker(batch=rows):
            try:
                tmdb = TMDbClient()
            except Exception:
                return
            for row, title, year, tid, norm in batch:
                try:
                    found = {}
                    resolved = tid
                    if not resolved:
                        found = tmdb.search_title(title, "vod", year or None) or {}
                        if not found:
                            found = tmdb.search_title(title, "vod", None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if not resolved:
                        continue
                    bundle = tmdb.details_bundle(resolved, "vod") or {}
                    if found:
                        seeded = dict(found)
                        seeded.update(bundle or {})
                        bundle = seeded
                    if not bundle:
                        continue
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("vod:%s" % resolved), bundle, _DETAILS_DATA_CACHE_LIMIT)
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("vod:title:%s:%s" % (norm, str(year or ""))), bundle, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue

        _submit_content_bg(worker, key=("movie-metadata-warm", id(self)))

    def _prefetchCards(self, items, start, count, backdrop=False, priority=5):
        """Warm only the next page at a low priority without decoding it yet.

        The queue writes the original JPEG/PNG response to disk, so this changes
        timing only; it never alters image dimensions, compression, or poster art.
        """
        for item in (items or [])[start:start + count]:
            try:
                url = self.imageUrl(item, backdrop)
                if url:
                    request_artwork(url, "backdrops" if backdrop else "posters", None,
                                    priority=priority, source=dict(self.source or {}))
            except Exception:
                pass


    def _alignTopSelector(self):
        try:
            index = max(0, min(self.topIndex, len(self.TOP_X) - 1))
            cell_w = self.TOP_W[index]
            x = self.TOP_X[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
        except Exception:
            pass


    def updateFocus(self):
        try:
            self._alignTopSelector(); self["topSelector"].setVisible(self.focus == "top")
            self["backdropSelector"].instance.move(ePoint(sx(self.BACKDROP_X[self.backdropIndex]), sy(555))); self["backdropSelector"].setVisible(self.focus == "backdrops" and bool(self.backdrops))
            self["latestSelector"].instance.move(ePoint(sx(self.LATEST_X[self.latestIndex]), sy(getattr(self, "OLD_LATEST_RAIL_TOP", 825)))); self["latestSelector"].setVisible(self.focus == "latest" and bool(self.latest))
        except Exception: pass

    def preview(self):
        item = self.current()
        if not item:
            return
        try:
            self["hero"].show()
        except Exception:
            pass
        # Every move gets a new token.  It guarantees that a slower lookup for
        # a previous poster cannot overwrite the backdrop of the current movie.
        self._previewRequestId += 1
        request_id = self._previewRequestId
        # Display-only cleanup for the selected title too. Do not mutate the
        # original server title used by playback/search.
        raw_title = item.get("name") or item.get("title") or ""
        title = visible_title(raw_title, 34).upper()
        # Every selection invalidates both artwork slots. Never display the
        # previous title's clearlogo or promo image while fetching a new title.
        self._image_requests.pop("logoImage", None)
        self._image_requests.pop("promoBanner", None)
        self["logoTitle"].setText(title)
        self["logoTitle"].show()
        self["logoImage"].hide()
        self["promoBanner"].hide()
        self["promoFrame"].hide()
        self["logoHintIcon"].hide()
        self["logoHint"].hide()
        # Only fanart.tv moviebanner/tvbanner URLs are ever used in this slot.
        # Do not reuse old TMDb pseudo-fanart cache or backdrop_path.
        banner = str(item.get("_fanart_tv_banner") or "").strip()
        if banner:
            self.loadImage(banner, "promoBanner", 288, 54)
        # Large-details metadata policy for the first paint. No network or
        # image decoding here; a late TMDb result changes text only.
        initial = merge_metadata(item, language=TMDbClient().language, kind=self.kind)
        year = initial["year"]
        genre = initial["genre"]
        rating = initial["rating"]
        self._information_badge_preview_rating = rating or ''
        parts = [year]
        if self.kind != "series" and rating:
            parts.append("★ " + str(rating)[:4])
        parts.append(genre)
        self["heroMeta"].setText("   •   ".join(x for x in parts if x))
        self["heroDesc"].setText(_hero_preview_summary(initial["description"]))
        # Re-display the actual decoded Enigma2 pixmap without ePicLoad or
        # another image lookup when navigating back to a recently viewed title.
        hero_ready = self._restorePreviewPixmap('hero', item)
        logo_ready = self._restorePreviewPixmap('logoImage', item)
        cached_metadata = self._getPreviewMetadata(item)
        if cached_metadata:
            self._applyPreviewMetadata(cached_metadata, request_id, from_cache=True)
        if not hero_ready:
            if self.focus == "latest" and self.kind in ("vod", "series"):
                # Latest Movies/TV Shows use the same GENRE recovery path as
                # the GENRE page: provider/cache candidates first, then the
                # shared GENRE downloader and exact-title TMDb fallback.
                self._image_requests.pop('hero', None)
                self._genreHeroRecover('hero', item, 'backdrop', 1920, 1080)
            else:
                back = self.imageUrl(item, True)
                if back:
                    self.loadImage(back, "hero", 1920, 520)
                else:
                    self._image_requests.pop('hero', None)
                    self._genreHeroRecover('hero', item, 'backdrop', 1920, 1080)
        # Resolve metadata and transparent logos only after selection settles;
        # do not enqueue a logo request for every rapid arrow press.
        # the selection stops moving; no network activity on the GUI thread.
        self._previewBackdropPending = (dict(item), request_id, not hero_ready, not logo_ready)
        # Both images and the localized metadata are already available.
        # No TMDb title search, provider detail request, or decode is needed.
        if hero_ready and logo_ready and cached_metadata:
            self._previewBackdropPending = None
            self._categorySwitchPreviewNow = False
            try:
                self._previewBackdropTimer.stop()
            except Exception:
                pass
            return
        if getattr(self, "_categorySwitchPreviewNow", False):
            self._categorySwitchPreviewNow = False
            try:
                self._previewBackdropTimer.stop()
            except Exception:
                pass
            self._beginPreviewBackdropLookup()
        else:
            try:
                self._previewBackdropTimer.stop()
                self._previewBackdropTimer.start(180, True)
            except Exception:
                self._beginPreviewBackdropLookup()

    def _beginPreviewBackdropLookup(self):
        pending = self._previewBackdropPending
        self._previewBackdropPending = None
        if not pending:
            return
        item, request_id, need_backdrop, need_logo = pending
        if request_id != self._previewRequestId:
            return
        selected = self.current()
        if need_logo and isinstance(selected, dict):
            # Same GENRE clearlogo candidate selection and transparency loader.
            # Provider info can be cached even if TMDb has no localized logo.
            self._genreHeroRecover('logoImage', selected, 'logo',
                                   680 if self.kind == 'vod' else 620,
                                   106 if self.kind == 'vod' else 96)
        _submit_content_bg(
            self._lookupPreviewArtwork,
            args=(item, request_id, need_backdrop, need_logo),
            key=("preview-artwork", id(self)),
            hero=bool(getattr(self, "_fastMoviesPerformance", False))
        )

    def _recoverSelectedPreview(self, request_id, widget, media, width, height):
        """Attach asynchronous GENRE recovery to the actual selected row.

        Background metadata lookups operate on detached dictionaries; those
        copies cannot pass _genreHeroIdentity's stale-selection guard.
        """
        if request_id != self._previewRequestId or self._contentScreenDisposed:
            return
        item = self.current()
        if isinstance(item, dict):
            self._genreHeroRecover(widget, item, media, width, height)

    def _movieBackdropUrl(self, data):
        data = data or {}
        return self.norm(
            data.get("backdrop_path") or data.get("backdrop") or
            data.get("backdrop_url") or data.get("movie_backdrop")
        )

    def _bundleLogoUrl(self, data):
        images = (data or {}).get("images") or {}
        return tmdb_logo_url(best_tmdb_logo(images.get("logos") or [], preferred_logo_languages(details=data)), "w500")

    def _startPreviewBannerLookup(self, tmdb_id, bundle, request_id):
        """Resolve true banner without blocking the hero/clearlogo worker."""
        if not read_fanart_banner_key() or request_id != self._previewRequestId:
            return
        kind = self.kind
        # Use the same shared worker pool as other content enrichment.
        # Superseded requests are dropped before their network work starts.
        def worker():
            if request_id != self._previewRequestId:
                return
            banner = fetch_banner(TMDbClient(), kind, tmdb_id, bundle, logo_language())
            if banner and request_id == self._previewRequestId:
                self._queueGui(self._applyPreviewArtwork, "", "", request_id, banner)
        _submit_content_bg(worker, key=("preview-banner", id(self)))

    def _lookupPreviewArtwork(self, item, request_id, need_backdrop=True, need_logo=True, force_tmdb_backdrop=False):
        """Portal/server first, then TMDb enhancement without holding the UI.

        A server backdrop is applied as soon as it is available. If TMDb search
        provides a backdrop, that is also applied before the slower full details
        request used for transparent logos and richer metadata. Stale requests
        are discarded by request_id, matching EStalker's fast navigation model.
        """
        try:
            if request_id != getattr(self, "_previewRequestId", request_id):
                return
            # r233: do not block Movies hero navigation on provider vod_info().
            # TV Shows were already fast because they went straight from the
            # visible row to TMDb cache. Movies now use that same path. Existing
            # server metadata in the row remains an immediate fallback.
            details = dict(item or {})
            if isinstance(item.get("info"), dict):
                details.update(item.get("info") or {})

            # A GENRE-style cached verified backdrop should paint before any
            # TMDb title/details/logo requests. The selected item may have been
            # resolved previously by the visible rail or Movie/TV details.
            known_backdrop = str(details.get("_tmdb_backdrop") or "").strip()
            # Cross-page disk-only TMDb artwork index, supplied by verified
            # metadata stored for the selected movie/TV title.
            known_verified_id = ''
            try:
                stored_identity = self._getPreviewMetadata(item)
                if isinstance(stored_identity, dict):
                    known_verified_id = stored_identity.get('id') or stored_identity.get('tmdb_id') or ''
                if need_backdrop and known_verified_id:
                    from .identity_artwork_index import cached_url
                    identity_backdrop = cached_url(self.kind, known_verified_id, 'backdrop')
                    if identity_backdrop:
                        known_backdrop = identity_backdrop
            except Exception:
                pass
            if not known_backdrop and need_backdrop:
                try:
                    saved = _cinematic_verified_get(self.source, self.kind, details)
                    known_backdrop = str(saved.get("url") or "").strip()
                    if known_backdrop and saved.get("tmdb_id"):
                        details["tmdb_id"] = saved["tmdb_id"]
                except Exception:
                    pass
            server_backdrop = self._movieBackdropUrl(details) if (need_backdrop and not force_tmdb_backdrop) else ""
            # Resolve relative provider backdrops against the active server.
            if server_backdrop and not item.get("_tmdb"):
                server_backdrop = _server_asset_url(self.source, server_backdrop)
            if server_backdrop and server_backdrop == item.get("_fast_invalid_backdrop_url"):
                server_backdrop = ""
            raw_title = (details.get("name") or details.get("title") or
                         item.get("name") or item.get("title") or "")
            server_logo = self._bundleLogoUrl(details) if need_logo else ""
            # Disk-only identity-logo preflight before the TMDb title search or
            # details request. The ID must come from previously verified TMDb
            # metadata (or the selected bundle), NEVER a portal stream ID.
            if need_logo:
                try:
                    from .title_logo_ultra_bridge import cached_identity_logo
                    known_id = details.get('tmdb_id') or details.get('tmdb')
                    stored_bundle = self._getPreviewMetadata(item)
                    if isinstance(stored_bundle, dict):
                        known_id = stored_bundle.get('id') or stored_bundle.get('tmdb_id') or known_id
                    if known_id:
                        local_logo = cached_identity_logo(
                            self.kind, known_id, (600, 104),
                            title=raw_title, details=stored_bundle or details, item=item,
                            cancelled=lambda: request_id != self._previewRequestId,
                            preferred_only=True)
                        if local_logo and request_id == self._previewRequestId:
                            self._queueGui(self._applyPreviewTitleLogoPath, local_logo, request_id)
                except Exception:
                    pass
            # Cache-first across *all currently known* Hero URLs, not just the
            # first provider URL. Use metadata already stored on disk/memory;
            # never wait for a fresh TMDb request before showing a cached image.
            known_meta = self._getPreviewMetadata(item) if isinstance(item, dict) else None
            cached_backdrop_url = (self._movieBackdropUrl(known_meta)
                                   if isinstance(known_meta, dict) and need_backdrop else "")
            # Prefer the connected server's backdrop even if a TMDb fallback
            # happens to be cached already.  The normal GENRE recovery path
            # tries TMDb if this server image fails validation/download.
            backdrop_urls = ([server_backdrop] if server_backdrop else
                cached_candidates_first((known_backdrop, cached_backdrop_url), 'backdrops')) if need_backdrop else []
            if backdrop_urls:
                self._queueGui(self._applyPreviewArtwork, backdrop_urls[0], "", request_id)
            # Keep the Arabic-logo preference. A known cached server logo may
            # show immediately, and TMDb can still replace it with Arabic later.
            if server_logo and (logo_language() == "en" or
                                has_language_logo((details.get("images") or {}).get("logos") or [], logo_language())):
                self._queueGui(self._applyPreviewArtwork, "", server_logo, request_id)
            if request_id != self._previewRequestId:
                return

            # Cached, verified artwork can display immediately. Keep metadata
            # enrichment independent, but skip *extra* image-gallery lookup.
            cached_backdrop_ready = bool(known_verified_id and known_backdrop and
                cached_artwork(known_backdrop, 'backdrops'))
            # TMDb remains the fallback, not an automatic replacement for a
            # provider URL which is still being decoded/downloaded.
            need_tmdb_backdrop = bool(need_backdrop and not server_backdrop and not cached_backdrop_ready)
            # A server English logo must not suppress a genuine Arabic logo.
            need_tmdb_logo = bool(need_logo)

            # Metadata is intentionally independent from artwork. Even when the
            # server already supplied backdrop/logo, Movies/Series metadata must
            # still prefer TMDb and use server fields only as fallback.
            tmdb = TMDbClient()
            tmdb_id = details.get("tmdb_id") or details.get("tmdb") or item.get("tmdb_id") or item.get("tmdb")
            found = {}
            # Read the same selected row's fresh details cache; the expensive
            # TMDb title search/details_bundle need not run on every keypress.
            selected = self.current()
            cached_bundle = (self._getPreviewMetadata(selected)
                             if request_id == self._previewRequestId and isinstance(selected, dict) and
                             str(selected.get('name') or selected.get('title') or '') ==
                             str(item.get('name') or item.get('title') or '')
                             else None)
            if cached_bundle and (cached_bundle.get('id') or cached_bundle.get('tmdb_id')):
                tmdb_id = cached_bundle.get('id') or cached_bundle.get('tmdb_id')
            if not tmdb_id:
                raw_title = (details.get("name") or details.get("title") or
                             item.get("name") or item.get("title") or "")
                item_year = self._year(details) or self._year(item) or None
                if raw_title:
                    try:
                        found = tmdb.search_title(raw_title, self.kind, item_year) or {}
                        if not found:
                            found = tmdb.search_title(raw_title, self.kind, None) or {}
                    except Exception:
                        found = {}
                tmdb_id = found.get("id") or found.get("tmdb_id")

            quick_backdrop = self._movieBackdropUrl(found) if need_tmdb_backdrop else ""
            if quick_backdrop and (not backdrop_urls or not cached_artwork(backdrop_urls[0], 'backdrops')
                                   or cached_artwork(quick_backdrop, 'backdrops')):
                self._queueGui(self._applyPreviewArtwork, quick_backdrop, "", request_id)
                # TMDb details can identify a more authoritative backdrop than
                # the search preview; do not permanently lock the search image.
            if request_id != self._previewRequestId:
                return
            if not tmdb_id:
                if server_backdrop:
                    self._queueGui(self._applyPreviewArtwork, server_backdrop, "", request_id)
                elif need_backdrop:
                    # Large-page Hero: reuse GENRE's bounded provider/cache recovery.
                    self._queueGui(self._recoverSelectedPreview, request_id,
                                   'hero', 'backdrop', 1920, 1080)
                if need_logo and not server_logo:
                    self._queueGui(self._recoverSelectedPreview, request_id,
                                   'logoImage', 'logo', 600, 104)
                return

            if cached_bundle:
                bundle = cached_bundle
            else:
                try:
                    bundle = tmdb.details_bundle(tmdb_id, self.kind) or {}
                except Exception:
                    bundle = {}
            if found:
                seed = dict(found)
                seed.update(bundle or {})
                bundle = seed

            # Apply TMDb text/meta first. Missing individual fields remain as the
            # already-visible server values, so a partial TMDb response is safe.
            if bundle:
                self._queueGui(self._applyPreviewMetadata, bundle, request_id)

            backdrop = self._movieBackdropUrl(bundle) if need_tmdb_backdrop else ''
            if not backdrop and need_tmdb_backdrop:
                alternatives = self._sameMovieBackdropPaths(tmdb, tmdb_id, bundle)
                if alternatives:
                    backdrop = self.norm(alternatives[0])
            if tmdb_id and isinstance(bundle, dict):
                try:
                    from .identity_artwork_index import remember
                    remember(self.kind, tmdb_id, bundle.get('poster_path'),
                             bundle.get('backdrop_path') or backdrop or quick_backdrop)
                except Exception:
                    pass
            final_backdrop = (server_backdrop if need_backdrop and server_backdrop else
                              (known_backdrop if cached_backdrop_ready else
                               backdrop or quick_backdrop))
            if backdrop:
                self._queueGui(self._rememberPreviewTmdbBackdrop, request_id, backdrop, tmdb_id)
            # Backdrop must be dispatched BEFORE slow external title-logo fallbacks.
            if final_backdrop:
                if (not backdrop_urls or not cached_artwork(backdrop_urls[0], 'backdrops')
                        or cached_artwork(final_backdrop, 'backdrops')):
                    self._queueGui(self._applyPreviewArtwork, final_backdrop, "", request_id)
            elif need_backdrop:
                self._queueGui(self._recoverSelectedPreview, request_id,
                               'hero', 'backdrop', 1920, 1080)
            if need_tmdb_logo and request_id == self._previewRequestId:
                try:
                    from .title_logo_ultra_bridge import resolve_title_logo
                    logo_path = resolve_title_logo(tmdb, self.kind, tmdb_id,
                            title=raw_title, details=bundle, item=item, canvas=(620, 96),
                            cancelled=lambda: request_id != self._previewRequestId)
                    if logo_path and request_id == self._previewRequestId:
                        self._queueGui(self._applyPreviewTitleLogoPath, logo_path, request_id)
                except Exception:
                    pass
            # Queue banner enrichment separately so a slow fanart.tv request
            # cannot hold up navigating Movies/TV Shows or loading the logo.
            if request_id == self._previewRequestId:
                self._startPreviewBannerLookup(tmdb_id, bundle, request_id)
        except Exception:
            pass

    def _applyPreviewMetadata(self, data, request_id, from_cache=False):
        if request_id != self._previewRequestId:
            return
        if not from_cache:
            self._keepPreviewMetadata(self.current(), data)
        # The hero and its focused Backdrop card refer to the same content.
        # Preserve the verified TMDb identity and origin on the card itself;
        # otherwise the same backdrop reached via top navigation has no flag.
        if self.focus == "backdrops" and isinstance(data, dict):
            try:
                current = self.current()
                if isinstance(current, dict):
                    previous_id = str(current.get("tmdb_id") or current.get("tmdb") or "")
                    previous_country = self._countryCodeFromBackdropItem(current)
                    resolved_id = str(data.get("id") or "").strip()
                    if resolved_id.isdigit() and int(resolved_id) > 0:
                        current["tmdb_id"] = resolved_id
                        current["_verified_tmdb_id"] = resolved_id
                    verified = verified_country_code(data, "tv" if self.kind == "series" else "movie")
                    if verified and verified != previous_country:
                        self._rememberBackdropFlagCountry(current, verified)
                    if (str(current.get("tmdb_id") or "") != previous_id or
                            (verified and verified != previous_country)):
                        self._setBackdropFlag(self.backdropIndex, current)
            except Exception:
                pass
        # Same metadata selection as Movie/Series Details: preserve the
        # localized title/plot, prefer verified TMDb rating and date, and never
        # blank existing provider text if a details response is partial.
        current = self.current() or {}
        info = merge_metadata(current, tmdb=data, language=TMDbClient().language, kind=self.kind)
        if info["title"]:
            self["logoTitle"].setText(visible_title(info["title"], 34))
        self._information_badge_preview_rating = info['rating'] or ''
        meta = [info["year"]]
        if self.kind != "series" and info["rating"]:
            try:
                meta.append("★ %.1f" % float(info["rating"]))
            except (ValueError, TypeError):
                meta.append("★ " + str(info["rating"])[:4])
        meta.append(info["genre"])
        self["heroMeta"].setText("   •   ".join(str(x) for x in meta if x))
        if info["description"]:
            self["heroDesc"].setText(_hero_preview_summary(info["description"]))

    def _rememberPreviewTmdbBackdrop(self, request_id, backdrop, tmdb_id):
        """Remember the selected, verified TMDb backdrop on the correct row."""
        if request_id != self._previewRequestId or not backdrop:
            return
        current = self.current()
        if not isinstance(current, dict):
            return
        final_url = self.norm(backdrop)
        if final_url and "image.tmdb.org/t/p/" in final_url:
            current["_tmdb_backdrop"] = final_url
            if tmdb_id:
                current["tmdb_id"] = str(tmdb_id)
                current["_verified_tmdb_id"] = str(tmdb_id)
                try:
                    from .identity_artwork_index import remember
                    remember(self.kind, tmdb_id, backdrop=final_url)
                except Exception:
                    pass
                if self.focus == "backdrops":
                    try:
                        self._setBackdropFlag(self.backdropIndex, current)
                    except Exception:
                        pass

    def _applyPreviewTitleLogoPath(self, path, request_id):
        if request_id != self._previewRequestId or not os.path.isfile(path):
            return
        identity = self._genreHeroIdentity('logoImage', self.current())
        if (identity is not None and
                getattr(self, '_genreHeroWins', {}).get('logoImage') == identity):
            return
        # Keep an exact request marker to prevent stale ePicLoad callbacks.
        self._ultraTitleLogoRequestId = request_id
        token = "logoImage|" + path
        self._image_requests["logoImage"] = token
        w, h = (600, 104)
        self.decode(path, "logoImage", w, h)

    def _applyPreviewArtwork(self, backdrop, logo, request_id, banner=""):
        if request_id != self._previewRequestId:
            return
        if backdrop and getattr(self, '_genreHeroDecoded', {}).get('hero') != \
                self._genreHeroIdentity('hero', self.current()):
            backdrop = self.norm(backdrop)
            if getattr(self, "_image_requests", {}).get("hero") != backdrop:
                self.loadImage(backdrop, "hero", 1920, 520)
        if logo and getattr(self, '_genreHeroDecoded', {}).get('logoImage') != \
                self._genreHeroIdentity('logoImage', self.current()) and \
                getattr(self, "_ultraTitleLogoRequestId", None) != request_id:
            if getattr(self, "_image_requests", {}).get("logoImage") != logo:
                w, h = (600, 104)
                self.loadImage(logo, "logoImage", w, h)
        if banner:
            # A real fanart.tv moviebanner/tvbanner. No backdrop substitutions.
            current = self.current() or {}
            if isinstance(current, dict):
                current["_fanart_tv_banner"] = banner
            self.loadImage(banner, "promoBanner", 288, 54)

    def _openPackageDrawerHome(self):
        """PACKAGES menu for the CLASSIC page (Backdrops + Latest rails)."""
        if self.kind not in ("vod", "series") or not getattr(self, "categoriesLoaded", False):
            return False
        rows = list(getattr(self, "categoriesList", None) or [])
        if len(rows) < 2:
            return False
        names = [(r.get("category_name") if isinstance(r, dict) else r) or "" for r in rows]
        start = int(getattr(self, "categoryIndex", -1))
        current = start if 0 <= start < len(rows) else 0
        def chosen(target, start=start):
            # _changeCategory moves relative to the current index (-1 = none).
            self._changeCategory(target - start)
        from .package_drawer import open_package_drawer
        return open_package_drawer(self, names, current, chosen, "CLASSIC")

    def left(self):
        # First card of a rail (first page): slide in the PACKAGES menu.
        if ((self.focus == "backdrops" and self.backdropIndex == 0 and self.backdropStart == 0) or
                (self.focus == "latest" and self.latestIndex == 0)):
            if self._openPackageDrawerHome():
                return
        if self.focus == "top": self.topIndex = max(0, self.topIndex - 1)
        elif self.focus == "backdrops":
            if self.backdropIndex > 0: self.backdropIndex -= 1
            elif self.backdropStart > 0:
                # LEFT from card #5 returns to #4, never to #1.
                self.backdropStart = max(0, self.backdropStart - 4)
                self.backdropIndex = min(3, len(self.backdrops) - self.backdropStart - 1)
                self.renderBackdrops()
        else:
            if self.latestIndex > 0: self.latestIndex -= 1
            elif self.latestStart > 0: self.latestStart = max(0, self.latestStart - 8); self.renderLatest()
        self.updateFocus(); self.preview()

    def right(self):
        if self.focus == "top": self.topIndex = min(len(self.TOP) - 1, self.topIndex + 1)
        elif self.focus == "backdrops":
            if self.backdropIndex < 3 and self.backdropStart + self.backdropIndex + 1 < len(self.backdrops): self.backdropIndex += 1
            elif self.backdropStart + 4 < len(self.backdrops): self.backdropStart += 4; self.backdropIndex = 0; self.renderBackdrops()
        else:
            if self.latestIndex < 7 and self.latestStart + self.latestIndex + 1 < len(self.latest): self.latestIndex += 1
            elif self.latestStart + 8 < len(self.latest): self.latestStart += 8; self.latestIndex = 0; self.renderLatest()
        self.updateFocus(); self.preview()

    def up(self):
        if self.focus == "latest" and self.latestStart > 0:
            # UP = previous Latest page; first page moves up to Backdrops.
            self.latestStart = max(0, self.latestStart - 8)
            self.latestIndex = min(self.latestIndex, max(0, len(self.latest) - self.latestStart - 1))
            self.renderLatest()
            self.updateFocus(); self.preview()
            return
        if self.focus == "latest":
            self.focus = "backdrops"
        elif self.focus == "backdrops":
            self.focus = "top"
        else:
            self.focus = "top"
        self.updateFocus(); self.preview()



    def down(self):
        if self.focus == "top":
            # Backdrops are the first content level. If it is still loading,
            # stay on top rather than jumping directly to the lower poster row.
            if self.backdrops:
                self.focus = "backdrops"
            elif not self.latest:
                self.focus = "top"
            else:
                # Only fall back when Backdrops are genuinely unavailable.
                self.focus = "latest"
        elif self.focus == "backdrops":
            self.focus = "latest" if self.latest else "backdrops"
        else:
            self.focus = "latest"
        self.updateFocus()
        if self.focus != "top":
            self.preview()


    def _backdropDisplayTitle(self, value):
        """Clean noisy provider labels for UI only; never mutate server data."""
        text = " ".join(str(value or "").split())
        if not text:
            return ""
        # Known non-title tokens commonly injected by servers/playlists.
        tag = r"(?:TOP|NEW|RECENT|4K|8K|UHD|FHD|FULL\s*HD|HD|SD|2160P|1080P|720P|NF|NETFLIX|AMZ|AMZN|PRIME|PRIME\s*VIDEO|DSNP|DISNEY\+?|APPLE\+?|APPLE\s*TV\+?|HULU|HBO|MAX|WEB[- ]?DL|WEBRIP|BLURAY|HEVC|H\.?26[45]|X26[45]|HDR10?\+?|HDR|DV|DOLBY(?:\s*VISION)?|AR|ARA|ARABIC|EN|ENG|ENGLISH|FR|TR|SUBS?|AR[-_ ]?SUBS?|DUB(?:BED)?|MULTI)"
        # Strip leading chains such as '4K-NF - ' / 'AR-SUBS | ' / 'EN : '.
        for _ in range(6):
            new = re.sub(r"^\s*(?:" + tag + r")(?:\s*[-_|:/+]\s*(?:" + tag + r"))*\s*(?:[-|:/]\s*)+", "", text, flags=re.I)
            if new == text:
                break
            text = new.strip()
        # Remove leading bracket groups like [4K NF] / (TOP) when they contain only tags.
        text = re.sub(r"^\s*[\[(](?:[^\])]{0,36})[\])]\s*[-|:]?\s*", lambda m: "" if re.search(tag, m.group(0), re.I) else m.group(0), text).strip()
        # Remove standalone quality/language wrappers anywhere in the title.
        text = re.sub(r"[\[({]\s*(?:(?:" + tag + r")(?:[\s,|+._-]+)?)+\s*[\])}]", " ", text, flags=re.I)
        # Remove duplicate provider suffixes after separators, e.g. 'Title - NF'.
        text = re.sub(r"\s*(?:[-|:/]\s*(?:" + tag + r"))+\s*$", "", text, flags=re.I)
        # Clean empty separator noise left by providers.
        text = re.sub(r"\s{2,}", " ", text)
        text = re.sub(r"^[\-_|:/+\s]+|[\-_|:/+\s]+$", "", text)
        return text or " ".join(str(value or "").split())

    def _clipDisplayTitle(self, value, limit):
        text = self._backdropDisplayTitle(value)
        try:
            limit = int(limit or 0)
        except Exception:
            limit = 0
        if limit <= 0 or len(text) <= limit:
            return text
        probe = text[:limit + 1].rstrip()
        if " " in probe[:-1]:
            probe = probe.rsplit(" ", 1)[0].rstrip()
        probe = probe.rstrip(" -_|:/,.؛،")
        return (probe or text[:limit].rstrip(" -_|:/,.؛،")).rstrip() + "…"

    def _normTitle(self, value):
        text = (value or "").lower()
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray)\b", " ", text)
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return " ".join(text.split())

    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _serverTmdbId(self, item):
        item = item or {}
        for key in ("tmdb_id", "tmdb", "tmdbid"):
            value = item.get(key)
            if value not in (None, ""):
                try:
                    return str(int(value))
                except Exception:
                    value = str(value).strip()
                    if value:
                        return value
        info = item.get("info")
        if isinstance(info, dict):
            for key in ("tmdb_id", "tmdb", "tmdbid"):
                value = info.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _strictMatchFromRows(self, tmdbItem, rows):
        tmdbItem = tmdbItem or {}
        target_id = self._serverTmdbId(tmdbItem)
        target_year = self._year(tmdbItem)
        wanted = [
            self._normTitle(tmdbItem.get("name") or tmdbItem.get("title")),
            self._normTitle(tmdbItem.get("original_title") or tmdbItem.get("original_name"))
        ]
        wanted = [x for x in wanted if x]
        if not wanted and not target_id:
            return None

        # 1) Exact TMDb ID is authoritative.
        if target_id:
            for row in rows or []:
                if self._serverTmdbId(row) == target_id:
                    return row

        # 2) Title/year matching is intentionally strict.  A wrong movie is
        # worse than reporting "not available".
        best = None
        best_score = 0.0
        for row in rows or []:
            candidate = self._normTitle((row or {}).get("name") or (row or {}).get("title"))
            if not candidate:
                continue
            row_year = self._year(row)
            if target_year and row_year and target_year != row_year:
                continue

            score = max([self._title_score(w, candidate) for w in wanted] or [0.0])
            if score <= 0.0:
                continue

            # If either side lacks a year, accept only an exact/near-exact
            # normalized title.  This prevents remakes and similarly named films.
            if not (target_year and row_year) and score < 0.98:
                continue

            # With an exact year, still require a strong title identity.
            if target_year and row_year and score < 0.94:
                continue

            if score > best_score:
                best, best_score = row, score
        return best

    def matchServerItem(self, tmdbItem):
        match = self._strictMatchFromRows(tmdbItem, self.serverItems or [])
        if match:
            return match

        # Xtream serverItems already contains the full enabled catalogue.
        # Stalker landing mode contains only one package, so Backdrop
        # must search every enabled package before declaring the title absent.
        if self.source.get("type") != "stalker":
            return None
        try:
            client = get_source_client(self.source)
            categories, _origin = get_cached_categories(
                self.source, self.kind, client=client, wait_for_server=True
            )
            categories = filter_categories(self.source, self.kind, categories or [])
            for category in categories:
                category_id = str((category or {}).get("category_id") or "")
                if not category_id:
                    continue
                rows, _origin = get_category_streams(
                    self.source, self.kind, client, category_id,
                    use_cache=True, wait_for_server=True
                )
                match = self._strictMatchFromRows(tmdbItem, rows or [])
                if match:
                    return match
        except Exception:
            pass
        return None


    def _switchContentKind(self, new_kind):
        """Switch Movies/TV Shows inside this same Screen; never stack another ContentHomeScreen."""
        if new_kind == self.kind:
            self.focus = "top"
            self.updateFocus()
            return
        self.contentGeneration += 1
        self.categoryLoadToken += 1
        self.kind = new_kind
        self._previewPixmapCache.clear()
        self._previewPixmapBytes = 0
        with self._previewMetadataLock:
            self._previewMetadataCache.clear()
        self._setMovieLogoGeometry()
        self._previewRequestId += 1
        self._previewBackdropPending = None
        self._image_requests.pop("logoImage", None)
        self._image_requests.pop("promoBanner", None)
        # Do not reuse the previous media kind's hero decode/pixmap URL.
        # The new kind may resolve the same URL after its own selection is set.
        self._image_requests.pop("hero", None)
        if hasattr(self, "_fastRenderedArtwork"):
            self._fastRenderedArtwork.pop("hero", None)
        # Provider category IDs can overlap between Movies and Series. RAM
        # package rows are keyed only by category ID and must NEVER survive a
        # type change. Preserve all persistent HDD/USB/internal-flash caches.
        with self._fullPackageLock:
            self._fullPackageRows.clear()
        self.recentStable = []
        if hasattr(self, "_fastRenderedArtwork"):
            self._fastRenderedArtwork.clear()
        self.contentMode = _content_default_mode(new_kind)
        self.topIndex = 3 if new_kind == "vod" else 4
        self.focus = "top"

        self.backdrops, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        self.backdropStart = self.backdropIndex = self.latestStart = self.latestIndex = 0

        # Keep the top hero/backdrop title fixed while switching content type.
        primary_title = "Movies You Might Like" if new_kind == "vod" else "TV Shows You Might Like"
        self["backdropTitle"].setText(tr(primary_title))
        self._updateLatestTitle()
        self["latestCategoryName"].setText("")
        self["heroDesc"].setText("")
        self["logoTitle"].setText("")
        self["logoTitle"].show()
        self["promoBanner"].hide()
        self["promoFrame"].hide()
        self["heroMeta"].setText("")
        try:
            # Never hide the hero while switching Movies/TV Shows.
            # Keep a visible placeholder until the new backdrop is decoded.
            self["hero"].show()
            if self["hero"].instance:
                self["hero"].instance.setPixmapFromFile(
                    os.path.join(PLUGIN_PATH, "skins", "home/banner_placeholder.jpg")
                )
            self["logoImage"].hide()
        except Exception:
            pass
        self.renderBackdrops()
        self.renderLatest()
        # A fresh GENRE snapshot makes _loadBackdrops return early because it
        # assumes the artwork was already painted. That happened in start(),
        # but previously NOT here. Paint the new kind's cached hero/rail now.
        self._restoreCachedBackdropRail()
        self.updateFocus()

        generation = self.contentGeneration
        # Fast back-and-forth navigation (Movies <-> TV Shows) reuses only the
        # correct content kind's successful first-package result. Server data
        # is fetched normally on a real miss, filter change or expiry.
        landing = self._recentLandingSnapshot(new_kind)
        if landing is not None:
            self._usingLandingSnapshot = True
            try:
                self.serverReady(landing[0], landing[1], landing[2], landing[3], generation)
            finally:
                self._usingLandingSnapshot = False
        t = threading.Thread(target=self.worker, args=(generation, landing is not None), name="TiviMateContentSwitch")
        t.daemon = True
        t.start()

    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _detailItemWithPackage(self, item):
        """Carry the *real server package* from Movies/TV to its Details page.

        GENRE/Packages already tag titles with the selected package. The Movies
        and TV landing rails open directly from provider rows, which frequently
        have only category_id (or no category information on the first package).
        Resolve by the same provider category list; never guess from the title,
        TMDb movie ID, active top tab, or a global streaming platform.
        """
        row = dict(item or {})
        if (row.get("_server_package_name") or row.get("_source_category_name") or
                row.get("package_name") or row.get("group-title")):
            return row
        category_id = str(row.get("_source_category_id") or row.get("category_id") or "").strip()
        # TMDb feed IDs are not IPTV category IDs. Only resolve them when the
        # item's provenance explicitly contains a server-side category ID.
        if (category_id and not category_id.startswith("__") and
                (not row.get("_tmdb") or row.get("_source_category_id"))):
            for category in getattr(self, "categoriesList", []) or []:
                if (isinstance(category, dict) and
                        str(category.get("category_id") or "").strip() == category_id):
                    name = str(category.get("category_name") or "").strip()
                    if name:
                        row["_server_package_name"] = name
                    return row
        # Some Xtream/Stalker first-package entries omit category_id entirely.
        # Resolve only when the exact server item ID belongs to the first-page
        # package currently represented by serverItems; NEVER use a TMDb-only
        # recommendation/Latest result or a mere title match.
        if not category_id and not row.get("_tmdb"):
            key = "series_id" if self.kind == "series" else "stream_id"
            item_id = str(row.get(key) or "").strip()
            selected_index = getattr(self, "categoryIndex", -1)
            categories = getattr(self, "categoriesList", []) or []
            if item_id and 0 <= selected_index < len(categories):
                match_category = categories[selected_index]
                name = str(match_category.get("category_name") or "").strip()
                if name and any(isinstance(other, dict) and
                                str(other.get(key) or "").strip() == item_id
                                for other in (getattr(self, "serverItems", []) or [])):
                    row["_server_package_name"] = name
        return row

    def ok(self):
        from .ui import TiviMateE2Search, TiviMateE2Home, MediaScreen, SeriesDetailsScreen, ServerHub, ContinueWatchingScreen, SettingsDashboard, FavoritesScreen
        from .tivimate_player import TiviMatePlayer
        if self.focus == "top":
            if self.topIndex == 0:
                self._openPageOnce(TiviMateE2Home)
                return
            if self.topIndex == 1:
                self._openPageOnce(TiviMateE2Search, self.source)
                return
            if self.topIndex == 2:
                self._openPageOnce(MediaScreen, self.source, "live")
                return
            if self.topIndex == 3:
                self._switchContentKind("vod")
                return
            if self.topIndex == 4:
                self._switchContentKind("series")
                return
            if self.topIndex == 5:
                from .ui import ContentPackagesScreen
                self._openPageOnce(ContentPackagesScreen, self.source)
                return
            if self.topIndex == 6:
                from .ui import MovieGenresScreen
                self._openPageOnce(MovieGenresScreen, dict(self.source), self.kind)
                return
            if self.topIndex == 7:
                self._openPageOnce(ContinueWatchingScreen, self.source)
                return
            if self.topIndex == 8:
                from .ui import TiviMateE2IPTVFinder
                self._openPageOnce(TiviMateE2IPTVFinder)
                return
            if self.topIndex == 9:
                self._openPageOnce(SettingsDashboard)
                return
            if self.topIndex == 10:
                self._openPageOnce(FavoritesScreen)
                return
            return
        item = self.current()
        if not item:
            return
        if self.kind in ("series", "vod"):
            item = self._detailItemWithPackage(item)
        if self.kind == "series":
            if item.get("_tmdb"):
                chosen = dict(item)
                chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
                self.session.open(SeriesDetailsScreen, self.source, chosen)
                return
            self.session.open(SeriesDetailsScreen, self.source, item)
            return
        if item.get("_tmdb"):
            chosen = dict(item)
            chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
            chosen["_source_scope"]="content_home"
            self.session.open(
                MovieDetailsScreen, self.source, chosen, self.serverItems,
                {"scope":"content_home","category_id":str(chosen.get("category_id") or ""),"items":list(self.serverItems or [])}
            )
            return
        detail_item=dict(item or {})
        detail_item["_source_scope"]="content_home"
        self.session.open(
            MovieDetailsScreen, self.source, detail_item, self.serverItems,
            {"scope":"content_home","category_id":str(detail_item.get("category_id") or ""),"items":list(self.serverItems or [])}
        )
        return

    def _sortLabel(self):
        return {"default": "Latest", "name": "Name", "rating": "Rating"}.get(self.sortMode, "Latest")

    def _sortBadge(self):
        labels = {
            "default": "[%s]" % tr("Latest"),
            "name": "[A-Z %s]" % tr("Name"),
            "rating": "[★ %s]" % tr("Rating"),
        }
        return labels.get(self.sortMode, labels["default"])

    def _addedSortValue(self, item):
        """Return the provider's real add/update timestamp for Latest rows.

        Movies use ``added``. Series use ``last_modified`` first and then
        ``added`` because many Xtream panels do not publish ``added`` for a
        series. Production year and TMDb release dates are deliberately not
        used here.
        """
        row = item or {}
        if self.kind == "series":
            raw = row.get("last_modified")
            if raw in (None, "", 0, "0"):
                raw = row.get("added")
        else:
            raw = row.get("added")
        if raw is None:
            return 0
        try:
            value = float(raw)
            # Some portals send Unix time in milliseconds rather than seconds.
            if value != value or value == float("inf") or value == float("-inf"):
                return 0
            if abs(value) >= 100000000000:
                value = value / 1000.0
            return value
        except Exception:
            pass
        try:
            text = str(raw).strip().replace("T", " ")
        except Exception:
            return 0
        # Stalker commonly returns e.g. "2015-08-21 18:35:31".  Parse the
        # standard date-time part and tolerate an optional time-zone suffix.
        for value, pattern in ((text[:19], "%Y-%m-%d %H:%M:%S"), (text[:10], "%Y-%m-%d")):
            try:
                return time.mktime(time.strptime(value, pattern))
            except (TypeError, ValueError, OverflowError):
                pass
        return 0

    def _sortedItems(self, items):
        rows = list(items or [])
        if self.sortMode == "name":
            rows.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
        elif self.sortMode == "newest":
            rows.sort(key=lambda x: str(x.get("last_modified") or x.get("added") or x.get("year") or x.get("releaseDate") or ""), reverse=True)
        elif self.sortMode == "year":
            rows.sort(key=lambda x: str(x.get("year") or x.get("releaseDate") or "")[:4], reverse=True)
        elif self.sortMode == "rating":
            def rating_value(x):
                try: return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception: return 0
            rows.sort(key=rating_value, reverse=True)
        else:
            # Sort timestamped entries newest-first. Keep entries for which the
            # provider exposes no usable timestamp in their original server
            # order instead of hiding the whole Series section.
            dated = []
            undated = []
            for position, item in enumerate(rows):
                stamp = self._addedSortValue(item)
                if stamp > 0:
                    dated.append((stamp, position, item))
                else:
                    undated.append((position, item))
            dated.sort(key=lambda entry: (entry[0], -entry[1]), reverse=True)
            rows = [entry[2] for entry in dated] + [entry[1] for entry in undated]
        return rows

    def _activeItems(self):
        return self.categoryItems if self.categoryIndex >= 0 else self.serverItems

    def _positionLatestCategoryName(self):
        """Keep the server package name directly beside the translated mode title."""
        try:
            if not self["latestTitle"].instance or not self["latestCategoryName"].instance:
                return
            lang = get_language()
            if lang == "ar":
                # Arabic heading is right-aligned in the block moved by
                # _applyArabicHeadingLayout. Put the package immediately to its left.
                title_x = 1110
                title_w = 730
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(220, min(700, len(self["latestTitle"].getText()) * 18))
                cat_w = 720
                x = max(80, title_x + title_w - rendered - cat_w - 18)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(cat_w), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(2)
                except Exception:
                    pass
            else:
                title_x = 80
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(180, min(700, len(self["latestTitle"].getText()) * 17))
                x = min(1020, title_x + rendered + 14)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(820), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(0)
                except Exception:
                    pass
        except Exception:
            pass

    def _updateLatestTitle(self):
        try:
            self["latestTitle"].setText(tr(_content_mode_title(self.kind, self.contentMode)))
        except Exception:
            pass
        try:
            category = str(getattr(self, "categoryName", "") or "").strip()
            # Keep very long provider package names within the content rail;
            # never let an EN|LATEST ... caption cover navigation or the hero.
            if len(category) > 42:
                category = category[:41].rstrip() + "…"

            # NONE disables only the optional automatic source label.
            # Keep server/package posters visible, but do not show the orphan
            # Date/Recent sort badge when no explicit package is selected.
            if self.contentMode == "none" and not category:
                self["latestCategoryName"].setText("")
                self._positionLatestCategoryName()
                return

            badge = self._sortBadge()
            if category:
                text = "  •  %s   %s" % (category, badge)
            else:
                text = "  •  %s" % badge
            self["latestCategoryName"].setText(text)
        except Exception:
            pass
        self._positionLatestCategoryName()

    def _changeCategory(self, direction):
        # Do not label previously painted posters as a different package while
        # an uncached request is in flight. A second keypress must still know
        # the last actually displayed category, not a pending selection.
        pending = getattr(self, "_categoryPendingRestore", None)
        if pending:
            previous_index, previous_name = pending[1], pending[2]
        else:
            previous_index, previous_name = self.categoryIndex, self.categoryName
        if not self.categoriesLoaded:
            self["heroDesc"].setText("")
            return
        if not self.categoriesList:
            self["heroDesc"].setText(tr("No enabled categories are available for this library."))
            return
        if direction < 0 and self.categoryIndex < 0:
            self.categoryIndex = len(self.categoriesList) - 1
        else:
            self.categoryIndex = (self.categoryIndex + direction) % len(self.categoriesList)
        category = self.categoriesList[self.categoryIndex]
        category_id = str(category.get("category_id") or "")
        self.categoryName = category.get("category_name") or "Other"
        _package_diag("CATEGORY_SWITCH", kind=self.kind, direction=direction, index=self.categoryIndex, category_id=category_id, category_name=self.categoryName)
        self._updateLatestTitle()
        if not category_id:
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self._categoryPendingRestore = (token, previous_index, previous_name)

        # Reuse ONLY a package that this screen previously loaded as a full
        # provider response. Never reuse a global/recent/partial category map.
        if category_id in self._fullPackageRows:
            rows = list(self._fullPackageRows.get(category_id) or [])
            _package_diag("PACKAGE_SCREEN_RAM_HIT", kind=self.kind, category_id=category_id, category_name=self.categoryName, item_count=len(rows))
            self._categoryPendingRestore = None
            self.categoryItems = rows
            self.latest = self._sortedItems(rows)
            self.latestStart = self.latestIndex = 0
            self.focus = "latest"
            self._categorySwitchPreviewNow = True
            self._updateLatestTitle()
            self.renderLatest()
            if self.latest:
                self.preview()
            self.updateFocus()
            self["heroDesc"].setText("")
            return

        # Movies AND TV Shows: paint existing per-package cache immediately.
        # A cold miss still loads off the GUI thread, never blocking navigation.
        quick_rows = []
        quick_origin = "miss"
        if self.kind in ("vod", "series"):
            try:
                quick_rows, quick_origin = peek_category_streams_cache(self.source, self.kind, category_id)
            except Exception:
                quick_rows, quick_origin = [], "miss"
        if quick_rows:
            self._categoryPendingRestore = None
            self.categoryItems = list(quick_rows)
            self.latest = self._sortedItems(self.categoryItems)
            self.latestStart = self.latestIndex = 0
            self.focus = "latest"
            self._categorySwitchPreviewNow = True
            self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
            if self.latest:
                self.preview()
            _package_diag("PACKAGE_MOVIES_FAST_CACHE", kind=self.kind, category_id=category_id, category_name=self.categoryName, origin=quick_origin, item_count=len(quick_rows))
        else:
            # Keep the *previous* package label with its previous artwork until
            # the requested package has actually arrived. No false associations.
            self.categoryName = previous_name
            # Cold package cache: keep the already-painted small-poster rail on
            # screen while the selected Movies/Series package is fetched by the
            # worker.  Do not blank the UI and make the package switch look even
            # slower. categoryReady() replaces it atomically when data arrives.
            self.focus = "latest"
            self._updateLatestTitle(); self.updateFocus()
        self["heroDesc"].setText("")
        name = "TiviMateNextCategory" if direction > 0 else "TiviMatePreviousCategory"
        is_stalker = self.source.get("type") == "stalker"
        if is_stalker:
            # Supersede any older unfinished category request.  The worker also
            # checks the token before storing a result, preventing an old reply
            # from overwriting a newer red/blue selection.
            self.stalkerCategoryLoadResult = None
            self.stalkerCategoryPendingToken = token
            self.stalkerCategoryLoadStartedAt = time.monotonic()
        submitted = _submit_content_bg(
            self._loadCategory,
            args=(token, category_id),
            key=("category-load", id(self))
        )
        _package_diag("PACKAGE_WORKER_SUBMIT", kind=self.kind, category_id=category_id, category_name=self.categoryName, token=token, submitted=submitted)
        if not submitted:
            self["heroDesc"].setText(tr("."))
        if is_stalker:
            try:
                self.stalkerCategoryLoadTimer.start(120, True)
            except Exception:
                pass

    def previousCategory(self):
        self._changeCategory(-1)

    def nextCategory(self):
        self._changeCategory(1)

    def _loadCategory(self, token, category_id):
        if token != getattr(self, "categoryLoadToken", token):
            return
        source = dict(self.source or {})
        try:
            client = get_source_client(source)
            cid = str(category_id or "").strip()
            # Package switch: use the per-package RAM/disk cache first.
            # On a real cache miss only, fetch this selected package from the
            # provider in the worker thread and persist it for the next visit.
            # This deliberately avoids the old direct client.streams() path,
            # which bypassed package cache and caused every switch to wait.
            _package_diag("PACKAGE_FETCH_BEGIN", kind=self.kind, category_id=cid, token=token, source_type=source.get("type") or "")
            items, origin = get_category_streams(
                source, self.kind, client, cid, use_cache=True, wait_for_server=True
            )
            _package_diag("PACKAGE_FETCH_DONE", kind=self.kind, category_id=cid, token=token, origin=origin, item_count=len(items or []))
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, items, origin, "")
                return
            self._queueGui(self.categoryReady, token, items, origin)
        except Exception as exc:
            _package_diag("PACKAGE_FETCH_ERROR", kind=self.kind, category_id=str(category_id or ""), token=token, error=repr(exc))
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, [], "error", str(exc))
                return
            self._queueGui(self.categoryFailed, token, str(exc))


    def _finishStalkerCategoryLoad(self):
        """Apply the newest Stalker category result only on the GUI thread."""
        expected = getattr(self, "stalkerCategoryPendingToken", None)
        if expected is None:
            return
        result = self.stalkerCategoryLoadResult
        if result is None:
            if (time.monotonic() - getattr(self, "stalkerCategoryLoadStartedAt", time.monotonic())) >= 10.0:
                # The worker is daemonized and may complete later, but a dead
                # portal must not cause an endless GUI polling/spinner cycle.
                self.stalkerCategoryPendingToken = None
                self.categoryFailed(expected, "Server did not respond; retry the package later")
                return
            if expected == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        # A completion can race with this callback; erase only the same object
        # that was observed, never a newer result written by a newer worker.
        if self.stalkerCategoryLoadResult is result:
            self.stalkerCategoryLoadResult = None
        token, items, origin, error = result
        if token != getattr(self, "categoryLoadToken", 0) or token != expected:
            if getattr(self, "stalkerCategoryPendingToken", None) == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        self.stalkerCategoryPendingToken = None
        if error:
            self.categoryFailed(token, error)
        else:
            self.categoryReady(token, items, origin)

    def categoryReady(self, token, items, origin):
        if token != self.categoryLoadToken:
            _package_diag("CATEGORY_READY_STALE", kind=self.kind, token=token, current_token=self.categoryLoadToken, origin=origin, item_count=len(items or []))
            return
        if not items and origin in ("loading", "error", "empty_cooldown", "retry_later"):
            self.categoryFailed(token, "Server response not ready; use the cached package or try again later")
            return
        self._categoryPendingRestore = None
        # A cold miss keeps the preceding package label visible. Only change
        # it after the selected category's response is applied.
        if 0 <= self.categoryIndex < len(self.categoriesList):
            self.categoryName = str(self.categoriesList[self.categoryIndex].get("category_name") or "Other")
        self.categoryItems = list(items or [])
        _package_diag("CATEGORY_READY", kind=self.kind, token=token, category_name=self.categoryName, origin=origin, item_count=len(self.categoryItems))

        # Cache only this complete provider response.
        try:
            if 0 <= self.categoryIndex < len(self.categoriesList):
                current_cid = str((self.categoriesList[self.categoryIndex] or {}).get("category_id") or "")
                if current_cid:
                    self._rememberPackageRows(current_cid, self.categoryItems)
        except Exception:
            pass

        self.latest = self._sortedItems(self.categoryItems)
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()
        if not self.latest:
            if self.source.get("type") == "stalker" and origin == "empty":
                self["heroDesc"].setText("Stalker returned no items for %s. Try another package or refresh the source." % self.categoryName)
            else:
                self["heroDesc"].setText("No titles are available in %s." % self.categoryName)

    def categoryFailed(self, token, msg):
        if token != self.categoryLoadToken:
            _package_diag("CATEGORY_FAILED_STALE", kind=self.kind, token=token, current_token=self.categoryLoadToken, error=msg)
            return
        requested_name = str((self.categoriesList[self.categoryIndex] or {}).get("category_name") or self.categoryName) if 0 <= self.categoryIndex < len(self.categoriesList) else self.categoryName
        _package_diag("CATEGORY_FAILED", kind=self.kind, token=token, category_name=requested_name, error=msg)
        pending = getattr(self, "_categoryPendingRestore", None)
        if pending and pending[0] == token:
            self.categoryIndex, self.categoryName = pending[1], pending[2]
            self._categoryPendingRestore = None
        # Show a real error on a cold cache miss, but never flush already
        # decoded posters just because a provider request timed out.
        if not self.latest:
            self.categoryItems, self.latest = [], []
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self._updateLatestTitle()
        self["heroDesc"].setText("Unable to load %s: %s" % (requested_name, msg))

    def toggleSort(self):
        modes = ["newest", "name", "year", "default"] if self.kind == "series" else ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        self.latest = self._sortedItems(self._activeItems())
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()

    def openPosterServerFilter(self):
        from .poster_remote_actions import open_filter
        return open_filter(self)

    def serverList(self):
        """GREEN: open the existing server chooser, not the server editor."""
        try:
            from .ui import HomeServerPopup, get_sources
            sources = list(get_sources() or [])
            if not sources:
                self.session.open(MessageBox, "No servers available.", MessageBox.TYPE_INFO, timeout=3)
                return
            self.session.openWithCallback(self._fastServerChosen, HomeServerPopup, sources, self.source)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open server list: %s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def _fastServerChosen(self, source=None):
        """Switch by opening a fresh content screen; old async work is disposed."""
        if not isinstance(source, dict) or not source:
            return
        try:
            from .ui import HomeServerPopup
            if HomeServerPopup.sourceKey(source) == HomeServerPopup.sourceKey(self.source):
                return
            self.session.open(self.__class__, dict(source), self.kind)
            self.close()
        except Exception as exc:
            self.session.open(MessageBox, "Unable to switch server: %s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def openMovieGenres(self):
        if self.kind not in ("vod","series"):
            return
        try:
            from .ui import MovieGenresScreen
            self._openPageOnce(MovieGenresScreen, self.source, self.kind)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Movie Genres:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def categories(self):
        # Replace the legacy blue Movie/Series Categories screen with the
        # modern package browser; its artwork follows Movies vs Series.
        from .ui import HomePackageBrowserScreen
        self.session.openWithCallback(self.categoryChosen, HomePackageBrowserScreen, self.source, self.kind)

    def categoryChosen(self, selected=None):
        if not selected or not isinstance(selected, dict):
            return
        category_id = str(selected.get("id") or "")
        category_name = selected.get("name") or ""
        if not category_id:
            return
        # Green Packages is a launcher: after choosing a package, open the
        # large package/content page directly for that package. Do not filter
        # this Movies/TV Shows home page in-place.
        from .ui import MediaScreen
        if category_id == "__recent_added__":
            self._openPageOnce(MediaScreen, self.source, self.kind, category_id, category_name)
            return
        self._openPageOnce(MediaScreen, self.source, self.kind, category_id, category_name)

# Home-triggered metadata-only warm for Movies/TV Shows backdrop rails.
def warm_backdrop_metadata_from_home(source):
    """Prepare Movies + TV backdrop rail rows and TMDb metadata without artwork downloads."""
    source = dict(source or {})
    if not source:
        return
    try:
        tmdb = TMDbClient()
    except Exception:
        return
    for kind in ("vod", "series"):
        try:
            allowed = set(str(x) for x in (get_allowed_category_ids(source, kind) or []) if str(x))
            if not allowed:
                continue
            filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
            cache_mode = "backdrop_filtered_smart_v6_anyyear_warm_%s_%s" % (kind, filter_sig)
            rows = _home_feed_cache_get(cache_mode, source, allow_stale=False)
            if not rows:
                client = get_source_client(source)
                ordered_ids = list(allowed)
                random.shuffle(ordered_ids)
                candidates, seen = [], set()
                for offset in range(0, len(ordered_ids), 4):
                    batches = get_category_streams_batch(source, kind, client, ordered_ids[offset:offset + 4], use_cache=True, wait_for_server=True, max_workers=4)
                    for cid, items, _origin in batches:
                        for raw in items or []:
                            if not isinstance(raw, dict):
                                continue
                            title = str(raw.get("name") or raw.get("title") or "").strip()
                            year = str(raw.get("year") or raw.get("releaseDate") or raw.get("release_date") or "").strip()
                            if not title:
                                continue
                            clean = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
                            key = clean
                            if not clean or key in seen:
                                continue
                            seen.add(key)
                            row = dict(raw)
                            m = re.search(r"(?<!\d)(19\d{2}|20\d{2})(?!\d)", year or title)
                            if m:
                                row["_backdrop_year"] = m.group(1)
                            candidates.append(row)
                    if len(candidates) >= 36:
                        break
                random.shuffle(candidates)
                rows = candidates[:12]
                if rows:
                    _home_feed_cache_put(cache_mode, source, rows)
            for row in rows[:12]:
                try:
                    title = str(row.get("name") or row.get("title") or "").strip()
                    if not title:
                        continue
                    year = str(row.get("_backdrop_year") or row.get("year") or "").strip()[:4] or None
                    resolved = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
                    found = {}
                    if not resolved:
                        found = tmdb.search_title(title, kind, year) or tmdb.search_title(title, kind, None) or {}
                        resolved = str(found.get("id") or found.get("tmdb_id") or "").strip()
                    if not resolved:
                        continue
                    bundle = tmdb.details_bundle(resolved, kind) or {}
                    merged = dict(found or {})
                    merged.update(bundle)
                    row["tmdb_id"] = resolved
                    bd = str(merged.get("backdrop_path") or "").strip()
                    ps = str(merged.get("poster_path") or "").strip()
                    if bd:
                        row["_tmdb_backdrop"] = bd
                    if ps:
                        row["_tmdb_poster"] = ps
                    norm = re.sub(r"[^a-z0-9]+", " ", title.lower()).strip()
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("%s:%s" % (kind, resolved)), merged, _DETAILS_DATA_CACHE_LIMIT)
                    _memory_put(_DETAILS_DATA_CACHE, _tmdb_details_memory_key("%s:title:%s:%s" % (kind, norm, str(year or ""))), merged, _DETAILS_DATA_CACHE_LIMIT)
                except Exception:
                    continue
            if rows:
                _home_feed_cache_put(cache_mode, source, rows[:12])
        except Exception:
            continue


# Experimental Movies/TV Shows cinematic layout.  The original
# ContentHomeScreen remains intact as the underlying data/navigation engine.
def _cinematic_is_landscape_image(path):
    """Validate image orientation without PIL/extra packages on Enigma2.

    Supported normal artwork: JPEG, PNG, WebP, GIF. Unknown or truncated
    images are not painted over the cinematic backdrop to avoid stretched
    portrait posters masquerading as provider backdrop URLs.
    """
    try:
        with open(path, "rb") as stream:
            data = stream.read(262144)
        width = height = 0
        if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
            width = int.from_bytes(data[16:20], "big")
            height = int.from_bytes(data[20:24], "big")
        elif data[:2] == b"\xff\xd8":
            pos = 2
            while pos + 9 < len(data):
                if data[pos] != 255:
                    pos += 1
                    continue
                while pos < len(data) and data[pos] == 255:
                    pos += 1
                if pos >= len(data):
                    break
                code = data[pos]
                pos += 1
                if code in (0xD8, 0xD9, 0x01) or 0xD0 <= code <= 0xD7:
                    continue
                if pos + 2 > len(data):
                    break
                length = int.from_bytes(data[pos:pos+2], "big")
                if length < 2 or pos + length > len(data):
                    break
                if code in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF) and length >= 7:
                    height = int.from_bytes(data[pos+3:pos+5], "big")
                    width = int.from_bytes(data[pos+5:pos+7], "big")
                    break
                pos += length
        elif data[:4] == b"RIFF" and data[8:12] == b"WEBP" and len(data) >= 30:
            fmt = data[12:16]
            if fmt == b"VP8X":
                width = 1 + int.from_bytes(data[24:27], "little")
                height = 1 + int.from_bytes(data[27:30], "little")
            elif fmt == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
                width = int.from_bytes(data[26:28], "little") & 0x3fff
                height = int.from_bytes(data[28:30], "little") & 0x3fff
            elif fmt == b"VP8L" and data[20:21] == b"\x2f":
                bits = int.from_bytes(data[21:25], "little")
                width = (bits & 0x3fff) + 1
                height = ((bits >> 14) & 0x3fff) + 1
        elif data[:6] in (b"GIF87a", b"GIF89a") and len(data) >= 10:
            width = int.from_bytes(data[6:8], "little")
            height = int.from_bytes(data[8:10], "little")
        return width >= 240 and height >= 100 and width >= height * 1.30
    except Exception:
        return False


def _featured_film_signature(row):
    """Content identity across 4K/HD package copies, not provider stream IDs.

    Keep different release years separate. A missing year can still match the
    same named film with a known year; different known years never collide.
    No network requests and no dedupe across servers.
    """
    if not isinstance(row, dict):
        return ("", "", "")
    tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
        tmdb_id = ""
    title = str(row.get("name") or row.get("title") or row.get("original_title") or "").casefold().strip()
    # Strip wrappers containing only a quality or language badge, not subtitles
    # or meaningful title parts. Provider duplicates often have [4K] / [HD].
    title = re.sub(
        r"[\[({]\s*(?:(?:4k|8k|uhd|fhd|full\s*hd|hd|sd|2160p|1080p|720p|hdr10?\+?|dv|dolby\s*vision|hevc|h\.?265|x265|x264|bluray|blu\s*ray|web[\s.-]*dl|remux|imax|multi|arabic|english|مدبلج|مترجم)(?:[\s,|+._-]+)?)+\s*[\])}]",
        " ", title, flags=re.I)
    # Normal resolution tokens, including dotted/underscored file names.
    title = re.sub(r"(?<![\w])(?:4k|8k|uhd|fhd|full[\s._-]*hd|hd|sd|2160p|1080p|720p|hdr10?\+?|dv|hevc|h\.?265|x265|x264|bluray|blu[\s._-]*ray|web[\s._-]*dl|remux)(?![\w])", " ", title, flags=re.I)
    year = ""
    for field in ("year", "release_date", "releaseDate", "releasedate", "first_air_date"):
        match = re.search(r"(?<!\d)(?:19|20)\d{2}(?!\d)", str(row.get(field) or ""))
        if match:
            year = match.group(0)
            break
    # A trailing release year is metadata for VOD entries, not part of its title.
    match = re.search(r"(?:[\s\[({._-]+)((?:19|20)\d{2})(?:[\s\])}._-]*)$", title)
    if match:
        if not year:
            year = match.group(1)
        title = title[:match.start()]
    title = " ".join(re.findall(r"[a-z0-9\u0600-\u06ff]+", title))
    return (title, year, tmdb_id)


def _featured_film_is_duplicate(signature, selected_signatures):
    title, year, tmdb_id = signature
    for prev_title, prev_year, prev_tmdb in selected_signatures:
        if tmdb_id and prev_tmdb and tmdb_id == prev_tmdb:
            return True
        if title and prev_title == title and (not year or not prev_year or year == prev_year):
            return True
    return False



def _featured_backdrop_variant_identity(row):
    """Stable identity for one Latest backdrop card, including TMDb alternates."""
    row = row if isinstance(row, dict) else {}
    package_id = str(row.get("_source_category_id") or row.get("category_id") or "")
    signature = _featured_film_signature(row)
    backdrop = (row.get("_tmdb_backdrop") or row.get("backdrop_path") or
                row.get("backdrop") or row.get("backdrop_url") or "")
    return (package_id, signature, _tmdb_backdrop_identity(str(backdrop or "")))


class FastMoviesContentScreen(ContentHomeScreen):
    """Old responsive Movies navigation with the Movie Details fullscreen backdrop.

    The hero uses the same shared backdrop cache and Movie Details dim layer;
    the poster row, featured cards, actions and data-fetch flow stay unchanged.
    """
    skin = FAST_MOVIES_CLASSIC_PACKAGE_RAIL
    OLD_LATEST_RAIL_TOP = 773  # NEW lower row focus y (778 - 5).

    def __init__(self, session, source, kind, initialMode=None, actorRows=None, actorName=""):
        # Only the selected Current design gets the 6-poster package tile.
        # NewMoviesContentScreen inherits us, but keeps its own untouched skin.
        self._classicPackageRail = not getattr(self, "_newMoviesGallery", False)
        self._classicPackageRailReady = False
        if self._classicPackageRail:
            # Gold focus is 4px left of the poster (unlike the poster image).
            self.LATEST_X = [307, 574, 841, 1108, 1375, 1642]
            self._classicFlagsIdentity = {}
            self._classicPackageLogoCurrent = ''
            self._classicPackageYearCurrent = ''
        # 'series' sometimes opens this exact Movies class; do not tint its backdrop.
        if kind == 'series' and self.__class__ is FastMoviesContentScreen:
            from .font_preferences import read_preferences, scale_skin_text
            _font_prefs = read_preferences()
            self.skin = scale_skin_text(
                FAST_MOVIES_CLASSIC_PACKAGE_RAIL_SERIES,
                _font_prefs["font_scale"], _font_prefs["overview_font_scale"]
            )
        # Backdrop rail remains completely invisible until a real image is decoded.
        self._backdropCardReadySlots = set()
        # These slots exist before the base Screen's onLayoutFinish callbacks.
        self._autoTrailerToken = 0
        self._autoTrailerPlaying = False
        self._autoTrailerOldService = None
        self._autoTrailerService = None
        self._autoTrailerBackendRetried = False
        self._autoTrailerCache = OrderedDict()
        self._autoTrailerDelay = eTimer()
        self._autoTrailerEnd = eTimer()
        self._autoTrailerAnim = eTimer()
        self._autoTrailerSeconds = 10
        self._autoTrailerPhase = 0
        for timer, callback, conn_name in (
            (self._autoTrailerDelay, self._tickBackdropTrailerCount, '_autoTrailerDelayConn'),
            (self._autoTrailerEnd, self._stopAutoTrailer, '_autoTrailerEndConn'),
            (self._autoTrailerAnim, self._animateBackdropTrailerCount, '_autoTrailerAnimConn')):
            try:
                setattr(self, conn_name, timer.timeout.connect(callback))
            except Exception:
                try:
                    timer.callback.append(callback)
                except Exception:
                    timer.timeout.get().append(callback)
        # Packages is the initial focused control, not the autoplay Backdrops.
        self._preferPackageInitialFocus = True
        # Shared sort selection for Current Movies and New Cinematic Movies.
        # DATE deliberately starts with the existing Latest/add-date order.
        self._moviesSortChoice = "date"
        ContentHomeScreen.__init__(self, session, source, kind, initialMode, actorRows, actorName)
        if self._classicPackageRail:
            self['classicPackageName'] = Label('')
            self['classicPackageLogo'] = Pixmap()
            self['classicPackageYear'] = Pixmap()
            self['classicPackageLogo'].hide()
            self['classicPackageYear'].hide()
            for _i in range(6):
                self['classicMovieFlag%d' % _i] = Pixmap()
                self['classicMovieFlag%d' % _i].hide()
            self._classicPackageRailReady = True
            self.onLayoutFinish.append(self._updateClassicPackageTile)
            self.onShow.append(self._updateClassicPackageTile)
            # Native flag pixmaps may not exist during the first cached paint.
            # Retry only already-visible cards after layout/show; never reload posters.
            self.onLayoutFinish.append(self._refreshClassicVisibleFlags)
            self.onShow.append(self._refreshClassicVisibleFlags)
            self._updateClassicPackageTile()
        from .server_footer_identity import compact_server_name, refresh_footer_label
        self["footerServerName"] = Label(compact_server_name(self.source))
        self.onShow.append(lambda: refresh_footer_label(self))
        # The old page title is replaced by the same transparent AR/EN logo used
        # in the new page. Other screens (including TV Shows) keep their labels.
        self["oldLatestMoviesLogo"] = Pixmap()
        self["oldLatestMoviesLogo"].hide()
        # Current, Classic and New share a live second line under SORT.
        self["moviesSortIndicator"] = Label("")
        self.onLayoutFinish.append(self._refreshFooterSortIndicator)
        self.onShow.append(self._refreshFooterSortIndicator)
        self.onLayoutFinish.append(self._refreshOldMoviesLatestLogo)
        self.onShow.append(self._refreshOldMoviesLatestLogo)
        self["fastServerMenuAction"] = ActionMap(["MenuActions"],
            {"menu": self._moviesPageDesignMenu if kind in ("vod", "series") else self.serverList}, -1)
        self["fastTrailerZeroAction"] = ActionMap(
            ["NumberActions"], {"0": self._toggleBackdropTrailerAuto}, -1)
        from .cinematic_catalog import _cinema_trailer_enabled
        self._backdropTrailerAuto = _cinema_trailer_enabled()
        self["backdropTrailerCount"] = Label("")
        self["backdropTrailerCaption"] = Label("")
        self["backdropTrailerToggleHint"] = Label("")
        self._refreshBackdropTrailerHint()
        # Enigma2 widget instances are created only after the skin is applied.
        self.onLayoutFinish.append(self._refreshBackdropTrailerHint)
        self["backdropTrailerCount"].hide()
        self["backdropTrailerCaption"].hide()
        for slot in range(4):
            for part in ("Frame", "Shade", "Badge"):
                name = "backdrop%s%d" % (part, slot)
                self[name] = Pixmap()
                self[name].hide()
            # All visible elements follow the image, not the category list.
            self._setBackdropCardVisual(slot, False)
        # Every skin generated from FastMovies includes this widget. On images
        # without VideoWindow, a hidden Pixmap avoids a startup failure.
        if VideoWindow is None:
            self["trailerPreview"] = Pixmap()
        else:
            try:
                self["trailerPreview"] = VideoWindow(decoder=0, fb_width=1920, fb_height=1080)
            except TypeError:
                self["trailerPreview"] = VideoWindow(decoder=0)
        self["trailerPreview"].hide()
        if ServiceEventTracker is not None and iPlayableService is not None:
            events = {}
            failed = getattr(iPlayableService, "evTuneFailed", None)
            if failed is not None:
                events[failed] = self._autoTrailerTuneFailed
            if getattr(self, "_newMoviesGallery", False):
                eof = getattr(iPlayableService, "evEOF", None)
                if eof is not None:
                    events[eof] = self._stopAutoTrailer
            if events:
                self._autoTrailerEvents = ServiceEventTracker(screen=self, eventmap=events)
        self.onClose.append(self._stopAutoTrailer)
        self.onHide.append(self._stopAutoTrailer)
        # Both Movies and TV Shows use this fast content-only screen.
        self._fastMoviesPerformance = True
        # Serialize cache-first and post-package-refresh backdrop passes.
        self._packageBackdropRefreshLock = threading.Lock()
        self._fastBackdropSlots = {}
        self._fastPosterSlots = {}
        self._fastRenderedArtwork = {}
        # Bookkeeping for the independent country-flag resolver. The provider
        # often supplies a backdrop without any country/TMDb ID; that must not
        # prevent the small flag badge from appearing later.
        self._backdropFlagResolveJobs = {}
        # Keep optional flag identity searches off the critical first-paint path.
        # A short idle delay lets cached film artwork and selected hero render
        # before initiating any extra TMDb title searches for other cards.
        self._backdropCountryDelay = eTimer()
        try:
            self._backdropCountryDelayConn = self._backdropCountryDelay.timeout.connect(
                self._runDeferredBackdropCountries)
        except Exception:
            try:
                self._backdropCountryDelay.callback.append(self._runDeferredBackdropCountries)
            except Exception:
                self._backdropCountryDelay.timeout.get().append(self._runDeferredBackdropCountries)
        self._backdropCountryAttemptAt = OrderedDict()
        self._backdropFlagRetryCount = 0
        self._backdropFlagRetryView = None
        self._backdropFlagRetryTimer = eTimer()
        try:
            self._backdropFlagRetryConn = self._backdropFlagRetryTimer.timeout.connect(self._retryVisibleBackdropFlags)
        except Exception:
            try:
                self._backdropFlagRetryTimer.callback.append(self._retryVisibleBackdropFlags)
            except Exception:
                self._backdropFlagRetryTimer.timeout.get().append(self._retryVisibleBackdropFlags)
        self.onClose.append(self._stopBackdropFlagRetry)
        self.onHide.append(self._stopBackdropFlagRetry)
        self.onShow.append(self._resumeBackdropFlagRetry)
        if not getattr(self, "_actorMode", False):
            self._updateFeaturedBackdropTitle()

    def _positionLatestCategoryName(self):
        if getattr(self, '_classicPackageRail', False):
            # The classic rail shows the category on the tile, not over films.
            return
        return ContentHomeScreen._positionLatestCategoryName(self)

    def _updateClassicPackageTile(self):
        if not getattr(self, '_classicPackageRailReady', False):
            return
        # Identical source and label semantics as NewMoviesContentScreen:
        # categoryName changes only after actual provider/cache category data.
        name = str(getattr(self, 'categoryName', '') or '').strip()
        if not name:
            name = str(getattr(self, '_actorName', '') or '').strip()
        if not name:
            name = 'Movies' if self.kind == 'vod' else 'TV Shows'
        self['classicPackageName'].setText(name[:35] + '…' if len(name) > 36 else name)
        from .genre_package_badges import resolve_package_badge
        logo, year = '', ''
        try:
            logo, year = resolve_package_badge(name, self.kind)
        except Exception:
            pass
        if not year:
            match = re.search(r'(?<!\d)((?:19|20)\d{2})(?!\d)', name)
            if match:
                path = os.path.join(PLUGIN_PATH, 'skins', 'genre', 'package_badges',
                                    'year_%s.png' % match.group(1))
                if os.path.isfile(path):
                    year = path
        if logo and logo.endswith('_full.png'):
            compact = logo[:-9] + '_compact.png'
            if os.path.isfile(compact):
                logo = compact
        for key, path, attr in (
                ('classicPackageLogo', logo, '_classicPackageLogoCurrent'),
                ('classicPackageYear', year, '_classicPackageYearCurrent')):
            widget = self[key]
            if path and os.path.isfile(path):
                try:
                    if getattr(widget, 'instance', None):
                        if getattr(self, attr, '') != path:
                            widget.instance.setPixmapFromFile(path)
                            setattr(self, attr, path)
                        widget.show()
                        if key == 'classicPackageLogo':
                            self['classicPackageName'].setText('')
                    continue
                except Exception:
                    pass
            setattr(self, attr, '')
            widget.hide()

    def _refreshClassicVisibleFlags(self):
        """Reattach known flags after native layout or a cached page revisit.

        Poster image workers, dimensions, and loading order are unchanged.
        """
        if not getattr(self, '_classicPackageRailReady', False):
            return
        for slot in range(6):
            if self.latestStart + slot >= len(self.latest):
                continue
            image = 'latest%d' % slot
            # Do not put a flag over a card that has not decoded its poster.
            if image in getattr(self, '_fastRenderedArtwork', {}):
                self._syncClassicMovieFlag(slot)

    def _syncClassicMovieFlag(self, slot):
        if not getattr(self, '_classicPackageRailReady', False) or not 0 <= slot < 6:
            return
        index = self.latestStart + slot
        if index >= len(self.latest):
            return
        item = self.latest[index]
        if not isinstance(item, dict):
            return
        widget = self['classicMovieFlag%d' % slot]
        if not getattr(widget, 'instance', None):
            return
        info = item.get('info') if isinstance(item.get('info'), dict) else {}
        kind = 'tv' if self.kind == 'series' else 'movie'
        code = str(item.get('_new_poster_verified_country') or
                   item.get('_country_code') or '').strip().upper()
        if not re.fullmatch(r'[A-Z]{2}', code) or code in ('XX', 'GL'):
            code = ''
        if not code:
            # A verified flag from the upper Backdrop/previous package view
            # is safer than an unverified provider country or stream language.
            try:
                cache_key = self._backdropFlagMemoryKey(item)
                code = str(_BACKDROP_FLAG_COUNTRIES.get(cache_key) or '').upper()
            except Exception:
                code = ''
        if not code:
            explicit = {}
            for field in ('origin_country', 'production_countries'):
                value = item.get(field) or info.get(field)
                if value:
                    explicit[field] = value
            try:
                code = verified_country_code(explicit, kind)
            except Exception:
                code = ''
        if not re.fullmatch(r'[A-Z]{2}', code) or code in ('XX', 'GL'):
            code = ''
        tmdb_id = str(item.get('tmdb_id') or item.get('_locked_tmdb_id') or
                      item.get('_tmdb_id') or item.get('tmdb') or item.get('tmdbid') or
                      info.get('tmdb_id') or info.get('tmdb') or '').strip()
        if not tmdb_id.isdigit() or int(tmdb_id) <= 0:
            tmdb_id = ''
        # A TMDb ID is useful when the server item contains no country.
        # No title search is started and the two existing flag workers remain.
        if not code and not tmdb_id:
            return
        ticket = (self.contentGeneration, self.kind, index, id(item), code, tmdb_id)
        if self._classicFlagsIdentity.get(slot) == ticket:
            # Keep a successfully decoded flag visible across focus moves.
            if (getattr(widget, '_tivimate_flag_token', None) is not None and
                    getattr(widget, '_tivimate_flag_rendered', None) ==
                    getattr(widget, '_tivimate_flag_token', None)):
                widget.show()
            return
        self._classicFlagsIdentity[slot] = ticket

        def still_current(s=slot, t=ticket, row=item):
            return (not self._contentScreenDisposed and
                    self._classicFlagsIdentity.get(s) == t and
                    self.latestStart + s < len(self.latest) and
                    self.latest[self.latestStart + s] is row)

        def remember_country(country, row=item, s=slot, t=ticket):
            if not still_current(s, t, row):
                return
            country = str(country or '').strip().upper()
            if re.fullmatch(r'[A-Z]{2}', country) and country not in ('XX', 'GL'):
                row['_new_poster_verified_country'] = country
                self._rememberBackdropFlagCountry(row, country)

        show_country_flag(widget, {'origin_country': [code]} if code else {},
                          kind, tmdb_id if not code else '',
                          visible_when=still_current, gui_dispatch=self._queueGui,
                          on_resolved=remember_country)

    def renderLatest(self):
        ContentHomeScreen.renderLatest(self)
        if getattr(self, '_classicPackageRailReady', False):
            self._updateClassicPackageTile()
            for slot in range(6):
                if self.latestStart+slot >= len(self.latest):
                    self._classicFlagsIdentity.pop(slot, None)
                    self['classicMovieFlag%d' % slot].hide()

    def left(self):
        if not getattr(self, '_classicPackageRail', False) or self.focus != 'latest':
            return ContentHomeScreen.left(self)
        if self.latestIndex == 0 and self._openPackageDrawerHome():
            return
        if self.latestIndex > 0:
            self.latestIndex -= 1
        elif self.latestStart > 0:
            self.latestStart = max(0, self.latestStart-6)
            self.latestIndex = min(5, max(0,len(self.latest)-self.latestStart-1))
            self.renderLatest()
        self.updateFocus()
        self.preview()

    def right(self):
        if not getattr(self, '_classicPackageRail', False) or self.focus != 'latest':
            return ContentHomeScreen.right(self)
        if self.latestStart+self.latestIndex+1 < len(self.latest):
            if self.latestIndex < 5:
                self.latestIndex += 1
            else:
                self.latestStart += 6
                self.latestIndex = 0
                self.renderLatest()
        self.updateFocus()
        self.preview()

    def up(self):
        # Classic six-poster rail: UP = previous six; first page -> Backdrops.
        if (getattr(self, '_classicPackageRail', False) and
                self.focus == 'latest' and self.latestStart > 0):
            self.latestStart = max(0, self.latestStart - 6)
            self.latestIndex = min(self.latestIndex, max(0, len(self.latest) - self.latestStart - 1))
            self.renderLatest()
            self.updateFocus()
            if self.latest:
                self.preview()
            return
        return ContentHomeScreen.up(self)

    def down(self):
        # Match the approved New layout: DOWN from the lower six-poster rail
        # advances to the next six items, not a no-op.  All other focus modes
        # retain their existing Backdrop/top navigation.
        if (getattr(self, '_classicPackageRail', False) and
                self.focus == 'latest'):
            following = self.latestStart + 6
            if following < len(self.latest):
                self.latestStart = following
                self.latestIndex = 0
                self.renderLatest()
            self.updateFocus()
            if self.latest:
                self.preview()
            return
        return ContentHomeScreen.down(self)

    def _refreshFooterSortIndicator(self):
        """Always show selected option beneath the toolbar's SORT caption."""
        if self.kind == "vod":
            mode = getattr(self, "_moviesSortChoice", "date")
            label = {"date": "Date", "atoz": "A-Z", "ztoa": "Z-A",
                     "default": "Original"}.get(mode, "Date")
        else:
            mode = getattr(self, "sortMode", "default")
            label = {"default": "Latest", "newest": "Newest", "name": "Name",
                     "year": "Year", "rating": "Rating"}.get(mode, "Latest")
        try:
            self["moviesSortIndicator"].setText(label)
        except Exception:
            pass

    def _sortLabel(self):
        if self.kind == "vod":
            return {"date": "Latest", "atoz": "A-Z", "ztoa": "Z-A",
                    "default": "Original"}.get(getattr(self, "_moviesSortChoice", "date"), "Latest")
        return {"newest": "Newest", "name": "Name", "year": "Year",
                "default": "Latest"}.get(self.sortMode, "Latest")

    def _sortBadge(self):
        if self.kind == "vod":
            # Compact badge: the chosen option always fits inside the native
            # ChoiceBox selection frame, without long translated suffixes.
            return "[%s]" % self._sortLabel()
        return "[Sort: %s]" % self._sortLabel()

    def _sortedItems(self, items):
        if self.kind != "vod":
            return ContentHomeScreen._sortedItems(self, items)
        choice = getattr(self, "_moviesSortChoice", "date")
        if choice == "default":
            # The provider's own order, not the previous sorted list.
            return list(items or [])
        if choice in ("atoz", "ztoa"):
            rows = list(items or [])
            rows.sort(key=lambda entry: clean_display_title(
                (entry or {}).get("name") or (entry or {}).get("title") or "").casefold(),
                reverse=(choice == "ztoa"))
            return rows
        # Date follows the same package-film Latest ranking already used by
        # GENRE / PACKAGES: real provider add dates (including alternative add
        # fields) first, then release date, then year.  The previous
        # ContentHomeScreen._addedSortValue checked only `added`, so dates
        # missing on some portals left their movies in the wrong order.
        # Python's stable sort preserves provider order for equal/missing dates.
        from .genre_page import _newest_key as package_latest_key
        rows = list(items or [])
        rows.sort(key=package_latest_key, reverse=True)
        return rows

    def toggleSort(self):
        """Yellow cycles the four modes in place, as the original page did.

        Both Movies skins inherit this method. No modal screen is opened.
        """
        if self.kind != "vod":
            result = ContentHomeScreen.toggleSort(self)
            self._refreshFooterSortIndicator()
            return result
        modes = ("date", "atoz", "ztoa", "default")
        current = getattr(self, "_moviesSortChoice", "date")
        try:
            next_index = (modes.index(current) + 1) % len(modes)
        except ValueError:
            next_index = 0
        self._moviesSortChoice = modes[next_index]
        self.latest = self._sortedItems(self._activeItems())
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle()
        # Update the option directly below the toolbar SORT caption.
        self._refreshFooterSortIndicator()
        self.renderLatest()
        self.preview()
        self.updateFocus()

    def _moviesPageDesignMenu(self):
        """Three original page designs, previewed visually with gold focus."""
        if self.kind not in ("vod", "series"):
            return self.serverList()
        from .movies_page_picker import MoviesPagePicker
        self.session.openWithCallback(self._moviesPageDesignChosen,
                                      MoviesPagePicker, self.kind)

    def _moviesPageDesignChosen(self, chosen=None):
        if chosen not in ("current", "new", "grid24", "apple"):
            return
        from .movies_layout_choice import save_content_layout
        if not save_content_layout(self.kind, chosen):
            self.session.open(MessageBox, "Unable to save page design.",
                              MessageBox.TYPE_ERROR, timeout=4)
            return
        current = "new" if getattr(self, "_newMoviesGallery", False) else "current"
        if chosen == current:
            return
        if chosen == "new":
            from .movies_new_layout import NewMoviesContentScreen
            target = NewMoviesContentScreen
        elif chosen == "grid24":
            from .cinematic_catalog import CinematicCatalogScreen
            target = CinematicCatalogScreen
        elif chosen == "apple":
            from .apple_movies_layout import AppleMoviesScreen, AppleSeriesScreen
            target = AppleSeriesScreen if self.kind == "series" else AppleMoviesScreen
        else:
            target = FastMoviesContentScreen
        self._stopAutoTrailer()
        self.session.openWithCallback(self._moviesPageDesignReturn,
                                      target, dict(self.source), self.kind)

    def _moviesPageDesignReturn(self, _answer=None):
        self.close()

    def current(self):
        """Use the first selected real backdrop for the unfocused opening hero.

        Packages remains focused on entry.  The initial hero is only a visual
        preview, not a remote-control selection and cannot start the trailer.
        All other focus modes keep their existing item-selection behaviour.
        """
        if self.focus == "top" and self.backdrops:
            index = self.backdropStart + self.backdropIndex
            if 0 <= index < len(self.backdrops):
                return self.backdrops[index]
        return ContentHomeScreen.current(self)

    def _paintOpeningHero(self):
        """Connect the shared cached Backdrop/Poster artwork to the hero on entry.

        Both the main navigation and Cinema tiles open this same screen. The
        backdrop rail used to paint without triggering preview() because the
        focus deliberately stays on Packages.  Reuse the normal server-first,
        TMDb-fallback preview pipeline without changing that focus.
        """
        if self.focus != "top" or self._contentScreenDisposed:
            return
        item = self.current()
        if not isinstance(item, dict):
            return
        identity = (self.kind, id(item))
        if getattr(self, "_openingHeroIdentity", None) == identity:
            return
        self._openingHeroIdentity = identity
        self.preview()

    def _setBackdropCardVisual(self, slot, show):
        """Reveal one complete backdrop card only when its real artwork exists.

        The badge, frame, shade, rating, flag and focus remain invisible until
        ePicLoad successfully commits the correct current image to this slot.
        Empty slots never show black boxes or the #n rank overlay.
        """
        if not 0 <= int(slot) < 4:
            return
        slot = int(slot)
        image = "backdrop%d" % slot
        idx = self.backdropStart + slot
        valid_item = 0 <= idx < len(self.backdrops)
        latest = getattr(self, "_image_requests", {}).get(image)
        painted = getattr(self, "_fastRenderedArtwork", {}).get(image)
        # A lightweight, local picture is the visual fallback for a *real*
        # movie/series card.  Never mark it as downloaded artwork: a later
        # provider/TMDb image must still replace it via the original loader.
        fallback_slots = getattr(self, "_backdropFallbackSlots", {})
        fallback_identity = (idx, id(self.backdrops[idx])) if valid_item else None
        fallback_ready = fallback_slots.get(slot) == fallback_identity
        ready = bool(show and valid_item and
                     ((latest and latest == painted) or fallback_ready))
        if ready:
            self._backdropCardReadySlots.add(slot)
        else:
            self._backdropCardReadySlots.discard(slot)
        parts = (image, "backdropFrame%d" % slot,
                 "backdropShade%d" % slot, "backdropBadge%d" % slot,
                 "rank%d" % slot, "backdropLabel%d" % slot,
                 "backdropRate%d" % slot, "backdropFlag%d" % slot)
        for name in parts:
            try:
                component = self[name]
                if not ready:
                    component.hide()
                elif name == "backdropFlag%d" % slot:
                    # A flag may have decoded while its backdrop was loading.
                    if (getattr(component, "_tivimate_flag_token", None) is not None
                            and getattr(component, "_tivimate_flag_rendered", None) ==
                            getattr(component, "_tivimate_flag_token", None)):
                        component.show()
                elif name in ("backdropRate%d" % slot, "backdropLabel%d" % slot):
                    if str(component.getText() or "").strip():
                        component.show()
                else:
                    component.show()
            except Exception:
                pass
        self.updateFocus()

    def updateFocus(self):
        ContentHomeScreen.updateFocus(self)
        # Do not outline an empty/undecoded backdrop. Posters retain focus.
        try:
            if (self.focus != "backdrops" or
                    self.backdropIndex not in self._backdropCardReadySlots):
                self["backdropSelector"].hide()
        except Exception:
            pass

    def _stopBackdropFlagRetry(self):
        try:
            self._backdropFlagRetryTimer.stop()
        except Exception:
            pass
        try:
            self._backdropCountryDelay.stop()
        except Exception:
            pass

    def _resumeBackdropFlagRetry(self):
        if (self.backdrops and not self._contentScreenDisposed and
                self._backdropFlagRetryCount < 1):
            try:
                self._backdropFlagRetryTimer.start(45000, True)
            except Exception:
                pass

    def _scheduleBackdropFlagRetry(self):
        # On a cached entry, the backdrop image may paint long before a country
        # lookup completes.  One lightweight timer makes a failed first lookup
        # recoverable instead of leaving an empty flag forever.
        self._stopBackdropFlagRetry()
        self._backdropFlagRetryCount = 0
        if self.backdrops and not self._contentScreenDisposed:
            self._backdropFlagRetryTimer.start(45000, True)

    def _retryVisibleBackdropFlags(self):
        if self._contentScreenDisposed or not self.backdrops:
            return
        if self._backdropFlagRetryCount >= 1:
            return
        self._backdropFlagRetryCount += 1
        unresolved = []
        for slot in range(4):
            index = self.backdropStart + slot
            if index >= len(self.backdrops):
                continue
            item = self.backdrops[index]
            if not isinstance(item, dict):
                continue
            try:
                widget = self["backdropFlag%d" % slot]
                token = getattr(widget, "_tivimate_flag_token", None)
                if token is not None and getattr(widget, "_tivimate_flag_rendered", None) == token:
                    continue
                code = self._countryCodeFromBackdropItem(item)
                info = item.get("info") if isinstance(item.get("info"), dict) else {}
                known_id = str(item.get("tmdb_id") or item.get("_locked_tmdb_id") or
                               item.get("_tmdb_id") or item.get("tmdb") or
                               info.get("tmdb_id") or info.get("tmdb") or "").strip()
                if code or known_id.isdigit() and int(known_id) > 0:
                    self._setBackdropFlag(slot, item, force=True)
                else:
                    unresolved.append((slot, item))
            except Exception:
                pass
        if unresolved:
            self._startBackdropCountryResolve(unresolved)
        if self._backdropFlagRetryCount < 1:
            self._backdropFlagRetryTimer.start(45000, True)

    def _refreshBackdropTrailerHint(self):
        enabled = bool(self._backdropTrailerAuto)
        hint = self["backdropTrailerToggleHint"]
        hint.setText("ON" if enabled else "OFF")
        try:
            from skin import parseColor
            if hint.instance is not None:
                hint.instance.setForegroundColor(
                    parseColor('#F8D278' if enabled else '#FF3B3B'))
        except Exception:
            pass

    def _toggleBackdropTrailerAuto(self):
        """0 changes the SAME persistent preference used by Cinematic."""
        from .cinematic_catalog import _cinema_save_trailer_enabled
        self._backdropTrailerAuto = not self._backdropTrailerAuto
        _cinema_save_trailer_enabled(self._backdropTrailerAuto)
        self._stopAutoTrailer()
        self._refreshBackdropTrailerHint()
        if self._backdropTrailerAuto:
            self._scheduleBackdropTrailerCount()

    def _animateBackdropTrailerCount(self):
        # Subtle upward motion, 3 short frames once per numeral.
        if not self._backdropTrailerAuto or self._autoTrailerPlaying:
            return
        try:
            offset = max(0, 3-self._autoTrailerPhase)*7
            self["backdropTrailerCount"].instance.move(ePoint(sx(1660), sy(132+offset)))
        except Exception:
            pass
        self._autoTrailerPhase += 1
        if self._autoTrailerPhase < 4:
            try: self._autoTrailerAnim.start(85, True)
            except Exception: pass

    def _showBackdropTrailerCount(self):
        if not self._backdropTrailerAuto: return
        self["backdropTrailerCount"].setText(str(self._autoTrailerSeconds))
        self["backdropTrailerCaption"].setText("TRAILER IN")
        self["backdropTrailerCount"].show()
        self["backdropTrailerCaption"].show()
        self._autoTrailerPhase = 0
        self._animateBackdropTrailerCount()

    def _backdropTrailerFocusAllowed(self):
        # The opt-in Movies gallery may preview a real film representative of
        # the selected package. Original Movies/Series behavior is unchanged.
        if self.focus == "backdrops":
            return True
        return bool(getattr(self, "_newMoviesGallery", False) and
                    self.focus == "latest" and self.current() is not None)

    def _scheduleBackdropTrailerCount(self):
        if (not self._backdropTrailerAuto or self._contentScreenDisposed or
                self.kind not in ("vod", "series") or not self._backdropTrailerFocusAllowed() or
                VideoWindow is None or not self.current()):
            return
        self._autoTrailerSeconds = 10
        self._showBackdropTrailerCount()
        try: self._autoTrailerDelay.start(1000, True)
        except Exception: pass

    def _tickBackdropTrailerCount(self):
        if (not self._backdropTrailerAuto or self._contentScreenDisposed or
                not self._backdropTrailerFocusAllowed() or self.kind not in ("vod", "series")):
            return
        self._autoTrailerSeconds -= 1
        if self._autoTrailerSeconds <= 0:
            self["backdropTrailerCount"].hide()
            self["backdropTrailerCaption"].hide()
            self._beginAutoTrailer()
        else:
            self._showBackdropTrailerCount()
            try: self._autoTrailerDelay.start(1000, True)
            except Exception: pass

    def preview(self):
        # Focus changes immediately cancel an earlier movie's play/resolution.
        # Poster and navigation focus never trigger auto video.
        self._stopAutoTrailer()
        ContentHomeScreen.preview(self)
        from .cinematic_catalog import _cinema_trailer_enabled
        self._backdropTrailerAuto = _cinema_trailer_enabled()
        self._refreshBackdropTrailerHint()
        self._scheduleBackdropTrailerCount()

    def _beginAutoTrailer(self):
        if (not self._backdropTrailerAuto or
                self.kind not in ("vod", "series") or not self._backdropTrailerFocusAllowed() or
                self._contentScreenDisposed or VideoWindow is None or
                getattr(self, "_pageOpenBusy", False)):
            return
        item = self.current()
        if not isinstance(item, dict):
            return
        token = self._autoTrailerToken
        cache_key = (self.kind, str(item.get("tmdb_id") or item.get("tmdb") or ""),
                     str(item.get("name") or item.get("title") or "").strip().casefold(),
                     str(self._year(item) or ""))
        cached = self._autoTrailerCache.get(cache_key)
        if cached and time.time() - cached[0] < (160 if cached[1].get("state") == "ready" else 900):
            self._autoTrailerReady(token, cached[1])
            return
        # The shared bounded pool coalesces old selection requests; no thread
        # per key press and no TMDb/YouTube operations on the Enigma2 UI thread.
        _submit_content_bg(self._resolveAutoTrailer, args=(dict(item), token, cache_key),
                           key=("autotrailer", id(self)))

    def _resolveAutoTrailer(self, item, token, cache_key):
        if token != self._autoTrailerToken or self._contentScreenDisposed:
            return
        try:
            tid = item.get("tmdb_id") or item.get("_locked_tmdb_id") or item.get("tmdb")
            try:
                tid = int(str(tid or "0").strip())
            except (TypeError, ValueError):
                tid = 0
            if tid <= 0:
                tmdb = TMDbClient(language="en-US")
                title = str(item.get("name") or item.get("title") or "").strip()
                if not title:
                    return
                year = self._year(item) or None
                # TV Shows have a separate TMDb namespace from films; never
                # resolve a series against /search/movie or /movie/*/videos.
                media_kind = "series" if self.kind == "series" else "vod"
                found = tmdb.search_title(title, media_kind, year) or {}
                if not found and year:
                    found = tmdb.search_title(title, media_kind, None) or {}
                tid = int(str(found.get("id") or found.get("tmdb_id") or "0"))
            if tid <= 0 or token != self._autoTrailerToken:
                return
            result = _resolve_movie_trailer_stream(tid, "series" if self.kind == "series" else "vod")
        except Exception:
            result = {"state": "missing"}
        if token == self._autoTrailerToken and not self._contentScreenDisposed:
            self._queueGui(self._cacheAutoTrailerResult, token, cache_key, result)

    def _cacheAutoTrailerResult(self, token, cache_key, result):
        if token != self._autoTrailerToken or self._contentScreenDisposed:
            return
        self._autoTrailerCache[cache_key] = (time.time(), result)
        self._autoTrailerCache.move_to_end(cache_key)
        while len(self._autoTrailerCache) > 20:
            self._autoTrailerCache.popitem(last=False)
        self._autoTrailerReady(token, result)

    def _autoTrailerReady(self, token, result):
        if (token != self._autoTrailerToken or self.kind not in ("vod", "series") or
                not self._backdropTrailerFocusAllowed() or self._contentScreenDisposed or
                getattr(self, "_pageOpenBusy", False) or
                VideoWindow is None or result.get("state") != "ready"):
            return
        url = str(result.get("url") or "").strip()
        if not url:
            return
        try:
            nav = self.session.nav
            old = nav.getCurrentlyPlayingServiceReference()
            ref = _trailer_reference(
                url, str(result.get("name") or "Trailer"),
                5002 if result.get("split") and _trailer_has_serviceapp() else 4097)
            self._autoTrailerBackendRetried = False
            self._autoTrailerOldService = old
            self._autoTrailerService = ref
            self._autoTrailerPlaying = True
            self["trailerPreview"].show()
            nav.playService(ref)
            # Prevent finished/failed previews keeping a stale black video
            # window indefinitely. Never run an unbounded looping player.
            # New Movies plays the full available trailer and returns on EOF;
            # a ten-minute safety timeout handles streams that never send EOF.
            # The current layout keeps its original 110-second preview.
            self._autoTrailerEnd.start(600000 if getattr(self, "_newMoviesGallery", False)
                                       else 110000, True)
        except Exception:
            self._stopAutoTrailer()

    def _autoTrailerTuneFailed(self):
        if not self._autoTrailerPlaying or self._contentScreenDisposed:
            return
        ref = self._autoTrailerService
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            if (current is not None and ref is not None and
                    current.toString() != ref.toString() and
                    (self._autoTrailerOldService is None or
                     current.toString() != self._autoTrailerOldService.toString())):
                return
        except Exception:
            pass
        if (not self._autoTrailerBackendRetried and
                getattr(ref, "type", 4097) != 5002 and _trailer_has_serviceapp()):
            self._autoTrailerBackendRetried = True
            try:
                alternate = _trailer_reference(ref.getPath(), "Trailer", 5002)
                self._autoTrailerService = alternate
                self.session.nav.playService(alternate)
                return
            except Exception:
                pass
        self._stopAutoTrailer()

    def _stopAutoTrailer(self):
        self._autoTrailerToken += 1
        try:
            self._autoTrailerDelay.stop()
            self._autoTrailerEnd.stop()
            self._autoTrailerAnim.stop()
        except Exception:
            pass
        try:
            self["backdropTrailerCount"].hide()
            self["backdropTrailerCaption"].hide()
        except Exception:
            pass
        active = self._autoTrailerPlaying
        old = self._autoTrailerOldService
        ours = self._autoTrailerService
        self._autoTrailerPlaying = False
        self._autoTrailerOldService = None
        self._autoTrailerService = None
        try:
            self["trailerPreview"].hide()
        except Exception:
            pass
        if active:
            try:
                nav = self.session.nav
                current = nav.getCurrentlyPlayingServiceReference()
                # A second screen/player may have switched services; never
                # interrupt its playback when our page is hidden or closed.
                if current is not None and ours is not None and current.toString() == ours.toString():
                    nav.stopService()
                    if old is not None:
                        nav.playService(old)
            except Exception:
                pass

    def _switchContentKind(self, new_kind):
        self._stopAutoTrailer()
        if new_kind == self.kind:
            # Re-entering Movies/TV Shows from the top navigation must refresh
            # the same opening hero as opening the Cinema tile. Do not rebuild
            # the page, discard its caches, or move focus to the backdrop rail.
            self.focus = "top"
            self.updateFocus()
            self._openingHeroIdentity = None
            self._paintOpeningHero()
            self._updateFeaturedBackdropTitle()
            return
        from .movies_layout_choice import configured_movies_screen
        desired = configured_movies_screen(FastMoviesContentScreen, new_kind)
        if desired is not FastMoviesContentScreen:
            self._stopAutoTrailer()
            self._openPageOnce(desired, dict(self.source), new_kind)
            return
        self._openingHeroIdentity = None
        result = ContentHomeScreen._switchContentKind(self, new_kind)
        self._updateFeaturedBackdropTitle()
        return result

    def _openPageOnce(self, screen, *args):
        self._stopAutoTrailer()
        return ContentHomeScreen._openPageOnce(self, screen, *args)

    def ok(self):
        self._stopAutoTrailer()
        return ContentHomeScreen.ok(self)

    def _featuredBackdropTitle(self):
        if get_language() == "ar":
            return "أحدث المسلسلات" if self.kind == "series" else "أحدث الأفلام"
        return "Latest TV Shows" if self.kind == "series" else "Latest Movies"

    def _updateFeaturedBackdropTitle(self):
        if not getattr(self, "_actorMode", False):
            self["backdropTitle"].setText(self._featuredBackdropTitle())
        # Updating the mode (Movies/Series) must not leave the old logo in TV.
        self._refreshOldMoviesLatestLogo()

    def _refreshOldMoviesLatestLogo(self):
        """Current Movies/Series: display matching bilingual gold Latest logo.

        Do not touch the New or Cinematic layouts; those own their headings.
        """
        try:
            logo = self["oldLatestMoviesLogo"]
            enabled = (self.kind in ("vod", "series") and
                       self.__class__ is FastMoviesContentScreen and
                       not getattr(self, "_actorMode", False))
            if not enabled:
                logo.hide()
                self["backdropTitle"].show()
                return
            kind_prefix = "series" if self.kind == "series" else "movies"
            lang = "ar" if get_language() == "ar" else "en"
            filename = "%s_latest_title_%s.png" % (kind_prefix, lang)
            path = os.path.join(os.path.dirname(__file__), "skins", "movies", filename)
            if os.path.isfile(path) and getattr(logo, "instance", None):
                logo.instance.setPixmapFromFile(path)
                logo.show()
                self["backdropTitle"].hide()
            else:
                logo.hide()
                self["backdropTitle"].show()
        except Exception:
            pass

    def loadImage(self, url, widget, width, height, fallback_item=None):
        # Repainting the same full-HD backdrop invokes an expensive ePicLoad
        # decode on receivers even when the artwork has not changed.
        url = (url or "").strip().replace("\\/", "/")
        if url and widget not in ("logoImage", "promoBanner") and getattr(self, "_fastRenderedArtwork", {}).get(widget) == url:
            return
        if widget == "hero":
            width, height = 1920, 1080
        return ContentHomeScreen.loadImage(
            self, url, widget, width, height, fallback_item=fallback_item)

    def _applyPreviewArtwork(self, backdrop, logo, request_id, banner=""):
        """Keep a successfully decoded Hero image; do not suppress candidates
        merely because a different URL is pending or marked as selected.
        """
        if request_id != self._previewRequestId:
            return
        current = self.current()
        if isinstance(current, dict):
            if backdrop:
                identity = self._genreHeroIdentity('hero', current)
                if identity is not None and getattr(self, '_genreHeroDecoded', {}).get('hero') == identity:
                    backdrop = ""
            if logo:
                identity = self._genreHeroIdentity('logoImage', current)
                if identity is not None and getattr(self, '_genreHeroDecoded', {}).get('logoImage') == identity:
                    logo = ""
        return ContentHomeScreen._applyPreviewArtwork(self, backdrop, logo, request_id, banner)

    def _loadBackdropsLegacyMovies(self, generation=None):
        """Fast random Backdrop rail from enabled packages only.

        The rail never leaves the user's active Movies/TV Shows package filter.
        Every package enabled in the active Package Filter can contribute,
        regardless of provider name, language, country or release year.
        Both rails exclude wrestling, sports, programmes, documentaries,
        unscripted reality, anime and cartoons. Both rails deduplicate titles.
        Prefer diverse packages, provider artwork and cached responses;
        never block each card on TMDb verification.
        """
        if generation is None:
            generation = self.contentGeneration
        kind = self.kind
        page_kind = "vod" if self.kind == "vod" else "series"
        source = dict(self.source or {})
        try:
            saved_allowed = get_allowed_category_ids(source, page_kind)
            client = get_source_client(source)
            category_names = {}
            category_order = []
            m3u_entries = None
            categories_seed = None

            # Fast Backdrop startup:
            # - Existing saved package filters use RAM/disk metadata immediately.
            # - A brand-new image/server may read categories once to discover the
            #   currently enabled package IDs.
            # - An empty result stays silent and never triggers a blocking retry.
            if saved_allowed is None:
                cache_version = "v43_kind_verified_image_recovery"
                cache_mode = "backdrop_all_enabled_%s_%s_all" % (cache_version, page_kind)
                self._featuredBackdropCacheMode = cache_mode
                fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
                if fresh_cached:
                    self._queueGui(
                        self.backdropsReady,
                        fresh_cached[:self.BACKDROP_ITEM_LIMIT],
                        generation, fresh_cached[self.BACKDROP_ITEM_LIMIT:]
                    )
                    return

                if source.get("type") in ("m3u", "fg"):
                    try:
                        m3u_entries, _m3u_origin = get_cached_catalog(
                            source, "live", lambda: M3UClient(source).entries(),
                            wait_for_server=True
                        )
                    except Exception:
                        m3u_entries = []
                    allowed = set(
                        str((row or {}).get("group") or (row or {}).get("category_id") or "").strip()
                        for row in (m3u_entries or [])
                        if isinstance(row, dict) and M3UClient._entry_kind(row) == page_kind
                    )
                else:
                    try:
                        categories_seed, _cat_origin = get_cached_categories(
                            source, page_kind, client=client, wait_for_server=True
                        )
                    except Exception:
                        categories_seed = []
                    allowed = set(
                        str((cat or {}).get("category_id") or (cat or {}).get("id") or
                            (cat or {}).get("genre_id") or (cat or {}).get("group_id") or "").strip()
                        for cat in (categories_seed or [])
                        if isinstance(cat, dict)
                    )
            else:
                allowed = set(str(x) for x in (saved_allowed or []) if str(x))
                if not allowed:
                    self._queueGui(self.backdropsReady, [], generation, [])
                    return

                filter_sig = hashlib.sha1(("|".join(sorted(allowed))).encode("utf-8")).hexdigest()[:12]
                cache_version = "v43_kind_verified_image_recovery"
                cache_mode = "backdrop_all_enabled_%s_%s_%s" % (cache_version, page_kind, filter_sig)
                self._featuredBackdropCacheMode = cache_mode
                fresh_cached = _home_feed_cache_get(cache_mode, source, allow_stale=False)
                if fresh_cached:
                    self._queueGui(
                        self.backdropsReady,
                        fresh_cached[:self.BACKDROP_ITEM_LIMIT],
                        generation, fresh_cached[self.BACKDROP_ITEM_LIMIT:]
                    )
                    return
            if source.get("type") in ("m3u", "fg"):
                try:
                    if m3u_entries is None:
                        m3u_entries, _m3u_origin = get_cached_catalog(
                            source, "live", lambda: M3UClient(source).entries(),
                            wait_for_server=True
                        )
                    # M3U "Movies" group labels often identify live TV genres.
                    # Match M3UClient.streams(kind) classification exactly.
                    m3u_entries = [r for r in (m3u_entries or [])
                                   if isinstance(r, dict) and
                                   M3UClient._entry_kind(r) == page_kind]
                except Exception:
                    m3u_entries = []
                for raw in list(m3u_entries or []):
                    if not isinstance(raw, dict):
                        continue
                    cid = str(raw.get("group") or raw.get("category_id") or "").strip()
                    if not cid or cid not in allowed:
                        continue
                    if cid not in category_names:
                        category_names[cid] = cid
                        category_order.append(cid)
            try:
                if m3u_entries is not None:
                    categories, _origin = [], "m3u"
                elif categories_seed is not None:
                    categories, _origin = list(categories_seed or []), "seed"
                else:
                    categories, _origin = get_cached_categories(
                        source, page_kind, client=client, wait_for_server=True
                    )

                # With a saved package filter, an empty metadata cache means the
                # background category refresh has only just started. Do not wait
                # here and do not compete with the normal Series page loading.


                for cat in categories or []:
                    if not isinstance(cat, dict):
                        continue
                    cid = str(cat.get("category_id") or "")
                    if not cid or cid not in allowed:
                        continue
                    name = str(
                        cat.get("category_name") or cat.get("name") or
                        cat.get("title") or ""
                    )
                    category_names[cid] = name
                    if cid not in category_order:
                        category_order.append(cid)
            except Exception:
                pass

            # Keep only the user's enabled package IDs. Categories of any name
            # (VOD, Netflix, HBO, Apple, Prime, etc.) are eligible; no brand,
            # region, language, year or 20-package whitelist. Movies then
            # exclude non-movie categories only in prepare_row().
            category_order = [cid for cid in category_order if cid in allowed]
            if not category_order:
                # Package IDs remain usable before category-name metadata arrives.
                category_order = list(allowed)
            ordered_ids = list(dict.fromkeys(category_order))
            random.shuffle(ordered_ids)
            if not ordered_ids:
                raise RuntimeError("No enabled packages for Backdrop")

            target_count = self.BACKDROP_ITEM_LIMIT
            seen = set()

            def prepare_row(raw, cid):
                if not isinstance(raw, dict):
                    return None
                # Defense-in-depth for mixed M3U groups and imported lists.
                if m3u_entries is not None and M3UClient._entry_kind(raw) != page_kind:
                    return None
                item_cid = str(
                    raw.get("category_id") or raw.get("categoryId") or
                    raw.get("genre_id") or raw.get("genre-id") or cid
                )
                if item_cid and item_cid not in allowed:
                    return None
                # Keep Movies and TV Shows separate. Exclude broadcasts and
                # non-scripted categories in BOTH featured rails, not packages.
                declared_type = str(raw.get("media_type") or raw.get("content_type") or "").lower().strip()
                if page_kind == "vod" and declared_type in ("series", "tv", "tvshow", "episode", "live", "channel"):
                    return None
                if page_kind == "series" and declared_type in ("movie", "vod", "film", "live", "channel"):
                    return None
                if page_kind == "vod" and not _featured_movie_allowed(raw, category_names.get(str(cid), "")):
                    return None
                if page_kind == "series" and not _featured_series_allowed(raw, category_names.get(str(cid), "")):
                    return None
                title = str(raw.get("name") or raw.get("title") or "").strip()
                if not title:
                    return None
                row = dict(raw)
                display_title = self._backdropDisplayTitle(title)
                dedupe_title = re.sub(r"[^a-z0-9\u0600-\u06ff]+", " ", display_title.lower()).strip()
                if not dedupe_title:
                    return None
                key = "title:%s" % dedupe_title
                if key in seen:
                    return None
                seen.add(key)
                row["_display_title"] = display_title
                row["_you_might_like"] = True
                row["_source_category_id"] = str(cid)
                row["_source_category_name"] = category_names.get(str(cid), "")
                try:
                    year_value = str(self._year(raw) or "").strip()[:4]
                except Exception:
                    year_value = ""
                if year_value:
                    row["_backdrop_year"] = year_value
                return row

            # Gather candidates from several independent enabled packages,
            # not just the first batch yielding target_count films.
            package_pools = {}
            batch_size = 4
            for offset in range(0, len(ordered_ids), batch_size):
                batch_ids = ordered_ids[offset:offset + batch_size]
                if m3u_entries is not None:
                    package_batches = []
                    for cid in batch_ids:
                        rows = [
                            raw for raw in list(m3u_entries or [])
                            if isinstance(raw, dict)
                            and str(raw.get("group") or raw.get("category_id") or "").strip() == str(cid)
                        ]
                        package_batches.append((cid, rows, "m3u"))
                else:
                    package_batches = get_category_streams_batch(
                        source, page_kind, client, batch_ids,
                        use_cache=True, wait_for_server=True, max_workers=4
                    )
                for cid, rows, _origin in package_batches:
                    # A bounded random sample per package avoids a very large
                    # catalogue dominating memory/CPU and gives diversity.
                    rows = list(rows or [])
                    if len(rows) > 120:
                        rows = random.sample(rows, 120)
                    else:
                        random.shuffle(rows)
                    accepted = []
                    for raw in rows:
                        row = prepare_row(raw, cid)
                        if row is not None:
                            accepted.append(row)
                            if len(accepted) >= target_count:
                                break
                    if accepted:
                        package_pools[str(cid)] = accepted

                # Get diverse choices without scanning every active category
                # unnecessarily. If the first batch has few valid pictures,
                # subsequent batches are attempted automatically.
                pictured_packages = 0
                pictured_rows = 0
                for rows in package_pools.values():
                    count = sum(bool(self.imageUrl(row, True)) for row in rows)
                    pictured_rows += count
                    pictured_packages += bool(count)
                if pictured_rows >= target_count + 3 and (pictured_packages >= min(5, len(ordered_ids)) or
                                                           offset + batch_size >= min(len(ordered_ids), 12)):
                    break

            if not package_pools:
                raise RuntimeError("No usable Backdrop content in enabled packages")

            # No blocking TMDb country/year/language validation. Such checks
            # caused the rail to shrink or show nothing with legitimate VOD.
            # Select balanced content from active packages using artwork already
            # provided by the server or metadata cache.
            candidates = _balanced_featured_select(package_pools, target_count * 6)
            with_art = []
            without_art = []
            for item in candidates:
                has_landscape_url = bool(self.imageUrl(item, True))
                (with_art if has_landscape_url else without_art).append(item)
            # A source may supply only poster URLs even when TMDb has several
            # proper backdrops. Keep those titles eligible for asynchronous
            # TMDb backdrop resolution, but NEVER show their posters here.
            verified_rows = with_art + without_art
            if not verified_rows:
                raise RuntimeError("No featured titles in enabled packages")
            selected = verified_rows[:target_count]
            reserve = verified_rows[target_count:target_count + 3]
            # Cache all displayed artwork choices and three backups. Cache key
            # changed above so old restrictive selections cannot reappear.
            _home_feed_cache_put(cache_mode, source, selected + reserve)
            self._queueGui(self.backdropsReady, selected, generation, reserve)
        except Exception as exc:
            self._queueGui(self.backdropsFailed, str(exc), generation)



    def recentReady(self, token, recent, categories, generation=None, partial=False):
        """Apply a Recent Added result once, without losing last-good content.

        Provider failures and incomplete scans can return no items.  An empty
        response is never evidence that previously verified titles vanished.
        Enigma2 widgets are updated via _queueGui, never from the worker.
        """
        if (getattr(self, "_contentScreenDisposed", False) or
                self.contentMode != "recent" or
                token != self.recentRequestToken or
                (generation is not None and generation != self.contentGeneration)):
            return
        if categories:
            self.categoriesList = list(categories)
            self.categoriesLoaded = True
        rows = self._sortedItems(recent or [])
        rows = _screen_dedupe_content(rows, self.kind)[:25]
        if not rows:
            # Preserve existing posters/cursor on temporary provider failures,
            # empty cooldown and incomplete Stalker/Xtream catalogues.
            if self.recentStable or self.latest:
                return
            rows = _screen_dedupe_content(
                _home_feed_cache_get("recent_%s" % self.kind, self.source,
                                     allow_stale=True), self.kind)[:25]
            if not rows:
                self["heroDesc"].setText(
                    "Recent content is temporarily unavailable. The server will be retried on the next visit.")
                return
        previous = list(self.latest or [])
        previous_ids = [str((r or {}).get("stream_id") or
                            (r or {}).get("series_id") or
                            (r or {}).get("id") or "") for r in previous]
        new_ids = [str((r or {}).get("stream_id") or
                       (r or {}).get("series_id") or
                       (r or {}).get("id") or "") for r in rows]
        self.recentStable = list(rows)
        self.categoryName = "RECENT ADDED"
        self.categoryIndex = -1
        self.categoryItems = list(rows)
        # Successful refreshes keep the verified cache fresh even if the IDs
        # do not change. Avoid re-decoding unchanged posters on the GUI.
        if recent:
            _submit_content_bg(
                _home_feed_cache_put,
                args=("recent_%s" % self.kind, dict(self.source), list(rows)),
                key=("recent-cache", id(self), self.kind))
        if new_ids == previous_ids and len(previous) == len(rows):
            return  # Avoid blinking and re-decoding unchanged posters.
        self.latest = rows
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle()
        self.renderLatest()
        self.updateFocus()

    def serverReady(self, latest, allItems=None, categories=None, landingCategory=None, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        if not self._usingLandingSnapshot:
            self._rememberLandingSnapshot(latest, allItems, categories, landingCategory)
        self.serverItems = list(allItems or [])
        self.categoryItems = []
        self.categoriesList = list(categories or [])

        # Build one in-memory category map once. This removes the repeated
        # full-catalog scan that used to happen on every package key press.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        # _categoryRowsIndex had no readers; it duplicated the provider
        # catalogue's row references on every page open for no benefit.
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        landing_id = str((landingCategory or {}).get("category_id") or "")
        landing_name = (landingCategory or {}).get("category_name") or ""
        if landing_id == "__recent_added__":
            self.categoryIndex = -1
            self.categoryName = landing_name or "RECENT ADDED"
            self.categoryItems = list(allItems or [])
            self._updateLatestTitle()
        elif landing_id:
            for index, category in enumerate(self.categoriesList):
                if str(category.get("category_id") or "") == landing_id:
                    self.categoryIndex = index
                    self.categoryName = category.get("category_name") or landing_name or "Other"
                    self._updateLatestTitle()
                    self.categoryItems = list(allItems or [])
                    if landing_id:
                        self._rememberPackageRows(landing_id, self.categoryItems)
                    break
        server_latest = latest or []

        # SERVER/PACKAGE POSTERS ARE A SEPARATE PERMANENT PATH.
        # NONE means: no automatic Netflix/Prime/Trending lower feed.
        # It does NOT disable server packages, Recent Added, or their posters.
        if self.contentMode in ("none", "recent"):
            self.latest = _screen_dedupe_content(server_latest, self.kind)
            self.latestStart = self.latestIndex = 0
            if self.latest and not self._usingLandingSnapshot:
                _submit_content_bg(_save_content_landing_cache,
                                   args=(dict(self.source), self.kind, list(self.latest)[:64]),
                                   key=("landing-cache", id(self), self.kind))
            self._updateLatestTitle()
            self.renderLatest()
        elif not self.latest:
            # Automatic provider modes are supplied later by TMDb.
            self.latest = []
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()
        if self.source.get("type") == "stalker" and not self.latest:
            self["heroDesc"].setText(tr("Stalker packages are ready. Open Categories and select a package to load its titles."))
        if not self.backdrops:
            # Keep the opening focus on the top navigation. Once the user presses
            # DOWN, focus goes to Backdrops first (or Latest only if Trending is unavailable).
            if self.focus != "top":
                self.focus = "backdrops" if self.backdrops else ("latest" if self.latest else "backdrops")
                self.preview()
            self.updateFocus()
        # The earlier serverReady definition was shadowed by this override.
        # Repaint the opening Hero once real server items become available.
        self._paintOpeningHero()


    def _loadBackdrops(self, generation=None):
        if self.kind not in ("vod", "series") or getattr(self, "_actorMode", False):
            return ContentHomeScreen._loadBackdrops(self, generation)
        lock = self._packageBackdropRefreshLock
        if not lock.acquire(False):
            return
        try:
            return self._loadPackagesBackdrops(generation)
        finally:
            lock.release()

    def _loadPackagesBackdrops(self, generation=None):
        """Backdrop from PACKAGES cache, sorted by the package's newest item.

        Paint existing Packages cache immediately, then fill missing packages
        on the same background worker with at most two provider requests at
        once. Only *complete* results receive the five-hour selection TTL.
        Keep the existing artwork workers/queue and GENRE completely separate.
        """
        if self.kind not in ("vod", "series") or getattr(self, "_actorMode", False):
            return ContentHomeScreen._loadBackdrops(self, generation)
        if generation is None:
            generation = self.contentGeneration
        source = dict(self.source or {})
        kind = self.kind
        if generation != self.contentGeneration or self._contentScreenDisposed:
            return
        try:
            snapshot_mode = _package_backdrop_snapshot_mode(source, kind)
            snapshot_all = (_home_feed_cache_get(snapshot_mode, source, allow_stale=True)
                            if _genre_snapshot_matches_cache(snapshot_mode, source) else [])
            snapshot = [row for row in snapshot_all
                        if not _cinematic_backdrop_temporarily_missing(source, kind, row)
                        and not (isinstance(row, dict) and row.get("_featured_alt_backdrop"))]
            has_snapshot = bool(snapshot)
            series_packages_changed = False
            if (has_snapshot and len(snapshot) == len(snapshot_all) and
                    _package_backdrop_snapshot_is_fresh(snapshot_mode, source)):
                # Fresh for five hours only while the MOVIES/SERIES package
                # contents stay identical: a newly added title shows at once.
                row = _home_feed_cache_load().get(
                    _home_feed_cache_key(snapshot_mode, source)) or {}
                current_revision = _series_packages_cache_revision(source, kind)
                if (current_revision is None or
                        current_revision == row.get("selection_packages_revision")):
                    return
                series_packages_changed = True

            # Read exactly the same category and per-package caches used by the
            # Packages page. Do NOT read genre/latest_order.json or fetch every
            # package from its provider when the cache is incomplete.
            categories, _origin = get_cached_categories(
                source, kind, client=None, wait_for_server=False)
            if generation != self.contentGeneration or self._contentScreenDisposed:
                return
            if not categories:
                # Cold installation: no saved Packages category catalog yet.
                # This runs on a background thread, so waiting once is safe.
                try:
                    categories, _origin = get_cached_categories(
                        source, kind, client=get_source_client(source),
                        wait_for_server=True)
                except Exception:
                    categories = []
                if generation != self.contentGeneration or self._contentScreenDisposed:
                    return
            if not categories:
                return  # Keep last-good rail if the provider supplied no categories.
            categories = filter_categories(source, kind, categories or [])
            allowed = get_allowed_category_ids(source, kind)
            enabled = None if allowed is None else {str(cid) for cid in allowed if str(cid)}
            if enabled is not None and not enabled:
                self._queueGui(self.backdropsReady, [], generation, [])
                return

            exclude = (
                "sport", "sports", "football", "soccer", "wwe", "wrestling",
                "ufc", "mma", "boxing", "basketball", "tennis", "formula 1",
                "formula1", "f1", "racing", "race", "music", "musical",
                "songs", "song", "radio", "concert", "theatre", "theater",
                "stage play", "plays", "مسرح", "مسرحيات", "اغاني", "أغاني",
                "موسيقى", "رياضة", "رياضي", "كرة قدم", "مصارعة", "ملاكمة"
            )

            def date_value(raw):
                if raw in (None, ""):
                    return 0
                try:
                    value = int(float(raw))
                    if value > 100000000000:
                        value //= 1000
                    if value > 100000000:
                        return value
                except (ValueError, TypeError, OverflowError):
                    pass
                text = str(raw).strip().replace("T", " ").replace("Z", "")
                for pattern, width in (("%Y-%m-%d %H:%M:%S", 19),
                                       ("%Y-%m-%d", 10),
                                       ("%Y/%m/%d %H:%M:%S", 19),
                                       ("%Y/%m/%d", 10)):
                    try:
                        return int(time.mktime(time.strptime(text[:width], pattern)))
                    except (ValueError, TypeError, OverflowError):
                        continue
                return 0

            def item_rank(item):
                """Real provider add/update date first; release date only fallback."""
                if not isinstance(item, dict):
                    return (0, 0)
                fields = ("added", "added_timestamp", "added_at", "date_added",
                          "created_at", "timestamp")
                # Match Packages Latest: a season/episode update is not a newly
                # added show. Use last_modified only if no add date exists.
                if kind == "series":
                    fields += ("last_modified",)
                for field in fields:
                    stamp = date_value(item.get(field))
                    if stamp:
                        return (2, stamp)
                for field in ("release_date", "releaseDate", "releasedate",
                              "release_date_utc", "first_air_date"):
                    stamp = date_value(item.get(field))
                    if stamp:
                        return (1, stamp)
                try:
                    year = int(str(item.get("year") or "")[:4])
                    if 1800 <= year <= 2200:
                        return (1, int(time.mktime((year, 1, 1, 0, 0, 0, 0, 0, -1))))
                except (ValueError, TypeError, OverflowError):
                    pass
                return (0, 0)

            packages, seen_ids = [], set()
            for category in categories:
                if isinstance(category, dict):
                    cid = str(category.get("category_id") or category.get("id") or "").strip()
                    name = str(category.get("category_name") or category.get("name") or
                               category.get("title") or "").strip()
                elif isinstance(category, (list, tuple)) and len(category) >= 2:
                    name, cid = str(category[0] or "").strip(), str(category[1] or "").strip()
                else:
                    continue
                if (not cid or not name or cid.startswith("__") or cid in seen_ids or
                        (enabled is not None and cid not in enabled) or
                        any(term in name.casefold() for term in exclude)):
                    continue
                seen_ids.add(cid)
                packages.append({"id": cid, "name": name, "order": len(packages)})
            if not packages:
                return

            # No GENRE sort metadata: derive package order from the same cached
            # per-package titles used by the pinned Latest Packages page.
            for package in packages:
                if generation != self.contentGeneration or self._contentScreenDisposed:
                    return
                rows, _origin = peek_category_streams_cache(source, kind, package["id"])
                package["rows"] = rows or []
                package["latest"] = max((item_rank(r) for r in (rows or [])), default=(0, 0))
            packages.sort(key=lambda p: (p["latest"], -p["order"]), reverse=True)

            def choose_from_cached_packages():
                selected, signatures = [], []
                for package in packages:
                    if generation != self.contentGeneration or self._contentScreenDisposed:
                        return
                    if len(selected) >= self.BACKDROP_ITEM_LIMIT:
                        break
                    items = package["rows"]
                    if not items:
                        continue
                    rows = []
                    for raw in items:
                        if not isinstance(raw, dict):
                            continue
                        row = dict(raw)
                        row.setdefault("category_id", package["id"])
                        row.setdefault("category_name", package["name"])
                        row["_source_category_id"] = package["id"]
                        row["_source_category_name"] = package["name"]
                        rows.append(row)
                    try:
                        rows = filter_items_for_source(source, kind, rows)
                    except Exception:
                        pass
                    rows = [r for r in rows if isinstance(r, dict) and
                            str(r.get("name") or r.get("title") or "").strip()]
                    rows.sort(key=item_rank, reverse=True)  # stable on undated ties
                    added = 0
                    for row in rows:
                        identity = _featured_film_signature(row)
                        if (not identity[0] or
                                _featured_film_is_duplicate(identity, signatures) or
                                _featured_backdrop_wrestling_blocked(row, package["name"]) or
                                _cinematic_backdrop_temporarily_missing(source, kind, row)):
                            continue
                        selected.append(row)
                        signatures.append(identity)
                        added += 1
                        if added >= 2 or len(selected) >= self.BACKDROP_ITEM_LIMIT:
                            break

                return selected

            def expand_with_more_info(selected):
                """Fill *empty slots*, after cache-first paint/provider checks.

                Reuse the TMDb image set behind Movie More Info, always tied
                to the verified movie ID. Do not alter Packages selection (two
                distinct titles per package) or artwork worker queues.
                """
                limit = self.BACKDROP_ITEM_LIMIT
                expanded = list(selected or [])[:limit]
                if len(expanded) >= limit or not expanded:
                    return expanded
                try:
                    tmdb = TMDbClient()
                    if not tmdb.configured():
                        return expanded
                except Exception:
                    return expanded
                galleries = []
                # A finite supplement, not a prefetch of the whole catalogue.
                for row in expanded[:8]:
                    if generation != self.contentGeneration or self._contentScreenDisposed:
                        return expanded[:limit]
                    title = str(row.get("name") or row.get("title") or "").strip()
                    year = self._year(row) or None
                    tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
                    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
                        tmdb_id = ""
                    if not tmdb_id:
                        try:
                            verified = _cinematic_verified_get(source, kind, row)
                            tmdb_id = str(verified.get("tmdb_id") or "").strip()
                        except Exception:
                            tmdb_id = ""
                    if (not tmdb_id or not tmdb_id.isdigit()) and title:
                        # Identical TMDb title lookup policy to Movie Details;
                        # never treat a portal stream ID as a TMDb ID.
                        try:
                            match = tmdb.search_title(title, kind, year) or {}
                            tmdb_id = str(match.get("id") or match.get("tmdb_id") or "").strip()
                        except Exception:
                            tmdb_id = ""
                    if not tmdb_id.isdigit() or int(tmdb_id) < 1:
                        galleries.append([])
                        continue
                    try:
                        bundle = tmdb.details_bundle(tmdb_id, kind) or {}
                    except Exception:
                        bundle = {}
                    if not isinstance(bundle, dict):
                        bundle = {}
                    paths = _tmdb_same_movie_backdrops(bundle)
                    if len(paths) < 2:
                        # Same extra TMDb images route used by More Info.
                        media = "movie" if kind == "vod" else "tv"
                        try:
                            images = tmdb._get("/%s/%s/images" % (media, tmdb_id),
                                               {"include_image_language": image_languages(tmdb, bundle, row)}) or {}
                            if isinstance(images, dict):
                                payload = dict(bundle)
                                payload["images"] = images
                                paths = _tmdb_same_movie_backdrops(payload)
                        except Exception:
                            pass
                    current = (_server_backdrop_url(source, row) or row.get("_tmdb_backdrop") or
                               row.get("backdrop_path") or "")
                    seen = {_tmdb_backdrop_identity(current)} if current else set()
                    variants = []
                    for path in paths:
                        url = self.norm(path)
                        key = _tmdb_backdrop_identity(url)
                        if not url or key in seen:
                            continue
                        seen.add(key)
                        extra = dict(row)
                        extra["tmdb_id"] = tmdb_id
                        extra["_tmdb_backdrop"] = url
                        extra["backdrop_path"] = url
                        extra["_featured_alt_backdrop"] = True
                        extra["_featured_alt_index"] = len(variants) + 1
                        variants.append(extra)
                        if len(variants) >= 4:  # More Info shows up to five images.
                            break
                    galleries.append(variants)
                # Spread extra images across selected films, rather than filling
                # the row with repeated shots of the first movie.
                offset = 0
                while len(expanded) < limit:
                    progress = False
                    for gallery in galleries:
                        if len(expanded) >= limit:
                            break
                        if offset < len(gallery):
                            expanded.append(gallery[offset])
                            progress = True
                    if not progress:
                        break
                    offset += 1
                return expanded[:limit]

            def same_selection(a, b):
                return [_featured_backdrop_variant_identity(x) for x in a] == [
                        _featured_backdrop_variant_identity(x) for x in b]

            def publish_selection(items, missing, retry_at):
                if generation != self.contentGeneration or self._contentScreenDisposed:
                    return
                if not items:
                    return
                # Never replace an already-visible full rail with fewer images
                # while TMP/Packages data is still being populated.
                if (snapshot and len(items) < len(snapshot) and
                        not (series_packages_changed and not missing)):
                    return
                unique_titles = len({tuple(_featured_film_signature(row)) for row in items if isinstance(row, dict) and _featured_film_signature(row)[0]})
                complete = not missing or unique_titles >= self.BACKDROP_ITEM_LIMIT
                _home_feed_cache_put(snapshot_mode, source, items,
                                     package_complete=complete,
                                     package_retry_at=(0 if complete else retry_at),
                                     package_revision=_series_packages_cache_revision(source, kind))
                if not same_selection(items, self.backdrops):
                    self._queueGui(self.backdropsReady, items, generation, [])

            missing = [p for p in packages if not p["rows"]]
            selected = choose_from_cached_packages()
            # First paint is solely from warm RAM/disk caches: no network wait.
            # Partial selections remain marked incomplete rather than pinned 5h.
            previous_row = _home_feed_cache_load().get(
                _home_feed_cache_key(snapshot_mode, source)) or {}
            # An HDD->TMP switch or a new TMP boot invalidates old retry
            # cooldowns, just as it invalidates the old snapshot itself.
            next_retry = (float(previous_row.get("selection_retry_at") or 0)
                          if previous_row.get("selection_cache_scope") ==
                          _genre_backdrop_cache_scope() else 0)
            can_fetch = bool(missing and len(selected) < self.BACKDROP_ITEM_LIMIT and
                             time.time() >= next_retry)
            retry_at = (time.time() + 120 if can_fetch else next_retry)
            publish_selection(selected, missing, retry_at)

            if not can_fetch:
                # Gallery work must never block the initial cache-first paint.
                return
            # v56/v57 stopped after six *missing packages*, not six usable
            # packages. Some packages return just one usable title (or none),
            # leaving a 4-5 card rail for the rest of the screen session.
            # Keep the cache-first first paint, then try more missing packages
            # in the background until 12 distinct titles are available.
            # This is a finite per-opening budget, NOT a full catalog prefetch.
            try:
                client = get_source_client(source)
            except Exception:
                client = None
            if client is None:
                return
            remaining = min(len(missing), 16)
            # Freeze this request list. 'missing' is recalculated after each
            # successful batch; iterating that changing list would skip groups.
            pending = missing[:remaining]
            for offset in range(0, len(pending), 2):
                if generation != self.contentGeneration or self._contentScreenDisposed:
                    return
                batch = pending[offset:offset + 2]
                try:
                    results = get_category_streams_batch(
                        source, kind, client, [p["id"] for p in batch],
                        use_cache=True, wait_for_server=True, max_workers=2)
                except Exception:
                    # A single broken provider request must not discard the
                    # already-visible cached backdrops or crash the screen.
                    continue
                by_id = {str(cid): rows for cid, rows, _origin in results if rows}
                changed = False
                for package in batch:
                    rows = by_id.get(package["id"])
                    if rows:
                        package["rows"] = rows
                        package["latest"] = max(
                            (item_rank(r) for r in rows), default=(0, 0))
                        changed = True
                if not changed:
                    continue
                packages.sort(key=lambda p: (p["latest"], -p["order"]), reverse=True)
                missing = [p for p in packages if not p["rows"]]
                updated = choose_from_cached_packages()
                publish_selection(updated, missing, time.time() + 120)
                if len(updated) >= self.BACKDROP_ITEM_LIMIT:
                    break
            # Fill any remaining slots with alternate images for the selected
            # movies/series, using More Info's TMDb gallery after first paint.
            if generation == self.contentGeneration and not self._contentScreenDisposed:
                # No repeated images of the same title: the next card is the
                # next newest title of another enabled package.
                pass
            # If fewer than 12 usable titles were found, keep the partial
            # rail visible. Do not lock the incomplete selection for five
            # hours while uncached packages may still be available.
            # More provider lookups need another opening after cooldown.
        except Exception as exc:
            if not self.backdrops:
                self._queueGui(self.backdropsFailed, str(exc), generation)

    def backdropsReady(self, backdrops, generation=None, lower_items=None):
        if generation is not None and generation != self.contentGeneration:
            return
        if self.kind not in ("vod", "series") or getattr(self, "_actorMode", False):
            return ContentHomeScreen.backdropsReady(self, backdrops, generation, lower_items)
        # The worker already chose distinct GENRE Latest titles and may have
        # selected several titles from one package; don't collapse that list
        # by package or stream ID here (HD/4K copies have different IDs).
        incoming = [dict(row) for row in (backdrops or [])
                    if isinstance(row, dict) and
                    not _featured_backdrop_wrestling_blocked(row)][:self.BACKDROP_ITEM_LIMIT]
        def selection_ids(rows):
            return [_featured_backdrop_variant_identity(row) for row in rows]
        if incoming and selection_ids(incoming) == selection_ids(self.backdrops):
            return  # Keep pixmaps, request tokens, cursor and auto-trailer.
        previous = self.backdrops
        previous_focus = self.focus
        previous_start = self.backdropStart
        previous_index = self.backdropIndex
        self.backdrops = incoming
        try:
            self._updateFeaturedBackdropTitle()
        except Exception:
            pass
        if self.backdrops:
            self.backdropStart, self.backdropIndex = _restore_backdrop_cursor(
                previous, self.backdrops, previous_start, previous_index)
            # Painting the first cached/network Backdrops must not steal the
            # focus from Packages; only remote-control navigation may do that.
            self.focus = previous_focus
        self.renderBackdrops()
        # The two-per-package worker already sorted this rail. The older
        # delayed global sort would scatter one package's two items.
        self._stopBackdropNewestSortTimer()
        if self.focus == "backdrops":
            self.preview()
        elif self.focus == "top":
            self._paintOpeningHero()
        self.updateFocus()

    def _resolveBackdropFlagIdentity(self, slot, item, ticket):
        """Find only the TMDb ID/country for a visible card; never replace art.

        Run in the existing bounded background pool. A provider backdrop is NOT
        evidence that country metadata exists, and it must not suppress flags.
        """
        try:
            title = str(item.get("name") or item.get("title") or
                        item.get("original_title") or item.get("original_name") or "").strip()
            if not title:
                return
            kind = ticket[1]
            year = self._year(item) or None
            tmdb = TMDbClient()
            # search_title already tries year and fallback-to-no-year; a
            # second call duplicates expensive network attempts on misses.
            match = tmdb.search_title(title, kind, year) or {}
            tmdb_id = str(match.get("id") or match.get("tmdb_id") or "").strip()
            if not tmdb_id.isdigit() or int(tmdb_id) <= 0:
                return
            # TV search results can already include origin_country. For movies
            # or missing codes, country_flags resolves production country from
            # this ID on its own dedicated worker (and its existing disk cache).
            country = self._countryCodeFromBackdropItem(match)
            self._queueGui(self._applyBackdropFlagIdentity, slot, item, ticket, tmdb_id, country)
        except Exception:
            pass
        finally:
            # Failed lookups must release this ticket; otherwise a later
            # visit/retry cannot queue the same card again.
            self._queueGui(self._completeBackdropFlagResolve, slot, ticket)

    def _completeBackdropFlagResolve(self, slot, ticket):
        if self._backdropFlagResolveJobs.get(slot) == ticket:
            self._backdropFlagResolveJobs.pop(slot, None)

    def _applyBackdropFlagIdentity(self, slot, item, ticket, tmdb_id, country):
        """Refresh only the still-visible card; never apply an old page result."""
        try:
            if getattr(self, "_contentScreenDisposed", False):
                return
            if self._backdropFlagResolveJobs.get(slot) != ticket:
                return
            if self.contentGeneration != ticket[0] or self.kind != ticket[1]:
                return
            index = self.backdropStart + int(slot)
            if index != ticket[2] or not (0 <= index < len(self.backdrops)):
                return
            if self.backdrops[index] is not item:
                return
            item["tmdb_id"] = tmdb_id
            if country:
                self._rememberBackdropFlagCountry(item, country)
            self._setBackdropFlag(slot, item)
        except Exception:
            pass

    def _deferBackdropCountryResolve(self):
        """Do not compete with poster/hero loads for TMDb or GUI resources."""
        try:
            self._backdropCountryDelay.stop()
            self._backdropCountryDelay.start(2800, True)
        except Exception:
            pass

    def _runDeferredBackdropCountries(self):
        """Submit at most one new lookup per tick, after artwork first paint."""
        if self._contentScreenDisposed or self.kind not in ("vod", "series"):
            return
        ready = []
        for slot in range(4):
            index = self.backdropStart + slot
            if index >= len(self.backdrops):
                break
            item = self.backdrops[index]
            if isinstance(item, dict) and self.imageUrl(item, True):
                ready.append((slot, item))
        if not ready:
            return
        submitted, remaining = self._startBackdropCountryResolve(ready, limit=1)
        if remaining:
            try:
                self._backdropCountryDelay.start(1800, True)
            except Exception:
                pass

    def _startBackdropCountryResolve(self, visible, limit=None):
        """Lookup only genuinely missing identities, throttled off the image path."""
        submitted = 0
        remaining = False
        now = time.monotonic()
        for slot, item in (visible or []):
            if not isinstance(item, dict) or not 0 <= int(slot) < 4:
                continue
            info = item.get("info") if isinstance(item.get("info"), dict) else {}
            known_id = str(item.get("tmdb_id") or item.get("_locked_tmdb_id") or
                           item.get("_tmdb_id") or item.get("tmdb") or item.get("tmdbid") or
                           info.get("tmdb_id") or info.get("tmdb") or "").strip()
            if self._countryCodeFromBackdropItem(item) or (known_id.isdigit() and int(known_id) > 0):
                # _setBackdropFlag already hands these directly to the flag
                # cache/download pool; a title search would be redundant.
                continue
            ticket = (self.contentGeneration, self.kind, self.backdropStart + int(slot), id(item))
            if self._backdropFlagResolveJobs.get(slot) == ticket:
                continue
            # One slow/failing title can otherwise be queried repeatedly on
            # every category visit, consuming several wget 8-second timeouts.
            lookup_key = self._backdropFlagMemoryKey(item)
            attempted = self._backdropCountryAttemptAt.get(lookup_key, 0) if lookup_key else 0
            if attempted and 0 <= now - attempted < 90:
                continue
            if limit is not None and submitted >= limit:
                remaining = True
                continue
            self._backdropFlagResolveJobs[slot] = ticket
            admitted = _submit_content_bg(
                self._resolveBackdropFlagIdentity, args=(int(slot), item, ticket),
                key=("fast-backdrop-country", id(self), int(slot)),
                country=True
            )
            if not admitted:
                self._backdropFlagResolveJobs.pop(slot, None)
            else:
                submitted += 1
                if lookup_key:
                    self._backdropCountryAttemptAt[lookup_key] = now
                    self._backdropCountryAttemptAt.move_to_end(lookup_key)
                    while len(self._backdropCountryAttemptAt) > 96:
                        self._backdropCountryAttemptAt.popitem(last=False)
        return submitted, remaining

    def _skipEmptyBackdropCard(self, widget, expected_url=None):
        """Keep the original Movies/TV Shows item when its backdrop is missing.

        This compatibility entry point is still reached after artwork failure
        and after exhausting *same-title* TMDb backdrop alternatives. Do not
        replace it with a different film/series, delete its slot, change the
        package order, or start metadata searches for another title. The
        existing placeholder and details remain tied to the selected item.
        """
        return False

    def _startBackdropMetadataResolve(self, visible):
        """Paint every cached visible backdrop BEFORE requesting missing art.

        The four cards can mix cache hits with slow provider images.  Keep the
        HDD/USB/internal-flash hits ahead of downloads without waiting for a
        server response or doing TMDb searches for rows already carrying art.
        """
        cached_visible, uncached_visible, missing = [], [], []
        ready_art = []
        for slot, item in (visible or []):
            if not isinstance(item, dict):
                continue
            # Same source/kind verified index and provider-first URL policy.
            url = self.imageUrl(item, True)
            if url and "image.tmdb.org/t/p/" in str(url):
                url = re.sub(r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                             r"\1w780\2", str(url), count=1)
            if not url:
                missing.append((slot, item))
                continue
            ready_art.append((slot, item))
            widget = "backdrop%d" % int(slot)
            if getattr(self, "_image_requests", {}).get(widget) == url:
                continue  # A previous decode/download is already running.
            try:
                local = cached_artwork(url, "backdrops")
            except Exception:
                local = None
            (cached_visible if local and os.path.isfile(local) else
             uncached_visible).append((url, widget))

        # Cache hits are decoded first, without waiting for ANY missing image.
        # A corrupt cached image still goes through loadImage's normal
        # validation/recovery; we never silently mark it as successful.
        for url, widget in cached_visible:
            self.loadImage(url, widget, 406, 206)
        for url, widget in uncached_visible:
            self.loadImage(url, widget, 406, 206)

        if ready_art:
            self._deferBackdropCountryResolve()
        if missing:
            # GENRE asks the provider for series_info/vod_info before trying
            # the matching TMDb gallery. Keep the slot alive until recovery.
            for slot, item in missing:
                self._genreHeroRecover('backdrop%d' % int(slot), item,
                                       'backdrop', 406, 206)
        else:
            self._backdropMetadataToken = None

        # Warm only the NEXT four Backdrop cards, after all visible work has
        # been submitted.  Disk hits are already ready; missing remote images
        # use the shared LOW-priority prefetch feeder (no TMDb searches here).
        # This is NOT the poster feed and never downloads the entire catalogue.
        next_start = self.backdropStart + 4
        if (not self._contentScreenDisposed and
                next_start < len(self.backdrops)):
            next_urls = []
            for item in self.backdrops[next_start:next_start + 4]:
                if not isinstance(item, dict):
                    continue
                url = self.imageUrl(item, True)
                if url and "image.tmdb.org/t/p/" in str(url):
                    url = re.sub(r"(image\.tmdb\.org/t/p/)(?:w\d+|original)(/)",
                                 r"\1w780\2", str(url), count=1)
                if url:
                    try:
                        local = cached_artwork(url, "backdrops")
                    except Exception:
                        local = None
                    if not local or not os.path.isfile(local):
                        next_urls.append(url)
            if next_urls:
                prefetch_artwork(next_urls, "backdrops", priority=1)

    def imageUrl(self, item, backdrop=False):
        if backdrop and isinstance(item, dict):
            # An explicit alternate TMDb backdrop chosen for the Latest rail must
            # paint as-is, even when the provider also exposes a usable image.
            alt_backdrop = str(item.get("_tmdb_backdrop") or "").strip()
            if item.get("_featured_alt_backdrop") and alt_backdrop:
                return self.norm(alt_backdrop)
            # Same selected-Hero preference as GENRE: a provider's real
            # landscape background wins over a TMDb search cache hit.
            # This is local-only and does not trigger network on the UI thread.
            if not item.get('_tmdb'):
                provider_url = ContentHomeScreen.imageUrl(self, item, True)
                if not provider_url:
                    try:
                        from .hero_shared import _provider_details
                        cached_info = _provider_details(self.source, item, self.kind,
                                                        allow_network=False)
                        provider_url = self.norm(cached_info.get('_genre_backdrop_url'))
                    except Exception:
                        provider_url = ''
                if provider_url and provider_url != item.get('_fast_invalid_backdrop_url'):
                    try:
                        path = cached_artwork(provider_url, 'backdrops')
                        if (path and os.path.isfile(path) and
                                not _cinematic_is_landscape_image(path)):
                            item['_fast_invalid_backdrop_url'] = provider_url
                            provider_url = ''
                    except Exception:
                        pass
                    if provider_url:
                        return provider_url
            # If the provider has no usable background, retain the existing
            # per-source verified TMDb cache and GENRE image fallback.
            resolved = item.get("_tmdb_backdrop")
            if resolved:
                return self.norm(resolved)
            # Read the lightweight per-source index only once per row per visit.
            # No TMDb call, no new image-cache family, no provider data rewrite.
            if not item.get("_fast_backdrop_index_checked"):
                item["_fast_backdrop_index_checked"] = True
                try:
                    entry = _cinematic_verified_get(self.source, self.kind, item)
                    url = str(entry.get("url") or "").strip()
                    tmdb_id = str(entry.get("tmdb_id") or "").strip()
                    if url and tmdb_id.isdigit():
                        item["_tmdb_backdrop"] = url
                        item["tmdb_id"] = tmdb_id
                        if entry.get("country"):
                            item["_country_code"] = entry["country"]
                        return self.norm(url)
                except Exception:
                    pass
            provider_url = ContentHomeScreen.imageUrl(self, item, True)
            if not provider_url or provider_url == item.get("_fast_invalid_backdrop_url"):
                return ""
            # A known provider portrait can be identified from the disk cache
            # without a single HTTP request or loading a stretched image.
            # Images not yet cached still download through the normal queue.
            if self.kind in ("vod", "series"):
                try:
                    existing = cached_artwork(provider_url, "backdrops")
                    if existing and os.path.isfile(existing) and not _cinematic_is_landscape_image(existing):
                        item["_fast_invalid_backdrop_url"] = provider_url
                        return ""
                except Exception:
                    pass
            return provider_url
        return ContentHomeScreen.imageUrl(self, item, backdrop)


# Cinematic experimental pages retired.  Both content kinds share the
# responsive cached navigation; Movie/Series details are unaffected.


FAST_SERIES_CONTENT_HOME = FAST_MOVIES_CLASSIC_PACKAGE_RAIL_SERIES.replace(
    'name="FastMoviesContentScreen"', 'name="FastSeriesContentScreen"', 1
)


class FastSeriesContentScreen(FastMoviesContentScreen):
    """Use the same responsive artwork/card UI for TV Shows.

    The kind remains 'series', so series details, categories, caches, and
    episodes still use the existing TV Shows paths.  Only its display/navigation
    screen is changed; no cinematic page or new content fetcher is created.
    """
    skin = FAST_SERIES_CONTENT_HOME
