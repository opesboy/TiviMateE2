# -*- coding: utf-8 -*-
"""Premium row renderer for the Xtream / M3U / Stalker server editors.

The real ConfigList stays alive (keys, editing and saving are unchanged) but
is drawn outside the visible desktop.  Seven custom rows mirror it: label on
the left, value on the right, a rounded accent focus bar and ON/OFF switches
for yes/no options.  Pure PNG + Label widgets, so it looks identical on
OpenATV, OpenPLi, DreamOS and VTi (no cornerRadius or list renderer quirks).
"""
from Components.Pixmap import Pixmap
from enigma import eTimer, gRGB
from .vti_compat import VTiTextLabel as Label
from .py27_compat import gui_text as _gui

try:
    _text = unicode  # Python 2.7
except NameError:
    _text = str

ROWS = 7
ROW_Y = 344
ROW_H = 62
ROW_X = 500
ROW_W = 1300
SKIN_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/server"

_LABEL_NORMAL = 0xA9BBCB
_LABEL_FOCUS = 0xFFFFFF
_VALUE_NORMAL = 0x7F95A8
_VALUE_FOCUS = 0xFFFFFF


def rows_skin(accent_key, x=ROW_X, y0=ROW_Y, w=ROW_W, rows=ROWS, row_h=ROW_H, counter_y=282, focus=None):
    """Skin XML for the rows; accent_key picks the focus bar / switch colour."""
    focus = focus or ("editor_focus_%s.png" % accent_key)
    parts = []
    for i in range(rows):
        y = y0 + i * row_h
        parts.append(
            '<eLabel position="%d,%d" size="%d,1" backgroundColor="#16293A" zPosition="5"/>'
            % (x + 24, y + row_h - 1, w - 48))
        parts.append(
            '<widget name="edFocus%d" position="%d,%d" size="%d,%d" '
            'pixmap="%s/%s" alphatest="blend" zPosition="6"/>'
            % (i, x - 5, y + 2, w + 10, row_h - 4, SKIN_DIR, focus))
        parts.append(
            '<widget name="edLabel%d" position="%d,%d" size="620,%d" font="Regular;25" '
            'foregroundColor="#A9BBCB" transparent="1" halign="left" valign="center" '
            'noWrap="1" zPosition="8"/>' % (i, x + 34, y, row_h))
        parts.append(
            '<widget name="edValue%d" position="%d,%d" size="600,%d" font="Regular;24" '
            'foregroundColor="#7F95A8" transparent="1" halign="right" valign="center" '
            'noWrap="1" zPosition="8"/>' % (i, x + w - 640, y, row_h))
        parts.append(
            '<widget name="edOn%d" position="%d,%d" size="76,38" pixmap="%s/editor_switch_on_%s.png" '
            'alphatest="blend" zPosition="9"/>' % (i, x + w - 112, y + (row_h - 38) // 2, SKIN_DIR, accent_key))
        parts.append(
            '<widget name="edOff%d" position="%d,%d" size="76,38" pixmap="%s/editor_switch_off.png" '
            'alphatest="blend" zPosition="9"/>' % (i, x + w - 112, y + (row_h - 38) // 2, SKIN_DIR))
    track_y = y0 + 8
    track_h = rows * row_h - 16
    parts.append('<eLabel position="%d,%d" size="4,%d" backgroundColor="#14263A" zPosition="6"/>'
                 % (x + w + 18, track_y, track_h))
    for i in range(rows):
        # Scroll thumb as fixed segments: no runtime move/resize (720p safe).
        parts.append('<widget name="edSeg%d" position="%d,%d" size="4,%d" backgroundColor="__ACCENT__" '
                     'zPosition="7" text=" " font="Regular;2"/>'
                     % (i, x + w + 18, track_y + i * (track_h // rows), track_h // rows))
    parts.append('<widget name="edCounter" position="%d,%d" size="200,36" font="Regular;20" '
                 'foregroundColor="#7F95A8" transparent="1" halign="right" valign="center" zPosition="6"/>'
                 % (x + w - 200 - 260, counter_y))
    return "\n    ".join(parts)


KEY_SLOTS = 5
KEY_W = 262
KEY_GAP = 14
KEY_Y = 948
_KEY_COLORS = {"RED": 0xF25D5D, "GREEN": 0x4CD678, "YELLOW": 0xF4CD50, "BLUE": 0x46AAFF}


def keys_skin(cx=1155, key_y=KEY_Y):
    """Five equal key pills; filled from the screen's original keys text."""
    x0 = cx - (KEY_SLOTS * KEY_W + (KEY_SLOTS - 1) * KEY_GAP) // 2
    parts = []
    for i in range(KEY_SLOTS):
        x = x0 + i * (KEY_W + KEY_GAP)
        parts.append('<widget name="edKeyPill%d" position="%d,%d" size="%d,58" pixmap="%s/editor_key_pill.png" '
                     'alphatest="blend" zPosition="3"/>' % (i, x, key_y, KEY_W, SKIN_DIR))
        parts.append('<widget name="edKeyTag%d" position="%d,%d" size="64,58" font="Regular;19" foregroundColor="#C9D6E2" '
                     'transparent="1" halign="center" valign="center" zPosition="5"/>' % (i, x + 10, key_y))
        parts.append('<widget name="edKeyText%d" position="%d,%d" size="%d,58" font="Regular;21" foregroundColor="#FFFFFF" '
                     'transparent="1" halign="left" valign="center" noWrap="1" zPosition="5"/>' % (i, x + 76, key_y, KEY_W - 86))
    return "\n    ".join(parts)


def _parse_keys(text):
    """'OK  KEYBOARD      GREEN  SAVE' -> [('OK', 'KEYBOARD'), ('GREEN', 'SAVE')]."""
    import re as _re
    if isinstance(text, bytes) and not isinstance(text, _text):
        text = text.decode("utf-8", "ignore")
    out = []
    for chunk in _re.split(u"\\s{4,}", _text(text or u"").strip()):
        bits = chunk.strip().split(None, 1)
        if len(bits) == 2:
            out.append((bits[0].upper(), bits[1].strip()))
    return out[:KEY_SLOTS]


def _nice_label(label):
    """KEYBOARD -> Keyboard, IMPORT/SAVE -> Import/Save, PHONE QR -> Phone QR."""
    import re as _re
    if not label.isupper():
        return label
    return _re.sub(u"[A-Za-z]+", lambda m: m.group(0) if len(m.group(0)) <= 3 else m.group(0).capitalize(), label)


def _fill_keys(screen):
    try:
        keys = _parse_keys(screen["keys"].getText())
    except Exception:
        keys = []
    # Fewer keys than slots: use the middle slots so the row stays centred.
    offset = max(0, (KEY_SLOTS - len(keys)) // 2)
    for i in range(KEY_SLOTS):
        try:
            k = i - offset
            if 0 <= k < len(keys):
                name, label = keys[k]
                color = _KEY_COLORS.get(name)
                screen["edKeyTag%d" % i].setText(_gui(u"\u25cf" if color else name))
                try:
                    screen["edKeyTag%d" % i].instance.setForegroundColor(gRGB(color or 0xC9D6E2))
                except Exception:
                    pass
                screen["edKeyText%d" % i].setText(_gui(_nice_label(label)))
                screen["edKeyPill%d" % i].show()
            else:
                screen["edKeyTag%d" % i].setText("")
                screen["edKeyText%d" % i].setText("")
                screen["edKeyPill%d" % i].hide()
        except Exception:
            continue


def _entry_value(cfg):
    """(text, switch) for one config element; switch is None/True/False."""
    try:
        from Components.config import ConfigYesNo, ConfigPassword, ConfigSelection, ConfigBoolean
    except Exception:
        ConfigYesNo = ConfigPassword = ConfigSelection = ConfigBoolean = ()
    try:
        if ConfigYesNo and isinstance(cfg, (ConfigYesNo, ConfigBoolean)):
            return u"", bool(cfg.value)
        if ConfigPassword and isinstance(cfg, ConfigPassword):
            value = _text(cfg.value or u"")
            return (u"•" * min(len(value), 12)) if value else u"—", None
        if ConfigSelection and isinstance(cfg, ConfigSelection):
            return _text(cfg.getText() or u""), None
        value = cfg.value
        if isinstance(value, bytes) and not isinstance(value, _text):
            value = value.decode("utf-8", "ignore")
        value = _text(value if value is not None else u"").strip()
        return (value or u"—"), None
    except Exception:
        return u"", None


def _short(text, limit=46):
    text = _text(text or u"")
    return text if len(text) <= limit else text[:limit - 1] + u"…"


class _Rows(object):
    def __init__(self, screen, rows=ROWS):
        self.screen = screen
        self.rows = rows
        self.top = 0
        self.signature = None
        self.timer = eTimer()
        try:
            self.timer.callback.append(self.refresh)
        except AttributeError:
            self._conn = self.timer.timeout.connect(self.refresh)
        screen.onShown.append(self._start)
        screen.onHide.append(self._stop)
        screen.onClose.append(self._stop)
        screen.onLayoutFinish.append(self._layout)

    def _layout(self):
        # The real list sits below the visible desktop (skin position);
        # only these rows are drawn.
        _fill_keys(self.screen)
        self.refresh()

    def _start(self):
        self.refresh()
        try:
            self.timer.start(120, False)
        except Exception:
            pass

    def _stop(self):
        try:
            self.timer.stop()
        except Exception:
            pass

    def _color(self, widget, value):
        try:
            self.screen[widget].instance.setForegroundColor(gRGB(value))
        except Exception:
            pass

    def refresh(self):
        screen = self.screen
        try:
            entries = list(screen["config"].list or [])
            index = int(screen["config"].getCurrentIndex() or 0)
        except Exception:
            return
        values = [_entry_value(entry[1]) if len(entry) > 1 else (u"", None) for entry in entries]
        signature = (index, len(entries), tuple(values))
        if signature == self.signature:
            return
        self.signature = signature
        count = len(entries)
        if index < self.top:
            self.top = index
        elif index >= self.top + self.rows:
            self.top = index - self.rows + 1
        self.top = max(0, min(self.top, max(0, count - self.rows)))
        for slot in range(self.rows):
            row = self.top + slot
            focus = row == index
            try:
                if row >= count:
                    screen["edLabel%d" % slot].setText("")
                    screen["edValue%d" % slot].setText("")
                    screen["edFocus%d" % slot].hide()
                    screen["edOn%d" % slot].hide()
                    screen["edOff%d" % slot].hide()
                    continue
                text, switch = values[row]
                label = entries[row][0]
                if isinstance(label, bytes) and not isinstance(label, _text):
                    label = label.decode("utf-8", "ignore")
                screen["edLabel%d" % slot].setText(_gui(_short(label, 44)))
                if switch is None:
                    shown = _short(text)
                    try:
                        from Components.config import ConfigSelection
                        if focus and isinstance(entries[row][1], ConfigSelection):
                            shown = u"‹   %s   ›" % shown
                    except Exception:
                        pass
                    screen["edValue%d" % slot].setText(_gui(shown))
                    screen["edOn%d" % slot].hide()
                    screen["edOff%d" % slot].hide()
                else:
                    screen["edValue%d" % slot].setText("")
                    if switch:
                        screen["edOff%d" % slot].hide()
                        screen["edOn%d" % slot].show()
                    else:
                        screen["edOn%d" % slot].hide()
                        screen["edOff%d" % slot].show()
                if focus:
                    screen["edFocus%d" % slot].show()
                else:
                    screen["edFocus%d" % slot].hide()
                self._color("edLabel%d" % slot, _LABEL_FOCUS if focus else _LABEL_NORMAL)
                self._color("edValue%d" % slot, _VALUE_FOCUS if focus else _VALUE_NORMAL)
            except Exception:
                continue
        try:
            screen["edCounter"].setText(_gui(u"%d / %d" % (index + 1, count)) if count else "")
        except Exception:
            pass
        try:
            if count > self.rows:
                first = int(round(self.top * self.rows / float(count)))
                last = int(round((self.top + self.rows) * self.rows / float(count))) - 1
                last = max(first, min(self.rows - 1, last))
            else:
                first, last = 0, -1
            for seg in range(self.rows):
                if first <= seg <= last:
                    screen["edSeg%d" % seg].show()
                else:
                    screen["edSeg%d" % seg].hide()
        except Exception:
            pass


def attach(screen, rows=ROWS):
    """Create the row widgets; call in __init__ after ConfigListScreen.__init__."""
    for i in range(rows):
        screen["edFocus%d" % i] = Pixmap()
        screen["edLabel%d" % i] = Label("")
        screen["edValue%d" % i] = Label("")
        screen["edOn%d" % i] = Pixmap()
        screen["edOff%d" % i] = Pixmap()
    for i in range(rows):
        screen["edSeg%d" % i] = Label(" ")
    screen["edCounter"] = Label("")
    for i in range(KEY_SLOTS):
        screen["edKeyPill%d" % i] = Pixmap()
        screen["edKeyTag%d" % i] = Label("")
        screen["edKeyText%d" % i] = Label("")
    screen._premiumEditorRows = _Rows(screen, rows)
    return screen._premiumEditorRows
