# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import ensure_dir
from Plugins.Extensions.TiviMateE2Py27.py27_compat import FileExistsError
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace, int_from_bytes, monotonic, scandir, thread_factory, thread_ident, text_type, http_url_bytes

"""Small, UI-safe artwork download queue for Enigma2.

Artwork is always read from the local cache first.  On a cache miss this module
starts the existing helper in a separate process and keeps at most six network
transfers alive at once.  Consequently a list renderer never performs DNS,
HTTP, image conversion, or disk writes on the Enigma2 GUI thread.
"""

import hashlib
import json
import re
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlparse, urlsplit, parse_qsl, urlencode
import os
from stat import S_ISREG
import threading
import time
import zlib

from enigma import eConsoleAppContainer, eTimer

try:
    from twisted.web.client import downloadPage
except Exception:
    downloadPage = None

from .cache_manager import get_cache_dir, get_cache_root, cleanup_cache, get_settings, is_internal_cache_active
from .compat import python_command

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
try:
    PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()
except Exception:
    # Never let a missing /usr/bin/python2 break the whole artwork module;
    # the Twisted path below does not need an external interpreter.
    PYTHON_EXECUTABLE = PYTHON_COMMAND = "/usr/bin/python"
# Match Ultra everywhere: four bounded transfers keep the receiver responsive
# while visible artwork still paints quickly. Ultra remains the primary path;
# this is the same limit for its generic fallback and legacy callers.
MAX_CONCURRENT_DOWNLOADS = 3  # r146: VTi timed out with 4
# Bound the queued artwork metadata/callbacks as well as active transfers. On a
# fast scroll a receiver can otherwise accumulate hundreds of stale poster jobs
# while the network is slower than the UI. Dropped stale jobs are harmless: a
# visible card requests the same cached URL again when rendered.
# Keep the same total in-flight/queued window used by Ultra's artwork lane.
MAX_PENDING_DOWNLOADS = 25

# R227: one bad/slow artwork response must never freeze the remaining Movies
# poster queue. Each transfer gets one controlled retry and a hard watchdog.
MAX_JOB_RETRIES = 1
# Slow Python 2.7 receivers (MIPS/ARM) need longer for a TLS handshake.
JOB_STALL_SECONDS = 20
WATCHDOG_INTERVAL_MS = 1400
_watchdog_timer = [None]

# Global low-priority prefetch feeder. Screens can hand us every artwork URL
# they already know about; the feeder releases them to the normal queue in
# small slices so page rendering never waits for a bulk image burst.
_PREFETCH_FEED_SIZE = 2
_PREFETCH_INTERVAL_MS = 350
# Bound *queued* prefetch metadata, not HDD/USB image retention.  The most
# recently visited screen gets the newest prefetch slots; older work can be
# fetched on demand.  _prefetch_seen tracks pending keys only, never every
# image cached during an entire Enigma2 session.
MAX_PREFETCH_PENDING = 25
# Limit synchronous disk/cache checks when a package supplies thousands of URLs.
# Visible poster requests are separate and never limited by this bound.
MAX_PREFETCH_SCAN = 128
_prefetch_pending = []
_prefetch_seen = set()
_prefetch_timer = [None]

MAX_CALLBACKS_PER_JOB = 64
MAX_NOTIFY_TIMERS = 64
MIN_VALID_BYTES = 32

_pending = []
_running = {}
_jobs = {}
# Ephemeral negative cache prevents repeated HTTP attempts against broken image
# links when moving in and out of screens. No success or empty path is persisted.
_FAILED_ARTWORK_UNTIL = {}
_FAILED_ARTWORK_SECONDS = 75.0
_sequence = [0]
_cleanup_count = [0]
_cleanup_running = [False]
_cleanup_lock = threading.Lock()
_cleanup_last_run = [time.time()]
# Bounded cleanup bursts keep rapid 24-poster pages responsive.
INTERNAL_CLEANUP_BATCH = 12
INTERNAL_CLEANUP_INTERVAL = 45.0
_notify_timers = []
_display_sequence = [0]
CLEANUP_EVERY_SUCCESSES = 12

# r173: hard application-exit gate. Once Home exits, no artwork callback,
# retry, prefetch or late network completion may recreate the cache tree.
_APP_EXITING = [False]

def set_app_exiting(value=True):
    try:
        _APP_EXITING[0] = bool(value)
    except Exception:
        pass

def is_app_exiting():
    try:
        return bool(_APP_EXITING[0])
    except Exception:
        return False


def provider_asset_url(source, value):
    """Normalize artwork supplied by the IPTV provider, never as a TMDb path."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = text_type(value or u"").strip().replace("\\/", "/")
    except Exception:
        return ""
    if not value:
        return ""
    # JSON-encoded one-element artwork arrays are common on Xtream forks.
    if value.startswith("["):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, list) and decoded:
                value = text_type(decoded[0] or u"").strip().replace("\\/", "/")
        except (ValueError, TypeError):
            pass
    if not value:
        return ""
    if value.startswith("//"):
        base = text_type((source or {}).get("url") or (source or {}).get("portal") or u"")
        scheme = urlparse(base).scheme or "http"
        return scheme + ":" + value
    if value.startswith(("http://", "https://")):
        return value.replace(" ", "%20")

    source = source or {}
    base = text_type(source.get("url") or source.get("portal") or u"").strip().rstrip("/")
    if not base:
        return value.replace(" ", "%20")
    if "://" not in base:
        base = "http://" + base

    try:
        parsed = urlparse(base)
        scheme = parsed.scheme or "http"
        netloc = parsed.netloc
        # Some saved Xtream sources keep port in a separate field.
        port = text_type(source.get("port") or u"").strip()
        if port and ":" not in netloc.rsplit("@", 1)[-1]:
            netloc = "%s:%s" % (netloc, port)
        origin = "%s://%s" % (scheme, netloc)
        if value.startswith("/"):
            return (origin + value).replace(" ", "%20")
        path = (parsed.path or "").rstrip("/")
        return ("%s%s/%s" % (origin, path, value.lstrip("/"))).replace(" ", "%20")
    except Exception:
        return value.replace(" ", "%20")


def _asset_values(value):
    """Iterate supplier artwork fields, including language-keyed alternatives.

    Some Xtream/Stalker sources return a list or a mapping of image URLs
    instead of one string. Metadata/overview is never required to use them.
    """
    if isinstance(value, (list, tuple)):
        for entry in value[:16]:
            for candidate in _asset_values(entry):
                yield candidate
    elif isinstance(value, dict):
        for key in ("url", "src", "file_path", "path", "image", "poster",
                    "backdrop", "logo", "ar", "en"):
            if value.get(key):
                for candidate in _asset_values(value[key]):
                    yield candidate
        # Also allow Japanese/Korean/Turkish/etc., without a fixed whitelist.
        for key, entry in value.items():
            if (key not in ("url", "src", "file_path", "path", "image", "poster",
                            "backdrop", "logo", "ar", "en") and
                    re.match(r'^[a-z]{2,3}(?:[-_][a-z]{2})?$',
                             text_type(key).lower()) and entry):
                for candidate in _asset_values(entry):
                    yield candidate
    elif isinstance(value, (str, unicode)) and value.strip():
        yield value


def find_provider_asset(source, item, keys, extra=None):
    """Resolve provider artwork independently of title and TMDb metadata.

    Preserve the caller's poster/backdrop/logo key restrictions. Read image
    fields from the catalogue row and from its nested detail structures so a
    film with no plot, translated title or TMDb match still shows server art.
    """
    records = []
    for entry in (item, extra):
        if isinstance(entry, dict):
            records.append(entry)
            for nested_key in ("info", "movie_data", "series_data", "metadata",
                               "data", "details"):
                nested = entry.get(nested_key)
                if isinstance(nested, dict):
                    records.append(nested)
    for mapping in records:
        for key in keys:
            for value in _asset_values(mapping.get(key)):
                if key in ('poster_path', 'backdrop_path', 'logo_path'):
                    try:
                        relative = text_type(value).strip().replace('\\/', '/')
                        if (relative.startswith(u'/') and not relative.startswith(u'//')
                                and '?' not in relative and
                                re.match(r'^/[A-Za-z0-9_-]{8,}\.(?:png|jpe?g|webp)$', relative, re.I)):
                            size = ('w500' if key == 'poster_path' else
                                    'w780' if key == 'backdrop_path' else 'original')
                            return u'https://image.tmdb.org/t/p/%s%s' % (size, relative)
                    except (UnicodeError, ValueError, TypeError):
                        pass
                url = provider_asset_url(source, value)
                if url:
                    return url
    return ""


def normalise_url(url):
    try:
        return text_type(url or u"").strip().replace("\\/", "/")
    except Exception:
        return ""




def _media_cache_kind(kind):
    """Collapse every screen-specific media alias into one shared cache family."""
    value = str(kind or "artwork").strip().lower()
    poster_aliases = {
        "poster", "posters", "contenthome", "search", "home_poster",
        "details_poster", "live_tmdb_poster", "download_poster"
    }
    backdrop_aliases = {
        "backdrop", "backdrops", "hero", "home_backdrop", "details_backdrop",
        "backdrop_cards",
        "episodes", "episode", "stills"
    }
    logo_aliases = {"logo", "logos", "package_logo", "provider_logo"}
    if value in poster_aliases:
        return "posters"
    if value in backdrop_aliases:
        return "backdrops"
    if value in logo_aliases:
        return "logos"
    # Cinematic used the singular ``actor`` while Series Details used
    # ``actors``.  Both are portraits: one shared on-disk family is enough.
    # Keep each screen's existing downloader, priority and image size.
    if value in ("actor", "actors"):
        return "actors"
    return value or "artwork"


# Migrate old Cinematic portraits without blocking Enigma2's GUI or startup.
# Existing /actor images remain readable while a single background thread
# moves them into the shared /actors directory. No writes touch logos.
_ACTOR_MIGRATION_LOCK = threading.Lock()
_ACTOR_MIGRATION_ROOTS = set()


def _legacy_actor_cache_file(target):
    root = os.path.dirname(os.path.dirname(target))
    return os.path.join(root, "actor", os.path.basename(target))


def _merge_legacy_actor_cache(root):
    """Preserve every old portrait, including collisions, on the same volume.

    Only original actor cache files and their circular derivatives are moved;
    directories, links and unrelated files are untouched. Existing valid
    /actors entries always win if a legacy filename happens to collide.
    """
    legacy = os.path.join(root, "actor")
    target = os.path.join(root, "actors")
    try:
        if not os.path.isdir(legacy) or os.path.islink(legacy):
            return
        ensure_dir(target)
        with scandir(legacy) as entries:
            for entry in entries:
                if (not entry.is_file(follow_symlinks=False) or
                        not entry.name.startswith(("artwork_", "actor_circle_")) or
                        entry.name.endswith((".tmp", ".part"))):
                    continue
                src = entry.path
                dst = os.path.join(target, entry.name)
                # Normal case: same-volume hard link is instant and atomic;
                # unlink legacy only after the new name exists.
                try:
                    os.link(src, dst)
                    os.unlink(src)
                    continue
                except FileExistsError:
                    pass
                except (OSError, IOError):
                    pass
                # FAT/exFAT sometimes cannot hard-link; copy to a private temp
                # file before publishing. No destination is ever overwritten.
                if not os.path.exists(dst):
                    temp = os.path.join(target, ".actor_move_%s_%s" %
                                        (thread_ident(), entry.name))
                    try:
                        import shutil
                        shutil.copy2(src, temp)
                        if os.path.getsize(src) != os.path.getsize(temp):
                            continue
                        # os.rename is atomic on the same volume. Avoid replacing
                        # any destination that another portrait request created.
                        if not os.path.lexists(dst):
                            os.rename(temp, dst)
                            # On filesystems without hard links, callers may
                            # still hold the legacy filename this session.
                            # Keep that name until a later safe migration.
                            continue
                    except (OSError, IOError):
                        pass
                    finally:
                        try:
                            if os.path.exists(temp):
                                os.unlink(temp)
                        except (OSError, IOError):
                            pass
                # A previous cache entry has the same name. Preserve any
                # differing legacy bytes rather than silently deleting them.
                try:
                    import hashlib as _hashlib
                    def _hash_file(filename):
                        digest = _hashlib.sha256()
                        with open(filename, "rb") as handle:
                            while True:
                                part = handle.read(65536)
                                if not part:
                                    break
                                digest.update(part)
                        return digest.digest()
                    if (os.path.isfile(dst) and
                            os.path.getsize(src) == os.path.getsize(dst) and
                            _hash_file(src) == _hash_file(dst)):
                        os.unlink(src)
                        continue
                    conflicts = os.path.join(target, "_legacy_conflicts")
                    ensure_dir(conflicts)
                    suffix = _hashlib.sha1(src.encode("utf-8")).hexdigest()[:12]
                    saved = os.path.join(conflicts, suffix + "_" + entry.name)
                    if not os.path.lexists(saved):
                        os.rename(src, saved)
                except (OSError, IOError):
                    # Never drop an image when storage is full or read-only.
                    pass
        try:
            os.rmdir(legacy)  # Only remove the empty obsolete directory.
        except (OSError, IOError):
            pass
    except (OSError, IOError):
        pass


def _schedule_actor_cache_merge(root):
    """One bounded, non-UI migration for each active TMP/HDD cache root."""
    if not os.path.isdir(os.path.join(root, "actor")):
        return
    with _ACTOR_MIGRATION_LOCK:
        if root in _ACTOR_MIGRATION_ROOTS:
            return
        _ACTOR_MIGRATION_ROOTS.add(root)
    try:
        thread = thread_factory(target=_merge_legacy_actor_cache,
                                  args=(root,), name="TiviMateActorCacheMerge")
        thread.daemon = True
        thread.start()
    except RuntimeError:
        with _ACTOR_MIGRATION_LOCK:
            _ACTOR_MIGRATION_ROOTS.discard(root)


def cached_candidates_first(urls, kind, limit=0):
    """Stable, shared disk-cache-first ordering for multi-source art candidates.

    Keep server/TMDb alternatives in their original order on a cache miss.
    No HTTP, provider metadata lookups, image conversions or downloads here.
    A cached URL wins even if it occurred late in the source's candidate list.
    """
    hit, miss, seen = [], [], set()
    for raw in urls or ():
        url = normalise_url(raw)
        if not url or url in seen:
            continue
        seen.add(url)
        if cached_artwork(url, kind):
            hit.append(url)
        else:
            miss.append(url)
    ranked = hit + miss
    return ranked[:limit] if limit else ranked


def _canonical_tmdb_artwork(url, kind):
    """Return one shared TMDb URL/key for every screen.

    TMDb serves the same file through size-specific URLs (w342/w500/w780/w780/
    original). Older builds hashed the full URL, so the same poster/backdrop was
    cached once per screen size.  r130-test standardises TMDb artwork to one
    quality per media type and one cache key derived from the TMDb file path.
    """
    url = normalise_url(url)
    small_card = str(kind or "").strip().lower() == "backdrop_cards"
    kind = _media_cache_kind(kind)
    clean = url.split("?", 1)[0]
    marker = "image.tmdb.org/t/p/"
    lower = clean.lower()
    pos = lower.find(marker)
    if pos < 0:
        return url, ""
    tail = clean[pos + len(marker):].lstrip("/")
    parts = tail.split("/", 1)
    if len(parts) != 2 or not parts[1]:
        return url, ""
    rel = parts[1].lstrip("/")
    # One good-quality file shared by Home, rails, details, search and player.
    # Backdrops use HD w780; posters use w500 to keep cache weight modest.
    if small_card:
        # r146: Movies/TV Latest cards are ~410 px wide: a w300 copy is about
        # 3x smaller. Own cache key, so a full-screen w780 is never replaced.
        canonical = "https://image.tmdb.org/t/p/w300/%s" % rel
        return canonical, "w300/" + rel
    if str(kind or "").lower() == "backdrops":
        size = "w780"
    elif str(kind or "").lower() == "posters":
        size = "w342"  # r146: ~40% smaller, faster
    else:
        size = parts[0] or "original"
    canonical = "https://image.tmdb.org/t/p/%s/%s" % (size, rel)
    return canonical, rel


def _provider_cache_identity(url):
    """Content-ID query parameters distinguish images, auth tokens do not."""
    parts = urlsplit(url)
    base = parts.scheme + "://" + parts.netloc + parts.path
    if not parts.query:
        return base
    parameters = parse_qsl(parts.query, keep_blank_values=True)
    volatile = {"token", "access_token", "auth", "auth_token", "authorization",
                "signature", "sig", "expires", "expiry", "exp", "timestamp", "ts",
                "session", "session_id", "sessionid", "jwt"}
    stable = [(k, v) for k, v in parameters
              if k.lower() not in volatile and
              not k.lower().startswith(("x-amz-", "x-goog-"))]
    if not stable:
        return base
    return base + "?" + urlencode(sorted(stable))


def artwork_path(url, kind="artwork"):
    """Return the stable shared cache path for an artwork URL."""
    url = normalise_url(url)
    if not url:
        return ""
    raw_kind = kind
    kind = _media_cache_kind(kind)
    # Ultra percent-escapes Unicode URL paths before fetching; use the SAME
    # network URL for cache hashing, so a visible card and its prefetch never
    # create two separate image files or repeatedly miss one another's cache.
    if url.startswith((u'http://', u'https://')):
        try:
            url.encode('ascii')  # Keep all previous ASCII URL/cache identities.
        except UnicodeEncodeError:
            try:
                from .py27_compat import http_url_bytes
                url = http_url_bytes(url)
            except (UnicodeError, ValueError, TypeError):
                pass
    canonical_url, tmdb_rel = _canonical_tmdb_artwork(url, raw_kind)
    clean_url = canonical_url.split("?", 1)[0]
    lower_url = clean_url.lower()
    # A logo downloader transcodes transparent WebP into real PNG bytes.
    # Naming that result *.jpg makes old DreamOS/ePicLoad reject the valid
    # PNG and leaves all screens without a title logo. Do not alter artwork
    # paths for posters/backdrops or existing JPEG package branding.
    ext = ".png" if (lower_url.endswith(".png") or
                       (kind == "logos" and lower_url.endswith(".webp"))) else ".jpg"
    if tmdb_rel:
        # Same TMDb image => same filename, regardless of which page requested it.
        digest = hashlib.md5(tmdb_rel.encode("utf-8")).hexdigest()
        prefix = "poster_" if kind == "posters" else ("backdrop_" if kind == "backdrops" else ("logo_" if kind == "logos" else "artwork_"))
        return os.path.join(get_cache_dir(kind), prefix + "tmdb_" + digest + ext)
    # Unlike legacy code, CGI image ID 101 cannot alias image ID 202.
    digest = hashlib.md5(_provider_cache_identity(canonical_url).encode("utf-8")).hexdigest()
    prefix = "poster_" if kind == "posters" else ("backdrop_" if kind == "backdrops" else ("logo_" if kind == "logos" else "artwork_"))
    return os.path.join(get_cache_dir(kind), prefix + digest + ext)


# A small stat-keyed result cache avoids reading/validating megabyte-sized PNGs
# on every draw.  Replacing the file changes its inode/mtime or size.
_IMAGE_VALID_MEMO = {}
_IMAGE_VALID_MEMO_LIMIT = 512


def _image_structure_ok(path, size):
    """Fast check only (r146): image signature + complete file end.

    The old deep check (JPEG segment walk, PNG CRC + full zlib inflate) cost
    CPU on every new poster, most of all on Python 2 boxes. Two tiny reads
    still catch the real failures: HTML/error pages and cut-off downloads.
    """
    if size < 32 or size > 24 * 1024 * 1024:
        return False
    with open(path, "rb") as f:
        head = f.read(16)
        f.seek(max(0, size - 32))
        tail = f.read()
    if head.startswith(b"\xff\xd8\xff"):
        return b"\xff\xd9" in tail
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return b"IEND" in tail
    if head.startswith(b"RIFF") and head[8:12] == b"WEBP":
        return True
    if head.startswith((b"GIF87a", b"GIF89a")):
        return tail.endswith(b"\x3b")
    return False


def _image_signature_ok(path):
    try:
        st = os.stat(path)
        key = (st.st_size, getattr(st, 'st_mtime_ns', st.st_mtime), st.st_ino)
        saved = _IMAGE_VALID_MEMO.get(path)
        if saved and saved[0] == key:
            return saved[1]
        valid = _image_structure_ok(path, st.st_size)
        if len(_IMAGE_VALID_MEMO) >= _IMAGE_VALID_MEMO_LIMIT:
            _IMAGE_VALID_MEMO.clear()
        _IMAGE_VALID_MEMO[path] = (key, valid)
        return valid
    except (OSError, IOError, ValueError, zlib.error):
        return False


def _cached_artwork_core(url, kind="artwork"):
    """Cheap cache-first check with bounded timestamp writes.

    On HDD artwork retention is unlimited, so an mtime write for every
    already-cached poster is unnecessary and causes HDD I/O. Receiver flash
    still needs LRU recency, but updates are batched per file. USB with age
    retention also receives occasional recency updates.
    """
    if is_app_exiting():
        return ""
    path = artwork_path(url, kind)
    try:
        if not path:
            return ""
        if _media_cache_kind(kind) == "actors":
            # New portraits live in actors/. If an old actor/ image is being
            # displayed, promote its name before the asynchronous directory
            # merge: callbacks must not hold a path the worker could remove.
            if not os.path.isfile(path):
                old_path = _legacy_actor_cache_file(path)
                if os.path.isfile(old_path):
                    try:
                        os.link(old_path, path)  # zero-copy on HDD/TMP
                    except (OSError, IOError):
                        # Some removable filesystems do not support hardlinks.
                        # Their legacy image remains valid until migrated.
                        if not os.path.isfile(path):
                            path = old_path
            _schedule_actor_cache_merge(os.path.dirname(os.path.dirname(path)))
        st = os.stat(path)
        if st.st_size < MIN_VALID_BYTES or not S_ISREG(st.st_mode):
            return ""
        if not _image_signature_ok(path):
            return ""
        if path.startswith("/var/tmp/tivimatee2-cache/"):
            # /var/tmp may be a symlink to tmpfs. Avoid flash-style LRU writes
            # there, and use a quieter 3-minute LRU interval on real flash.
            touch_seconds = 180 if is_internal_cache_active() else 600
        elif path.startswith("/media/hdd/"):
            touch_seconds = 0        # Unlimited HDD cache needs no LRU writes
        else:
            touch_seconds = 600      # USB, TMP and other retention modes
        if touch_seconds and time.time() - st.st_mtime >= touch_seconds:
            try:
                os.utime(path, None)
            except Exception:
                pass
        return path
    except (OSError, ValueError, IOError):
        pass
    # Only after a genuine local miss: try a directly addressable file from a
    # configured Xtream mirror with the same login and exact image identity.
    # This is local disk I/O only; a miss immediately proceeds to the original
    # downloader with every queue, worker and callback unchanged.
    if _media_cache_kind(kind) in ("posters", "backdrops", "logos"):
        try:
            from .cross_domain_artwork import cached_mirror
            return cached_mirror(url, _media_cache_kind(kind), artwork_path, _valid)
        except Exception:
            pass
    return ""


def _valid(path):
    try:
        return bool(path and os.path.isfile(path) and
                    os.path.getsize(path) >= MIN_VALID_BYTES and
                    _image_signature_ok(path))
    except (OSError, ValueError, IOError):
        return False


def valid_image_file(path, minimum_bytes=MIN_VALID_BYTES):
    """Public, bounded validator shared by the small artwork caches."""
    try:
        return bool(path and os.path.isfile(path) and
                    os.path.getsize(path) >= int(minimum_bytes) and
                    _image_signature_ok(path))
    except (OSError, ValueError, TypeError, IOError):
        return False


def _schedule_cleanup():
    """Batch artwork pruning without delaying visible poster downloads.

    INTERNAL uses a 12-image batch instead of one full directory scan per
    image. After *every* successful flash write, the cheap free-space check
    can still request an immediate emergency cleanup if below the reserve.
    TMP-backed /var/tmp symlinks do not take the INTERNAL cleanup path.
    """
    if is_app_exiting():
        return
    try:
        cfg = get_settings() or {}
        root = get_cache_root()
        on_internal = is_internal_cache_active()
        if not on_internal and os.path.realpath(root).startswith("/media/hdd/"):
            return
        flash_limit = int(cfg.get("flash_image_limit", 40) or 0)
        flash_reserve_mb = int(cfg.get("flash_min_free_mb", 30) or 0)
        internal_policy = on_internal and (flash_limit > 0 or flash_reserve_mb > 0)
        age_policy = (not on_internal and
                      int(cfg.get("retention_days", 0) or 0) > 0)
        if not (internal_policy or age_policy):
            return
        emergency = False
        if internal_policy and flash_reserve_mb > 0:
            try:
                st = os.statvfs(root)
                emergency = (int(st.f_bavail) * int(st.f_frsize) <
                             flash_reserve_mb * 1024 * 1024)
            except Exception:
                # Keep the normal count/time cleaning active on mount failures.
                pass
    except Exception:
        return

    now = time.time()
    with _cleanup_lock:
        _cleanup_count[0] += 1
        if _cleanup_running[0]:
            return
        elapsed = max(0.0, now - _cleanup_last_run[0])
        if internal_policy:
            due = (emergency or _cleanup_count[0] >= INTERNAL_CLEANUP_BATCH
                   or elapsed >= INTERNAL_CLEANUP_INTERVAL)
        else:
            due = _cleanup_count[0] >= CLEANUP_EVERY_SUCCESSES
        if not due:
            return
        _cleanup_count[0] = 0
        _cleanup_running[0] = True
        _cleanup_last_run[0] = now

    def worker():
        try:
            cleanup_cache()
        except Exception:
            pass
        finally:
            with _cleanup_lock:
                _cleanup_running[0] = False

    thread = thread_factory(target=worker, name="TiviMateArtworkCleanup")
    thread.daemon = True
    thread.start()


def _notify(callbacks, path):
    for callback in list(callbacks or []):
        try:
            callback(path)
        except Exception:
            # A screen may legitimately have closed while an artwork transfer was
            # queued.  One dead callback must not affect another screen/job.
            pass


def _schedule_notify(callbacks, path, delay_ms):
    """Schedule one UI-thread refresh for a completed local artwork file."""
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    timer = eTimer()
    holder = {"timer": timer, "deliver": lambda: _notify(callbacks, path)}

    def fire():
        try:
            _notify(callbacks, path)
        finally:
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _notify_timers.remove(holder)
            except Exception:
                pass

    try:
        holder["connection"] = timer.timeout.connect(fire)
    except Exception:
        try:
            timer.callback.append(fire)
        except Exception:
            timer.timeout.get().append(fire)
    # The first completed poster notification is NOT optional: dropping it
    # can leave a visible GENRE slot on the default poster permanently. If
    # many images finish together, deliver the oldest callback on the UI thread
    # before releasing its timer, rather than silently discarding it.
    while len(_notify_timers) >= MAX_NOTIFY_TIMERS:
        old = _notify_timers.pop(0)
        try:
            old.get("timer").stop()
        except Exception:
            pass
        try:
            old_callback = old.get("deliver")
            if old_callback:
                old_callback()
        except Exception:
            pass
    _notify_timers.append(holder)
    timer.start(max(1, int(delay_ms)), True)


def _notify_after_write(callbacks, path, delay_ms=35):
    """Deliver each completed download once; decoding owns its own lifecycle.

    Calling the image completion callback twice created two ePicLoad decoders
    for the same picture and inflated transient RAM on slower receivers.
    """
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    _display_sequence[0] += 1
    # Ultra paints the first completed local asset almost immediately. Keep a
    # tiny coalescing window for ePicLoad, but do not add a visible 90ms wait.
    first_delay = min(35, max(8, int(delay_ms) // 2)) + ((_display_sequence[0] - 1) % 2) * 12
    _schedule_notify(callbacks, path, first_delay)


def _prefetch_key_for_job(job):
    try:
        url = normalise_url((job or {}).get("url") or "")
        kind = str((job or {}).get("kind") or "artwork")
        if not url:
            return None
        return (_media_cache_kind(kind), _provider_cache_identity(url))
    except Exception:
        return None


def _final_job_failure(path, job):
    """Fail one artwork item only; never allow it to stop the queue."""
    _running.pop(path, None)
    _jobs.pop(path, None)
    if path:
        _FAILED_ARTWORK_UNTIL[path] = monotonic() + _FAILED_ARTWORK_SECONDS
        if len(_FAILED_ARTWORK_UNTIL) > 256:
            now = monotonic()
            for stale, deadline in list(_FAILED_ARTWORK_UNTIL.items()):
                if deadline <= now:
                    _FAILED_ARTWORK_UNTIL.pop(stale, None)
            for stale in list(_FAILED_ARTWORK_UNTIL)[:max(0, len(_FAILED_ARTWORK_UNTIL) - 256)]:
                _FAILED_ARTWORK_UNTIL.pop(stale, None)
    key = _prefetch_key_for_job(job)
    if key is not None:
        try:
            _prefetch_seen.discard(key)
        except Exception:
            pass
    _notify((job or {}).get("errbacks"), path)


def _retry_or_fail(path, job):
    """Retry a failed/stalled transfer once, then skip only that item."""
    if not job:
        _jobs.pop(path, None)
        _start_next()
        return
    _running.pop(path, None)
    try:
        part = job.get("part") or ""
        if part and os.path.exists(part):
            os.remove(part)
    except Exception:
        pass
    tries = int(job.get("attempt", 0) or 0)
    if tries < MAX_JOB_RETRIES:
        job["attempt"] = tries + 1
        job["started"] = 0
        job.pop("deferred", None)
        job.pop("container", None)
        # Keep the failed item near the front, but preserve visible-card priority.
        _pending.append(job)
        _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    else:
        _final_job_failure(path, job)
    _start_next()


def _watchdog_tick():
    """Release stuck artwork slots so the rest of Movies continues loading."""
    now = time.time()
    stalled = []
    for path, job in list(_running.items()):
        try:
            started = float(job.get("started", 0) or 0)
        except Exception:
            started = 0
        if started and (now - started) >= JOB_STALL_SECONDS:
            stalled.append((path, job))
    for path, job in stalled:
        # Remove from running first: any late callback becomes harmless.
        if _running.get(path) is not job:
            continue
        _running.pop(path, None)
        try:
            deferred = job.get("deferred")
            if deferred is not None and hasattr(deferred, "cancel"):
                deferred.cancel()
        except Exception:
            pass
        try:
            container = job.get("container")
            if container is not None and hasattr(container, "kill"):
                container.kill()
        except Exception:
            pass
        _retry_or_fail(path, job)
    if _running or _pending:
        _arm_watchdog()


def _arm_watchdog():
    try:
        timer = _watchdog_timer[0]
        if timer is None:
            timer = eTimer()
            _watchdog_timer[0] = timer
            try:
                timer.timeout.connect(_watchdog_tick)
            except Exception:
                try:
                    timer.callback.append(_watchdog_tick)
                except Exception:
                    timer.timeout.get().append(_watchdog_tick)
        timer.start(WATCHDOG_INTERVAL_MS, True)
    except Exception:
        pass



def _speed_job(path, job, ok):
    try:
        from .speed_log import log, short_url
        started = float((job or {}).get("started") or 0)
        if started:
            size = os.path.getsize(path) if ok and os.path.isfile(path) else 0
            log("IMG", short_url((job or {}).get("url")), time.time() - started, ok, size, "queue")
    except Exception:
        pass

def _finish(path, status, expected_job=None):
    # Ignore a late completion from a timed-out/cancelled transfer. The same
    # cache path may already belong to its retry; a stale callback must never
    # pop that newer job from _running and stall the artwork queue.
    current = _running.get(path)
    if current is None or (expected_job is not None and current is not expected_job):
        return
    job = _running.pop(path, None)
    if job is None:
        return
    if is_app_exiting():
        _jobs.pop(path, None)
        try:
            if path and os.path.isfile(path): os.remove(path)
        except Exception:
            pass
        return
    try:
        success = int(status) == 0
    except Exception:
        success = False
    _speed_job(path, job, bool(success and _valid(path)))
    if success and _valid(path):
        _FAILED_ARTWORK_UNTIL.pop(path, None)
        _jobs.pop(path, None)
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
        _start_next()
    else:
        _retry_or_fail(path, job)


def _finish_twisted(path, success, expected_job=None):
    # A Deferred cancelled by the watchdog can still deliver a late callback.
    # Only the transfer that currently owns this path is allowed to finish it.
    current = _running.get(path)
    if current is None or (expected_job is not None and current is not expected_job):
        return
    job = _running.pop(path, None)
    if job is None:
        return
    part = job.get("part") or ""
    if is_app_exiting():
        _jobs.pop(path, None)
        for stale in (part, path):
            try:
                if stale and os.path.isfile(stale): os.remove(stale)
            except Exception:
                pass
        return
    ok = False
    if success and part:
        try:
            if _valid(part):
                try:
                    atomic_replace(part, path)
                except AttributeError:
                    if os.path.exists(path):
                        os.remove(path)
                    os.rename(part, path)
                ok = _valid(path)
        except Exception:
            ok = False
    _speed_job(path, job, ok)
    if not ok:
        try:
            if part and os.path.exists(part):
                os.remove(part)
        except Exception:
            pass
    if ok:
        _FAILED_ARTWORK_UNTIL.pop(path, None)
        _jobs.pop(path, None)
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
        _start_next()
    else:
        _retry_or_fail(path, job)


def _start_next():
    if is_app_exiting():
        return
    # GENRE/Ultra has its own bounded executor. Do not let the generic queue
    # open six more sockets while Ultra is painting visible artwork; yield to
    # it with two slots, then return to full speed after its queue drains.
    effective_limit = MAX_CONCURRENT_DOWNLOADS
    try:
        from .genre_ultra_artwork import pending_count as _ultra_pending
        if _ultra_pending() > 0:
            effective_limit = min(effective_limit, 4)  # r146: was 2
    except (ImportError, RuntimeError):
        pass
    while len(_running) < effective_limit and _pending:
        job = _pending.pop(0)
        path = job.get("path")
        if not path or path in _running:
            continue
        if _valid(path):
            _jobs.pop(path, None)
            _notify(job.get("callbacks"), path)
            continue
        try:
            if is_app_exiting():
                _jobs.pop(path, None)
                continue
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            if is_app_exiting():
                _jobs.pop(path, None)
                continue

            # Use the exact same Twisted download path that the VOD player uses.
            # This avoids launching a fresh Python interpreter for each poster and
            # keeps the image transfer inside Enigma2's proven async network stack.
            # VTi: old Twisted sends no SNI for https, which CDN artwork hosts
            # (image.tmdb.org: actor photos, logos) reject. Use an SNI context
            # factory on the first attempt; the retry of an https item goes
            # through the urllib2 helper (bundled CA, TMDb http fallback).
            is_https = str(job.get("url") or "").lower().startswith("https://")
            retry_https = is_https and int(job.get("attempt", 0) or 0) > 0
            if downloadPage is not None and not retry_https:
                part = path + ".part"
                try:
                    if os.path.exists(part):
                        os.remove(part)
                except Exception:
                    pass
                job["part"] = part
                job["started"] = time.time()
                _running[path] = job
                _arm_watchdog()
                request_url = http_url_bytes(job["url"])
                try:
                    from .py27_ssl import fast_image_url
                    request_url = http_url_bytes(fast_image_url(request_url))
                    is_https = request_url.lower().startswith("https://")
                except Exception:
                    pass
                factory = None
                if is_https:
                    try:
                        from .py27_ssl import twisted_context_factory
                        factory = twisted_context_factory(request_url)
                    except Exception:
                        factory = None
                if factory is not None:
                    d = downloadPage(request_url, part, contextFactory=factory, timeout=12)
                else:
                    d = downloadPage(request_url, part, timeout=12)
                job["deferred"] = d
                d.addCallback(lambda _r, cache_path=path, owner=job: _finish_twisted(cache_path, True, owner))
                d.addErrback(lambda _f, cache_path=path, owner=job: _finish_twisted(cache_path, False, owner))
                continue

            # Compatibility fallback for images without Twisted downloadPage.
            container = eConsoleAppContainer()
            job["container"] = container
            job["started"] = time.time()
            _running[path] = job
            _arm_watchdog()

            def done(status, cache_path=path, owner=job):
                _finish(cache_path, status, owner)

            try:
                container.appClosed.append(done)
            except Exception:
                container.appClosed.get().append(done)
            container.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, IMAGE_FETCH, http_url_bytes(job["url"]), path)
        except Exception:
            _running.pop(path, None)
            try:
                tries = int(job.get("attempt", 0) or 0)
            except Exception:
                tries = MAX_JOB_RETRIES
            if tries < MAX_JOB_RETRIES:
                job["attempt"] = tries + 1
                job["started"] = 0
                _pending.append(job)
                _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
            else:
                _final_job_failure(path, job)
            # A synchronous launch failure must not strand the remaining queue.
            # The normal async callbacks call _start_next(), but this exception
            # path previously returned with pending artwork permanently idle.
            _start_next()



_prefetch_redirect = threading.local()


def _on_gui_thread():
    try:
        main = getattr(threading, "main_thread", None)
        if main is not None:
            return threading.current_thread() is main()
        return isinstance(threading.current_thread(), threading._MainThread)
    except Exception:
        return True


def _to_gui_thread(func, *args):
    """r146: queue work (eTimer / Twisted transfers) must run on the GUI
    thread. A worker-thread call (Apple gallery joining a queued backdrop)
    crashed Enigma2 with a fatal signal on OpenATV 8 / Python 3.14."""
    try:
        from twisted.internet import reactor
        reactor.callFromThread(func, *args)
        return True
    except Exception:
        return False


def _request_artwork_core(url, kind="artwork", callback=None, priority=0, errback=None,
                          _from_worker=False):
    """Use cached artwork immediately or enqueue an asynchronous cache refresh.

    ``callback`` receives the completed local path only after the helper has
    written a valid file.  Duplicate requests share one network transfer while
    every interested widget still receives its own completion callback.
    """
    # Redirect at most once: if thread detection is unreliable on an image,
    # the redirected call must run instead of bouncing forever.
    if not _from_worker and not _on_gui_thread() and _to_gui_thread(
            _request_artwork_core, url, kind, callback, priority, errback, True):
        try:
            return artwork_path(url, kind)
        except Exception:
            return ""
    # TMDb size URL without a file name ("/t/p/w1280"): always 404.
    try:
        _u = str(url or "")
        if "image.tmdb.org/t/p/" in _u and "." not in _u.rstrip("/").rsplit("/", 1)[-1]:
            if errback:
                _notify([errback], "")
            return ""
    except Exception:
        pass
    if is_app_exiting():
        return ""
    url = normalise_url(url)
    if not url:
        return ""
    # Normalise TMDb size before both cache lookup and download, so every page
    # shares exactly the same on-disk poster/backdrop file.
    url, _tmdb_rel = _canonical_tmdb_artwork(url, kind)
    path = cached_artwork(url, kind)
    if path:
        if callback:
            _notify([callback], path)
        return path

    path = artwork_path(url, kind)
    if _FAILED_ARTWORK_UNTIL.get(path, 0.0) > monotonic():
        if errback:
            _notify([errback], path)
        return path
    _FAILED_ARTWORK_UNTIL.pop(path, None)
    # A prefetch may have queued this URL at priority 1 before the user
    # selected it.  When the visible widget arrives, promote that existing
    # transfer rather than leaving its callback buried behind unrelated jobs.
    if callback is not None:
            try:
                # A callback means this asset is visible now. Promote posters,
                # backdrops and logos alike; background prefetch has no callback
                # and remains low priority.
                priority = max(int(priority or 0), 120)
            except Exception:
                pass
    job = _jobs.get(path)
    if job is not None:
        if callback:
            callbacks = job.setdefault("callbacks", [])
            callbacks.append(callback)
            if len(callbacks) > MAX_CALLBACKS_PER_JOB:
                del callbacks[:-MAX_CALLBACKS_PER_JOB]
            try:
                if job in _pending and int(priority or 0) > int(job.get("priority") or 0):
                    job["priority"] = int(priority)
                    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
            except Exception:
                pass
        if errback:
            errbacks = job.setdefault("errbacks", [])
            errbacks.append(errback)
            if len(errbacks) > MAX_CALLBACKS_PER_JOB:
                del errbacks[:-MAX_CALLBACKS_PER_JOB]
        return path

    # Visible assets are what the user is waiting to see in Movies, TV Shows,
    # Packages and Search. Give callback-backed work a higher queue priority
    # than background prefetch without changing cache keys, image quality,
    # decoding, retries, or provider/TMDb fallback behavior.
    try:
        if callback is not None:
            priority = max(int(priority or 0), 120)
        # r146: every page paints its posters first; backdrops, logos and
        # other artwork follow once the visible posters are queued.
        if int(priority or 0) >= 100 and str(kind or "").startswith("poster"):
            priority = int(priority) + 60
    except Exception:
        pass

    _sequence[0] += 1
    job = {
        "url": url,
        "path": path,
        "callbacks": [callback] if callback else [],
        "errbacks": [errback] if errback else [],
        "priority": int(priority or 0),
        "sequence": _sequence[0],
        "kind": kind,
        "attempt": 0,
        "started": 0,
    }
    _jobs[path] = job
    _pending.append(job)
    # Highest priority first, then preserve the visual order for equal priority.
    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    # RAM guard for long browsing sessions: keep active transfers plus only a
    # small window of pending artwork metadata. Prefer current/high-priority and
    # newer jobs; stale jobs will be requested again if they become visible.
    if len(_pending) > MAX_PENDING_DOWNLOADS:
        overflow = len(_pending) - MAX_PENDING_DOWNLOADS
        candidates = sorted(_pending, key=lambda item: (item.get("priority", 0), item.get("sequence", 0)))
        for stale in candidates[:overflow]:
            try:
                _pending.remove(stale)
            except Exception:
                pass
            stale_path = stale.get("path")
            if stale_path and stale_path not in _running:
                _jobs.pop(stale_path, None)
            stale_key = _prefetch_key_for_job(stale)
            if stale_key is not None:
                try:
                    _prefetch_seen.discard(stale_key)
                except Exception:
                    pass
            try:
                stale["callbacks"] = []
                stale["errbacks"] = []
            except Exception:
                pass
    _start_next()
    return path



def _prefetch_tick():
    """Feed bulk prefetch jobs into the normal queue without blocking the UI."""
    if is_app_exiting():
        return
    timer = _prefetch_timer[0]
    try:
        if timer is not None:
            timer.stop()
    except Exception:
        pass
    fed = 0

    # Do not feed background prefetch while visible poster widgets are still
    # waiting.  This uses the existing prefetch timer only; no new hook/timer is
    # added.  As soon as visible poster work drains, prefetch resumes normally.
    try:
        visible_poster_busy = any(
            _media_cache_kind((job or {}).get("kind")) == "posters"
            and bool((job or {}).get("callbacks"))
            for job in list(_running.values()) + list(_pending)
        )
    except Exception:
        visible_poster_busy = False
    # GENRE and all visible poster cards share the bounded Ultra executor.
    # Give those first-paint downloads priority over background prefetch.
    try:
        from .genre_ultra_artwork import pending_count as _ultra_pending
        visible_poster_busy = visible_poster_busy or _ultra_pending() > 0
    except (ImportError, RuntimeError):
        pass
    if visible_poster_busy and _prefetch_pending:
        try:
            if timer is None:
                timer = eTimer()
                _prefetch_timer[0] = timer
                try:
                    timer.timeout.connect(_prefetch_tick)
                except Exception:
                    try:
                        timer.callback.append(_prefetch_tick)
                    except Exception:
                        timer.timeout.get().append(_prefetch_tick)
            timer.start(260, True)
        except Exception:
            pass
        return

    # Leave room for visible/high-priority requests.
    room = max(0, (MAX_PENDING_DOWNLOADS - 12) - len(_pending))
    take = min(_PREFETCH_FEED_SIZE, room, len(_prefetch_pending))
    while take > 0 and _prefetch_pending:
        url, kind, priority, key = _prefetch_pending.pop(0)
        # Queued/running transfers already deduplicate through _jobs; keeping
        # this key after feed would grow RAM with every successful image.
        _prefetch_seen.discard(key)
        try:
            request_artwork(url, kind, None, priority=priority)
        except Exception:
            pass
        fed += 1
        take -= 1
    if _prefetch_pending:
        try:
            if timer is None:
                timer = eTimer()
                _prefetch_timer[0] = timer
                try:
                    timer.timeout.connect(_prefetch_tick)
                except Exception:
                    try:
                        timer.callback.append(_prefetch_tick)
                    except Exception:
                        timer.timeout.get().append(_prefetch_tick)
            timer.start(_PREFETCH_INTERVAL_MS if fed else 700, True)
        except Exception:
            pass


def prefetch_artwork(urls, kind="artwork", priority=1):
    """Cache every supplied URL progressively in the background.

    This is intentionally separate from visible-card rendering.  It only feeds
    a few low-priority jobs at a time, so content/text can paint immediately
    while poster/backdrop cache fills behind it. Duplicate URLs are ignored.
    """
    if not _on_gui_thread() and not getattr(_prefetch_redirect, "busy", False):
        def _run(items=list(urls or []), k=kind, pr=priority):
            _prefetch_redirect.busy = True
            try:
                prefetch_artwork(items, k, pr)
            finally:
                _prefetch_redirect.busy = False
        if _to_gui_thread(_run):
            return
    if is_app_exiting():
        return 0
    added = 0
    scanned = 0
    for raw in (urls or ()):
        if scanned >= MAX_PREFETCH_SCAN or added >= MAX_PREFETCH_PENDING:
            break
        scanned += 1
        url = normalise_url(raw)
        if not url:
            continue
        key = (_media_cache_kind(kind), _provider_cache_identity(url))
        if key in _prefetch_seen:
            continue
        if cached_artwork(url, kind):
            continue  # Disk cache is authoritative; no lifetime RAM set.
        _prefetch_seen.add(key)
        _prefetch_pending.append((url, kind, int(priority or 0), key))
        added += 1
        # Keep only the latest bounded window of low-priority work.  Nothing
        # is deleted from disk; a dropped URL still downloads on demand.
        if len(_prefetch_pending) > MAX_PREFETCH_PENDING:
            _url, _kind, _priority, old_key = _prefetch_pending.pop(0)
            _prefetch_seen.discard(old_key)
    if added:
        _prefetch_tick()
    return added

def queue_status():
    """Return lightweight diagnostics for support logs and unit tests."""
    return {"pending": len(_pending), "running": len(_running), "limit": MAX_CONCURRENT_DOWNLOADS, "pending_limit": MAX_PENDING_DOWNLOADS, "notify_timers": len(_notify_timers), "prefetch_pending": len(_prefetch_pending)}


def cancel_all_artwork():
    """Cancel every queued/in-flight artwork job for application shutdown/exit."""
    set_app_exiting(True)
    # Stop delayed UI notifications too; none may touch artwork after Home exit.
    try:
        for holder in list(_notify_timers):
            try: holder.get("timer").stop()
            except Exception: pass
        _notify_timers[:] = []
    except Exception:
        pass
    try:
        timer = _prefetch_timer[0]
        if timer is not None:
            try: timer.stop()
            except Exception: pass
    except Exception:
        pass
    try:
        _prefetch_pending[:] = []
        _prefetch_seen.clear()
    except Exception:
        pass
    try:
        timer = _watchdog_timer[0]
        if timer is not None:
            try: timer.stop()
            except Exception: pass
    except Exception:
        pass
    try:
        for path, job in list(_running.items()):
            try:
                d = job.get("deferred")
                if d is not None and hasattr(d, "cancel"):
                    d.cancel()
            except Exception:
                pass
            try:
                c = job.get("container")
                if c is not None and hasattr(c, "kill"):
                    c.kill()
            except Exception:
                pass
            for temp_key in ("part",):
                try:
                    tp = job.get(temp_key)
                    if tp and os.path.isfile(tp): os.remove(tp)
                except Exception:
                    pass
            try:
                job["callbacks"] = []
                job["errbacks"] = []
            except Exception:
                pass
        _running.clear()
        _pending[:] = []
        _jobs.clear()
        _FAILED_ARTWORK_UNTIL.clear()
    except Exception:
        pass


# Media-family dispatch. Every screen (including legacy UI parts, GENRE,
# ContentHome, movie details, player and favourites) already calls this API.
# Keep transport/cancellation/prefetch shared; move media policies to managers.
def _media_manager(kind):
    family = _media_cache_kind(kind)
    if family == "posters":
        from . import poster_manager
        return poster_manager
    if family == "backdrops":
        from . import backdrop_manager
        return backdrop_manager
    if family == "logos":
        from . import logo_manager
        return logo_manager
    return None


def cached_artwork(url, kind="artwork"):
    if str(kind or "").strip().lower() == "backdrop_cards":
        # Own small TMDb copy (w300): the backdrop manager would look up
        # the full-size file instead and never find it.
        return _cached_artwork_core(url, kind)
    manager = _media_manager(kind)
    if manager is not None:
        return manager.cached(url)
    return _cached_artwork_core(url, kind)


def request_artwork(url, kind="artwork", callback=None, priority=0, errback=None,
                    source=None, transparent=None):
    """GENRE transport, shared cache, safe UI callbacks across all pages."""
    family = _media_cache_kind(kind)
    if family in ("posters", "backdrops", "logos"):
        try:
            from .unified_genre_artwork import request as genre_request
            return genre_request(url, family, callback=callback, priority=priority,
                                 errback=errback, source=source,
                                 transparent=transparent)
        except Exception:
            return _request_artwork_core(url, family, callback=callback,
                                         priority=priority, errback=errback)
    return _request_artwork_core(url, kind, callback=callback,
                                 priority=priority, errback=errback)
