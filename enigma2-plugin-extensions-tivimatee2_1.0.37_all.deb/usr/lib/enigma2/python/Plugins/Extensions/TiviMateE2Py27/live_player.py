# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import monotonic, thread_factory, text_type, gui_text
from .storage import get_data_root, data_path
import os, threading, time, json, re, base64

from Components.ActionMap import ActionMap
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from .vti_compat import safe_open_screen as _safe_open_screen
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import InfoBarBase, ServiceEventTracker
from .vti_compat import VTiTextStaticText as StaticText  # Python2/VTi renderer needs UTF-8 bytes
from enigma import eTimer, ePicLoad, iPlayableService, iServiceInformation
# VTi legacy images may not export this cosmetic spinner switch.
try:
    from enigma import setSpinnerOnOff
except (ImportError, AttributeError):
    def setSpinnerOnOff(_enabled):
        return None
from .live_service import live_reference
from .service_compat import serviceapp_backend_available, compatible_service_type
from .ultra_live_decoder import UltraLiveDecoderGuard
from .stalker_live_pool import live_playback_client, invalidate_live_playback_client
from .stalker_vti_diag import note as _stalker_note, url_kind as _stalker_url_kind
from .live_epg_bridge import cached as _shared_live_epg_cached, remember as _shared_live_epg_remember, select_stalker_now_next as _shared_stalker_now_next, wait_for_visible_result as _shared_epg_wait
from .live_epg_handoff import read_handoff as _read_live_epg_handoff
from .ultra_epg_selection import epg_title as _ultra_epg_title
from .xtream_epg_normalizer import decode_xtream_epg_text as _decode_xtream_title, epg_row_title as _epg_row_title
from .epg_local import lookup_channel_epg, load_source_epg, epg_json_path
from .artwork_queue import request_artwork, cached_artwork
from .live_infobar_pill import prepare_pill_image
from .live_sports_artwork import classify_football, resolve_football_art, _log_sports
from .tmdb_client import TMDbClient
from .estalker_picon import direct_picon, resolve_picon_url
from .display_scale import scale_skin, scale_size
from .i18n import tr
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBarGenerics import InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSummarySupport
from Screens.MessageBox import MessageBox
from .recording_manager import stalker_live_recorder
from Screens.Screen import Screen

try:
    from .core import XtreamClient, M3UClient, StalkerClient, get_source_client, cached_image, stalker_log, load_stalker_compat, save_stalker_compat
    from .stalker_task_handle import TaskHandle
    from .stalker_live_pool import STALKER_LIVE_EXECUTOR
except Exception as _source_import_error:
    _stalker_note('CORE_IMPORT_FAILED', error=type(_source_import_error).__name__)
    XtreamClient = M3UClient = StalkerClient = get_source_client = None
    TaskHandle = None
    STALKER_LIVE_EXECUTOR = None
    cached_image = None
    def load_stalker_compat(portal, mac): return {}
    def save_stalker_compat(portal, mac, **values): return {}
    def stalker_log(message):
        pass


# Bounded startup checks: a dead server/stream must not leave Enigma2
# opening indefinitely. These timers run on the GUI thread but do no I/O.
LIVE_RESOLVE_TIMEOUT_SECONDS = 11
LIVE_STARTUP_TIMEOUT_SECONDS = 16
LIVE_STALKER_STARTUP_TIMEOUT_SECONDS = 12

PLAYER_CONFIG = data_path("player.json")
# Kept only as a read fallback for installations that used the earlier live-only setting.
LIVE_SETTINGS_FILE = data_path("channel_settings.json")

# Shared Live programme-poster index.  The Live list already consumes this
# file; the full-screen infobar now feeds it as soon as it resolves a poster.
LIVE_POSTER_INDEX_FILE = data_path("live_poster_index.json")
LIVE_INFOBAR_BACKDROP_INDEX_FILE = data_path("live_infobar_backdrops.json")

def _live_diag_safe_source(source):
    source = source or {}
    return str(source.get("name") or source.get("title") or source.get("playlist_name") or source.get("type") or "unknown").strip()

def _live_diag_safe_icon(value):
    """Return non-sensitive picon diagnostics (never credentials/query strings)."""
    raw = str(value or "").strip().replace("\\/", "/")
    if not raw:
        return "empty"
    try:
        clean = raw.split("?", 1)[0]
        # Do not persist usernames/passwords that some panels embed in paths.
        clean = re.sub(r"(?i)(username|password|user|pass)[=/][^/&]+", r"\1=<redacted>", clean)
        parts = clean.split("/")
        tail = "/".join(parts[-2:]) if len(parts) >= 2 else clean
        host = ""
        if "://" in clean:
            host = clean.split("://", 1)[1].split("/", 1)[0]
        return "present len=%d host=%s tail=%s" % (len(raw), host or "-", tail[-120:])
    except Exception:
        return "present len=%d" % len(raw)

def _live_diag_log(source, item, stage, **values):
    return None

def _remember_infobar_live_poster(title, url):
    key = re.sub(r"\s+", " ", str(title or "").strip().lower())
    url = str(url or "").strip()
    if not key or not url:
        return
    data = {}
    try:
        with open(LIVE_POSTER_INDEX_FILE, "r") as handle:
            raw = json.load(handle) or {}
        if isinstance(raw, dict):
            data = {str(k): str(v) for k, v in raw.items() if k and v}
    except Exception:
        pass
    if data.get(key) == url:
        return
    data[key] = url
    if len(data) > 1200:
        for old_key in list(data.keys())[:len(data) - 1000]:
            data.pop(old_key, None)
    try:
        folder = os.path.dirname(LIVE_POSTER_INDEX_FILE)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = LIVE_POSTER_INDEX_FILE + ".tmp"
        with open(tmp, "w") as handle:
            json.dump(data, handle, ensure_ascii=True, separators=(",", ":"))
        os.rename(tmp, LIVE_POSTER_INDEX_FILE)
    except Exception:
        pass


def _load_live_infobar_backdrops():
    try:
        with open(LIVE_INFOBAR_BACKDROP_INDEX_FILE, "r") as handle:
            value = json.load(handle)
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    return {}


def _remember_live_infobar_backdrop(title, url):
    key = re.sub(r"\s+", " ", str(title or "").strip().lower())
    url = str(url or "").strip()
    if not key or not url:
        return
    rows = _load_live_infobar_backdrops()
    if rows.get(key) == url:
        return
    rows[key] = url
    if len(rows) > 1200:
        for old in list(rows)[:len(rows)-1000]:
            rows.pop(old, None)
    tmp = LIVE_INFOBAR_BACKDROP_INDEX_FILE + ".tmp"
    try:
        with open(tmp, "w") as handle:
            json.dump(rows, handle, separators=(",", ":"))
        os.rename(tmp, LIVE_INFOBAR_BACKDROP_INDEX_FILE)
    except Exception:
        pass


STALKER_SERVICE_TYPES_FILE = data_path("stalker_service_types.json")

def _stalker_source_key(source):
    source = source or {}
    return "%s|%s" % (source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _load_stalker_live_service_type(source, fallback):
    if (source or {}).get("type") != "stalker":
        return fallback
    try:
        with open(STALKER_SERVICE_TYPES_FILE, "r") as handle:
            raw = json.load(handle) or {}
        value = int((raw.get(_stalker_source_key(source), {}) or {}).get("live", fallback))
        if value in (1, 4097, 5001, 5002):
            return value
    except Exception:
        pass
    return fallback



def _stalker_compat(source):
    source = source or {}
    return load_stalker_compat(source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _save_stalker_engine(source, value):
    source = source or {}
    return save_stalker_compat(source.get("portal") or source.get("url") or "", source.get("mac") or "", live_engine=int(value))

def _available_service_types():
    values = [(4097, "GStreamer 4097 (default)")]
    if serviceapp_backend_available(5001):
        values.append((5001, "GstPlayer 5001"))
    else:
        values.append((5001, "GstPlayer 5001 (requires ServiceApp)"))
    if serviceapp_backend_available(5002):
        values.append((5002, "ExtePlayer3 5002"))
    return values

def _load_service_type():
    available = [value for value, _label in _available_service_types()]
    for path in (PLAYER_CONFIG, LIVE_SETTINGS_FILE):
        try:
            import json
            with open(path, "r") as handle:
                value = int((json.load(handle) or {}).get("service_type", 4097))
            if value in available:
                return value
        except Exception:
            pass
    return available[0] if available else 4097

def _save_service_type(value):
    try:
        import json
        folder = os.path.dirname(PLAYER_CONFIG)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = PLAYER_CONFIG + ".tmp"
        with open(tmp, "w") as handle:
            json.dump({"service_type": int(value)}, handle)
        os.rename(tmp, PLAYER_CONFIG)
    except Exception:
        pass


def _reminder_u(value):
    if isinstance(value, str):
        return value.decode("utf-8", "replace")
    return text_type(value if value is not None else u"")

class LiveInfoBarShowHide(object):
    STATE_HIDDEN = 0
    STATE_SHOWN = 1

    def __init__(self):
        self._ib_state = self.STATE_SHOWN
        self._ib_timer = eTimer()
        try:
            self._ib_timer.timeout.connect(self._hideInfobar)
        except Exception:
            self._ib_timer.callback.append(self._hideInfobar)
        # Ultra's infobar-show handler does not perform synchronous metadata
        # work. Keep the visible OSD path paint-only; reuse a one-shot GUI
        # timer for EPG refresh after the requested channel is playing.
        self._ib_epg_timer = eTimer()
        try:
            self._ib_epg_timer_connection = self._ib_epg_timer.timeout.connect(self._deferredInfobarEpg)
        except Exception:
            self._ib_epg_timer.callback.append(self._deferredInfobarEpg)
        self.onShow.append(self._onShown)
        self.onHide.append(self._onHidden)

    def _onShown(self):
        self._ib_state = self.STATE_SHOWN
        self._startHideTimer()

    def _onHidden(self):
        self._ib_state = self.STATE_HIDDEN

    def _startHideTimer(self):
        try:
            self._ib_timer.stop()
            # Stream setup may take longer than the old five-second timer,
            # especially for Stalker create_link. Never hide the first
            # infobar before the channel has decoded a real video frame.
            if (getattr(self, "_liveResolvePending", False)
                    or getattr(self, "_liveStartupPending", False)
                    or (not getattr(self, "reuse_current", False)
                        and not getattr(self, "_livePlaybackConfirmed", False))):
                return
            self._ib_timer.start(5000, True)
        except Exception:
            pass

    def _hideInfobar(self):
        try:
            self.hide()
        except Exception:
            pass

    def toggleInfobar(self):
        if self._ib_state == self.STATE_HIDDEN:
            self.show()
            self._startHideTimer()
        else:
            self.hide()

    def showInfobar(self):
        # Rendering must never start EPG parsing/requests or poster lookups
        # inline with the OK press. The channel decoder keeps priority.
        try:
            self.show()
            self._startHideTimer()
            # The browser already drew a valid guide for this exact channel.
            # Paint its snapshot immediately, even before DreamOS publishes
            # evStart/media metadata; never block first video frames for EPG.
            try:
                if not text_type(self["epgNow"].getText() or u"").strip():
                    self._showBrowserInfobarEpg(self._current())
            except Exception:
                pass
            if (getattr(self, '_livePlaybackConfirmed', False)
                    and not getattr(self, '_liveStartupPending', False)
                    and not getattr(self, '_liveResolvePending', False)
                    and not getattr(self, '_epgSchedulePending', False)):
                self._ib_epg_timer.start(180, True)
        except Exception:
            pass

    def _deferredInfobarEpg(self):
        # Ultra-style OSD: schedule work after the paint, and only for a
        # confirmed service. No decoder reinitialisation or new service play.
        if (getattr(self, '_epgClosed', False)
                or getattr(self, '_liveStartupPending', False)
                or getattr(self, '_liveResolvePending', False)
                or not getattr(self, '_livePlaybackConfirmed', False)
                or getattr(self, '_epgSchedulePending', False)):
            return
        try:
            if getattr(self, '_epg_ready', False):
                self._updateEpg()  # existing provider cache/throttle rules
            else:
                self._scheduleEpg()  # adopted PiG may have missed evStart
        except Exception:
            pass


class TiviMateLivePlayer(InfoBarBase, LiveInfoBarShowHide, InfoBarAudioSelection,
                         InfoBarSubtitleSupport, InfoBarSummarySupport, Screen):
    """Dedicated Live player. It intentionally does not inherit or modify the VOD player."""

    skin = '''<screen name="TiviMateLivePlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
        <!-- r451: VOD-style Live infobar + actual color-key legend + native player technical badges. -->
        <eLabel position="0,800" size="1920,280" backgroundColor="#B8000000" zPosition="1"/>
        <eLabel position="0,799" size="1920,1" backgroundColor="#55FFFFFF" zPosition="2"/>

        <!-- Live EPG landscape art only: no black placeholder, no vertical poster. -->
        <!-- Always-visible transparent TiViMate fallback INSIDE the oval, not in the channel picon. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/tivimate_inside_oval.png" position="34,826" size="400,224" alphatest="blend" zPosition="4" />
        <widget name="livePoster" position="34,826" size="400,224" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="backdropFrame" position="34,826" size="400,224" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/oval_mask_frame.png" alphatest="blend" scale="1" zPosition="7"/>
        <eLabel position="450,834" size="1,200" backgroundColor="#3859636D" zPosition="2"/>
        <eLabel position="1580,820" size="1,235" backgroundColor="#3859636D" zPosition="2"/>

        <widget source="channel" render="Label" position="476,824" size="617,46" font="Regular;36" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="resolutionBadge" position="1110,824" size="100,42" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="aspectBadge" position="1220,824" size="82,42" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="videoBadge" position="1312,824" size="100,42" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="audioBadge" position="1422,824" size="100,42" alphatest="blend" scale="1" zPosition="5"/>

        <widget name="nowTag" position="476,884" size="92,34" font="Regular;25" foregroundColor="#FFD84D" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNow" position="573,884" size="907,34" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="nextTag" position="476,927" size="92,31" font="Regular;22" foregroundColor="#28A9FF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNext" position="573,927" size="907,31" font="Regular;22" foregroundColor="#C7D3DF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <eLabel position="476,978" size="1004,11" backgroundColor="#59636D" zPosition="3"/>
        <widget name="epgProgress" position="476,978" size="1004,11" backgroundColor="#59636D" foregroundColor="#16C4EA" zPosition="4"/>
        <widget name="epgProgressText" position="1185,997" size="295,31" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="4"/>
        <!-- EPG synopsis / film year / rating; uses unused space below progress and does not cover playback. -->
        <widget name="epgDetails" position="476,993" size="694,37" font="Regular;17" foregroundColor="#E4EDF5" backgroundColor="#00000000" transparent="1" noWrap="0" zPosition="5"/>

        <!-- right: channel picon only. r507 removes the counter/date/hint text
             below it and lets the picon use the full right-hand infobar panel. -->
        <widget name="picon" position="1600,835" size="265,220" alphatest="blend" scale="1" zPosition="4"/>

        <!-- Color-key legend.  Every label below is wired to the same action map. -->
        <eLabel position="476,1035" size="20,20" backgroundColor="#E53935" zPosition="6"/>
        <widget name="redKeyText" position="506,1029" size="210,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
        <eLabel position="726,1035" size="20,20" backgroundColor="#31D158" zPosition="6"/>
        <widget name="greenKeyText" position="756,1029" size="180,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
        <eLabel position="946,1035" size="20,20" backgroundColor="#FFD84D" zPosition="6"/>
        <widget name="yellowKeyText" position="976,1029" size="250,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
        <eLabel position="1236,1035" size="20,20" backgroundColor="#28A9FF" zPosition="6"/>
        <widget name="blueKeyText" position="1266,1029" size="260,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
    </screen>'''

    def __init__(self, session, source, channels, index=0, reuse_current=False, favorite_exit_stop=False, pending_link=None):
        Screen.__init__(self, session)
        # Initialise the oval-artwork worker state before any asynchronous
        # EPG/artwork callback can be registered (OpenATV crash-log guard).
        self._livePillClosed = False
        self._livePillLock = threading.Lock()
        self._livePillResults = []
        self._livePillWorkers = 0
        self._livePillRequestSeq = 0
        self.session = session
        self.source = source or {}
        self.channels = list(channels or [])
        self.reuse_current = bool(reuse_current)
        self.favorite_exit_stop = bool(favorite_exit_stop)
        self._pendingLiveLink = pending_link if isinstance(pending_link, dict) else None
        self._pendingLiveLinkIndex = int(index or 0)
        self._preserve_live_subtitles_on_close = False
        self.index = max(0, min(int(index or 0), max(0, len(self.channels) - 1)))
        compat = _stalker_compat(self.source) if self.source.get("type") == "stalker" else {}
        saved_auto_engine = compat.get("live_engine")
        self._auto_engine = bool(self.source.get("type") == "stalker" and not saved_auto_engine)
        if self.source.get("type") == "stalker":
            initial_engine = saved_auto_engine or _load_stalker_live_service_type(self.source, _load_service_type())
        else:
            initial_engine = self.source.get("service_type", _load_service_type())
        self.service_type = compatible_service_type(initial_engine or 4097)
        if self.source.get('type') == 'stalker':
            _stalker_note('PLAYER_OPEN', service=self.service_type,
                          auto=int(self._auto_engine), channels=len(self.channels),
                          client=int(get_source_client is not None))
        available_engines = [v for v, _label in _available_service_types()]
        preferred_order = [4097, 5002, 5001]
        self._engine_candidates = [v for v in preferred_order if v in available_engines and v != self.service_type]
        self._engine_attempted = [self.service_type]
        self.current_url = ""
        # Ultra-owned external player tracking. Native 4097 is never killed.
        self._ultraDecoderGuard = UltraLiveDecoderGuard()
        self._ultraExternalUrl = ""
        self._live_client = None
        # Stalker client startup reads cache, creates a session and may spawn
        # prefetch work. Leave that to the async link worker, never the GUI.
        try:
            if self.source.get("type") == "xtream":
                self._live_client = get_source_client(self.source)
        except Exception:
            self._live_client = None

        # Stalker create_link is a network operation. Never run it on the
        # Enigma2 UI thread; otherwise the system spinner appears while the
        # portal is resolving the channel URL.
        self._liveResolveToken = 0
        self._liveResolveHandle = None
        self._liveResolveResult = None
        self._liveResolvePending = False
        self._liveResolveDeadline = 0.0
        self._liveResolveTimer = eTimer()
        try:
            self._liveResolveTimer.timeout.connect(self._finishAsyncLiveResolve)
        except Exception:
            self._liveResolveTimer.callback.append(self._finishAsyncLiveResolve)
        # Fullscreen can take ownership of the browser's pending create_link.
        # No duplicate network request, and the Infobar opens immediately.
        self._handoffLinkTimer = eTimer()
        try:
            self._handoffLinkTimer.timeout.connect(self._pollPendingLiveLink)
        except Exception:
            self._handoffLinkTimer.callback.append(self._pollPendingLiveLink)
        # Separate timeout for Enigma's native service engine after a URL was
        # resolved. evStart alone does not prove a playable video decoded.
        self._liveStartupTimer = eTimer()
        try:
            self._liveStartupTimer.timeout.connect(self._checkLiveStartup)
        except Exception:
            self._liveStartupTimer.callback.append(self._checkLiveStartup)
        self._liveStartupDeadline = 0.0
        self._liveStartupAt = 0.0
        self._liveStartupIndex = -1
        self._liveStartupKey = ""
        self._liveStartupPending = False
        self._livePlaybackConfirmed = False
        self._liveServiceStarted = False
        # Ultra player_golden57: suppress EOF/TuneFailed caused by replacing
        # the previous Enigma service; never infer a stall from UI polls.
        self._liveEventSuppressUntil = 0.0
        self._liveInterruptedRef = ""
        self._liveStartupSeenRef = False
        self._liveStartupMissingSince = 0.0
        self._liveTuneFailedRef = ""
        self._liveTuneFailedAt = 0.0
        self._liveVideoProbeSize = None
        self._liveVideoProbeAt = 0.0
        self._liveAudioProbeAt = 0.0
        self._liveSpinnerMuted = False
        self._liveAttemptKey = None
        self._watchdogBusy = False
        self._picon_token = 0
        self._picon_path = None
        self._subssupport = None
        self._external_subs = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._subtitle_session_delay_ms = 0
        # Live subtitles have their own channel/program context.  Keep it
        # independent from VOD/Series item metadata and reset it on zaps.
        self._live_epg_context = {}
        self._liveEpgPlot = u""
        self._infobarPosterYear = ""
        self._infobarPosterRating = 0.0
        self._live_subtitle_channel_key = ""
        self._subtitle_horizontal_offset = 0
        self._infobarPosterPath = ""
        self._infobarArtworkKind = "backdrops"
        self._original_service = None
        try:
            self._original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass

        InfoBarBase.__init__(self)
        LiveInfoBarShowHide.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSummarySupport.__init__(self)

        self["channel"] = StaticText("")
        self["counter"] = StaticText("")
        self["clock"] = StaticText("")
        self["hint"] = StaticText(tr("↑↓ Change   MENU Player Engine   BLUE TiviMate Subtitles   RED Edit Subtitles"))
        self["picon"] = Pixmap()
        self["livePoster"] = Pixmap()
        self["backdropFrame"] = Pixmap()
        from .resolution_badge import player_badge_skin
        self.skin = player_badge_skin(self.skin)
        self["resolutionBadge"] = Label("")
        self["aspectBadge"] = Pixmap()
        self["videoBadge"] = Pixmap()
        self["audioBadge"] = Pixmap()
        self._liveTechBadgeValues = {"resolution": "", "aspect": "", "video": "", "audio": ""}
        self._liveTechFastRefresh = 0
        for _name in ("resolutionBadge", "aspectBadge", "videoBadge", "audioBadge"):
            try:
                self[_name].hide()
            except Exception:
                pass
        self["redKeyText"] = Label(tr("Edit Subtitles"))
        self["greenKeyText"] = Label(tr("Audio Tracks"))
        self["yellowKeyText"] = Label(tr("Server Subtitles"))
        self["blueKeyText"] = Label(tr("TiviMate Subtitles"))
        self._livePosterToken = 0
        self._livePosterResult = None
        self._livePosterTimer = eTimer()
        try:
            self._livePosterTimer.callback.append(self._startInfobarPosterLookup)
        except Exception:
            self._livePosterTimer.timeout.connect(self._startInfobarPosterLookup)
        self._livePosterPoll = eTimer()
        try:
            self._livePosterPoll.callback.append(self._finishInfobarPosterLookup)
        except Exception:
            self._livePosterPoll.timeout.connect(self._finishInfobarPosterLookup)
        self._livePillTimer = eTimer()
        try:
            self._livePillTimer.callback.append(self._finishInfobarPill)
        except Exception:
            self._livePillTimer.timeout.connect(self._finishInfobarPill)
        self._livePosterPic = ePicLoad()
        try:
            self._livePosterPic.PictureData.get().append(self._infobarPosterDecoded)
        except Exception:
            self._livePosterPicConn = self._livePosterPic.PictureData.connect(self._infobarPosterDecoded)
        try:
            self["livePoster"].hide()
            self["backdropFrame"].show()
        except Exception:
            pass
        self["nowTag"] = Label(tr("NOW"))
        self["epgNow"] = Label("")
        self["nextTag"] = Label(tr("NEXT"))
        self["epgNext"] = Label("")
        self["epgDetails"] = Label("")
        self["epgProgress"] = ProgressBar()
        self["epgProgressText"] = Label("")
        try:
            self["epgProgress"].setRange((0, 100))
        except Exception:
            pass

        self._pic = ePicLoad()
        try:
            self._pic.PictureData.get().append(self._piconDecoded)
        except Exception:
            self._pic_conn = self._pic.PictureData.connect(self._piconDecoded)

        self._clock_timer = eTimer()
        try:
            self._clock_timer_connection = self._clock_timer.timeout.connect(self._updateClock)
        except Exception:
            self._clock_timer.callback.append(self._updateClock)

        # Playback must start before any EPG JSON work.  The one-shot timer
        # lets the decoder settle, then reads the already-built in-memory/disk
        # cache without starting downloads or XML conversion in the player.
        self._epg_timer = eTimer()
        try:
            self._epg_timer_connection = self._epg_timer.timeout.connect(self._delayedEpg)
        except Exception:
            self._epg_timer.callback.append(self._delayedEpg)
        self._epg_ready = False
        self._epgSchedulePending = False
        # The JSON/XMLTV EPG can be many megabytes. Never decode it on the
        # Enigma2 GUI thread: one coalescing worker does all local lookups.
        self._epgAsyncToken = 0
        self._epgAsyncLock = threading.Lock()
        self._epgAsyncPending = None
        self._epgAsyncResult = None
        self._epgAsyncWorkerRunning = False
        self._epgClosed = False
        self._epgNextReadAt = 0.0
        self._epgNextRequestAt = 0.0
        self._epgAsyncPoll = eTimer()
        try:
            self._epgAsyncPoll_connection = self._epgAsyncPoll.timeout.connect(self._finishAsyncEpgLookup)
        except Exception:
            self._epgAsyncPoll.callback.append(self._finishAsyncEpgLookup)
        self._stalker_epg_token = 0
        self._stalker_epg_result = None
        self._stalker_epg_started_at = 0.0
        self._stalker_epg_poll = eTimer()
        try:
            self._stalker_epg_poll_connection = self._stalker_epg_poll.timeout.connect(self._finishStalkerPlayerEpg)
        except Exception:
            self._stalker_epg_poll.callback.append(self._finishStalkerPlayerEpg)

        # Xtream Live EPG follows the same provider-direct model as Stalker.
        self._xtream_epg_token = 0
        self._xtream_epg_result = None
        self._xtream_epg_started_at = 0.0
        self._xtream_epg_cache = {}
        self._xtream_epg_last_update = 0.0
        self._xtream_epg_poll = eTimer()
        try:
            self._xtream_epg_poll_connection = self._xtream_epg_poll.timeout.connect(self._finishXtreamPlayerEpg)
        except Exception:
            self._xtream_epg_poll.callback.append(self._finishXtreamPlayerEpg)

        self._engine_timer = eTimer()
        try:
            self._engine_timer.timeout.connect(self._verifyAutoEngine)
        except Exception:
            self._engine_timer.callback.append(self._verifyAutoEngine)

        self._watchdog_timer = eTimer()
        try:
            self._watchdog_timer.timeout.connect(self._sendStalkerWatchdog)
        except Exception:
            self._watchdog_timer.callback.append(self._sendStalkerWatchdog)

        self._catchup_result = None
        self._catchup_item = None
        self._catchup_timer = eTimer()
        try:
            self._catchup_timer.timeout.connect(self._finishXtreamCatchupFromInfobar)
        except Exception:
            self._catchup_timer.callback.append(self._finishXtreamCatchupFromInfobar)

        self["actions"] = ActionMap([
            "OkCancelActions", "DirectionActions", "InfobarShowHideActions",
            "ChannelSelectBaseActions", "InfobarChannelSelection", "InfoActions", "ColorActions", "NumberActions", "MenuActions",
            "InfobarInstantRecord", "RecordActions", "TiviMatePlayerActions"
        ], {
            "cancel": self.back,
            "red": self.openSubtitleEditor,
            "green": self.audioSelection,
            "yellow": self.openSubtitleSelection,
            "ok": self.showInfobar,
            "oklong": self.back,
            "toggleShow": self.showInfobar,
            "right": self.nextChannel,
            "left": self.prevChannel,
            "up": self.back,
            "down": self.back,
            "channelUp": self.nextChannel,
            "channelDown": self.prevChannel,
            "menu": self.openPlayerEngineMenu,
            # INFO must always reopen the Live Infobar on different Enigma2 images.
            # Catch-up remains accessible in MENU; INFO must not silently
            # route every ordinary channel to the archive handler.
            "info": self.showInfobar,
            "0": self.cycleServiceType,
            "blue": self.openSubsSupport,
            "subtitleFineMinus": self.subtitleFineMinus,
            "subtitleFinePlus": self.subtitleFinePlus,
            "instantRecord": self.toggleLiveRecording,
            "record": self.toggleLiveRecording,
        }, -2)

        live_events = {iPlayableService.evStart: self._serviceStarted}
        tune_failed = getattr(iPlayableService, "evTuneFailed", None)
        if tune_failed is not None:
            live_events[tune_failed] = self._serviceFailed
        stream_eof = getattr(iPlayableService, "evEOF", None)
        if stream_eof is not None:
            live_events[stream_eof] = self._serviceEof
        self._events = ServiceEventTracker(screen=self, eventmap=live_events)
        if self.reuse_current:
            self.onFirstExecBegin.append(self._showCurrentWithoutRestart)
        elif self._pendingLiveLink is not None:
            self.onFirstExecBegin.append(self._beginPendingLiveLink)
        else:
            self.onFirstExecBegin.append(self.playCurrent)
        self.onClose.append(self._cleanup)

    def _cancelPendingLiveLink(self):
        state = getattr(self, "_pendingLiveLink", None)
        self._pendingLiveLink = None
        try: self._handoffLinkTimer.stop()
        except Exception: pass
        if state is not None:
            handle = state.get("handle")
            if handle is not None:
                try: handle.cancel()
                except Exception: pass

    def _beginPendingLiveLink(self):
        """Show the Infobar NOW while Ultra's original worker finishes."""
        item = self._current()
        if item:
            # Mixed Favorites can belong to another provider than the hidden
            # Live browser.  A transferred URL must inherit *its* engine,
            # auth, subtitles and service reference, never the parent server.
            self._activateSourceForItem(item)
        if not item or self.source.get("type") != "stalker":
            self._cancelPendingLiveLink()
            self.playCurrent()
            return
        self._prepareLiveSubtitleChannel(item)
        try:
            self["channel"].setText(item.get("name") or item.get("title") or "IPTV")
            self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
            self["hint"].setText("Opening channel...  •  CH+/- Next channel")
        except Exception: pass
        self._muteLiveSpinner()
        try: self.showInfobar()
        except Exception: pass
        self._pollPendingLiveLink()

    def _pollPendingLiveLink(self):
        state = self._pendingLiveLink
        if state is None:
            return
        if self.index != self._pendingLiveLinkIndex:
            self._cancelPendingLiveLink()
            return
        # A fast channel change or a wrong Favorites card must never consume
        # another provider's old create_link result, even if indices coincide.
        if state.get("favorite"):
            item = self._current() or {}
            channel = str(item.get("stream_id") or item.get("ch_id") or
                          item.get("id") or item.get("url") or item.get("cmd") or
                          item.get("name") or "").strip()
            owner = item.get("_favorite_source") if isinstance(item.get("_favorite_source"), dict) else {}
            if (not channel or channel != state.get("source", (None, None))[1] or
                    str(owner.get("type") or "") != "stalker" or
                    owner != state.get("owner")):
                self._cancelPendingLiveLink()
                return
        result = state.get("result")
        if result is None:
            if monotonic() >= state.get("deadline", 0):
                self._cancelPendingLiveLink()
                self._liveStartFailure(tr("Server did not respond. Try another channel."))
            else:
                try: self._handoffLinkTimer.start(90, True)
                except Exception: pass
            return
        expected_token = state.get("token")
        self._pendingLiveLink = None
        try: self._handoffLinkTimer.stop()
        except Exception: pass
        try:
            token, row, _force, url, _error = result
        except Exception:
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        if token != expected_token or not url:
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        # The worker belongs to this exact Infobar selection now. Enigma's
        # decoder startup and fallbacks remain entirely inside the player.
        self._playResolvedCurrent(self._current(), url, self.index)

    def _showCurrentWithoutRestart(self):
        """Reopen the full-screen Live UI around the already playing service.

        This intentionally does not resolve stream_url/create_link and never
        calls playService, so selecting the same channel from the list cannot
        refresh or restart playback.
        """
        item = self._current()
        if not item:
            return
        name = item.get("name") or item.get("title") or "IPTV"
        try:
            self.current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            self.current_ref = None
        try:
            self._restorePreservedLiveSubtitle(item)
        except Exception:
            pass
        try:
            self.source["_tivimate_current_live_id"] = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            pass
        self["channel"].setText(name)
        self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
        # The Live browser already verified decoded media on this exact ref
        # before passing reuse_current=True. evStart happened *before* this
        # screen existed, so do not wait for another event that cannot arrive.
        # Adopt the live service without reissuing create_link/playService.
        if self.current_ref is None:
            # A previously verified PiG might stop between the browser's
            # check and opening this screen. Recover with one normal bounded
            # resolve, rather than leaving a black player indefinitely.
            self.playCurrent()
            return
        if self.reuse_current:
            # Adopted preview is older than this screen's PID baseline.
            # It remains owned by the Live browser, not by this player.
            self._livePlaybackConfirmed = True
            self._liveServiceStarted = True
            # Opening full-screen reuses the verified PiG without playService.
            # A delayed browser event must not end this adopted service.
            self._liveEventSuppressUntil = monotonic() + 1.25
            self._liveInterruptedRef = ""
            if self.source.get('type') == 'stalker':
                try:
                    self._watchdog_timer.stop()
                    self._watchdog_timer.start(30000, True)
                except Exception:
                    pass
        self._updateClock()
        try:
            self._clock_timer.start(10000, False)
        except Exception:
            pass
        self._loadPicon(item)
        # showInfobar schedules the EPG once via its existing delayed timer.
        self.showInfobar()

    def _current(self):
        if not self.channels:
            return {}
        return self.channels[self.index]

    def _activateSourceForItem(self, item):
        """Use the owning provider while zapping a mixed-source Favorites list.

        Normal Live lists keep the player's original source unchanged.  Global
        Favorites rows carry ``_favorite_source`` in memory; when present we
        switch only the provider context used to resolve/play that row.
        """
        fav_source = item.get("_favorite_source") if isinstance(item, dict) else None
        if not isinstance(fav_source, dict):
            return
        if fav_source is self.source or fav_source == self.source:
            return
        self.source = fav_source
        self._live_client = None
        try:
            if self.source.get("type") == "xtream":
                self._live_client = get_source_client(self.source)
        except Exception:
            self._live_client = None

        compat = _stalker_compat(self.source) if self.source.get("type") == "stalker" else {}
        saved_auto_engine = compat.get("live_engine")
        self._auto_engine = bool(self.source.get("type") == "stalker" and not saved_auto_engine)
        try:
            if self.source.get("type") == "stalker":
                initial_engine = saved_auto_engine or _load_stalker_live_service_type(self.source, _load_service_type())
            else:
                initial_engine = self.source.get("service_type", _load_service_type())
            self.service_type = compatible_service_type(initial_engine or 4097)
        except Exception:
            self.service_type = int(_load_service_type() or 4097)
        available_engines = [v for v, _label in _available_service_types()]
        preferred_order = [4097, 5002, 5001]
        self._engine_candidates = [v for v in preferred_order if v in available_engines and v != self.service_type]
        self._engine_attempted = [self.service_type]

    def _urlFor(self, item):
        try:
            stype = self.source.get("type")
            if stype in ("xtream", "stalker"):
                client = self._live_client
                if client is None:
                    client = get_source_client(self.source)
                    self._live_client = client
                return client.stream_url(item, "live")
            if stype in ("m3u", "fg"):
                return item.get("url", "")
            return ""
        except Exception as exc:
            try:
                if self.source.get("type") == "stalker":
                    stalker_log("PLAYER resolve failed channel=%s error=%s" % (
                        (item or {}).get("name") or (item or {}).get("title") or "", exc))
            except Exception:
                pass
            return ""


    def _clearLiveTechnicalBadges(self):
        # r521: a zap must never show codec/resolution values from the
        # previous service while the decoder is switching to the new one.
        self._liveTechBadgeValues = {"resolution": "", "aspect": "", "video": "", "audio": ""}
        # r522: reuse the existing clock timer for a few quick local decoder-info
        # reads after zapping. No new timer/hook/network request is introduced.
        self._liveTechFastRefresh = 4
        for _name in ("resolutionBadge", "aspectBadge", "videoBadge", "audioBadge"):
            try:
                self[_name].hide()
            except Exception:
                pass

    def _clearLiveEpgUi(self):
        # r521: clear the old channel's programme text immediately. EPG is
        # scheduled only from the existing evStart callback after playback
        # starts, so zapping stays playback-first and the lookup is invisible.
        self._epgSchedulePending = False
        self._epg_ready = False
        self._live_epg_context = {}
        self._epgAsyncToken += 1
        self._epgNextReadAt = 0.0
        self._epgNextRequestAt = 0.0
        # Discard any in-flight provider result for the previous channel.
        self._stalker_epg_token += 1
        self._xtream_epg_token += 1
        self._stalker_epg_result = None
        self._xtream_epg_result = None
        try:
            self._stalker_epg_poll.stop()
            self._xtream_epg_poll.stop()
        except Exception:
            pass
        try:
            self._epgAsyncPoll.stop()
            with self._epgAsyncLock:
                self._epgAsyncPending = None
                self._epgAsyncResult = None
        except Exception:
            pass
        try:
            self._epg_timer.stop()
            self._ib_epg_timer.stop()
        except Exception:
            pass
        try:
            self._setLiveEpgLabel("epgNow", "")
            self._setLiveEpgLabel("epgNext", "")
            self._liveEpgPlot = u""
            self._infobarPosterYear = ""
            self._infobarPosterRating = 0.0
            self["epgDetails"].setText("")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
        except Exception:
            pass
        # Clear old channel artwork immediately when zapping. Keep the oval
        # frame and the static TiViMate fallback visible until new EPG art loads.
        try:
            self._scheduleInfobarPoster("")
        except Exception:
            pass

    def _cancelLiveStartup(self):
        self._liveStartupSeenRef = False
        self._liveStartupMissingSince = 0.0
        self._liveTuneFailedRef = ""
        self._liveTuneFailedAt = 0.0
        self._liveServiceStarted = False
        self._liveVideoProbeSize = None
        self._liveVideoProbeAt = 0.0
        self._liveAudioProbeAt = 0.0
        self._liveStartupPending = False
        self._liveStartupDeadline = 0.0
        self._liveStartupAt = 0.0
        self._liveStartupKey = ""
        try:
            self._liveStartupTimer.stop()
        except Exception:
            pass

    def _cancelLiveResolve(self):
        old_handle = getattr(self, "_liveResolveHandle", None)
        self._liveResolveHandle = None
        if old_handle is not None:
            old_handle.cancel()
        self._liveResolveToken += 1
        self._liveResolvePending = False
        self._liveResolveDeadline = 0.0
        self._liveResolveStartedAt = 0.0
        self._liveResolveResult = None
        try:
            self._liveResolveTimer.stop()
        except Exception:
            pass

    def _muteLiveSpinner(self):
        # Enigma's native spinner can remain onscreen while a dead IPTV service
        # waits in the decoder. Temporarily mute it for this Live attempt only.
        if not self._liveSpinnerMuted:
            try:
                setSpinnerOnOff(0)
                self._liveSpinnerMuted = True
            except Exception:
                pass

    def _restoreLiveSpinner(self):
        # Never leak a global Enigma spinner override into other screens.
        if self._liveSpinnerMuted:
            self._liveSpinnerMuted = False
            try:
                setSpinnerOnOff(1)
            except Exception:
                pass

    def _liveStartFailure(self, message, stop_service=True):
        self._liveAttemptKey = None
        # Do not skip channels automatically, modify their links or retry a
        # whole server when a single channel fails. Remote zapping stays live.
        # A failed create_link does not imply the previous working service
        # should be stopped: only stop a failed service actually started for
        # this exact channel/ref.
        had_startup = bool(self._liveStartupPending)
        failing_ref = getattr(self, "current_ref", None)
        self._cancelLiveStartup()
        self._livePlaybackConfirmed = False
        # Release any native service loading before displaying the failure.
        self._restoreLiveSpinner()
        # Never keep a dead Stalker stream's session watchdog running.
        try:
            self._watchdog_timer.stop()
        except Exception:
            pass
        if stop_service and had_startup and failing_ref is not None:
            try:
                active_ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if active_ref and active_ref.toString() == failing_ref.toString():
                    # Ultra's baseline excludes pre-existing receiver processes.
                    # Stop this exact failed service before retiring its PIDs.
                    retired_url = str(getattr(self, 'current_url', '') or '')
                    if retired_url == getattr(self, '_ultraExternalUrl', ''):
                        self._ultraDecoderGuard.capture(retired_url)
                    self.session.nav.stopService()
                    if retired_url == getattr(self, '_ultraExternalUrl', ''):
                        self._ultraDecoderGuard.retire(retired_url)
                        self._ultraExternalUrl = ''
            except Exception:
                pass
        try:
            self._engine_timer.stop()
        except Exception:
            pass
        if self.source.get("type") == "stalker":
            _stalker_note('PLAYER_FAILED', link=int(bool(self.current_url)),
                          startup=int(had_startup), service=self.service_type)
            # A modal MessageBox steals CH+/CH- focus for four seconds. Keep
            # dead channels non-blocking and show a clear inline failure.
            try: self["hint"].setText(str(message) + "  •  CH+/- Next channel")
            except Exception: pass
            try: self._setLiveEpgLabel("epgNow", str(message))
            except Exception: pass
            try: self.showInfobar()
            except Exception: pass
        else:
            # A modal failure dialog blocks remote channel navigation for
            # several seconds. Keep failures inline on every Live source.
            try:
                self["hint"].setText(str(message) + "  •  CH+/- Next channel")
            except Exception:
                pass
            try:
                self._setLiveEpgLabel("epgNow", str(message))
            except Exception:
                pass
            try:
                self.showInfobar()
            except Exception:
                pass

    def _checkLiveStartup(self):
        if not self._liveStartupPending:
            return
        if self._liveStartupIndex != self.index:
            self._cancelLiveStartup()
            return
        # A decoder can abandon a dead IPTV service without evTuneFailed.
        # Previously this silently occupied the entire 12/16-second startup
        # window even after Enigma stopped playing the attempted reference.
        # Fail fast only if the reference is truly absent; keep the original
        # full deadline for slow streams whose ref is still being buffered.
        if self._liveStartupReferenceLost():
            # The decoder can reject a Stalker service before the scheduled
            # 5.5-second automatic engine probe. In that case the original
            # code failed immediately and never tried the next already-known
            # playback engine. Reuse the SAME resolved URL and shared startup
            # deadline; do not create_link again or extend the timeout.
            if (self.source.get("type") == "stalker" and self._auto_engine and
                    self._engine_candidates and self.current_url and
                    time.time() < self._liveStartupDeadline):
                self._verifyAutoEngine()
                return
            self._liveStartFailure(tr("Channel could not start."), stop_service=True)
            return
        # An evTuneFailed can precede evStart. Do not leave a rejected decoder
        # hanging until the normal 12/16-second deadline if the SAME reference
        # still owns Navigation after a short settling interval. An unrelated
        # error from a previous channel can never match this expected ref.
        failed_ref = getattr(self, '_liveTuneFailedRef', '')
        failed_at = float(getattr(self, '_liveTuneFailedAt', 0.0) or 0.0)
        if failed_ref and failed_at and monotonic() - failed_at >= 0.7:
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, 'current_ref', None)
                still_failed = bool(active and expected and
                    active.toString() == expected.toString() == failed_ref)
            except Exception:
                still_failed = False
            self._liveTuneFailedRef = ''
            self._liveTuneFailedAt = 0.0
            if still_failed and not self._videoIsReady() and not self._audioOnlyIsReady():
                if (self.source.get('type') == 'stalker' and self._auto_engine and
                        self._engine_candidates and self.current_url and
                        time.time() < self._liveStartupDeadline):
                    self._verifyAutoEngine()
                else:
                    self._liveStartFailure(tr('Channel could not start.'), stop_service=True)
                return
        # On some Enigma2 images evStart arrives before Navigation publishes
        # its reference. The event is then ignored by _serviceStarted and is
        # never re-emitted; a valid channel would otherwise time out after
        # 12/16 seconds. Recover only for the exact new reference after the
        # decoder has produced media metadata, never from an old ref alone.
        if not self._liveServiceStarted and time.time() - self._liveStartupAt >= 1.25:
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, "current_ref", None)
                if active and expected and active.toString() == expected.toString():
                    svc = self.session.nav.getCurrentService()
                    info = svc and svc.info()
                    if info and (int(info.getInfo(iServiceInformation.sVideoWidth) or 0) > 0 and
                                 int(info.getInfo(iServiceInformation.sVideoHeight) or 0) > 0):
                        self._liveServiceStarted = True
            except Exception:
                pass
        # Some Enigma images briefly expose the *previous* channel's video
        # dimensions while a new service opens. Give the new decoder a moment.
        if ((time.time() - self._liveStartupAt >= 1.5) and
                (self._videoIsReady() or self._audioOnlyIsReady())):
            self._livePlaybackConfirmed = True
            if self.source.get('type') == 'stalker':
                _stalker_note('DECODER_READY', service=self.service_type)
            self._cancelLiveStartup()
            self._restoreLiveSpinner()
            # EPG and decoder badge refresh follow usable video, not a
            # potentially stalled create_link/playService. Never hold playback
            # behind programme parsing or artwork requests.
            # Reading codecs and loading PNG badges on the first decoded
            # frame delays the OSD and channel transition on slow receivers.
            # The existing 1s metadata refresh does this after video starts.
            self._liveTechFastRefresh = max(3, int(getattr(self, '_liveTechFastRefresh', 0) or 0))
            try:
                self._clock_timer.start(1000, False)
            except Exception:
                pass
            self._scheduleEpg()
            # First OK must display the channel WITH its infobar. Restart the
            # five-second visibility window on decoded video, not on the
            # possibly slow first provider request or playService call.
            self.showInfobar()
            # An engine is learned only after actual video was decoded.
            if self.source.get("type") == "stalker":
                try:
                    self._engine_timer.stop()
                    if self._auto_engine:
                        _save_stalker_engine(self.source, self.service_type)
                        self._auto_engine = False
                    self._watchdog_timer.stop()
                    self._watchdog_timer.start(30000, True)
                except Exception:
                    pass
            return
        if time.time() >= self._liveStartupDeadline:
            self._liveStartFailure(tr("Channel unavailable - try another channel."), stop_service=True)
            return
        try:
            # Most successful tunes settle in their first three seconds.
            # Reduce the extra delay between decoded video and confirmation,
            # then revert to the original gentle poll for slow/dead channels.
            elapsed = time.time() - self._liveStartupAt
            self._liveStartupTimer.start(220 if elapsed < 3.0 else 350, True)
        except Exception:
            pass

    def _liveStartupReferenceLost(self):
        """A missing Enigma service is a failure; slow buffering is NOT.

        Enigma builds differ in when they publish a ref after playService.
        Allow five seconds on builds that have not reported one yet. Once the
        expected ref has been observed, a sustained 0.9s disappearance is
        strong evidence that native playback has already terminated.
        """
        if not self._liveStartupPending:
            return False
        now = monotonic()
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            same = bool(ref is not None and expected is not None and
                        ref.toString() == expected.toString())
        except Exception:
            # An unavailable navigation API isn't evidence of failure.
            return False
        if same:
            self._liveStartupSeenRef = True
            self._liveStartupMissingSince = 0.0
            return False
        if not self._liveStartupMissingSince:
            self._liveStartupMissingSince = now
        # Match the normal Live/Windows preview policy: a temporarily empty
        # Navigation reference may take five seconds to appear on OpenATV/Pure,
        # but an unchanged *different* active service means the new tune is
        # probably not taking over. Retire it sooner and keep CH+/- responsive.
        grace = (0.9 if self._liveStartupSeenRef else
                 (5.0 if ref is None else 1.8))
        return bool(now - self._liveStartupMissingSince >= grace)

    def _ultraLiveEventCurrent(self):
        """Port of Ultra's current-ref/event-suppression guard for Live.

        Like Ultra, allow a missing Navigation ref after EOF: Enigma may
        clear the finished service before dispatching its event. Reject an
        explicitly *different* active ref so a late event cannot end a zap.
        """
        if monotonic() < getattr(self, '_liveEventSuppressUntil', 0.0):
            return False
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, 'current_ref', None)
            if expected is None:
                return False
            # Ultra's player_golden57 permits an empty Navigation ref after
            # an EOF, but a different *nonempty* ref belongs to another zap.
            return active is None or active.toString() == expected.toString()
        except Exception:
            return False

    def _ultraLiveInterrupted(self, reason):
        """Ultra player_golden57._handle_runtime_interruption policy.

        After a confirmed Live stream fails, NEVER automatically stop/play
        a decoder or refresh its URL. That caused repeated native allocations
        on real receivers. Leave the current Navigation service alone and
        permit a *manual* retry by selecting the channel again.
        """
        if not self._livePlaybackConfirmed or self._liveStartupPending:
            return False
        if not self._ultraLiveEventCurrent():
            return False
        try:
            ref_str = self.current_ref.toString()
        except Exception:
            return False
        if self._liveInterruptedRef == ref_str:
            return True
        self._liveInterruptedRef = ref_str
        self._livePlaybackConfirmed = False
        self._liveAttemptKey = None
        try: self._watchdog_timer.stop()
        except Exception: pass
        try: self._engine_timer.stop()
        except Exception: pass
        self._restoreLiveSpinner()
        # Inline status, not a modal MessageBox that prevents CH+/-.
        try: self['hint'].setText(tr('Stream interrupted - select channel to retry'))
        except Exception: pass
        try: self._setLiveEpgLabel("epgNow", tr('Stream interrupted'))
        except Exception: pass
        try: self.showInfobar()
        except Exception: pass
        return True

    def _serviceEof(self):
        """Ultra's evEOF policy: established Live never auto-restarts."""
        if not self._ultraLiveEventCurrent():
            return
        if self._livePlaybackConfirmed:
            self._ultraLiveInterrupted('EOF')
        elif self._liveStartupPending:
            # Failure during initial tuning is handled by the existing
            # bounded decoder startup/fallback logic, not a fresh create_link.
            self._serviceFailed()

    def _serviceFailed(self):
        # Ultra handles a genuine interruption after confirmed playback
        # without stopping and recreating native decoder instances.
        if (getattr(self, '_livePlaybackConfirmed', False) and
                not getattr(self, '_liveStartupPending', False)):
            self._ultraLiveInterrupted('tune failed')
            return
        # Startup still uses its original current-ref/deadline validation.
        # Ultra-style event suppression applies to confirmed playback only;
        # suppressing initial evTuneFailed could mask a genuinely bad engine.
        # Some engines emit a late error from the previously selected channel;
        # act only while the current selection is still opening.
        if self._liveStartupPending and self._liveStartupIndex == self.index:
            # A late evTuneFailed from the previous zap must not fail a newer
            # service. Only act on a ref that matches this attempt; otherwise
            # let the bounded startup deadline decide without a false failure.
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, "current_ref", None)
                # evTuneFailed can arrive late from the preceding service.
                # An empty or different navigation ref does NOT identify the
                # failed tune as our new channel. Let the bounded startup
                # probe decide rather than incorrectly aborting a fresh zap.
                if active is None or expected is None or active.toString() != expected.toString():
                    return
                if not self._liveServiceStarted and not self._liveStartupSeenRef:
                    # First evTuneFailed may be from the old service. Require
                    # a poll of the new ref before accepting the event.
                    return
                if time.time() - self._liveStartupAt < 0.65:
                    return
                self._liveTuneFailedRef = expected.toString()
                self._liveTuneFailedAt = monotonic()
                # Do not recurse into the full startup check from inside an
                # Enigma2 service callback; let its existing poll observe it.
                self._liveStartupTimer.start(350, True)
            except Exception:
                return

    def _playResolvedCurrent(self, item, url, expected_index=None):
        if not item or not url:
            return
        if expected_index is not None and int(expected_index) != int(self.index):
            return

        # Retrying an already-resolved Stalker URL under another decoder is
        # NOT a new channel. Avoid repeating EPG cancellation, artwork reset,
        # Picon decoding and UI timers for every engine candidate. These extra
        # GUI operations compete with native service startup on slow boxes.
        # The initial tune still clears stale EPG/technical data normally.
        same_engine_retry = bool(
            self.source.get("type") == "stalker" and self._auto_engine and
            self._liveStartupPending and self._liveStartupIndex == self.index and
            len(self._engine_attempted) > 1 and self.current_url == url)
        if not same_engine_retry:
            try:
                self._epg_timer.stop()
            except Exception:
                pass
            self._epgSchedulePending = False
            self._clearLiveEpgUi()
            self._clearLiveTechnicalBadges()
        previous_external_url = getattr(self, '_ultraExternalUrl', '')
        if previous_external_url and previous_external_url != url:
            self._ultraDecoderGuard.capture(previous_external_url)
        self.current_url = url
        # Stalker auto-engine retries must share the original deadline rather
        # than each restarting a full timeout on the same channel.
        key = "%s:%s:%s" % (str(self.source.get("type") or ""), self.index,
                                str(item.get("id") or item.get("stream_id") or
                                    item.get("ch_id") or item.get("cmd") or
                                    item.get("name") or ""))
        old_key = self._liveStartupKey
        old_deadline = self._liveStartupDeadline
        self._liveStartupKey = key
        self._liveStartupIndex = self.index
        self._liveStartupAt = time.time()
        if key == old_key and self._auto_engine and old_deadline > time.time():
            self._liveStartupDeadline = old_deadline
        else:
            duration = (LIVE_STALKER_STARTUP_TIMEOUT_SECONDS if self.source.get("type") == "stalker"
                        else LIVE_STARTUP_TIMEOUT_SECONDS)
            self._liveStartupDeadline = time.time() + duration
        self._liveStartupPending = True
        self._livePlaybackConfirmed = False
        self._liveServiceStarted = False
        self._liveStartupSeenRef = False
        self._liveStartupMissingSince = 0.0
        self._liveTuneFailedRef = ""
        self._liveTuneFailedAt = 0.0
        self._liveVideoProbeSize = None
        self._liveVideoProbeAt = 0.0
        self._liveAudioProbeAt = 0.0
        self._liveEngineMediaGraceUsed = False
        try:
            self._liveStartupTimer.stop()
            # Poll a new decoder quickly while its first frames arrive;
            # readiness still requires the current ref + stable dimensions.
            self._liveStartupTimer.start(220, True)
        except Exception:
            pass
        try:
            self.source["_tivimate_current_live_id"] = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            pass
        name = item.get("name") or item.get("title") or "IPTV"
        if self.source.get("type") == "stalker":
            try:
                stalker_log("PLAYER service_type=%s channel=%s url=%s" % (
                    self.service_type, name, (url or "")[:180]))
            except Exception:
                pass
        effective_service_type = compatible_service_type(self.service_type)
        try:
            if effective_service_type == 1 and ".m3u8" in str(url).lower():
                effective_service_type = 4097
        except Exception:
            pass
        ref = live_reference(self.source, item, effective_service_type, url, name)
        if self.source.get('type') == 'stalker':
            scheme, ext = _stalker_url_kind(url)
            _stalker_note('DECODER_OPEN', service=effective_service_type, scheme=scheme, format=ext)
        self.current_ref = ref
        self._liveEventSuppressUntil = monotonic() + 1.25
        self._liveInterruptedRef = ""
        try:
            # Do not restore the native Loading spinner immediately after
            # playService: disconnected IPTV services may buffer for seconds.
            # Restore when video decodes, playback fails, or this player closes.
            self._muteLiveSpinner()
            accepted = self.session.nav.playService(ref)
            # playService reports immediate rejection on some Enigma2 images.
            # Do not wait the full startup timeout for an already rejected ref.
            if accepted is not None and accepted != 0:
                if self.source.get('type') == 'stalker':
                    _stalker_note('DECODER_REJECT', service=effective_service_type,
                                  result=accepted if isinstance(accepted, (int, long)) else 'nonzero')
                self._handleImmediateLiveReject()
                return
        except Exception as exc:
            if self.source.get('type') == 'stalker':
                _stalker_note('DECODER_EXCEPTION', service=effective_service_type, error=type(exc).__name__)
            self._handleImmediateLiveReject()
            return

        # Only after Navigation accepted a replacement may Ultra-style cleanup
        # retire external processes associated with the old, different URL.
        # An engine retry uses the SAME URL, so never kill its pending decoder.
        if previous_external_url and previous_external_url != url:
            self._ultraDecoderGuard.retire(previous_external_url)
        self._ultraExternalUrl = url if effective_service_type in (5001, 5002, 8193, 8903) else ''
        if self._ultraExternalUrl:
            guard = getattr(self, '_ultraDecoderGuard', None)
            if guard is not None:
                guard.capture(self._ultraExternalUrl)

        if not same_engine_retry:
            self["channel"].setText(name)
            self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
            self._updateClock()
            try:
                self._clock_timer.start(10000, False)
            except Exception:
                pass
            # Cached Picons are queued once for the channel, not once per
            # decoder candidate. EPG stays deferred until video confirmation.
            self._loadPicon(item)
            self.showInfobar()

        if self.source.get("type") == "stalker" and self._auto_engine:
            # Previously both fallback timers used 5.5s. In a 12s shared
            # startup window, the last engine then received ~1s and could
            # never finish buffering. Give a compatible final candidate a
            # meaningful chance, without renewing the 12-second deadline.
            try:
                self._engine_timer.stop()
                if self._engine_candidates:
                    remaining_ms = int((self._liveStartupDeadline - time.time()) * 1000)
                    preferred_ms = 4600 if len(self._engine_attempted) == 1 else 3000
                    if remaining_ms > 1300:
                        self._engine_timer.start(min(preferred_ms, remaining_ms - 1200), True)
            except Exception:
                pass

    def _handleImmediateLiveReject(self):
        """Fast rejection: retry the next compatible engine on the SAME URL.

        Do not enter a new create_link request or extend the startup deadline.
        A rejection from a standalone engine or an exhausted engine list is
        reported immediately, rather than waiting for the full timer.
        """
        if (self.source.get('type') == 'stalker' and self._auto_engine and
                self._liveStartupPending and self._liveStartupIndex == self.index and
                self._engine_candidates and self.current_url and
                time.time() < self._liveStartupDeadline):
            self._verifyAutoEngine()
            return
        self._liveStartFailure(tr("Channel could not start."), stop_service=True)

    def _finishAsyncLiveResolve(self):
        if not self._liveResolvePending:
            return
        result = self._liveResolveResult
        # A resolved URL is useful even if the GUI polls slightly after its
        # deadline. Otherwise an already-completed link is discarded and the
        # user must retry the channel. The token/index checks below still
        # prevent stale links from playing after zapping.
        if result is None and time.time() >= self._liveResolveDeadline:
            self._cancelLiveResolve()
            self._liveStartFailure(tr("Server did not respond. Try another channel."))
            return
        self._liveResolveResult = None
        if result is None:
            try:
                # Fast response for a cached/healthy portal, fewer GUI timer
                # wakeups for a slow or dead portal after the first 800 ms.
                age = time.time() - float(getattr(self, '_liveResolveStartedAt', 0.0) or 0.0)
                self._liveResolveTimer.start(50 if age < 0.8 else 120, True)
            except Exception:
                pass
            return
        token, index, item, url = result
        if token != self._liveResolveToken or index != self.index:
            # A previous Stalker request finished after CH+/CH-. Continue
            # polling for the current request, not the obsolete result.
            try:
                self._liveResolveTimer.start(50, True)
            except Exception:
                pass
            return
        self._liveResolvePending = False
        self._liveResolveDeadline = 0.0
        self._liveResolveStartedAt = 0.0
        self._liveResolveHandle = None
        if not url:
            _stalker_note('LINK_FAILED', stage='resolved_empty')
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        self._playResolvedCurrent(item, url, index)


    def playCurrent(self):
        # CH+/- or a changed engine supersedes a transferred browser request.
        self._cancelPendingLiveLink()
        item = self._current()
        if not item:
            return
        # A repeated selection should not trigger a new portal request or
        # reinitialize the decoder. The service engine and provider are part
        # of the key so an explicit engine change still works normally.
        source = item.get('_favorite_source') if isinstance(item.get('_favorite_source'), dict) else self.source
        identity = (str((source or {}).get('portal') or (source or {}).get('url') or ''),
                    str((source or {}).get('mac') or ''),
                    str((source or {}).get('type') or ''),
                    str(item.get('stream_id') or item.get('ch_id') or item.get('id') or
                        item.get('url') or item.get('cmd') or item.get('name') or ''),
                    int(self.index), int(self.service_type))
        if identity == getattr(self, '_liveAttemptKey', None):
            if self._liveResolvePending or self._liveStartupPending:
                return
            if self._livePlaybackConfirmed and self.current_ref is not None:
                try:
                    current = self.session.nav.getCurrentlyPlayingServiceReference()
                    if current is not None and current.toString() == self.current_ref.toString():
                        return
                except Exception:
                    pass
        # A previous channel's five-second infobar timer must not expire
        # while the new selection is still resolving/starting.
        try:
            self._ib_timer.stop()
        except Exception:
            pass
        self._muteLiveSpinner()
        self._activateSourceForItem(item)
        identity = (str(self.source.get('portal') or self.source.get('url') or ''),
                    str(self.source.get('mac') or ''), str(self.source.get('type') or ''),
                    identity[3], int(self.index), int(self.service_type))
        self._prepareLiveSubtitleChannel(item)
        self._livePlaybackConfirmed = False
        # Late engine/watchdog timers from the previous channel must never
        # restart playback or send portal requests while zapping.
        try:
            self._engine_timer.stop()
            self._watchdog_timer.stop()
        except Exception:
            pass
        # Cancel any previous channel's playback timeout immediately. Keep
        # Stalker auto-engine retries on the same URL on a shared deadline.
        auto_retry = (self._auto_engine and self.source.get("type") == "stalker"
                      and bool(self._liveStartupPending)
                      and self._liveStartupIndex == self.index
                      and len(self._engine_attempted) > 1)
        if not auto_retry:
            self._cancelLiveStartup()
        self._cancelLiveResolve()
        # A failed channel may consume all automatic decoder alternatives.
        # Re-arm them on a NEW selection, not on same-URL engine retries.
        # Never overwrite an explicitly selected engine or a learned working
        # engine. Keep the current service type as first attempt.
        if (identity != getattr(self, '_liveAttemptKey', None) and
                self.source.get('type') == 'stalker' and self._auto_engine):
            try:
                available = [int(v) for v, _label in _available_service_types()]
                self._engine_candidates = [v for v in (4097, 5002, 5001)
                                           if v in available and v != int(self.service_type)]
                self._engine_attempted = [int(self.service_type)]
            except Exception:
                self._engine_candidates = []
                self._engine_attempted = [int(self.service_type)]
        self._liveAttemptKey = identity

        # Stalker create_link can take seconds. Resolve it in a worker so
        # Enigma2 never blocks and never shows its system Loading spinner.
        if self.source.get("type") == "stalker":
            self._liveResolveToken += 1
            token = self._liveResolveToken
            handle = TaskHandle(token, "stalker_live_link") if TaskHandle else None
            self._liveResolveHandle = handle
            index = int(self.index)
            selected = dict(item or {})
            self._liveResolveResult = None
            self._liveResolvePending = True
            _stalker_note('LINK_BEGIN', has_client=int(get_source_client is not None))
            self._liveResolveStartedAt = time.time()
            self._liveResolveDeadline = self._liveResolveStartedAt + LIVE_RESOLVE_TIMEOUT_SECONDS

            try:
                self["channel"].setText(selected.get("name") or selected.get("title") or "IPTV")
                self["counter"].setText("%d / %d" % (index + 1, len(self.channels)))
            except Exception:
                pass

            # Snapshot the provider before leaving the GUI thread; mixed
            # favorites can switch providers while an old link is resolving.
            client_source = dict(self.source or {})
            def worker():
                url = ""
                try:
                    if token != self._liveResolveToken or (handle is not None and handle.cancelled()):
                        return
                    # Ultra client sessions contain mutable auth/cookies. Reuse
                    # only within this executor worker, never across GUI/EPG or
                    # watchdog threads (same Ultra policy as list and Windows).
                    if get_source_client is None:
                        _stalker_note('LINK_CLIENT_MISSING')
                    else:
                        client = live_playback_client(client_source, get_source_client)
                        if client is not None and token == self._liveResolveToken:
                            url = client.stream_url(selected, "live", cancel_event=handle) or ""
                            scheme, ext = _stalker_url_kind(url)
                            _stalker_note('LINK_RESULT', status=('ok' if url else 'empty'), scheme=scheme, format=ext)
                        elif client is None:
                            _stalker_note('LINK_CLIENT_MISSING')
                except Exception as exc:
                    _stalker_note('LINK_EXCEPTION', error=type(exc).__name__)
                    # A failed transport can poison a worker-local session.
                    # Cancellation isn't a transport failure: retain its cache.
                    if not (handle is not None and handle.cancelled()):
                        invalidate_live_playback_client(client_source)
                    try:
                        stalker_log("PLAYER async resolve failed channel=%s error=%s" % (
                            selected.get("name") or selected.get("title") or "", exc))
                    except Exception:
                        pass
                if handle is not None and handle.cancelled():
                    return
                if token == self._liveResolveToken and self._liveResolvePending:
                    self._liveResolveResult = (token, index, selected, url)

            # The UltraStalker lazy executor keeps concurrent link resolves
            # bounded. Queued superseded channel jobs are cancelled, not run.
            try:
                if STALKER_LIVE_EXECUTOR is not None:
                    future = STALKER_LIVE_EXECUTOR.submit(
                        worker, _task_key=("live", id(self)), _replace_task_key=True
                    )
                    if handle is not None:
                        handle.future = future
                else:
                    thread = thread_factory(target=worker, name="TiviMateStalkerCreateLink")
                    thread.daemon = True
                    thread.start()
            except Exception as exc:
                self._cancelLiveResolve()
                self._liveStartFailure(tr("Channel link unavailable."))
                return
            try:
                self._liveResolveTimer.start(50, True)
            except Exception:
                pass
            return

        # Xtream/M3U links are local/cheap and keep the existing fast path.
        url = self._urlFor(item)
        if not url:
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        self._playResolvedCurrent(item, url, self.index)


    def _sendStalkerWatchdog(self):
        if self.source.get("type") != "stalker" or not self._livePlaybackConfirmed:
            return
        source = dict(self.source or {})
        # A portal can hang forever on keepalive. Do not spawn another
        # unbounded thread every 30 seconds for the same stuck request.
        if getattr(self, '_watchdogBusy', False):
            try: self._watchdog_timer.start(30000, True)
            except Exception: pass
            return
        self._watchdogBusy = True
        def worker():
            try:
                # Ultra sessions may only be used by their owning thread.
                client = live_playback_client(source, get_source_client)
                if client is not None:
                    client.watchdog()
            except Exception:
                invalidate_live_playback_client(source)
            finally:
                self._watchdogBusy = False
        try:
            from .stalker_live_pool import STALKER_WATCHDOG_EXECUTOR
            STALKER_WATCHDOG_EXECUTOR.submit(
                worker, _task_key=("player-watchdog", id(self)), _replace_task_key=True)
        except Exception:
            self._watchdogBusy = False
        try: self._watchdog_timer.start(30000, True)
        except Exception: pass

    def _videoIsReady(self):
        """Conservative startup proof, scoped to THIS Enigma2 service.

        Video dimensions alone can be metadata left by the preceding channel.
        Wait for this service's evStart and two stable samples.  Enigma2 does
        not expose a portable decoded-frame/audio confirmation API here; this
        check deliberately does not claim that sound was verified.
        """
        try:
            if not self._liveStartupPending or not self._liveServiceStarted:
                return False
            playing = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            if not playing or not expected or playing.toString() != expected.toString():
                self._liveVideoProbeSize = None
                self._liveVideoProbeAt = 0.0
                return False
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return False
            width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
            height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
            if width <= 0 or height <= 0:
                self._liveVideoProbeSize = None
                self._liveVideoProbeAt = 0.0
                return False
            size = (width, height)
            now = time.time()
            if size != self._liveVideoProbeSize:
                self._liveVideoProbeSize = size
                self._liveVideoProbeAt = now
                return False
            return bool(now - self._liveVideoProbeAt >= 0.75)
        except Exception:
            return False

    def _audioOnlyIsReady(self):
        """Accept declared audio-only Live streams without a fictitious video.

        Enigma can provide an audio-only channel with a permanent 0x0 video
        geometry. Previously all such channels waited until startup timeout
        and were incorrectly stopped. Do NOT infer audio-only from missing
        dimensions alone: that also happens while a video stream buffers.
        Require an explicitly absent video PID and valid audio PID/track,
        with two stable readings from the expected current service.
        """
        try:
            if not self._liveStartupPending or not self._liveServiceStarted:
                self._liveAudioProbeAt = 0.0
                return False
            nav = self.session.nav
            playing = nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            if not playing or not expected or playing.toString() != expected.toString():
                self._liveAudioProbeAt = 0.0
                return False
            if time.time() - self._liveStartupAt < 3.0:
                return False
            service = nav.getCurrentService()
            info = service and service.info()
            if not info:
                return False
            # Missing PID support is UNKNOWN, not proof of audio-only.
            video_pid_type = getattr(iServiceInformation, "sVideoPID", None)
            audio_pid_type = getattr(iServiceInformation, "sAudioPID", None)
            if video_pid_type is None or audio_pid_type is None:
                return False
            if int(info.getInfo(video_pid_type)) != -1 or int(info.getInfo(audio_pid_type)) < 0:
                self._liveAudioProbeAt = 0.0
                return False
            tracks = service.audioTracks()
            if not tracks or int(tracks.getNumberOfTracks()) <= 0:
                self._liveAudioProbeAt = 0.0
                return False
            if not self._liveAudioProbeAt:
                self._liveAudioProbeAt = time.time()
                return False
            return (time.time() - self._liveAudioProbeAt >= 0.75)
        except Exception:
            self._liveAudioProbeAt = 0.0
            return False

    def _verifyAutoEngine(self):
        if self.source.get("type") != "stalker" or not self._auto_engine:
            return
        # Never restart a completed, cancelled or expired channel. In
        # particular a late engine timer must not keep a broken stream alive.
        if not self._liveStartupPending or self._liveStartupIndex != self.index:
            return
        if time.time() >= self._liveStartupDeadline:
            self._liveStartFailure(tr("Channel unavailable - try another channel."), stop_service=True)
            return
        if self._videoIsReady() or self._audioOnlyIsReady():
            # Centralize confirmation and engine persistence in one place.
            self._checkLiveStartup()
            return
        # The first engine may already be furnishing new-service dimensions
        # while the two-sample decoder proof settles. Do not zap it away
        # prematurely. This grace can occur only once per engine attempt.
        if not getattr(self, '_liveEngineMediaGraceUsed', False):
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                service = self.session.nav.getCurrentService()
                info = service and service.info()
                expected = getattr(self, 'current_ref', None)
                if (active is not None and expected is not None and
                        active.toString() == expected.toString() and
                        self._liveServiceStarted and info is not None and
                        int(info.getInfo(iServiceInformation.sVideoWidth) or 0) > 0 and
                        int(info.getInfo(iServiceInformation.sVideoHeight) or 0) > 0 and
                        self._liveStartupDeadline - time.time() > 1.8):
                    self._liveEngineMediaGraceUsed = True
                    self._engine_timer.start(800, True)
                    return
            except Exception:
                pass
        if not self._engine_candidates:
            # Exhaustion applies to this channel only. Do not globally disable
            # auto-engine after one bad stream: a different channel might
            # work on another engine. A proven engine is persisted elsewhere.
            stalker_log("AUTO ENGINE exhausted attempted=%s" % self._engine_attempted)
            return
        if not self.current_url:
            return
        next_engine = int(self._engine_candidates.pop(0))
        self.service_type = next_engine
        self._engine_attempted.append(next_engine)
        stalker_log("AUTO ENGINE try service_type=%s" % next_engine)
        self["hint"].setText("Auto engine: %s" % next_engine)
        # The URL was already resolved for this exact channel. Retrying the
        # playback engine must not repeat slow Stalker create_link requests.
        self._playResolvedCurrent(self._current(), self.current_url, self.index)

    def cycleServiceType(self):
        values = [value for value, _label in _available_service_types()]
        try:
            pos = values.index(int(self.service_type))
        except Exception:
            pos = 0
        self.service_type = values[(pos + 1) % len(values)]
        _save_service_type(self.service_type)
        if self.source.get("type") == "stalker":
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE TiviMate Subtitles" % self.service_type)
        self.playCurrent()

    def _catchupDecodeText(self, value):
        value = value or ""
        try:
            import base64
            raw = str(value).strip()
            if raw and re.match(r"^[A-Za-z0-9+/=]+$", raw) and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw)
                try:
                    decoded = decoded.decode("utf-8", "ignore")
                except Exception:
                    pass
                if decoded:
                    return str(decoded)
        except Exception:
            pass
        return str(value or "")

    def _catchupTimestamp(self, row, begin=True):
        row = row or {}
        keys = ("start_timestamp", "begin_timestamp", "start", "begin", "date_start") if begin else (
            "stop_timestamp", "end_timestamp", "stop", "end", "date_end"
        )
        for key in keys:
            raw = row.get(key)
            if raw in (None, ""):
                continue
            try:
                value = int(float(str(raw)))
                if value > 100000000000:
                    value = int(value / 1000)
                if value > 1000000000:
                    return value
            except Exception:
                pass
            text = str(raw or "").strip().replace("T", " ")
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d:%H-%M"):
                try:
                    return int(time.mktime(time.strptime(text[:19], fmt)))
                except Exception:
                    pass
        return 0

    def openCatchupFromInfobar(self):
        source_type = self.source.get("type")
        if source_type == "stalker":
            self._openStalkerCatchupFromInfobar()
            return
        if source_type != "xtream":
            self.openPlayerEngineMenu()
            return
        item = self._current() or {}
        if not (item.get("tv_archive") or item.get("archive") or item.get("has_archive") or item.get("tv_archive_duration")):
            self.session.open(MessageBox, tr("This channel does not advertise catch-up support."), MessageBox.TYPE_INFO, timeout=4)
            return
        if self._catchup_result is not None:
            return
        self._catchup_item = dict(item)
        stream_id = str(item.get("stream_id") or item.get("id") or "")
        epg_id = str(item.get("epg_channel_id") or item.get("epg_id") or "")
        source = dict(self.source or {})
        self["hint"].setText("")

        def worker():
            rows, error = [], ""
            try:
                rows = XtreamClient(source).short_epg(stream_id, limit=20, epg_channel_id=epg_id) or []
            except Exception as exc:
                error = str(exc)
            self._catchup_result = (rows, error)

        t = thread_factory(target=worker, name="TiviMateInfobarCatchup")
        t.daemon = True
        t.start()
        try:
            self._catchup_timer.start(120, False)
        except Exception:
            pass

    def _openStalkerCatchupFromInfobar(self):
        item = self._current() or {}
        if not item:
            return
        self._catchup_item = dict(item)
        self._catchup_result = None
        source = dict(self.source or {})
        channel_id = str(
            item.get("ch_id") or item.get("stream_id") or item.get("id") or
            item.get("cmd") or item.get("url") or ""
        ).strip()
        if not channel_id:
            self.session.open(MessageBox, tr("Catch-up is not available for this channel."), MessageBox.TYPE_INFO, timeout=4)
            return

        self["hint"].setText("")

        def worker():
            rows, error = [], ""
            try:
                client = StalkerClient(source)
                rows = client.short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchup_result = ("stalker", rows, error)

        t = thread_factory(target=worker, name="TiviMateStalkerInfobarCatchup")
        t.daemon = True
        t.start()
        try:
            self._catchup_timer.start(120, False)
        except Exception:
            pass

    def _finishStalkerCatchupFromInfobar(self, rows, error):
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._catchupTimestamp(row, True)
            end = self._catchupTimestamp(row, False)
            title = self._catchupDecodeText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            if begin and begin < now and title and (archive not in (0, "0", False) or not end or end <= now):
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))

        self["hint"].setText("")
        if not choices:
            msg = tr("No catch-up programmes are available for this channel.")
            if error:
                msg += "\n" + error
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
            return

        self.session.openWithCallback(
            self._playStalkerCatchupFromInfobar,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )

    def _playStalkerCatchupFromInfobar(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = self._catchup_item or self._current() or {}
        try:
            client = StalkerClient(dict(self.source or {}))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))

            title = self._catchupDecodeText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up"
            service_type = int(self.service_type or 4097)
            ref = live_reference(self.source, item, service_type, url, title)

            try:
                self.session.nav.stopService()
            except Exception:
                pass
            try:
                self.session.nav.playService(ref, forceRestart=True)
            except TypeError:
                self.session.nav.playService(ref)

            self.current_ref = ref
            self["hint"].setText(tr("Catch-up / Archive"))
            self.showInfobar()
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )

    def _finishXtreamCatchupFromInfobar(self):
        result = self._catchup_result
        if result is None:
            try:
                self._catchup_timer.start(120, False)
            except Exception:
                pass
            return
        self._catchup_result = None
        try:
            self._catchup_timer.stop()
        except Exception:
            pass

        # Stalker uses the same eStalker-style flow already used by the Live menu:
        # short_epg -> create_catchup_link.
        if isinstance(result, (tuple, list)) and len(result) == 3 and result[0] == "stalker":
            self._finishStalkerCatchupFromInfobar(result[1], result[2])
            return

        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._catchupTimestamp(row, True)
            end = self._catchupTimestamp(row, False)
            title = self._catchupDecodeText(row.get("title") or row.get("name") or row.get("programme"))
            if begin and begin < now and title:
                if not end or end <= begin:
                    end = begin + 3600
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))
        self["hint"].setText("")
        if not choices:
            msg = tr("No catch-up programmes are available for this channel.")
            if error:
                msg += "\n" + error
            self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=6)
            return
        self.session.openWithCallback(
            self._playXtreamCatchupFromInfobar,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )

    def _playXtreamCatchupFromInfobar(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = self._catchup_item or self._current() or {}
        try:
            begin = int(event.get("_begin") or self._catchupTimestamp(event, True) or 0)
            end = int(event.get("_end") or self._catchupTimestamp(event, False) or 0)
            if not begin:
                raise RuntimeError(tr("Programme start time is missing"))
            if not end or end <= begin:
                end = begin + 3600
            duration = max(1, int((end - begin + 59) / 60))
            base = str(self.source.get("url") or "").rstrip("/")
            user = str(self.source.get("username") or "")
            password = str(self.source.get("password") or "")
            sid = str(item.get("stream_id") or item.get("id") or "")
            if not (base and user and password and sid):
                raise RuntimeError(tr("Xtream archive credentials are incomplete"))
            start = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))
            url = "%s/timeshift/%s/%s/%d/%s/%s.ts" % (base, user, password, duration, start, sid)
            ref = live_reference(self.source, item, int(self.service_type), url,
                                 self._catchupDecodeText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up")
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            try:
                self.session.nav.playService(ref, forceRestart=True)
            except TypeError:
                self.session.nav.playService(ref)
            self.current_ref = ref
            self["hint"].setText(tr("Catch-up / Archive"))
            self.showInfobar()
        except Exception as exc:
            self.session.open(MessageBox, "%s: %s" % (tr("Unable to play catch-up"), exc), MessageBox.TYPE_ERROR)

    def openPlayerEngineMenu(self):
        choices = []
        for value, label in _available_service_types():
            prefix = "✓ " if int(value) == int(self.service_type) else ""
            choices.append((prefix + label, value))
        # Keep archive access after reserving INFO for showing the Infobar.
        if (self.source or {}).get("type") in ("xtream", "stalker"):
            choices.append(("Catch-up / Archive", "__catchup__"))
        try:
            from .epg_reminders import has as _reminder_has, upcoming as _reminders
            event = getattr(self, "_epgUpcomingEvent", None)
            if event and event[0] > time.time():
                channel = (event[3] or {}).get("name") or (event[3] or {}).get("title") or ""
                clock = time.strftime("%H:%M", time.localtime(event[0]))
                if _reminder_has(event[0], channel, event[2]):
                    choices.append((gui_text(u"Reminder set: %s %s" % (clock, _reminder_u(event[2]))), "__reminders__"))
                else:
                    choices.append((gui_text(u"Remind me: %s %s" % (clock, _reminder_u(event[2]))), "__remind__"))
            if _reminders():
                choices.append(("My reminders (%d)" % len(_reminders()), "__reminders__"))
        except Exception:
            pass
        self.session.openWithCallback(
            self._playerEngineSelected,
            ChoiceBox,
            title="Live Options / Player Engine",
            list=choices
        )

    def _addEpgReminder(self):
        event = getattr(self, "_epgUpcomingEvent", None)
        if not event:
            return
        begin, _stop, title, item = event
        item = dict(item or {})
        channel = item.get("name") or item.get("title") or ""
        try:
            from .epg_reminders import add
            ok = add(self.source, item, begin, title, channel, int(self.service_type or 4097))
        except Exception:
            ok = False
        clock = time.strftime("%H:%M", time.localtime(begin))
        message = gui_text(u"Reminder saved for %s\n%s" % (clock, _reminder_u(title))) if ok else "Could not save the reminder."
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=5)

    def _openEpgReminders(self):
        try:
            from .epg_reminders import upcoming, label
            rows = upcoming()
        except Exception:
            rows = []
        if not rows:
            self.session.open(MessageBox, "No reminders.", MessageBox.TYPE_INFO, timeout=4)
            return
        choices = [(label(row) + "   (OK = delete)", row.get("id")) for row in rows]
        self.session.openWithCallback(self._epgReminderPicked, ChoiceBox,
                                      title="My reminders", list=choices)

    def _epgReminderPicked(self, selected):
        if not selected:
            return
        try:
            from .epg_reminders import remove
            remove(selected[1])
        except Exception:
            pass
        self._openEpgReminders()

    def _playerEngineSelected(self, selected):
        if not selected:
            return
        if selected[1] == "__catchup__":
            return self.openCatchupFromInfobar()
        if selected[1] == "__remind__":
            return self._addEpgReminder()
        if selected[1] == "__reminders__":
            return self._openEpgReminders()
        value = int(selected[1])
        if value == int(self.service_type):
            return
        self.service_type = value
        _save_service_type(value)
        if self.source.get("type") == "stalker":
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE TiviMate Subtitles" % self.service_type)
        self.playCurrent()


    def _recordingBackend(self):
        return stalker_live_recorder

    def toggleLiveRecording(self):
        if self.source.get("type") != "stalker":
            self.session.open(MessageBox, "Live recording is available for Stalker portals only.", MessageBox.TYPE_INFO, timeout=5)
            return
        recorder = self._recordingBackend()
        if recorder.is_recording():
            ok, message = recorder.stop()
            if ok:
                self.session.open(MessageBox, "Live recording stopped.\n%s" % message, MessageBox.TYPE_INFO, timeout=5)
            else:
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=5)
            self._restorePlayerEngineAfterRecording()
            return

        item = self._current()
        url = self.current_url or self._urlFor(item)
        if not url:
            self.session.open(MessageBox, "No playable Live URL is available.", MessageBox.TYPE_ERROR, timeout=5)
            return

        self._record_pending_item = dict(item or {})
        self._record_pending_url = url
        self._record_previous_service_type = int(self.service_type)

        # Native Enigma2 recording produced black files with ServiceApp engines
        # (5001/5002) on several images.  Temporarily zap the same channel
        # with 4097, wait for the decoder to lock, then start RecordService.
        if int(self.service_type) != 4097:
            self.service_type = 4097
            self["hint"].setText("Recording engine: 4097")
            self.playCurrent()
            try:
                self._recordStartTimer.stop()
            except Exception:
                self._recordStartTimer = eTimer()
                try:
                    self._recordStartTimer_conn = self._recordStartTimer.timeout.connect(self._startLiveRecordingNow)
                except Exception:
                    try:
                        self._recordStartTimer.callback.append(self._startLiveRecordingNow)
                    except Exception:
                        self._recordStartTimer.timeout.get().append(self._startLiveRecordingNow)
            self.session.open(MessageBox, "Switching temporarily to 4097 for recording...", MessageBox.TYPE_INFO, timeout=3)
            self._recordStartTimer.start(2200, True)
            return

        self._startLiveRecordingNow()

    def _startLiveRecordingNow(self):
        item = getattr(self, "_record_pending_item", None) or self._current() or {}
        url = getattr(self, "_record_pending_url", "") or self.current_url or self._urlFor(item)
        channel = item.get("name") or item.get("title") or "IPTV Live"

        # Stalker links are session-bound and often reject a reused viewing
        # URL. Resolve a new create_link exclusively for this recording.
        if self.source.get("type") == "stalker":
            try:
                client = get_source_client(self.source) if get_source_client else None
                fresh_url = client.stream_url(item, "live") if client is not None else ""
                if not fresh_url:
                    raise RuntimeError("portal returned an empty recording link")
                url = fresh_url
                self._record_pending_url = fresh_url
                stalker_log("RECORD fresh link channel=%s url=%s" % (channel, fresh_url[:180]))
            except Exception as exc:
                self._restorePlayerEngineAfterRecording()
                self.session.open(MessageBox, "Stalker recording link failed.\n%s" % exc, MessageBox.TYPE_ERROR, timeout=8)
                return

        if not url:
            self._restorePlayerEngineAfterRecording()
            self.session.open(MessageBox, "No playable Live URL is available.", MessageBox.TYPE_ERROR, timeout=5)
            return
        try:
            if self.source.get("type") == "stalker":
                # A dedicated 4097 reference is used only by the Stalker
                # recorder. The viewing service remains untouched.
                service_ref = live_reference(self.source, item, 4097, url, channel)
            else:
                service_ref = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            service_ref = None
        recorder = self._recordingBackend()
        ok, message = recorder.start(url, channel, session=self.session, service_ref=service_ref)
        if not ok:
            self._restorePlayerEngineAfterRecording()
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=7)
            return
        self.session.open(MessageBox, "Starting Live recording...", MessageBox.TYPE_INFO, timeout=3)
        try:
            self._recordVerifyTimer.stop()
        except Exception:
            self._recordVerifyTimer = eTimer()
            try:
                self._recordVerifyTimer_conn = self._recordVerifyTimer.timeout.connect(self._verifyLiveRecording)
            except Exception:
                try:
                    self._recordVerifyTimer.callback.append(self._verifyLiveRecording)
                except Exception:
                    self._recordVerifyTimer.timeout.get().append(self._verifyLiveRecording)
        self._recordVerifyTimer.start(3500, True)

    def _restorePlayerEngineAfterRecording(self):
        previous = getattr(self, "_record_previous_service_type", None)
        self._record_previous_service_type = None
        self._record_pending_item = None
        self._record_pending_url = ""
        if previous is None or int(previous) == int(self.service_type):
            return
        self.service_type = int(previous)
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE TiviMate Subtitles" % self.service_type)
        self.playCurrent()

    def _verifyLiveRecording(self):
        recorder = self._recordingBackend()
        ok, message = recorder.verify()
        if ok:
            self.session.open(MessageBox, "Live recording started.\n%s" % message, MessageBox.TYPE_INFO, timeout=5)
            return
        if recorder.is_recording():
            try:
                self._recordVerifyTimer.start(2500, True)
            except Exception:
                pass
            return
        self._restorePlayerEngineAfterRecording()
        self.session.open(MessageBox, "Recording failed.\n%s" % message, MessageBox.TYPE_ERROR, timeout=8)

    def _liveSubtitleSessionStore(self):
        try:
            store = self.source.get("_tivimate_live_subtitle_session")
            if not isinstance(store, dict):
                store = {}
                self.source["_tivimate_live_subtitle_session"] = store
            return store
        except Exception:
            return {}

    def _savePreservedLiveSubtitle(self):
        """Persist only the active Live subtitle file/delay across a temporary list round-trip."""
        key = self._liveSubtitleChannelKey(self._current())
        path = str(getattr(self, "_external_subtitle_path", "") or "")
        if not key or not path or not os.path.isfile(path):
            return
        try:
            delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
        except Exception:
            delay_ms = 0
        store = self._liveSubtitleSessionStore()
        if isinstance(store, dict):
            store.clear()
            context = dict(getattr(self, "_live_epg_context", {}) or {})
            store.update({
                "channel_key": key,
                "path": path,
                "delay_ms": delay_ms,
                "program_begin": int(context.get("begin") or 0),
                "program_duration": int(context.get("duration") or 0),
            })

    def _discardPreservedLiveSubtitle(self):
        try:
            self.source.pop("_tivimate_live_subtitle_session", None)
        except Exception:
            pass

    def _restorePreservedLiveSubtitle(self, item=None):
        """Reattach the same downloaded subtitle when reopening the exact same Live channel."""
        store = self._liveSubtitleSessionStore()
        if not isinstance(store, dict) or not store:
            return False
        key = self._liveSubtitleChannelKey(item)
        if not key or key != str(store.get("channel_key") or ""):
            self._discardPreservedLiveSubtitle()
            return False
        path = str(store.get("path") or "")
        if not path or not os.path.isfile(path):
            self._discardPreservedLiveSubtitle()
            return False
        try:
            from .subtitle_picker_bridge import _controller
            controller = _controller(self)
            # Restore the Live programme clock before parsing/resuming the
            # subtitle. Without it, a newly opened List/Grid player has no
            # EPG context and correctly starts at cue zero by mistake.
            try:
                begin = int(store.get("program_begin") or 0)
                duration = int(store.get("program_duration") or 0)
                self._live_epg_context = {
                    "title": "",
                    "begin": begin,
                    "duration": duration,
                }
                engine = getattr(controller, "_TiviMateSubtitleSupport__subsEngine", None)
                if engine is not None:
                    engine._tivimate_live_program_begin = begin
                    engine._tivimate_live_program_duration = max(0, duration)
            except Exception:
                pass
            if not controller.loadSubs(path, newService=False):
                return False
            controller.resumeSubs()
            self._external_subs = controller
            self._subssupport = controller
            self._tivimate_subtitles = controller
            self._tivimate_subtitle_controller = controller
            self._external_subtitle_path = path
            self._external_subtitle_owner = "subssupport"
            try:
                self._subtitle_session_delay_ms = int(store.get("delay_ms", 0) or 0)
            except Exception:
                self._subtitle_session_delay_ms = 0
            try:
                controller._tivimateDelayChangedCB = getattr(self, "_tivimateSubtitleDelayChanged", None)
            except Exception:
                pass
            try:
                setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                if callable(setter) and self._subtitle_session_delay_ms:
                    setter(self._subtitle_session_delay_ms)
            except Exception:
                pass
            # resumeSubs() already starts from the current service clock.
            # Calling playAfterSeek() here performs a second seek-style sync
            # while the new player has no complete Live EPG context yet and
            # can incorrectly select the first subtitle cue.
            self._live_subtitle_channel_key = key
            return True
        except Exception as exc:
            print("[TiviMateE2] live subtitle restore failed: %s" % exc)
            return False

    def _clearSubsSupport(self):
        """Release every Live subtitle controller reference as one lifecycle."""
        controllers = (
            getattr(self, "_external_subs", None),
            getattr(self, "_subssupport", None),
            getattr(self, "_tivimate_subtitles", None),
            getattr(self, "_tivimate_subtitle_controller", None),
        )
        self._external_subs = None
        self._subssupport = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._external_subtitle_owner = ""
        self._subtitle_session_delay_ms = 0
        self._tivimate_subtitle_auto_search_key = None

        seen = set()
        for support in controllers:
            if support is None or id(support) in seen:
                continue
            seen.add(id(support))
            # The engine may emit one final delay event while shutting down;
            # do not call back into a closing Live player.
            try:
                support._tivimateDelayChangedCB = None
            except Exception:
                pass
            try:
                support.hideSubsDialog()
            except Exception:
                pass
            try:
                support.exitSubs()
            except Exception:
                pass

    def _liveSubtitleChannelKey(self, item=None):
        item = item or self._current() or {}
        return str(
            item.get("stream_id") or item.get("ch_id") or item.get("id") or
            item.get("url") or item.get("cmd") or item.get("name") or item.get("title") or ""
        ).strip()

    def _prepareLiveSubtitleChannel(self, item=None):
        """Reset subtitle state only when the actual Live channel changes."""
        key = self._liveSubtitleChannelKey(item)
        if key and key != getattr(self, "_live_subtitle_channel_key", ""):
            # Opening the channel list and selecting the same channel creates
            # a fresh player object. Preserve the saved subtitle for this key;
            # it is reattached after the new service emits evStart.
            preserved = self._liveSubtitleSessionStore()
            keep_preserved = (isinstance(preserved, dict) and
                              str(preserved.get("channel_key") or "") == key)
            self._clearSubsSupport()
            if not keep_preserved:
                self._discardPreservedLiveSubtitle()
            self._live_epg_context = {}
            self._live_subtitle_channel_key = key

    def _refreshLiveEpgDetails(self):
        """Paint existing Live EPG description and already-resolved TMDb metadata.

        Never fetch anything here.  This method runs only on the GUI thread.
        """
        pieces = []
        year = text_type(getattr(self, '_infobarPosterYear', '') or u'').strip()
        if len(year) == 4 and year.isdigit():
            pieces.append(year)
        try:
            rating = float(getattr(self, '_infobarPosterRating', 0.0) or 0.0)
            if 0.0 < rating <= 10.0:
                pieces.append('%.1f/10' % rating)
        except (ValueError, TypeError):
            pass
        description = text_type(getattr(self, '_liveEpgPlot', u'') or u'').strip()
        if description:
            # Two unobtrusive lines; the UI label clips any longer synopsis.
            pieces.append(description[:230])
        try:
            self['epgDetails'].setText(u'  |  '.join(text_type(v) for v in pieces))
        except Exception:
            pass

    def _setLiveEpgDescription(self, description):
        try:
            value = text_type(description or u'')
            self._liveEpgPlot = u' '.join(value.replace(u'\r', u' ').replace(u'\n', u' ').split())
        except Exception:
            self._liveEpgPlot = u''
        self._refreshLiveEpgDetails()

    def _setLiveEpgContext(self, title="", begin=0, duration=0):
        try:
            begin = int(begin or 0)
        except Exception:
            begin = 0
        try:
            duration = max(0, int(duration or 0))
        except Exception:
            duration = 0
        self._live_epg_context = {
            "title": text_type(title or u"").strip(),
            "begin": begin,
            "duration": duration,
        }

    def _subsSupportEpgContext(self):
        """Return the current Live programme title and elapsed seconds."""
        now = int(time.time())
        context = dict(getattr(self, "_live_epg_context", {}) or {})
        title = text_type(context.get("title") or u"").strip()
        begin = int(context.get("begin") or 0)
        duration = max(0, int(context.get("duration") or 0))
        if title:
            elapsed = max(0, now - begin) if begin else 0
            if duration > 0:
                elapsed = min(elapsed, duration)
            return title, elapsed

        # Xtream and Stalker use provider-direct EPG. Never fall back to
        # EPGImport/local XML for those Live source types.
        item = self._current()
        if str(self.source.get("type") or "") not in ("xtream", "stalker"):
            try:
                current, _upcoming = lookup_channel_epg(self.source, item, now)
                if current and len(current) > 2:
                    begin = int(current[0] or 0)
                    duration = max(0, int(current[1] or 0))
                    title = text_type(current[2] or u"").strip()
                    if title:
                        self._setLiveEpgContext(title, begin, duration)
                        elapsed = max(0, now - begin) if begin else 0
                        if duration > 0:
                            elapsed = min(elapsed, duration)
                        return title, elapsed
            except Exception:
                pass

        # Last-resort UI title.  Strip both a time range and a single leading
        # time used by Stalker EPG, but do not invent programme timing.
        try:
            import re
            title = text_type(self["epgNow"].getText() or u"").strip()
            title = re.sub(r"^\s*\d{1,2}[:.]\d{2}\s*[\-–—]\s*\d{1,2}[:.]\d{2}\s*", "", title).strip()
            title = re.sub(r"^\s*\d{1,2}[:.]\d{2}\s+", "", title).strip()
            if title and title.lower() not in ("no epg data", ""):
                return title, 0
        except Exception:
            pass
        return "", 0

    def _buildLiveSubtitleContext(self):
        item = self._current() or {}
        program_title, elapsed = self._subsSupportEpgContext()
        epg = dict(getattr(self, "_live_epg_context", {}) or {})
        channel_name = text_type(item.get("name") or item.get("title") or self["channel"].getText() or u"").strip()
        channel_id = self._liveSubtitleChannelKey(item)
        return {
            "media_type": "live",
            "source_type": str(self.source.get("type") or ""),
            "channel_name": channel_name,
            "channel_id": channel_id,
            "program_title": text_type(program_title or u"").strip(),
            "begin": int(epg.get("begin") or 0),
            "duration": int(epg.get("duration") or 0),
            "elapsed": int(elapsed or 0),
        }

    def _subsSupportSearchTitle(self):
        context = self._buildLiveSubtitleContext()
        return context.get("program_title") or context.get("channel_name") or ""

    def _showNotification(self, text, kind=None, timeout=4):
        """Show a short Enigma2 message from Live without depending on VOD HUD widgets."""
        try:
            _safe_open_screen(self.session, None, 
                MessageBox,
                str(text),
                MessageBox.TYPE_INFO if kind is None else kind,
                timeout=max(1, int(timeout or 4)),
            )
        except Exception as exc:
            print("[TiviMateE2] live notification failed: %s" % exc)

    def openSubsSupport(self):
        context = self._buildLiveSubtitleContext()
        title = context.get("program_title") or context.get("channel_name") or ""
        try:
            from .subtitle_picker_bridge import open_tivimate_subtitle_search
            if open_tivimate_subtitle_search(self, title, context=context):
                return
        except Exception as exc:
            print("[TiviMateE2] live subtitle search open failed: %s" % exc)
        stage = str(getattr(self, "_tivimate_subtitle_search_error", "") or "initialization")
        self._showNotification("TiviMate Subtitles could not open (%s)." % stage,
                               MessageBox.TYPE_ERROR, timeout=6)

    def _subtitlePickerSource(self):
        """Use the active downloaded file or active SubsSupport engine for RED."""
        from .subtitle_cue_source import get_active_subtitle_rows
        return get_active_subtitle_rows(self)

    def openSubtitleEditor(self):
        """RED: same large subtitle-line picker used by VOD, aligned to current EPG elapsed time."""
        cues, subtitle_list = self._subtitlePickerSource()
        if not subtitle_list:
            self._showNotification("No readable subtitle is loaded", MessageBox.TYPE_INFO, 3)
            return
        self._subtitle_picker_cues = cues
        current_index = 0
        try:
            _title, elapsed_sec = self._subsSupportEpgContext()
            playback_ms = max(0, int(float(elapsed_sec or 0) * 1000.0))
            delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
            subtitle_time_ms = max(0, playback_ms - delay_ms)
            current_index = len(cues) - 1
            for cue_index, cue in enumerate(cues):
                cue_start_ms = int(cue[0])
                if cue_start_ms >= subtitle_time_ms:
                    current_index = cue_index
                    if cue_index > 0:
                        prev_ms = int(cues[cue_index - 1][0])
                        if abs(subtitle_time_ms - prev_ms) <= abs(cue_start_ms - subtitle_time_ms):
                            current_index = cue_index - 1
                    break
        except Exception:
            current_index = 0
        current_index = max(0, min(current_index, len(subtitle_list) - 1))
        try:
            from Plugins.Extensions.TiviMateE2Py27.subtitle_picker_original import SubtitlePicker
            _safe_open_screen(self.session, self._subtitlePickerSelected, SubtitlePicker, subtitle_list, current_index)
        except Exception as exc:
            print("[TiviMateE2] live subtitle picker open failed: %s" % exc)
            return

    def _subtitlePickerSelected(self, selected=None):
        if selected is None:
            return
        fine_ms = 0
        if isinstance(selected, (tuple, list)) and len(selected) >= 2:
            try:
                fine_ms = int(selected[1] or 0)
            except Exception:
                fine_ms = 0
            selected = selected[0]
        try:
            index = int(selected)
        except Exception:
            return
        cues = list(getattr(self, "_subtitle_picker_cues", None) or [])
        if index < 0 or index >= len(cues):
            return
        try:
            _title, elapsed_sec = self._subsSupportEpgContext()
            playback_ms = max(0, int(float(elapsed_sec or 0) * 1000.0))
            cue_start_ms = int(cues[index][0])
            delay_ms = max(-120000, min(120000, playback_ms - cue_start_ms + fine_ms))
            controller = (getattr(self, "_external_subs", None) or getattr(self, "_tivimate_subtitles", None) or getattr(self, "_subssupport", None) or getattr(self, "_tivimate_subtitle_controller", None))
            if controller is None:
                return
            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if callable(setter):
                setter(delay_ms)
            self._subtitle_session_delay_ms = delay_ms
            self._showNotification("Subtitle synchronized: %+.1f sec" % (delay_ms / 1000.0), MessageBox.TYPE_INFO, 2)
        except Exception:
            pass

    def _stepSubtitleDialogue(self, direction):
        """PREVIOUS/NEXT remote buttons select adjacent subtitle *cues*.

        Keep the stream running. Align the chosen cue to the current Live
        program elapsed time; never use the former 200-ms fine-delay behavior.
        """
        try:
            cues, _rows = self._subtitlePickerSource()
            if not cues:
                return
            controller = (getattr(self, "_external_subs", None)
                          or getattr(self, "_tivimate_subtitles", None)
                          or getattr(self, "_subssupport", None)
                          or getattr(self, "_tivimate_subtitle_controller", None))
            if controller is None:
                return
            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if not callable(setter):
                return
            _title, elapsed = self._subsSupportEpgContext()
            playback_ms = max(0, int(float(elapsed or 0) * 1000))
            getter = getattr(controller, "getSubsDelay", None)
            current_delay = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
            if callable(getter):
                try:
                    active = getter()
                    if active is not None:
                        current_delay = int(float(active))
                except Exception:
                    pass
            subtitle_ms = playback_ms - current_delay
            previous_index = getattr(self, "_subtitle_cue_step_index", None)
            previous_playback = getattr(self, "_subtitle_cue_step_playback_ms", None)
            # Keep repeated button presses relative to the last selected cue.
            # Recalculate after a major EPG time jump or a fresh subtitle file.
            signature = (getattr(self, "_external_subtitle_path", None), len(cues), cues[0][0], cues[-1][0])
            if (previous_index is not None and
                    getattr(self, "_subtitle_cue_step_signature", None) == signature and
                    previous_playback is not None and
                    abs(playback_ms - previous_playback) < 10000):
                current_index = int(previous_index)
            else:
                current_index = 0
                for idx, cue in enumerate(cues):
                    if int(cue[0]) <= subtitle_ms:
                        current_index = idx
                    else:
                        break
            target_index = max(0, min(len(cues) - 1, current_index + (1 if direction > 0 else -1)))
            if target_index == current_index:
                return
            target_ms = int(cues[target_index][0])
            # Avoid silently jumping to a different cue if the offset cannot
            # be represented by the subtitle engine's supported delay range.
            delay_ms = playback_ms - target_ms
            if not -120000 <= delay_ms <= 120000:
                return
            setter(delay_ms)
            self._subtitle_session_delay_ms = delay_ms
            self._subtitle_cue_step_index = target_index
            self._subtitle_cue_step_playback_ms = playback_ms
            self._subtitle_cue_step_signature = signature
        except Exception as exc:
            print("[TiviMateE2] Live subtitle cue step failed: %s" % exc)

    def subtitleFineMinus(self):
        self._stepSubtitleDialogue(-1)

    def subtitleFinePlus(self):
        self._stepSubtitleDialogue(1)

    def openSubtitleSelection(self):
        """Open embedded/server subtitles on different Enigma2 image variants."""
        error = None
        try:
            selector = getattr(self, "subtitleSelection", None)
            if callable(selector):
                result = selector()
                if result != 0:
                    return result
        except Exception as exc:
            error = exc
            print("[TiviMateE2] native Live subtitle selector failed: %s" % exc)
        # Some images return 0 without opening a dialog if the service has no
        # embedded subtitle tracks. That is not an external-subtitle failure.
        try:
            service = self.session.nav.getCurrentService()
            subtitle = service and service.subtitle()
            tracks = subtitle and subtitle.getSubtitleList()
            if not tracks:
                self._showNotification("No server subtitle tracks. BLUE: TiviMate Subtitles.",
                                       MessageBox.TYPE_INFO, timeout=5)
                return False
        except Exception:
            pass
        try:
            from Screens.AudioSelection import SubtitleSelection
            _safe_open_screen(self.session, None, SubtitleSelection, self)
            return True
        except Exception as exc:
            print("[TiviMateE2] Live subtitle selection unavailable: %s / %s" % (error, exc))
            self._showNotification("Subtitle selection unavailable on this image. Try BLUE.",
                                   MessageBox.TYPE_ERROR, timeout=5)
            return False

    def _setLiveTechnicalBadgePixmap(self, widget_name, filename):
        try:
            widget = self[widget_name]
        except Exception:
            return
        if not filename:
            try:
                widget.hide()
            except Exception:
                pass
            return
        if filename == "@dolby":
            path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "live", "dolby.png")
        else:
            path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "common", filename)
        if not os.path.exists(path):
            try:
                widget.hide()
            except Exception:
                pass
            return
        try:
            widget.instance.setPixmapFromFile(path)
        except Exception:
            try:
                widget.setPixmapFromFile(path)
            except Exception:
                return
        try:
            widget.show()
        except Exception:
            pass

    def _liveTechnicalStreamInfo(self):
        """Read already-playing service geometry/codecs; no network request."""
        resolution = aspect = video = audio_name = ""
        service = info = None
        width = height = 0
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
        except Exception:
            pass
        if info is not None:
            try:
                width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
                height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
            except Exception:
                width = height = 0
        if width > 0 or height > 0:
            if width >= 3000 or height >= 1800:
                resolution = "2160p"
            elif width >= 1800 or height >= 1000:
                resolution = "1080p"
            elif width >= 1200 or height >= 700:
                resolution = "720p"
            elif width >= 900 or height >= 560:
                resolution = "576p"
            elif width >= 700 or height >= 460:
                resolution = "480p"
            try:
                ratio = float(width) / float(height) if height else 0.0
                if abs(ratio - (16.0 / 9.0)) < 0.14:
                    aspect = "16:9"
                elif abs(ratio - (4.0 / 3.0)) < 0.11:
                    aspect = "4:3"
                elif 2.18 <= ratio <= 2.52:
                    aspect = "2.35:1"
            except Exception:
                pass
        if info is not None:
            try:
                key = getattr(iServiceInformation, "sVideoType", None)
                if key is not None:
                    raw = info.getInfo(key)
                    video_map = {0:"MPEG2",1:"H.264",3:"VC-1",4:"MPEG4",5:"VC-1",7:"HEVC",8:"VP8",9:"VP9",10:"XVID",11:"AVS",12:"AVS2"}
                    try:
                        iv = int(raw)
                    except Exception:
                        iv = -1
                    video = video_map.get(iv, "")
                    if not video and iv == -2:
                        try:
                            txt = str(info.getInfoString(key) or "").upper()
                        except Exception:
                            txt = ""
                        if "HEVC" in txt or "H265" in txt or "H.265" in txt:
                            video = "HEVC"
                        elif "H264" in txt or "H.264" in txt or "AVC" in txt:
                            video = "H.264"
                        elif "VP9" in txt:
                            video = "VP9"
            except Exception:
                pass
        try:
            tracks = service and service.audioTracks()
            if tracks and int(tracks.getNumberOfTracks()) > 0:
                index = int(tracks.getCurrentTrack())
                desc = str(tracks.getTrackInfo(index).getDescription() or "").upper().replace("_", " ")
                if "E-AC3" in desc or "EAC3" in desc or "EC-3" in desc or "DD+" in desc or "DOLBY DIGITAL PLUS" in desc:
                    audio_name = "E-AC3"
                elif ("AC3" in desc or "AC-3" in desc or "DOLBY DIGITAL" in desc
                      or "A/52" in desc or "A52" in desc or "DD 5.1" in desc
                      or desc.strip() == "DD"):
                    audio_name = "AC3"
                elif "DTS" in desc:
                    audio_name = "DTS"
                elif "AAC" in desc:
                    audio_name = "AAC"
                elif "MP3" in desc or "MPEG LAYER 3" in desc:
                    audio_name = "MP3"
        except Exception:
            pass
        # Some OpenATV service types expose Dolby only through service.info()
        # while the selected track description stays generic. Use that as a
        # fallback only when the track API did not identify the codec.
        if not audio_name and info is not None:
            try:
                audio_key = getattr(iServiceInformation, "sAudioType", None)
                if audio_key is not None:
                    try:
                        atxt = str(info.getInfoString(audio_key) or "").upper().replace("_", " ")
                    except Exception:
                        atxt = ""
                    if "E-AC3" in atxt or "EAC3" in atxt or "EC-3" in atxt or "DD+" in atxt or "DOLBY DIGITAL PLUS" in atxt:
                        audio_name = "E-AC3"
                    elif "AC3" in atxt or "AC-3" in atxt or "A/52" in atxt or "A52" in atxt or "DOLBY DIGITAL" in atxt:
                        audio_name = "AC3"
                    elif "DTS" in atxt:
                        audio_name = "DTS"
                    elif "AAC" in atxt:
                        audio_name = "AAC"
            except Exception:
                pass
        return resolution, aspect, video, audio_name

    def _updateLiveTechnicalBadges(self):
        try:
            resolution, aspect, video, audio_name = self._liveTechnicalStreamInfo()
            resolution_files = {
                "2160p":"player_badge_res_2160p_r280.png", "1080p":"player_badge_res_1080p_r280.png",
                "720p":"player_badge_res_720p_r280.png", "576p":"player_badge_res_576p_r280.png",
                "480p":"player_badge_res_480p_r280.png",
            }
            aspect_files = {"16:9":"player_badge_aspect_16_9_r280.png", "4:3":"player_badge_aspect_4_3_r280.png", "2.35:1":"player_badge_aspect_2_35_1_r280.png"}
            video_files = {"H.264":"player_badge_video_h264_r280.png", "HEVC":"player_badge_video_hevc_r280.png", "VP9":"player_badge_video_vp9_r280.png", "VP8":"player_badge_video_vp8_r280.png", "MPEG2":"player_badge_video_mpeg2_r280.png", "MPEG4":"player_badge_video_mpeg4_r280.png", "VC-1":"player_badge_video_vc1_r280.png", "XVID":"player_badge_video_xvid_r280.png", "AVS":"player_badge_video_avs_r280.png", "AVS2":"player_badge_video_avs2_r280.png"}
            audio_files = {"AAC":"player_badge_audio_aac_r280.png", "AC3":"@dolby", "E-AC3":"@dolby", "DTS":"player_badge_audio_dts_r280.png", "MP3":"player_badge_audio_mp3_r280.png"}
            last = getattr(self, "_liveTechBadgeValues", {}) or {}
            if resolution in resolution_files: last["resolution"] = resolution
            if aspect in aspect_files: last["aspect"] = aspect
            if video in video_files: last["video"] = video
            if audio_name in audio_files: last["audio"] = audio_name
            self._liveTechBadgeValues = last
            from .resolution_badge import set_resolution_badge
            set_resolution_badge(self, "resolutionBadge", last.get("resolution"))
            self._setLiveTechnicalBadgePixmap("aspectBadge", aspect_files.get(last.get("aspect")))
            self._setLiveTechnicalBadgePixmap("videoBadge", video_files.get(last.get("video")))
            self._setLiveTechnicalBadgePixmap("audioBadge", audio_files.get(last.get("audio")))
        except Exception:
            pass

    def _ultraLiveStartEventCurrent(self):
        """Apply Ultra's current-service guard to evStart as well as EOF.

        When a fresh Stalker create_link is pending, Enigma2 may still be
        playing the previous channel. Its late evStart must not refresh the
        new channel's EPG, infobar or subtitles. Unlike EOF, a matching evStart
        is allowed during the short zap suppression grace: otherwise valid
        start events could be lost on fast decoders.
        """
        if getattr(self, '_liveResolvePending', False):
            return False
        if not (getattr(self, '_liveStartupPending', False) or
                getattr(self, '_livePlaybackConfirmed', False)):
            return False
        try:
            expected = getattr(self, 'current_ref', None)
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            return bool(expected is not None and active is not None and
                        expected.toString() == active.toString())
        except Exception:
            return False

    def _serviceStarted(self):
        # Ultra player_golden57._event_matches_current_reference: a late
        # evStart from the last channel must never touch the current UI.
        if not self._ultraLiveStartEventCurrent():
            return
        # Never attribute a delayed evStart from another service to this tune.
        # Ultra captures external ServiceApp processes after evStart, since
        # they can spawn asynchronously after Navigation.playService returns.
        try:
            expected = getattr(self, 'current_ref', None)
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            if (expected is not None and active is not None and
                    expected.toString() == active.toString() and
                    getattr(self, '_ultraExternalUrl', '')):
                self._ultraDecoderGuard.capture(self._ultraExternalUrl)
        except Exception:
            pass
        if self._liveStartupPending:
            try:
                current = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, "current_ref", None)
                if current and expected and current.toString() == expected.toString():
                    self._liveServiceStarted = True
            except Exception:
                pass
        # evStart does not mean there is a decoded frame. The startup check
        # continues only until real video dimensions are available.
        if self._liveStartupPending:
            self._checkLiveStartup()
        # Selecting the same channel from the list can create a new player
        # and restart the native service. Reattach the saved external file so
        # RED still shows the track and the rendered subtitles do not vanish.
        if (not getattr(self, "_external_subtitle_path", "") and
                isinstance(self._liveSubtitleSessionStore(), dict)):
            try:
                self._restorePreservedLiveSubtitle(self._current())
            except Exception:
                pass
        # r522: evStart can arrive before all decoder metadata is populated.
        # Read once immediately, then temporarily reuse the existing clock
        # timer for quick local badge refreshes. EPG scheduling is unchanged.
        if not self._liveStartupPending:
            # A late/instant evStart must not block the GUI/decoder with PNG
            # badge decoding. Defer it through the existing clock timer.
            self._liveTechFastRefresh = max(3, int(getattr(self, '_liveTechFastRefresh', 0) or 0))
            if not getattr(self, '_epg_ready', False):
                self._scheduleEpg()
        try:
            if getattr(self, "_liveTechFastRefresh", 0) > 0:
                self._clock_timer.start(1000, False)
        except Exception:
            pass
        self.showInfobar()

    def _favoriteSafeZap(self, delta):
        # CH+/CH- is an ActionMap callback: an uncaught provider/item exception
        # here restarts Enigma2. Keep the existing player and service list alive.
        if not self.channels:
            return
        old_index = self.index
        try:
            self.index = (self.index + int(delta)) % len(self.channels)
            self.playCurrent()
        except Exception as exc:
            self.index = old_index
            try:
                print("[TiviMateE2] Live zap failed safely: %r" % (exc,))
            except Exception:
                pass

    def nextChannel(self):
        self._favoriteSafeZap(1)

    def prevChannel(self):
        self._favoriteSafeZap(-1)
    def _showInfobarPosterFallback(self):
        """Keep the oval frame and its TiViMate logo visible if artwork is missing."""
        try:
            self["livePoster"].hide()
            self["backdropFrame"].show()
            self._infobarPosterPath = ""
        except Exception:
            pass

    def _scheduleInfobarPoster(self, title, description=""):
        self._infobarPosterYear = ""
        self._infobarPosterRating = 0.0
        self._refreshLiveEpgDetails()
        self._livePosterToken += 1
        token = self._livePosterToken
        self._infobarFootballFixture = None
        self._infobarEpgDescription = ""
        self._infobarPosterPath = ""
        self._livePillRequestSeq += 1  # invalidate previous channel's pending crop
        self._infobarPosterDecodeToken = -1
        self._livePosterResult = None
        try:
            self._livePosterTimer.stop()
            self._livePosterPoll.stop()
            self["livePoster"].hide()
            self["backdropFrame"].show()
        except Exception:
            pass
        enabled = str(self.source.get("show_live_infobar_poster", True)).strip().lower() in ("1","true","yes","on","enabled")
        _live_diag_log(self.source, self._current(), "poster_schedule", enabled=enabled, title=str(title or ""))
        if not enabled:
            return
        # Use the same title cleanup as the Live browser.  This only changes
        # the copy sent to TMDb; the displayed EPG title is untouched.
        clean = text_type(title or u"").strip()
        clean = re.sub(r"^\s*\[(?:HD|FHD|UHD|4K|HEVC|H265|H264|AR|ARA|EN|ENG)\]\s*", "", clean, flags=re.I)
        clean = re.sub(r"\s*\[(?:HD|FHD|UHD|4K|HEVC|H265|H264|AR|ARA|EN|ENG)\]\s*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*\((?:HD|FHD|UHD|4K|HEVC|H\.?265|H\.?264|AR|ARA|EN|ENG)\)\s*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*[Ss]\s*\d{1,2}\s*[Ee]\s*\d{1,3}\b.*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*(?:EP(?:ISODE)?\.?|E)\s*#?\d{1,3}\b.*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*(?:الحلقة|حلقة)\s*\d{1,3}\b.*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*(?:الموسم)\s*\d{1,2}\s*(?:الحلقة|حلقة)\s*\d{1,3}\b.*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", clean)
        clean = re.sub(r"(?:\s*[\-–—|]\s*)?(?:HD|FHD|UHD|4K|1080P|720P|HEVC|H\.?265|H\.?264)\s*$", "", clean, flags=re.I)
        clean = re.sub(r"\s+", " ", clean).strip(" -–—:|")
        if not clean:
            channel_name = str((self._current() or {}).get("name") or "")
            # A club-specific TV channel can display that club's fanart even
            # without EPG. Generic beIN/SSC channels cannot identify a match.
            self._infobarFootballFixture = classify_football("", channel_name)
            if self._infobarFootballFixture:
                self._infobarPosterTitle = channel_name
                try: self._livePosterTimer.start(350, True)
                except Exception: self._startInfobarPosterLookup()
            else:
                _log_sports('no_epg_or_team')
                self._showInfobarPosterFallback()
            return
        self._infobarPosterTitle = clean
        # Football is a separate provider path: do not reuse a movie backdrop
        # from this title or show an old match's image as a current event.
        current_item = self._current() or {}
        channel_name = str(current_item.get("name") or current_item.get("title") or "")
        self._infobarFootballFixture = classify_football(clean, channel_name, description)
        self._infobarEpgDescription = text_type(description or u"")[:300]
        if self._infobarFootballFixture:
            try: self._livePosterTimer.start(350, True)
            except Exception: self._startInfobarPosterLookup()
            return

        # Never mistake a generic football EPG entry for a TMDb film. If the
        # feed provides no club/match information, keep the TiViMate oval logo.
        if re.search(r"(?i)\b(?:football|soccer|live match|soccer live)\b|كرة\s*القدم|مباراة|مباراه|الدوري|كأس|كاس", clean):
            _log_sports('sports_epg_without_identifiable_team')
            self._showInfobarPosterFallback()
            return

        key = re.sub(r"\s+", " ", clean.strip().lower())
        backdrop_url = str(_load_live_infobar_backdrops().get(key) or "").strip()
        if backdrop_url:
            cached = cached_artwork(backdrop_url, "backdrops") if cached_artwork else None
            if cached:
                self._showInfobarPoster(cached, token)
            else:
                def ready_backdrop(path):
                    if path and os.path.exists(path):
                        self._showInfobarPoster(path, token)
                request_artwork(backdrop_url, kind="backdrops", callback=ready_backdrop, priority=250)
            return

        # Do not reuse cached vertical movie posters in the Live infobar.
        # The Live list can keep using its own poster cache independently.
        try:
            self._livePosterTimer.start(350, True)
        except Exception:
            self._startInfobarPosterLookup()

    def _startInfobarPosterLookup(self):
        title = getattr(self, "_infobarPosterTitle", "")
        token = self._livePosterToken
        if not title:
            return
        fixture = getattr(self, "_infobarFootballFixture", None)
        channel = (self._current() or {}).get("name") or (self._current() or {}).get("title") or ""
        description = getattr(self, "_infobarEpgDescription", "")
        def worker():
            if fixture:
                # Distinct metadata provider for matches; keep TMDb movie/series
                # titles unchanged and never fall back to unrelated film art.
                try:
                    sports_url, _matched = resolve_football_art(title, channel, description=description)
                except Exception:
                    sports_url = ""
                _log_sports('football_worker_done', artwork_found=bool(sports_url), matches=bool(fixture))
                self._livePosterResult = (token, sports_url, 0.0, "", "backdrops", "", True, "")
                return
            url = ""
            rating = 0.0
            year = ""
            poster_path = ""
            overview = ""
            try:
                client = TMDbClient()
                movie = client.search_artwork(title, "vod", required_key="backdrop_path") or {}
                series = {} if movie else (client.search_artwork(title, "series", required_key="backdrop_path") or {})
                result = movie or series or {}
                backdrop_path = result.get("backdrop_path") or ""
                poster_path = result.get("poster_path") or ""
                overview = result.get("overview") or ""
                if backdrop_path:
                    url = "https://image.tmdb.org/t/p/w780" + backdrop_path
                try:
                    rating = float(result.get("vote_average") or result.get("rating") or 0.0)
                except Exception:
                    rating = 0.0
                date_value = str(result.get("release_date") or result.get("first_air_date") or "")
                if len(date_value) >= 4 and date_value[:4].isdigit():
                    year = date_value[:4]
            except Exception:
                pass
            poster_url = ("https://image.tmdb.org/t/p/w342" + poster_path) if poster_path else ""
            self._livePosterResult = (token, url, rating, year, "backdrops", poster_url, False, overview)
        t = thread_factory(target=worker, name="TiviMateInfobarPoster")
        t.daemon = True
        t.start()
        try:
            self._livePosterPoll.start(250, False)
        except Exception:
            pass

    def _finishInfobarPosterLookup(self):
        result = self._livePosterResult
        if result is None:
            try:
                self._livePosterPoll.start(250, False)
            except Exception:
                pass
            return
        self._livePosterResult = None
        token, url, rating, year, art_kind, poster_url, is_football, overview = result
        if token != self._livePosterToken:
            return
        _live_diag_log(self.source, self._current(), "poster_lookup", found=bool(url), title=getattr(self, "_infobarPosterTitle", ""), rating=rating, year=year)
        if not url:
            # Keep the programme poster already resolved by the Live list.
            if not getattr(self, "_infobarPosterPath", ""):
                self._showInfobarPosterFallback()
            return
        self._infobarPosterRating = rating
        self._infobarPosterYear = year
        # Search artwork already returned a TMDb overview; reuse it only when
        # EPG supplied no description. No additional lookup or worker.
        if not getattr(self, '_liveEpgPlot', u'') and overview and not is_football:
            self._setLiveEpgDescription(overview)
        else:
            self._refreshLiveEpgDetails()
        self._infobarArtworkKind = "backdrops"
        # Feed the exact poster resolved by the infobar back to the Live list.
        # This avoids a second TMDb search when the user leaves full-screen.
        try:
            if poster_url:
                _remember_infobar_live_poster(getattr(self, "_infobarPosterTitle", ""), poster_url)
            if art_kind == "backdrops" and not is_football:
                _remember_live_infobar_backdrop(getattr(self, "_infobarPosterTitle", ""), url)
        except Exception:
            pass
        cached = cached_artwork(url, "backdrops") if cached_artwork else None
        if cached:
            if is_football: _log_sports('sports_image_cached')
            self._showInfobarPoster(cached, token)
            return
        def ready(path):
            if is_football: _log_sports('sports_image_download', ok=bool(path and os.path.exists(path)))
            if path and os.path.exists(path):
                self._showInfobarPoster(path, token)
            elif token == self._livePosterToken:
                self._showInfobarPosterFallback()
        def failed(_reason=None):
            if is_football: _log_sports('sports_download_failed')
        request_artwork(url, kind="backdrops", callback=ready, priority=250, errback=failed)

    def _showInfobarPoster(self, path, token):
        if (getattr(self, "_livePillClosed", True) or
                token != getattr(self, "_livePosterToken", None) or
                not path or not os.path.exists(path)):
            return
        # Capturing the lock once prevents a delayed image worker from
        # accessing missing or reset state after a screen has been closed.
        lock = getattr(self, "_livePillLock", None)
        if lock is None:
            return
        self._infobarPosterPath = str(path)
        self._livePillRequestSeq += 1
        request_seq = self._livePillRequestSeq
        with lock:
            if self._livePillClosed:
                return
            self._livePillWorkers += 1

        def worker():
            try:
                try:
                    prepared = prepare_pill_image(path)
                except Exception:
                    prepared = path
                with lock:
                    if (not getattr(self, "_livePillClosed", True) and
                            token == getattr(self, "_livePosterToken", None) and
                            request_seq == getattr(self, "_livePillRequestSeq", None)):
                        self._livePillResults.append((token, request_seq, prepared or path))
            finally:
                with lock:
                    self._livePillWorkers = max(0, getattr(self, "_livePillWorkers", 0) - 1)

        try:
            job = thread_factory(target=worker, name="TiviMateLiveOval")
            job.daemon = True
            job.start()
        except Exception:
            with lock:
                self._livePillWorkers = max(0, self._livePillWorkers - 1)
            return
        try:
            self._livePillTimer.start(90, False)
        except Exception:
            pass

    def _finishInfobarPill(self):
        if getattr(self, "_livePillClosed", True):
            return
        lock = getattr(self, "_livePillLock", None)
        if lock is None:
            return
        with lock:
            results = self._livePillResults[:]
            self._livePillResults = []
            remaining = self._livePillWorkers
        if not remaining:
            try:
                self._livePillTimer.stop()
            except Exception:
                pass
        for token, request_seq, path in results:
            if token != self._livePosterToken or request_seq != self._livePillRequestSeq or not path or not os.path.isfile(path):
                continue
            try:
                self._infobarPosterDecodeToken = token
                # Directly load premasked PNG to preserve the capsule alpha.
                # ePicLoad on some Python 2.7 DreamOS builds flattens alpha.
                if (os.path.basename(path).startswith('pill_') and
                        path.lower().endswith('.png')):
                    try:
                        from Tools.LoadPixmap import LoadPixmap
                        ptr = LoadPixmap(path=path)
                        if ptr is not None and token == self._livePosterToken:
                            self['livePoster'].instance.setPixmap(ptr)
                            self['livePoster'].show()
                            self['backdropFrame'].show()
                            continue
                    except Exception:
                        pass
                # Decode original art only if every alpha-crop backend failed.
                self._livePosterPic.setPara((400, 224, 1, 1, False, 1, "#00000000"))
                self._livePosterPic.startDecode(path)
            except Exception:
                pass

    def _infobarPosterDecoded(self, info=None):
        try:
            if getattr(self, "_infobarPosterDecodeToken", -1) != self._livePosterToken:
                return
            ptr = self._livePosterPic.getData()
            if ptr is None:
                self._showInfobarPosterFallback()
                return
            # Native clipping on supported Enigma2 builds; Pillow crop already
            # carries alpha on receivers with python3-PIL installed.
            instance = self["livePoster"].instance
            if hasattr(instance, "setCornerRadius"):
                try:
                    instance.setCornerRadius(112)
                except TypeError:
                    try:
                        from enigma import eWidget
                        instance.setCornerRadius(112, eWidget.RADIUS_ALL)
                    except Exception:
                        pass
                except Exception:
                    pass
            instance.setPixmap(ptr)
            self["livePoster"].show()
            if getattr(self, "_infobarFootballFixture", None):
                _log_sports('sports_image_displayed')
            self["backdropFrame"].show()
        except Exception:
            pass


    def _loadPicon(self, item):
        # The channel picon is independent of the programme backdrop. The
        # TiViMate fallback logo belongs inside the left oval (in the skin).
        try:
            self._infobarPiconReqId = int(getattr(self, '_infobarPiconReqId', 0) or 0) + 1
        except Exception:
            self._infobarPiconReqId = 1
        req_id = self._infobarPiconReqId

        try:
            fallback = os.path.join(os.path.dirname(__file__), 'skins', 'common', 'te2_fallback.png')
            if os.path.isfile(fallback) and self['picon'].instance:
                self['picon'].instance.setPixmapFromFile(fallback)
                self['picon'].show()
            else:
                self['picon'].hide()
        except Exception:
            pass
        url = resolve_picon_url(item, self.source)
        _live_diag_log(self.source, item, "picon_request", has_url=bool(url), icon=_live_diag_safe_icon(url))
        if not url:
            return

        def current_id():
            return int(getattr(self, '_infobarPiconReqId', 0) or 0)

        def apply_path(path):
            if req_id != current_id():
                return
            if not path or not os.path.isfile(path):
                _live_diag_log(self.source, item, "picon_result", result="no_valid_channel_picon")
                return
            try:
                from .live_picon_display import paint_picon
                if paint_picon(self, 'picon', path, req_id, current_id):
                    _live_diag_log(self.source, item, "picon_result", result="shown", path=os.path.basename(str(path)))
            except Exception as exc:
                _live_diag_log(self.source, item, "picon_result", result="show_failed", error=repr(exc))

        direct_picon(url, (280,168), req_id, current_id, apply_path, prefix='tivimate_infobar_picon_')


    def _piconDecoded(self, info=None):
        return


    def _setLiveEpgLabel(self, key, value):
        """Paint DreamOS/Python 2.7 programme labels using UTF-8 bytes.

        Do not rely on the SIP C++ Label binding to convert a Python 2 unicode
        string through the default ASCII codec. Other Live list widgets use
        the same UTF-8 GUI representation and can already show Arabic EPG.
        """
        try:
            self[key].setText(gui_text(value if value is not None else u""))
            self[key].show()
            return True
        except Exception as exc:
            try:
                self[key].setText(text_type(value if value is not None else u""))
                self[key].show()
                return True
            except Exception as again:
                self._traceLiveEpg("label_error", label=key,
                                   err=type(exc).__name__ + "/" + type(again).__name__)
                return False

    def _traceLiveEpg(self, event, **fields):
        return None  # r146: diagnostics off
        """Small bounded diagnostic file; no channels, URLs, credentials or titles."""
        try:
            path = data_path("live_epg_diagnostic.log")
            if os.path.isfile(path) and os.path.getsize(path) > 64000:
                os.rename(path, path + ".old")
            parts = [time.strftime("%Y-%m-%d %H:%M:%S"), str(event),
                     "provider=" + str((self.source or {}).get("type") or ""),
                     "index=" + str(getattr(self, "index", -1))]
            for key, val in sorted(fields.items()):
                parts.append(str(key) + "=" + str(val)[:32])
            with open(path, "a") as handle:
                handle.write(" ".join(parts) + "\n")
        except Exception:
            pass

    def _showBrowserInfobarEpg(self, item=None):
        """Display verified browser Now/Next without re-resolving channel IDs.

        Live's visible list/Windows screen already resolved these titles.
        They belong to this copied channel row only. A fresh short_epg lookup
        still runs later and can replace the text with more current results.
        """
        if item is None:
            item = self._current()
        handoff = _read_live_epg_handoff(item)
        if not handoff:
            self._traceLiveEpg("handoff_missing")
            return False
        now, upcoming = handoff
        title = text_type(now.get('title') or u'').strip()
        if not title:
            return False
        current_clock = text_type(now.get('t_time') or u'').strip()
        self._setLiveEpgLabel("epgNow", (current_clock + u'   ' + title) if current_clock else title)
        nxt = text_type(upcoming.get('title') or u'').strip()
        next_clock = text_type(upcoming.get('t_time') or u'').strip()
        self._setLiveEpgLabel("epgNext", (next_clock + u'   ' + nxt) if next_clock and nxt else nxt)
        desc = now.get('description') or now.get('descr') or now.get('desc') or u''
        self._setLiveEpgDescription(desc)
        # Set even when no absolute timestamps are available: a subsequent
        # empty remote EPG result must not erase a valid visible programme.
        try:
            begin = int(now.get('start_timestamp') or 0)
            end = int(now.get('stop_timestamp') or 0)
        except (ValueError, TypeError, OverflowError):
            begin, end = 0, 0
        self._setLiveEpgContext(title, begin, max(0, end - begin))
        self._traceLiveEpg("handoff_painted", next=int(bool(nxt)), timed=int(bool(begin)))
        if begin and end > begin:
            self._refreshEpgProgress()
        return True

    def _showCachedInfobarEpg(self, item=None):
        """Paint the exact channel's previously loaded Live-list EPG instantly.

        The list/Windows EPG worker already published positive results in the
        shared RAM bridge. Do not throw them away while a second request runs.
        This never touches disk or network and does not invent Now/Next titles.
        """
        if item is None:
            item = self._current()
        rows = _shared_live_epg_cached(self.source, item)
        if not rows:
            return False
        current = following = None
        provider = str((self.source or {}).get("type") or "").lower()
        if provider == "stalker":
            current, following = self._parseStalkerPlayerEpg(rows)
        else:
            current, following = self._parseXtreamPlayerEpg(rows)
            if current is None:
                # M3U/XMLTV and older panels sometimes have titles but no
                # usable absolute timestamps. Display those titles without
                # guessing a progress value or programme time.
                selected, next_row = _shared_stalker_now_next(rows)
                if selected:
                    begin, stop, raw = selected
                    current = (begin, stop, self._decodeXtreamEpgText(
                        _epg_row_title(raw)), raw)
                if next_row:
                    begin, stop, raw = next_row
                    following = (begin, stop, self._decodeXtreamEpgText(
                        _epg_row_title(raw)), raw)
        if not current:
            return False
        begin, end, title, row = current
        title = text_type(title or u"").strip()
        if not title:
            return False
        begin, end = int(begin or 0), int(end or 0)
        duration = max(0, end - begin)
        clock = self._formatEpgClock(begin, duration) if begin and duration else ""
        if provider == "stalker":
            clock = text_type(row.get("t_time") or "").strip() or clock
        self._setLiveEpgLabel("epgNow", (clock + u"   " + title) if clock else title)
        next_text = u""
        if following:
            nb, ne, nt, nr = following
            nt = text_type(nt or u"").strip()
            if nt:
                nb, ne = int(nb or 0), int(ne or 0)
                next_clock = self._formatEpgClock(nb, max(0, ne-nb)) if nb and ne > nb else ""
                if provider == "stalker":
                    next_clock = text_type(nr.get("t_time") or "").strip() or next_clock
                next_text = (next_clock + u"   " + nt) if next_clock else nt
        self._setLiveEpgLabel("epgNext", next_text)
        desc = row.get("descr") or row.get("description") or row.get("desc") or row.get("plot") or ""
        if provider != "stalker":
            desc = self._decodeXtreamEpgText(desc)
        self._setLiveEpgDescription(desc)
        if begin and duration:
            self._setLiveEpgContext(title, begin, duration)
            self._refreshEpgProgress()
        return True

    def _scheduleEpg(self):
        # playService(), evStart and showInfobar can all fire for the same
        # channel. One pending timer is enough; do not postpone EPG over and
        # over while the first frames decode.
        if getattr(self, '_epgSchedulePending', False):
            return
        self._epgSchedulePending = True
        self._epg_ready = False
        self._epgAsyncToken += 1
        self._epgNextReadAt = 0.0
        self._epgNextRequestAt = 0.0
        self._xtream_epg_last_update = 0.0
        try:
            self._epg_timer.stop()
        except Exception:
            pass
        # A channel with verified EPG in the browser must not reopen with
        # empty Now/Next while the player schedules a redundant lookup.
        # On actual zaps _clearLiveEpgUi already cleared the previous channel.
        restored = False
        try:
            # The original Live/Windows GUI is authoritative for the channel
            # that opened fullscreen. Fall back to RAM bridge only on a miss.
            restored = (self._showBrowserInfobarEpg(self._current()) or
                        self._showCachedInfobarEpg(self._current()))
        except Exception:
            restored = False
        self._traceLiveEpg("epg_schedule", restored=int(bool(restored)),
                           cached=int(bool((getattr(self, "_live_epg_context", {}) or {}).get("title"))),
                           handoff=int(bool(_read_live_epg_handoff(self._current()))))
        if not restored and not (getattr(self, "_live_epg_context", {}) or {}).get("title"):
            self._setLiveEpgLabel("epgNow", "")
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
        try:
            self._epg_timer.start(900, True)
        except TypeError:
            self._epg_timer.start(650)
        except Exception:
            self._delayedEpg()

    def _delayedEpg(self):
        self._epgSchedulePending = False
        self._epg_ready = True
        self._updateEpg()

    def _stalkerEpgTimestamp(self, value):
        if value in (None,""): return 0
        try:
            if isinstance(value,(int,float)): return int(value)
        except Exception: pass
        raw=str(value or "").strip()
        try: return int(float(raw))
        except Exception: pass
        try: return int(time.mktime(time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S")))
        except Exception: return 0

    def _parseStalkerPlayerEpg(self, rows):
        # Identical programme selection as Live List and Windows.
        current, following = _shared_stalker_now_next(rows)
        def player_row(event):
            if event is None:
                return None
            begin, end, raw = event
            return (begin, end, _ultra_epg_title(raw), raw)
        return player_row(current), player_row(following)

    def _startStalkerPlayerEpg(self, item):
        if self.source.get("type")!="stalker": return False
        ch_id=str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or "").strip()
        if not ch_id: return False
        self._stalker_epg_token += 1
        token=self._stalker_epg_token
        self._stalker_epg_started_at = monotonic()
        shared_rows = _shared_live_epg_cached(self.source, item)
        if shared_rows:
            self._stalker_epg_result = (token, shared_rows)
            try: self._stalker_epg_poll.start(1, True)
            except Exception: pass
            return True
        source = dict(self.source or {})
        selected = dict(item or {})
        def worker():
            try:
                # EPG lane must not borrow the playback client's mutable
                # session. Read the shared Ultra-style EPG cache first.
                rows = _shared_epg_wait(source, selected, max_wait=0.7)
                if not rows:
                    current_client = live_playback_client(source, get_source_client)
                    if current_client is None:
                        raise RuntimeError("Stalker client unavailable")
                    rows = current_client.short_epg(ch_id,limit=10,force=False) or []
            except Exception:
                invalidate_live_playback_client(source)
                rows=[]
            if token == self._stalker_epg_token:
                self._stalker_epg_result=(token,rows)
        try:
            from .stalker_live_pool import LIVE_EPG_EXECUTOR
            self._stalker_epg_future = LIVE_EPG_EXECUTOR.submit(
                worker, _task_key=("player-short-epg", id(self)), _replace_task_key=True)
        except Exception:
            # A bounded pool may be closed during shutdown: never block GUI.
            self._stalker_epg_result = (token, [])
        try: self._stalker_epg_poll.start(100,True)
        except Exception: pass
        return True

    def _finishStalkerPlayerEpg(self):
        result=self._stalker_epg_result
        if result is None:
            if monotonic() - self._stalker_epg_started_at >= 7.0:
                # Late workers must not keep the infobar polling forever.
                result = (self._stalker_epg_token, [])
            else:
                try: self._stalker_epg_poll.start(100,True)
                except Exception: pass
                return
        self._stalker_epg_result=None
        token,rows=result
        if token != self._stalker_epg_token: return
        _shared_live_epg_remember(self.source, self._current(), rows)
        current,upcoming=self._parseStalkerPlayerEpg(rows)
        try:
            # Next programme of THIS channel, for MENU > Remind me.
            self._epgUpcomingEvent = (int(upcoming[0]), int(upcoming[1]), upcoming[2], self._current()) if upcoming and upcoming[0] else None
        except Exception:
            self._epgUpcomingEvent = None
        self._traceLiveEpg("stalker_response", rows=len(rows or []),
                           now=int(bool(current)), next=int(bool(upcoming)))
        if not current:
            if (getattr(self, "_live_epg_context", {}) or {}).get("title"):
                self._epgNextRequestAt = time.time() + 60
                return
            self._setLiveEpgLabel("epgNow", tr("No EPG data"))
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
            self._epgNextRequestAt = time.time() + 60
            return
        now=int(time.time()); begin,stop,title,row=current; duration=max(0,stop-begin)
        if begin and duration:
            self._setLiveEpgContext(title, begin, duration)
        current_time=str(row.get("t_time") or "").strip()
        self._setLiveEpgLabel("epgNow", u"%s   %s"%(
            current_time or (self._formatEpgClock(begin,duration) if begin else ""),title))
        description = row.get("descr") or row.get("description") or row.get("descr_short") or row.get("plot") or ""
        self._setLiveEpgDescription(description)
        self._scheduleInfobarPoster(title, description)
        if upcoming:
            ub,us,ut,urow=upcoming; ud=max(0,us-ub)
            nt=str(urow.get("t_time") or "").strip()
            self._setLiveEpgLabel("epgNext", u"%s   %s"%(
                nt or (self._formatEpgClock(ub,ud) if ub else ""),ut))
        else: self._setLiveEpgLabel("epgNext", "")
        elapsed=max(0,now-begin)
        percent=min(100,max(0,int((elapsed*100)/duration))) if duration>0 else 0
        elapsed_min=int(elapsed/60); total_min=int((duration+59)/60) if duration else 0
        self["epgProgress"].setValue(percent)
        if total_min>0:
            self["epgProgressText"].setText("%d / %d min  •  %d%%"%(elapsed_min,total_min,percent))
            try:
                self["epgProgress"].show(); self["epgProgressText"].show()
            except Exception: pass

    def _decodeXtreamEpgText(self, value):
        # Use the same validated UTF-8/Base64 decoder as the live-list EPG;
        # do not accidentally decode a short plain programme name as Base64.
        return _decode_xtream_title(value)

    def _xtreamEpgTimestamp(self, row, start=True):
        keys = ("start_timestamp", "start", "begin_timestamp", "begin") if start else (
            "stop_timestamp", "end", "end_timestamp", "stop"
        )
        for key in keys:
            value = (row or {}).get(key)
            if value in (None, ""):
                continue
            try:
                stamp = int(float(value))
                if stamp > 100000000000:
                    stamp = int(stamp / 1000)
                if stamp > 1000000000:
                    return stamp
            except Exception:
                try:
                    return int(time.mktime(time.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")))
                except Exception:
                    pass
        return 0

    def _parseXtreamPlayerEpg(self, rows):
        """Normalise Xtream short-EPG rows for the Live infobar.

        Xtream panels can return a valid current programme while their EPG
        timestamps use a different panel clock.  Keep the provider data as the
        single source of truth, but normalise one clock offset for the whole
        returned schedule before the Live infobar/subtitle context consumes it.
        """
        now = int(time.time())
        events = []
        marked_current = None
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._xtreamEpgTimestamp(row, True)
            stop = self._xtreamEpgTimestamp(row, False)
            if not stop and begin:
                raw_duration = row.get("duration") or row.get("duration_sec") or row.get("duration_seconds") or 0
                duration = 0
                try:
                    duration = int(float(raw_duration))
                except Exception:
                    text = str(raw_duration or "").strip()
                    try:
                        parts = [int(x) for x in text.split(":")]
                        if len(parts) == 3:
                            duration = parts[0] * 3600 + parts[1] * 60 + parts[2]
                        elif len(parts) == 2:
                            duration = parts[0] * 60 + parts[1]
                    except Exception:
                        duration = 0
                if duration > 0:
                    stop = begin + duration
            title = _epg_row_title(row)
            if begin and title:
                if not stop or stop <= begin:
                    stop = begin + 3600
                event = (begin, stop, title, row)
                events.append(event)
                flag = row.get("now_playing")
                if flag is None:
                    flag = row.get("is_now")
                if flag is None:
                    flag = row.get("current")
                try:
                    is_current = str(flag).strip().lower() in ("1", "true", "yes", "now", "current")
                except Exception:
                    is_current = False
                if is_current and marked_current is None:
                    marked_current = event
        events.sort(key=lambda x: x[0])
        if not events:
            return None, None

        # First trust timestamps when they already contain the receiver clock.
        current = None
        upcoming = None
        for idx, event in enumerate(events):
            if event[0] <= now < event[1]:
                current = event
                upcoming = events[idx + 1] if idx + 1 < len(events) else None
                break

        # Some Xtream panels explicitly mark the current row but expose its
        # start/stop in the panel clock.  Derive one offset from that row and
        # apply it to every event.  A provider progress percentage, when
        # supplied, gives an exact elapsed position; otherwise anchor the
        # receiver clock to the middle of the marked interval.  The offset is
        # rounded to 15 minutes because real panel clock offsets are normally
        # timezone-sized values rather than arbitrary seconds.
        if current is None and marked_current is not None:
            mb, ms, _mt, mr = marked_current
            duration = max(1, ms - mb)
            pct = None
            for key in ("percentage", "percent", "progress", "progress_percent"):
                raw = mr.get(key)
                if raw in (None, ""):
                    continue
                try:
                    value = float(str(raw).replace("%", "").strip())
                    if 0.0 <= value <= 1.0:
                        value *= 100.0
                    if 0.0 <= value <= 100.0:
                        pct = value
                        break
                except Exception:
                    pass
            if pct is not None:
                provider_position = mb + int((duration * pct) / 100.0)
            else:
                provider_position = mb + int(duration / 2)
            raw_offset = now - provider_position
            quantum = 15 * 60
            offset = int(round(float(raw_offset) / quantum) * quantum)
            shifted = []
            for eb, es, et, er in events:
                shifted.append((eb + offset, es + offset, et, er))
            events = shifted
            marked_current = (mb + offset, ms + offset, marked_current[2], mr)
            for idx, event in enumerate(events):
                if event[0] <= now < event[1]:
                    current = event
                    upcoming = events[idx + 1] if idx + 1 < len(events) else None
                    break
            if current is None:
                current = marked_current
                for idx, event in enumerate(events):
                    if event[0] == current[0] and event[2] == current[2]:
                        upcoming = events[idx + 1] if idx + 1 < len(events) else None
                        break

        if current is None:
            # No explicit now-playing marker. Xtream short_epg timestamps can be
            # in the panel clock instead of the receiver clock. Choose the same
            # conservative fallback row as before, then (only when it does not
            # contain "now") derive one rounded panel->receiver offset from the
            # fallback interval and apply it to the full schedule. This keeps the
            # displayed EPG times and the progress bar on the same local clock.
            past = [event for event in events if event[0] <= now]
            future = [event for event in events if event[0] > now]
            if past:
                current = past[-1]
                for event in future:
                    if event[0] > current[0]:
                        upcoming = event
                        break
            else:
                current = events[0]
                upcoming = events[1] if len(events) > 1 else None

            if current is not None and not (current[0] <= now < current[1]):
                cb, cs, _ct, _cr = current
                duration = max(1, cs - cb)
                provider_position = cb + int(duration / 2)
                raw_offset = now - provider_position
                quantum = 15 * 60
                offset = int(round(float(raw_offset) / quantum) * quantum)
                shifted = [(eb + offset, es + offset, et, er) for eb, es, et, er in events]
                events = shifted
                current = None
                upcoming = None
                for idx, event in enumerate(events):
                    if event[0] <= now < event[1]:
                        current = event
                        upcoming = events[idx + 1] if idx + 1 < len(events) else None
                        break
                if current is None and events:
                    current = events[0]
                    upcoming = events[1] if len(events) > 1 else None

        return current, upcoming

    def _startXtreamPlayerEpg(self, item):
        if self.source.get("type") != "xtream":
            return False
        # Use the exact same Xtream channel identity order as the Live list.
        # Some panels/items expose ch_id/channel_id without stream_id.
        stream_id = str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or (item or {}).get("channel_id") or "").strip()
        if not stream_id:
            return False
        epg_channel_id = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or (item or {}).get("epg_id") or "").strip()
        shared_rows = _shared_live_epg_cached(self.source, item)
        if shared_rows:
            self._xtream_epg_token += 1
            self._xtream_epg_result = (self._xtream_epg_token, shared_rows)
            try: self._xtream_epg_poll.start(1, True)
            except Exception: pass
            return True
        cached = self._xtream_epg_cache.get(stream_id)
        if cached and (time.time() - float(cached[0] or 0)) < 900:
            self._xtream_epg_token += 1
            self._xtream_epg_result = (self._xtream_epg_token, list(cached[1] or []))
            try:
                self._xtream_epg_poll.start(1, True)
            except Exception:
                pass
            return True
        self._xtream_epg_token += 1
        token = self._xtream_epg_token
        self._xtream_epg_started_at = monotonic()
        self._xtream_epg_result = None
        client = self._live_client
        def worker():
            try:
                current_client = client if (client is not None and XtreamClient is not None and isinstance(client, XtreamClient)) else get_source_client(self.source)
                if current_client is None:
                    raise RuntimeError("Xtream client unavailable")
                rows = current_client.short_epg(stream_id, limit=10, epg_channel_id=epg_channel_id) or []
            except Exception:
                rows = []
            if not isinstance(rows, list):
                rows = []
            _live_diag_log(self.source, item, "epg_short_api", lookup_stream_id=stream_id, lookup_epg_id=epg_channel_id, row_count=len(rows))
            # Ignore obsolete requests after a fast channel switch. Do not
            # poison a positive cache entry with a transient empty response.
            if token != self._xtream_epg_token:
                return
            positive_rows = [dict(r) for r in rows if isinstance(r, dict)]
            if positive_rows:
                self._xtream_epg_cache[stream_id] = (time.time(), positive_rows)
                if len(self._xtream_epg_cache) > 800:
                    oldest = sorted(self._xtream_epg_cache.items(), key=lambda kv: float(kv[1][0] or 0))[:120]
                    for key, _value in oldest:
                        self._xtream_epg_cache.pop(key, None)
            self._xtream_epg_result = (token, rows)
        t = thread_factory(target=worker, name="TiviMateXtreamShortEPG")
        t.daemon = True
        t.start()
        try:
            self._xtream_epg_poll.start(100, True)
        except Exception:
            pass
        return True

    def _finishXtreamPlayerEpg(self):
        result = self._xtream_epg_result
        if result is None:
            if monotonic() - self._xtream_epg_started_at >= 7.0:
                result = (self._xtream_epg_token, [])
            else:
                try:
                    self._xtream_epg_poll.start(100, True)
                except Exception:
                    pass
                return
        self._xtream_epg_result = None
        token, rows = result
        if token != self._xtream_epg_token:
            return
        _shared_live_epg_remember(self.source, self._current(), rows)
        current, upcoming = self._parseXtreamPlayerEpg(rows)
        try:
            # Next programme of THIS channel, for MENU > Remind me.
            self._epgUpcomingEvent = (int(upcoming[0]), int(upcoming[1]), upcoming[2], self._current()) if upcoming and upcoming[0] else None
        except Exception:
            self._epgUpcomingEvent = None
        self._traceLiveEpg("xtream_response", rows=len(rows or []),
                           now=int(bool(current)), next=int(bool(upcoming)))
        if not current:
            if (getattr(self, "_live_epg_context", {}) or {}).get("title"):
                self._epgNextReadAt = time.time() + 75
                return
            self._live_epg_context = {}
            self._setLiveEpgLabel("epgNow", tr("No EPG data"))
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
            self._epgNextReadAt = time.time() + 75
            return
        now = int(time.time())
        self._xtream_epg_last_update = time.time()
        begin, stop, title, row = current
        duration = max(0, stop - begin)
        self._setLiveEpgContext(title, begin, duration)
        self._setLiveEpgLabel("epgNow", u"%s   %s" % (self._formatEpgClock(begin, duration), title))
        description = self._decodeXtreamEpgText(row.get("descr") or row.get("description") or row.get("descr_short") or row.get("plot") or "")
        self._setLiveEpgDescription(description)
        self._scheduleInfobarPoster(title, description)
        if upcoming:
            ub, us, ut, _urow = upcoming
            self._setLiveEpgLabel("epgNext", u"%s   %s" % (self._formatEpgClock(ub, max(0, us - ub)), ut))
        else:
            self._setLiveEpgLabel("epgNext", "")
        elapsed = max(0, now - begin)
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        elapsed_min = int(elapsed / 60)
        total_min = int((duration + 59) / 60) if duration else 0
        self["epgProgress"].setValue(percent)
        if total_min > 0:
            self["epgProgressText"].setText("%d / %d min  •  %d%%" % (elapsed_min, total_min, percent))
            try:
                self["epgProgress"].show()
                self["epgProgressText"].show()
            except Exception:
                pass
        else:
            self["epgProgressText"].setText("")

    def _formatEpgClock(self, begin, duration):
        try:
            end = int(begin) + int(duration or 0)
            return "%s–%s" % (time.strftime("%H:%M", time.localtime(int(begin))), time.strftime("%H:%M", time.localtime(end)))
        except Exception:
            return ""

    def _refreshEpgProgress(self):
        """Local, cheap refresh only; never touch cache files or network."""
        context = getattr(self, "_live_epg_context", {}) or {}
        begin = int(context.get("begin") or 0)
        duration = max(0, int(context.get("duration") or 0))
        if not begin or not duration:
            return
        # Some DreamOS skin updates blank a Label while the progress widget
        # retains its context. Repaint from the verified EPG title, not from
        # guessed channel metadata. Never show a blank NOW over a live bar.
        title = text_type(context.get("title") or u"").strip()
        if title and not text_type(self["epgNow"].getText() or u"").strip():
            self._setLiveEpgLabel("epgNow", u"%s   %s" % (self._formatEpgClock(begin, duration), title))
        now = int(time.time())
        elapsed = max(0, now - begin)
        percent = min(100, int(elapsed * 100 / duration))
        self["epgProgress"].setValue(percent)
        self["epgProgressText"].setText("%d / %d min  •  %d%%" % (
            elapsed // 60, (duration + 59) // 60, percent))

    def _asyncEpgWorker(self):
        """One daemon worker per player: newer zaps replace queued lookups."""
        while True:
            with self._epgAsyncLock:
                job = self._epgAsyncPending
                self._epgAsyncPending = None
                if job is None or self._epgClosed:
                    self._epgAsyncWorkerRunning = False
                    return
            token, source, item = job
            try:
                value = lookup_channel_epg(source, item, int(time.time()))
            except Exception:
                value = (None, None)
            with self._epgAsyncLock:
                if not self._epgClosed and token == self._epgAsyncToken:
                    self._epgAsyncResult = (token, source.get("type"), item, value)

    def _requestAsyncLocalEpg(self, item):
        # Convert once to plain dictionaries so background work never reads
        # mutable player/source objects while a new channel is being opened.
        token = self._epgAsyncToken
        try:
            source = dict(self.source or {})
            item_copy = dict(item or {})
        except Exception:
            return
        launch = False
        with self._epgAsyncLock:
            self._epgAsyncPending = (token, source, item_copy)
            self._epgAsyncResult = None
            if not self._epgAsyncWorkerRunning:
                self._epgAsyncWorkerRunning = True
                launch = True
        if launch:
            t = thread_factory(target=self._asyncEpgWorker, name="TiviMateLightEPG")
            t.daemon = True
            t.start()
        try:
            self._epgAsyncPoll.start(180, True)
        except TypeError:
            self._epgAsyncPoll.start(180)

    def _finishAsyncEpgLookup(self):
        with self._epgAsyncLock:
            result = self._epgAsyncResult
            self._epgAsyncResult = None
            running = self._epgAsyncWorkerRunning
        if result is None:
            if running and not self._epgClosed:
                try:
                    self._epgAsyncPoll.start(220, True)
                except TypeError:
                    self._epgAsyncPoll.start(220)
            return
        token, source_type, item, events = result
        if self._epgClosed or token != self._epgAsyncToken:
            return
        current, upcoming = events
        self._traceLiveEpg("local_response", now=int(bool(current)),
                           next=int(bool(upcoming)))
        # A timed EPG row without a programme name is not valid NOW data.
        # Never let an empty-title local result replace verified provider
        # handoff with a progress-only bar and blank Now/Next labels.
        if current and not text_type(current[2] or u"").strip():
            current = None
        if not current:
            positive_rows = _shared_live_epg_cached(self.source, item)
            if source_type == "xtream" and positive_rows and self._startXtreamPlayerEpg(item):
                self._epgNextReadAt = time.time() + 180
                return
            if source_type == "xtream" and self._startXtreamPlayerEpg(item):
                # Only the remote provider fallback runs now, in its own thread.
                # The provider request is asynchronous. Normal EPG channels
                # retain their regular refresh interval; only empty results
                # are throttled for ten minutes when the worker finishes.
                self._epgNextReadAt = time.time() + 180
                return
            if (getattr(self, "_live_epg_context", {}) or {}).get("title"):
                self._epgNextReadAt = time.time() + 75
                return
            self._setLiveEpgLabel("epgNow", tr("No EPG data"))
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
            self._epgNextReadAt = time.time() + 75
            return
        begin, duration, title, desc = current
        # Prepared XMLTV/native EPG can be fresher than portal short_epg.
        # Publish this successful infobar result so Windows paints it on return.
        bridge_rows = [{"title": title or "", "description": desc or "",
                        "start_timestamp": int(begin),
                        "stop_timestamp": int(begin) + int(duration or 0)}]
        if upcoming:
            ub, ud, ut, upcoming_desc = upcoming
            bridge_rows.append({"title": ut or "", "description": upcoming_desc or "",
                                "start_timestamp": int(ub),
                                "stop_timestamp": int(ub) + int(ud or 0)})
        _shared_live_epg_remember(self.source, item, bridge_rows)
        previous = (getattr(self, "_live_epg_context", {}) or {}).get("title")
        self._setLiveEpgContext(title, begin, duration)
        self._setLiveEpgDescription(desc)
        self._setLiveEpgLabel("epgNow", u"%s   %s" % (self._formatEpgClock(begin, duration), title or ""))
        if upcoming:
            ub, ud, ut, _u_desc = upcoming
            self._setLiveEpgLabel("epgNext", u"%s   %s" % (self._formatEpgClock(ub, ud), ut or ""))
        else:
            self._setLiveEpgLabel("epgNext", "")
        self._refreshEpgProgress()
        try:
            self["epgProgress"].show()
            self["epgProgressText"].show()
        except Exception:
            pass
        # Artwork network requests are independent and only needed when the
        # programme changes, not on each progress update.
        if title and title != previous:
            self._scheduleInfobarPoster(title, desc)
        self._epgNextReadAt = time.time() + 75

    def _updateEpg(self, item=None):
        """No blocking JSON parsing, EPG API or XMLTV work on the GUI thread."""
        if self._epgClosed:
            return
        now = time.time()
        if self._live_epg_context:
            self._refreshEpgProgress()
        if self.source.get("type") == "stalker":
            if now < self._epgNextRequestAt:
                return
            self._epgNextRequestAt = now + 180
            if not self._startStalkerPlayerEpg(item or self._current()):
                self._setLiveEpgLabel("epgNow", tr("No EPG data"))
                self._epgNextRequestAt = now + 60
            return
        # Xtream/M3U/other source types: one asynchronous prepared-cache
        # lookup, then provider-direct Xtream short_epg only on a miss.
        if now < self._epgNextReadAt:
            return
        self._epgNextReadAt = now + 75
        self._requestAsyncLocalEpg(item or self._current())

    def _mbcAutoAudioTrack(self):
        """MBC-only audio-track helper; reuses existing Live refresh path."""
        try:
            item = self._current() or {}
            name = str(item.get("name") or item.get("title") or "").upper()
            if "MBC" not in name:
                return
            key = str(item.get("url") or item.get("stream_id") or item.get("id") or name)
            if getattr(self, "_mbcAudioTrackKey", "") == key:
                return
            service = self.session.nav.getCurrentService()
            tracks = service and service.audioTracks()
            if not tracks:
                return
            count = int(tracks.getNumberOfTracks() or 0)
            if count <= 0:
                return
            # Prefer an explicitly Arabic track, then AAC/MPEG audio.  This is
            # deliberately MBC-only and does not alter audio on other channels.
            current = int(tracks.getCurrentTrack() or 0)
            best = None
            fallback = None
            for i in range(count):
                try:
                    info = tracks.getTrackInfo(i)
                    desc = str(info.getDescription() or "").upper().replace("_", " ")
                    lang = str(info.getLanguage() or "").upper()
                except Exception:
                    desc, lang = "", ""
                text = lang + " " + desc
                if ("ARA" in text or "ARAB" in text):
                    best = i
                    break
                if fallback is None and ("AAC" in text or "MPEG" in text or "MP2" in text or "MP3" in text):
                    fallback = i
            target = best if best is not None else fallback
            if target is None:
                target = 0
            if int(target) != current:
                tracks.selectTrack(int(target))
            self._mbcAudioTrackKey = key
        except Exception:
            pass

    def _updateClock(self):
        try:
            self["clock"].setText(time.strftime("%H:%M  %d/%m/%Y"))
            # _updateClock is also called before playService on a zap. Keep
            # codec polling and audio track switching off the startup path.
            if (getattr(self, '_liveResolvePending', False)
                    or getattr(self, '_liveStartupPending', False)
                    or not getattr(self, '_livePlaybackConfirmed', False)):
                return
            self._updateLiveTechnicalBadges()
            self._mbcAutoAudioTrack()
            fast_refresh = int(getattr(self, "_liveTechFastRefresh", 0) or 0)
            if fast_refresh > 0:
                values = getattr(self, "_liveTechBadgeValues", {}) or {}
                # Resolution + video + audio are the useful decoder fields.
                # Aspect is optional on some streams, so do not wait for it.
                complete = bool(values.get("resolution") and values.get("video") and values.get("audio"))
                self._liveTechFastRefresh = 0 if complete else max(0, fast_refresh - 1)
                if self._liveTechFastRefresh <= 0:
                    try:
                        self._clock_timer.start(10000, False)
                    except Exception:
                        pass
                # Keep the fast local badge passes isolated from EPG work.
                return
            if self._epg_ready:
                self._updateEpg()
        except Exception:
            pass

    def back(self):
        # Closing the full-screen player to browse the Live list is temporary.
        # Preserve the selected subtitle file/delay so reopening the same
        # channel can reattach it without a new search or download.
        self._preserve_live_subtitles_on_close = True
        item = self._current() or {}
        live_id = str(
            item.get("stream_id") or item.get("ch_id") or item.get("id") or
            item.get("url") or item.get("cmd") or item.get("name") or ""
        ).strip()
        # Normal Live: keep the active service when returning to the browser.
        # Favorites may explicitly request stop-on-exit.  Stopping every Live
        # service here breaks reopening/zapping after Back on some Enigma2 images.
        if getattr(self, "favorite_exit_stop", False):
            try:
                expected = getattr(self, 'current_ref', None)
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                if expected is not None and active is not None and active.toString() == expected.toString():
                    self._ultraDecoderGuard.capture(self._ultraExternalUrl)
                    self.session.nav.stopService()
                    self._ultraDecoderGuard.retire(self._ultraExternalUrl)
                    self._ultraExternalUrl = ''
            except Exception:
                pass
        # Returning from a verified playing channel permits one-OK Infobar
        # re-entry from the browser.  Carry an exact service-reference token;
        # never use a matching title/channel number alone as playback proof.
        returned_ref = ""
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            if (bool(getattr(self, "_livePlaybackConfirmed", False)) and
                    active is not None and expected is not None and
                    active.toString() == expected.toString()):
                returned_ref = active.toString()
        except Exception:
            pass
        owner = item.get("_favorite_source") if isinstance(item.get("_favorite_source"), dict) else self.source
        owner = owner or {}
        owner_key = "%s|%s|%s|%s" % (
            owner.get("type", ""),
            str(owner.get("url") or owner.get("host") or owner.get("server") or
                owner.get("portal") or "").rstrip("/"),
            owner.get("username", ""), owner.get("mac", ""))
        self.close((self.index, live_id, returned_ref, owner_key))

    def _cleanup(self):
        self._cancelPendingLiveLink()
        self._livePillClosed = True
        self._liveAttemptKey = None
        self._restoreLiveSpinner()
        # A player can close while infobar images/EPG are still in flight.
        # Cancel their UI polling and invalidate all late image completions.
        self._livePosterToken += 1
        self._livePillRequestSeq += 1
        self._livePosterResult = None
        for name in ("_livePosterTimer", "_livePosterPoll", "_livePillTimer"):
            try:
                timer = getattr(self, name, None)
                if timer is not None:
                    timer.stop()
            except Exception:
                pass
        self._cancelLiveStartup()
        self._cancelLiveResolve()
        self._epgClosed = True
        self._epgAsyncToken += 1
        try:
            self._epgAsyncPoll.stop()
            with self._epgAsyncLock:
                self._epgAsyncPending = None
                self._epgAsyncResult = None
        except Exception:
            pass
        try:
            self._liveResolveTimer.stop()
        except Exception:
            pass
        if getattr(self, "_preserve_live_subtitles_on_close", False):
            self._savePreservedLiveSubtitle()
        else:
            self._discardPreservedLiveSubtitle()
        self._clearSubsSupport()
        try:
            self._clock_timer.stop()
            self._epg_timer.stop()
            try:
                self._stalker_epg_poll.stop()
                self._stalker_epg_token += 1
            except Exception:
                pass
            try:
                self._xtream_epg_poll.stop()
                self._xtream_epg_token += 1
            except Exception:
                pass
            self._engine_timer.stop()
            self._watchdog_timer.stop()
            try:
                self._catchup_timer.stop()
            except Exception:
                pass
            self._ib_timer.stop()
            self._ib_epg_timer.stop()
        except Exception:
            pass
        # DreamOS/Python2 signal.connect() returns an eConnection which must
        # remain alive while the screen is open, then be released on close.
        # Do not leave the callback retaining the player after it exits.
        for name in ("_ib_epg_timer_connection", "_clock_timer_connection",
                     "_epg_timer_connection", "_epgAsyncPoll_connection",
                     "_stalker_epg_poll_connection", "_xtream_epg_poll_connection"):
            connection = getattr(self, name, None)
            if connection is not None:
                try:
                    connection.disconnect()
                except Exception:
                    pass
                try:
                    setattr(self, name, None)
                except Exception:
                    pass
        # Do not restore the DVB service when closing only the full-screen
        # Live player. The IPTV service must continue while browsing channels
        # and packages. MediaScreen restores the original receiver service only
        # when the user finally exits the Live section.


# Resolve the native FHD/WQHD layout only after the full player class exists.
TiviMateLivePlayer.skin = scale_skin(TiviMateLivePlayer.skin)
