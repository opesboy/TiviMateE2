# -*- coding: utf-8 -*-
"""Keep actor-scoped provider results intact across poster style switches.

Actor results are already filtered against the active server's content.  A
change of visual skin must NOT convert this virtual result into a provider
category or start a new category download.
"""

_POSTER_STYLES = ('circle', 'poster', 'genre', 'cinematic')

def _actor_person(value, name):
    if not isinstance(value, dict):
        return None
    person_id = str(value.get('id') or '').strip()
    if not person_id.isdigit() or person_id == '0':
        return None
    return {'id': person_id, 'name': name,
            'profile_path': str(value.get('profile_path') or '')}


def open_actor_results(session, source, kind, actor_name, rows, style=None, actor=None):
    from .view_style_picker import get_style, get_actor_style
    kind = 'series' if kind == 'series' else 'vod'
    entries = [dict(row) for row in (rows or ()) if isinstance(row, dict)]
    if not entries:
        return False
    from .py27_compat import text_type
    name = text_type(actor_name or u'Actor').strip() or u'Actor'
    view_source = dict(source or {})
    person = _actor_person(actor, name)
    if person is None:
        carried = view_source.get('_actor_search_person')
        if isinstance(carried, dict) and carried.get('name') == name:
            person = _actor_person(carried, name)
    if person is None:
        view_source.pop('_actor_search_person', None)
    else:
        view_source['_actor_search_person'] = person
    if style in _POSTER_STYLES or (style == 'spotlight' and person is not None):
        mode = style
    elif person is not None:
        mode = get_actor_style(kind)
    else:
        mode = get_style('actor', kind)
    view_source['_actor_search_rows'] = entries
    view_source['_actor_search_name'] = name
    view_source['_view_picker_context'] = 'actor'
    # VTi: if the results screen fails while being built, a plain
    # session.open() left the details page suspended over the TV channel with a
    # dead remote (GUI restart needed). safe_open_screen restores the page and
    # logs the real error to /home/root/tivimatee2_vti_screen_errors.log.
    from .vti_compat import safe_open_screen
    if mode == 'spotlight':
        try:
            from .actor_spotlight import ActorSpotlightScreen
            opened = safe_open_screen(session, None, ActorSpotlightScreen, view_source, kind, '')
            if opened is not None:
                return True
        except Exception as exc:
            print('[TiviMateE2Py27] Spotlight unavailable: %s' % exc)
        # A failed new screen never breaks the original working poster search.
        mode = 'poster'
    if mode == 'cinematic':
        from .cinematic_catalog import CinematicCatalogScreen
        opened = safe_open_screen(session, None, CinematicCatalogScreen, view_source, kind, '')
    elif mode == 'genre':
        from .genre_page import StandaloneGenreScreen
        opened = safe_open_screen(session, None, StandaloneGenreScreen, view_source, kind, '')
    else:
        from .ui import MediaScreen
        view_source['_view_style_override'] = 'circle' if mode == 'circle' else 'original'
        # The exact actor results are given to the original poster browser;
        # no replacement stream/catalogue fetch and no changes to its queue.
        opened = safe_open_screen(session, None, MediaScreen, view_source, kind, None, name, entries)
    if opened is None:
        try:
            from Screens.MessageBox import MessageBox
            from .py27_compat import gui_text
            safe_open_screen(session, None, MessageBox,
                             gui_text(u"Actor results could not be opened (see /home/root/tivimatee2_vti_screen_errors.log)"),
                             MessageBox.TYPE_ERROR, timeout=8)
        except Exception:
            pass
        return False
    return True
