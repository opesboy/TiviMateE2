# -*- coding: utf-8 -*-
"""Private, size-limited Stage diagnostics for Stalker on legacy VTi.

Never record URLs, MACs, tokens, cookies, channel names, credentials or
untrusted error strings. Only safe enum-like codes, integer types and the
exception class are recorded. No additional networking or worker threads.
"""
import os
import re
import threading
import time

_LOG_FILE = '/home/root/tivimatee2_stalker_vti.log'
_LOCK = threading.RLock()
_ALLOWED = re.compile(r'[^a-zA-Z0-9_]')
_NUMBER_KEYS = set(('sqlite', 'requests', 'service', 'auto', 'channels',
                    'client', 'has_client', 'link', 'startup', 'result', 'handshake', 'profile', 'token', 'categories'))
_ENUMS = {
    'engine': ('ultra', 'legacy'),
    'status': ('ok', 'empty'),
    'reason': ('none', 'cancelled', 'timeout', 'connection', 'dns',
               'network', 'auth', 'rate_limit', 'response', 'portal'),
    'stage': ('resolved_empty', 'handshake', 'profile', 'categories', 'complete'),
    'scheme': ('http', 'https', 'rtmp', 'rtsp', 'udp', 'rtp', 'other', 'unknown'),
    'format': ('m3u8', 'ts', 'other', 'unknown'),
}


def _safe(value):
    try:
        raw = str(value or '')
    except Exception:
        raw = 'unknown'
    return _ALLOWED.sub('_', raw)[:64]


def note(stage, **facts):
    return None  # r146: diagnostics off
    """Safe best-effort local logging. Never interfere with video or GUI."""
    try:
        fields = []
        for key, value in sorted(facts.items()):
            if key in _NUMBER_KEYS:
                try:
                    value = str(int(value))
                except Exception:
                    value = 'unknown'
            elif key in _ENUMS:
                value = _safe(value)
                if value not in _ENUMS[key]:
                    value = 'unknown'
            elif key == 'error':
                # Python exception class names are not error messages.
                value = _safe(value)
                if not re.match(r'^[A-Za-z_][A-Za-z0-9_]{0,63}$', value):
                    value = 'unknown'
            else:
                # Never accept an arbitrary detail such as a portal URL.
                continue
            fields.append('%s=%s' % (key, value))
        line = '%s %s %s\n' % (time.strftime('%Y-%m-%dT%H:%M:%S'), _safe(stage), ' '.join(fields))
        with _LOCK:
            if os.path.isfile(_LOG_FILE) and os.path.getsize(_LOG_FILE) > 131072:
                os.rename(_LOG_FILE, _LOG_FILE + '.old')
            with open(_LOG_FILE, 'ab') as handle:
                handle.write(line.encode('ascii'))
    except Exception:
        pass


def url_kind(url):
    """Return only a coarse format code; never print the actual URL."""
    try:
        raw = str(url or '').strip().lower()
        scheme = raw.split(':', 1)[0]
        if scheme not in ('http', 'https', 'rtmp', 'rtsp', 'udp', 'rtp'):
            scheme = 'other'
        path = raw.split('?', 1)[0].split('#', 1)[0]
        ext = 'm3u8' if path.endswith('.m3u8') else ('ts' if path.endswith('.ts') else 'other')
        return scheme, ext
    except Exception:
        return 'unknown', 'unknown'
