# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch
from Plugins.Extensions.TiviMateE2Py27.py27_compat import monotonic, thread_factory
from .movies_layout_choice import configured_movies_screen
def _content_dedupe_key(item, kind=""):
    """Stable content identity shared across pages in the same screen.

    Prefer a confirmed TMDb id. Otherwise use cleaned title+year so provider
    duplicates such as FHD/4K copies collapse even when stream ids differ.
    Fall back to provider ids only when title information is unavailable.
    """
    row = item or {}
    if isinstance(row, dict) and row.get("_keep_copy"):
        # Movie Parts / Other Sources: every provider copy stays visible.
        return "copy:%s" % (row.get("stream_id") or row.get("vod_id") or row.get("id") or row.get("cmd") or id(row))
    try:
        tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or row.get("tmdbId") or "").strip()
    except Exception:
        tmdb_id = ""
    if tmdb_id and tmdb_id not in ("0", "None", "none"):
        return "tmdb:%s:%s" % (str(kind or row.get("_search_kind") or ""), tmdb_id)
    title = text_type(row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or u"").lower().strip()
    # Remove common provider quality/language decorations before comparing.
    title = re.sub(r"[\[\(][^\]\)]*(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264|arabic|english|multi)[^\]\)]*[\]\)]", " ", title, flags=re.I)
    title = re.sub(r"(?<![a-z0-9])(?:4k|uhd|fhd|full\s*hd|1080p|2160p|720p|hdr|hevc|x265|x264)(?![a-z0-9])", " ", title, flags=re.I)
    title = re.sub(r"\s+", " ", re.sub(u'[^a-z0-9\u0600-ۿ]+', " ", title)).strip()
    year = str(row.get("year") or row.get("release_date") or row.get("releaseDate") or row.get("first_air_date") or "").strip()
    m = re.search(r"(?:19|20)\d{2}", year)
    year = m.group(0) if m else ""
    if title:
        return u"title:%s:%s:%s" % (text_type(kind or row.get("_search_kind") or u""), title, year)
    provider_id = str(row.get("series_id") or row.get("stream_id") or row.get("vod_id") or row.get("id") or "").strip()
    return "id:%s:%s" % (str(kind or row.get("_search_kind") or ""), provider_id) if provider_id else ""


def _dedupe_content_rows(items, kind=""):
    out = []
    seen = set()
    for item in list(items or []):
        key = _content_dedupe_key(item, kind)
        if key and key in seen:
            continue
        if key:
            seen.add(key)
        out.append(item)
    return out



_GENRE_SELECT_ROOT = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/genre/"


def _genre_selector_skin_native(xml):
    # Select assets matching the actual GUI desktop (not the TV output mode).
    # The VTi legacy skin parser otherwise clips a FHD JPEG instead of
    # scaling its source pixels to 1280x720.
    if sx(1920) == 1280 and sy(1080) == 720:
        xml = xml.replace(_GENRE_SELECT_ROOT + "genre_select.jpg",
                          _GENRE_SELECT_ROOT + "hd/genre_select.jpg")
        xml = xml.replace(_GENRE_SELECT_ROOT + "genre_selector.png",
                          _GENRE_SELECT_ROOT + "hd/genre_selector.png")
    return scale_skin(xml)


class TiviMateGenreSelectScreen(Screen):
    # Match FHD frame to its FHD tile; downscale the complete design as one
    # canvas on VTi 720p without changing its original focus geometry.
    skin = _genre_selector_skin_native("""
    <screen name="TiviMateGenreSelectScreen" position="0,0" size="1920,1080" flags="wfNoBorder">
        <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/genre/genre_select.jpg" alphatest="off" scale="1" zPosition="0" />
        <widget name="selector" position="58,256" size="908,607" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/genre/genre_selector.png" alphatest="blend" scale="1" zPosition="5" />
    </screen>
    """)
    def __init__(self, session, source=None, keep_open=False):
        Screen.__init__(self, session)
        self.index = 0
        self.source = dict(source or {})
        self.keep_open = bool(keep_open)
        self._pageOpenBusy = False
        self["selector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.ok,
            "cancel": self.close,
            "left": self.left,
            "right": self.right,
        }, -1)
        self.onLayoutFinish.append(self._syncSelector)

    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _syncSelector(self):
        try:
            self["selector"].instance.move(ePoint(sx(58 if self.index == 0 else 960), sy(256)))
        except Exception:
            pass


    def left(self):
        self.index = 0
        self._syncSelector()

    def right(self):
        self.index = 1
        self._syncSelector()

    def ok(self):
        selected = (tr("Movies"), "vod") if self.index == 0 else (tr("TV Shows"), "series")
        if self.keep_open and self.source:
            # Keep the two-tile selector underneath the Genre package page.
            # Back from Movies/TV Shows therefore reveals this selector
            # immediately; Back from the selector itself returns to Home.
            from .vti_compat import open_vti_page_once
            open_vti_page_once(self, MovieGenresScreen, dict(self.source), selected[1])
            return
        self.close(selected)


class TiviMateE2Search(Screen):
    skin = SEARCH_SCREEN
    PAGE_SIZE = 10
    GRID_X = [70, 315, 560, 805, 1050]
    GRID_Y = [257, 585]


    def _enrichSearchSelectionFromTmdb(self, item, kind, title, server_year, server_rating, server_overview, source_name, kind_label):
        """Fill sparse Search detail metadata from TMDb without replacing good server data."""
        if not title or kind not in ("vod", "series"):
            return
        token = u"%s:%s:%s" % (kind, text_type(title), text_type((item or {}).get("stream_id") or (item or {}).get("series_id") or u""))
        self._search_tmdb_detail_token = token

        def worker():
            try:
                raw_year = server_year or (item or {}).get("releaseDate") or (item or {}).get("release_date") or (item or {}).get("first_air_date") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                wanted_year = match.group(0) if match else None
                client = TMDbClient()
                tmdb_id = (item or {}).get("tmdb_id") or (item or {}).get("tmdb") or (item or {}).get("tmdbId")
                found = {}
                if not tmdb_id:
                    found = client.search_artwork(title, kind, wanted_year) or {}
                    tmdb_id = found.get("id")
                data = client.details_bundle(tmdb_id, kind) if tmdb_id else found
                if not isinstance(data, dict) or not data:
                    return

                def apply():
                    if getattr(self, "_search_tmdb_detail_token", None) != token:
                        return
                    current = self.current() or {}
                    current_title = current.get("name") or current.get("title") or ""
                    if text_type(current_title) != text_type(title):
                        return
                    info = merge_metadata(
                        {"title": title, "description": server_overview,
                         "year": server_year, "rating": server_rating},
                        tmdb=data, language=client.language, kind=kind)
                    extra = [info["genre"]]
                    if info["runtime"]:
                        extra.append("%s min" % info["runtime"])
                    meta = u"%s: %s   •   %s\n%s: %s\n%s: %s" % (
                        text_type(tr("Type")), text_type(kind_label), text_type(source_name), text_type(tr("Year")),
                        text_type(info["year"] or u"-"), text_type(tr("Rating")), text_type(info["rating"] or u"-")[:4])
                    if any(extra):
                        meta += u"\n" + u"   •   ".join(text_type(x) for x in extra if x)
                    self["selectedTitle"].setText(gui_text(visible_title(info["title"] or title, 67)))
                    self["selectedMeta"].setText(gui_text(meta))
                    overview = text_type(info["description"] or u"")
                    if len(overview) > 320:
                        overview = overview[:317] + u"..."
                    self["selectedOverview"].setText(gui_text(overview))
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = thread_factory(target=worker, name="TiviMateSearchDetailsTMDB")
        t.daemon = True
        t.start()


    def __init__(self, session, source):
        Screen.__init__(self, session)
        # New app session: allow Live picon caching again.
        try:
            from .estalker_picon import set_app_exiting
            set_app_exiting(False)
        except Exception:
            pass
        self._pageOpenBusy = False
        self.source = source
        self.query = ""
        self.results = []
        self._allSearchResults = []
        self.searchFilter = "all"
        self.filterIndex = 0
        self.page = 0
        self.index = 0
        self.loaders = []
        self.downloaders = []
        self._artwork_requests = {}
        self._search_slot_tokens = {}
        self._search_page_serial = 0
        self._search_selection_serial = 0
        self._detail_request = None
        self._searchGeneration = 0
        self._searchLastPublished = 0.0
        self._searchClosed = False
        # At most two outstanding network scans, even if a portal ignores a
        # socket deadline and users launch several different queries quickly.
        self._searchNetworkGate = threading.BoundedSemaphore(2)
        self.onClose.append(self._stopSearchWork)
        self.topNames = [nav_label("Home"), nav_label("Search"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("GENRE"), nav_label("Resume"), nav_label("Server Finder"), nav_label("Settings"), nav_label("Favorites")]
        self.topX = [20, 190, 360, 530, 700, 870, 1040, 1210, 1380, 1550, 1720]
        self.topW = [170] * 11
        self.topIndex = 1
        # Search opens focused on the search/content area, not the top menu.
        # With no result selected, OK opens the keyboard immediately.
        self.navFocus = "content"
        for i, name in enumerate(self.topNames):
            self["top%d" % i] = Label(name)
        self["topSelector"] = Pixmap()
        self["back"] = Label("‹")
        self["searchText"] = Label(tr("Search for a movie or series..."))
        self["mic"] = Label("◉")
        self["closeIcon"] = Label("×")
        self["moviesTitle"] = Label(tr("Search results"))
        self["showsTitle"] = Label("")
        self["filter0"] = Label("ALL")
        self["filter1"] = Label("MOVIES")
        self["filter2"] = Label("SERIES")
        self["filterSelector"] = Pixmap()
        for i in range(10):
            self["poster%d" % i] = Pixmap()
            self["posterLabel%d" % i] = Label("")
            self["posterRate%d" % i] = Label("")
        self["movieSelector"] = Pixmap()
        self["showSelector"] = Pixmap()
        self["detailPoster"] = Pixmap()
        self["selectedTitle"] = DirectionalLabel("")
        self["selectedMeta"] = Label("")
        self["selectedOverview"] = SynopsisLabel("")
        self["play"] = Label("▷  " + tr("Play"))
        self["favorite"] = Label("☆  " + tr("Add to My List"))
        self["pageInfo"] = Label("")
        self["status"] = Label(tr("Press OK to start searching"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "green": self.openKeyboard, "yellow": self.prevPage, "blue": self.nextPage,
            "yellowlong": self.addCurrentFavourite
        }, -1)
        self.onLayoutFinish.append(self.layoutReady)

    def layoutReady(self):
        self["status"].setText(tr("Press OK to start searching"))
        self._updateSearchTopFocus()
        try:
            self["movieSelector"].hide(); self["showSelector"].hide()
            self["detailPoster"].hide()
            for i in range(10):
                self["poster%d" % i].hide()
                self["posterLabel%d" % i].hide()
                self["posterRate%d" % i].hide()
        except Exception:
            pass
        self._updateFilterFocus()


    def _updateSearchTopFocus(self):
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
            self["topSelector"].setVisible(self.navFocus == "top")
        except Exception:
            pass


    def _updateFilterFocus(self):
        try:
            xs = [530, 730, 930]
            self["filterSelector"].instance.move(ePoint(sx(xs[self.filterIndex]), sy(234)))
            self["filterSelector"].setVisible(self.navFocus == "filter")
        except Exception:
            pass

    def _stopSearchWork(self):
        # Invalidate late replies and poster selection from any previous search.
        self._searchClosed = True
        self._searchGeneration += 1
        self._search_tmdb_detail_token = None

    def _applySearchFilter(self, preserve_selection=False):
        previous = self.current() if preserve_selection and self.results else None
        previous_id = None
        if previous:
            previous_id = (str(previous.get("_search_source_key") or ""),
                           str(previous.get("_search_kind") or ""),
                           str(previous.get("stream_id") or previous.get("series_id") or previous.get("id") or ""),
                           str(previous.get("name") or previous.get("title") or ""))
        rows = list(getattr(self, "_allSearchResults", []) or [])
        if self.searchFilter == "movies":
            rows = [x for x in rows if (x or {}).get("_search_kind") == "vod"]
        elif self.searchFilter == "series":
            rows = [x for x in rows if (x or {}).get("_search_kind") == "series"]
        # Alphabetical results are stable across cache/server progressive updates.
        # Titles beginning with the typed letters always come first; within each
        # group sort A-Z (or Arabic letters), not by provider/network arrival.
        query = str(getattr(self, 'query', '') or '').strip().lower()
        def alpha_title(row):
            raw = str((row or {}).get('name') or (row or {}).get('title') or '').strip()
            # Ignore provider quality/language labels at the START of the name.
            clean = re.sub(r'^(?:(?:\[[^\]]{1,24}\]|\([^)]{1,24}\)|(?:4K|UHD|FHD|HD|AR|EN)\s*[:|\-])\s*)+', '', raw, flags=re.I)
            return ' '.join((clean or raw).lower().split())
        rows.sort(key=lambda row: (0 if query and alpha_title(row).startswith(query) else 1,
                                   alpha_title(row),
                                   str((row or {}).get('_search_kind') or ''),
                                   str((row or {}).get('stream_id') or (row or {}).get('series_id') or '')))
        self.results = rows
        selected_at = 0
        if previous_id:
            for at, row in enumerate(rows):
                identity = (str(row.get("_search_source_key") or ""),
                            str(row.get("_search_kind") or ""),
                            str(row.get("stream_id") or row.get("series_id") or row.get("id") or ""),
                            str(row.get("name") or row.get("title") or ""))
                if identity == previous_id:
                    selected_at = at
                    break
        self.page = selected_at // self.PAGE_SIZE
        self.index = selected_at % self.PAGE_SIZE
        self.renderPage()

    def _startSearchWithoutLoading(self, reset=False):
        # Do not display a blocking Searching... state: cached matches arrive
        # first and additional package matches are appended as they finish.
        self._searchGeneration += 1
        generation = self._searchGeneration
        self._searchLastPublished = 0.0
        if reset:
            self._allSearchResults = []
            self.results = []
            self.page = 0
            self.index = 0
        self._applySearchFilter(preserve_selection=not reset)
        if not self.results:
            self["status"].setText("No cached matches yet")
        thread = thread_factory(target=self._worker,
                                  args=(generation, self.query, self.searchFilter),
                                  name="TiviMateSearchCacheFirst")
        thread.daemon = True
        thread.start()

    def _selectFilter(self, index):
        self.filterIndex = max(0, min(2, int(index)))
        self.searchFilter = ("all", "movies", "series")[self.filterIndex]
        self._updateFilterFocus()
        # The existing matches are filtered immediately. A background refresh
        # may add missing matching rows; do not clear them and show Loading.
        if self.query:
            self._startSearchWithoutLoading(reset=False)
        elif getattr(self, "_allSearchResults", None):
            self._applySearchFilter()

    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        # VTi: preserve the real failure when a child screen cannot be opened.
        from .vti_compat import open_vti_page_once
        return open_vti_page_once(self, screen, *args)


    def _openSearchTop(self):
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 1:
            self.navFocus = "content"; self._updateSearchTopFocus(); self.openKeyboard(); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.source, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, "vod"), self.source, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, "series"), self.source, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.source); return
        if self.topIndex == 6:
            self._openSearchGenre(); return
        if self.topIndex == 7:
            self._openPageOnce(ContinueWatchingScreen, self.source); return
        if self.topIndex == 8:
            self._openPageOnce(TiviMateE2IPTVFinder); return
        if self.topIndex == 9:
            self._openPageOnce(SettingsDashboard); return
        if self.topIndex == 10:
            self._openPageOnce(FavoritesScreen); return
    def _openSearchGenre(self):
        choices = [(tr("Movies"), "vod"), (tr("TV Shows"), "series")]
        self.session.openWithCallback(self._openSearchGenreSelected, TiviMateGenreSelectScreen)

    def _openSearchGenreSelected(self, selected=None):
        if not selected or not self.source:
            return
        kind = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if kind in ("vod", "series"):
            self._openPageOnce(MovieGenresScreen, dict(self.source), kind)


    def addTmdbKey(self):
        # Import from a local text/key/config file.  The built-in shared key and
        # any previously saved private key are never displayed on screen.
        self.session.openWithCallback(self.tmdbKeyEntered, TMDbKeyImportBrowser, "/")

    def tmdbKeyEntered(self, value=None):
        if value is None:
            return
        self.customTmdbKey.value = (value or "").strip()
        try:
            self["hint"].setText("Custom TMDb key ready. Press GREEN to save.")
        except Exception:
            pass

    def openKeyboard(self):
        try:
            self.session.openWithCallback(self.searchReady, VirtualKeyBoard, title="Search", text=self.query)
        except RuntimeError:
            self["status"].setText(tr("Press OK again to open the search keyboard"))

    def searchReady(self, value=None):
        if value is None:
            if not self.query:
                self.close()
            return
        new_query = (value or "").strip()
        changed = new_query != self.query
        self.query = new_query
        self["searchText"].setText(self.query or tr("Search for a movie or series..."))
        if not self.query:
            self._searchGeneration += 1
            self._allSearchResults = []
            self.results = []
            self.renderPage()
            return
        self._startSearchWithoutLoading(reset=changed)

    def _tag(self, rows, kind):
        out = []
        for item in rows:
            try:
                row = dict(item or {})
            except Exception:
                row = item or {}
            row["_search_kind"] = kind
            out.append(row)
        return out

    def _strictFilteredSearchRows(self, kind, client, source=None, on_progress=None, deadline=None, cancelled=None):
        """Return rows ONLY from packages explicitly selected for ``source``.

        Movies (vod) and Series have independent filter scopes. There is deliberately
        no provider-wide fallback: an unselected package is never queried by Search.
        ``source`` is explicit so Multi-Portal Search can respect each portal's own
        package filter instead of accidentally reusing the currently-open portal.
        """
        if kind not in ("vod", "series"):
            return []
        src = source or self.source
        allowed = get_allowed_category_ids(src, kind)
        # Strict means explicit selection is required. None/no selection must not
        # silently turn into "search the whole server".
        if not allowed:
            return []

        allowed = set(str(x) for x in allowed if str(x))
        if not allowed:
            return []

        # Preserve the user's filtered package order when category metadata is available.
        ordered_ids = []
        try:
            categories, _origin = get_cached_categories(
                src, kind, client=client, wait_for_server=False
            )
            for row in categories or []:
                cid = str((row or {}).get("category_id") or "")
                if cid and cid in allowed and cid not in ordered_ids:
                    ordered_ids.append(cid)
        except Exception:
            pass
        for cid in allowed:
            if cid not in ordered_ids:
                ordered_ids.append(cid)

        output = []
        seen = set()
        for cid in ordered_ids:
            if (deadline is not None and monotonic() >= deadline) or (cancelled and cancelled()):
                break
            try:
                rows, _origin = get_category_streams(
                    src, kind, client, cid,
                    use_cache=True, wait_for_server=True
                )
            except Exception:
                rows = []
            for item in rows or []:
                if not isinstance(item, dict):
                    continue
                # Extra guard against broken portals returning cross-package rows.
                item_cid = str(
                    item.get("category_id") or item.get("categoryId") or
                    item.get("genre_id") or item.get("genre-id") or ""
                )
                if item_cid and item_cid not in allowed:
                    continue
                unique = _content_dedupe_key(item, kind)
                if unique and unique in seen:
                    continue
                if unique:
                    seen.add(unique)
                output.append(item)
            if on_progress:
                on_progress(kind, output)
        return output

    def _searchSourceName(self, source):
        src = source or {}
        return str(src.get("name") or src.get("title") or src.get("portal") or src.get("url") or "Stalker")

    def _attachSearchSource(self, rows, source, kind):
        out = []
        src = dict(source or {})
        src_key = _source_identity(src)
        src_name = self._searchSourceName(src)
        for item in rows or []:
            try:
                row = dict(item or {})
            except Exception:
                continue
            row["_search_kind"] = kind
            row["_search_source"] = src
            row["_search_source_key"] = src_key
            row["_search_source_name"] = src_name
            out.append(row)
        return out

    def _itemSearchSource(self, item):
        src = (item or {}).get("_search_source")
        return src if isinstance(src, dict) and src else self.source

    def _dedupeSearchRows(self, items):
        # Keep one clean copy per portal. The same movie on Portal A and Portal B
        # must remain visible because playback credentials/source are different.
        out = []
        seen = set()
        for item in list(items or []):
            base = _content_dedupe_key(item, (item or {}).get("_search_kind", ""))
            src_key = str((item or {}).get("_search_source_key") or _source_identity(self.source))
            key = "%s|%s" % (src_key, base) if base else "%s|id:%s" % (src_key, id(item))
            if key in seen:
                continue
            seen.add(key)
            out.append(item)
        return out

    def _searchOneStalkerPortal(self, source, query, per_portal_limit=50, search_filter="all"):
        q = text_type(query or u"").strip().lower()
        client = StalkerClient(source)

        def match(rows):
            out = []
            for x in (rows or []):
                row = x or {}
                searchable = u" ".join(text_type(row.get(k) or u"") for k in (
                    "name", "title", "year", "release_date", "releaseDate",
                    "first_air_date", "added", "last_modified"
                )).lower()
                if q in searchable:
                    out.append(x)
            return out

        movie_ids = get_allowed_category_ids(source, "vod") or []
        series_ids = get_allowed_category_ids(source, "series") or []
        # A year such as 2026 is metadata, not necessarily part of the title.
        # Search the selected package rows locally for year queries so ALL /
        # MOVIES / SERIES can reuse the same complete result set instantly.
        year_query = bool(py27_fullmatch(r"(?:19|20)\d{2}", q))
        want_movies = search_filter in ("all", "movies")
        want_series = search_filter in ("all", "series")
        movies = []
        shows = []
        if want_movies:
            movies_native = None if year_query else client.search_filtered_media_native("vod", query, movie_ids, limit=per_portal_limit)
            movies_all = self._strictFilteredSearchRows("vod", client, source) if movies_native is None else movies_native
            movies = match(movies_all)[:per_portal_limit]
        if want_series:
            shows_native = None if year_query else client.search_filtered_media_native("series", query, series_ids, limit=per_portal_limit)
            shows_all = self._strictFilteredSearchRows("series", client, source) if shows_native is None else shows_native
            shows = match(shows_all)[:per_portal_limit]
        return self._attachSearchSource(movies, source, "vod") + self._attachSearchSource(shows, source, "series")

    def _searchCacheRows(self, source, kind):
        """Read only selected-package RAM/HDD snapshots; never call network."""
        from .filters import peek_filtered_streams_cache
        allowed = get_allowed_category_ids(source, kind)
        if not allowed:
            return []
        allowed = set(str(cid) for cid in allowed)
        rows, _origin = peek_filtered_streams_cache(source, kind)
        return [row for row in rows if isinstance(row, dict) and
                (not str(row.get("category_id") or row.get("categoryId") or
                         row.get("genre_id") or "") or
                 str(row.get("category_id") or row.get("categoryId") or
                     row.get("genre_id") or "") in allowed)]

    def _partialSearchGeneration(self, generation, results):
        if generation != self._searchGeneration or self._searchClosed:
            return
        rows = self._dedupeSearchRows(results or [])[:500]
        # Avoid needlessly re-decoding all visible posters on an identical
        # partial update. Preserve the currently highlighted movie/series.
        old = [(r.get("_search_source_key"), r.get("_search_kind"),
                r.get("stream_id") or r.get("series_id") or r.get("id"))
               for r in self._allSearchResults]
        new = [(r.get("_search_source_key"), r.get("_search_kind"),
                r.get("stream_id") or r.get("series_id") or r.get("id"))
               for r in rows]
        if old == new:
            return
        self._allSearchResults = rows
        self._applySearchFilter(preserve_selection=True)

    def _worker(self, generation, query, search_filter=None):
        """Cache-first, progressive search: no UI waits, no progress spinner."""
        try:
            q = text_type(query or u"").strip().lower()
            search_filter = search_filter or self.searchFilter
            source = dict(self.source)
            stype = source.get("type")
            kinds = (["vod"] if search_filter == "movies" else
                     ["series"] if search_filter == "series" else
                     ["vod", "series"])
            matches = {"vod": [], "series": []}
            deadline = monotonic() + 12.0

            def match(rows):
                # Search titles by the letters at the START of the name first.
                # Keep partial matches afterwards so existing searches remain useful.
                starts, others = [], []
                for item in rows or []:
                    row = item or {}
                    title = text_type(row.get("name") or row.get("title") or u"").strip().lower()
                    searchable = u" ".join(text_type(row.get(k) or u"") for k in
                                          ("name", "title", "year", "release_date",
                                           "releaseDate", "first_air_date", "added", "last_modified")).lower()
                    if title.startswith(q):
                        starts.append(row)
                    elif q in searchable:
                        others.append(row)
                return starts + others

            def combined():
                return self._dedupeSearchRows(matches["vod"] + matches["series"])[:500]

            def publish(force=False):
                if generation != self._searchGeneration or self._searchClosed:
                    return
                now = monotonic()
                if not force and now - self._searchLastPublished < 0.7:
                    return
                self._searchLastPublished = now
                result = list(combined())
                if reactor:
                    reactor.callFromThread(self._partialSearchGeneration, generation, result)
                else:
                    self._partialSearchGeneration(generation, result)

            # Always paint existing verified package caches before touching
            # a portal. Empty cache is not treated as successful search data.
            if stype in ("xtream", "stalker"):
                for kind in kinds:
                    if generation != self._searchGeneration:
                        return
                    local = match(self._searchCacheRows(source, kind))
                    matches[kind] = (self._attachSearchSource(local, source, kind)
                                     if stype == "stalker" else self._tag(local, kind))
                publish(force=True)

            if not self._searchNetworkGate.acquire(False):
                # Busy portals must not queue an unbounded number of network
                # threads. The new search still displays its cached results.
                if reactor:
                    reactor.callFromThread(self._readySearchGeneration, generation, combined())
                else:
                    self._readySearchGeneration(generation, combined())
                return
            try:
                if stype == "stalker":
                    # Keep the native portal search scoped to the one active source.
                    # No automatic scanning of every configured portal.
                    rows = self._searchOneStalkerPortal(
                        source, query, per_portal_limit=50, search_filter=search_filter)
                    for kind in kinds:
                        fresh = [row for row in rows if row.get("_search_kind") == kind]
                        matches[kind] = self._dedupeSearchRows(matches[kind] + fresh)
                    publish(force=True)
                elif stype == "xtream":
                    client = XtreamClient(source)
                    for kind in kinds:
                        if generation != self._searchGeneration or monotonic() >= deadline:
                            break
                        def progress(_kind, scanned):
                            if generation != self._searchGeneration:
                                return
                            new_rows = self._tag(match(scanned), _kind)
                            matches[_kind] = self._dedupeSearchRows(matches[_kind] + new_rows)
                            publish()
                        rows = self._strictFilteredSearchRows(
                            kind, client, source, on_progress=progress, deadline=deadline,
                            cancelled=lambda: generation != self._searchGeneration or self._searchClosed)
                        matches[kind] = self._dedupeSearchRows(
                            matches[kind] + self._tag(match(rows), kind))
                        publish(force=True)
            finally:
                self._searchNetworkGate.release()
            if generation != self._searchGeneration:
                return
            if reactor:
                reactor.callFromThread(self._readySearchGeneration, generation, combined())
            else:
                self._readySearchGeneration(generation, combined())
        except Exception as exc:
            if generation != self._searchGeneration:
                return
            if reactor:
                reactor.callFromThread(self._failedSearchGeneration, generation, str(exc))
            else:
                self._failedSearchGeneration(generation, str(exc))

    def _readySearchGeneration(self, generation, results):
        if (getattr(self, "_searchClosed", False) or
                generation != int(getattr(self, "_searchGeneration", 0) or 0)):
            return
        self._ready(results)

    def _failedSearchGeneration(self, generation, err):
        if (getattr(self, "_searchClosed", False) or
                generation != int(getattr(self, "_searchGeneration", 0) or 0)):
            return
        self._failed(err)

    def _failed(self, err):
        # Keep any cached matches visible when a remote server is unavailable.
        self["status"].setText("%d results" % len(self.results) if self.results else "No cached results available")

    def short_title(self, item):
        return visible_title((item or {}).get("name") or (item or {}).get("title") or "", 30)

    def _ready(self, results):
        new_rows = self._dedupeSearchRows(results or [])
        def identities(rows):
            return [(r.get("_search_source_key"), r.get("_search_kind"),
                     r.get("stream_id") or r.get("series_id") or r.get("id"))
                    for r in rows]
        # No needless poster repaint on final completion of the same results.
        if identities(self._allSearchResults) != identities(new_rows):
            self._allSearchResults = new_rows
            self._applySearchFilter(preserve_selection=True)
        if not self.results:
            self["status"].setText("No matches found")

    def pageItems(self):
        start = self.page * self.PAGE_SIZE
        return self.results[start:start + self.PAGE_SIZE]

    def pageCount(self):
        if not self.results:
            return 1
        return (len(self.results) + self.PAGE_SIZE - 1) // self.PAGE_SIZE

    def renderPage(self):
        items = self.pageItems()
        self._search_page_serial += 1
        self._search_slot_tokens = {}
        self._artwork_requests = {}
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster/poster_placeholder.png")
        for i in range(10):
            try:
                self["poster%d" % i].hide()
                self["posterLabel%d" % i].hide()
                self["posterRate%d" % i].hide()
            except Exception:
                pass
        for i, item in enumerate(items):
            self._search_slot_tokens[i] = (self._search_page_serial, self.page * self.PAGE_SIZE + i)
            try:
                self["poster%d" % i].instance.setPixmapFromFile(placeholder)
                self["poster%d" % i].show()
                self["posterLabel%d" % i].setText(self.short_title(item))
                rating = item.get("rating") or item.get("rating_5based") or item.get("vote_average") or ""
                self["posterRate%d" % i].setText(str(rating)[:4])
                self["posterLabel%d" % i].show()
                self["posterRate%d" % i].show()
            except Exception:
                pass
            self.loadImage(i, item.get("stream_icon") or item.get("cover") or item.get("poster_path") or "", item)
        # Search artwork remains strictly on the visible page (10 cards).
        # Do not request another 10 posters before the user navigates there.
        self.index = min(self.index, max(0, len(items) - 1))
        total = len(self.results)
        self["moviesTitle"].setText("%s: %s" % (tr("Search results"), self.query))
        self["showsTitle"].setText("%d %s" % (total, tr("results")))
        self["pageInfo"].setText("‹   %s %d / %d   ›" % (tr("Page"), self.page + 1, self.pageCount()))
        self["status"].setText("%d %s" % (total, tr("results")))
        self.updateSelection()

    def current(self):
        items = self.pageItems()
        return items[self.index] if items and self.index < len(items) else None

    def currentGlobalIndex(self):
        return self.page * self.PAGE_SIZE + self.index

    def updateSelection(self):
        self._search_selection_serial += 1
        items = self.pageItems()
        if not items:
            try:
                self["movieSelector"].hide(); self["showSelector"].hide(); self["detailPoster"].hide()
            except Exception:
                pass
            self["selectedTitle"].setText("")
            self["selectedMeta"].setText("")
            self["selectedOverview"].setText("")
            return
        self.index = min(self.index, len(items) - 1)
        col = self.index % 5
        row = self.index // 5
        x = self.GRID_X[col]
        y = self.GRID_Y[row]
        try:
            self["showSelector"].hide()
            self["movieSelector"].instance.move(ePoint(sx(x), sy(y)))
            self["movieSelector"].show()
        except Exception:
            pass
        item = self.current() or {}
        title = item.get("name") or item.get("title") or ""
        year = item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or ""
        if isinstance(year, str) and len(year) >= 4:
            year = year[:4]
        rating = item.get("rating") or item.get("rating_5based") or item.get("vote_average") or "-"
        kind = item.get("_search_kind", "vod")
        kind_label = tr("TV Show") if kind == "series" else (tr("Channel") if kind == "live" else tr("Movie"))
        self["selectedTitle"].setText(gui_text(visible_title(title, 67) if kind != "live" else text_type(title)))
        result_source = self._itemSearchSource(item)
        source_name = self._searchSourceName(result_source)
        meta = u"%s: %s   •   %s\n%s: %s\n%s: %s" % (
            text_type(tr("Type")), text_type(kind_label), text_type(source_name),
            text_type(tr("Year")), text_type(year or u"-"),
            text_type(tr("Rating")), text_type(rating))
        self["selectedMeta"].setText(gui_text(meta))
        overview = text_type(item.get("plot") or item.get("description") or item.get("overview") or u"")
        if len(overview) > 220:
            overview = overview[:217] + u"..."
        self["selectedOverview"].setText(gui_text(overview))
        # Keep provider/server metadata first, then fill only missing fields from TMDb.
        # This is asynchronous so moving across search results never blocks the UI.
        if kind in ("vod", "series"):
            self._enrichSearchSelectionFromTmdb(item, kind, title, year, rating, overview, source_name, kind_label)
        self["favorite"].setText(("★  " + tr("Remove from My List")) if is_favourite(result_source, kind, item) else ("☆  " + tr("Add to My List")))
        detail_url = item.get("stream_icon") or item.get("cover") or item.get("poster_path") or ""
        try:
            self["detailPoster"].show()
        except Exception:
            pass
        self.loadDetailImage(detail_url, item)

    def left(self):
        if self.navFocus == "filter":
            self._selectFilter(self.filterIndex - 1)
            return
        if self.navFocus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateSearchTopFocus()
            return
        if not self.results:
            return
        if self.index > 0:
            self.index -= 1
            self.updateSelection()
        elif self.page > 0:
            self.page -= 1
            self.index = min(self.PAGE_SIZE - 1, len(self.pageItems()) - 1)
            self.renderPage()

    def right(self):
        if self.navFocus == "filter":
            self._selectFilter(self.filterIndex + 1)
            return
        if self.navFocus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateSearchTopFocus()
            return
        items = self.pageItems()
        if not items:
            return
        if self.index < len(items) - 1:
            self.index += 1
            self.updateSelection()
        elif self.page < self.pageCount() - 1:
            self.page += 1
            self.index = 0
            self.renderPage()

    def up(self):
        if self.navFocus == "top":
            return
        if self.navFocus == "filter":
            self.navFocus = "top"
            self._updateSearchTopFocus(); self._updateFilterFocus()
            return
        if self.index >= 5:
            self.index -= 5
            self.updateSelection()
        else:
            self.navFocus = "filter"
            self._updateSearchTopFocus(); self._updateFilterFocus()


    def down(self):
        if self.navFocus == "top":
            self.navFocus = "filter"
            self._updateSearchTopFocus(); self._updateFilterFocus()
            return
        if self.navFocus == "filter":
            self.navFocus = "content"
            self._updateFilterFocus()
            return
        items = self.pageItems()
        candidate = self.index + 5
        if candidate < len(items):
            self.index = candidate
            self.updateSelection()


    def prevPage(self):
        if self.page > 0:
            self.page -= 1
            self.index = 0
            self.renderPage()

    def nextPage(self):
        if self.page < self.pageCount() - 1:
            self.page += 1
            self.index = 0
            self.renderPage()

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        kind = item.get("_search_kind", "vod")
        result_source = self._itemSearchSource(item)
        added, saved = toggle_favourite(result_source, kind, item)
        if not saved:
            self["status"].setText(tr("Unable to save favorite"))
        elif added:
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Removed from favorites"))
        self.updateSelection()

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            return
        kind = item.get("_search_kind", "vod")
        if kind not in ("vod", "series"):
            return
        result_source = self._itemSearchSource(item)
        if is_favourite(result_source, kind, item):
            self["status"].setText(tr("Item is already in favorites"))
        elif add_favourite(result_source, kind, item):
            self["status"].setText(tr("Added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))
        self.updateSelection()

    def ok(self):
        if self.navFocus == "top":
            self._openSearchTop()
            return
        if self.navFocus == "filter":
            self._selectFilter(self.filterIndex)
            if not self.query:
                self.openKeyboard()
            return
        item = self.current()
        if not item:
            self.openKeyboard()
            return
        kind = item.get("_search_kind", "vod")
        result_source = self._itemSearchSource(item)
        if kind == "live":
            rows = [x for x in self.results if x.get("_search_kind") == "live"]
            idx = 0
            try:
                idx = rows.index(item)
            except Exception:
                pass
            self.session.open(TiviMateLivePlayer, result_source, rows, idx)
            return
        if kind == "series":
            self.session.open(SeriesDetailsScreen, result_source, item)
            return
        if result_source.get("type") == "stalker":
            # Portal login + create_link off the GUI thread (no freeze on OK).
            if getattr(self, "_vodResolving", False):
                return
            self._vodResolving = True
            src = dict(result_source)

            def done(url, item=item, src=src):
                self._vodResolving = False
                self._playSearchMovie(src, item, url)

            def failed(exc):
                self._vodResolving = False
                self.session.open(MessageBox, "Unable to resolve a playable movie URL.\n%s" % exc, MessageBox.TYPE_ERROR)
            from .bg_resolve import resolve_async
            resolve_async(lambda: StalkerClient(src).stream_url(item, "vod"), done, failed)
            return
        ext = item.get("container_extension") or result_source.get("output", "ts")
        url = "%s/movie/%s/%s/%s.%s" % (result_source.get("url", "").rstrip("/"), result_source.get("username", ""), result_source.get("password", ""), item.get("stream_id", ""), ext)
        self._playSearchMovie(result_source, item, url)

    def _playSearchMovie(self, result_source, item, url):
        if not url:
            self.session.open(MessageBox, "Unable to resolve a playable movie URL.", MessageBox.TYPE_ERROR)
            return
        play_item = dict(item or {})
        play_item["_source_type"] = result_source.get("type", "")
        play_item["_source_key"] = _source_identity(result_source)
        play_item["_kind"] = "vod"
        service_type = int(_media_service_type(result_source, "vod"))
        self.session.open(TiviMatePlayer, eServiceReference(service_type, 0, url), play_item)

    def _searchPosterFileUsable(self, path):
        return usable_poster_file(path, minimum_bytes=1024)

    def _searchPosterFallback(self, slot, item, detail=False):
        item = item or {}
        kind = item.get("_search_kind", "vod")
        if kind not in ("vod", "series"):
            return
        title = item.get("name") or item.get("title") or item.get("original_title") or ""
        if not title:
            return
        token = "tmdb:%s:%s:%s" % (kind, slot, str(title))
        expected_slot = self._search_slot_tokens.get(slot)
        expected_selection = self._search_selection_serial
        if detail:
            self._detail_request = token
        else:
            self._artwork_requests[slot] = token

        def worker():
            try:
                raw_year = item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                found = TMDbClient().search_artwork(title, kind, year, required_key="poster_path") or {}
                poster = found.get("poster_path") or ""
                if not poster:
                    return
                url = poster if str(poster).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(poster)

                def apply():
                    if detail:
                        if (getattr(self, "_detail_request", None) != token or
                                self._search_selection_serial != expected_selection):
                            return
                        self.loadDetailImage(url, item, allow_fallback=False)
                    else:
                        if (getattr(self, "_artwork_requests", {}).get(slot) != token or
                                self._search_slot_tokens.get(slot) != expected_slot):
                            return
                        self.loadImage(slot, url, item, allow_fallback=False)

                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = thread_factory(target=worker, name="TiviMateSearchPosterTMDB")
        t.daemon = True
        t.start()

    def loadImage(self, slot, url, item=None, allow_fallback=True):
        if allow_fallback and isinstance(item, dict) and item.get('_search_kind', 'vod') in ('vod', 'series'):
            from .shared_genre_posters import request_genre_poster
            token = self._search_slot_tokens.get(slot)
            source = dict(self._itemSearchSource(item) or {})
            # Token belongs to this slot AND the current page. Do not let a
            # stale provider/TMDb request repaint the next search page.
            self._artwork_requests[slot] = ('shared-genre', token)
            def valid():
                return (getattr(self, '_search_slot_tokens', {}).get(slot) != token or
                        getattr(self, '_artwork_requests', {}).get(slot) != ('shared-genre', token))
            def resolved(path, winner):
                if valid():
                    return
                self.decode(slot, path)
                if slot == self.index:
                    self._detail_request = ('shared-genre', self._search_selection_serial)
                    self.decodeDetail(path)
            if request_genre_poster(source, item, item.get('_search_kind', 'vod'),
                                    resolved, cancelled=valid, primary=url):
                return
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            if allow_fallback and item is not None:
                self._searchPosterFallback(slot, item, detail=False)
            return
        self._artwork_requests[slot] = url
        expected_slot = self._search_slot_tokens.get(slot)

        def done(path, s=slot, expected=url, fallback_item=item):
            if (getattr(self, "_artwork_requests", {}).get(s) != expected or
                    self._search_slot_tokens.get(s) != expected_slot):
                return
            if not self._searchPosterFileUsable(path):
                if allow_fallback and fallback_item is not None:
                    self._searchPosterFallback(s, fallback_item, detail=False)
                return
            self.decode(s, path)
            try:
                if s == self.index:
                    self._detail_request = expected
                    self.decodeDetail(path)
            except Exception:
                pass

        def failed(_path, s=slot, fallback_item=item):
            if (self._search_slot_tokens.get(s) == expected_slot and
                    self._artwork_requests.get(s) == url and
                    allow_fallback and fallback_item is not None):
                self._searchPosterFallback(s, fallback_item, detail=False)

        cached = cached_artwork(url, "posters")
        if cached and self._searchPosterFileUsable(cached):
            done(cached)
        else:
            # Visible first row takes precedence; second row is lower priority.
            request_artwork(url, "posters", done, priority=(95 if slot < 5 else 65), errback=failed,
                            source=dict(self._itemSearchSource(item) or {}))

    def loadDetailImage(self, url, item=None, allow_fallback=True):
        if allow_fallback and isinstance(item, dict) and item.get('_search_kind', 'vod') in ('vod', 'series'):
            from .shared_genre_posters import request_genre_poster
            serial = self._search_selection_serial
            source = dict(self._itemSearchSource(item) or {})
            self._detail_request = ('shared-genre', serial)
            def stale():
                return (getattr(self, '_search_selection_serial', -1) != serial or
                        getattr(self, '_detail_request', None) != ('shared-genre', serial))
            def resolved(path, winner):
                if not stale():
                    self.decodeDetail(path)
            if request_genre_poster(source, item, item.get('_search_kind', 'vod'),
                                    resolved, cancelled=stale, primary=url):
                return
        url = (url or "").strip().replace("\\/", "/")
        placeholder = os.path.join(PLUGIN_PATH, "skins", "poster/poster_placeholder.png")
        try:
            self["detailPoster"].instance.setPixmapFromFile(placeholder)
        except Exception:
            pass
        if not url:
            if allow_fallback and item is not None:
                self._searchPosterFallback(self.index, item, detail=True)
            return
        self._detail_request = url
        expected_selection = self._search_selection_serial

        def done(path, expected=url, fallback_item=item):
            if (getattr(self, "_detail_request", None) != expected or
                    self._search_selection_serial != expected_selection):
                return
            if not self._searchPosterFileUsable(path):
                if allow_fallback and fallback_item is not None:
                    self._searchPosterFallback(self.index, fallback_item, detail=True)
                return
            self.decodeDetail(path)

        def failed(_path, fallback_item=item):
            if (self._detail_request == url and
                    self._search_selection_serial == expected_selection and
                    allow_fallback and fallback_item is not None):
                self._searchPosterFallback(self.index, fallback_item, detail=True)

        cached = cached_artwork(url, "posters")
        if cached and self._searchPosterFileUsable(cached):
            done(cached)
        else:
            request_artwork(url, "posters", done, priority=95, errback=failed,
                            source=dict(self._itemSearchSource(item) or {}))

    def decode(self, slot, path):
        expected_slot = self._search_slot_tokens.get(slot)
        expected_request = self._artwork_requests.get(slot)
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, s=slot, ll=loader):
            try:
                if (self._search_slot_tokens.get(s) != expected_slot or
                        self._artwork_requests.get(s) != expected_request):
                    return
                ptr = ll.getData()
                widget = self["poster%d" % s]
                if ptr and widget.instance:
                    widget.instance.setPixmap(ptr)
                    widget.show()
            except Exception:
                pass
            finally:
                try:
                    if ll in self.loaders:
                        self.loaders.remove(ll)
                except Exception:
                    pass
        connect_picture_data(loader, ready, self, oneshot=True)
        render_width, render_height = scale_size(200, 285)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def decodeDetail(self, path):
        expected_selection = self._search_selection_serial
        expected_request = self._detail_request
        loader = ePicLoad()
        self.loaders.append(loader)
        def ready(_=None, ll=loader):
            try:
                if (self._search_selection_serial != expected_selection or
                        self._detail_request != expected_request):
                    return
                ptr = ll.getData()
                if ptr and self["detailPoster"].instance:
                    self["detailPoster"].instance.setPixmap(ptr)
                    self["detailPoster"].show()
            except Exception:
                pass
            finally:
                try:
                    if ll in self.loaders:
                        self.loaders.remove(ll)
                except Exception:
                    pass
        connect_picture_data(loader, ready, self, oneshot=True)
        render_width, render_height = scale_size(215, 305)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)



HOME_SERVER_POPUP_SKIN = r"""
<screen name="HomeServerPopup" position="600,315" size="720,450" flags="wfNoBorder" backgroundColor="#101820" title="Select Server">
    <ePixmap position="0,0" size="720,450" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/server/server_popup_bg_r182.png" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="title" position="42,30" size="636,52" font="Regular;32" foregroundColor="#F5E5C6" backgroundColor="#101820" transparent="1" zPosition="3"/>
    <widget name="subtitle" position="42,83" size="636,34" font="Regular;19" foregroundColor="#AEB9C5" backgroundColor="#101820" transparent="1" zPosition="3"/>
    <widget name="servers" position="42,135" size="636,228" scrollbarMode="showOnDemand" zPosition="4"/>
    <widget name="hint" position="42,386" size="636,34" font="Regular;18" foregroundColor="#91A1AF" backgroundColor="#101820" transparent="1" halign="center" zPosition="3"/>
</screen>
"""

class HomeServerChoiceList(MenuList):
    # Reuse the exact Xtream/Stalker artwork from Live -> YELLOW server switch.
    TYPE_PIXMAPS = {
        "xtream": os.path.join(PLUGIN_PATH, "skins/server/live_switch_xtream.png"),
        "stalker": os.path.join(PLUGIN_PATH, "skins/server/live_switch_stalker.png"),
        "m3u": os.path.join(PLUGIN_PATH, "skins/server/icon_m3u_r123.png"),
    }
    STATUS_PIXMAPS = {
        "online": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_green.png"),
        "offline": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "checking": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_grey.png"),
    }

    def __init__(self, sources, states, active_key):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        self._type_pixmaps = {}
        self._status_pixmaps = {}
        for key, path in self.TYPE_PIXMAPS.items():
            try: self._type_pixmaps[key] = LoadPixmap(path)
            except Exception: self._type_pixmaps[key] = None
        for key, path in self.STATUS_PIXMAPS.items():
            try: self._status_pixmaps[key] = LoadPixmap(path)
            except Exception: self._status_pixmaps[key] = None
        try:
            self.l.setFont(0, gFont("Regular", 27))
            self.l.setFont(1, gFont("Regular", 17))
            self.l.setItemHeight(57)
        except Exception:
            pass
        self.setSources(sources, states, active_key)

    def setSources(self, sources, states, active_key):
        self.setList([self._row(source, states.get(HomeServerPopup.sourceKey(source), "checking"), active_key) for source in sources])

    def _row(self, source, state, active_key):
        stype = str(source.get("type") or "iptv").lower()
        name = str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")[:31]
        active = HomeServerPopup.sourceKey(source) == active_key
        row = [source]
        icon = self._type_pixmaps.get(stype)
        if icon:
            row.append(MultiContentEntryPixmapAlphaBlend(pos=(8, 9), size=(38, 38), png=icon))
        row.append(MultiContentEntryText(pos=(58, 4), size=(440, 31), font=0, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=(u"✓  " if active else u"   ") + name))
        row.append(MultiContentEntryText(pos=(62, 34), size=(440, 19), font=1, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=stype.upper()))
        led = self._status_pixmaps.get(state if state in ("online", "offline") else "checking")
        if led:
            row.append(MultiContentEntryPixmapAlphaBlend(pos=(548, 18), size=(20, 20), png=led))
        row.append(MultiContentEntryText(pos=(575, 9), size=(60, 38), font=1, flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER, text=("ONLINE" if state == "online" else "OFF" if state == "offline" else "...")))
        return row


class HomeServerPopup(Screen):
    skin = HOME_SERVER_POPUP_SKIN

    def __init__(self, session, sources, active_source=None):
        Screen.__init__(self, session)
        self.sources = [dict(x or {}) for x in (sources or []) if x]
        self.active_source = dict(active_source or {})
        self.active_key = self.sourceKey(self.active_source)
        # Show the last known real server state immediately instead of making
        # every row grey while the background refresh is still running.
        self.states = {}
        for x in self.sources:
            state = str(x.get("_last_status") or "").lower()
            self.states[self.sourceKey(x)] = state if state in ("online", "offline") else "checking"
        self._probeResult = None
        self._probePending = 0
        self._closed = False
        self._probeTimer = eTimer()
        _connect_timer(self._probeTimer, self._finishProbe)
        self["title"] = Label(tr("Select Server"))
        self["subtitle"] = Label(tr("Choose the server for Home"))
        self["hint"] = Label(tr("OK Select     RED Delete     BLUE Test     EXIT Cancel"))
        self["servers"] = HomeServerChoiceList(self.sources, self.states, self.active_key)
        active_index = 0
        for i, source in enumerate(self.sources):
            if self.sourceKey(source) == self.active_key:
                active_index = i; break
        try: self["servers"].moveToIndex(active_index)
        except Exception: pass
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.choose, "cancel": self.close,
            "up": self["servers"].up, "down": self["servers"].down,
            "left": self["servers"].pageUp, "right": self["servers"].pageDown,
            "red": self.deleteCurrent, "blue": self.testCurrent,
        }, -1)
        # Open instantly using saved states. BLUE explicitly tests only the
        # highlighted source; opening the popup never contacts other servers.
        self.onClose.append(self._cleanup)

    @staticmethod
    def sourceKey(source):
        source = source or {}
        return "%s|%s|%s|%s" % (source.get("type", ""), (source.get("url") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def _current(self):
        row = self["servers"].getCurrent()
        return row[0] if row and isinstance(row[0], dict) else None

    def choose(self):
        source = self._current()
        self.close(dict(source) if source else None)

    def _startProbe(self, only_source=None):
        if self._closed or self._probePending > 0: return
        targets = [dict(only_source)] if only_source else [dict(x) for x in self.sources]
        if only_source:
            for source in targets:
                self.states[self.sourceKey(source)] = "checking"
            self["servers"].setSources(self.sources, self.states, self.active_key)
        # Probe independently so one slow/offline server cannot keep every LED grey.
        self._probeResult = {}
        self._probePending = len(targets)
        def worker(source):
            key = self.sourceKey(source)
            try:
                reply = get_source_client(source).test()
                if str(source.get("type") or "").lower() == "xtream" and isinstance(reply, dict):
                    user = reply.get("user_info") or reply.get("user") or {}
                    auth = str(user.get("auth") if "auth" in user else "").lower()
                    status = str(user.get("status") or "").lower()
                    ok = auth not in ("0", "false", "no") and status not in ("expired", "disabled", "banned", "blocked", "inactive")
                elif isinstance(reply, dict):
                    ok = bool(reply.get("ok", True))
                else:
                    ok = bool(reply)
                state = "online" if ok else "offline"
            except Exception:
                state = "offline"
            if isinstance(self._probeResult, dict):
                self._probeResult[key] = state
            self._probePending = max(0, self._probePending - 1)
        for source in targets:
            t = thread_factory(target=worker, args=(source,), name="TiviMateHomeServerStatus")
            t.daemon = True; t.start()
        try: self._probeTimer.start(120, True)
        except Exception: pass

    def _finishProbe(self):
        if self._closed: return
        result = dict(self._probeResult or {})
        if result:
            self.states.update(result)
            try: self["servers"].setSources(self.sources, self.states, self.active_key)
            except Exception: pass
            for key in result:
                try: self._probeResult.pop(key, None)
                except Exception: pass
        if self._probePending > 0:
            try: self._probeTimer.start(120, True)
            except Exception: pass
        else:
            try: self._probeTimer.stop()
            except Exception: pass

    def testCurrent(self):
        source = self._current()
        if source: self._startProbe(source)

    def deleteCurrent(self):
        source = self._current()
        if not source: return
        name = str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
        self.session.openWithCallback(lambda answer: self._deleteConfirmed(source) if answer else None, MessageBox, tr("Delete server '%s'?") % name, MessageBox.TYPE_YESNO)

    def _deleteConfirmed(self, source):
        key = self.sourceKey(source)
        saved = [dict(x or {}) for x in (get_sources() or []) if x and self.sourceKey(x) != key]
        set_sources(saved)
        # Keep playlists.txt in sync with sources.json. get_sources() imports
        # playlists.txt on every load, so leaving the deleted entry there makes
        # it reappear in Home -> Switch Server after the screen is reopened.
        write_playlists(saved)
        self.sources = [x for x in self.sources if self.sourceKey(x) != key]
        self.states.pop(key, None)
        deleted_active = key == self.active_key
        if deleted_active:
            self.active_key = self.sourceKey(self.sources[0]) if self.sources else ""
        if not self.sources:
            self.close(("deleted", None, deleted_active))
            return
        self["servers"].setSources(self.sources, self.states, self.active_key)
        try: self["servers"].moveToIndex(0)
        except Exception: pass
        if deleted_active:
            self.close(("deleted", dict(self.sources[0]), True))

    def _cleanup(self):
        self._closed = True
        try: self._probeTimer.stop()
        except Exception: pass


class TiviMateE2Home(Screen):
    skin = HOME_SKIN_CINEMA_BLUE
    NAV = ["Search", "Live", "Movies", "TV Shows", "Packages", "GENRE", "Resume", "Server Finder", "Settings"]
    NAV_X = [359 + 150 * i for i in range(9)]
    NAV_Y = [210] * 9
    POSTER_X = [216, 461, 706, 951, 1196, 1441]
    POSTER_Y = 701
    ACTIVE_FILE = data_path("active_source.json")


    def __init__(self, session):
        self.homeAppearance = _load_home_appearance()
        self.homeSkinName = "cinema_blue"
        self.isReferenceHome = False
        self.skin = HOME_SKIN_CINEMA_BLUE
        from .font_preferences import read_preferences, scale_skin_text
        self.skin = scale_skin_text(self.skin, read_preferences()["font_scale"])
        if self.homeSkinName == "skin2_dark":
            try:
                from xml.sax.saxutils import escape as _xml_escape
                _info = _xml_escape(str(tr("More Info")), {'"': "&quot;"})
                self.skin = self.skin.replace("ⓘ  More Info", "ⓘ  " + _info)
            except Exception:
                pass
        self.NAV = ["Search", "Live", "Movies", "TV Shows", "Packages", "GENRE", "Resume", "Server Finder", "Settings"]
        self.NAV_X = [22] * 9 if self.homeSkinName == "cinema_blue" else [359 + 150 * i for i in range(9)]
        self.NAV_Y = [252 + i * 78 for i in range(9)] if self.homeSkinName == "cinema_blue" else [79] * 9
        self.POSTER_X = [445, 685, 925, 1165, 1405, 1645] if self.homeSkinName == "cinema_blue" else [55, 375, 695, 1015, 1335, 1655]
        self.POSTER_Y = 643 if self.homeSkinName == "cinema_blue" else 510
        self.posterSize = (215, 360)
        self.bannerSize = (1920, 370)
        Screen.__init__(self, session)
        # A new Home session re-enables artwork writes after the previous
        # explicit Home exit locked every late downloader/callback.
        try:
            from .artwork_queue import set_app_exiting as set_artwork_exiting
            set_artwork_exiting(False)
        except Exception:
            pass
        try:
            from .estalker_picon import set_app_exiting as set_picon_exiting
            set_picon_exiting(False)
        except Exception:
            pass
        self._pageOpenBusy = False
        self.source = self._loadActiveSource()
        self.homeContentMode = "popular_movies"
        valid_home_modes = ("popular_movies", "popular_series", "trending_movies", "trending_series")
        # Classic is deliberately light: only the Popular Show feed is enabled.
        # Do not change Cinema's saved content preference on disk.
        if self.homeSkinName == "skin2_dark" or self.homeContentMode not in valid_home_modes:
            self.homeContentMode = "popular_movies"
        self.focus = "nav"
        self.navIndex = 2 if self.homeSkinName == "cinema_blue" else 0
        self.posterIndex = 0
        self.recent = []
        # Warm VOD index used by Home Popular/Trending movie cards. It is filled
        # in the background while TMDb posters are shown, so WATCH does not start
        # a full server scan after the user opens a movie.
        self.homeMovieServerItems = []
        self.homeMovieIndexLoading = False
        self.imageLoaders = [None] * 7
        self.imageDownloaders = [None] * 7
        self.featureRequestId = 0
        # Every asynchronous Home job belongs to the server generation that
        # created it. Switching server invalidates older workers/callbacks.
        self._sourceGeneration = 1
        self._homeClosed = False
        # The dashboard hero is part of the application identity, never of a specific IPTV source.
        self.globalHero = True
        self["headline"] = Label(tr("TiViMate IPTV EXPERIENCE"))
        self["subheadline"] = Label(tr("Live TV  •  Movies  •  Series  •  beIN SPORTS"))
        self["logo"] = Label(tr("TiviMate E2"))
        self["homeBrandLogo"] = Pixmap()
        if self.homeSkinName == "cinema_blue":
            self["cinemaLogoShine"] = Pixmap()
        self["poweredBy"] = Label("Developed by opesboy")
        for i in range(9): self["nav%d" % i] = Label(nav_label(self.NAV[i]) if i < len(self.NAV) else "")
        self["navSelector"] = Pixmap()
        self["cinemaTileFocus"] = Pixmap()
        self["cinemaSidebarFocus"] = Pixmap()
        self["cinemaClockFace"] = Pixmap()
        self["cinemaClockHour"] = Pixmap()
        self["cinemaClockMinute"] = Pixmap()
        for _i, _name in enumerate(("Search", "Server Finder", "Resume", "Favorites", "Settings", "Switch Server", "Appearance", "App Font")):
            if _name == "App Font":
                self["cinemaSide%d" % _i] = Label({"ar": "تغيير الخط", "fr": "Police", "tr": "Yazı Tipi"}.get(get_language(), "App Font"))
                continue
            self["cinemaSide%d" % _i] = Label(({"ar":"تبديل السيرفر", "fr":"Changer serveur", "tr":"Sunucu Değiştir"}.get(get_language(), "Switch Server") if _name == "Switch Server" else ({"ar":"المظهر", "fr":"Apparence", "tr":"Görünüm"}.get(get_language(), "Appearance") if _name == "Appearance" else tr(_name))))
        self["clock"] = Label("")
        self["date"] = Label("")
        self["cinemaServerName"] = Label("")
        self["banner"] = Pixmap()
        self["quality"] = Label(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"] = Label(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"] = Label(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"] = SynopsisLabel("")
        self["playNow"] = Label(tr("WATCH NOW"))
        self["recentTitle"] = Label(tr("Popular Show"))
        for i in range(6):
            self["poster%d" % i] = Pixmap()
            self["posterMetaTitle%d" % i] = Label("")
            self["posterMetaRate%d" % i] = Label("")
        self["posterSelector"] = Pixmap()
        self._updateCinemaServerName()
        self["status"] = Label("")
        if self.homeSkinName in ("skin2_dark", "cinema_blue"):
            lang = get_language()
            if lang == "ar":
                self["actionLabel0"] = Label("تبديل السيرفر")
                self["actionLabel1"] = Label("المظهر")
                self["actionLabel2"] = Label("بحث السيرفرات" if self.homeSkinName == "skin2_dark" else "اختيار القوائم")
                self["actionLabel3"] = Label("المفضلة")
                self["skin2HelpTitle"] = Label("أزرار الريموت")
                self["skin2HelpBody"] = Label("الأحمر: تبديل السيرفر   الأخضر: المظهر\nالأصفر: بحث السيرفرات   الأزرق: المفضلة" if self.homeSkinName == "skin2_dark" else "الأحمر: تبديل السيرفر   الأخضر: المظهر\nالأصفر: اختيار القوائم   الأزرق: المفضلة")
                self["skin2LangTitle"] = Label("اللغة العربية")
                self["skin2LangBody"] = Label("واجهة وقوائم عربية متناسقة وواضحة")
                self["skin2Key5"] = Label("المفتاح 5\nإعدادات الترجمة")
            elif lang == "fr":
                self["actionLabel0"] = Label("CHANGER SERVEUR")
                self["actionLabel1"] = Label("CHANGER SKIN")
                self["actionLabel2"] = Label("RECHERCHE SERVEUR" if self.homeSkinName == "skin2_dark" else "CHOISIR LISTE")
                self["actionLabel3"] = Label("FAVORIS")
                self["skin2HelpTitle"] = Label("Touches de la télécommande")
                self["skin2HelpBody"] = Label("Rouge: Changer serveur   Vert: Apparence\nJaune: Recherche serveur   Bleu: Favoris" if self.homeSkinName == "skin2_dark" else "Rouge: Changer serveur   Vert: Apparence\nJaune: Choisir liste   Bleu: Favoris")
                self["skin2LangTitle"] = Label("Interface française")
                self["skin2LangBody"] = Label("Menus et informations adaptés à la langue")
                self["skin2Key5"] = Label("Touche 5\nRéglages des sous-titres")
            else:
                self["actionLabel0"] = Label("SWITCH SERVER")
                self["actionLabel1"] = Label("APPEARANCE")
                self["actionLabel2"] = Label("SERVER FINDER" if self.homeSkinName == "skin2_dark" else "CHOOSE LISTS")
                self["actionLabel3"] = Label("FAVORITES")
                self["skin2HelpTitle"] = Label("REMOTE SHORTCUTS")
                self["skin2HelpBody"] = Label("Red: Switch server   Green: Appearance\nYellow: Server Finder   Blue: Favorites" if self.homeSkinName == "skin2_dark" else "Red: Switch server   Green: Appearance\nYellow: Choose lists   Blue: Favorites")
                self["skin2LangTitle"] = Label("LANGUAGE")
                self["skin2LangBody"] = Label("Menus and information follow the selected language")
                self["skin2Key5"] = Label("KEY 5\nSubtitle settings")
        # Artwork purge is tied only to an explicit BACK/EXIT from the main
        # Home screen. Internal child-screen closes/navigation must never trigger it.
        self._homeExitRequested = False
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self._exitFromHome, "menu": self.openHomeMenu,
            "red": self.openHomeServerPopup, "green": self._homeGreenAction, "yellow": self._homeYellowAction,
            "yellowlong": self.addRecentFavourite, "blue": self.openFavorites
        }, -1)
        self.clockTimer = eTimer()
        _connect_timer(self.clockTimer, self.updateClock)
        self.loadTimer = eTimer()
        _connect_timer(self.loadTimer, self.startLoad)
        # A short, local one-shot sheen on the wordmark embedded in Cinema Home.
        # Never run artwork/network jobs or repeat this animation continuously.
        self._cinemaShineTimer = None
        self._cinemaShineIndex = 0
        if self.homeSkinName == "cinema_blue":
            self._cinemaShineTimer = eTimer()
            _connect_timer(self._cinemaShineTimer, self._advanceCinemaLogoShine)
            self.onClose.append(self._stopCinemaLogoShine)
        # Stalker/Ministra portals can complete the network request in a worker
        # while a Twisted reactor is unavailable or not integrated with Enigma2.
        # Deliver their Home result through an eTimer, the same UI-thread pattern
        # used by ContentHome.  This remains completely generic: it carries only
        # a source snapshot, a request token, and normalized items.
        self.stalkerRecentToken = 0
        self.stalkerRecentResult = None
        self.stalkerRecentTimer = eTimer()
        _connect_timer(self.stalkerRecentTimer, self._finishStalkerRecentLoad)

        # Update work happens only after the Home screen is visible and always
        # in a background thread, so it never delays loading IPTV content.
        self.updateCheckTimer = eTimer()
        self.updateCheckPollTimer = eTimer()
        self.updateDownloadPollTimer = eTimer()
        _connect_timer(self.updateCheckTimer, self._beginUpdateCheck)
        _connect_timer(self.updateCheckPollTimer, self._pollUpdateCheck)
        _connect_timer(self.updateDownloadPollTimer, self._pollUpdateDownload)
        self._updateCheckPending = None
        self._updateDownloadPending = None
        self._updateCandidate = None
        self._updateInstallProcess = None
        self._updateCheckStarted = False
        try: self.onClose.append(self._stopUpdateTimers)
        except Exception: pass
        try: self.onClose.append(self._stopStalkerRecentTimer)
        except Exception: pass
        try: self.onClose.append(self._invalidateHomeJobs)
        except Exception: pass
        # Leaving TiviMateE2 while INTERNAL cache is selected must leave
        # no artwork behind. Cancel late download writers first, then remove only
        # posters/backdrops/picons/logos; persistent data caches stay intact.
        try: self.onClose.append(self._clearInternalArtworkOnExit)
        except Exception: pass
        self.onLayoutFinish.append(self.layoutReady)
        if self.homeSkinName == "cinema_blue":
            self.onLayoutFinish.append(self._cinemaClockStart)
            self.onLayoutFinish.append(self._startCinemaLogoShine)


    def _exitFromHome(self):
        # Mark only the real application exit from Home. The onClose hook below
        # may also run for framework-driven closes, which must preserve artwork.
        self._homeExitRequested = True
        self.close()

    def _clearInternalArtworkOnExit(self):
        if not bool(getattr(self, "_homeExitRequested", False)):
            return
        try:
            from .estalker_picon import set_app_exiting
            set_app_exiting(True)
        except Exception:
            pass
        try:
            from .artwork_queue import set_app_exiting as set_artwork_exiting, cancel_all_artwork
            set_artwork_exiting(True)
            cancel_all_artwork()
        except Exception:
            pass
        # Keep Home/source metadata and bounded artwork on internal storage, so
        # the next launch can paint from cache instead of fetching everything.
        # The flash-specific cleanup_cache() still protects free space and caps
        # each artwork family. HDD/USB caches are unaffected.
        try:
            self._purgeInternalCachesKeepPopularShow()
        except Exception:
            pass

    def _purgeInternalCachesKeepPopularShow(self):
        try:
            cfg = get_cache_settings() or {}
            if not is_internal_cache_active():
                return False
        except Exception:
            return False

        # Never clear the user's Home or image cache just because they pressed
        # BACK. The flash-aware LRU cleanup below enforces count/free-space
        # limits without resetting every startup to a cache miss.
        # r171 migration cleanup: older TiviMateE2 builds wrote artwork directly
        # under /var/tmp. Remove only files carrying TiviMateE2's own filename
        # prefixes, then remove a legacy folder only when it becomes empty. This
        # avoids touching unrelated Enigma2 plugins that may also use /var/tmp.
        legacy_artwork = {
            "/var/tmp/posters": ("poster_",),
            "/var/tmp/backdrops": ("backdrop_",),
            "/var/tmp/logos": ("logo_",),
            "/var/tmp/picons": ("picon_", "xst_live_picon_"),
        }
        for folder, prefixes in legacy_artwork.items():
            try:
                if not os.path.isdir(folder):
                    continue
                for name in os.listdir(folder):
                    path = os.path.join(folder, name)
                    if os.path.isfile(path) and any(name.startswith(prefix) for prefix in prefixes):
                        try:
                            os.remove(path)
                        except Exception:
                            pass
                try:
                    if not os.listdir(folder):
                        os.rmdir(folder)
                except Exception:
                    pass
            except Exception:
                pass

        # Preserve data-side Home, Recent, content landing and EPG metadata on
        # normal app exit. Those caches already have their own expiry/source
        # validation, and clearing them here forced a network reload every
        # time the user reopened TiviMateE2 on INTERNAL/AUTO flash storage.
        # In-process catalogs remain reusable as well; source-specific
        # invalidation is handled by the existing catalog/cache owner.
        # Do NOT touch artwork image quotas, queues or downloader settings.

        # Protect receiver flash using its configured image-count/free-space
        # quota, instead of erasing every GENRE cache hit.
        # The artwork queue is already stopped at this point.
        try:
            from .cache_manager import cleanup_cache
            cleanup_cache()
        except Exception:
            pass
        return True

    def _applyRecentTitleLayout(self):
        """Keep the Home content heading on the right edge only for Arabic.
        Do not mirror the whole screen; only reposition this heading."""
        try:
            widget = self["recentTitle"]
            if not widget or not widget.instance:
                return
            lang = get_language()
            if self.isReferenceHome:
                x, y, w, h = (100, 610, 500, 42)
                if lang == "ar":
                    # Arabic heading sits at the far-right edge above the last poster.
                    x, w = (1650, 220)
            else:
                x, y, w, h = (55, 468, 560, 40)
                if lang == "ar":
                    # Skin 2: keep only this heading RTL-positioned; do not mirror Home.
                    x, w = (1650, 220)
            widget.instance.move(ePoint(sx(x), sy(y)))
            widget.instance.resize(eSize(sx(w), sy(h)))
        except Exception:
            pass

    def layoutReady(self):
        # Both Home skins scale their decoded hero at the Pixmap level.
        try:
            self["banner"].instance.setScale(1)
        except Exception:
            pass
        self.applyGlobalHero()
        self._applyRecentTitleLayout()
        self.updateFocus(); self.updateClock()
        try: self.clockTimer.start(30000, False)
        except Exception: pass
        try: self.loadTimer.start(250, True)
        except Exception: self.startLoad()
        # Delay the request slightly so a slow or unavailable update endpoint
        # never affects the first paint of the home interface.
        if _load_update_settings().get("auto_check", True):
            try: self.updateCheckTimer.start(1500, True)
            except Exception: self._beginUpdateCheck()

    def _stopUpdateTimers(self):
        for timer in (getattr(self, "updateCheckTimer", None),
                      getattr(self, "updateCheckPollTimer", None),
                      getattr(self, "updateDownloadPollTimer", None)):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _stopStalkerRecentTimer(self):
        # Invalidate a finishing worker before the screen is destroyed.
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass

    def _invalidateHomeJobs(self):
        self._homeClosed = True
        self._sourceGeneration = getattr(self, "_sourceGeneration", 0) + 1
        self.featureRequestId = getattr(self, "featureRequestId", 0) + 1
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None

    def _sourceJobValid(self, generation, source):
        if getattr(self, "_homeClosed", False):
            return False
        if generation != getattr(self, "_sourceGeneration", -1):
            return False
        try:
            return _source_identity(source or {}) == _source_identity(self.source or {})
        except Exception:
            return False

    def _beginUpdateCheck(self):
        # Only the separate Python 2.7 manifest is queried in a worker.
        if not _load_update_settings().get("auto_check", True):
            return
        if self._updateCheckStarted:
            return
        self._updateCheckStarted = True
        self._updateCheckPending = None

        def worker():
            try:
                self._updateCheckPending = check_for_update()
            except Exception:
                self._updateCheckPending = {}

        try:
            thread = thread_factory(target=worker)
            thread.daemon = True
            thread.start()
            self.updateCheckPollTimer.start(200, True)
        except Exception:
            self._updateCheckPending = {}

    def _pollUpdateCheck(self):
        if self._updateCheckPending is None:
            try: self.updateCheckPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateCheckPending or {}
        self._updateCheckPending = None
        if not result.get("available"):
            return
        self._updateCandidate = result
        try:
            self.session.openWithCallback(self._onUpdatePrompt, TiviMateUpdatePrompt, result, timeout=20)
        except Exception:
            pass

    def _onUpdatePrompt(self, answer):
        if not answer or not self._updateCandidate:
            return
        package = self._updateCandidate.get("package")
        if not package:
            return
        self._updateDownloadPending = None
        try: self["status"].setText("")
        except Exception: pass

        def worker():
            self._updateDownloadPending = download_package(package)

        try:
            thread = thread_factory(target=worker)
            thread.daemon = True
            thread.start()
            self.updateDownloadPollTimer.start(200, True)
        except Exception:
            self._updateDownloadPending = {"ok": False, "message": "Unable to start download"}

    def _pollUpdateDownload(self):
        if self._updateDownloadPending is None:
            try: self.updateDownloadPollTimer.start(200, True)
            except Exception: pass
            return
        result = self._updateDownloadPending or {}
        self._updateDownloadPending = None
        if not result.get("ok"):
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("Update download failed.\n\n%s" % (result.get("message") or "Please try again later."))
            return
        command = install_command(result)
        if not command:
            cleanup_update_package(result)
            try: self["status"].setText(tr(""))
            except Exception: pass
            self._showUpdateMessage("The verified update package could not be installed.")
            return
        try: self["status"].setText(tr(""))
        except Exception: pass
        try:
            if open_update_console(self.session, result, self._updateCandidate or {},
                                   self._onUpdateInstallFinished):
                return
        except Exception:
            pass
        cleanup_update_package(result)
        self._showUpdateMessage("Unable to start the update installer.")

    def _onUpdateInstallFinished(self, status):
        self._updateInstallProcess = None
        try: self["status"].setText(tr(""))
        except Exception: pass
        if status == 0:
            try:
                from enigma import quitMainloop
                quitMainloop(3)
            except Exception:
                self._showUpdateMessage("TiviMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.")
        else:
            self._showUpdateMessage("The update installer returned an error.\n\nYour current TiviMate E2 installation has not been changed.")

    def _showUpdateMessage(self, text):
        try:
            self.session.open(MessageBox, text, type=MessageBox.TYPE_INFO, timeout=12)
        except Exception:
            pass

    def _sourceKey(self, source):
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("url", "").rstrip("/"), source.get("username", ""), source.get("mac", ""))

    def _loadActiveSource(self):
        sources = get_sources()
        if not sources: return None
        try:
            with open_text(self.ACTIVE_FILE, "r") as f: key = json.load(f).get("key", "")
            for source in sources:
                if self._sourceKey(source) == key: return source
        except Exception: pass
        for source in sources:
            if source.get("type") == "xtream": return source
        return sources[0]

    def _saveActiveSource(self):
        try:
            ensure_dir(os.path.dirname(self.ACTIVE_FILE))
            with open_text(self.ACTIVE_FILE, "w") as f: json.dump({"key": self._sourceKey(self.source)}, f)
        except Exception: pass

    def _updateCinemaServerName(self):
        try:
            name = str((self.source or {}).get("name") or "").strip()
        except Exception:
            name = ""
        if not name:
            try:
                self["cinemaServerName"].setText("")
            except Exception:
                pass
            return
        display = name[:16]
        try:
            self["cinemaServerName"].setText(display)
        except Exception:
            pass

    def updateClock(self):
        now = time.localtime()
        self["clock"].setText(time.strftime("%H:%M", now))
        # Compact localized weekday and date, only for Cinema's clock area.
        if self.homeSkinName == "cinema_blue":
            days = {
                "ar": ("الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"),
                "tr": ("Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"),
                "fr": ("lun", "mar", "mer", "jeu", "ven", "sam", "dim"),
                "en": ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"),
            }
            lang = get_language()
            weekday = days.get(lang, days["en"])[(now.tm_wday) % 7]
            self["date"].setText("%s %02d.%02d.%04d" % (weekday, now.tm_mday, now.tm_mon, now.tm_year))
        else:
            self["date"].setText(time.strftime("%d.%m.%Y", now))

    def _heroRating(self, row):
        item = row.get("item") or {}
        raw = row.get("rating") or item.get("rating") or item.get("vote_average") or item.get("rating_5based") or 0
        try:
            value = float(str(raw).replace(",", "."))
            if value > 10.0:
                value = value / 10.0
            return max(0.0, min(10.0, value))
        except Exception:
            return 0.0

    def _heroYear(self, row):
        item = row.get("item") or {}
        raw = u" ".join(text_type(x or u"") for x in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match = re.search(r"\b(19|20)\d{2}\b", raw)
        return match.group(0) if match else ""

    def _heroOverview(self, row):
        item = row.get("item") or {}
        return text_type(
            row.get("overview") or item.get("plot") or item.get("description") or
            item.get("overview") or u""
        ).strip()

    def _heroGenre(self, row):
        item = row.get("item") or {}
        return str(row.get("genre") or item.get("genre") or "").strip()

    def _enrichHeroAsync(self, key, row):
        generation = self._generation
        title = self._title(row)
        kind = "series" if self._isSeries(row) else "vod"
        item = row.get("item") or {}
        year = self._heroYear(row) or item.get("year") or ""
        def worker():
            try:
                found = TMDbClient().search_artwork(title, kind=kind, year=year) or {}
            except Exception:
                found = {}
            if generation != self._generation or not found:
                return
            data = self._load()
            rec = data.get(key)
            if not isinstance(rec, dict):
                return
            rec["rating"] = found.get("vote_average") or rec.get("rating") or ""
            rec["year"] = str(found.get("release_date") or found.get("first_air_date") or rec.get("year") or "")[:4]
            rec["overview"] = found.get("overview") or rec.get("overview") or ""
            path = found.get("backdrop_path") or ""
            if path and not rec.get("backdrop"):
                rec["backdrop"] = IMAGE_BASE + "w780" + path
            data[key] = rec
            self._save(data)
            # Update only if this exact item is still selected.
            selected = self._selected()
            if not selected or selected[0] != key or generation != self._generation:
                return
            rating = self._heroRating(rec)
            stars = int(round(rating / 2.0)) if rating else 0
            star_text = ("★" * stars) + ("☆" * (5 - stars)) if rating else "☆☆☆☆☆"
            year_text = self._heroYear(rec)
            self["heroStars"].setText("%s   %.1f/10%s" % (
                star_text, rating, ("  •  " + year_text) if year_text else ""
            ) if rating else star_text)
            overview = self._heroOverview(rec)
            if overview:
                self["heroDesc"].setText(overview[:280])
            backdrop = self._asset(rec)
            if backdrop:
                self._loadArtwork(backdrop, "hero", generation)
        t = thread_factory(target=worker, name="TiviMateContinueHeroInfo")
        t.daemon = True
        t.start()


    def _startCinemaLogoShine(self):
        """Play one gentle left-to-right shine after Cinema Home first paints."""
        if self.homeSkinName != "cinema_blue" or getattr(self, "_homeClosed", False):
            return
        self._cinemaShineIndex = 0
        try:
            self["cinemaLogoShine"].hide()
            if self._cinemaShineTimer is not None:
                self._cinemaShineTimer.start(280, True)  # Do not delay Home first paint.
        except Exception:
            pass

    def _advanceCinemaLogoShine(self):
        timer = getattr(self, "_cinemaShineTimer", None)
        if getattr(self, "_homeClosed", False) or self.homeSkinName != "cinema_blue":
            self._stopCinemaLogoShine()
            return
        frame = int(getattr(self, "_cinemaShineIndex", 0))
        if frame >= 16:
            self._stopCinemaLogoShine()
            return
        try:
            path = os.path.join(PLUGIN_PATH, "skins", "home", "shine_once", "shine_%02d.png" % frame)
            self["cinemaLogoShine"].instance.setPixmapFromFile(path)
            self["cinemaLogoShine"].show()
            self._cinemaShineIndex = frame + 1
            if timer is not None:
                timer.start(83, True)
        except Exception:
            self._stopCinemaLogoShine()

    def _stopCinemaLogoShine(self):
        try:
            if self._cinemaShineTimer is not None:
                self._cinemaShineTimer.stop()
        except Exception:
            pass
        try:
            if self.homeSkinName == "cinema_blue":
                self["cinemaLogoShine"].hide()
        except Exception:
            pass

    def _cinemaClockStart(self):
        try:
            from enigma import eTimer
            self._cinemaClockTimer = eTimer()
            self._cinemaClockTimer.callback.append(self._cinemaClockTick)
            self._cinemaClockTick()
        except Exception:
            pass

    def _cinemaClockTick(self):
        try:
            from datetime import datetime
            import os
            now = datetime.now()
            minute = int(now.minute)
            hour_slot = ((now.hour % 12) * 12 + minute // 5) % 144
            clock_root = os.path.join(PLUGIN_PATH, "skins", "home", "cinema_clock_compact_r173")
            self["cinemaClockHour"].instance.setPixmapFromFile(os.path.join(clock_root, "h%03d.png" % hour_slot))
            self["cinemaClockMinute"].instance.setPixmapFromFile(os.path.join(clock_root, "m%02d.png" % minute))
            self["cinemaClockHour"].show()
            self["cinemaClockMinute"].show()
            self._cinemaClockTimer.start(60000, True)
        except Exception:
            pass

    def updateFocus(self):
        if self.homeSkinName == "cinema_blue":
            # Cinema sidebar contains exactly six entries (indices 0..5).
            # Normalize stale navigation state before positioning the highlight.
            self.navIndex = max(0, min(7, int(self.navIndex)))
            try:
                if self.focus == "posters":
                    self["cinemaTileFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "home", "cinema_focus_%d_r171.png" % self.posterIndex))
                    self["cinemaTileFocus"].show()
                    self["cinemaSidebarFocus"].hide()
                else:
                    self["cinemaTileFocus"].hide()
                    self["cinemaSidebarFocus"].instance.move(ePoint(sx(18), sy(212 + self.navIndex * 92)))
                    self["cinemaSidebarFocus"].show()
            except Exception:
                pass
            return
        if self["navSelector"].instance:
            try:
                if self.homeSkinName == "skin2_dark":
                    x = self.NAV_X[self.navIndex]
                    y = 79
                else:
                    x = self.NAV_X[self.navIndex]
                    y = self.NAV_Y[self.navIndex]
                self["navSelector"].instance.move(ePoint(sx(x), sy(y)))
                self["navSelector"].show() if self.focus == "nav" else self["navSelector"].hide()
            except Exception:
                pass
        if self["posterSelector"].instance:
            try:
                x = self.POSTER_X[self.posterIndex]
                y = self.POSTER_Y
                if self.homeSkinName == "skin2_dark":
                    x -= 2
                    y -= 2
                self["posterSelector"].instance.move(ePoint(sx(x), sy(y)))
                focused = self.focus == "posters" and bool(self.recent)
                self["posterSelector"].show() if focused else self["posterSelector"].hide()
            except Exception:
                pass
        # The old Skin2 focus frame has a light footer: use a black title only
        # on the focused poster; keep all unfocused poster titles light on dark.
        if self.homeSkinName == "skin2_dark":
            try:
                selected = self.focus == "posters" and bool(self.recent)
                for slot in range(6):
                    widget = self["posterMetaTitle%d" % slot].instance
                    if widget:
                        color = "#151515" if selected and slot == self.posterIndex else "#F7FBFF"
                        widget.setForegroundColor(parseColor(color))
            except Exception:
                pass

    def left(self):
        if self.homeSkinName == "cinema_blue":
            if self.focus == "posters":
                if self.posterIndex > 0: self.posterIndex -= 1
                else: self.focus = "nav"
            self.updateFocus()
            return
        if self.focus == "nav":
            self.navIndex = (self.navIndex - 1) % len(self.NAV)
        else:
            self.posterIndex = max(0, self.posterIndex - 1)
            self.updateFeature()
        self.updateFocus()

    def right(self):
        if self.homeSkinName == "cinema_blue":
            if self.focus == "nav":
                self.focus = "posters"
                self.posterIndex = 0
            else:
                self.posterIndex = min(4, self.posterIndex + 1)
            self.updateFocus()
            return
        if self.focus == "nav":
            self.navIndex = (self.navIndex + 1) % len(self.NAV)
        else:
            self.posterIndex = min(max(0, len(self.recent) - 1), self.posterIndex + 1)
            self.updateFeature()
        self.updateFocus()

    def up(self):
        if self.homeSkinName == "cinema_blue":
            if self.focus == "nav": self.navIndex = (self.navIndex - 1) % 8
            self.updateFocus()
            return
        self.focus = "nav"
        self.updateFocus()

    def down(self):
        if self.homeSkinName == "cinema_blue":
            if self.focus == "nav": self.navIndex = (self.navIndex + 1) % 8
            self.updateFocus()
            return
        if self.recent:
            self.focus = "posters"
            self.updateFeature()
        self.updateFocus()

    def _pageClosed(self, *args):
        self._pageOpenBusy = False
        if getattr(self, '_closeAfterLiveStyleSwitch', False):
            self._closeAfterLiveStyleSwitch = False
            try:
                if (self.session.current_dialog is self and
                        getattr(self.session, 'in_exec', True)):
                    self.close()
            except Exception:
                pass

    def _openPageOnce(self, screen, *args):
        # VTi: preserve the real failure when a child screen cannot be opened.
        from .vti_compat import open_vti_page_once
        return open_vti_page_once(self, screen, *args)


    def openAppFontChooser(self):
        """Sidebar > App Font: one font for TiviMate and its subtitles."""
        from .app_font_setting import font_choices, current_font, save as _font_save
        current = current_font()
        rows = [(("✓  " if key == current else "     ") + str(text), key) for key, text in font_choices()]

        def chosen(selection=None):
            if not selection:
                return
            key = selection[1] if isinstance(selection, (tuple, list)) and len(selection) > 1 else selection
            if _font_save(key):
                self.session.open(MessageBox, tr("Font saved."), MessageBox.TYPE_INFO, timeout=3)
        self.session.openWithCallback(chosen, ChoiceBox, title={"ar": "تغيير الخط"}.get(get_language(), "APP FONT"), list=rows)

    def ok(self):
        if self.homeSkinName == "cinema_blue":
            if self.focus == "posters":
                idx = (2, 3, 4, 5, 1)[self.posterIndex]
            else:
                # Never index the six-entry action map with a stale navIndex.
                self.navIndex = max(0, min(7, int(self.navIndex)))
                idx = (0, 7, 6, -1, 8, -2, -3, -4)[self.navIndex]
            if idx == -4:
                self.openAppFontChooser()
                return
            if idx == -3:
                self._openPageOnce(HomeAppearanceSettings)
                return
            if idx == -2:
                try:
                    self.openHomeServerPopup()
                except Exception as error:
                    try:
                        import traceback
                        traceback.print_exc()
                        self.session.open(MessageBox, "Switch Server: %s" % error, MessageBox.TYPE_ERROR, timeout=8)
                    except Exception:
                        pass
                return
            if idx == -1:
                try: self.openFavorites()
                except Exception: self._openPageOnce(ContinueWatchingScreen, self.source)
                return
            # Keep the selected sidebar/tile and focus intact when opening a page.
            # idx is a destination, never a sidebar selection index.
            index = idx
        elif self.focus == "posters":
            self.playRecent()
            return
        else:
            index = self.navIndex
        if index == 0:
            self._openPageOnce(TiviMateE2Search, self.source)
            return
        if index == 1:
            self.openMedia("live")
            return
        if index == 2:
            self.openContentHome("vod")
            return
        if index == 3:
            self.openContentHome("series")
            return
        if index == 4:
            self.openContentPackages()
            return
        if index == 5:
            # Keep the selector open under the selected Genre page so Back
            # returns here instead of jumping straight to Home.
            self._openPageOnce(TiviMateGenreSelectScreen, dict(self.source), True)
            return
        if index == 6:
            self._openPageOnce(ContinueWatchingScreen, self.source)
            return
        if index == 7:
            self._openPageOnce(TiviMateE2IPTVFinder)
            return
        if index == 8:
            self.openSettings()
            return


    def addRecentFavourite(self):
        if self.focus != "posters" or not self.recent:
            self["status"].setText(tr("Select a movie poster first"))
            return
        item = self.recent[min(self.posterIndex, len(self.recent) - 1)]
        if is_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie is already in favorites"))
        elif add_favourite(self.source, "vod", item):
            self["status"].setText(tr("Movie added to favorites"))
        else:
            self["status"].setText(tr("Unable to save favorite"))

    def openHomeServerPopup(self):
        # Home server switch is for user IPTV servers only. Public FAST/catalog
        # M3U packages (LG/Samsung/Xiaomi/Xumo/etc.) belong to Live/Finder and
        # must not appear here even though they are represented internally as M3U.
        public_m3u_markers = (
            "iptvorg", "samsungtv", "xiaomitv", "xumotv", "xumo", "freetv",
            "localnow", "lgchannels", "roku", "tubitv", "vizio", "tclplus",
            "freelivesports",
        )
        public_name_markers = (
            "LG CHANNELS", "SAMSUNG TV PLUS", "XIAOMI TV+", "XUMO PLAY",
            "FREE TV", "LOCAL NOW", "ROKU CHANNEL", "TUBI LIVE TV",
            "VIZIO WATCHFREE", "TCL TV+", "FREE LIVE SPORTS", "IPTV-ORG", "IPTV ORG",
        )
        def _home_server(source):
            source = source or {}
            stype = str(source.get("type") or "").lower()
            # Real IPTV servers discovered through Server Finder must remain
            # selectable here.  Only known public/live-only catalogue M3U
            # sources are excluded below.
            if stype in ("xtream", "stalker"):
                return True
            if stype != "m3u":
                return False
            marker = str(source.get("finder_source") or source.get("fast_service") or "").lower()
            if marker in public_m3u_markers:
                return False
            if source.get("iptvorg_group") or source.get("samsung_group") or source.get("xiaomi_group"):
                return False
            name = str(source.get("name") or "").upper()
            if any(token in name for token in public_name_markers):
                return False
            url = str(source.get("url") or "").lower()
            path = str(source.get("path") or "").lower()
            if "iptv-org.github.io/iptv/" in url or "tivimatee2_iptvorg_" in path:
                return False
            if url.startswith("fastm3u://"):
                return False
            return True
        sources = [x for x in (get_sources() or []) if _home_server(x)]
        if not sources:
            self.session.open(MessageBox, tr("No IPTV servers found."), MessageBox.TYPE_INFO, timeout=3)
            return
        self.session.openWithCallback(self._homeServerPopupClosed, HomeServerPopup, sources, self.source)

    def _homeServerPopupClosed(self, source=None):
        if not source:
            return
        if isinstance(source, (tuple, list)) and source and source[0] == "deleted":
            replacement = source[1] if len(source) > 1 else None
            deleted_active = bool(source[2]) if len(source) > 2 else False
            if deleted_active and replacement:
                self.selectServer(replacement)
            elif deleted_active and not replacement:
                self["status"].setText(tr("No IPTV servers found."))
            return
        try:
            if self._sourceKey(source) == self._sourceKey(self.source or {}):
                return
        except Exception:
            pass
        self.selectServer(source)

    def openContinueWatching(self):
        self._openPageOnce(ContinueWatchingScreen, self.source)

    def _homeGreenAction(self):
        if self.homeSkinName == "skin2_dark":
            self._openPageOnce(HomeAppearanceSettings)
        else:
            self.openContentPackages()

    def _homeYellowAction(self):
        # Classic yellow key: open Server Finder directly, not Home-content picker.
        # Cinema keeps its original (disabled) yellow-key behavior.
        if self.homeSkinName == "skin2_dark":
            self._openPageOnce(TiviMateE2IPTVFinder)

    def refreshHome(self):
        # YELLOW must refresh only the current Home feed. Invalidate every older
        # worker first so a late Recent/Trending result cannot overwrite Popular.
        current_mode = getattr(self, "homeContentMode", None)
        if not current_mode:
            try:
                current_mode = _load_home_appearance().get("content", "popular_movies")
            except Exception:
                current_mode = "popular_movies"
        self.homeContentMode = "popular_movies" if self.homeSkinName == "skin2_dark" else (current_mode or "popular_movies")
        self.globalHero = True
        try:
            self._sourceGeneration += 1
        except Exception:
            self._sourceGeneration = 1
        try:
            self.stalkerRecentToken += 1
            self.stalkerRecentResult = None
            self.stalkerRecentTimer.stop()
        except Exception:
            pass
        self.posterIndex = 0
        self.recent = []
        self.resetPosters()
        self.startLoad()

    def openContentHome(self, kind):
        # The home hero provider is NOT the Movies or TV Shows provider.
        source = _load_page_source("series" if kind == "series" else "movies", self.source)
        if not source:
            self.openSettings()
            return
        if _page_source_compatible(source, kind):
            # First entry fixes the initial choice until this page switches it.
            _save_page_source("series" if kind == "series" else "movies", source)
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, kind), source, kind)
            return
        self.session.open(MessageBox, "This section requires a VOD-capable server.", MessageBox.TYPE_INFO)

    def openMedia(self, kind):
        source = (self.source if kind == "live" else
                  _load_page_source("series" if kind == "series" else "movies", self.source))
        if not source:
            self.openSettings()
            return
        if kind in ("vod", "series") and not _page_source_compatible(source, kind):
            self.session.open(MessageBox, "This section requires a VOD-capable server.", MessageBox.TYPE_INFO)
            return
        if kind in ("vod", "series"):
            _save_page_source("series" if kind == "series" else "movies", source)
        self._openPageOnce(MediaScreen, source, kind)

    def openHomeMenu(self):
        choices = [(tr("GENRE"), "genre"), (tr("Favorites"), "favorites")]
        self.session.openWithCallback(self._homeMenuSelected, ChoiceBox, title=tr("Menu"), list=choices)

    def _homeMenuSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if action == "favorites":
            self.openFavorites()
            return
        if action == "genre":
            self._openPageOnce(TiviMateGenreSelectScreen, dict(self.source), True)

    def _homeGenreSelected(self, selected=None):
        if not selected or not self.source:
            return
        kind = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if kind not in ("vod", "series"):
            return
        try:
            # Keep Genre navigation hierarchical: when the Movies/TV Shows
            # genre page closes, return to the two-tile Genre selector rather
            # than dropping straight back to Home.
            self.session.openWithCallback(self._returnToHomeGenreSelector, MovieGenresScreen, dict(self.source), kind)
        except Exception as exc:
            self.session.open(MessageBox, tr("Unable to open Genres")+":\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def _returnToHomeGenreSelector(self, *args):
        self.session.openWithCallback(self._homeGenreSelected, TiviMateGenreSelectScreen)

    def openFavorites(self):
        self._openPageOnce(FavoritesScreen)

    def openLiveTools(self):
        if self.kind != "live":
            self.openFavorites(); return
        choices = [(tr("Favorites"), "favorites")]
        if self.source.get("type") == "stalker":
            pin_state = _load_stalker_pin(self.source)
            if self.focus == "category":
                choices.append((tr("Hide this package"), "hide_category"))
                row = self["category"].getCurrent()
                cid = str(row[1] or "") if row else ""
                if cid and not cid.startswith("__"):
                    if cid in pin_state["categories"]:
                        choices.append((tr("Unlock this package"), "unlock_category"))
                    else:
                        choices.append((tr("Lock this package"), "lock_category"))
            elif self.current():
                choices.append((tr("Hide this channel"), "hide_channel"))
                channel_id = _live_item_id(self.current())
                if channel_id in pin_state["channels"]:
                    choices.append((tr("Unlock this channel"), "unlock_channel"))
                else:
                    choices.append((tr("Lock this channel"), "lock_channel"))
            choices.append((tr("Change parental PIN"), "change_pin"))
            choices.append((tr("Stalker player engines"), "stalker_engines"))
            choices.append((tr("Recently watched"), "stalker_recent"))
            state = _load_stalker_hidden(self.source)
            if state["categories"]:
                choices.append((tr("Show hidden packages"), "show_hidden_packages"))
            if state["channels"]:
                choices.append((tr("Show hidden channels"), "show_hidden_channels"))
        self.session.openWithCallback(self._liveToolSelected, ChoiceBox, title=tr("Live options"), list=choices)

    def _liveToolSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if action == "favorites":
            self.openFavorites(); return
        if action == "hide_category":
            self._hideCurrentStalkerCategory(); return
        if action == "hide_channel":
            self._hideCurrentStalkerChannel(); return
        if action == "show_hidden_packages":
            self._showHiddenStalkerPackages(); return
        if action == "show_hidden_channels":
            self._showHiddenStalkerChannels(); return
        if action == "catchup":
            self._openStalkerCatchup(); return
        if action in ("lock_category", "lock_channel"):
            self._lockCurrentStalkerItem(action == "lock_category"); return
        if action in ("unlock_category", "unlock_channel"):
            self._requestStalkerPin(("unlock", action == "unlock_category")); return
        if action == "change_pin":
            self._requestStalkerPin(("change_pin", None)); return
        if action == "stalker_engines":
            self._openStalkerEngineSettings(); return
        if action == "stalker_recent":
            self._openStalkerRecentlyWatched(); return

    def _openStalkerRecentlyWatched(self):
        if self.source.get("type") != "stalker":
            return
        rows = _load_stalker_recent(self.source, 30)
        choices = []
        for resume_key, row in rows:
            title = text_type(row.get("title") or tr("Untitled"))
            position = int(row.get("position", 0) or 0)
            length = int(row.get("length", 0) or 0)
            if length > 0:
                pct = max(0, min(99, int(position * 100 / length)))
                label = "%s  •  %d%%" % (title, pct)
            else:
                label = "%s  •  %02d:%02d" % (title, position // 60, position % 60)
            choices.append((label, (resume_key, row)))
        if not choices:
            self.session.open(MessageBox, tr("No recently watched Stalker items."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerRecentlyWatched, ChoiceBox, title=tr("Recently watched"), list=choices)

    def _playStalkerRecentlyWatched(self, selected=None):
        if not selected:
            return
        try:
            _resume_key_value, row = selected[1]
            item = dict(row.get("item") or {})
            kind = str(row.get("kind") or "vod")
            if kind not in ("vod", "series"):
                kind = "vod"
            item["_source_type"] = "stalker"
            item["_source_key"] = _source_identity(self.source)
            item["_kind"] = kind
            source = dict(self.source)

            def done(url, item=item, kind=kind, source=source):
                if not url:
                    self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), tr("Portal returned no playable URL")), MessageBox.TYPE_ERROR)
                    return
                ref = eServiceReference(_stalker_service_type(source, kind), 0, url)
                ref.setName(gui_text(item.get("name") or item.get("title") or "IPTV"))
                self.session.openWithCallback(self.playerClosed, TiviMatePlayer, ref, item)

            def failed(exc):
                self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)
            # Portal login + create_link off the GUI thread (no freeze).
            from .bg_resolve import resolve_async
            resolve_async(lambda: StalkerClient(source).stream_url(item, kind), done, failed)
        except Exception as exc:
            self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)

    def _openStalkerEngineSettings(self):
        if self.source.get("type") != "stalker":
            return
        self._stalkerEngineValues = _load_stalker_service_types(self.source)
        self._chooseStalkerEngine("live")

    def _chooseStalkerEngine(self, kind):
        labels = {"live": tr("Stalker Live player"), "vod": tr("Stalker Movies player"), "series": tr("Stalker Series player")}
        current = int(self._stalkerEngineValues.get(kind, 4097))
        choices = []
        for value in STALKER_SERVICE_TYPE_CHOICES:
            choices.append(((u"✓ " if value == current else u"") + str(value), value))
        self.session.openWithCallback(lambda selected, k=kind: self._stalkerEngineSelected(k, selected), ChoiceBox, title=labels.get(kind, kind), list=choices)

    def _stalkerEngineSelected(self, kind, selected=None):
        if not selected:
            return
        try:
            value = int(selected[1])
        except Exception:
            return
        if value not in STALKER_SERVICE_TYPE_CHOICES:
            return
        self._stalkerEngineValues[kind] = value
        order = ("live", "vod", "series")
        try:
            next_kind = order[order.index(kind) + 1]
        except Exception:
            next_kind = None
        if next_kind:
            return self._chooseStalkerEngine(next_kind)
        if _save_stalker_service_types(self.source, self._stalkerEngineValues):
            self.session.open(MessageBox, tr("Stalker player engines saved."), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, tr("Unable to save Stalker player engines."), MessageBox.TYPE_ERROR)

    def _lockCurrentStalkerItem(self, is_category=False):
        if self.source.get("type") != "stalker":
            return
        state = _load_stalker_pin(self.source)
        if is_category:
            row = self["category"].getCurrent()
            if not row:
                return
            item_id = str(row[1] or "")
            if not item_id or item_id.startswith("__"):
                self.session.open(MessageBox, tr("This package cannot be locked."), MessageBox.TYPE_INFO); return
            state["categories"].add(item_id)
            state["category_names"][item_id] = str(row[0] or item_id)
            message = tr("Package locked.")
        else:
            item = self.current()
            if not item:
                return
            item_id = _live_item_id(item)
            if not item_id:
                return
            state["channels"].add(item_id)
            state["channel_names"][item_id] = text_type(item.get("name") or item.get("title") or item_id)
            message = tr("Channel locked.")
        _save_stalker_pin(self.source, state)
        try: self["desc"].setText(message)
        except Exception: pass

    def _requestStalkerPin(self, action):
        if time.time() < getattr(self, "_pinBlockedUntil", 0):
            wait = max(1, int(self._pinBlockedUntil - time.time()))
            self.session.open(MessageBox, "%s %s" % (tr("Try again in"), wait), MessageBox.TYPE_ERROR); return
        self._pinPendingAction = action
        self.session.openWithCallback(self._stalkerPinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _stalkerPinEntered(self, value=None):
        if value is None:
            self._pinPendingAction = None
            return
        state = _load_stalker_pin(self.source)
        if str(value).strip() != str(state.get("pin") or "0000"):
            self._pinFailures = getattr(self, "_pinFailures", 0) + 1
            if self._pinFailures >= 3:
                self._pinBlockedUntil = time.time() + 30
                self._pinFailures = 0
            self._pinPendingAction = None
            self.session.open(MessageBox, tr("Incorrect PIN"), MessageBox.TYPE_ERROR); return
        self._pinFailures = 0
        action = self._pinPendingAction
        self._pinPendingAction = None
        if not action:
            return
        kind, payload = action
        if kind == "play":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLivePlayerNow()
        if kind == "category":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLockedCategoryNow()
        if kind == "unlock":
            is_category = bool(payload)
            state = _load_stalker_pin(self.source)
            if is_category:
                row = self["category"].getCurrent()
                item_id = str(row[1] or "") if row else ""
                state["categories"].discard(item_id)
                state["category_names"].pop(item_id, None)
            else:
                item_id = _live_item_id(self.current())
                state["channels"].discard(item_id)
                state["channel_names"].pop(item_id, None)
            _save_stalker_pin(self.source, state)
            try: self["desc"].setText(tr("Lock removed."))
            except Exception: pass
            return
        if kind == "change_pin":
            self.session.openWithCallback(self._stalkerNewPinEntered, VirtualKeyBoard, title=tr("Enter new 4-digit PIN"), text="")

    def _stalkerNewPinEntered(self, value=None):
        value = str(value or "").strip()
        if not (len(value) == 4 and value.isdigit()):
            self.session.open(MessageBox, tr("PIN must contain exactly 4 digits."), MessageBox.TYPE_ERROR); return
        state = _load_stalker_pin(self.source)
        state["pin"] = value
        _save_stalker_pin(self.source, state)
        self.stalkerPinUnlockedUntil = time.time() + 300
        self.session.open(MessageBox, tr("Parental PIN changed."), MessageBox.TYPE_INFO)

    def _isCurrentStalkerCategoryLocked(self):
        if self.source.get("type") != "stalker":
            return False
        row = self["category"].getCurrent()
        cid = str(row[1] or "") if row else ""
        return bool(cid and cid in _load_stalker_pin(self.source)["categories"])

    def _isCurrentStalkerChannelLocked(self):
        if self.source.get("type") != "stalker":
            return False
        return _live_item_id(self.current()) in _load_stalker_pin(self.source)["channels"]

    def _hideCurrentStalkerCategory(self):
        row = self["category"].getCurrent()
        if not row:
            return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        state = _load_stalker_hidden(self.source)
        state["categories"].add(cid)
        state["category_names"][cid] = str(name or cid)
        _save_stalker_hidden(self.source, state)
        try:
            rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
            self["category"].setList(rows)
            self["list"].setList([])
            self.focus = "category"
            self["desc"].setText(tr("Package hidden. Use MENU to restore it."))
        except Exception:
            pass

    def _hideCurrentStalkerChannel(self):
        item = self.current()
        if not item:
            return
        channel_id = _live_item_id(item)
        if not channel_id:
            return
        state = _load_stalker_hidden(self.source)
        state["channels"].add(channel_id)
        state["channel_names"][channel_id] = text_type(item.get("name") or item.get("title") or channel_id)
        _save_stalker_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        try: self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))
        except Exception: pass

    def _showHiddenStalkerPackages(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["category_names"].get(cid, cid), ("category", cid)) for cid in sorted(state["categories"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden packages."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden packages"), list=choices)

    def _showHiddenStalkerChannels(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["channel_names"].get(chid, chid), ("channel", chid)) for chid in sorted(state["channels"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden channels."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden channels"), list=choices)

    def _restoreHiddenStalkerItem(self, selected=None):
        if not selected:
            return
        try:
            kind, item_id = selected[1]
        except Exception:
            return
        state = _load_stalker_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        _save_stalker_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _openStalkerCatchup(self):
        item = self.current()
        if not item or self.source.get("type") != "stalker":
            return
        self._catchupItem = dict(item)
        self._catchupResult = None
        try: self["desc"].setText(tr(""))
        except Exception: pass
        source = dict(self.source)
        channel_id = _live_item_id(item)
        def worker():
            rows, error = [], ""
            try:
                rows = StalkerClient(source).short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            self._catchupResult = (rows, error)
        thread_factory(target=worker, name="TiviMateStalkerCatchup", daemon=True).start()
        self._catchupTimer = eTimer()
        _connect_timer(self._catchupTimer, self._finishStalkerCatchupLoad)
        try: self._catchupTimer.start(150, False)
        except Exception: pass

    def _finishStalkerCatchupLoad(self):
        result = getattr(self, "_catchupResult", None)
        if result is None:
            try: self._catchupTimer.start(150, False)
            except Exception: pass
            return
        try: self._catchupTimer.stop()
        except Exception: pass
        self._catchupResult = None
        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            channel = getattr(self, "_catchupItem", {}) or {}
            channel_archive = (
                channel.get("has_archive") or channel.get("archive") or
                channel.get("allow_archive") or channel.get("tv_archive") or
                channel.get("archive_duration") or channel.get("tv_archive_duration")
            )
            event_archived = str(archive or "").strip().lower() in ("1", "true", "yes", "on")
            channel_archived = str(channel_archive or "").strip().lower() not in ("", "0", "false", "no", "off")
            if begin and end and end <= now and title and (event_archived or channel_archived):
                payload = dict(row)
                payload["_begin"] = begin
                payload["_end"] = end
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, payload))
        if not choices:
            message = tr("No catch-up programmes are available for this channel.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerCatchup, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _playStalkerCatchup(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = getattr(self, "_catchupItem", {}) or {}
        try:
            client = StalkerClient(dict(self.source))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))

            service_type = _stalker_service_type(self.source, "live")
            title = self._decodeEpgText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up"
            ref = eServiceReference(service_type, 0, url)
            ref.setName(gui_text(title))

            play_item = dict(item)
            play_item["_source_type"] = "stalker"
            play_item["_source_key"] = _source_identity(self.source)
            play_item["_kind"] = "live"
            play_item["_catchup"] = True
            play_item["name"] = title

            self.session.openWithCallback(
                self.playerClosed, TiviMatePlayer, ref, play_item
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        choices = []
        for name, value in LIVE_STYLE_CHOICES:
            label = ("✓ " if value == current else "") + name
            choices.append((label, value))
        self.session.openWithCallback(self._liveStyleSelected, ChoiceBox, title="Choose Live style", list=choices)

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
        except Exception:
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        source = dict(self.source)
        # Open first, and close the old Home/Live page only once the new
        # screen has returned. Never attempt to open after self.close().
        self._closeAfterLiveStyleSwitch = True
        if not self._openPageOnce(MediaScreen, source, "live"):
            self._closeAfterLiveStyleSwitch = False


    def openContentPackages(self):
        source = _load_page_source("packages_vod", self.source)
        if not source:
            self.session.open(MessageBox, tr("Add an IPTV source first."), MessageBox.TYPE_INFO, timeout=4)
            return
        if not _page_source_compatible(source, "packages_vod"):
            self.session.open(MessageBox, tr("Movies and TV Shows packages require a compatible server."), MessageBox.TYPE_INFO, timeout=5)
            return
        self._openPageOnce(ContentPackagesScreen, source)

    def openSettings(self):
        self._openPageOnce(SettingsDashboard)

    def selectServer(self, source):
        # r183: a Home server switch is a clean source boundary. Invalidate all
        # old async work and clear only in-memory state; persistent caches stay
        # isolated per source and are reused when switching back.
        self._sourceGeneration = getattr(self, "_sourceGeneration", 0) + 1
        self.featureRequestId = getattr(self, "featureRequestId", 0) + 1
        self.stalkerRecentToken = getattr(self, "stalkerRecentToken", 0) + 1
        self.stalkerRecentResult = None
        try:
            self.stalkerRecentTimer.stop()
        except Exception:
            pass
        self.homeMovieServerItems = []
        self.homeMovieIndexLoading = False
        # Server switching always lands on the Home default feed. This prevents
        # stale legacy Recent Added state from being revived for the new source.
        self.homeContentMode = "popular_movies"
        try:
            cfg = _load_home_appearance()
            _save_home_appearance(cfg.get("skin", "skin2_dark"), "popular_movies")
        except Exception:
            pass
        self.source = dict(source or {})
        # All-server scanning and notice queues are independent of the active
        # playback source. Switching servers must not discard an unseen popup.
        self._saveActiveSource()
        self._updateCinemaServerName()
        self.recent = []
        self.posterIndex = 0
        self.globalHero = True
        self.resetPosters()
        self.startLoad()

    def resetPosters(self):
        for i in range(6):
            try: self["poster%d" % i].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "poster/poster_placeholder.png"))
            except Exception: pass
            try:
                self["posterMetaTitle%d" % i].setText(tr(""))
                self["posterMetaRate%d" % i].setText(tr(""))
            except Exception: pass
        self.applyGlobalHero()

    def applyGlobalHero(self):
        """Render the application hero only until a selected poster supplies its own backdrop."""
        self.featureRequestId += 1
        request_id = self.featureRequestId
        self["quality"].setText(tr("TIVIMATE  •  PREMIUM IPTV"))
        self["featureTitle"].setText(tr("YOUR ENTERTAINMENT, ONE PLACE"))
        self["featureMeta"].setText(tr("Browse, discover and enjoy your library in one unified experience."))
        self["featureDesc"].setText(tr(""))
        self["playNow"].setText(tr("WATCH NOW"))
        # The Home row is never Recent Added anymore. While a feed is loading,
        # show the active Home feed title instead of the removed legacy label.
        home_labels = {
            "popular_movies": tr("Popular Show"),
            "popular_series": tr("Popular TV Shows"),
            "trending_movies": tr("Movies You Might Like"),
            "trending_series": tr("TV Shows You Might Like"),
        }
        self["recentTitle"].setText(home_labels.get(getattr(self, "homeContentMode", "popular_movies"), tr("Popular Show")))
        self._applyRecentTitleLayout()
        hero = os.path.join(PLUGIN_PATH, "skins", "home/tivimate_global_hero_r70.jpg")
        try:
            self.decodeImage(6, hero, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        except Exception:
            try: self["banner"].instance.setPixmapFromFile(hero)
            except Exception: pass

    def _homeRecentCacheKey(self, source=None, mode=None):
        mode = str(mode or getattr(self, "homeContentMode", "recent_movies") or "recent_movies")
        raw = "%s|%s" % (_source_identity(source or self.source or {}), mode)
        try:
            return hashlib.sha1(raw.encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(raw).encode("utf-8")).hexdigest()

    def _homeMovieIndexCacheKey(self, source=None):
        try:
            return hashlib.sha1(_source_identity(source or self.source or {}).encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(_source_identity(source or self.source or {})).encode("utf-8")).hexdigest()

    def _loadCachedHomeMovieIndex(self):
        try:
            if not os.path.isfile(_home_movie_index_file()):
                return []
            with open_text(_home_movie_index_file(), "r") as handle:
                payload = json.load(handle) or {}
            row = (payload.get("sources") or {}).get(self._homeMovieIndexCacheKey(), {})
            items = row.get("items") or []
            return list(items or [])
        except Exception:
            return []

    def _saveCachedHomeMovieIndex(self, rows, source=None):
        try:
            ensure_dir(os.path.dirname(_home_movie_index_file()))
            payload = {}
            if os.path.isfile(_home_movie_index_file()):
                try:
                    with open_text(_home_movie_index_file(), "r") as handle:
                        payload = json.load(handle) or {}
                except Exception:
                    payload = {}
            sources = payload.get("sources")
            if not isinstance(sources, dict):
                sources = {}
            # Keep enough rows for fast in-memory matching, but not an unlimited catalog.
            sources[self._homeMovieIndexCacheKey(source)] = {
                "saved": int(time.time()),
                "items": list(rows or [])[:2500],
            }
            payload["sources"] = sources
            with open_text(_home_movie_index_file(), "w") as handle:
                json.dump(payload, handle)
        except Exception:
            pass

    def _preloadHomeMovieIndex(self):
        if not self.source:
            return

        # Paint/use last known index immediately if available.
        if not self.homeMovieServerItems:
            try:
                cached = self._loadCachedHomeMovieIndex()
                if cached:
                    self.homeMovieServerItems = cached
            except Exception:
                pass

        if self.homeMovieIndexLoading:
            return

        self.homeMovieIndexLoading = True
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)

        def worker():
            rows = []
            try:
                rows = list(get_filtered_streams(source, "vod", get_source_client(source)) or [])
            except Exception:
                rows = []
            def finish():
                self.homeMovieIndexLoading = False
                if self._sourceJobValid(generation, source) and rows:
                    self.homeMovieServerItems = rows
                    try:
                        self._saveCachedHomeMovieIndex(rows, source)
                    except Exception:
                        pass
            try:
                if reactor:
                    reactor.callFromThread(finish)
                else:
                    finish()
            except Exception:
                try:
                    finish()
                except Exception:
                    pass

        t = thread_factory(target=worker, name="TiviMateHomeMovieIndex")
        t.daemon = True
        t.start()

    def _homeCategoryText(self, category):
        row = category or {}
        return str(
            row.get("category_name") or row.get("name") or
            row.get("title") or row.get("genre") or ""
        ).strip().lower()

    def _homeCategoryAllowed(self, category, kind):
        """Keep Home server rails movie/series-only without doing network work."""
        text = self._homeCategoryText(category)
        if not text:
            return True
        # These are provider packages that are often exposed through VOD even
        # though they are not films/series.  Reject them before fetching rows.
        blocked = (
            "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
            "wwe", "wrestling", "raw", "smackdown", "nxt",
            "sport", "sports", "football", "soccer", "match", "matches", "event", "events",
            "anime", "animation", "cartoon", "kids", "children", "child",
            "theater", "theatre", "plays", "stage",
            "music", "songs", "concert", "karaoke",
            "program", "programs", "xxx", "adult", "18+",
            "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
            "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
            "اغاني", "أغاني", "برامج"
        )
        if any(token in text for token in blocked):
            return False
        if kind == "vod":
            wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
        else:
            wrong = ("movie", "movies", "film", "films", "cinema", "افلام", "أفلام")
        return not any(token in text for token in wrong)

    def _homeItemAllowed(self, item, kind, category_name=""):
        row = item or {}
        text = u" ".join(text_type(row.get(k) or u"") for k in (
            "name", "title", "genre", "category_name", "description"
        )).lower()
        if category_name:
            text += u" " + text_type(category_name).lower()
        blocked = (
            "ufc", "efc", "mma", "boxing", "boxer", "fight", "fighting", "combat", "ppv",
            "wwe", "wrestling", "smackdown", "nxt",
            "sport", "sports", "football", "soccer", "match", "matches",
            "anime", "animation", "cartoon", "kids", "children",
            "theater", "theatre", "stage", "music", "concert", "karaoke",
            "program", "programs", "xxx", "adult",
            "مصارعة", "رياضة", "رياضي", "مباريات", "قتال", "ملاكمة",
            "انمي", "أنمي", "كرتون", "اطفال", "أطفال", "مسرح", "مسرحيات",
            "اغاني", "أغاني", "برامج"
        )
        if any(token in text for token in blocked):
            return False
        if kind == "vod":
            wrong = ("series", "tv show", "tvshow", "مسلسل", "مسلسلات")
        else:
            wrong = ("movie", "movies", "film", "cinema", "افلام", "أفلام")
        return not any(token in text for token in wrong)

    def _homeCanonicalKey(self, item, kind):
        """Collapse the same title across 4K/FHD/language/provider copies."""
        row = item or {}
        tmdb_id = str(row.get("tmdb_id") or row.get("tmdb") or "").strip()
        if tmdb_id and tmdb_id not in ("0", "None", "none"):
            return "tmdb:%s:%s" % (str(kind or "vod"), tmdb_id)
        raw = text_type(row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or u"")
        year_text = " ".join(str(row.get(k) or "") for k in (
            "year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"
        ))
        m = re.search(r"\b(?:19|20)\d{2}\b", year_text)
        year = m.group(0) if m else ""
        text = raw.lower()
        text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
        text = re.sub(
            r"(?i)\b(?:8k|4k|uhd|fhd|fullhd|hd|sd|2160p|1080p|720p|hdr|hdr10|dv|dolby|atmos|"
            r"hevc|x265|x264|h265|h264|web[- ]?dl|webrip|bluray|blu[- ]?ray|remux|"
            r"nf|netflix|amz|amzn|amazon|prime|prime video|ar|ara|arabic|en|eng|english|fr|french|"
            r"sub|subs|dub|dubbed|multi)\b", " ", text
        )
        text = re.sub(r"[\[\]{}()_.|:+/\\-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        if not text:
            sid = str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or "").strip()
            return "id:%s:%s" % (str(kind or "vod"), sid)
        return "%s|%s|%s" % (str(kind or "vod"), text, year)

    def _homeQualityScore(self, item):
        text = " ".join(str((item or {}).get(k) or "") for k in ("name", "title", "quality", "container_extension")).lower()
        score = 0
        if "8k" in text:
            score = 80
        elif "4k" in text or "2160" in text:
            score = 70
        elif "uhd" in text:
            score = 65
        elif "fhd" in text or "1080" in text:
            score = 50
        elif re.search(r"\bhd\b|720", text):
            score = 30
        elif re.search(r"\bsd\b", text):
            score = 10
        # Prefer the copy with richer artwork/metadata when quality is tied.
        meta = sum(1 for k in ("stream_icon", "cover_big", "cover", "movie_image", "poster", "backdrop_path", "rating", "plot") if (item or {}).get(k))
        return score * 100 + meta

    def _homeDeduplicate(self, items, kind):
        best = {}
        order = []
        for raw in list(items or []):
            if not isinstance(raw, dict):
                continue
            row = dict(raw)
            key = self._homeCanonicalKey(row, kind)
            if not key:
                continue
            if key not in best:
                best[key] = row
                order.append(key)
            elif self._homeQualityScore(row) > self._homeQualityScore(best[key]):
                best[key] = row
        return [best[k] for k in order if k in best]

    def _homeStampSource(self, row, source, kind, cid="", category_name=""):
        item = dict(row or {})
        cid = str(cid or item.get("category_id") or item.get("categoryId") or "").strip()
        if cid:
            item["category_id"] = cid
            item["_source_category_id"] = cid
        if category_name:
            item["_source_category_name"] = str(category_name)
        item["_source_scope"] = "home_category" if cid else "home"
        item["_source_server_id"] = _source_identity(source or {})
        item["_tivimate_home_kind"] = kind
        return item

    def _homeContextItems(self, item, kind):
        """Resolve the selected Home item's real package from RAM/disk only."""
        row = dict(item or {})
        cid = str(row.get("_source_category_id") or row.get("category_id") or row.get("categoryId") or "").strip()
        if not cid or not self.source:
            return list(self.recent or [])
        rows = []
        try:
            rows, _origin = get_category_streams(
                self.source, kind, get_source_client(self.source), cid,
                use_cache=True, wait_for_server=False
            )
        except Exception:
            rows = []
        if not rows:
            candidates = list(self.homeMovieServerItems or []) + list(self.recent or [])
            rows = [x for x in candidates if str((x or {}).get("category_id") or (x or {}).get("categoryId") or "").strip() == cid]
        cname = str(row.get("_source_category_name") or "")
        stamped = [self._homeStampSource(x, self.source, kind, cid, cname) for x in list(rows or []) if isinstance(x, dict)]
        return self._homeDeduplicate(stamped, kind) or [row]

    def _startHomeServer2026Rotating(self, mode):
        """Home rows use enabled packages; You Might Like accepts release years 2024-2026."""
        # Disable all non-Popular Home fetch modes on Classic at the source,
        # not only their visible headings. The Cinema feed stays untouched.
        if self.homeSkinName == "skin2_dark":
            mode = "popular_movies"
            self.homeContentMode = mode
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        mode = str(mode or "popular_movies")
        kind = "series" if mode in ("popular_series", "trending_series") else "vod"
        # A previous mode's worker must never repaint this feed after a switch.
        self._homeFeedToken = getattr(self, "_homeFeedToken", 0) + 1
        feed_token = self._homeFeedToken
        self._homeFeedWaitStarted = monotonic()
        self._homeFeedWaitExpired = False
        try: self.stalkerRecentTimer.stop()
        except Exception: pass
        self.stalkerRecentResult = None

        # Separate cache namespace so older pool/rotation results can never leak in.
        # Popular rows are plain/random from enabled packages only.
        # You Might Like rows are random 2024-2026 matches from enabled packages only.
        if mode in ("popular_movies", "popular_series"):
            base_cache_mode = ("popular_series_seriesonly_v3" if mode == "popular_series" else "popular_show_moviesonly_v5")
        else:
            base_cache_mode = "enabled_packages_2024_2026_streaming_priority_v3_%s" % mode
        cache_mode = _home_server_filter_cache_mode(source, base_cache_mode)
        cached = _home_server_2026_cache_get(source, cache_mode)
        if cached:
            try:
                self._recentReady(cached)
            except Exception:
                pass
            return

        # Cache-first startup: a 6-hour rotation must not blank the Home row
        # and show loading again when perfectly usable saved items still exist.
        # Keep the package-filter/source-specific key; refresh expired results
        # asynchronously so the displayed row is replaced only when ready.
        saved = _home_server_2026_cache_get_any(source, cache_mode)
        if saved:
            try:
                self._recentReady(saved)
            except Exception:
                pass
        else:
            try:
                self["status"].setText(tr(""))
            except Exception:
                pass

        def worker():
            try:
                # A server switch/exit invalidates this generation. Do not
                # issue any new provider calls for a now-inactive server.
                if not self._sourceJobValid(generation, source):
                    return
                import random
                client = get_source_client(source)
                q = "2026"

                # Popular Show on Home = Movies only.
                # Pick eight random Movies from enabled movie packages.
                if mode == "popular_movies" and source.get("type") not in ("m3u", "fg"):
                    def collect_popular_kind(home_kind, target):
                        allowed_kind = get_allowed_category_ids(source, home_kind)
                        if allowed_kind is None:
                            try:
                                cats, _origin = get_cached_categories(
                                    source, home_kind, client=client, wait_for_server=True
                                )
                            except Exception:
                                cats = []
                            allowed_kind = set(
                                str((cat or {}).get("category_id") or (cat or {}).get("id") or
                                    (cat or {}).get("genre_id") or (cat or {}).get("group_id") or "").strip()
                                for cat in (cats or [])
                                if isinstance(cat, dict)
                            )
                        allowed_kind = set(str(x) for x in (allowed_kind or []) if str(x))
                        if not allowed_kind:
                            return []

                        names = {}
                        ordered = []
                        try:
                            cats, _origin = get_cached_categories(
                                source, home_kind, client=client, wait_for_server=False
                            )
                            if not cats:
                                cats, _origin = get_cached_categories(
                                    source, home_kind, client=client, wait_for_server=True
                                )
                            for cat in cats or []:
                                if not isinstance(cat, dict):
                                    continue
                                cid = str(cat.get("category_id") or cat.get("id") or "").strip()
                                if not cid:
                                    continue
                                names[cid] = str(cat.get("category_name") or cat.get("name") or "")
                                if cid in allowed_kind and cid not in ordered:
                                    ordered.append(cid)
                        except Exception:
                            pass

                        for cid in allowed_kind:
                            if cid not in ordered:
                                ordered.append(cid)
                        random.shuffle(ordered)

                        result = []
                        seen_local = set()
                        # Four packages at a time; stop as soon as this kind has its share.
                        for offset in range(0, len(ordered), 4):
                            if not self._sourceJobValid(generation, source):
                                return []
                            batch_ids = ordered[offset:offset + 4]
                            batches = get_category_streams_batch(
                                source, home_kind, client, batch_ids,
                                use_cache=True, wait_for_server=True, max_workers=4
                            )
                            by_cid = dict((str(cid), list(rows or [])) for cid, rows, _origin in batches)
                            for cid in batch_ids:
                                candidates = [x for x in by_cid.get(str(cid), []) if isinstance(x, dict)]
                                random.shuffle(candidates)
                                for raw in candidates:
                                    item_cid = str(
                                        raw.get("category_id") or raw.get("categoryId") or
                                        raw.get("genre_id") or raw.get("genre-id") or cid
                                    )
                                    if item_cid and item_cid not in allowed_kind:
                                        continue
                                    row = self._homeStampSource(
                                        raw, source, home_kind, cid, names.get(str(cid), "")
                                    )
                                    key = self._homeCanonicalKey(row, home_kind)
                                    if not key or key in seen_local:
                                        continue
                                    seen_local.add(key)
                                    row["_home_server_2026"] = True
                                    row["_home_rotation_mode"] = mode
                                    result.append(row)
                                    break
                                if len(result) >= target:
                                    break
                            if len(result) >= target:
                                break
                        return result[:target]

                    rows = collect_popular_kind("vod", 8)
                    random.shuffle(rows)

                    if not rows:
                        raise RuntimeError("No movies are available in enabled packages")

                    if not self._sourceJobValid(generation, source):
                        return
                    _home_server_2026_cache_put(source, cache_mode, rows[:8])
                    if self._sourceJobValid(generation, source) and self._homeFeedToken == feed_token and not self._homeFeedWaitExpired:
                        self.stalkerRecentResult = (-100, rows[:8], "")
                    return

                # M3U Home support: Packages already use group-title as the stable
                # category identity. Reuse the same enabled package filters here and
                # build Home directly from the cached playlist instead of calling the
                # Xtream/Stalker category API that M3U does not implement.
                if source.get("type") in ("m3u", "fg") and mode == "popular_movies":
                    allowed = get_allowed_category_ids(source, kind)
                    entries, _origin = get_cached_catalog(
                        source, "live", lambda: M3UClient(source).entries(),
                        wait_for_server=True
                    )
                    if allowed is None:
                        allowed = set(
                            str((row or {}).get("group") or (row or {}).get("category_id") or "").strip()
                            for row in (entries or [])
                            if isinstance(row, dict)
                        )
                    allowed = set(str(x) for x in (allowed or []) if str(x))
                    if not allowed:
                        raise RuntimeError("No enabled packages are selected")
                    entries, _origin = get_cached_catalog(
                        source, "live", lambda: M3UClient(source).entries(),
                        wait_for_server=True
                    )
                    grouped = {}
                    for raw in list(entries or []):
                        if not isinstance(raw, dict):
                            continue
                        cid = str(raw.get("group") or raw.get("category_id") or "").strip()
                        if not cid or cid not in allowed:
                            continue
                        title = str(raw.get("name") or raw.get("title") or "")
                        if mode not in ("popular_movies", "popular_series"):
                            item_year = self._recentYear(raw)
                            if item_year not in (2024, 2025, 2026):
                                continue
                        row = self._homeStampSource(raw, source, kind, cid, cid)
                        row["_home_server_2026"] = True
                        row["_home_rotation_mode"] = mode
                        grouped.setdefault(cid, []).append(row)

                    pool = []
                    seen = set()
                    target_count = 8
                    ordered_ids = list(allowed)
                    random.shuffle(ordered_ids)

                    if mode == "popular_movies":
                        # Match the normal Home diversity rule: one random title per
                        # enabled package first, then continue only if more are needed.
                        for cid in ordered_ids:
                            candidates = list(grouped.get(cid, []))
                            random.shuffle(candidates)
                            for row in candidates:
                                key = self._homeCanonicalKey(row, kind)
                                if not key or key in seen:
                                    continue
                                seen.add(key)
                                pool.append(row)
                                break
                            if len(pool) >= target_count:
                                break
                        if len(pool) < target_count:
                            leftovers = []
                            for cid in ordered_ids:
                                leftovers.extend(grouped.get(cid, []))
                            random.shuffle(leftovers)
                            for row in leftovers:
                                key = self._homeCanonicalKey(row, kind)
                                if not key or key in seen:
                                    continue
                                seen.add(key)
                                pool.append(row)
                                if len(pool) >= target_count:
                                    break
                    else:
                        for cid in ordered_ids:
                            pool.extend(grouped.get(cid, []))
                        pool = self._homeDeduplicate(pool, kind)
                        random.shuffle(pool)

                    pool = self._homeDeduplicate(pool, kind)
                    if not pool:
                        if mode in ("popular_movies", "popular_series"):
                            raise RuntimeError("No content is available in enabled packages")
                        raise RuntimeError("No content is available in enabled packages")

                    rows = pool[:target_count]
                    if not self._sourceJobValid(generation, source):
                        return
                    _home_server_2026_cache_put(source, cache_mode, rows)
                    if self._sourceJobValid(generation, source) and self._homeFeedToken == feed_token and not self._homeFeedWaitExpired:
                        self.stalkerRecentResult = (-100, rows, "")
                    return

                # You Might Like: enabled-package items released in 2024, 2025, or 2026.
                # Popular Movies/TV Shows are different by design: any enabled item is eligible.
                # selected package ids only -> cache-backed package streams ->
                # local title/name substring match. No secondary catalog/fallback.
                allowed = get_allowed_category_ids(source, kind)
                # A brand-new server has no saved package filter yet. Everywhere
                # else in the app, None means "all packages enabled"; Home must
                # follow the same rule instead of treating None as no packages.
                if allowed is None:
                    try:
                        _all_categories, _all_origin = get_cached_categories(
                            source, kind, client=client, wait_for_server=True
                        )
                    except Exception:
                        _all_categories = []
                    allowed = set(
                        str((cat or {}).get("category_id") or (cat or {}).get("id") or
                            (cat or {}).get("genre_id") or (cat or {}).get("group_id") or "").strip()
                        for cat in (_all_categories or [])
                        if isinstance(cat, dict)
                    )
                allowed = set(str(x) for x in (allowed or []) if str(x))
                if not allowed:
                    raise RuntimeError("No enabled packages are selected")

                ordered_ids = []
                category_names = {}
                try:
                    categories, _origin = get_cached_categories(
                        source, kind, client=client, wait_for_server=False
                    )
                    # First launch after a manual cache delete: the category cache can
                    # legitimately be empty. In that case rebuild it once from the
                    # server before deciding that Home has no enabled content.
                    if not categories:
                        categories, _origin = get_cached_categories(
                            source, kind, client=client, wait_for_server=True
                        )
                    for cat in categories or []:
                        if not isinstance(cat, dict):
                            continue
                        cid = str(cat.get("category_id") or "")
                        if cid:
                            category_names[cid] = str(cat.get("category_name") or cat.get("name") or "")
                        if cid and cid in allowed and cid not in ordered_ids:
                            if mode == "popular_series" and not self._homeCategoryAllowed(cat, "series"):
                                continue
                            ordered_ids.append(cid)
                except Exception:
                    pass

                # You Might Like: prioritize familiar streaming-provider packages, but
                # ONLY when those packages are enabled. Remaining enabled packages stay
                # as fallback so the row can still fill to eight items.
                if mode in ("trending_movies", "trending_series"):
                    provider_terms = (
                        "netflix", "prime video", "amazon prime", "amazon",
                        "disney+", "disney plus", "disney", "max", "hbo",
                        "apple tv+", "apple tv", "paramount+", "paramount",
                        "hulu", "peacock", "starz", "shahid", "osn+", "osn"
                    )
                    def _provider_rank(cid):
                        name = str(category_names.get(str(cid), "") or "").lower()
                        for pos, term in enumerate(provider_terms):
                            if term in name:
                                return (0, pos)
                        return (1, 999)
                    ordered_ids.sort(key=_provider_rank)

                # Enabled package IDs are already kind-scoped by
                # get_allowed_category_ids(source, kind). Keep them as a fallback for
                # every Home mode so Movies and TV Shows both recover after cache loss,
                # even if category metadata is temporarily unavailable.
                for cid in allowed:
                    if cid not in ordered_ids:
                        ordered_ids.append(cid)

                pool = []
                seen = set()
                target_count = 8

                if mode == "popular_movies":
                    # r139 Popular Show: keep provider/enabled-package order and take
                    # ONE random item from each package. Start with the first 8 enabled
                    # packages; if a package is empty/duplicate, continue to the next
                    # package until eight unique Home items are ready. No year/rating/type
                    # filtering is done here -- speed and package diversity come first.
                    for offset in range(0, len(ordered_ids), 8):
                        if not self._sourceJobValid(generation, source):
                            return
                        batch_ids = ordered_ids[offset:offset + 8]
                        package_batches = get_category_streams_batch(
                            source, kind, client, batch_ids,
                            use_cache=True, wait_for_server=True, max_workers=4
                        )
                        by_cid = dict((str(cid), list(rows or [])) for cid, rows, _origin in package_batches)
                        for cid in batch_ids:
                            candidates = [x for x in by_cid.get(str(cid), []) if isinstance(x, dict)]
                            random.shuffle(candidates)
                            chosen = None
                            for raw in candidates:
                                item_cid = str(
                                    raw.get("category_id") or raw.get("categoryId") or
                                    raw.get("genre_id") or raw.get("genre-id") or ""
                                )
                                if item_cid and item_cid not in allowed:
                                    continue
                                row = self._homeStampSource(raw, source, kind, cid, category_names.get(cid, ""))
                                key = self._homeCanonicalKey(row, kind)
                                if not key or key in seen:
                                    continue
                                seen.add(key)
                                row["_home_server_2026"] = True
                                row["_home_rotation_mode"] = mode
                                chosen = row
                                break
                            if chosen is not None:
                                pool.append(chosen)
                            if len(pool) >= target_count:
                                break
                        if len(pool) >= target_count:
                            break
                else:
                    # Existing Popular TV / You Might Like behavior.
                    if mode == "popular_series":
                        random.shuffle(ordered_ids)
                    batch_size = 4
                    for offset in range(0, len(ordered_ids), batch_size):
                        if not self._sourceJobValid(generation, source):
                            return
                        package_batches = get_category_streams_batch(
                            source, kind, client, ordered_ids[offset:offset + batch_size],
                            use_cache=True, wait_for_server=True, max_workers=4
                        )
                        for cid, rows, _origin in package_batches:
                            for raw in rows or []:
                                if not isinstance(raw, dict):
                                    continue
                                item_cid = str(
                                    raw.get("category_id") or raw.get("categoryId") or
                                    raw.get("genre_id") or raw.get("genre-id") or ""
                                )
                                if item_cid and item_cid not in allowed:
                                    continue
                                title = str(raw.get("name") or raw.get("title") or "")
                                if mode not in ("popular_movies", "popular_series"):
                                    item_year = self._recentYear(raw)
                                    if item_year not in (2024, 2025, 2026):
                                        continue
                                if mode == "popular_series" and not self._homeItemAllowed(raw, "series", category_names.get(str(cid), "")):
                                    continue
                                row = self._homeStampSource(raw, source, kind, cid, category_names.get(cid, ""))
                                key = self._homeCanonicalKey(row, kind)
                                if not key:
                                    continue
                                if key in seen:
                                    for idx, existing in enumerate(pool):
                                        if self._homeCanonicalKey(existing, kind) == key and self._homeQualityScore(row) > self._homeQualityScore(existing):
                                            pool[idx] = row
                                            break
                                    continue
                                seen.add(key)
                                row["_home_server_2026"] = True
                                row["_home_rotation_mode"] = mode
                                pool.append(row)
                        pool = self._homeDeduplicate(pool, kind)
                        if len(pool) >= target_count:
                            break

                pool = self._homeDeduplicate(pool, kind)
                if not pool:
                    if mode in ("popular_movies", "popular_series"):
                        raise RuntimeError("No content is available in enabled packages")
                    raise RuntimeError("No content is available in enabled packages")

                # One final selection only. TMDb must never repaint the row.
                # Final Home selection is random for all four rows.
                # Popular: any enabled content. You Might Like: enabled content from 2024-2026.
                if mode != "popular_movies":
                    random.shuffle(pool)
                rows = pool[:8]

                if not rows:
                    if mode in ("popular_movies", "popular_series"):
                        raise RuntimeError("No usable content is available")
                    raise RuntimeError("No usable content is available in enabled packages")
                if not self._sourceJobValid(generation, source):
                    return
                _home_server_2026_cache_put(source, cache_mode, rows)
                if self._sourceJobValid(generation, source) and self._homeFeedToken == feed_token and not self._homeFeedWaitExpired:
                    self.stalkerRecentResult = (-100, rows, "")
            except Exception as exc:
                if self._sourceJobValid(generation, source) and self._homeFeedToken == feed_token and not self._homeFeedWaitExpired:
                    self.stalkerRecentResult = (-100, [], str(exc))

        thread = thread_factory(target=worker, name="TiviMateHomeExactSearch2026_%s" % mode)
        thread.daemon = True
        thread.start()
        try:
            self.stalkerRecentTimer.start(120, True)
        except Exception:
            pass

    def startLoad(self):
        if not self.source:
            self["status"].setText(tr("No server selected • Press SETTINGS"))
            return

        mode = getattr(self, "homeContentMode", "popular_movies") or "popular_movies"
        if self.homeSkinName == "skin2_dark":
            mode = "popular_movies"
            self.homeContentMode = mode
        valid_modes = ("popular_movies", "popular_series", "trending_movies", "trending_series")
        if mode not in valid_modes:
            mode = "popular_movies"
            self.homeContentMode = mode
        return self._startHomeServer2026Rotating(mode)

    def _finishStalkerRecentLoad(self):
        result = self.stalkerRecentResult
        if result is None:
            # The existing 60-second slow-server ceiling is a UI wait guard,
            # not a network timeout. Cached Home cards stay visible throughout.
            started = getattr(self, "_homeFeedWaitStarted", monotonic())
            if getattr(self, "_homeClosed", False):
                return
            if monotonic() - started >= 60.0:
                self._homeFeedWaitExpired = True
                self._homeFeedToken = getattr(self, "_homeFeedToken", 0) + 1
                try: self.stalkerRecentTimer.stop()
                except Exception: pass
                if not getattr(self, "recent", None):
                    self._recentFailed("Server did not respond. Retry or switch server.")
                return
            try:
                self.stalkerRecentTimer.start(120, True)
            except Exception:
                pass
            return

        if self.stalkerRecentResult is result:
            self.stalkerRecentResult = None

        token, items, error = result
        if token != -100:
            return
        if error or not items:
            self._recentFailed(error or "Server returned no Home content")
            return
        self._recentReady(items)

    def _recentFailed(self, error):
        self["status"].setText("Unable to load Home content: %s" % error)

    def _recentReady(self, items, background=True):
        mode = getattr(self, "homeContentMode", "popular_movies")
        home_kind = "series" if mode.endswith("_series") else "vod"
        items = _dedupe_content_rows(items or [], home_kind)[:6]
        # If cached content is already visible and the background refresh found
        # exactly the same six entries, keep the existing pixmaps/hero untouched.
        try:
            old_ids = [str((x or {}).get("stream_id") or (x or {}).get("vod_id") or (x or {}).get("name") or "") for x in self.recent]
            new_ids = [str((x or {}).get("stream_id") or (x or {}).get("vod_id") or (x or {}).get("name") or "") for x in items]
            if background and self.recent and old_ids == new_ids:
                return
        except Exception:
            pass
        # GENRE cancels stale card jobs on page changes. Classic follows the
        # same rule without clearing the cache or the static hero.
        manager = getattr(self, '_classicGenrePosters', None)
        if manager is not None:
            manager.begin_page()
        self.recent = items
        heading = tr("Popular Show")
        mode = getattr(self, "homeContentMode", "popular_movies")
        labels = {
            "popular_movies": tr("Popular Show"),
            "popular_series": tr("Popular TV Shows"),
            "trending_movies": tr("Movies You Might Like"),
            "trending_series": tr("TV Shows You Might Like"),
        }
        heading = labels.get(mode, heading)
        status_label = tr("%d Home picks") % len(self.recent)
        self["recentTitle"].setText(gui_text(heading))
        self._applyRecentTitleLayout()
        # VTi/Python2 eLabel_setText expects UTF-8 str, not unicode.
        # Normalize provider names, including Arabic, before crossing SWIG.
        status = text_type(tr("Server: %s  •  %s")) % (
            text_type(self.source.get("name") or "SERVER"), text_type(status_label))
        self["status"].setText(gui_text(status))
        for i, item in enumerate(self.recent[:6]):
            pw, ph = self.posterSize
            poster_url = item.get("stream_icon") or item.get("cover_big") or item.get("cover") or item.get("movie_image") or item.get("poster") or ""
            self.loadImage(i, poster_url, "poster%d" % i, pw, ph, fallback_item=item)
            title = text_type(item.get("name") or item.get("title") or u"").strip()
            rating = str(item.get("rating") or item.get("rating_5based") or "").strip()
            self["posterMetaTitle%d" % i].setText(gui_text(visible_title(title, 26)))
            self["posterMetaRate%d" % i].setText(rating[:4])
        self.posterIndex = 0
        self.globalHero = not bool(self.recent)
        if self.globalHero:
            self.applyGlobalHero()
        else:
            self.updateFeature()
        self.updateFocus()

    def updateFeature(self):
        # The selected poster owns the banner once the library row is ready.
        if not self.recent: return
        item = self.recent[min(self.posterIndex, len(self.recent)-1)]
        self["featureTitle"].setText(gui_text(visible_title(item.get("name") or item.get("title") or "MOVIE", 55).upper()))
        year = text_type(item.get("year") or item.get("releaseDate") or u"")
        rating = text_type(item.get("rating") or u"")
        genre = text_type(item.get("genre") or u"")
        meta = u"  •  ".join(x for x in (year, (u"★ " + rating) if rating else u"", genre) if x)
        self["featureMeta"].setText(gui_text(meta))
        self["featureDesc"].setText(gui_text(text_type(item.get("plot") or
            item.get("description") or u"From the selected server.")[:180]))

        # Classic runs without remote/rotating hero backdrops. Keep its
        # existing local, static hero: only the selected text changes here.
        # Increment the token to discard any pre-switch/late backdrop callback.
        self.featureRequestId += 1
        if self.homeSkinName == "skin2_dark":
            return
        # Cinema can continue its existing preview/backdrop behavior.
        request_id = self.featureRequestId
        stream_id = item.get("stream_id") or item.get("vod_id")
        direct_backdrop = self._normaliseBackdrop(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        if direct_backdrop:
            self.loadImage(6, direct_backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)
        elif stream_id:
            source = dict(self.source or {})
            generation = getattr(self, "_sourceGeneration", 0)
            item_snapshot = dict(item or {})
            thread = thread_factory(target=self._loadFeatureBackdrop, args=(stream_id, request_id, source, generation, item_snapshot), name="TiviMateBackdrop")
            thread.daemon = True
            thread.start()

    def _normaliseBackdrop(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if not isinstance(value, str):
            return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("["):
            try:
                arr = json.loads(value)
                value = arr[0] if arr else ""
            except Exception:
                pass
        if value.startswith("/") and not value.startswith("//"):
            value = "https://image.tmdb.org/t/p/w780" + value
        return value if value.startswith(("http://", "https://")) else ""

    def _cleanRecentTitle(self, value):
        import re
        text = text_type(value or u"")
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray|top)\b", u" ", text, flags=re.I)
        text = re.sub(r"[\[\]{}()_.|:+-]+", " ", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _recentYear(self, item):
        import re
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        match = re.search(r"\b(?:19|20)\d{2}\b", raw)
        return int(match.group(0)) if match else None

    def _loadFeatureBackdrop(self, stream_id, request_id, source=None, generation=None, item_snapshot=None):
        # Defensive guard: old queued requests must not fetch a Classic backdrop.
        if self.homeSkinName == "skin2_dark":
            return
        source = dict(source or self.source or {})
        generation = getattr(self, "_sourceGeneration", 0) if generation is None else generation
        item_snapshot = dict(item_snapshot or {})
        try:
            if not self._sourceJobValid(generation, source):
                return
            # M3U rows carry a synthetic stream_id, not an Xtream VOD id. Skip
            # Xtream metadata for M3U and let the existing TMDb fallback resolve
            # the real backdrop from the title/year.
            if source.get("type") in ("m3u", "fg"):
                data = {}
            else:
                data = XtreamClient(source).vod_info(stream_id) or {}
            info = {}
            if isinstance(data.get("movie_data"), dict): info.update(data.get("movie_data") or {})
            if isinstance(data.get("info"), dict): info.update(data.get("info") or {})
            backdrop = self._normaliseBackdrop(
                info.get("backdrop_path") or info.get("backdrop") or info.get("backdrop_url") or
                data.get("backdrop_path") or data.get("backdrop")
            )
            # Home Movies sometimes contains only a poster. Resolve the movie on
            # TMDb and use its true backdrop without changing any other section.
            if not backdrop:
                current = item_snapshot
                tmdb = TMDbClient()
                tid = info.get("tmdb_id") or info.get("tmdb") or current.get("tmdb_id") or current.get("tmdb")
                if not tid:
                    title = info.get("name") or current.get("name") or current.get("title") or ""
                    found = tmdb.search_artwork(title, "vod", self._recentYear(info or current), required_key="backdrop_path") if str(title or "").strip() else None
                    tid = (found or {}).get("id")
                bundle = tmdb.details_bundle(tid, "vod") if tid else {}
                backdrop = self._normaliseBackdrop(bundle.get("backdrop_path"))
            if backdrop and request_id == self.featureRequestId and self._sourceJobValid(generation, source):
                if reactor is not None:
                    reactor.callFromThread(self._applyFeatureBackdropForSource, generation, source, request_id, backdrop)
                else:
                    self._applyFeatureBackdropForSource(generation, source, request_id, backdrop)
        except Exception:
            pass

    def _applyFeatureBackdropForSource(self, generation, source, request_id, backdrop):
        if self.homeSkinName == "skin2_dark":
            return
        if not self._sourceJobValid(generation, source):
            return
        if request_id != getattr(self, "featureRequestId", -1):
            return
        self.loadImage(6, backdrop, "banner", self.bannerSize[0], self.bannerSize[1], request_id=request_id)

    def _homePosterYear(self, item):
        try:
            raw = " ".join(str((item or {}).get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
            match = re.search(r"\b(?:19|20)\d{2}\b", raw)
            return int(match.group(0)) if match else None
        except Exception:
            return None

    def _homePosterKind(self, item):
        marker = str((item or {}).get("_tivimate_home_kind") or "").lower()
        if marker in ("series", "tv", "shows", "tvshows"):
            return "series"
        if (item or {}).get("series_id") is not None and not (item or {}).get("stream_id"):
            return "series"
        return "vod"

    def _homePosterFallback(self, item, slot, widget, width, height, failed_url=""):
        snapshot = dict(item or {})
        source = dict(self.source or {})
        generation = getattr(self, "_sourceGeneration", 0)
        key = (slot, widget)

        def worker():
            try:
                if not self._sourceJobValid(generation, source):
                    return
                title = snapshot.get("name") or snapshot.get("title") or snapshot.get("original_name") or snapshot.get("original_title") or ""
                if not str(title or "").strip():
                    return
                found = TMDbClient().search_artwork(
                    title,
                    self._homePosterKind(snapshot),
                    self._homePosterYear(snapshot),
                    required_key="poster_path"
                ) or {}
                poster = str(found.get("poster_path") or "").strip()
                if not poster:
                    return
                if poster.startswith("/"):
                    poster = "https://image.tmdb.org/t/p/w500" + poster

                def apply():
                    if not self._sourceJobValid(generation, source):
                        return
                    current = getattr(self, "_artwork_requests", {}).get(key)
                    if failed_url and current != (failed_url, None):
                        return
                    self.loadImage(slot, poster, widget, width, height)

                if reactor is not None:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = thread_factory(target=worker, name="TiviMateHomePosterFallback")
        t.daemon = True
        t.start()

    def _homePosterFileValid(self, path):
        """Cheap Home-card validation matching the working Movies/Series path."""
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            return bool(head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n"))
        except Exception:
            return False

    def loadImage(self, slot, url, widget, width, height, request_id=None, fallback_item=None):
        # Only Classic Home uses the GENRE-style visible-slot scheduler.
        # Cinema, Search and the Movies/Series pages retain their existing paths.
        manager = getattr(self, '_classicGenrePosters', None)
        if (manager is not None and request_id is None and
                widget == 'poster%d' % slot and isinstance(fallback_item, dict)):
            manager.request(slot, url, fallback_item, width, height)
            return
        if (request_id is None and widget.startswith('poster') and
                isinstance(fallback_item, dict)):
            from .shared_genre_posters import request_genre_poster
            source = dict(self.source or {})
            generation = getattr(self, '_sourceGeneration', 0)
            request_key = (slot, widget)
            if not hasattr(self, '_artwork_requests'):
                self._artwork_requests = {}
            ticket = object()
            self._artwork_requests[request_key] = ticket
            def stale():
                return (getattr(self, '_homeClosed', True) or
                        getattr(self, '_sourceGeneration', None) != generation or
                        getattr(self, '_artwork_requests', {}).get(request_key) is not ticket)
            def resolved(path, winner):
                if stale():
                    return
                def on_decoded():
                    try:
                        from .poster_resolution_cache import remember_decoded
                        remember_decoded(source, self._homePosterKind(fallback_item), fallback_item, winner)
                    except Exception:
                        pass
                self.decodeImage(slot, path, widget, width, height,
                                 expected_token=ticket, on_decoded=on_decoded)
            if request_genre_poster(source, fallback_item,
                                    self._homePosterKind(fallback_item), resolved,
                                    cancelled=stale, primary=url):
                return
        # Remote hero artwork is disabled in Classic; poster cards still load.
        if self.homeSkinName == "skin2_dark" and widget == "banner":
            return
        url = (url or "").strip().replace("\\/", "/")
        if not url or (request_id is not None and request_id != self.featureRequestId):
            return
        # One token per visual slot prevents a prior selection from painting over
        # the current poster or backdrop after the user moves the selection.
        requests = getattr(self, "_artwork_requests", None)
        if requests is None:
            requests = {}
            self._artwork_requests = requests
        token = (slot, widget)
        requests[token] = (url, request_id)
        priority = 120 if widget == "banner" else 75

        def done(path, s=slot, w=widget, x=width, y=height, rid=request_id, expected=(url, request_id), key=token, item=fallback_item):
            if getattr(self, "_artwork_requests", {}).get(key) != expected:
                return
            # Home used to treat HTTP-200 error bodies as posters.  The working
            # Movies/Series cards validate these bytes and immediately fall back
            # to TMDb, so use the exact same policy here.
            if item is not None and rid is None and not self._homePosterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._homePosterFallback(item, s, w, x, y, url)
                return
            self.decodeImage(s, path, w, x, y, request_id=rid)

        def failed(_path, s=slot, w=widget, x=width, y=height, expected_url=url, item=fallback_item):
            if item is not None and request_id is None:
                self._homePosterFallback(item, s, w, x, y, expected_url)

        request_artwork(url, "backdrops" if widget == "banner" else "posters", done,
                        priority=priority, errback=failed if fallback_item is not None else None,
                        source=dict(self.source or {}))

    def decodeImage(self, slot, path, widget, width, height, request_id=None,
                    expected_token=None, on_decoded=None):
        if request_id is not None and request_id != self.featureRequestId:
            return
        if expected_token is not None and getattr(self, '_artwork_requests', {}).get((slot, widget)) is not expected_token:
            return
        loader = ePicLoad(); self.imageLoaders[slot] = loader
        def ready(_info=None, slot=slot, widget=widget, request_id=request_id, l=loader):
            try:
                if request_id is not None and request_id != self.featureRequestId:
                    return
                if expected_token is not None and getattr(self, '_artwork_requests', {}).get((slot, widget)) is not expected_token:
                    return
                ptr = l.getData()
                if ptr and self[widget].instance:
                    self[widget].instance.setPixmap(ptr)
                    if on_decoded:
                        on_decoded()
            except Exception:
                pass
            finally:
                try:
                    if self.imageLoaders[slot] is l:
                        self.imageLoaders[slot] = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self, oneshot=True)
        # A zero aspect ratio makes ePicLoad fill the complete panorama.
        # Both remaining Home skins use this decoding path.
        # so selected movie backdrops cannot be letterboxed with black side areas.
        render_width, render_height = scale_size(width, height)
        if widget == "banner" and self.homeSkinName == "skin2_dark":
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        else:
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def playRecent(self):
        if not self.recent or not self.source:
            return
        item = dict(self.recent[self.posterIndex] or {})
        if item.get("_home_tmdb_feed") or item.get("_tmdb"):
            kind = str(item.get("_tivimate_home_kind") or item.get("media_type") or "vod")
            item["_home_tmdb_feed"] = item.get("_home_tmdb_feed") or getattr(self, "homeContentMode", "popular_movies")
            if kind == "series":
                self.session.open(SeriesDetailsScreen, self.source, item)
            else:
                # Home never checks server availability before opening details.
                # The details screen performs the provider search after entry.
                item["_source_scope"] = str(item.get("_source_scope") or "home")
                item["_source_server_id"] = _source_identity(self.source)
                cid = str(item.get("_source_category_id") or item.get("category_id") or "").strip()
                context_items = self._homeContextItems(item, "vod") if cid else list(self.homeMovieServerItems or [])
                self.session.open(
                    MovieDetailsScreen, self.source, item, context_items,
                    {"scope":item.get("_source_scope") or "home", "category_id":cid, "items":list(context_items or [])}
                )
            return

        kind = str(item.get("_tivimate_home_kind") or "vod")
        item["_recent_home"] = True
        if kind == "series":
            self.session.open(SeriesDetailsScreen, self.source, item)
        else:
            item["_source_scope"] = str(item.get("_source_scope") or "home_category")
            item["_source_server_id"] = _source_identity(self.source)
            cid = str(item.get("_source_category_id") or item.get("category_id") or "").strip()
            context_items = self._homeContextItems(item, "vod") if cid else list(self.recent or [])
            self.session.open(
                MovieDetailsScreen, self.source, item, context_items,
                {"scope":item.get("_source_scope") or "home_category", "category_id":cid, "items":list(context_items or [])}
            )

from .tivimate_player import TiviMatePlayer, _load_player_type


from Plugins.Extensions.TiviMateE2Py27.py27_futures import ThreadPoolExecutor as _ResumeThreadPoolExecutor
_RESUME_CIRCLE_POOL = _ResumeThreadPoolExecutor(max_workers=1, thread_name_prefix="TiviResumeCircle")

class ContinueWatchingScreen(Screen):
    RESUME_FILE = data_path("resume.json")
    VIEW_FILE = data_path("continue_view.json")
    skin = '<screen name="ContinueWatchingScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">\n<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />\n<widget name="hero" position="0,0" size="1920,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/continue_default_hero.jpg" alphatest="blend" scale="1" zPosition="1" />\n<ePixmap position="0,0" size="1920,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/content_overlay.png" alphatest="blend" zPosition="2" />\n<ePixmap position="20,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/home.png" alphatest="blend" zPosition="7" />\n<widget name="top0" position="46,15" size="140,64" font="Bold;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="190,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/search.png" alphatest="blend" zPosition="7" />\n<widget name="top1" position="216,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="360,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/live.png" alphatest="blend" zPosition="7" />\n<widget name="top2" position="386,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="530,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/movies.png" alphatest="blend" zPosition="7" />\n<widget name="top3" position="556,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="700,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/shows.png" alphatest="blend" zPosition="7" />\n<widget name="top4" position="726,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="870,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/packages.png" alphatest="blend" zPosition="7" />\n<widget name="top5" position="896,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="1040,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/genre.png" alphatest="blend" zPosition="7" />\n<widget name="top6" position="1066,15" size="140,64" font="Bold;22" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="1210,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/continue.png" alphatest="blend" zPosition="7" />\n<widget name="top7" position="1236,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="1380,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/server_finder.png" alphatest="blend" zPosition="7" />\n<widget name="top8" position="1406,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="1550,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/settings.png" alphatest="blend" zPosition="7" />\n<widget name="top9" position="1576,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<ePixmap position="1720,35" size="20,20" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/navicons/favorites.png" alphatest="blend" zPosition="7" />\n<widget name="top10" position="1746,15" size="140,64" font="Bold;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" noWrap="1" />\n<widget name="topSelector" position="15,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/nav_gold.png" alphatest="blend" zPosition="9" />\n<widget name="heroTitle" position="95,142" size="940,82" font="Regular;50" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroMeta" position="100,240" size="940,42" font="Regular;27" foregroundColor="#5ADAF4" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroStars" position="100,278" size="940,34" font="Regular;24" foregroundColor="#FFD34E" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="heroDesc" position="100,322" size="980,70" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />\n<widget name="heroProgress" position="100,418" size="650,12" backgroundColor="#38424D" foregroundColor="#FFFFFF" zPosition="5" />\n<widget name="heroPercent" position="770,402" size="130,36" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />\n<widget name="resumeWatchPill" position="1224,307" size="570,106" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_watchnow_pill.png" alphatest="blend" zPosition="8" />\n<widget name="resumeWatchCircle" position="1142,287" size="146,146" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_watchnow_circle_default.png" alphatest="blend" zPosition="9" />\n<widget name="resumeWatchCircleFrame" position="1142,287" size="146,146" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_watchnow_circle_frame.png" alphatest="blend" zPosition="10" />\n<widget name="resumeWatchText" position="1400,335" size="370,49" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="10" />\n<widget name="moviesTitle" position="80,468" size="720,38" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="moviesPage" position="1480,470" size="360,34" font="Regular;21" foregroundColor="#9ADFED" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" />\n<widget name="seriesTitle" position="80,724" size="720,38" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="seriesPage" position="1480,726" size="360,34" font="Regular;21" foregroundColor="#9ADFED" backgroundColor="#00000000" transparent="1" halign="right" zPosition="5" /><widget name="card0" position="82,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell0" position="80,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title0" position="94,705" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta0" position="96,692" size="110,22" font="Bold;20" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card1" position="537,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell1" position="535,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title1" position="549,705" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta1" position="551,692" size="110,22" font="Bold;20" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card2" position="992,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell2" position="990,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title2" position="1004,705" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta2" position="1006,692" size="110,22" font="Bold;20" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card3" position="1447,527" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell3" position="1445,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title3" position="1459,705" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta3" position="1461,692" size="110,22" font="Bold;20" foregroundColor="#F3C74F" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card4" position="82,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell4" position="80,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title4" position="94,950" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta4" position="96,937" size="110,22" font="Bold;20" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card5" position="537,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell5" position="535,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title5" position="549,950" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta5" position="551,937" size="110,22" font="Bold;20" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card6" position="992,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell6" position="990,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title6" position="1004,950" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta6" position="1006,937" size="110,22" font="Bold;20" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="card7" position="1447,772" size="406,160" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/banner_placeholder.jpg" alphatest="blend" scale="1" zPosition="2" />\n<widget name="shell7" position="1445,770" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_shell_r75_410x210.png" alphatest="blend" scale="1" zPosition="3" />\n<widget name="title7" position="1459,950" size="360,22" font="Regular;19" foregroundColor="#F7F9FC" backgroundColor="#00000000" transparent="1" zPosition="5" />\n<widget name="meta7" position="1461,937" size="110,22" font="Bold;20" foregroundColor="#55D9F2" backgroundColor="#00000000" transparent="1" zPosition="5" /><widget name="prog0" position="98,719" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play0" position="100,599" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog1" position="553,719" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play1" position="555,599" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog2" position="1008,719" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play2" position="1010,599" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog3" position="1463,719" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play3" position="1465,599" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog4" position="98,964" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play4" position="100,844" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog5" position="553,964" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play5" position="555,844" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog6" position="1008,964" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play6" position="1010,844" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="prog7" position="1463,964" size="388,10" backgroundColor="#27323B" foregroundColor="#2AA6FF" zPosition="7" />\n<widget name="play7" position="1465,844" size="58,58" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/resume_play_overlay_58.png" alphatest="blend" zPosition="7" />\n<widget name="focus" position="80,525" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/poster_card_focus_r75_410x210.png" alphatest="blend" scale="1" zPosition="8" />\n<widget name="empty" position="365,620" size="1190,70" font="Regular;28" foregroundColor="#AAB6C2" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="8" />\n\n\n\n<widget name="posterBottomControl" position="730,970" size="460,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/continue_poster_backdrop_menu.png" alphatest="blend" scale="1" zPosition="30" />\n<widget name="backdropBottomControl" position="730,970" size="460,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/home/continue_poster_backdrop_menu.png" alphatest="blend" scale="1" zPosition="30" />\n</screen>'
    CARD_COUNT = 4
    X = [80, 535, 990, 1445]
    MOVIE_Y = 525
    SERIES_Y = 770


    def __init__(self, session, current_source=None):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.currentSource = dict(current_source or {})
        self["hero"] = Pixmap(); self["heroTitle"] = DirectionalLabel(tr("YOUR STORY CONTINUES HERE")); self["heroMeta"] = DirectionalLabel(tr("Movies  •  TV Shows")); self["heroDesc"] = SynopsisLabel(tr("Start watching and unfinished titles will appear here automatically."))
        from .resolution_badge import install_information_badge
        install_information_badge(self, "heroMeta")
        self["heroPercent"] = Label(""); self["heroStars"] = Label(""); self["heroProgress"] = ProgressBar(); self["moviesTitle"] = Label(tr("Continue Watching") + "  •  " + tr("Movies")); self["seriesTitle"] = Label(tr("Continue Watching") + "  •  " + tr("TV Shows"))
        self["resumeWatchPill"] = Pixmap()
        self["resumeWatchCircle"] = Pixmap()
        self["resumeWatchCircleFrame"] = Pixmap()
        self["resumeWatchText"] = Label(tr("WATCH NOW"))
        self.topNames = [nav_label("Home"), nav_label("Search"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("GENRE"), nav_label("Resume"), nav_label("Server Finder"), nav_label("Settings"), nav_label("Favorites")]
        for i, name in enumerate(self.topNames):
            self["top%d" % i] = Label(name)
        self["topSelector"] = Pixmap()
        self["moviesPage"] = Label(""); self["seriesPage"] = Label(""); self["focus"] = Pixmap(); self["empty"] = Label(""); self["posterBottomControl"] = Pixmap(); self["backdropBottomControl"] = Pixmap()
        try: self["heroProgress"].setRange((0,100))
        except Exception: pass
        for i in range(8):
            self["card%d" % i] = Pixmap(); self["shell%d" % i] = Pixmap(); self["title%d" % i] = Label(""); self["meta%d" % i] = Label(""); self["prog%d" % i] = ProgressBar(); self["play%d" % i] = Pixmap()
            try: self["prog%d" % i].setRange((0,100))
            except Exception: pass
        self.movies=[]; self.series=[]; self.moviePage=0; self.seriesPage=0; self.row=0; self.index=0; self._generation=0; self._heroUrl=""; self._loaders=[]
        self._resume_artwork_targets = {}
        self._resume_artwork_closed = False
        self.onClose.append(self._disposeResumeArtwork)
        self._resume_locale_token = None
        self._resume_locale_cache = {}
        self._resume_locale_timer = eTimer()
        self._resume_locale_timer.callback.append(self._resolveResumeLocale)
        self.onClose.append(self._stopResumeLocale)
        self._resume_circle_identity = None
        self._resume_circle_serial = 0
        self._resume_circle_disposed = False
        self._resume_circle_source = None
        self._resume_circle_timer = eTimer()
        self._resume_circle_timer.callback.append(self._beginResumeCircleDecode)
        self.onClose.append(self._stopResumeCircle)
        # Hidden until a real Resume item has been selected.
        for _widget in ("resumeWatchPill", "resumeWatchCircle", "resumeWatchCircleFrame", "resumeWatchText"):
            self[_widget].hide()
        self.viewMode = self._loadViewMode()
        self.navFocus = "top"
        self.topIndex = 7
        self.topX = [20, 190, 360, 530, 700, 870, 1040, 1210, 1380, 1550, 1720]
        self.topW = [170] * 11
        self["actions"] = ActionMap(["OkCancelActions","DirectionActions","MenuActions","ColorActions"], {"ok":self.ok,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,"menu":self.openOptions,"red":self.removeSelected,"yellow":self.clearAll,"blue":self.toggleViewMode}, -1)
        self.onLayoutFinish.append(self._applyContinueViewLayout); self.onLayoutFinish.append(self._updatePosterBottomControl); self.onLayoutFinish.append(self.reload); self.onLayoutFinish.append(self._updateTopFocus)

    def _stopResumeCircle(self):
        self._resume_circle_disposed = True
        self._resume_circle_serial += 1
        try:
            self._resume_circle_timer.stop()
        except Exception:
            pass

    def _showResumeWatchButton(self, identity):
        """Selected hero owns this visual button; OK still plays via playMovie."""
        for name in ("resumeWatchPill", "resumeWatchCircle", "resumeWatchCircleFrame", "resumeWatchText"):
            try:
                self[name].setVisible(bool(identity))
            except Exception:
                pass
        if identity is None:
            self._resume_circle_identity = None
            self._resume_circle_source = None
            self._resume_circle_serial += 1
            try:
                self._resume_circle_timer.stop()
            except Exception:
                pass
            return
        if identity != self._resume_circle_identity:
            self._resume_circle_serial += 1
            self._resume_circle_identity = identity
            self._resume_circle_source = None
            try:
                self._resume_circle_timer.stop()
            except Exception:
                pass
            try:
                self["resumeWatchCircle"].instance.setPixmapFromFile(
                    os.path.join(PLUGIN_PATH, "skins", "home", "resume_watchnow_circle_default.png"))
            except Exception:
                pass

    def _scheduleResumeCircle(self, image_path, image_url, identity):
        if (self._resume_circle_disposed or not identity or
                identity != self._resume_circle_identity):
            return
        self._resume_circle_source = (image_path, image_url, identity)
        try:
            self._resume_circle_timer.stop()
            self._resume_circle_timer.start(360, True)
        except Exception:
            pass

    def _beginResumeCircleDecode(self):
        if self._resume_circle_disposed or not self._resume_circle_source:
            return
        path, url, identity = self._resume_circle_source
        serial = self._resume_circle_serial
        def worker():
            if self._resume_circle_disposed or serial != self._resume_circle_serial:
                return
            try:
                from .resume_thumbnail import cached_resume_circle
                thumb = cached_resume_circle(path, url)
            except Exception:
                thumb = None
            if (thumb and not self._resume_circle_disposed and
                    serial == self._resume_circle_serial and reactor is not None):
                reactor.callFromThread(self._renderResumeCircle, thumb, identity, serial)
        try:
            _RESUME_CIRCLE_POOL.submit(worker)
        except Exception:
            pass

    def _renderResumeCircle(self, path, identity, serial):
        if (self._resume_circle_disposed or serial != self._resume_circle_serial or
                identity != self._resume_circle_identity):
            return
        try:
            self["resumeWatchCircle"].instance.setPixmapFromFile(path)
            self["resumeWatchCircle"].show()
        except Exception:
            pass

    def _stopResumeLocale(self):
        try:
            self._resume_locale_timer.stop()
        except Exception:
            pass
        self._resume_locale_token = None

    def _scheduleResumeLocale(self, key, row):
        """Fetch the selected film's locale, never refetch all card metadata."""
        try:
            lang = TMDbClient().language
        except Exception:
            return
        token = (self._generation, str(key), lang)
        self._resume_locale_token = token
        try:
            self._resume_locale_timer.stop()
        except Exception:
            pass
        cached = self._resume_locale_cache.get(token)
        if cached:
            self._applyResumeLocale(token, cached)
            return
        try:
            self._resume_locale_timer.start(380, True)
        except Exception:
            pass

    def _heroYear(self, row):
        """Extract the year for the Resume item (not the Home screen)."""
        item = row.get("item") or {}
        raw = u" ".join(text_type(value or u"") for value in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match = re.search(r"\b(19|20)\d{2}\b", raw)
        return match.group(0) if match else ""

    def _heroOverview(self, row):
        """Use the existing Resume overview when TMDb lacks a translation."""
        item = row.get("item") or {}
        return text_type(
            row.get("overview") or item.get("plot") or item.get("description") or
            item.get("overview") or u""
        ).strip()

    def _resolveResumeLocale(self):
        token = getattr(self, "_resume_locale_token", None)
        selected = self._selected()
        if not token or not selected or str(selected[0]) != token[1]:
            return
        row = dict(selected[1] or {})
        item = dict(row.get("item") or {})
        kind = "series" if self._isSeries(row) else "vod"
        title = self._title(row)
        year = self._heroYear(row)
        def worker():
            try:
                client = TMDbClient()
                if client.language != token[2]:
                    return
                tmdb_id = item.get("tmdb_id") or item.get("tmdb") or row.get("tmdb_id")
                if not tmdb_id:
                    found = client.search_artwork(title, kind, year or None) or {}
                    tmdb_id = found.get("id")
                if not tmdb_id:
                    return
                bundle = client.details_bundle(tmdb_id, kind) or {}
                if not bundle:
                    return
                info = merge_metadata(
                    {"title": title, "description": self._heroOverview(row), "year": year},
                    tmdb=bundle, language=client.language, kind=kind)
                incoming = {"title": info["title"], "overview": info["description"]}
                if reactor is not None:
                    reactor.callFromThread(self._applyResumeLocale, token, incoming)
            except Exception:
                pass
        thread = thread_factory(target=worker, name="TiviMateResumeLocale")
        thread.daemon = True
        thread.start()

    def _applyResumeLocale(self, token, details):
        if self._resume_locale_token != token or self._generation != token[0]:
            return
        selected = self._selected()
        if not selected or str(selected[0]) != token[1]:
            return
        stable = dict(details or {})
        if details.get("title"):
            current_title = self["heroTitle"].getText()
            title = keep_arabic_on_late_update(current_title, details["title"], token[2])
            stable["title"] = title
            self["heroTitle"].setText(gui_text(visible_title(title, 55)))
        if details.get("overview"):
            current_desc = self["heroDesc"].getText()
            overview = keep_arabic_on_late_update(current_desc, details["overview"], token[2])
            stable["overview"] = overview
            self["heroDesc"].setText(gui_text(text_type(overview)[:280]))
        self._resume_locale_cache[token] = stable

    def _loadViewMode(self):
        try:
            with open(self.VIEW_FILE, "r") as h:
                data = json.load(h) or {}
            mode = str(data.get("mode") or "").lower()
            if mode in ("poster", "backdrop"):
                return mode
        except Exception:
            pass
        return "backdrop"

    def _saveViewMode(self):
        try:
            folder = os.path.dirname(self.VIEW_FILE)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = self.VIEW_FILE + ".tmp"
            with open(tmp, "w") as h:
                json.dump({"mode": self.viewMode}, h, separators=(",", ":"))
            os.rename(tmp, self.VIEW_FILE)
        except Exception:
            pass

    def _load(self):
        try:
            with open(self.RESUME_FILE,"r") as h: data=json.load(h)
            return data if isinstance(data,dict) else {}
        except Exception: return {}
    def _save(self,data):
        try:
            folder=os.path.dirname(self.RESUME_FILE)
            if folder and not os.path.isdir(folder): os.makedirs(folder)
            tmp=self.RESUME_FILE+".tmp"
            with open(tmp,"w") as h: json.dump(data,h,separators=(",",":"),sort_keys=True)
            os.rename(tmp,self.RESUME_FILE)
        except Exception: pass
    def _isSeries(self,row):
        item = row.get("item") or {}
        kind = str(row.get("kind") or item.get("_kind") or "").lower()
        if kind in ("series", "tv", "show"):
            return True
        has_episode_identity = bool(
            row.get("episode") not in (None, "") or
            item.get("episode_num") not in (None, "") or
            item.get("episode_number") not in (None, "") or
            item.get("_subdl_episode") not in (None, "") or
            ((row.get("season") not in (None, "") or item.get("season") not in (None, "") or item.get("season_number") not in (None, "")) and
             (item.get("episode") not in (None, "") or row.get("episode") not in (None, "")))
        )
        if kind == "episode":
            return has_episode_identity
        if item.get("_tmdb_kind") == "series" and has_episode_identity:
            return True
        return False

    def _seriesIdentity(self,key,row):
        item = row.get("item") or {}
        # Group Continue Watching by the parent show name first.  Do not use
        # series_id as the primary key: some providers change or duplicate it
        # between episode records, which used to create repeated cards.
        title = (
            row.get("series_title") or item.get("series_name") or
            item.get("_tmdb_title") or row.get("title") or
            item.get("name") or item.get("title") or ""
        )
        value = text_type(title or u"").strip().lower()
        # Strip episode markers and common IPTV decorations so e.g.
        # "AR - Suits - S01E05" and "Suits S01 E05" collapse to "suits".
        value = re.sub(r"(?i)\bS(?:EASON)?\s*\d{1,2}\s*[- .]*E(?:P(?:ISODE)?)?\s*\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\bS\d{1,2}E\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\b\d{1,2}X\d{1,3}\b", " ", value)
        value = re.sub(r"(?i)\b(?:4k|uhd|fhd|hd|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|ar|ara|arabic|en|eng|english)\b", " ", value)
        value = re.sub(r"[\[\]\(\)\{\}_|:/\-]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        if value:
            return "name:" + value
        sid = str(row.get("series_id") or item.get("series_id") or "").strip().lower()
        return "id:" + sid if sid else "key:" + str(key)
    def _contentIdentity(self, row):
        item = row.get("item") or {}
        series_name = row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or ""
        title = series_name or row.get("title") or item.get("name") or item.get("title") or ""
        text = text_type(title or u"").lower()
        text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
        text = re.sub(r"(?i)\b(?:4k|8k|uhd|fhd|hd|sd|2160p|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|bluray|ar|ara|arabic|en|eng|english)\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        text = " ".join(text.split())
        season = str(row.get("season") or item.get("season") or item.get("season_number") or "")
        episode = str(row.get("episode") or item.get("episode_num") or item.get("episode_number") or "")
        if self._isSeries(row):
            return "series|%s|s%s|e%s" % (text, season, episode)
        year_raw = u" ".join(text_type(x or u"") for x in (item.get("year"), item.get("releaseDate"), item.get("release_date"), row.get("title")))
        m = re.search(r"\b(19|20)\d{2}\b", year_raw)
        return "movie|%s|%s" % (text, m.group(0) if m else "")

    def _serverKeyFromStreamUrl(self, streamurl):
        url = str(streamurl or "").strip()
        if not url:
            return ""
        try:
            parsed = urlparse(url)
            stream_host = (parsed.netloc or "").lower()
            stream_path = parsed.path or ""
        except Exception:
            stream_host = ""
            stream_path = url

        best = ""
        for source in (get_sources() or []):
            try:
                source_key = _source_identity(source)
                base = str(source.get("url") or source.get("portal") or source.get("host") or source.get("server") or "").strip()
                if "://" not in base and base:
                    base = "http://" + base
                bp = urlparse(base)
                source_host = (bp.netloc or "").lower()
                username = str(source.get("username") or "")
                # Exact server host is the strongest direct match.
                if source_host and stream_host and source_host == stream_host:
                    if username and (("/" + username + "/") in stream_path or username in stream_path):
                        return source_key
                    best = source_key
            except Exception:
                pass
        return best

    def _migrateMultiServerRows(self, data):
        groups = {}
        changed = False
        for key, row in list(data.items()):
            if not isinstance(row, dict):
                continue
            ident = text_type(row.get("content_id") or self._contentIdentity(row))
            if not ident:
                continue
            if ident not in groups:
                groups[ident] = (key, row)
                row["content_id"] = ident
            else:
                keep_key, keep = groups[ident]
                # Newest progress/visuals win.
                if int(row.get("updated") or 0) > int(keep.get("updated") or 0):
                    old_keep_key, old_keep = keep_key, keep
                    keep_key, keep = key, row
                    groups[ident] = (keep_key, keep)
                    donor_key, donor = old_keep_key, old_keep
                else:
                    donor_key, donor = key, row

                keep_servers = dict(keep.get("servers") or {})
                donor_servers = dict(donor.get("servers") or {})
                for skey, sentry in donor_servers.items():
                    if skey:
                        keep_servers[skey] = sentry
                for source_row in (keep, donor):
                    skey = str(source_row.get("source_key") or "")
                    if not skey and source_row.get("streamurl"):
                        skey = self._serverKeyFromStreamUrl(source_row.get("streamurl"))
                        if skey:
                            source_row["source_key"] = skey
                            changed = True
                    if skey and source_row.get("streamurl"):
                        keep_servers[skey] = {
                            "source_key": skey,
                            "source_type": source_row.get("source_type") or "xtream",
                            "streamurl": source_row.get("streamurl"),
                            "service_type": int(source_row.get("service_type") or 4097),
                            "item": dict(source_row.get("item") or {}),
                        }
                keep["servers"] = keep_servers
                keep["content_id"] = ident
                data[keep_key] = keep
                if donor_key in data and donor_key != keep_key:
                    del data[donor_key]
                changed = True

        # Migrate single legacy rows too.
        for key, row in list(data.items()):
            if not isinstance(row, dict):
                continue
            row["content_id"] = text_type(row.get("content_id") or self._contentIdentity(row))
            servers = dict(row.get("servers") or {})
            skey = str(row.get("source_key") or "")
            if not skey and row.get("streamurl"):
                skey = self._serverKeyFromStreamUrl(row.get("streamurl"))
                if skey:
                    row["source_key"] = skey
                    changed = True
            if skey and row.get("streamurl") and skey not in servers:
                servers[skey] = {
                    "source_key": skey,
                    "source_type": row.get("source_type") or "xtream",
                    "streamurl": row.get("streamurl"),
                    "service_type": int(row.get("service_type") or 4097),
                    "item": dict(row.get("item") or {}),
                }
                row["servers"] = servers
                changed = True
            data[key] = row
        return changed

    def reload(self):
        data = self._load()
        try:
            if self._migrateMultiServerRows(data):
                self._save(data)
        except Exception:
            pass
        rows = sorted(data.items(), key=lambda p: int((p[1] or {}).get("updated", 0) or 0), reverse=True)
        self.movies = []
        self.series = []
        seen = set()
        duplicate_keys = []
        for key, row in rows:
            if not isinstance(row, dict):
                continue
            try:
                pos = int(row.get("position") or 0)
                length = int(row.get("length") or 0)
                if length > 0 and pos >= int(length * 0.95):
                    continue
            except Exception:
                pass
            if self._isSeries(row):
                ident = self._seriesIdentity(key, row)
                if ident in seen:
                    # Keep only the newest unfinished episode/card for a show.
                    duplicate_keys.append(key)
                    continue
                seen.add(ident)
                self.series.append((key, row))
            else:
                self.movies.append((key, row))

        # Also clean duplicate legacy records from disk, so reopening Continue
        # Watching cannot make the same show reappear again.
        if duplicate_keys:
            changed = False
            for key in duplicate_keys:
                if key in data:
                    try:
                        del data[key]
                        changed = True
                    except Exception:
                        pass
            if changed:
                self._save(data)

        if self.row == 0 and not self.movies and self.series:
            self.row = 1
        elif self.row == 1 and not self.series and self.movies:
            self.row = 0
        self.index = 0
        self.renderRows()
        self.updateFocus()
    def _pageRows(self,row=None):
        row=self.row if row is None else row; items=self.movies if row==0 else self.series; page=self.moviePage if row==0 else self.seriesPage; s=page*self.CARD_COUNT
        return items[s:s+self.CARD_COUNT]
    def _pct(self,row):
        try:
            pos=int(row.get("position") or 0); length=int(row.get("length") or 0); return max(0,min(100,int(pos*100.0/length))) if length>0 else 0
        except Exception: return 0
    def _title(self,row):
        item=row.get("item") or {}
        if self._isSeries(row): return text_type(row.get("series_title") or item.get("series_name") or item.get("_tmdb_title") or row.get("title") or item.get("name") or item.get("title") or tr("TV Show"))
        return text_type(row.get("title") or item.get("name") or item.get("title") or tr("Movie"))
    def _updatePosterBottomControl(self):
        try:
            if self.viewMode == "poster":
                self["posterBottomControl"].show()
                self["backdropBottomControl"].hide()
            else:
                self["posterBottomControl"].hide()
                self["backdropBottomControl"].show()
        except Exception:
            pass

    def _setResumeCardOverlay(self, slot, row=None):
        """Show real watch progress and play glyph on backdrop cards only.

        A missing/unknown movie duration is not a fabricated progress value.
        Poster mode and empty cells never display backdrop overlays.
        """
        try:
            enabled = self.viewMode == "backdrop" and row is not None
            play = self["play%d" % slot]
            progress = self["prog%d" % slot]
            if enabled:
                play.show()
                pct = self._pct(row)
                if pct > 0:
                    progress.setValue(pct)
                    progress.show()
                else:
                    progress.hide()
            else:
                play.hide()
                progress.hide()
        except Exception:
            pass

    def toggleViewMode(self):
        self.viewMode = "poster" if self.viewMode == "backdrop" else "backdrop"
        self._saveViewMode()
        self._updatePosterBottomControl()
        self._applyContinueViewLayout()
        self.renderRows()
        self.updateFocus()

    def _posterAsset(self,row):
        item=row.get("item") or {}
        value=(item.get("stream_icon") or item.get("movie_image") or item.get("cover") or
               item.get("cover_big") or item.get("poster") or item.get("poster_url") or
               item.get("poster_path") or row.get("poster") or "")
        value=str(value or "").strip().replace("\\/","/")
        if value.startswith("/") and not value.startswith("//"):
            return IMAGE_BASE+"w500"+value
        return value

    def _resolvePosterAsync(self, key, row, widget):
        title = self._title(row)
        kind = "series" if self._isSeries(row) else "vod"
        item = row.get("item") or {}
        year = item.get("year") or row.get("year") or ""
        generation = self._generation
        identity = text_type(row.get("content_id") or self._contentIdentity(row))
        def worker():
            try:
                result = TMDbClient().search_artwork(title, kind=kind, year=year, required_key="poster_path") or {}
                path = result.get("poster_path") or ""
                url = IMAGE_BASE + "w500" + path if path else ""
            except Exception:
                url = ""
            if not url or generation != self._generation:
                return
            data = self._load()
            rec = data.get(key)
            if (isinstance(rec, dict) and
                    text_type(rec.get("content_id") or self._contentIdentity(rec)) == identity):
                rec["poster"] = url
                data[key] = rec
                self._save(data)
                # Keep the visible row warm for the next page visit too.
                row["poster"] = url
                if reactor:
                    reactor.callFromThread(self._loadPosterArtwork, url, widget, generation)
                else:
                    self._loadPosterArtwork(url, widget, generation)
        t = thread_factory(target=worker, name="TiviMateContinuePoster")
        t.daemon = True
        t.start()

    def _applyContinueViewLayout(self):
        poster = self.viewMode == "poster"
        try: self["hero"].show()
        except Exception: pass
        for slot in range(8):
            col=slot if slot<4 else slot-4
            base_x=self.X[col]; base_y=self.MOVIE_Y if slot<4 else self.SERIES_Y
            try:
                w=self["card%d"%slot]
                if poster:
                    w.instance.move(ePoint(sx(base_x+125),sy(base_y+2))); w.instance.resize(eSize(sx(160),sy(205)))
                else:
                    w.instance.move(ePoint(sx(base_x+2),sy(base_y+2))); w.instance.resize(eSize(sx(406),sy(160)))
            except Exception: pass
        try: self["focus"].instance.resize(eSize(sx(410),sy(210)))
        except Exception: pass

    @staticmethod
    def _resumeBackdropUrl(raw):
        """Accept actual image URLs, including serialized provider backdrops.

        Reject video playback URLs and do not turn provider-relative filenames
        into an unrelated TMDb image. File URLs already held in the shared
        artwork cache are still resolved through the same cache-first loader.
        """
        try:
            if isinstance(raw, (list, tuple)):
                return ContinueWatchingScreen._resumeBackdropUrl(raw[0]) if raw else ""
            if isinstance(raw, dict):
                for key in ("url", "src", "file_path", "backdrop", "image"):
                    found = ContinueWatchingScreen._resumeBackdropUrl(raw.get(key))
                    if found:
                        return found
                return ""
            value = text_type(raw or u"").strip().replace(chr(92) + "/", "/")
            if value.startswith(u"["):
                try:
                    return ContinueWatchingScreen._resumeBackdropUrl(json.loads(value))
                except (TypeError, ValueError):
                    return ""
            if value.startswith((u"http://", u"https://")):
                return value
            # /media/hdd/cache/<cached image> is an already-downloaded picture,
            # not a TMDb path and must not be prefixed with TMDb's host.
            if value.startswith(u"/media/") and os.path.isfile(value):
                return value
            if (value.startswith(u"/") and not value.startswith(u"//") and
                    re.match(r'^/[A-Za-z0-9_-]{8,}\.(?:jpe?g|png|webp)$',value,re.I)):
                return backdrop_url(value)
        except Exception:
            pass
        return ""

    def _asset(self,row):
        """Resume record and provider artwork win; TMDb only on cache miss."""
        if not isinstance(row, dict):
            return ""
        identity = text_type(row.get("content_id") or self._contentIdentity(row) or u"")
        owner = str(row.get("backdrop_content_id") or "")
        # Older player records have no identity stamp. They were stored for
        # this row, not a shared package. Do not discard valid legacy imagery.
        if (not owner or owner == identity) and row.get("backdrop"):
            saved = self._resumeBackdropUrl(row.get("backdrop"))
            if saved:
                return saved
        item = row.get("item") or {}
        if isinstance(item, dict):
            for key in ("backdrop_path", "backdrop_url", "backdrop", "fanart",
                        "background", "background_image"):
                value = self._resumeBackdropUrl(item.get(key))
                if value:
                    return value
        return ""
    def _resolveBackdropAsync(self,key,row,widget):
        # Preserve each card's record identity; workers must never stamp a
        # different movie after the selection or page changes.
        title=self._title(row)
        kind="series" if self._isSeries(row) else "vod"
        item=row.get("item") or {}
        if not isinstance(item,dict): item={}
        year=item.get("year") or row.get("year") or ""
        generation=self._generation
        identity=text_type(row.get("content_id") or self._contentIdentity(row))
        def worker():
            url=""
            try:
                tmdb=TMDbClient()
                tid=(item.get("tmdb_id") or item.get("tmdb") or item.get("_tmdb_id") or
                     row.get("tmdb_id") or row.get("tmdb"))
                # Provider stream IDs are not TMDb IDs. Verify matching title
                # before trusting artwork from a guessed details lookup.
                if tid:
                    try:
                        bundle=tmdb.details_bundle(tid,kind) or {}
                        from Plugins.Extensions.TiviMateE2Py27.tmdb_client import _tmdb_identity_anchor, _tmdb_identity_row_score
                        anchor=_tmdb_identity_anchor(title,kind)
                        score=_tmdb_identity_row_score(anchor,anchor,bundle,kind,year) if anchor else 0
                        if score >= 0.80:
                            url=self._resumeBackdropUrl(bundle.get("backdrop_path"))
                    except Exception:
                        pass
                if not url:
                    found=tmdb.search_artwork(title,kind=kind,year=year,required_key="backdrop_path") or {}
                    url=self._resumeBackdropUrl(found.get("backdrop_path"))
            except Exception:
                pass
            if not url and kind == "vod":
                # Some IPTV titles have no TMDb match. A known Xtream stream
                # can still supply the original backdrop from get_vod_info.
                try:
                    stream_id = item.get("stream_id") or item.get("vod_id")
                    stored_source = str(row.get("source_key") or item.get("_source_key") or "")
                    source = None
                    if stream_id and stored_source:
                        for entry in (get_sources() or []):
                            if _source_identity(entry) == stored_source:
                                source = entry
                                break
                    if source and str(source.get("type") or "") == "xtream":
                        from .core import XtreamClient
                        from .artwork_queue import find_provider_asset
                        info = XtreamClient(source).vod_info(stream_id) or {}
                        url = self._resumeBackdropUrl(find_provider_asset(
                            source, info, ("backdrop_path", "backdrop", "backdrop_url", "fanart")))
                except Exception:
                    pass
            if not url:
                return
            # Only a matching content record receives the persistently cached
            # backdrop; older source records are left untouched otherwise.
            data=self._load()
            rec=data.get(key)
            if isinstance(rec,dict) and text_type(rec.get("content_id") or self._contentIdentity(rec)) == identity:
                rec["backdrop"]=url
                rec["backdrop_content_id"]=identity
                data[key]=rec
                self._save(data)
                row["backdrop"]=url
                row["backdrop_content_id"]=identity
            wanted=(key,identity) if widget=="hero" else None
            if widget=="hero" and wanted!=getattr(self,"_resumeHeroIdentity",None):
                return
            # GUI callbacks must not be invoked directly from this worker.
            if reactor is not None:
                reactor.callFromThread(self._loadArtwork,url,widget,generation,wanted)
            else:
                self._loadArtwork(url,widget,generation,wanted)
        t=thread_factory(target=worker,name="TiviMateContinueBackdrop")
        t.daemon=True
        t.start()
    def _disposeResumeArtwork(self):
        self._resume_artwork_closed = True
        self._resume_artwork_targets.clear()
        try:
            self._loaders[:] = []
        except Exception:
            pass

    def _decodeResumeBackdrop(self, path, widget, generation, url, owner):
        """Decode cached JPEG/PNG using Enigma2 rather than a silent pixmap set.

        setPixmapFromFile can succeed without drawing correctly on some
        DreamOS images, particularly with HD backdrops in smaller cards.
        Every decoder has an owner and is released on its completion.
        """
        if (self._resume_artwork_closed or not path or not os.path.isfile(path) or
                generation != self._generation):
            return
        state = (generation, url, owner)
        self._resume_artwork_targets[widget] = state
        def still_current():
            if self._resume_artwork_closed or self._generation != generation:
                return False
            if self._resume_artwork_targets.get(widget) != state:
                return False
            if widget == "hero" and (url != self._heroUrl or
                    (owner is not None and owner != getattr(self,"_resumeHeroIdentity",None))):
                return False
            return True
        def direct_fallback():
            if not still_current():
                return
            try:
                target = self[widget]
                if target.instance:
                    target.instance.setPixmapFromFile(path)
                    target.show()
            except Exception:
                pass
        loader = None
        try:
            loader = ePicLoad()
            self._loaders.append(loader)
            size = (1920,500) if widget == "hero" else (406,160)
            rw,rh = scale_size(*size)
            loader.setPara((rw,rh,0,0,False,1,"#000000"))
            def decoded(_=None, current=loader):
                try:
                    if still_current():
                        pix = current.getData()
                        if pix:
                            target=self[widget]
                            if target.instance:
                                target.instance.setPixmap(pix)
                                target.show()
                                return
                        direct_fallback()
                except Exception:
                    direct_fallback()
                finally:
                    try: self._loaders.remove(current)
                    except Exception: pass
            connection = connect_picture_data(loader, decoded, self, oneshot=True)
            status = loader.startDecode(path)
            if isinstance(status,int) and status < 0:
                try: self._loaders.remove(loader)
                except Exception: pass
                direct_fallback()
        except Exception:
            if loader is not None:
                try: self._loaders.remove(loader)
                except Exception: pass
            direct_fallback()

    def _loadArtwork(self,url,widget,generation,identity=None,fallback=None):
        if not url or self._resume_artwork_closed:
            return
        if widget=="hero":
            if identity is not None and identity != getattr(self, "_resumeHeroIdentity", None):
                return
            self._heroUrl=url
        def done(path,expected=widget,g=generation,u=url,wanted=identity):
            if self._resume_artwork_closed or g!=self._generation or not path:
                return
            if expected=="hero" and (u!=self._heroUrl or
                  (wanted is not None and wanted!=getattr(self, "_resumeHeroIdentity", None))):
                return
            if expected == "hero":
                self._scheduleResumeCircle(path,u,getattr(self,"_resumeHeroIdentity",None))
            self._decodeResumeBackdrop(path,expected,g,u,wanted)
        # Local real image path is never a remote CDN URL.
        if os.path.isfile(url):
            done(url)
            return
        # Reuse the exact persistent cache shared with Movies/GENRE/Details.
        try:
            local = cached_artwork(url,"backdrops")
            if local and os.path.isfile(local):
                done(local)
                return
        except Exception:
            pass
        def missing(_path=None, previous=fallback, gen=generation, target=widget):
            if previous is not None and gen == self._generation and not self._resume_artwork_closed:
                try:
                    original_key, original_row = previous
                    self._resolveBackdropAsync(original_key,original_row,target)
                except Exception:
                    pass
        try: request_artwork(url,"backdrops",done,priority=35,errback=missing)
        except Exception: missing()
    def _loadPosterArtwork(self,url,widget,generation,fallback=None):
        if not url:return
        def fallback_poster():
            if (fallback is not None and generation == self._generation and
                    self.viewMode == "poster"):
                key, row = fallback
                self._resolvePosterAsync(key, row, widget)
        def done(path,expected=widget,g=generation):
            if g != self._generation or self.viewMode != "poster":
                return
            if not usable_poster_file(path, minimum_bytes=128):
                fallback_poster()
                return
            try:
                w=self[expected]
                if w.instance:
                    w.instance.setPixmapFromFile(path); w.show()
            except Exception:
                pass
        # Show a cached poster directly, without waiting in the download queue.
        cached = cached_artwork(url, "posters")
        if cached and usable_poster_file(cached, minimum_bytes=128):
            done(cached)
        else:
            try:request_artwork(url,"posters",done,priority=95,errback=lambda _path: fallback_poster())
            except Exception: fallback_poster()

    def renderRows(self):
        self._generation+=1; g=self._generation
        movie_ph=os.path.join(PLUGIN_PATH,"skins","home","continue_default_movies.jpg")
        series_ph=os.path.join(PLUGIN_PATH,"skins","home","continue_default_series.jpg")
        m=self._pageRows(0); s=self._pageRows(1)
        mp=((len(self.movies)+3)//4) if self.movies else 0; sp=((len(self.series)+3)//4) if self.series else 0
        self["moviesPage"].setText("%d  •  %d/%d"%(len(self.movies),self.moviePage+1 if self.movies else 0,mp)); self["seriesPage"].setText("%d  •  %d/%d"%(len(self.series),self.seriesPage+1 if self.series else 0,sp))
        for slot in range(8):
            rows=m if slot<4 else s; idx=slot if slot<4 else slot-4
            image=self["card%d"%slot]; shell=self["shell%d"%slot]; title=self["title%d"%slot]; meta=self["meta%d"%slot]
            ph=movie_ph if slot<4 else series_ph
            if idx>=len(rows):
                self._setResumeCardOverlay(slot)
                title.setText(""); meta.setText("")
                try:
                    if not rows and idx==0:
                        if image.instance and os.path.exists(ph): image.instance.setPixmapFromFile(ph)
                        image.show(); shell.show(); title.hide(); meta.hide()
                    else:
                        image.hide(); shell.hide(); title.hide(); meta.hide()
                except Exception: pass
                continue
            key,row=rows[idx]; pct=self._pct(row)
            if self.viewMode=="backdrop":
                title.setText("")
                meta.setText(("%d%%"%pct) if pct else "")
            else:
                title.setText(visible_title(self._title(row), 38))
                meta.setText(("%d%%"%pct) if pct else tr("Resume"))
            self._setResumeCardOverlay(slot, row)
            try:
                image.show(); shell.show();
                if self.viewMode=="backdrop":
                    title.hide()
                else:
                    title.show()
                meta.show()
                if image.instance and os.path.exists(ph): image.instance.setPixmapFromFile(ph)
            except Exception: pass
            if self.viewMode=="poster":
                url=self._posterAsset(row)
                if url:self._loadPosterArtwork(url,"card%d"%slot,g,(key,row))
                else:self._resolvePosterAsync(key,row,"card%d"%slot)
            else:
                url=self._asset(row)
                if url:self._loadArtwork(url,"card%d"%slot,g,fallback=(key,row))
                else:self._resolveBackdropAsync(key,row,"card%d"%slot)
        # Warm only the next four cards in each lane (max 8 total), matching
        # the fast GENRE visible-first policy. Never prefetch the entire history.
        next_rows = ([row for _key, row in self.movies[(self.moviePage + 1) * self.CARD_COUNT:
                                                         (self.moviePage + 2) * self.CARD_COUNT]] +
                     [row for _key, row in self.series[(self.seriesPage + 1) * self.CARD_COUNT:
                                                          (self.seriesPage + 2) * self.CARD_COUNT]])
        if self.viewMode == "poster":
            prefetch_artwork([self._posterAsset(row) for row in next_rows if self._posterAsset(row)],
                             "posters", priority=2)
        else:
            prefetch_artwork([self._asset(row) for row in next_rows if self._asset(row)],
                             "backdrops", priority=1)
        self["empty"].setText(tr("Your unfinished movies and TV shows will appear here.") if not self.movies and not self.series else "")

    def _selected(self):
        rows=self._pageRows(); self.index=min(max(0,self.index),len(rows)-1) if rows else 0; return rows[self.index] if rows else None
    def updateFocus(self):
        rows=self._pageRows()
        if not rows:
            x = self.X[0]
            y = self.MOVIE_Y if self.row == 0 else self.SERIES_Y
            try:
                self["focus"].instance.move(ePoint(sx(x), sy(y)))
                self["focus"].hide()
            except Exception:
                pass
            default_hero = os.path.join(PLUGIN_PATH, "skins", "home/continue_default_hero.jpg")
            try:
                if self["hero"].instance and os.path.exists(default_hero):
                    self["hero"].instance.setPixmapFromFile(default_hero)
                    self["hero"].show()
            except Exception:
                pass
            self["heroTitle"].setText(tr("YOUR STORY CONTINUES HERE"))
            self["heroMeta"].setText(tr("Movies  •  TV Shows"))
            try:
                self["heroStars"].setText("★★★★★")
            except Exception:
                pass
            self["heroDesc"].setText(tr("Pick up where you left off. Your movies and TV shows will appear here automatically."))
            self["heroProgress"].setValue(0)
            self["heroPercent"].setText("")
            self._resumeHeroIdentity=None
            self._heroUrl=""
            self._showResumeWatchButton(None)
            return

        self.index=min(max(0,self.index),len(rows)-1)
        x=self.X[self.index]
        y=self.MOVIE_Y if self.row==0 else self.SERIES_Y
        try:
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:
            pass

        key,row=self._selected()
        wanted_identity=(key,text_type(row.get("content_id") or self._contentIdentity(row)))
        if getattr(self,"_resumeHeroIdentity",None)!=wanted_identity:
            # Keep a visible default hero, not a stale prior title's backdrop.
            self._heroUrl=""
            try:
                placeholder=os.path.join(PLUGIN_PATH,"skins","home","continue_default_hero.jpg")
                if self["hero"].instance and os.path.isfile(placeholder):
                    self["hero"].instance.setPixmapFromFile(placeholder)
                    self["hero"].show()
            except Exception:
                pass
        self._resumeHeroIdentity=wanted_identity
        self._showResumeWatchButton(self._resumeHeroIdentity)
        pct=self._pct(row)
        self["heroTitle"].setText(visible_title(self._title(row), 55))

        try:
            pos=int(row.get("position") or 0)
            total=int(row.get("length") or 0)
        except Exception:
            pos=total=0

        def clock(v):
            h=v//3600
            m=(v%3600)//60
            return ("%dh %02dm"%(h,m)) if h else ("%d min"%m)

        item=row.get("item") or {}
        year=""
        raw_year=u" ".join(text_type(x or u"") for x in (
            row.get("year"), item.get("year"), item.get("releaseDate"),
            item.get("release_date"), item.get("first_air_date"), self._title(row)
        ))
        match=re.search(r"\b(19|20)\d{2}\b", raw_year)
        if match:
            year=match.group(0)

        genre=str(row.get("genre") or item.get("genre") or "").strip()
        media_label=tr("TV Show") if self._isSeries(row) else tr("Movie")
        parts=[media_label]
        if year: parts.append(year)
        if genre: parts.append(genre[:38])
        if pos: parts.append(clock(pos))
        if total: parts.append(clock(total))
        self["heroMeta"].setText("  •  ".join(parts))

        raw_rating=row.get("rating") or item.get("rating") or item.get("vote_average") or 0
        try:
            rating=float(str(raw_rating).replace(",", "."))
            if rating>10.0:
                rating=rating/10.0
            rating=max(0.0,min(10.0,rating))
        except Exception:
            rating=0.0
        stars=int(round(rating/2.0)) if rating else 0
        star_text=("★"*stars)+("☆"*(5-stars)) if rating else "☆☆☆☆☆"
        try:
            self["heroStars"].setText(("%s   %.1f/10"%(star_text,rating)) if rating else star_text)
        except Exception:
            pass

        overview=text_type(row.get("overview") or item.get("plot") or item.get("description") or item.get("overview") or u"").strip()
        self["heroDesc"].setText(overview[:280] if overview else tr("OK Play   •   MENU Options"))
        self._scheduleResumeLocale(key, row)

        self["heroProgress"].setValue(pct)
        self["heroPercent"].setText("%d%%"%pct if pct else "")
        url=self._asset(row)
        if url:
            self._loadArtwork(url,"hero",self._generation,self._resumeHeroIdentity,(key,row))
        else:
            self._resolveBackdropAsync(key,row,"hero")


    def _updateTopFocus(self):
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
            self["topSelector"].setVisible(self.navFocus == "top")
        except Exception:
            pass
        try:
            self["focus"].setVisible(self.navFocus != "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        # VTi: preserve the real failure when a child screen cannot be opened.
        from .vti_compat import open_vti_page_once
        return open_vti_page_once(self, screen, *args)


    def _openTop(self):
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Search, self.currentSource); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.currentSource, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, "vod"), self.currentSource, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, "series"), self.currentSource, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.currentSource); return
        if self.topIndex == 6:
            self._openContinueGenre(); return
        if self.topIndex == 7:
            self.navFocus = "content"; self._updateTopFocus(); return
        if self.topIndex == 8:
            self._openPageOnce(TiviMateE2IPTVFinder); return
        if self.topIndex == 9:
            self._openPageOnce(SettingsDashboard); return
        if self.topIndex == 10:
            self._openPageOnce(FavoritesScreen); return

    def _openContinueGenre(self):
        choices = [(tr("Movies"), "vod"), (tr("TV Shows"), "series")]
        self.session.openWithCallback(self._openContinueGenreSelected, TiviMateGenreSelectScreen)

    def _openContinueGenreSelected(self, selected=None):
        if not selected or not self.currentSource:
            return
        kind = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if kind in ("vod", "series"):
            self._openPageOnce(MovieGenresScreen, dict(self.currentSource), kind)


    def left(self):
        if self.navFocus == "top":
            self.topIndex = (self.topIndex - 1) % len(self.topNames)
            self._updateTopFocus()
            return
        if self._pageRows():
            self.index = max(0, self.index - 1)
            self.updateFocus()

    def right(self):
        if self.navFocus == "top":
            self.topIndex = (self.topIndex + 1) % len(self.topNames)
            self._updateTopFocus()
            return
        if self._pageRows():
            self.index = min(len(self._pageRows()) - 1, self.index + 1)
            self.updateFocus()

    def up(self):
        if self.navFocus == "top":
            return
        if self.row == 1 and self.movies:
            self.row = 0
            self.index = min(self.index, len(self._pageRows()) - 1)
            self.updateFocus()
        else:
            self.navFocus = "top"
            self._updateTopFocus()

    def down(self):
        if self.navFocus == "top":
            self.navFocus = "content"
            if not self._pageRows() and self.series:
                self.row = 1
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self.updateFocus()
            self._updateTopFocus()
            return
        if self.row == 0 and self.series:
            self.row = 1
            self.index = min(self.index, max(0, len(self._pageRows()) - 1))
            self.updateFocus()

    def ok(self):
        if self.navFocus == "top":
            self._openTop()
            return
        selected = self._selected()
        if not selected:
            return
        _key, row = selected
        self.playMovie(row)

    def playMovie(self,row):
        try:
            play_vod_exact_continue_path(
                self.session,
                row,
                current_source=dict(self.currentSource or {}),
                callback=lambda *a: self.reload()
            )
        except Exception:
            # A VTi player-open failure may already have suspended this screen.
            # Do not trigger a second modal-open exception / Enigma restart.
            try:
                if (getattr(self.session, 'current_dialog', None) is self and
                        getattr(self.session, 'in_exec', True)):
                    self.session.open(MessageBox,
                                      gui_text(tr("Unable to play this item.")),
                                      MessageBox.TYPE_ERROR, timeout=7)
            except Exception:
                pass

    def removeSelected(self):
        selected=self._selected()
        if not selected:return
        data=self._load(); data.pop(selected[0],None); self._save(data); self.reload()
    def clearAll(self):self.session.openWithCallback(self._clearConfirm,MessageBox,tr("Clear all Continue Watching history?"),MessageBox.TYPE_YESNO)
    def _clearConfirm(self,yes):
        if yes:self._save({}); self.moviePage=0; self.seriesPage=0; self.reload()
    def openOptions(self):
        selected=self._selected(); choices=[]
        if selected: choices.append((tr("Play"),"open")); choices.extend([(tr("Remove from Continue Watching"),"remove"),(tr("Mark as Watched"),"remove")])
        choices.append((tr("Clear Continue Watching"),"clear")); self.session.openWithCallback(self._optionChosen,ChoiceBox,title=tr("Continue Watching"),list=choices)
    def _optionChosen(self,choice):
        if not choice:return
        action=choice[1]
        if action=="open":self.ok()
        elif action=="remove":self.removeSelected()
        elif action=="clear":self.clearAll()



def play_vod_exact_continue_path(session, row, current_source=None, callback=None):
    """Exact Continue Watching VOD playback path shared by Continue and Movies."""
    current_source = dict(current_source or {})
    current_key = ""
    try:
        current_key = _source_identity(current_source)
    except Exception:
        current_key = ""

    servers = dict((row or {}).get("servers") or {})
    selected = None

    # Exact Continue Watching server-selection order.
    if current_key:
        selected = servers.get(current_key)

    if not selected:
        legacy_key = str((row or {}).get("source_key") or "")
        if legacy_key and legacy_key in servers:
            selected = servers.get(legacy_key)

    if not selected:
        for skey, sentry in list(servers.items()):
            if isinstance(sentry, dict) and sentry.get("streamurl"):
                selected = sentry
                break

    if selected:
        item = dict(selected.get("item") or {})
        url = selected.get("streamurl") or ""
        source_type = selected.get("source_type") or (row or {}).get("source_type") or current_source.get("type") or "xtream"
        source_key = selected.get("source_key") or (row or {}).get("source_key") or current_key
        saved_service_type = selected.get("service_type") or (row or {}).get("service_type")
    else:
        item = dict((row or {}).get("item") or {})
        url = (row or {}).get("streamurl") or item.get("_streamurl") or ""
        source_type = (row or {}).get("source_type") or item.get("_source_type") or current_source.get("type") or "xtream"
        source_key = (row or {}).get("source_key") or item.get("_source_key") or ""
        saved_service_type = (row or {}).get("service_type")

    if not url:
        raise RuntimeError("Playback link is not available for this item.")

    # Keep the same payload shape as Continue Watching, but do not force Resume.
    item.pop("_continue_resume", None)
    item.pop("_continue_position", None)
    item["_source_type"] = source_type
    item["_source_key"] = source_key
    item.setdefault("name", (row or {}).get("title") or item.get("title") or "MOVIE")

    # Use the saved per-source VOD engine. For legacy Continue rows from another
    # source, preserve the engine stored with that exact row.
    try:
        current_matches = bool(current_source) and (not source_key or _source_identity(current_source) == source_key)
    except Exception:
        current_matches = False
    # Always resolve the owning source and use its currently saved Movies
    # engine.  Legacy Continue rows may contain an old 4097 snapshot; that
    # must not override the user's current Xtream Movies player setting.
    engine_source = current_source if current_matches else None
    if not engine_source and source_key:
        try:
            for candidate in get_sources():
                if _source_identity(candidate) == source_key:
                    engine_source = candidate
                    break
        except Exception:
            engine_source = None
    try:
        if engine_source:
            st = int(_media_service_type(engine_source, "vod"))
        else:
            st = int(saved_service_type or 4097)
    except Exception:
        st = int(saved_service_type or 4097)

    # Keep exact resolved movie URL. Older VTi eServiceReference.getPath()
    # can be empty, while toString() includes the display name after the URL.
    item["_tivimate_playback_url"] = url
    from Plugins.Extensions.TiviMateE2Py27.py27_compat import native_media_url_bytes
    ref = eServiceReference(st, 0, native_media_url_bytes(url))
    ref.setName(gui_text((row or {}).get("title") or item.get("name") or item.get("title") or "MOVIE"))

    # Preserve the same service, VOD engine, subtitle state and callback.
    # VTi 15 can leave a suspended parent when Screen.execBegin raises.
    # Never retry a partially-opened player on the same key press.
    from .vti_compat import open_vti_player_once
    open_vti_player_once(session, TiviMatePlayer, ref, item, callback=callback)


from .live_player import TiviMateLivePlayer
