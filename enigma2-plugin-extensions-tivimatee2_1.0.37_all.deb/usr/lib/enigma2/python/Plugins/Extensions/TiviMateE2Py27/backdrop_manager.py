# -*- coding: utf-8 -*-
"""Shared backdrop policy for TiviMateE2 backgrounds and landscape artwork."""
from . import artwork_queue as _queue
from .py27_compat import text_type
from collections import OrderedDict
import threading

KIND = "backdrops"
PROVIDER_KEYS = (
    "backdrop_path", "backdrop", "backdrop_url", "movie_backdrop",
    "fanart", "fanart_url", "background", "background_image",
    "backdrop_image", "backdrop_pic", "screenshot", "screenshot_uri",
)
_PROVIDER_CONTEXTS = OrderedDict()
_CONTEXT_LOCK = threading.RLock()
_MAX_CONTEXTS = 384


def _remember_provider(url, source):
    if not url or not isinstance(source, dict):
        return
    key = _queue.normalise_url(url)
    if not key:
        return
    with _CONTEXT_LOCK:
        _PROVIDER_CONTEXTS.pop(key, None)
        _PROVIDER_CONTEXTS[key] = dict(source)
        while len(_PROVIDER_CONTEXTS) > _MAX_CONTEXTS:
            _PROVIDER_CONTEXTS.popitem(last=False)


def _provider_for(url):
    with _CONTEXT_LOCK:
        return _PROVIDER_CONTEXTS.get(_queue.normalise_url(url))


def provider_backdrop_url(source, item, extra=None):
    """Get genuine landscape artwork from common provider detail structures.

    Xtream and Stalker can nest backdrop fields under info/movie_data/data.
    Only check landscape-specific keys; never substitute a cover/poster.
    """
    for record in (item, extra):
        if not isinstance(record, dict):
            continue
        direct = _queue.find_provider_asset(source, record, PROVIDER_KEYS)
        if direct:
            _remember_provider(direct, source)
            return direct
        for key in ("info", "movie_data", "series_data", "metadata", "data", "details"):
            nested = record.get(key)
            if isinstance(nested, dict):
                found = _queue.find_provider_asset(source, nested, PROVIDER_KEYS)
                if found:
                    _remember_provider(found, source)
                    return found
    return ""


_SIZE_CACHE = [0.0, "w780"]


def configured_backdrop_size():
    """TMDb backdrop size from Settings (default w780). 'original' is often a
    4K / multi-MB file; it is only used when the user picked it explicitly.
    'w1920' is not a TMDb size and maps to w1280. Cached 30 s (no file read
    per artwork URL)."""
    import time as _time
    now = _time.time()
    if now - _SIZE_CACHE[0] < 30.0:
        return _SIZE_CACHE[1]
    try:
        from .tmdb_client import backdrop_quality
        size = backdrop_quality()
    except Exception:
        size = "w780"
    size = {"w1920": "w1280"}.get(size, size)
    size = size if size in ("w780", "w1280", "original") else "w780"
    _SIZE_CACHE[0], _SIZE_CACHE[1] = now, size
    return size


def tmdb_backdrop_url(value, size=None):
    if size is None:
        size = configured_backdrop_size()
    value = text_type(value or u"").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/%s" % size + value
    return value if value.startswith(("https://", "http://")) else ""


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None, source=None):
    from .unified_genre_artwork import request as genre_request
    return genre_request(url, KIND, callback=callback, priority=priority,
                         errback=errback, source=source)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
