# -*- coding: utf-8 -*-
"""Python2.7 DreamOS helpers. Offline and independent of Python3."""

import io
import os


def _decode_source_text(raw):
    """Safely decode provider metadata without disturbing valid UTF-8."""
    try:
        return raw.decode('utf-8')
    except UnicodeDecodeError:
        for cut in (1, 2, 3):
            try:
                return raw[:-cut].decode('utf-8')
            except UnicodeDecodeError:
                pass
        try:
            return raw.decode('cp1256')
        except (UnicodeError, LookupError):
            return raw.decode('utf-8', 'replace')


class _SafeTextWriter(object):
    """Allow Python 2.7 json.dump byte chunks on a Unicode text stream.

    io.open(..., encoding='utf-8') accepts unicode only on Python 2.7.
    json.dump writes both byte str and unicode chunks on that runtime.
    The read path and actual on-disk UTF-8 encoding stay unchanged.
    """
    def __init__(self, stream):
        self._stream = stream

    def __enter__(self):
        self._stream.__enter__()
        return self

    def __exit__(self, *args):
        return self._stream.__exit__(*args)

    def write(self, data):
        if isinstance(data, bytes):
            data = _decode_source_text(data)
        return self._stream.write(data)

    def writelines(self, rows):
        for row in rows:
            self.write(row)

    def __getattr__(self, name):
        return getattr(self._stream, name)


def open_text(path, mode="r", encoding="utf-8", errors="strict"):
    """Open UTF-8 text while accepting Python2 json.dump writes."""
    if "b" in mode:
        return io.open(path, mode)
    stream = io.open(path, mode, encoding=encoding or "utf-8", errors=errors or "strict")
    import sys
    if sys.version_info[0] == 2 and any(x in mode for x in ('w', 'a', '+')):
        return _SafeTextWriter(stream)
    return stream


def json_dump_text(data, stream, **kwargs):
    """JSON-to-text helper for direct io.open unicode output in Python 2.7."""
    import json
    payload = json.dumps(data, **kwargs)
    if isinstance(payload, bytes):
        payload = _decode_source_text(payload)
    return stream.write(payload)


_DIR_MEMO = {}


def ensure_dir(path, mode=511):
    """Create a directory if absent; equivalent to exist_ok=True."""
    if not path:
        return
    # r146: called for every cached image; skip the stat for 30 s once seen.
    import time as _time
    now = _time.time()
    seen = _DIR_MEMO.get(path)
    if seen is not None and 0 <= now - seen < 30.0:
        return
    if os.path.isdir(path):
        if len(_DIR_MEMO) > 256:
            _DIR_MEMO.clear()
        _DIR_MEMO[path] = now
        return
    try:
        os.makedirs(path, mode)
    except (OSError, IOError):
        if not os.path.isdir(path):
            raise


def atomic_replace(source, destination):
    """Use os.replace where available and rename safely on legacy Python."""
    replace = getattr(os, "replace", None)
    if replace is not None:
        return replace(source, destination)
    if os.path.exists(destination):
        try:
            os.unlink(destination)
        except (OSError, IOError):
            pass
    return os.rename(source, destination)


def python_command():
    """Use an actual Python 2 interpreter; never execute a Python 3 binary."""
    for path in ('/usr/bin/python2.7', '/usr/bin/python2'):
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path, path
    legacy = '/usr/bin/python'
    if os.path.isfile(legacy) and os.access(legacy, os.X_OK):
        real = os.path.basename(os.path.realpath(legacy)).lower()
        if 'python3' not in real:
            return legacy, legacy
    # No compatible binary should cause a controlled error, not silently use 3.x.
    raise RuntimeError('Python 2.7 executable not found')
