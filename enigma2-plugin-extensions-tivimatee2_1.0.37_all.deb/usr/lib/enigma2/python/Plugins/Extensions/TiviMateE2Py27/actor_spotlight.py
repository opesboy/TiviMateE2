# -*- coding: utf-8 -*-
"""Actor Spotlight: a dedicated results page for one actor.

Left: portrait, name, birth facts and biography (TMDb person record).
Right: the actor's titles found on the active server, 12 large posters per
page, each captioned with the year and the character played.

The page subclasses the GENRE grid so posters keep its exact provider ->
validation -> TMDb pipeline, sorting, favourites and Details hand-over.  Only
the layout, the page size and the actor panel are new.  Nothing here changes
the actor search itself: the rows are the ones Movie/Series Details found.
"""

import os
import re
import threading
import time
try:
    from .py27_futures import ThreadPoolExecutor
except ImportError:
    from concurrent.futures import ThreadPoolExecutor

from .vti_compat import VTiTextLabel as Label
from Components.Pixmap import Pixmap
from enigma import ePoint

from enigma import ePicLoad
from .py27_compat import text_type, gui_text
from .cache_manager import stable_cache_key, persistent_cache_get, persistent_cache_set
from .display_scale import scale_skin, sx, sy, scale_size
from .display_titles import visible_title
from .genre_page import (StandaloneGenreScreen, GENRE_PILL_SPECS, _genre_pill_score,
                         _genre_pill_language, _genre_pill_age)
from .genre_ultra_artwork import request as fetch_artwork
from .i18n import tr, get_language
from .picload_compat import connect_picture_data
from .resolution_badge import (extract_resolution, extract_rating, extract_duration,
                               _year_genre_from_sources, _actual_media_genre)
from .rtl_text import DirectionalLabel, SynopsisLabel
from .tmdb_client import TMDbClient

def safe_text(value):
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.decode("utf-8", "replace")
    try:
        return text_type(value)
    except Exception:
        return u""


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27"
ART = os.path.join(PLUGIN_PATH, "skins", "actor")
POSTER_PLACEHOLDER = os.path.join(ART, "spot_poster_placeholder.png")

# 1920x1080 design canvas (display_scale converts it for HD / WQHD desktops).
COLS = 6
ROWS = 2
PAGE = COLS * ROWS
BASE_SLOTS = 24              # widgets the GENRE base class always creates
X = (648, 854, 1060, 1266, 1472, 1678)
Y = (250, 605)
POSTER_W = 182
POSTER_H = 273
FOCUS_PAD = 12
PHOTO_X, PHOTO_Y, PHOTO_W, PHOTO_H = 66, 122, 260, 392
PILL_X = 648
PILL_Y = 116
PILL_LIMIT = 1540            # the page counter column starts at x=1566
ROLE_CARD = 15               # characters of a role under a poster
GOLD = "#F2CF85"
LOGO_W, LOGO_H = 192, 34
_SPOT_LOGO_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviSpotLogo")

_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

_TEXT = {
    "ar": {
        "ACTOR": u"ممثل",
        "movies on\nthis server": u"أفلام على\nهذا السيرفر",
        "movie on\nthis server": u"فيلم على\nهذا السيرفر",
        "TV shows on\nthis server": u"مسلسلات على\nهذا السيرفر",
        "TV show on\nthis server": u"مسلسل على\nهذا السيرفر",
        "out of %d\nTMDb credits": u"من أصل %d\nعملاً في TMDb",
        "BORN": u"الميلاد",
        "FROM": u"من",
        "as %s": u"بدور %s",
        "KNOWN FOR %s": u"معروف بـ %s",
        "Acting": u"التمثيل", "Directing": u"الإخراج", "Writing": u"الكتابة", "Production": u"الإنتاج",
    },
    "fr": {
        "ACTOR": u"ACTEUR",
        "movies on\nthis server": u"films sur\nce serveur",
        "movie on\nthis server": u"film sur\nce serveur",
        "TV shows on\nthis server": u"séries sur\nce serveur",
        "TV show on\nthis server": u"série sur\nce serveur",
        "out of %d\nTMDb credits": u"sur %d\ncrédits TMDb",
        "BORN": u"NAISSANCE",
        "FROM": u"ORIGINE",
        "as %s": u"rôle : %s",
        "KNOWN FOR %s": u"CONNU POUR : %s",
        "Acting": u"INTERPRÉTATION", "Directing": u"RÉALISATION", "Writing": u"ÉCRITURE", "Production": u"PRODUCTION",
    },
    "tr": {
        "ACTOR": u"OYUNCU",
        "movies on\nthis server": u"film bu\nsunucuda",
        "movie on\nthis server": u"film bu\nsunucuda",
        "TV shows on\nthis server": u"dizi bu\nsunucuda",
        "TV show on\nthis server": u"dizi bu\nsunucuda",
        "out of %d\nTMDb credits": u"toplam %d\nTMDb yapımı",
        "BORN": u"DOĞUM",
        "FROM": u"YER",
        "as %s": u"rol: %s",
        "KNOWN FOR %s": u"ALANI: %s",
        "Acting": u"OYUNCULUK", "Directing": u"YÖNETMENLİK", "Writing": u"YAZARLIK", "Production": u"YAPIM",
    },
}


def _language():
    try:
        return safe_text(get_language() or "en").lower()[:2]
    except Exception:
        return "en"


def _t(text):
    """Page-local labels; unknown languages and keys stay English."""
    return _TEXT.get(_language(), {}).get(text, text)


def _shorten(value, limit):
    text = " ".join(safe_text(value or "").split())
    if len(text) <= limit:
        return text
    part = text[:limit].rstrip()
    cut = part.rfind(" ")
    if cut >= limit // 2:
        part = part[:cut]
    return part.rstrip(u" -_|:/,.؛،") + u"…"


def _person_number(person_id):
    try:
        value = int(safe_text(person_id or "0").strip())
    except Exception:
        return 0
    return value if value > 0 else 0


def _parse_date(value):
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", safe_text(value or "").strip())
    if not match:
        return None
    year, month, day = int(match.group(1)), int(match.group(2)), int(match.group(3))
    if not (1800 <= year <= 2200 and 1 <= month <= 12 and 1 <= day <= 31):
        return None
    return year, month, day


def _years_between(start, end):
    years = end[0] - start[0]
    if (end[1], end[2]) < (start[1], start[2]):
        years -= 1
    return years


def _format_date(parts):
    year, month, day = parts
    if _language() == "en":
        return "%d %s %d" % (day, _MONTHS[month - 1], year)
    return "%02d/%02d/%d" % (day, month, year)


def birth_line(birthday, deathday, today=None):
    """'14 May 1983 (43)' for the living, '1933 – 2020 (86)' otherwise."""
    born = _parse_date(birthday)
    if not born:
        return ""
    died = _parse_date(deathday)
    if died:
        age = _years_between(born, died)
        text = u"%d – %d" % (born[0], died[0])
        return (text + " (%d)" % age) if 0 < age < 125 else text
    if today is None:
        now = time.localtime()
        today = (now.tm_year, now.tm_mon, now.tm_mday)
    age = _years_between(born, today)
    text = _format_date(born)
    # A receiver without a valid clock (1970) must not invent an age.
    return (text + " (%d)" % age) if 0 < age < 125 else text


def birthplace_line(value):
    parts = [part.strip() for part in safe_text(value or "").split(",") if part.strip()]
    if len(parts) > 2:
        parts = [parts[0], parts[-1]]
    return _shorten(", ".join(parts), 32)


def department_line(value):
    name = safe_text(value or "").strip()
    if not name:
        return ""
    label = _TEXT.get(_language(), {}).get(name)
    if label is None:
        label = name.upper() if _language() == "en" else name
    return _t("KNOWN FOR %s") % label


def load_person(person_id):
    """Compact TMDb person record, cached for a week.  Worker threads only."""
    number = _person_number(person_id)
    if not number:
        return {}
    try:
        client = TMDbClient()
        language = safe_text(client.language or "en-US")
    except Exception:
        return {}
    key = stable_cache_key("actor_spotlight_person_v1", number, language)
    try:
        saved = persistent_cache_get(key)
        if isinstance(saved, dict) and saved.get("id"):
            return saved
    except Exception:
        pass
    try:
        data = client._get("/person/%d" % number) or {}
    except Exception:
        data = {}
    if not isinstance(data, dict) or not data.get("id"):
        return {}
    biography = safe_text(data.get("biography") or "").strip()
    if not biography and not language.lower().startswith("en"):
        # Most people have no translated biography: English beats an empty panel.
        try:
            english = client._get("/person/%d" % number, {"language": "en-US"}) or {}
            if isinstance(english, dict):
                biography = safe_text(english.get("biography") or "").strip()
        except Exception:
            pass
    record = {
        "id": safe_text(data.get("id")),
        "name": safe_text(data.get("name") or ""),
        "biography": biography[:1200],
        "birthday": safe_text(data.get("birthday") or ""),
        "deathday": safe_text(data.get("deathday") or ""),
        "place_of_birth": safe_text(data.get("place_of_birth") or ""),
        "known_for_department": safe_text(data.get("known_for_department") or ""),
        "profile_path": safe_text(data.get("profile_path") or ""),
    }
    try:
        persistent_cache_set(key, "actor_spotlight", record, 7 * 24 * 3600)
    except Exception:
        pass
    return record


def _clean_role(value):
    text = " ".join(safe_text(value or "").split())
    return _shorten(text, 26) if text else ""


def load_roles(person_id, kind):
    """Character names of one person by TMDb id / title key, cached 24 h.

    Same languages as the actor search (TMDb language, English, Arabic), so a
    provider title in any of them finds its credit.  Worker threads only.
    """
    number = _person_number(person_id)
    if not number:
        return {}
    from .actor_match import title_key, loose_key, _languages
    try:
        client = TMDbClient()
        languages = _languages(client)
    except Exception:
        return {}
    endpoint = "/person/%d/%s" % (number, "tv_credits" if kind == "series" else "movie_credits")
    key = stable_cache_key("actor_spotlight_roles_v2", endpoint, ",".join(languages))
    try:
        saved = persistent_cache_get(key)
        if isinstance(saved, dict) and saved.get("count"):
            return saved
    except Exception:
        pass
    payloads = [None] * len(languages)

    def fetch(index, language):
        try:
            payloads[index] = client._get(endpoint, {"language": language}) or {}
        except Exception:
            payloads[index] = None

    workers = []
    for index, language in enumerate(languages):
        worker = threading.Thread(target=fetch, args=(index, language), name="TiviActorRoles")
        worker.daemon = True
        worker.start()
        workers.append(worker)
    deadline = time.time() + 15
    for worker in workers:
        worker.join(max(0.1, deadline - time.time()))
    ids, keys, loose, seen = {}, {}, {}, set()
    title_ids = {}
    for payload in payloads:
        if not isinstance(payload, dict):
            continue
        for credit in payload.get("cast") or []:
            if not isinstance(credit, dict):
                continue
            credit_id = safe_text(credit.get("id") or "").strip()
            if credit_id:
                seen.add(credit_id)
            # Credits IDs are verified TMDb identities, unlike provider stream IDs.
            credit_year = (str(credit.get("release_date") or credit.get("first_air_date") or "")[:4])
            for field in ("title", "original_title", "name", "original_name"):
                title = title_key(credit.get(field))
                if title and credit_id:
                    identity = title + "|" + credit_year
                    prev = title_ids.get(identity)
                    if prev is None:
                        title_ids[identity] = credit_id
                    elif prev != credit_id:
                        title_ids[identity] = ""  # ambiguous remake: no wrong logo
            role = _clean_role(credit.get("character")) or ids.get(credit_id, "")
            if not role:
                continue
            if credit_id:
                ids.setdefault(credit_id, role)
            for field in ("title", "original_title", "name", "original_name"):
                title = title_key(credit.get(field))
                if not title:
                    continue
                keys.setdefault(title, role)
                compact = loose_key(title)
                if len(compact) >= 3:
                    loose.setdefault(compact, role)
    result = {"count": len(seen), "ids": ids, "keys": keys, "loose": loose,
              "credit_ids": list(seen), "title_ids": title_ids}
    if seen:
        try:
            persistent_cache_set(key, "actor_spotlight", result, 24 * 3600)
        except Exception:
            pass
    return result


def role_for(roles, row):
    """The character this actor plays in one provider row, or ''."""
    if not isinstance(roles, dict) or not isinstance(row, dict):
        return ""
    from .actor_match import title_key, loose_key, _row_tmdb_id
    try:
        ids = roles.get("ids") or {}
        keys = roles.get("keys") or {}
        loose = roles.get("loose") or {}
        tmdb_id = _row_tmdb_id(row)
        if tmdb_id and ids.get(tmdb_id):
            return safe_text(ids[tmdb_id])
        for field in ("name", "title", "original_name", "original_title", "o_name"):
            title = title_key(row.get(field))
            if not title:
                continue
            if keys.get(title):
                return safe_text(keys[title])
            compact = loose_key(title)
            if len(compact) >= 3 and loose.get(compact):
                return safe_text(loose[compact])
    except Exception:
        pass
    return ""


def verified_credit_id(roles, row):
    """Return only a TMDb ID proven to belong to this actor and exact title/year."""
    if not isinstance(roles, dict) or not isinstance(row, dict):
        return ""
    from .actor_match import title_key, _row_tmdb_id
    credits = roles.get("credit_ids") or []
    item_id = _row_tmdb_id(row)
    if item_id and item_id in credits:
        return item_id
    title_ids = roles.get("title_ids") or {}
    year = safe_text(row.get("year") or row.get("release_date") or row.get("first_air_date") or "")[:4]
    if not year.isdigit():
        # Missing year: never risk attributing a same-name film to the wrong remake.
        return ""
    for field in ("name", "title", "original_title", "o_name"):
        title = title_key(row.get(field))
        if title:
            match = title_ids.get(title + "|" + year)
            if match:
                return match
    return ""


def build_skin():
    rows = [
        '<screen name="ActorSpotlightScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05070B">',
        '<eLabel position="0,0" size="1920,1080" backgroundColor="#05070B" zPosition="0" />',
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="off" scale="1" zPosition="1" />' % os.path.join(ART, "spotlight_bg.jpg"),

        # ---- actor panel -------------------------------------------------
        '<widget name="actorTag" position="104,58" size="440,34" font="Bold;21" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorPhoto" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="4" />' % (
            PHOTO_X, PHOTO_Y, PHOTO_W, PHOTO_H, os.path.join(ART, "actor_default.png")),
        '<ePixmap position="64,120" size="264,396" pixmap="%s" alphatest="blend" scale="1" zPosition="6" />' % os.path.join(ART, "actor_frame.png"),
        '<widget name="actorCount" position="352,276" size="196,104" font="Bold;84" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorCountLabel" position="356,384" size="192,58" font="Regular;21" foregroundColor="#F7F4EC" transparent="1" zPosition="5" />',
        '<eLabel position="356,450" size="56,2" backgroundColor="%s" zPosition="5" />' % GOLD,
        '<widget name="actorCredits" position="356,462" size="192,54" font="Regular;18" foregroundColor="#C7D5E0" transparent="1" zPosition="5" />',
        '<widget name="actorName" position="64,538" size="484,64" font="Bold;44" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorNameSmall" position="64,538" size="484,64" font="Bold;31" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorRole" position="64,606" size="484,28" font="Regular;19" foregroundColor="#C7D5E0" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorBornTag" position="64,652" size="118,30" font="Bold;16" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorBorn" position="186,652" size="362,30" font="Regular;21" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorFromTag" position="64,688" size="118,30" font="Bold;16" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorFrom" position="186,688" size="362,30" font="Regular;21" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorBio" position="64,738" size="484,190" font="Regular;20" foregroundColor="#C7D5E0" transparent="1" zPosition="5" />',
        '<widget name="status" position="64,946" size="484,28" font="Regular;18" foregroundColor="#E5C478" transparent="1" valign="center" noWrap="1" zPosition="5" />',

        # ---- selected title ----------------------------------------------
        '<widget name="heroTitle" position="648,50" size="900,56" font="Bold;38" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
    ]
    pill_fonts = {"genreCategories": 18, "genreQuality": 17}
    for name, width, inset, style in GENRE_PILL_SPECS:
        rows.append('<widget name="%sBg" position="%d,%d" size="%d,38" pixmap="%s" alphatest="blend" zPosition="8" />' % (
            name, PILL_X, PILL_Y, width, os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_%s.png" % style)))
        rows.append('<widget name="%s" position="%d,%d" size="%d,38" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />' % (
            name, PILL_X + inset, PILL_Y, width - inset - (5 if inset <= 5 else 8), pill_fonts.get(name, 19)))
    rows.extend([
        # "as <character>" for the selected title, under the page counter.
        '<widget name="actorPlays" position="1566,166" size="294,60" font="Bold;20" foregroundColor="%s" transparent="1" halign="center" zPosition="5" />' % GOLD,
        '<widget name="heroPlot" position="648,166" size="900,64" font="Regular;21" foregroundColor="#E0E8F0" transparent="1" zPosition="5" />',
        '<ePixmap position="1566,50" size="294,62" pixmap="%s" alphatest="blend" zPosition="5" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_page_counter_gold_r136.png"),
        '<widget name="page" position="1566,62" size="294,38" font="Bold;25" foregroundColor="#FFE1A0" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />',
        '<widget name="heading" position="1566,122" size="294,34" font="Bold;22" foregroundColor="#F8D891" transparent="1" halign="center" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="selector" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="10" />' % (
            X[0] - FOCUS_PAD, Y[0] - FOCUS_PAD, POSTER_W + 2 * FOCUS_PAD, POSTER_H + 2 * FOCUS_PAD, os.path.join(ART, "spot_focus.png")),

        # ---- remote legend -----------------------------------------------
        '<ePixmap position="20,1027" size="1880,52" pixmap="%s" alphatest="blend" scale="1" zPosition="35" />' % os.path.join(ART, "spot_toolbar.png"),
        '<widget name="footerSortValue" position="582,1054" size="170,20" font="Regular;15" foregroundColor="#C6CFDA" backgroundColor="#00000000" transparent="1" halign="left" valign="center" noWrap="1" zPosition="38" />',

        # ---- GENRE widgets this page does not show (names stay valid) ----
        '<widget name="heroBackdrop" position="0,0" size="1,1" alphatest="blend" />',
        '<widget name="heroLogo" position="0,0" size="1,1" alphatest="blend" />',
        '<widget name="packageLogo" position="0,0" size="1,1" alphatest="blend" />',
    ])
    for name in ("heroInfo", "heroMeta", "subheading", "footerServerName",
                 "redHint", "greenHint", "yellowHint", "blueHint", "menuHint"):
        rows.append('<widget name="%s" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % name)
    for index in range(10):
        rows.append('<widget name="nav%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % index)
    for index in range(8):
        rows.append('<widget name="genre%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % index)

    shell = os.path.join(ART, "spot_poster_shell.png")
    for slot in range(BASE_SLOTS):
        if slot >= PAGE:
            rows.extend([
                '<widget name="poster%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
                '<widget name="shell%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
                '<widget name="title%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % slot,
                '<widget name="meta%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % slot,
                '<widget name="spotLogo%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
            ])
            continue
        xpos, ypos = X[slot % COLS], Y[slot // COLS]
        rows.extend([
            '<widget name="poster%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="4" />' % (
                slot, xpos, ypos, POSTER_W, POSTER_H, POSTER_PLACEHOLDER),
            '<widget name="shell%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="5" />' % (
                slot, xpos, ypos, POSTER_W, POSTER_H, shell),
            '<widget name="title%d" position="%d,%d" size="%d,34" font="Bold;17" foregroundColor="#F7F4EC" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, xpos - 10, ypos + POSTER_H + 8, POSTER_W + 20),
            '<widget name="spotLogo%d" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" zPosition="8" />' % (
                slot, xpos - 10, ypos + POSTER_H + 8, POSTER_W + 20, LOGO_H),
            '<widget name="meta%d" position="%d,%d" size="%d,24" font="Regular;15" foregroundColor="#C7D5E0" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, xpos - 10, ypos + POSTER_H + 46, POSTER_W + 20),
        ])
    rows.append('</screen>')
    return scale_skin("\n".join(rows))


class ActorSpotlightScreen(StandaloneGenreScreen):
    """Actor results: portrait panel plus 12 large posters per page."""

    _PAGE_SOURCE_PREFIX = "actor_spotlight_"
    _CARD_SIZE = (POSTER_W, POSTER_H)     # read by the GENRE poster decoder
    skin = build_skin()

    def __init__(self, session, source, initial_kind="vod", initial_category_id=""):
        StandaloneGenreScreen.__init__(self, session, source, initial_kind, initial_category_id)
        person = self.source.get("_actor_search_person")
        self._spot_person = dict(person) if isinstance(person, dict) else {}
        self._spot_person_id = safe_text(self._spot_person.get("id") or "").strip()
        self._spot_name = safe_text(self.source.get("_actor_search_name") or
                              self._spot_person.get("name") or "").strip()
        self._spot_roles = {}
        self._spot_credit_total = 0
        self._spot_photo_url = ""
        self._spot_photo_loader = None
        self._spot_logo_tokens = {}
        self._spot_logo_jobs = []
        self._spot_logo_decoders = {}
        self._spot_logo_page_key = None
        for slot in range(BASE_SLOTS):
            self["spotLogo%d" % slot] = Pixmap()
            self["spotLogo%d" % slot].hide()
        self.onClose.append(self._spot_close_logos)
        self["actorTag"] = Label(_t("ACTOR"))
        self["actorPhoto"] = Pixmap()
        self["actorCount"] = Label("")
        self["actorCountLabel"] = Label("")
        self["actorCredits"] = Label("")
        self["actorName"] = DirectionalLabel("")
        self["actorNameSmall"] = DirectionalLabel("")
        self["actorRole"] = Label("")
        self["actorBornTag"] = Label("")
        self["actorBorn"] = Label("")
        self["actorFromTag"] = Label("")
        self["actorFrom"] = Label("")
        self["actorBio"] = SynopsisLabel("")
        self["actorPlays"] = Label("")
        self["actorPlays"].hide()
        for slot in range(PAGE, BASE_SLOTS):
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        # Bound method on purpose: OpenATV exec()s non-method entries.
        self.onLayoutFinish.append(self._spot_begin)

    # ------------------------------------------------------------ actor panel
    def _spot_begin(self):
        try:
            self._spot_set_name(self._spot_name)
            self._spot_update_counts()
        except Exception:
            pass
        self._spot_request_photo(self._spot_person.get("profile_path"))
        self._spot_load_person()

    def _spot_set_name(self, name):
        name = " ".join(safe_text(name or "").split())
        long_name = len(name) > 17
        self["actorName"].setText("" if long_name else name)
        self["actorNameSmall"].setText(_shorten(name, 27) if long_name else "")

    def _spot_update_counts(self):
        try:
            total = len(self._poster_original_rows or self.genre_items or [])
            series = self.kind == "series"
            if total == 1:
                label = "TV show on\nthis server" if series else "movie on\nthis server"
            else:
                label = "TV shows on\nthis server" if series else "movies on\nthis server"
            self["actorCount"].setText(safe_text(total) if total else "")
            self["actorCountLabel"].setText(_t(label) if total else "")
            credits = int(self._spot_credit_total or 0)
            # The current Details title is left out of the results, so only a
            # larger TMDb total is a meaningful "out of".
            self["actorCredits"].setText(
                (_t("out of %d\nTMDb credits") % credits) if total and credits > total else "")
        except Exception:
            pass

    def _spot_request_photo(self, profile_path):
        path = safe_text(profile_path or "").strip()
        if path.startswith("http"):
            url = path
        elif path.startswith("/"):
            url = "https://image.tmdb.org/t/p/w342" + path
        else:
            return
        if url == self._spot_photo_url or self._closed:
            return
        self._spot_photo_url = url
        try:
            fetch_artwork(url, "actor", dict(self.source or {}), self._spot_photo_ready,
                          self._spot_photo_failed, self._post_to_gui)
        except Exception:
            pass

    def _spot_photo_failed(self, _path=None):
        """No portrait: the neutral default from the skin stays visible."""
        return

    def _spot_photo_ready(self, local):
        if getattr(self, "_closed", True) or not local or not os.path.isfile(local):
            return
        loader = ePicLoad()
        self._spot_photo_loader = loader

        def ready(_info=None, current=loader):
            try:
                if getattr(self, "_closed", True) or self._spot_photo_loader is not current:
                    return
                pointer = current.getData()
                widget = self["actorPhoto"]
                if pointer and widget.instance:
                    widget.instance.setPixmap(pointer)
                    widget.show()
            except Exception:
                pass

        try:
            connect_picture_data(loader, ready, self, oneshot=True)
            width, height = scale_size(PHOTO_W, PHOTO_H)
            loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(local)
        except Exception:
            pass

    def _spot_load_person(self):
        person_id = self._spot_person_id
        kind = self.kind
        if not person_id:
            return

        def worker():
            try:
                info = load_person(person_id)
            except Exception:
                info = {}
            if info and not getattr(self, "_closed", True):
                self._post_to_gui(self._spot_apply_person, info)
            try:
                roles = load_roles(person_id, kind)
            except Exception:
                roles = {}
            if roles and not getattr(self, "_closed", True):
                self._post_to_gui(self._spot_apply_roles, roles)

        thread = threading.Thread(target=worker, name="TiviMateActorSpotlight")
        thread.daemon = True
        thread.start()

    def _spot_apply_person(self, info):
        if getattr(self, "_closed", True) or not isinstance(info, dict):
            return
        try:
            self["actorRole"].setText(department_line(info.get("known_for_department")))
            born = birth_line(info.get("birthday"), info.get("deathday"))
            self["actorBornTag"].setText(_t("BORN") if born else "")
            self["actorBorn"].setText(born)
            place = birthplace_line(info.get("place_of_birth"))
            self["actorFromTag"].setText(_t("FROM") if place else "")
            self["actorFrom"].setText(place)
            self["actorBio"].setText(_shorten(info.get("biography"), 260))
        except Exception:
            pass
        if not self._spot_photo_url:
            self._spot_request_photo(info.get("profile_path"))

    def _spot_apply_roles(self, roles):
        if getattr(self, "_closed", True) or not isinstance(roles, dict):
            return
        self._spot_roles = roles
        try:
            self._spot_credit_total = int(roles.get("count") or 0)
        except Exception:
            self._spot_credit_total = 0
        self._spot_update_counts()
        self._spot_refresh_captions()
        self._spot_place_role()
        self._spot_request_logos()

    def _spot_role(self, item):
        return role_for(self._spot_roles, item) if self._spot_roles else ""

    def _spot_caption(self, item):
        year = safe_text(item.get("year") or item.get("releaseDate") or item.get("release_date") or
                   item.get("first_air_date") or "")[:4]
        if not year.isdigit():
            year = ""
        role = self._spot_role(item)
        if role:
            second = _t("as %s") % _shorten(role, ROLE_CARD)
        else:
            rating = safe_text(item.get("rating") or item.get("rating_5based") or
                         item.get("vote_average") or "").strip()
            second = (u"★ " + rating[:4]) if rating and rating not in ("0", "0.0") else ""
        return u" · ".join(part for part in (year, second) if part)

    def _spot_refresh_captions(self):
        """Roles arrive after the posters: repaint the two text lines only."""
        try:
            total = len(self.genre_items)
            for slot in range(PAGE):
                index = self.page_start + slot
                if index < total and isinstance(self.genre_items[index], dict):
                    self["meta%d" % slot].setText(self._spot_caption(self.genre_items[index]))
        except Exception:
            pass

    def _spot_place_role(self):
        """'as <character>' for the selected title, under the page counter."""
        try:
            label = self["actorPlays"]
            role = self._spot_role(self._selected_item() or {})
            if not role:
                label.hide()
                return
            label.setText(_t("as %s") % role)
            label.show()
        except Exception:
            pass

    # ------------------------------------------------------ title clearlogos
    def _spot_close_logos(self):
        for job in getattr(self, "_spot_logo_jobs", ()):
            try:
                job.cancel()
            except Exception:
                pass
        self._spot_logo_jobs = []
        self._spot_logo_tokens.clear()
        self._spot_logo_decoders.clear()

    def _spot_request_logos(self):
        # Identical title clearlogos for films and TV series; keep readable captions as fallback.
        if self.kind not in ("vod", "series") or getattr(self, "_closed", True):
            return
        if not self._spot_roles or not self.genre_items:
            return
        for slot in range(PAGE):
            index = self.page_start + slot
            if index >= len(self.genre_items):
                continue
            row = self.genre_items[index]
            if not isinstance(row, dict):
                continue
            media_id = verified_credit_id(self._spot_roles, row)
            if not media_id:
                continue
            token = (self._generation, index, media_id)
            if self._spot_logo_tokens.get(slot) == token:
                continue
            self._spot_logo_tokens[slot] = token
            title = safe_text(row.get("name") or row.get("title") or "")
            snap = dict(row)
            def worker(current_slot=slot, current_token=token, item=snap,
                       ident=media_id, name=title):
                try:
                    from .title_logo_ultra_bridge import resolve_title_logo
                    def obsolete():
                        return (getattr(self, "_closed", True) or
                                self._spot_logo_tokens.get(current_slot) != current_token)
                    if obsolete():
                        return
                    image = resolve_title_logo(TMDbClient(), self.kind, ident, title=name,
                                               item=item, canvas=(LOGO_W, LOGO_H),
                                               cancelled=obsolete)
                    if image and not obsolete():
                        self._post_to_gui(self._spot_show_logo, current_slot, current_token, image)
                except Exception:
                    pass  # readable movie/series title remains the default fallback
            try:
                self._spot_logo_jobs.append(_SPOT_LOGO_POOL.submit(worker))
            except Exception:
                self._spot_logo_tokens.pop(slot, None)

    def _spot_show_logo(self, slot, token, path):
        if (getattr(self, "_closed", True) or
                self._spot_logo_tokens.get(slot) != token or
                not os.path.isfile(path)):
            return
        widget = self["spotLogo%d" % slot]
        # Alpha-preserving renderer on old VTi, pure/EGAMI and Python3.
        try:
            from .transparent_pixmap import show_widget
            if show_widget(widget, path, align="center"):
                self["title%d" % slot].hide()
                return
        except Exception:
            pass
        # A failed PNG paint leaves the text visible instead of a black box.

    # ------------------------------------------- GENRE behaviour not used here
    def _adjust_movie_logo_size(self):
        return

    def _request_hero_artwork(self, token, url, category, widget, origin="provider"):
        # The stage belongs to the actor: no film backdrop or clearlogo.
        return

    def _show_hero_image(self, token, name, path):
        return

    def _set_hero_logo_state(self, active):
        self._hero_logo_active = False
        try:
            self["heroTitle"].setText(visible_title(getattr(self, "_hero_plain_title", ""), 44))
        except Exception:
            pass

    def open_poster_server(self):
        # These results belong to the server they were searched on.
        return

    def filter_poster_server(self):
        return

    # ------------------------------------------------------------- hero text
    def _set_hero_text(self, info):
        StandaloneGenreScreen._set_hero_text(self, info)
        badges = {}
        try:
            sources = getattr(self, "_hero_text_sources", {}) or {}
            item = self._selected_item() or {}
            provider = sources.get("provider") or {}
            catalog = sources.get("catalog") or {}
            verified = sources.get("tmdb_verified") or {}
            tmdb = sources.get("tmdb") or {}
            year_value, _genres = _year_genre_from_sources([info, provider, item, catalog])
            ordered = (provider, item, verified, tmdb, catalog)
            badges = {
                "genreYear": year_value or safe_text(info.get("year") or "").strip()[:4],
                "genreCategories": _actual_media_genre(verified, tmdb, sources.get("tmdb_search") or {},
                                                       provider, info, item, catalog),
                "genreRating": _genre_pill_score(extract_rating(info, verified, tmdb, item)),
                "genreDuration": extract_duration(info, provider, item, catalog),
                "genreLanguage": _genre_pill_language(*ordered),
                "genreAge": _genre_pill_age(*ordered),
                "genreQuality": extract_resolution(item, catalog, provider),
            }
        except Exception:
            badges = {}
        self._render_genre_metadata_pills(badges)
        try:
            self["heroMeta"].setText("")
            self["heroPlot"].setText(_shorten(info.get("description"), 200))
        except Exception:
            pass

    def _render_genre_metadata_pills(self, values):
        xpos = PILL_X
        for name, width, inset, _style in GENRE_PILL_SPECS:
            text = safe_text((values or {}).get(name) or "").strip()
            if name == "genreCategories" and len(text) > 30:
                text = text[:28].rstrip(u" ,،") + u"…"
            widget = self[name]
            background = self[name + "Bg"]
            widget.setText(text)
            if not text or xpos + width > PILL_LIMIT:
                widget.hide()
                background.hide()
                continue
            try:
                background.instance.move(ePoint(sx(xpos), sy(PILL_Y)))
                widget.instance.move(ePoint(sx(xpos + inset), sy(PILL_Y)))
                background.show()
                widget.show()
            except Exception:
                widget.hide()
                background.hide()
                continue
            xpos += width + 8

    # ------------------------------------------------------------------ grid
    def _set_placeholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(POSTER_PLACEHOLDER)
        except Exception:
            pass

    def _render_empty(self, message):
        try:
            self._hero_timer.stop()
        except Exception:
            pass
        self._hero_token = None
        self._hero_text_token = None
        self._hero_text_sources = {}
        self._hero_plain_title = ""
        self._hero_logo_active = False
        self["heading"].setText(tr("TV SHOWS") if self.kind == "series" else tr("MOVIES"))
        self["page"].setText("1 / 1")
        self["status"].setText(message)
        self["heroTitle"].setText("")
        self["heroMeta"].setText("")
        self["heroPlot"].setText("")
        for name, _width, _inset, _style in GENRE_PILL_SPECS:
            self[name].setText("")
            self[name].hide()
            self[name + "Bg"].hide()
        self["actorPlays"].hide()
        self._rendered_page_key = None
        for slot in range(BASE_SLOTS):
            self["title%d" % slot].setText("")
            self["meta%d" % slot].setText("")
            self["spotLogo%d" % slot].hide()
            self["title%d" % slot].show()
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        try:
            self["selector"].hide()
        except Exception:
            pass

    def render(self):
        total = len(self.genre_items)
        pages = max(1, (total + PAGE - 1) // PAGE)
        self.page_start = (self.index // PAGE) * PAGE if total else 0
        self["heading"].setText(tr("TV SHOWS") if self.kind == "series" else tr("MOVIES"))
        self["page"].setText("%d / %d" % (self.page_start // PAGE + 1, pages))
        self._spot_update_counts()
        selected = self._selected_item() or {}
        self._schedule_hero()
        self._update_hero_info(self._hero_token, {
            "title": safe_text(selected.get("name") or selected.get("title") or ""),
            "year": safe_text(selected.get("year") or selected.get("release_date") or "")[:4],
            "rating": safe_text(selected.get("rating") or selected.get("vote_average") or ""),
            "description": safe_text(selected.get("plot") or selected.get("description") or
                               selected.get("overview") or selected.get("storyline") or
                               selected.get("plot_outline") or "").strip(),
            # The virtual category is the actor's name, never a film genre.
            "category": "",
        }, "catalog")
        self._spot_place_role()

        # Moving inside a page only moves the focus ring (no poster reloads).
        page_key = (self._generation, self.page_start, total)
        if page_key != self._rendered_page_key:
            self._spot_close_logos()
            self._cancel_poster_jobs()
            self._rendered_page_key = page_key
            self._poster_resolved_priority.clear()
            self._poster_tmdb_started.clear()
            for slot in range(PAGE):
                item_index = self.page_start + slot
                item = self.genre_items[item_index] if item_index < total else None
                if not isinstance(item, dict):
                    self._poster_tokens.pop(slot, None)
                    self["poster%d" % slot].hide()
                    self["shell%d" % slot].hide()
                    self["title%d" % slot].setText("")
                    self["meta%d" % slot].setText("")
                    self["spotLogo%d" % slot].hide()
                    self["title%d" % slot].show()
                    continue
                self["poster%d" % slot].show()
                self["shell%d" % slot].show()
                self["spotLogo%d" % slot].hide()
                self["title%d" % slot].show()
                self["title%d" % slot].setText(
                    visible_title(safe_text(item.get("name") or item.get("title") or ""), 19))
                self["meta%d" % slot].setText(self._spot_caption(item))
                self._set_placeholder(slot)
                self._load_poster(slot, item, item_index)
            self._spot_request_logos()

        if total:
            slot = self.index - self.page_start
            self["selector"].instance.move(ePoint(sx(X[slot % COLS] - FOCUS_PAD),
                                                  sy(Y[slot // COLS] - FOCUS_PAD)))
            self["selector"].show()
        else:
            self["selector"].hide()

    # ------------------------------------------------------------ navigation
    def left(self):
        if self.genre_items and self.index % COLS:
            self.index -= 1
            self.render()

    def right(self):
        if (self.genre_items and self.index + 1 < len(self.genre_items)
                and self.index % COLS < COLS - 1):
            self.index += 1
            self.render()

    def up(self):
        if self.genre_items and self.index >= COLS:
            self.index -= COLS
            self.render()

    def down(self):
        if not self.genre_items:
            return
        last = len(self.genre_items) - 1
        if self.index + COLS <= last:
            self.index += COLS
            self.render()
        elif self.index // COLS < last // COLS:
            # A shorter last row: land on its final poster instead of stopping.
            self.index = last
            self.render()

    def page_up(self):
        if self.genre_items and self.index >= PAGE:
            self.index -= PAGE
            self.render()

    def page_down(self):
        if not self.genre_items:
            return
        last = len(self.genre_items) - 1
        if self.index // PAGE < last // PAGE:
            self.index = min(last, self.index + PAGE)
            self.render()

    # ------------------------------------------------------------ view styles
    def open_view_style_menu(self):
        from .view_style_picker import PosterViewPicker
        self.session.openWithCallback(self._view_style_chosen, PosterViewPicker,
                                      "actor", self.kind, True)

    def _view_style_chosen(self, choice=None):
        if choice == "spotlight":
            return      # already here
        return StandaloneGenreScreen._view_style_chosen(self, choice)
