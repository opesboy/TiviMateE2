# -*- coding: utf-8 -*-
"""Page design picker: 2x2 preview cards for Movies and Series layouts."""
import os
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from .display_scale import scale_skin, sx, sy
from .movies_layout_choice import get_content_layout
from enigma import ePoint

_ASSETS = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker'
_CHOICES = ('new', 'current', 'grid24', 'apple')
_CARDS = ((210, 150), (990, 150), (210, 620), (990, 620))
_W, _H = 720, 405


def _pix(name, x, y, w, h, z, image):
    return ('<widget name="%s" position="%d,%d" size="%d,%d" pixmap="%s/%s" '
            'alphatest="blend" scale="1" zPosition="%d" />' % (name, x, y, w, h, _ASSETS, image, z))


class MoviesPagePicker(Screen):
    skin = scale_skin(
        '<screen name="MoviesPagePicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05060A">'
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s/picker_bg.jpg" alphatest="off" scale="1" zPosition="1" />' % _ASSETS
        + ''.join(_pix('dim%d' % i, x, y, _W, _H, 2, 'picker_dim.png') for i, (x, y) in enumerate(_CARDS))
        + _pix('designFocus', _CARDS[0][0] - 20, _CARDS[0][1] - 20, _W + 40, _H + 40, 3, 'picker_focus.png')
        + _pix('activeBadge', _CARDS[0][0] + _W - 166, _CARDS[0][1] + 16, 150, 40, 4, 'picker_active.png')
        + '</screen>')

    def __init__(self, session, kind='vod'):
        Screen.__init__(self, session)
        self.kind = 'series' if kind == 'series' else 'vod'
        self.choices = _CHOICES
        active = get_content_layout(self.kind)
        self.active = self.choices.index(active) if active in self.choices else -1
        self.index = self.active if self.active >= 0 else 0
        self._finished = False
        for i in range(len(_CARDS)):
            self['dim%d' % i] = Pixmap()
        self['designFocus'] = Pixmap()
        self['activeBadge'] = Pixmap()
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'ChannelSelectBaseActions',
            'InfobarChannelSelection', 'MenuActions'], {'ok': self.accept, 'cancel': self.cancel,
            'menu': self.cancel, 'left': self.left, 'right': self.right,
            'up': self.up, 'down': self.down, 'pageUp': self.left, 'pageDown': self.right,
            'channelUp': self.left, 'channelDown': self.right,
            'prevBouquet': self.left, 'nextBouquet': self.right}, -1)
        self.onLayoutFinish.append(self.prepare)

    def prepare(self):
        if self._finished:
            return
        try:
            if self.active >= 0:
                x, y = _CARDS[self.active]
                self['activeBadge'].instance.move(ePoint(sx(x + _W - 166), sy(y + 16)))
                self['activeBadge'].show()
            else:
                self['activeBadge'].hide()
        except Exception:
            pass
        self._render_focus()

    def _render_focus(self):
        if self._finished:
            return
        x, y = _CARDS[self.index]
        self['designFocus'].instance.move(ePoint(sx(x - 20), sy(y - 20)))
        self['designFocus'].show()
        for i in range(len(_CARDS)):
            if i == self.index:
                self['dim%d' % i].hide()
            else:
                self['dim%d' % i].show()

    def left(self):
        self.index = (self.index - 1) % len(self.choices)
        self._render_focus()

    def right(self):
        self.index = (self.index + 1) % len(self.choices)
        self._render_focus()

    def up(self):
        self.index = (self.index - 2) % len(self.choices)
        self._render_focus()

    def down(self):
        self.index = (self.index + 2) % len(self.choices)
        self._render_focus()

    # Older callers may still use these names.
    previous = left
    next = right

    def cancel(self):
        if not self._finished:
            self._finished = True
            self.close(None)

    def accept(self):
        if not self._finished:
            self._finished = True
            self.close(self.choices[self.index])
