# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
from .display_scale import bind_screen_resolution
"""TiviMateE2 text scaling preferences, independent of subtitle sizing.

UltraStalker-compatible steps for interface text and Movies/Series overviews.
Normal is a strictly unchanged view of the existing plugin screens.
"""
import json
import os
import re

PREF_FILE = "/etc/enigma2/tivimatee2/font_preferences.json"
MODES = ("normal", "large", "larger", "xlarge")
FACTORS = {"normal": 1.0, "large": 1.12, "larger": 1.22, "xlarge": 1.32}
OVERVIEW_FONTS = {"normal": 0, "large": 34, "larger": 42, "xlarge": 52}
_FONT = re.compile(r'(font="[^";]+;)(\d+)(")')
_OVERVIEW_WIDGET = re.compile(r'<widget\s+name="(?:desc|info_description)"[^>]*>')


def read_preferences():
    prefs = {"font_scale": "normal", "overview_font_scale": "normal"}
    if not os.path.isfile(PREF_FILE):
        return prefs
    try:
        with open(PREF_FILE, "r") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            for key in prefs:
                value = str(payload.get(key, "normal") or "normal").strip().lower()
                if value in MODES:
                    prefs[key] = value
    except (IOError, OSError, ValueError, TypeError):
        pass
    return prefs


def save_preferences(general, overview):
    if general not in MODES or overview not in MODES:
        return False
    target = os.path.dirname(PREF_FILE)
    temporary = PREF_FILE + ".tmp"
    try:
        if not os.path.isdir(target):
            os.makedirs(target)
        with open(temporary, "w") as handle:
            json.dump({"font_scale": general, "overview_font_scale": overview}, handle)
            handle.flush()
            os.fsync(handle.fileno())
        atomic_replace(temporary, PREF_FILE)
        return read_preferences() == {"font_scale": general, "overview_font_scale": overview}
    except (IOError, OSError, ValueError, TypeError):
        try:
            if os.path.exists(temporary): os.unlink(temporary)
        except (OSError, IOError):
            pass
        return False


def scale_skin_text(xml, general="normal", overview="normal", detail=False):
    """Scale visible skin text, never widget geometry or Enigma2 system fonts.

    Ultra global text increments are capped to +10px.  Overview targets only
    the actual Movies/Series description widget, not unrelated text/subtitles.
    Detail preference uses a bounded step for the synopsis; the SynopsisLabel
    existing layout code then handles Arabic line wrapping inside its box.
    """
    if not isinstance(xml, (str, unicode)): return xml
    factor = FACTORS.get(general, 1.0)
    if factor > 1.0:
        def alter_font(match):
            baseline = int(match.group(2))
            if baseline < 12: return match.group(0)
            size = max(baseline, min(baseline + 10, int(round(baseline * factor))))
            return match.group(1) + str(size) + match.group(3)
        xml = _FONT.sub(alter_font, xml)
    if detail and overview in OVERVIEW_FONTS and overview != "normal":
        preferred = OVERVIEW_FONTS[overview]
        def set_synopsis(match):
            tag = match.group(0)
            def update(font_match):
                current = int(font_match.group(2))
                if current < 12: return font_match.group(0)
                # At most 52px, with a fixed lower bound to preserve the
                # authored text box.  Per-title dynamic fitting is separate.
                return font_match.group(1) + str(max(current, min(52, preferred))) + font_match.group(3)
            return _FONT.sub(update, tag, count=1)
        xml = _OVERVIEW_WIDGET.sub(set_synopsis, xml)
    return xml


def apply_module_screens(namespace, screen_cls):
    """Refresh only TiviMate-owned class skins from their *unscaled* sources.

    This can be run on saving settings, without double enlarging fonts.
    Widgets already on screen keep their size; newly opened pages use the
    chosen setting. Other Enigma2 plugins are never modified.
    """
    prefs = read_preferences()
    count = 0
    seen = set()
    for obj in list(namespace.values()):
        if not isinstance(obj, type) or obj in seen:
            continue
        seen.add(obj)
        try:
            if not issubclass(obj, screen_cls): continue
            if not str(getattr(obj, "__module__", "")).startswith("Plugins.Extensions.TiviMateE2Py27."):
                continue
            source = obj.__dict__.get("skin")
            if not isinstance(source, (str, unicode)): continue
            # Preserve the original XML even if preferences change several
            # times without restarting the receiver.
            base = obj.__dict__.get("_tivimate_unscaled_skin")
            if not isinstance(base, (str, unicode)):
                base = source
                obj._tivimate_unscaled_skin = source
            detail = obj.__name__ in ("MovieDetailsScreen", "SeriesDetailsScreen", "MovieMoreInfoScreen")
            updated = scale_skin_text(base, prefs["font_scale"], prefs["overview_font_scale"], detail=detail)
            # Also protect screens with class-level raw FHD XML that never went
            # through scale_skin(). Already-scaled HD/WQHD roots retain their
            # explicit own resolution rather than getting scaled twice.
            updated = bind_screen_resolution(updated)
            if source != updated:
                obj.skin = updated
                count += 1
        except (AttributeError, TypeError, ValueError):
            continue
    return count


_LAST_REFRESH = {}


def refresh_loaded_screens():
    """Apply saved text sizes immediately to *next* TiviMate pages opened.

    Skipped when the preferences and loaded modules are unchanged since the
    last run: rewriting hundreds of class skins on every plugin open cost a
    noticeable delay on slow Python 2 receivers (VTi).
    """
    import sys
    try:
        stamp = os.stat(PREF_FILE).st_mtime if os.path.isfile(PREF_FILE) else 0
    except OSError:
        stamp = 0
    loaded = tuple(name for name in sorted(sys.modules) if name.startswith("Plugins.Extensions.TiviMateE2Py27.") and sys.modules.get(name) is not None)
    signature = (stamp, len(loaded))
    if _LAST_REFRESH.get("sig") == signature:
        return 0
    _LAST_REFRESH["sig"] = signature
    try:
        from Screens.Screen import Screen
    except ImportError:
        return 0
    count = 0
    for name in (
        "Plugins.Extensions.TiviMateE2Py27.ui",
        "Plugins.Extensions.TiviMateE2Py27.content_home",
        "Plugins.Extensions.TiviMateE2Py27.genre_page",
        "Plugins.Extensions.TiviMateE2Py27.tivimate_player",
        "Plugins.Extensions.TiviMateE2Py27.live_player",
        "Plugins.Extensions.TiviMateE2Py27.movies_new_layout",
        "Plugins.Extensions.TiviMateE2Py27.cinematic_catalog",
        "Plugins.Extensions.TiviMateE2Py27.view_style_picker",
        "Plugins.Extensions.TiviMateE2Py27.movies_page_picker",
        "Plugins.Extensions.TiviMateE2Py27.live_menu_screen",
    ):
        module = sys.modules.get(name)
        if module is not None:
            count += apply_module_screens(vars(module), Screen)
    return count
