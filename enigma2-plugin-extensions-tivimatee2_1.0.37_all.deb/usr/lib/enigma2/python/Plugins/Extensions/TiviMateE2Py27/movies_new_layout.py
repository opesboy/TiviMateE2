# -*- coding: utf-8 -*-
import io
"""Selectable professional Movies layout.

Top: full-size GENRE-backed cinematic movie posters.
Bottom: one real server package rail in the original portrait+title+rating card format.
This module does not change either underlying server feed or normal Movies skin.
"""
import re
import os
import xml.etree.ElementTree as ET
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from Components.Pixmap import Pixmap
from enigma import ePoint, eSize
from .content_home import FastMoviesContentScreen, FAST_MOVIES_CONTENT_HOME
from .display_scale import sx, sy
from .shared_genre_posters import request_genre_poster
from .py27_compat import text_type, gui_text
from .country_flags import show_country_flag
from .resolution_badge import information_badge_skin
from .genre_package_badges import resolve_package_badge
from .metadata_display import (merge_metadata, provider_cache_key,
                               contains_arabic_text)
from .tmdb_client import TMDbClient
from .cache_manager import get_cache_dir
from .i18n import get_language
from .content_home import _submit_content_bg, _hero_preview_summary
import hashlib
import json

_ROOT = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/'
_VISIBLE = 6
_PAGE_SIZE = 12
_POSTER_X = (80, 388, 696, 1004, 1312, 1620)
_POSTER_Y, _POSTER_W, _POSTER_H = 408, 232, 348
# Approved lower rail: six vertical full-cover movie posters, scaled down
# slightly from 180x270 to 165x248, preserving the 2:3 original aspect.
# Match the category tile to the six lower posters without affecting the top rail.
_PACKAGE_VISIBLE = 6
_MOVIE_X = (312, 579, 846, 1113, 1380, 1647)
_MOVIE_Y, _MOVIE_W, _MOVIE_H = 778, 165, 248
_PACKAGE_TILE_X, _PACKAGE_TILE_Y = 80, _MOVIE_Y
_PACKAGE_TILE_W, _PACKAGE_TILE_H = _MOVIE_W, _MOVIE_H
_CARD_POSTER_W = _MOVIE_W
_CARD_POSTER_H = _MOVIE_H
_CARD_3D_X = 0
_CARD_3D_W = _MOVIE_W



def _new_skin():
    """Remove every old card/text overlay, retaining widget names for base compatibility.

    The old screen contains ~100 widgets and ePixmaps at fixed positions.
    Merely adding another image over them leaves logos/labels/frames visible.
    Park old widget instances off-screen (so base still finds them) and build
    a clean, z-ordered 3-zone screen with a full 16:9 hero and unclipped posters.
    """
    root = ET.fromstring(FAST_MOVIES_CONTENT_HOME.replace(
        'name="FastMoviesContentScreen"', 'name="NewMoviesContentScreen"', 1))
    safe_widgets = set(['hero','logoImage','logoTitle','heroMeta','heroDesc',
                        'heroPlay','heroInfo','trailerPreview','topSelector',
                        'backdropTrailerCount','backdropTrailerCaption',
                        'backdropTrailerToggleHint','moviesSortIndicator',
                        'footerServerName'])
    safe_widgets.update('top%d' % i for i in range(11))
    # Existing coordinates are already scale_skin()-scaled at definition time.
    def xy(node, x,y,w,h,layer=None):
        node.set('position','%d,%d' % (sx(x),sy(y)))
        node.set('size','%d,%d' % (sx(w),sy(h)))
        if layer is not None: node.set('zPosition',str(layer))
    def panel(path,x,y,w,h,z,scale=False):
        attrs={'position':'%d,%d' % (sx(x),sy(y)),
               'size':'%d,%d' % (sx(w),sy(h)),
               'pixmap':_ROOT+path,'alphatest':'blend','zPosition':str(z)}
        if scale: attrs['scale']='1'
        ET.SubElement(root,'ePixmap',attrs)
    def label(text,x,y,w,h,font='Regular;23',color='#FFFFFF',z=20):
        ET.SubElement(root,'eLabel',{
           'text':text,'position':'%d,%d' % (sx(x),sy(y)),
           'size':'%d,%d' % (sx(w),sy(h)),'font':font,
           'foregroundColor':color,'transparent':'1',
           'backgroundColor':'#00000000','zPosition':str(z)})
    def widget(name,x,y,w,h,z,**kw):
        props={'name':name, 'position':'%d,%d' % (sx(x),sy(y)),
               'size':'%d,%d' % (sx(w),sy(h)), 'zPosition':str(z)}
        props.update({k:str(v) for k,v in kw.items()})
        ET.SubElement(root,'widget',props)
    for node in list(root):
        tag = node.tag
        name = node.get('name','')
        if tag == 'widget':
            if name not in safe_widgets:
                # Do not park a visible legacy widget at negative coordinates.
                # Pure2 can clamp those to (0,0) and render old/new on top.
                # Keep the name for base-class callbacks, but place its tiny
                # footprint just outside the active desktop.
                node.set('position','%d,%d' % (sx(1920),sy(1080)))
                node.set('size','1,1')
                node.set('transparent','1')
                continue
            if name.startswith('top') and (name[3:].isdigit() or name=='topSelector'):
                node.set('zPosition','30')
                continue
            if name == 'footerServerName':
                xy(node,523,1052,140,22,38)
                node.set('font','Regular;15')
                node.set('halign','left')
                node.set('valign','center')
                node.set('transparent','1')
                continue
            if name == 'moviesSortIndicator':
                # New layout only: show the CURRENT sorting mode inside the
                # existing bottom SORT button, never as a top-left overlay.
                # Pure2 must not receive off-screen/negative widget coords.
                xy(node, 746, 1051, 170, 23, 38)
                node.set('transparent', '1')
                node.set('backgroundColor', '#00000000')
                node.set('foregroundColor', '#E8EDF3')
                node.set('font', 'Regular;17')
                node.set('halign', 'left')
                node.set('valign', 'center')
                node.attrib.pop('borderWidth', None)  # not supported on VTi
                continue
            if name=='hero':
                xy(node,0,0,1920,1080,1)  # full 16:9 movie backdrop, extends beneath all rails
                node.set('scale','1')
                continue
            if name=='logoImage':
                xy(node,275,106,480,72,24)  # Compact clearlogo, retaining transparent-pixel alignment
                continue
            if name=='logoTitle':
                xy(node,18,110,820,70,23)
                node.set('font','Regular;52')
                continue
            if name=='heroMeta':
                xy(node,78,184,860,35,23)
                node.set('font','Regular;25')
                continue
            if name=='heroDesc':
                xy(node,78,225,925,78,23)
                node.set('font','Regular;25')
                continue
            if name=='heroPlay':
                xy(node,79,310,235,53,26)
                node.set('foregroundColor','#0B1D34')
                node.set('font','Bold;27')
                node.set('halign','center')
                continue
            if name=='heroInfo':
                xy(node,346,310,238,53,26)
                node.set('font','Regular;25')
                node.set('halign','center')
                continue
            if name=='trailerPreview':
                # Below the top menu (ends at Y=87); ends at Y=394, before Latest frames at Y=404.
                xy(node,1042,100,796,294,22)
                continue
            if name in ('backdropTrailerCount','backdropTrailerCaption'):
                xy(node,1630,90 if name.endswith('Count') else 211,185,90 if name.endswith('Count') else 30,28)
                continue
            if name=='backdropTrailerToggleHint':
                xy(node,1810,1050,72,26,38)
                node.set('font','Regular;17')
                node.set('halign','center')
                continue
        elif tag=='ePixmap':
            pix=node.get('pixmap','')
            if ('/skins/navicons/' in pix or 'vod_nav_wave85_only.png' in pix or
                    pix.endswith('/skins/movies/movies_hero_partial_gradient_85.png') or
                    pix.endswith('/skins/common/poster_actions_toolbar_trailer_newsort.png')):
                # The dynamic-label footer already has no baked-in sort value.
                # Keep the footer and its existing buttons unmodified.
                pass
            else:
                # Static old graphics have no runtime owners; remove them
                # instead of moving them offscreen with negative coordinates.
                # On Pure2 that can make both visual layouts appear at once.
                root.remove(node)
        elif tag=='eLabel':
            # Keep only solid underlying background. All old static hints are hidden.
            if node.get('position') in ('0,0','%d,%d'%(sx(0),sy(0))) and node.get('size') in ('1920,1080','%d,%d'%(sx(1920),sy(1080))):
                node.set('zPosition','0')
            else:
                root.remove(node)
    # The inherited original Movies partial gradient was retained above;
    # do not add either of the newer extra opaque cinematic masks.
    panel('movies_pro_button_play.png',72,304,250,65,24)
    panel('movies_pro_button_info.png',340,304,250,65,24)
    # The approved Latest Movies logo replaces the static label. A widget is
    # used so the image follows the CURRENT app language even after switching
    # languages without a full Enigma2/Python restart.
    widget('newLatestTitleLogo',72,369,230,38,21,alphatest='blend',scale='1')
    widget('newLatestSeriesTitle',72,365,430,46,22,font='Bold;31',
           foregroundColor='#FFFFFF',backgroundColor='#00000000',transparent='1')
    widget('newPosterCounter',1450,369,336,33,21,font='Regular;20',
           foregroundColor='#9DBBD2',backgroundColor='#00000000',transparent='1',halign='right')
    for slot,x in enumerate(_POSTER_X):
        widget('newPoster%d'%slot,x,_POSTER_Y,_POSTER_W,_POSTER_H,18,
               pixmap=_ROOT+'movies_new_portrait_placeholder.jpg',alphatest='blend',scale='1')
        panel('movies_cinema_poster_frame.png',x-4,_POSTER_Y-4,
              _POSTER_W+8,_POSTER_H+8,19)
        widget('newPosterFlag%d'%slot,x+9,_POSTER_Y+306,30,30,23,
               alphatest='blend',scale='1')
        widget('newPosterRating%d'%slot,x+48,_POSTER_Y+307,110,29,23,
               font='Regular;19',foregroundColor='#F8D37C',transparent='1')
        widget('newPosterRank%d'%slot,x+8,_POSTER_Y+8,48,28,23,
               font='Bold;19',foregroundColor='#FFFFFF',transparent='1')
    # Restore the original blue category tile with its yellow side stripe,
    # removing the recently added silver cinematic frame. The category
    # retains the same geometry as the six lower movie posters.
    panel('movies_cinema_category_single.png',_PACKAGE_TILE_X,_PACKAGE_TILE_Y,
          _PACKAGE_TILE_W,_PACKAGE_TILE_H,19,scale=True)
    widget('newPackageName',_PACKAGE_TILE_X+8,_PACKAGE_TILE_Y+76,
           _PACKAGE_TILE_W-16,100,24,font='Bold;22',halign='center',
           valign='center',foregroundColor='#FFFFFF',transparent='1')
    # GENRE's original compact badge is centered without upscaling.
    # Its PNG has generous transparent side margins.
    _badge_w, _badge_h = 204, 34
    widget('newPackageLogo',_PACKAGE_TILE_X + (_PACKAGE_TILE_W-_badge_w)//2,
           _PACKAGE_TILE_Y + (_PACKAGE_TILE_H-_badge_h)//2,
           _badge_w,_badge_h,25,alphatest='blend',scale='1')
    # Only the NEW Movies layout shows the category's existing year badge.
    # Keep it inside the bottom of the same original blue tile; no new files.
    widget('newPackageYear',_PACKAGE_TILE_X+(_PACKAGE_TILE_W-92)//2,
           _PACKAGE_TILE_Y+_PACKAGE_TILE_H-47,92,32,26,
           alphatest='blend',scale='1')
    for slot,x in enumerate(_MOVIE_X):
        # Full-height uncropped original GENRE movie cover. Unlike the broken
        # previous revision there are no adjacent title/rating card columns.
        widget('backdropMovie%d'%slot,x,_MOVIE_Y,
               _CARD_POSTER_W,_CARD_POSTER_H,18,
               pixmap=_ROOT+'movies_new_portrait_placeholder.jpg',alphatest='blend',scale='1')
        panel('movies_cinema_poster_frame.png',x-4,_MOVIE_Y-4,
              _MOVIE_W+8,_MOVIE_H+8,19,scale=True)
        # Keep the existing flag and rating overlay, but no movie title
        # appears on the lower posters.
        panel('movies_gallery_lower_fade.png',x,_MOVIE_Y+175,_MOVIE_W,73,20,scale=True)
        widget('firstMovieName%d'%slot,x+8,_MOVIE_Y+175,_MOVIE_W-16,36,23,
               font='Bold;18',foregroundColor='#FFFFFF',transparent='1',noWrap='1')
        widget('newMovieFlag%d'%slot,x+9,_MOVIE_Y+210,30,30,24,
               alphatest='blend',scale='1')
        widget('firstMovieRate%d'%slot,x+46,_MOVIE_Y+210,_MOVIE_W-54,28,24,
               font='Bold;20',foregroundColor='#F7D47A',transparent='1')
    # The approved seven-key toolbar is inherited from the shared skin above.
    # Do not create another copy of the old four-key legend here.
    widget('newPosterFocus',_POSTER_X[0]-5,_POSTER_Y-5,
           _POSTER_W+10,_POSTER_H+10,27,
           pixmap=_ROOT+'movies_cinema_poster_focus_portrait.png',alphatest='blend')
    widget('newMovieFocus',_MOVIE_X[0]-5,_MOVIE_Y-5,_MOVIE_W+10,_MOVIE_H+10,27,
           pixmap=_ROOT+'movies_cinema_poster_focus_portrait.png',alphatest='blend',scale='1')
    # The shared Movies class originally attaches its coloured metadata at y=226.
    # On this compact new page that was ON TOP of the synopsis: preinstall the
    # same original information badges at y=185, so the shared helper does not
    # add a second overlapping row. Leave the legacy Movies class untouched.
    skin = ET.tostring(root,encoding='utf-8').decode('utf-8')
    skin, found = information_badge_skin(skin, 'heroMeta', position=(330,185))
    if not found: raise ValueError('New Movies metadata badges missing')
    return skin



# r146: logo visible-width results survive screen changes and restarts, so a
# logo is measured once (the pure-Python PNG scan is slow without Pillow).
_LOGO_BOUNDS_DISK = {"data": None}


def _logo_bounds_store():
    if _LOGO_BOUNDS_DISK["data"] is None:
        data = {}
        try:
            import json
            from .cache_manager import get_cache_dir
            path = os.path.join(get_cache_dir("metadata"), "logo_bounds_v1.json")
            _LOGO_BOUNDS_DISK["path"] = path
            if os.path.isfile(path):
                with open(path, "rb") as handle:
                    loaded = json.loads(handle.read().decode("utf-8"))
                if isinstance(loaded, dict):
                    data = loaded
        except Exception:
            data = {}
        _LOGO_BOUNDS_DISK["data"] = data
    return _LOGO_BOUNDS_DISK["data"]


def _logo_bounds_key(path):
    try:
        st = os.stat(path)
        return "%s|%d|%d" % (os.path.basename(path), st.st_size, int(st.st_mtime))
    except Exception:
        return ""


def _logo_bounds_save(key, bounds):
    data = _logo_bounds_store()
    data[key] = list(bounds)
    if len(data) > 1500:
        for old in list(data)[:500]:
            data.pop(old, None)
    path = _LOGO_BOUNDS_DISK.get("path")
    if not path:
        return
    def write():
        try:
            import json
            temp = path + ".tmp"
            with open(temp, "wb") as handle:
                handle.write(json.dumps(dict(data)).encode("utf-8"))
            os.rename(temp, path)
        except Exception:
            pass
    try:
        import threading
        worker = threading.Thread(target=write, name="TiviLogoBounds")
        worker.daemon = True
        worker.start()
    except Exception:
        pass


class NewMoviesContentScreen(FastMoviesContentScreen):
    skin = _new_skin()
    BACKDROP_ITEM_LIMIT = 12

    def _positionLatestCategoryName(self):
        # The old Movies page dynamically moves its category caption to y=772.
        # The new Movies page already shows that same category in newPackageName
        # inside the blue tile. Keep the inherited duplicate off-screen.
        return

    def __init__(self,session,source,kind='vod',initialMode=None,actorRows=None,actorName=''):
        self._newMoviesGallery = True
        self._galleryWidgetsReady = False
        # Cached Backdrops may be present before Enigma2 has created the
        # native newPoster pixmaps. A request completed in that window gets
        # discarded by ePicLoad and the identity guard prevents repainting.
        self._upperPosterLayoutReady = False
        self._newPosterIdentity = {}
        self._newPosterBackdropStarted = {}
        self._newMovieIdentity = {}
        self._posterFlagIdentity = {}
        self._movieFlagIdentity = {}
        self._clearLogoBoundsByItem = {}
        self._clearLogoBoundsByFile = {}
        self._arabicPreviewBundles = {}
        self._arabicRequested = set()
        self._cachedProviderMetadata = {}
        self._actualClearLogoBounds = (275,106,480,72)
        FastMoviesContentScreen.__init__(self,session,source,kind,initialMode,actorRows,actorName)
        for i in range(_VISIBLE):
            self['newPoster%d'%i]=Pixmap()
            self['newPosterFlag%d'%i]=Pixmap()
            self['newPosterFlag%d'%i].hide()
            self['newPosterRating%d'%i]=Label('')
            self['newPosterRank%d'%i]=Label('')
            if i < _PACKAGE_VISIBLE:
                self['backdropMovie%d'%i]=Pixmap()
                self['newMovieFlag%d'%i]=Pixmap()
                self['newMovieFlag%d'%i].hide()
                self['firstMovieName%d'%i]=Label('')
                self['firstMovieRate%d'%i]=Label('')
        self['newPosterFocus']=Pixmap()
        self['newMovieFocus']=Pixmap()
        self['newPosterCounter']=Label('')
        self['newLatestTitleLogo']=Pixmap()
        self['newLatestSeriesTitle']=Label('')
        self['newPackageName']=Label('')
        self['newPackageLogo']=Pixmap()
        self['newPackageLogo'].hide()
        self._newPackageLogoCurrent=''
        self['newPackageYear']=Pixmap()
        self['newPackageYear'].hide()
        self._newPackageYearCurrent=''
        self._galleryWidgetsReady=True
        self.renderBackdrops()
        self.renderLatest()
        self.updateFocus()
        self._paintOpeningHero()
        self.onLayoutFinish.append(self._refreshVisiblePosterFlags)
        # Delay the upper rail's image requests until native Pixmap.instance
        # exists; the lower rail normally arrives after layout from serverReady.
        self.onLayoutFinish.append(self._renderUpperPostersAfterLayout)
        self.onShow.append(self._renderUpperPostersAfterLayout)
        self.onLayoutFinish.append(self._refreshVisibleMovieFlags)
        self.onLayoutFinish.append(self._updatePackageName)
        self.onLayoutFinish.append(self._updateLatestTitleLogo)
        self.onShow.append(self._updateLatestTitleLogo)
        self.onLayoutFinish.append(self._refreshNewSortIndicator)
        # A single real provider category, never a duplicate neighbour fetch.
        if self.categoriesLoaded and self.categoriesList and self.categoryIndex < 0:
            self._changeCategory(1)

    def _refreshNewSortIndicator(self):
        """Present the active sort choice in the footer; never on the hero."""
        if self.kind == 'vod':
            mode = getattr(self, '_moviesSortChoice', 'date')
            label = {'date': 'Date', 'atoz': 'A-Z',
                     'ztoa': 'Z-A', 'default': 'Original'}.get(mode, 'Date')
        else:
            mode = getattr(self, 'sortMode', 'default')
            label = {'default': 'Latest', 'newest': 'Newest',
                     'name': 'Name', 'year': 'Year',
                     'rating': 'Rating'}.get(mode, 'Latest')
        try:
            self['moviesSortIndicator'].setText(label)
        except Exception:
            pass

    def toggleSort(self):
        # The base class legitimately clears its hidden sort label after each
        # click. Restore it here only for this new poster layout.
        result = FastMoviesContentScreen.toggleSort(self)
        self._refreshNewSortIndicator()
        return result

    def _updateLatestTitleLogo(self):
        """Use matching gold AR/EN artwork for both Latest Movies and TV Shows."""
        try:
            logo = self['newLatestTitleLogo']
            series_title = self['newLatestSeriesTitle']
            lang = 'ar' if get_language() == 'ar' else 'en'
            if self.kind == 'series':
                filename = 'series_latest_title_%s.png' % lang
            else:
                filename = 'movies_latest_title_%s.png' % lang
            path = os.path.join(_ROOT, filename)
            if os.path.isfile(path) and getattr(logo, 'instance', None):
                logo.instance.setPixmapFromFile(path)
                logo.show()
                series_title.setText('')
                series_title.hide()
            else:
                logo.hide()
                if self.kind == 'series':
                    series_title.setText('أحدث المسلسلات' if lang == 'ar' else 'LATEST TV SHOWS')
                    series_title.show()
                else:
                    series_title.setText('')
                    series_title.hide()
        except Exception:
            pass

    def _setMovieLogoGeometry(self):
        """Centre the VISIBLE logo pixels over the synopsis (VTi clipped the old left offset).

        Ultra's identity-logo cache centres small lettering on a transparent
        canvas. Merely setting a left widget position leaves Arabic lettering
        visibly in the middle. Account for the transparent alpha border, not
        just the holder's x coordinate. No new cached PNGs are generated.
        """
        try:
            target = self['logoImage'].instance
            if target is not None:
                x, y, w, h = self._actualClearLogoBounds
                target.move(ePoint(sx(x), sy(y)))
                target.resize(eSize(sx(w), sy(h)))
        except Exception:
            pass

    @staticmethod
    def _pngAlphaLeft(path):
        """Find visible alpha's left edge in normal 8-bit PNG with stdlib only.

        This also works on lean Enigma2 receivers without Pillow. Decode just
        the alpha bytes of each filtered scanline, not the whole RGB picture.
        All inputs are existing local identity logos (normally 620x96).
        """
        try:
            import struct
            import zlib
            with open(path, 'rb') as handle:
                raw = handle.read(4000000)
            if raw[:8] != b'\x89PNG\r\n\x1a\n':
                return 0
            offset, parts = 8, []
            width = height = depth = color = interlace = 0
            while offset + 12 <= len(raw):
                size = struct.unpack('>I', raw[offset:offset+4])[0]
                if size > 3500000 or offset + 12 + size > len(raw):
                    break
                name = raw[offset+4:offset+8]
                payload = raw[offset+8:offset+8+size]
                offset += 12 + size
                if name == b'IHDR':
                    width,height,depth,color,_,_,interlace = struct.unpack('>IIBBBBB', payload)
                elif name == b'IDAT':
                    parts.append(payload)
                elif name == b'IEND':
                    break
            if (depth != 8 or color not in (4,6) or interlace or
                    not 0 < width <= 1200 or not 0 < height <= 300 or not parts):
                return 0
            bpp = 4 if color == 6 else 2
            stride = width * bpp
            unpacked = zlib.decompress(b''.join(parts))
            if len(unpacked) != (stride+1)*height:
                return 0
            prev = [0]*width
            pos, leftmost = 0, width
            for _y in range(height):
                if leftmost == 0:
                    break
                filter_type = unpacked[pos]
                if not isinstance(filter_type, int):
                    filter_type = ord(filter_type)
                pos += 1
                if filter_type not in (0,1,2,3,4):
                    return 0
                cur = [0]*width
                # Only columns left of the current edge matter, and every
                # later row needs only those columns of this row.
                for x in range(leftmost):
                    value = unpacked[pos+x*bpp+bpp-1]
                    if not isinstance(value, int):
                        value = ord(value)
                    a = cur[x-1] if x else 0
                    b = prev[x]
                    c = prev[x-1] if x else 0
                    if filter_type == 1: value += a
                    elif filter_type == 2: value += b
                    elif filter_type == 3: value += (a+b)//2
                    elif filter_type == 4:
                        pred = a+b-c
                        da,db,dc = abs(pred-a),abs(pred-b),abs(pred-c)
                        value += a if da<=db and da<=dc else (b if db<=dc else c)
                    value &= 255
                    cur[x] = value
                    if value >= 24 and x < leftmost:
                        leftmost = x
                prev = cur
                pos += stride
            return leftmost if leftmost < width else 0
        except Exception:
            return 0

    def _leftLogoBounds(self, path):
        if path in self._clearLogoBoundsByFile:
            return self._clearLogoBoundsByFile[path]
        disk_key = _logo_bounds_key(path)
        saved = _logo_bounds_store().get(disk_key) if disk_key else None
        if isinstance(saved, list) and len(saved) == 4:
            bounds = tuple(int(v) for v in saved)
            self._clearLogoBoundsByFile[path] = bounds
            return bounds
        width, height, left_pad = 640, 100, 0
        right_edge = None
        try:
            import struct
            with open(path, 'rb') as fh:
                header = fh.read(24)
            if header[:8] == b'\x89PNG\r\n\x1a\n' and header[12:16] == b'IHDR':
                iw, ih = struct.unpack('>II', header[16:24])
                if 0 < iw < 20000 and 0 < ih < 20000:
                    width = max(1, min(690, int(round(iw * 100.0 / ih))))
                    height = max(1, min(100, int(round(width * float(ih) / iw))))
                    try:
                        from PIL import Image
                        with Image.open(path) as im:
                            if 'A' in im.getbands():
                                # Ignore near-transparent antialias/shadow pixels.
                                alpha = im.getchannel('A').point(lambda value: 255 if value >= 24 else 0)
                                box = alpha.getbbox()
                                if box is not None:
                                    left_pad = int(round(box[0] * float(width) / iw))
                                    right_edge = int(round(box[2] * float(width) / iw))
                    except Exception:
                        left_pad = int(round(self._pngAlphaLeft(path) * float(width) / iw))
                        right_edge = width - left_pad
        except Exception:
            pass
        if right_edge is None or right_edge <= left_pad:
            right_edge = width
        # Centred over the info pills (x 330..700): the VISIBLE
        # lettering is centred, not the transparent canvas.
        bounds = (515 - (left_pad + right_edge) // 2, 83 + (100 - height) // 2, width, height)
        if len(self._clearLogoBoundsByFile) > 64:
            self._clearLogoBoundsByFile.clear()
        self._clearLogoBoundsByFile[path] = bounds
        if disk_key:
            _logo_bounds_save(disk_key, bounds)
        return bounds

    def _arabicUi(self):
        try:
            return str(get_language() or '').lower().split('-')[0].split('_')[0] == 'ar'
        except Exception:
            return False

    def _cachedProviderForCurrent(self, item):
        """Read the EXACT Movie Details provider-info file, without a network call."""
        if not isinstance(item, dict):
            return {}
        mid = str(item.get('stream_id') or item.get('vod_id') or '').strip()
        if not mid or str((self.source or {}).get('type') or '').lower() not in ('xtream','stalker'):
            return {}
        key = provider_cache_key('vod', mid, self.source)
        if key in self._cachedProviderMetadata:
            return self._cachedProviderMetadata[key]
        payload = {}
        try:
            path = os.path.join(get_cache_dir('metadata'),
                                'provider_info_' + hashlib.md5(key.encode('utf-8')).hexdigest() + '.json')
            if os.path.isfile(path) and os.path.getsize(path) > 2:
                with io.open(path, 'r', encoding='utf-8') as handle:
                    read = json.load(handle)
                if isinstance(read, dict):
                    payload = read
        except Exception:
            pass
        if len(self._cachedProviderMetadata) >= 48:
            self._cachedProviderMetadata.clear()
        self._cachedProviderMetadata[key] = payload
        return payload

    def _applyArabicText(self, data, request_id, key):
        if (not self._arabicUi() or request_id != self._previewRequestId or
                self._previewCacheKey(self.current()) != key):
            return
        current = self.current() or {}
        info = merge_metadata(current, cached=self._cachedProviderForCurrent(current),
                              tmdb=data or {}, language='ar-AE', kind=self.kind)
        if info['title']:
            from .display_titles import visible_title
            self['logoTitle'].setText(gui_text(visible_title(info['title'], 34)))
        if info['description']:
            self['heroDesc'].setText(gui_text(_hero_preview_summary(info['description'])))
        parts = [info['year']]
        if self.kind != 'series' and info['rating']:
            parts.append(u'★ ' + text_type(info['rating'])[:4])
        parts.append(info['genre'])
        self['heroMeta'].setText(gui_text(u'   •   '.join(text_type(x) for x in parts if x)))

    def _receiveArabicDetails(self, request_id, key, bundle):
        if request_id != self._previewRequestId or self._previewCacheKey(self.current()) != key:
            return
        if not isinstance(bundle, dict) or not bundle.get('id'):
            return
        if len(self._arabicPreviewBundles) >= 36:
            self._arabicPreviewBundles.clear()
        self._arabicPreviewBundles[key] = bundle
        self._applyArabicText(bundle, request_id, key)

    def _applyPreviewMetadata(self, data, request_id, from_cache=False):
        # Leave original provider-first/artwork-cache/tmdb-callback logic intact.
        result = FastMoviesContentScreen._applyPreviewMetadata(self, data, request_id, from_cache)
        if request_id != self._previewRequestId or not self._arabicUi():
            return result
        key = self._previewCacheKey(self.current())
        if key is None:
            return result
        bundle = self._arabicPreviewBundles.get(key)
        if not bundle and isinstance(data, dict) and contains_arabic_text(data.get('overview') or data.get('description')):
            bundle = data
            self._arabicPreviewBundles[key] = bundle
        self._applyArabicText(bundle or data or {}, request_id, key)
        if bundle or key in self._arabicRequested:
            return result
        try:
            ident = (data or {}).get('id') or (data or {}).get('tmdb_id')
            ident = str(int(str(ident)))
            if int(ident) <= 0:
                return result
        except (ValueError, TypeError, AttributeError):
            return result
        self._arabicRequested.add(key)
        def fetch():
            try:
                # Locale-separated 24h TMDb details cache, same API/cache as
                # Movie Details. One lookup only per selected item, off GUI.
                ar = TMDbClient(language='ar-AE').details_bundle(ident, self.kind)
                if ar:
                    self._queueGui(self._receiveArabicDetails, request_id, key, ar)
            except Exception:
                pass
        _submit_content_bg(fetch, key=('new-movies-arabic', id(self)))
        return result

    def preview(self):
        # Per-item bounds also apply when the native logo pixmap is restored
        # directly from the shared decoded-pixmap cache.
        key = self._previewCacheKey(self.current())
        self._actualClearLogoBounds = self._clearLogoBoundsByItem.get(key, (275,106,480,72))
        self._setMovieLogoGeometry()
        result = FastMoviesContentScreen.preview(self)
        if self._arabicUi() and key in self._arabicPreviewBundles:
            self._applyArabicText(self._arabicPreviewBundles[key], self._previewRequestId, key)
        return result

    def loadImage(self, url, widget, width, height, fallback_item=None):
        if widget == 'hero':
            width, height = 1920, 1080
        elif widget == 'logoImage':
            width, height = 640, 100
        return FastMoviesContentScreen.loadImage(self,url,widget,width,height,fallback_item)

    def decode(self, path, widget, width, height):
        if widget == 'hero':
            width, height = 1920, 1080
        elif widget == 'logoImage':
            identity = self._genreHeroIdentity(widget, self.current())
            if (identity is not None and
                    getattr(self, '_genreHeroDecoded', {}).get(widget) == identity):
                return
            self._actualClearLogoBounds = self._leftLogoBounds(path)
            key = self._previewCacheKey(self.current())
            if key is not None:
                if len(self._clearLogoBoundsByItem) > 64:
                    self._clearLogoBoundsByItem.clear()
                self._clearLogoBoundsByItem[key] = self._actualClearLogoBounds
            self._setMovieLogoGeometry()
            width, height = self._actualClearLogoBounds[2:]
        return FastMoviesContentScreen.decode(self,path,widget,width,height)

    def _posterRows(self):
        # ONLY the original GENRE Latest package-backdrop rail, capped at 12.
        # The previous design wrongly used self.latest (all movies) first.
        return (self.backdrops or [])[:_PAGE_SIZE]

    def _movieRows(self):
        # The already-selected server package, with original sort/cache logic.
        return self.latest or []

    def current(self):
        if self.focus in ('top','backdrops'):
            rows=self._posterRows()
            idx=self.backdropStart+self.backdropIndex
            return rows[idx] if 0<=idx<len(rows) else None
        if self.focus=='latest':
            rows=self._movieRows()
            idx=self.latestStart+self.latestIndex
            return rows[idx] if 0<=idx<len(rows) else None
        return FastMoviesContentScreen.current(self)

    def serverReady(self,latest,allItems=None,categories=None,landingCategory=None,generation=None):
        previous_id=''
        if 0 <= self.categoryIndex < len(self.categoriesList):
            previous_id=str((self.categoriesList[self.categoryIndex] or {}).get('category_id') or '')
        out=FastMoviesContentScreen.serverReady(self,latest,allItems,categories,landingCategory,generation)
        if self._galleryWidgetsReady and (generation is None or generation==self.contentGeneration):
            self.renderBackdrops();self.renderLatest();self._paintOpeningHero()
            if self.categoriesList:
                chosen=0
                for idx,cat in enumerate(self.categoriesList):
                    if previous_id and str((cat or {}).get('category_id') or '')==previous_id:
                        chosen=idx
                        break
                self.categoryIndex=chosen-1
                self._changeCategory(1)
        return out

    def backdropsReady(self,backdrops,generation=None,lower_items=None):
        out=FastMoviesContentScreen.backdropsReady(self,backdrops,generation,lower_items)
        if self._galleryWidgetsReady and (generation is None or generation==self.contentGeneration):
            self.renderBackdrops();self.renderLatest();self._paintOpeningHero()
        return out

    def _paintOpeningHero(self):
        if self._contentScreenDisposed or self.focus!='top' or not self._posterRows():return
        return FastMoviesContentScreen._paintOpeningHero(self)

    def _art_token(self,item,index):
        # In DreamOS/Python 2 a unicode Arabic title must not raise while
        # rendering the Latest row; a failed token used to abort all cards.
        return (self.contentGeneration, index,
                text_type((item or {}).get('stream_id') or
                          (item or {}).get('series_id') or
                          (item or {}).get('id') or
                          (item or {}).get('name') or u''), id(item))

    def _newPosterCountryInfo(self, item):
        """Country for this exact media item, not a guessed provider/language flag.

        TMDb movie and TV IDs occupy separate namespaces. For an identified
        title, only an already verified country or a fresh lookup in the
        correct namespace is authoritative; provider `country` may describe
        a stream/server and can be wrong even when Details is correct.
        """
        info = item.get('info') if isinstance(item.get('info'), dict) else {}
        tid = str(item.get('tmdb_id') or item.get('_locked_tmdb_id') or
                  item.get('_tmdb_id') or item.get('tmdb') or item.get('tmdbid') or
                  info.get('tmdb_id') or info.get('tmdb') or '').strip()
        if not tid.isdigit() or int(tid) <= 0:
            tid = ''
        kind = 'tv' if self.kind == 'series' else 'movie'
        verified = str(item.get('_new_poster_verified_country') or '').strip().upper()
        if not re.match(r'^[A-Z]{2}$', verified) or verified in ('XX', 'GL'):
            verified = ''
        if verified:
            country = verified
        elif tid:
            # Never prefer an unverified portal code over the TMDb ID. The
            # existing two-worker flag resolver fetches this kind/ID's country
            # asynchronously, with no change to poster/backdrop queues.
            country = ''
        else:
            # With no resolved TMDb ID, only explicit production/origin fields
            # are acceptable. Bare country/language fields are not reliable.
            from .country_flags import country_code
            explicit = {}
            for field in ('origin_country', 'production_countries'):
                value = item.get(field) or info.get(field)
                if value:
                    explicit[field] = value
            country = country_code(explicit, kind)
        return kind, tid, country

    def _rememberNewPosterCountry(self, item, code, slot, state, poster=True):
        identities = self._posterFlagIdentity if poster else self._movieFlagIdentity
        if self._contentScreenDisposed or identities.get(slot) != state:
            return
        code = str(code or '').strip().upper()
        if not re.match(r'^[A-Z]{2}$', code) or code in ('XX', 'GL'):
            return
        # Callback is supplied only when the ID is resolved by TMDb. Preserve
        # this verified result on the row for subsequent page/selection renders.
        item['_new_poster_verified_country'] = code
        self._rememberBackdropFlagCountry(item, code)

    def _renderUpperPostersAfterLayout(self):
        """Paint once native widgets exist, including warm-cache startup.

        This also safely retries slots that had no native instance during a
        previous redraw. Successful slots keep their per-item identity and
        will not enqueue duplicate poster downloads on onShow.
        """
        if getattr(self, '_contentScreenDisposed', False):
            return
        self._upperPosterLayoutReady = True
        self.renderBackdrops()

    def _refreshVisiblePosterFlags(self):
        # Reattempt cached flags only after Pixmap.instance exists. On some
        # Enigma images widgets are registered before native layout creation.
        for slot in range(_VISIBLE):
            idx = self.backdropStart + slot
            rows = self._posterRows()
            if idx < len(rows):
                self._syncPosterFlag(slot, rows[idx], self._art_token(rows[idx], idx))

    def _syncPosterFlag(self, slot, item, token):
        if not 0 <= slot < _VISIBLE:
            return
        widget = self['newPosterFlag%d' % slot]
        if not getattr(widget, 'instance', None):
            return
        kind, tid, country = self._newPosterCountryInfo(item)
        state = (token, kind, country, tid)
        if self._posterFlagIdentity.get(slot) == state:
            return
        self._posterFlagIdentity[slot] = state
        data = {'origin_country': [country]} if country else {}
        def still_current(s=slot, t=state):
            return (not self._contentScreenDisposed and
                    self._posterFlagIdentity.get(s) == t)
        show_country_flag(widget, data, kind, tid,
                          visible_when=still_current,
                          gui_dispatch=self._queueGui,
                          on_resolved=(lambda code, row=item, s=slot, st=state:
                                       self._rememberNewPosterCountry(row, code, s, st))
                          if tid and not country else None)

    def _refreshVisibleMovieFlags(self):
        for slot in range(_PACKAGE_VISIBLE):
            idx = self.latestStart + slot
            rows = self._movieRows()
            if idx < len(rows):
                self._syncMovieFlag(slot, rows[idx], self._art_token(rows[idx], idx))

    def _syncMovieFlag(self, slot, item, token):
        if not 0 <= slot < _PACKAGE_VISIBLE:
            return
        widget = self['newMovieFlag%d' % slot]
        if not getattr(widget, 'instance', None):
            return
        kind, tid, country = self._newPosterCountryInfo(item)
        state = (token, kind, country, tid)
        if self._movieFlagIdentity.get(slot) == state:
            return
        self._movieFlagIdentity[slot] = state
        data = {'origin_country': [country]} if country else {}
        def still_current(s=slot, t=state):
            return (not self._contentScreenDisposed and
                    self._movieFlagIdentity.get(s) == t)
        show_country_flag(widget, data, kind, tid,
                          visible_when=still_current,
                          gui_dispatch=self._queueGui,
                          on_resolved=(lambda code, row=item, s=slot, st=state:
                                       self._rememberNewPosterCountry(row, code, s, st, False))
                          if tid and not country else None)

    def _setBackdropFlag(self, slot, item, force=False):
        # Preserve the original country's ID enrichment for the first 4 cards.
        result = FastMoviesContentScreen._setBackdropFlag(self, slot, item, force)
        if getattr(self, '_galleryWidgetsReady', False) and 0 <= int(slot) < _VISIBLE:
            idx = self.backdropStart + int(slot)
            if idx < len(self._posterRows()) and self._posterRows()[idx] is item:
                self._syncPosterFlag(int(slot), item, self._art_token(item, idx))
        return result

    def renderBackdrops(self):
        """Latest top tiles are PORTRAIT posters, never landscape backdrops.

        The earlier Python 2.7 port drew a cached backdrop directly into each
        portrait widget, then requested another backdrop if the real poster
        was missing. This code follows Python 3/GENRE's poster-only resolver:
        cache -> provider poster -> verified TMDb poster. The independent
        backdrop rail and artwork worker counts are not changed.
        """
        if not self._galleryWidgetsReady:
            return
        # On warm launches the row data arrives before the six top pixmaps
        # have native instances. Do not mark these rows as rendered yet.
        if not self._upperPosterLayoutReady:
            return
        rows = self._posterRows()
        first = self.backdropStart
        total = len(rows)
        self['newPosterCounter'].setText(('%d - %d / %d' %
            (first + 1, min(total, first + _VISIBLE), total)) if total else '')
        for slot in range(_VISIBLE):
            idx = first + slot
            item = rows[idx] if idx < total else None
            wid = 'newPoster%d' % slot
            # Never consume the identity without a screen pixmap to receive
            # the decoder result. OnShow/layout can retry this slot safely.
            if not getattr(self[wid], 'instance', None):
                self._newPosterIdentity.pop(slot, None)
                continue
            token = self._art_token(item, idx) if item else None
            if self._newPosterIdentity.get(slot) == token:
                continue
            self._newPosterIdentity[slot] = token
            self['newPosterRank%d' % slot].setText('#%d' % (idx + 1) if item else '')
            from .resolution_badge import extract_rating
            self['newPosterRating%d' % slot].setText(extract_rating(item) if item else '')
            if item:
                self._syncPosterFlag(slot, item, token)
            else:
                self._posterFlagIdentity.pop(slot, None)
                self['newPosterFlag%d' % slot].hide()
            self._image_requests.pop(wid, None)
            self[wid].hide()
            if not item:
                continue
            # Local-only placeholder while a real poster is resolved. No
            # landscape fallback is ever painted into this portrait widget.
            self.setPlaceholder(wid, 'movies/movies_new_portrait_placeholder.jpg')
            self[wid].show()

            def still_current(s=slot, t=token, row=item, index=idx):
                live = self._posterRows()
                return (not self._contentScreenDisposed and
                        self._newPosterIdentity.get(s) == t and
                        0 <= index < len(live) and live[index] is row)

            def paint(path, winner=None, w=wid, is_current=still_current):
                if not path or not os.path.isfile(path) or not is_current():
                    return
                self._image_requests[w] = winner or path
                self.decode(path, w, _POSTER_W, _POSTER_H)

            source = dict(self.source or {})
            # GENRE downloader checks *every* candidate's orientation, not
            # only the first server URL. A failed poster leaves the portrait
            # placeholder; it must NEVER trigger a backdrop request.
            # The downloader accepts a *cancellation* predicate: True means
            # STOP.  still_current() is the opposite (True means the slot is
            # valid).  Passing it directly suppressed every visible upper
            # poster before its download was ever queued.  Bind the per-slot
            # predicate here to avoid a late callback using the next slot.
            def cancelled(is_current=still_current):
                return not is_current()

            request_genre_poster(
                source, item, self.kind, paint,
                cancelled=cancelled, primary=self.imageUrl(item, False),
                callback_gui=self._queueGui, portrait_only=True)
        self.updateFocus()

    def _loadCinemaCard(self,item,slot,wid,token):
        # The same GENRE cache-first poster resolver as the upper movie rail.
        source=dict(self.source or {})
        def stale():
            return self._contentScreenDisposed or self._newMovieIdentity.get(slot)!=token
        def done(path,_winner=None):
            if stale() or not path:return
            self._image_requests[wid]=path
            self.decode(path,wid,_CARD_POSTER_W,_CARD_POSTER_H)
        request_genre_poster(source,item,self.kind,done,
                             cancelled=stale,primary=self.imageUrl(item,False),
                             callback_gui=self._queueGui, portrait_only=True)

    def _packageLabels(self,item,slot):
        # Lower posters show only the existing country flag and rating.
        # Preserve the title widget for screen compatibility, but leave it blank.
        info=(item or {}).get('info') if isinstance((item or {}).get('info'),dict) else {}
        self['firstMovieName%d'%slot].setText('')
        from .resolution_badge import extract_rating
        self['firstMovieRate%d'%slot].setText(extract_rating(item) if item else '')

    def renderLatest(self):
        if not self._galleryWidgetsReady:return
        rows=self._movieRows()
        self._updatePackageName()
        for slot in range(_PACKAGE_VISIBLE):
            idx=self.latestStart+slot
            item=rows[idx] if idx<len(rows) else None
            wid='backdropMovie%d'%slot
            token=self._art_token(item,idx) if item else None
            if self._newMovieIdentity.get(slot)==token:continue
            self._newMovieIdentity[slot]=token
            self._image_requests.pop(wid,None)
            self[wid].hide()
            self._packageLabels(item,slot)
            if item:
                self._syncMovieFlag(slot,item,token)
                self._loadCinemaCard(item,slot,wid,token)
            else:
                self._movieFlagIdentity.pop(slot,None)
                self['newMovieFlag%d'%slot].hide()
        self.updateFocus()

















    def _updatePackageName(self):
        # The same real category as GENRE: show its existing badge on top of
        # the transparent silver frame. Never substitute an unrelated logo.
        if not self._galleryWidgetsReady:
            return
        name = str(getattr(self, 'categoryName', '') or '').strip()
        if not name:
            rows = self._movieRows()
            index = self.latestStart + self.latestIndex
            item = rows[index] if index < len(rows) else None
            if item:
                name = str(item.get('_source_category_name') or
                           item.get('category_name') or '').strip()
        logo_path = ''
        year_path = ''
        if name:
            try:
                logo_path, year_path = resolve_package_badge(name, self.kind)
            except Exception:
                logo_path, year_path = '', ''
            # A provider's year-only category may have no recognized logo.
            # The original 1900-2099 GENRE year PNGs still apply to its name.
            if not year_path:
                year_match = re.search(r'(?<!\d)((?:19|20)\d{2})(?!\d)', name)
                if year_match:
                    candidate = os.path.join(os.path.dirname(__file__), 'skins',
                                             'genre', 'package_badges',
                                             'year_%s.png' % year_match.group(1))
                    if os.path.isfile(candidate):
                        year_path = candidate
        # The year is displayed INSIDE this blue category tile, and is cleared
        # promptly on package changes without affecting the provider data.
        year_widget = self['newPackageYear']
        if year_path and os.path.isfile(year_path) and getattr(year_widget, 'instance', None):
            try:
                if year_path != self._newPackageYearCurrent:
                    year_widget.instance.setPixmapFromFile(year_path)
                    self._newPackageYearCurrent = year_path
                year_widget.show()
            except Exception:
                self._newPackageYearCurrent = ''
                year_widget.hide()
        else:
            self._newPackageYearCurrent = ''
            year_widget.hide()
        # Choose the compact representation from the existing GENRE folder
        # because its visible artwork is wider within the transparent PNG.
        if logo_path and logo_path.endswith('_full.png'):
            compact = logo_path[:-9] + '_compact.png'
            if os.path.isfile(compact):
                logo_path = compact
        logo_widget = self['newPackageLogo']
        if logo_path and os.path.isfile(logo_path) and getattr(logo_widget, 'instance', None):
            try:
                if logo_path != self._newPackageLogoCurrent:
                    logo_widget.instance.setPixmapFromFile(logo_path)
                    self._newPackageLogoCurrent = logo_path
                logo_widget.show()
                self['newPackageName'].setText('')
                return
            except Exception:
                self._newPackageLogoCurrent = ''
        logo_widget.hide()
        self['newPackageName'].setText(name)

    def updateFocus(self):
        if not self._galleryWidgetsReady:return
        self._updatePackageName()
        try:
            self['topSelector'].hide()
            self['backdropSelector'].hide()
            self['latestSelector'].hide()
            self['newPosterFocus'].hide()
            self['newMovieFocus'].hide()
            if self.focus=='top':
                self['topSelector'].show();self._alignTopSelector()
            elif self.focus=='backdrops' and self._posterRows():
                index=min(_VISIBLE-1,max(0,self.backdropIndex))
                self['newPosterFocus'].instance.move(ePoint(sx(_POSTER_X[index]-5),sy(_POSTER_Y-5)))
                self['newPosterFocus'].show()
            elif self.focus=='latest' and self._movieRows():
                index=min(_PACKAGE_VISIBLE-1,max(0,self.latestIndex))
                self['newMovieFocus'].instance.move(ePoint(sx(_MOVIE_X[index]-5),sy(_MOVIE_Y-5)))
                self['newMovieFocus'].show()
        except Exception:pass

    def _openPackageDrawerHome(self):
        # Same shared PACKAGES menu as every poster style, titled LATEST.
        if self.kind not in ("vod", "series") or not getattr(self, "categoriesLoaded", False):
            return False
        rows = list(getattr(self, "categoriesList", None) or [])
        if len(rows) < 2:
            return False
        names = [(r.get("category_name") if isinstance(r, dict) else r) or "" for r in rows]
        start = int(getattr(self, "categoryIndex", -1))
        current = start if 0 <= start < len(rows) else 0
        def chosen(target, start=start):
            self._changeCategory(target - start)
        from .package_drawer import open_package_drawer
        return open_package_drawer(self, names, current, chosen, "LATEST")

    def left(self):
        # LEFT on the first card of any page of either rail opens the menu.
        if ((self.focus=='backdrops' and self.backdropIndex==0 and self._posterRows()) or
                (self.focus=='latest' and self.latestIndex==0 and self._movieRows())):
            if self._openPackageDrawerHome():
                return
        if self.focus=='backdrops':
            if self.backdropIndex>0:self.backdropIndex-=1
            elif self.backdropStart>0:
                self.backdropStart=max(0,self.backdropStart-_VISIBLE)
                self.backdropIndex=min(_VISIBLE-1,len(self._posterRows())-self.backdropStart-1)
                self.renderBackdrops()
        elif self.focus=='latest':
            if self.latestIndex>0:self.latestIndex-=1
            elif self.latestStart>0:
                self.latestStart=max(0,self.latestStart-_PACKAGE_VISIBLE)
                self.latestIndex=min(_PACKAGE_VISIBLE-1,len(self._movieRows())-self.latestStart-1)
                self.renderLatest()
        else:self.topIndex=max(0,self.topIndex-1)
        self.updateFocus()
        if self.focus!='top':self.preview()

    def right(self):
        if self.focus=='backdrops':
            if self.backdropStart+self.backdropIndex+1<len(self._posterRows()):
                if self.backdropIndex<_VISIBLE-1:self.backdropIndex+=1
                else:
                    self.backdropStart+=_VISIBLE;self.backdropIndex=0;self.renderBackdrops()
        elif self.focus=='latest':
            if self.latestStart+self.latestIndex+1<len(self._movieRows()):
                if self.latestIndex<_PACKAGE_VISIBLE-1:self.latestIndex+=1
                else:
                    self.latestStart+=_PACKAGE_VISIBLE;self.latestIndex=0;self.renderLatest()
        else:self.topIndex=min(len(self.TOP)-1,self.topIndex+1)
        self.updateFocus()
        if self.focus!='top':self.preview()

    def up(self):
        if self.focus=='latest':self.focus='backdrops' if self._posterRows() else 'top'
        elif self.focus=='backdrops':self.focus='top'
        self.updateFocus()
        if self.focus!='top':self.preview()

    def down(self):
        if self.focus=='top':
            self.focus='backdrops' if self._posterRows() else ('latest' if self._movieRows() else 'top')
        elif self.focus=='backdrops' and self._movieRows():self.focus='latest'
        elif self.focus=='latest' and self.latestStart+_PACKAGE_VISIBLE<len(self._movieRows()):
            self.latestStart+=_PACKAGE_VISIBLE;self.latestIndex=0;self.renderLatest()
        self.updateFocus()
        if self.focus!='top':self.preview()

    def _switchContentKind(self,new_kind):
        # Honour the saved design for BOTH media kinds.  When they share the
        # Cinematic skin, switch in place without stacking duplicate pages.
        from .movies_layout_choice import configured_movies_screen
        if new_kind != self.kind:
            other = configured_movies_screen(FastMoviesContentScreen, new_kind)
            if other is not NewMoviesContentScreen:
                self._stopAutoTrailer()
                self._openPageOnce(other, dict(self.source), new_kind)
                return
        result = FastMoviesContentScreen._switchContentKind(self, new_kind)
        self._updateLatestTitleLogo()
        self._updatePackageName()
        return result
