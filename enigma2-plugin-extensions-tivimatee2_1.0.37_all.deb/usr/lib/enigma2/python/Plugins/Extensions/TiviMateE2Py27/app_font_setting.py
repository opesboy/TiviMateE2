# -*- coding: utf-8 -*-
"""APP & SUBTITLE FONT row for Settings > Skin & Poster View.

One choice drives the TiviMate app font and both subtitle renderers: it is
the same setting as Subtitle style > Font type, applied as the Enigma2
replacement font while TiviMate is open. Works on Python 2.7 and 3.
"""
from __future__ import absolute_import


def _subtitles():
    package = __name__.rsplit(".", 1)[0]
    return __import__(package + ".TiviMateSubtitles.tivimate_subtitles", fromlist=["x"])


def font_choices():
    try:
        choices = list(_subtitles().fontChoiceList or [])
    except Exception:
        choices = []
    out = []
    for entry in choices:
        if isinstance(entry, (tuple, list)) and len(entry) >= 2:
            out.append((entry[0], entry[1]))
        else:
            out.append((entry, entry))
    return out or [("Regular", "Regular")]


def current_font():
    try:
        return _subtitles().initTiviMateSettings().external.font.regular.type.value
    except Exception:
        return "Regular"


def label(value, choices=None):
    """Short card label: 'BritishCouncil Arabic Bold Italic' -> 'BritishCouncil'."""
    import re
    text = value or "Regular"
    for key, name in (choices or font_choices()):
        if key == value:
            text = name
            break
    short = re.sub(r"\b(Bold|Italic|BoldIt|BoldItalic|bold|italic)\b", " ", text)
    short = " ".join(short.split()) or text
    if len(short) > 18:
        short = " ".join(re.sub(r"\b(Arabic|arabic|Regular)\b", " ", short).split()) or short
    from .py27_compat import ucut as _ucut
    return _ucut(short, 18, 17)


def step(value, delta, choices=None):
    keys = [key for key, _text in (choices or font_choices())]
    if not keys:
        return value
    try:
        index = keys.index(value)
    except ValueError:
        index = 0
    return keys[(index + delta) % len(keys)]


def save(value):
    """Store the font for regular/italic/bold and apply it now."""
    try:
        module = _subtitles()
        settings = module.initTiviMateSettings()
        for style in ("regular", "italic", "bold"):
            entry = getattr(settings.external.font, style).type
            entry.value = value
            entry.save()
        try:
            from Components.config import configfile
            configfile.save()
        except Exception:
            pass
        module.applySubtitleFontAsReplacement(settings)
        return True
    except Exception as exc:
        print("[TiviMateE2] app font save failed: %s" % exc)
        return False
