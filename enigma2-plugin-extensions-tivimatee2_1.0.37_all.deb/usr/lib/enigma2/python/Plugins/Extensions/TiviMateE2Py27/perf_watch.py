# -*- coding: utf-8 -*-
"""Low-overhead GUI stall sampler (diagnostics for slow receivers, e.g. VTi).

A daemon thread looks at the GUI thread's Python stack every 100 ms. When the
GUI thread stays inside TiviMate code for 400 ms or longer, the plugin frames
of that stall are appended to /tmp/tivimate_slow.log with its duration.
No Enigma2 object is touched from the sampler thread.
"""
import os
import sys
import threading
import time

LOG = "/tmp/tivimate_slow.log"
_MAX_LOG = 256 * 1024
_INTERVAL = 0.1
_MIN_STALL = 0.4
_STARTED = False
_MARK = os.sep + "TiviMateE2Py27" + os.sep


def _plugin_stack(frame):
    out = []
    while frame is not None:
        code = frame.f_code
        name = code.co_filename or ""
        if _MARK in name:
            out.append("%s:%d %s" % (name.split(_MARK, 1)[1], frame.f_lineno, code.co_name))
        frame = frame.f_back
    return out  # innermost first


def _write(lines):
    try:
        if os.path.exists(LOG) and os.path.getsize(LOG) > _MAX_LOG:
            os.rename(LOG, LOG + ".1")
        with open(LOG, "a") as handle:
            handle.write("\n".join(lines) + "\n")
    except Exception:
        pass


def _run(gui_ident):
    stall_start = None
    worst = None
    while True:
        time.sleep(_INTERVAL)
        try:
            frame = sys._current_frames().get(gui_ident)
        except Exception:
            frame = None
        stack = _plugin_stack(frame) if frame is not None else []
        now = time.time()
        if stack:
            if stall_start is None:
                stall_start = now
                worst = {}
            # Count which innermost plugin lines the GUI thread sits in.
            key = " <- ".join(stack[:6])
            worst[key] = worst.get(key, 0) + 1
        elif stall_start is not None:
            duration = now - stall_start
            if duration >= _MIN_STALL:
                lines = ["%s  GUI busy %.1fs" % (time.strftime("%H:%M:%S"), duration)]
                for key, hits in sorted(worst.items(), key=lambda kv: -kv[1])[:4]:
                    lines.append("   %3d%%  %s" % (int(100.0 * hits / max(1, sum(worst.values()))), key))
                _write(lines)
            stall_start = None
            worst = None


def start():
    """Call from the GUI thread (plugin main) once."""
    global _STARTED
    # r146: the 100 ms stack sampler costs CPU on small receivers; it only
    # runs when /tmp/tivimate_speed.on exists.
    if _STARTED or not hasattr(sys, "_current_frames") or True:
        return
    _STARTED = True
    try:
        gui_ident = threading.current_thread().ident
        try:
            from .py27_compat import thread_factory
            worker = thread_factory(target=_run, args=(gui_ident,), daemon=True)
        except Exception:
            worker = threading.Thread(target=_run, args=(gui_ident,))
            worker.daemon = True
        _write(["%s  ---- TiviMate start (stall log) ----" % time.strftime("%Y-%m-%d %H:%M:%S")])
        worker.start()
    except Exception:
        pass


def mark(text):
    if not _STARTED:
        return
    _write(["%s  %s" % (time.strftime("%H:%M:%S"), text)])
