# -*- coding: utf-8 -*-
"""Task cancellation primitive ported from UltraStalker/core/tasks.py.

Limited to Stalker Live jobs: cancelled requests must not affect other pages.
"""
import threading
class TaskHandle:
    def __init__(self, task_id, key=None):
        self.task_id = task_id
        self.key = key
        self.cancel_event = threading.Event()
        self.future = None
        self._cancel_lock = threading.RLock()
        self._cancel_callbacks = []

    def add_cancel_callback(self, callback):
        if not callable(callback):
            return
        run_now = False
        with self._cancel_lock:
            if self.cancel_event.is_set():
                run_now = True
            elif callback not in self._cancel_callbacks:
                self._cancel_callbacks.append(callback)
        if run_now:
            try:
                callback()
            except Exception:
                pass

    def cancel(self):
        self.cancel_event.set()
        if self.future is not None:
            self.future.cancel()
        with self._cancel_lock:
            callbacks = list(self._cancel_callbacks)
            self._cancel_callbacks = []
        for callback in callbacks:
            try:
                callback()
            except Exception:
                pass

    def clear_cancel_callbacks(self):
        with self._cancel_lock:
            self._cancel_callbacks = []

    def is_set(self):
        return self.cancel_event.is_set()

    def cancelled(self):
        return self.cancel_event.is_set()

    def wait(self, seconds):
        return self.cancel_event.wait(seconds)

