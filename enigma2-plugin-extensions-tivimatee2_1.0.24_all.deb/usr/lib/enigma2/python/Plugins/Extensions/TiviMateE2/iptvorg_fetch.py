# -*- coding: utf-8 -*-
"""Shared, bounded IPTV-org M3U download for Finder's Arabic groups only."""
import os
import time
import hashlib
import threading

from .cache_manager import get_cache_dir

_TTL = 2 * 60 * 60


def _is_m3u(body):
    return (isinstance(body, bytes) and
            body.lstrip().startswith(b"#EXTM3U") and
            b"#EXTINF" in body and
            (b"http://" in body or b"https://" in body))


def fetch_iptvorg_m3u(url, timeout=7, max_bytes=24*1024*1024):
    """Return (UTF-8 playlist, used_cache). Raise with actual transport cause."""
    name="iptvorg_"+hashlib.sha1(url.encode("utf-8")).hexdigest()+".m3u"
    cache=os.path.join(get_cache_dir("source_catalog"), name)
    try:
        if os.path.isfile(cache) and 0 <= time.time()-os.path.getmtime(cache)<_TTL:
            with open(cache, "rb") as fh:
                raw=fh.read(max_bytes+1)
            if len(raw)<=max_bytes and _is_m3u(raw):
                return raw.decode("utf-8","replace"), True
    except Exception:
        pass
    errors=[]
    data=None
    # First use the existing Finder transport. It may work on images where
    # requests is not installed.
    try:
        from .web_manager import _urlopen_text
        code, final, content=_urlopen_text(url,timeout=timeout,max_bytes=max_bytes)
        if int(code or 0)==200:
            data=content.encode("utf-8") if isinstance(content,str) else content
            if len(data)>max_bytes or not _is_m3u(data):
                errors.append("urllib returned incomplete/invalid M3U")
                data=None
        else:
            errors.append("urllib HTTP %s: %s"%(code,str(content)[:110]))
    except Exception as exc:
        errors.append("urllib: %s"%str(exc)[:110])
    # Different certificate store/HTTP implementation, with TLS verification ON.
    if data is None:
        try:
            import requests
            response=requests.get(url, timeout=(min(timeout,5),timeout),
                                  headers={"User-Agent":"Mozilla/5.0 (Linux; Enigma2) TiviMateE2", "Accept":"*/*"},
                                  stream=True, allow_redirects=True)
            try:
                if response.status_code != 200:
                    raise RuntimeError("HTTP %s"%response.status_code)
                parts=[]
                size=0
                for chunk in response.iter_content(65536):
                    if not chunk: continue
                    size+=len(chunk)
                    if size>max_bytes:
                        raise RuntimeError("M3U exceeds %d bytes"%max_bytes)
                    parts.append(chunk)
                raw=b"".join(parts)
                if not _is_m3u(raw):
                    raise RuntimeError("Response is not a channel M3U")
                data=raw
            finally:
                response.close()
        except Exception as exc:
            errors.append("requests: %s"%str(exc)[:140])
    if data is None:
        raise RuntimeError("; ".join(errors)[:300])
    try:
        folder=os.path.dirname(cache)
        if not os.path.isdir(folder):os.makedirs(folder)
        tmp=cache+".%s.%s.tmp"%(os.getpid(),threading.current_thread().ident)
        with open(tmp,"wb") as fh:fh.write(data)
        os.replace(tmp,cache)
    except Exception:
        pass
    return data.decode("utf-8","replace"), False
