# -*- coding: utf-8 -*-
"""Static TMDb percentage ring art for Enigma2 details pages.

No runtime image drawing, threads or third-party libraries are required.
"""
import os

_SCORE_ROOT = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/movies/tmdb_score_circles"


def score_asset(vote_average):
    """Only turn a genuine 0..10 TMDb vote average into a ring image."""
    try:
        value = float(str(vote_average).strip().replace(",", "."))
        if not 0.0 < value <= 10.0:
            return ""
        percentage = max(1, min(100, int(value * 10.0 + 0.5)))
        return os.path.join(_SCORE_ROOT, "score_%03d.jpg" % percentage)
    except (TypeError, ValueError, OverflowError):
        return ""


def show_score(widget, vote_average):
    """Update on the Enigma GUI thread; hide if the official score is absent."""
    path = score_asset(vote_average)
    try:
        if not path or not widget.instance:
            widget.hide()
            return
        # JPEG is compact but opaque. Clip it on recent Enigma2 images;
        # older Pure2/OpenATV builds use a transparent PNG fallback instead
        # of showing a square over the movie backdrop.
        clipping_ok = False
        instance = widget.instance
        if hasattr(instance, "setCornerRadius"):
            try:
                size = instance.size()
                radius = min(size.width(), size.height()) // 2
                try:
                    instance.setCornerRadius(radius)
                except TypeError:
                    from enigma import eWidget
                    instance.setCornerRadius(radius, eWidget.RADIUS_ALL)
                clipping_ok = True
            except Exception:
                pass
        if not clipping_ok:
            fallback = os.path.splitext(path)[0] + ".png"
            if os.path.isfile(fallback):
                path = fallback
        instance.setPixmapFromFile(path)
        widget.show()
    except Exception:
        try:
            widget.hide()
        except Exception:
            pass
