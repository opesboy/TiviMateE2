
"""Small, UI-safe artwork download queue for Enigma2.

Artwork is always read from the local cache first.  On a cache miss this module
starts the existing helper in a separate process and keeps at most six network
transfers alive at once.  Consequently a list renderer never performs DNS,
HTTP, image conversion, or disk writes on the Enigma2 GUI thread.
"""

import hashlib
import json
from urllib.parse import urlparse
import os
from stat import S_ISREG
import threading
import time
import zlib

from enigma import eConsoleAppContainer, eTimer

try:
    from twisted.web.client import downloadPage
except Exception:
    downloadPage = None

from .cache_manager import get_cache_dir, get_cache_root, cleanup_cache, get_settings, is_internal_cache_active
from .compat import python_command

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()
# Six transfers improve visible Movies/TV Shows/package poster fill speed while
# the bounded queue still prevents an unbounded burst on Enigma2 receivers.  Artwork bytes are never changed.
MAX_CONCURRENT_DOWNLOADS = 4
# Bound the queued artwork metadata/callbacks as well as active transfers. On a
# fast scroll a receiver can otherwise accumulate hundreds of stale poster jobs
# while the network is slower than the UI. Dropped stale jobs are harmless: a
# visible card requests the same cached URL again when rendered.
MAX_PENDING_DOWNLOADS = 36

# R227: one bad/slow artwork response must never freeze the remaining Movies
# poster queue. Each transfer gets one controlled retry and a hard watchdog.
MAX_JOB_RETRIES = 1
JOB_STALL_SECONDS = 11
WATCHDOG_INTERVAL_MS = 1400
_watchdog_timer = [None]

# Global low-priority prefetch feeder. Screens can hand us every artwork URL
# they already know about; the feeder releases them to the normal queue in
# small slices so page rendering never waits for a bulk image burst.
_PREFETCH_FEED_SIZE = 6
_PREFETCH_INTERVAL_MS = 180
# Bound *queued* prefetch metadata, not HDD/USB image retention.  The most
# recently visited screen gets the newest prefetch slots; older work can be
# fetched on demand.  _prefetch_seen tracks pending keys only, never every
# image cached during an entire Enigma2 session.
MAX_PREFETCH_PENDING = 48
# Limit synchronous disk/cache checks when a package supplies thousands of URLs.
# Visible poster requests are separate and never limited by this bound.
MAX_PREFETCH_SCAN = 128
_prefetch_pending = []
_prefetch_seen = set()
_prefetch_timer = [None]

MAX_CALLBACKS_PER_JOB = 64
MAX_NOTIFY_TIMERS = 64
MIN_VALID_BYTES = 32

_pending = []
_running = {}
_jobs = {}
# Ephemeral negative cache prevents repeated HTTP attempts against broken image
# links when moving in and out of screens. No success or empty path is persisted.
_FAILED_ARTWORK_UNTIL = {}
_FAILED_ARTWORK_SECONDS = 75.0
_sequence = [0]
_cleanup_count = [0]
_cleanup_running = [False]
_notify_timers = []
_display_sequence = [0]
CLEANUP_EVERY_SUCCESSES = 12

# r173: hard application-exit gate. Once Home exits, no artwork callback,
# retry, prefetch or late network completion may recreate the cache tree.
_APP_EXITING = [False]

def set_app_exiting(value=True):
    try:
        _APP_EXITING[0] = bool(value)
    except Exception:
        pass

def is_app_exiting():
    try:
        return bool(_APP_EXITING[0])
    except Exception:
        return False


def provider_asset_url(source, value):
    """Normalize artwork supplied by the IPTV provider, never as a TMDb path."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = str(value or "").strip().replace("\\/", "/")
    except Exception:
        return ""
    if not value:
        return ""
    # JSON-encoded one-element artwork arrays are common on Xtream forks.
    if value.startswith("["):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, list) and decoded:
                value = str(decoded[0] or "").strip().replace("\\/", "/")
        except (ValueError, TypeError):
            pass
    if not value:
        return ""
    if value.startswith("//"):
        base = str((source or {}).get("url") or (source or {}).get("portal") or "")
        scheme = urlparse(base).scheme or "http"
        return scheme + ":" + value
    if value.startswith(("http://", "https://")):
        return value.replace(" ", "%20")

    source = source or {}
    base = str(source.get("url") or source.get("portal") or "").strip().rstrip("/")
    if not base:
        return value.replace(" ", "%20")
    if "://" not in base:
        base = "http://" + base

    try:
        parsed = urlparse(base)
        scheme = parsed.scheme or "http"
        netloc = parsed.netloc
        # Some saved Xtream sources keep port in a separate field.
        port = str(source.get("port") or "").strip()
        if port and ":" not in netloc.rsplit("@", 1)[-1]:
            netloc = "%s:%s" % (netloc, port)
        origin = "%s://%s" % (scheme, netloc)
        if value.startswith("/"):
            return (origin + value).replace(" ", "%20")
        path = (parsed.path or "").rstrip("/")
        return ("%s%s/%s" % (origin, path, value.lstrip("/"))).replace(" ", "%20")
    except Exception:
        return value.replace(" ", "%20")


def find_provider_asset(source, item, keys, extra=None):
    """One provider metadata traversal for posters, backdrops and logos.

    Each media manager specifies its own field names.  Media types do not
    borrow one another's artwork as a placeholder.
    """
    item = item if isinstance(item, dict) else {}
    extra = extra if isinstance(extra, dict) else {}
    mappings = [item]
    info = item.get("info")
    if isinstance(info, dict):
        mappings.append(info)
    if extra:
        mappings.append(extra)
        extra_info = extra.get("info")
        if isinstance(extra_info, dict):
            mappings.append(extra_info)
    for mapping in mappings:
        for key in keys:
            value = mapping.get(key)
            if value not in (None, "", [], {}):
                url = provider_asset_url(source, value)
                if url:
                    return url
    return ""


def normalise_url(url):
    try:
        return (url or "").strip().replace("\\/", "/")
    except Exception:
        return ""




def _media_cache_kind(kind):
    """Collapse every screen-specific media alias into one shared cache family."""
    value = str(kind or "artwork").strip().lower()
    poster_aliases = {
        "poster", "posters", "contenthome", "search", "home_poster",
        "details_poster", "live_tmdb_poster", "download_poster"
    }
    backdrop_aliases = {
        "backdrop", "backdrops", "hero", "home_backdrop", "details_backdrop",
        "episodes", "episode", "stills"
    }
    logo_aliases = {"logo", "logos", "package_logo", "provider_logo"}
    if value in poster_aliases:
        return "posters"
    if value in backdrop_aliases:
        return "backdrops"
    if value in logo_aliases:
        return "logos"
    return value or "artwork"

def _canonical_tmdb_artwork(url, kind):
    """Return one shared TMDb URL/key for every screen.

    TMDb serves the same file through size-specific URLs (w342/w500/w780/w780/
    original). Older builds hashed the full URL, so the same poster/backdrop was
    cached once per screen size.  r130-test standardises TMDb artwork to one
    quality per media type and one cache key derived from the TMDb file path.
    """
    url = normalise_url(url)
    kind = _media_cache_kind(kind)
    clean = url.split("?", 1)[0]
    marker = "image.tmdb.org/t/p/"
    lower = clean.lower()
    pos = lower.find(marker)
    if pos < 0:
        return url, ""
    tail = clean[pos + len(marker):].lstrip("/")
    parts = tail.split("/", 1)
    if len(parts) != 2 or not parts[1]:
        return url, ""
    rel = parts[1].lstrip("/")
    # One good-quality file shared by Home, rails, details, search and player.
    # Backdrops use HD w780; posters use w500 to keep cache weight modest.
    if str(kind or "").lower() == "backdrops":
        size = "w780"
    elif str(kind or "").lower() == "posters":
        size = "w500"
    else:
        size = parts[0] or "original"
    canonical = "https://image.tmdb.org/t/p/%s/%s" % (size, rel)
    return canonical, rel


def artwork_path(url, kind="artwork"):
    """Return the stable shared cache path for an artwork URL."""
    url = normalise_url(url)
    if not url:
        return ""
    kind = _media_cache_kind(kind)
    canonical_url, tmdb_rel = _canonical_tmdb_artwork(url, kind)
    clean_url = canonical_url.split("?", 1)[0]
    lower_url = clean_url.lower()
    ext = ".png" if lower_url.endswith(".png") else ".jpg"
    if tmdb_rel:
        # Same TMDb image => same filename, regardless of which page requested it.
        digest = hashlib.md5(tmdb_rel.encode("utf-8")).hexdigest()
        prefix = "poster_" if kind == "posters" else ("backdrop_" if kind == "backdrops" else ("logo_" if kind == "logos" else "artwork_"))
        return os.path.join(get_cache_dir(kind), prefix + "tmdb_" + digest + ext)
    # Provider/CDN artwork still deduplicates query-string token changes.
    digest = hashlib.md5(clean_url.encode("utf-8")).hexdigest()
    prefix = "poster_" if kind == "posters" else ("backdrop_" if kind == "backdrops" else ("logo_" if kind == "logos" else "artwork_"))
    return os.path.join(get_cache_dir(kind), prefix + digest + ext)


# A small stat-keyed result cache avoids reading/validating megabyte-sized PNGs
# on every draw.  Replacing the file changes its inode/mtime or size.
_IMAGE_VALID_MEMO = {}
_IMAGE_VALID_MEMO_LIMIT = 512


def _image_structure_ok(path, size):
    """Check actual image structure with standard-library, bounded reads.

    JPEG entropy cannot be fully decoded without an image codec; require valid
    segment layout, SOF, SOS and EOI.  PNG checks chunk CRCs and complete zlib
    stream.  WebP checks RIFF/chunk sizes (including tiny legitimate WebP).
    This does not replace ePicLoad's final decode check.
    """
    if size < 32 or size > 24 * 1024 * 1024:
        return False
    with open(path, "rb") as f:
        head = f.read(32)
        if head.startswith(b"\xff\xd8\xff"):
            # The actual first SOF and SOS must be present.  A forged JFIF
            # header followed by garbage and an EOI is not a JPEG picture.
            f.seek(2)
            sof = False
            sos = False
            while f.tell() < min(size, 512 * 1024):
                marker = f.read(1)
                if marker != b"\xff":
                    return False
                while marker == b"\xff":
                    marker = f.read(1)
                if not marker:
                    return False
                tag = marker[0]
                if tag in (0xD8, 0x01) or 0xD0 <= tag <= 0xD7:
                    continue
                if tag == 0xD9:
                    return False
                b = f.read(2)
                if len(b) != 2:
                    return False
                length = int.from_bytes(b, "big")
                if length < 2 or f.tell() + length - 2 > size:
                    return False
                if tag in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF):
                    if length < 8:
                        return False
                    values = f.read(5)
                    if len(values) != 5:
                        return False
                    height = int.from_bytes(values[1:3], "big")
                    width = int.from_bytes(values[3:5], "big")
                    if not (8 <= width <= 16000 and 8 <= height <= 16000):
                        return False
                    sof = True
                    f.seek(length - 7, 1)
                elif tag == 0xDA:
                    sos = True
                    break
                else:
                    f.seek(length - 2, 1)
            if not (sof and sos):
                return False
            # EOI is the final marker; allow only a few trailing zero bytes.
            f.seek(max(0, size - 32))
            tail = f.read()
            eoi = tail.rfind(b"\xff\xd9")
            return eoi >= 0 and not any(tail[eoi + 2:])
        if head.startswith(b"\x89PNG\r\n\x1a\n"):
            f.seek(8)
            first = True
            saw_idat = saw_end = False
            inflator = zlib.decompressobj()
            raw_count = 0
            raw_limit = 256 * 1024 * 1024
            while f.tell() + 12 <= size:
                header = f.read(8)
                if len(header) != 8:
                    return False
                n = int.from_bytes(header[:4], 'big')
                kind = header[4:]
                if n > 24 * 1024 * 1024 or f.tell() + n + 4 > size:
                    return False
                if first:
                    first = False
                    if kind != b'IHDR' or n != 13:
                        return False
                crc = zlib.crc32(kind)
                if kind == b'IHDR':
                    if n != 13:
                        return False
                    info = f.read(13)
                    w = int.from_bytes(info[:4], 'big')
                    h = int.from_bytes(info[4:8], 'big')
                    if not (8 <= w <= 16000 and 8 <= h <= 16000):
                        return False
                    raw_limit = min(raw_limit, w * h * 9 + 64 * h)
                    crc = zlib.crc32(info, crc)
                else:
                    remaining = n
                    while remaining:
                        part = f.read(min(remaining, 32768))
                        if not part:
                            return False
                        crc = zlib.crc32(part, crc)
                        remaining -= len(part)
                        if kind == b'IDAT':
                            saw_idat = True
                            pending = part
                            while pending:
                                out = inflator.decompress(pending, 65536)
                                raw_count += len(out)
                                if raw_count > raw_limit:
                                    return False
                                pending = inflator.unconsumed_tail
                                if not out and not pending:
                                    break
                expected = f.read(4)
                if len(expected) != 4 or int.from_bytes(expected, 'big') != crc & 0xffffffff:
                    return False
                if kind == b'IEND':
                    saw_end = n == 0 and f.tell() == size
                    break
            return saw_idat and saw_end and inflator.eof
        if head.startswith(b'RIFF') and head[8:12] == b'WEBP':
            riff_end = int.from_bytes(head[4:8], 'little') + 8
            if riff_end != size or size < 20:
                return False
            f.seek(12)
            chunks = 0
            got_picture = False
            while f.tell() + 8 <= size:
                hdr = f.read(8)
                tag = hdr[:4]
                n = int.from_bytes(hdr[4:], 'little')
                if n < 0 or f.tell() + n + (n & 1) > size:
                    return False
                if tag in (b'VP8 ', b'VP8L', b'ANMF') and n >= (10 if tag == b'VP8 ' else (5 if tag == b'VP8L' else 16)):
                    got_picture = True
                f.seek(n + (n & 1), 1)
                chunks += 1
            return got_picture and chunks > 0 and f.tell() == size
        if head.startswith((b'GIF87a', b'GIF89a')) and size >= 35:
            width = int.from_bytes(head[6:8], 'little')
            height = int.from_bytes(head[8:10], 'little')
            f.seek(size - 1)
            return width >= 8 and height >= 8 and f.read(1) == b'\x3b'
    return False


def _image_signature_ok(path):
    try:
        st = os.stat(path)
        key = (st.st_size, getattr(st, 'st_mtime_ns', st.st_mtime), st.st_ino)
        saved = _IMAGE_VALID_MEMO.get(path)
        if saved and saved[0] == key:
            return saved[1]
        valid = _image_structure_ok(path, st.st_size)
        if len(_IMAGE_VALID_MEMO) >= _IMAGE_VALID_MEMO_LIMIT:
            _IMAGE_VALID_MEMO.clear()
        _IMAGE_VALID_MEMO[path] = (key, valid)
        return valid
    except (OSError, IOError, ValueError, zlib.error):
        return False


def _cached_artwork_core(url, kind="artwork"):
    """Cheap cache-first check with bounded timestamp writes.

    On HDD artwork retention is unlimited, so an mtime write for every
    already-cached poster is unnecessary and causes HDD I/O. Receiver flash
    still needs LRU recency, but updates are batched per file. USB with age
    retention also receives occasional recency updates.
    """
    if is_app_exiting():
        return ""
    path = artwork_path(url, kind)
    try:
        if not path:
            return ""
        st = os.stat(path)
        if st.st_size < MIN_VALID_BYTES or not S_ISREG(st.st_mode):
            return ""
        if not _image_signature_ok(path):
            return ""
        if path.startswith("/var/tmp/tivimatee2-cache/"):
            touch_seconds = 30       # Enigma2 internal flash LRU
        elif path.startswith("/media/hdd/"):
            touch_seconds = 0        # Unlimited HDD cache needs no LRU writes
        else:
            touch_seconds = 600      # USB and other optional age retention
        if touch_seconds and time.time() - st.st_mtime >= touch_seconds:
            try:
                os.utime(path, None)
            except Exception:
                pass
        return path
    except (OSError, ValueError):
        return ""


def _valid(path):
    try:
        return bool(path and os.path.isfile(path) and
                    os.path.getsize(path) >= MIN_VALID_BYTES and
                    _image_signature_ok(path))
    except (OSError, ValueError):
        return False


def _schedule_cleanup():
    """Run lightweight artwork-only cleanup when its policy is enabled."""
    if is_app_exiting():
        return
    try:
        cfg = get_settings() or {}
        location = str(cfg.get("location") or "auto").strip().lower()
        try:
            actual_root = os.path.realpath(get_cache_root())
        except Exception:
            actual_root = ""
        on_internal = is_internal_cache_active()
        # HDD artwork retention is unlimited.  Avoid repeatedly walking a
        # potentially huge HDD image tree in background cleanup workers even
        # when a legacy retention_days preference is nonzero.
        if not on_internal and actual_root.startswith("/media/hdd/"):
            return
        internal_policy = (on_internal and (
            int(cfg.get("flash_image_limit", 20) or 0) > 0 or
            int(cfg.get("flash_min_free_mb", 30) or 0) > 0
        ))
        age_policy = int(cfg.get("retention_days", 0) or 0) > 0
        if not (internal_policy or age_policy):
            return
    except Exception:
        return
    _cleanup_count[0] += 1
    # Internal flash keeps a tight LRU cap, so trim after each successful image.
    # HDD/USB age cleanup remains batched to avoid unnecessary disk walks.
    threshold = 1 if internal_policy else CLEANUP_EVERY_SUCCESSES
    if _cleanup_count[0] < threshold or _cleanup_running[0]:
        return
    _cleanup_count[0] = 0
    _cleanup_running[0] = True

    def worker():
        try:
            cleanup_cache()
        except Exception:
            pass
        finally:
            _cleanup_running[0] = False

    thread = threading.Thread(target=worker, name="TiviMateArtworkCleanup")
    thread.daemon = True
    thread.start()


def _notify(callbacks, path):
    for callback in list(callbacks or []):
        try:
            callback(path)
        except Exception:
            # A screen may legitimately have closed while an artwork transfer was
            # queued.  One dead callback must not affect another screen/job.
            pass


def _schedule_notify(callbacks, path, delay_ms):
    """Schedule one UI-thread refresh for a completed local artwork file."""
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    timer = eTimer()
    holder = {"timer": timer, "deliver": lambda: _notify(callbacks, path)}

    def fire():
        try:
            _notify(callbacks, path)
        finally:
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _notify_timers.remove(holder)
            except Exception:
                pass

    try:
        holder["connection"] = timer.timeout.connect(fire)
    except Exception:
        try:
            timer.callback.append(fire)
        except Exception:
            timer.timeout.get().append(fire)
    # The first completed poster notification is NOT optional: dropping it
    # can leave a visible GENRE slot on the default poster permanently. If
    # many images finish together, deliver the oldest callback on the UI thread
    # before releasing its timer, rather than silently discarding it.
    while len(_notify_timers) >= MAX_NOTIFY_TIMERS:
        old = _notify_timers.pop(0)
        try:
            old.get("timer").stop()
        except Exception:
            pass
        try:
            old_callback = old.get("deliver")
            if old_callback:
                old_callback()
        except Exception:
            pass
    _notify_timers.append(holder)
    timer.start(max(1, int(delay_ms)), True)


def _notify_after_write(callbacks, path, delay_ms=90):
    """Deliver each completed download once; decoding owns its own lifecycle.

    Calling the image completion callback twice created two ePicLoad decoders
    for the same picture and inflated transient RAM on slower receivers.
    """
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    _display_sequence[0] += 1
    first_delay = min(60, max(10, int(delay_ms) // 2)) + ((_display_sequence[0] - 1) % 3) * 35
    _schedule_notify(callbacks, path, first_delay)


def _prefetch_key_for_job(job):
    try:
        url = normalise_url((job or {}).get("url") or "")
        kind = str((job or {}).get("kind") or "artwork")
        if not url:
            return None
        return (kind, url.split("?", 1)[0])
    except Exception:
        return None


def _final_job_failure(path, job):
    """Fail one artwork item only; never allow it to stop the queue."""
    _running.pop(path, None)
    _jobs.pop(path, None)
    if path:
        _FAILED_ARTWORK_UNTIL[path] = time.monotonic() + _FAILED_ARTWORK_SECONDS
        if len(_FAILED_ARTWORK_UNTIL) > 256:
            now = time.monotonic()
            for stale, deadline in list(_FAILED_ARTWORK_UNTIL.items()):
                if deadline <= now:
                    _FAILED_ARTWORK_UNTIL.pop(stale, None)
            for stale in list(_FAILED_ARTWORK_UNTIL)[:max(0, len(_FAILED_ARTWORK_UNTIL) - 256)]:
                _FAILED_ARTWORK_UNTIL.pop(stale, None)
    key = _prefetch_key_for_job(job)
    if key is not None:
        try:
            _prefetch_seen.discard(key)
        except Exception:
            pass
    _notify((job or {}).get("errbacks"), path)


def _retry_or_fail(path, job):
    """Retry a failed/stalled transfer once, then skip only that item."""
    if not job:
        _jobs.pop(path, None)
        _start_next()
        return
    _running.pop(path, None)
    try:
        part = job.get("part") or ""
        if part and os.path.exists(part):
            os.remove(part)
    except Exception:
        pass
    tries = int(job.get("attempt", 0) or 0)
    if tries < MAX_JOB_RETRIES:
        job["attempt"] = tries + 1
        job["started"] = 0
        job.pop("deferred", None)
        job.pop("container", None)
        # Keep the failed item near the front, but preserve visible-card priority.
        _pending.append(job)
        _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    else:
        _final_job_failure(path, job)
    _start_next()


def _watchdog_tick():
    """Release stuck artwork slots so the rest of Movies continues loading."""
    now = time.time()
    stalled = []
    for path, job in list(_running.items()):
        try:
            started = float(job.get("started", 0) or 0)
        except Exception:
            started = 0
        if started and (now - started) >= JOB_STALL_SECONDS:
            stalled.append((path, job))
    for path, job in stalled:
        # Remove from running first: any late callback becomes harmless.
        if _running.get(path) is not job:
            continue
        _running.pop(path, None)
        try:
            deferred = job.get("deferred")
            if deferred is not None and hasattr(deferred, "cancel"):
                deferred.cancel()
        except Exception:
            pass
        try:
            container = job.get("container")
            if container is not None and hasattr(container, "kill"):
                container.kill()
        except Exception:
            pass
        _retry_or_fail(path, job)
    if _running or _pending:
        _arm_watchdog()


def _arm_watchdog():
    try:
        timer = _watchdog_timer[0]
        if timer is None:
            timer = eTimer()
            _watchdog_timer[0] = timer
            try:
                timer.timeout.connect(_watchdog_tick)
            except Exception:
                try:
                    timer.callback.append(_watchdog_tick)
                except Exception:
                    timer.timeout.get().append(_watchdog_tick)
        timer.start(WATCHDOG_INTERVAL_MS, True)
    except Exception:
        pass


def _finish(path, status, expected_job=None):
    # Ignore a late completion from a timed-out/cancelled transfer. The same
    # cache path may already belong to its retry; a stale callback must never
    # pop that newer job from _running and stall the artwork queue.
    current = _running.get(path)
    if current is None or (expected_job is not None and current is not expected_job):
        return
    job = _running.pop(path, None)
    if job is None:
        return
    if is_app_exiting():
        _jobs.pop(path, None)
        try:
            if path and os.path.isfile(path): os.remove(path)
        except Exception:
            pass
        return
    try:
        success = int(status) == 0
    except Exception:
        success = False
    if success and _valid(path):
        _FAILED_ARTWORK_UNTIL.pop(path, None)
        _jobs.pop(path, None)
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
        _start_next()
    else:
        _retry_or_fail(path, job)


def _finish_twisted(path, success, expected_job=None):
    # A Deferred cancelled by the watchdog can still deliver a late callback.
    # Only the transfer that currently owns this path is allowed to finish it.
    current = _running.get(path)
    if current is None or (expected_job is not None and current is not expected_job):
        return
    job = _running.pop(path, None)
    if job is None:
        return
    part = job.get("part") or ""
    if is_app_exiting():
        _jobs.pop(path, None)
        for stale in (part, path):
            try:
                if stale and os.path.isfile(stale): os.remove(stale)
            except Exception:
                pass
        return
    ok = False
    if success and part:
        try:
            if _valid(part):
                try:
                    os.replace(part, path)
                except AttributeError:
                    if os.path.exists(path):
                        os.remove(path)
                    os.rename(part, path)
                ok = _valid(path)
        except Exception:
            ok = False
    if not ok:
        try:
            if part and os.path.exists(part):
                os.remove(part)
        except Exception:
            pass
    if ok:
        _FAILED_ARTWORK_UNTIL.pop(path, None)
        _jobs.pop(path, None)
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
        _start_next()
    else:
        _retry_or_fail(path, job)


def _start_next():
    if is_app_exiting():
        return
    while len(_running) < MAX_CONCURRENT_DOWNLOADS and _pending:
        job = _pending.pop(0)
        path = job.get("path")
        if not path or path in _running:
            continue
        if _valid(path):
            _jobs.pop(path, None)
            _notify(job.get("callbacks"), path)
            continue
        try:
            if is_app_exiting():
                _jobs.pop(path, None)
                continue
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            if is_app_exiting():
                _jobs.pop(path, None)
                continue

            # Use the exact same Twisted download path that the VOD player uses.
            # This avoids launching a fresh Python interpreter for each poster and
            # keeps the image transfer inside Enigma2's proven async network stack.
            if downloadPage is not None:
                part = path + ".part"
                try:
                    if os.path.exists(part):
                        os.remove(part)
                except Exception:
                    pass
                job["part"] = part
                job["started"] = time.time()
                _running[path] = job
                _arm_watchdog()
                request_url = job["url"].encode("utf-8") if isinstance(job["url"], str) else job["url"]
                d = downloadPage(request_url, part, timeout=7)
                job["deferred"] = d
                d.addCallback(lambda _r, cache_path=path, owner=job: _finish_twisted(cache_path, True, owner))
                d.addErrback(lambda _f, cache_path=path, owner=job: _finish_twisted(cache_path, False, owner))
                continue

            # Compatibility fallback for images without Twisted downloadPage.
            container = eConsoleAppContainer()
            job["container"] = container
            job["started"] = time.time()
            _running[path] = job
            _arm_watchdog()

            def done(status, cache_path=path, owner=job):
                _finish(cache_path, status, owner)

            try:
                container.appClosed.append(done)
            except Exception:
                container.appClosed.get().append(done)
            container.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, IMAGE_FETCH, job["url"], path)
        except Exception:
            _running.pop(path, None)
            try:
                tries = int(job.get("attempt", 0) or 0)
            except Exception:
                tries = MAX_JOB_RETRIES
            if tries < MAX_JOB_RETRIES:
                job["attempt"] = tries + 1
                job["started"] = 0
                _pending.append(job)
                _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
            else:
                _final_job_failure(path, job)


def _request_artwork_core(url, kind="artwork", callback=None, priority=0, errback=None):
    """Use cached artwork immediately or enqueue an asynchronous cache refresh.

    ``callback`` receives the completed local path only after the helper has
    written a valid file.  Duplicate requests share one network transfer while
    every interested widget still receives its own completion callback.
    """
    if is_app_exiting():
        return ""
    url = normalise_url(url)
    if not url:
        return ""
    # Normalise TMDb size before both cache lookup and download, so every page
    # shares exactly the same on-disk poster/backdrop file.
    url, _tmdb_rel = _canonical_tmdb_artwork(url, kind)
    path = cached_artwork(url, kind)
    if path:
        if callback:
            _notify([callback], path)
        return path

    path = artwork_path(url, kind)
    if _FAILED_ARTWORK_UNTIL.get(path, 0.0) > time.monotonic():
        if errback:
            _notify([errback], path)
        return path
    _FAILED_ARTWORK_UNTIL.pop(path, None)
    # A prefetch may have queued this URL at priority 1 before the user
    # selected it.  When the visible widget arrives, promote that existing
    # transfer rather than leaving its callback buried behind unrelated jobs.
    if callback is not None:
        try:
            if _media_cache_kind(kind) == "posters":
                priority = max(int(priority or 0), 120)
        except Exception:
            pass
    job = _jobs.get(path)
    if job is not None:
        if callback:
            callbacks = job.setdefault("callbacks", [])
            callbacks.append(callback)
            if len(callbacks) > MAX_CALLBACKS_PER_JOB:
                del callbacks[:-MAX_CALLBACKS_PER_JOB]
            try:
                if job in _pending and int(priority or 0) > int(job.get("priority") or 0):
                    job["priority"] = int(priority)
                    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
            except Exception:
                pass
        if errback:
            errbacks = job.setdefault("errbacks", [])
            errbacks.append(errback)
            if len(errbacks) > MAX_CALLBACKS_PER_JOB:
                del errbacks[:-MAX_CALLBACKS_PER_JOB]
        return path

    # Visible poster slots are what the user is waiting to see in Movies,
    # TV Shows and Packages.  Give callback-backed poster work a higher queue
    # priority than backdrops and background prefetch without changing cache keys,
    # image quality, decoding, retries, or provider/TMDb fallback behaviour.
    try:
        if callback is not None and _media_cache_kind(kind) == "posters":
            priority = max(int(priority or 0), 120)
    except Exception:
        pass

    _sequence[0] += 1
    job = {
        "url": url,
        "path": path,
        "callbacks": [callback] if callback else [],
        "errbacks": [errback] if errback else [],
        "priority": int(priority or 0),
        "sequence": _sequence[0],
        "kind": kind,
        "attempt": 0,
        "started": 0,
    }
    _jobs[path] = job
    _pending.append(job)
    # Highest priority first, then preserve the visual order for equal priority.
    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    # RAM guard for long browsing sessions: keep active transfers plus only a
    # small window of pending artwork metadata. Prefer current/high-priority and
    # newer jobs; stale jobs will be requested again if they become visible.
    if len(_pending) > MAX_PENDING_DOWNLOADS:
        overflow = len(_pending) - MAX_PENDING_DOWNLOADS
        candidates = sorted(_pending, key=lambda item: (item.get("priority", 0), item.get("sequence", 0)))
        for stale in candidates[:overflow]:
            try:
                _pending.remove(stale)
            except Exception:
                pass
            stale_path = stale.get("path")
            if stale_path and stale_path not in _running:
                _jobs.pop(stale_path, None)
            stale_key = _prefetch_key_for_job(stale)
            if stale_key is not None:
                try:
                    _prefetch_seen.discard(stale_key)
                except Exception:
                    pass
            try:
                stale["callbacks"] = []
                stale["errbacks"] = []
            except Exception:
                pass
    _start_next()
    return path



def _prefetch_tick():
    """Feed bulk prefetch jobs into the normal queue without blocking the UI."""
    if is_app_exiting():
        return
    timer = _prefetch_timer[0]
    try:
        if timer is not None:
            timer.stop()
    except Exception:
        pass
    fed = 0

    # Do not feed background prefetch while visible poster widgets are still
    # waiting.  This uses the existing prefetch timer only; no new hook/timer is
    # added.  As soon as visible poster work drains, prefetch resumes normally.
    try:
        visible_poster_busy = any(
            _media_cache_kind((job or {}).get("kind")) == "posters"
            and bool((job or {}).get("callbacks"))
            for job in list(_running.values()) + list(_pending)
        )
    except Exception:
        visible_poster_busy = False
    # GENRE and all visible poster cards share the bounded Ultra executor.
    # Give those first-paint downloads priority over background prefetch.
    try:
        from .genre_ultra_artwork import pending_count as _ultra_pending
        visible_poster_busy = visible_poster_busy or _ultra_pending() > 0
    except (ImportError, RuntimeError):
        pass
    if visible_poster_busy and _prefetch_pending:
        try:
            if timer is None:
                timer = eTimer()
                _prefetch_timer[0] = timer
                try:
                    timer.timeout.connect(_prefetch_tick)
                except Exception:
                    try:
                        timer.callback.append(_prefetch_tick)
                    except Exception:
                        timer.timeout.get().append(_prefetch_tick)
            timer.start(260, True)
        except Exception:
            pass
        return

    # Leave room for visible/high-priority requests.
    room = max(0, (MAX_PENDING_DOWNLOADS - 12) - len(_pending))
    take = min(_PREFETCH_FEED_SIZE, room, len(_prefetch_pending))
    while take > 0 and _prefetch_pending:
        url, kind, priority, key = _prefetch_pending.pop(0)
        # Queued/running transfers already deduplicate through _jobs; keeping
        # this key after feed would grow RAM with every successful image.
        _prefetch_seen.discard(key)
        try:
            request_artwork(url, kind, None, priority=priority)
        except Exception:
            pass
        fed += 1
        take -= 1
    if _prefetch_pending:
        try:
            if timer is None:
                timer = eTimer()
                _prefetch_timer[0] = timer
                try:
                    timer.timeout.connect(_prefetch_tick)
                except Exception:
                    try:
                        timer.callback.append(_prefetch_tick)
                    except Exception:
                        timer.timeout.get().append(_prefetch_tick)
            timer.start(_PREFETCH_INTERVAL_MS if fed else 700, True)
        except Exception:
            pass


def prefetch_artwork(urls, kind="artwork", priority=1):
    """Cache every supplied URL progressively in the background.

    This is intentionally separate from visible-card rendering.  It only feeds
    a few low-priority jobs at a time, so content/text can paint immediately
    while poster/backdrop cache fills behind it. Duplicate URLs are ignored.
    """
    if is_app_exiting():
        return 0
    added = 0
    scanned = 0
    for raw in (urls or ()):
        if scanned >= MAX_PREFETCH_SCAN or added >= MAX_PREFETCH_PENDING:
            break
        scanned += 1
        url = normalise_url(raw)
        if not url:
            continue
        key = (kind, url.split("?", 1)[0])
        if key in _prefetch_seen:
            continue
        if cached_artwork(url, kind):
            continue  # Disk cache is authoritative; no lifetime RAM set.
        _prefetch_seen.add(key)
        _prefetch_pending.append((url, kind, int(priority or 0), key))
        added += 1
        # Keep only the latest bounded window of low-priority work.  Nothing
        # is deleted from disk; a dropped URL still downloads on demand.
        if len(_prefetch_pending) > MAX_PREFETCH_PENDING:
            _url, _kind, _priority, old_key = _prefetch_pending.pop(0)
            _prefetch_seen.discard(old_key)
    if added:
        _prefetch_tick()
    return added

def queue_status():
    """Return lightweight diagnostics for support logs and unit tests."""
    return {"pending": len(_pending), "running": len(_running), "limit": MAX_CONCURRENT_DOWNLOADS, "pending_limit": MAX_PENDING_DOWNLOADS, "notify_timers": len(_notify_timers), "prefetch_pending": len(_prefetch_pending)}


def cancel_all_artwork():
    """Cancel every queued/in-flight artwork job for application shutdown/exit."""
    set_app_exiting(True)
    # Stop delayed UI notifications too; none may touch artwork after Home exit.
    try:
        for holder in list(_notify_timers):
            try: holder.get("timer").stop()
            except Exception: pass
        _notify_timers[:] = []
    except Exception:
        pass
    try:
        timer = _prefetch_timer[0]
        if timer is not None:
            try: timer.stop()
            except Exception: pass
    except Exception:
        pass
    try:
        _prefetch_pending[:] = []
        _prefetch_seen.clear()
    except Exception:
        pass
    try:
        timer = _watchdog_timer[0]
        if timer is not None:
            try: timer.stop()
            except Exception: pass
    except Exception:
        pass
    try:
        for path, job in list(_running.items()):
            try:
                d = job.get("deferred")
                if d is not None and hasattr(d, "cancel"):
                    d.cancel()
            except Exception:
                pass
            try:
                c = job.get("container")
                if c is not None and hasattr(c, "kill"):
                    c.kill()
            except Exception:
                pass
            for temp_key in ("part",):
                try:
                    tp = job.get(temp_key)
                    if tp and os.path.isfile(tp): os.remove(tp)
                except Exception:
                    pass
            try:
                job["callbacks"] = []
                job["errbacks"] = []
            except Exception:
                pass
        _running.clear()
        _pending[:] = []
        _jobs.clear()
        _FAILED_ARTWORK_UNTIL.clear()
    except Exception:
        pass


# Media-family dispatch. Every screen (including legacy UI parts, GENRE,
# ContentHome, movie details, player and favourites) already calls this API.
# Keep transport/cancellation/prefetch shared; move media policies to managers.
def _media_manager(kind):
    family = _media_cache_kind(kind)
    if family == "posters":
        from . import poster_manager
        return poster_manager
    if family == "backdrops":
        from . import backdrop_manager
        return backdrop_manager
    if family == "logos":
        from . import logo_manager
        return logo_manager
    return None


def cached_artwork(url, kind="artwork"):
    manager = _media_manager(kind)
    if manager is not None:
        return manager.cached(url)
    return _cached_artwork_core(url, kind)


def request_artwork(url, kind="artwork", callback=None, priority=0, errback=None):
    manager = _media_manager(kind)
    if manager is not None:
        return manager.request(url, callback=callback, priority=priority, errback=errback)
    return _request_artwork_core(url, kind, callback=callback, priority=priority, errback=errback)
