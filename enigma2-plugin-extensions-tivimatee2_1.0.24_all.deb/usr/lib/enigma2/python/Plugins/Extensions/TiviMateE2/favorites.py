# -*- coding: utf-8 -*-
"""Persistent, source-scoped favourites for TiviMate E2.

The store intentionally keeps only a hash of the configured source identity.  A
favourite therefore remains associated with its server without duplicating the
source URL, account name, or password into this file.
"""
from .storage import data_path, favorites_path

import hashlib
import io
import json
import os
import time
import threading
from functools import wraps

from .filters import source_filter_key

# This is user data, not disposable artwork/cache.  Keep it next to the
# persistent live-package marker on HDD, USB or the receiver's internal flash.
FAVORITES_FILE = favorites_path("favorites.json")
FAVORITES_VERSION = 1
_STORE_LOCK = threading.RLock()


def _store_path():
    # Resolve an inserted/removed HDD at use time, rather than pinning a
    # volatile /var/tmp location at plugin import time.
    return favorites_path("favorites.json")


def _legacy_paths(target):
    """Known old cache locations; read only. Never erase the original file."""
    candidates = [
        data_path("favorites.json"),
        "/etc/enigma2/tivimatee2/favorites.json",
        "/etc/enigma2/tivimatee2_favorites.json",
        "/var/tmp/tivimatee2-cache/favorites.json",
    ]
    for mount in ("/media/hdd", "/media/usb", "/media/usb1", "/media/usb2",
                  "/media/usb3", "/media/mmc", "/media/sdcard"):
        candidates.append(os.path.join(mount, ".tivimatee2-cache", "favorites.json"))
    result = []
    seen = {os.path.realpath(target)}
    for candidate in candidates:
        real = os.path.realpath(candidate)
        if real not in seen and os.path.isfile(candidate):
            seen.add(real)
            result.append(candidate)
    return result


def _read_store(path):
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return None
        items = data.get("items")
        if not isinstance(items, list):
            return None
        return {"version": FAVORITES_VERSION,
                "items": [x for x in items if isinstance(x, dict)],
                "manual_order": bool(data.get("manual_order"))}
    except (OSError, IOError, ValueError, TypeError):
        return None


def _serialised_mutation(fn):
    """Keep GUI and background package adds from overwriting each other."""
    @wraps(fn)
    def wrapped(*args, **kwargs):
        with _STORE_LOCK:
            return fn(*args, **kwargs)
    return wrapped

text_type = str


def _text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8", "ignore")
        except Exception:
            return str(value)
    try:
        return text_type(value)
    except Exception:
        return str(value)


def source_id(source):
    """Return a stable opaque identifier without persisting source credentials."""
    raw = _text(source_filter_key(source or {})).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _item_key(kind, item):
    item = item or {}
    values = []
    for key in ("stream_id", "series_id", "vod_id", "id", "url", "cmd", "name", "title"):
        value = item.get(key)
        if value is not None and _text(value).strip():
            values.append("%s=%s" % (key, _text(value).strip()))
            break
    raw = "%s|%s" % (_text(kind).lower(), "|".join(values))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _snapshot(item):
    """Keep fields needed for display and standard playback only.

    No server configuration is copied into a favourite record.  The selected
    server is resolved again from the normal source configuration at playback.
    """
    item = item or {}
    allowed = (
        "stream_id", "series_id", "vod_id", "id", "name", "title",
        "container_extension", "stream_icon", "cover", "cover_big",
        "movie_image", "backdrop", "backdrop_path", "backdrop_url",
        "category_id", "category_name", "group", "group-title",
        "rating", "rating_5based", "year", "releaseDate", "releasedate",
        "plot", "description", "genre", "tmdb_id", "added", "cmd",
        "url", "epg_channel_id", "tvg_id", "epg_id", "channel_id",
        "_genre_favorite", "_genre_index", "_genre_kind", "_genre_mode"
    )
    result = {}
    for key in allowed:
        value = item.get(key)
        if value is None:
            continue
        if isinstance(value, (dict, list, tuple)):
            # Nested provider metadata is not required to restore an item.
            continue
        result[key] = _text(value)
    return result


def _empty():
    return {"version": FAVORITES_VERSION, "items": [], "manual_order": False}


def _load():
    with _STORE_LOCK:
        target = _store_path()
        if os.path.exists(target):
            # A damaged present file is not a signal to reimport stale
            # favourites (which could undo intentional removals).
            return _read_store(target) or _empty()
        # One-time copy-forward from the old cache location. Merge old stores
        # safely so a USB/HDD migration doesn't discard existing channels.
        combined = _empty()
        seen = set()
        for old_file in _legacy_paths(target):
            source = _read_store(old_file)
            if not source:
                continue
            combined["manual_order"] |= source["manual_order"]
            for record in source["items"]:
                key = record.get("id")
                if not key or key in seen:
                    continue
                seen.add(key)
                combined["items"].append(record)
        if combined["items"]:
            # Never delete an old file, even if a new destination is unwritable.
            _save(combined)
        return combined


def _save(data):
    with _STORE_LOCK:
        path = _store_path()
        temporary = path + ".tmp"
        try:
            # Fail safely if a present user file cannot be parsed: never
            # replace damaged-but-recoverable records with an empty list.
            if os.path.exists(path) and _read_store(path) is None:
                return False
            folder = os.path.dirname(path)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            with io.open(temporary, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, sort_keys=True, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
            return True
        except Exception:
            try:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            except Exception:
                pass
            return False


def favourite_id(source, kind, item):
    return "%s:%s:%s" % (source_id(source), _text(kind).lower(), _item_key(kind, item))


def is_favourite(source, kind, item):
    target = favourite_id(source, kind, item)
    return any(record.get("id") == target for record in _load().get("items", []))


def list_favourites(kind=None):
    data = _load()
    records = list(data.get("items", []))
    if not data.get("manual_order"):
        records.sort(key=lambda record: int(record.get("saved_at") or 0), reverse=True)
    if kind:
        records = [record for record in records if record.get("kind") == _text(kind).lower()]
    return records


@_serialised_mutation
def save_manual_order(record_ids):
    """Persist the visible Favorite order without copying source credentials."""
    data = _load()
    by_id = {record.get("id"): record for record in data.get("items", []) if record.get("id")}
    ordered = []
    seen = set()
    for record_id in record_ids or []:
        record = by_id.get(record_id)
        if record is not None and record_id not in seen:
            ordered.append(record); seen.add(record_id)
    # Keep records outside the current filter in their existing relative order.
    for record in data.get("items", []):
        record_id = record.get("id")
        if record_id not in seen:
            ordered.append(record); seen.add(record_id)
    data["items"] = ordered
    data["manual_order"] = True
    return _save(data)


@_serialised_mutation
def add_favourite(source, kind, item):
    if not isinstance(item, dict):
        return False
    kind = _text(kind).lower().strip()
    if kind not in ("live", "vod", "series"):
        return False
    data = _load()
    record_id = favourite_id(source, kind, item)
    existing = [record for record in data["items"] if record.get("id") != record_id]
    snapshot = _snapshot(item)
    # Xtream and Stalker rebuild a stream URL from the normal source at playback.
    # Only M3U rows need their item URL retained to remain playable.
    if (source or {}).get("type") != "m3u":
        snapshot.pop("url", None)
    title = snapshot.get("name") or snapshot.get("title") or "IPTV"
    existing.append({
        "id": record_id,
        "source_id": source_id(source),
        "kind": kind,
        "title": title,
        "saved_at": int(time.time()),
        "item": snapshot,
    })
    data["items"] = existing
    return _save(data)


@_serialised_mutation
def add_favourites(source, kind, items):
    """Add many favourites with one atomic store write. Returns (added_ids, saved)."""
    kind = _text(kind).lower().strip()
    if kind not in ("live", "vod", "series"):
        return [], False
    data = _load()
    existing_ids = set(record.get("id") for record in data.get("items", []) if record.get("id"))
    added_ids = []
    for item in (items or []):
        if not isinstance(item, dict):
            continue
        record_id = favourite_id(source, kind, item)
        if not record_id or record_id in existing_ids:
            continue
        snapshot = _snapshot(item)
        if (source or {}).get("type") != "m3u":
            snapshot.pop("url", None)
        title = snapshot.get("name") or snapshot.get("title") or "IPTV"
        data["items"].append({
            "id": record_id, "source_id": source_id(source), "kind": kind,
            "title": title, "saved_at": int(time.time()), "item": snapshot,
        })
        existing_ids.add(record_id)
        added_ids.append(record_id)
    if not added_ids:
        return [], True
    return added_ids, _save(data)


@_serialised_mutation
def remove_favourite(source, kind, item):
    data = _load()
    record_id = favourite_id(source, kind, item)
    original_count = len(data["items"])
    data["items"] = [record for record in data["items"] if record.get("id") != record_id]
    if len(data["items"]) == original_count:
        return True
    return _save(data)


@_serialised_mutation
def toggle_favourite(source, kind, item):
    if is_favourite(source, kind, item):
        return False, remove_favourite(source, kind, item)
    return True, add_favourite(source, kind, item)


@_serialised_mutation
def remove_record(record_id):
    """Remove a saved row even when the original source has been deleted."""
    data = _load()
    original_count = len(data["items"])
    data["items"] = [record for record in data["items"] if record.get("id") != record_id]
    if len(data["items"]) == original_count:
        return True
    return _save(data)


@_serialised_mutation
def clear_favourites(kind=None):
    """Clear Favorites for one media kind, or all kinds when kind is empty."""
    data = _load()
    wanted = _text(kind).lower().strip() if kind else ""
    if wanted:
        data["items"] = [record for record in data.get("items", []) if record.get("kind") != wanted]
    else:
        data["items"] = []
    return _save(data)


def source_for_record(record, sources):
    wanted = (record or {}).get("source_id", "")
    for source in (sources or []):
        try:
            if source_id(source) == wanted:
                return source
        except Exception:
            pass
    return None


def count():
    return len(_load().get("items", []))
