# -*- coding: utf-8 -*-
"""Language-aware transparent TMDb title logos for every Enigma2 screen.

Use the selected TMDb metadata language, not the device interface language.
Images are selected by TMDb's real iso_639_1 tag; no image translation.
All remote lookups in this module must run on an existing background worker.
"""
from . import artwork_queue as _queue

KIND = "logos"
PROVIDER_KEYS = ("logo", "title_logo", "logo_path", "clearlogo")
RASTER = (".png", ".jpg", ".jpeg", ".webp")


def provider_logo_url(source, item, extra=None):
    return _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)


def tmdb_logo_url(value, size="original"):
    value = str(value or "").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/%s" % size + value
    return value if value.startswith(("https://", "http://")) else ""


def logo_language(client=None):
    """Resolve locale from TMDb Settings (including Auto) to ISO-639-1."""
    if client is None:
        from .tmdb_client import TMDbClient
        client = TMDbClient()
    return str(getattr(client, "language", "en-US") or "en-US").split("-")[0].split("_")[0].strip().lower() or "en"


def image_languages(client=None):
    """Only fetch selected-language, English and language-neutral TMDb images."""
    selected = logo_language(client)
    return ",".join(dict.fromkeys((selected, "en", "null")))


def _valid_logos(entries):
    return [row for row in (entries or []) if isinstance(row, dict) and
            str(row.get("file_path") or "").lower().split("?")[0].endswith(RASTER)]


def has_language_logo(entries, language=None):
    selected = str(language or "en").split("-")[0].lower()
    return any(str(row.get("iso_639_1") or "").lower() == selected
               for row in _valid_logos(entries))


def best_tmdb_logo(entries, language="en"):
    """Requested language first; English second; neutral third; other last.

    For old calls, keep a plain image path result compatible with earlier builds.
    TMDb `null` is language-neutral, not evidence of translated lettering.
    """
    selected = str(language or "en").split("-")[0].lower()
    def score(row):
        lang = str(row.get("iso_639_1") or "").lower()
        rank = 4 if lang == selected else 3 if lang == "en" else 2 if not lang else 1
        try:
            votes = float(row.get("vote_average") or 0)
        except (ValueError, TypeError):
            votes = 0.0
        try:
            width = int(row.get("width") or 0)
        except (ValueError, TypeError):
            width = 0
        return (rank, votes, width)
    rows = _valid_logos(entries)
    return max(rows, key=score).get("file_path") if rows else ""


def localized_logo_url(client, media, tmdb_id, images=None, size="w500"):
    """Return a genuine matching-language logo, then a safe fallback.

    The metadata bundle can be cached with only English logos. Fetch a small
    images-only payload in the *background* before accepting that fallback.
    This avoids English dominating Arabic/French/Turkish selected logos.
    """
    wanted = logo_language(client)
    previous = _valid_logos(((images or {}).get("logos") or []) if isinstance(images, dict) else images)
    if has_language_logo(previous, wanted):
        return tmdb_logo_url(best_tmdb_logo(previous, wanted), size)
    media = "tv" if str(media or "").lower() in ("tv", "series") else "movie"
    try:
        if int(str(tmdb_id or "0").strip()) > 0 and client.configured():
            payload = client._get("/%s/%s/images" % (media, tmdb_id), {
                "include_image_language": image_languages(client)
            }) or {}
            more = _valid_logos(payload.get("logos") or [])
            if more:
                previous.extend(more)
    except Exception:
        pass
    return tmdb_logo_url(best_tmdb_logo(previous, wanted), size)


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None):
    return _queue._request_artwork_core(url, KIND, callback, priority, errback)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
