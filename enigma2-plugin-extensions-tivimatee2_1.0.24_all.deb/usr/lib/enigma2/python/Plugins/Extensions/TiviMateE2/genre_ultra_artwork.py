# -*- coding: utf-8 -*-
"""GENRE-only first-paint downloader adapted from UltraStalker's provider path.

The rest of TiviMateE2 still uses artwork_queue. The shared cache layout is
unchanged, so completed artwork remains reusable by the other pages.  Work
that touches the network or image codecs runs in a bounded executor.
"""
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit, quote, unquote, urlunsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
import hashlib
import os
import tempfile
import threading
import time

from .artwork_queue import artwork_path, cached_artwork, normalise_url

_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix="TiviGenreUltraArtwork")
_LOCK = threading.RLock()
_PENDING = {}
_FAILURES = {}
_FAILED_TTL = 25.0
_MAX_IN_FLIGHT = 48
_GENERIC_UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG250 stbapp"


def _origin(url):
    try:
        s = urlsplit(url or "")
        if s.scheme.lower() not in ("http", "https") or not s.hostname:
            return None
        return (s.scheme.lower(), s.hostname.lower(), s.port or (443 if s.scheme.lower() == "https" else 80))
    except (ValueError, TypeError):
        return None


def _clean_url(url):
    """Match Ultra's URL quoting while preserving signed CDN query values."""
    url = normalise_url(url)
    if len(url) > 1 and url[0] == url[-1] and url[0] in ('"', "'"):
        url = url[1:-1].strip()
    parts = urlsplit(url)
    if _origin(url) is None:
        return ""
    path = quote(unquote(parts.path), safe="/:@-._~!$&'()*+,;=")
    query = quote(unquote(parts.query), safe="=&:@/?-._~!$'()*+,;")
    return urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))


def _headers(url, source):
    source = source or {}
    base = str(source.get("url") or source.get("portal") or source.get("base_url") or "").strip()
    headers = {"User-Agent": _GENERIC_UA, "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8", "Connection": "close"}
    if _origin(base):
        root = urlsplit(base)
        headers["Referer"] = "%s://%s/" % (root.scheme, root.netloc)
    # MAG secrets must never be sent to sibling CDNs or TMDb.
    if _origin(url) == _origin(base) and str(source.get("type") or "").lower() == "stalker":
        mac = str(source.get("mac") or "").strip()
        if mac:
            headers["Cookie"] = "mac=%s; stb_lang=en" % quote(mac, safe="")
            headers["X-User-Agent"] = "Model: MAG250; Link: WiFi"
        try:
            # Reuse established session/token headers only for exact origin.
            from .core import get_source_client
            client = get_source_client(source)
            if callable(getattr(client, "headers", None)):
                identity = client.headers() or {}
                for k, v in identity.items():
                    if k.lower() in ("cookie", "authorization", "x-user-agent", "user-agent", "referer"):
                        headers[k] = str(v)
                headers.pop("Host", None)
        except Exception:
            pass
    return headers


class _ProtectedRedirect(HTTPRedirectHandler):
    """Ultra's provider redirect policy: don't forward MAC/token cross-host."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        redirected = super(_ProtectedRedirect, self).redirect_request(req, fp, code, msg, headers, newurl)
        if redirected is not None and _origin(req.full_url) != _origin(newurl):
            for key in ("Cookie", "Authorization", "X-User-Agent", "Host"):
                redirected.remove_header(key)
                redirected.headers.pop(key, None)
                redirected.unredirected_hdrs.pop(key, None)
        return redirected


def _valid_file(path):
    try:
        return bool(path and os.path.getsize(path) >= 64 and os.path.isfile(path))
    except OSError:
        return False


def _format(head):
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:2] == b"BM":
        return "bmp"
    return ""


def _convert_if_needed(temp, dest, fmt):
    if fmt in ("jpeg", "png"):
        os.replace(temp, dest)
        return
    try:
        from PIL import Image
        with Image.open(temp) as image:
            image.seek(0)
            image.convert("RGB").save(dest, "JPEG", quality=94)
        return
    except (ImportError, OSError, ValueError):
        pass
    # Enigma2 images without Pillow can still have ffmpeg installed.
    from .image_fetch import convert_to_jpeg
    if not convert_to_jpeg(temp, dest):
        raise ValueError("no usable image decoder for %s" % fmt)


def _download(url, kind, source):
    # Ultra's path: persistent local hit -> short network request -> validated
    # and normalized original. No image work on the main Enigma2 thread.
    existing = cached_artwork(url, kind)
    if existing:
        return existing
    target = artwork_path(url, kind)
    if not target:
        return ""
    os.makedirs(os.path.dirname(target), exist_ok=True)
    temp = None
    normalized = None
    try:
        fd, temp = tempfile.mkstemp(prefix=".genre_art_", suffix=".part", dir=os.path.dirname(target))
        cap = 12 * 1024 * 1024 if kind == "backdrops" else 6 * 1024 * 1024
        opener = build_opener(_ProtectedRedirect())
        request = Request(url, headers=_headers(url, source))
        total = 0
        head = b""
        with os.fdopen(fd, "wb") as sink, opener.open(request, timeout=3.5) as response:
            status = getattr(response, "status", 200)
            if status and int(status) >= 400:
                raise IOError("HTTP %s" % status)
            while True:
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                if not head:
                    head = chunk[:24]
                total += len(chunk)
                if total > cap:
                    raise ValueError("provider image exceeds limit")
                sink.write(chunk)
        fmt = _format(head)
        if total < 64 or not fmt:
            raise ValueError("invalid image bytes")
        if cached_artwork(url, kind):
            return cached_artwork(url, kind)
        # Validate decoded formats *before* publishing them to the cache.
        if fmt in ("webp", "gif", "bmp"):
            normalized = target + ".converted.%d" % threading.get_ident()
            _convert_if_needed(temp, normalized, fmt)
            os.replace(normalized, target)
        else:
            os.replace(temp, target)
        return cached_artwork(url, kind) or (target if _valid_file(target) else "")
    finally:
        for stale in (temp, normalized):
            if stale:
                try:
                    os.unlink(stale)
                except OSError:
                    pass


def _trace(url, kind, exc):
    # Never record credentials, URL query strings, or a raw portal address.
    try:
        key = hashlib.sha1(url.encode("utf-8", "ignore")).hexdigest()[:12]
        msg = "%s %s %s %s\n" % (time.strftime("%H:%M:%S"), kind, key,
                                    str(exc.__class__.__name__))
        log_path = "/tmp/tivimate_genre_artwork.log"
        try:
            if os.path.getsize(log_path) > 512 * 1024:
                os.unlink(log_path)
        except OSError:
            pass
        with open(log_path, "a") as f:
            f.write(msg)
    except Exception:
        pass



# A title logo is not a backdrop.  Ultra's JPEG conversion is correct for
# posters but destroys transparent writing on PNG/WebP title logos.  Keep the
# original logo file and an independent, tiny repair queue.  Cached genuine
# PNG logos appear instantly and never contend with visible poster downloads.
_LOGO_POOL = ThreadPoolExecutor(max_workers=3, thread_name_prefix="TiviGenreClearlogo")
_LOGO_PENDING = {}
_LOGO_RETRY_AT = {}


def _logo_cache_usable(path, url):
    if not path or not os.path.isfile(path):
        return False
    try:
        with open(path, "rb") as f:
            header = f.read(32)
        path_ext = urlsplit(url).path.lower().rsplit(".", 1)[-1]
        # Only clear alpha-bearing PNGs are acceptable for title logos.
        # Previous Ultra conversions sometimes left opaque PNG/JPEG banners
        # in this cache, which could render as ugly background rectangles.
        if not header.startswith(b"\x89PNG\r\n\x1a\n"):
            return False
        # Pillow is already needed for precise, aspect-preserving presentation.
        # On receivers without Pillow, a real transparent PNG still starts as
        # a valid input, but the renderer safely falls back to plain title text.
        try:
            from PIL import Image
            with Image.open(path) as logo:
                if logo.width < 4 or logo.height < 4:
                    return False
                alpha = logo.convert("RGBA").getchannel("A")
                low, high = alpha.getextrema()
                return low < 255 and high > 0
        except ImportError:
            # Enigma2 images do not always include Pillow. Indexed PNGs with
            # a tRNS palette entry carry genuine alpha too (colour type 3);
            # the previous check rejected ALL of them and hid title logos.
            if len(header) < 26:
                return False
            colour_type = header[25]
            if colour_type in (4, 6):
                return True
            if colour_type not in (0, 2, 3):
                return False
            try:
                # PNG chunks start after the 8-byte signature. Inspect at
                # most 128 KiB of metadata, never decompress image pixels.
                with open(path, "rb") as src:
                    src.seek(8)
                    scanned = 8
                    while scanned < 131072:
                        prefix = src.read(8)
                        if len(prefix) != 8:
                            break
                        length = int.from_bytes(prefix[:4], "big")
                        name = prefix[4:]
                        if length > 131072 or scanned + length + 12 > 131072:
                            break
                        if name == b"tRNS":
                            return length > 0
                        if name in (b"IDAT", b"IEND"):
                            break
                        src.seek(length + 4, 1)  # payload + CRC
                        scanned += length + 12
            except (OSError, ValueError):
                pass
            return False
        except (OSError, ValueError):
            return False
    except (OSError, ValueError):
        return False


def _download_transparent_logo(url, source):
    from urllib.request import Request
    path = artwork_path(url, "logos")
    if _logo_cache_usable(cached_artwork(url, "logos"), url):
        return path
    if not path:
        return ""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temp = None
    converted = None
    try:
        fd, temp = tempfile.mkstemp(prefix=".genre_logo_", suffix=".part", dir=os.path.dirname(path))
        opener = build_opener(_ProtectedRedirect())
        url_headers = _headers(url, source)
        url_headers["Accept"] = "image/png,image/webp,image/*;q=0.8"
        total = 0
        head = b""
        with os.fdopen(fd, "wb") as sink, opener.open(Request(url, headers=url_headers), timeout=4.0) as response:
            while True:
                chunk = response.read(65536)
                if not chunk:
                    break
                if not head:
                    head = chunk[:32]
                total += len(chunk)
                if total > 4 * 1024 * 1024:
                    raise ValueError("title logo exceeds 4 MB")
                sink.write(chunk)
        fmt = _format(head)
        ext = urlsplit(url).path.lower().rsplit(".", 1)[-1]
        if total < 64 or not fmt:
            raise ValueError("invalid title logo")
        if fmt == "png":
            clean = temp
        elif fmt == "webp":
            converted = path + ".rgba.%d.png" % threading.get_ident()
            try:
                from PIL import Image
                with Image.open(temp) as im:
                    im.seek(0)
                    im.convert("RGBA").save(converted, "PNG")
            except (ImportError, OSError, ValueError):
                import shutil
                import subprocess
                ffmpeg = shutil.which("ffmpeg")
                if not ffmpeg:
                    raise ValueError("transparent WebP logo decoder unavailable")
                subprocess.run([ffmpeg, "-loglevel", "error", "-y", "-i", temp,
                                "-frames:v", "1", "-pix_fmt", "rgba", "-f", "image2",
                                "-vcodec", "png", converted], check=True, timeout=8,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            clean = converted
        elif fmt == "jpeg" and ext in ("jpg", "jpeg"):
            clean = temp  # Genuine JPEG source; never synthesize a false alpha.
        else:
            raise ValueError("non-transparent result for transparent title logo")
        if os.path.getsize(clean) < 64:
            raise ValueError("empty converted title logo")
        # Atomic per-file repair; leave all posters, backdrops, other logos,
        # HDD/USB data and older cache records entirely untouched.
        os.replace(clean, path)
        return path if _logo_cache_usable(path, url) else ""
    finally:
        for candidate in (temp, converted):
            if candidate:
                try:
                    os.unlink(candidate)
                except OSError:
                    pass


def request_transparent_logo(url, source, ready, failed, gui):
    """Preserve old clearlogo transparency while Ultra handles posters quickly."""
    url = _clean_url(url)
    if not url:
        gui(failed, "")
        return
    cached = cached_artwork(url, "logos")
    if _logo_cache_usable(cached, url):
        gui(ready, cached)
        return
    with _LOCK:
        if len(_LOGO_RETRY_AT) > 128:
            now = time.monotonic()
            _LOGO_RETRY_AT.update((key, until) for key, until in _LOGO_RETRY_AT.items() if until > now)
            if len(_LOGO_RETRY_AT) > 128:
                for old in list(_LOGO_RETRY_AT)[:64]:
                    _LOGO_RETRY_AT.pop(old, None)
        if _LOGO_RETRY_AT.get(url, 0.0) > time.monotonic():
            gui(failed, "")
            return
        if url in _LOGO_PENDING:
            if len(_LOGO_PENDING[url]) < 24:
                _LOGO_PENDING[url].append((ready, failed, gui))
            return
        if len(_LOGO_PENDING) >= 24:
            gui(failed, "")
            return
        _LOGO_PENDING[url] = [(ready, failed, gui)]

    def worker():
        path = ""
        try:
            path = _download_transparent_logo(url, source)
        except Exception as exc:
            _trace(url, "transparent-logo", exc)
            with _LOCK:
                _LOGO_RETRY_AT[url] = time.monotonic() + 35
        if not path:
            # Do not re-fetch a source that only returns opaque/missing art
            # every time the user scrolls past the same title.
            with _LOCK:
                _LOGO_RETRY_AT[url] = time.monotonic() + 60
        with _LOCK:
            callbacks = _LOGO_PENDING.pop(url, [])
        for ok, fail, invoke in callbacks:
            try:
                invoke(ok if path else fail, path)
            except Exception:
                pass
    try:
        _LOGO_POOL.submit(worker)
    except RuntimeError:
        with _LOCK:
            _LOGO_PENDING.pop(url, None)
        gui(failed, "")


def pending_count():
    """Number of active/queued Ultra artwork jobs (no file paths exposed)."""
    with _LOCK:
        return len(_PENDING)


def request(url, kind, source, ready, failed, gui):
    """Send callbacks to the GUI thread and merge simultaneous URL requests."""
    url = _clean_url(url)
    if not url:
        gui(failed, "")
        return
    cached = cached_artwork(url, kind)
    if cached:
        gui(ready, cached)
        return
    key = (url, kind)
    with _LOCK:
        if _FAILURES.get(key, 0) > time.monotonic():
            gui(failed, "")
            return
        if key in _PENDING:
            if len(_PENDING[key]) < 40:
                _PENDING[key].append((ready, failed, gui))
            return
        if len(_FAILURES) > 256:
            now = time.monotonic()
            for old_key, expiry in list(_FAILURES.items()):
                if expiry < now:
                    _FAILURES.pop(old_key, None)
            if len(_FAILURES) > 256:
                for old_key in list(_FAILURES)[:64]:
                    _FAILURES.pop(old_key, None)
        if len(_PENDING) >= _MAX_IN_FLIGHT:
            gui(failed, "")
            return
        _PENDING[key] = [(ready, failed, gui)]

    def worker():
        path = ""
        try:
            path = _download(url, kind, source)
            if not path:
                raise ValueError("no validated artwork")
        except Exception as exc:
            _trace(url, kind, exc)
            with _LOCK:
                _FAILURES[key] = time.monotonic() + _FAILED_TTL
        with _LOCK:
            callbacks = _PENDING.pop(key, [])
        for ok, fail, invoke in callbacks:
            try:
                invoke(ok if path else fail, path)
            except Exception:
                pass
    try:
        _POOL.submit(worker)
    except RuntimeError:
        with _LOCK:
            _PENDING.pop(key, None)
        gui(failed, "")
