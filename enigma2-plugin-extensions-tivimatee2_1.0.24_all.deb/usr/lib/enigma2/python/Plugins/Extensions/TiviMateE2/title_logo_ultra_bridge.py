# -*- coding: utf-8 -*-
"""Identity-safe title logos, adapted from UltraStalker title_logo_ultra.

Worker-thread only. Shared across GENRE, movie/series details, packages and
preview hero. Never changes the poster or backdrop pipeline.
"""
import hashlib
import json
import os
import re
import shutil
import tempfile
import threading
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError

from .cache_manager import get_cache_dir
from .genre_ultra_artwork import _download_transparent_logo, _logo_cache_usable
from .logo_manager import tmdb_logo_url, logo_language

_LOCKS = [threading.Lock() for _ in range(24)]
_ARAB_COUNTRIES = frozenset(('AE', 'SA', 'EG', 'BH', 'QA', 'OM', 'KW', 'IQ', 'JO', 'LB',
                             'SY', 'PS', 'YE', 'MA', 'DZ', 'TN', 'LY', 'SD'))


def _media(kind):
    return 'tv' if str(kind).lower() in ('series', 'tv', 'episode') else 'movie'


def _valid_id(value):
    try:
        number = int(str(value or '').strip())
        return str(number) if number > 0 else ''
    except (ValueError, TypeError):
        return ''


def _origin_lang(item, details, title, requested):
    # Ultra's original-language policy; do not infer a dubbed title's language
    # if canonical metadata already establishes the original language.
    row = details if isinstance(details, dict) else {}
    item = item if isinstance(item, dict) else {}
    original = str(row.get('original_language') or item.get('original_language') or '').split('-')[0].lower()
    countries = row.get('origin_country') or row.get('production_countries') or item.get('origin_country') or []
    if isinstance(countries, str):
        countries = [countries]
    codes = set()
    for obj in countries if isinstance(countries, (list, tuple)) else []:
        if isinstance(obj, dict):
            obj = obj.get('iso_3166_1') or ''
        codes.add(str(obj).upper())
    arabic = original == 'ar' or (not original and bool(codes & _ARAB_COUNTRIES))
    if not original and not codes and re.search('[\u0600-\u06FF]', title or ''):
        arabic = True
    selected = str(requested or 'en').split('-')[0].lower()
    if arabic:
        return ('ar', 'en')
    if selected not in ('ar', 'en', ''):
        return (selected, 'en')
    return ('en',)


def _cache_path(kind, ident, lang, canvas):
    w, h = int(canvas[0]), int(canvas[1])
    folder = os.path.join(get_cache_dir('logos'), 'identity_ultra_v1')
    return os.path.join(folder, '%s_%s_%s_%sx%s.png' % (_media(kind), ident, lang, w, h))


def _copy_preserving_alpha(source, destination, canvas):
    """Like Ultra's master canvas; do not stretch transparent lettering."""
    os.makedirs(os.path.dirname(destination), exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.logo_', suffix='.png', dir=os.path.dirname(destination))
    os.close(fd)
    try:
        try:
            from PIL import Image
            with Image.open(source) as image:
                if image.width < 4 or image.height < 4 or image.width * image.height > 6000000:
                    return ''
                frame = image.convert('RGBA')
                lo, hi = frame.getchannel('A').getextrema()
                if lo >= 255 or hi <= 0:
                    return ''
                w, h = [int(x) for x in canvas]
                maxw, maxh = max(1, w - 18), max(1, h - 8)
                frame.thumbnail((maxw, maxh), Image.Resampling.LANCZOS if hasattr(Image, 'Resampling') else Image.LANCZOS)
                result = Image.new('RGBA', (w, h), (0, 0, 0, 0))
                result.alpha_composite(frame, ((w-frame.width)//2, (h-frame.height)//2))
                result.save(temp, 'PNG')
        except ImportError:
            # Enigma2 without Pillow: prefer receiver ffmpeg to keep transparent
            # aspect-fit, otherwise keep genuine PNG alpha bytes unchanged.
            import subprocess
            from shutil import which
            ffmpeg = which('ffmpeg')
            if ffmpeg:
                w, h = [int(x) for x in canvas]
                filt = ('scale=%s:%s:force_original_aspect_ratio=decrease,'
                        'pad=%s:%s:(ow-iw)/2:(oh-ih)/2:color=black@0' %
                        (max(1, w-18), max(1, h-8), w, h))
                try:
                    subprocess.run([ffmpeg, '-v', 'error', '-y', '-i', source,
                                    '-vf', filt, '-frames:v', '1', '-pix_fmt', 'rgba',
                                    '-update', '1', temp], stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, check=True, timeout=6)
                except (OSError, subprocess.SubprocessError):
                    shutil.copyfile(source, temp)
            else:
                shutil.copyfile(source, temp)
        if not _logo_cache_usable(temp, 'logo.png'):
            return ''
        os.replace(temp, destination)
        return destination
    finally:
        try:
            os.unlink(temp)
        except OSError:
            pass


def _ranking(row):
    try:
        vote = float(row.get('vote_average') or 0)
    except (ValueError, TypeError):
        vote = 0
    try:
        count = int(row.get('vote_count') or 0)
    except (ValueError, TypeError):
        count = 0
    try:
        area = int(row.get('width') or 0) * int(row.get('height') or 0)
    except (ValueError, TypeError):
        area = 0
    return (vote, count, area)


def _tmdb_candidates(client, kind, ident, metadata, languages, cancelled):
    # Include language-neutral artwork; never relabel a foreign image as English.
    logos = list((metadata.get('images') or {}).get('logos') or []) if isinstance(metadata, dict) else []
    if not cancelled():
        try:
            found = client._get('/%s/%s/images' % (_media(kind), ident), {
                'include_image_language': ','.join(dict.fromkeys(tuple(languages) + ('null',)))}) or {}
            logos.extend(found.get('logos') or [])
        except Exception:
            pass
    ranked = {}
    seen = set()
    for entry in logos:
        if not isinstance(entry, dict):
            continue
        uri = tmdb_logo_url(entry.get('file_path'), 'w500')
        if not uri or uri in seen:
            continue
        seen.add(uri)
        lang = str(entry.get('iso_639_1') or '').split('-')[0].lower() or '00'
        ranked.setdefault(lang, []).append((_ranking(entry), uri))
    for k in ranked:
        ranked[k].sort(reverse=True)
    return {key: [url for _, url in rows] for key, rows in ranked.items()}


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _fanart_candidates(client, kind, ident, cancelled):
    # Fanart is strictly optional; no key -> no request and no bogus setting.
    try:
        from .banner_artwork import read_key
        key = read_key()
    except Exception:
        key = ''
    if not key or cancelled():
        return {}
    media = _media(kind)
    media_id = ident
    if media == 'tv':
        try:
            extra = client._get('/tv/%s/external_ids' % ident, {}) or {}
            media_id = _valid_id(extra.get('tvdb_id'))
        except Exception:
            media_id = ''
        if not media_id:
            return {}
    category = 'tv' if media == 'tv' else 'movies'
    base = 'https://webservice.fanart.tv/v3/%s/%s?' % (category, media_id)
    opener = build_opener(_NoRedirect)
    payload = {}
    for auth in ('client_key', 'api_key'):
        if cancelled():
            return {}
        try:
            request = Request(base + urlencode({auth: key}), headers={
                'Accept': 'application/json', 'User-Agent': 'TiviMateE2/UltraLogo'})
            with opener.open(request, timeout=4) as response:
                raw = response.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                return {}
            payload = json.loads(raw.decode('utf-8'))
            break
        except HTTPError as exc:
            if exc.code not in (401, 403):
                return {}
        except Exception:
            return {}
    names = ('hdtvlogo', 'clearlogo', 'tvlogo') if media == 'tv' else ('hdmovielogo', 'movielogo')
    ranked = {}
    for field in names:
        for entry in payload.get(field) or [] if isinstance(payload, dict) else []:
            if not isinstance(entry, dict):
                continue
            url = str(entry.get('url') or '').strip()
            parsed = urlsplit(url)
            # Never send portal credentials or Fanart API credentials to images.
            if parsed.hostname != 'assets.fanart.tv' or parsed.scheme not in ('https', 'http'):
                continue
            if parsed.scheme == 'http':
                url = 'https://' + url.split('://', 1)[1]
            lang = str(entry.get('lang') or '00').lower()
            try:
                score = int(entry.get('likes') or 0)
            except (ValueError, TypeError):
                score = 0
            ranked.setdefault(lang, []).append((score, url))
    for k in ranked:
        ranked[k].sort(reverse=True)
    return {k: [url for _, url in rows] for k, rows in ranked.items()}


def resolve_title_logo(client, kind, tmdb_id, title='', details=None, item=None,
                       canvas=(620, 100), cancelled=None):
    """Return validated, alpha-preserving local PNG or empty string.

    Call ONLY from a background worker. A verified TMDb ID must be supplied by
    the caller; provider stream/series IDs are never accepted as TMDb identity.
    """
    ident = _valid_id(tmdb_id)
    if not ident:
        return ''
    cancelled = cancelled or (lambda: False)
    raw = details if isinstance(details, dict) else {}
    language = logo_language(client)
    # Pure disk-only fast path. The first focus after reopen must not do a
    # metadata request merely to rediscover an already prepared canvas.
    fast_langs = _origin_lang(item, raw, title, language)
    for tag in tuple(fast_langs) + ('00', 'any'):
        stored = _cache_path(kind, ident, tag, canvas)
        if _logo_cache_usable(stored, 'logo.png'):
            return stored
    # Avoid blank logos when TMDb returns only the listing row.
    if not raw.get('original_language') and not cancelled():
        try:
            extra = client._get('/%s/%s' % (_media(kind), ident), {'language': 'en-US'}) or {}
            raw = dict(raw)
            for key in ('original_language', 'origin_country', 'production_countries', 'images'):
                if not raw.get(key) and extra.get(key):
                    raw[key] = extra[key]
        except Exception:
            pass
    langs = _origin_lang(item, raw, title, language)
    lock = _LOCKS[int(hashlib.sha1((_media(kind)+ident).encode('ascii')).hexdigest()[:8], 16) % len(_LOCKS)]
    with lock:
        for lang in tuple(langs) + ('00', 'any'):
            existing = _cache_path(kind, ident, lang, canvas)
            if _logo_cache_usable(existing, 'logo.png'):
                return existing
        if cancelled():
            return ''
        logos = _tmdb_candidates(client, kind, ident, raw, langs, cancelled)
        fanart = None
        budget = 16  # bounded failures cannot create unbounded loading
        for lang in tuple(langs) + ('00', 'any'):
            if cancelled() or budget <= 0:
                return ''
            target = _cache_path(kind, ident, lang, canvas)
            if lang == 'any':
                # Ultra's last-resort gallery query includes foreign-language
                # logos that ar,en,null filters intentionally do not return.
                if not cancelled():
                    try:
                        gallery = client._get('/%s/%s/images' % (_media(kind), ident), {}) or {}
                        for row in gallery.get('logos') or []:
                            if not isinstance(row, dict):
                                continue
                            iso = str(row.get('iso_639_1') or '').split('-')[0].lower()
                            url = tmdb_logo_url(row.get('file_path'), 'w500')
                            if iso and iso not in langs and url:
                                logos.setdefault(iso, []).append(url)
                    except Exception:
                        pass
                urls = [url for tag, rows in logos.items() if tag not in langs and tag != '00' for url in rows[:2]]
            else:
                urls = list(logos.get(lang, []))
            # Ultra policy: per-language TMDb -> Fanart, neutral -> any fallback.
            if lang not in ('00', 'any'):
                urls = urls[:4]
            elif lang == '00':
                urls = urls[:6]
            else:
                urls = urls[:6]
            seen = set()
            def try_urls(values):
                nonlocal budget
                for url in values:
                    if cancelled() or budget <= 0:
                        return ''
                    if not url or url in seen:
                        continue
                    seen.add(url)
                    budget -= 1
                    try:
                        source = _download_transparent_logo(url, {})
                        if source and _logo_cache_usable(source, url):
                            ready = _copy_preserving_alpha(source, target, canvas)
                            if ready:
                                return ready
                    except Exception:
                        continue
                return ''
            result = try_urls(urls)
            if result:
                return result
            if fanart is None and not cancelled():
                fanart = _fanart_candidates(client, kind, ident, cancelled)
            if fanart:
                if lang == 'any':
                    extras = [url for tag, rows in fanart.items() if tag not in langs and tag != '00' for url in rows[:2]]
                else:
                    extras = fanart.get(lang, [])
                result = try_urls(extras[:4])
                if result:
                    return result
        return ''
