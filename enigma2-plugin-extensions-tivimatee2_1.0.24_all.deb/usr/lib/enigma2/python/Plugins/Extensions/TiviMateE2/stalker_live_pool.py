# -*- coding: utf-8 -*-
"""UltraStalker/core/executor.py LazyThreadPoolExecutor, adapted for Live.

Only Stalker channel-link resolution enters this executor.
"""
import threading
from concurrent.futures import ThreadPoolExecutor

class LazyThreadPoolExecutor:
    """Create worker threads only on first submit and shut them down centrally."""
    def __init__(self, max_workers=1, thread_name_prefix="ultrastalker"):
        self.max_workers=max(1,int(max_workers or 1)); self.thread_name_prefix=str(thread_name_prefix or "ultrastalker")
        self._lock=threading.RLock(); self._executor=None; self._shutdown=False; self._tasks={}
    def _ensure(self):
        with self._lock:
            if self._shutdown: raise RuntimeError("executor is shut down")
            if self._executor is None:
                self._executor=ThreadPoolExecutor(max_workers=self.max_workers, thread_name_prefix=self.thread_name_prefix)
            return self._executor
    def submit(self, fn, *args, **kwargs):
        """Submit work, with opt-in keyed duplicate/stale-job control.

        ``_task_key`` returns the already pending/running Future instead of
        queueing identical work. ``_replace_task_key`` cancels an older queued
        Future with the same key and queues the newest request. Running work is
        never force-killed; callers that replace focus jobs already provide
        their own cancellation token and therefore exit cooperatively.
        """
        task_key=kwargs.pop("_task_key",None)
        replace=bool(kwargs.pop("_replace_task_key",False))
        if task_key in (None,""):
            return self._ensure().submit(fn,*args,**kwargs)
        # Lookup, submit and registration happen in ONE critical section so two
        # concurrent callers with the same key can never both run the work.
        with self._lock:
            existing=self._tasks.get(task_key)
            if existing is not None and not existing.done():
                if not replace:return existing
                try:existing.cancel()
                except Exception:pass
            future=self._ensure().submit(fn,*args,**kwargs)
            self._tasks[task_key]=future
            def _forget(done,key=task_key):
                with self._lock:
                    if self._tasks.get(key) is done:self._tasks.pop(key,None)
            future.add_done_callback(_forget)
        return future
    def shutdown(self, wait=False, cancel_futures=True):
        with self._lock:
            self._shutdown=True; ex=self._executor; self._executor=None; self._tasks.clear()
        if ex is None: return
        try: ex.shutdown(wait=bool(wait), cancel_futures=bool(cancel_futures))
        except TypeError: ex.shutdown(wait=bool(wait))
    @property
    def started(self):
        with self._lock: return self._executor is not None


STALKER_LIVE_EXECUTOR = LazyThreadPoolExecutor(max_workers=3, thread_name_prefix="TiviStalkerLive")
