# -*- coding: utf-8 -*-
"""Apply bundled Greta Arabic to TiviMateE2 labels without altering Enigma2 fonts.

OpenATV's skin.reloadSkins() calls enigma.clearFonts().  A registration
made earlier in a plugin import is *not* durable.  Look up the font face at
use time and restore it if the skin font table has been cleared.  Do not use
the global replacement flag (which would affect every Enigma2 screen).
"""

import os
import unicodedata

from Components.Label import Label
from enigma import gFont, eLabel, ePoint, eSize

_FONT_PATH = os.path.join(os.path.dirname(__file__), "skins", "fonts", "Greta.ttf")
_FONT_FACE = "TiviMateGreta"
_registered_without_query = False
_warned = set()


def _warn_once(key, message):
    if key not in _warned:
        _warned.add(key)
        print("[TiviMateE2][Greta] %s" % message)


def _faces():
    """Return the native OpenATV face list; None on older images."""
    try:
        from enigma import getFontFaces
        return getFontFaces()
    except (ImportError, AttributeError, TypeError):
        return None
    except Exception as exc:
        _warn_once("font-list", "Unable to query font faces: %s" % exc)
        return None


def register_greta():
    """Ensure our private alias exists in the current Enigma2 font table.

    Avoid caching a success flag when getFontFaces is supported.  A skin
    reload can invalidate earlier addFont calls without restarting Python.
    """
    global _registered_without_query
    if not os.path.isfile(_FONT_PATH):
        _warn_once("missing", "Font file missing: %s" % _FONT_PATH)
        return False

    faces = _faces()
    if faces is not None and _FONT_FACE in faces:
        return True
    if faces is None and _registered_without_query:
        return True

    try:
        from enigma import addFont
        # The fourth argument selects the global Arabic replacement font.
        # Keep it at 0: this font is private to TiviMateE2 widgets.
        try:
            addFont(_FONT_PATH, _FONT_FACE, 100, 0, 0)
        except TypeError:
            addFont(_FONT_PATH, _FONT_FACE, 100, 0)
        faces = _faces()
        if faces is not None and _FONT_FACE not in faces:
            _warn_once("register-check", "Native font was not registered: %s" % _FONT_FACE)
            return False
        _registered_without_query = True
        print("[TiviMateE2][Greta] Active font: %s" % _FONT_FACE)
        return True
    except Exception as exc:
        _warn_once("registration", "Font registration failed: %s" % exc)
        return False


def has_arabic_text(value):
    """Match Arabic text, including presentation forms, not Latin metadata."""
    for char in str(value or ""):
        cp = ord(char)
        if ((0x0600 <= cp <= 0x06FF or 0x0750 <= cp <= 0x077F or
             0x08A0 <= cp <= 0x08FF or 0xFB50 <= cp <= 0xFDFF or
             0xFE70 <= cp <= 0xFEFF) and
                unicodedata.bidirectional(char) in ("AL", "R")):
            return True
    return False


def normalize_arabic_synopsis(value):
    """Keep complete Arabic synopsis and let native eLabel wrap by pixel width.

    Never insert a hard newline after N words: word lengths and skin widths
    differ. Collapse provider line breaks, retaining intentional paragraphs.
    English and other non-Arabic descriptions stay entirely untouched.
    """
    raw = str(value or "")
    if not raw or not has_arabic_text(raw):
        return raw
    # Series feeds and older cached metadata may contain manual line breaks.
    # Keep genuine paragraph boundaries while avoiding short ragged lines.
    text = raw.replace("\r\n", "\n").replace("\r", "\n")
    paragraphs = []
    import re
    for part in re.split(r"\n[ \t]*\n+", text):
        cleaned = " ".join(part.split())
        if cleaned:
            paragraphs.append(cleaned)
    return "\n".join(paragraphs)


class DirectionalLabel(Label):
    """Use Greta Arabic in this plugin's native eLabel, not system fonts.

    Enigma2's label is initially skinned before movie metadata becomes ready.
    The native skin must therefore already contain the Greta face, even when
    the label starts empty; waiting for setText (the old approach) is not
    sufficient on all OpenATV/Pure2 variants.  LTR text restores the exact
    original skin font at paint time. This component never calls addFont with
    replacement=1 and never affects unrelated Enigma2 screens.
    """

    def __init__(self, text=""):
        self._directional_value = str(text or "")
        self._regular_font = None
        self._skin_halign = "left"
        self._skin_font_prepared = False
        Label.__init__(self, text)

    def _read_skin_attributes(self):
        for key, value in (getattr(self, "skinAttributes", None) or []):
            if key == "font" and self._regular_font is None:
                try:
                    family, size = str(value).rsplit(";", 1)
                    size = int(size)
                    if family and size > 0 and family != _FONT_FACE:
                        self._regular_font = (family, size)
                except (ValueError, TypeError):
                    pass
            elif str(key).lower() in ("halign", "horizontalalignment"):
                self._skin_halign = str(value).strip().lower()

    def _apply_direction(self):
        widget = getattr(self, "instance", None)
        if widget is None:
            return
        arabic = has_arabic_text(self._directional_value)
        if self._regular_font is None:
            self._read_skin_attributes()
        # Keep the original skin alignment for Arabic as well.  Do not push
        # Arabic titles/descriptions to the right automatically; users want
        # Arabic to stay in the same visual position as English unless a
        # widget was explicitly skinned as right-aligned.
        if self._skin_halign not in ("center", "centre", "block"):
            try:
                widget.setHAlign(2 if self._skin_halign == "right" else 0)
            except Exception:
                pass
        if self._regular_font is None:
            return
        family, size = self._regular_font
        face = _FONT_FACE if arabic and register_greta() else family
        try:
            widget.setFont(gFont(face, size))
        except Exception as exc:
            _warn_once("native-font", "Could not apply label font: %s" % exc)

    def setText(self, value):
        self._directional_value = str(value or "")
        Label.setText(self, value)
        self._apply_direction()

    def _set_text_property(self, value):
        self.setText(value)

    # VariableText.text stores the base setter; override direct property use.
    text = property(Label.getText, _set_text_property)

    def applySkin(self, desktop, parent):
        self._read_skin_attributes()
        # IMPORTANT: a label may begin with empty text. Install the private
        # face in the native XML *before* the skin parser paints the widget.
        # This is the actual change from the previous font refresh builds.
        if self._regular_font and register_greta():
            old = self.skinAttributes or []
            self.skinAttributes = [
                (key, "%s;%d" % (_FONT_FACE, self._regular_font[1]))
                if key == "font" else (key, value)
                for key, value in old
            ]
            self._skin_font_prepared = True
        applied = Label.applySkin(self, desktop, parent)
        # The skin may have changed the native font in Label.applySkin.
        self._apply_direction()
        return applied

    def postWidgetCreate(self, instance):
        Label.postWidgetCreate(self, instance)
        # On Pure2 and older images native widgets may be created before all
        # attributes exist; applySkin does the final update later.
        self._read_skin_attributes()
        self._apply_direction()

    def onShow(self):
        try:
            Label.onShow(self)
        except Exception:
            pass
        # Reapply after returning to a previous screen, including skin switch.
        self._apply_direction()


def metadata_uses_arabic(value="", tmdb_arabic=None):
    """Center Arabic *content*, even when the menu/UI language is English.

    Many users keep the TiviMate menus English while requesting Arabic TMDb
    metadata. The previous check only used the menu language; consequently
    movie and series pages never centered their Arabic facts row.
    """
    if has_arabic_text(value):
        return True
    try:
        from .i18n import get_language
        if str(get_language() or "").lower().startswith("ar"):
            return True
    except Exception:
        pass
    if tmdb_arabic is None:
        try:
            from .tmdb_client import load_settings
            tmdb_arabic = str(load_settings().get("language") or "").lower().startswith("ar")
        except Exception:
            tmdb_arabic = False
    return bool(tmdb_arabic)


class CenteredArabicMetadataLabel(DirectionalLabel):
    """Center year/genre for Arabic metadata, regardless of the menu language.

    Read the TMDb language setting once per screen/widget, not on every cursor
    movement. An Arabic genre text overrides English app and TMDb settings.
    English-only metadata retains the skin's configured alignment unless the
    user explicitly selects an Arabic metadata language.
    """
    def __init__(self, text=""):
        self._tmdb_arabic_metadata = False
        try:
            from .tmdb_client import load_settings
            self._tmdb_arabic_metadata = str(load_settings().get("language") or "").lower().startswith("ar")
        except Exception:
            pass
        super(CenteredArabicMetadataLabel, self).__init__(text)

    def _apply_direction(self):
        super(CenteredArabicMetadataLabel, self)._apply_direction()
        widget = getattr(self, "instance", None)
        if widget is None:
            return
        try:
            if metadata_uses_arabic(self._directional_value, self._tmdb_arabic_metadata):
                widget.setHAlign(1)  # eLabel.alignCenter
            elif self._skin_halign in ("center", "centre", "block"):
                widget.setHAlign(1)
            else:
                widget.setHAlign(2 if self._skin_halign == "right" else 0)
        except Exception:
            pass

    def onShow(self):
        super(CenteredArabicMetadataLabel, self).onShow()
        self._apply_direction()


class SynopsisLabel(DirectionalLabel):
    """Display Arabic overviews in reading order on OpenATV / Pure2.

    eLabel's RTL automatic *multi-line* layout can render the last visual
    line first.  The UTF-8 text from TMDb is already in correct logical order;
    reversing its words or passing it through a whole-paragraph BiDi transform
    makes that bug worse.  For Arabic only, wrap by the native font's measured
    width and give each successive line its own non-wrapping native eLabel.
    English stays in the original, unmodified native eLabel.  Child widgets
    inherit this label's placement/clipping and do not alter the screen skin.
    """

    _MAX_LINES = 14

    def __init__(self, text=""):
        self._synopsis_lines = []
        self._synopsis_measurer = None
        self._synopsis_layout_key = None
        DirectionalLabel.__init__(self, normalize_arabic_synopsis(text))

    def _remove_native_lines(self):
        for line in self._synopsis_lines:
            try:
                line.hide()
            except Exception:
                pass
        # Keep the reusable instances so fast navigation does not continuously
        # allocate/destroy Enigma2 native widgets.

    def _wrapped_lines(self, raw, font, width):
        """Logical order, measured using the same native font as the display."""
        measurer = self._synopsis_measurer
        if measurer is None:
            return [raw]
        try:
            measurer.setFont(font)
            measurer.resize(eSize(int(max(width * 2, 2048)), 90))
            measurer.setNoWrap(True)
        except Exception:
            return [raw]

        widths = {}

        def measured(text):
            found = widths.get(text)
            if found is not None:
                return found
            try:
                measurer.setText(text)
                found = int(measurer.calculateSize().width())
            except Exception:
                # Fallback should err toward shorter lines, never guess that a
                # paragraph fits when the native measurement is unavailable.
                found = len(text) * max(9, self._regular_font[1] // 2)
            widths[text] = found
            return found

        result = []
        for para in raw.split("\n"):
            words = para.split()
            if not words:
                if result and result[-1] != "":
                    result.append("")
                continue
            current = ""
            for word in words:
                candidate = (current + " " + word) if current else word
                if current and measured(candidate) > width:
                    result.append(current)
                    current = word
                else:
                    current = candidate
            if current:
                result.append(current)
        return result

    def _layout_arabic_lines(self):
        native = getattr(self, "instance", None)
        if native is None:
            return
        raw = self._directional_value
        if not raw or not has_arabic_text(raw):
            self._remove_native_lines()
            self._synopsis_layout_key = None
            # Keep English and other non-Arabic synopses entirely native.
            try:
                native.setText(raw)
                native.setNoWrap(False)
            except Exception:
                pass
            return
        if self._regular_font is None:
            self._read_skin_attributes()
        if self._regular_font is None:
            return  # try again in applySkin after the font attribute is known
        family, size = self._regular_font
        face = _FONT_FACE if register_greta() else family
        font = gFont(face, size)
        try:
            available_width = int(native.size().width())
            available_height = int(native.size().height())
        except Exception:
            return
        if available_width < 30 or available_height < 15:
            return
        key = (raw, face, size, available_width, available_height)
        if key == self._synopsis_layout_key:
            return
        self._synopsis_layout_key = key
        # The original empty label is still a native widget and a clipping
        # parent, but is not allowed to auto-wrap the Arabic paragraph.
        try:
            native.setText("")
            native.setNoWrap(True)
        except Exception:
            pass
        if self._synopsis_measurer is None:
            try:
                self._synopsis_measurer = eLabel(native)
                self._synopsis_measurer.hide()
            except Exception:
                self._synopsis_layout_key = None
                native.setText(raw)
                return
        try:
            self._synopsis_measurer.setFont(font)
            self._synopsis_measurer.setNoWrap(True)
        except Exception:
            pass

        lines = self._wrapped_lines(raw, font, max(30, available_width - 20))
        # Keep text within the original synopsis box.  Use its native font size
        # as a guide rather than the number of words (which varies by script).
        line_height = max(1, int(round(size * 1.21)))
        count = min(self._MAX_LINES, max(1, available_height // line_height))
        visible = lines[:count]
        if len(lines) > count and visible:
            # Clip as the original single widget would do; never change the
            # logical order or move a closing sentence to the first row.
            pass

        # Extract exact foreground shade from the screen skin when possible.
        color = None
        for attr, value in (getattr(self, "skinAttributes", None) or []):
            if attr == "foregroundColor":
                try:
                    from skin import parseColor
                    color = parseColor(value)
                except Exception:
                    pass
                break

        painted = True
        for index, text in enumerate(visible):
            if index >= len(self._synopsis_lines):
                try:
                    self._synopsis_lines.append(eLabel(native))
                except Exception:
                    painted = False
                    break
            line = self._synopsis_lines[index]
            try:
                line.setFont(font)
                line.setTransparent(True)
                try:
                    line.setNoWrap(True)
                except (AttributeError, TypeError):
                    pass
                # Synopsis text only: keep Arabic right-aligned inside its
                # existing box. All other labels (titles, metadata, buttons)
                # retain their original skin alignment via DirectionalLabel.
                # Keep each wrapped line in logical top-to-bottom order.
                line.setHAlign(2)
                if color is not None:
                    line.setForegroundColor(color)
                line.resize(eSize(available_width, line_height))
                line.move(ePoint(0, index * line_height))
                line.setText(text)
                line.show()
            except Exception:
                painted = False
                break
        if not painted:
            # An older Enigma2 build might not support native child eLabels.
            # Do not allow that to turn the description into a blank area.
            self._remove_native_lines()
            self._synopsis_layout_key = None
            try:
                native.setNoWrap(False)
                native.setText(raw)
            except Exception:
                pass
            return
        for line in self._synopsis_lines[len(visible):]:
            try:
                line.hide()
            except Exception:
                pass

    def setText(self, value):
        DirectionalLabel.setText(self, normalize_arabic_synopsis(value))
        self._synopsis_layout_key = None
        self._layout_arabic_lines()

    def applySkin(self, desktop, parent):
        result = DirectionalLabel.applySkin(self, desktop, parent)
        self._synopsis_layout_key = None
        self._layout_arabic_lines()
        return result

    def postWidgetCreate(self, instance):
        DirectionalLabel.postWidgetCreate(self, instance)
        self._layout_arabic_lines()

    def onShow(self):
        DirectionalLabel.onShow(self)
        self._synopsis_layout_key = None
        self._layout_arabic_lines()

    def preWidgetRemove(self, instance):
        self._remove_native_lines()
        self._synopsis_lines = []
        self._synopsis_measurer = None
        self._synopsis_layout_key = None
        try:
            DirectionalLabel.preWidgetRemove(self, instance)
        except AttributeError:
            pass


class AdaptiveOverviewLabel(SynopsisLabel):
    """Ultra-style film/series overview: fit preferred size to native box.

    Only instantiated in the three dedicated Movies/Series detail screens.
    Native eLabel measures English; Arabic retains the existing per-line Greta
    renderer and logical top-to-bottom line ordering after font selection.
    """

    def __init__(self, text=""):
        self._overview_original_font = None
        self._overview_fitted_key = None
        SynopsisLabel.__init__(self, text)

    def _fit_overview_font(self):
        try:
            from .font_preferences import read_preferences
            mode = read_preferences().get("overview_font_scale", "normal")
            if mode == "normal":
                return
            instance = getattr(self, "instance", None)
            if instance is None:
                return
            self._read_skin_attributes()
            if self._regular_font is None:
                return
            if self._overview_original_font is None:
                self._overview_original_font = self._regular_font
            family, preferred = self._overview_original_font
            width, height = int(instance.size().width()), int(instance.size().height())
            raw = str(self._directional_value or "")
            if width < 80 or height < 40 or not raw:
                return
            key = (raw, width, height, family, preferred)
            if key == self._overview_fitted_key:
                return
            self._overview_fitted_key = key
            is_arabic = has_arabic_text(raw)
            face = _FONT_FACE if is_arabic and register_greta() else family
            chosen = preferred
            for candidate in range(int(preferred), 17, -1):
                try:
                    instance.setFont(gFont(face, candidate))
                    instance.setNoWrap(False)
                    instance.setText(raw)
                    measured = int(instance.calculateSize().height())
                    # Some native image versions return a single line for
                    # wrapped text. Use a conservative fallback in that case.
                    if measured <= candidate * 1.4 and len(raw) > 120:
                        char_width = candidate * (0.53 if is_arabic else 0.50)
                        estimated_lines = max(1, int((len(raw) * char_width) / max(50, width - 20)) + 1)
                        measured = max(measured, int(estimated_lines * candidate * 1.20))
                    if measured <= max(20, height - 5):
                        chosen = candidate
                        break
                except Exception:
                    chosen = max(18, min(int(preferred), int(height / 4.5)))
                    break
            self._regular_font = (family, chosen)
            instance.setFont(gFont(face, chosen))
            self._synopsis_layout_key = None
        except Exception:
            # Font preferences must never prevent details from displaying.
            return

    def _layout_arabic_lines(self):
        self._fit_overview_font()
        return SynopsisLabel._layout_arabic_lines(self)
