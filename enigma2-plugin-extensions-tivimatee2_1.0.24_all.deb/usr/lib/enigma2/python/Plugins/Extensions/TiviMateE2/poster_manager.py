# -*- coding: utf-8 -*-
"""Shared VOD/series poster policy for every TiviMateE2 page.

Keep GENRE, Movies, TV Shows, Details, Search, Favorites and Package layouts
independent. Visible poster requests use the same validated, bounded Ultra
provider downloader as GENRE, with the original artwork queue as a fallback.
"""
from . import artwork_queue as _queue
import re
import threading
from collections import OrderedDict
from urllib.parse import urlsplit

KIND = "posters"
PROVIDER_KEYS = (
    "stream_icon", "movie_image", "cover", "cover_big", "poster",
    "poster_url", "poster_path", "screenshot_uri", "image",
)

# Context is exact-URL scoped, not a single mutable 'current server' value:
# combined Movies/Series searches can load posters from different Stalker
# portals simultaneously. Retain just a bounded window of sources in RAM.
_PROVIDER_CONTEXTS = OrderedDict()
_CONTEXT_LOCK = threading.RLock()
_MAX_CONTEXTS = 384


def _remember_provider(url, source):
    if not url or not isinstance(source, dict):
        return
    if not str(url).startswith(("http://", "https://")):
        return
    key = _queue.normalise_url(url)
    if not key:
        return
    with _CONTEXT_LOCK:
        _PROVIDER_CONTEXTS.pop(key, None)
        _PROVIDER_CONTEXTS[key] = dict(source)
        while len(_PROVIDER_CONTEXTS) > _MAX_CONTEXTS:
            _PROVIDER_CONTEXTS.popitem(last=False)


def _provider_for(url):
    with _CONTEXT_LOCK:
        return _PROVIDER_CONTEXTS.get(url)


def provider_poster_url(source, item, extra=None):
    url = _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)
    try:
        filename = (urlsplit(str(url or "")).path.rsplit("/", 1)[-1]).lower()
        if re.fullmatch(r"(?:no[_-]?(?:title|poster|image)|nopic|placeholder|default[_-]?poster)(?:[_-][a-z0-9]+)?\.(?:jpe?g|png|webp)", filename):
            return ""
    except Exception:
        pass
    _remember_provider(url, source)
    return url


def tmdb_poster_url(value):
    """Accept an absolute image URL or TMDb poster_path, never a backdrop."""
    value = str(value or "").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/w500" + value
    return value if value.startswith(("https://", "http://")) else ""


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None):
    """GENRE Ultra transport for visible posters, shared cache for all pages.

    UI callbacks always re-enter the Twisted/Enigma main thread. If that main
    loop is unavailable, use the existing safe artwork queue unmodified.
    Ultra failures also fall back to the existing queue rather than leaving a
    valid image permanently missing on a supported Enigma2 image.
    """
    if _queue.is_app_exiting():
        return ""
    url = _queue.normalise_url(url)
    if not url:
        return ""
    # Keep the canonical TMDb resolution / file path used across every page.
    canonical, _rel = _queue._canonical_tmdb_artwork(url, KIND)
    existing = cached(canonical)
    if existing:
        if callback:
            callback(existing)
        return existing

    try:
        from twisted.internet import reactor
        if not getattr(reactor, "running", False):
            raise RuntimeError("no Enigma2 reactor")
        from .genre_ultra_artwork import request as ultra_request
    except (ImportError, RuntimeError):
        return _queue._request_artwork_core(canonical, KIND, callback, priority, errback)

    source = _provider_for(url) or _provider_for(canonical)

    def on_main(func, path):
        if _queue.is_app_exiting():
            return
        reactor.callFromThread(func, path)

    def ready(path):
        if callback:
            callback(path)

    def fallback(_unused):
        if _queue.is_app_exiting():
            return
        _queue._request_artwork_core(canonical, KIND, callback, priority, errback)

    try:
        ultra_request(canonical, KIND, source, ready, fallback, on_main)
    except Exception:
        return _queue._request_artwork_core(canonical, KIND, callback, priority, errback)
    return _queue.artwork_path(canonical, KIND)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)


def usable_poster_file(path, minimum_bytes=128):
    """Reject HTML/error pages in cached posters, keep current fallback logic."""
    try:
        import os
        if not path or not os.path.isfile(path) or os.path.getsize(path) < minimum_bytes:
            return False
        with open(path, "rb") as stream:
            head = stream.read(12)
        return (head.startswith(b"\xff\xd8\xff") or
                head.startswith(b"\x89PNG\r\n\x1a\n") or
                (head.startswith(b"RIFF") and head[8:12] == b"WEBP") or
                head.startswith(b"GIF87a") or head.startswith(b"GIF89a"))
    except Exception:
        return False
