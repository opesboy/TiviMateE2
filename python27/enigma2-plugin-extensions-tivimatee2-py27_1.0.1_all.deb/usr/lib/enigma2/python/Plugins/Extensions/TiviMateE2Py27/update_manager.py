# -*- coding: utf-8 -*-
"""Independent update channel for the Python 2.7/DreamOS TiviMateE2 plugin.

Only the dedicated python27 GitHub manifest and py27 package identity are
accepted.  The Python 3 manifest and Python 3 package are never consulted.
All downloads and integrity checks run in the caller's background worker.
"""
from __future__ import absolute_import

import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import tempfile

try:
    from urllib2 import urlopen
except ImportError:
    from urllib.request import urlopen

try:
    from urlparse import urlparse
except ImportError:
    from urllib.parse import urlparse

PLUGIN_VERSION = '1.0.1'
PACKAGE_ID = 'enigma2-plugin-extensions-tivimatee2-py27'
MANIFEST_URL = 'https://raw.githubusercontent.com/opesboy/TiviMateE2/main/python27/update.json'
PACKAGE_BASE_URL = 'https://raw.githubusercontent.com/opesboy/TiviMateE2/main/python27/'
MAX_MANIFEST_BYTES = 65536
MAX_PACKAGE_BYTES = 80 * 1024 * 1024
_VERSION_RE = re.compile(r'^\d+\.\d+\.\d+$')
_SHA_RE = re.compile(r'^[0-9a-f]{64}$')
try:
    _STRING_TYPES = (basestring,)
except NameError:
    _STRING_TYPES = (str, bytes)


def _version_tuple(value):
    if not isinstance(value, _STRING_TYPES):
        return None
    try:
        value = value.decode('ascii') if isinstance(value, bytes) else value
        if not _VERSION_RE.match(value):
            return None
        return tuple(int(x) for x in value.split('.'))
    except Exception:
        return None


def _package_details(info, version):
    """Reject cross-channel URL, revision-suffixed names and wrong checksums."""
    if not isinstance(info, dict) or _version_tuple(version) is None:
        return None
    name = PACKAGE_ID + '_' + version + '_all.ipk'
    url = PACKAGE_BASE_URL + name
    sha = str(info.get('sha256') or '').lower()
    if info.get('url') != url or not _SHA_RE.match(sha):
        return None
    return {'url': url, 'sha256': sha, 'version': version, 'package_id': PACKAGE_ID}


def _read_url(url, max_bytes, timeout):
    response = urlopen(url, timeout=timeout)
    try:
        # A redirected download must remain on precisely the expected URL.
        if response.geturl() != url:
            raise ValueError('Update URL redirected outside the python27 channel')
        body = response.read(max_bytes + 1)
        if len(body) > max_bytes:
            raise ValueError('Update download exceeds the permitted size')
        return body
    finally:
        response.close()


def check_for_update():
    """Return an available candidate only for a newer clean X.Y.Z release."""
    try:
        body = _read_url(MANIFEST_URL, MAX_MANIFEST_BYTES, 9)
        manifest = json.loads(body.decode('utf-8'))
        if not isinstance(manifest, dict):
            raise ValueError('Invalid update manifest')
        if manifest.get('channel') != 'python27' or manifest.get('package_id') != PACKAGE_ID:
            raise ValueError('Update channel/package identity mismatch')
        if manifest.get('enabled') is not True:
            return {'available': False, 'reason': 'disabled'}
        # A clean version number is the *only* release identifier.  Do not
        # compare revisions from Python 3 or accept rNNN suffixes.
        version = manifest.get('version')
        newest = _version_tuple(version)
        current = _version_tuple(PLUGIN_VERSION)
        if newest is None or current is None or 'revision' in manifest:
            raise ValueError('Update manifest has an invalid version/revision')
        if newest <= current:
            return {'available': False, 'reason': 'current', 'version': PLUGIN_VERSION}
        packages = manifest.get('packages') or {}
        candidate = _package_details(packages.get('ipk'), version)
        if candidate is None:
            raise ValueError('Update IPK does not belong to the Python 2.7 channel')
        return {'available': True, 'reason': 'newer', 'version': version,
                'notes': manifest.get('notes') or '', 'package': candidate}
    except Exception as exc:
        return {'available': False, 'reason': 'error', 'message': str(exc)}


def _ar_member(path, member):
    """Read one Debian/ar control member without calling external `ar`."""
    with open(path, 'rb') as stream:
        if stream.read(8) != b'!<arch>\n':
            raise ValueError('Update is not a valid IPK/ar archive')
        while True:
            header = stream.read(60)
            if not header:
                break
            if len(header) != 60 or header[58:60] != b'`\n':
                raise ValueError('Malformed IPK archive')
            name = header[:16].strip().rstrip(b'/')
            length = int(header[48:58].strip())
            if length < 0 or length > MAX_PACKAGE_BYTES:
                raise ValueError('Invalid archive member size')
            if name == member.encode('ascii'):
                return stream.read(length)
            stream.seek(length + (length % 2), 1)
    raise ValueError('IPK lacks required control archive')


def _decompress_control(data, archive_name):
    if archive_name.endswith('.gz'):
        import gzip
        return gzip.GzipFile(fileobj=io.BytesIO(data)).read()
    if archive_name.endswith('.xz'):
        try:
            import lzma
            return lzma.decompress(data)
        except ImportError:
            pass
        except Exception as exc:
            raise ValueError('Invalid xz package control: %s' % exc)
        try:
            worker = subprocess.Popen(['xz', '-dc'], stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            decoded, errors = worker.communicate(data)
            if worker.returncode != 0:
                raise ValueError('xz control decode failed: %s' % errors[:200])
            return decoded
        except OSError:
            # DreamOS has dpkg-deb on many images, even if xz is absent.
            raise ValueError('Missing xz decoder for IPK control verification')
    raise ValueError('Unsupported IPK control compression')


def _verify_package(path, version):
    """Verify the package's actual name and version, not only the filename."""
    control = None
    # DreamOS includes dpkg-deb; it can read the standard ar/xz package even
    # when a standalone `xz` executable or Python lzma module is absent.
    try:
        control = subprocess.check_output(['dpkg-deb', '-f', path],
                                          stderr=subprocess.STDOUT)
        if not control or len(control) > 65536:
            raise ValueError('Invalid dpkg control metadata')
    except (OSError, subprocess.CalledProcessError):
        control = None
    if control is None:
        control = _control_from_ar(path)
    fields = {}
    for line in control.decode('utf-8').splitlines():
        if line and not line[0].isspace() and ':' in line:
            key, val = line.split(':', 1)
            fields[key.lower()] = val.strip()
    if fields.get('package') != PACKAGE_ID or fields.get('version') != version:
        raise ValueError('Package ID/version does not match this Python 2.7 release')
    if fields.get('architecture') != 'all':
        raise ValueError('Package architecture mismatch')
    return True


def _control_from_ar(path):
    archive_name = None
    compressed = None
    for name in ('control.tar.xz', 'control.tar.gz'):
        try:
            compressed = _ar_member(path, name)
            archive_name = name
            break
        except ValueError as exc:
            if 'lacks required control archive' not in str(exc):
                raise
    if compressed is None:
        raise ValueError('IPK control archive not found')
    content = _decompress_control(compressed, archive_name)
    with tarfile.open(fileobj=io.BytesIO(content), mode='r:') as tf:
        control = None
        for entry in tf.getmembers():
            if entry.name.lstrip('./') == 'control' and entry.isfile():
                control = tf.extractfile(entry).read(65536)
                break
    if control is None:
        raise ValueError('Package control metadata is missing')
    return control


def download_package(package):
    """Download and verify the exact signed-off Python27 update candidate."""
    version = package.get('version') if isinstance(package, dict) else ''
    candidate = _package_details(package, version)
    if candidate is None:
        return {'ok': False, 'message': 'Invalid Python 2.7 package address or checksum'}
    if _version_tuple(version) <= _version_tuple(PLUGIN_VERSION):
        return {'ok': False, 'message': 'The package is not newer than the installed version'}
    path = ''
    fd = -1
    try:
        # This is a transient installer, never a poster/EPG artwork cache.
        fd, path = tempfile.mkstemp(prefix='tivimatee2_py27_update_', suffix='.ipk')
        digest = hashlib.sha256()
        total = 0
        response = urlopen(candidate['url'], timeout=18)
        try:
            if response.geturl() != candidate['url']:
                raise ValueError('Package redirected outside the python27 channel')
            with os.fdopen(fd, 'wb') as output:
                fd = -1
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > MAX_PACKAGE_BYTES:
                        raise ValueError('Update IPK is unexpectedly large')
                    digest.update(chunk)
                    output.write(chunk)
        finally:
            response.close()
            if fd >= 0:
                os.close(fd)
        if total < 256 or digest.hexdigest() != candidate['sha256']:
            raise ValueError('IPK SHA-256 verification failed')
        _verify_package(path, version)
        return {'ok': True, 'path': path, 'version': version,
                'package_id': PACKAGE_ID, 'sha256': candidate['sha256']}
    except Exception as exc:
        if fd >= 0:
            try: os.close(fd)
            except Exception: pass
        if path:
            try: os.unlink(path)
            except Exception: pass
        return {'ok': False, 'message': str(exc)}


def install_command(result):
    """Return the shell command only after identity and integrity revalidation."""
    if not isinstance(result, dict) or result.get('ok') is not True:
        return ''
    path = result.get('path')
    version = result.get('version')
    checksum = result.get('sha256')
    if (not isinstance(path, (str, bytes)) or
            not os.path.basename(path).startswith('tivimatee2_py27_update_') or
            not path.endswith('.ipk') or not os.path.isfile(path) or
            result.get('package_id') != PACKAGE_ID or
            _version_tuple(version) is None or
            _version_tuple(version) <= _version_tuple(PLUGIN_VERSION) or
            not isinstance(checksum, (str, bytes)) or not _SHA_RE.match(checksum)):
        return ''
    try:
        with open(path, 'rb') as stream:
            digest = hashlib.sha256()
            for block in iter(lambda: stream.read(65536), b''):
                digest.update(block)
        if digest.hexdigest() != checksum:
            return ''
        _verify_package(path, version)
    except Exception:
        return ''
    quoted = "'" + path.replace("'", "'\\''") + "'"
    # DreamOS normally uses dpkg. Other compatible Enigma2 boxes use opkg.
    return ('if command -v dpkg >/dev/null 2>&1; then dpkg -i ' + quoted +
            '; elif command -v opkg >/dev/null 2>&1; then opkg install --force-reinstall ' +
            quoted + '; else exit 127; fi')


def cleanup_update_package(result=None):
    if not isinstance(result, dict):
        return
    path = result.get('path')
    if isinstance(path, (str, bytes)) and os.path.basename(path).startswith('tivimatee2_py27_update_'):
        try: os.unlink(path)
        except Exception: pass
