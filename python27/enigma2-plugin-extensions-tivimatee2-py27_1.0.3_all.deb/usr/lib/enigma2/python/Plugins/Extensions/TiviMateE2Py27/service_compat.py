# -*- coding: utf-8 -*-
"""Detect optional ServiceApp engines without making Enigma2 depend on them.

ServiceApp registers types 5001/5002.  A binary alone is not enough if the
plugin is missing; a plugin directory alone is not enough if the player binary
is missing.  An existing saved engine can remain configured and is only
normalized at runtime, so installing ServiceApp later restores the preference.
"""
import os

_PLUGIN_BASE = "/usr/lib/enigma2/python/Plugins"


def _serviceapp_installed():
    for section in ("SystemPlugins", "Extensions"):
        directory = os.path.join(_PLUGIN_BASE, section, "ServiceApp")
        if any(os.path.isfile(os.path.join(directory, "plugin" + suffix))
               for suffix in (".py", ".pyc", ".pyo")):
            return True
    return False


def serviceapp_backend_available(service_type):
    try:
        service_type = int(service_type)
    except (ValueError, TypeError):
        return False
    binary = {5001: "gstplayer", 5002: "exteplayer3"}.get(service_type)
    if binary is None or not _serviceapp_installed():
        return False
    return any(os.path.isfile(os.path.join(folder, binary)) and
               os.access(os.path.join(folder, binary), os.X_OK)
               for folder in ("/usr/bin", "/usr/local/bin"))


def compatible_service_type(value):
    """Preserve all existing types except unavailable optional 5001/5002."""
    try:
        value = int(value)
    except (ValueError, TypeError):
        return 4097
    if value in (5001, 5002) and not serviceapp_backend_available(value):
        return 4097
    return value
