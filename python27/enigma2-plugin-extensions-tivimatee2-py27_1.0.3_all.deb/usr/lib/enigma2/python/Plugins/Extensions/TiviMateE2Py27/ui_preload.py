# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import thread_factory
"""Safely precompile the trusted built-in UI fragments without importing any Enigma widget.

This work runs after session start and only uses Python's compiler; all
Enigma screens/objects continue to be created on the main GUI thread.
"""
import os
import threading

_LOCK = threading.Lock()
_CODE = {}
_STARTED = False
_RELEASED = False


def _signature(path):
    stat = os.stat(path)
    return (stat.st_size, getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1000000000)))


def get_compiled_part(path):
    """Return a compiled fragment if unchanged, otherwise compile it normally."""
    path = os.path.abspath(path)
    try:
        signature = _signature(path)
        with _LOCK:
            if not _RELEASED:
                entry = _CODE.get(path)
                if entry and entry[0] == signature:
                    return entry[1]
    except Exception:
        pass
    with open(path, "rb") as handle:
        data = handle.read()
    compiled = compile(data, path, "exec")
    # Only retain the code if source did not change while reading it.
    try:
        signature = _signature(path)
        with _LOCK:
            if not _RELEASED:
                _CODE[path] = (signature, compiled)
    except Exception:
        pass
    return compiled


def start_prewarm():
    """Start once; don't import UI or create Enigma widgets in this thread."""
    global _STARTED
    with _LOCK:
        if _STARTED:
            return
        _STARTED = True

    def worker():
        folder = os.path.join(os.path.dirname(__file__), "_ui_parts")
        names = (
            "01_common_and_skins.py", "02_editors_and_tmdb.py",
            "03_packages_and_settings.py", "04_server_manager.py",
            "05_search_home_continue.py", "06_series_details.py",
            "07_media_and_favorites.py",
        )
        for name in names:
            with _LOCK:
                if _RELEASED:
                    return
            try:
                get_compiled_part(os.path.join(folder, name))
            except Exception:
                # The UI loader will compile the original source on demand.
                pass
    t = thread_factory(target=worker, name="TiviMateUICompileWarmup")
    t.daemon = True
    t.start()


def release():
    """Discard warmed code after the UI module has imported successfully."""
    global _RELEASED
    with _LOCK:
        _RELEASED = True
        _CODE.clear()
