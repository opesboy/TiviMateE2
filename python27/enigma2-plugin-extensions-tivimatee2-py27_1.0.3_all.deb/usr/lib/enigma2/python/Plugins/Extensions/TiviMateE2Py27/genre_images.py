# -*- coding: utf-8 -*-
"""GENRE's first package backdrop, stored under the configured cache location.

HDD / USB: <selected TiviMateE2 cache root>/images/genre/<server>/<kind>/<package>.jpg
TMP: /tmp/tivimatee2-py27-cache/images/genre/... (cleared on reboot).
Internal flash: /etc/enigma2/.tivimatee2-py27-cache/images/genre/...

The new folder shares the existing cache *root*, but its images are deliberately
outside cleanup_cache() / clear_cache() transient artwork directories. Existing
images from the previous /media/<device>/tivimatee2/images/genre are migrated
safely, without replacing an already saved image or touching unknown files.
"""
from __future__ import absolute_import
from Plugins.Extensions.TiviMateE2Py27.py27_compat import scandir, thread_factory, text_type

import hashlib
import os
import re
import shutil
import threading

_IMAGE_LOCK = threading.RLock()
_MEDIA_FOLDERS = ('/media/hdd', '/media/usb', '/media/usb1', '/media/usb2',
                  '/media/usb3', '/media/mmc', '/media/sdcard')
_OLD_FLASH_ROOT = '/etc/enigma2/tivimatee2_py27/images/genre'
_NEW_FLASH_ROOT = '/etc/enigma2/.tivimatee2-py27-cache/images/genre'
# Match the Ultra backdrop downloader (12 MiB); a valid displayed
# backdrop between 6 and 12 MiB must not be rejected by permanent GENRE save.
_MAX_IMAGE_BYTES = 12 * 1024 * 1024
_MIN_IMAGE_BYTES = 200
_MIGRATION_STARTED = set()
_LEGACY_IMAGE_RE = re.compile(r'^[A-Za-z0-9_-]+_[a-f0-9]{10}\.(?:jpg|png|webp)$')
_LEGACY_SERVER_RE = re.compile(r'^[A-Za-z0-9_-]+_[a-f0-9]{16}$')


def _real_mount(path):
    """Never create a fake HDD folder on the receiver's internal flash."""
    try:
        return os.path.isdir(path) and os.access(path, os.W_OK | os.X_OK) and (
            os.path.ismount(path) or os.path.ismount(os.path.realpath(path)))
    except Exception:
        return False


def _image_root():
    """Honor explicit TMP for genre pictures as for other artwork.

    INTERNAL keeps its historical persistent folder on receiver flash.
    Never silently write GENRE pictures to flash when TMP is selected.
    """
    try:
        from .cache_manager import get_cache_root, get_settings
        cfg = get_settings() or {}
        location = str(cfg.get('location') or 'auto').strip().lower()
        root = str(get_cache_root() or '').rstrip('/')
    except Exception:
        location, root = 'auto', ''
    if location == 'tmp':
        # Even if cache-root selection falls back, never write to /etc.
        return os.path.join(root or '/tmp/tivimatee2-py27-cache', 'images', 'genre')
    if root and root.startswith('/media/'):
        # get_cache_root() already selects a mounted HDD / USB / MMC.
        return os.path.join(root, 'images', 'genre')
    return _NEW_FLASH_ROOT


def _legacy_image_roots():
    target = _image_root()
    if target.startswith('/tmp/'):
        # Never MOVE permanent HDD/flash images into volatile /tmp: that would
        # delete the only persistent copies. TMP starts its own fresh cache.
        return []
    # Never bulk-copy mounted-HDD artwork into limited receiver flash simply
    # because the user selected Internal as the cache destination.
    if target == _NEW_FLASH_ROOT:
        return [_OLD_FLASH_ROOT]
    old = []
    for mount in _MEDIA_FOLDERS:
        if _real_mount(mount):
            old.append(os.path.join(mount, 'tivimatee2', 'images', 'genre'))
    # Older flash pictures can be restored to the selected HDD/USB once available.
    old.append(_OLD_FLASH_ROOT)
    return old


def _safe(value, maximum=48):
    # Python2 str(unicode_arabic) raises UnicodeEncodeError. Slugs are ASCII;
    # server identity is retained independently in its UTF-8 digest below.
    value = text_type(value if value is not None else u'').strip()
    value = re.sub(u'[^a-zA-Z0-9_-]+', u'_', value).strip(u'_')
    return (value or u'unknown')[:maximum].encode('ascii')


def _server_identity(source):
    source = source or {}
    # Identical identity to earlier GENRE saved-image releases.
    return u'|'.join(text_type(x if x is not None else u'') for x in (
        source.get('type'),
        text_type(source.get('url') or source.get('host') or source.get('server') or
                  source.get('portal') or u'').rstrip(u'/'),
        source.get('username'), source.get('mac')
    ))


def _relative_folder(source, kind):
    source = source or {}
    source_name = _safe(source.get('name') or source.get('server_name') or
                        source.get('host') or 'Server', 32)
    digest = hashlib.sha256(_server_identity(source).encode('utf-8')).hexdigest()[:16]
    media_type = 'series' if kind == 'series' else 'movies'
    return os.path.join('%s_%s' % (source_name, digest), media_type)


def _folder(source, kind):
    return os.path.join(_image_root(), _relative_folder(source, kind))


# The folder's human-readable server name is not the actual authentication
# identity. Renaming a server used to orphan its existing GENRE package art:
# the folder name changed even though the stable 16-char identity hash did not.
# Search matching old names only on a direct cache miss.  Reuse those pictures
# in place; do NOT duplicate images, rename directories or change downloads.
_NAMED_FOLDER_ALIASES = {}
_NAMED_FOLDER_ALIAS_LIMIT = 64


def _same_server_old_folders(source, kind):
    root = _image_root()
    media = 'series' if kind == 'series' else 'movies'
    digest = hashlib.sha256(_server_identity(source).encode('utf-8')).hexdigest()[:16]
    current_name = os.path.basename(os.path.dirname(_folder(source, kind)))
    key = (root, digest, media, current_name)
    with _IMAGE_LOCK:
        cached = _NAMED_FOLDER_ALIASES.get(key)
        if cached is not None:
            return cached
    dirs = []
    try:
        # Bounded directory scan happens only when the target image is absent;
        # the normal cached GENRE first-paint path remains a direct file lookup.
        with scandir(root) as entries:
            for entry in entries:
                if len(dirs) >= 32:
                    break
                if (entry.name != current_name and
                        entry.name.endswith('_' + digest) and
                        entry.is_dir(follow_symlinks=False)):
                    dirs.append(os.path.join(entry.path, media))
    except (OSError, ValueError, IOError):
        pass
    result = tuple(dirs)
    with _IMAGE_LOCK:
        if len(_NAMED_FOLDER_ALIASES) >= _NAMED_FOLDER_ALIAS_LIMIT:
            _NAMED_FOLDER_ALIASES.clear()
        _NAMED_FOLDER_ALIASES[key] = result
    return result


def _stem(category_id):
    cat = text_type(category_id if category_id is not None else u'')
    if not cat:
        return ''
    return '%s_%s' % (_safe(cat, 40), hashlib.sha256(cat.encode('utf-8')).hexdigest()[:10])


def _image_type(path):
    try:
        if not path or os.path.islink(path) or not os.path.isfile(path):
            return ''
        size = os.path.getsize(path)
        if size < _MIN_IMAGE_BYTES or size > _MAX_IMAGE_BYTES:
            return ''
        with open(path, 'rb') as fh:
            signature = fh.read(16)
        if signature.startswith(b'\xff\xd8\xff'):
            return '.jpg'
        if signature.startswith(b'\x89PNG\r\n\x1a\n'):
            return '.png'
        if signature[:4] == b'RIFF' and signature[8:12] == b'WEBP':
            return '.webp'
    except Exception:
        pass
    return ''


def _saved_at(folder, stem):
    if not stem:
        return ''
    for ext in ('.jpg', '.png', '.webp'):
        path = os.path.join(folder, stem + ext)
        if _image_type(path) == ext:
            return path
    return ''


def _digest(path):
    sha = hashlib.sha256()
    with open(path, 'rb') as fh:
        while True:
            buf = fh.read(64 * 1024)
            if not buf:
                break
            sha.update(buf)
    return sha.digest()


def _migrate_one(old_path, new_path):
    """Atomic verified move: never overwrite or delete a mismatching original.

    A hardlink makes same-device moves instantaneous; cross-device copies use
    a staging file and checksum. Legacy is removed ONLY after content matches.
    """
    ext = os.path.splitext(old_path)[1].lower()
    if _image_type(old_path) != ext:
        return ''
    with _IMAGE_LOCK:
        # If this package already has a valid picture in another format,
        # keep that original rather than introducing a competing .png/.jpg.
        stem = os.path.splitext(os.path.basename(new_path))[0]
        chosen = _saved_at(os.path.dirname(new_path), stem)
        if chosen and chosen != new_path:
            return chosen
        if os.path.lexists(new_path):
            try:
                if _image_type(new_path) == ext and _digest(new_path) == _digest(old_path):
                    os.unlink(old_path)  # Verified duplicate, no actual image lost.
                return new_path if _image_type(new_path) == ext else ''
            except Exception:
                return new_path if _image_type(new_path) == ext else ''
        directory = os.path.dirname(new_path)
        tmp = ''
        try:
            if not os.path.isdir(directory):
                os.makedirs(directory)
            try:
                os.link(old_path, new_path)
            except (OSError, IOError):
                tmp = '%s.part.%d.%d' % (new_path, os.getpid(), threading.current_thread().ident or 0)
                shutil.copyfile(old_path, tmp)
                if _image_type(tmp) != ext or _digest(tmp) != _digest(old_path):
                    return ''
                if os.path.lexists(new_path):
                    return new_path if _image_type(new_path) == ext else ''
                os.rename(tmp, new_path)
                tmp = ''
            if _image_type(new_path) == ext and _digest(new_path) == _digest(old_path):
                os.unlink(old_path)
                return new_path
            # Keep the old image in place if verification fails.
            return ''
        except Exception:
            return new_path if _image_type(new_path) == ext else ''
        finally:
            if tmp:
                try:
                    if os.path.isfile(tmp):
                        os.unlink(tmp)
                except Exception:
                    pass


def _prune_empty_old_folders(base_root):
    """Remove *empty* old genre/images/tivimatee2 folders, never user content."""
    try:
        for folder in (base_root, os.path.dirname(base_root), os.path.dirname(os.path.dirname(base_root))):
            if folder in (_OLD_FLASH_ROOT, '/etc/enigma2/tivimatee2_py27', '/etc/enigma2/tivimatee2_py27/images'):
                # Never remove the plugin's original /etc/enigma2 folder.
                if folder != base_root:
                    continue
            if os.path.isdir(folder) and not os.path.islink(folder):
                os.rmdir(folder)  # Only succeeds if truly empty.
    except (OSError, IOError):
        pass
    except Exception:
        pass


def _background_migrate(target_root):
    """Migrate remaining (not-yet-opened) GENRE pictures off the GUI thread."""
    for old_root in _legacy_image_roots():
        if old_root == target_root or not os.path.isdir(old_root):
            continue
        try:
            for base, dirs, files in os.walk(old_root, topdown=True, followlinks=False):
                dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(base, d))]
                rel_folder = os.path.relpath(base, old_root)
                parts = rel_folder.split(os.sep)
                if len(parts) != 2 or not _LEGACY_SERVER_RE.match(parts[0]) or parts[1] not in ('movies', 'series'):
                    continue
                for name in files:
                    if not _LEGACY_IMAGE_RE.match(name):
                        continue
                    old_path = os.path.join(base, name)
                    target_path = os.path.join(target_root, rel_folder, name)
                    _migrate_one(old_path, target_path)
            # Bottom-up pruning; other files/directories must remain untouched.
            for base, _dirs, _files in os.walk(old_root, topdown=False):
                try:
                    os.rmdir(base)
                except (OSError, IOError):
                    pass
            _prune_empty_old_folders(old_root)
        except Exception:
            pass


def _schedule_migration():
    root = _image_root()
    with _IMAGE_LOCK:
        if root in _MIGRATION_STARTED:
            return
        _MIGRATION_STARTED.add(root)
    try:
        if not any(os.path.isdir(r) for r in _legacy_image_roots() if r != root):
            return
        worker = thread_factory(target=_background_migrate, args=(root,),
                                  name='TiviMateGenreImageMigration')
        worker.daemon = True
        worker.start()
    except Exception:
        pass


def saved_genre_image(source, kind, category_id):
    """Return the permanent picture instantly, falling back to a legacy picture.

    The old path is moved and verified on the first access to that category;
    all other old pictures are migrated once in the background.
    """
    stem = _stem(category_id)
    if not stem:
        return ''
    new_folder = _folder(source, kind)
    picture = _saved_at(new_folder, stem)
    if picture:
        _schedule_migration()
        return picture
    # A user may rename a provider without changing URL/MAC/login. Existing
    # permanent package pictures are still valid under its former folder name.
    for older_folder in _same_server_old_folders(source, kind):
        picture = _saved_at(older_folder, stem)
        if picture:
            return picture
    # Some previous builds used images/Genre, images/Gener or
    # images/Packages while retaining this SAME server hash + category stem.
    # Probe those directories only when canonical cache misses. Never mix
    # servers or return an unvalidated generic GENERAL image.
    relative = _relative_folder(source, kind)
    for alt in ('Genre', 'GENRE', 'Gener', 'Packages', 'packages'):
        base = os.path.join(os.path.dirname(_image_root()), alt)
        for alternate_folder in (os.path.join(base, relative),):
            picture = _saved_at(alternate_folder, stem)
            if picture:
                return picture
    # Previous server names may differ while authentication identity is the
    # same. A bounded scan by the stable digest is safer than a global lookup.
    suffix = '_' + hashlib.sha256(_server_identity(source).encode('utf-8')).hexdigest()[:16]
    for alt in ('Genre', 'GENRE', 'Gener', 'Packages', 'packages'):
        base = os.path.join(os.path.dirname(_image_root()), alt)
        try:
            matches = [name for name in os.listdir(base)
                       if name.endswith(suffix)][:16]
        except (OSError, IOError):
            matches = []
        for name in matches:
            picture = _saved_at(os.path.join(base, name,
                               'series' if kind == 'series' else 'movies'), stem)
            if picture:
                return picture
    for legacy_root in _legacy_image_roots():
        legacy_folder = os.path.join(legacy_root, relative)
        old_picture = _saved_at(legacy_folder, stem)
        if old_picture:
            new_picture = _migrate_one(old_picture, os.path.join(new_folder, os.path.basename(old_picture)))
            _schedule_migration()
            return new_picture or old_picture
    _schedule_migration()
    return ''


def save_genre_image(source, kind, category_id, downloaded_path):
    """Save the first valid picture on the configured storage; never overwrite."""
    ext = _image_type(downloaded_path)
    stem = _stem(category_id)
    if not ext or not stem:
        return ''
    with _IMAGE_LOCK:
        existing = saved_genre_image(source, kind, category_id)
        if existing:
            return existing
        directory = _folder(source, kind)
        # Never fill the last flash blocks with permanently saved artwork.
        if directory.startswith('/etc/enigma2/'):
            try:
                stat = os.statvfs('/etc/enigma2')
                if stat.f_bavail * stat.f_frsize < 30 * 1024 * 1024:
                    return ''
            except Exception:
                return ''
        tmp = ''
        try:
            if not os.path.isdir(directory):
                os.makedirs(directory)
            target = os.path.join(directory, stem + ext)
            tmp = '%s.part.%d.%d' % (target, os.getpid(), threading.current_thread().ident or 0)
            shutil.copyfile(downloaded_path, tmp)
            if _image_type(tmp) != ext:
                return ''
            if os.path.lexists(target):
                return target if _image_type(target) == ext else ''
            os.rename(tmp, target)
            return target
        except Exception:
            return ''
        finally:
            if tmp:
                try:
                    if os.path.isfile(tmp):
                        os.unlink(tmp)
                except Exception:
                    pass
