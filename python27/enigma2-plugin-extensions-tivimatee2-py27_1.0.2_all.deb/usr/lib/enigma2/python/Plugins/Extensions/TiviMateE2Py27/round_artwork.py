# -*- coding: utf-8 -*-
"""Cached transparent circle rendering for DreamOS/Python 2.7 artwork.

Never modifies the source image. PIL work stays off Enigma2's GUI thread.
The bounded pool has only two workers, independent of poster download queues.
"""
from __future__ import absolute_import
import os
import tempfile
import threading
from .py27_futures import ThreadPoolExecutor

_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix='TiviCircleMask')
_LOCKS = [threading.Lock() for _ in range(12)]

def _target(path, size):
    stem, _ext = os.path.splitext(path)
    return stem + '.tivi-circle-%s.png' % int(size)

def cached(path, size):
    try:
        dest = _target(path, size)
        if (os.path.isfile(dest) and os.path.getsize(dest) > 256 and
                os.path.getmtime(dest) >= os.path.getmtime(path)):
            return dest
    except (IOError, OSError, ValueError, TypeError):
        pass
    return ''

def make_circle(path, size):
    try:
        size = int(size)
        if not path or size < 20 or size > 512 or not os.path.isfile(path):
            return path
        hit = cached(path, size)
        if hit:
            return hit
        from PIL import Image, ImageDraw
        key = abs(hash((path, size))) % len(_LOCKS)
        with _LOCKS[key]:
            hit = cached(path, size)
            if hit:
                return hit
            image = Image.open(path)
            try:
                rgb = image.convert('RGBA')
            finally:
                try: image.close()
                except Exception: pass
            w, h = rgb.size
            if w < 4 or h < 4:
                return path
            sample = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
            ratio = max(float(size) / float(w), float(size) / float(h))
            width = max(size, int(round(w * ratio)))
            height = max(size, int(round(h * ratio)))
            rgb = rgb.resize((width, height), sample)
            left = max(0, (width - size) // 2)
            top = max(0, (height - size) // 2)
            rgb = rgb.crop((left, top, left + size, top + size))
            mask = Image.new('L', (size, size), 0)
            ImageDraw.Draw(mask).ellipse((1, 1, size-2, size-2), fill=255)
            rgb.putalpha(mask)
            dest = _target(path, size)
            fd, tmp = tempfile.mkstemp(prefix='.tivi-round-', suffix='.png', dir=os.path.dirname(dest))
            os.close(fd)
            try:
                rgb.save(tmp, 'PNG')
                if os.path.getsize(tmp) < 256:
                    return path
                # Python 2.7's os.rename does not overwrite on every platform.
                try: os.rename(tmp, dest)
                except OSError:
                    if os.path.exists(dest): os.unlink(dest)
                    os.rename(tmp, dest)
            finally:
                try:
                    if os.path.exists(tmp): os.unlink(tmp)
                except OSError: pass
            return dest
    except Exception:
        # Pillow is not guaranteed on DreamOS/Python 2.7. Try the receiver's
        # existing ffmpeg binary with a bundled precomputed alpha mask.
        # Never modify source bytes or block the Enigma2 GUI thread.
        try:
            from .py27_compat import which, subprocess_run
            import subprocess
            ffmpeg = which('ffmpeg')
            mask = os.path.join(os.path.dirname(__file__), 'skins', 'common',
                                'round_alpha_%s.png' % size)
            if not ffmpeg or not os.path.isfile(mask):
                return path
            dest = _target(path, size)
            if cached(path, size):
                return dest
            tmp = dest + '.ffmpeg.%s.png' % os.getpid()
            args = [ffmpeg, '-nostdin', '-loglevel', 'error', '-y', '-i', path,
                    '-i', mask, '-filter_complex',
                    '[0:v]scale=%d:%d:force_original_aspect_ratio=increase,'
                    'crop=%d:%d,format=rgba[image];'
                    '[1:v]format=gray[mask];[image][mask]alphamerge' %
                    (size, size, size, size),
                    '-frames:v', '1', '-f', 'image2', '-vcodec', 'png', tmp]
            subprocess_run(args, check=True, timeout=9,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if os.path.getsize(tmp) > 256:
                os.rename(tmp, dest)
                return dest
        except Exception:
            pass
        finally:
            try:
                if 'tmp' in locals() and os.path.isfile(tmp): os.unlink(tmp)
            except OSError: pass
        # Some older DreamOS installations have ImageMagick but no Pillow
        # and no ffmpeg. Do not show an uncropped black square if convert works.
        try:
            from .py27_compat import which, subprocess_run
            import subprocess
            tool = which('convert')
            mask = os.path.join(os.path.dirname(__file__), 'skins', 'common',
                                'round_alpha_%s.png' % size)
            if tool and os.path.isfile(mask):
                dest = _target(path, size)
                tmp = dest + '.convert.%s.png' % os.getpid()
                subprocess_run([tool, path, '-auto-orient', '-resize',
                                '%sx%s^' % (size, size), '-gravity', 'center',
                                '-extent', '%sx%s' % (size, size), mask,
                                '-alpha', 'off', '-compose', 'CopyOpacity',
                                '-composite', tmp],
                               check=True, timeout=9,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if os.path.getsize(tmp) > 256:
                    try: os.rename(tmp, dest)
                    except OSError:
                        if os.path.exists(dest): os.unlink(dest)
                        os.rename(tmp, dest)
                    return dest
        except Exception:
            pass
        finally:
            try:
                if 'tmp' in locals() and os.path.exists(tmp): os.unlink(tmp)
            except OSError:
                pass
        return path

def prepare_circle(path, size, callback):
    """Call callback on GUI thread, with cached circular PNG or source fallback."""
    hit = cached(path, size)
    if hit:
        callback(hit)
        return
    try:
        from twisted.internet import reactor
    except Exception:
        reactor = None
    # Without reactor, avoid calling Enigma widgets from a background thread.
    if reactor is None:
        callback(make_circle(path, size))
        return
    def work():
        return make_circle(path, size)
    def ready(future):
        try: result = future.result()
        except Exception: result = path
        reactor.callFromThread(callback, result)
    try:
        _POOL.submit(work).add_done_callback(ready)
    except Exception:
        callback(path)
