# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
"""Asynchronous, cache-first Windows picon letterboxing.

Keeps PIL file opening/thumbnail creation off Enigma2's GUI thread. Existing
cached v2 thumbnails are accepted to avoid reprocessing after an update.
"""
import hashlib
import os
import threading

try:
    from PIL import Image, ImageOps
except ImportError:
    # DreamOS Python2 distributions frequently omit Pillow.
    Image = ImageOps = None

from .cache_manager import get_cache_dir
from .artwork_queue import valid_image_file
from .ultra_stalker_engine.core.executor import LazyThreadPoolExecutor

_LOCK = threading.RLock()
_PENDING = {}
_EXECUTOR = LazyThreadPoolExecutor(max_workers=2, thread_name_prefix="ultrastalker-picon-render")


def _details(path, mode):
    stat = os.stat(path)
    if mode == 'tile':
        tag = 'windows-logo-100x76-small-v4'
        prefix = 'windows_tilelogo_small_'
        dimensions = (100, 76)
        content_size = (94, 67)
    elif mode == 'grid-poster':
        tag = 'windows-grid-126x160-v3'
        prefix = 'windows_grid_'
        dimensions = (126, 160)
        content_size = (112, 146)
    else:
        tag = 'info148x110-small-v4'
        prefix = 'windows_infol_logo_small_'
        dimensions = (148, 110)
        content_size = (142, 87)
    # Older thumbnails used mtime. Accept them if they exist.
    if mode == 'tile':
        legacy_key = '%s|%d|%d|%s' % (path, stat.st_size, int(stat.st_mtime), tag)
    else:
        legacy_key = '%s|%s|%s|%s' % (path, stat.st_size, int(stat.st_mtime), tag)
    if mode == 'grid-poster':
        legacy_key = '%s|%d|%d|%s' % (path, stat.st_size, int(stat.st_mtime), tag)
    legacy_hash = hashlib.sha1(legacy_key.encode('utf-8')).hexdigest()[:20 if mode == 'grid-poster' else 18]
    legacy = os.path.join(os.path.dirname(path), prefix + legacy_hash + '.png')
    # New key is stable across atime/mtime touch for HDD and internal flash.
    key = '%s|%s|%s|%s|v3' % (path, stat.st_size, stat.st_ino, mode)
    digest = hashlib.sha1(key.encode('utf-8')).hexdigest()[:18]
    # Always store generated thumbnails under the plugin-owned picons cache.
    # Normal Live icons already live here: keep their previous filenames and
    # avoid re-encoding them when upgrading. For a foreign source path, use
    # an isolated subfolder, never the source directory or global /hdd/picon.
    cache_dir = get_cache_dir('picons')
    root = os.path.dirname(path)
    if os.path.normpath(root) != os.path.normpath(cache_dir):
        root = os.path.join(cache_dir, 'render')
        if not os.path.isdir(root):
            try:
                os.makedirs(root)
            except OSError:
                if not os.path.isdir(root):
                    raise
    dest = os.path.join(root, prefix + digest + '.png')
    return legacy, dest, dimensions, content_size


def cached_windows_picon(path, mode):
    if not path or not os.path.isfile(path):
        return ''
    try:
        legacy, dest, _dimensions, _content = _details(path, mode)
        if valid_image_file(dest, 100):
            return dest
        if valid_image_file(legacy, 100):
            return legacy
    except Exception:
        pass
    return ''


def _notify(callback, result):
    try:
        from twisted.internet import reactor
        reactor.callFromThread(callback, result)
    except Exception:
        try: callback(result)
        except Exception: pass


def request_windows_picon(path, mode, callback):
    """Return cached thumbnail now, or build once and deliver on GUI thread."""
    if not path or mode not in ('tile', 'info', 'grid-poster') or not os.path.isfile(path):
        return ''
    # Native ePicLoad downstream can decode the original when Pillow is
    # unavailable. Preserve the same cache and never start a network fetch.
    if Image is None or ImageOps is None:
        return path if valid_image_file(path, 100) else ''
    try:
        legacy, dest, dimensions, content = _details(path, mode)
        # A miss used to compute _details() twice, including file stat and
        # hashes, for every displayed tile. Reuse one lookup per request.
        if valid_image_file(dest, 100):
            return dest
        if valid_image_file(legacy, 100):
            return legacy
    except Exception:
        return ''
    with _LOCK:
        if dest in _PENDING:
            _PENDING[dest].append(callback)
            return ''
        _PENDING[dest] = [callback]

    def work():
        result = ''
        try:
            if valid_image_file(dest, 100):
                result = dest
            else:
                resample = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS')
                with Image.open(path) as image:
                    if mode == 'grid-poster':
                        # Preserve the exact old poster geometry and cropping.
                        try:
                            photo = ImageOps.exif_transpose(image)
                        except Exception:
                            photo = image
                        resized = ImageOps.fit(photo.convert('RGB'), content,
                                               method=resample, centering=(0.5, 0.5)).convert('RGBA')
                    else:
                        resized = image.convert('RGBA')
                        resized.thumbnail(content, resample)
                    canvas = Image.new('RGBA', dimensions, (0, 0, 0, 0))
                    offset = ((dimensions[0] - resized.size[0]) // 2,
                              (dimensions[1] - resized.size[1]) // 2)
                    canvas.paste(resized, offset, resized)
                    temporary = dest + '.new'
                    try:
                        canvas.save(temporary, 'PNG', compress_level=4)
                        atomic_replace(temporary, dest)
                        result = dest
                    finally:
                        if os.path.exists(temporary):
                            os.unlink(temporary)
        except Exception:
            # Never let unsupported Pillow features erase existing picons.
            result = path if valid_image_file(path, 100) else ''
        finally:
            with _LOCK:
                callbacks = _PENDING.pop(dest, [])
            for done in callbacks:
                _notify(done, result)

    try:
        _EXECUTOR.submit(work, _task_key=dest)
    except Exception:
        with _LOCK:
            _PENDING.pop(dest, None)
    return ''


def request_windows_grid_poster(path, callback):
    """Cache-first 126x160 grid poster using Ultra's bounded worker lane."""
    return request_windows_picon(path, 'grid-poster', callback)
