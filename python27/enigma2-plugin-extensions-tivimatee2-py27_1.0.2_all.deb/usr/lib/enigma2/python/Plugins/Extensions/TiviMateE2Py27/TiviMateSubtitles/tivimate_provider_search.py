# -*- coding: utf-8 -*-
'''
Created on Aug 2, 2014

@author: marko
'''
from __future__ import absolute_import
from __future__ import print_function

import sys
import json

# The external Python 2 worker may not inherit Enigma2's embedded sys.path.
# Add only the plugin's canonical Python package root.
import os
_package_root = os.path.abspath(os.path.join(os.path.dirname(__file__),
                                               '..', '..', '..', '..'))
if _package_root not in sys.path:
    sys.path.insert(0, _package_root)
# import time
import traceback

try:
    import six
except ImportError:
    # DreamOS Python 2 may have no system six. Use only the bundled copy.
    try:
        import imp
        six = imp.load_source('six', os.path.join(os.path.dirname(__file__), '_vendor_six.py'))
    except Exception:
        six = None



def _subtitle_worker_log(message):
    """Persistent, receiver-local failure diagnosis; no search API keys logged."""
    try:
        from Plugins.Extensions.TiviMateE2Py27.storage import data_path
        filename = data_path('subtitle_provider_debug.log')
        if os.path.isfile(filename) and os.path.getsize(filename) > 512 * 1024:
            with open(filename, 'w') as handle:
                handle.write('Subtitle worker log rotated\n')
        import time
        with open(filename, 'a') as handle:
            handle.write('%s [worker] %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'),
                                                message))
    except Exception:
        pass

stdout = None


class Messages(object):
    MESSAGE_CAPTCHA_CALLBACK = 1
    MESSAGE_UPDATE_CALLBACK = 2
    MESSAGE_DELAY_CALLBACK = 3
    MESSAGE_CANCELLED_SCRIPT = 4
    MESSAGE_FINISHED_SCRIPT = 5
    MESSAGE_ERROR_SCRIPT = 6
    MESSAGE_CHOOSE_FILE_CALLBACK = 7
    MESSAGE_OVERWRITE_CALLBACK = 8


def _json_safe(value):
    """Return a json.dumps-safe value on both Python 2 and Python 3."""
    try:
        # Removed unused 'string_types' variable to fix F841
        text_type = six.text_type if six is not None else str
        binary_type = six.binary_type if six is not None else bytes
    except Exception:
        text_type = str
        binary_type = bytes

    if value is None or isinstance(value, (bool, int, float)):
        return value

    # Python 2: keep unicode as unicode, decode byte strings where possible.
    if six is not None and six.PY2:
        if isinstance(value, text_type):
            return value
        if isinstance(value, binary_type):
            try:
                return value.decode('utf-8')
            except Exception:
                return value.decode('utf-8', 'ignore')
    else:
        if isinstance(value, binary_type):
            try:
                return value.decode('utf-8', 'ignore')
            except Exception:
                return str(value)
        if isinstance(value, text_type):
            return value

    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return dict((_json_safe(k), _json_safe(v)) for k, v in value.items())

    # Exceptions/custom objects are not JSON serializable. Send readable text.
    try:
        if six is not None and six.PY2:
            return text_type(value)
        return str(value)
    except Exception:
        return ""


def send(mtype, m):
    dump = json.dumps({'message': mtype, 'value': _json_safe(m)})
    dump = "%07d%s" % (len(dump) + 7, dump)
    stdout.write(dump)
    stdout.flush()


def recieve():
    return json.loads(sys.stdin.read(int(sys.stdin.read(7))))


def delayCB(seconds):
    send(Messages.MESSAGE_DELAY_CALLBACK, seconds)
    recieve()


def captchaCB(image):
    send(Messages.MESSAGE_CAPTCHA_CALLBACK, image)
    return recieve()


def messageCB(text):
    print('messageCB:', text)


def updateCB(*args):
    send(Messages.MESSAGE_UPDATE_CALLBACK, args)


def chooseFileCB(*args):
    send(Messages.MESSAGE_CHOOSE_FILE_CALLBACK, args)
    return recieve()


def overwriteFileCB(*args):
    send(Messages.MESSAGE_OVERWRITE_CALLBACK, args)
    return recieve()


def scriptError(e):
    try:
        from .seekers.seeker import SubtitlesErrors, BaseSubtitlesError
    except (ValueError, ImportError):
        from seekers.seeker import SubtitlesErrors, BaseSubtitlesError
    # Keep the original error_code for existing callbacks, but expose class and
    # reason instead of silently showing an empty subtitle list.
    try:
        reason = '%s: %s' % (e.__class__.__name__, str(e))
    except Exception:
        reason = e.__class__.__name__
    _subtitle_worker_log('FAILED ' + reason[:350])
    if isinstance(e, BaseSubtitlesError):
        data = {'error_code': e.code, 'provider': e.provider}
    else:
        data = {'error_code': SubtitlesErrors.UNKNOWN_ERROR, 'provider': ''}
    data['message'] = reason[:350]
    if stdout is not None:
        send(Messages.MESSAGE_ERROR_SCRIPT, data)


def scriptFinished(subtitlesDict):
    send(Messages.MESSAGE_FINISHED_SCRIPT, subtitlesDict)


def scriptCancelled(subtitlesDict):
    send(Messages.MESSAGE_CANCELLED_SCRIPT, subtitlesDict)


def searchSubtitles(seeker, options):
    seekers = options.get('providers')
    title = options.get('title')
    filepath = options.get('filepath')
    langs = options.get('langs')
    year = options.get('year')
    tvshow = options.get('tvshow')
    season = options.get('season')
    episode = options.get('episode')
    timeout = options.get('timeout', 10)
    return seeker.getSubtitles(seekers, updateCB, title, filepath, langs, year, tvshow, season, episode, timeout)


def downloadSubtitles(seeker, options):
    overwriteFileCBTmp = None
    if options.get('settings').get('ask_overwrite'):
        overwriteFileCBTmp = overwriteFileCB

    return seeker.downloadSubtitle(
        options.get("selected_subtitle"),
        options.get("subtitles_dict"),
        chooseFileCB,
        options.get("path"),
        options.get("filename"),
        overwriteFileCBTmp,
        options.get("settings"))


def main():
    global stdout
    stdout = sys.stdout
    # The original stdout is the binary/JSON IPC channel to Enigma2.
    # Silence subprocess print/debug output without creating a /tmp log.
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = sys.stdout
    options = recieve()
    _subtitle_worker_log('search=%s download=%s provider_count=%d' % (
        bool(options.get('search')), bool(options.get('download')),
        len((options.get('search') or {}).get('providers') or [])))
    try:
        sys.stdout.flush()
    except Exception:
        pass
    try:
        from .seek import SubsSeeker
    except (ValueError, ImportError):
        from seek import SubsSeeker
    seeker = SubsSeeker(options.get('download_path', '/tmp/'),
                        options.get('tmp_path', '/tmp/'),
                        captchaCB, delayCB, messageCB,
                        options.get('settings'))
    if options.get('search'):
        # Report providers that are registered but cannot load their optional
        # dependencies on this Python 2.7 image. Do not pretend they ran.
        try:
            unavailable = [(p.id, p.error) for p in seeker.seekers
                           if getattr(p, 'error', None) is not None]
            for provider_id, reason in unavailable:
                reason_type = reason.__class__.__name__
                # ImportError arguments are generally the missing module name
                # or a missing import symbol; log only safe identifiers.
                import re
                try:
                    raw_reason = str(reason).strip()
                except Exception:
                    raw_reason = ''
                try:
                    match = re.search(r"(?:No module named|cannot import name)\s+['\"]?([A-Za-z0-9_.]+)", raw_reason)
                    reason_name = match.group(1) if match else ''
                except Exception:
                    reason_name = ''
                _subtitle_worker_log('unavailable %s: %s%s' %
                                     (provider_id, reason_type,
                                      (' / ' + reason_name) if reason_name else ''))
        except Exception:
            pass
        results = searchSubtitles(seeker, options['search'])
        try:
            failures = [(key, payload.get('message', '')) for key, payload in
                        (results or {}).items() if isinstance(payload, dict)
                        and payload.get('status') is False]
            count = sum(len(v.get('list') or []) for v in (results or {}).values()
                        if isinstance(v, dict))
            _subtitle_worker_log('completed: results=%d failed_providers=%d' %
                                 (count, len(failures)))
            for provider, reason in failures[:15]:
                _subtitle_worker_log('provider %s: %s' % (provider, str(reason)[:160]))
        except Exception as e:
            _subtitle_worker_log('diagnostic failed: %s' % e.__class__.__name__)
        return results
    elif options.get('download'):
        return downloadSubtitles(seeker, options['download'])


if __name__ == '__main__':
    try:
        scriptFinished(main())
        stdout.close()
        sys.stdout.close()
        sys.exit(0)
    except KeyboardInterrupt:
        scriptCancelled({})
        stdout.close()
        sys.stdout.flush()
        sys.stdout.close()
        sys.exit(0)
    except Exception as e:
        _subtitle_worker_log('TRACE ' + traceback.format_exc()[-2000:])
        scriptError(e)
        if stdout is None:
            sys.exit(1)
        stdout.close()
        sys.stdout.close()
        sys.exit(1)
