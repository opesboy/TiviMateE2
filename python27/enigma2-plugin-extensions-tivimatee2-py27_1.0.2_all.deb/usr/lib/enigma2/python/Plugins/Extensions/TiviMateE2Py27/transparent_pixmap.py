# -*- coding: utf-8 -*-
"""GUI-thread-only native PNG paint on old DreamOS.

The Python2 ePicLoad resize path can fill fully transparent PNG pixels with
black. Skin alphaTest=blend works with LoadPixmap for already-sized PNG files.
Caller must verify the current artwork request/token before invoking this.
"""
from __future__ import absolute_import
import os


def show(screen, widget_name, path):
    if not path or not path.lower().endswith('.png') or not os.path.isfile(path):
        return None
    try:
        from Tools.LoadPixmap import LoadPixmap
        ptr = LoadPixmap(path=path)
        widget = screen[widget_name]
        if ptr is None or widget.instance is None:
            return None
        try:
            widget.instance.setScale(1)
        except (AttributeError, TypeError):
            pass
        widget.instance.setPixmap(ptr)
        widget.show()
        return ptr
    except Exception:
        return None
