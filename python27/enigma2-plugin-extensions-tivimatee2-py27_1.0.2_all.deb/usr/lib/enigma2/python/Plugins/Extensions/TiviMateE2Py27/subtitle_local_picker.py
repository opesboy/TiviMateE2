# -*- coding: utf-8 -*-
"""Self-contained DreamOS-safe local .srt/.ass subtitle file selector.

Does not import the provider-search subsystem until the user selects a file.
"""
from __future__ import absolute_import
import os

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Screens.Screen import Screen
from .display_scale import scale_skin
from .py27_compat import gui_text, text_type


_SUB_EXTENSIONS = ('.srt', '.ass', '.ssa', '.sub', '.vtt', '.txt')


class TiviMateLocalSubtitlePicker(Screen):
    skin = '''<screen name="TiviMateLocalSubtitlePicker" position="center,center" size="1920,1080" backgroundColor="#10141B" flags="wfNoBorder">
        <eLabel position="40,36" size="1840,90" backgroundColor="#1C2838" zPosition="1" />
        <widget name="titleLabel" position="70,48" size="1750,64" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#1C2838" transparent="1" zPosition="2" />
        <widget name="directory" position="70,135" size="1750,42" font="Regular;24" foregroundColor="#CFD9E5" backgroundColor="#10141B" transparent="1" />
        <widget name="files" position="60,200" size="1800,720" scrollbarMode="showOnDemand" backgroundColor="#10141B" foregroundColor="#FFFFFF" />
        <eLabel position="40,940" size="1840,1" backgroundColor="#3B4B5C" />
        <widget name="hint" position="70,962" size="1740,62" font="Regular;26" foregroundColor="#D9E5F3" backgroundColor="#10141B" transparent="1" />
    </screen>'''

    def __init__(self, session):
        Screen.__init__(self, session)
        self["titleLabel"] = Label("IMPORT SUBTITLE FILE")
        self["directory"] = Label("")
        self["hint"] = Label("OK: OPEN / IMPORT     GREEN: IMPORT     RED: BACK     BLUE: ROOT")
        self._folder = next((folder for folder in ('/media/hdd/', '/media/usb/', '/media/mmc/', '/tmp/')
                             if os.path.isdir(folder)), '/')
        self._entries = {}
        self['files'] = MenuList([])
        self['actions'] = ActionMap(
            ['OkCancelActions', 'ColorActions', 'DirectionActions'],
            {'ok': self._choose, 'green': self._choose,
             'cancel': self.close, 'red': self.close, 'blue': self._root,
             'up': self._up, 'down': self._down,
             'left': self._pageUp, 'right': self._pageDown}, -2)
        self.onLayoutFinish.append(self._refresh)

    def _refresh(self):
        folder = self._folder
        self['directory'].setText(gui_text(folder))
        rows = []
        entries = {}
        if os.path.realpath(folder) != '/':
            label = '[..] Parent folder'
            rows.append(label)
            entries[label] = (os.path.dirname(os.path.normpath(folder)) or '/', True)
        try:
            filenames = os.listdir(folder)
        except Exception:
            filenames = []
        dirs, files = [], []
        for name in filenames:
            try:
                path = os.path.join(folder, name)
                if os.path.isdir(path):
                    dirs.append((name, path))
                elif os.path.isfile(path) and os.path.splitext(name)[1].lower() in _SUB_EXTENSIONS:
                    files.append((name, path))
            except Exception:
                continue
        for group, prefix, is_directory in ((dirs, '[DIR] ', True), (files, '', False)):
            for name, path in sorted(group, key=lambda pair: pair[0].lower()):
                label = prefix + gui_text(text_type(name))
                rows.append(label)
                entries[label] = (path, is_directory)
        if not rows:
            rows = ['No subtitle files here - BLUE to open root']
        self._entries = entries
        self['files'].setList(rows)

    def _up(self):
        self['files'].up()

    def _down(self):
        self['files'].down()

    def _pageUp(self):
        self['files'].pageUp()

    def _pageDown(self):
        self['files'].pageDown()

    def _root(self):
        self._folder = '/'
        self._refresh()

    def _choose(self):
        try:
            label = self['files'].getCurrent()
            selected = self._entries.get(label)
            if not selected:
                return
            path, is_directory = selected
            if is_directory:
                self._folder = path
                self._refresh()
                return
            native_path = gui_text(path)
            if os.path.isfile(native_path):
                self.close(native_path)
        except Exception as exc:
            print('[TiviMateE2Py27] local subtitle picker: %s' % exc)


TiviMateLocalSubtitlePicker.skin = scale_skin(TiviMateLocalSubtitlePicker.skin)
