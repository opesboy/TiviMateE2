# -*- coding: utf-8 -*-
"""True-alpha 400x224 Live infobar capsule, compatible with Python 2.7.

Use the same PIL crop as Python 3 when available. On receivers without PIL,
try FFmpeg or ImageMagick in the *existing artwork worker* (not GUI thread).
Never replace an original downloaded backdrop: the cropped PNG is separately
cached by source path, size and mtime.
"""
import hashlib
import os
import subprocess

from .storage import data_path
from .py27_compat import atomic_replace

CAPSULE_SIZE = (400, 224)
_MASK_PATH = os.path.join(os.path.dirname(__file__), 'skins', 'live_infobar', 'capsule_alpha_mask.png')


def _valid_png(path):
    try:
        if os.path.getsize(path) < 1000:
            return False
        with open(path, 'rb') as fp:
            return fp.read(8) == b'\x89PNG\r\n\x1a\n'
    except Exception:
        return False


def _with_pillow(source_path, target):
    from PIL import Image, ImageFilter, ImageOps
    resample = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
    original = Image.open(source_path)
    try:
        original.load()
        original = original.convert('RGB')
        width, height = CAPSULE_SIZE
        ow, oh = original.size  # PIL on Python 2 has no Image.width attribute.
        if ow * height >= oh * width * 0.65:
            canvas = ImageOps.fit(original, CAPSULE_SIZE, method=resample, centering=(0.5, 0.5)).convert('RGBA')
        else:
            bg = ImageOps.fit(original, CAPSULE_SIZE, method=resample).filter(ImageFilter.GaussianBlur(18)).convert('RGBA')
            inset = ImageOps.contain(original, (int(width * 0.90), height), method=resample).convert('RGBA')
            # Older Pillow releases do not provide Image.alpha_composite method.
            bg.paste(inset, ((width - inset.size[0]) // 2, (height - inset.size[1]) // 2), inset)
            canvas = bg
        alpha = Image.open(_MASK_PATH).convert('L')
        canvas.putalpha(alpha)
        canvas.save(target, format='PNG', optimize=True)
    finally:
        try:
            original.close()
        except Exception:
            pass


def _run_quiet(args):
    with open(os.devnull, 'wb') as null:
        try:
            return subprocess.call(args, stdin=null, stdout=null, stderr=null) == 0
        except (OSError, ValueError):
            return False


def _with_ffmpeg(source_path, target):
    cmd = ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error',
           '-y', '-threads', '1', '-i', source_path, '-i', _MASK_PATH,
           '-filter_complex',
           '[0:v]scale=400:224:force_original_aspect_ratio=increase,'
           'crop=400:224,format=rgb24[art];'
           '[1:v]format=gray[alpha];'
           '[art][alpha]alphamerge,format=rgba[out]',
           '-map', '[out]', '-frames:v', '1', '-update', '1',
           '-c:v', 'png', '-f', 'image2', target]
    return _run_quiet(cmd) and _valid_png(target)


def _with_imagemagick(source_path, target):
    cmd = ['convert', source_path, '-auto-orient', '-resize', '400x224^',
           '-gravity', 'center', '-extent', '400x224', _MASK_PATH,
           '-alpha', 'off', '-compose', 'CopyOpacity', '-composite', target]
    return _run_quiet(cmd) and _valid_png(target)


def prepare_pill_image(source_path):
    source_path = source_path or ''
    if not source_path or not os.path.isfile(source_path):
        return source_path
    try:
        stat = os.stat(source_path)
        stamp = '%s|%s|%s|pill4' % (source_path, stat.st_size, int(stat.st_mtime))
        digest = hashlib.sha256(stamp.encode('utf-8')).hexdigest()[:24]
        target = data_path('live_infobar', 'pill_%s.png' % digest)
        if _valid_png(target):
            return target
        tmp = target + '.%d.png' % os.getpid()
        try:
            # Convert off the GUI thread; no network operation here.
            try:
                _with_pillow(source_path, tmp)
            except Exception:
                pass
            if not _valid_png(tmp):
                if not _with_ffmpeg(source_path, tmp):
                    _with_imagemagick(source_path, tmp)
            if _valid_png(tmp):
                atomic_replace(tmp, target)
                return target
        finally:
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass
    except Exception:
        pass
    # Existing native cornerRadius support remains the final fallback.
    return source_path
