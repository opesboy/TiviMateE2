# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import ensure_dir
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace, int_from_bytes, monotonic, subprocess_run, thread_ident, which
"""GENRE-only first-paint downloader adapted from UltraStalker's provider path.

The rest of TiviMateE2 still uses artwork_queue. The shared cache layout is
unchanged, so completed artwork remains reusable by the other pages.  Work
that touches the network or image codecs runs in a bounded executor.
"""
from Plugins.Extensions.TiviMateE2Py27.py27_futures import ThreadPoolExecutor
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit, quote, unquote, urlunsplit
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, build_opener, HTTPRedirectHandler
import hashlib
import os
import tempfile
from contextlib import closing
import threading
import time
import subprocess

from .artwork_queue import artwork_path, cached_artwork, normalise_url

_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviGenreUltraArtwork")
_BACKDROP_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix="TiviGenreVisibleBackdrop")
_LOCK = threading.RLock()
_PENDING = {}
_FAILURES = {}
_FAILED_TTL = 25.0
# Keep a short, bounded window. A large window lets rapid navigation retain
# stale cards and callbacks long after the user has moved on, which makes
# GENRE feel crowded on slower receivers. Three workers preserve first-paint
# parallelism while the smaller window gives newly selected cards room sooner.
_MAX_IN_FLIGHT = 25
_GENERIC_UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG250 stbapp"


def _origin(url):
    try:
        s = urlsplit(url or "")
        if s.scheme.lower() not in ("http", "https") or not s.hostname:
            return None
        return (s.scheme.lower(), s.hostname.lower(), s.port or (443 if s.scheme.lower() == "https" else 80))
    except (ValueError, TypeError):
        return None


def _clean_url(url):
    """Match Ultra's URL quoting while preserving signed CDN query values."""
    url = normalise_url(url)
    if len(url) > 1 and url[0] == url[-1] and url[0] in ('"', "'"):
        url = url[1:-1].strip()
    parts = urlsplit(url)
    if _origin(url) is None:
        return ""
    path = quote(parts.path.encode("utf-8") if isinstance(parts.path, unicode) else parts.path, safe="/:@-._~!$&'()*+,;=%")
    query = quote(parts.query.encode("utf-8") if isinstance(parts.query, unicode) else parts.query, safe="=&:@/?-._~!$'()*+,;%")
    return urlunsplit((parts.scheme, parts.netloc, path, query, parts.fragment))


def _headers(url, source):
    source = source or {}
    base = str(source.get("url") or source.get("portal") or source.get("base_url") or "").strip()
    headers = {"User-Agent": _GENERIC_UA, "Accept": "image/jpeg,image/png;q=0.9,image/*;q=0.5,*/*;q=0.1", "Connection": "close"}
    if _origin(base):
        root = urlsplit(base)
        headers["Referer"] = "%s://%s/" % (root.scheme, root.netloc)
    # MAG secrets must never be sent to sibling CDNs or TMDb.
    if _origin(url) == _origin(base) and str(source.get("type") or "").lower() == "stalker":
        mac = str(source.get("mac") or "").strip()
        if mac:
            headers["Cookie"] = "mac=%s; stb_lang=en" % quote(mac, safe="")
            headers["X-User-Agent"] = "Model: MAG250; Link: WiFi"
        try:
            # Reuse established session/token headers only for exact origin.
            from .core import get_source_client
            client = get_source_client(source)
            if callable(getattr(client, "headers", None)):
                identity = client.headers() or {}
                for k, v in identity.items():
                    if k.lower() in ("cookie", "authorization", "x-user-agent", "user-agent", "referer"):
                        headers[k] = str(v)
                headers.pop("Host", None)
        except Exception:
            pass
    return headers


class _ProtectedRedirect(HTTPRedirectHandler):
    """Ultra's provider redirect policy: don't forward MAC/token cross-host."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        redirected = super(_ProtectedRedirect, self).redirect_request(req, fp, code, msg, headers, newurl)
        # urllib2 redirected requests are native Request objects on Python 2.7
        # and need not expose the Python 3 full_url attribute.
        request_url = req.get_full_url() if hasattr(req, "get_full_url") else getattr(req, "full_url", "")
        if redirected is not None and _origin(request_url) != _origin(newurl):
            for key in ("Cookie", "Authorization", "X-User-Agent", "Host"):
                redirected.remove_header(key)
                redirected.headers.pop(key, None)
                redirected.unredirected_hdrs.pop(key, None)
        return redirected


def _valid_file(path):
    try:
        return bool(path and os.path.getsize(path) >= 64 and os.path.isfile(path))
    except OSError:
        return False


def _format(head):
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[:2] == b"BM":
        return "bmp"
    return ""


def _convert_if_needed(temp, dest, fmt):
    if fmt in ("jpeg", "png"):
        atomic_replace(temp, dest)
        return
    try:
        from PIL import Image
        with Image.open(temp) as image:
            image.seek(0)
            image.convert("RGB").save(dest, "JPEG", quality=94)
        return
    except (ImportError, OSError, ValueError):
        pass
    # Enigma2 images without Pillow can still have ffmpeg installed.
    from .image_fetch import convert_to_jpeg
    if not convert_to_jpeg(temp, dest):
        raise ValueError("no usable image decoder for %s" % fmt)


def _download(url, kind, source):
    # Ultra's path: persistent local hit -> short network request -> validated
    # and normalized original. No image work on the main Enigma2 thread.
    existing = cached_artwork(url, kind)
    if existing:
        return existing
    target = artwork_path(url, kind)
    if not target:
        return ""
    ensure_dir(os.path.dirname(target))
    temp = None
    normalized = None
    try:
        fd, temp = tempfile.mkstemp(prefix=".genre_art_", suffix=".part", dir=os.path.dirname(target))
        cap = 12 * 1024 * 1024 if kind in ("backdrops", "episode_hd") else 6 * 1024 * 1024
        opener = build_opener(_ProtectedRedirect())
        request = Request(url, headers=_headers(url, source))
        total = 0
        head = b""
        try:
            with os.fdopen(fd, "wb") as sink, closing(opener.open(request, timeout=3.5)) as response:
                status = getattr(response, "status", 200)
                if status and int(status) >= 400:
                    raise IOError("HTTP %s" % status)
                while True:
                    chunk = response.read(64 * 1024)
                    if not chunk:
                        break
                    if not head:
                        head = chunk[:24]
                    total += len(chunk)
                    if total > cap:
                        raise ValueError("provider image exceeds limit")
                    sink.write(chunk)
        except Exception as error:
            # Python 2.7 urllib2 on DreamOS can fail TLS negotiation with
            # image.tmdb.org while the receiver's wget succeeds.  Retry only
            # public TMDb artwork, never provider URLs or private credentials.
            if ((urlsplit(url).hostname or '').lower() != 'image.tmdb.org'
                    or type(error).__name__ in ('HTTPError', 'ValueError')
                    or not which('wget')):
                raise
            subprocess_run([which('wget'), '-q', '-O', temp, '--tries=1',
                            '--timeout=7', url], check=True, timeout=10,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            total = os.path.getsize(temp)
            if total > cap:
                raise ValueError('TMDb artwork exceeds limit')
            with open(temp, 'rb') as recovered:
                head = recovered.read(24)
            _trace(url, 'tmdb-wget-recovery', error)
        fmt = _format(head)
        if total < 64 or not fmt:
            raise ValueError("invalid image bytes")
        if cached_artwork(url, kind):
            return cached_artwork(url, kind)
        # Validate decoded formats *before* publishing them to the cache.
        if fmt in ("webp", "gif", "bmp"):
            normalized = target + ".converted.%d" % thread_ident()
            _convert_if_needed(temp, normalized, fmt)
            atomic_replace(normalized, target)
        else:
            atomic_replace(temp, target)
        return cached_artwork(url, kind) or (target if _valid_file(target) else "")
    finally:
        for stale in (temp, normalized):
            if stale:
                try:
                    os.unlink(stale)
                except OSError:
                    pass


def _trace(url, kind, exc):
    """Bounded failure diagnostics: NEVER log URLs, passwords or titles."""
    try:
        log_path = '/tmp/tivimatee2_py27_artwork_errors.log'
        if os.path.exists(log_path) and os.path.getsize(log_path) > 65536:
            os.unlink(log_path)
        with open(log_path, 'a') as sink:
            code = getattr(exc, 'returncode', None)
            safe_code = ' exit=%d' % code if isinstance(code, int) else ''
            sink.write('%s %s %s%s\n' % (int(time.time()), kind,
                                           type(exc).__name__, safe_code))
    except Exception:
        pass



# A title logo is not a backdrop.  Ultra's JPEG conversion is correct for
# posters but destroys transparent writing on PNG/WebP title logos.  Keep the
# original logo file and an independent, tiny repair queue.  Cached genuine
# PNG logos appear instantly and never contend with visible poster downloads.
_LOGO_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviGenreClearlogo")
_LOGO_PENDING = {}
_LOGO_RETRY_AT = {}


def _logo_cache_usable(path, url):
    """Accept genuine transparent logos on PIL 1.x, Pillow, or no PIL.

    Never require Python3-era Pillow features; a conservative PNG chunk
    fallback handles RGBA/GA and indexed PNG with a tRNS transparency chunk.
    """
    if not path or not os.path.isfile(path):
        return False
    try:
        with open(path, "rb") as reader:
            header = reader.read(32)
        if not header.startswith(b"\x89PNG\r\n\x1a\n") or len(header) < 26:
            return False
        colour_type = ord(header[25:26])  # type byte is an int on both runtimes
        # For Pillow versions with pixel access, validate non-opaque alpha.
        try:
            from PIL import Image
            img = Image.open(path)
            try:
                width, height = img.size
                if width < 4 or height < 4:
                    return False
                rgba = img.convert("RGBA")
                alpha = rgba.split()[-1]
                low, high = alpha.getextrema()
                return low < 255 and high > 0
            finally:
                try:
                    img.close()
                except (AttributeError, IOError, OSError):
                    pass
        except (ImportError, AttributeError, TypeError, IOError, OSError, ValueError):
            pass
        # A pixel decoder is not always installed on DreamOS Python 2.7.
        # Built-in alpha channels use PNG types 4 or 6. PNG true-colour
        # (type 2), grayscale (type 0) and palette (type 3) can also carry
        # genuine transparency in a tRNS chunk, even on old DreamOS without
        # PIL. Do not reject those legitimate logos as opaque.
        if colour_type in (4, 6):
            return True
        if colour_type not in (0, 2, 3):
            return False
        with open(path, "rb") as reader:
            reader.seek(8)
            scanned = 8
            while scanned < 131072:
                chunk = reader.read(8)
                if len(chunk) != 8:
                    break
                length = int_from_bytes(chunk[:4], "big")
                name = chunk[4:]
                if length < 0 or length > 131072 or scanned + length + 12 > 131072:
                    break
                if name == b"tRNS":
                    return length > 0
                if name in (b"IDAT", b"IEND"):
                    break
                reader.seek(length + 4, 1)
                scanned += length + 12
    except (IOError, OSError, ValueError, TypeError):
        pass
    return False


def _title_logo_path(url):
    """A real transparent PNG must have .png extension for native DreamOS.

    Unsuffixed PHP/provider URLs sometimes return alpha PNG. Their shared
    cache path remains unchanged for generic package branding; only this
    explicitly transparent title-logo request gets a dedicated PNG filename.
    """
    shared = artwork_path(url, 'logos')
    if not shared:
        return ''
    return shared if shared.lower().endswith('.png') else shared[:-4] + '.alpha.png'


def _cached_transparent_logo(url):
    """Use a validated alpha PNG, including old incorrectly named *.jpg files.

    Only verified PNG bytes can be promoted. Posters, backdrops and opaque
    provider-package logos are neither rewritten nor deleted.
    """
    path = _title_logo_path(url)
    if _logo_cache_usable(path, url):
        return path
    if not path:
        return ''
    shared = artwork_path(url, 'logos')
    old = shared[:-4] + '.jpg' if shared.lower().endswith('.png') else shared
    for candidate in (shared, old):
        if candidate == path or not _logo_cache_usable(candidate, url):
            continue
        try:
            ensure_dir(os.path.dirname(path))
            fd, temp = tempfile.mkstemp(prefix='.logo_repair_', suffix='.png',
                                         dir=os.path.dirname(path))
            os.close(fd)
            try:
                import shutil
                shutil.copyfile(candidate, temp)
                if _logo_cache_usable(temp, url):
                    atomic_replace(temp, path)
            finally:
                try: os.unlink(temp)
                except OSError: pass
        except (IOError, OSError, ValueError):
            pass
        if _logo_cache_usable(path, url):
            return path
        # The old validated bytes remain a fallback if the directory is full.
        return candidate
    return ''


def _webp_to_png_with_libwebp(source, destination):
    """Optional native WebP decoder; keep Python 2.7/PIL 1.x compatible.

    Use the system's installed libwebp (if present), never bundle binaries.
    Encode PNG with the standard-library zlib. All writes stay in our temp
    file until a proper alpha PNG is validated and atomically published.
    """
    import ctypes
    import struct
    import zlib
    binary = None
    with open(source, 'rb') as stream:
        binary = stream.read(4 * 1024 * 1024 + 1)
    if not binary or len(binary) > 4 * 1024 * 1024 or _format(binary[:24]) != 'webp':
        raise ValueError('invalid WebP header or size')
    decoder = None
    for name in ('libwebp.so.7', 'libwebp.so.6', 'libwebp.so.5', 'libwebp.so'):
        try:
            decoder = ctypes.CDLL(name)
            break
        except (OSError, AttributeError):
            pass
    if decoder is None:
        raise ImportError('native WebP decoder not installed')
    decoder.WebPGetInfo.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                                     ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
    decoder.WebPGetInfo.restype = ctypes.c_int
    decoder.WebPDecodeRGBA.argtypes = [ctypes.c_void_p, ctypes.c_size_t,
                                        ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int)]
    decoder.WebPDecodeRGBA.restype = ctypes.c_void_p
    decoder.WebPFree.argtypes = [ctypes.c_void_p]
    decoder.WebPFree.restype = None
    input_bytes = ctypes.create_string_buffer(binary)
    ptr = ctypes.cast(input_bytes, ctypes.c_void_p)
    w, h = ctypes.c_int(), ctypes.c_int()
    if decoder.WebPGetInfo(ptr, len(binary), ctypes.byref(w), ctypes.byref(h)) != 1:
        raise ValueError('WebP dimensions unavailable')
    width, height = w.value, h.value
    if width < 4 or height < 4 or width > 4096 or height > 4096 or width * height > 4000000:
        raise ValueError('WebP dimensions exceed logo safety limit')
    pixels = decoder.WebPDecodeRGBA(ptr, len(binary), ctypes.byref(w), ctypes.byref(h))
    if not pixels:
        raise ValueError('WebP native decoder returned no pixels')
    def chunk(name, payload):
        header = struct.pack('>I', len(payload)) + name
        return header + payload + struct.pack('>I', zlib.crc32(name + payload) & 0xffffffff)
    try:
        with open(destination, 'wb') as sink:
            sink.write(b'\x89PNG\r\n\x1a\n')
            sink.write(chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)))
            compress = zlib.compressobj(4)
            buffered = b''
            stride = width * 4
            address = ctypes.cast(pixels, ctypes.c_void_p).value
            for y in range(height):
                row = b'\x00' + ctypes.string_at(address + y * stride, stride)
                buffered += compress.compress(row)
                if len(buffered) >= 262144:
                    sink.write(chunk(b'IDAT', buffered))
                    buffered = b''
            buffered += compress.flush()
            if buffered:
                sink.write(chunk(b'IDAT', buffered))
            sink.write(chunk(b'IEND', b''))
    finally:
        decoder.WebPFree(pixels)
    return _logo_cache_usable(destination, 'logo.png')


def _decode_webp_logo(source, destination, url):
    """Try installed decoders in order without losing a valid alpha channel.

    The Python 3 build can decode WebP through Pillow. On DreamOS Python 2.7
    Pillow often lacks the codec and ffmpeg may lack the decoder or encoder.
    """
    try:
        from PIL import Image
        im = Image.open(source)
        try:
            im.seek(0)
            im.convert('RGBA').save(destination, 'PNG')
        finally:
            try: im.close()
            except (AttributeError, IOError, OSError): pass
        if _logo_cache_usable(destination, 'logo.png'):
            return True
    except (ImportError, AttributeError, TypeError, IOError, OSError, ValueError):
        pass
    try:
        if _webp_to_png_with_libwebp(source, destination):
            return True
    except (ImportError, AttributeError, TypeError, IOError, OSError, ValueError) as error:
        # No URL/title is logged: image contents and account details remain private.
        _trace(url, 'logo-native-webp-unavailable', error)
    candidates = (
        ('dwebp', lambda cmd: [cmd, source, '-o', destination]),
        ('ffmpeg', lambda cmd: [cmd, '-nostdin', '-loglevel', 'error', '-y',
                                '-i', source, '-frames:v', '1', '-vcodec', 'png',
                                destination]),
        ('convert', lambda cmd: [cmd, source, '-alpha', 'on', destination]),
    )
    for name, args_fn in candidates:
        command = which(name)
        if not command:
            continue
        try:
            subprocess_run(args_fn(command), check=True, timeout=8,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if _logo_cache_usable(destination, 'logo.png'):
                return True
            _trace(url, 'logo-' + name + '-opaque-or-invalid', ValueError('invalid alpha PNG'))
        except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
            _trace(url, 'logo-' + name + '-failed', error)
    raise ValueError('transparent WebP could not be decoded')


def _download_transparent_logo(url, source):
    from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request
    path = _title_logo_path(url)
    existing = _cached_transparent_logo(url)
    if existing:
        return existing
    if not path:
        return ""
    ensure_dir(os.path.dirname(path))
    temp = None
    converted = None
    try:
        fd, temp = tempfile.mkstemp(prefix=".genre_logo_", suffix=".part", dir=os.path.dirname(path))
        opener = build_opener(_ProtectedRedirect())
        url_headers = _headers(url, source)
        url_headers["Accept"] = "image/png,image/webp,image/*;q=0.8"
        total = 0
        head = b""
        # Python 2.7 urllib2 can fail HTTPS negotiation on older DreamOS builds
        # even when the receiver's wget works with the same TMDb CDN.
        # No credentials or custom Authorization headers are sent to wget.
        try:
            with os.fdopen(fd, "wb") as sink, closing(opener.open(Request(url, headers=url_headers), timeout=4.0)) as response:
                while True:
                    chunk = response.read(65536)
                    if not chunk:
                        break
                    if not head:
                        head = chunk[:32]
                    total += len(chunk)
                    if total > 4 * 1024 * 1024:
                        raise ValueError("title logo exceeds 4 MB")
                    sink.write(chunk)
        except Exception as primary_error:
            host = (urlsplit(url).hostname or "").lower()
            wget = which("wget")
            if host != "image.tmdb.org" or not wget:
                raise
            try:
                subprocess_run([wget, "-q", "-O", temp, "--tries=1", "--timeout=7", url],
                               check=True, timeout=10, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
                total = os.path.getsize(temp)
                if total > 4 * 1024 * 1024:
                    raise ValueError("title logo exceeds 4 MB")
                with open(temp, "rb") as response_file:
                    head = response_file.read(32)
                _trace(url, "logo-wget-recovery", primary_error)
            except Exception as retry_error:
                _trace(url, "logo-wget-failed", retry_error)
                raise primary_error
        fmt = _format(head)
        ext = urlsplit(url).path.lower().rsplit(".", 1)[-1]
        if total < 64 or not fmt:
            raise ValueError("invalid title logo")
        if fmt == "png":
            clean = temp
        elif fmt == "webp":
            converted = path + ".rgba.%d.png" % thread_ident()
            # Do not let one incompatible ffmpeg invocation abort all title
            # logos on DreamOS. Preserve full alpha through available decoders.
            _decode_webp_logo(temp, converted, url)
            clean = converted
        elif fmt == "jpeg" and ext in ("jpg", "jpeg"):
            clean = temp  # Genuine JPEG source; never synthesize a false alpha.
        else:
            raise ValueError("non-transparent result for transparent title logo")
        if os.path.getsize(clean) < 64:
            raise ValueError("empty converted title logo")
        # Check actual alpha on the temp image BEFORE publishing; otherwise an
        # opaque response could poison the shared logo cache across screens.
        if not _logo_cache_usable(clean, url):
            raise ValueError("title logo has no real transparency")
        atomic_replace(clean, path)
        return path
    finally:
        for candidate in (temp, converted):
            if candidate:
                try:
                    os.unlink(candidate)
                except OSError:
                    pass


def request_transparent_logo(url, source, ready, failed, gui):
    """Preserve old clearlogo transparency while Ultra handles posters quickly."""
    url = _clean_url(url)
    if not url:
        gui(failed, "")
        return
    cached = _cached_transparent_logo(url)
    if cached:
        gui(ready, cached)
        return
    with _LOCK:
        if len(_LOGO_RETRY_AT) > 128:
            now = monotonic()
            _LOGO_RETRY_AT.update((key, until) for key, until in _LOGO_RETRY_AT.items() if until > now)
            if len(_LOGO_RETRY_AT) > 128:
                for old in list(_LOGO_RETRY_AT)[:64]:
                    _LOGO_RETRY_AT.pop(old, None)
        if _LOGO_RETRY_AT.get(url, 0.0) > monotonic():
            gui(failed, "")
            return
        if url in _LOGO_PENDING:
            if len(_LOGO_PENDING[url]) < 12:
                _LOGO_PENDING[url].append((ready, failed, gui))
            return
        if len(_LOGO_PENDING) >= 12:
            gui(failed, "")
            return
        _LOGO_PENDING[url] = [(ready, failed, gui)]

    def worker():
        path = ""
        try:
            path = _download_transparent_logo(url, source)
        except Exception as exc:
            _trace(url, "transparent-logo", exc)
            with _LOCK:
                _LOGO_RETRY_AT[url] = monotonic() + 35
        if not path:
            # Do not re-fetch a source that only returns opaque/missing art
            # every time the user scrolls past the same title.
            with _LOCK:
                _LOGO_RETRY_AT[url] = monotonic() + 60
        with _LOCK:
            callbacks = _LOGO_PENDING.pop(url, [])
        for ok, fail, invoke in callbacks:
            try:
                invoke(ok if path else fail, path)
            except Exception:
                pass
    try:
        _LOGO_POOL.submit(worker)
    except RuntimeError:
        with _LOCK:
            _LOGO_PENDING.pop(url, None)
        gui(failed, "")


def is_pending(url, kind):
    """Read-only check for a visible transfer, used to deduplicate prefetch."""
    url = _clean_url(url)
    if not url:
        return False
    with _LOCK:
        return (url, kind) in _PENDING


def pending_count():
    """Number of active/queued Ultra artwork jobs (no file paths exposed)."""
    with _LOCK:
        return len(_PENDING)


def cancel_owner(owner):
    """Remove callbacks belonging to an old GENRE screen from shared jobs."""
    if owner is None:
        return
    with _LOCK:
        for key, callbacks in list(_PENDING.items()):
            kept = []
            for callback in callbacks:
                callback_owner = None
                for candidate in callback:
                    callback_owner = getattr(candidate, "__self__", None)
                    if callback_owner is not None:
                        break
                if callback_owner is not owner:
                    kept.append(callback)
            # Keep the key while a worker may still be downloading: this
            # prevents duplicate downloads of the same URL.
            _PENDING[key] = kept


def request(url, kind, source, ready, failed, gui):
    """Send callbacks to the GUI thread and merge simultaneous URL requests."""
    url = _clean_url(url)
    if not url:
        gui(failed, "")
        return
    cached = cached_artwork(url, kind)
    if cached:
        gui(ready, cached)
        return
    # GENRE can be requested after a background prefetch from another page.
    # Join its already pending transfer; never schedule a second fetch of
    # identical cache bytes. Keep GENRE's own bounded executor untouched.
    try:
        from . import artwork_queue as _queue
        existing_path = artwork_path(url, kind)
        # A generic prefetch lacks MAG authentication. For Stalker, the real
        # visible request must use Ultra's provider headers, not join it.
        auth_required = str((source or {}).get("type") or "").lower() == "stalker"
        if not auth_required and existing_path in _queue._jobs:
            _queue._request_artwork_core(
                url, kind, callback=lambda p: gui(ready, p),
                priority=120, errback=lambda p: gui(failed, p))
            return
    except Exception:
        pass
    key = (url, kind)
    with _LOCK:
        if _FAILURES.get(key, 0) > monotonic():
            gui(failed, "")
            return
        if key in _PENDING:
            if len(_PENDING[key]) < 16:
                _PENDING[key].append((ready, failed, gui))
            return
        if len(_FAILURES) > 256:
            now = monotonic()
            for old_key, expiry in list(_FAILURES.items()):
                if expiry < now:
                    _FAILURES.pop(old_key, None)
            if len(_FAILURES) > 256:
                for old_key in list(_FAILURES)[:64]:
                    _FAILURES.pop(old_key, None)
        # Two reserved Hero positions allow a newly selected backdrop to
        # start even when a 24-poster page already occupies the normal window.
        # Normal poster requests stay within the original bounded limit.
        allowance = 2 if kind == "backdrops" else 0
        if len(_PENDING) >= _MAX_IN_FLIGHT + allowance:
            gui(failed, "")
            return
        _PENDING[key] = [(ready, failed, gui)]

    def worker():
        path = ""
        try:
            path = _download(url, kind, source)
            if not path:
                raise ValueError("no validated artwork")
        except Exception as exc:
            _trace(url, kind, exc)
            with _LOCK:
                _FAILURES[key] = monotonic() + _FAILED_TTL
        with _LOCK:
            callbacks = _PENDING.pop(key, [])
        for ok, fail, invoke in callbacks:
            try:
                invoke(ok if path else fail, path)
            except Exception:
                pass
    try:
        (_BACKDROP_POOL if kind == "backdrops" else _POOL).submit(worker)
    except RuntimeError:
        with _LOCK:
            _PENDING.pop(key, None)
        gui(failed, "")
