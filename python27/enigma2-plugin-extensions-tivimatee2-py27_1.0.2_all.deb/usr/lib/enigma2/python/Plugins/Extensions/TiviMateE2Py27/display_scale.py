# -*- coding: utf-8 -*-
"""Runtime screen-profile helper for TiviMate E2.

The plugin artwork was authored on a 1920x1080 design canvas.  Enigma2 can
create screens on larger desktops, but coordinates passed later through
``ePoint`` are physical pixels.  This module keeps the XML skin and those
runtime movements in the same coordinate system.
"""

import re
import os

BASE_WIDTH = 1920
BASE_HEIGHT = 1080
HD_WIDTH = 1280
HD_HEIGHT = 720
WQHD_WIDTH = 2560
WQHD_HEIGHT = 1440
PROFILE_FILE = "/etc/enigma2/tivimatee2_py27_display_profile"


def load_profile_preference():
    """Return the user-selected UI profile. FHD is always the safe default."""
    try:
        with open(PROFILE_FILE, "r") as handle:
            value = str(handle.read() or "").strip().lower()
        # Ignore stale WQHD preferences; only the default FHD skin is available.
        return "fhd"
    except Exception:
        pass
    return "fhd"


def save_profile_preference(value):
    """Persist only the explicit FHD/WQHD UI choice."""
    value = "fhd"
    try:
        parent = os.path.dirname(PROFILE_FILE)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(PROFILE_FILE, "w") as handle:
            handle.write(value + "\n")
        return True
    except Exception:
        return False

_PAIR_RE = re.compile(r'\b(position|size)\s*=\s*"\s*(-?\d+)\s*,\s*(-?\d+)\s*"')
_FONT_RE = re.compile(r'\bfont\s*=\s*"([^";]+);(\d+)"')
_BORDER_RE = re.compile(r'\bborderWidth\s*=\s*"(\d+)"')
_ITEM_HEIGHT_RE = re.compile(r'\bitemHeight\s*=\s*"(\d+)"')
_SCREEN_TAG_RE = re.compile(r'<screen\b[^>]*>')
_RESOLUTION_ATTRIBUTE_RE = re.compile(r'\bresolution\s*=')


def bind_screen_resolution(xml, design_width=BASE_WIDTH, design_height=BASE_HEIGHT):
    """Pin plugin XML to its actual design coordinate system.

    Enigma2 supports root <screen resolution="W,H">. Without this explicit
    attribute its scaling may inherit the active skin's HD/FHD root context,
    separating pixmaps from widget positions or runtime focus coordinates.

    Existing screen-specific resolution attributes are never overridden.
    No widget coordinates, assets or font sizes are changed by this helper.
    """
    if not xml or '<screen' not in xml:
        return xml
    target = ' resolution="%d,%d"' % (int(design_width), int(design_height))

    def replace_tag(match):
        tag = match.group(0)
        if _RESOLUTION_ATTRIBUTE_RE.search(tag):
            return tag
        return tag[:-1] + target + '>'

    return _SCREEN_TAG_RE.sub(replace_tag, xml)



def _round_pixel(value):
    """Round a coordinate predictably on Python 2.7."""
    value = float(value)
    if value >= 0:
        return int(value + 0.5)
    return int(value - 0.5)


def desktop_size():
    """Return the active Enigma2 desktop dimensions, or the FHD baseline."""
    try:
        from enigma import getDesktop
        size = getDesktop(0).size()
        width = int(size.width())
        height = int(size.height())
        if width > 0 and height > 0:
            return width, height
    except Exception:
        pass
    return BASE_WIDTH, BASE_HEIGHT


def _is_16_by_9(width, height):
    try:
        return abs((float(width) / float(height)) - (16.0 / 9.0)) < 0.04
    except Exception:
        return False


def scale_factors():
    """Return the automatic factor for the supported FHD/WQHD profiles.

    The normal FHD canvas is unchanged.  On older Pure2 images using an
    actual 1280x720 Enigma2 GUI desktop, scale *both* XML widgets and dynamic
    selection positions together; otherwise FHD coordinates can be clipped
    and the focus may appear detached from its label/icon.  WQHD remains
    explicitly opt-in.  A 4K video output alone never triggers UI scaling.
    """
    width, height = desktop_size()
    # Some Pure2 skins use a native 720p GUI even when video output is 1080p.
    # Only act on an actual HD GUI desktop. Never infer this from HDMI mode.
    if (abs(width - HD_WIDTH) <= 16 and abs(height - HD_HEIGHT) <= 16
            and _is_16_by_9(width, height)):
        return float(width) / BASE_WIDTH, float(height) / BASE_HEIGHT
    # FHD is the explicit default. WQHD is opt-in and is applied only when
    # Enigma2 itself exposes a 2560x1440-class desktop. This prevents a user
    # choice from pushing coordinates outside a legacy FHD OSD canvas.
    if load_profile_preference() == "wqhd":
        if (abs(width - WQHD_WIDTH) <= 32 and abs(height - WQHD_HEIGHT) <= 32
                and _is_16_by_9(width, height)):
            return float(WQHD_WIDTH) / BASE_WIDTH, float(WQHD_HEIGHT) / BASE_HEIGHT
    return 1.0, 1.0


def profile_name():
    """Return the visible profile label used for diagnostics."""
    factor_x, factor_y = scale_factors()
    if factor_x < 1.0 and factor_y < 1.0:
        return "HD"
    return "WQHD" if factor_x > 1.0 and factor_y > 1.0 else "FHD"


def sx(value):
    """Scale an FHD horizontal coordinate to the active desktop."""
    return _round_pixel(float(value) * scale_factors()[0])


def sy(value):
    """Scale an FHD vertical coordinate to the active desktop."""
    return _round_pixel(float(value) * scale_factors()[1])


def scale_size(width, height):
    """Scale a width/height pair for image decoding or widget movement."""
    return sx(width), sy(height)


_PIXMAP_ATTR = re.compile(r'\bpixmap="([^"]+)"')

def scale_skin(xml):
    """Create a native-size skin string for the active FHD/WQHD desktop.

    Only explicit numerical layout attributes are transformed.  Values such
    as ``center,center`` and file names are left untouched, so dialog layouts
    and packaged artwork paths stay compatible with old Enigma2 images.
    """
    factor_x, factor_y = scale_factors()
    if factor_x == 1.0 and factor_y == 1.0:
        return bind_screen_resolution(xml)

    def replace_pair(match):
        return '%s="%d,%d"' % (
            match.group(1),
            _round_pixel(int(match.group(2)) * factor_x),
            _round_pixel(int(match.group(3)) * factor_y)
        )

    def replace_font(match):
        # Font parsing does not automatically follow an ePoint move.  Keep
        # it proportionate to the native-size position/size attributes.
        font_scale = min(factor_x, factor_y)
        return 'font="%s;%d"' % (
            match.group(1),
            max(1, _round_pixel(int(match.group(2)) * font_scale))
        )

    def replace_border(match):
        border_scale = min(factor_x, factor_y)
        return 'borderWidth="%d"' % max(1, _round_pixel(int(match.group(1)) * border_scale))

    def replace_item_height(match):
        return 'itemHeight="%d"' % max(1, _round_pixel(int(match.group(1)) * factor_y))

    xml = _PAIR_RE.sub(replace_pair, xml)
    xml = _FONT_RE.sub(replace_font, xml)
    xml = _BORDER_RE.sub(replace_border, xml)
    xml = _ITEM_HEIGHT_RE.sub(replace_item_height, xml)
    return bind_screen_resolution(xml,
                                  _round_pixel(BASE_WIDTH * factor_x),
                                  _round_pixel(BASE_HEIGHT * factor_y))


def diagnostic_summary():
    """Small non-sensitive diagnostic value for optional UI logging."""
    width, height = desktop_size()
    return "%s %dx%d" % (profile_name(), width, height)
