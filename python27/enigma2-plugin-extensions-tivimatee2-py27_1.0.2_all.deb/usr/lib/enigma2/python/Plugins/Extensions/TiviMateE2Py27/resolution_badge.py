# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch
"""One yellow, rounded resolution badge for information pages and players.

UI-only: no network, image processing, provider changes, timers or defaults.
Metadata text and poster geometry are not modified. Unknown quality is hidden.
"""
import re
import weakref
from types import MethodType

_BACKGROUND = '#F6CF49'
_FOREGROUND = '#151515'
_NAME = 'infoResolution'
_YEAR_NAME = 'infoYear'
_GENRE_NAME = 'infoGenre'
_DURATION_NAME = 'infoDuration'
_RATING_NAME = 'infoRating'
_DURATION_COLOR = '#7457A6'  # purple
_YEAR_COLOR = '#287BCB'      # Blue: year
_GENRE_COLOR = '#19866A'     # Green: genres
_RATING_COLOR = '#AD3368'    # pink: actual audience score

_TOKEN = re.compile(r'(?<![a-z0-9])(?:4320[pi]|2160[pi]|1440[pi]|1080[pi]|720[pi]|576[pi]|480[pi]|360[pi]|8k|4k|uhd|fhd|full[\s._-]*hd|hd|sd)(?![a-z0-9])', re.I)
_FIELDS = ('resolution', 'video_resolution', 'stream_quality', 'video_quality', 'quality', '_resolution', '_video_resolution')
_NESTED = ('info', 'video', 'video_info', 'stream_info', 'movie_data', 'episode_info', 'item', '_detail_provider_info')


def canonical_resolution(value):
    if value is None:
        return ''
    text = str(value).strip()
    if text in ('4320', '2160', '1440', '1080', '720', '576', '480', '360'):
        return {'4320':'8K', '2160':'4K'}.get(text, text + 'p')
    dims = re.search(r'(?<!\d)(\d{3,4})\s*[xX×]\s*(\d{3,4})(?!\d)', text)
    if dims:
        height = int(dims.group(2))
        if height in (4320, 2160, 1440, 1080, 720, 576, 480, 360):
            return {4320:'8K', 2160:'4K'}.get(height, '%dp' % height)
    match = _TOKEN.search(text)
    if not match:
        return ''
    tag = match.group(0).lower()
    if py27_fullmatch(r'full[\s._-]*hd', tag) or tag == 'fhd':
        return '1080p'
    return {'8k': '8K', '4320p': '8K', '4k': '4K', '2160p': '4K',
            'uhd': '4K', 'hd': 'HD', 'sd': 'SD'}.get(tag, tag)


def extract_resolution(*sources):
    """Read explicit source fields/video dimensions, then provider title tags."""
    pending = list(sources)
    seen = set()
    titles = []
    for _ in range(48):
        if not pending:
            break
        source = pending.pop(0)
        if isinstance(source, (tuple, list)):
            pending.extend(source[:4])
            continue
        if not isinstance(source, dict) or id(source) in seen:
            continue
        seen.add(id(source))
        for key in _FIELDS:
            result = canonical_resolution(source.get(key))
            if result:
                return result
        for key in ('video_height', '_video_height', 'height'):
            try:
                height = int(source.get(key) or 0)
            except (TypeError, ValueError):
                continue
            if height in (4320, 2160, 1440, 1080, 720, 576, 480, 360):
                return canonical_resolution(str(height))
        for key in ('name', 'title', 'stream_name'):
            if source.get(key):
                titles.append(source[key])
        pending[0:0] = [source[key] for key in _NESTED if isinstance(source.get(key), dict)]
    for title in titles:
        result = canonical_resolution(title)
        if result:
            return result
    return ''


def extract_rating(*sources):
    """Return a verified-looking 0-10 metadata rating or nothing.

    A poster's painted score is not inferred. No fabricated zero is displayed;
    a 5-based source is scaled only when its field explicitly says 5-based.
    """
    pending = list(sources)
    seen = set()
    while pending and len(seen) < 48:
        record = pending.pop(0)
        if isinstance(record, (tuple, list)):
            pending.extend(record[:6])
            continue
        if not isinstance(record, dict) or id(record) in seen:
            continue
        seen.add(id(record))
        for key in ('vote_average', 'rating', 'rating_10based', 'rating_5based', 'tmdb_rating'):
            val = record.get(key)
            if val in (None, '', 0, '0', '0.0') or isinstance(val, (dict,list,tuple,bool)):
                continue
            text = str(val).strip().replace(',', '.')
            match = re.match(r'^\s*(\d{1,2}(?:\.\d{1,2})?)\s*(?:/\s*(5|10))?\s*$', text)
            if not match:
                continue
            rating = float(match.group(1))
            if key == 'rating_5based' or match.group(2) == '5':
                rating *= 2.0
            if 0 < rating <= 10:
                return '★ %.1f' % rating
        for nested_name in ('info', 'movie_data', 'series_data', '_detail_provider_info',
                            'tmdb', 'tmdb_verified', 'metadata', 'data'):
            child = record.get(nested_name)
            if isinstance(child, dict):
                pending.append(child)
    return ''


def _factor(skin):
    match = re.search(r'<screen\b[^>]*\bsize="(\d+),(\d+)"', skin or '')
    if not match:
        return 1.0
    return float(match.group(1)) / 1920.0


def _scaled(value, factor):
    return max(1, int(value * factor + 0.5))


def badge_widget(name, x, y, factor=1.0, z=12, width=102, color=_BACKGROUND,
                 text_color=_FOREGROUND, font_size=20):
    """Match the original rounded 4K pill; only widths and colors differ."""
    return ('<widget name="%s" position="%d,%d" size="%d,%d" font="Regular;%d" '
            'foregroundColor="%s" backgroundColor="%s" transparent="0" '
            'cornerRadius="%d" halign="center" valign="center" noWrap="1" zPosition="%d" />\n') % (
                name, x, y, _scaled(width, factor), _scaled(35, factor),
                _scaled(font_size, factor), text_color, color, _scaled(10, factor), z)




def format_duration(value):
    """Format a credible film runtime in hours/minutes; hide unknown values.

    Long bare provider values such as 6480 are generally seconds mislabeled
    as minutes. Never claim a movie lasts 108 hours from that field.
    """
    if value is None or isinstance(value, bool):
        return ''
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ''
    text = str(value).strip().lower()
    if not text or text in ('0', '0.0', 'none', 'null', 'n/a', '-', '--'):
        return ''
    if ':' in text:
        parts = text.split(':')
        if len(parts) == 3 and all(x.isdigit() for x in parts):
            hours, minutes, seconds = map(int, parts)
            duration = hours * 60 + minutes + (1 if seconds >= 30 else 0)
        elif len(parts) == 2 and all(x.isdigit() for x in parts):
            hours, minutes = map(int, parts)
            duration = hours * 60 + minutes
        else:
            return ''
    else:
        hours = re.search(r'(\d+(?:[.,]\d+)?)\s*(?:hours?|hrs?|hr|h|ساع(?:ة|ات)?)', text)
        mins = re.search(r'(\d+)\s*(?:minutes?|mins?|min|m|دق(?:يقة|ائق)?)', text)
        if hours:
            duration = int(round(float(hours.group(1).replace(',', '.')) * 60)) + (int(mins.group(1)) if mins else 0)
        else:
            match = re.search(r'\d+(?:[.,]\d+)?', text)
            if not match:
                return ''
            duration = int(round(float(match.group(0).replace(',', '.'))))
            if not py27_fullmatch(r'\d+(?:[.,]\d+)?\s*(?:min(?:utes?|s)?|دقيق(?:ة|ات))?', text):
                if 'sec' in text or 'ثان' in text:
                    duration = int(round(duration / 60.0))
                else:
                    return ''
            elif duration > 600:
                # IPTV providers commonly put seconds in duration / runtime,
                # including a false 'min' suffix. Restrict to plausible films.
                duration = int(round(duration / 60.0))
    if duration <= 0 or duration > 600:
        return ''
    hours, minutes = divmod(duration, 60)
    return ('%dh %02dm' % (hours, minutes)) if hours else ('%dm' % minutes)


def extract_duration(*sources):
    """Use selected content's structured runtime only, not text descriptions."""
    pending = list(sources)
    seen = set()
    while pending and len(seen) < 45:
        src = pending.pop(0)
        if isinstance(src, (list, tuple)):
            pending.extend(src[:3]); continue
        if not isinstance(src, dict) or id(src) in seen:
            continue
        seen.add(id(src))
        for key in ('runtime', 'duration', 'duration_secs', 'episode_run_time', 'run_time'):
            val = src.get(key)
            if val not in (None, '', [], 0):
                if key == 'duration_secs':
                    try:
                        return format_duration(round(float(val) / 60))
                    except (ValueError, TypeError):
                        pass
                label = format_duration(val)
                if label:
                    return label
        for key in ('info', 'movie_data', 'series_data', '_detail_provider_info', 'tmdb', 'data'):
            nested = src.get(key)
            if isinstance(nested, dict):
                pending.append(nested)
    return ''

def _fact_badge_row(x, y, factor, z=12):
    """Five coloured metadata pills; entire row fits the 24-poster right panel."""
    gap = _scaled(8, factor)
    widths = [_scaled(v, factor) for v in (85, 86, 173, 119, 91)]
    total = sum(widths) + 4 * gap
    screen_width = _scaled(1920, factor)
    start = max(_scaled(10, factor), min(x, screen_width - _scaled(20, factor) - total))
    positions = [start]
    for w in widths[:-1]:
        positions.append(positions[-1] + w + gap)
    return (badge_widget(_NAME, positions[0], y, factor, z, 85, _BACKGROUND, _FOREGROUND, 18) +
            badge_widget(_YEAR_NAME, positions[1], y, factor, z, 86, _YEAR_COLOR, '#FFFFFF', 18) +
            badge_widget(_GENRE_NAME, positions[2], y, factor, z, 173, _GENRE_COLOR, '#FFFFFF', 16) +
            badge_widget(_DURATION_NAME, positions[3], y, factor, z, 119, _DURATION_COLOR, '#FFFFFF', 17) +
            badge_widget(_RATING_NAME, positions[4], y, factor, z, 91, _RATING_COLOR, '#FFFFFF', 17))

def information_badge_skin(skin, anchor='meta', position=None):
    """Attach quality, year and genre pills in the same row on info pages."""
    if not isinstance(skin, basestring) or '<screen' not in skin:
        return skin, False
    if re.search(r'<widget\b[^>]*\bname="%s"' % _NAME, skin):
        return skin, True
    factor = _factor(skin)
    static = re.search(r'<eLabel\b(?=[^>]*\btext="1080p")(?=[^>]*\bbackgroundColor="#F6CF49")[^>]*/>', skin)
    if static:
        pos = re.search(r'\bposition="(-?\d+),(-?\d+)"', static.group(0))
        if pos:
            widgets = _fact_badge_row(int(pos.group(1)), int(pos.group(2)), factor, 9)
            return skin[:static.start()] + widgets + skin[static.end():], True
    match = re.search(r'<widget\b(?=[^>]*\bname="%s")[^>]*/>' % re.escape(anchor), skin)
    if not match:
        return skin, False
    pos = re.search(r'\bposition="(-?\d+),(-?\d+)"', match.group(0))
    size = re.search(r'\bsize="(\d+),(\d+)"', match.group(0))
    if not pos or not size:
        return skin, False
    if position is not None:
        x, y = (int(v * factor + 0.5) for v in position)
    else:
        x = int(pos.group(1)) + int(size.group(1)) + _scaled(20, factor)
        y = int(pos.group(2)) + max(0, (int(size.group(2)) - _scaled(35, factor)) // 2)
        screen_width = _scaled(1920, factor)
        if x + _scaled(102, factor) > screen_width - _scaled(30, factor):
            x = screen_width - _scaled(150, factor)
    return skin.replace('</screen>', _fact_badge_row(x, y, factor) + '</screen>', 1), True


def player_badge_skin(skin, name='resolutionBadge'):
    """Restyle only the resolution cell; leave codec/audio/aspect cells intact."""
    factor = _factor(skin)
    pattern = r'<widget\b(?=[^>]*\bname="%s")[^>]*/>' % re.escape(name)
    def replace(match):
        pos = re.search(r'\bposition="(-?\d+),(-?\d+)"', match.group(0))
        size = re.search(r'\bsize="(\d+),(\d+)"', match.group(0))
        z = re.search(r'\bzPosition="(\d+)"', match.group(0))
        if not pos:
            return match.group(0)
        y = int(pos.group(2))
        if size:
            y += max(0, (int(size.group(2)) - _scaled(35, factor)) // 2)
        widget = badge_widget(name, int(pos.group(1)), y, factor, int(z.group(1)) if z else 5)
        if size:
            width = min(int(size.group(1)), _scaled(102, factor))
            widget = re.sub(r'\bsize="\d+,\d+"', 'size="%d,%d"' % (width, _scaled(35, factor)), widget, count=1)
        return widget
    return re.sub(pattern, replace, skin, count=1)


def set_resolution_badge(screen, name, value):
    result = canonical_resolution(value)
    try:
        widget = screen[name]
        widget.setText(result)
        widget.show() if result else widget.hide()
    except (KeyError, AttributeError, TypeError):
        pass


_YEAR_TOKEN = re.compile(r'(?<!\d)(?:19|20)\d{2}(?!\d)')
_NON_GENRE = re.compile(r'^(?:\d+(?:[.,]\d+)?\s*(?:min|mins|minutes|دقيقة|دقائق|ساع|h|hr|hour|hours)|'
                        r'\d{1,2}:\d{2}(?::\d{2})?|\d+h\s*\d*m|[★☆]\s*\d+(?:[.,]\d+)?|'
                        r'\d+(?:[.,]\d+)?\s*%|hdd|4k|8k|1080p?|720p?|uhd|fhd|hd|sd)$', re.I)


def _clean_genres(value):
    if isinstance(value, list):
        parts = [(v.get('name') or v.get('title') or '') if isinstance(v, dict) else str(v)
                 for v in value[:5]]
        value = '، '.join(str(x) for x in parts if x)
    if not isinstance(value, str):
        return ''
    text = value.strip().strip('• -|،,')
    if not text or text.isdigit() or _NON_GENRE.match(text) or py27_fullmatch(_YEAR_TOKEN, text):
        return ''
    if re.match(r'(?i)^(?:sort:|loading|search all|unable|select |browse,|movies featuring)', text):
        return ''
    if len(text) > 34:
        text = text[:33].rstrip() + '…'
    return text


# TMDb canonical genre IDs and localized genre names; category/package names
# (e.g. EN-ACTION, NETFLIX MOVIES) are never film genres.
_GENRE_BY_ID = {28:'Action',12:'Adventure',16:'Animation',35:'Comedy',80:'Crime',99:'Documentary',18:'Drama',10751:'Family',14:'Fantasy',36:'History',27:'Horror',10402:'Music',9648:'Mystery',10749:'Romance',878:'Science Fiction',10770:'TV Movie',53:'Thriller',10752:'War',37:'Western',10759:'Action & Adventure',10762:'Kids',10763:'News',10764:'Reality',10765:'Sci-Fi & Fantasy',10766:'Soap',10767:'Talk',10768:'War & Politics'}
_GENRE_NAMES = {
    'action','adventure','animation','comedy','crime','documentary','drama',
    'family','fantasy','history','horror','music','mystery','romance','science fiction',
    'sci-fi','thriller','war','western','tv movie','kids','news','reality','soap','talk',
    'action & adventure','sci-fi & fantasy','war & politics',
    'أكشن','اكشن','حركة','مغامرة','مغامرات','رسوم متحركة','انيميشن',
    'كوميديا','كوميدي','جريمة','وثائقي','وثائقية','دراما','عائلي','عائلة',
    'فانتازيا','خيال','تاريخ','تاريخي','رعب','موسيقى','غموض','رومانسي',
    'رومانسية','خيال علمي','إثارة','اثارة','تشويق','حرب','حربي','غربي','أطفال',
    'اطفال','أخبار','اخبار','واقعي','واقع','مسلسلات تلفزيونية'}

def _actual_media_genre(*sources):
    """Find real film/series genres without substituting provider package names.

    TMDb/XTream/Stalker encode genres as localized text, composite strings,
    JSON-like lists, or numeric IDs. Avoid exact-string-only checks: e.g.
    'دراما ورومانسية' is two genres and must not disappear from the badge.
    """
    def normalized(value):
        if isinstance(value, (list, tuple)):
            result = []
            for entry in value[:8]:
                if isinstance(entry, dict):
                    entry = entry.get('name') or entry.get('title') or entry.get('id') or ''
                result.append(entry)
            value = ', '.join(str(v) for v in result)
        if isinstance(value, dict):
            value = value.get('name') or value.get('title') or ''
        if value is None:
            return ''
        value = str(value).strip()
        if not value:
            return ''
        # Match validated genres inside composite genre fields, never search
        # provider category/name/title or arbitrary descriptions.
        tokens = re.split(u'[,،;/|•]+|\\s+&\\s+|\\s+and\\s+|\\s+و\\s+|\\s+و(?=[\u0600-ۿ])', value, flags=re.I)
        chosen = []
        for token in tokens:
            token = token.strip(' \t-–()[]')
            # Numeric TMDb genre IDs supplied in some portal payloads.
            try:
                name = _GENRE_BY_ID.get(int(token))
            except (ValueError, TypeError):
                name = None
            if not name:
                if token.lower() in _GENRE_NAMES:
                    name = token
                elif token.startswith('و') and token[1:].strip().lower() in _GENRE_NAMES:
                    name = token[1:].strip()
            if name and name.lower() not in {n.lower() for n in chosen}:
                chosen.append(name)
        return '، '.join(chosen[:2])

    def variants(src):
        if not isinstance(src, dict):
            return
        yield src
        for k in ('info', 'movie_data', 'series_data', 'details', 'metadata',
                  'tmdb', 'content', 'data', 'result'):
            child = src.get(k)
            if isinstance(child, dict):
                yield child
    for src in sources:
        for record in variants(src):
            for key in ('genres', 'genre_names', 'genre', 'genre_ids', 'genre_id'):
                result = normalized(record.get(key))
                if result:
                    return result
    return ''


def _year_genre_from_meta(meta):
    """Read the *displayed* metadata first to avoid an old selection's facts."""
    meta = str(meta or '')
    year = _YEAR_TOKEN.search(meta)
    pieces = [part.strip() for part in re.split(r'\s*[•|]\s*', meta) if part.strip()]
    genres = []
    for piece in pieces:
        piece = _YEAR_TOKEN.sub('', piece).strip(' \t-,')
        if not piece or _NON_GENRE.match(piece):
            continue
        # Ignore non-genre status or rating facts; keep Arabic/English genres.
        if (piece.startswith(('★', '☆')) or
                re.match(r'(?i)^(?:sort:|loading|search all|unable|select |browse,)', piece)):
            continue
        genre = _clean_genres(piece)
        if genre:
            genres.append(genre)
    return (year.group(0) if year else '', _clean_genres('، '.join(genres[:2])))


def _year_genre_from_sources(sources):
    year = ''
    genre = ''
    for src in sources[:12]:
        if not isinstance(src, dict):
            continue
        info = src.get('info') if isinstance(src.get('info'), dict) else {}
        for record in (src, info):
            if not year:
                for k in ('year', 'release_date', 'releasedate', 'first_air_date', 'releaseDate'):
                    found = _YEAR_TOKEN.search(str(record.get(k) or ''))
                    if found:
                        year = found.group(0)
                        break
            if not genre:
                for k in ('genre', 'genres', 'genre_names'):
                    genre = _clean_genres(record.get(k))
                    if genre:
                        break
        if year and genre:
            break
    return year, genre


def _set_pill(screen, name, value):
    try:
        widget = screen[name]
        if value:
            widget.setText(value)
            widget.show()
        else:
            widget.setText('')
            widget.hide()
    except (KeyError, AttributeError, TypeError):
        pass


def _current_sources(screen):
    """Selected item's data first, including results opened from GENRE.

    Avoid stale detail dictionaries taking priority over the highlighted poster.
    """
    sources = []
    current_item = None
    kind = getattr(screen, 'kind', None)
    # MediaScreen.current() resolves pageStart+posterIndex for any package,
    # including packages opened from the standalone GENRE selector.
    try:
        current_method = getattr(screen, 'current', None)
        if callable(current_method):
            current_item = current_method()
            if isinstance(current_item, dict):
                sources.append(current_item)
    except (IndexError, KeyError, TypeError, AttributeError):
        pass
    # Some skins update the info label before the selected-item accessor is
    # ready. Read the active card from its list, never a random first item.
    if current_item is None and kind in ('vod', 'series'):
        try:
            index = int(getattr(screen, 'pageStart', 0)) + int(getattr(screen, 'posterIndex', 0))
            current_item = getattr(screen, 'mediaItemsCurrent', [])[index]
            if isinstance(current_item, dict):
                sources.append(current_item)
        except (IndexError, KeyError, TypeError, ValueError, AttributeError):
            pass
    if isinstance(current_item, dict) and hasattr(screen, 'fullInfoCache'):
        try:
            from .metadata_display import provider_cache_key
            media_id = (current_item.get('stream_id') or current_item.get('series_id') or
                        current_item.get('vod_id') or current_item.get('id') or '')
            key = provider_cache_key(kind or 'vod', media_id, getattr(screen, 'source', {}))
            cached = screen.fullInfoCache.get(key)
            if isinstance(cached, dict):
                sources.append(cached)
        except (ImportError, AttributeError, TypeError, KeyError):
            pass
    # SeriesDetails and favourites keep other selected-item structures.
    try:
        if hasattr(screen, 'episodeItems'):
            index = int(getattr(screen, 'episodePage', 0)) * 5 + int(getattr(screen, 'episodeIndex', 0))
            item = screen.episodeItems[index]
            if isinstance(item, dict):
                sources.append(item)
    except (IndexError, TypeError, ValueError):
        pass
    try:
        if hasattr(screen, 'recent'):
            item = screen.recent[int(getattr(screen, 'posterIndex', 0))]
            if isinstance(item, dict):
                sources.append(item)
    except (IndexError, TypeError, ValueError):
        pass
    for method in ('_selected', '_currentRecord'):
        try:
            callback = getattr(screen, method, None)
            if callable(callback):
                value = callback()
                if isinstance(value, dict):
                    sources.append(value)
        except (IndexError, KeyError, TypeError, AttributeError):
            pass
    for key in ('item', 'seriesItem', 'seriesData', '_tmdb_bundle', 'bundle', 'featureItem', '_featureItem', '_featuredItem', 'featuredItem'):
        value = getattr(screen, key, None)
        if isinstance(value, dict):
            sources.append(value)
    # MediaScreen may preserve this object from the previous selection; do not
    # mix it with the GENRE card currently highlighted.
    if not (kind in ('vod', 'series') and isinstance(current_item, dict)):
        value = getattr(screen, '_serverMovieInfo', None)
        if isinstance(value, dict):
            sources.append(value)
    return sources


def _hide_plain_facts(value, sources):
    """Show year and genres in the existing coloured pills, never twice.

    Prefer the *current label's* metadata over an old item's provider values.
    A newly selected item's cached info can arrive after this label was set;
    year/genres that are explicitly in the label must still be deduplicated.
    Ordinary instructions, sort labels, errors and package names stay intact.
    """
    if not isinstance(value, str) or not value.strip():
        return value
    source_year, source_genre = _year_genre_from_sources(sources)
    shown_year = _YEAR_TOKEN.search(value)
    meta_year, meta_genre = _year_genre_from_meta(value)
    year = meta_year or source_year
    # Treat a plain list of genres as metadata only when it comes with a year
    # or is also confirmed by the selected item; never erase generic labels
    # such as 'Movies • TV Shows' or a server status line.
    genre = source_genre or (meta_genre if shown_year else '')
    quality = extract_resolution(*sources)
    duration = extract_duration(*sources)
    rating = extract_rating(*sources)
    if not (year or genre or quality or duration or rating):
        return value

    def normalized(text):
        return re.sub(r'\s+', ' ', str(text or '').strip(' \t.,،-|')).lower()

    genre_names = set()
    for raw in (genre, meta_genre if shown_year else ''):
        if not raw:
            continue
        genre_names.add(normalized(raw))
        for token in re.split(r'[,،/؛;•]+', raw):
            if token.strip():
                genre_names.add(normalized(token))
    # A short compound list of genres (e.g. 'Comedy, Drama') is one value,
    # while unrelated notes, provider names and synopsis remain unmodified.
    remaining = []
    for part in re.split(r'\s*[•|]\s*', value):
        text = part.strip()
        if not text:
            continue
        compact = normalized(text)
        if year and py27_fullmatch(r'(?:(?:year|سنة)\s*[:\-]\s*)?' + re.escape(year), compact, re.I):
            continue
        if quality and canonical_resolution(text) == quality:
            continue
        if genre_names and (compact in genre_names or
                (',' in text or '،' in text) and all(
                    normalized(v) in genre_names for v in re.split(r'[,،]', text) if v.strip())):
            continue
        if duration and format_duration(text) == duration:
            continue
        if rating and (py27_fullmatch(r'[★☆]\s*\d{1,2}(?:[.,]\d+)?', text) or
                       py27_fullmatch(r'\d{1,2}(?:[.,]\d+)?\s*/\s*10', text)):
            continue
        remaining.append(text)
    return '  •  '.join(remaining)


def _compact_browsing_pills(screen):
    """Bring visible facts together on Movies/TV browse pages only."""
    screen_type = screen.__class__.__name__
    if screen_type not in ('FastMoviesContentScreen', 'NewMoviesContentScreen', 'SeriesDetailsScreen'):
        return
    try:
        from enigma import ePoint
    except ImportError:
        return
    factor = _factor(getattr(screen, 'skin', ''))
    badges = ((_NAME, 85), (_YEAR_NAME, 86), (_GENRE_NAME, 173),
              (_DURATION_NAME, 119), (_RATING_NAME, 91))
    if screen_type == 'SeriesDetailsScreen':
        # Compact only populated pills and center them over the circular flag.
        # Without this, a missing genre leaves a large gap before duration.
        visible = []
        for name, width in badges:
            try:
                widget = screen[name]
                if str(widget.getText() or '').strip():
                    visible.append((widget, width))
            except (KeyError, AttributeError, TypeError):
                continue
        if not visible:
            return
        total = sum(width for _, width in visible) + 8 * (len(visible) - 1)
        x = int(720 - total / 2)
        for widget, width in visible:
            try:
                if widget.instance is not None:
                    widget.instance.move(ePoint(_scaled(x, factor), _scaled(148, factor)))
            except (AttributeError, TypeError):
                pass
            x += width + 8
        return
    # Keep the original Movies/TV browsing layout unchanged.
    start_y = 185 if screen_type == 'NewMoviesContentScreen' else 226
    x = 330
    for name, width in badges:
        try:
            widget = screen[name]
            if not str(widget.getText() or '').strip():
                continue
            if getattr(widget, 'instance', None) is not None:
                widget.instance.move(ePoint(_scaled(x, factor), _scaled(start_y, factor)))
            x += width + 8
        except (KeyError, AttributeError, TypeError):
            continue

def install_information_badge(screen, anchor='meta', observe=None, position=None, details_deduplicate=False, badges_only=False):
    """Bind to existing GUI metadata changes; no extra timer or worker.

    Existing setText logic remains untouched. The new label only reads raw
    selected-source data, not a default value or TMDb descriptions.
    """
    if getattr(screen, '_information_resolution_installed', False):
        return
    skin, found = information_badge_skin(getattr(screen, 'skin', ''), anchor, position)
    if not found:
        return
    from Components.Label import Label
    screen.skin = skin
    for badge_name in (_NAME, _YEAR_NAME, _GENRE_NAME, _DURATION_NAME, _RATING_NAME):
        screen[badge_name] = Label('')
        screen[badge_name].hide()
    screen._information_badge_meta_text = ''
    screen._information_resolution_installed = True
    screen._information_resolution_closed = False
    reference = weakref.ref(screen)
    def refresh(_owner=None):
        current = reference()
        if current is None or getattr(current, '_information_resolution_closed', False):
            return
        sources = _current_sources(current)
        set_resolution_badge(current, _NAME, extract_resolution(*sources))
        year, genre = _year_genre_from_meta(getattr(current, '_information_badge_meta_text', ''))
        if not year or not genre:
            source_year, source_genre = _year_genre_from_sources(sources)
            year = year or source_year
            genre = genre or source_genre
        _set_pill(current, _YEAR_NAME, year)
        _set_pill(current, _GENRE_NAME, genre)
        duration = extract_duration(*sources)
        if not duration:
            for part in re.split(r'\s*[•|]\s*', str(getattr(current, '_information_badge_meta_text', '') or '')):
                if re.search(r'(?i)\b\d+\s*(?:min|hour|hr)|\d{1,2}:\d{2}', part):
                    duration = format_duration(part)
                    if duration: break
        _set_pill(current, _DURATION_NAME, duration)
        rating = extract_rating(*sources)
        if not rating and current.__class__.__name__ in ('FastMoviesContentScreen', 'NewMoviesContentScreen'):
            # The active TMDb preview sometimes enriches the displayed score
            # before fullInfoCache gets a provider record. Never reuse the old
            # poster's score: preview() resets this field on selection change.
            preview_rating = getattr(current, '_information_badge_preview_rating', '')
            match = re.search(r'[★☆]\s*(\d{1,2}(?:[.,]\d+)?)',
                              str(getattr(current, '_information_badge_meta_text', '') or ''))
            if match:
                preview_rating = match.group(1)
            rating = extract_rating({'rating': preview_rating})
        _set_pill(current, _RATING_NAME, rating)
        _compact_browsing_pills(current)
    for name in (observe or (anchor,)):
        try:
            original = screen[name].setText
        except (KeyError, AttributeError):
            continue
        def changed(value, original=original, name=name):
            # Keep complete metadata for badge extraction, but show duration only
            # in MovieDetailsScreen where year and genres have their own pills.
            display_value = value
            if name == anchor and badges_only:
                display_value = ''
            elif name == anchor and details_deduplicate and isinstance(value, str):
                display_value = ''  # Details: facts are already in coloured pills.
            elif name == anchor and isinstance(value, str):
                display_value = _hide_plain_facts(value, _current_sources(screen))
            result = original(display_value)
            if name == anchor:
                screen._information_badge_meta_text = value
            refresh()
            return result
        screen[name].setText = changed
    def closed(*args):
        current = reference()
        if current is not None:
            current._information_resolution_closed = True
    # PurE2/Enigma2 executes non-bound layout callbacks as Python code via
    # exec(). Register genuine methods, matching the screen.close type, so
    # this callback is called normally instead of triggering a TypeError.
    screen.onLayoutFinish.append(MethodType(refresh, screen))
    screen.onClose.append(MethodType(closed, screen))
    refresh()
