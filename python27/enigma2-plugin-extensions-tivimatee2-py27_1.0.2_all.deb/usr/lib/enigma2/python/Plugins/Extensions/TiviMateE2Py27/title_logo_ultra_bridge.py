# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import ensure_dir
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace, subprocess_run, which
"""Identity-safe title logos, adapted from UltraStalker title_logo_ultra.

Worker-thread only. Shared across GENRE, movie/series details, packages and
preview hero. Never changes the poster or backdrop pipeline.
"""
import hashlib
import json
import os
import re
import shutil
import tempfile
from contextlib import closing
import threading
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode, urlsplit
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, build_opener, HTTPRedirectHandler
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import HTTPError

from .cache_manager import get_cache_dir
from .genre_ultra_artwork import _download_transparent_logo, _logo_cache_usable
from .logo_manager import tmdb_logo_url, logo_language, preferred_logo_languages, _ordered_languages

_LOCKS = [threading.Lock() for _ in range(24)]
_ARAB_COUNTRIES = frozenset(('AE', 'SA', 'EG', 'BH', 'QA', 'OM', 'KW', 'IQ', 'JO', 'LB',
                             'SY', 'PS', 'YE', 'MA', 'DZ', 'TN', 'LY', 'SD'))


def _media(kind):
    return 'tv' if str(kind).lower() in ('series', 'tv', 'episode') else 'movie'


def _valid_id(value):
    try:
        number = int(str(value or '').strip())
        return str(number) if number > 0 else ''
    except (ValueError, TypeError):
        return ''


def _origin_lang(item, details, title, requested):
    # The original Arabic title logo is still preferred when the UI is English.
    # This helper is shared with the other TMDb logo paths to keep them equal.
    return preferred_logo_languages(details=details, item=item, title=title,
                                    selected=requested)


def _cache_path(kind, ident, lang, canvas):
    w, h = int(canvas[0]), int(canvas[1])
    folder = os.path.join(get_cache_dir('logos'), 'identity_ultra_v1')
    return os.path.join(folder, '%s_%s_%s_%sx%s.png' % (_media(kind), ident, lang, w, h))


def _copy_preserving_alpha(source, destination, canvas):
    """Like Ultra's master canvas; do not stretch transparent lettering."""
    ensure_dir(os.path.dirname(destination))
    fd, temp = tempfile.mkstemp(prefix='.logo_', suffix='.png', dir=os.path.dirname(destination))
    os.close(fd)
    try:
        try:
            from PIL import Image
            image = Image.open(source)
            try:
                image_width, image_height = image.size
                if image_width < 4 or image_height < 4 or image_width * image_height > 6000000:
                    return ''
                frame = image.convert('RGBA')
                lo, hi = frame.split()[-1].getextrema()
                if lo >= 255 or hi <= 0:
                    return ''
                w, h = [int(x) for x in canvas]
                maxw, maxh = max(1, w - 18), max(1, h - 8)
                resample = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 1))
                frame.thumbnail((maxw, maxh), resample)
                result = Image.new('RGBA', (w, h), (0, 0, 0, 0))
                frame_width, frame_height = frame.size
                # An unmasked RGBA paste preserves alpha without requiring
                # Pillow.Image.alpha_composite() (not present on old builds).
                result.paste(frame, ((w-frame_width)//2, (h-frame_height)//2))
                result.save(temp, 'PNG')
            finally:
                try:
                    image.close()
                except (AttributeError, IOError, OSError):
                    pass
        except (ImportError, AttributeError, TypeError, IOError, OSError, ValueError):
            # DreamOS/Python 2.7 sometimes has an old PIL that imports but lacks
            # modern RGBA/thumbnail methods. Preserve the original transparent
            # PNG rather than dropping every clearlogo for that reason.
            # If ffmpeg is available it is used for aspect-fit as before.
            import subprocess
            ffmpeg = which('ffmpeg')
            if ffmpeg:
                w, h = [int(x) for x in canvas]
                filt = ('scale=%s:%s:force_original_aspect_ratio=decrease,'
                        'pad=%s:%s:(ow-iw)/2:(oh-ih)/2:color=black@0' %
                        (max(1, w-18), max(1, h-8), w, h))
                try:
                    subprocess_run([ffmpeg, '-v', 'error', '-y', '-i', source,
                                    '-vf', filt, '-frames:v', '1', '-pix_fmt', 'rgba',
                                    '-update', '1', temp], stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, check=True, timeout=6)
                except (OSError, RuntimeError, subprocess.CalledProcessError):
                    shutil.copyfile(source, temp)
            else:
                shutil.copyfile(source, temp)
        if not _logo_cache_usable(temp, 'logo.png'):
            return ''
        atomic_replace(temp, destination)
        return destination
    finally:
        try:
            os.unlink(temp)
        except OSError:
            pass


def _ranking(row):
    try:
        vote = float(row.get('vote_average') or 0)
    except (ValueError, TypeError):
        vote = 0
    try:
        count = int(row.get('vote_count') or 0)
    except (ValueError, TypeError):
        count = 0
    try:
        area = int(row.get('width') or 0) * int(row.get('height') or 0)
    except (ValueError, TypeError):
        area = 0
    return (vote, count, area)


def _tmdb_candidates(client, kind, ident, metadata, languages, cancelled):
    # Include language-neutral artwork; never relabel a foreign image as English.
    logos = list((metadata.get('images') or {}).get('logos') or []) if isinstance(metadata, dict) else []
    if not cancelled():
        try:
            found = client._get('/%s/%s/images' % (_media(kind), ident), {
                'include_image_language': ','.join(_ordered_languages(tuple(languages) + ('null',)))}) or {}
            logos.extend(found.get('logos') or [])
        except Exception:
            pass
    ranked = {}
    seen = set()
    for entry in logos:
        if not isinstance(entry, dict):
            continue
        uri = tmdb_logo_url(entry.get('file_path'), 'w500')
        if not uri or uri in seen:
            continue
        seen.add(uri)
        lang = str(entry.get('iso_639_1') or '').split('-')[0].lower() or '00'
        ranked.setdefault(lang, []).append((_ranking(entry), uri))
    for k in ranked:
        ranked[k].sort(reverse=True)
    return {key: [url for _, url in rows] for key, rows in ranked.items()}


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _fanart_candidates(client, kind, ident, cancelled):
    # Fanart is strictly optional; no key -> no request and no bogus setting.
    try:
        from .banner_artwork import read_key
        key = read_key()
    except Exception:
        key = ''
    if not key or cancelled():
        return {}
    media = _media(kind)
    media_id = ident
    if media == 'tv':
        try:
            extra = client._get('/tv/%s/external_ids' % ident, {}) or {}
            media_id = _valid_id(extra.get('tvdb_id'))
        except Exception:
            media_id = ''
        if not media_id:
            return {}
    category = 'tv' if media == 'tv' else 'movies'
    base = 'https://webservice.fanart.tv/v3/%s/%s?' % (category, media_id)
    opener = build_opener(_NoRedirect)
    payload = {}
    for auth in ('client_key', 'api_key'):
        if cancelled():
            return {}
        try:
            request = Request(base + urlencode({auth: key}), headers={
                'Accept': 'application/json', 'User-Agent': 'TiviMateE2/UltraLogo'})
            with closing(opener.open(request, timeout=4)) as response:
                raw = response.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                return {}
            payload = json.loads(raw.decode('utf-8'))
            break
        except HTTPError as exc:
            if exc.code not in (401, 403):
                return {}
        except Exception:
            return {}
    names = ('hdtvlogo', 'clearlogo', 'tvlogo') if media == 'tv' else ('hdmovielogo', 'movielogo')
    ranked = {}
    for field in names:
        for entry in payload.get(field) or [] if isinstance(payload, dict) else []:
            if not isinstance(entry, dict):
                continue
            url = str(entry.get('url') or '').strip()
            parsed = urlsplit(url)
            # Never send portal credentials or Fanart API credentials to images.
            if parsed.hostname != 'assets.fanart.tv' or parsed.scheme not in ('https', 'http'):
                continue
            if parsed.scheme == 'http':
                url = 'https://' + url.split('://', 1)[1]
            lang = str(entry.get('lang') or '00').lower()
            try:
                score = int(entry.get('likes') or 0)
            except (ValueError, TypeError):
                score = 0
            ranked.setdefault(lang, []).append((score, url))
    for k in ranked:
        ranked[k].sort(reverse=True)
    return {k: [url for _, url in rows] for k, rows in ranked.items()}



def cached_identity_logo(kind, tmdb_id, canvas=(620, 100), title='', details=None,
                         item=None, cancelled=None, preferred_only=False):
    """Disk-only, identity-safe logo lookup across all supported page canvases.

    Never performs TMDb/Fanart requests. Existing cached logo of the same
    verified TMDb movie/tv ID is reused before new gallery metadata lookups.
    Preserve the requested Arabic/English/neutral ordering and transparency.
    """
    ident = _valid_id(tmdb_id)
    if not ident:
        return ''
    cancelled = cancelled or (lambda: False)
    langs = _origin_lang(item, details, title, logo_language(None))
    sizes = (tuple(canvas), (490, 130), (620, 96), (620, 100), (680, 106),
             (690, 110), (760, 132), (900, 142), (920, 124))
    # Do not re-encode an already suitable image; only resize a cached
    # correctly identified PNG when this page requests another canvas size.
    # In the pre-network fast path, never let a cached English fallback stop
    # discovery of a real Arabic logo. The fallback is checked after fetching.
    # Match the working Python 3 resolver: the pre-network fast path may
    # reuse only the preferred language. A previously cached English/neutral
    # fallback must not permanently hide an available original-language logo.
    candidate_langs = (langs[0],) if preferred_only else tuple(langs) + ('00', 'any')
    for lang in _ordered_languages(candidate_langs):
        if cancelled():
            return ''
        destination = _cache_path(kind, ident, lang, canvas)
        if _logo_cache_usable(destination, 'logo.png'):
            return destination
        for size in sizes:
            if tuple(size) == tuple(canvas):
                continue
            source = _cache_path(kind, ident, lang, size)
            if _logo_cache_usable(source, 'logo.png'):
                converted = _copy_preserving_alpha(source, destination, canvas)
                if converted:
                    return converted
    return ''


def resolve_title_logo(client, kind, tmdb_id, title='', details=None, item=None,
                       canvas=(620, 100), cancelled=None):
    """Return validated, alpha-preserving local PNG or empty string.

    Call ONLY from a background worker. A verified TMDb ID must be supplied by
    the caller; provider stream/series IDs are never accepted as TMDb identity.
    """
    ident = _valid_id(tmdb_id)
    if not ident:
        return ''
    cancelled = cancelled or (lambda: False)
    raw = details if isinstance(details, dict) else {}
    language = logo_language(client)
    # Pure disk-only fast path. The first focus after reopen must not do a
    # metadata request merely to rediscover an already prepared canvas.
    # Shared cache-first by verified identity (including logos prepared at a
    # different page size). No metadata request before this disk-only lookup.
    cached = cached_identity_logo(kind, ident, canvas, title, raw, item, cancelled, preferred_only=True)
    if cached:
        return cached
    # Avoid blank logos when TMDb returns only the listing row.
    if not raw.get('original_language') and not cancelled():
        try:
            extra = client._get('/%s/%s' % (_media(kind), ident), {'language': 'en-US'}) or {}
            raw = dict(raw)
            for key in ('original_language', 'origin_country', 'production_countries', 'images'):
                if not raw.get(key) and extra.get(key):
                    raw[key] = extra[key]
        except Exception:
            pass
    langs = _origin_lang(item, raw, title, language)
    lock = _LOCKS[int(hashlib.sha1((_media(kind)+ident).encode('ascii')).hexdigest()[:8], 16) % len(_LOCKS)]
    with lock:
        # Only the selected language can short-circuit the remote lookup.
        # English/neutral cached fallbacks are considered *after* attempting
        # the preferred language, to allow switching an already-cached title.
        existing = _cache_path(kind, ident, langs[0], canvas)
        if _logo_cache_usable(existing, 'logo.png'):
            return existing
        if cancelled():
            return ''
        logos = _tmdb_candidates(client, kind, ident, raw, langs, cancelled)
        fanart = None
        budget = 16  # same total budget as the working Python 3 identity resolver
        for lang in _ordered_languages(tuple(langs) + ('00', 'any')):
            if cancelled() or budget <= 0:
                return ''
            target = _cache_path(kind, ident, lang, canvas)
            if lang != langs[0] and _logo_cache_usable(target, 'logo.png'):
                return target
            if lang == 'any':
                # Ultra's last-resort gallery query includes foreign-language
                # logos that ar,en,null filters intentionally do not return.
                if not cancelled():
                    try:
                        # TMDb's default language filter often returns only
                        # English logos. Explicitly request other language
                        # galleries for this *same verified title ID*.
                        extra_languages = ('fr', 'es', 'de', 'it', 'pt', 'tr',
                                           'ja', 'ko', 'zh', 'hi', 'ru', 'null')
                        gallery = client._get('/%s/%s/images' % (_media(kind), ident), {
                            'include_image_language': ','.join(_ordered_languages(tuple(langs) + extra_languages))
                        }) or {}
                        for row in gallery.get('logos') or []:
                            if not isinstance(row, dict):
                                continue
                            iso = str(row.get('iso_639_1') or '').split('-')[0].lower()
                            url = tmdb_logo_url(row.get('file_path'), 'w500')
                            if iso and iso not in langs and url:
                                logos.setdefault(iso, []).append(url)
                    except Exception:
                        pass
                urls = [url for tag, rows in logos.items() if tag not in langs and tag != '00' for url in rows[:2]]
            else:
                urls = list(logos.get(lang, []))
            # Match Python 3: ranked preferred-language images first;
            # bounded attempts leave room for English/neutral/other fallback.
            urls = urls[:4] if lang not in ('00', 'any') else urls[:6]
            seen = set()
            budget_ref = [budget]
            def try_urls(values):
                # Python 2.7: mutable counter avoids nonlocal statement
                for url in values:
                    if cancelled() or budget_ref[0] <= 0:
                        return ''
                    if not url or url in seen:
                        continue
                    seen.add(url)
                    budget_ref[0] -= 1
                    try:
                        source = _download_transparent_logo(url, {})
                        if source and _logo_cache_usable(source, url):
                            ready = _copy_preserving_alpha(source, target, canvas)
                            if ready:
                                return ready
                    except Exception:
                        continue
                return ''
            result = try_urls(urls)
            budget = budget_ref[0]
            if result:
                return result
            if budget <= 0 or cancelled():
                return ''
            if fanart is None and not cancelled():
                fanart = _fanart_candidates(client, kind, ident, cancelled)
            if fanart:
                if lang == 'any':
                    extras = [url for tag, rows in fanart.items() if tag not in langs and tag != '00' for url in rows[:2]]
                elif lang == '00':
                    extras = fanart.get('00', []) + fanart.get('', [])
                else:
                    extras = fanart.get(lang, [])
                result = try_urls(extras[:4])
                budget = budget_ref[0]
                if result:
                    return result
        return ''
