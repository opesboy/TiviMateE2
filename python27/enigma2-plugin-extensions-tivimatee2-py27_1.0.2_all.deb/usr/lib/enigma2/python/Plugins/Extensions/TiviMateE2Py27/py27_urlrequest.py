# -*- coding: utf-8 -*-
"""Scoped urllib2-compatible urllib.request bridge for Python 2.7."""
import urllib2
from Plugins.Extensions.TiviMateE2Py27.py27_compat import http_url_bytes
from urllib2 import (HTTPError, URLError, HTTPRedirectHandler, HTTPCookieProcessor,
                     HTTPHandler, HTTPSHandler, build_opener, install_opener,
                     ProxyHandler, Request as _Request)
class Request(_Request):
    def __init__(self, url, data=None, headers={}, origin_req_host=None,
                 unverifiable=False, method=None):
        self._method_override = method
        _Request.__init__(self, http_url_bytes(url), data=data, headers=headers,
                          origin_req_host=origin_req_host, unverifiable=unverifiable)
    @property
    def full_url(self): return self.get_full_url()
    def get_method(self):
        if self._method_override: return self._method_override
        return _Request.get_method(self)

class _ContextResponse(object):
    def __init__(self, response): self._response=response
    def __getattr__(self, key): return getattr(self._response,key)
    def __iter__(self): return iter(self._response)
    def __enter__(self): return self
    def __exit__(self, typ, value, tb):
        try: self._response.close()
        except Exception:pass
        return False

def urlopen(url, data=None, timeout=10, **kwargs):
    # Python >=2.7.9 supports a TLS context. Fail closed for unsupported variants.
    # urllib2.urlopen also accepts direct URLs; protect this entry point.
    if isinstance(url, (str, unicode)):
        url = http_url_bytes(url)
    response=urllib2.urlopen(url, data=data, timeout=timeout, **kwargs)
    return _ContextResponse(response)
