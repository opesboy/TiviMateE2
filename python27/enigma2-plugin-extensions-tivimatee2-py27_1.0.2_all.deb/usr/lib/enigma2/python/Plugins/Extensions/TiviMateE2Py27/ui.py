# -*- coding: utf-8 -*-
from .pink_rating import show_pink_rating
from .country_flags import show_country_flag
from .storage import get_data_root, data_path, favorites_path
from .finder_playlist_storage import finder_playlist_path, finder_identity_url
from .episode_still_index import episode_still_index_lookup, episode_still_index_save
from .genre_images import saved_genre_image, save_genre_image
from .genre_package_badges import resolve_package_badge
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode, urlparse, quote
import uuid

from .compat import atomic_replace, ensure_dir, open_text, python_command

import os
import sys
import tempfile
import hashlib
import json
import gzip
import base64
import threading
import time
import re
from datetime import datetime, timedelta

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import MoviePlayer
try:
    from Screens.AudioSelection import AudioSelection
except Exception:
    AudioSelection = None
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText as _EnigmaMultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from .py27_compat import gui_text, text_type

def _live_classic_row_label(number, channel_name, favourite=False):
    """Build *Unicode* before crossing the Enigma2 Python2 display boundary.

    Some Arabic channel names are unicode while the favourite star is a UTF-8
    source byte literal.  Python2 tries to decode those bytes as ASCII when
    interpolating them; the crash happens before Py27TextMenuList.setList().
    Keeping this conversion here also handles legacy CP1256 provider names.
    """
    try:
        name = text_type(channel_name if channel_name is not None else u'')
    except (UnicodeError, TypeError, ValueError):
        name = u''
    name = name.strip() or u'Unnamed Channel'
    try:
        label_number = text_type(number)
    except (UnicodeError, TypeError, ValueError):
        label_number = u''
    return u'%s   %s%s' % (label_number, u'★  ' if favourite else u'', name)


class Py27TextMenuList(MenuList):
    """UTF-8 labels for legacy Enigma2 menus, leave provider rows untouched."""
    def setList(self, entries):
        fixed = []
        for entry in (entries or []):
            if isinstance(entry, (tuple, list)) and entry:
                fixed.append((gui_text(entry[0]),) + tuple(entry[1:]))
            elif isinstance(entry, (str, unicode)):
                fixed.append(gui_text(entry))
            else:
                fixed.append(entry)
        return MenuList.setList(self, fixed)

class Py27LivePiconList(MenuList):
    """Cache-first picons in Classic Live channel rows (Python 2.7 safe).

    The renderer NEVER downloads or opens files: only previously prepared
    gPixmaps are read. At most the 15 visible rows request remote picons.
    """
    def __init__(self, entries=None, owner=None):
        self._liveOwner = owner
        self._liveGeneration = 0
        self._livePiconReady = {}
        self._livePiconPaths = {}
        self._livePiconDecoders = {}
        self._livePiconAsked = set()
        self._livePiconDefault = None
        self._liveTimer = eTimer()
        try:
            self._liveTimer.timeout.connect(self._request_visible)
        except (AttributeError, TypeError):
            self._liveTimer.callback.append(self._request_visible)
        try:
            self._livePiconDefault = LoadPixmap(os.path.join(
                os.path.dirname(__file__), 'skins', 'live', 'icons', 'general.png'))
        except Exception:
            pass
        MenuList.__init__(self, entries or [], False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', 22))
        self.l.setItemHeight(50)
        self.l.setBuildFunc(self._build_live_row)
        self.onSelectionChanged.append(self._schedule_visible)

    def setList(self, entries):
        self._liveGeneration += 1
        self._livePiconAsked.clear()
        self._livePiconDecoders.clear()
        fixed = []
        for row in (entries or []):
            if isinstance(row, (tuple, list)) and row:
                fixed.append((gui_text(row[0]),) + tuple(row[1:]))
            else:
                fixed.append(row)
        MenuList.setList(self, fixed)
        self._schedule_visible()

    def _build_live_row(self, name, channel):
        row = [(name, channel)]
        image = None
        try:
            from .estalker_picon import resolve_picon_url
            url = resolve_picon_url(channel, getattr(self._liveOwner, 'source', None))
            image = self._livePiconReady.get(url)
        except Exception:
            pass
        if image is None:
            image = self._livePiconDefault
        if image is not None:
            row.append(MultiContentEntryPixmapAlphaBlend(
                pos=(7, 5), size=(40, 40), png=image))
        row.append(MultiContentEntryText(
            pos=(54, 0), size=(450, 50), font=0,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=gui_text(name)))
        return row

    def _schedule_visible(self):
        try:
            self._liveTimer.stop()
            self._liveTimer.start(90, True)
        except Exception:
            pass

    def _request_visible(self):
        generation = self._liveGeneration
        try:
            rows = self.list or []
            try:
                start = int(self.instance.getTopIndex())
            except Exception:
                selected = int(self.getSelectedIndex() or 0)
                start = max(0, selected - 5)
            start = max(0, min(start, max(0, len(rows) - 1)))
            from .estalker_picon import resolve_picon_url, cached_picon_path, direct_picon
            source = getattr(self._liveOwner, 'source', None)
            for i in range(start, min(len(rows), start + 15)):
                entry = rows[i]
                if not isinstance(entry, (tuple, list)) or len(entry) < 2 or not isinstance(entry[1], dict):
                    continue
                url = resolve_picon_url(entry[1], source)
                if not url or url in self._livePiconAsked:
                    continue
                self._livePiconAsked.add(url)
                def current():
                    return self._liveGeneration
                def ready(path, expected=generation, target=url):
                    if expected != self._liveGeneration or not path or not os.path.isfile(path):
                        return
                    try:
                        pix = LoadPixmap(path) if path.lower().endswith('.png') else None
                        if pix is None:
                            loader = ePicLoad()
                            self._livePiconDecoders[target] = loader
                            def decoded(_info=None, ref=loader, image_url=target,
                                        file_path=path, version=expected):
                                if self._livePiconDecoders.get(image_url) is not ref:
                                    return
                                self._livePiconDecoders.pop(image_url, None)
                                if version != self._liveGeneration:
                                    return
                                try:
                                    image = ref.getData()
                                    if image is not None:
                                        self._publish_live_picon(image_url, file_path, image)
                                except Exception:
                                    pass
                            from .picload_compat import connect_picture_data
                            connect_picture_data(loader, decoded, self, oneshot=True)
                            loader.setPara((40, 40, 0, 0, False, 1, '#00000000'))
                            try: loader.startDecode(path)
                            except Exception: self._livePiconDecoders.pop(target, None)
                            return
                        self._publish_live_picon(target, path, pix)
                    except Exception:
                        pass
                hit = cached_picon_path(url, (220, 130))
                if hit:
                    ready(hit)
                else:
                    direct_picon(url, (220, 130), generation, current, ready,
                                 prefix='xst_live_picon_', priority=10)
        except Exception:
            pass

    def _publish_live_picon(self, target, path, pix):
        try:
            self._livePiconReady[target] = pix
            self._livePiconPaths[target] = path
            if len(self._livePiconReady) > 90:
                self._livePiconReady.clear()
                self._livePiconPaths.clear()
                self._livePiconReady[target] = pix
            from .estalker_picon import resolve_picon_url
            selected = int(self.getSelectedIndex() or 0)
            try:
                top = int(self.instance.getTopIndex())
            except Exception:
                top = max(0, selected - 5)
            for index, row in enumerate(self.list or []):
                if index < max(0, top-2) or index >= top+17:
                    continue
                if isinstance(row, (tuple, list)) and len(row) >= 2 and isinstance(row[1], dict):
                    if resolve_picon_url(row[1], getattr(self._liveOwner, 'source', None)) == target:
                        try: self.l.invalidateEntry(index)
                        except Exception: pass
        except Exception:
            pass


def MultiContentEntryText(*args, **kwargs):
    """Python 2.7 DreamOS renderer accepts UTF-8 byte labels, not unicode.

    Scoped to this plugin's UI source fragments; no global Enigma2 patches.
    """
    if 'text' in kwargs:
        kwargs['text'] = gui_text(kwargs['text'])
    return _EnigmaMultiContentEntryText(*args, **kwargs)

from Components.Label import Label
from .rtl_text import DirectionalLabel, SynopsisLabel, AdaptiveOverviewLabel, CenteredArabicMetadataLabel, RisingOverviewLabel
from .display_titles import clean_display_title, visible_title
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigPassword, ConfigSelection, ConfigYesNo, getConfigListEntry, config, configfile
from enigma import (eServiceReference, ePicLoad, eTimer, eConsoleAppContainer, ePoint,
    eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eEPGCache, eSize)
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from .live_service import live_reference, live_reference_string, epg_reference_string
from .live_package_icons import package_country, package_kind, package_special_icon, package_visual, fetch_flag
from .epg_local import lookup_channel_epg, load_source_epg, refresh_source_epg, ensure_source_epg
try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .metadata_display import merge_metadata, provider_cache_key, keep_arabic_on_late_update, contains_arabic_text
from .poster_manager import usable_poster_file
from .content_home import ContentHomeScreen, FastMoviesContentScreen, FastSeriesContentScreen, MovieDetailsScreen, warm_backdrop_metadata_from_home, _server_poster_url, _server_asset_url
from .banner_artwork import read_key as read_fanart_banner_key, save_key as save_fanart_banner_key

HOME_TMDb_CACHE_FILE = data_path("home_tmdb_cache.json")
_HOME_TMDb_CACHE_LOCK = threading.Lock()

# ---------------------------------------------------------------------------
# TiviMateE2 UI source layout
#
# The large UI implementation is split into ordered source fragments under
# _ui_parts/. They are executed in this module namespace so existing imports
# from .ui keep the same public API and class globals without circular imports.
# ---------------------------------------------------------------------------
def _load_ui_part(filename):
    path = os.path.join(os.path.dirname(__file__), "_ui_parts", filename)
    # Compilation is warmed after Enigma2 session start, off the GUI thread.
    # If the warmup is not ready (or a source file changed), fall back to the
    # original trusted-source compiler, with identical execution semantics.
    from .ui_preload import get_compiled_part
    eval(get_compiled_part(path), globals(), globals())


_UI_PARTS = (
    "01_common_and_skins.py",
    "02_editors_and_tmdb.py",
    "03_packages_and_settings.py",
    "04_server_manager.py",
    "05_search_home_continue.py",
    "06_series_details.py",
    "07_media_and_favorites.py",
)

for _ui_part in _UI_PARTS:
    _load_ui_part(_ui_part)

# Warming is for first paint only. Avoid retaining ~36k lines of bytecode in
# duplicate memory after the UI has loaded.
from .ui_preload import release as _release_warmed_ui
_release_warmed_ui()
del _release_warmed_ui
del _ui_part

# Ultra-style user-selectable typography. Apply once to plugin-owned skins only;
# Enigma2 system skins and subtitle font settings remain untouched.
from .font_preferences import apply_module_screens as _apply_font_screens
_apply_font_screens(globals(), Screen)
del _apply_font_screens
