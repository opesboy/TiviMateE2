# -*- coding: utf-8 -*-
"""Apple-inspired 20-card Movies screen.

Only the film presentation is changed. The provider, cache-first artwork
lookup, poster fallback, playing and movie details stay on the existing
Cinematic/GENRE implementation. No additional poster network queue is made.
"""
import os
import re
import threading
import hashlib
import time
import xml.etree.ElementTree as ET
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from .py27_compat import text_type
from Components.Pixmap import Pixmap
from Components.ActionMap import ActionMap
from enigma import ePoint, eSize, ePicLoad, eTimer
from .display_scale import sx, sy
from .cinematic_catalog import CinematicCatalogScreen
from .genre_page import StandaloneGenreScreen
from .resolution_badge import extract_rating
from .cinematic_catalog import _CINE_BACKDROP_COVER_POOL
from .picload_compat import connect_picture_data
from .tmdb_client import TMDbClient
from .backdrop_manager import tmdb_backdrop_url
from .artwork_queue import cached_artwork
from .genre_ultra_artwork import request as genre_ultra_request
try:
    from .genre_ultra_artwork import pending_count as _ultra_pending
except Exception:
    def _ultra_pending():
        return 0

_ASSET = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/'
_PINK = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/poster/vod_large_poster_rating_pink_84x82.png'
_COLS = 5
_PER_PAGE = 20
_DRAWER_COUNT = 8
_DRAWER_STEPS = 6
_X = (133, 345, 557, 769, 981)
_Y = (215, 415, 615, 815)
_W, _H = 170, 185

# Limit concurrent gallery resolution; shared by Apple Movies instances.
_APPLE_GALLERY_GATE = threading.BoundedSemaphore(1)

# Visual fingerprints: provider/cached files often have another name or size
# than the TMDb gallery file, so URL identity alone cannot tell that the inner
# frame and the outer background show the same picture.
# TMDb /images list per title (RAM, 6 h): revisiting a film needs no network.
_APPLE_GALLERY_CACHE = {}
_APPLE_GALLERY_LOCK = threading.Lock()
_APPLE_GALLERY_TTL = 6 * 3600

_APPLE_HASH_CACHE = {}
_APPLE_HASH_LOCK = threading.Lock()
_APPLE_SAME_IMAGE_DISTANCE = 12


def _apple_dhash(path):
    """64-bit difference hash; tolerant to resize/re-encode, cheap on boxes."""
    try:
        stat = os.stat(path)
        key = (os.path.realpath(path), stat.st_size, int(stat.st_mtime))
    except Exception:
        return None
    with _APPLE_HASH_LOCK:
        if key in _APPLE_HASH_CACHE:
            return _APPLE_HASH_CACHE[key]
    value = None
    try:
        from PIL import Image
        with Image.open(path) as image:
            try: image.draft('L', (72, 64))
            except Exception: pass
            small = image.convert('L').resize((9, 8))
            pixels = list(small.getdata())
        value = 0
        for row in range(8):
            for col in range(8):
                left = pixels[row * 9 + col]
                right = pixels[row * 9 + col + 1]
                value = (value << 1) | (1 if left > right else 0)
    except Exception:
        value = None
    with _APPLE_HASH_LOCK:
        if len(_APPLE_HASH_CACHE) > 300:
            _APPLE_HASH_CACHE.clear()
        _APPLE_HASH_CACHE[key] = value
    return value


def _apple_same_picture(first, second):
    """True when two files show the same scene (same backdrop twice)."""
    if not first or not second:
        return False
    try:
        if os.path.realpath(first) == os.path.realpath(second):
            return True
    except Exception:
        pass
    a = _apple_dhash(first)
    b = _apple_dhash(second)
    if a is None or b is None:
        return False
    return bin(a ^ b).count('1') <= _APPLE_SAME_IMAGE_DISTANCE



def _apple_round_flag(path):
    """Circular country flag (64px, thin white ring) cached beside the flag."""
    if not path or not os.path.isfile(path):
        return ''
    target = path[:-4] + '_round64.png'
    try:
        if os.path.isfile(target) and os.path.getmtime(target) >= os.path.getmtime(path):
            return target
        from PIL import Image, ImageOps, ImageDraw
        big = 192
        lanczos = Image.Resampling.LANCZOS if hasattr(Image, 'Resampling') else Image.LANCZOS
        with Image.open(path) as flag:
            face = ImageOps.fit(flag.convert('RGBA'), (big, big), method=lanczos)
        mask = Image.new('L', (big, big), 0)
        ImageDraw.Draw(mask).ellipse((9, 9, big - 10, big - 10), fill=255)
        out = Image.new('RGBA', (big, big), (0, 0, 0, 0))
        out.paste(face, (0, 0), mask)
        ImageDraw.Draw(out).ellipse((4, 4, big - 5, big - 5), outline=(255, 255, 255, 235), width=8)
        out = out.resize((64, 64), lanczos)
        tmp = target + '.%s.tmp' % threading.current_thread().ident
        out.save(tmp, format='PNG')
        os.rename(tmp, target)
        return target
    except Exception:
        return ''


def _apple_bytes(value):
    """UTF-8 bytes for hashing on Python 3 and 2.7 (byte paths stay as-is)."""
    if isinstance(value, bytes):
        return value
    return _apple_unicode(value).encode('utf-8')


def _apple_backdrop_url(path, role='outer'):
    """TMDb backdrop sized for this screen, never 'original' (often 4K, MBs).

    Outer = full-screen dimmed background, inner = 670px framed image. Small
    files keep Apple's extra artwork from blocking the shared poster lanes."""
    try:
        from .display_scale import desktop_size
        width = int(desktop_size()[0] or 1920)
    except Exception:
        width = 1920
    if role == 'inner':
        size = 'w780'
    else:
        size = 'w1280' if width >= 1600 else 'w780'
    return tmdb_backdrop_url(path, size)


def _apple_unicode(value):
    """Keep Arabic package/genre labels safe on both Python 2.7 and 3."""
    if value is None:
        return u''
    try:return text_type(value)
    except Exception:return u''

# Attributes VTi's skin.py rejects ("Attribute not implemented"); removing
# them here means the screen never depends on the global VTi skin hook.
_VTI_UNSUPPORTED = ('cornerRadius', 'cornerRadiusValue', 'itemCornerRadius',
    'itemCornerRadiusSelected', 'itemCornerRadiusMarked', 'itemGradientSelected',
    'itemGradient', 'selectionForegroundColor', 'selectionForegroundColorValue',
    'selectionBackgroundColor', 'scrollbarWidth', 'scrollbarRadius', 'secondfont',
    'borderWidth', 'borderColor', 'resolution', 'textBorderColor', 'textBorderWidth',
    'padding', 'textPadding', 'backgroundGradient', 'foregroundGradient')


def _skin(series=False):
    """20 dynamic posters, native GENRE badges, and the original sliding package drawer."""
    base=CinematicCatalogScreen.skin
    if isinstance(base,unicode):base=base.encode('utf-8')
    root=ET.fromstring(base)
    root.set('name','AppleSeriesScreen' if series else 'AppleMoviesScreen')
    root.set('backgroundColor','#060910')
    def pos(node,x,y,w,h,z):
        node.set('position','%d,%d'%(sx(x),sy(y)))
        node.set('size','%d,%d'%(sx(w),sy(h)))
        node.set('zPosition',str(z))
    for node in list(root):
        if node.tag in ('eLabel','ePixmap'):
            root.remove(node)
            continue
        if node.tag!='widget':continue
        pos(node,0,0,1,1,1)
        node.set('transparent','1')
        name=node.get('name','')
        if name=='selector':
            pos(node,_X[0]-8,_Y[0]-8,_W+16,_H+16,38)
            node.set('pixmap',_ASSET+'apple_focus.png')
            node.set('alphatest','blend')
        elif name.startswith('poster') and name[6:].isdigit():
            i=int(name[6:])
            if i<_PER_PAGE:
                pos(node,_X[i%5],_Y[i//5],_W,_H,10)
                node.set('alphatest','blend');node.set('scale','1')
        elif name.startswith('shell') and name[5:].isdigit():
            i=int(name[5:])
            if i<_PER_PAGE:
                pos(node,_X[i%5],_Y[i//5],_W,_H,16)
                node.set('pixmap',_ASSET+'apple_shell.png')
                node.set('alphatest','blend')
        elif name=='heroBackdrop':
            # Constrained to the silver framed right panel. Never full-screen.
            pos(node,1221,365,670,646,12)
            node.set('alphatest','off');node.set('scale','1')
        elif name=='rightBackdropShade':
            pos(node,1221,365,670,646,13)
            node.set('pixmap',_ASSET+'apple_backdrop_shade.png')
            node.set('alphatest','blend')
        elif name=='heroLogo':
            # Above the silver frame, over the full-screen backdrop.
            pos(node,1257,180,600,160,24)
            node.set('alphatest','blend');node.set('scale','1')
        elif name=='heroTitle':
            pos(node,1229,205,656,110,24)
            node.set('font','Bold;40');node.set('foregroundColor','#F7F6F7')
            node.set('halign','center');node.set('valign','center')
        elif name=='heroMeta':
            pos(node,0,0,1,1,1)
        elif name=='heroPlot':
            pos(node,1246,747,635,137,29)
            node.set('font','Regular;23');node.set('foregroundColor','#F1EEF0')
            node.set('halign','left')
        elif name in ('cinemaQuality','cinemaRating'):
            pos(node,0,0,1,1,1)
        elif name=='cinemaGenres':
            # Same pill as Cinematic poster view.
            pos(node,1505,470,376,35,30)
            node.set('font','Regular;16');node.set('foregroundColor','#FFFFFF')
            node.set('halign','center');node.set('valign','center')
            # Rounded pill is a PNG behind the text (VTi has no cornerRadius).
            node.set('transparent','1');node.set('noWrap','1')
            for _k in ('borderColor','borderWidth'):
                if _k in node.attrib:del node.attrib[_k]
        elif name=='cinemaYear':
            pos(node,0,0,1,1,1)
            node.set('font','Regular;18');node.set('foregroundColor','#FFFFFF')
            node.set('halign','center');node.set('valign','center')
            node.set('transparent','1')
            for _k in ('borderColor','borderWidth'):
                if _k in node.attrib:del node.attrib[_k]
        elif name=='cinemaDuration':
            pos(node,1505,420,119,35,30)
            node.set('font','Regular;17');node.set('foregroundColor','#FFFFFF')
            node.set('halign','center');node.set('valign','center')
            node.set('transparent','1')
            for _k in ('borderColor','borderWidth'):
                if _k in node.attrib:del node.attrib[_k]
        elif name=='playFocus':
            pos(node,1243,918,446,81,27)
            node.set('pixmap',_ASSET+'apple_play.png')
            node.set('alphatest','blend')
        elif name=='playText':
            pos(node,1355,935,265,49,30)
            node.set('font','Bold;32');node.set('foregroundColor','#FFF8F0')
            node.set('halign','center');node.set('valign','center')
        elif name=='footerServerName':
            pos(node,550,1053,161,21,54)
            node.set('font','Regular;15');node.set('foregroundColor','#FFCD74')
            node.set('halign','left');node.set('valign','center')
            node.set('transparent','1')
        elif name=='footerSortValue':
            # Same position/style as the other key captions (e.g. Previous Bouquet).
            pos(node,792,1053,150,21,54)
            node.set('font','Regular;15');node.set('foregroundColor','#A3ABB5')
            node.set('halign','left');node.set('valign','center')
            node.set('transparent','1')
        elif name=='page':
            pos(node,994,106,166,52,26)
            node.set('font','Bold;20');node.set('foregroundColor','#FFFFFF')
            node.set('halign','center');node.set('valign','center')
        elif name=='status':
            pos(node,760,106,166,52,26)
            node.set('font','Bold;20');node.set('foregroundColor','#FFFFFF')
            node.set('halign','center');node.set('valign','center')
        elif name=='cinemaCategory':
            pos(node,0,0,1,1,1)
    root.insert(0,ET.Element('ePixmap',{
        'position':'0,0','size':'%d,%d'%(sx(1920),sy(1080)),
        'pixmap':_ASSET+('apple_background_series.jpg' if series else 'apple_background.jpg'),'scale':'1','alphatest':'off','zPosition':'0'}))
    def pix(name,x,y,w,h,z,path=None):
        attrs={'position':'%d,%d'%(sx(x),sy(y)),
               'size':'%d,%d'%(sx(w),sy(h)),
               'alphatest':'blend','scale':'1','zPosition':str(z)}
        if name:
            attrs['name']=name
            if name=='appleRatingBadge':attrs['pixmap']=_PINK
            elif name=='appleDrawerSelection':attrs['pixmap']=_ASSET+'apple_pkg_drawer_selection.png'
            elif path:attrs['pixmap']=_ASSET+path
        else:attrs['pixmap']=_ASSET+path
        ET.SubElement(root,'widget' if name else 'ePixmap',attrs)
    def label(name,x,y,w,h,z,size=20,color='#FFFFFF',align='left',face='Regular'):
        ET.SubElement(root,'widget',{'name':name,
            'position':'%d,%d'%(sx(x),sy(y)),
            'size':'%d,%d'%(sx(w),sy(h)),
            'font':'%s;%d'%(face,size),'foregroundColor':color,
            'halign':align,'valign':'center','noWrap':'1',
            'transparent':'1','zPosition':str(z)})
    # The backdrop now sits above the dark panel base and below the silver edge.
    # Alternate backdrop appears OUTSIDE the silver frame; z2 stays behind cards.
    # Full-screen alternate backdrop (different from the framed one), with the
    # original header/footer redrawn above it so titles stay readable.
    pix('appleOuterBackdrop',0,0,1920,1080,1)
    pix(None,0,0,1920,1080,3,'apple_fullscreen_overlay_series.png' if series else 'apple_fullscreen_overlay.png')
    pix(None,1209,352,696,672,5,'apple_right_panel_frame.png')
    pix(None,1209,352,696,672,36,'apple_right_panel_outline.png')
    pix('applePreview',1235,397,245,325,25)
    pix(None,1229,391,257,336,27,'apple_preview_frame.png')
    # Pink rating badge (same artwork) under the year bar, round flag beside it.
    pix('appleRatingBadge',1505,585,84,82,33)
    label('appleBigRating',1520,632,56,28,34,24,'#FFFFFF','center')
    pix('appleCountryFlag',1605,594,64,64,33)
    pix(None,1505,520,376,50,24,'apple_meta_panel_blue.png')
    label('appleMetaLine',1510,528,366,34,27,21,'#FFFFFF','center','Bold')
    # Professional count/page pills next to the Apple title.
    pix(None,712,106,220,52,24,'apple_header_count_pill.png')
    pix(None,946,106,220,52,24,'apple_header_page_pill.png')
    pix(None,1715,924,73,73,29,'apple_bookmark.png')
    pix(None,1803,924,73,73,29,'apple_info.png')
    # Original animated packages drawer. Hidden at entry and layered over posters only on demand.
    pix('appleDrawer',0,126,350,824,61)
    # Same look as the main Packages menu: charcoal panel, white bold text,
    # glowing gold pill focus. Content stays the Apple server packages.
    pix('appleDrawerSelection',14,281,322,68,62)
    label('appleDrawerHeading',30,158,290,52,64,27,'#FFFFFF','center','Bold')
    label('appleDrawerCounter',44,212,262,36,64,19,'#E8B84A','center','Bold')
    for i in range(_DRAWER_COUNT):
        label('appleDrawerRow%d'%i,42,285+75*i,280,60,65,22,'#FFFFFF','left','Bold')
    # Identical PNG used by the other poster views (red, blue, green, yellow, MENU, long press).
    pix(None,20,1026,1880,52,50,'apple_exact_poster_toolbar.png')
    # Pill backgrounds (rounded PNG) behind the duration / genre labels.
    pix('appleDurationPill',1505,420,119,35,29,'apple_pill_duration.png')
    pix('appleGenrePill',1505,470,376,35,29,'apple_pill_genre.png')
    # VTi (Python 2.7) rejects cornerRadius: never emit it from this screen.
    # Every FHD artwork must scale to the GUI size (720p VTi desktops).
    for node in root.iter():
        if node.get('pixmap') and not node.get('scale'):node.set('scale','1')
        for key in _VTI_UNSUPPORTED:
            if key in node.attrib:del node.attrib[key]
    return ET.tostring(root,encoding='utf-8').decode('utf-8')

class AppleMoviesScreen(CinematicCatalogScreen):
    skin = _skin()
    # Own remembered server per page ("apple_vod" / "apple_series"); GREEN
    # saves to the same key, so the chosen server is used on reopen.
    _PAGE_SOURCE_PREFIX = 'apple_'
    _DRAWER_TITLE = 'APPLE'

    def __init__(self,session,source,initial_kind='vod',initial_category_id=''):
        kind='series' if initial_kind=='series' else 'vod'
        # r146: the base __init__ can already start the gallery worker;
        # its state must exist first (AttributeError in TiviAppleGallery).
        self._apple_outer_cache={}
        self._apple_outer_pending=set()
        self._apple_outer_attempted={}
        CinematicCatalogScreen.__init__(self,session,source,kind,initial_category_id)
        self['applePreview']=Pixmap()
        self['appleOuterBackdrop']=Pixmap()
        self._apple_outer_cache={}
        self._apple_outer_pending=set()
        self._apple_outer_attempted={}
        self._apple_gallery_timer=eTimer()
        self._apple_gallery_timer_connections=[]
        try:
            self._apple_gallery_timer_connections.append(
                self._apple_gallery_timer.timeout.connect(self._apple_start_gallery))
        except Exception:
            self._apple_gallery_timer.callback.append(self._apple_start_gallery)
        self._apple_backdrop_loaders={}
        self._apple_backdrop_expected={}
        self._apple_inner_source_url=""
        self._apple_outer_visible_token=None
        # token -> raw inner file / (raw outer file, TMDb identity) / excluded ids
        self._apple_inner_paths={}
        self._apple_outer_sources={}
        self._apple_outer_excluded={}
        self['appleOuterBackdrop'].hide()
        self['appleDrawer']=Pixmap()
        self['appleDrawerSelection']=Pixmap()
        self['appleDrawerHeading']=Label('PACKAGES')
        self['appleDrawerCounter']=Label('')
        self._apple_drawer_rows=[]
        for _i in range(_DRAWER_COUNT):
            _key='appleDrawerRow%d'%_i
            self[_key]=Label('')
            self._apple_drawer_rows.append(self[_key])
        self._apple_drawer_visible=False
        self._apple_drawer_animation=0
        self._apple_drawer_target=0
        self._apple_drawer_index=0
        self._apple_drawer_connections=[]
        self._apple_drawer_timer=eTimer()
        try:
            self._apple_drawer_connections.append(self._apple_drawer_timer.timeout.connect(self._apple_drawer_tick))
        except Exception:
            self._apple_drawer_timer.callback.append(self._apple_drawer_tick)
        self._apple_drawer_hide_labels()
        self['appleDrawer'].hide()
        self['appleDrawerSelection'].hide()
        # The XML skin names must be present in Screen before Enigma2
        # instantiates the widgets; previously these 61 components were
        # omitted when restoring the sliding drawer, crashing skin creation.
        self['appleMetaLine']=Label('')
        self['appleRatingBadge']=Pixmap()
        self['appleBigRating']=Label('')
        self['appleRatingBadge'].hide()
        self['appleCountryFlag']=Pixmap()
        self['appleCountryFlag'].hide()
        self['appleGenrePill']=Pixmap()
        self['appleDurationPill']=Pixmap()
        self['appleGenrePill'].hide()
        self['appleDurationPill'].hide()
        self._apple_flag_cache={}
        self._apple_gallery_wait={}
        self._apple_paths={}
        self._apple_preview_loader=None
        self._apple_preview_expected=None
        # Apple-only red key behaves as Back as labelled; all other keys
        # keep their existing GENRE/Cinematic server/category/sort behaviour.
        self['actions']=ActionMap(['OkCancelActions','DirectionActions','ColorActions',
          'MenuActions','InfoActions','NumberActions'],{
          'ok':self._apple_ok,'cancel':self._apple_cancel,
          'left':self.left,'right':self.right,'up':self.up,'down':self.down,
          'pageUp':self.page_up,'pageDown':self.page_down,
          'red':self.previous_genre,'green':self.open_poster_server,
          'yellow':self.sort_posters,'blue':self.next_genre,
          'info':self.open_selected,'menu':self.open_view_style_menu,
          'yellowlong':self.toggle_favorite, 'greenlong':self.filter_poster_server},-1)
        self.onClose.append(self._apple_release)
        self.onLayoutFinish.append(self._apple_layout_ready)

    def _apple_release(self):
        self._apple_outer_cache.clear()
        self._apple_outer_pending.clear()
        self._apple_outer_attempted.clear()
        self._apple_inner_paths.clear()
        self._apple_outer_sources.clear()
        self._apple_outer_excluded.clear()
        self._apple_flag_cache.clear()
        try:self._apple_gallery_timer.stop()
        except Exception:pass
        self._apple_backdrop_loaders.clear()
        self._apple_backdrop_expected.clear()
        self._apple_paths.clear()
        self._apple_preview_loader=None
        self._apple_preview_expected=None
        try:self._apple_drawer_timer.stop()
        except Exception:pass

    def _apple_layout_ready(self):
        self._refresh_play_focus()
        try:self['appleDrawer'].hide()
        except Exception:pass
        self._apple_drawer_hide_labels()

    def _cinema_trailer_selection(self):
        # Apple Movies preview is artwork only: no background player or timer.
        return

    def _request_cast(self,item,token):
        # No actor row on this layout; never start its secondary fetch.
        return

    def _load_hero(self):
        # Restore the established GENRE cache-first hero pipeline for selected
        # artwork; do not introduce any custom download queue.
        return CinematicCatalogScreen._load_hero(self)

    def _adjust_movie_logo_size(self):
        # The legacy GENRE callback must not move the Apple logo out of place.
        return

    def _compact_cinema_badges(self):
        # Keep original meaningful badges colored; never invent a video-quality score.
        # Year is already in the blue info bar: never show it twice.
        for name in ('cinemaQuality','cinemaRating','cinemaYear'):
            try:self[name].hide()
            except Exception:pass
        for name in ('cinemaGenres','cinemaDuration'):
            try:
                if self[name].getText():self[name].show()
                else:self[name].hide()
            except Exception:pass
        self._apple_sync_pills()

    def _apple_sync_pills(self):
        for label,pill in (('cinemaGenres','appleGenrePill'),('cinemaDuration','appleDurationPill')):
            try:
                if self[label].getText():self[pill].show()
                else:self[pill].hide()
            except Exception:pass

    def _set_hero_text(self, info):
        # Retain provider-first text with localized TMDb corrections, as in
        # Details/GENRE; no invented years, ratings, or categories.
        CinematicCatalogScreen._set_hero_text(self, info)
        sources=getattr(self,'_hero_text_sources',{}) or {}
        item=self._selected_item() or {}
        cat=self.categories[self.category_index] if self.categories else {}
        year=_apple_unicode(info.get('year') or item.get('year') or '')[:4]
        rating=_apple_unicode(info.get('rating') or item.get('rating') or '')
        self['heroMeta'].setText(year)
        self._apple_set_rating(rating)
        try:
            from .resolution_badge import _actual_media_genre
            genre=_actual_media_genre(sources.get('tmdb_verified') or {},
                sources.get('tmdb') or {}, sources.get('tmdb_search') or {},
                sources.get('provider') or {}, info, item)
        except Exception:
            genre=''
        if not genre:
            genre=_apple_unicode(item.get('genre') or item.get('genres') or '')
        self._apple_show_genres(genre)
        self['heroPlot'].setText(_apple_unicode(info.get('description'))[:750])
        self._apple_meta(info)

    def _apple_show_genres(self, genres):
        # Use the same native GENRE badge provided by CinematicCatalogScreen.
        if isinstance(genres,(list,tuple)):
            genres=', '.join(_apple_unicode(x.get('name') if isinstance(x,dict) else x) for x in genres)
        value=_apple_unicode(genres).strip()
        if len(value)>35:value=value[:34]+u'…'
        try:
            self['cinemaGenres'].setText(value)
            if value:self['cinemaGenres'].show()
            else:self['cinemaGenres'].hide()
            self._apple_sync_pills()
        except Exception:pass

    def _apple_drawer_hide_labels(self):
        for key in ('appleDrawerHeading','appleDrawerCounter','appleDrawerSelection'):
            try:self[key].hide()
            except Exception:pass
        for widget in getattr(self,'_apple_drawer_rows',[]):
            try:widget.hide()
            except Exception:pass

    def _apple_drawer_refresh(self):
        categories=self.categories or []
        total=len(categories)
        if not total: return
        self._apple_drawer_index=max(0,min(self._apple_drawer_index,total-1))
        start=max(0,min(self._apple_drawer_index-3,max(0,total-_DRAWER_COUNT)))
        for i,label in enumerate(self._apple_drawer_rows):
            idx=start+i
            if idx<total:
                name=_apple_unicode(categories[idx].get('name')).strip()
                if len(name)>20:name=name[:19]+u'…'
                label.setText(name)
                label.show()
            else:
                label.setText('');label.hide()
        self['appleDrawerHeading'].setText('PACKAGES')
        self['appleDrawerCounter'].setText('%d / %d'%(self._apple_drawer_index+1,total))
        self['appleDrawerHeading'].show()
        self['appleDrawerCounter'].show()
        try:
            self['appleDrawerSelection'].instance.move(ePoint(sx(14),sy(281+75*(self._apple_drawer_index-start))))
            self['appleDrawerSelection'].show()
        except Exception:pass

    def _apple_drawer_open(self):
        # One PACKAGES menu for every poster style (shared overlay).
        return self._open_package_drawer()

    def _apple_drawer_open_builtin(self):
        if not self.categories:return
        self._apple_drawer_index=max(0,min(self.category_index,len(self.categories)-1))
        self._apple_drawer_visible=True
        self._apple_drawer_target=_DRAWER_STEPS
        try:self['selector'].hide()
        except Exception:pass
        self._apple_drawer_tick()

    def _apple_drawer_close(self):
        if not self._apple_drawer_visible and self._apple_drawer_target==0:return
        self._apple_drawer_visible=False
        self._apple_drawer_target=0
        self._apple_drawer_hide_labels()
        self._apple_drawer_tick()
        if self.genre_items and not self._focus_on_play:
            try:self['selector'].show()
            except Exception:pass

    def _apple_drawer_tick(self):
        try:self._apple_drawer_timer.stop()
        except Exception:pass
        if self._apple_drawer_animation<self._apple_drawer_target:
            self._apple_drawer_animation+=1
        elif self._apple_drawer_animation>self._apple_drawer_target:
            self._apple_drawer_animation-=1
        n=self._apple_drawer_animation
        if n>0:
            try:
                self['appleDrawer'].instance.setPixmapFromFile(_ASSET+'apple_pkg_drawer_%d.png'%n)
                self['appleDrawer'].show()
            except Exception:pass
        else:
            self['appleDrawer'].hide()
        if n==_DRAWER_STEPS and self._apple_drawer_visible:
            self._apple_drawer_refresh()
        elif n!=_DRAWER_STEPS:
            self._apple_drawer_hide_labels()
        if n!=self._apple_drawer_target:
            try:self._apple_drawer_timer.start(45,True)
            except Exception:pass

    def _apple_ok(self):
        if not self._apple_drawer_visible:
            return self.activate_focused()
        if not self.categories:return
        target=self._apple_drawer_index
        self._apple_drawer_close()
        if target==self.category_index:return
        self.category_index=target
        self._generation+=1
        self._render_genre_bar()
        self._load_selected_genre(self._generation)

    def _apple_cancel(self):
        if self._apple_drawer_visible:
            self._apple_drawer_close()
            return
        return self.close()

    def _apple_meta(self,info):
        item=self._selected_item() or {}
        parts=[]
        year=_apple_unicode(info.get('year') or item.get('year') or '')[:4]
        if re.match(r'^(?:19|20)\d{2}$',year):parts.append(year)
        duration=info.get('runtime') or info.get('duration') or item.get('runtime') or item.get('duration') or ''
        try:
            if isinstance(duration,(int,float)) and 1<int(duration)<500:
                parts.append('%d min'%duration)
            elif re.match(r'^\d{1,3}$',_apple_unicode(duration).strip()):
                minutes=int(duration)
                if 1<minutes<500:parts.append('%d min'%minutes)
        except Exception:pass
        certificate=_apple_unicode(info.get('certification') or info.get('age_rating') or item.get('certification') or item.get('age_rating') or '').strip()
        if certificate and len(certificate)<12:parts.append(certificate)
        self['appleMetaLine'].setText('  |  '.join(parts))
        try:
            self['cinemaYear'].setText(year if re.match(r'^(?:19|20)\d{2}$',year) else '')
            self['cinemaYear'].hide()
            minutes=next((p for p in parts if p.endswith(' min')),'')
            self['cinemaDuration'].setText(minutes)
            if minutes:self['cinemaDuration'].show()
            else:self['cinemaDuration'].hide()
            self._apple_sync_pills()
        except Exception:pass

    def _apple_set_rating(self, value):
        """A single selected-title badge, never duplicated on the 20 small posters."""
        try:
            # extract_rating returns e.g. '★ 6.4', whereas provider info may
            # return '6.4' or '6.4/10'. Parse only the first score.
            match = re.search(r'(?<!\d)(\d{1,2}(?:[.,]\d+)?)', _apple_unicode(value or ''))
            score = float(match.group(1).replace(',', '.')) if match else 0.0
            valid = 0 < score <= 10
        except (ValueError, TypeError, OverflowError):
            valid = False
        if valid:
            self['appleBigRating'].setText('%.1f' % score)
            self['appleRatingBadge'].show()
            self['appleBigRating'].show()
        else:
            self['appleBigRating'].setText('')
            self['appleRatingBadge'].hide()
            self['appleBigRating'].hide()

    def _apple_trace(self, message):
        """Small local diagnostic log; never write private portal or API URLs."""
        # r146: off in normal use (create /tmp/tivimate_speed.on to enable).
        if not getattr(AppleMoviesScreen, '_trace_on', None) or time.time()-AppleMoviesScreen._trace_on[0]>10:
            AppleMoviesScreen._trace_on=(time.time(), False)
        if not AppleMoviesScreen._trace_on[1]:
            return
        try:
            target='/tmp/tivimate_apple_backdrops.log'
            if os.path.isfile(target) and os.path.getsize(target)>90000:
                os.rename(target,target+'.old')
            with open(target,'a') as log:
                log.write('%s %s\n' % (time.strftime('%H:%M:%S'),message[:250]))
        except Exception:pass

    def _apple_start_gallery(self):
        if not self._closed and self._hero_token:
            self._apple_request_outer(self._hero_token)

    def _update_hero_info(self, token, info, origin="tmdb"):
        # Preserve original provider-first, Arabic-aware metadata handling.
        CinematicCatalogScreen._update_hero_info(self, token, info, origin)
        if origin in ('tmdb_search','tmdb','tmdb_verified'):
            self._apple_request_outer(token)

    def _request_hero_artwork(self,token,url,category,widget,origin='provider'):
        # Every fetched hero uses the established downloader. An alternate
        # image is scheduled only after the base TMDb hero verified its ID.
        result=CinematicCatalogScreen._request_hero_artwork(
            self,token,url,category,widget,origin)
        if widget=='heroBackdrop' and token==self._hero_token:
            if url:self._apple_inner_source_url=_apple_unicode(url)
        return result

    def _apple_request_outer(self, token):
        """Resolve the same film's gallery independently of the hero cache.

        Reuses the established artwork downloader, does no image work in the GUI,
        and does not block/swap the existing primary backdrop or poster queues.
        """
        if self._closed or token != self._hero_token:
            return
        if token in self._apple_outer_cache or token in self._apple_outer_pending:
            return
        # Posters first: while the visible posters are still downloading, the
        # background waits (max ~6 s) so it never competes for poster lanes.
        try:busy=_ultra_pending()>0
        except Exception:busy=False
        if busy:
            started=self._apple_gallery_wait.get(token)
            if started is None:
                started=self._apple_gallery_wait[token]=time.time()
                if len(self._apple_gallery_wait)>40:
                    self._apple_gallery_wait.clear();self._apple_gallery_wait[token]=started
            if time.time()-started<1.5:
                try:self._apple_gallery_timer.start(300,True)
                except Exception:pass
                return
        # Successful results stay in the cache; failed lookups may retry later.
        last=self._apple_outer_attempted.get(token,0)
        if time.time()-last<45:
            return
        if not _APPLE_GALLERY_GATE.acquire(False):
            self._apple_trace('gallery busy; will retry')
            try:self._apple_gallery_timer.start(400,True)
            except Exception:pass
            return
        self._apple_outer_pending.add(token)
        item=dict(self._selected_item() or {})
        kind=self.kind
        source=dict(self.source or {})
        primary=_apple_unicode(self._apple_inner_source_url or '')
        lookup=dict(getattr(self,'_hero_lookup_cache',{}) or {})
        self._apple_trace('gallery requested for selection %s'%str(token))

        def same_identity(value):
            value=_apple_unicode(value).strip().replace(chr(92)+'/','/')
            match=re.search(r'image\.tmdb\.org/t/p/(?:w\d+|original)(/[^?#]+)',value,re.I)
            if match:return match.group(1).lower()
            return value.split('?',1)[0].lower()

        def current():
            return not self._closed and token==self._hero_token

        def complete(ok):
            try:self._apple_outer_pending.discard(token)
            except AttributeError:return
            if not ok:
                self._apple_outer_attempted[token]=time.time()
            else:
                self._apple_outer_attempted.pop(token,None)

        def worker():
            started_async=[False]
            # The busy slot covers TMDb lookup only, not the asynchronous image
            # download (which is already bounded by the existing downloader).
            try:
                if not current():return
                client=TMDbClient()
                title=_apple_unicode(item.get('name') or item.get('title')).strip()
                year=_apple_unicode(item.get('year') or '')[:4]
                catalog_id=item.get('tmdb_id') or item.get('tmdb') or item.get('tmdbId')
                lookup_key=(title,kind,year,_apple_unicode(catalog_id or ''))
                found=lookup.get(lookup_key) or {}
                if not found:
                    # Enigma 2.7 may use byte titles in cached tuples; compare
                    # normalised keys, rather than rejecting an Arabic match.
                    for key,row in lookup.items():
                        try:
                            if len(key)==4 and _apple_unicode(key[0])==title and \
                                    key[1]==kind and _apple_unicode(key[2])==year:
                                found=row or {};break
                        except Exception:pass
                verified_id=found.get('id') if isinstance(found,dict) else None
                if not verified_id and catalog_id:
                    # More Info first tries the numeric catalogue id. Accept
                    # it only when the record identity/year is consistent.
                    try:
                        direct=client.details_bundle(catalog_id,kind) or {}
                        release=_apple_unicode(direct.get('release_date') or direct.get('first_air_date') or '')[:4]
                        direct_title=_apple_unicode(direct.get('title') or direct.get('name') or '')
                        similar=(re.sub(r'\W+','',direct_title,flags=re.U).lower()==
                                 re.sub(r'\W+','',title,flags=re.U).lower())
                        if (str(direct.get('id') or '')==str(catalog_id) and
                                (year and year==release or not year and similar)):
                            found=direct;verified_id=direct['id']
                    except Exception:pass
                if not verified_id:
                    # Hero TMDb metadata may never reach its lookup cache on
                    # first render. Resolve identity as More Info already does.
                    found=client.search_artwork(title,kind,year or None) or {}
                    verified_id=found.get('id')
                    if not verified_id:
                        self._apple_trace('no verified TMDb identity for selection')
                        return
                if not current():return
                details=client.details_bundle(verified_id,kind) or {}
                if str(details.get('id') or '')!=str(verified_id):
                    self._apple_trace('gallery details identity mismatch')
                    return
                # Round country flag in parallel: the background never waits
                # for the flag download.
                def flag_job(details=details,found=found,verified_id=verified_id):
                    try:
                        from .country_flags import country_code,_fetch_flag,_country_from_tmdb
                        code=country_code(details,kind) or country_code(found,kind) or \
                            _country_from_tmdb(kind,verified_id)
                        flag=_apple_round_flag(_fetch_flag(code)) if code else ''
                        if flag:
                            self._apple_flag_cache[token]=flag
                            if len(self._apple_flag_cache)>80:
                                self._apple_flag_cache.pop(next(iter(self._apple_flag_cache)),None)
                            self._post_to_gui(self._apple_show_flag,token,flag)
                    except Exception as exc:
                        self._apple_trace('flag error: %s'%type(exc).__name__)
                try:
                    flag_thread=threading.Thread(target=flag_job,name='TiviMateAppleFlag')
                    flag_thread.daemon=True;flag_thread.start()
                except Exception:
                    flag_job()
                if not current():return
                def gallery_rows(bundle):
                    images=bundle.get('images') or {}
                    rows=(images.get('backdrops') or []) if isinstance(images,dict) else []
                    candidates=[]; seen=set()
                    def add(path):
                        path=_apple_unicode(path).strip().replace(chr(92)+'/','/')
                        if not (path.startswith('/') and not path.startswith('//')):return
                        if '/t/p/' in path:return
                        identity=same_identity(path)
                        if identity and identity not in seen:
                            seen.add(identity);candidates.append(path)
                    add(bundle.get('backdrop_path'))
                    valid=[x for x in rows if isinstance(x,dict) and x.get('file_path')]
                    def rank(x):
                        try:return (float(x.get('vote_average') or 0),
                                    int(x.get('vote_count') or 0),int(x.get('width') or 0))
                        except Exception:return (0,0,0)
                    for row in sorted(valid,key=rank,reverse=True):add(row.get('file_path'))
                    for row in rows:
                        if isinstance(row,str):add(row)
                    return candidates
                gallery=gallery_rows(details)
                if len(gallery)<4:
                    # The appended images follow the UI language (Arabic), so
                    # TMDb returns only Arabic-tagged backdrops: usually none or
                    # one. Ask exactly like More Info does: requested/original
                    # languages plus neutral (null) and English scenes.
                    endpoint='/tv/%s/images'%verified_id if kind=='series' else '/movie/%s/images'%verified_id
                    try:
                        from .logo_manager import image_languages
                        langs=image_languages(client,details,item) or 'null'
                    except Exception:
                        langs='null'
                    wanted=[x for x in _apple_unicode(langs).split(',') if x]
                    for extra in ('null','en','ar'):
                        if extra not in wanted:wanted.append(extra)
                    gkey=(kind,str(verified_id))
                    with _APPLE_GALLERY_LOCK:
                        hit=_APPLE_GALLERY_CACHE.get(gkey)
                    if hit and time.time()-hit[0]<_APPLE_GALLERY_TTL:
                        gallery_result=hit[1]
                    else:
                        try:gallery_result=client._get(endpoint,{'include_image_language':','.join(wanted)}) or {}
                        except Exception:gallery_result={}
                        if not gallery_result.get('backdrops'):
                            try:gallery_result=client._get(endpoint,{'language':'en-US','include_image_language':'null,en'}) or {}
                            except Exception:gallery_result={}
                        if gallery_result.get('backdrops'):
                            with _APPLE_GALLERY_LOCK:
                                if len(_APPLE_GALLERY_CACHE)>300:_APPLE_GALLERY_CACHE.clear()
                                _APPLE_GALLERY_CACHE[gkey]=(time.time(),{'backdrops':list(gallery_result.get('backdrops') or [])})
                    if gallery_result.get('backdrops'):
                        enriched=dict(details)
                        images=dict(enriched.get('images') or {})
                        images['backdrops']=list(images.get('backdrops') or [])+list(gallery_result.get('backdrops') or [])
                        enriched['images']=images
                        gallery=gallery_rows(enriched)
                self._apple_trace('TMDb gallery: %d unique backdrops'%len(gallery))
                if not gallery:return
                # Provider can have a different primary image; do not hide its
                # existing image. Alternate picks a different real TMDb frame.
                inside_identity=same_identity(primary)
                tmdb_primary=same_identity(details.get('backdrop_path') or found.get('backdrop_path') or '')
                # When provider hero fails, the first verified TMDb gallery
                # frame is an independent, reliable inner fallback.
                def inner_fallback(path):
                    if not current() or self._apple_backdrop_expected.get('heroBackdrop',None):return
                    self._apple_trace('inner fallback ready')
                    self._post_to_gui(self._show_hero_image,token,'heroBackdrop',path)
                # If the gallery is the only source, fetch the first image for
                # the inner layer and pick a separate image for the outer.
                chosen_inner=gallery[0]
                excluded=set(self._apple_outer_excluded.get(token) or ())
                options=[p for p in gallery if same_identity(p) not in (
                    same_identity(chosen_inner),inside_identity,tmdb_primary)
                    and same_identity(p) not in excluded]
                if not options:
                    options=[p for p in gallery if same_identity(p)!=same_identity(chosen_inner)
                             and same_identity(p) not in excluded]
                if not options and inside_identity and inside_identity!=same_identity(chosen_inner):
                    # Inner frame is the provider's own image: the TMDb one may
                    # still be a different scene (verified visually in prepare).
                    options=[p for p in gallery if same_identity(p) not in excluded]
                if not options:
                    self._apple_trace('gallery has only one usable backdrop')
                    # Still show the primary frame if the hero path is missing.
                    if not self._apple_backdrop_expected.get('heroBackdrop'):
                        url=_apple_backdrop_url(chosen_inner,'inner')
                        if url:
                            genre_ultra_request(url,'backdrops',source,inner_fallback,
                                lambda unused:None,self._post_to_gui)
                    return
                # Spread chosen image across the gallery for visibly different
                # scenes, matching More Info's diversity policy.
                chosen_outer=options[-1] if len(options)>3 else options[0]
                # Primary hero is requested independently by the original code.
                # Only add this fallback when its image has not decoded yet.
                if not self._apple_backdrop_expected.get('heroBackdrop'):
                    url=_apple_backdrop_url(chosen_inner,'inner')
                    if url:
                        genre_ultra_request(url,'backdrops',source,inner_fallback,
                            lambda unused:self._apple_trace('inner fallback download failed'),
                            self._post_to_gui)
                candidates=[chosen_outer]+[p for p in options if p!=chosen_outer]
                def attempt(index):
                    if not current():complete(False);return
                    if index>=min(4,len(candidates)):
                        self._apple_trace('outer download failed, candidates exhausted')
                        complete(False);return
                    url=_apple_backdrop_url(candidates[index],'outer')
                    if not url:
                        attempt(index+1);return
                    def ready(path):
                        if not current():complete(False);return
                        if not path or not os.path.isfile(path):
                            attempt(index+1);return
                        identity=same_identity(candidates[index])
                        def prepare():
                            # Reject a gallery frame that is visually the same
                            # picture already painted inside the silver frame.
                            inner=self._apple_inner_paths.get(token)
                            if inner and _apple_same_picture(inner,path):
                                self._apple_trace('outer equals inner picture; trying next')
                                self._apple_outer_excluded.setdefault(token,set()).add(identity)
                                self._post_to_gui(attempt,index+1)
                                return
                            try:out=self._apple_outer_cover(path)
                            except Exception:out=path
                            self._apple_outer_sources[token]=(path,identity)
                            self._post_to_gui(self._apple_show_outer,token,out)
                            self._post_to_gui(complete,True)
                        try:_CINE_BACKDROP_COVER_POOL.submit(prepare)
                        except Exception:prepare()
                    def failed(unused):
                        self._apple_trace('outer download error, trying alternative')
                        attempt(index+1)
                    cached=cached_artwork(url,'backdrops')
                    if cached: self._post_to_gui(ready,cached)
                    else: genre_ultra_request(url,'backdrops',source,ready,failed,self._post_to_gui)
                started_async[0]=True
                attempt(0)
            except Exception as exc:
                self._apple_trace('gallery resolver error: %s'%type(exc).__name__)
            finally:
                try:_APPLE_GALLERY_GATE.release()
                except Exception:pass
                # Do not lock out a later retry merely because async download
                # was enqueued. Finish is reported by its real ready/error hook.
                if not started_async[0] or not current():complete(False)
        t=threading.Thread(target=worker,name='TiviAppleGallery')
        t.daemon=True
        t.start()

    def _apple_outer_cover(self,path):
        """Cache subdued outside backdrop for the current frame and receiver."""
        from PIL import Image,ImageOps,ImageEnhance
        folder=os.path.join(os.path.dirname(path),'apple_outer_cover')
        if not os.path.isdir(folder):
            try:os.makedirs(folder)
            except OSError:
                if not os.path.isdir(folder):raise
        stat=os.stat(path)
        # Native desktop size (1280x720 on 720p boxes): less work, same look.
        size=(max(1,sx(1920)),max(1,sy(1080)))
        stamp='outer%dx%d-v5|%s|%s|%s'%(size[0],size[1],os.path.realpath(path),stat.st_size,stat.st_mtime)
        key=hashlib.sha1(_apple_bytes(stamp)).hexdigest()
        target=os.path.join(folder,key+'.jpg')
        if os.path.isfile(target) and os.path.getsize(target)>100:return target
        tmp=target+'.'+str(threading.current_thread().ident)+'.tmp'
        try:
            with Image.open(path) as image:
                # Dimmed background: fast JPEG draft decode + bilinear resize
                # (LANCZOS at 1920x1080 cost ~1 s on slow receivers).
                try:image.draft('RGB',size)
                except Exception:pass
                bilinear=Image.Resampling.BILINEAR if hasattr(Image,'Resampling') else Image.BILINEAR
                frame=ImageOps.fit(image.convert('RGB'),size,method=bilinear)
                frame=ImageEnhance.Brightness(frame).enhance(0.38)
                frame.save(tmp,format='JPEG',quality=80)
            try:os.rename(tmp,target)
            except OSError:
                if not os.path.isfile(target):raise
        finally:
            try:
                if os.path.isfile(tmp):os.unlink(tmp)
            except OSError:pass
        return target

    def _apple_decode_backdrop(self,name,token,path,w,h):
        """Render JPEG through ePicLoad, as the working Apple poster preview does."""
        if self._closed or token != self._hero_token or not path or not os.path.isfile(path):return
        loader=ePicLoad()
        self._apple_backdrop_loaders[name]=loader
        expected=(token,path)
        self._apple_backdrop_expected[name]=expected
        def ready(_=None,current=loader,needed=expected,slot=name):
            if (self._closed or self._apple_backdrop_loaders.get(slot) is not current or
                    self._apple_backdrop_expected.get(slot)!=needed or needed[0]!=self._hero_token):return
            try:
                picture=current.getData()
                if picture and self[slot].instance:
                    self[slot].instance.setPixmap(picture)
                    self[slot].show()
                    self._apple_trace('decode painted '+slot)
            except Exception as error:
                self._apple_trace('decode paint failed %s: %s'%(slot,type(error).__name__))
        try:
            connect_picture_data(loader,ready,self,oneshot=True)
            loader.setPara((sx(w),sy(h),0,0,False,1,'#080A10'))
            self._apple_trace('decode requested '+name)
            loader.startDecode(path)
        except Exception as error:
            self._apple_trace('decode start failed %s: %s'%(name,type(error).__name__))
            try:self[name].instance.setPixmapFromFile(path);self[name].show()
            except Exception:pass

    def _apple_show_flag(self,token,path):
        if self._closed or token!=self._hero_token or not path or not os.path.isfile(path):return
        try:
            self['appleCountryFlag'].instance.setPixmapFromFile(path)
            self['appleCountryFlag'].show()
        except Exception:pass

    def _apple_show_outer(self,token,path):
        if self._closed or token != self._hero_token or not path or not os.path.isfile(path):return
        self._apple_trace('outer backdrop ready')
        self._apple_outer_cache[token]=path
        if len(self._apple_outer_cache)>50:
            try:self._apple_outer_cache.pop(next(iter(self._apple_outer_cache)))
            except Exception:pass
        self._apple_decode_backdrop('appleOuterBackdrop',token,path,1920,1080)

    def _schedule_hero(self):
        """Keep the original INSIDE backdrop; the OUTSIDE uses an alternate frame."""
        key=(self._generation,self.index,self.kind)
        if key != self._apple_outer_visible_token:
            self._apple_outer_visible_token=key
            try:getattr(self,'_apple_inner_locked',{}).pop(key,None)
            except Exception:pass
            self._apple_backdrop_expected.clear()
            self._apple_backdrop_loaders.clear()
            try:
                self._apple_gallery_timer.stop()
                self._apple_gallery_timer.start(350,True)
            except Exception:pass
            self._apple_inner_source_url='' 
            try:
                self['appleCountryFlag'].hide()
                flag=self._apple_flag_cache.get(key)
                if flag and os.path.isfile(flag):
                    self['appleCountryFlag'].instance.setPixmapFromFile(flag)
                    self['appleCountryFlag'].show()
            except Exception:pass
            cached_outer=self._apple_outer_cache.get(key)
            try:
                if cached_outer and os.path.isfile(cached_outer):
                    self._apple_decode_backdrop('appleOuterBackdrop',key,cached_outer,1920,1080)
                else:self['appleOuterBackdrop'].hide()
            except Exception:pass
        cached=((self._hero_cache.get(key) or {}).get('images') or {}).get('heroBackdrop')
        StandaloneGenreScreen._schedule_hero(self)
        if cached and os.path.isfile(cached):
            self['heroBackdrop'].hide()  # No raw 16:9 image stretching/flicker.
            self._show_hero_image(key,'heroBackdrop',cached)

    def _apple_cover_backdrop(self, path):
        """Fit the cached backdrop offline; output stays alongside image cache."""
        from PIL import Image, ImageOps
        folder=os.path.join(os.path.dirname(path),'apple_panel_cover')
        if not os.path.isdir(folder):
            try: os.makedirs(folder)
            except OSError:
                if not os.path.isdir(folder): raise
        stat=os.stat(path)
        stamp='apple670x646-v3|%s|%s|%s'%(os.path.realpath(path),stat.st_size,stat.st_mtime)
        key=hashlib.sha1(_apple_bytes(stamp)).hexdigest()
        target=os.path.join(folder,key+'.jpg')
        if os.path.isfile(target) and os.path.getsize(target)>100: return target
        tmp=target+'.'+str(threading.current_thread().ident)+'.tmp'
        try:
            with Image.open(path) as original:
                resampling=Image.Resampling.LANCZOS if hasattr(Image,'Resampling') else Image.LANCZOS
                frame=ImageOps.fit(original.convert('RGB'),(670,646),method=resampling,centering=(0.5,0.5))
                frame.save(tmp,format='JPEG',quality=84)
            try: os.rename(tmp,target)
            except OSError:
                if not os.path.isfile(target): raise
        finally:
            try:
                if os.path.isfile(tmp): os.unlink(tmp)
            except OSError: pass
        return target

    def _show_hero_image(self, token, name, path):
        if name!='heroBackdrop':
            return StandaloneGenreScreen._show_hero_image(self,token,name,path)
        if self._closed or token!=self._hero_token or not path or not os.path.isfile(path):return
        # r146: one backdrop inside the frame per selection. The provider
        # image, the TMDb image and the gallery fallback used to arrive one
        # after another and each repainted the frame; the first one stays.
        locked=getattr(self,'_apple_inner_locked',None)
        if locked is None:
            locked=self._apple_inner_locked={}
        first=locked.get(token)
        if first and first!=path and os.path.isfile(first):
            return
        locked[token]=path
        if len(locked)>60:
            try:locked.pop(next(iter(locked)))
            except Exception:pass
        self._apple_inner_paths[token]=path
        if len(self._apple_inner_paths)>60:
            try:self._apple_inner_paths.pop(next(iter(self._apple_inner_paths)))
            except Exception:pass
        def work():
            try:
                target=self._apple_cover_backdrop(path)
            except Exception:
                target=path
            self._post_to_gui(self._apple_draw_backdrop,token,target)
            # Inner may arrive after the outer was chosen (or a cached outer
            # was painted): if both show the same picture, pick another one.
            outer=self._apple_outer_sources.get(token)
            if outer and _apple_same_picture(path,outer[0]):
                self._post_to_gui(self._apple_outer_conflict,token,outer[1])
        try:
            _CINE_BACKDROP_COVER_POOL.submit(work)
        except RuntimeError:
            pass

    def _apple_outer_conflict(self,token,identity):
        """Outer background duplicates the inner frame: request a different one."""
        if self._closed or token!=self._hero_token:return
        self._apple_trace('outer duplicates inner; re-resolving')
        self._apple_outer_excluded.setdefault(token,set()).add(identity)
        self._apple_outer_sources.pop(token,None)
        self._apple_outer_cache.pop(token,None)
        self._apple_outer_attempted.pop(token,None)
        try:self['appleOuterBackdrop'].hide()
        except Exception:pass
        self._apple_request_outer(token)

    def _apple_draw_backdrop(self,token,path):
        if self._closed or token!=self._hero_token or not os.path.isfile(path):return
        self._apple_decode_backdrop('heroBackdrop',token,path,670,646)

    def _refresh_play_focus(self):
        try:
            image='apple_play_selected.png' if self._focus_on_play else 'apple_play.png'
            self['playFocus'].instance.setPixmapFromFile(_ASSET+image)
            self['playFocus'].show()
        except Exception:
            pass

    def _display_selected_preview(self, path, item_index):
        if (self._closed or item_index != self.index or
                not path or not os.path.isfile(path)):
            return
        self._apple_preview_expected=(item_index,path)
        loader=ePicLoad()
        self._apple_preview_loader=loader
        def ready(_=None,current=loader,expected=(item_index,path)):
            if self._closed or self._apple_preview_loader is not current or self._apple_preview_expected != expected:
                return
            try:
                picture=current.getData()
                if picture and self['applePreview'].instance:
                    self['applePreview'].instance.setPixmap(picture)
                    self['applePreview'].show()
            except Exception:
                pass
        try:
            connect_picture_data(loader, ready, self, oneshot=True)
            loader.setPara((sx(245),sy(325),0,0,False,1,'#0D0C0B'))
            loader.startDecode(path)
        except Exception:
            self._apple_preview_loader=None

    def _decode_poster(self, slot, path, token, item, origin, resolved_url=''):
        # Observe a path resolved by the original GENRE pipeline, after its
        # cache-first/provider/TMDb logic, without changing request concurrency.
        if (not self._closed and self._poster_tokens.get(slot)==token and
                path and os.path.isfile(path)):
            idx=self.page_start+slot
            priority=2 if origin in ('provider','provider_detail') else 1
            known=self._apple_paths.get(idx)
            if known is None or priority >= known[0]:
                self._apple_paths[idx]=(priority,path)
                if idx==self.index:
                    self._display_selected_preview(path,idx)
        return CinematicCatalogScreen._decode_poster(self,slot,path,token,item,origin,resolved_url)

    def _render_empty(self,message):
        CinematicCatalogScreen._render_empty(self,message)
        try: self['applePreview'].hide()
        except Exception: pass
        self._apple_show_genres('')
        self._apple_set_rating(None)

    def render(self):
        cat=self.categories[self.category_index] if self.categories else {}
        total=len(self.genre_items)
        self.page_start=(self.index//_PER_PAGE)*_PER_PAGE if total else 0
        pages=max(1,(total+_PER_PAGE-1)//_PER_PAGE)
        self['page'].setText('PAGE  %d / %d'%(self.page_start//_PER_PAGE+1,pages))
        self['heading'].setText('')
        self['subheading'].setText('')
        self['status'].setText('%d %s'%(total,'SERIES' if self.kind=='series' else 'MOVIES'))
        self['cinemaCategory'].setText('')
        self['playText'].setText('Select Episode' if self.kind=='series' else 'Play Movie')
        item=self._selected_item() or {}
        title=_apple_unicode(item.get('name') or item.get('title') or '')
        year=_apple_unicode(item.get('year') or item.get('release_date') or '')[:4]
        category=_apple_unicode(cat.get('name') or '')
        plot=_apple_unicode(item.get('plot') or item.get('description') or item.get('overview') or '').strip()
        rating=extract_rating(item)
        self['heroTitle'].setText(title[:80])
        self['heroMeta'].setText(year)
        self._apple_set_rating(rating)
        self['heroPlot'].setText(_apple_unicode(plot)[:750])
        self._apple_meta(item)
        self._apple_show_genres(item.get('genre') or item.get('genres') or '')
        page_key=(self._generation,self.page_start,total)
        if page_key != self._rendered_page_key:
            self._cancel_poster_jobs()
            self._rendered_page_key=page_key
            self._poster_resolved_priority.clear()
            self._poster_tmdb_started.clear()
            self._apple_paths.clear()
            for slot in range(24):
                idx=self.page_start+slot
                row=self.genre_items[idx] if slot<_PER_PAGE and idx<total else None
                if not row:
                    self._poster_tokens.pop(slot,None)
                    self['poster%d'%slot].hide()
                    self['shell%d'%slot].hide()
                    self['meta%d'%slot].setText('')
                    continue
                self['poster%d'%slot].show()
                self['shell%d'%slot].show()
                self['meta%d'%slot].setText(_apple_unicode(row.get('year') or '')[:4])
                self._set_placeholder(slot)
                self._load_poster(slot,row,idx)
        self._schedule_hero()
        self._update_hero_info(self._hero_token,{
            'title':title, 'year':year,
            'rating':_apple_unicode(rating or ''),
            'description':plot,
            'category':category}, 'catalog')
        saved=self._apple_paths.get(self.index)
        if saved:
            if self._apple_preview_expected is None or self._apple_preview_expected[0]!=self.index:
                self['applePreview'].hide()
                self._display_selected_preview(saved[1],self.index)
        else:
            self._apple_preview_expected=None
            self['applePreview'].hide()
        if total:
            slot=self.index-self.page_start
            self['selector'].instance.move(ePoint(sx(_X[slot%_COLS]-8),sy(_Y[slot//_COLS]-8)))
            if self._focus_on_play: self['selector'].hide()
            else: self['selector'].show()
        else:
            self['selector'].hide()
        self._refresh_play_focus()
        if self._apple_drawer_visible:
            try:self['selector'].hide()
            except Exception:pass

    def left(self):
        if self._apple_drawer_visible:
            return
        if not self._focus_on_play and self.genre_items and self.index%_COLS==0:
            self._apple_drawer_open()
            return
        if self._focus_on_play:
            self._focus_on_play=False
            self.index=min(self._last_grid_index,max(0,len(self.genre_items)-1))
            self.render()
        elif self.genre_items and self.index%_COLS:
            self.index-=1
            self.render()

    def right(self):
        if self._apple_drawer_visible:
            self._apple_drawer_close()
            return
        if self._focus_on_play:return
        if not self.genre_items:return
        if self.index%_COLS==_COLS-1 or self.index+1>=len(self.genre_items):
            self._last_grid_index=self.index
            self._focus_on_play=True
        else:
            self.index+=1
        self.render()

    def up(self):
        if self._apple_drawer_visible:
            self._apple_drawer_index=max(0,self._apple_drawer_index-1)
            self._apple_drawer_refresh()
            return
        if self._focus_on_play:return
        if self.index>=_COLS:
            self.index-=_COLS
            self.render()

    def down(self):
        if self._apple_drawer_visible:
            self._apple_drawer_index=min(len(self.categories)-1,self._apple_drawer_index+1)
            self._apple_drawer_refresh()
            return
        if self._focus_on_play:return
        if self.index+_COLS<len(self.genre_items):
            self.index+=_COLS
            self.render()

    def page_up(self):
        if self._apple_drawer_visible:
            self._apple_drawer_index=max(0,self._apple_drawer_index-_DRAWER_COUNT)
            self._apple_drawer_refresh()
            return
        if not self.genre_items:return
        self._focus_on_play=False
        self.index=max(0,self.index-_PER_PAGE)
        self.render()

    def page_down(self):
        if self._apple_drawer_visible:
            self._apple_drawer_index=min(len(self.categories)-1,self._apple_drawer_index+_DRAWER_COUNT)
            self._apple_drawer_refresh()
            return
        if not self.genre_items:return
        self._focus_on_play=False
        self.index=min(len(self.genre_items)-1,self.index+_PER_PAGE)
        self.render()

    def open_view_style_menu(self):
        from .movies_page_picker import MoviesPagePicker
        self.session.openWithCallback(self._apple_design_chosen,MoviesPagePicker,self.kind)

    def _apple_design_chosen(self,choice=None):
        if choice not in ('current','new','grid24','apple') or choice=='apple':return
        from .movies_layout_choice import save_content_layout,configured_movies_screen
        if not save_content_layout(self.kind,choice):return
        from .content_home import FastMoviesContentScreen
        screen=configured_movies_screen(FastMoviesContentScreen,self.kind)
        self.session.openWithCallback(self._movie_page_design_return,screen,dict(self.source),self.kind)


class AppleSeriesScreen(AppleMoviesScreen):
    """Same Apple design for TV series (own header, episode selection)."""
    skin = _skin(True)

    def __init__(self,session,source,initial_kind='series',initial_category_id=''):
        AppleMoviesScreen.__init__(self,session,source,'series',initial_category_id)
