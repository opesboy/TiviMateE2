# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace, int_from_bytes, thread_ident
"""On-demand country flags for Movie and Series details.

TMDb supplies the production/origin country. The flag is downloaded only for
that country, in a separate, bounded worker pool (not the busy poster queue).
Small PNGs are cached on the configured HDD/USB/internal artwork root.
All Enigma widgets are updated from the GUI thread and late results cannot
replace the flag of a different screen/selection.
"""
import os
import re
import ssl
import threading
import time
from collections import deque
from Plugins.Extensions.TiviMateE2Py27.py27_futures import Future
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import URLError

_CODE = re.compile(r"^[A-Z]{2}$")
_COUNTRY_CACHE = {}
_COUNTRY_LOCK = threading.RLock()
class _FlagPool(object):
    """Two workers, at most 32 queued flags, newest selections take priority.

    Drop superseded pending work instead of retaining screen callbacks forever.
    Idle workers exit; do not change the shared executor used by other features.
    """
    def __init__(self):
        self.condition = threading.Condition()
        self.pending = deque()
        self.workers = 0

    def submit(self, key, fn, *args):
        future = Future()
        dropped = []
        with self.condition:
            if key is not None:
                for job in list(self.pending):
                    if job[0] == key:
                        self.pending.remove(job)
                        dropped.append(job[1])
            if len(self.pending) >= 32:
                dropped.append(self.pending.popleft()[1])
            self.pending.append((key, future, fn, args))
            if self.workers < 2:
                self.workers += 1
                try:
                    thread = threading.Thread(target=self._run, name='TiviMateFlag')
                    thread.daemon = True
                    thread.start()
                except Exception:
                    self.workers -= 1
                    if not self.workers:
                        while self.pending:
                            dropped.append(self.pending.popleft()[1])
            self.condition.notify()
        for old in dropped:
            old.cancel()
        return future

    def _run(self):
        while True:
            with self.condition:
                while not self.pending:
                    self.condition.wait(45)
                    if not self.pending:
                        self.workers -= 1
                        return
                key, future, fn, args = self.pending.popleft()
            try:
                if future.set_running_or_notify_cancel():
                    try:
                        future.set_result(fn(*args))
                    except BaseException as exc:
                        future.set_exception(exc)
            finally:
                key = future = fn = args = exc = None
                import sys
                if hasattr(sys, 'exc_clear'):
                    sys.exc_clear()


_POOL = _FlagPool()


def submit_flag_job(key, fn, *args):
    return _POOL.submit(key, fn, *args)
_FAIL_TTL = 120
_COUNTRY_TTL = 43200
_NETWORK_STATUS = threading.local()


def country_code(bundle, kind):
    if not isinstance(bundle, dict):
        return ""
    is_tv = str(kind or "").lower() in ("series", "tv", "shows")
    fields = ("origin_country", "production_countries") if is_tv else ("production_countries", "origin_country")
    for field in fields:
        rows = bundle.get(field) or []
        if isinstance(rows, dict):
            rows = [rows]
        if not isinstance(rows, (tuple, list)):
            continue
        for row in rows:
            raw = (row.get("iso_3166_1") or row.get("country_code")) if isinstance(row, dict) else row
            code = str(raw or "").strip().upper()
            if py27_fullmatch(_CODE, code):
                return code
    return ""


def _flags_dir():
    from .cache_manager import get_cache_dir
    return get_cache_dir("flags")


def _flag_path(code):
    return os.path.join(_flags_dir(), "country_%s.png" % code.lower())


def _valid_png(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) < 80:
            return False
        with open(path, "rb") as f:
            header = f.read(24)
        return (len(header) == 24 and header[:8] == b"\x89PNG\r\n\x1a\n"
                and header[12:16] == b"IHDR"
                and int_from_bytes(header[16:20], "big") > 0
                and int_from_bytes(header[20:24], "big") > 0)
    except Exception:
        return False


def country_flag_path(bundle, kind):
    code = country_code(bundle, kind)
    if not code:
        return ""
    path = _flag_path(code)
    return path if _valid_png(path) else ""


def _download(url):
    _NETWORK_STATUS.last = "unknown"
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0",
        "Accept": "image/png,image/jpeg;q=0.8",
    })
    # Older Enigma2 receivers may have an outdated CA bundle. First attempt
    # verified TLS and use the same last-resort image-only SSL compatibility as
    # the existing artwork helper, restricted to known fixed flag hosts.
    try:
        try:
            response = urlopen(request, timeout=7)
        except (getattr(ssl, 'SSLCertVerificationError', URLError), URLError):
            # Never bypass TLS verification for downloaded artwork.
            # The regular local flag/fallback handling remains available.
            raise
        with response:
            data = response.read(192 * 1024 + 1)
        if len(data) > 192 * 1024 or len(data) < 80:
            _NETWORK_STATUS.last = "invalid image size"
            return b""
        if (data[:8] != b"\x89PNG\r\n\x1a\n" or
                data[12:16] != b"IHDR"):
            _NETWORK_STATUS.last = "response is not PNG"
            return b""
        _NETWORK_STATUS.last = "ok"
        return data
    except Exception as exc:
        _NETWORK_STATUS.last = type(exc).__name__
        return b""


def _fetch_flag(code):
    """Dedicated fetch; never block on poster/backdrop downloads."""
    path = _flag_path(code)
    if _valid_png(path):
        return path
    sources = (
        "https://flagcdn.com/w80/%s.png" % code.lower(),
        "https://flagsapi.com/%s/flat/64.png" % code,
    )
    failures = []
    for url in sources:
        data = _download(url)
        if not data:
            failures.append(url.split("/")[2] + ": " + str(getattr(_NETWORK_STATUS, "last", "unknown")))
            continue
        temp = "%s.part.%s.%s" % (path, os.getpid(), thread_ident())
        try:
            with open(temp, "wb") as fh:
                fh.write(data)
            if not _valid_png(temp):
                continue
            atomic_replace(temp, path)
            return path
        except Exception:
            pass
        finally:
            try:
                if os.path.exists(temp):
                    os.unlink(temp)
            except Exception:
                pass
    # Keep one tiny diagnostic record. If both flag hosts are blocked by the
    # receiver's DNS/TLS/firewall, the next failure can be diagnosed accurately
    # without guessing or adding any image to the IPK.
    try:
        with open(os.path.join(_flags_dir(), "last_download_failure.txt"), "w") as f:
            f.write("Country: %s\n%s\n" % (code, "\n".join(failures)))
    except Exception:
        pass
    return ""


def _country_from_tmdb(kind, tmdb_id):
    key = ("tv" if kind in ("tv", "series") else "movie", str(tmdb_id))
    now = time.time()
    with _COUNTRY_LOCK:
        cached = _COUNTRY_CACHE.get(key)
        if cached and now - cached[1] < (_COUNTRY_TTL if cached[0] else _FAIL_TTL):
            return cached[0]
    country = ""
    try:
        from .tmdb_client import TMDbClient
        # Request only metadata for the resolved TMDb ID. This request is run
        # in the flag worker, never on the UI thread.
        payload = TMDbClient()._get("/%s/%s" % key, {"language": "en-US"}) or {}
        country = country_code(payload, kind)
    except Exception:
        pass
    with _COUNTRY_LOCK:
        if len(_COUNTRY_CACHE) > 256:
            _COUNTRY_CACHE.clear()
        _COUNTRY_CACHE[key] = (country, time.time())
    return country


def _flag_may_show(widget):
    checker = getattr(widget, "_tivimate_flag_allowed", None)
    if checker is None:
        return True
    try:
        return bool(checker())
    except Exception:
        return False


def _transparent_flag_fit(path, width, height):
    """Cache an exact-size RGBA flag; never flatten onto a black canvas."""
    if width < 1 or height < 1 or width > 512 or height > 512:
        return ''
    target = '%s.flagalpha1_%dx%d.png' % (path[:-4], width, height)
    cached = _cached_flag_fit(path, width, height)
    if cached:
        return cached
    temp = '%s.%s.%s.tmp' % (target, os.getpid(), thread_ident())
    try:
        from PIL import Image
        source = Image.open(path)
        try:
            w, h = source.size
            if w < 1 or h < 1 or w * h > 1000000:
                return ''
            face = source.convert('RGBA')
        finally:
            close = getattr(source, "close", None)
            if close:
                close()
        factor = min(float(width) / w, float(height) / h)
        dims = (max(1, int(round(w * factor))), max(1, int(round(h * factor))))
        sampling = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
        if face.size != dims:
            face = face.resize(dims, sampling)
        canvas = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        canvas.paste(face, ((width - dims[0]) // 2, (height - dims[1]) // 2))
        canvas.save(temp, 'PNG')
        atomic_replace(temp, target)
        return target
    except Exception:
        return ''
    finally:
        try:
            if os.path.exists(temp):
                os.unlink(temp)
        except OSError:
            pass


def _cached_flag_fit(path, width, height):
    if not path or width < 1 or height < 1:
        return ''
    target = '%s.flagalpha1_%dx%d.png' % (path[:-4], width, height)
    try:
        if _valid_png(target) and os.path.getmtime(target) >= os.path.getmtime(path):
            return target
    except OSError:
        pass
    return ''


def flag_widget_size(widget):
    try:
        size = widget.instance.size()
        return int(size.width()), int(size.height())
    except Exception:
        return 0, 0


def display_flag_pixmap(widget, path):
    """GUI-only: load the worker-prepared PNG, never run Pillow here."""
    if not widget.instance or not _valid_png(path):
        return False
    from Tools.LoadPixmap import LoadPixmap
    pix = LoadPixmap(path=path)
    if pix is None:
        return False
    try:
        widget.instance.setScale(0 if '.flagalpha1_' in path else 1)
    except (AttributeError, TypeError):
        pass
    widget.instance.setPixmap(pix)
    return True


def _decode_flag(widget, path, token):
    if not path or getattr(widget, '_tivimate_flag_token', None) != token:
        return
    try:
        if not display_flag_pixmap(widget, path):
            return
        widget._tivimate_flag_rendered = token
        if _flag_may_show(widget):
            widget.show()
        else:
            widget.hide()
    except Exception:
        pass


def _gui_on_ready(widget, token, path):
    if getattr(widget, "_tivimate_flag_token", None) == token and path:
        _decode_flag(widget, path, token)


def _cached_country_code(kind, tmdb_id):
    """Return the verified country already fetched by the shared TMDb worker."""
    if not str(tmdb_id or "").isdigit():
        return ""
    key = ("tv" if kind in ("tv", "series") else "movie", str(tmdb_id))
    with _COUNTRY_LOCK:
        cached = _COUNTRY_CACHE.get(key)
        return str(cached[0] or "") if cached else ""


def _gui_on_flag_resolved(widget, token, path, code, resolved_callback=None):
    """Apply a visible flag and share its verified country on the GUI thread."""
    if not path or getattr(widget, "_tivimate_flag_token", None) != token:
        return
    _gui_on_ready(widget, token, path)
    if code and callable(resolved_callback):
        try:
            resolved_callback(code)
        except Exception:
            pass


def _flag_circle_face(flag, big, sampling):
    """Square face for a round flag that keeps the whole design visible.

    A plain centre crop of a 2:1 flag cuts the hoist side away (the red bar of
    the UAE, Kuwait's black trapezoid, Jordan/Palestine/Sudan triangles,
    Qatar/Bahrain serrations). Keep the hoist when the left edge differs from
    the right edge, and squeeze the remaining width a little instead of
    cutting it, so every part of the flag stays inside the circle.
    """
    from PIL import Image, ImageOps
    width, height = flag.size
    if width <= 0 or height <= 0:
        return flag.resize((big, big), sampling)
    if float(width) / height <= 1.05:
        return ImageOps.fit(flag, (big, big), method=sampling)
    hoist = False
    try:
        probe = flag.convert('RGB').resize((32, 16), sampling).load()
        diff = 0
        for y in range(16):
            left, right = probe[1, y], probe[30, y]
            diff += abs(left[0] - right[0]) + abs(left[1] - right[1]) + abs(left[2] - right[2])
        hoist = diff / 16.0 > 60
    except Exception:
        hoist = False
    ratio = float(width) / height
    squeeze = 1.4 if hoist else 1.2
    if hoist and ratio > 2.2:
        squeeze = 1.7          # very long flags (Qatar 11:28)
    keep = int(round(min(width, height * squeeze)))
    if not hoist:
        left = (width - keep) // 2
    elif ratio > 2.2:
        left = (width - keep) // 3
    else:
        left = 0
    return flag.crop((left, 0, left + keep, height)).resize((big, big), sampling)

def _apple_round_flag(path):
    """Circular country flag (64px, thin white ring) cached beside the flag."""
    if not path or not os.path.isfile(path):
        return ''
    target = path[:-4] + '_v3_round64.png'
    tmp = target + '.%s.%s.tmp' % (os.getpid(), thread_ident())
    try:
        if _valid_png(target) and os.path.getmtime(target) >= os.path.getmtime(path):
            return target
        from PIL import Image, ImageOps, ImageDraw
        big = 192
        lanczos = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
        flag = Image.open(path)
        try:
            if flag.size[0] * flag.size[1] > 1000000:
                return ''
            face = _flag_circle_face(flag.convert('RGBA'), big, lanczos)
        finally:
            close = getattr(flag, 'close', None)
            if close:
                close()
        mask = Image.new('L', (big, big), 0)
        ImageDraw.Draw(mask).ellipse((9, 9, big - 10, big - 10), fill=255)
        out = Image.new('RGBA', (big, big), (0, 0, 0, 0))
        out.paste(face, (0, 0), mask)
        draw = ImageDraw.Draw(out)
        try:
            draw.ellipse((4, 4, big - 5, big - 5), outline=(255, 255, 255, 235), width=8)
        except TypeError:
            for inset in range(4, 12):
                draw.ellipse((inset, inset, big - inset - 1, big - inset - 1), outline=(255, 255, 255, 235))
        out = out.resize((64, 64), lanczos)
        out.save(tmp, format='PNG')
        atomic_replace(tmp, target)
        return target
    except Exception:
        return ''
    finally:
        try:
            if os.path.exists(tmp):
                os.unlink(tmp)
        except OSError:
            pass


def _worker(kind, tmdb_id, code, round_style=False, dimensions=(0, 0)):
    if not code and tmdb_id:
        code = _country_from_tmdb(kind, tmdb_id)
    if not code:
        return ""
    raw = _fetch_flag(code)
    if raw and round_style:
        raw = _apple_round_flag(raw) or raw
    return (_transparent_flag_fit(raw, *dimensions) or raw) if raw else ""


def show_country_flag(widget, bundle, kind, tmdb_id=None, visible_when=None, gui_dispatch=None, on_resolved=None, round_style=False):
    """Display a valid online flag using shared details cache and worker.

    An optional screen-owned GUI dispatcher lets screens that already use
    their eTimer mainloop queue avoid relying on Twisted integration.
    """
    try:
        widget._tivimate_flag_allowed = visible_when
        # Style only details; poster-card flags retain their original appearance.
        round_style = bool(round_style)
        token = int(getattr(widget, "_tivimate_flag_token", None) or 0) + 1
        widget._tivimate_flag_token = token
        widget._tivimate_flag_rendered = None
        try:
            for timer_name in ("_tivimate_flag_fallback_timer", "_tivimate_flag_poll_timer"):
                old_timer = getattr(widget, timer_name, None)
                if old_timer:
                    old_timer.stop()
        except Exception:
            pass
        widget.hide()
        dimensions = flag_widget_size(widget)
        code = country_code(bundle, kind)
        if code:
            path = country_flag_path(bundle, kind)
            if path and round_style:
                styled = path[:-4] + '_v3_round64.png'
                try:
                    path = styled if (_valid_png(styled) and
                                      os.path.getmtime(styled) >= os.path.getmtime(path)) else ''
                except OSError:
                    path = ''
            fitted = _cached_flag_fit(path, *dimensions)
            if fitted:
                _gui_on_flag_resolved(widget, token, fitted, code, on_resolved)
                return True
        candidate = str(tmdb_id or (bundle or {}).get("id") or "").strip()
        if not code and (not candidate.isdigit() or int(candidate) < 1):
            return False
        def prepare():
            if getattr(widget, '_tivimate_flag_token', None) != token:
                return ''
            return _worker(kind, candidate if not code else None, code, round_style, dimensions)
        future = submit_flag_job(('widget', id(widget)), prepare)
        # The fast Movies/TV screens already have an eTimer-driven GUI queue.
        # Deliver through it rather than Twisted: on some Pure2/OpenATV builds
        # a reactor may import but its callFromThread is not integrated with
        # the running Enigma2 mainloop. The flag would remain hidden forever.
        if callable(gui_dispatch):
            def deliver_with_screen_queue(completed):
                try:
                    path = completed.result()
                except Exception:
                    path = ""
                if not path:
                    return
                try:
                    known = code or (_cached_country_code(kind, candidate) if path else "")
                    gui_dispatch(_gui_on_flag_resolved, widget, token, path, known, on_resolved)
                except Exception:
                    pass
            future.add_done_callback(deliver_with_screen_queue)
            return True
        # Other consumers retain their existing Twisted/eTimer behaviour.
        try:
            from twisted.internet import reactor
            def deliver(future):
                try:
                    path = future.result()
                except Exception:
                    path = ""
                if path:
                    reactor.callFromThread(_gui_on_ready, widget, token, path)
            future.add_done_callback(deliver)
        except Exception:
            # Pure2 images without Twisted callbacks use one short-lived GUI
            # poller. It does not perform downloads on the UI thread.
            from enigma import eTimer
            timer = eTimer()
            widget._tivimate_flag_poll_timer = timer
            def poll():
                if getattr(widget, "_tivimate_flag_token", None) != token:
                    timer.stop()
                    return
                if future.done():
                    timer.stop()
                    try:
                        _gui_on_ready(widget, token, future.result())
                    except Exception:
                        pass
                else:
                    timer.start(250, True)
            try:
                widget._tivimate_flag_poll_conn = timer.timeout.connect(poll)
            except Exception:
                timer.callback.append(poll)
            timer.start(250, True)
        return True
    except Exception:
        return False
