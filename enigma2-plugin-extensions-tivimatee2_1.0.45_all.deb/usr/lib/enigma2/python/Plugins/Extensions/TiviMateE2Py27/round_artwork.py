# -*- coding: utf-8 -*-
"""Cached transparent circle rendering for DreamOS/Python 2.7 artwork.

Never modifies the source image. PIL work stays off Enigma2's GUI thread.
The bounded pool has only two workers, independent of poster download queues.
"""
from __future__ import absolute_import
import os
import hashlib
import shutil
import tempfile
import threading
from .py27_futures import ThreadPoolExecutor

_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix='TiviCircleMask')
_LOCKS = [threading.Lock() for _ in range(12)]
_MASKS = {}

def _source_key(path):
    """Stable content-based identity; cache-maintenance touches are ignored.

    Read a small fixed sample instead of hashing the whole JPEG each time.
    Different poster URLs already use distinct original cache filenames.
    """
    stat = os.stat(path)
    raw_path = os.path.realpath(path)
    if isinstance(raw_path, unicode):
        raw_path = raw_path.encode('utf-8', 'ignore')
    digest = hashlib.sha256()
    digest.update(raw_path)
    digest.update(str(stat.st_size).encode('ascii'))
    with open(path, 'rb') as handle:
        digest.update(handle.read(4096))
        if stat.st_size > 4096:
            handle.seek(max(0, stat.st_size - 4096))
            digest.update(handle.read(4096))
    return digest.hexdigest()[:20]


def _target(path, size):
    # Isolate derived PNGs so flash/HDD poster-retention never evicts an
    # ORIGINAL downloaded poster merely because its rounded copy was created.
    from .cache_manager import get_cache_dir
    root = get_cache_dir('circle_variants')
    return os.path.join(root, 'circle2-%d-%s.png' % (int(size), _source_key(path)))


def cached(path, size):
    try:
        dest = _target(path, size)
        if os.path.isfile(dest) and os.path.getsize(dest) > 256:
            return dest
        # One-time migration of an already generated thumbnail from the
        # original poster folder; no JPEG decode or additional HTTP request.
        stem, unused_ext = os.path.splitext(path)
        legacy = stem + '.tivi-circle-%s.png' % int(size)
        # Old hard-edged copies are not reused (smooth edge since circle2).
        if False and os.path.isfile(legacy) and os.path.getsize(legacy) > 256:
            try:
                os.rename(legacy, dest)
                return dest
            except OSError:
                return legacy
    except (IOError, OSError, ValueError, TypeError):
        pass
    return ''

def _alpha_mask(size):
    """Exact-size bundled mask, else the largest one (scaled by the tool)."""
    folder = os.path.join(os.path.dirname(__file__), 'skins', 'common')
    exact = os.path.join(folder, 'round_alpha_%s.png' % size)
    if os.path.isfile(exact):
        return exact, False
    best = os.path.join(folder, 'round_alpha_320.png')
    return (best, True) if os.path.isfile(best) else ('', False)


def make_circle(path, size):
    try:
        size = int(size)
        if not path or size < 20 or size > 512 or not os.path.isfile(path):
            return path
        hit = cached(path, size)
        if hit:
            return hit
        from PIL import Image, ImageDraw
        key = abs(hash((path, size))) % len(_LOCKS)
        with _LOCKS[key]:
            hit = cached(path, size)
            if hit:
                return hit
            image = Image.open(path)
            try:
                try:
                    # JPEG: decode directly at (at least) the circle size.
                    if image.format == 'JPEG':
                        image.draft('RGB', (size, size))
                except Exception:
                    pass
                rgb = image.convert('RGBA')
            finally:
                try: image.close()
                except Exception: pass
            w, h = rgb.size
            if w < 4 or h < 4:
                return path
            sample = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
            ratio = max(float(size) / float(w), float(size) / float(h))
            width = max(size, int(round(w * ratio)))
            height = max(size, int(round(h * ratio)))
            rgb = rgb.resize((width, height), sample)
            left = max(0, (width - size) // 2)
            top = max(0, int((height - size) * 0.40))
            rgb = rgb.crop((left, top, left + size, top + size))
            # Smooth edge: circle drawn 4x larger then shrunk (made once per size).
            mask = _MASKS.get(size)
            if mask is None:
                big = size * 4
                mask = Image.new('L', (big, big), 0)
                ImageDraw.Draw(mask).ellipse((0, 0, big - 1, big - 1), fill=255)
                mask = mask.resize((size, size), sample)
                _MASKS[size] = mask
            rgb.putalpha(mask)
            dest = _target(path, size)
            fd, tmp = tempfile.mkstemp(prefix='.tivi-round-', suffix='.png', dir=os.path.dirname(dest))
            os.close(fd)
            try:
                rgb.save(tmp, 'PNG')
                if os.path.getsize(tmp) < 256:
                    return path
                # Python 2.7's os.rename does not overwrite on every platform.
                try: os.rename(tmp, dest)
                except (OSError, IOError):
                    if os.path.exists(dest): os.unlink(dest)
                    os.rename(tmp, dest)
            finally:
                try:
                    if os.path.exists(tmp): os.unlink(tmp)
                except (OSError, IOError): pass
            return dest
    except Exception:
        # Pillow is not guaranteed on DreamOS/Python 2.7. Try the receiver's
        # existing ffmpeg binary with a bundled precomputed alpha mask.
        # Never modify source bytes or block the Enigma2 GUI thread.
        try:
            from .py27_compat import which, subprocess_run
            import subprocess
            ffmpeg = which('ffmpeg')
            mask, scale_mask = _alpha_mask(size)
            if not ffmpeg or not mask:
                raise RuntimeError('no ffmpeg/mask')
            dest = _target(path, size)
            if cached(path, size):
                return dest
            tmp = dest + '.ffmpeg.%s.png' % os.getpid()
            args = [ffmpeg, '-nostdin', '-loglevel', 'error', '-y', '-i', path,
                    '-i', mask, '-filter_complex',
                    '[0:v]scale=%d:%d:force_original_aspect_ratio=increase,'
                    'crop=%d:%d,format=rgba[image];'
                    '[1:v]%sformat=gray[mask];[image][mask]alphamerge' %
                    (size, size, size, size,
                     ('scale=%d:%d,' % (size, size)) if scale_mask else ''),
                    '-frames:v', '1', '-f', 'image2', '-vcodec', 'png', tmp]
            subprocess_run(args, check=True, timeout=9,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if os.path.getsize(tmp) > 256:
                os.rename(tmp, dest)
                return dest
        except Exception:
            pass
        finally:
            try:
                if 'tmp' in locals() and os.path.isfile(tmp): os.unlink(tmp)
            except (OSError, IOError): pass
        # Some older DreamOS installations have ImageMagick but no Pillow
        # and no ffmpeg. Do not show an uncropped black square if convert works.
        try:
            from .py27_compat import which, subprocess_run
            import subprocess
            tool = which('convert')
            mask, scale_mask = _alpha_mask(size)
            if tool and mask:
                dest = _target(path, size)
                tmp = dest + '.convert.%s.png' % os.getpid()
                subprocess_run([tool, path, '-auto-orient', '-resize',
                                '%sx%s^' % (size, size), '-gravity', 'center',
                                '-extent', '%sx%s' % (size, size), '(', mask,
                                '-resize', '%sx%s!' % (size, size), ')',
                                '-alpha', 'off', '-compose', 'CopyOpacity',
                                '-composite', tmp],
                               check=True, timeout=9,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if os.path.getsize(tmp) > 256:
                    try: os.rename(tmp, dest)
                    except (OSError, IOError):
                        if os.path.exists(dest): os.unlink(dest)
                        os.rename(tmp, dest)
                    return dest
        except Exception:
            pass
        finally:
            try:
                if 'tmp' in locals() and os.path.exists(tmp): os.unlink(tmp)
            except (OSError, IOError):
                pass
        return path

def prepare_circle(path, size, callback, is_current=None):
    """Call callback on GUI thread, with cached circular PNG or source fallback."""
    hit = cached(path, size)
    if hit:
        callback(hit)
        return
    try:
        from twisted.internet import reactor
    except Exception:
        reactor = None
    # Without reactor, avoid calling Enigma widgets from a background thread.
    if reactor is None:
        callback(make_circle(path, size))
        return
    def work():
        # A queued page may no longer be visible after fast scrolling.
        # Skip its expensive circle conversion, but preserve callbacks.
        if is_current is not None:
            try:
                if not is_current():
                    return path
            except Exception:
                return path
        return make_circle(path, size)
    def ready(future):
        try: result = future.result()
        except Exception: result = path
        reactor.callFromThread(callback, result)
    try:
        _POOL.submit(work).add_done_callback(ready)
    except Exception:
        callback(path)
