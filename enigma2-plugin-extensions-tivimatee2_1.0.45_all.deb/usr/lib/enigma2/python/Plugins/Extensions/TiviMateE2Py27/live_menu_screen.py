# -*- coding: utf-8 -*-
"""Live Menu: dark/gold layout with the current Enigma2 picture in a framed preview."""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from Components.Pixmap import Pixmap
from enigma import ePoint, eSize
import os
try:
    from enigma import gRGB
except Exception:
    gRGB = None
from .display_scale import scale_skin, sx, sy
from .picload_compat import connect_picture_data, disconnect_picture_data

_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'skins', 'live') + os.sep

# Design canvas 1920x1080 (scaled by scale_skin / sx / sy).
_LIST_X = 110
_ROW_Y0 = 250
_ROW_STEP = 150
_FOOT_X = (130, 520, 910, 1300)

_C_WHITE = 0xF4F6FA
_C_IDLE = 0xCDD2DC
_C_GOLD = 0xD4AF37
_C_NUM = 0x5A6270


def _rows():
    out = []
    for i in range(4):
        y = _ROW_Y0 + i * _ROW_STEP
        out.append(
            '<widget name="iconDim%d" position="160,%d" size="62,62" pixmap="%slive_menu_icon_dim_%d.png" alphatest="blend" scale="1" zPosition="5" />'
            '<widget name="icon%d" position="160,%d" size="62,62" pixmap="%slive_menu_icon_%d.png" alphatest="blend" scale="1" zPosition="6" />'
            '<widget name="name%d" position="250,%d" size="600,52" font="Regular;36" foregroundColor="#CDD2DC" transparent="1" valign="center" noWrap="1" zPosition="5" />'
            '<widget name="detail%d" position="251,%d" size="600,34" font="Regular;23" foregroundColor="#96A0B0" transparent="1" valign="center" noWrap="1" zPosition="5" />'
            '<widget name="number%d" position="880,%d" size="60,44" font="Regular;24" foregroundColor="#5A6270" transparent="1" halign="center" valign="center" zPosition="5" />'
            % (i, y + 31, _ASSETS, i, i, y + 31, _ASSETS, i, i, y + 22, i, y + 72, i, y + 40))
    return ''.join(out)


SKIN = ('<screen name="TiviMateLiveMenu" position="center,center" size="1920,1080" '
        'flags="wfNoBorder" backgroundColor="#07090E" transparent="0">'
        '<widget name="menuBackground" position="0,0" size="1920,1080" alphatest="blend" scale="1" zPosition="1" />'
        '<widget name="focus" position="110,250" size="860,124" pixmap="' + _ASSETS + 'live_menu_gold_focus.png" alphatest="blend" scale="1" zPosition="2" />'
        '<widget name="heading" position="140,85" size="750,66" font="Regular;50" foregroundColor="#F4F6FA" transparent="1" valign="center" zPosition="4" />'
        '<widget name="subheading" position="142,146" size="750,36" font="Regular;24" foregroundColor="#D4AF37" transparent="1" valign="center" zPosition="4" />'
        + _rows()
        # Live picture of the running service inside the gold frame.
        + '<widget source="session.VideoPicture" render="Pig" position="1075,195" size="700,394" backgroundColor="transparent" transparent="0" zPosition="10" />'
        + '<widget name="liveBadge" position="1093,213" size="90,34" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#C81E2D" transparent="0" halign="center" valign="center" zPosition="12" />'
        + '<widget name="selLabel" position="1080,610" size="340,32" font="Regular;20" foregroundColor="#D4AF37" transparent="1" valign="center" zPosition="5" />'
        + '<widget name="okHint" position="1430,610" size="340,32" font="Regular;20" foregroundColor="#6E7684" transparent="1" halign="right" valign="center" zPosition="5" />'
        + ''.join('<widget name="selIcon%d" position="1080,690" size="76,76" pixmap="%slive_menu_big_%d.png" alphatest="blend" scale="1" zPosition="5" />' % (i, _ASSETS, i) for i in range(4))
        + '<widget name="previewTitle" position="1180,686" size="600,54" font="Regular;40" foregroundColor="#F4F6FA" transparent="1" valign="center" noWrap="1" zPosition="5" />'
        + '<widget name="previewHint" position="1181,744" size="600,36" font="Regular;23" foregroundColor="#96A0B0" transparent="1" valign="center" noWrap="1" zPosition="5" />'
        + ''.join('<widget name="foot%d" position="%d,960" size="300,48" font="Regular;26" foregroundColor="#C8CDD6" transparent="1" valign="center" zPosition="5" />' % (i, x + 50) for i, x in enumerate(_FOOT_X))
        + '</screen>')


class LiveMenuScreen(Screen):
    skin = scale_skin(SKIN)
    ITEMS = (("Change View", "Windows / Classic", "#", "change_live_view",
              "Switch between Windows and Classic layouts"),
             ("Favorites", "My channels", "*", "favorites",
              "Open and manage your favourite channels"),
             ("Export to Enigma2", "Channels, packages & picons", ">", "export_enigma2",
              "Send channels and picons to Enigma2"),
             ("Live Options", "Playback and appearance", "@", "options",
              "Tune playback and the look of Live TV"))

    def __init__(self, session):
        Screen.__init__(self, session)
        self.index = 0
        self._menu_bg_loader = None
        self._menu_bg_connection = None
        self._menu_closed = False
        self.onClose.append(self._close_menu_background)
        self['menuBackground'] = Pixmap()
        self['focus'] = Pixmap()
        self['heading'] = Label('LIVE MENU')
        self['subheading'] = Label('TiviMateE2  ·  Live TV')
        self['liveBadge'] = Label('LIVE')
        self['selLabel'] = Label('SELECTED')
        self['okHint'] = Label('OK  to open')
        self['previewTitle'] = Label('')
        self['previewHint'] = Label('')
        for i, label in enumerate(('Exit', 'OK', 'Options', 'Info')):
            self['foot%d' % i] = Label(label)
        for i, item in enumerate(self.ITEMS):
            self['number%d' % i] = Label('%d' % (i + 1))
            self['iconDim%d' % i] = Pixmap()
            self['icon%d' % i] = Pixmap()
            self['selIcon%d' % i] = Pixmap()
            self['name%d' % i] = Label(item[0])
            self['detail%d' % i] = Label(item[1])
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'ColorActions', 'NumberActions'], {
            'ok': self._choose, 'green': self._choose, 'cancel': self._cancel,
            'red': self._cancel, 'up': self._up, 'down': self._down,
            'left': self._up, 'right': self._down,
            '1': lambda: self._choose_index(0), '2': lambda: self._choose_index(1),
            '3': lambda: self._choose_index(2), '4': lambda: self._choose_index(3),
            'yellow': lambda: self._choose_index(3), 'blue': lambda: self._choose_index(2)
        }, -1)
        self.onLayoutFinish.append(self._load_menu_pixmaps)

    def _load_menu_pixmaps(self):
        self._load_menu_background()
        paths = [('focus', 'live_menu_gold_focus.png')]
        for i in range(len(self.ITEMS)):
            paths.extend((('icon%d' % i, 'live_menu_icon_%d.png' % i),
                          ('iconDim%d' % i, 'live_menu_icon_dim_%d.png' % i),
                          ('selIcon%d' % i, 'live_menu_big_%d.png' % i)))
        for widget, filename in paths:
            try:
                instance = self[widget].instance
                try:
                    instance.setScale(1)
                except Exception:
                    pass
                instance.setPixmapFromFile(_ASSETS + filename)
            except Exception:
                pass
        self._refresh()

    def _load_menu_background(self):
        # Old pixmap widgets may silently fail to display a full-screen PNG
        # with skin scaling/alpha. Load directly, then decode once at the
        # actual GUI size using the native Enigma2 decoder (not poster cache).
        path = _ASSETS + 'live_menu_background.png'
        widget = self['menuBackground']
        instance = widget.instance
        if not os.path.isfile(path):
            alternate = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'TiviMateE2', 'skins', 'live', 'live_menu_background.png')
            if os.path.isfile(alternate):
                path = alternate
        if instance is None or not os.path.isfile(path):
            print('[TiviMateE2] Live Menu background unavailable: %s' % path)
            return
        try:
            instance.move(ePoint(0, 0))
            instance.resize(eSize(sx(1920), sy(1080)))
        except Exception:
            pass
        try:
            instance.setScale(1)
        except Exception:
            pass
        try:
            from Tools.LoadPixmap import LoadPixmap
            ptr = LoadPixmap(path=path)
            if ptr is not None:
                instance.setPixmap(ptr)
            else:
                instance.setPixmapFromFile(path)
            widget.show()
        except Exception:
            try:
                instance.setPixmapFromFile(path)
                widget.show()
            except Exception:
                pass
        try:
            from enigma import ePicLoad
            loader = ePicLoad()
            self._menu_bg_loader = loader
            self._menu_bg_connection = connect_picture_data(loader, self._menu_background_ready, owner=self)
            if self._menu_bg_connection is None:
                raise RuntimeError('no PictureData callback')
            loader.setPara((sx(1920), sy(1080), 1, 1, False, 1, '#0007090E'))
            if loader.startDecode(path) not in (0, None):
                raise RuntimeError('background decode failed')
        except Exception as exc:
            print('[TiviMateE2] Live Menu background decoder: %s' % exc)
            self._release_menu_background()

    def _menu_background_ready(self, *args):
        if self._menu_closed or self._menu_bg_loader is None:
            return
        try:
            ptr = self._menu_bg_loader.getData()
            if ptr is not None:
                widget = self['menuBackground']
                if widget.instance is not None:
                    widget.instance.setPixmap(ptr)
                    widget.show()
            else:
                print('[TiviMateE2] Live Menu background decode returned no pixmap')
        except Exception as exc:
            print('[TiviMateE2] Live Menu background display: %s' % exc)
        # Keep the decoder until the screen closes. Some older bindings do
        # not allow destroying an ePicLoad from within its own callback.

    def _release_menu_background(self):
        if self._menu_bg_loader is not None:
            disconnect_picture_data(self._menu_bg_loader, self._menu_bg_connection, owner=self)
        self._menu_bg_connection = None
        self._menu_bg_loader = None

    def _close_menu_background(self):
        self._menu_closed = True
        self._release_menu_background()

    def _color(self, widget, value):
        if gRGB is None:
            return
        try:
            inst = self[widget].instance
            inst.setForegroundColor(gRGB(value))
            inst.invalidate()
        except Exception:
            pass

    def _refresh(self):
        try:
            self['focus'].instance.move(ePoint(sx(_LIST_X), sy(_ROW_Y0 + self.index * _ROW_STEP)))
        except Exception:
            pass
        for i in range(len(self.ITEMS)):
            on = i == self.index
            try:
                if on:
                    self['icon%d' % i].show(); self['iconDim%d' % i].hide(); self['selIcon%d' % i].show()
                else:
                    self['icon%d' % i].hide(); self['iconDim%d' % i].show(); self['selIcon%d' % i].hide()
            except Exception:
                pass
            self._color('name%d' % i, _C_WHITE if on else _C_IDLE)
            self._color('number%d' % i, _C_GOLD if on else _C_NUM)
        item = self.ITEMS[self.index]
        self['previewTitle'].setText(item[0])
        self['previewHint'].setText(item[4])

    def _up(self):
        self.index = (self.index - 1) % len(self.ITEMS); self._refresh()

    def _down(self):
        self.index = (self.index + 1) % len(self.ITEMS); self._refresh()

    def _choose_index(self, index):
        self.index = index; self._choose()

    def _choose(self):
        self.close((self.ITEMS[self.index][0], self.ITEMS[self.index][3]))

    def _cancel(self):
        self.close(None)
