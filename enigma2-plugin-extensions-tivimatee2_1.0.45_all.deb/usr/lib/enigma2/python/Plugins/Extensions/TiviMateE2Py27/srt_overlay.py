# -*- coding: utf-8 -*-
"""Small, receiver-safe SRT reader used by TiviMateE2's VOD player.

This module intentionally has no dependency on Enigma2 subtitle-track APIs.
It only turns a local SRT file into timed text cues; the player owns drawing
and synchronization against the current service PTS.
"""
from __future__ import unicode_literals

import re
import sys

_TAG_RE = re.compile(r"<[^>]*>|\{\\[^}]*\}")
_TIME_RE = re.compile(
    r"^\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*"
    r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"
)


def _millis(hour, minute, second, millis):
    value = str(millis or "0").ljust(3, "0")[:3]
    return (((int(hour) * 60 + int(minute)) * 60 + int(second)) * 1000) + int(value)


def _cyrillic_bytes(raw):
    """True for a Windows-1251 (Bulgarian/Russian...) file that is not UTF-8.

    cp1256 decodes these bytes without an error and turned Cyrillic
    subtitles into Arabic-looking garbage. Arabic files read well as cp1256
    and are left alone (same rule as TiviMateSubtitles/process.py)."""
    def ratios(text):
        total = cyr = ara = 0
        for ch in text:
            cp = ord(ch)
            is_arabic = 0x0600 <= cp <= 0x06FF or 0xFB50 <= cp <= 0xFEFF
            if not (is_arabic or ch.isalpha()):
                continue
            total += 1
            if 0x0400 <= cp <= 0x04FF:
                cyr += 1
            elif is_arabic:
                ara += 1
        if total < 20:
            return 0.0, 0.0
        return cyr / float(total), ara / float(total)
    try:
        raw.decode("utf-8")
        return False
    except UnicodeError:
        pass
    try:
        cyr = ratios(raw.decode("cp1251"))[0]
        ara = ratios(raw.decode("cp1256"))[1]
    except Exception:
        return False
    return cyr >= 0.5 and cyr - ara >= 0.3


def _decode(raw):
    """Decode subtitle *bytes* to Unicode on DreamOS Python 2.7.

    Under Python 2, ``isinstance(raw, str)`` checks for bytes, so the old
    short circuit mistakenly returned encoded Arabic data unchanged.
    Regex operations using unicode_literals then failed on non-ASCII bytes.
    """
    try:
        unicode_class = unicode
    except NameError:
        unicode_class = str
    if isinstance(raw, unicode_class):
        return raw
    raw = raw or b""
    if not raw:
        return u""
    # UTF-16 only with its byte-order mark: without one, "utf-16" accepts
    # most UTF-8 files of even length and returned unreadable text.
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        try:
            return raw.decode("utf-16")
        except (UnicodeError, LookupError):
            pass
    if _cyrillic_bytes(raw):
        return raw.decode("cp1251")
    for encoding in ("utf-8-sig", "utf-8", "cp1256", "iso-8859-6", "cp1252"):
        try:
            return raw.decode(encoding)
        except (UnicodeError, LookupError):
            pass
    return raw.decode("utf-8", "replace")


def parse_srt_file(path):
    """Return sorted ``(start_ms, end_ms, text)`` SRT cues from a local file."""
    # Enigma2 Python 2.7 may use an ASCII filesystem encoding. Do not let
    # a filename containing Arabic characters block a valid downloaded SRT.
    try:
        unicode_class = unicode
    except NameError:
        unicode_class = str
    if sys.version_info[0] < 3 and isinstance(path, unicode_class):
        path = path.encode("utf-8")
    with open(path, "rb") as handle:
        content = _decode(handle.read())
    content = content.replace("\r\n", "\n").replace("\r", "\n")
    cues = []
    for block in re.split(r"\n{2,}", content):
        lines = [line.strip() for line in block.split("\n")]
        while lines and not lines[0]:
            lines.pop(0)
        if lines and lines[0].isdigit():
            lines.pop(0)
        if not lines:
            continue
        match = _TIME_RE.match(lines[0])
        if not match:
            continue
        start = _millis(*match.groups()[:4])
        end = _millis(*match.groups()[4:])
        if end <= start:
            continue
        body = "\n".join(line for line in lines[1:] if line).strip()
        body = _TAG_RE.sub("", body).strip()
        if body:
            cues.append((start, end, body))
    cues.sort(key=lambda cue: (cue[0], cue[1]))
    return cues
