# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import thread_factory
"""Bounded, keyed background task manager.

Newest keyed work wins. Stale queued tasks are skipped before execution, which
prevents fast navigation from building a large backlog of obsolete portal/TMDb
jobs. Worker count and queue size are intentionally small for Enigma2 boxes.
"""
import threading
import itertools
from collections import OrderedDict
try:
    import Queue as queue
except Exception:
    import Queue as queue
from .diagnostics import event, timer

class TaskManager(object):
    def __init__(self, name="TiviMate", workers=4, max_pending=96):
        self.name = str(name)
        self.queue = queue.Queue(maxsize=max(8, int(max_pending)))
        self.lock = threading.RLock()
        self.latest = OrderedDict()
        self._tickets = itertools.count(1)
        # Retention is only for queued/running work. Stale forgotten tickets
        # compare unequal to their missing key and are skipped safely.
        self.max_tracked_keys = max(128, int(max_pending) * 4)
        self.started = False
        self._running_workers = 0
        self.idle_timeout = 45.0
        self.workers = max(1, min(6, int(workers)))

    def _ensure(self):
        with self.lock:
            while self._running_workers < self.workers:
                t = thread_factory(target=self._worker, name="%sTask-%d" % (self.name, self._running_workers + 1))
                t.daemon = True
                self._running_workers += 1
                try:
                    t.start()
                except Exception:
                    self._running_workers -= 1
                    self.started = bool(self._running_workers)
                    raise
                self.started = True

    def submit(self, target, args=(), key=None, area="background"):
        # Atomic admission: a queue-full submission must NOT supersede a
        # previously accepted job with the same key. A worker can only check
        # generation after releasing this lock, so it sees a committed ticket.
        with self.lock:
            self._ensure()
            generation = next(self._tickets) if key is not None else 0
            try:
                self.queue.put_nowait((target, tuple(args or ()), key, generation, str(area)))
            except queue.Full:
                admitted = False
            else:
                admitted = True
                if key is not None:
                    self.latest[key] = generation
                    self.latest[key] = self.latest.pop(key)
                    while len(self.latest) > self.max_tracked_keys:
                        self.latest.popitem(last=False)
        if not admitted:
            event("tasks", "queue_full", manager=self.name, task_area=area, key=key or "")
            return False
        return generation or True

    def cancel(self, key):
        if key is None:
            return
        # Generation tickets are unique across all submissions. Removing the
        # current ticket invalidates *every* queued predecessor without leaving
        # an unused cancellation marker in memory.
        with self.lock:
            self.latest.pop(key, None)

    def active(self, key, generation):
        if key is None:
            return True
        with self.lock:
            return int(self.latest.get(key, 0) or 0) == int(generation or 0)

    def _worker(self):
        while True:
            try:
                target, args, key, generation, area = self.queue.get(timeout=self.idle_timeout)
            except queue.Empty:
                # Admission and retirement share this lock: a submit cannot
                # enqueue a job behind the last departing worker.
                with self.lock:
                    if self.queue.empty():
                        self._running_workers -= 1
                        self.started = bool(self._running_workers)
                        return
                continue
            except Exception:
                continue
            try:
                if key is not None and not self.active(key, generation):
                    event("tasks", "stale_skip", manager=self.name, task_area=area, key=key)
                    continue
                done = timer("tasks", "run", manager=self.name, task_area=area, key=key or "")
                try:
                    target(*args)
                    done("ok")
                except Exception as exc:
                    done("error", error=exc.__class__.__name__)
            finally:
                if key is not None:
                    with self.lock:
                        if self.latest.get(key) == generation:
                            self.latest.pop(key, None)
                try:
                    self.queue.task_done()
                except Exception:
                    pass
                # An idle worker must not own the last screen or its arguments.
                target = args = key = generation = area = done = exc = None
                # Python 2 keeps the last exception traceback in this frame.
                import sys
                if hasattr(sys, "exc_clear"):
                    sys.exc_clear()

CONTENT_TASKS = TaskManager("TiviMateContent", workers=4, max_pending=128)
MAINTENANCE_TASKS = TaskManager("TiviMateMaint", workers=1, max_pending=16)
