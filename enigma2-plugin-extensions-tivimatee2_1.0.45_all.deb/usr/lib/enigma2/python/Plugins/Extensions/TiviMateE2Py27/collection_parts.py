# -*- coding: utf-8 -*-
"""Movie Parts (Saga): a dedicated page for one TMDb movie collection.

Top-left: the collection name, how many of its parts the active server has,
then the selected part (number, clearlogo/title, metadata pills, synopsis).
Background: the selected part's backdrop, dimmed by a readability overlay.
Bottom: every part in release order on a gold timeline - a numbered chip, a
dot and a large poster per part.  Parts the server does not carry stay in
the timeline (veiled, "Not on this server") so the saga order stays readable.

Like Actor Spotlight, the page subclasses the GENRE grid so posters, hero
artwork, metadata and the Details hand-over keep their proven pipeline.
Only the layout, the navigation and the collection panel are new.
"""

import json
import os
import time
from .py27_compat import thread_factory

try:        # Python 2.7 build: unicode-safe Label (VTi / DreamOS)
    from .vti_compat import VTiTextLabel as Label
except ImportError:
    from Components.Label import Label
try:
    from .py27_compat import text_type as _txt
except ImportError:
    _txt = str
from Components.Pixmap import Pixmap
from Screens.MessageBox import MessageBox
from enigma import ePoint, eSize, eTimer

from .display_scale import scale_skin, sx, sy
from .display_titles import visible_title
from .genre_page import (StandaloneGenreScreen, GENRE_PILL_SPECS, _genre_pill_score,
                         _genre_pill_language, _genre_pill_age)
from .i18n import tr, tr_text, get_language
from .resolution_badge import (extract_resolution, extract_rating, extract_duration,
                               _year_genre_from_sources, _actual_media_genre)
from .rtl_text import DirectionalLabel, SynopsisLabel
from .localized_story import LocalizedStoryMixin

# The same file ships in TiviMateE2 (Python 3) and TiviMateE2Py27.
PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
ART = os.path.join(PLUGIN_PATH, "skins", "saga")
PLACEHOLDER = os.path.join(ART, "saga_placeholder.png")
_SAGA_RIBBON_ASSETS = {lang: os.path.join(ART, 'saga_viewing_ribbon_%s.png' % lang)
                       for lang in ('en', 'ar', 'fr', 'tr')}
_SAGA_RIBBON_DEFAULT = _SAGA_RIBBON_ASSETS['en']
_SAGA_RIBBON_W = 146
_SAGA_RIBBON_H = 146

# 1920x1080 design canvas (display_scale converts it for other desktops).
PAGE = 6
BASE_SLOTS = 24              # widgets the GENRE base class always creates
POSTER_W, POSTER_H = 200, 300
GAP = 60
CHIP_Y, CHIP_H = 548, 36
LINE_Y = 614                 # centre of the timeline
DOT, DOT_FOCUS = 20, 44
POSTER_Y = 650
FOCUS_PAD = 14
LOGO_W, LOGO_H = POSTER_W + 40, 34
TEXT_X = 60
PILL_X, PILL_Y = TEXT_X, 380
PILL_LIMIT = 1240
GOLD = "#F2CF85"

_TEXT = {
    "ar": {
        "MOVIE COLLECTION": u"سلسلة الأفلام",
        "MOVIE PARTS": u"سلسلة الأفلام",
        "Part %d": u"الجزء %d",
        "PART %d OF %d": u"الجزء %d من %d",
        "%d of %d parts on this server": u"%d من %d أجزاء متوفرة على هذا السيرفر",
        "All %d parts on this server": u"جميع الأجزاء الـ %d متوفرة على هذا السيرفر",
        "Not on this server": u"غير متوفر على السيرفر",
        "NOT AVAILABLE": u"لم يُعثر عليه",
        "SEARCH INCOMPLETE": u"لم يكتمل البحث",
        "NOW VIEWING": u"الفيلم الحالي",
        "%d copies": u"%d نسخ",
        "Previous page": u"الصفحة السابقة",
        "Next page": u"الصفحة التالية",
        "Movie details": u"تفاصيل الفيلم",
        "Hold: Favorite": u"مطوّل: المفضلة",
        "Back": u"رجوع",
        "This part is not available on this server.": u"لم يُعثر على هذا الجزء في الباقات المفعّلة.",
    },
    "fr": {
        "MOVIE COLLECTION": u"SÉRIE DE FILMS",
        "MOVIE PARTS": u"SÉRIE DE FILMS",
        "Part %d": u"Partie %d",
        "PART %d OF %d": u"PARTIE %d SUR %d",
        "%d of %d parts on this server": u"%d parties sur %d sur ce serveur",
        "All %d parts on this server": u"Les %d parties sont sur ce serveur",
        "Not on this server": u"Absent de ce serveur",
        "NOT AVAILABLE": u"Introuvable",
        "SEARCH INCOMPLETE": u"Recherche incomplète",
        "NOW VIEWING": u"FILM ACTUEL",
        "%d copies": u"%d copies",
        "Previous page": u"Page précédente",
        "Next page": u"Page suivante",
        "Movie details": u"Détails du film",
        "Hold: Favorite": u"Appui long : Favori",
        "Back": u"Retour",
        "This part is not available on this server.": u"Cette partie n'est pas disponible sur ce serveur.",
    },
    "tr": {
        "MOVIE COLLECTION": u"FİLM SERİSİ",
        "MOVIE PARTS": u"FİLM SERİSİ",
        "Part %d": u"Bölüm %d",
        "PART %d OF %d": u"BÖLÜM %d / %d",
        "%d of %d parts on this server": u"%d / %d bölüm bu sunucuda",
        "All %d parts on this server": u"%d bölümün tümü bu sunucuda",
        "Not on this server": u"Bu sunucuda yok",
        "NOT AVAILABLE": u"Bulunamadı",
        "SEARCH INCOMPLETE": u"Arama tamamlanmadı",
        "NOW VIEWING": u"ŞU ANKİ FİLM",
        "%d copies": u"%d kopya",
        "Previous page": u"Önceki sayfa",
        "Next page": u"Sonraki sayfa",
        "Movie details": u"Film detayları",
        "Hold: Favorite": u"Uzun bas: Favori",
        "Back": u"Geri",
        "This part is not available on this server.": u"Bu bölüm bu sunucuda mevcut değil.",
    },
}




_TEXT["de"] = {
    u'%d copies': u'%d Kopien',
    u'%d of %d parts on this server': u'%d von %d Teilen auf diesem Server',
    u'All %d parts on this server': u'Alle %d Teile auf diesem Server',
    u'Back': u'Zurück',
    u'Hold: Favorite': u'Gedrückt halten: Favorit',
    u'MOVIE COLLECTION': u'FILMREIHE',
    u'MOVIE PARTS': u'FILMREIHE',
    u'Movie details': u'Filmdetails',
    u'NOT AVAILABLE': u'NICHT VERFÜGBAR',
    u'NOW VIEWING': u'AKTUELLER FILM',
    u'Next page': u'Nächste Seite',
    u'Not on this server': u'Nicht auf diesem Server',
    u'PART %d OF %d': u'TEIL %d VON %d',
    u'Part %d': u'Teil %d',
    u'Previous page': u'Vorherige Seite',
    u'SEARCH INCOMPLETE': u'SUCHE UNVOLLSTÄNDIG',
    u'This part is not available on this server.': u'Dieser Teil ist auf diesem Server nicht verfügbar.',
}

# Localized saga-folder action; independent of the global content language.
_COLLECTION_ACTION_TEXT = {
    'ar': {
        'MENU: Toggle movie series favorite': u'MENU: إضافة / إزالة السلسلة من المفضلة',
        'Finish loading the movie series first.': u'انتظر حتى يكتمل تحميل سلسلة الأفلام',
        'Movie series removed from favorites': u'تمت إزالة سلسلة الأفلام من المفضلة',
        'Movie series added to favorites': u'تمت إضافة سلسلة الأفلام إلى المفضلة',
        'Unable to save movie series': u'تعذر حفظ سلسلة الأفلام',
    },
    'fr': {
        'MENU: Toggle movie series favorite': u'MENU : Ajouter / retirer la série des favoris',
        'Finish loading the movie series first.': u'Attendez le chargement de la série de films',
        'Movie series removed from favorites': u'Série de films retirée des favoris',
        'Movie series added to favorites': u'Série de films ajoutée aux favoris',
        'Unable to save movie series': u'Impossible de sauvegarder la série',
    },
    'tr': {
        'MENU: Toggle movie series favorite': u'MENU: Film serisini favorilere ekle / çıkar',
        'Finish loading the movie series first.': u'Önce film serisinin yüklenmesini bekleyin',
        'Movie series removed from favorites': u'Film serisi favorilerden kaldırıldı',
        'Movie series added to favorites': u'Film serisi favorilere eklendi',
        'Unable to save movie series': u'Film serisi kaydedilemedi',
    },
}

_COLLECTION_ACTION_TEXT["de"] = {
    u'Finish loading the movie series first.': u'Zuerst das Laden der Filmreihe abschließen lassen.',
    u'MENU: Toggle movie series favorite': u'MENU: Filmreihe zu Favoriten hinzufügen / entfernen',
    u'Movie series added to favorites': u'Filmreihe zu Favoriten hinzugefügt',
    u'Movie series removed from favorites': u'Filmreihe aus Favoriten entfernt',
    u'Unable to save movie series': u'Filmreihe konnte nicht gespeichert werden',
}

for _lang, _values in _COLLECTION_ACTION_TEXT.items():
    _TEXT.setdefault(_lang, {}).update(_values)

# Saga's two explicit favorite actions. Short labels fit the six-key toolbar.
_SAGA_FAVORITE_TEXT = {
    'ar': {
        'Add full series': u'إضافة السلسلة كاملة',
        'Add one movie': u'إضافة فيلم واحد',
        'Movie series already in favorites': u'السلسلة موجودة في المفضلة',
        'Selected movie already in favorites': u'الفيلم موجود في المفضلة',
        'Selected movie added to favorites': u'تمت إضافة الفيلم المحدد للمفضلة',
        'Unable to save selected movie': u'تعذر إضافة الفيلم للمفضلة',
        'No movie selected': u'اختر فيلمًا أولًا',
    },
    'fr': {
        'Add full series': u'Série entière',
        'Add one movie': u'Un seul film',
        'Movie series already in favorites': u'Série déjà dans les favoris',
        'Selected movie already in favorites': u'Film déjà dans les favoris',
        'Selected movie added to favorites': u'Film ajouté aux favoris',
        'Unable to save selected movie': u'Impossible d’ajouter le film',
        'No movie selected': u'Sélectionnez un film',
    },
    'tr': {
        'Add full series': u'Tüm seriyi ekle',
        'Add one movie': u'Tek film ekle',
        'Movie series already in favorites': u'Seri zaten favorilerde',
        'Selected movie already in favorites': u'Film zaten favorilerde',
        'Selected movie added to favorites': u'Film favorilere eklendi',
        'Unable to save selected movie': u'Film favorilere eklenemedi',
        'No movie selected': u'Önce bir film seçin',
    },
    'de': {
        'Add full series': u'Ganze Reihe',
        'Add one movie': u'Einzelner Film',
        'Movie series already in favorites': u'Filmreihe ist bereits in Favoriten',
        'Selected movie already in favorites': u'Film ist bereits in Favoriten',
        'Selected movie added to favorites': u'Film zu Favoriten hinzugefügt',
        'Unable to save selected movie': u'Film konnte nicht gespeichert werden',
        'No movie selected': u'Zuerst einen Film auswählen',
    },
}
for _lang, _values in _SAGA_FAVORITE_TEXT.items():
    _TEXT.setdefault(_lang, {}).update(_values)


def _language():
    try:
        return str(get_language() or "en").lower()[:2]
    except Exception:
        return "en"


def _t(text):
    if text == 'MOVIE PARTS' and _language() == 'en':
        return 'MOVIE SERIES'
    value = _TEXT.get(_language(), {}).get(text)
    return value if value is not None else tr_text(text)


def _shorten(value, limit):
    text = u" ".join(_txt(value or u"").split())
    if len(text) <= limit:
        return text
    part = text[:limit].rstrip()
    cut = part.rfind(" ")
    if cut >= limit // 2:
        part = part[:cut]
    return part.rstrip(u" -_|:/,.؛،") + u"…"


def _year(value):
    text = _txt(value or u"")[:4]
    return text if text.isdigit() else ""


def card_positions(count):
    """Centred x positions for the cards of one page."""
    count = max(1, min(PAGE, int(count or 1)))
    width = count * POSTER_W + (count - 1) * GAP
    start = (1920 - width) // 2
    return [start + i * (POSTER_W + GAP) for i in range(count)]


def build_cards(info):
    """One card per collection part, in release order.

    A part the server carries uses its best provider row (so Details and
    playback work unchanged); other copies stay in `_part_copies`.  A part the
    server lacks becomes a TMDb-only card flagged `_part_missing`.
    """
    cards = []
    current = _txt((info or {}).get("current_tmdb_id") or u"")
    for number, part in enumerate((info or {}).get("parts") or [], 1):
        if not isinstance(part, dict):
            continue
        rows = [dict(r) for r in (part.get("rows") or []) if isinstance(r, dict)]
        tmdb_id = _txt(part.get("tmdb_id") or u"")
        poster = _txt(part.get("poster_path") or u"")
        if rows:
            card = dict(rows[0])
            card["_part_copies"] = len(rows)
            card["_part_missing"] = False
        else:
            card = {"name": part.get("title") or "", "title": part.get("title") or "",
                    "_part_missing": True, "_part_copies": 0}
            if poster.startswith("/"):
                # Full TMDb URL: never let a provider prefix a relative path.
                card["stream_icon"] = "https://image.tmdb.org/t/p/w342" + poster
        if tmdb_id:
            card.setdefault("tmdb_id", tmdb_id)
            card["_locked_tmdb_id"] = tmdb_id
        if poster:
            # The server row may retain a DIFFERENT stale poster ID. For a
            # verified collection part, its official TMDb artwork wins.
            card["_tmdb_poster"] = poster
        year = _year(part.get("release_date"))
        if year and not _year(card.get("year")):
            card["year"] = year
        if part.get("overview") and not (card.get("plot") or card.get("description")):
            card["plot"] = part.get("overview")
        if part.get("vote") and not card.get("rating"):
            try:
                card["rating"] = "%.1f" % float(part.get("vote"))
            except Exception:
                pass
        card["_part_number"] = number
        card["_part_year"] = year
        card["_part_title"] = part.get("title") or card.get("name") or ""
        card["_part_current"] = bool(current and tmdb_id == current)
        card["_keep_copy"] = True
        cards.append(card)
    return cards


def build_skin(collection_buttons=True):
    rows = [
        '<screen name="CollectionPartsScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05070B">',
        '<eLabel position="0,0" size="1920,1080" backgroundColor="#05070B" zPosition="0" />',
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="off" scale="1" zPosition="1" />' % os.path.join(ART, "saga_bg.jpg"),
        '<widget name="heroBackdrop" position="0,0" size="1920,1080" alphatest="off" scale="1" zPosition="2" />',
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="blend" scale="1" zPosition="3" />' % os.path.join(ART, "saga_overlay.png"),

        # ---- collection panel --------------------------------------------
        '<widget name="sagaTag" position="%d,44" size="900,30" font="Bold;20" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % (TEXT_X, GOLD),
        '<widget name="sagaName" position="%d,76" size="1200,66" font="Bold;50" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />' % TEXT_X,
        '<widget name="sagaCount" position="%d,144" size="1100,30" font="Regular;22" foregroundColor="#C7D5E0" transparent="1" valign="center" noWrap="1" zPosition="5" />' % TEXT_X,
        '<eLabel position="%d,190" size="88,3" backgroundColor="%s" zPosition="5" />' % (TEXT_X, GOLD),

        # ---- selected part -----------------------------------------------
        '<widget name="partBig" position="%d,206" size="900,34" font="Bold;22" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % (TEXT_X, GOLD),
        '<widget name="heroLogo" position="%d,246" size="560,118" alphatest="blend" scale="1" zPosition="5" />' % TEXT_X,
        '<widget name="heroTitle" position="%d,262" size="1150,64" font="Bold;44" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />' % TEXT_X,
    ]
    pill_fonts = {"genreCategories": 18, "genreQuality": 17}
    for name, width, inset, style in GENRE_PILL_SPECS:
        rows.append('<widget name="%sBg" position="%d,%d" size="%d,38" pixmap="%s" alphatest="blend" zPosition="8" />' % (
            name, PILL_X, PILL_Y, width, os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_%s.png" % style)))
        rows.append('<widget name="%s" position="%d,%d" size="%d,38" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />' % (
            name, PILL_X + inset, PILL_Y, width - inset - (5 if inset <= 5 else 8), pill_fonts.get(name, 19)))
    rows.extend([
        '<widget name="heroPlot" position="%d,430" size="1100,96" font="Regular;22" foregroundColor="#E0E8F0" transparent="1" zPosition="5" />' % TEXT_X,

        # ---- right header ------------------------------------------------
        '<widget name="heading" position="1566,40" size="294,40" font="Bold;24" foregroundColor="#F8D891" transparent="1" halign="center" valign="center" noWrap="1" zPosition="5" />',
        '<ePixmap position="1566,86" size="294,62" pixmap="%s" alphatest="blend" zPosition="5" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_page_counter_gold_r136.png"),
        '<widget name="page" position="1566,98" size="294,38" font="Bold;25" foregroundColor="#FFE1A0" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />',
        '<widget name="status" position="1240,206" size="620,30" font="Regular;19" foregroundColor="#E5C478" transparent="1" halign="right" valign="center" noWrap="1" zPosition="5" />',

        # ---- timeline ----------------------------------------------------
        '<widget name="timeline" position="0,%d" size="10,2" font="Regular;1" backgroundColor="#8C7442" zPosition="5" />' % (LINE_Y - 1),
        '<widget name="chipFocus" position="0,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="7" />' % (
            CHIP_Y, POSTER_W - 10, CHIP_H, os.path.join(ART, "saga_chip_focus.png")),
        '<widget name="chipFocusText" position="0,%d" size="%d,%d" font="Bold;19" foregroundColor="#11151C" transparent="1" halign="center" valign="center" noWrap="1" zPosition="8" />' % (
            CHIP_Y, POSTER_W - 10, CHIP_H),
        '<widget name="dotFocus" position="0,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="7" />' % (
            LINE_Y - DOT_FOCUS // 2, DOT_FOCUS, DOT_FOCUS, os.path.join(ART, "saga_dot_focus.png")),
        '<widget name="selector" position="0,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="12" />' % (
            POSTER_Y - FOCUS_PAD, POSTER_W + 2 * FOCUS_PAD, POSTER_H + 2 * FOCUS_PAD, os.path.join(ART, "saga_focus.png")),

        # ---- remote legend -----------------------------------------------
        '<ePixmap position="20,1022" size="1880,52" pixmap="%s" alphatest="blend" zPosition="35" />' % os.path.join(ART, "saga_toolbar_actions.png" if collection_buttons else "saga_toolbar.png"),
        '<widget name="legendRed" position="%d,1022" size="%d,52" font="Regular;19" foregroundColor="#E8EDF3" transparent="1" valign="center" noWrap="1" zPosition="38" />' % ((84, 230) if collection_buttons else (84, 290)),
        '<widget name="legendBlue" position="%d,1022" size="%d,52" font="Regular;19" foregroundColor="#E8EDF3" transparent="1" valign="center" noWrap="1" zPosition="38" />' % ((397, 230) if collection_buttons else (454, 290)),
        '<widget name="legendOk" position="%d,1022" size="%d,52" font="Regular;19" foregroundColor="#E8EDF3" transparent="1" valign="center" noWrap="1" zPosition="38" />' % ((710, 230) if collection_buttons else (830, 290)),
        '<widget name="legendYellow" position="%d,1022" size="%d,52" font="Regular;19" foregroundColor="#E8EDF3" transparent="1" valign="center" noWrap="1" zPosition="38" />' % ((1336, 230) if collection_buttons else (1194, 290)),
        '<widget name="legendExit" position="%d,1022" size="%d,52" font="Regular;19" foregroundColor="#E8EDF3" transparent="1" valign="center" noWrap="1" zPosition="38" />' % ((1649, 210) if collection_buttons else (1582, 290)),

        # ---- GENRE widgets this page does not show (names stay valid) ----
        '<widget name="packageLogo" position="0,0" size="1,1" alphatest="blend" />',
    ])
    if collection_buttons:
        rows.append('<widget name="legendGreen" position="1023,1022" size="230,52" font="Regular;19" foregroundColor="#E8EDF3" transparent="1" valign="center" noWrap="1" zPosition="38" />')
    for name in ("heroInfo", "heroMeta", "subheading", "footerServerName", "footerSortValue",
                 "redHint", "greenHint", "yellowHint", "blueHint", "menuHint"):
        rows.append('<widget name="%s" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % name)
    for index in range(10):
        rows.append('<widget name="nav%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % index)
    for index in range(8):
        rows.append('<widget name="genre%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % index)

    xs = card_positions(PAGE)
    for slot in range(BASE_SLOTS):
        if slot >= PAGE:
            rows.extend([
                '<widget name="poster%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
                '<widget name="shell%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
                '<widget name="title%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % slot,
                '<widget name="meta%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % slot,
                '<widget name="partLogo%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
            ])
            continue
        x = xs[slot]
        rows.extend([
            '<widget name="chip%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="6" />' % (
                slot, x + 5, CHIP_Y, POSTER_W - 10, CHIP_H, os.path.join(ART, "saga_chip.png")),
            '<widget name="chipText%d" position="%d,%d" size="%d,%d" font="Bold;19" foregroundColor="#F3E2B8" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, x + 5, CHIP_Y, POSTER_W - 10, CHIP_H),
            '<widget name="dot%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="6" />' % (
                slot, x + (POSTER_W - DOT) // 2, LINE_Y - DOT // 2, DOT, DOT, os.path.join(ART, "saga_dot.png")),
            # VTi/Python 2.7: never make screen construction depend on a PNG.
            # Some VTi builds reject/miss this default image when returning
            # from the player; the actual poster is painted after the skin.
            '<widget name="poster%d" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" zPosition="8" />' % (
                slot, x, POSTER_Y, POSTER_W, POSTER_H),
            '<widget name="veil%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="9" />' % (
                slot, x, POSTER_Y, POSTER_W, POSTER_H, os.path.join(ART, "saga_veil.png")),
            '<widget name="veilText%d" position="%d,%d" size="%d,60" font="Bold;18" foregroundColor="#F2F2F2" transparent="1" halign="center" valign="center" zPosition="10" />' % (
                slot, x + 10, POSTER_Y + POSTER_H // 2 + 16, POSTER_W - 20),
            '<widget name="shell%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" zPosition="10" />' % (
                slot, x, POSTER_Y, POSTER_W, POSTER_H, os.path.join(ART, "saga_shell.png")),
            '<widget name="nowFlag%d" position="%d,%d" size="%d,28" font="Bold;15" foregroundColor="#11151C" backgroundColor="#F2CF85" halign="center" valign="center" noWrap="1" zPosition="11" />' % (
                slot, x + 24, POSTER_Y + 10, POSTER_W - 48),
            '<widget name="sagaRibbon%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="16" />' % (
                slot, x, POSTER_Y, _SAGA_RIBBON_W, _SAGA_RIBBON_H, _SAGA_RIBBON_DEFAULT),
            '<widget name="title%d" position="%d,%d" size="%d,30" font="Bold;19" foregroundColor="#F7F4EC" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, x - 20, POSTER_Y + POSTER_H + 8, POSTER_W + 40),
            '<widget name="partLogo%d" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" zPosition="8" />' % (
                slot, x - 20, POSTER_Y + POSTER_H + 8, POSTER_W + 40, LOGO_H),
            '<widget name="meta%d" position="%d,%d" size="%d,24" font="Regular;16" foregroundColor="#B9C6D3" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, x - 20, POSTER_Y + POSTER_H + 44, POSTER_W + 40),
        ])
    rows.append('</screen>')
    return scale_skin("\n".join(rows))


class CollectionPartsScreen(LocalizedStoryMixin, StandaloneGenreScreen):
    """All parts of one movie collection on a numbered timeline."""

    _PAGE_SOURCE_PREFIX = "collection_parts_"
    _CARD_SIZE = (POSTER_W, POSTER_H)     # read by the GENRE poster decoder
    skin = build_skin()

    def __init__(self, session, source, initial_kind="vod", initial_category_id=""):
        StandaloneGenreScreen.__init__(self, session, source, "vod", initial_category_id)
        info = self.source.get("_collection_parts_info")
        self._saga = dict(info) if isinstance(info, dict) else {}
        self._saga_background_lookup = self._saga.pop('_background_lookup', None)
        self._saga_scan_pending = callable(self._saga_background_lookup)
        self._saga_search_incomplete = bool(
            self._saga.get('_saga_search_incomplete', False))
        self._saga_enrichment_ready = None
        self._saga_preview_ready = None
        self._saga_enrichment_done = False
        self._saga_stage_started = 0.0
        self._saga_wait_expired = False
        # GUI timer: works even on Enigma2 images without Twisted reactor.
        self._saga_enrichment_timer = eTimer()
        self._saga_enrichment_timer.callback.append(self._poll_saga_enrichment)
        self.onClose.append(self._saga_enrichment_timer.stop)
        # Release order is the point of this page: never re-sort by date/A-Z.
        self._poster_sort_mode = "default"
        self._saga_layout_count = None
        self["sagaTag"] = Label(_t("MOVIE COLLECTION"))
        self["sagaName"] = DirectionalLabel("")
        self["sagaCount"] = Label("")
        self["partBig"] = Label("")
        self["timeline"] = Label("")
        self["chipFocus"] = Pixmap()
        self["chipFocusText"] = Label("")
        self["dotFocus"] = Pixmap()
        self["legendRed"] = Label(_t("Previous page"))
        self["legendBlue"] = Label(_t("Next page"))
        self["legendOk"] = Label(_t("Movie details"))
        self["legendYellow"] = Label(_t("Hold: Favorite"))
        if getattr(self, '_PAGE_SOURCE_PREFIX', '') == 'collection_parts_':
            self['legendGreen'] = Label(_t('Add full series'))
            self['legendYellow'].setText(_t('Add one movie'))
            self['menuHint'].setText(_t('MENU: Toggle movie series favorite'))
            # Only Saga changes: Other Sources retains its original key actions.
            actions = self['actions'].actions
            actions['green'] = self.add_collection_to_favorites
            actions['greenlong'] = self.add_collection_to_favorites
            actions['yellow'] = self.add_selected_movie_to_favorites
            actions['yellowlong'] = self.add_selected_movie_to_favorites
        self["legendExit"] = Label(_t("Back"))
        self._part_logo_tokens = {}
        for slot in range(BASE_SLOTS):
            self["partLogo%d" % slot] = Pixmap()
            self["partLogo%d" % slot].hide()
        for slot in range(PAGE):
            self["chip%d" % slot] = Pixmap()
            self["chipText%d" % slot] = Label("")
            self["dot%d" % slot] = Pixmap()
            self["veil%d" % slot] = Pixmap()
            self["veilText%d" % slot] = Label("")
            self["nowFlag%d" % slot] = Label("")
            self["sagaRibbon%d" % slot] = Pixmap()
            self["sagaRibbon%d" % slot].hide()
        for slot in range(PAGE, BASE_SLOTS):
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        self._saga_ribbon_loaded = None
        self.onLayoutFinish.append(self._saga_update_ribbons)
        self.onLayoutFinish.append(self._saga_begin)
        self.onLayoutFinish.append(self._start_saga_enrichment)
        self.onClose.append(self._close_part_logos)

    def _saga_update_ribbons(self):
        """Lightweight on-screen locale badge from bundled PNGs only.

        Does not decode or fetch poster assets and is safe for VTi/Python 2.7.
        """
        if not hasattr(self, '_saga_ribbon_loaded'):
            return
        path = _SAGA_RIBBON_ASSETS.get(_language(), _SAGA_RIBBON_DEFAULT)
        if self._saga_ribbon_loaded != path:
            all_loaded = True
            for slot in range(PAGE):
                inst = self['sagaRibbon%d' % slot].instance
                if inst is None:
                    all_loaded = False
                    continue
                inst.setPixmapFromFile(path)
            if all_loaded:
                self._saga_ribbon_loaded = path
        if not self.genre_items:
            count = 0
        else:
            count = max(0, min(PAGE, len(self.genre_items) - self.page_start))
        for slot in range(PAGE):
            widget = self['sagaRibbon%d' % slot]
            self['nowFlag%d' % slot].hide()
            if slot >= count or not self.genre_items[self.page_start + slot].get('_part_current'):
                widget.hide()
            elif widget.instance is None:
                widget.hide()
            else:
                widget.show()

    def _start_saga_enrichment(self):
        lookup = self._saga_background_lookup
        self._saga_background_lookup = None
        if not callable(lookup) or self._closed:
            return
        self._saga_enrichment_ready = None
        self._saga_enrichment_done = False
        self._saga_scan_pending = True
        self._saga_wait_expired = False
        self._saga_stage_started = time.time()
        def worker():
            try:
                # A single worker can deliver the TMDb parts first and then
                # finish checking locally cached / server-side availability.
                # Never call Enigma2 widgets from this background thread.
                if getattr(lookup, '_saga_preview', False):
                    def publish(preview):
                        if not self._closed and isinstance(preview, dict):
                            self._saga_preview_ready = preview
                    updated = lookup(lambda: bool(self._closed), publish)
                else:
                    updated = lookup(lambda: bool(self._closed))
            except Exception as exc:
                print('[TiviMateE2] Saga background scan error: %s' % exc)
                updated = None
            # Only hand over plain data; the eTimer updates widgets on GUI.
            self._saga_enrichment_ready = updated
            self._saga_enrichment_done = True
        task = thread_factory(target=worker, name='TiviMateSagaEnrichment')
        task.daemon = True
        task.start()
        self._saga_enrichment_timer.start(250, True)

    def _poll_saga_enrichment(self):
        if self._closed:
            return
        preview = self._saga_preview_ready
        if isinstance(preview, dict):
            self._saga_preview_ready = None
            # First render all known TMDb parts with "Searching..." on their
            # own posters. A later callback fills provider matches in place.
            preview['current_tmdb_id'] = (self._saga.get('current_tmdb_id') or
                                          preview.get('current_tmdb_id') or '')
            self._saga_scan_pending = not self._saga_wait_expired
            self._apply_saga_enrichment(preview)
        if not self._saga_enrichment_done:
            # One slow provider batch can take ten seconds; several batches
            # used to leave "Searching" visible indefinitely.  Keep the
            # background worker alive for accurate results but release the
            # on-screen pending state after a bounded UI wait.
            if (not self._saga_wait_expired and
                    time.time() - self._saga_stage_started >= 12.0):
                self._saga_wait_expired = True
                self._saga_scan_pending = False
                self._saga_search_incomplete = True
                self._finish_saga_pending_labels()
            self._saga_enrichment_timer.start(250, True)
            return
        updated = self._saga_enrichment_ready
        self._saga_enrichment_ready = None
        self._saga_enrichment_done = False
        if not isinstance(updated, dict):
            self._saga_scan_pending = False
            self._saga_search_incomplete = True
            self._finish_saga_pending_labels()
            return
        if updated.get('error') == 'none' and not updated.get('parts'):
            # Keep the screen modal until the message box is closed.
            # Calling session.open() after self.close() crashes OpenATV 8.
            self._saga_report_no_parts(tr('This movie has no other parts.'))
            return
        if updated.get('error') and not updated.get('parts'):
            self._saga_report_no_parts(tr('No parts of this movie were found on this server.'))
            return
        # First callback resolves TMDb & RAM/disk only. It may hand back a
        # second worker for uncached enabled packages.  Launch it only after
        # showing the real collection timeline, never before session.open.
        next_lookup = updated.pop('_background_lookup', None)
        updated['current_tmdb_id'] = self._saga.get('current_tmdb_id') or updated.get('current_tmdb_id') or ''
        self._saga_scan_pending = callable(next_lookup)
        self._saga_search_incomplete = (not updated.get("complete", False) and
                                         not self._saga_scan_pending)
        if updated.get('parts'):
            self._apply_saga_enrichment(updated)
        else:
            self._finish_saga_pending_labels()
        if callable(next_lookup) and not self._closed:
            self._saga_background_lookup = next_lookup
            self._start_saga_enrichment()

    def _saga_close_after_notice(self, _answer=None):
        if not self._closed:
            self.close()

    def _saga_report_no_parts(self, message):
        # Enigma2 permits modal dialogs only while their parent is active.
        # An async TMDb callback can arrive after another screen was opened.
        if self._closed:
            return
        self._saga_scan_pending = False
        self._saga_enrichment_timer.stop()
        try:
            if getattr(self.session, 'current_dialog', None) is self:
                self.session.openWithCallback(self._saga_close_after_notice,
                                              MessageBox, message,
                                              MessageBox.TYPE_INFO, timeout=5)
                return
        except Exception as exc:
            print('[TiviMateE2] Saga notice unavailable: %s' % exc)
        # Never try to open from an inactive/non-modal screen.
        # Preserve a readable status; EXIT still returns to the previous page.
        try:
            self['status'].setText(message)
        except Exception:
            pass

    def _finish_saga_pending_labels(self):
        # No provider changes: do not cancel/reload six already-visible posters.
        for slot in range(PAGE):
            idx = self.page_start + slot
            if idx >= len(self.genre_items):
                continue
            item = self.genre_items[idx]
            if not isinstance(item, dict) or not item.get('_part_missing'):
                continue
            label = _t('SEARCH INCOMPLETE') if self._saga_search_incomplete else _t('NOT AVAILABLE')
            self['veilText%d' % slot].setText(label)
            self['meta%d' % slot].setText(label)
        selected = self._selected_item() or {}
        self['status'].setText((_t('SEARCH INCOMPLETE') if self._saga_search_incomplete else
                                _t('NOT AVAILABLE')) if selected.get('_part_missing') else '')

    def _apply_saga_enrichment(self, info):
        if self._closed:
            return
        cards = build_cards(info)
        if not cards:
            return
        old_parts = self._saga.get('parts') or []
        new_parts = info.get('parts') or []
        old_keys = [[_txt(r.get('stream_id') or r.get('vod_id') or r.get('id') or r.get('cmd') or '')
                     for r in (p.get('rows') or [])] for p in old_parts]
        new_keys = [[_txt(r.get('stream_id') or r.get('vod_id') or r.get('id') or r.get('cmd') or '')
                     for r in (p.get('rows') or [])] for p in new_parts]
        old_ids = [_txt(p.get('tmdb_id') or '') for p in old_parts]
        new_ids = [_txt(p.get('tmdb_id') or '') for p in new_parts]
        if old_keys == new_keys and old_ids == new_ids:
            self._saga = dict(info)
            self._saga_begin()
            # A cache-only pass may have found no new matches while the server
            # scan is still running. Keep every unresolved poster "Searching".
            if not self._saga_scan_pending:
                self._finish_saga_pending_labels()
            return
        selected = self._selected_item() or {}
        current_id = _txt(selected.get('_locked_tmdb_id') or '')
        previous_index = self.index
        self._cancel_poster_jobs()
        self._generation += 1
        self._rendered_page_key = None
        self._poster_tokens = {}
        self._poster_resolved_priority.clear()
        self._poster_tmdb_started.clear()
        self._saga = dict(info)
        self.source['_collection_parts_info'] = dict(info)
        self.source['_actor_search_rows'] = cards
        self._poster_original_rows = list(cards)
        self.genre_items = cards
        self.index = min(previous_index, len(cards) - 1)
        if current_id:
            for pos, card in enumerate(cards):
                if _txt(card.get('_locked_tmdb_id') or '') == current_id:
                    self.index = pos
                    break
        self._saga_begin()
        self.render()

    # ------------------------------------------------------ poster clearlogos
    def _close_part_logos(self):
        self._part_logo_tokens.clear()

    def _request_part_logos(self):
        if getattr(self, "_closed", True) or not self.genre_items:
            return
        try:
            from .title_logo_ultra_bridge import cached_identity_logo, resolve_title_logo
            from .tmdb_client import TMDbClient
        except Exception:
            return
        for slot in range(PAGE):
            index = self.page_start + slot
            if index >= len(self.genre_items):
                continue
            row = self.genre_items[index]
            if not isinstance(row, dict):
                continue
            from .poster_logo_identity import existing_id
            ident = existing_id(row)
            title = _txt(row.get("_part_title") or row.get("name") or row.get("title") or u"").strip()
            if not ident and not title:
                continue
            token = (self._generation, index, ident or title)
            if self._part_logo_tokens.get(slot) == token:
                continue
            self._part_logo_tokens[slot] = token
            cached = None
            try:
                if ident:
                    cached = cached_identity_logo(self.kind, ident, (LOGO_W, LOGO_H), title, row, row)
            except Exception:
                cached = None
            if cached and os.path.isfile(cached):
                self._show_part_logo(slot, token, cached)
                continue
            snapshot = dict(row)
            def worker(current_slot=slot, current_token=token, current_ident=ident, current_title=title, item=snapshot):
                try:
                    def obsolete():
                        return (getattr(self, "_closed", True) or
                                self._part_logo_tokens.get(current_slot) != current_token)
                    if obsolete():
                        return
                    client = TMDbClient()
                    verified_id = current_ident
                    if not verified_id and getattr(self, '_os_ready', False):
                        # Other Sources can omit TMDb IDs. Year-stamped names
                        # are matched by verified title AND release year,
                        # inside this worker, without blocking the screen.
                        from .poster_logo_identity import verified_search_id
                        verified_id = verified_search_id(client, current_title, item,
                                                         self.kind, obsolete)
                    if obsolete() or not verified_id:
                        return
                    image = resolve_title_logo(client, self.kind, verified_id,
                                               title=current_title, details=item, item=item,
                                               canvas=(LOGO_W, LOGO_H), cancelled=obsolete)
                    if image and not obsolete():
                        self._post_to_gui(self._show_part_logo, current_slot, current_token, image)
                except Exception:
                    pass
            thread = thread_factory(target=worker, name='TiviMatePartsLogo')
            thread.daemon = True
            thread.start()

    def _show_part_logo(self, slot, token, path):
        if (getattr(self, "_closed", True) or
                self._part_logo_tokens.get(slot) != token or
                not path or not os.path.isfile(path)):
            return
        widget = self["partLogo%d" % slot]
        try:
            from .transparent_pixmap import show_widget
            if show_widget(widget, path, align="center"):
                self["title%d" % slot].hide()
                return
        except Exception:
            pass
        try:
            widget.hide()
        except Exception:
            pass
        self["title%d" % slot].show()

    # -------------------------------------------------------- collection panel
    def _saga_begin(self):
        try:
            name = u" ".join(_txt(self._saga.get("name") or self.source.get("_actor_search_name") or u"").split())
            self["sagaName"].setText(_shorten(name, 44))
            parts = len(self._saga.get("parts") or [])
            have = len([p for p in (self._saga.get("parts") or []) if (p or {}).get("rows")])
            if self._saga.get('_saga_initial_pending'):
                self["sagaCount"].setText(tr('Searching...'))
            elif parts and have >= parts:
                self["sagaCount"].setText(_t("All %d parts on this server") % parts)
            elif parts:
                self["sagaCount"].setText(_t("%d of %d parts on this server") % (have, parts))
            self["heading"].setText(_t("MOVIE PARTS"))
        except Exception:
            pass

    # ------------------------------------------- GENRE behaviour not used here
    def _adjust_movie_logo_size(self):
        return

    def _load_provider_hero_info(self, item, token, kind):
        # A part the server lacks has no provider record to ask for.
        if isinstance(item, dict) and item.get("_part_missing"):
            return
        return StandaloneGenreScreen._load_provider_hero_info(self, item, token, kind)

    def _set_hero_logo_state(self, active):
        self._hero_logo_active = bool(active)
        try:
            if self._hero_logo_active:
                self["heroTitle"].setText("")
            else:
                self["heroTitle"].setText(visible_title(getattr(self, "_hero_plain_title", ""), 46))
        except Exception:
            pass

    def open_poster_server(self):
        return      # parts belong to the server they were found on

    def filter_poster_server(self):
        return

    def sort_posters(self):
        return      # release order only

    def _collection_favourite_item(self):
        """A single source-scoped poster tile opening this exact movie saga.

        Only whitelisted part/stream fields are saved, never the source config.
        The full ordered TMDb timeline (including unavailable parts) is kept,
        but existing server videos are still ordinary provider rows.
        """
        if getattr(self, '_PAGE_SOURCE_PREFIX', '') != 'collection_parts_':
            return None
        info = self._saga or {}
        parts = [p for p in (info.get('parts') or []) if isinstance(p, dict)]
        if (len(parts) < 2 or self._saga_scan_pending or
                info.get('_saga_initial_pending')):
            return None
        valid_ids = [_txt(p.get('tmdb_id') or p.get('id') or '').strip()
                     for p in parts]
        first_id = next((x for x in valid_ids if x), '')
        if not first_id:
            return None
        from .favorites import _snapshot
        safe_parts = []
        is_m3u = (self.source or {}).get('type') == 'm3u'
        for part in parts[:60]:
            entry = {}
            for key in ('tmdb_id', 'title', 'release_date', 'poster_path',
                        'backdrop_path', 'overview', 'vote'):
                value = part.get(key)
                if value is not None and not isinstance(value, (dict, list, tuple)):
                    entry[key] = _txt(value)
            entries = []
            for row in (part.get('rows') or [])[:5]:
                if not isinstance(row, dict):
                    continue
                safe = _snapshot(row)
                if not is_m3u:
                    safe.pop('url', None)
                entries.append(safe)
            entry['rows'] = entries
            safe_parts.append(entry)
        poster = _txt(info.get('poster_path') or '').strip()
        if not poster:
            poster = _txt(parts[0].get('poster_path') or '').strip()
        if poster.startswith('/'):
            poster = 'https://image.tmdb.org/t/p/w500' + poster
        backdrop = _txt(info.get('backdrop_path') or '').strip()
        if backdrop.startswith('/'):
            backdrop = 'https://image.tmdb.org/t/p/original' + backdrop
        name = _txt(info.get('name') or '').strip()
        if not name:
            name = _txt(parts[0].get('title') or _t('MOVIE COLLECTION'))
        saved_info = {
            'name': name,
            'poster_path': _txt(info.get('poster_path') or ''),
            'backdrop_path': _txt(info.get('backdrop_path') or ''),
            'overview': _txt(info.get('overview') or '')[:600],
            'current_tmdb_id': _txt(info.get('current_tmdb_id') or ''),
            'parts': safe_parts, 'complete': bool(info.get('complete')),
        }
        return {
            'id': 'tmdb-collection:' + first_id,
            'name': name, 'cover': poster, 'backdrop_path': backdrop,
            'description': _txt(info.get('overview') or '')[:600],
            '_movie_collection': '1',
            '_movie_collection_count': str(len(parts)),
            '_movie_collection_data': json.dumps(saved_info, ensure_ascii=False,
                                                 separators=(',', ':')),
        }

    def add_collection_to_favorites(self):
        """GREEN: add the whole franchise as ONE collection card in Favorites."""
        if getattr(self, '_PAGE_SOURCE_PREFIX', '') != 'collection_parts_':
            return
        item = self._collection_favourite_item()
        if not item:
            self['status'].setText(_t('Finish loading the movie series first.'))
            return
        try:
            from .favorites import is_favourite, add_favourite
            if is_favourite(self.source, 'vod', item):
                self['status'].setText(_t('Movie series already in favorites'))
            elif add_favourite(self.source, 'vod', item):
                self['status'].setText(_t('Movie series added to favorites'))
            else:
                self['status'].setText(_t('Unable to save movie series'))
        except Exception:
            self['status'].setText(_t('Unable to save movie series'))

    def add_selected_movie_to_favorites(self):
        """YELLOW: add only the highlighted, playable movie to Favorites."""
        if getattr(self, '_PAGE_SOURCE_PREFIX', '') != 'collection_parts_':
            return
        item = self._selected_item()
        if not item:
            self['status'].setText(_t('No movie selected'))
            return
        if item.get('_part_missing'):
            self['status'].setText(_t('SEARCH INCOMPLETE') if self._saga_search_incomplete else _t('NOT AVAILABLE'))
            return
        try:
            from .favorites import is_favourite, add_favourite
            if is_favourite(self.source, 'vod', item):
                self['status'].setText(_t('Selected movie already in favorites'))
            elif add_favourite(self.source, 'vod', item):
                self['status'].setText(_t('Selected movie added to favorites'))
            else:
                self['status'].setText(_t('Unable to save selected movie'))
        except Exception:
            self['status'].setText(_t('Unable to save selected movie'))

    def open_view_style_menu(self):
        # Other Sources also subclasses this view; its MENU stays unchanged.
        if getattr(self, '_PAGE_SOURCE_PREFIX', '') != 'collection_parts_':
            return
        item = self._collection_favourite_item()
        if not item:
            self['status'].setText(_t('Finish loading the movie series first.'))
            return
        try:
            from .favorites import is_favourite, add_favourite, remove_favourite
            if is_favourite(self.source, 'vod', item):
                success = remove_favourite(self.source, 'vod', item)
                message = _t('Movie series removed from favorites')
            else:
                success = add_favourite(self.source, 'vod', item)
                message = _t('Movie series added to favorites')
            self['status'].setText(message if success else _t('Unable to save movie series'))
        except Exception:
            self['status'].setText(_t('Unable to save movie series'))

    def _refreshFooterSortValue(self):
        return

    def _load_poster(self, slot, item, item_index):
        """TMDb collection poster first; avoid wrong provider covers in Saga.

        All provider stream IDs/URLs are preserved on the card for playback.
        Only the visual poster is selected from the verified part identity.
        """
        # Other Sources subclasses this screen but must keep the distinct
        # source-copy posters. The canonical TMDb poster rule is Saga ONLY.
        if getattr(self, '_PAGE_SOURCE_PREFIX', '') == 'other_sources_timeline_':
            return StandaloneGenreScreen._load_poster(self, slot, item, item_index)
        poster = _txt((item or {}).get('_tmdb_poster') or u'').strip()
        if not poster.startswith('/'):
            return StandaloneGenreScreen._load_poster(self, slot, item, item_index)
        from .poster_manager import tmdb_poster_url
        from .artwork_queue import cached_artwork
        from .genre_ultra_artwork import request as request_poster
        url = tmdb_poster_url(poster)
        if not url:
            return StandaloneGenreScreen._load_poster(self, slot, item, item_index)
        token = '%d:%d:part:%s' % (self._generation, item_index, poster)
        self._poster_tokens[slot] = token
        snapshot = dict(item or {})
        def ready(path, current_slot=slot, expected=token, row=snapshot):
            self._post_to_gui(self._decode_poster, current_slot, path, expected,
                              row, 'tmdb', url)
        def failed(_path, current_slot=slot, expected=token):
            self._post_to_gui(self._keep_default_poster, current_slot, expected)
        hit = cached_artwork(url, 'posters')
        if hit and os.path.isfile(hit):
            self._decode_poster(slot, hit, token, snapshot, 'tmdb', url)
        else:
            try:
                request_poster(url, 'posters', dict(self.source or {}),
                               ready, failed, self._post_to_gui)
            except Exception:
                failed(None)

    # ------------------------------------------------------------- hero text
    def _set_hero_text(self, info):
        StandaloneGenreScreen._set_hero_text(self, info)
        badges = {}
        item = self._selected_item() or {}
        try:
            sources = getattr(self, "_hero_text_sources", {}) or {}
            provider = sources.get("provider") or {}
            catalog = sources.get("catalog") or {}
            verified = sources.get("tmdb_verified") or {}
            tmdb = sources.get("tmdb") or {}
            year_value, _genres = _year_genre_from_sources([info, provider, item, catalog])
            ordered = (provider, item, verified, tmdb, catalog)
            badges = {
                "genreYear": year_value or str(info.get("year") or "").strip()[:4],
                "genreCategories": _actual_media_genre(verified, tmdb, sources.get("tmdb_search") or {},
                                                       provider, info, item, catalog),
                "genreRating": _genre_pill_score(extract_rating(info, verified, tmdb, item)),
                "genreDuration": extract_duration(info, provider, item, catalog),
                "genreLanguage": _genre_pill_language(*ordered),
                "genreAge": _genre_pill_age(*ordered),
                # Stream quality only for a copy the server really has.
                "genreQuality": "" if item.get("_part_missing") else extract_resolution(item, catalog, provider),
            }
        except Exception:
            badges = {}
        self._render_genre_metadata_pills(badges)
        try:
            self["heroMeta"].setText("")
            plot = info.get("description") or item.get("plot") or ""
            self["heroPlot"].setText(_shorten(plot, 250))
            self._story_reapply()
        except Exception:
            pass

    def _render_genre_metadata_pills(self, values):
        xpos = PILL_X
        for name, width, inset, _style in GENRE_PILL_SPECS:
            text = _txt((values or {}).get(name) or u"").strip()
            if name == "genreCategories" and len(text) > 30:
                text = text[:28].rstrip(u" ,،") + u"…"
            widget = self[name]
            background = self[name + "Bg"]
            widget.setText(text)
            if not text or xpos + width > PILL_LIMIT:
                widget.hide()
                background.hide()
                continue
            try:
                background.instance.move(ePoint(sx(xpos), sy(PILL_Y)))
                widget.instance.move(ePoint(sx(xpos + inset), sy(PILL_Y)))
                background.show()
                widget.show()
            except Exception:
                widget.hide()
                background.hide()
                continue
            xpos += width + 8

    # ------------------------------------------------------------------ grid
    def _set_placeholder(self, slot):
        # Best-effort placeholder; never fail the screen on old VTi.  The
        # real poster is still loaded by the existing GENRE/Saga pipeline.
        candidates = (PLACEHOLDER,
                      os.path.join(PLUGIN_PATH, 'skins', 'movies',
                                   'apple_saga_placeholder.png'))
        for candidate in candidates:
            if not os.path.isfile(candidate):
                continue
            try:
                widget = self["poster%d" % slot]
                if widget.instance:
                    widget.instance.setPixmapFromFile(candidate)
                    return
            except Exception:
                continue

    def _hide_slot(self, slot):
        for name in ("poster", "shell", "chip", "dot", "veil"):
            self["%s%d" % (name, slot)].hide()
        for name in ("title", "meta", "chipText", "veilText", "nowFlag"):
            self["%s%d" % (name, slot)].setText("")
        self["nowFlag%d" % slot].hide()
        self["sagaRibbon%d" % slot].hide()

    def _render_empty(self, message):
        try:
            self._hero_timer.stop()
        except Exception:
            pass
        self._hero_token = None
        self._hero_text_token = None
        self._hero_text_sources = {}
        self._hero_plain_title = ""
        self._hero_logo_active = False
        self["page"].setText("1 / 1")
        self["status"].setText(message)
        self["heroTitle"].setText("")
        self["heroMeta"].setText("")
        self["heroPlot"].setText("")
        self["partBig"].setText("")
        for name, _width, _inset, _style in GENRE_PILL_SPECS:
            self[name].setText("")
            self[name].hide()
            self[name + "Bg"].hide()
        self._rendered_page_key = None
        for slot in range(BASE_SLOTS):
            self["title%d" % slot].setText("")
            self["meta%d" % slot].setText("")
            self["partLogo%d" % slot].hide()
            self["title%d" % slot].show()
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        for slot in range(PAGE):
            self._hide_slot(slot)
        for name in ("selector", "chipFocus", "dotFocus", "timeline"):
            try:
                self[name].hide()
            except Exception:
                pass
        self["chipFocusText"].setText("")

    def _card_meta(self, item):
        if item.get("_part_missing"):
            return (tr("Searching...") if self._saga_scan_pending else
                    (_t("SEARCH INCOMPLETE") if self._saga_search_incomplete else _t("NOT AVAILABLE")))
        parts = []
        if item.get("_part_year"):
            parts.append(item["_part_year"])
        rating = _txt(item.get("rating") or item.get("rating_5based") or item.get("vote_average") or u"").strip()
        if rating and rating not in ("0", "0.0"):
            parts.append(u"★ " + rating[:3])
        return u" · ".join(parts)

    def _move(self, name, x, y):
        try:
            self[name].instance.move(ePoint(sx(x), sy(y)))
        except Exception:
            pass

    def _layout_page(self, count):
        """Centre this page's cards and stretch the timeline between them."""
        xs = card_positions(count)
        for slot, x in enumerate(xs):
            self._move("chip%d" % slot, x + 5, CHIP_Y)
            self._move("chipText%d" % slot, x + 5, CHIP_Y)
            self._move("dot%d" % slot, x + (POSTER_W - DOT) // 2, LINE_Y - DOT // 2)
            self._move("poster%d" % slot, x, POSTER_Y)
            self._move("veil%d" % slot, x, POSTER_Y)
            self._move("veilText%d" % slot, x + 10, POSTER_Y + POSTER_H // 2 + 16)
            self._move("shell%d" % slot, x, POSTER_Y)
            self._move("nowFlag%d" % slot, x + 24, POSTER_Y + 10)
            self._move("sagaRibbon%d" % slot, x, POSTER_Y)
            self._move("title%d" % slot, x - 20, POSTER_Y + POSTER_H + 8)
            self._move("partLogo%d" % slot, x - 20, POSTER_Y + POSTER_H + 8)
            self._move("meta%d" % slot, x - 20, POSTER_Y + POSTER_H + 44)
        try:
            line = self["timeline"]
            if count > 1 or self._pages() > 1:
                # Past the outer cards: the saga continues on other pages.
                start = xs[0] + POSTER_W // 2 - (POSTER_W // 2 + 40 if self.page_start else 0)
                end = xs[-1] + POSTER_W // 2 + (POSTER_W // 2 + 40 if self.page_start + count < len(self.genre_items) else 0)
                line.instance.move(ePoint(sx(start), sy(LINE_Y - 1)))
                line.instance.resize(eSize(sx(max(2, end - start)), max(2, sy(2))))
                line.show()
            else:
                line.hide()
        except Exception:
            pass
        return xs

    def _pages(self):
        return max(1, (len(self.genre_items) + PAGE - 1) // PAGE)

    def render(self):
        total = len(self.genre_items)
        self.page_start = (self.index // PAGE) * PAGE if total else 0
        count = min(PAGE, total - self.page_start) if total else 0
        self["heading"].setText(_t("MOVIE PARTS"))
        self["page"].setText("%d / %d" % (self.page_start // PAGE + 1, self._pages()))
        selected = self._selected_item() or {}
        self._schedule_hero()
        self._update_hero_info(self._hero_token, {
            "title": _txt(selected.get("_part_title") or selected.get("name") or selected.get("title") or u""),
            "year": _txt(selected.get("_part_year") or selected.get("year") or u"")[:4],
            "rating": _txt(selected.get("rating") or selected.get("vote_average") or u""),
            "description": _txt(selected.get("plot") or selected.get("description") or
                                selected.get("overview") or u"").strip(),
            "category": "",
        }, "catalog")
        self._story_prepare(selected, kind="vod", limit=250)
        number = int(selected.get("_part_number") or (self.index + 1)) if total else 0
        self["partBig"].setText((_t("PART %d OF %d") % (number, total)) if total else "")
        missing_message = (tr("Searching...") if self._saga_scan_pending else
                           (_t("SEARCH INCOMPLETE") if self._saga_search_incomplete else _t("NOT AVAILABLE")))
        self["status"].setText(missing_message if selected.get("_part_missing") else "")

        page_key = (self._generation, self.page_start, total)
        if page_key != self._rendered_page_key:
            self._cancel_poster_jobs()
            self._rendered_page_key = page_key
            self._poster_resolved_priority.clear()
            self._poster_tmdb_started.clear()
            self._saga_xs = self._layout_page(count)
            for slot in range(PAGE):
                item_index = self.page_start + slot
                item = self.genre_items[item_index] if item_index < total else None
                if not isinstance(item, dict):
                    self._poster_tokens.pop(slot, None)
                    self["partLogo%d" % slot].hide()
                    self["title%d" % slot].show()
                    self._hide_slot(slot)
                    continue
                missing = bool(item.get("_part_missing"))
                self["chipText%d" % slot].setText(_t("Part %d") % int(item.get("_part_number") or item_index + 1))
                self["partLogo%d" % slot].hide()
                self["title%d" % slot].show()
                self["title%d" % slot].setText(
                    visible_title(_txt(item.get("_part_title") or item.get("name") or item.get("title") or u""), 20))
                self["meta%d" % slot].setText(self._card_meta(item))
                self["veilText%d" % slot].setText((tr("Searching...") if self._saga_scan_pending else
                                                    (_t("SEARCH INCOMPLETE") if self._saga_search_incomplete else _t("NOT AVAILABLE"))) if missing else "")
                # The localized corner ribbon replaces the old flat NOW VIEWING label.
                self["nowFlag%d" % slot].setText("")
                for name in ("poster", "shell", "chip", "dot"):
                    self["%s%d" % (name, slot)].show()
                if missing:
                    self["veil%d" % slot].show()
                else:
                    self["veil%d" % slot].hide()
                self._set_placeholder(slot)
                self._load_poster(slot, item, item_index)
            self._request_part_logos()

        if total:
            slot = self.index - self.page_start
            xs = getattr(self, "_saga_xs", None) or card_positions(count)
            x = xs[min(slot, len(xs) - 1)]
            self._move("selector", x - FOCUS_PAD, POSTER_Y - FOCUS_PAD)
            self._move("chipFocus", x + 5, CHIP_Y)
            self._move("chipFocusText", x + 5, CHIP_Y)
            self._move("dotFocus", x + (POSTER_W - DOT_FOCUS) // 2, LINE_Y - DOT_FOCUS // 2)
            self["chipFocusText"].setText(self["chipText%d" % slot].getText())
            for other in range(PAGE):
                if other == slot:
                    self["chipText%d" % other].hide()
                else:
                    self["chipText%d" % other].show()
            for name in ("selector", "chipFocus", "dotFocus"):
                self[name].show()
        else:
            for name in ("selector", "chipFocus", "dotFocus"):
                self[name].hide()
            self["chipFocusText"].setText("")

        self._saga_update_ribbons()

    # ------------------------------------------------------------ navigation
    def left(self):
        if self.genre_items and self.index > 0:
            self.index -= 1
            self.render()

    def right(self):
        if self.genre_items and self.index + 1 < len(self.genre_items):
            self.index += 1
            self.render()

    def up(self):
        return

    def down(self):
        return

    def page_up(self):
        if self.genre_items and self.index >= PAGE:
            self.index = (self.index // PAGE - 1) * PAGE
            self.render()

    def page_down(self):
        if not self.genre_items:
            return
        last = len(self.genre_items) - 1
        if self.index // PAGE < last // PAGE:
            self.index = min(last, (self.index // PAGE + 1) * PAGE)
            self.render()

    def previous_genre(self):
        return self.page_up()

    def next_genre(self):
        return self.page_down()

    # --------------------------------------------------------------- actions
    def _available_items(self):
        return [row for row in self.genre_items if isinstance(row, dict) and not row.get("_part_missing")]

    def toggle_favorite(self):
        item = self._selected_item() or {}
        if item.get("_part_missing"):
            self["status"].setText(_t("SEARCH INCOMPLETE") if self._saga_search_incomplete else _t("NOT AVAILABLE"))
            return
        return StandaloneGenreScreen.toggle_favorite(self)

    def open_selected(self):
        item = self._selected_item()
        if not item:
            return
        if item.get("_part_missing"):
            if self._saga_scan_pending:
                self["status"].setText(tr("Searching..."))
                return
            if self._saga_search_incomplete:
                self["status"].setText(_t("SEARCH INCOMPLETE"))
                return
            self.session.open(MessageBox, _t("This part is not available on this server."),
                              MessageBox.TYPE_INFO, timeout=4)
            return
        # Details must only ever see rows the server really has: a TMDb-only
        # card must never be taken for a playable server copy.
        everything = self.genre_items
        self.genre_items = self._available_items()
        try:
            self.index = self.genre_items.index(item)
        except ValueError:
            self.index = 0
        try:
            StandaloneGenreScreen.open_selected(self)
        finally:
            self.genre_items = everything
            try:
                self.index = everything.index(item)
            except ValueError:
                pass


def open_collection_parts(session, source, info):
    """Open the Saga page; False when there is nothing to show."""
    cards = build_cards(info)
    # Allow a fast TMDb timeline while missing provider parts are resolved
    # asynchronously. Without an active search, preserve old empty behaviour.
    if not cards or (not any(not c.get("_part_missing") for c in cards)
                     and not callable((info or {}).get('_background_lookup'))):
        return False
    view_source = dict(source or {})
    for key in ("_actor_search_person", "_view_style_override"):
        view_source.pop(key, None)
    view_source["_actor_search_rows"] = cards
    view_source["_actor_search_name"] = (info or {}).get("name") or tr("Movie Series")
    view_source["_view_picker_context"] = "collection"
    view_source["_collection_parts_info"] = dict(info or {})
    # VTi 15 can leave the parent dialog suspended if its screen builder
    # fails. Never fall through to the actor-results page on such a failure.
    from .vti_compat import safe_open_screen
    return safe_open_screen(session, None, CollectionPartsScreen,
                            view_source, "vod", "") is not None
