# -*- coding: utf-8 -*-
from .pink_rating import show_pink_rating
from .country_flags import show_country_flag
from .storage import get_data_root, data_path, favorites_path
from .finder_playlist_storage import finder_playlist_path, finder_identity_url
from .episode_still_index import episode_still_index_lookup, episode_still_index_save
from .genre_images import saved_genre_image, save_genre_image
from .genre_package_badges import resolve_package_badge
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode, urlparse, quote
import uuid

from .compat import atomic_replace, ensure_dir, open_text, python_command

import os
import sys
import tempfile
import hashlib
import json
import gzip
import base64
import threading
import time
import re
from datetime import datetime, timedelta

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Screens.InfoBar import MoviePlayer
try:
    from Screens.AudioSelection import AudioSelection
except Exception:
    AudioSelection = None
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText as _EnigmaMultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from .py27_compat import gui_text, text_type
from .py27_compat import wrap_choicebox as _wrap_choicebox
ChoiceBox = _wrap_choicebox(ChoiceBox)

def _live_classic_row_label(number, channel_name, favourite=False):
    """Build *Unicode* before crossing the Enigma2 Python2 display boundary.

    Some Arabic channel names are unicode while the favourite star is a UTF-8
    source byte literal.  Python2 tries to decode those bytes as ASCII when
    interpolating them; the crash happens before Py27TextMenuList.setList().
    Keeping this conversion here also handles legacy CP1256 provider names.
    """
    try:
        name = text_type(channel_name if channel_name is not None else u'')
    except (UnicodeError, TypeError, ValueError):
        name = u''
    name = name.strip() or u'Unnamed Channel'
    try:
        label_number = text_type(number)
    except (UnicodeError, TypeError, ValueError):
        label_number = u''
    return u'%s   %s%s' % (label_number, u'★  ' if favourite else u'', name)


class Py27TextMenuList(MenuList):
    """UTF-8 labels for legacy Enigma2 menus, leave provider rows untouched."""
    def setList(self, entries):
        fixed = []
        for entry in (entries or []):
            if isinstance(entry, (tuple, list)) and entry:
                fixed.append((gui_text(entry[0]),) + tuple(entry[1:]))
            elif isinstance(entry, (str, unicode)):
                fixed.append(gui_text(entry))
            else:
                fixed.append(entry)
        return MenuList.setList(self, fixed)


def MultiContentEntryText(*args, **kwargs):
    """Python 2.7 DreamOS renderer accepts UTF-8 byte labels, not unicode.

    Scoped to this plugin's UI source fragments; no global Enigma2 patches.
    """
    if 'text' in kwargs:
        kwargs['text'] = gui_text(kwargs['text'])
    return _EnigmaMultiContentEntryText(*args, **kwargs)

from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from .rtl_text import DirectionalLabel, SynopsisLabel, AdaptiveOverviewLabel, CenteredArabicMetadataLabel, RisingOverviewLabel
from .display_titles import clean_display_title, visible_title
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
try:
    from Components.VideoWindow import VideoWindow
except Exception:
    VideoWindow = None
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigText, ConfigPassword, ConfigSelection, ConfigYesNo, getConfigListEntry, config, configfile
from enigma import (eServiceReference, ePicLoad, eTimer, eConsoleAppContainer, ePoint,
    eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER, eEPGCache, eSize)
from .alpha_picload import ePicLoad  # same PNG-alpha renderer as Python 3
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from .live_service import live_reference, live_reference_string, epg_reference_string
from .live_package_icons import package_country, package_kind, package_special_icon, package_visual, fetch_flag
from .epg_local import lookup_channel_epg, load_source_epg, refresh_source_epg, ensure_source_epg
try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .metadata_display import merge_metadata, provider_cache_key, keep_arabic_on_late_update, contains_arabic_text
from .poster_manager import usable_poster_file
from .content_home import ContentHomeScreen, FastMoviesContentScreen, FastSeriesContentScreen, MovieDetailsScreen, warm_backdrop_metadata_from_home, _server_poster_url, _server_asset_url
from .banner_artwork import read_key as read_fanart_banner_key, save_key as save_fanart_banner_key

HOME_TMDb_CACHE_FILE = data_path("home_tmdb_cache.json")
_HOME_TMDb_CACHE_LOCK = threading.Lock()

# ---------------------------------------------------------------------------
# TiviMateE2 UI source layout
#
# The large UI implementation is split into ordered source fragments under
# _ui_parts/. They are executed in this module namespace so existing imports
# from .ui keep the same public API and class globals without circular imports.
# ---------------------------------------------------------------------------
def _load_ui_part(filename):
    path = os.path.join(os.path.dirname(__file__), "_ui_parts", filename)
    # Compilation is warmed after Enigma2 session start, off the GUI thread.
    # If the warmup is not ready (or a source file changed), fall back to the
    # original trusted-source compiler, with identical execution semantics.
    from .ui_preload import get_compiled_part
    eval(get_compiled_part(path), globals(), globals())


_UI_PARTS = (
    "01_common_and_skins.py",
    "02_editors_and_tmdb.py",
    "03_packages_and_settings.py",
    "04_server_manager.py",
    "05_search_home_continue.py",
    "06_series_details.py",
    "07_media_and_favorites.py",
)

for _ui_part in _UI_PARTS:
    _load_ui_part(_ui_part)

# Warming is for first paint only. Avoid retaining ~36k lines of bytecode in
# duplicate memory after the UI has loaded.
from .ui_preload import release as _release_warmed_ui
_release_warmed_ui()
del _release_warmed_ui
del _ui_part

# Ultra-style user-selectable typography. Apply once to plugin-owned skins only;
# Enigma2 system skins and subtitle font settings remain untouched.
from .font_preferences import apply_module_screens as _apply_font_screens
_apply_font_screens(globals(), Screen)
del _apply_font_screens
