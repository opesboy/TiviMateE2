# -*- coding: utf-8 -*-
"""Cinema-grade Other Sources chooser, matching the Movie Parts timeline.

All poster/backdrop/logo loading is delegated to the existing GENRE/Saga
pipeline. This module never calls the provider or TMDb itself and keeps the
original provider rows intact for MovieDetailsScreen.playItem.
"""

import os
from Components.Pixmap import Pixmap
from enigma import ePoint
from .display_scale import sx, sy
from .collection_parts import (CollectionPartsScreen, build_skin, build_cards, card_positions,
                               POSTER_Y, PAGE)
from .genre_page import StandaloneGenreScreen
from .resolution_badge import extract_resolution
from .display_titles import visible_title
from .i18n import tr, tr_text, get_language


def _text(value):
    try:
        from .py27_compat import text_type
        return text_type(value or u'')
    except Exception:
        try:
            return str(value or '')
        except Exception:
            return u''


_PHRASES = {
    'en': {'tag': 'AVAILABLE VERSIONS', 'heading': 'OTHER SOURCES',
           'count': '%d versions available', 'version': 'VERSION %d OF %d',
           'current': 'CURRENT VERSION', 'play': 'Play this version',
           'back': 'Back', 'next': 'Next page', 'favorite': 'Hold: Favorite',
           'copy': 'Copy %d'},
    'ar': {'tag': u'النسخ المتوفرة', 'heading': u'مصادر أخرى',
           'count': u'%d نسخ متوفرة', 'version': u'النسخة %d من %d',
           'current': u'النسخة الحالية', 'play': u'تشغيل النسخة',
           'back': u'رجوع', 'next': u'الصفحة التالية', 'favorite': u'مطوّل: المفضلة',
           'copy': u'نسخة %d'},
    'fr': {'tag': 'VERSIONS DISPONIBLES', 'heading': 'AUTRES SOURCES',
           'count': '%d versions disponibles', 'version': 'VERSION %d SUR %d',
           'current': 'VERSION ACTUELLE', 'play': 'Lire cette version',
           'back': 'Retour', 'next': 'Page suivante', 'favorite': 'Appui long : Favori',
           'copy': 'Copie %d'},
    'tr': {'tag': 'MEVCUT SÜRÜMLER', 'heading': 'DİĞER KAYNAKLAR',
           'count': '%d sürüm mevcut', 'version': 'SÜRÜM %d / %d',
           'current': 'MEVCUT SÜRÜM', 'play': 'Bu sürümü oynat',
           'back': 'Geri', 'next': 'Sonraki sayfa', 'favorite': 'Uzun bas: Favori',
           'copy': '%d. Kopya'},
}


def _phrase(key):
    try:
        lang = _text(get_language() or 'en').lower()[:2]
    except Exception:
        lang = 'en'
    if lang in _PHRASES:
        return _PHRASES[lang][key]
    return tr_text(_PHRASES['en'][key])


def _quality(item):
    try:
        return _text(extract_resolution(item) or '').upper().strip()
    except Exception:
        return ''


def _quality_rank(item):
    quality = _quality(item)
    if '8K' in quality or '4320' in quality:
        return 5
    if '4K' in quality or 'UHD' in quality or '2160' in quality:
        return 4
    if '1080' in quality or 'FHD' in quality:
        return 3
    if '720' in quality or 'HD' in quality:
        return 2
    if quality:
        return 1
    return 0


def prepare_sources(rows, selected_item=None):
    """Return the original provider rows and a separately enriched poster view.

    This function never alters stream IDs, auth tokens or playback URLs.
    Current source first; remaining copies ordered by known resolution.
    """
    original = [dict(r) for r in (rows or []) if isinstance(r, dict)]
    current = [r for r in original if r.get('_other_sources_current')]
    remaining = [r for r in original if not r.get('_other_sources_current')]
    # Stable sort: identical qualities remain in server order.
    remaining.sort(key=_quality_rank, reverse=True)
    ordered = current + remaining
    item = dict(selected_item or {})
    fallback_keys = ('tmdb_id', 'backdrop_path', 'poster_path', 'stream_icon',
                     'cover', 'plot', 'description', 'year', 'rating', 'logo')
    parts = []
    for n, row in enumerate(ordered, 1):
        art_row = dict(row)
        for key in fallback_keys:
            if not art_row.get(key) and item.get(key):
                art_row[key] = item[key]
        art_row['_os_index'] = n - 1
        art_row['_os_quality'] = _quality(row)
        art_row['_os_current'] = bool(row.get('_other_sources_current'))
        # CollectionPartsScreen requires a separately matched provider row.
        parts.append({'title': art_row.get('name') or art_row.get('title') or
                               item.get('name') or item.get('title') or '',
                      'release_date': '', 'rows': [art_row]})
    info = {'name': item.get('name') or item.get('title') or
                    (ordered[0].get('name') or ordered[0].get('title') if ordered else '') or '',
            'parts': parts, 'rows': [], 'complete': True,
            'overview': item.get('plot') or item.get('description') or '',
            'current_tmdb_id': ''}
    cards = build_cards(info)
    for n, card in enumerate(cards):
        card['_part_current'] = bool(ordered[n].get('_other_sources_current'))
        card['_os_quality'] = _quality(ordered[n])
        card['_os_index'] = n
    return ordered, info, cards


# Dedicated skin override for the Other Sources chooser only.  Saga itself
# remains untouched. The original nowFlag Label stays present for its base
# class, but is visually replaced with a transparent diagonal corner ribbon.
_OS_RIBBON_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'skins', 'saga')
# The original Arabic graphic keeps its exact r206 appearance.
_OS_RIBBONS = {'ar': 'saga_current_ribbon.png', 'en': 'saga_current_ribbon_en.png',
               'fr': 'saga_current_ribbon_fr.png', 'tr': 'saga_current_ribbon_tr.png'}
_OS_RIBBON = os.path.join(_OS_RIBBON_DIR, 'saga_current_ribbon_en.png')


def _os_local_ribbon():
    lang = _text(get_language() or 'en').lower()[:2]
    return os.path.join(_OS_RIBBON_DIR, _OS_RIBBONS.get(lang, _OS_RIBBONS['en']))
_OS_RIBBON_W = 146
_OS_RIBBON_H = 146


def _build_other_sources_skin():
    skin = build_skin(collection_buttons=False)
    overlays = []
    for slot, x in enumerate(card_positions(PAGE)):
        overlays.append(
            '<widget name="osRibbon%d" position="%d,%d" size="%d,%d" '
            'pixmap="%s" alphatest="blend" scale="1" zPosition="16" />' % (
                slot, sx(x), sy(POSTER_Y), sx(_OS_RIBBON_W), sy(_OS_RIBBON_H),
                _OS_RIBBON))
    return skin.replace('</screen>', '\n'.join(overlays) + '\n</screen>', 1)


class OtherSourcesTimelineScreen(CollectionPartsScreen):
    """An exact-copy chooser on the established golden Saga layout."""

    _PAGE_SOURCE_PREFIX = 'other_sources_timeline_'
    skin = _build_other_sources_skin()

    def __init__(self, session, source, initial_kind='vod', initial_category_id=''):
        # The GENRE constructor renders once before Saga widgets are created.
        # The guards below keep this initial render on the safe base path.
        self._os_ready = False
        CollectionPartsScreen.__init__(self, session, source, 'vod', '')
        self._os_original = [dict(r) for r in self.source.get('_os_original_rows') or []]
        for slot in range(PAGE):
            self['osRibbon%d' % slot] = Pixmap()
            self['osRibbon%d' % slot].hide()
        self._os_ribbon_file = None
        self.onLayoutFinish.append(self._os_update_ribbons)
        self._os_ready = True
        cards = build_cards(self._saga)
        for n, card in enumerate(cards):
            if n < len(self._os_original):
                card['_os_index'] = n
                card['_os_quality'] = _quality(self._os_original[n])
                card['_part_current'] = bool(self._os_original[n].get('_other_sources_current'))
        self._poster_original_rows = cards
        self.genre_items = cards
        self._poster_sort_mode = 'default'
        self.index = next((n for n, c in enumerate(cards) if c.get('_part_current')), 0)
        self._rendered_page_key = None
        self['sagaTag'].setText(_phrase('tag'))
        self['legendRed'].setText(_phrase('back'))
        self['legendBlue'].setText(_phrase('next'))
        self['legendOk'].setText(_phrase('play'))
        self['legendYellow'].setText(_phrase('favorite'))
        self['legendExit'].setText(_phrase('back'))
        self.render()

    def _render_empty(self, message):
        if not getattr(self, '_os_ready', False):
            return StandaloneGenreScreen._render_empty(self, message)
        result = CollectionPartsScreen._render_empty(self, message)
        for slot in range(PAGE):
            self['osRibbon%d' % slot].hide()
        return result

    def _os_update_ribbons(self):
        """Keep the ribbon fixed to the current poster on every page.

        The ribbon is a local transparent PNG, not an altered poster bitmap;
        displaying it never changes the shared artwork cache or queues.
        """
        if not getattr(self, '_os_ready', False):
            return
        # Choose the correct pre-rendered language ribbon. Only loaded on
        # language change, never in a poster download or image-decode worker.
        ribbon_file = _os_local_ribbon()
        if ribbon_file != self._os_ribbon_file:
            loaded = True
            for slot in range(PAGE):
                instance = self['osRibbon%d' % slot].instance
                if instance is None:
                    loaded = False
                    continue
                instance.setPixmapFromFile(ribbon_file)
            if loaded:
                self._os_ribbon_file = ribbon_file
        count = max(0, min(PAGE, len(self.genre_items) - self.page_start))
        xs = card_positions(count) if count else []
        for slot in range(PAGE):
            widget = self['osRibbon%d' % slot]
            # The unmodified Saga component may still show its old label.
            self['nowFlag%d' % slot].hide()
            self['sagaRibbon%d' % slot].hide()
            if slot >= count or not self.genre_items[self.page_start + slot].get('_part_current'):
                widget.hide()
                continue
            if widget.instance is None:
                # Avoid momentary incorrect positioning before onLayoutFinish.
                widget.hide()
                continue
            widget.instance.move(ePoint(sx(xs[slot]), sy(POSTER_Y)))
            widget.show()

    def _saga_begin(self):
        if not getattr(self, '_os_ready', False):
            return
        self['sagaTag'].setText(_phrase('tag'))
        self['sagaName'].setText(visible_title(_text(self._saga.get('name') or ''), 46))
        self['sagaCount'].setText(_phrase('count') % len(self.genre_items))
        self['heading'].setText(_phrase('heading'))

    def _card_meta(self, item):
        quality = _text(item.get('_os_quality') or '')
        extension = _text(item.get('container_extension') or '').upper().strip('.')
        tags = [value for value in (quality, extension) if value]
        return u'  ·  '.join(tags) or _phrase('copy') % (int(item.get('_os_index') or 0) + 1)

    def render(self):
        if not getattr(self, '_os_ready', False):
            return StandaloneGenreScreen.render(self)
        CollectionPartsScreen.render(self)
        self['heading'].setText(_phrase('heading'))
        self['sagaTag'].setText(_phrase('tag'))
        self['sagaCount'].setText(_phrase('count') % len(self.genre_items))
        if self.genre_items:
            self['partBig'].setText((_phrase('version') % (self.index + 1, len(self.genre_items))) + (u'  ·  ' + _text(self.genre_items[self.index].get('_os_quality')) if self.genre_items[self.index].get('_os_quality') else u''))
        for slot in range(PAGE):
            pos = self.page_start + slot
            if pos >= len(self.genre_items):
                continue
            card = self.genre_items[pos]
            quality = _text(card.get('_os_quality') or '')
            chip = (quality + u'  ·  %02d' % (pos + 1)) if quality else (_phrase('copy') % (pos + 1))
            self['chipText%d' % slot].setText(chip)
            self['title%d' % slot].setText(visible_title(
                _text(card.get('name') or card.get('title') or ''), 21))
            # Keep the old Label empty; the corner ribbon marks the current copy.
            self['nowFlag%d' % slot].setText('')
        slot = self.index - self.page_start
        if 0 <= slot < PAGE:
            self['chipFocusText'].setText(self['chipText%d' % slot].getText())
        self._os_update_ribbons()

    def open_selected(self):
        if self._closed:
            return
        index = int(self.index)
        if 0 <= index < len(self._os_original):
            # Return the raw provider copy to the existing playback callback.
            self.close(dict(self._os_original[index]))


def open_other_sources(session, source, rows, movie=None, selected_callback=None):
    ordered, info, cards = prepare_sources(rows, movie)
    if not cards:
        return False
    view_source = dict(source or {})
    view_source.pop('_actor_search_person', None)
    view_source['_actor_search_name'] = info.get('name') or tr('Other Sources')
    view_source['_actor_search_rows'] = cards
    view_source['_collection_parts_info'] = info
    view_source['_os_original_rows'] = ordered
    view_source['_view_picker_context'] = 'other_sources'
    if selected_callback is None:
        session.open(OtherSourcesTimelineScreen, view_source, 'vod', '')
    else:
        session.openWithCallback(selected_callback, OtherSourcesTimelineScreen,
                                 view_source, 'vod', '')
    return True
