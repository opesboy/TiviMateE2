# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch
import io
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace, monotonic, thread_factory, thread_ident
"""Standalone GENRE poster browser.

This module deliberately owns its screen, skin, category routing and poster grid.
It does not modify or reuse the original Packages / Movies / TV Shows screen
classes.  A small installer below redirects the existing GENRE selector to this
independent screen after the normal UI module has loaded.
"""

import os
import re
import random
import threading
import time
from Plugins.Extensions.TiviMateE2Py27.py27_futures import ThreadPoolExecutor
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit

# Shared bounded fallback lookup pool. Never spawn a thread per missing poster.
_GENRE_POSTER_POOL = ThreadPoolExecutor(max_workers=3, thread_name_prefix="TiviGenrePoster")
# A separate small pool checks downloaded/provider-cached images off the GUI
# thread. Never make ePicLoad/selection wait for pixel inspection.
_GENRE_PROVIDER_CHECK_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviGenreImageCheck")
# A thin catalogue record can omit artwork that is present in vod_info or
# series_info. Only visible blank/failed posters use this bounded pool.
_GENRE_PROVIDER_DETAIL_POOL = ThreadPoolExecutor(max_workers=3, thread_name_prefix="TiviGenreProviderArt")
_GENRE_PROVIDER_DETAIL_CACHE = {}
_GENRE_PROVIDER_DETAIL_LOCK = threading.RLock()
_GENRE_POSTER_PENDING = threading.BoundedSemaphore(25)
_GENRE_POSTER_LOOKUP = {}
_GENRE_POSTER_LOCK = threading.RLock()
_GENRE_PROVIDER_SLATE_CACHE = {}

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from .rtl_text import DirectionalLabel, SynopsisLabel, CenteredArabicMetadataLabel, has_arabic_text
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer, ePicLoad, eSize
from .alpha_picload import ePicLoad  # same PNG-alpha renderer as Python 3

from .py27_compat import text_type, gui_text
from .artwork_queue import cached_artwork, provider_asset_url, cached_candidates_first, _asset_values
from .genre_ultra_artwork import request as genre_ultra_request, request_transparent_logo, cancel_owner as cancel_genre_artwork_owner
try:
    from .genre_ultra_artwork import pending_count as _genre_ultra_pending
except ImportError:
    def _genre_ultra_pending():
        return 1
from .content_home import MovieDetailsScreen
from .poster_manager import provider_poster_url as _server_poster_url, tmdb_poster_url
from .backdrop_manager import provider_backdrop_url as _server_backdrop_url, tmdb_backdrop_url
from .logo_manager import localized_logo_url, tmdb_logo_url, provider_logo_url
from .core import get_source_client
from .cache_manager import stable_cache_key, persistent_cache_get, persistent_cache_set
from .display_scale import scale_skin, sx, sy, scale_size
from .picload_compat import connect_picture_data
from .favorites import add_favourite, is_favourite
from .filters import filter_categories, filter_items, get_cached_categories, get_category_streams
from .i18n import nav_label, tr
from .tmdb_client import TMDbClient, preferred_metadata_text
from .display_titles import visible_title
from .resolution_badge import badge_widget, extract_resolution, extract_rating, _year_genre_from_sources, _clean_genres, _actual_media_genre
from .package_logos import package_logo_path, package_browser_logo_path
from .metadata_display import merge_metadata, cached_provider_info
from .title_cleaning import clean_series_label


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27"
POSTER_PLACEHOLDER = os.path.join(PLUGIN_PATH, "skins", "poster", "poster_loading_transparent_r410.png")
POSTER_SHELL = os.path.join(PLUGIN_PATH, "skins", "poster", "apple_match", "genre_shell.png")
POSTER_FOCUS = os.path.join(PLUGIN_PATH, "skins", "poster", "apple_match", "genre_focus.png")
NEW_RED_RIBBON = os.path.join(PLUGIN_PATH, "skins", "poster", "new_corner_red.png")
GENRE_BACKGROUND = os.path.join(PLUGIN_PATH, "skins", "genre", "genre_background.jpg")


# The requested design is a fixed 8 x 3 page: exactly 24 poster slots are
# rendered before navigation goes to a new page.
GRID_COLUMNS = 8
GRID_ROWS = 3
PAGE_SIZE = GRID_COLUMNS * GRID_ROWS
GRID_X = (55, 282, 509, 736, 963, 1190, 1417, 1644)
GRID_Y = (240, 485, 730)
CARD_WIDTH = 184
CARD_HEIGHT = 221
GENRE_BAR_SIZE = 8

GENRE_PILL_Y = 40
GENRE_PILL_X = 570
# A connected, gold-outlined metadata strip. It is independent of poster queues.
# Unknown facts are hidden and subsequent pills shift left (no empty slots).
GENRE_PILL_SPECS = (
    ("genreYear",       116, 34, "year"),
    ("genreCategories", 281, 39, "genre"),
    ("genreRating",     112, 34, "rating"),
    ("genreDuration",   155, 36, "duration"),
    ("genreLanguage",    77,  5, "language"),
    ("genreAge",         89,  5, "age"),
    ("genreQuality",     87,  5, "quality"),
)


def _genre_pill_language(*records):
    """Read content's original language, not the UI translation setting."""
    for record in records:
        if not isinstance(record, dict):
            continue
        value = record.get('original_language') or record.get('audio_language') or ''
        code = str(value).strip().split('-')[0].split('_')[0].lower()
        if py27_fullmatch(r'[a-z]{2,3}', code):
            return code.upper()
    return ''


def _genre_pill_age(*records):
    """Never infer +18 from genre, adult keywords, or an unknown rating."""
    for record in records:
        if not isinstance(record, dict):
            continue
        for key in ('certification', 'age_rating', 'content_rating', 'mpaa', 'rated', 'parental_rating'):
            raw = record.get(key)
            if not isinstance(raw, (str, int)):
                continue
            value = str(raw).strip().upper().replace(' ', '')
            if value in ('18', '18+', '+18', 'R18', 'R18+'):
                return '+18'
            if value in ('16', '16+', '+16', '12', '12+', '+12', '13', '13+', '+13'):
                return '+' + re.sub(r'\D', '', value)
            if value in ('G', 'PG', 'PG-13', 'R', 'NC-17', 'TV-MA', 'TV-14'):
                return value
    return ''


def _genre_pill_score(value):
    value = str(value or '').strip().replace('★', '').strip()
    return value if py27_fullmatch(r'(?:10(?:\.0)?|[0-9](?:\.[0-9])?)', value) else ''


def _provider_placeholder_cached_verdict(path):
    """None if unchecked; otherwise a fast, thread-safe cached image verdict."""
    try:
        stat = os.stat(path)
        key = (path, stat.st_size, getattr(stat, "st_ino", 0))
    except (OSError, TypeError, IOError):
        return None
    with _GENRE_POSTER_LOCK:
        return _GENRE_PROVIDER_SLATE_CACHE.get(key)


def _provider_image_is_placeholder(path):
    """Detect a provider's flat 'NO TITLE/NO IMAGE' graphic, not JPEG errors.

    Providers may serve a valid, arbitrary-named JPEG containing just a tiny
    centre label. URL-name and image-header checks accept it as artwork. This
    deliberately conservative visual test flags *only* almost-solid slates
    with a small centred glyph cluster. No OCR or image-to-image matching.

    The test runs on a worker, and is cached by file identity; never run it in
    the Enigma2 render/decode callback. On images without Pillow, fail open.
    """
    try:
        stat = os.stat(path)
        # Artwork LRU maintenance touches timestamps on cache hits; an inode
        # and size key avoids re-decoding unchanged posters on every visit.
        key = (path, stat.st_size, getattr(stat, "st_ino", 0))
    except (OSError, TypeError, IOError):
        return False
    with _GENRE_POSTER_LOCK:
        if key in _GENRE_PROVIDER_SLATE_CACHE:
            return _GENRE_PROVIDER_SLATE_CACHE[key]
    # Verdicts survive plugin restarts: re-decoding every cached poster with
    # Pillow at each visit made cached posters feel "downloaded again"
    # (slow Python 2 receivers, e.g. VTi).
    disk_verdict = _slate_disk_get(key)
    if disk_verdict is not None:
        with _GENRE_POSTER_LOCK:
            _GENRE_PROVIDER_SLATE_CACHE[key] = disk_verdict
        return disk_verdict
    placeholder = False
    try:
        from PIL import Image
        with Image.open(path) as image:
            if image.width < 25 or image.height < 35:
                return False
            if hasattr(image, "draft"):
                image.draft("RGB", (64, 96))
            reduced = image.convert("RGB").resize((48, 72), Image.BILINEAR)
            pixels = list(reduced.getdata())
        w, h = 48, 72
        # The corners/edges of a generic slate have essentially one colour.
        edge = [pixels[y * w + x] for y in range(h) for x in range(w)
                if (x < 4 or x >= w - 4 or y < 5 or y >= h - 5)]
        edge.sort(key=lambda c: c[0]); red = edge[len(edge) // 2][0]
        edge.sort(key=lambda c: c[1]); green = edge[len(edge) // 2][1]
        edge.sort(key=lambda c: c[2]); blue = edge[len(edge) // 2][2]
        background = (red, green, blue)
        def distance(rgb):
            return max(abs(int(rgb[c]) - background[c]) for c in range(3))
        # A photograph / illustrated poster has substantial variation beyond
        # one small title. Do not reject dark or simple *real* artwork merely
        # because its outer border is uniform.
        near_bg = sum(1 for px in pixels if distance(px) <= 28)
        if near_bg >= int(len(pixels) * 0.88):
            contrast = [(i % w, i // w) for i, px in enumerate(pixels)
                        if distance(px) >= 48]
            if not contrast:
                placeholder = True
            elif len(contrast) <= int(len(pixels) * 0.055):
                x0 = min(x for x, y in contrast)
                x1 = max(x for x, y in contrast)
                y0 = min(y for x, y in contrast)
                y1 = max(y for x, y in contrast)
                # A compact, centrally placed label (e.g. NO TITLE) differs
                # from full-size film text, faces, and illustration.
                cx, cy = (x0 + x1) / (2.0 * w), (y0 + y1) / (2.0 * h)
                placeholder = (0.25 <= cx <= 0.75 and 0.25 <= cy <= 0.75
                               and (x1 - x0 + 1) <= w * 0.72
                               and (y1 - y0 + 1) <= h * 0.19)
    except Exception:
        placeholder = False
    with _GENRE_POSTER_LOCK:
        _GENRE_PROVIDER_SLATE_CACHE[key] = placeholder
        if len(_GENRE_PROVIDER_SLATE_CACHE) > 4096:
            for old_key in list(_GENRE_PROVIDER_SLATE_CACHE)[:1024]:
                _GENRE_PROVIDER_SLATE_CACHE.pop(old_key, None)
    _slate_disk_put(key, placeholder)
    return placeholder


_SLATE_DISK = {"data": None, "dirty": 0, "saved": 0.0}


def _slate_disk_file():
    from .cache_manager import get_cache_dir
    return os.path.join(get_cache_dir("posters"), ".slate_verdicts.json")


def _slate_disk_key(key):
    return "%s|%s|%s" % key


def _slate_disk_load():
    if _SLATE_DISK["data"] is None:
        data = {}
        try:
            import json
            with open(_slate_disk_file(), "r") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            data = {}
        _SLATE_DISK["data"] = data
    return _SLATE_DISK["data"]


def _slate_disk_get(key):
    try:
        with _GENRE_POSTER_LOCK:
            value = _slate_disk_load().get(_slate_disk_key(key))
        return None if value is None else bool(value)
    except Exception:
        return None


def _slate_disk_put(key, verdict):
    try:
        import json, time as _time
        with _GENRE_POSTER_LOCK:
            data = _slate_disk_load()
            data[_slate_disk_key(key)] = 1 if verdict else 0
            if len(data) > 30000:
                for old in list(data)[:8000]:
                    data.pop(old, None)
            _SLATE_DISK["dirty"] += 1
            now = _time.time()
            if _SLATE_DISK["dirty"] < 25 and now - _SLATE_DISK["saved"] < 15:
                return
            payload = json.dumps(data)
            _SLATE_DISK["dirty"] = 0
            _SLATE_DISK["saved"] = now
        target = _slate_disk_file()
        temp = "%s.%d.tmp" % (target, os.getpid())
        with open(temp, "w") as handle:
            handle.write(payload)
        os.rename(temp, target)
    except Exception:
        pass


# These words keep the common movie/series classifications at the front while
# preserving every provider category as its own independent route.
PREFERRED_GENRES = (
    ("action", ("action", "اكشن", "أكشن")),
    ("comedy", ("comedy", "كوميدي", "كوميديا")),
    ("horror", ("horror", "رعب")),
    ("adventure", ("adventure", "مغامر")),
    ("crime", ("crime", "جريمة")),
    ("drama", ("drama", "دراما")),
    ("sci-fi", ("sci-fi", "sci fi", "science fiction", "خيال علمي")),
    ("thriller", ("thriller", "إثارة", "اثارة")),
)


def _dim_hero_backdrop(path):
    """Reuse the dimmed full-HD image while the source bytes are unchanged.

    Using source mtime in the output filename regenerated a 1920x1080 JPEG
    on every cache hit because normal artwork access used to touch mtime.
    Hashing the original image content (on the worker thread) provides a
    stable identity across mtime-only changes, but refreshes on replacement.
    """
    try:
        from PIL import Image, ImageOps, ImageEnhance
        import hashlib
        # Store processed artwork in the one shared backdrops directory.
        # Never derive a child folder from the incoming artwork path.
        from .cache_manager import get_cache_dir
        out_dir = get_cache_dir("backdrops")
        source_name = os.path.basename(path)
        parent_name = os.path.basename(os.path.dirname(path))
        if (source_name.startswith(("apple_outer_v6_", "genre_dim40_", "genre_dim47_")) or
                (parent_name in ("apple_outer_cover", "genre_dim") and
                 re.match(r'^[0-9a-f]{40}(?:_dim40)?\.jpg$', source_name))):
            return path  # Avoid rendering already processed legacy artwork.
        canonical = os.path.join(out_dir, os.path.basename(path))
        if (os.path.basename(path).startswith("backdrop_") and
                os.path.isfile(canonical) and os.path.getsize(canonical) > 100):
            path = canonical
        digest = hashlib.sha1()
        with open(path, "rb") as inp:
            while True:
                chunk = inp.read(131072)
                if not chunk:
                    break
                digest.update(chunk)
        out = os.path.join(out_dir, "genre_dim40_" + digest.hexdigest() + ".jpg")
        if not os.path.isfile(out) or os.path.getsize(out) < 100:
            old = os.path.join(os.path.dirname(path), "genre_dim", digest.hexdigest() + "_dim40.jpg")
            if os.path.isfile(old) and os.path.getsize(old) > 100:
                try:
                    os.rename(old, out)
                except OSError:
                    pass
        if not os.path.isfile(out) or os.path.getsize(out) < 100:
            # Write the result atomically: an interrupted render must not
            # leave an apparently cached but incomplete backdrop.
            # Concurrent callbacks for the same backdrop must not share a
            # temporary output name (one render might remove another's file).
            temp = "%s.%d.part" % (out, thread_ident())
            try:
                with Image.open(path) as im:
                    im = ImageOps.fit(im.convert("RGB"), (1920, 1080), method=Image.Resampling.LANCZOS if hasattr(Image, "Resampling") else Image.LANCZOS)
                    ImageEnhance.Brightness(im).enhance(0.40).save(temp, "JPEG", quality=85)
                atomic_replace(temp, out)
            finally:
                try:
                    if os.path.isfile(temp):
                        os.remove(temp)
                except Exception:
                    pass
        return out
    except Exception:
        return path


def _build_genre_skin():
    """Build the independent 1920x1080 skin without changing shared skins."""
    xml = [
        '<screen name="StandaloneGenreScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05070B">',
        '<eLabel position="0,0" size="1920,1080" backgroundColor="#05070B" zPosition="0" />',
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="off" scale="1" zPosition="1" />' % GENRE_BACKGROUND,
        '<widget name="heroBackdrop" position="0,0" size="1920,1080" alphatest="off" scale="1" zPosition="2" />',
        # Cinematic-style shade: backdrop stays visible top-right, dark behind
        # the header text (left) and under the poster grid (bottom).
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="blend" zPosition="3" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pro_fade.png"),
        '<eLabel position="55,227" size="1811,2" backgroundColor="#6B5528" zPosition="5" />',
        # Fixed-alpha overlay: no per-backdrop Pillow conversion or extra on-disk JPEGs.
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="blend" scale="1" zPosition="3" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_backdrop_dim_55.png"),

        '<widget name="heroLogo" position="55,35" size="490,130" alphatest="blend" scale="1" zPosition="4" />',
        # The old image backdrop and the film logo remain untouched.
        # A compact, transparent typography group replaces overlapping multi-line text.
        '<widget name="heroInfo" position="0,0" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />',
        '<widget name="heroTitle" position="25,30" size="535,142" font="Bold;40" foregroundColor="#F7F4EC" transparent="1" halign="center" valign="center" zPosition="5" />',
        # Gold-rimmed dark pills from the approved GENRE design.
        '<widget name="genreYearBg" position="570,40" size="116,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_year.png"),
        '<widget name="genreYear" position="604,40" size="74,38" font="Regular;19" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="genreCategoriesBg" position="570,40" size="281,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_genre.png"),
        '<widget name="genreCategories" position="609,40" size="234,38" font="Regular;18" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="genreRatingBg" position="570,40" size="112,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_rating.png"),
        '<widget name="genreRating" position="604,40" size="70,38" font="Regular;19" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="genreDurationBg" position="570,40" size="155,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_duration.png"),
        '<widget name="genreDuration" position="606,40" size="111,38" font="Regular;19" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="genreLanguageBg" position="570,40" size="77,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_language.png"),
        '<widget name="genreLanguage" position="575,40" size="67,38" font="Regular;19" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="genreAgeBg" position="570,40" size="89,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_age.png"),
        '<widget name="genreAge" position="575,40" size="79,38" font="Regular;19" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="genreQualityBg" position="570,40" size="87,38" pixmap="%s" alphatest="blend" zPosition="8" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_quality.png"),
        '<widget name="genreQuality" position="575,40" size="77,38" font="Regular;17" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />',
        '<widget name="heroMeta" position="0,0" size="1,1" font="Regular;1" foregroundColor="#E5C478" transparent="1" zPosition="5" />',
        '<widget name="heroPlot" position="570,90" size="985,128" font="Regular;24" foregroundColor="#E0E8F0" transparent="1" zPosition="5" />',
        # Right header stays inside its own 280px column; the hero synopsis
        # ends at x=1555 and the poster grid begins at y=240.  The logo and
        # collection name get separate rows instead of sharing y=95..153.
        # One exclusive brand slot under the section title: never draw a
        # package badge AND its text caption simultaneously.  The page
        # counter stays centered beneath this slot and above the poster grid.
        '<widget name="heading" position="1572,25" size="294,50" font="Bold;29" foregroundColor="#F8D891" transparent="1" halign="center" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="packageLogo" position="1572,86" size="294,68" alphatest="blend" scale="1" zPosition="6" />',
        '<widget name="subheading" position="1572,86" size="294,68" font="Bold;23" foregroundColor="#F4F1E8" transparent="1" halign="center" valign="center" zPosition="5" />',
        # Keep live page numbers; only restyle their 24-poster full-backdrop header.
        '<ePixmap position="1572,159" size="294,62" pixmap="%s" alphatest="blend" zPosition="5" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_page_counter_gold.png"),
        '<widget name="page" position="1572,171" size="294,38" font="Bold;25" foregroundColor="#FFE1A0" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />',
        '<ePixmap position="55,962" size="1811,42" pixmap="%s" alphatest="blend" zPosition="4" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pro_status_bar.png"),
        '<widget name="status" position="95,962" size="1750,42" font="Regular;20" foregroundColor="#E9D8A6" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="selector" position="48,233" size="198,235" pixmap="%s" alphatest="blend" zPosition="10" />' % POSTER_FOCUS,
        # Keep the original Label instances (they are updated by the browser)
        # but remove the previous colored dots / menu legend visually.
        '<widget name="redHint" position="-2500,-2500" size="1,1" font="Regular;1" transparent="1" />',
        '<widget name="greenHint" position="-2500,-2500" size="1,1" font="Regular;1" transparent="1" />',
        '<widget name="yellowHint" position="-2500,-2500" size="1,1" font="Regular;1" transparent="1" />',
        '<widget name="blueHint" position="-2500,-2500" size="1,1" font="Regular;1" transparent="1" />',
        '<widget name="menuHint" position="-2500,-2500" size="1,1" font="Regular;1" transparent="1" />',
        '<ePixmap position="20,1027" size="1880,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/common/poster_actions_toolbar_sort_live_py2_genre.png" alphatest="blend" zPosition="35" />',
        '<widget name="footerServerName" position="548,1051" size="150,23" font="Bold;16" foregroundColor="#DCE6F0" backgroundColor="#00000000" transparent="1" halign="left" valign="center" noWrap="1" zPosition="38" />',
        '<widget name="footerSortValue" position="799,1050" size="104,25" font="Bold;16" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="38" />',
    ]

    # No navigation bar on this standalone GENRE page.

    # Eight genre routes occupy the line under the title. The active route is
    # written with square brackets, so no shared selector graphic is necessary.
    # Genre switching remains on RED/BLUE; hide the genre text row.

    for row, ypos in enumerate(GRID_Y):
        for column, xpos in enumerate(GRID_X):
            slot = row * GRID_COLUMNS + column
            title_y = ypos + 151
            meta_y = ypos + CARD_HEIGHT - 28
            xml.extend((
                '<widget name="poster%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="4" />' % (slot, xpos, ypos, CARD_WIDTH, CARD_HEIGHT, POSTER_PLACEHOLDER),
                '<widget name="shell%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="5" />' % (slot, xpos, ypos, CARD_WIDTH, CARD_HEIGHT, POSTER_SHELL),
                '<widget name="newBadge%d" position="%d,%d" size="112,112" pixmap="%s" alphatest="blend" zPosition="11" />' % (slot, xpos, ypos, NEW_RED_RIBBON),
                '<widget name="meta%d" position="%d,%d" size="%d,24" font="Regular;15" foregroundColor="#F2E3B5" backgroundColor="#0B111C" transparent="0" halign="center" valign="center" zPosition="7" />' % (slot, xpos + 32, meta_y - 6, CARD_WIDTH - 64),
                '<widget name="stars%d" position="%d,%d" size="120,22" alphatest="blend" scale="1" zPosition="7" />' % (slot, xpos + (CARD_WIDTH - 120) // 2, meta_y - 5),
            ))

    xml.append('</screen>')
    return scale_skin("\n".join(xml))


GENRE_POSTER_SKIN = _build_genre_skin()
from .font_preferences import read_preferences as _read_font_preferences, scale_skin_text as _scale_genre_fonts
GENRE_POSTER_SKIN = _scale_genre_fonts(GENRE_POSTER_SKIN, _read_font_preferences()["font_scale"])


def _fmt_rating(value):
    """'7.328' -> '7.3'; hide zero/invalid ratings instead of showing 0."""
    try:
        text = str(value or "").strip()
        number = float(text.replace(",", "."))
    except Exception:
        return value or ""
    if number <= 0:
        return ""
    return "%.1f" % number


def _stars_file(item):
    """Gold 0-5 stars (half steps) for a poster; '' when there is no rating.

    rating / vote_average are /10, rating_5based is already /5.
    """
    if not isinstance(item, dict):
        return ''
    value = None
    for key, scale in (("rating", 2.0), ("vote_average", 2.0), ("rating_5based", 1.0)):
        raw = item.get(key)
        try:
            number = float(str(raw).replace(",", ".").strip())
        except (TypeError, ValueError):
            continue
        if number > 0:
            value = number / scale
            break
    if value is None:
        return ''
    halves = int(round(max(0.0, min(5.0, value)) * 2))
    return os.path.join(PLUGIN_PATH, "skins", "genre", "stars", "stars_%02d.png" % halves)

def _set_meta(label, text):
    """Poster chip: hidden when empty so no blank dark pill is drawn."""
    try:
        label.setText(text)
        if text:
            label.show()
        else:
            label.hide()
    except Exception:
        pass


def _category_name(row):
    if not isinstance(row, dict):
        return ""
    return text_type(row.get("category_name") or row.get("name") or row.get("title") or row.get("genre") or u"").strip()


def _category_id(row):
    if not isinstance(row, dict):
        return ""
    for key in ("category_id", "id", "genre_id", "group", "group-title", "category"):
        value = row.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _short_text(value, limit):
    text = text_type(value or u"").strip()
    return text if len(text) <= limit else text[:max(1, limit - 1)].rstrip() + u"…"

def _genre_provider_metadata(payload):
    """Read detailed provider responses, not only the thin catalogue entry.

    Xtream VOD returns ``info`` plus ``movie_data``; TV returns ``info``.
    M3U/Stalker variants sometimes return flat or nested dictionaries.
    Do not copy artwork fields or alter provider data stored elsewhere.
    """
    if not isinstance(payload, dict):
        return {}
    merged = dict(payload)
    for key in ("movie_data", "series_data", "data", "info"):
        part = payload.get(key)
        if isinstance(part, dict):
            merged.update(part)
    def first(*keys):
        for key in keys:
            value = merged.get(key)
            if value is not None and str(value).strip():
                return text_type(value).strip()
        return ""
    return {
        "title": first("name", "title", "original_title"),
        "description": first("plot", "description", "overview", "storyline", "plot_outline"),
        "rating": first("rating", "vote_average", "rating_5based"),
        "year": first("year", "releasedate", "releaseDate", "release_date", "first_air_date")[:4],
        # Preserve the actual genres from provider detail records. Never copy
        # category_name: it is a package label, not a film genre.
        "genres": next((merged[k] for k in ("genres", "genre_names", "genre", "genre_ids", "genre_id")
                        if merged.get(k) not in (None, "", [])), ""),
        "tmdb_id": first("tmdb_id", "tmdb", "tmdbId", "tmdbid"),
        "runtime": first("runtime", "duration"),
        "original_language": first("original_language", "audio_language"),
        "certification": first("certification", "age_rating", "mpaa", "rated", "parental_rating"),
    }


def _verified_genre_title_tmdb(details, title, kind, year=""):
    """Validate a server-supplied TMDb ID before using its artwork.

    Mirrors GENRE's existing poster identity check, so an IPTV stream ID
    which happens to exist in TMDb never yields another film's clearlogo.
    """
    if not isinstance(details, dict) or not details.get("id") or not title:
        return False
    try:
        from .tmdb_client import _tmdb_identity_anchor, _tmdb_identity_row_score
        anchor = _tmdb_identity_anchor(title, kind)
        return bool(anchor and _tmdb_identity_row_score(
            anchor, anchor, details, kind, year or None) >= 0.80)
    except Exception:
        return False


def _genre_provider_poster_urls(source, record, kind="vod"):
    """Prioritize legitimate provider covers, never discard alternates.

    Current Stalker catalogues expose _genre_poster_candidates; older saved
    catalogue rows still work through their existing image fields.
    """
    if not isinstance(record, dict):
        return []
    candidates = []
    seen = set()
    # The large page may have resolved a *different* final TMDb/provider URL
    # from the same title. Use only the exact image it already decoded and
    # cached: the source row itself does not carry that other page's fields.
    try:
        from .poster_resolution_cache import cached_decoded_url
        winner = cached_decoded_url(source, kind, record)
        if winner:
            candidates.append(winner)
    except Exception:
        pass
    # Home / the large TV Shows page can already have resolved the exact
    # poster for this item. Reuse that URL and its shared disk cache before
    # trying alternative Stalker screenshots; do not perform a new lookup.
    # Extra URLs are accepted only when the poster has ALREADY been cached by
    # a large page. This adds no new network requests to GENRE.
    def add_warm(url):
        if url and cached_artwork(url, "posters"):
            candidates.append(url)
    resolved_tmdb = tmdb_poster_url(record.get("_tmdb_poster"))
    add_warm(resolved_tmdb)
    for key in ("_resolved_server_poster", "_player_cover"):
        try:
            add_warm(provider_asset_url(source, record.get(key)))
        except Exception:
            pass
    # Match the shared provider resolver used by the large pages, without
    # removing any existing GENRE/Stalker candidates or changing its workers.
    try:
        add_warm(_server_poster_url(source, record))
    except Exception:
        pass
    # This list comes from native Stalker raw fields before normalization.
    native = record.get("_genre_poster_candidates") or []
    if isinstance(native, (tuple, list)):
        for entry in native:
            candidates.extend(_asset_values(entry))
    # Standalone Xtream, M3U, and provider detail data may keep the image in
    # different keys or in a nested info/movie_data payload.
    fields = ("cover", "cover_big", "cover_url", "poster", "poster_url",
              "poster_path", "movie_image", "poster_image", "image_url",
              "image", "stream_icon", "screenshot_uri", "screenshot",
              "hd", "pic", "img", "thumbnail")
    for part in (record, record.get("info"), record.get("movie_data"),
                 record.get("series_data"), record.get("metadata"), record.get("data")):
        if not isinstance(part, dict):
            continue
        for key in fields:
            value = part.get(key)
            if value:
                # Preserve multiple / language-keyed source artwork URLs,
                # independently of whether this movie has any metadata.
                for candidate in _asset_values(value):
                    if key == 'poster_path':
                        try:
                            raw = text_type(candidate).strip()
                            if re.match(r'^/[A-Za-z0-9_-]{8,}\.(?:png|jpe?g|webp)$', raw, re.I):
                                candidate = tmdb_poster_url(raw)
                        except (TypeError, ValueError):
                            pass
                    candidates.append(candidate)
    urls = []
    for value in candidates:
        url = provider_asset_url(source, value)
        if not url or url in seen:
            continue
        try:
            filename = urlsplit(url).path.rsplit("/", 1)[-1].lower()
            if py27_fullmatch(r"(?:no[_-]?(?:poster|image|title)|nopic|placeholder|default[_-]?poster)(?:[_-][a-z0-9]+)?\.(?:jpe?g|png|webp)", filename):
                continue
        except Exception:
            pass
        seen.add(url)
        urls.append(url)
        # Inspect a bounded number of candidates before applying the network
        # fallback limit, so cached art is not hidden by eight broken links.
        if len(urls) >= 40:
            break
    return cached_candidates_first(urls, "posters", limit=8)


def _genre_provider_poster_url(source, record, kind="vod"):
    candidates = _genre_provider_poster_urls(source, record, kind)
    return candidates[0] if candidates else ""


def _genre_provider_artwork(source, payload):
    """Extract only genuine provider poster and backdrop URLs from VOD details.

    Some Stalker/Ultra-compatible portals keep the images in movie_data, info,
    metadata, or data rather than in the list item.  Preserve media types:
    never use a cover as a backdrop or a backdrop as a vertical poster.
    """
    if not isinstance(payload, dict):
        return "", ""
    poster = backdrop = ""
    for record in (payload, payload.get("info"), payload.get("movie_data"),
                   payload.get("series_data"), payload.get("metadata"),
                   payload.get("data"), payload.get("details")):
        if not isinstance(record, dict):
            continue
        if not poster:
            poster = _genre_provider_poster_url(source, record)
        if not backdrop:
            backdrop = _server_backdrop_url(source, record) or ""
        if poster and backdrop:
            break
    return poster, backdrop


def _genre_sort_key(row):
    name = _category_name(row).lower()
    for position, _entry in enumerate(PREFERRED_GENRES):
        aliases = _entry[1]
        if any(alias.lower() in name for alias in aliases):
            return (0, position, name)
    return (1, 999, name)


def _content_identity(item, kind):
    row = item or {}
    if row.get("_keep_copy"):
        # Movie Parts / Other Sources: every provider copy stays visible.
        return "copy:%s" % (row.get("stream_id") or row.get("vod_id") or row.get("id") or row.get("cmd") or id(row))
    for key in ("tmdb_id", "tmdb", "tmdbId"):
        value = str(row.get(key) or "").strip()
        if value and value not in ("0", "none", "None"):
            return "tmdb:%s:%s" % (kind, value)
    for key in ("stream_id", "series_id", "vod_id", "id"):
        value = str(row.get(key) or "").strip()
        if value:
            return "id:%s:%s" % (kind, value)
    title = text_type(row.get("name") or row.get("title") or u"").lower().strip()
    year = str(row.get("year") or row.get("release_date") or row.get("first_air_date") or "").strip()[:4]
    return "title:%s:%s:%s" % (kind, title, year)


# The NEW ribbon is purely decorative and never alters/downloads a poster.
def _new_badge_expiry(item, now=None, kind=None):
    if not isinstance(item, dict):
        return 0
    current = time.time() if now is None else now
    keys = ('added', 'added_timestamp', 'added_at', 'date_added',
            'created_at', 'created', 'add_date')
    series = (kind == 'series')
    if series:
        keys += ('last_modified',)
    latest_expiry = 0
    for key in keys:
        raw = item.get(key)
        if raw in (None, '', 0, '0'):
            continue
        stamp = 0
        try:
            stamp = float(raw)
            if stamp >= 100000000000:
                stamp /= 1000.0
            if stamp < 1000000000 or stamp > 4102444800:
                stamp = 0
        except (ValueError, TypeError, OverflowError):
            stamp = 0
        if not stamp:
            try:
                import datetime as _dt
                import calendar as _cal
                raw_text = str(raw).strip()
                # Explicit UTC or numeric timezone offsets are handled as UTC.
                match = re.search(r'(Z|[+-]\d{2}:?\d{2})$', raw_text, re.I)
                offset = 0
                is_utc = bool(match)
                if match:
                    suffix = match.group(1)
                    raw_text = raw_text[:-len(suffix)]
                    if suffix.upper() != 'Z':
                        digits = suffix[1:].replace(':', '')
                        offset = (int(digits[:2])*60+int(digits[2:]))*60
                        if suffix[0] == '-':
                            offset = -offset
                raw_text = raw_text.strip().replace('T', ' ')
                raw_text = raw_text.split('.')[0]
                for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M',
                            '%Y-%m-%d', '%Y/%m/%d %H:%M:%S'):
                    try:
                        val = _dt.datetime.strptime(raw_text, fmt)
                        stamp = float(_cal.timegm(val.timetuple())-offset) if is_utc else time.mktime(val.timetuple())
                        break
                    except (ValueError, TypeError, OverflowError):
                        pass
            except Exception:
                stamp = 0
        if stamp:
            age = current - stamp
            expiry = stamp + 86400.0 if 0 <= age < 86400 else 0
            # Movies keep their original add-date precedence. Series show NEW
            # for a new addition OR a recent provider modification.
            if not series:
                return expiry
            latest_expiry = max(latest_expiry, expiry)
    return latest_expiry

def _newest_key(item):
    """Copied date precedence from the current GENRE route: provider added first."""
    row = item if isinstance(item, dict) else {}

    def stamp(value):
        if value in (None, ""):
            return 0
        try:
            number = int(float(value))
            if number > 100000000000:
                number //= 1000
            if number > 100000000:
                return number
        except Exception:
            pass
        text = str(value).strip().replace("Z", "").replace("T", " ")
        for fmt, length in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%d", 10), ("%Y/%m/%d %H:%M:%S", 19), ("%Y/%m/%d", 10)):
            try:
                return int(time.mktime(time.strptime(text[:length], fmt)))
            except Exception:
                pass
        return 0

    for key in ("added", "added_timestamp", "added_at", "date_added", "created_at", "timestamp"):
        value = stamp(row.get(key))
        if value:
            return (3, value)
    for key in ("release_date", "releaseDate", "releasedate", "release_date_utc", "first_air_date"):
        value = stamp(row.get(key))
        if value:
            return (2, value)
    try:
        year = int(str(row.get("year") or "")[:4])
        if 1800 <= year <= 2200:
            return (1, year)
    except Exception:
        pass
    return (0, 0)


def prepare_genre_latest_rows(source, kind, category_id, category_name, items):
    """Prepare one package exactly as GENRE Latest prepares it.

    This is the single shared path for normalization, identity de-duplication,
    source filtering and newest-first ordering. The GENRE grid and the Movies /
    TV Shows Backdrop rail both consume this result; neither route maintains a
    second, slightly different copy of the Latest ordering rules.
    """
    rows = []
    seen = set()
    for item in list(items or []):
        if not isinstance(item, dict):
            continue
        row = dict(item)
        row.setdefault("category_id", category_id)
        row.setdefault("category_name", category_name)
        row["_source_category_id"] = category_id
        key = _content_identity(row, kind)
        if key in seen:
            continue
        seen.add(key)
        rows.append(row)
    try:
        rows = filter_items(source, kind, rows)
    except Exception:
        pass
    try:
        rows.sort(key=_newest_key, reverse=True)
    except Exception:
        pass
    return rows


def _hero_backdrop_url(value):
    """Hero backdrop at the user's TMDb backdrop quality (default w780).

    'original' TMDb files are often 4K / several MB; downloading one per
    selected poster kept a shared artwork lane busy and queued the posters
    behind it. The Settings choice is respected; 'w1920' (not a TMDb size)
    maps to w1280."""
    from .backdrop_manager import configured_backdrop_size
    size = configured_backdrop_size()
    url = tmdb_backdrop_url(value, size)
    if size != "original" and "/t/p/original/" in url:
        url = url.replace("/t/p/original/", "/t/p/%s/" % size, 1)
    return url


def _hero_logo_url(value):
    """Hero title logo at w500 (also rewrites an 'original' TMDb logo URL)."""
    url = tmdb_logo_url(value, "w500")
    if "/t/p/original/" in url:
        url = url.replace("/t/p/original/", "/t/p/w500/", 1)
    return url


class StandaloneGenreScreen(Screen):
    """Independent 24-poster GENRE screen for Movies and TV Shows."""

    _tivimateLogoAlign = 'catalog_center'
    skin = GENRE_POSTER_SKIN
    TOP = ("Home", "Search", "Live", "Movies", "TV Shows", "Packages", "GENRE", "Resume", "Server Finder", "Settings")

    def __init__(self, session, source, initial_kind="vod", initial_category_id=""):
        from .poster_blue_hold import add_footer_hint
        self.skin = add_footer_hint(self.skin)
        Screen.__init__(self, session)
        self.kind = "series" if str(initial_kind) == "series" else "vod"
        # GENRE poster and Cinematic are independent from GENRE backdrop and
        # from each other. A provider category_id is server-scoped: never
        # replace the explicitly supplied source for an opened package.
        page_type = getattr(self, "_PAGE_SOURCE_PREFIX", None) or ("cinematic_" if self.__class__.__name__ == "CinematicCatalogScreen" else "genre_poster_")
        self._serverPageKey = page_type + self.kind
        selected_source = dict(source or {})
        actor_scope = bool(selected_source.get("_actor_search_name") or selected_source.get("_actor_search_rows"))
        if not initial_category_id and not actor_scope:
            from .ui import _load_page_source, _save_page_source
            selected_source = _load_page_source(self._serverPageKey, selected_source)
            _save_page_source(self._serverPageKey, selected_source)
        self.source = selected_source
        from .server_footer_identity import compact_server_name, refresh_footer_label
        self["footerServerName"] = Label(compact_server_name(self.source))
        self.onShow.append(lambda: refresh_footer_label(self))
        # Resolve settings once rather than reading TMDb settings at each arrow press.
        self._hero_language = str(TMDbClient().language or "en-US")
        self.initial_category_id = str(initial_category_id or "")
        self._recent_grid_view = self.initial_category_id == '__recent_added__'
        self.categories = []
        self.genre_links = {"vod": {}, "series": {}}
        self.category_index = 0
        self.genre_items = []
        self._poster_original_rows = []
        self._poster_sort_mode = "date"
        self["footerSortValue"] = Label("Date")
        self.onShow.append(self._refreshFooterSortValue)
        self.index = 0
        self.page_start = 0
        self._generation = 0
        self._poster_tokens = {}
        self._poster_decoders = {}
        # Only missing/rejected catalogue posters use parallel fallback.  A
        # usable provider image always outranks a provisional TMDb image.
        self._poster_resolved_priority = {}
        self._poster_provider_attempts = {}  # visible slot -> (token, seen URLs)
        self._poster_tmdb_started = set()
        self._poster_jobs = []
        # Only currently visible slots wait here if the shared fallback pool
        # is temporarily full. Never lose a poster request on queue pressure.
        self._poster_retry = {}
        self._poster_retry_timer = eTimer()
        self._poster_retry_timer.callback.append(self._retry_missing_posters)
        self._rendered_page_key = None
        self._poster_paint_timer = eTimer()
        self._poster_paint_timer.callback.append(self._paint_poster_batch)
        self._poster_paint_key = None
        self._poster_paint_next = 0
        self._poster_paint_order = []
        self._poster_painted_slots = set()
        self._poster_layout_ready = False
        self._closed = False
        self.onLayoutFinish.append(self._poster_widgets_ready)
        # Enigma2 images without a running Twisted reactor still need an
        # on-GUI-thread destination for completed poster/background jobs.
        self._poster_gui_jobs = []
        self._poster_gui_lock = threading.Lock()
        self._poster_gui_timer = eTimer()
        self._poster_gui_timer.callback.append(self._drain_poster_gui_jobs)
        self._poster_gui_timer.start(100, False)
        self.onClose.append(self._poster_gui_timer.stop)
        # The next-page warmer serves GENRE/Cinematic (24) and Python 2.7
        # Apple (15) using the same existing low-priority downloader.
        self._next_page_warm_enabled = False  # r170: only visible pages
        if self._next_page_warm_enabled:
            self._next_page_warm_key = None
            self._next_page_warm_rows = []
            self._next_page_warm_inflight = False
            self._next_page_warm_paused = False
            self._next_page_warm_failed = set()
            self._next_page_warm_timer = eTimer()
            self._next_page_warm_timer.callback.append(self._next_page_warm_tick)
            self.onHide.append(self._next_page_warm_pause)
            self.onShow.append(self._next_page_warm_resume)
            self.onClose.append(self._next_page_warm_pause)
        self._series_details_class = None
        self._hero_token = None
        self._hero_timer = eTimer()
        self._hero_timer.callback.append(self._load_hero)
        self._hero_last_index = None
        self._hero_cache = {}
        self._hero_lookup_cache = {}  # keyed by title, kind, year, TMDb id
        self._hero_text_token = None
        self._hero_text_sources = {}
        self._hero_plain_title = ""
        self._hero_logo_active = False
        # Recent Added is a virtual cross-package feed, never a provider category.
        # A single GUI poll timer delivers slow provider replies even on images
        # where the Twisted reactor is not installed.
        self._recent_grid_reply = None
        self._recent_grid_timer = eTimer()
        self._recent_grid_timer.callback.append(self._recent_grid_poll)
        self.onClose.append(self._recent_grid_timer.stop)
        self.onClose.append(self._poster_paint_timer.stop)

        for index, label in enumerate(self.TOP):
            self["nav%d" % index] = Label(nav_label(label))
        for index in range(GENRE_BAR_SIZE):
            self["genre%d" % index] = Label("")
        for index in range(PAGE_SIZE):
            self["poster%d" % index] = Pixmap()
            self["shell%d" % index] = Pixmap()
            self["newBadge%d" % index] = Pixmap()
            self["newBadge%d" % index].hide()
            self["title%d" % index] = Label("")
            self["meta%d" % index] = Label("")
            self["stars%d" % index] = Pixmap()
        self._new_badge_displayed = {}
        self._new_badge_visible_limit = PAGE_SIZE
        self._new_badge_timer = eTimer()
        self._new_badge_timer.callback.append(self._new_badge_tick)
        self.onClose.append(self._new_badge_timer.stop)
        self["heroBackdrop"] = Pixmap()
        self["heroLogo"] = Pixmap()
        self["heroInfo"] = Label("")
        self["heroTitle"] = DirectionalLabel("")
        self["heroMeta"] = CenteredArabicMetadataLabel("")
        for name, _width, _inset, _style in GENRE_PILL_SPECS:
            self[name] = Label('')
            self[name].hide()
            self[name + 'Bg'] = Pixmap()
            self[name + 'Bg'].hide()
        self["heroPlot"] = SynopsisLabel("")
        self["heading"] = Label("")
        self["packageLogo"] = Pixmap()
        self["subheading"] = Label("")
        self["page"] = Label("")
        self["status"] = Label("")
        self["selector"] = Pixmap()
        self["redHint"] = Label("PREVIOUS GENRE")
        self["greenHint"] = Label("SERVER")
        self["yellowHint"] = Label("SORT")
        self["blueHint"] = Label("NEXT GENRE")
        self["menuHint"] = Label("MENU  Style    YELLOW long  Favorite    GREEN long  Filter")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions"],
            {
                "ok": self.open_selected,
                "info": self.open_selected,
                "cancel": self.close,
                "left": self.left,
                "right": self.right,
                "up": self.up,
                "down": self.down,
                "pageUp": self.page_up,
                "pageDown": self.page_down,
                "red": self.previous_genre,
                "green": self.open_poster_server,
                "yellow": self.sort_posters,
                "yellowlong": self.toggle_favorite,
                "greenlong": self.filter_poster_server,
                "blue": self.next_genre,
                "menu": self.open_view_style_menu,
            },
            -1,
        )
        from .poster_blue_hold import install_poster_blue_hold
        install_poster_blue_hold(self, self.next_genre)
        self.onLayoutFinish.append(self._adjust_movie_logo_size)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._mark_closed)

    def _next_page_warm_page_key(self):
        source = self.source or {}
        return (self._generation, self.page_start, len(self.genre_items),
                id(self.genre_items), self.category_index, self.kind,
                str(source.get('type') or ''),
                str(source.get('url') or source.get('portal') or source.get('host') or ''),
                str(source.get('username') or source.get('mac') or ''))

    def _next_page_warm_page_size(self):
        return 15 if self.__class__.__name__ in ('AppleMoviesScreen', 'AppleSeriesScreen') else PAGE_SIZE

    def _next_page_warm_arm(self, delay=850):
        if (self._next_page_warm_enabled and not self._closed and
                not self._next_page_warm_paused and self._next_page_warm_rows):
            self._next_page_warm_timer.start(delay, True)

    def _next_page_warm_prepare(self):
        if not self._next_page_warm_enabled:
            return
        key = self._next_page_warm_page_key()
        if key == self._next_page_warm_key:
            return
        self._next_page_warm_timer.stop()
        self._next_page_warm_key = key
        self._next_page_warm_failed.clear()
        self._next_page_warm_started = time.time()
        # Only the immediately following screen: 24 GENRE/Cinematic, 15 Apple.
        size = self._next_page_warm_page_size()
        first = self.page_start + size
        self._next_page_warm_rows = list(range(
            first, min(first + size, len(self.genre_items))))
        self._next_page_warm_arm(350)

    def _next_page_warm_lookup_tmdb(self, item, callback):
        """Resolve one *hidden* catalogue item's own poster off the GUI thread.

        Source entries may have no cover even though the visible page later
        obtains one via TMDb. Reuse its title and ID verification rather than
        speculative/incorrect IDs or a new downloader pool.
        """
        snapshot = dict(item or {})
        kind = self.kind
        def worker():
            url = ''
            try:
                raw_title = snapshot.get('name') or snapshot.get('title') or ''
                title = clean_series_label(raw_title).strip()
                text_year = ' '.join(str(snapshot.get(k) or '') for k in
                                     ('year', 'releaseDate', 'release_date', 'first_air_date'))
                match = re.search(r'\b(?:19|20)\d{2}\b', text_year)
                year = match.group(0) if match else ''
                if title:
                    key = (kind, title.lower(), year, self._poster_tmdb_id(snapshot))
                    with _GENRE_POSTER_LOCK:
                        hit = _GENRE_POSTER_LOOKUP.get(key)
                        valid = bool(hit and hit[0] > monotonic())
                        path = hit[1] if valid else ''
                    if not valid:
                        client = TMDbClient()
                        path = self._verified_tmdb_poster(client, snapshot, kind, title, year)
                        if not path:
                            found = client.search_artwork(title, kind, year or None,
                                                          required_key='poster_path') or {}
                            path = found.get('poster_path') or ''
                        with _GENRE_POSTER_LOCK:
                            _GENRE_POSTER_LOOKUP[key] = (monotonic() +
                                (1800.0 if path else 120.0), path)
                    url = tmdb_poster_url(path) or ''
            except Exception:
                url = ''
            # GUI scheduling and state mutation only on the Enigma2 main loop.
            self._post_to_gui(callback, url)
        try:
            _GENRE_POSTER_POOL.submit(worker)
        except Exception:
            callback('')

    def _next_page_warm_tick(self):
        if (self._closed or self._next_page_warm_paused or
                self._next_page_warm_key != self._next_page_warm_page_key() or
                self._next_page_warm_inflight):
            return
        # Allow *visible* posters to finish first, but do not wait for hero,
        # logo, backdrop or unrelated Ultra transfers to become globally idle.
        # A broken poster should not permanently starve the next page either.
        visible = min(self._next_page_warm_page_size(),
                      max(0, len(self.genre_items) - self.page_start))
        complete = all(self._poster_resolved_priority.get(slot, 0) > 0 or
                       slot in self._next_page_warm_failed or
                       slot in getattr(self, '_cinema_poster_failed', set())
                       for slot in range(visible))
        if not complete and time.time() - self._next_page_warm_started < 8.0:
            self._next_page_warm_arm(450)
            return
        # Only ONE low-priority request/lookup at a time. Ultra's existing
        # priority queue gives the foreground posters precedence automatically.
        source = dict(self.source or {})
        while self._next_page_warm_rows:
            index = self._next_page_warm_rows.pop(0)
            if index >= len(self.genre_items):
                continue
            row = self.genre_items[index]
            try:
                urls = _genre_provider_poster_urls(source, row, self.kind)
                hit = ''
                for cached_url in urls:
                    hit = cached_artwork(cached_url, 'posters')
                    if hit:
                        break
                if hit:
                    self._next_page_warm_ready(hit)
                    continue
                url = urls[0] if urls else ''
            except Exception:
                url = ''
            expected = self._next_page_warm_key
            self._next_page_warm_inflight = True

            def advance(path='', page=expected):
                self._next_page_warm_inflight = False
                if path and page == self._next_page_warm_key:
                    self._next_page_warm_ready(path)
                if not self._closed:
                    # Old page's completion must wake the new page's warmer.
                    self._next_page_warm_arm(90 if page == self._next_page_warm_key else 250)

            def download(url_to_fetch, page=expected, record=row):
                if self._closed or page != self._next_page_warm_key:
                    advance('', page)
                    return
                if not url_to_fetch or cached_artwork(url_to_fetch, 'posters'):
                    advance('', page)
                    return
                def finished(path, current_page=page):
                    advance(path, current_page)
                try:
                    genre_ultra_request(url_to_fetch, 'posters', source,
                                        finished, finished, self._post_to_gui,
                                        low=True)
                except Exception:
                    advance('', page)

            def tmdb_ready(resolved_url, page=expected):
                if self._closed or page != self._next_page_warm_key:
                    advance('', page)
                else:
                    download(resolved_url, page)

            if url:
                def provider_ready(path, page=expected):
                    advance(path, page)
                def provider_failed(path, page=expected, record=row):
                    if self._closed or page != self._next_page_warm_key:
                        advance('', page)
                    else:
                        self._next_page_warm_lookup_tmdb(record, tmdb_ready)
                try:
                    genre_ultra_request(url, 'posters', source, provider_ready,
                                        provider_failed, self._post_to_gui, low=True)
                except Exception:
                    self._next_page_warm_lookup_tmdb(row, tmdb_ready)
            else:
                self._next_page_warm_lookup_tmdb(row, tmdb_ready)
            return

    def _next_page_warm_ready(self, path):
        """Next-page poster is on disk (subclasses may prepare it further)."""
        return

    def _next_page_warm_pause(self):
        if not self._next_page_warm_enabled:
            return
        self._next_page_warm_paused = True
        self._next_page_warm_timer.stop()

    def _next_page_warm_resume(self):
        if not self._next_page_warm_enabled:
            return
        self._next_page_warm_paused = False
        if self._next_page_warm_key is None:
            self._next_page_warm_prepare()
        else:
            self._next_page_warm_arm(1400)

    def _cancel_poster_jobs(self):
        """Cancel obsolete TMDb fallbacks and retries from the previous page."""
        try:
            # The Ultra downloader is shared globally; remove this screen's
            # stale callbacks in addition to its local fallback futures.
            cancel_genre_artwork_owner(self)
        except Exception:
            pass
        try:
            self._poster_retry_timer.stop()
            self._poster_retry.clear()
        except Exception:
            pass
        for future in getattr(self, "_poster_jobs", ()):
            try:
                future.cancel()
            except Exception:
                pass
        self._poster_jobs = []
        self._poster_provider_attempts.clear()

    def _retry_missing_posters(self):
        """Retry only visible missing posters when another lookup frees a slot.

        A small single GUI timer avoids creating unbounded background tasks or
        leaving permanent placeholders when GENRE pages are changed quickly.
        """
        if self._closed:
            self._poster_retry.clear()
            return
        waiting = list(self._poster_retry.items())
        self._poster_retry.clear()
        for slot, (record, token) in waiting:
            if self._poster_tokens.get(slot) == token:
                self._resolve_tmdb_poster(slot, record, token)

    def _mark_closed(self):
        self._closed = True
        try:
            self._poster_gui_timer.stop()
            with self._poster_gui_lock:
                self._poster_gui_jobs[:] = []
        except Exception:
            pass
        try:
            self._poster_paint_timer.stop()
        except Exception:
            pass
        self._cancel_poster_jobs()
        self._generation += 1
        self._poster_tokens = {}
        self._poster_resolved_priority.clear()
        self._poster_tmdb_started.clear()
        self._rendered_page_key = None
        # Enigma2 can dispose Screen attributes before a queued ePicLoad
        # PictureData callback fires. Never assume the decoder map survives.
        decoders = getattr(self, "_poster_decoders", None)
        if decoders is not None:
            decoders.clear()
        hero_decoders = getattr(self, "_genre_hero_decoders", None)
        if hero_decoders is not None:
            hero_decoders.clear()
        try:
            self._hero_timer.stop()
        except Exception:
            pass

    def _set_hero_logo_state(self, active):
        self._hero_logo_active = bool(active)
        try:
            title = text_type(getattr(self, "_hero_plain_title", u"") or u"").strip()
            if not title:
                item = self._selected_item() or {}
                title = text_type(item.get("name") or item.get("title") or
                                  item.get("original_title") or
                                  item.get("original_name") or u"").strip()
            self["heroTitle"].setText(gui_text(visible_title(title, 65)))
            if active:
                self["heroTitle"].hide()
            elif title:
                self["heroTitle"].show()
            else:
                self["heroTitle"].hide()
        except Exception:
            pass

    def _resolve_package_logo(self, category=None, selected=None):
        """Choose a logo *only* from this GENRE package's own category name.

        A platform/quality logo is meaningful when the category actually
        identifies it. Generic MOVIES/SERIES artwork is not an exact logo for
        a longer package name (TOP MOVIES, EN - 2020 & OLD, etc.). Never take
        branding from the currently highlighted poster or nearby posters.
        """
        if not isinstance(category, dict):
            return '', ''
        name = re.sub(r'\s+', ' ', text_type(category.get('name') or u'')).strip()
        if not name:
            return '', ''
        try:
            path = (package_logo_path(name, self.kind)
                    or package_browser_logo_path(name, self.kind))
            if path and os.path.isfile(path):
                basename = os.path.basename(path).lower()
                # Generic kind badges discard the important category qualifier.
                # In those cases the actual category name is more informative.
                generic_badge = bool(re.match(
                    r'^(?:badge_|package_)(?:movies|series)(?:_ar)?_(?:full|compact)\.png$',
                    basename))
                generic_name = re.sub(u'[^a-z0-9\u0600-ۿ]+', ' ', name.lower()).strip()
                if generic_badge and generic_name not in (
                        'movies', 'movie', 'films', 'film', 'tv shows',
                        'series', 'مسلسلات', 'افلام', 'أفلام'):
                    return '', name
                return path, name
        except Exception:
            pass
        return '', name

    def _update_header_brand(self, category=None, selected=None):
        """Display exactly one item in the right-side full-backdrop brand slot."""
        path, name = self._resolve_package_logo(category)
        # Hide both old states before painting the new category. Avoid leaving
        # a stale logo on quick category switches or a stale caption beneath it.
        try:
            self['packageLogo'].hide()
        except Exception:
            pass
        try:
            self['subheading'].hide()
            self['subheading'].setText('')
        except Exception:
            pass
        if path and os.path.isfile(path):
            try:
                image = self['packageLogo']
                if image.instance is not None:
                    image.instance.setPixmapFromFile(path)
                    image.show()
                    return
            except Exception:
                try:self['packageLogo'].hide()
                except Exception:pass
        # Fallback: preserve the real category name, including language tags.
        label = name or 'GENRE'
        limit = 42 if any('\u0600' <= ch <= '\u06ff' for ch in label) else 48
        if len(label) > limit:
            label = label[:limit - 1].rstrip() + u'…'
        try:
            self['subheading'].setText(label)
            self['subheading'].show()
        except Exception:
            pass

    def _adjust_movie_logo_size(self):
        """Slightly larger film clearlogo, same existing cached PNG.

        Stay entirely left of hero title/metadata (which begin at x=570).
        The series layout retains its exact original dimensions.
        """
        try:
            widget = self["heroLogo"].instance
            if not widget:
                return
            if self.kind == "vod":
                widget.move(ePoint(sx(25), sy(30)))
                widget.resize(eSize(sx(535), sy(142)))
            else:
                widget.move(ePoint(sx(55), sy(35)))
                widget.resize(eSize(sx(490), sy(130)))
        except Exception:
            pass

    def _hero_logo_canvas(self):
        # Same detail-page PNG resolver, sized to this page's already-approved
        # holder. Preparing the right aspect ratio avoids stretch-on-first-paint.
        return (535, 142) if self.kind == 'vod' else (490, 130)

    def _commit_identity_hero_logo(self, token, path):
        # A decoded verified logo wins only AFTER the receiver can paint it.
        # Marking it authoritative before LoadPixmap/ePicLoad succeeds used to
        # suppress the working Details-style direct PNG on old DreamOS.
        if getattr(self, '_hero_identity_logo_pending', None) != (token, path):
            return
        if self._closed or token != self._hero_token:
            return
        with _GENRE_PROVIDER_DETAIL_LOCK:
            entry = self._hero_cache.setdefault(token, {'images': {}})
            entry['logo_priority'] = 3
            entry.setdefault('images', {})['heroLogo'] = path
        self._hero_identity_logo_pending = None

    def _show_identity_hero_logo(self, token, path):
        if self._closed or token != self._hero_token or not path or not os.path.isfile(path):
            return
        entry = self._hero_cache.get(token) or {}
        # The verified direct PNG is already visible: don't replace it with
        # a different Ultra canvas for the same film (big-then-small jump).
        current = (entry.get('images') or {}).get('heroLogo')
        if (entry.get('logo_priority', 0) >= 2 and current and
                getattr(self, '_hero_logo_painted', None) == (token, current)):
            return
        self._hero_identity_logo_pending = (token, path)
        self._show_hero_image(token, 'heroLogo', path)

    def _schedule_hero(self):
        key = (self._generation, self.index, self.kind)
        if key == self._hero_token:
            return
        self._hero_token = key
        self._hero_logo_painted = None
        # Keep existing artwork visible while navigating; reuse already resolved
        # paths without network or image processing on the GUI thread.
        entry = self._hero_cache.get(key)
        available = (entry or {}).get("images") or {}
        for widget in ("heroBackdrop", "heroLogo"):
            path = available.get(widget)
            if path and os.path.isfile(path):
                self._show_hero_image(key, widget, path)
            else:
                # Otherwise a prior show's background/logo remains visible.
                try:
                    self[widget].hide()
                    if widget == "heroLogo":
                        self._set_hero_logo_state(False)
                except Exception:
                    pass
        if entry and entry.get("complete"):
            return
        # The catalogue image may already be on HDD. Render it without waiting
        # for the 650 ms TMDb metadata debounce (or a remote TMDb search).
        selected = self._selected_item() or {}
        direct_backdrop = _server_backdrop_url(self.source, selected)
        if direct_backdrop and not available.get("heroBackdrop"):
            self._request_hero_artwork(key, direct_backdrop, "backdrops", "heroBackdrop", "provider")
        try:
            self._hero_timer.stop()
            # Returning to a previously resolved title should be immediate;
            # cold selections keep the 650 ms debounce to avoid request floods.
            selected=self._selected_item() or {}
            lookup_key=(text_type(selected.get("name") or selected.get("title") or u""),
                        self.kind,str(selected.get("year") or "")[:4],
                        str(selected.get("tmdb_id") or selected.get("tmdb") or selected.get("tmdbId") or ""))
            # Short HD-Satelit debounce (170 ms) instead of 650 ms per selection.
            self._hero_timer.start(85 if lookup_key in self._hero_lookup_cache else 170, True)
        except Exception:
            pass

    def _request_hero_artwork(self, token, url, category, widget, origin="provider"):
        """Cache-first artwork; a real provider backdrop wins a TMDb fallback."""
        if self._closed or token != self._hero_token:
            return
        url = _hero_backdrop_url(url) if widget == "heroBackdrop" else _hero_logo_url(url)
        if not url:
            return
        if widget == "heroLogo" and origin == "provider":
            # Preserve the provider clearlogo as a last-resort candidate.
            # A TMDb URL which downloads but fails to paint must not forever
            # suppress an already known provider logo for this same title.
            with _GENRE_PROVIDER_DETAIL_LOCK:
                entry = self._hero_cache.setdefault(token, {"images": {}})
                entry["provider_logo_url"] = url
        def ready(path):
            if self._closed or not path or not os.path.isfile(path):
                return
            def prepare():
                try:
                    prepared = (_dim_hero_backdrop(path) if widget == "heroBackdrop" and not _genre_like(self) else path)
                    if not prepared or not os.path.isfile(prepared) or self._closed:
                        return
                    with _GENRE_PROVIDER_DETAIL_LOCK:
                        entry = self._hero_cache.setdefault(token, {"images": {}})
                        if (widget == "heroBackdrop" and origin != "provider"
                                and entry.get("server_backdrop_ready")):
                            return
                        if widget == "heroBackdrop" and origin == "provider":
                            entry["server_backdrop_ready"] = True
                        if widget == "heroLogo":
                            # A genuine localized TMDb clearlogo overrides a
                            # provider clearlogo, never the other way round.
                            weight = 2 if origin == "tmdb" else 1
                            if weight < entry.get("logo_priority", 0):
                                return
                            entry["logo_priority"] = weight
                        entry.setdefault("images", {})[widget] = prepared
                    if token == self._hero_token:
                        self._post_to_gui(self._show_hero_image, token, widget, prepared)
                except Exception:
                    pass
            try:
                _GENRE_PROVIDER_CHECK_POOL.submit(prepare)
            except RuntimeError:
                pass
        if widget == "heroLogo":
            # Cached JPEGs created by the older Ultra path can look like ugly
            # opaque rectangles. Only a verified transparent logo is displayed;
            # missing/damaged ones are repaired individually without touching
            # the high-speed poster/backdrop downloader or unrelated cache.
            request_transparent_logo(url, dict(self.source or {}), ready,
                                     lambda _path: None, self._post_to_gui)
            return
        cached = cached_artwork(url, category)
        if cached:
            ready(cached)
        else:
            # GENRE: the selected title's backdrop goes ahead of the poster page.
            genre_ultra_request(url, category, dict(self.source or {}), ready, lambda _path: None, self._post_to_gui,
                                urgent=(widget == "heroBackdrop" and _genre_like(self)))

    def _load_provider_hero_info(self, item, token, kind):
        """Enrich selected GENRE text from provider info without blocking arrows."""
        source = dict(self.source or {})
        source_type = str(source.get("type") or "xtream").lower()
        if source_type not in ("xtream", "stalker"):
            return
        item_id = str(item.get("series_id") or item.get("stream_id") or item.get("id") or "").strip()
        if not item_id:
            return
        def worker():
            try:
                cache_key = stable_cache_key(
                    "genre_provider_details_v1", source.get("type"),
                    source.get("url") or source.get("base_url") or source.get("host"),
                    source.get("username") or source.get("user"),
                    source.get("password"), kind, item_id)
                metadata = persistent_cache_get(cache_key)
                # Entries written by older versions contain only text, so
                # refresh them once to find images missing from listing rows.
                if (not isinstance(metadata, dict) or "_genre_backdrop_url" not in metadata
                        or "_genre_logo_url" not in metadata):
                    client = get_source_client(source)
                    payload = (client.series_info(item_id) if kind == "series"
                               else client.vod_info(item_id)) or {}
                    metadata = _genre_provider_metadata(payload)
                    provider_poster, provider_backdrop = _genre_provider_artwork(source, payload)
                    metadata["_genre_poster_url"] = provider_poster
                    metadata["_genre_backdrop_url"] = provider_backdrop
                    # Provider details can hold a clearlogo even if catalogue
                    # rows expose only a poster or an image placeholder.
                    metadata["_genre_logo_url"] = provider_logo_url(source, payload)
                    # Cache only compact metadata and image URL strings, never
                    # the full series episodes or the VOD response.
                    persistent_cache_set(cache_key, "genre_provider_details",
                                         metadata, 6 * 60 * 60 if any(metadata.values()) else 5 * 60)
                if self._closed or token != self._hero_token:
                    return
                provider_backdrop = metadata.get("_genre_backdrop_url") or ""
                if provider_backdrop:
                    self._request_hero_artwork(token, provider_backdrop, "backdrops", "heroBackdrop", "provider")
                detail_logo = metadata.get("_genre_logo_url") or ""
                if detail_logo:
                    self._request_hero_artwork(token, detail_logo, "logos", "heroLogo", "provider")
                if any(metadata.get(key) for key in ("title", "description", "rating", "year", "genres")):
                    self._post_to_gui(self._update_hero_info, token, metadata, "provider")
                # A provider TMDb id can identify a film whose IPTV title has
                # prefixes/suffixes, where title search fails. Prefer that id.
                tmdb_id = metadata.get("tmdb_id")
                if tmdb_id and not self._closed and token == self._hero_token:
                    tmdb = TMDbClient()
                    details = tmdb.details_bundle(tmdb_id, kind) or {}
                    # The Python 3 title-logo path uses the FULL TMDb details
                    # bundle, not just the search row. GENRE already fetches
                    # that bundle for provider metadata but previously discarded
                    # its images and ID for title logos. Reuse it on the same
                    # worker after confirming that the provider ID really
                    # belongs to the highlighted title, not to a portal row.
                    selected_title = text_type(item.get('name') or
                                               item.get('title') or u'').strip()
                    selected_year = str(item.get('year') or
                                        metadata.get('year') or '')[:4]
                    verified = _verified_genre_title_tmdb(
                        details, selected_title, kind, selected_year)
                    if verified and not self._closed and token == self._hero_token:
                        try:
                            logo_url = localized_logo_url(
                                tmdb, 'tv' if kind == 'series' else 'movie',
                                details['id'], (details.get('images') or {}),
                                details=details, item=item, title=selected_title)
                            if logo_url and not self._closed and token == self._hero_token:
                                self._request_hero_artwork(
                                    token, logo_url, 'logos', 'heroLogo', 'tmdb')
                        except Exception:
                            pass  # Full metadata is still usable without a logo.
                    if details and not self._closed and token == self._hero_token:
                        self._post_to_gui(self._update_hero_info, token, {
                            "title": details.get("title") or details.get("name") or "",
                            "description": details.get("overview") or "",
                            "year": str(details.get("release_date") or details.get("first_air_date") or "")[:4],
                            "rating": str(details.get("vote_average") or ""),
                            "genres": details.get("genres") or details.get("genre_ids") or [],
                            "runtime": details.get("runtime") or "",
                            "original_language": details.get("original_language") or "",
                        }, "tmdb_verified")
            except Exception:
                # Retain the instant catalog fallback on a broken/unavailable provider.
                return
        thread = thread_factory(target=worker, name="TiviMateGenreProviderInfo")
        thread.daemon = True
        thread.start()

    def _load_hero(self):
        item = self._selected_item()
        token = self._hero_token
        if not item or self._closed:
            return
        item = dict(item)
        title = text_type(item.get("name") or item.get("title") or u"").strip()
        kind = self.kind
        year = str(item.get("year") or "")[:4]
        # Listing rows can omit the synopsis entirely, even though it is present
        # in get_vod_info/get_series_info (as seen in Movie/Series Details).
        # Resolve the detailed server record independently from TMDb artwork.
        self._load_provider_hero_info(item, token, kind)
        def worker():
            try:
                if self._closed or token != self._hero_token:
                    return
                client = TMDbClient()
                # Paint cached/provider backdrops first; the source listing
                # need not wait for the metadata/search request to finish.
                listing_backdrop = _server_backdrop_url(self.source, item)
                if listing_backdrop:
                    self._request_hero_artwork(token, listing_backdrop, "backdrops", "heroBackdrop", "provider")
                # Do not require a backdrop to identify a movie: a matching
                # TMDb row can have real metadata without any image at all.
                catalog_id = item.get("tmdb_id") or item.get("tmdb") or item.get("tmdbId")
                lookup_key=(title,kind,year,str(catalog_id or ""))
                saved=self._hero_lookup_cache.get(lookup_key)
                if saved is not None:
                    found=saved
                else:
                    # Stalker often returns its own numeric media ID in a
                    # field labelled tmdb_id.  An invalid TMDb lookup must not
                    # block the safer, title/year-verified TMDb search.
                    found = (client.details_bundle(catalog_id, kind) if catalog_id else {}) or {}
                    if found:
                        match_year = re.search(r"(?:19|20)\d{2}", str(
                            found.get("release_date") or found.get("first_air_date") or ""))
                        # A portal id accidentally matching a DIFFERENT TMDb
                        # record must not replace the selected Arabic title or
                        # produce a logo from an unrelated movie/series.
                        if (not (found.get("title") or found.get("name")) or
                                (kind != "series" and year.isdigit() and match_year
                                 and year != match_year.group(0))):
                            found = {}
                    if not found:
                        found = client.search_artwork(title, kind, year or None) or {}
                    if found and not self._closed and token==self._hero_token:
                        if len(self._hero_lookup_cache) >= 96:
                            try:
                                self._hero_lookup_cache.pop(next(iter(self._hero_lookup_cache)))
                            except (KeyError, StopIteration):
                                pass
                        self._hero_lookup_cache[lookup_key]=found
                # Store only verified TMDb search/details identity, never an
                # unverified portal-supplied numeric id.
                verified_id = found.get('id') if isinstance(found, dict) else None
                if verified_id:
                    try:
                        from .identity_artwork_index import remember, cached_url
                        remember(kind, verified_id, found.get('poster_path'), found.get('backdrop_path'))
                        local_backdrop = cached_url(kind, verified_id, 'backdrop')
                        if local_backdrop:
                            self._request_hero_artwork(token, local_backdrop, 'backdrops', 'heroBackdrop', 'tmdb')
                    except Exception:
                        pass
                backdrop = _server_backdrop_url(self.source, item) or found.get("backdrop_path")
                media_id = found.get("id") or catalog_id
                server_description = text_type(item.get("plot") or item.get("description") or item.get("overview") or item.get("storyline") or item.get("plot_outline") or u"").strip()
                server_rating = str(item.get("rating") or item.get("vote_average") or "").strip()
                # The quick server metadata stays visible while localized TMDb
                # metadata is resolved asynchronously below.
                description = preferred_metadata_text(found.get("overview"), server_description, client.language)
                rating = server_rating or str(found.get("vote_average") or "").strip()
                release = str(item.get("year") or item.get("release_date") or found.get("release_date") or found.get("first_air_date") or "")[:4]
                info = {
                    "title": title,
                    "year": release,
                    "rating": rating,
                    "description": description,
                    "category": text_type(item.get("category_name") or u"").strip(),
                    "genres": found.get("genres") or found.get("genre_ids") or
                              item.get("genres") or item.get("genre_ids") or item.get("genre") or "",
                    "runtime": found.get("runtime") or "",
                    "original_language": found.get("original_language") or "",
                }
                if not self._closed and token == self._hero_token:
                    try:
                        from twisted.internet import reactor
                        reactor.callFromThread(self._update_hero_info, token, info, "tmdb_search")
                    except Exception:
                        pass
                selected_lang = str(client.language or "en-US").lower()
                if media_id:
                    # Load full TMDb metadata for every selected language; the
                    # search index and poster rows often omit overview text.
                    def localize(selected_id=media_id, expected=token, base=dict(info)):
                        try:
                            if not selected_id or self._closed or expected != self._hero_token:
                                return
                            localized = client.details_bundle(selected_id, kind) or {}
                            if self._closed or expected != self._hero_token:
                                return
                            localized_title = localized.get("title") if kind == "vod" else localized.get("name")
                            localized_overview = localized.get("overview")
                            # Arabic requires actual Arabic script, because
                            # TMDb sometimes replies with original English.
                            if selected_lang.startswith("ar"):
                                def valid(value):
                                    return any(u"\u0600" <= c <= u"\u06ff" for c in text_type(value or u""))
                            else:
                                # For French/Turkish, rely on TMDb's requested
                                # locale. Both legitimately use Latin letters.
                                def valid(value):
                                    return bool(str(value or "").strip())
                            merged = {
                                "title": localized_title if valid(localized_title) else base.get("title", ""),
                                "description": localized_overview if valid(localized_overview) else base.get("description", ""),
                                "year": str(localized.get("release_date") or localized.get("first_air_date") or base.get("year") or "")[:4],
                                "rating": str(localized.get("vote_average") or base.get("rating") or ""),
                                "genres": localized.get("genres") or localized.get("genre_ids") or
                                          base.get("genres") or [],
                                "runtime": localized.get("runtime") or base.get("runtime") or "",
                                "original_language": localized.get("original_language") or base.get("original_language") or "",
                            }
                            self._post_to_gui(self._update_hero_info, expected, merged, "tmdb")
                            # Python 3's title-logo path also reads the full
                            # details-bundle images gallery. The search-row
                            # images array is commonly absent. Reuse this
                            # already-fetched bundle without a second API call.
                            images = localized.get('images') or {}
                            logos = images.get('logos') or []
                            if logos and not self._closed and expected == self._hero_token:
                                from .logo_manager import best_tmdb_logo, preferred_logo_languages
                                url = tmdb_logo_url(best_tmdb_logo(
                                    logos, preferred_logo_languages(
                                        client, localized, item, title)), 'w500')
                                if url:
                                    self._request_hero_artwork(expected, url,
                                        'logos', 'heroLogo', 'tmdb')
                        except Exception:
                            pass
                    thread_factory(target=localize, name="TiviMateGenreLocalizedMetadata", daemon=True).start()
                # Ultra policy: verified TMDb identity -> original-language gallery
                # -> English -> neutral -> Fanart (when configured) -> any-language.
                # No provider numeric stream ID may become a TMDb logo identity.
                if backdrop:
                    self._request_hero_artwork(token, backdrop, "backdrops", "heroBackdrop",
                                               "provider" if _server_backdrop_url(self.source, item) else "tmdb")
                verified_id = found.get("id") if isinstance(found, dict) else None
                if verified_id:
                    # Details is the working reference: paint a verified TMDb
                    # clearlogo URL through the shared transparent-PNG loader
                    # *before* the slower Ultra canvas builder. On DreamOS a
                    # prepared canvas can fail to decode even when the direct
                    # PNG succeeds, and must not leave the entire hero blank.
                    direct_logo = ''
                    try:
                        from .logo_manager import best_tmdb_logo, preferred_logo_languages
                        logos = ((found.get('images') or {}).get('logos') or [])
                        direct_logo = tmdb_logo_url(best_tmdb_logo(
                            logos, preferred_logo_languages(client, found, item, title)), 'w500')
                        if not direct_logo:
                            direct_logo = localized_logo_url(client,
                                'tv' if kind == 'series' else 'movie', verified_id,
                                (found.get('images') or {}), details=found,
                                item=item, title=title)
                    except Exception:
                        direct_logo = ''
                    if direct_logo and not self._closed and token == self._hero_token:
                        self._request_hero_artwork(token, direct_logo,
                            'logos', 'heroLogo', 'tmdb')
                    if self._closed or token != self._hero_token:
                        return
                    # Keep the same identity-aware, language-aware HDD cache
                    # and PNG preparation as Details. This is an improvement
                    # over direct first paint, not a prerequisite for it.
                    try:
                        from .title_logo_ultra_bridge import resolve_title_logo
                        logo_path = resolve_title_logo(client, kind, verified_id,
                            title=title, details=found, item=item,
                            canvas=self._hero_logo_canvas(),
                            cancelled=lambda: self._closed or token != self._hero_token)
                    except Exception:
                        logo_path = ''
                    if logo_path and not self._closed and token == self._hero_token:
                        self._post_to_gui(self._show_identity_hero_logo, token, logo_path)
                    elif not direct_logo and not self._closed and token == self._hero_token:
                        provider_logo = provider_logo_url(self.source, item)
                        if provider_logo:
                            self._request_hero_artwork(token, provider_logo,
                                'logos', 'heroLogo', 'provider')
                else:
                    # Only an actual provider clearlogo, never a poster, may be
                    # shown when no verified TMDb identity could be found.
                    provider_logo = provider_logo_url(self.source, item)
                    if provider_logo:
                        self._request_hero_artwork(token, provider_logo, "logos", "heroLogo", "provider")
            except Exception:
                pass
        thread_factory(target=worker, name="TiviMateGenreHero").start()

    def _show_hero_image(self, token, name, path):
        """Decode cached GENRE hero images before painting them on DreamOS.

        setPixmapFromFile may silently reject valid cached JPEG/WebP files.
        Keep one decoder per widget alive until PictureData fires, and never
        paint a callback belonging to an earlier selection.
        """
        if self._closed or token != self._hero_token or not path or not os.path.isfile(path):
            return
        if name == 'heroLogo' and path.lower().endswith('.png'):
            try:
                # Identical native alpha path to Movie/Series Details; never
                # stretch a raw source logo or composite alpha onto a dark box.
                from .transparent_pixmap import show as show_transparent_png
                if show_transparent_png(self, name, path) is not None:
                    decoders = getattr(self, '_genre_hero_decoders', None)
                    if decoders is not None:
                        decoders.pop(name, None)
                    self._set_hero_logo_state(True)
                    self._hero_logo_painted = (token, path)
                    self._commit_identity_hero_logo(token, path)
                    return
            except Exception:
                pass
        try:
            widget = self[name]
            instance = widget.instance
            if instance is None:
                return
            loader = ePicLoad()
            decoders = getattr(self, "_genre_hero_decoders", None)
            if decoders is None:
                decoders = {}
                self._genre_hero_decoders = decoders
            decoders[name] = loader
            size = instance.size()
            width, height = max(1, size.width()), max(1, size.height())

            def decoded(_=None, expected=token, target=name, source=path, current=loader):
                active = getattr(self, "_genre_hero_decoders", None)
                if active is None or active.get(target) is not current:
                    return
                active.pop(target, None)
                if self._closed or expected != self._hero_token:
                    return
                try:
                    pixmap = current.getData()
                    if pixmap:
                        target_widget = self[target]
                        if target_widget.instance is not None:
                            if target == "heroLogo":
                                # Native fitted PNGs disable scaling. Restore it
                                # for the legacy decoder fallback on old images.
                                try: target_widget.instance.setScale(1)
                                except Exception: pass
                            target_widget.instance.setPixmap(pixmap)
                            target_widget.show()
                            if target == "heroLogo":
                                self._set_hero_logo_state(True)
                                self._hero_logo_painted = (expected, source)
                                self._commit_identity_hero_logo(expected, source)
                        return
                except Exception as error:
                    self._genre_hero_error(target, source, error)
                self._recover_hero_image(expected, target, source)

            connect_picture_data(loader, decoded, self, oneshot=True)
            # Enigma2 alpha is inverted: FF means fully transparent.
            # The former #00000000 filled padded clearlogo pixels with BLACK.
            background = "#FF000000" if name == "heroLogo" else "#00000000"
            loader.setPara((width, height, 0, 0, False, 1, background))
            result = loader.startDecode(path)
            if isinstance(result, int) and result < 0:
                decoders.pop(name, None)
                self._recover_hero_image(token, name, path)
        except Exception as error:
            self._genre_hero_error(name, path, error)
            self._recover_hero_image(token, name, path)

    def _genre_hero_error(self, name, path, error):
        try:
            import logging
            logging.getLogger("TiviMateE2Py27.GENRE").warning(
                "GENRE hero image %s failed (%s): %s", name, os.path.basename(path), error)
        except Exception:
            pass

    def _recover_hero_image(self, token, name, path):
        if self._closed or token != self._hero_token:
            return
        try:
            from .native_image_recovery import request as recover
            kind = "logo" if name == "heroLogo" else "image"
            def recovered(converted):
                if self._closed or token != self._hero_token:
                    return
                if converted and os.path.isfile(converted):
                    if (name == 'heroLogo' and
                            getattr(self, '_hero_identity_logo_pending', None) == (token, path)):
                        self._hero_identity_logo_pending = (token, converted)
                    self._show_hero_image(token, name, converted)
                else:
                    self._genre_hero_error(name, path, "native image recovery unavailable")
            if recover(path, kind, recovered):
                return
        except Exception as error:
            self._genre_hero_error(name, path, error)
        self._genre_hero_error(name, path, "image decode failed")
        if name == 'heroLogo':
            self._hero_logo_decode_failed(token, path)

    def _hero_logo_decode_failed(self, token, path):
        """Forget a logo that downloaded but never painted on DreamOS.

        The old code committed its priority and cache path before ePicLoad
        succeeded, so one rejected image could leave an otherwise valid
        provider/logo fallback hidden until the plugin was restarted.
        """
        if self._closed or token != self._hero_token:
            return
        alternate = ''
        with _GENRE_PROVIDER_DETAIL_LOCK:
            entry = self._hero_cache.setdefault(token, {'images': {}})
            if (entry.get('images') or {}).get('heroLogo') == path:
                entry['images'].pop('heroLogo', None)
                entry['logo_priority'] = 0
            already_painted = getattr(self, '_hero_logo_painted', None)
            if already_painted and already_painted[0] == token and already_painted[1] != path:
                # Do not clear an already working logo on a later failed
                # request; keep it in the fast cache for the next focus too.
                entry.setdefault('images', {})['heroLogo'] = already_painted[1]
                entry['logo_priority'] = max(1, entry.get('logo_priority', 0))
                return
            self._hero_logo_painted = None
            if not entry.get('provider_logo_retry_done'):
                alternate = entry.get('provider_logo_url') or ''
                entry['provider_logo_retry_done'] = True
        self._set_hero_logo_state(False)
        if alternate:
            self._request_hero_artwork(token, alternate, 'logos', 'heroLogo', 'provider')

    def _update_hero_info(self, token, info, origin="tmdb"):
        if self._closed or token != self._hero_token:
            return
        try:
            if not isinstance(info, dict):
                self["heroInfo"].setText(text_type(info or u""))
                return
            if self._hero_text_token != token:
                self._hero_text_token = token
                self._hero_text_sources = {}
            self._hero_text_sources[origin] = dict(info)
            source = self._hero_text_sources
            # Provider full-info may arrive after localized TMDb; recomputing from
            # separated sources stops an English provider response replacing Arabic.
            tmdb_info = (source.get("tmdb_verified") or source.get("tmdb")
                         or source.get("tmdb_search") or {})
            client_lang = self._hero_language
            catalog = source.get("catalog") or self._selected_item() or {}
            cached = cached_provider_info(self.source, self.kind, catalog)
            self._set_hero_text(merge_metadata(catalog, provider=source.get("provider"),
                tmdb=tmdb_info, language=client_lang, kind=self.kind, cached=cached))
        except Exception:
            pass

    def _render_genre_metadata_pills(self, values):
        """Compact only visible content badges; never obscure the right heading."""
        xpos = GENRE_PILL_X
        for name, width, inset, _style in GENRE_PILL_SPECS:
            raw = values.get(name) or ''
            text = text_type(raw).strip()
            if name == 'genreCategories' and len(text) > 30:
                text = text[:28].rstrip(u' ,،') + u'…'
            widget = self[name]
            bg = self[name + 'Bg']
            # DreamOS Python 2.7 eLabel expects UTF-8 GUI strings.  A
            # unicode value can silently render an empty pill even though
            # its background is visible.  Keep text as unicode for logic,
            # but pass bytes to the Enigma2 label, like package titles.
            widget.setText(gui_text(text))
            if not text:
                widget.hide()
                bg.hide()
                continue
            # Cap the metadata strip before MOVIES/TV SHOWS; all positions
            # use display_scale just like GENRE's existing 24-card selector.
            if xpos + width > 1550:
                widget.hide()
                bg.hide()
                continue
            try:
                bg.instance.move(ePoint(sx(xpos), sy(GENRE_PILL_Y)))
                widget.instance.move(ePoint(sx(xpos + inset), sy(GENRE_PILL_Y)))
                bg.show()
                widget.show()
            except Exception:
                # Components are attached before the receiver creates widgets.
                widget.hide()
                bg.hide()
            xpos += width + 8

    def _set_hero_text(self, info):
        """Update top information labels only; do not repaint any artwork."""
        title = text_type(info.get("title") or u"").strip()
        year = str(info.get("year") or "").strip()[:4]
        rating = str(info.get("rating") or "").strip()
        description = text_type(info.get("description") or u"").strip()
        category = text_type(info.get("category") or u"").strip()
        is_ar = has_arabic_text(u" ".join([title, description, category]))
        if is_ar:
            parts = [part for part in (category, (u"★ " + rating[:4]) if rating else "", year) if part]
        else:
            parts = [part for part in (year, (u"★ " + rating[:4]) if rating else "", category) if part]
        # The metadata sources are selection-scoped by _hero_text_token.
        # Keep a previously displayed Arabic title if a late partial server
        # response arrives with English-only text for that SAME film.
        try:
            from .metadata_display import keep_arabic_on_late_update
            if getattr(self, "_hero_visible_title_token", None) == self._hero_token:
                title = keep_arabic_on_late_update(
                    getattr(self, "_hero_visible_title", ""), title, self._hero_language)
            self._hero_visible_title_token = self._hero_token
            self._hero_visible_title = title
        except Exception:
            pass
        self._hero_plain_title = title
        self._set_hero_logo_state(getattr(self, '_hero_logo_active', False))
        # Keep the original compact hero metadata in Cinematic subclasses; only
        # GENRE Grid uses this dedicated colour-badge row.
        if _genre_like(self):
            source_info = getattr(self, '_hero_text_sources', {}) or {}
            item = self._selected_item() or {}
            quality = extract_resolution(item, source_info.get('catalog') or {},
                                         source_info.get('provider') or {})
            # Explicit stream resolution only: never invent 4K from TMDb artwork.
            # The display metadata is merged across provider and TMDb sources.
            year_value, genres = _year_genre_from_sources([
                info, source_info.get('provider') or {}, item,
                source_info.get('catalog') or {}])
            year_value = year_value or year
            genres = _actual_media_genre(source_info.get('tmdb_verified') or {}, source_info.get('tmdb') or {},
                                         source_info.get('tmdb_search') or {}, source_info.get('provider') or {},
                                         info, item, source_info.get('catalog') or {})
            from .resolution_badge import extract_duration
            runtime = extract_duration(info, source_info.get('provider') or {}, item, source_info.get('catalog') or {})
            rating_text = _genre_pill_score(extract_rating(
                info, source_info.get('tmdb_verified') or {},
                source_info.get('tmdb') or {}, item))
            sources = (source_info.get('provider') or {},
                       item, source_info.get('tmdb_verified') or {},
                       source_info.get('tmdb') or {}, source_info.get('catalog') or {})
            language = _genre_pill_language(*sources)
            age = _genre_pill_age(*sources)
            # The exact visual strip in the approved mockup, plus an optional
            # verified stream-quality pill. Unknown data never gets invented.
            badges = {'genreYear': year_value, 'genreCategories': genres,
                      'genreRating': rating_text, 'genreDuration': runtime,
                      'genreLanguage': language, 'genreAge': age,
                      'genreQuality': quality}
            self._render_genre_metadata_pills(badges)
            # All repeated metadata is inside pills, not a second plain line.
            self["heroMeta"].setText("")
        else:
            self["heroMeta"].setText(gui_text(u"   •   ".join(text_type(part) for part in parts)))
        self["heroPlot"].setText(gui_text(description[:330]))

    def start(self):
        self._generation += 1
        try: self._recent_grid_timer.stop()
        except Exception: pass
        self._recent_grid_reply = None
        self._cancel_poster_jobs()
        self.genre_items = []
        self.index = 0
        self.page_start = 0
        self._poster_tokens = {}
        self._poster_resolved_priority.clear()
        self._poster_tmdb_started.clear()
        self._rendered_page_key = None
        self._render_nav()
        self._render_empty("")
        # A virtual actor collection is already prepared by Movie/Series
        # Details. Never fetch provider categories: it would replace the
        # actor's results with unrelated package rows on either grid skin.
        if self.source.get('_actor_search_name'):
            actor_name = text_type(self.source.get('_actor_search_name') or u'Actor')
            category = {'id': '__actor_results__', 'name': actor_name}
            self.categories = [category]
            self.category_index = 0
            self.initial_category_id = ''
            self._render_genre_bar()
            self._apply_items(self.source.get('_actor_search_rows') or [],
                              category, self._generation)
            return
        if self._recent_grid_view:
            # Do NOT query get_category_streams('__recent_added__').  The id is
            # a Packages navigation shortcut, not a real Xtream/Stalker id.
            category = {'id': '__recent_added__', 'name': tr('RECENTLY ADDED')}
            self.categories = [category]
            self.category_index = 0
            self.initial_category_id = ''
            self._poster_sort_mode = 'default'
            self._render_genre_bar()
            self._load_recent_grid(self._generation)
            return
        self._load_categories(self._generation)

    def _recent_grid_rows(self, items):
        """Preserve real category IDs and provider dates across poster styles."""
        result, seen = [], set()
        for item in (items or []):
            if not isinstance(item, dict):
                continue
            row = dict(item)
            cid = str(row.get('_source_category_id') or row.get('category_id') or
                      row.get('categoryId') or row.get('genre_id') or
                      row.get('group_id') or row.get('group') or '').strip()
            if cid and not cid.startswith('__'):
                row['_source_category_id'] = cid
                row['category_id'] = cid
            identity = _content_identity(row, self.kind)
            if identity in seen:
                continue
            seen.add(identity)
            result.append(row)
        try:
            result = filter_items(self.source, self.kind, result)
        except Exception:
            pass
        # recent_added_items already orders by actual provider add date;
        # don't replace that order with movie release year on undated rows.
        return result

    def _recent_grid_apply(self, rows, generation):
        if (self._closed or generation != self._generation or not self.categories or
                self.categories[self.category_index].get('id') != '__recent_added__'):
            return
        category = self.categories[self.category_index]
        # Recent's original provider ADD ordering survives initial render;
        # a later user-initiated SORT selection still takes effect.
        self._apply_items(self._recent_grid_rows(rows), category, generation)

    def _recent_grid_poll(self):
        if self._closed:
            self._recent_grid_timer.stop()
            return
        reply = self._recent_grid_reply
        if reply is None:
            # A blocked provider cannot leave an Enigma2 repeating timer
            # running indefinitely after the useful on-screen wait expires.
            if time.time() - getattr(self, '_recent_grid_started', time.time()) >= 30.0:
                self._recent_grid_timer.stop()
                if not self.genre_items:
                    self['status'].setText('Recent Added is slow. Reopen to retry.')
            return
        self._recent_grid_reply = None
        self._recent_grid_timer.stop()
        generation, result, error = reply
        if generation != self._generation:
            return
        if result:
            self._recent_grid_apply(result, generation)
        elif not self.genre_items:
            self['status'].setText(
                'Recent Added is temporarily unavailable. Retry by reopening.'
                if error else 'No Recent Added titles available.')
        # A server failure must NEVER replace an existing last-good snapshot.

    def _load_recent_grid(self, generation):
        """Same verified feed/cache as the ordinary Recent Added package.

        Use instant cache-first rendering, then refresh off the GUI thread.
        No category-specific fetches or new artwork/decoder worker pools.
        """
        try:
            from .ui import _recent_media_cache_state
            cached, fresh = _recent_media_cache_state(self.source, self.kind)
        except Exception:
            cached, fresh = [], False
        if cached:
            self._recent_grid_apply(cached[:200], generation)
            if fresh:
                return
        else:
            # Keep the Recent page visually quiet on a cold cache. The worker
            # still fetches and updates results asynchronously, without an
            # on-screen loading message. Ordinary GENRE pages are unchanged.
            self['status'].setText('')
        source = dict(self.source)
        kind = self.kind
        self._recent_grid_reply = None
        self._recent_grid_started = time.time()
        self._recent_grid_timer.start(200, False)

        def worker():
            try:
                from .filters import get_cached_categories, get_allowed_category_ids
                from .recent_feed import recent_added_items
                from .ui import _save_recent_media_cache
                client = get_source_client(source)
                cats, _origin = get_cached_categories(
                    source, kind, client=client, wait_for_server=True)
                allowed = get_allowed_category_ids(source, kind)
                categories = [dict(row) for row in (cats or [])
                              if isinstance(row, dict) and
                              str(row.get('category_id') or row.get('id') or '').strip() and
                              not str(row.get('category_id') or row.get('id')).startswith('__') and
                              (allowed is None or
                               str(row.get('category_id') or row.get('id')) in allowed)]
                # Never fall back to an arbitrary subset of packages.
                result = recent_added_items(
                    source, kind, client, categories, 200,
                    cancelled=lambda: self._closed or generation != self._generation)
                if result:
                    _save_recent_media_cache(source, kind, result)
                if not self._closed and generation == self._generation:
                    self._recent_grid_reply = (generation, result, '')
            except Exception as exc:
                if not self._closed and generation == self._generation:
                    self._recent_grid_reply = (generation, [], str(exc))

        t = thread_factory(target=worker, name='TiviMateRecentGenre', daemon=True)
        t.start()

    def _render_nav(self):
        for index, label in enumerate(self.TOP):
            value = nav_label(label)
            if label == "GENRE":
                value = "[ %s ]" % value
            self["nav%d" % index].setText(value)

    def _load_categories(self, generation):
        source = dict(self.source)
        kind = self.kind

        def worker():
            try:
                client = get_source_client(source)
                # This worker is already off the GUI thread. A nonblocking
                # probe followed immediately by a blocking fetch used to
                # initiate TWO requests on cold cache, then re-render twice.
                # The blocking API itself prefers RAM/disk and refreshes stale
                # data asynchronously, so a single call keeps cache-first UX.
                found, _origin = get_cached_categories(source, kind, client=client, wait_for_server=True)
                self._post_to_gui(self._apply_categories, self._normalise_categories(found), generation, True)
            except Exception:
                self._post_to_gui(self._apply_categories, [], generation, True)

        thread = thread_factory(target=worker, name="TiviMateStandaloneGenreCategories")
        thread.daemon = True
        thread.start()

    def _normalise_categories(self, rows):
        try:
            rows = filter_categories(self.source, self.kind, rows or [])
        except Exception:
            rows = list(rows or [])
        result = []
        seen = set()
        for row in rows:
            if isinstance(row, (tuple, list)) and len(row) >= 2:
                row = {"category_name": row[0], "category_id": row[1]}
            if not isinstance(row, dict):
                continue
            category_id = _category_id(row)
            name = _category_name(row)
            if not category_id or not name or category_id in seen:
                continue
            seen.add(category_id)
            result.append({"id": category_id, "name": name})
        result.sort(key=lambda item: _genre_sort_key({"category_name": item["name"]}))
        return result

    def _apply_categories(self, rows, generation, from_server):
        if self._closed or generation != self._generation:
            return
        previous_id = ""
        try:
            if self.categories:
                previous_id = str(self.categories[self.category_index].get("id") or "")
        except Exception:
            pass
        self.categories = list(rows or [])
        self.genre_links[self.kind] = dict((row["name"], {"kind": self.kind, "category_id": row["id"]}) for row in self.categories)
        if not self.categories:
            self._render_empty(tr("No categories available."))
            return
        # RECENTLY ADDED is the first entry of every poster style's list
        # (GENRE, Cinematic, Apple, Royal Circles). It reuses the verified
        # cross-package Recent feed/cache; the page still opens on the first
        # real package unless Recent itself was chosen.
        add_recent = (self.__class__.__name__ not in ('CollectionPartsScreen', 'OtherSourcesTimelineScreen')
                      and not self.source.get('_actor_search_name')
                      and not any(str(row.get("id")) == '__recent_added__' for row in self.categories))
        if add_recent:
            self.categories.insert(0, {"id": "__recent_added__", "name": tr("RECENTLY ADDED")})
            if not (self.initial_category_id or previous_id):
                self.category_index = max(1, self.category_index) if len(self.categories) > 1 else 0
        selected = self.initial_category_id or previous_id
        self.initial_category_id = ""
        if selected:
            for index, row in enumerate(self.categories):
                if str(row.get("id")) == selected:
                    self.category_index = index
                    break
            else:
                self.category_index = min(self.category_index, len(self.categories) - 1)
        else:
            self.category_index = min(self.category_index, len(self.categories) - 1)
        self._render_genre_bar()
        self._load_selected_genre(generation)

    def _render_genre_bar(self):
        if not self.categories:
            for slot in range(GENRE_BAR_SIZE):
                self["genre%d" % slot].setText("")
            return
        start = (self.category_index // GENRE_BAR_SIZE) * GENRE_BAR_SIZE
        for slot in range(GENRE_BAR_SIZE):
            position = start + slot
            if position >= len(self.categories):
                self["genre%d" % slot].setText("")
                continue
            name = _short_text(self.categories[position].get("name"), 19)
            self["genre%d" % slot].setText(("[ %s ]" % name) if position == self.category_index else name)

    def _load_selected_genre(self, generation):
        if not self.categories:
            return
        category = dict(self.categories[self.category_index])
        if str(category.get("id") or "") == "__recent_added__":
            # Virtual cross-package feed: never ask the provider for this id.
            self._cancel_poster_jobs()
            self.genre_items = []
            self.index = 0
            self.page_start = 0
            self._poster_tokens = {}
            self._poster_resolved_priority.clear()
            self._poster_tmdb_started.clear()
            self._rendered_page_key = None
            self._render_empty("")
            self._pkg_first_load_done = True
            self._load_recent_grid(generation)
            return
        source = dict(self.source)
        kind = self.kind
        cache_id = str(category.get('id') or '')
        previous = getattr(self, '_session_category_rows', {}).get(cache_id)
        if previous and time.time() - previous[0] < 600.0:
            self._cancel_poster_jobs()
            self._apply_items(list(previous[1]), category, generation)
            return
        self._cancel_poster_jobs()
        self.genre_items = []
        self.index = 0
        self.page_start = 0
        self._poster_tokens = {}
        self._poster_resolved_priority.clear()
        self._poster_tmdb_started.clear()
        self._rendered_page_key = None
        self._render_empty("")

        def worker():
            items = []
            try:
                client = get_source_client(source)
                # One cache-first call avoids scheduling a duplicate fetch
                # and then fetching the same package immediately again.
                items, _origin = get_category_streams(source, kind, client, category["id"], use_cache=True, wait_for_server=True)
            except Exception:
                items = []
            rows = prepare_genre_latest_rows(
                source, kind, category["id"], category["name"], items
            )
            self._post_to_gui(self._apply_items, rows, category, generation)

        thread = thread_factory(target=worker, name="TiviMateStandaloneGenreItems")
        thread.daemon = True
        thread.start()

    def _apply_items(self, rows, category, generation):
        if self._closed or generation != self._generation:
            return
        if not self.categories or self.category_index >= len(self.categories):
            return
        if str(self.categories[self.category_index].get("id")) != str(category.get("id")):
            return
        self._cancel_poster_jobs()
        self._poster_original_rows = list(rows or [])
        # Keep only four verified package snapshots per open screen. Do not
        # cache virtual Recent or failed cold-cache empty responses.
        if rows and str(category.get('id') or '') not in ('__recent_added__', '__actor_results__'):
            memo = getattr(self, '_session_category_rows', None)
            if memo is None:
                memo = {}
                self._session_category_rows = memo
            memo[str(category.get('id') or '')] = (time.time(), list(rows))
            if len(memo) > 4:
                oldest = min(memo, key=lambda key: memo[key][0])
                memo.pop(oldest, None)
        self.genre_items = self._sort_poster_rows(self._poster_original_rows)
        self.index = 0
        self.page_start = 0
        self._poster_tokens = {}
        self._rendered_page_key = None
        self.render()


    def _new_badge_tick(self):
        self._refresh_new_badges(getattr(self, '_new_badge_visible_limit', PAGE_SIZE))

    def _clear_new_badges(self):
        try:
            self._new_badge_timer.stop()
        except Exception:
            pass
        for i in range(PAGE_SIZE):
            if self._new_badge_displayed.get(i, False):
                self['newBadge%d' % i].hide()
        self._new_badge_displayed.clear()

    def _refresh_new_badges(self, limit=PAGE_SIZE):
        # Only 24 O(1) metadata reads; no IO, network, decoding or image writes.
        self._new_badge_visible_limit = limit
        now = time.time()
        nearest = None
        try:
            self._new_badge_timer.stop()
        except Exception:
            pass
        rows = self.genre_items or []
        for slot in range(PAGE_SIZE):
            ix = self.page_start + slot
            deadline = (_new_badge_expiry(rows[ix], now, self.kind)
                        if slot < limit and ix < len(rows) else 0)
            # Python 2.7 GENRE paints three placeholders at a time. Never show
            # a badge over a slot that hasn't been painted yet.
            if (getattr(self, '_poster_paint_key', None) == self._rendered_page_key and
                    slot not in getattr(self, '_poster_painted_slots', set())):
                deadline = 0
            visible = bool(deadline)
            if visible != self._new_badge_displayed.get(slot, False):
                try:
                    if visible:
                        self['newBadge%d' % slot].show()
                    else:
                        self['newBadge%d' % slot].hide()
                except Exception:
                    pass
                self._new_badge_displayed[slot] = visible
            if deadline and (nearest is None or deadline < nearest):
                nearest = deadline
        if nearest is not None:
            # A one-shot timer hides NEW even if the viewer stays on the page.
            try:
                self._new_badge_timer.start(max(1, int((nearest-now)*1000)+80), True)
            except Exception:
                pass

    def _render_empty(self, message):
        self._clear_new_badges()
        try:
            self._hero_timer.stop()
        except Exception:
            pass
        self._hero_token = None
        self._hero_text_token = None
        self._hero_text_sources = {}
        self._hero_plain_title = ""
        self._hero_logo_active = False
        heading = "TV SHOWS" if self.kind == "series" else "MOVIES"
        self["heading"].setText(heading)
        self["subheading"].setText("GENRE")
        try:
            self["subheading"].show()
        except Exception:
            pass
        try:
            self['packageLogo'].hide()
        except Exception:
            pass
        self._set_hero_logo_state(False)
        self["page"].setText("1 / 1")
        self["status"].setText(message)
        self["heroTitle"].setText("")
        self["heroMeta"].setText("")
        self["heroPlot"].setText("")
        for name, _width, _inset, _style in GENRE_PILL_SPECS:
            self[name].setText('')
            self[name].hide()
            self[name + 'Bg'].hide()
        self._render_genre_bar()
        self._rendered_page_key = None
        for slot in range(PAGE_SIZE):
            self["title%d" % slot].setText("")
            _set_meta(self["meta%d" % slot], "")
            self._set_stars(slot, None)
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        try:
            self["selector"].hide()
        except Exception:
            pass

    def render(self):
        category = self.categories[self.category_index] if self.categories else {}
        heading = "TV SHOWS" if self.kind == "series" else "MOVIES"
        total = len(self.genre_items)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        current_page = (self.index // PAGE_SIZE) + 1 if total else 1
        self.page_start = (self.index // PAGE_SIZE) * PAGE_SIZE if total else 0
        self["heading"].setText(heading)
        self._update_header_brand(category, self._selected_item() or {})
        self["page"].setText("%d / %d" % (current_page, pages))
        self["status"].setText(
            "Search all packages: %s (%d)" % (self._posterInlineState['query'], total)
            if getattr(self, '_posterInlineState', {}).get('query') else
            "%s  •  %d %s" % (str(category.get("name") or "GENRE"), total, "titles" if total != 1 else "title"))
        self._render_genre_bar()
        selected = self._selected_item() or {}
        name = text_type(selected.get("name") or selected.get("title") or u"")
        year = str(selected.get("year") or selected.get("release_date") or "")[:4]
        rating = str(selected.get("rating") or selected.get("vote_average") or "")
        description = str(selected.get("plot") or selected.get("description") or selected.get("overview") or selected.get("storyline") or selected.get("plot_outline") or "").strip()
        self._schedule_hero()
        self._update_hero_info(self._hero_token, {
            "title": name,
            "year": year,
            "rating": rating,
            "description": description,
            "category": text_type(category.get("name") or u""),
        }, "catalog")

        # Navigation inside the same page only moves the selection. Redrawing
        # every card on each arrow press used to replace all 24 cached posters
        # with placeholders and queue duplicate image decodes (visible flicker).
        page_key = (self._generation, self.page_start, total)
        if page_key != self._rendered_page_key:
            # Do not leave 24 fallback jobs queued for a page we left.
            self._cancel_poster_jobs()
            self._rendered_page_key = page_key
            self._poster_resolved_priority.clear()
            self._poster_tmdb_started.clear()
            # Clear stale tokens and last-page images immediately. Pace only
            # GUI slot binding; do not change download queue/concurrency.
            self._poster_tokens.clear()
            self._prepare_poster_paint(page_key, PAGE_SIZE)
            # Fixed grid: allocate all card outlines immediately. Bind image
            # requests top-to-bottom in catalogue order, just like Python 3.
            for slot in range(PAGE_SIZE):
                item_index = self.page_start + slot
                row = self.genre_items[item_index] if item_index < total else None
                self["poster%d" % slot].hide()
                if row is None:
                    self["shell%d" % slot].hide()
                    _set_meta(self["meta%d" % slot], "")
                    self._set_stars(slot, None)
                else:
                    self["shell%d" % slot].show()
                    year = str(row.get("year") or row.get("releaseDate") or row.get("release_date") or row.get("first_air_date") or "")[:4]
                    rating = str(row.get("rating") or row.get("rating_5based") or row.get("vote_average") or "").strip()
                    _set_meta(self["meta%d" % slot], "")
                    self._set_stars(slot, row)
            self._paint_poster_batch()
            self._next_page_warm_prepare()

        self._refresh_new_badges(PAGE_SIZE)
        if total:
            slot = self.index - self.page_start
            row = slot // GRID_COLUMNS
            column = slot % GRID_COLUMNS
            self["selector"].instance.move(ePoint(sx(GRID_X[column] - 7), sy(GRID_Y[row] - 7)))
            self["selector"].show()
        else:
            self["selector"].hide()

    def _paint_poster_batch(self):
        """Bind at most three posters per GUI tick; remote keys remain live."""
        if not getattr(self, '_poster_layout_ready', False):
            return
        if (self._closed or self._poster_paint_key != self._rendered_page_key or
                self._poster_paint_key is None or self.page_start != self._poster_paint_key[1]):
            return
        total=len(self.genre_items)
        for slot in self._next_poster_batch_slots():
            item_index=self.page_start+slot
            item=self.genre_items[item_index] if item_index<total else None
            if not item:
                self._poster_tokens.pop(slot,None)
                self["title%d" % slot].setText("")
                _set_meta(self["meta%d" % slot], "")
                self._set_stars(slot, None)
                continue
            # The frame/metadata have already been fixed in place before
            # any request. Only the real decoded poster is revealed later.
            self._set_placeholder(slot)
            self._load_poster(slot,item,item_index)
        self._refresh_new_badges(PAGE_SIZE)
        if self._poster_paint_next < len(self._poster_paint_order):
            try:
                # Submit consecutive poster slots promptly while keeping
                # the VTi/Python 2.7 GUI responsive. Network completions may
                # arrive independently; the cards themselves never move.
                self._poster_paint_timer.start(55, True)
            except Exception:
                # An unavailable timer should not hide the remaining posters.
                # Defer no screen work to a downloader; leave GUI responsive.
                pass

    def _prepare_poster_paint(self, page_key, count):
        """Request visible posters in screen order (top row to bottom).

        Match the Python 3 catalogue's cache-first ordering. Only the bind
        operation is batched for slow Python 2.7/VTi GUI loops; no shuffling,
        geometry changes, or new image/cache workers are introduced.
        """
        self._poster_paint_timer.stop()
        self._poster_paint_key = page_key
        self._poster_paint_next = 0
        self._poster_paint_order = list(range(max(0, int(count))))
        self._poster_painted_slots.clear()

    def _next_poster_batch_slots(self):
        limit = 3
        i = self._poster_paint_next
        batch = self._poster_paint_order[i:i + limit]
        self._poster_paint_next = i + len(batch)
        self._poster_painted_slots.update(batch)
        return batch

    def _set_stars(self, slot, item):
        """Show the gold star row on a poster card (no dark chip behind it)."""
        try:
            widget = self["stars%d" % slot]
        except Exception:
            return
        path = _stars_file(item) if item else ''
        try:
            if path and widget.instance and os.path.isfile(path):
                widget.instance.setPixmapFromFile(path)
                widget.show()
            else:
                widget.hide()
        except Exception:
            pass

    def _set_placeholder(self, slot):
        """Never paint a dark NO POSTER slate as if it were real artwork.

        The card shell and selection outline are already separate widgets.
        Only a verified, decoded image should make the poster itself visible.
        Avoid repeated PNG decodes in the GUI thread on VTi / Python 2.7.
        """
        try:
            self["poster%d" % slot].hide()
        except Exception:
            pass

    def _poster_url(self, item):
        # Use the very same provider image extraction as ContentHomeScreen.
        try:
            url = _genre_provider_poster_url(self.source, item)
        except Exception:
            url = ""
        url = str(url or "").strip().replace("\\/", "/")
        # IPTV catalogues often return an *image* saying NO TITLE or NO IMAGE.
        # Treat explicitly named placeholder assets as missing, not a success.
        try:
            filename = (urlsplit(url).path.rsplit("/", 1)[-1] or "").lower()
            if py27_fullmatch(r"(?:no[_-]?(?:poster|image|title)|nopic|placeholder|default[_-]?poster)(?:[_-][a-z0-9]+)?\.(?:jpe?g|png|webp)", filename):
                return ""
        except Exception:
            pass
        return url

    def _poster_widgets_ready(self):
        """Native pixmaps must exist before cached poster results are decoded."""
        if self._closed:
            return
        self._poster_layout_ready = True
        self._paint_poster_batch()

    def _drain_poster_gui_jobs(self):
        """Main-loop fallback for legacy VTi without an active Twisted reactor."""
        if self._closed:
            return
        with self._poster_gui_lock:
            batch = self._poster_gui_jobs[:12]
            del self._poster_gui_jobs[:len(batch)]
        for callback, args in batch:
            if self._closed:
                break
            try:
                callback(*args)
            except Exception:
                pass

    def _post_to_gui(self, func, *args):
        """Deliver artwork on Enigma2's GUI thread; never drop worker results."""
        if self._closed:
            return
        try:
            from twisted.internet import reactor
            if getattr(reactor, 'running', False):
                reactor.callFromThread(func, *args)
                return
        except Exception:
            pass
        # The eTimer is created and started on the main thread in __init__.
        # No worker ever touches the Enigma widget or starts a native timer.
        with self._poster_gui_lock:
            if len(self._poster_gui_jobs) < 256:
                self._poster_gui_jobs.append((func, args))

    def _fallback_poster(self, slot, item, token, avoid_url=""):
        """Start independent, bounded provider/TMDb lookups for a missing card.

        Provider details may take many seconds on a slow Stalker portal. Don't
        serialize TMDb behind that request: show the first valid image, while
        a later real provider poster remains authoritative.
        """
        if self._closed or self._poster_tokens.get(slot) != token:
            return
        self._resolve_provider_detail_poster(slot, item, token, avoid_url)
        self._resolve_tmdb_poster(slot, item, token)

    def _load_poster(self, slot, item, item_index):
        urls = _genre_provider_poster_urls(self.source, item, self.kind)
        token = "%d:%d:%s" % (self._generation, item_index, urls[0] if urls else "tmdb")
        self._poster_tokens[slot] = token
        self._poster_provider_attempts[slot] = (token, set())
        self._try_next_provider_poster(slot, item, token)

    def _try_next_provider_poster(self, slot, item, token):
        """Try actual server covers, cache-first, before any remote fallback.

        A rejected or unreachable screenshot_uri must never prevent a second
        valid provider cover from being used. No parallel provider downloads:
        one currently visible image is requested at a time per slot.
        """
        if self._closed or self._poster_tokens.get(slot) != token:
            return
        if self._poster_resolved_priority.get(slot, 0) >= 2:
            return
        state = self._poster_provider_attempts.get(slot)
        if state is None or state[0] != token:
            return
        seen = state[1]
        urls = _genre_provider_poster_urls(self.source, item, self.kind)
        # Check all provider cache hits before spending time on HTTP.
        for url in urls:
            if url in seen:
                continue
            path = cached_artwork(url, "posters")
            if path and os.path.isfile(path):
                seen.add(url)
                verdict = _provider_placeholder_cached_verdict(path)
                if verdict is True:
                    continue
                if verdict is False:
                    self._decode_poster(slot, path, token, item, "provider", url)
                else:
                    self._validate_provider_poster(slot, path, token, item, url)
                return
        for url in urls:
            if url in seen:
                continue
            seen.add(url)

            def ready(path, expected=token, current_slot=slot, record=item, resolved_url=url):
                self._validate_provider_poster(current_slot, path, expected, record, resolved_url)

            def failed(_path, expected=token, current_slot=slot, record=item):
                self._post_to_gui(self._try_next_provider_poster, current_slot, record, expected)

            try:
                genre_ultra_request(url, "posters", dict(self.source or {}), ready, failed, self._post_to_gui)
            except Exception:
                self._post_to_gui(self._try_next_provider_poster, slot, item, token)
            return
        self._fallback_poster(slot, item, token)

    def _resolve_provider_detail_poster(self, slot, item, token, avoid_url=""):
        """Try this source's VOD/series detail image before falling back to TMDb.

        IPTV catalogue entries frequently lack a poster even while vod_info / 
        series_info contains `cover`/`movie_image`. Resolving a visible missing
        card is never done on the Enigma2 GUI thread, and other posters continue
        painting while at most three provider detail calls run concurrently.
        """
        if getattr(self, "_closed", True) or self._poster_tokens.get(slot) != token:
            return
        snap = dict(item or {})
        source = dict(self.source or {})
        media_id = str(snap.get("series_id" if self.kind == "series" else "stream_id") or
                       snap.get("stream_id") or snap.get("vod_id") or snap.get("id") or "").strip()
        if not media_id or str(source.get("type") or "").lower() not in ("xtream", "stalker"):
            self._resolve_tmdb_poster(slot, snap, token)
            return
        kind = self.kind
        origin = text_type(source.get("url") or source.get("portal") or source.get("host") or u"")
        key = (text_type(source.get("type") or u""), origin, text_type(source.get("username") or u""),
               str(source.get("mac") or ""), kind, media_id)

        def worker():
            artwork = ""
            try:
                with _GENRE_PROVIDER_DETAIL_LOCK:
                    cached = _GENRE_PROVIDER_DETAIL_CACHE.get(key)
                if cached and cached[0] > monotonic():
                    artwork = cached[1]
                else:
                    payload = {}
                    # Reuse the server detail cache already persisted by the
                    # movie details page (if present), without another request.
                    if kind == "vod":
                        try:
                            import hashlib, json
                            from .metadata_display import provider_cache_key
                            from .cache_manager import get_cache_dir
                            ck = provider_cache_key("vod", media_id, source)
                            path = os.path.join(get_cache_dir("metadata"),
                                                "provider_info_" + hashlib.md5(ck.encode("utf-8")).hexdigest() + ".json")
                            if os.path.isfile(path):
                                with io.open(path, "r", encoding="utf-8") as stream:
                                    payload = json.load(stream) or {}
                        except Exception:
                            payload = {}
                    if not payload:
                        try:
                            from .metadata_display import provider_cache_key
                            ck = stable_cache_key(
                                "genre_provider_details_v1", source.get("type"),
                                source.get("url") or source.get("base_url") or source.get("host"),
                                source.get("username") or source.get("user"),
                                source.get("password"), kind, media_id)
                            meta = persistent_cache_get(ck)
                            if isinstance(meta, dict):
                                # Old metadata may have cached a named NO
                                # POSTER image as if it were valid artwork.
                                # Revalidate that single URL without wiping
                                # the rest of the provider-detail cache.
                                artwork = _genre_provider_poster_url(
                                    source, {"cover": meta.get("_genre_poster_url") or ""})
                        except Exception:
                            pass
                    # An old provider-details cache can have valid text but
                    # no usable poster.  Extract its image first; never treat
                    # the existence of text-only metadata as an artwork hit.
                    if isinstance(payload, dict) and not artwork:
                        artwork, _unused = _genre_provider_artwork(source, payload)
                    if artwork == avoid_url:
                        artwork = ""
                    if not artwork:
                        client = get_source_client(source)
                        if str(source.get("type") or "").lower() == "stalker":
                            # StalkerClient.vod_info/series_info return their
                            # own persisted responses. Ask for fresh artwork
                            # only when this particular visible card lacks it.
                            # The artwork-only lookup does NOT overwrite the
                            # server's full detail/episode cache.
                            payload = client.genre_fresh_artwork_info(media_id, kind)
                        elif not payload:
                            payload = (client.series_info(media_id) if kind == "series"
                                       else client.vod_info(media_id)) or {}
                        if isinstance(payload, dict):
                            artwork, _unused = _genre_provider_artwork(source, payload)
                            if artwork == avoid_url:
                                artwork = ""
                    with _GENRE_PROVIDER_DETAIL_LOCK:
                        _GENRE_PROVIDER_DETAIL_CACHE[key] = (monotonic() + (1200 if artwork else 120), artwork)
                        if len(_GENRE_PROVIDER_DETAIL_CACHE) > 192:
                            for stale in list(_GENRE_PROVIDER_DETAIL_CACHE)[:48]:
                                _GENRE_PROVIDER_DETAIL_CACHE.pop(stale, None)
            except Exception:
                pass
            self._post_to_gui(self._apply_provider_detail_poster, slot, snap, token, artwork)

        try:
            job = _GENRE_PROVIDER_DETAIL_POOL.submit(worker)
            self._poster_jobs.append(job)
        except Exception:
            self._resolve_tmdb_poster(slot, snap, token)

    def _apply_provider_detail_poster(self, slot, item, token, url):
        if getattr(self, "_closed", True) or self._poster_tokens.get(slot) != token:
            return
        if not url:
            self._resolve_tmdb_poster(slot, item, token)
            return
        def done(path, s=slot, expected=token, record=item):
            # This is the detailed provider's *last* candidate. A rejected
            # placeholder must advance to TMDb, not loop back to details.
            def worker():
                invalid = not path or not os.path.isfile(path) or _provider_image_is_placeholder(path)
                if invalid:
                    self._post_to_gui(self._resolve_tmdb_poster, s, record, expected)
                else:
                    self._post_to_gui(self._decode_poster, s, path, expected, record, "provider_detail", url)
            _GENRE_PROVIDER_CHECK_POOL.submit(worker)
        def failed(_path, s=slot, expected=token, record=item):
            self._resolve_tmdb_poster(s, record, expected)
        try:
            genre_ultra_request(url, "posters", dict(self.source or {}), done, failed, self._post_to_gui)
        except Exception:
            self._resolve_tmdb_poster(slot, item, token)

    def _validate_provider_poster(self, slot, path, token, item, resolved_url=""):
        """Validate the downloaded bytes off-thread before painting a GENRE card."""
        snapshot = dict(item or {})
        def worker():
            if self._closed or self._poster_tokens.get(slot) != token:
                return
            if not path or not os.path.isfile(path) or _provider_image_is_placeholder(path):
                self._post_to_gui(self._try_next_provider_poster, slot, snapshot, token)
            else:
                self._post_to_gui(self._decode_poster, slot, path, token, snapshot, "provider", resolved_url)
        try:
            future = _GENRE_PROVIDER_CHECK_POOL.submit(worker)
            self._poster_jobs.append(future)
        except Exception:
            # Never silently lose a card when a worker pool is shutting down.
            self._post_to_gui(self._try_next_provider_poster, slot, snapshot, token)

    @staticmethod
    def _poster_tmdb_id(item):
        """A validated provider TMDb id, including catalogues using nested info.

        This is only a lookup hint. A mismatched ID never supplies artwork.
        """
        record = item if isinstance(item, dict) else {}
        info = record.get("info")
        mappings = (record, info if isinstance(info, dict) else {})
        for row in mappings:
            for key in ("tmdb_id", "tmdb", "tmdbId", "tmdbid"):
                value = str(row.get(key) or "").strip()
                if value.isdigit() and 0 < len(value) <= 10 and int(value) > 0:
                    return value
        return ""

    @staticmethod
    def _verified_tmdb_poster(client, item, kind, title, year):
        """Trust a provider TMDb ID only after verifying the actual title.

        Details are cache-first; a foreign or stale ID falls back to safe name
        search instead of displaying an unrelated movie/series poster.
        """
        tmdb_id = StandaloneGenreScreen._poster_tmdb_id(item)
        if not tmdb_id or not title:
            return ""
        try:
            from .tmdb_client import _tmdb_identity_anchor, _tmdb_identity_row_score
            row = client.details_bundle(tmdb_id, kind) or {}
            anchor = _tmdb_identity_anchor(title, kind)
            if _tmdb_identity_row_score(anchor, anchor, row, kind, year or None) >= 0.80:
                poster = row.get("poster_path") or ""
                if not poster:
                    # The canonical poster_path can be blank even when TMDb
                    # has alternative posters for this exact verified title.
                    choices = ((row.get("images") or {}).get("posters") or [])
                    poster = next((pic.get("file_path") for pic in choices
                                   if isinstance(pic, dict) and pic.get("file_path")), "")
                return str(poster or "").strip()
        except Exception:
            pass
        return ""

    def _resolve_tmdb_poster(self, slot, item, token):
        if getattr(self, "_closed", True) or getattr(self, "_poster_tokens", {}).get(slot) != token:
            return
        snapshot = dict(item or {})
        kind = self.kind
        raw_title = text_type(snapshot.get("name") or snapshot.get("title") or u"").strip()
        title_key = clean_series_label(raw_title)
        raw_year = " ".join(str(snapshot.get(key) or "") for key in ("year", "releaseDate", "release_date", "first_air_date"))
        match = re.search(r"\b(?:19|20)\d{2}\b", raw_year)
        year_key = match.group(0) if match else ""
        lookup_key = (kind, title_key.lower(), year_key, self._poster_tmdb_id(snapshot))
        if not _GENRE_POSTER_PENDING.acquire(blocking=False):
            # Another GENRE page may still be using the shared lookup pool.
            # Revisit this visible slot later instead of leaving it blank for
            # the rest of the visit. This map holds at most 24 visible slots.
            self._poster_retry[slot] = (snapshot, token)
            self._poster_retry_timer.start(950, True)
            return
        self._poster_retry.pop(slot, None)
        # Provider callbacks can fail while a TMDb lookup is already queued.
        # Never search the same title twice for the same visible card.
        request_key = (slot, token)
        if request_key in self._poster_tmdb_started:
            _GENRE_POSTER_PENDING.release()
            return
        self._poster_tmdb_started.add(request_key)

        def worker():
            try:
                if self._closed or self._poster_tokens.get(slot) != token:
                    return
                url = ""
                with _GENRE_POSTER_LOCK:
                    cached_search = _GENRE_POSTER_LOOKUP.get(lookup_key)
                    if cached_search and cached_search[0] > monotonic():
                        url = cached_search[1]
                if not cached_search or cached_search[0] <= monotonic():
                    client = TMDbClient()
                    # GENRE previously ignored an existing provider TMDb ID and
                    # always searched the (sometimes decorated) server title.
                    # Prefer ID-based artwork after an identity check; search by
                    # name remains the fallback if the ID is missing or wrong.
                    url = self._verified_tmdb_poster(client, snapshot, kind, title_key, year_key)
                    if not url and title_key:
                        found = client.search_artwork(title_key, kind, year_key or None, required_key="poster_path") or {}
                        url = str(found.get("poster_path") or "").strip()
                    if url and title_key:
                        try:
                            verified = found.get('id') if isinstance(found, dict) else None
                            if verified:
                                from .identity_artwork_index import remember
                                remember(kind, verified, poster=url)
                        except Exception:
                            pass
                    if not url and title_key:
                        # Some correctly matched TMDb titles have no primary
                        # poster_path yet, but the detail payload can contain
                        # alternative posters.  Never borrow another title's
                        # artwork: search_title checks identity before ID use.
                        found = client.search_title(title_key, kind, year_key or None) or {}
                        matched_id = str(found.get("id") or found.get("tmdb_id") or "").strip()
                        if matched_id.isdigit():
                            url = self._verified_tmdb_poster(
                                client, {"tmdb_id": matched_id}, kind, title_key, year_key)
                    with _GENRE_POSTER_LOCK:
                        _GENRE_POSTER_LOOKUP[lookup_key] = (monotonic() + (1800.0 if url else 120.0), url)
                        if len(_GENRE_POSTER_LOOKUP) > 256:
                            for old in list(_GENRE_POSTER_LOOKUP)[:64]:
                                _GENRE_POSTER_LOOKUP.pop(old, None)
                # TMDb search returns a relative poster path (e.g. /abc.jpg).
                # Resolve it as a POSTER only; never substitute a backdrop.
                url = tmdb_poster_url(url)
                if self._closed or self._poster_tokens.get(slot) != token:
                    return
                if not url:
                    self._post_to_gui(self._keep_default_poster, slot, token)
                    return

                def ready(path, expected=token, current_slot=slot, record=snapshot):
                    self._post_to_gui(self._decode_poster, current_slot, path, expected, record, "tmdb", url)

                def failed(_path, expected=token, current_slot=slot, record=snapshot):
                    self._post_to_gui(self._keep_default_poster, current_slot, expected)

                cached = cached_artwork(url, "posters")
                if cached and os.path.isfile(cached):
                    ready(cached)
                else:
                    genre_ultra_request(url, "posters", dict(self.source or {}), ready, failed, self._post_to_gui)
            except Exception:
                self._post_to_gui(self._keep_default_poster, slot, token)

        try:
            future = _GENRE_POSTER_POOL.submit(worker)
            # Releasing from a Future callback covers both completed and
            # cancelled-before-start requests, avoiding semaphore leaks.
            future.add_done_callback(lambda completed: _GENRE_POSTER_PENDING.release())
            self._poster_jobs.append(future)
        except Exception:
            self._poster_tmdb_started.discard(request_key)
            _GENRE_POSTER_PENDING.release()

    def _keep_default_poster(self, slot, token):
        """Only use the vertical default image if server and TMDb posters fail."""
        if getattr(self, "_closed", True) or getattr(self, "_poster_tokens", {}).get(slot) != token:
            return
        if self._poster_resolved_priority.get(slot, 0):
            return
        self._set_placeholder(slot)
        if getattr(self, '_next_page_warm_enabled', False):
            self._next_page_warm_failed.add(slot)

    def _decode_poster(self, slot, path, token, item, origin, resolved_url=""):
        """Decode the original cached poster, as the Saga page does.

        No secondary poster copy, backdrop-derived fill, PIL crop, or
        artwork queue changes.  The separate shell supplies the rounded edge.
        """
        if (getattr(self, "_closed", True)
                or getattr(self, "_poster_tokens", {}).get(slot) != token):
            return
        if not path or not os.path.isfile(path):
            self._poster_decode_failed(slot, item, token, origin)
            return
        # Decode the ORIGINAL poster directly from the shared posters cache.
        # No style-specific files, no extra cache folders and no image download.
        priority = 2 if origin in ("provider", "provider_detail") else 1
        if self._poster_resolved_priority.get(slot, 0) > priority:
            return
        loader = ePicLoad()
        # During teardown the Screen's attributes may disappear while native
        # ePicLoad still has a queued PictureData notification.
        decoders = getattr(self, "_poster_decoders", None)
        if decoders is None:
            return
        # Two provider/TMDb responses can finish together. Keep their native
        # decoders independent; one must not invalidate the other's callback.
        decoder_key = (slot, origin)
        decoders[decoder_key] = loader

        def ready(_=None, current=loader, current_slot=slot, expected=token,
                  record=item, stage=origin, winner_url=resolved_url):
            try:
                active = getattr(self, "_poster_decoders", None)
                tokens = getattr(self, "_poster_tokens", {})
                if getattr(self, "_closed", True) or active is None or active.get(decoder_key) is not current:
                    return
                if tokens.get(current_slot) != expected:
                    return
                if self._poster_resolved_priority.get(current_slot, 0) > priority:
                    return
                pointer = current.getData()
                if not pointer:
                    try:
                        from .native_image_recovery import request as _native_retry
                        def _retry_genre_native(converted, target=current_slot, ticket=expected, rec=record, step=stage, uri=winner_url):
                            if not self._closed and self._poster_tokens.get(target) == ticket:
                                if converted:
                                    self._decode_poster(target, converted, ticket, rec, step, uri)
                                else:
                                    self._poster_decode_failed(target, rec, ticket, step)
                        if _native_retry(path, 'image', _retry_genre_native):
                            return
                    except Exception:
                        pass
                if pointer:
                    widget = self["poster%d" % current_slot]
                    if widget.instance:
                        widget.instance.setPixmap(pointer)
                        widget.show()
                        self._poster_resolved_priority[current_slot] = priority
                        # Keep ordered batches on their own GUI timer;
                        # decoded images do not reshuffle pending slots.
                        # GENRE already found and decoded the right image. Share
                        # its successful URL with the small TV/Movies poster rail.
                        # This is a passive indexed write on the existing worker:
                        # no extra network calls or changes to GENRE's loading.
                        if winner_url:
                            try:
                                from .poster_resolution_cache import remember_decoded
                                remember_decoded(self.source, self.kind, record, winner_url)
                            except Exception:
                                pass
                else:
                    self._poster_decode_failed(current_slot, record, expected, stage)
            except Exception:
                pass
            finally:
                active = getattr(self, "_poster_decoders", None)
                if active is not None and active.get(decoder_key) is current:
                    active.pop(decoder_key, None)

        try:
            connect_picture_data(loader, ready, self, oneshot=True)
            width, height = scale_size(CARD_WIDTH, CARD_HEIGHT)
            loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            active = getattr(self, "_poster_decoders", None)
            if active is not None and active.get(decoder_key) is loader:
                active.pop(decoder_key, None)
            self._poster_decode_failed(slot, item, token, origin)

    def _poster_decode_failed(self, slot, item, token, origin):
        if getattr(self, "_closed", True) or getattr(self, "_poster_tokens", {}).get(slot) != token:
            return
        if origin == "provider":
            self._try_next_provider_poster(slot, item, token)
        elif origin == "provider_detail":
            self._resolve_tmdb_poster(slot, item, token)
        elif origin == "tmdb":
            self._keep_default_poster(slot, token)
        # Poster failed from both sources: keep the vertical placeholder.

    def _selected_item(self):
        if 0 <= self.index < len(self.genre_items):
            return self.genre_items[self.index]
        return None

    def left(self):
        if self.genre_items and self.index % GRID_COLUMNS:
            self.index -= 1
            self.render()
        else:
            # First column: slide in the PACKAGES menu (same as Apple).
            self._open_package_drawer()

    def _open_package_drawer(self):
        if self.source.get('_actor_search_name') or len(self.categories or []) < 2:
            return
        from .package_drawer import open_package_drawer
        names = [(c.get('name') if isinstance(c, dict) else c) or '' for c in self.categories]
        open_package_drawer(self, names, self.category_index, self._package_drawer_chosen,
                            getattr(self, "_DRAWER_TITLE", "GENRE GRID"))

    def _package_drawer_chosen(self, target):
        if self._closed or not self.categories or not 0 <= target < len(self.categories):
            return
        if target == self.category_index:
            return
        self.category_index = target
        self._generation += 1
        self._render_genre_bar()
        self._load_selected_genre(self._generation)

    def right(self):
        if self.genre_items and self.index + 1 < len(self.genre_items) and self.index % GRID_COLUMNS < GRID_COLUMNS - 1:
            self.index += 1
            self.render()

    def up(self):
        if self.genre_items and self.index >= GRID_COLUMNS:
            self.index -= GRID_COLUMNS
            self.render()

    def down(self):
        if self.genre_items and self.index + GRID_COLUMNS < len(self.genre_items):
            self.index += GRID_COLUMNS
            self.render()

    def page_up(self):
        if self.genre_items:
            self.index = max(0, self.index - PAGE_SIZE)
            self.render()

    def page_down(self):
        if self.genre_items:
            self.index = min(len(self.genre_items) - 1, self.index + PAGE_SIZE)
            self.render()

    def previous_genre(self):
        if hasattr(self, '_cancelPosterInlineSearch'):
            self._cancelPosterInlineSearch(True)
        if self.source.get('_actor_search_name'):
            return self.page_up()
        if not self.categories:
            return
        self.category_index = (self.category_index - 1) % len(self.categories)
        self._generation += 1
        self._render_genre_bar()
        self._load_selected_genre(self._generation)

    def next_genre(self):
        if hasattr(self, '_cancelPosterInlineSearch'):
            self._cancelPosterInlineSearch(True)
        if self.source.get('_actor_search_name'):
            return self.page_down()
        if not self.categories:
            return
        self.category_index = (self.category_index + 1) % len(self.categories)
        self._generation += 1
        self._render_genre_bar()
        self._load_selected_genre(self._generation)

    def _sort_poster_rows(self, rows):
        rows = list(rows or [])
        mode = getattr(self, '_poster_sort_mode', 'date')
        if mode == 'date':
            rows.sort(key=_newest_key, reverse=True)
        elif mode in ('atoz', 'ztoa'):
            rows.sort(key=lambda item: text_type((item or {}).get('name') or (item or {}).get('title') or u'').lower(),
                      reverse=(mode == 'ztoa'))
        # "default" returns GENRE's original provider/cache-prepared order.
        return rows

    def _refreshFooterSortValue(self):
        label = {'date': 'Date', 'atoz': 'A-Z', 'ztoa': 'Z-A',
                 'default': 'Original'}.get(self._poster_sort_mode, 'Date')
        try:
            self['footerSortValue'].setText(label)
        except Exception:
            pass

    def sort_posters(self):
        modes = ('date', 'atoz', 'ztoa', 'default')
        old = getattr(self, '_poster_sort_mode', 'date')
        self._poster_sort_mode = modes[(modes.index(old) + 1) % len(modes)] if old in modes else 'date'
        self._refreshFooterSortValue()
        rows = list(getattr(self, '_poster_original_rows', ()) or self.genre_items)
        if not rows:
            return
        # Existing decoder requests belong to the old selection/order.
        self._cancel_poster_jobs()
        self._generation += 1
        self.genre_items = self._sort_poster_rows(rows)
        self.index = self.page_start = 0
        self._poster_tokens = {}
        self._rendered_page_key = None
        self.render()
        # The chosen mode belongs below SORT in the bottom toolbar,
        # not temporarily in the poster/status strip.
        self._refreshFooterSortValue()

    def open_poster_server(self):
        from .poster_remote_actions import open_server
        return open_server(self)

    def filter_poster_server(self):
        from .poster_remote_actions import open_filter
        return open_filter(self)

    def show_movies(self):
        if self.source.get('_actor_search_name'):
            return  # Actor results are scoped to their original content kind.
        if self.kind != "vod":
            self.kind = "vod"
            from .ui import _load_page_source, _save_page_source
            page_type = getattr(self, "_PAGE_SOURCE_PREFIX", None) or ("cinematic_" if self.__class__.__name__ == "CinematicCatalogScreen" else "genre_poster_")
            self._serverPageKey = page_type + self.kind
            self.source = _load_page_source(self._serverPageKey, self.source)
            _save_page_source(self._serverPageKey, self.source)
            # Category IDs are scoped to both media kind and provider.
            self.initial_category_id = ""
            self._adjust_movie_logo_size()
            self.start()

    def show_series(self):
        if self.source.get('_actor_search_name'):
            return
        if self.kind != "series":
            self.kind = "series"
            from .ui import _load_page_source, _save_page_source
            page_type = getattr(self, "_PAGE_SOURCE_PREFIX", None) or ("cinematic_" if self.__class__.__name__ == "CinematicCatalogScreen" else "genre_poster_")
            self._serverPageKey = page_type + self.kind
            self.source = _load_page_source(self._serverPageKey, self.source)
            _save_page_source(self._serverPageKey, self.source)
            # Category IDs are scoped to both media kind and provider.
            self.initial_category_id = ""
            self._adjust_movie_logo_size()
            self.start()

    def open_view_style_menu(self):
        # Opened as a Movies/TV Shows PAGE DESIGN: show that picker instead.
        from .page_layout_screens import is_page_level, open_page_design_picker
        if is_page_level(self):
            return open_page_design_picker(self)
        context = str(self.source.get('_view_picker_context') or 'genre')
        if context == 'actor' and self.source.get('_actor_search_person'):
            from .view_style_picker import SpotlightViewPicker
            self.session.openWithCallback(self._view_style_chosen, SpotlightViewPicker,
                                          context, self.kind, True)
            return
        from .view_style_picker import PosterViewPicker
        self.session.openWithCallback(self._view_style_chosen, PosterViewPicker,
                                      context, self.kind)

    def _view_style_chosen(self, choice=None):
        from .page_layout_screens import handle_page_choice
        if handle_page_choice(self, choice):
            return
        if choice == 'spotlight' and self.source.get('_actor_search_person'):
            from .actor_results_layout import open_actor_results
            open_actor_results(self.session, self.source, self.kind,
                               self.source.get('_actor_search_name'),
                               self.source.get('_actor_search_rows') or [], style='spotlight')
            return
        if choice not in ('circle', 'poster', 'genre', 'cinematic', 'circle3', 'apple'):
            return
        if self.source.get('_actor_search_name'):
            from .actor_results_layout import open_actor_results
            # Keep all actor matches, not just the current grid page.
            open_actor_results(self.session, self.source, self.kind,
                               self.source.get('_actor_search_name'),
                               self.source.get('_actor_search_rows') or [], style=choice)
            return
        # Cinematic inherits this callback from GENRE.  The old unconditional
        # `choice == 'genre'` return saved the preference without changing the
        # visible page until the user exited and reopened the package.
        from .cinematic_catalog import CinematicCatalogScreen
        from .circle_grid import CircleGridScreen
        if choice == 'genre' and type(self) is StandaloneGenreScreen:
            return  # Already displaying the GENRE grid.
        if choice == 'circle3' and isinstance(self, CircleGridScreen):
            return  # Already displaying the circle grid.
        try:
            from .apple_movies_layout import AppleMoviesScreen as _AppleScreen
        except Exception:
            _AppleScreen = None
        if choice == 'apple' and _AppleScreen is not None and isinstance(self, _AppleScreen):
            return  # Already displaying Apple.
        if (choice == 'cinematic' and isinstance(self, CinematicCatalogScreen)
                and not (_AppleScreen is not None and isinstance(self, _AppleScreen))):
            return  # Already displaying Cinematic.
        category = self.categories[self.category_index] if self.categories else {}
        cid = str(category.get('id') or self.initial_category_id or '')
        if not cid:
            return
        # VTi: a failing style screen must not leave this page suspended.
        from .vti_compat import safe_open_screen as _safe_open
        view_source = dict(self.source)
        view_source['_view_picker_context'] = str(self.source.get('_view_picker_context') or 'genre')
        if choice == 'genre':
            _safe_open(self.session, None, StandaloneGenreScreen, view_source, self.kind, cid)
        elif choice == 'cinematic':
            _safe_open(self.session, None, CinematicCatalogScreen, view_source, self.kind, cid)
        elif choice == 'circle3':
            # Circles in three rows (GENRE engine), see circle_grid.py.
            _safe_open(self.session, None, CircleGridScreen, view_source, self.kind, cid)
        elif choice == 'apple' and _AppleScreen is not None:
            from .apple_movies_layout import AppleSeriesScreen as _AppleSeries
            _safe_open(self.session, None, (_AppleSeries if self.kind == 'series' else _AppleScreen), view_source, self.kind, cid)
        else:
            from .ui import MediaScreen
            view_source['_view_style_override'] = 'circle' if choice == 'circle' else 'original'
            _safe_open(self.session, None, MediaScreen, view_source, self.kind, cid,
                              text_type(category.get('name') or u''),
                              [] if cid == '__recent_added__' else list(self.genre_items))

    def toggle_favorite(self):
        item = self._selected_item()
        if not item:
            return
        title = text_type(item.get("name") or item.get("title") or tr("CONTENT"))
        try:
            if is_favourite(self.source, self.kind, item):
                self["status"].setText("%s is already in Favorites" % title)
            elif add_favourite(self.source, self.kind, item):
                self["status"].setText("%s added to Favorites" % title)
            else:
                self["status"].setText("Unable to save Favorite")
        except Exception:
            self["status"].setText("Unable to save Favorite")

    def open_selected(self):
        item = self._selected_item()
        if not item:
            return
        category = self.categories[self.category_index] if self.categories else {}
        detail_item = dict(item)
        actor_scope = bool(self.source.get('_actor_search_name'))
        recent_scope = str(category.get('id') or '') == '__recent_added__'
        # Virtual actor and Recent results span multiple real provider categories.  Never
        # overwrite their real category with the fake actor-results category:
        # Details, playback and provider artwork need the original category.
        real_category_id = str(detail_item.get('_source_category_id') or
                               detail_item.get('category_id') or '')
        detail_item["_source_category_id"] = (real_category_id if (actor_scope or recent_scope) else
                                               str(category.get("id") or real_category_id))
        detail_item["_genre_standalone"] = True
        # Carry the exact selected package name into Details. Do not assign
        # generic/actor/Recent pseudo-categories as a streaming platform.
        if not (actor_scope or recent_scope) and not detail_item.get("_server_package_name"):
            detail_item["_server_package_name"] = text_type(category.get("name") or u"")
        if self.kind == "series":
            try:
                if self._series_details_class is None:
                    from .ui import SeriesDetailsScreen
                    self._series_details_class = SeriesDetailsScreen
                self.session.open(self._series_details_class, dict(self.source), detail_item)
            except Exception as exc:
                self.session.open(MessageBox, "Unable to open series details:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            self.session.open(
                MovieDetailsScreen,
                dict(self.source),
                detail_item,
                list(self.genre_items),
                {"scope": "actor" if actor_scope else ("recent" if recent_scope else "genre"),
                 "category_id": detail_item.get("_source_category_id"),
                 "items": list(self.genre_items)},
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open movie details:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)


def install_genre_page(ui_module):
    """Link the original GENRE-backdrop screen to the independent poster page.

    The normal GENRE selector and its existing MovieGenresScreen backdrop grid
    stay exactly in their original route.  Only an OK press on one of those
    backdrop cards opens the standalone 8x3 title grid, scoped to that exact
    provider category.  This intentionally avoids touching Packages, Movies,
    TV Shows, or their original implementations.
    """
    if getattr(ui_module, "_standalone_genre_page_installed", False):
        return
    backdrop_screen = getattr(ui_module, "MovieGenresScreen", None)
    if backdrop_screen is None:
        return

    original_choose = backdrop_screen.choose

    def open_standalone_from_backdrop(self):
        rows = list(getattr(self, "rows", []) or [])
        index = int(getattr(self, "index", 0) or 0)
        if index < 0 or index >= len(rows):
            return
        row = rows[index] if isinstance(rows[index], dict) else {}
        category_id = str(row.get("id") or row.get("category_id") or "").strip()
        kind = "series" if str(row.get("kind") or getattr(self, "kind", "vod")) == "series" else "vod"
        source = dict(getattr(self, "source", {}) or {})
        if not source or not category_id:
            return original_choose(self)

        # Do not register a return callback here.  The existing GENRE backdrop
        # screen remains alive below this child screen, and Enigma2 reveals it
        # automatically when EXIT closes the 24-poster screen.  Avoiding a late
        # callback prevents a closed/invalid backdrop widget from being painted
        # during the screen-stack transition on older receiver images.
        from .view_style_picker import get_style
        style = get_style('genre', kind)
        if style == 'cinematic':
            from .cinematic_catalog import CinematicCatalogScreen
            source['_view_picker_context'] = 'genre'
            self.session.open(CinematicCatalogScreen, source, kind, category_id)
        elif style == 'genre':
            self.session.open(StandaloneGenreScreen, source, kind, category_id)
        elif style == 'circle3':
            from .circle_grid import CircleGridScreen
            source['_view_picker_context'] = 'genre'
            self.session.open(CircleGridScreen, source, kind, category_id)
        elif style == 'apple':
            from .apple_movies_layout import AppleMoviesScreen, AppleSeriesScreen
            source['_view_picker_context'] = 'genre'
            self.session.open(AppleSeriesScreen if kind == 'series' else AppleMoviesScreen, source, kind, category_id)
        else:
            from .ui import MediaScreen
            source['_view_picker_context'] = 'genre'
            source['_view_style_override'] = 'circle' if style == 'circle' else 'original'
            self.session.open(MediaScreen, source, kind, category_id, text_type(row.get('name') or u''))

    backdrop_screen._standalone_genre_original_choose = original_choose
    backdrop_screen.choose = open_standalone_from_backdrop
    ui_module.StandaloneGenreScreen = StandaloneGenreScreen
    ui_module._standalone_genre_page_installed = True


def _genre_like(screen):
    """GENRE Grid and the screens drawn with its layout (Royal Circles)."""
    return type(screen) is StandaloneGenreScreen or bool(getattr(screen, "_GENRE_LIKE", False))
