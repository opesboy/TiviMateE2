# -*- coding: utf-8 -*-
"""TiviMateE2 VOD Player - clean rebuild.

This module is a standalone VOD player path. It deliberately does not load
or execute the legacy ``_player_parts`` implementation. Live TV continues to
use ``live_player.py``.

Design goals:
* Enigma2-native playback (eServiceReference/session.nav + public InfoBar mixins)
* 4097 default, 5002/5001 available, 8193 only on DreamOS, never service type 1
* resume identity independent from service type and stream URL
* safe service switching while preserving resume/audio/subtitle preferences
* clear startup/EOF behavior without auto-fallback or hidden engine changes
* TiviMate subtitle provider bridge preserved as a feature layer
"""
from __future__ import absolute_import
from Plugins.Extensions.TiviMateE2Py27.py27_compat import gui_text, thread_factory, native_episode_url_bytes, text_type

import hashlib
import json
import os
import re
import time
import threading

try:
    from PIL import Image, ImageDraw
except Exception:
    Image = None
    ImageDraw = None

from Components.ActionMap import ActionMap
try:
    from Components.ActionMap import NumberActionMap
except Exception:
    NumberActionMap = ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from .vti_compat import VTiTextLabel as Label
from .vti_compat import safe_open_screen as _safe_open_screen
from .rtl_text import DirectionalLabel
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
try:
    from Components.Sources.StaticText import StaticText
except Exception:
    from Components.Sources.Source import Source

    class StaticText(Source):
        def __init__(self, text=""):
            Source.__init__(self)
            self.text = text

        def setText(self, text):
            self.text = text
            self.changed((self.CHANGED_ALL,))

from enigma import eConsoleAppContainer, eServiceReference, eTimer, iPlayableService
# VTi legacy images may not export this cosmetic spinner switch.
try:
    from enigma import setSpinnerOnOff
except (ImportError, AttributeError):
    def setSpinnerOnOff(_enabled):
        return None
try:
    from enigma import ePicLoad
except ImportError:
    ePicLoad = None
try:
    from Tools.LoadPixmap import LoadPixmap
except ImportError:
    LoadPixmap = None
try:
    from enigma import iServiceInformation
except Exception:
    iServiceInformation = None

# UltraStalker native aspect-ratio authority.
try:
    from enigma import eAVSwitch
except Exception:
    try:
        from enigma import eAVControl as eAVSwitch
    except Exception:
        eAVSwitch = None

ASPECT_RATIOS = {
    0: "4:3 Letterbox",
    1: "4:3 PanScan",
    2: "16:9",
    3: "16:9 Always",
    4: "16:10 Letterbox",
    5: "16:10 PanScan",
    6: "16:9 Letterbox",
}

from Screens.ChoiceBox import ChoiceBox
from Plugins.Extensions.TiviMateE2Py27.py27_compat import wrap_choicebox as _wrap_choicebox
ChoiceBox = _wrap_choicebox(ChoiceBox)
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.InfoBarGenerics import (
    InfoBarAudioSelection,
    InfoBarMoviePlayerSummarySupport,
    InfoBarNotifications,
    InfoBarSeek,
    InfoBarSubtitleSupport,
    InfoBarSummarySupport,
)

from .display_scale import scale_skin
from . import next_episode_notice
from .storage import data_path
from .artwork_queue import request_artwork, cached_artwork
from .tmdb_client import TMDbClient
from .cache_manager import get_cache_dir
try:
    from twisted.internet import reactor
except Exception:
    reactor = None


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27"
PLAYER_STATE_FILE = data_path("vod_player_state_v2.json")
PLAYER_RESUME_FILE = data_path("vod_resume_v2.json")
CONTINUE_WATCHING_FILE = data_path("resume.json")
PLAYER_PREFS_FILE = data_path("vod_preferences_v2.json")

PTS = 90000
RESUME_MIN_SECONDS = 15
RESUME_OFFER_SECONDS = 20
COMPLETE_RATIO = 0.95
STARTUP_GRACE_SECONDS = 12
STALL_NOTICE_SECONDS = 12
# UltraStalker starts a 12-second startup watchdog.  Enigma2 sometimes emits
# evStart before video frames exist, so allow one short verification window.
VOD_STARTUP_TIMEOUT_MS = 12000
VOD_DECODER_VERIFY_MS = 6000
# The loopback buffer opens the stream first, so the decoder starts later.
# Give buffered films more time instead of declaring the engine broken.
VOD_BUFFER_STARTUP_TIMEOUT_MS = 25000
VOD_BUFFER_VERIFY_MS = 10000
BUFFER_STARTUP_GRACE_SECONDS = 25
VOD_MEMORY_CHECK_MS = 5000


# ---------------------------------------------------------------------------
# Small, dependency-free persistence helpers
# ---------------------------------------------------------------------------
def _read_json(path):
    try:
        with open(path, "r") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_json(path, value):
    try:
        parent = os.path.dirname(path)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        temp = path + ".tmp"
        with open(temp, "w") as handle:
            json.dump(value, handle, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        os.rename(temp, path)
        return True
    except Exception:
        return False


PLAYER_BUFFER_FILE = "/etc/enigma2/tivimatee2/playback_buffer.json"
BUFFER_SIZES = (0, 8, 16, 32, 64, 128, 256, 512)


def _player_buffer_mb():
    try:
        value = int(_read_json(PLAYER_BUFFER_FILE).get("megabytes", 0))
        return value if value in BUFFER_SIZES else 0
    except Exception:
        return 0


def _save_player_buffer_mb(value):
    if int(value) not in BUFFER_SIZES:
        return False
    return _write_json(PLAYER_BUFFER_FILE, {"megabytes": int(value)})


def _clean_title(value):
    return re.sub(u"\\s+", u" ", text_type(value or u"").strip())


def _identity_title(value):
    # Python 2 can hold non-UTF-8 byte strings from IPTV catalogues. Normalize
    # to Unicode here, so the identity never double-encodes opaque bytes.
    text = re.sub(u"\\s+", u" ", text_type(value or u"").strip()).lower()
    text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
    text = re.sub(
        r"\b(?:4k|8k|uhd|fhd|hd|sd|2160p|1080p|720p|nf|netflix|amz|amzn|"
        r"web[- ]?dl|webrip|bluray|x264|x265|h264|h265|hevc|ar|ara|arabic|en|eng|english)\b",
        " ", text, flags=re.I,
    )
    text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
    return " ".join(text.split())


def _item_year(item):
    item = item or {}
    for key in ("year", "release_year", "releaseDate", "release_date"):
        match = re.search(u"\\b(?:19|20)\\d{2}\\b", text_type(item.get(key) or u""))
        if match:
            return match.group(0)
    title = item.get("name") or item.get("title") or item.get("stream_name") or ""
    match = re.search(u"\\b(?:19|20)\\d{2}\\b", text_type(title))
    return match.group(0) if match else ""


def _media_identity(item):
    """Stable identity that never includes service type or stream URL."""
    item = item or {}
    series_name = item.get("series_name") or item.get("_tmdb_title") or ""
    title = series_name or item.get("name") or item.get("title") or item.get("stream_name") or ""
    normalized = _identity_title(title)
    season = text_type(item.get("season_number") or item.get("season") or item.get("_subdl_season") or u"")
    episode = text_type(item.get("episode_number") or item.get("episode_num") or item.get("episode") or item.get("_subdl_episode") or u"")
    kind = text_type(item.get("_kind") or u"").lower()
    is_episode = bool(series_name or season or episode or kind in ("episode", "series", "tv", "show"))

    if normalized:
        if is_episode:
            raw = u"episode|%s|s%s|e%s" % (normalized, season, episode)
        else:
            raw = u"movie|%s|%s" % (normalized, _item_year(item))
    else:
        source = text_type(item.get("_source_key") or item.get("server_id") or item.get("source_id") or item.get("playlist_id") or u"")
        content_id = ""
        for key in ("stream_id", "vod_id", "movie_id", "episode_id", "id"):
            value = item.get(key)
            if value not in (None, ""):
                content_id = text_type(value)
                break
        raw = u"id|%s|%s|s%s|e%s" % (source, content_id, season, episode)
    return hashlib.sha1(text_type(raw).encode("utf-8")).hexdigest()


def _ref_url(ref):
    if ref is None:
        return ""
    try:
        path = ref.getPath()
        if path:
            # A Python2 Unicode URL must not pass through str(), which tries
            # ASCII and can abort the VTi screen before playback starts.
            return text_type(path)
    except Exception:
        pass
    try:
        text = text_type(ref.toString() or u"")
        if text.startswith(("http://", "https://")):
            return text
        if "http%3a" in text.lower() or "https%3a" in text.lower():
            try:
                from Plugins.Extensions.TiviMateE2Py27.py27_urllib import unquote
            except Exception:
                from urllib import unquote
            # Reference format: 10 colon-separated fields, URL, optional name.
            # split(':', 10)[-1] is not safe: it also includes ':Movie Name'.
            fields = text.split(":", 11)
            if len(fields) > 10:
                candidate = unquote(fields[10])
                if candidate.startswith(("http://", "https://")):
                    return candidate
    except Exception:
        pass
    return ""


# Restricted VTi playback diagnostics: no URLs, movie names, credentials or IDs.

def _vti_subtitle_diag(event, detail=''):
    return None  # r146: diagnostics off
    try:
        safe_event = re.sub(r'[^A-Z0-9_]', '', text_type(event).upper())[:40]
        safe_detail = re.sub(r'[^A-Z0-9_]', '', text_type(detail).upper())[:36]
        path = '/home/root/tivimatee2_vti_subtitle.log'
        if os.path.isfile(path) and os.path.getsize(path) > 65536:
            with open(path, 'w') as handle:
                handle.write('')
        with open(path, 'a') as handle:
            handle.write('%s event=%s detail=%s\n' % (
                time.strftime('%Y-%m-%dT%H:%M:%S'), safe_event, safe_detail))
    except Exception:
        pass

def _vti_vod_diag(event, engine=0, detail=""):
    return None  # r146: diagnostics off
    try:
        safe_event = re.sub(r"[^A-Z0-9_]", "", text_type(event).upper())[:42]
        safe_detail = re.sub(r"[^A-Z0-9_]", "", text_type(detail).upper())[:36]
        line = "%s event=%s engine=%d detail=%s\n" % (
            time.strftime("%Y-%m-%dT%H:%M:%S"), safe_event, int(engine), safe_detail)
        path = "/home/root/tivimatee2_vti_movie.log"
        try:
            if os.path.isfile(path) and os.path.getsize(path) > 131072:
                with open(path, "w") as stream:
                    stream.write("")
        except Exception:
            pass
        with open(path, "a") as stream:
            stream.write(line)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Service policy
# ---------------------------------------------------------------------------
def _is_dreamos():
    from .dreamos_compat import is_dreamos as detect_dreamos
    return detect_dreamos()


from .service_compat import serviceapp_backend_available, compatible_service_type

def _available_stream_types():
    values = [(4097, "GStreamer")]
    if serviceapp_backend_available(5001):
        values.append((5001, "ServiceApp / GstPlayer"))
    if serviceapp_backend_available(5002):
        values.append((5002, "ServiceApp / ExtePlayer3"))
    if _is_dreamos():
        values.append((8193, "DreamOS"))
    return values


def _load_player_type():
    """Return last manually chosen VOD/series service type, if any.

    None means no manual preference: keep the configured server type.
    """
    value = _read_json(PLAYER_STATE_FILE).get("last_service_type")
    try:
        value = int(value)
    except (TypeError, ValueError):
        return None
    return value if value in [item[0] for item in _available_stream_types()] else None


def _save_player_type(value):
    """Persist one shared preference for movies and episodes across restarts."""
    try:
        value = int(value)
    except (TypeError, ValueError):
        return False
    if value not in [item[0] for item in _available_stream_types()]:
        return False
    state = _read_json(PLAYER_STATE_FILE)
    state["last_service_type"] = value
    return _write_json(PLAYER_STATE_FILE, state)


# ---------------------------------------------------------------------------
# Lightweight UI helpers; no legacy player class is referenced
# ---------------------------------------------------------------------------
def _tivimate_raise_screen_skin(screen, level=35):
    """Set the root OSD layer BEFORE Enigma2's readSkin, not after open().

    VTi's original config/AudioSelection skins use zPosition 0..3, while the
    tested VOD infobar must keep z=10 for OK. A late setZPosition on a
    dialog's instance is not supported on every VTi build. Only change the
    top-level <screen> tag of this one popup, never children or global skins.
    """
    skin_text = getattr(screen, 'skin', '') or ''
    match = re.search(r'<screen\b[^>]*>', skin_text, re.S)
    if not match:
        raise ValueError('popup skin root not found')
    opening = match.group(0)
    opening = re.sub(r'\s+zPosition\s*=\s*["\'][^"\']*["\']', '', opening)
    opening = opening[:-1] + ' zPosition="%d">' % int(level)
    screen.skin = skin_text[:match.start()] + opening + skin_text[match.end():]


def _logo_log(message):
    """Player circle/logo diagnostics in /tmp (RAM; reset above ~20 KB)."""
    try:
        import time as _t
        path = '/tmp/tivimate_player_logo.log'
        if os.path.exists(path) and os.path.getsize(path) > 20000:
            os.remove(path)
        with open(path, 'a') as handle:
            handle.write('%s %s\n' % (_t.strftime('%H:%M:%S'), message))
    except Exception:
        pass


class _TiviMateVODOptions(Screen):
    """VTi-safe modal menu with a translucent backdrop and readable list.

    Keep the working fix19 MenuList implementation and the player zPosition
    untouched.  Background is approximately 50 percent transparent; all
    text and the actual selection stay fully opaque above decorative layers.
    """
    def __init__(self, session, options, title='TIVIMATE PLAYER  /  SETTINGS'):
        from enigma import getDesktop
        self._options = list(options or [])
        desktop = getDesktop(0).size()
        dw, dh = int(desktop.width()), int(desktop.height())
        main = title == 'TIVIMATE PLAYER  /  SETTINGS'
        width = min(880 if main else 760, max(320, dw - 80))
        visible = max(1, min(12, len(self._options)))
        ideal_row = 48 if dh < 900 else 52
        height = min(dh - 50, max(280, 158 + visible * ideal_row))
        row_height = max(28, min(ideal_row, (height - 163) // visible))
        x, y = (dw - width) // 2, (dh - height) // 2
        # 0x80 is 50% transparency in Enigma2's #AARRGGBB convention.
        # Decoration is always BELOW title, list and hint, even on older VTi.
        self.skin = ("""<screen name="TiviMateVODOptions" position="%d,%d"
            size="%d,%d" zPosition="35" backgroundColor="#800C1421"
            flags="wfNoBorder">
            <eLabel position="0,0" size="%d,70"
                backgroundColor="#70152538" zPosition="1" />
            <eLabel position="20,15" size="4,40"
                backgroundColor="#00E0BF7A" zPosition="2" />
            <widget name="titleLabel" position="36,13" size="%d,50"
                font="Regular;27" foregroundColor="#00F4E3B7"
                backgroundColor="#800C1421" transparent="1"
                valign="center" noWrap="1" zPosition="8" />
            <eLabel position="20,77" size="%d,1"
                backgroundColor="#504F697D" zPosition="2" />
            <widget name="optionList" position="24,86" size="%d,%d"
                foregroundColor="#00FFFFFF"
                backgroundColor="#800C1421"
                scrollbarMode="showOnDemand" zPosition="8" />
            <eLabel position="20,%d" size="%d,1"
                backgroundColor="#504F697D" zPosition="2" />
            <widget name="hintLabel" position="26,%d" size="%d,36"
                font="Regular;19" foregroundColor="#00CBD7E4"
                backgroundColor="#800C1421" transparent="1"
                valign="center" zPosition="8" />
        </screen>""" % (x, y, width, height,
                        width, width - 60,
                        width - 40,
                        width - 48, height - 158,
                        height - 57, width - 40,
                        height - 49, width - 52))
        Screen.__init__(self, session)
        self['titleLabel'] = Label(gui_text(title))
        self['hintLabel'] = Label('OK  Select       EXIT  Back')
        self['optionList'] = MenuList([gui_text(row[0]) for row in self._options],
                                      enableWrapAround=True)
        try:
            self['optionList'].l.setItemHeight(row_height)
            from enigma import gFont
            self['optionList'].l.setFont(0, gFont('Regular', max(18, row_height // 2)))
        except Exception:
            pass
        self['actions'] = ActionMap(
            ['OkCancelActions', 'DirectionActions', 'ColorActions', 'MenuActions'],
            {'ok': self._select, 'green': self._select,
             'cancel': self._cancel, 'red': self._cancel, 'menu': self._cancel,
             'up': self['optionList'].up, 'down': self['optionList'].down,
             'left': self['optionList'].pageUp,
             'right': self['optionList'].pageDown}, -2)

    def _cancel(self):
        self.close(None)

    def _select(self):
        try:
            current = self['optionList'].getCurrent()
            for title, key in self._options:
                if gui_text(title) == current:
                    self.close((title, key))
                    return
        except Exception as exc:
            print('[TiviMateE2Py27] menu selection failed: %s' % exc)
        self.close(None)


class FreshInfoBarShowHide(object):
    def __init__(self):
        self._hud_lock = 0
        self._hud_timer = eTimer()
        try:
            self._hud_timer_conn = self._hud_timer.timeout.connect(self._hideHud)
        except Exception:
            self._hud_timer.callback.append(self._hideHud)
        self.onShow.append(self._hudShown)

    def _hudShown(self):
        if self._hud_lock:
            return
        try:
            self._hud_timer.stop()
            self._hud_timer.start(5000, True)
        except Exception:
            pass

    def _hideHud(self):
        # r265: restore normal InfoBar auto-hide using the existing HUD timer.
        # Playback remains active; only the player HUD Screen is hidden.
        if self._hud_lock:
            return
        try:
            self.hide()
        except Exception:
            pass

    def refreshInfobar(self):
        try:
            self.show()
        except Exception:
            pass
        self._hudShown()

    def lockShow(self):
        self._hud_lock += 1
        try:
            self._hud_timer.stop()
            self.show()
        except Exception:
            pass

    def unlockShow(self):
        self._hud_lock = max(0, self._hud_lock - 1)
        if not self._hud_lock:
            self._hudShown()
            # Returning from MENU/submenus: re-apply the circle artwork.
            try:
                last = getattr(self, '_cover_cached_path', None)
                if last and hasattr(self, '_displayHudPosterPath'):
                    self._displayHudPosterPath(last)
            except Exception:
                pass


class FreshPVRState(object):
    def __init__(self):
        try:
            self.onPlayStateChanged.append(self._freshPlayState)
        except Exception:
            pass

    def _freshPlayState(self, state):
        text = ">"
        try:
            text = state[3] or ">"
        except Exception:
            pass
        icon = 0
        speed = ""
        if text == "||":
            icon = 1
        elif text == "END":
            icon = 2
        elif text.startswith(">>"):
            icon = 3
            speed = text.replace(">>", "").strip()
        elif text.startswith("<<"):
            icon = 4
            speed = text.replace("<<", "").strip()
        elif text.startswith("/"):
            icon = 5
            speed = text
        try:
            self["statusicon"].setPixmapNum(icon)
            self["speed"].setText(speed)
        except Exception:
            pass
        self.refreshInfobar()


def _vti_subtitle_style():
    """The same subtitle look as the Python 3 renderer: font, size, colour,
    outline and position from TiviMate Subtitles settings (KEY 5)."""
    style = {"font": "Regular", "size": 55, "color": "#00ffff00",
             "border": "#00000000", "border_width": 3, "position": 98}
    try:
        from .TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings
        ext = initTiviMateSettings().external
        style["font"] = str(ext.font.regular.type.value or "Regular")
        style["size"] = max(14, min(100, int(ext.font.size.value)))
        style["color"] = "#%s%s" % (ext.font.regular.alpha.value, ext.font.regular.color.value)
        if ext.shadow.enabled.value:
            style["border"] = "#00%s" % ext.shadow.color.value
            style["border_width"] = int(ext.shadow.size.value)
        else:
            style["border_width"] = 0
        style["position"] = max(10, min(100, int(ext.position.value)))
    except Exception:
        pass
    return style


class _VTiSRTDisplay(Screen):
    """Subtitle-only transparent dialog; independent of the auto-hiding HUD."""
    def __init__(self, session):
        from enigma import getDesktop
        size = getDesktop(0).size()
        width, height = max(1, size.width()), max(1, size.height())
        style = _vti_subtitle_style()
        self._tivimateStyle = style
        font_size = style["size"]
        left, caption_width = int(width * 0.04), int(width * 0.92)
        caption_height = max(80, int(font_size * 3.2))
        bottom = int(height * style["position"] / 100.0)
        top = max(0, min(height - caption_height, bottom - caption_height))
        # Keep the caption-only overlay behind the HUD z=10, above video.
        # This dialog is instantiated (never opened as a modal); it has no
        # ActionMap and cannot own the player's remote control.
        self.skin = ('<screen position="%d,%d" size="%d,%d" zPosition="5" '
                     'backgroundColor="#FF000000" flags="wfNoBorder">'
                     '<widget name="caption" position="0,0" size="%d,%d" '
                     'font="Regular;%d" foregroundColor="#FFFFFF" '
                     'backgroundColor="#00000000" transparent="1" '
                     'halign="center" valign="bottom" zPosition="1" />'
                     '</screen>') % (left, top, caption_width, caption_height,
                                      caption_width, caption_height, font_size)
        Screen.__init__(self, session)
        self['caption'] = Label('')
        self._tivimateFont = None
        self.onLayoutFinish.append(self._applyStyle)

    def _applyStyle(self):
        style = self._tivimateStyle
        try:
            from enigma import gFont
            from skin import parseColor
            label = self['caption'].instance
            self._tivimateFont = style["font"]
            label.setFont(gFont(style["font"], style["size"]))
            label.setForegroundColor(parseColor(style["color"]))
            if style["border_width"] > 0:
                if hasattr(label, 'setBorderColor'):
                    label.setBorderColor(parseColor(style["border"]))
                if hasattr(label, 'setBorderWidth'):
                    label.setBorderWidth(style["border_width"])
        except Exception as exc:
            print('[TiviMateE2] subtitle style not applied: %s' % exc)

    def fitFont(self, text):
        """Cyrillic text with a font that has no Cyrillic: use TiviMate's
        bundled font for that line, exactly like the Python 3 renderer."""
        style = self._tivimateStyle
        wanted = style["font"]
        try:
            from .TiviMateSubtitles.tivimate_subtitles import (
                _TIVIMATE_FONT_PATHS, _tivimate_font_has_arabic,
                _tivimate_font_has_cyrillic, _tivimate_text_has_cyrillic)
            path = _TIVIMATE_FONT_PATHS.get(wanted)
            # Python 2.7's independent SRT Label has to check Arabic itself;
            # it does not pass through Python 3's SubsSupport glyph fallback.
            # If the selected font lacks Arabic presentation forms, use the
            # EXISTING bundled font; do not ship any additional font files.
            try:
                is_arabic = any(0x0600 <= ord(ch) <= 0x06FF
                                for ch in text_type(text or u''))
            except Exception:
                is_arabic = False
            if is_arabic and (not path or not _tivimate_font_has_arabic(path)):
                wanted = "TiviMateArabic"
            elif _tivimate_text_has_cyrillic(text) and path and not _tivimate_font_has_cyrillic(path):
                wanted = "TiviMateArabic"
        except Exception:
            pass
        if wanted != self._tivimateFont:
            try:
                from enigma import gFont
                self['caption'].instance.setFont(gFont(wanted, style["size"]))
                self._tivimateFont = wanted
            except Exception:
                pass


class _VTiInPlayerSRT(object):
    """VTi Python2 SRT renderer using the existing, in-player eLabel.

    Only SRT/text files with valid time-coded cues enter this path.  ASS/SSA,
    embedded tracks and Live continue through their existing implementations.
    """
    def __init__(self, owner, path, cues):
        self.owner = owner
        self.path = path
        self.cues = cues
        self.starts = [int(cue[0]) for cue in cues]
        self.timer = owner._makeTimer(self._tick)
        # This screen stays visible when FreshInfoBarShowHide hides the HUD
        # after five seconds; the player itself is NOT a persistent overlay.
        self.overlay = None
        try:
            self.overlay = owner.session.instantiateDialog(_VTiSRTDisplay)
            self.overlay.hide()
        except Exception as exc:
            _vti_subtitle_diag('OVERLAY_DIALOG_FAILED', type(exc).__name__)
        self.last_text = None
        self.last_pts_ms = None
        self.last_pts_at = None
        self.fallback_started_at = None
        self.running = False
        self._pts_warned = False
        self.resumeSubs()

    def getSubsPath(self):
        return self.path

    def getSubsDelay(self):
        return int(getattr(self.owner, '_subtitle_session_delay_ms', 0) or 0)

    def setTiviMateDelay(self, milliseconds):
        self.owner._subtitle_session_delay_ms = int(milliseconds)
        self._tick()

    setSubsDelay = setTiviMateDelay

    def _playing_ms(self):
        owner = self.owner
        now = time.time()
        try:
            service = owner.session.nav.getCurrentService()
            seek = service and service.seek()
            result = seek and seek.getPlayPosition()
            if result and int(result[0]) == 0 and int(result[1]) > 0:
                position = int(result[1]) // 90
                self.last_pts_ms = position
                self.last_pts_at = now
                return position
        except Exception:
            pass
        # A few VTi ServiceApp combinations do not return a seek position.
        # Reuse the last position the player has already verified; otherwise
        # use elapsed wall clock as an explicit, logged best-effort fallback.
        if self.last_pts_ms is None:
            stored = int(getattr(owner, '_last_position', 0) or 0)
            if stored > 0:
                self.last_pts_ms = stored // 90
                self.last_pts_at = now
            elif getattr(owner, '_playback_confirmed', False):
                if self.fallback_started_at is None:
                    self.fallback_started_at = now
                    _vti_subtitle_diag('NO_PTS_CLOCK_FALLBACK')
                return max(0, int((now - self.fallback_started_at) * 1000))
            else:
                return None
        if not self._pts_warned:
            self._pts_warned = True
            _vti_subtitle_diag('NO_PTS_USING_LAST_POSITION')
        if getattr(owner, 'seekstate', None) == getattr(owner, 'SEEK_STATE_PAUSE', object()):
            return self.last_pts_ms
        return max(0, int(self.last_pts_ms + (now - self.last_pts_at) * 1000))

    def _tick(self):
        if not self.running or getattr(self.owner, '_closing', False):
            return
        video_ms = self._playing_ms()
        if video_ms is None:
            return
        clock_ms = video_ms - self.getSubsDelay()
        import bisect
        index = bisect.bisect_right(self.starts, clock_ms) - 1
        caption = u''
        if index >= 0:
            start_ms, end_ms, content = self.cues[index]
            if int(start_ms) <= clock_ms < int(end_ms):
                caption = content
        if caption == self.last_text:
            return
        try:
            if self.overlay is not None:
                widget = self.overlay['caption']
                if caption:
                    try:
                        self.overlay.fitFont(caption)
                    except Exception:
                        pass
                widget.setText(gui_text(caption))
                if caption:
                    self.overlay.show()
                else:
                    self.overlay.hide()
            else:
                widget = self.owner['srtOverlay']
                widget.setText(gui_text(caption))
                if caption:
                    widget.show()
                else:
                    widget.hide()
            self.last_text = caption
        except Exception as exc:
            _vti_subtitle_diag('RENDER_FAIL', type(exc).__name__)

    def resumeSubs(self):
        self.running = True
        self.timer.start(200, False)
        self._tick()

    def playAfterSeek(self):
        self.last_pts_ms = None
        self.last_pts_at = None
        self.fallback_started_at = None
        self._tick()

    def pauseSubs(self):
        self.running = False
        try:
            self.timer.stop()
        except Exception:
            pass
        self.hideSubs()

    def hideSubs(self):
        try:
            if self.overlay is not None:
                self.overlay['caption'].setText('')
                self.overlay.hide()
            else:
                self.owner['srtOverlay'].setText('')
                self.owner['srtOverlay'].hide()
        except Exception:
            pass
        self.last_text = None

    def resetSubs(self, *args):
        self.pauseSubs()

    def exitSubs(self):
        self.pauseSubs()
        if self.overlay is not None:
            try:
                self.owner.session.deleteDialog(self.overlay)
            except Exception:
                pass
            self.overlay = None

    def reloadSubtitleStyle(self):
        self._tick()
        return True

def _stalker_source_for_key(source_key):
    """Configured Stalker server for a VOD item's _source_key (worker-safe)."""
    try:
        from .core import get_sources
        stalkers = [s for s in (get_sources() or []) if str(s.get("type") or "").lower() == "stalker"]
    except Exception:
        return {}
    key = str(source_key or "").lower()
    for source in stalkers:
        mac = str(source.get("mac") or "").lower()
        url = str(source.get("url") or source.get("portal") or "").lower()
        host = url.split("://", 1)[-1].split("/", 1)[0]
        if mac and mac in key and (not host or host in key):
            return source
    return stalkers[0] if len(stalkers) == 1 else {}


class TiviMatePlayer(
    InfoBarBase,
    FreshInfoBarShowHide,
    FreshPVRState,
    InfoBarAudioSelection,
    InfoBarSubtitleSupport,
    InfoBarSeek,
    InfoBarNotifications,
    InfoBarSummarySupport,
    InfoBarMoviePlayerSummarySupport,
    Screen,
):
    """Standalone VOD player built around Enigma2 public playback APIs."""

    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True

    skin = """<screen name="TiviMateVodPlayerV2" position="0,0" size="1920,1080" zPosition="10" backgroundColor="#ff000000" flags="wfNoBorder">
        <!-- r276: full-width bottom HUD; large circle + clean reference icon row. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/infobar_bg_premium.png" position="0,812" size="1920,268" alphatest="blend" scale="1" zPosition="1"/>

        <widget name="cover" position="28,748" size="320,320" alphatest="blend" scale="1" zPosition="5"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/poster_ring_pro.png" position="12,732" size="352,352" alphatest="blend" zPosition="6"/>

        <widget name="titleLabel" position="385,845" size="760,46" font="Regular;36" noWrap="1" halign="left" valign="center" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="3"/>
        <!-- Keep the service type source and numeric footer; do not render offscreen icons. -->
        <widget source="streamtype" render="Label" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <!-- r153: footer metadata remains; remove the unused floating service icon. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/chip_service.png" position="385,890" size="120,34" alphatest="blend" zPosition="3"/>
        <widget name="serviceTypeText" position="421,891" size="78,32" font="Regular;22" halign="center" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="7"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/chip_imdb.png" position="517,890" size="136,34" alphatest="blend" zPosition="3"/>
        <widget name="ratingLabel" position="597,891" size="52,32" font="Regular;22" halign="center" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="7"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/chip_year.png" position="665,890" size="120,34" alphatest="blend" zPosition="3"/>
        <widget name="metaLabel" position="701,891" size="78,32" font="Regular;22" halign="center" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="7"/>

        <widget name="vodPosition" position="385,930" size="180,38" font="Regular;29" noWrap="1" foregroundColor="#28A9FF" backgroundColor="#00000000" halign="left" transparent="1" zPosition="3"/>
        <widget name="vodDuration" position="1180,930" size="190,38" font="Regular;29" noWrap="1" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="right" transparent="1" zPosition="3"/>
        <!-- Progress drawn with plain pixmaps: some images (VTi/HD) ignore ProgressBar pixmaps and paint a white bar. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/progress_track.png" position="385,970" size="985,14" alphatest="blend" zPosition="3"/>
        <widget name="vodProgressFill" position="385,970" size="1,14" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/progress_fill.png" alphatest="blend" zPosition="4"/>
        <widget name="vodProgress" position="-20,-20" size="1,1" borderWidth="0" transparent="1" zPosition="0"/>
        <widget name="vodKnob" position="370,962" size="30,30" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/progress_knob.png" alphatest="blend" zPosition="6"/>

        <!-- r481: compact original-style color keys + 0/TV hints below progress. Visual only. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_red.png" position="386,1010" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="redHint" position="418,1003" size="180,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_green.png" position="611,1010" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="greenHint" position="643,1003" size="130,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_yellow.png" position="786,1010" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="yellowHint" position="818,1003" size="155,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_blue.png" position="986,1010" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="blueHint" position="1017,1003" size="52,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <widget name="zeroHint" position="1070,1003" size="135,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>
        <widget name="tvHint" position="1210,1003" size="180,36" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" zPosition="4"/>

        <!-- Provider logo uses the package/source already attached to the item. -->
        <widget name="providerLogo" position="1285,846" size="105,42" alphatest="blend" scale="1" zPosition="4"/>
        <!-- Movie title logo: player HUD only; no playback/TMDb logic is changed. -->
        <widget name="movieLogo" position="850,838" size="300,72" alphatest="blend" scale="1" zPosition="5"/>

        <!-- r277: technical badges are live values from the currently playing service. -->
        <widget name="resolutionBadge" position="1404,849" size="96,36" alphatest="blend" zPosition="4"/>
        <widget name="aspectBadge" position="1508,849" size="82,36" alphatest="blend" zPosition="4"/>
        <widget name="videoBadge" position="1598,849" size="96,36" alphatest="blend" zPosition="4"/>
        <widget name="audioBadge" position="1702,849" size="89,36" alphatest="blend" zPosition="4"/>
        <widget name="bufferBadge" position="1172,849" size="96,36" alphatest="blend" zPosition="4"/>

        <!-- Same analog clock used on Packages; centered just below the H.26 video badge. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live/classic_clock_blue.png" position="1380,920" size="262,100" alphatest="blend" zPosition="4"/>
        <widget name="playerTime" position="1470,936" size="150,42" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" noWrap="1" zPosition="6"/>
        <widget name="playerDate" position="1460,976" size="170,22" font="Regular;15" foregroundColor="#7FC4FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5"/>

        <widget name="lockIcon" position="1810,846" size="42,42" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/tivimate_infobar/player/player_icon_lock_r276.png" alphatest="blend" zPosition="4"/>

        <widget name="codecLabel" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="speed" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="statusicon" position="0,0" size="1,1" zPosition="0"/>

        <widget name="descLabel" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="service8193Box" position="0,0" size="1,1" zPosition="0"/>
        <widget name="service8193Label" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="notification" position="520,760" size="880,42" font="Regular;23" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="20"/>
        <widget name="subtitleHint" position="0,0" size="1,1" font="Regular;1" transparent="1" zPosition="0"/>
        <widget name="srtOverlay" position="120,600" size="1680,160" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="bottom" zPosition="30"/>
    </screen>"""

    def __init__(self, session, service, item=None):
        Screen.__init__(self, session)
        self.session = session
        self.input_service = service
        self.item = dict(item or {})
        try:
            # Per-title audio/subtitle language memory (Ultra track_prefs).
            from .track_restore import install as _install_track_memory
            _install_track_memory(self)
        except Exception:
            pass
        # VTi may return an empty getPath() for a network service reference.
        # A fallback to toString() can accidentally append the movie's display
        # title to the URL. Prefer the precise URL supplied by the caller.
        self.streamurl = (text_type((self.item.get("_catchup_url") if self.item.get("_catchup") else None) or self.item.get("_tivimate_playback_url") or u"").strip()
                          or _ref_url(service) or text_type(
            self.item.get("url") or self.item.get("stream_url") or self.item.get("play_url") or u""
        ))
        # Preserve the service type selected by the caller/server instead of
        # forcing every VOD session to 4097. Fall back to 4097 only when the
        # incoming reference does not expose a valid type.
        try:
            incoming_type = int(getattr(service, "type", 0) or 0)
        except Exception:
            incoming_type = 0
        if not incoming_type:
            try:
                incoming_type = int(str(service.toString() or "").split(":", 1)[0])
            except Exception:
                incoming_type = 0
        saved_type = _load_player_type()
        self.servicetype = compatible_service_type(saved_type if saved_type is not None else (incoming_type if incoming_type > 0 else 4097))
        self._startup_preferred_type = int(self.servicetype)
        self._vod_attempted_types = []
        self._automatic_vod_retry = False
        self._fallback_pending = False
        self._fallback_next_type = None
        self._identity = _media_identity(self.item)
        self._closing = False
        # Monotonic UI generation: artwork workers may finish after a zap/close.
        self._artwork_generation = 0
        self._restored_original_service = False
        self._started = False
        self._playback_confirmed = False
        self._buffer_job = None
        self._buffer_play_url = ""
        self._buffer_bypass_once = False
        self._service_started_at = 0.0
        self._startup_eof_count = 0
        self._seen_service_start = False
        self._startup_guard_expanded = False
        self._startup_failed = False
        self._owned_vod_ref = ''
        self._memory_guard_level = 0
        self._last_position = 0
        self._last_duration = 0
        self._last_pts_seen = 0
        self._last_pts_change_at = 0.0
        self._stall_notice_sent = False
        self._resume_target = 0
        self._resume_applied = False
        self._resume_attempts = 0
        self._external_subs = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._external_subtitle_owner = ""
        self._subtitle_session_delay_ms = 0
        self._subtitle_restore_attempted = False
        self._record_process = None
        self._record_path = ""
        self.ar_id_player = -1
        self._episode_items = list(self.item.get("_episode_items") or [])
        try:
            self._episode_index = int(self.item.get("_episode_index", -1))
        except Exception:
            self._episode_index = -1
        self._episode_source = dict(self.item.get("_episode_source") or {})
        self._cover_cached_path = ""

        try:
            self.original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            self.original_service = None

        # Initialize only public Enigma2 mixins used by this player.
        for klass in (
            InfoBarBase,
            FreshInfoBarShowHide,
            InfoBarAudioSelection,
            InfoBarSubtitleSupport,
            InfoBarSeek,
            InfoBarNotifications,
            InfoBarSummarySupport,
            InfoBarMoviePlayerSummarySupport,
        ):
            klass.__init__(self)
        FreshPVRState.__init__(self)

        # UltraStalker-style native server subtitles: preserve the receiver's
        # InfoBarSubtitleSupport subtitle_window and its built-in renderer.
        # The separate TiviMateSubtitleSupportEmbedded.__init__ replaced that
        # window with SubsEmbeddedScreen; ServiceApp could report a selected
        # language although no actual text was painted by the receiver.
        # Downloaded subtitles still use the independent SubsSupport bridge.
        self._unified_embedded_ready = False

        # The details page may pass translated TMDb display text. Use it only
        # with the same currently selected locale; never alter stream names/IDs.
        current_metadata_locale = text_type(TMDbClient().language or u"").lower()
        localized = (text_type(self.item.get("_tmdb_metadata_locale") or u"").lower() == current_metadata_locale)
        visible_title = ((self.item.get("_tmdb_metadata_title") if localized else "") or
                         self.item.get("name") or self.item.get("title") or
                         self.item.get("stream_name") or "TiviMate")
        title = _clean_title(visible_title)
        # The DreamOS Python 2.7 GUI expects UTF-8 bytes for Enigma labels.
        self["titleLabel"] = DirectionalLabel(gui_text(title))
        year = _item_year(self.item)
        rating = text_type(self.item.get("rating") or self.item.get("rating_5based") or self.item.get("vote_average") or u"").strip()
        runtime = text_type(self.item.get("runtime") or self.item.get("duration") or self.item.get("duration_secs") or u"").strip()
        genre = text_type(self.item.get("genre") or self.item.get("genres") or self.item.get("category_name") or u"").strip()
        try:
            rating = "%.1f" % float(rating.replace(u",", u".")) if rating else ""
        except Exception:
            pass
        self["ratingLabel"] = Label(rating if rating else "-")
        self["metaLabel"] = Label(year if year else "-")
        self["redHint"] = Label("Edit CC")
        self["greenHint"] = Label("Audio")
        self["yellowHint"] = Label("Subtitle List")
        self["blueHint"] = Label("CC")
        self["zeroHint"] = Label("0  Aspect Ratio")
        self["tvHint"] = Label("TV  Service Type")
        description_text = ((self.item.get("_tmdb_metadata_overview") if localized else "") or
                            self.item.get("plot") or self.item.get("description") or self.item.get("overview") or "")
        description = _clean_title(description_text)
        self["descLabel"] = Label(description[:260])
        extension = os.path.splitext(self.streamurl.split("?", 1)[0])[-1].replace(".", "").upper() or "STREAM"
        video_hint = text_type(self.item.get("container_extension") or self.item.get("codec") or self.item.get("video_codec") or u"").upper()
        # Python 2.7 must not decode the UTF-8 byte separator as ASCII when
        # codec metadata is Unicode. Build Unicode first; VTiTextLabel converts
        # only the finished label into UTF-8 bytes for the native eLabel.
        codec_parts = [text_type(x) for x in (extension, video_hint) if x]
        self["codecLabel"] = Label(u"  \u2022  ".join(codec_parts))
        self["cover"] = Pixmap()
        # Native ePicLoad is important for JPG posters on DreamOS Python 2.7,
        # where Pillow is commonly absent. Keep decoder and its signal alive.
        self._hud_pic = ePicLoad() if ePicLoad is not None else None
        self._hud_pic_connection = None
        self._hud_decode_path = ""
        self._hud_decode_identity = ""
        if self._hud_pic is not None:
            try:
                self._hud_pic.PictureData.get().append(self._hudPosterDecoded)
            except Exception:
                try:
                    self._hud_pic_connection = self._hud_pic.PictureData.connect(self._hudPosterDecoded)
                except Exception:
                    self._hud_pic = None
        self["vodProgress"] = ProgressBar()
        self["vodKnob"] = Pixmap()
        self["vodProgressFill"] = Pixmap()
        self._vodKnobX = -1
        self._vodFillW = -1
        # Older Enigma2 ProgressBar versions discard a pre-render setRange()
        # call. Keep the native 0..100 range on every Python2/3 image rather
        # than sending 0..1000 values into a bar still limited to 100.
        try:
            self["vodProgress"].setRange((0, 100))
        except Exception:
            pass
        self["vodPosition"] = Label("00:00")
        self["vodDuration"] = Label("00:00")
        self["resolutionBadge"] = Pixmap()
        self["aspectBadge"] = Pixmap()
        self["videoBadge"] = Pixmap()
        self["audioBadge"] = Pixmap()
        self["bufferBadge"] = Pixmap()
        self["playerClockFace"] = Pixmap()
        self["playerClockHour"] = Pixmap()
        self["playerClockMinute"] = Pixmap()
        self["playerDate"] = Label("")
        self["playerTime"] = Label("")
        self["serviceTypeText"] = Label("")
        self._player_clock_minute = None
        self._player_clock_hour_slot = None
        self["providerLogo"] = Pixmap()
        self["movieLogo"] = Pixmap()
        try:
            self["movieLogo"].hide()
        except Exception:
            pass
        try:
            self["providerLogo"].hide()
        except Exception:
            pass
        self["lockIcon"] = Pixmap()
        for _badge_name in ("resolutionBadge", "aspectBadge", "videoBadge", "audioBadge"):
            try:
                self[_badge_name].hide()
            except Exception:
                pass
        self._tech_badge_tick = 0
        # Keep the last valid technical values while Enigma2 briefly reports
        # empty stream metadata during/after a VOD seek.  Reset on each new
        # service start so values never leak to another movie/episode.
        self._tech_badge_values = {"resolution": "", "aspect": "", "video": "", "audio": ""}
        self["speed"] = Label("")
        self["notification"] = Label("")
        self["subtitleHint"] = Label("")
        self["srtOverlay"] = Label("")
        try:
            self["srtOverlay"].hide()
        except Exception:
            pass
        self["statusicon"] = MultiPixmap()
        self["streamcat"] = StaticText("Series" if self._episode_items else "VOD")
        self["streamtype"] = StaticText(str(self.servicetype))
        self["extension"] = StaticText(extension)
        self["service8193Box"] = Pixmap()
        self["service8193Label"] = Label("8193")
        if not _is_dreamos():
            try:
                self["service8193Box"].hide()
                self["service8193Label"].hide()
            except Exception:
                pass

        self._notification_timer = self._makeTimer(self._clearNotification)
        self._monitor_timer = self._makeTimer(self._monitorPlayback)
        self._checkpoint_timer = self._makeTimer(self._checkpoint)
        self._resume_timer = self._makeTimer(self._resumeTick)
        self._prefs_timer = self._makeTimer(self._restorePreferences)
        self._startup_guard_timer = self._makeTimer(self._checkStartupGuard)
        self._startup_exit_timer = self._makeTimer(self._startupFailureExit)
        self._fallback_timer = self._makeTimer(self._executeVodFallback)
        self._memory_guard_timer = self._makeTimer(self._checkMemoryGuard)

        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions",
                "ChannelSelectBaseActions",
                "MoviePlayerActions",
                "MediaPlayerActions",
                "DirectionActions",
                "TiviMatePlayerActions",
                "MenuActions",
            ],
            {
                "menu": self.openPlayerMenu,
                "cancel": self.back,
                "ok": self.refreshInfobar,
                # Keep INFO opening the existing VOD player menu when the
                # receiver uses the plugin-local INFO keymap fallback.
                "info": self.openPlayerMenu,
                "green": self.audioSelection,
                "red": self.openSubtitleEditor,
                "blue": self.openSubsSupport,
                "yellow": self.openSubtitleSelection,
                "channelUp": self.nextEpisode,
                "channelDown": self.prevEpisode,
                "tv": self.cycleStreamTypeQuick,
                "subtitleFineMinus": self.subtitleFineMinus,
                "subtitleFinePlus": self.subtitleFinePlus,
            },
            -2,
        )
        self["menuActions"] = ActionMap(
            ["MenuActions", "InfobarEPGActions"],
            {"menu": self.openPlayerMenu, "info": self.openPlayerMenu},
            -3,
        )
        try:
            # The receiver's native seek-number keymap is not consistent on
            # all Enigma2 images for Xtream/Stalker episode references. Bind
            # episode skips explicitly to the same InfoBarSeek methods that
            # handle movies. Keep movies and the 0/5 shortcuts unchanged.
            number_map = {"5": self.openSubsSupport,
                          "0": (lambda *args: self.nextAspectRatio())}
            is_episode = bool(self._episode_items) or str(
                self.item.get("_kind") or "").lower() == "episode"
            # Movies too: many images ignore the native seek keymap for IPTV
            # references, so 1/3 4/6 7/9 did nothing on films (e.g. 9).
            if is_episode or True:
                number_map.update({
                    "1": (lambda *args: self._episodeNumberSeek(1)),
                    "3": (lambda *args: self._episodeNumberSeek(3)),
                    "4": (lambda *args: self._episodeNumberSeek(4)),
                    "6": (lambda *args: self._episodeNumberSeek(6)),
                    "7": (lambda *args: self._episodeNumberSeek(7)),
                    "9": (lambda *args: self._episodeNumberSeek(9)),
                })
            self["numberActions"] = NumberActionMap(["NumberActions"], number_map, -4)
        except Exception as exc:
            print("[TiviMateE2] VOD number actions unavailable: %s" % exc)

        events = {
            iPlayableService.evStart: self._serviceStarted,
            iPlayableService.evEOF: self._serviceEOF,
        }
        tune_failed = getattr(iPlayableService, "evTuneFailed", None)
        if tune_failed is not None:
            events[tune_failed] = self._serviceFailed
        self._event_tracker = ServiceEventTracker(screen=self, eventmap=events)
        self.onLayoutFinish.append(self._showInitialHudCover)
        self.onFirstExecBegin.append(self.playStream)
        self.onClose.append(self._cleanup)

    # ------------------------------------------------------------------
    # Timers / notification
    # ------------------------------------------------------------------
    def _makeTimer(self, callback):
        timer = eTimer()
        try:
            connection = timer.timeout.connect(callback)
            setattr(self, "_timer_connection_%s" % id(timer), connection)
        except Exception:
            timer.callback.append(callback)
        return timer

    def _showNotification(self, text, kind=None, timeout=4):
        try:
            self["notification"].setText(gui_text(text))
            self.refreshInfobar()
        except Exception:
            pass
        try:
            self._notification_timer.stop()
            self._notification_timer.start(int(timeout * 1000), True)
        except Exception:
            pass

    def _clearNotification(self):
        try:
            self["notification"].setText("")
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Playback core
    # ------------------------------------------------------------------
    def _relayVodUrl(self, url):
        """Movies/episodes with a single-use Stalker play_token (any image)
        or any Stalker VOD on DreamOS play through the local relay, so the
        player's Range/seek requests never hit a used token (HTTP 458/462)."""
        try:
            from .stream_relay import stalker_play_url, has_play_token, is_dreamos
            episode_source = dict(getattr(self, "_episode_source", None) or {})
            is_stalker = (str(self.item.get("_source_type") or "").lower() == "stalker" or
                          str(episode_source.get("type") or "").lower() == "stalker")
            if not (has_play_token(url) or (is_stalker and is_dreamos())):
                return url
            refresher = None
            if str(episode_source.get("type") or "").lower() == "stalker":
                row = dict(self.item)

                def refresher():
                    from .core import StalkerClient
                    return StalkerClient(episode_source).stream_url(row, "series")
            elif is_stalker:
                # Movies: the single-use play_token was spent by the decoder's
                # first request. Without a refresher the second request
                # (MP4 index read / reconnect, ~2-3 s in) got HTTP 458/462 and
                # the film stopped. Ask the portal for a fresh link instead.
                row = dict(self.item)
                source_key = str(self.item.get("_source_key") or "")

                def refresher():
                    from .core import StalkerClient
                    source = _stalker_source_for_key(source_key)
                    if not source:
                        return ""
                    return StalkerClient(source).stream_url(row, "vod")
            return stalker_play_url(url, refresher=refresher, force=True)
        except Exception:
            return url

    def _serviceReference(self):
        stream_url = self._buffer_play_url or self._relayVodUrl(self.streamurl)
        # A native-byte URL is mandatory for Python2 on every VOD service,
        # including films whose portal path contains non-UTF-8 octets.
        from .py27_compat import native_media_url_bytes
        stream_url = native_media_url_bytes(stream_url)
        ref = eServiceReference(int(self.servicetype), 0, stream_url)
        title = _clean_title(self.item.get("name") or self.item.get("title") or self.item.get("stream_name") or "TiviMate")
        try:
            ref.setName(gui_text(title))
        except Exception:
            pass
        return ref

    def _refreshHudTitle(self):
        """Always show the current title, including UTF-8 Arabic titles on DreamOS."""
        item = self.item or {}
        current_locale = text_type(TMDbClient().language or u"").lower()
        localized = (text_type(item.get("_tmdb_metadata_locale") or u"").lower() == current_locale)
        title = ((item.get("_tmdb_metadata_title") if localized else u"") or
                 item.get("name") or item.get("title") or
                 item.get("stream_name") or item.get("series_name") or
                 item.get("original_title") or u"")
        if not title:
            try:
                title = self.input_service.getName()
            except Exception:
                pass
        title = _clean_title(title or u"TiviMate")
        try:
            self["titleLabel"].setText(gui_text(title))
            # Same behaviour as the Python 3 HUD: a real image logo replaces
            # the caption; a title is a fallback only while the logo loads.
            if not getattr(self, "_movie_logo_visible", False):
                self["titleLabel"].show()
            else:
                self["titleLabel"].hide()
        except Exception:
            pass

    def _hudPosterDecoded(self, info=None):
        """DreamOS JPEG/PNG fallback; never call native pixmap APIs on a worker."""
        if self._closing or not self._hud_pic:
            return
        if self._hud_decode_identity != self._identity:
            return
        try:
            pix = self._hud_pic.getData()
            if pix is None:
                return
            widget = self["cover"].instance
            if widget is None:
                return
            # Native clipping makes a circular poster on builds supporting it;
            # on older DreamOS at least the full poster remains visible.
            self._setHudPosterCorner(widget)
            widget.setPixmap(pix)
            self["cover"].show()
            self._cover_cached_path = self._hud_decode_path
            _logo_log('shown (decoded): %s' % os.path.basename(str(self._hud_decode_path)))
        except Exception as exc:
            _logo_log('decode display failed: %r' % (exc,))
            print("[TiviMateE2Py27] HUD poster native decode: %s" % exc)

    @staticmethod
    def _setHudPosterCorner(widget):
        if not hasattr(widget, "setCornerRadius"):
            return
        try:
            size = widget.size()
            radius = max(1, min(int(size.width()), int(size.height())) // 2)
        except Exception:
            radius = 160
        try:
            widget.setCornerRadius(radius)
        except TypeError:
            try:
                from enigma import eWidget
                widget.setCornerRadius(radius, eWidget.RADIUS_ALL)
            except Exception:
                pass
        except Exception:
            pass

    def _displayHudPosterPath(self, path):
        if not path or self._closing:
            return False
        path = gui_text(path)
        if not os.path.isfile(path):
            return False
        # A pre-masked circular PNG already has the exact 320x320 pixels.
        # LoadPixmap keeps the alpha channel that ePicLoad can flatten to black.
        if path.lower().endswith('.png'):
            try:
                widget = self['cover'].instance
                if widget is not None:
                    widget.setPixmapFromFile(path)
                    self['cover'].show()
                    self._cover_cached_path = path
                    _logo_log('shown (file): %s' % os.path.basename(path))
                    return True
            except Exception as exc:
                _logo_log('setPixmapFromFile failed: %r' % (exc,))
        if path.lower().endswith('.png') and LoadPixmap is not None:
            try:
                widget = self['cover'].instance
                ptr = LoadPixmap(path=path)
                if ptr is not None and widget is not None:
                    widget.setPixmap(ptr)
                    self['cover'].show()
                    self._cover_cached_path = path
                    return True
            except Exception:
                pass
        # Keep the existing decoder for JPEG and native LoadPixmap failures.
        if self._hud_pic is not None:
            try:
                self._hud_decode_identity = self._identity
                self._hud_decode_path = path
                widget = self["cover"].instance
                size = widget.size() if widget is not None else None
                width = int(size.width()) if size is not None else 320
                height = int(size.height()) if size is not None else 320
                self._hud_pic.setPara((max(1, width), max(1, height), 1, 1, False, 1, "#FF000000" if path.lower().endswith('.png') else "#00000000"))
                self._hud_pic.startDecode(path)
                _logo_log('decoding: %s' % os.path.basename(path))
                return True
            except Exception as exc:
                _logo_log('ePicLoad failed: %r' % (exc,))
                print("[TiviMateE2Py27] HUD poster ePicLoad: %s" % exc)
        if LoadPixmap is not None:
            try:
                pix = LoadPixmap(path=path)
                if pix is not None:
                    widget = self["cover"].instance
                    self._setHudPosterCorner(widget)
                    widget.setPixmap(pix)
                    self["cover"].show()
                    self._cover_cached_path = path
                    return True
            except Exception:
                pass
        if path.lower().endswith(".png"):
            try:
                widget = self["cover"].instance
                self._setHudPosterCorner(widget)
                widget.setPixmapFromFile(path)
                self["cover"].show()
                self._cover_cached_path = path
                return True
            except Exception:
                pass
        return False

    def _showInitialHudCover(self):
        # Local packaged artwork must not depend on playback confirmation.
        path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "player", "player_tivimate_circle_fallback_r278.png")
        try:
            if os.path.isfile(path) and self["cover"].instance is not None:
                self["cover"].instance.setPixmapFromFile(path)
                self["cover"].show()
        except Exception:
            pass

    def _loadHudPoster(self):
        # r268: crop the already-cached server poster to a true transparent circle.
        # No network request or new timer/hook; the generated PNG is reused from cache.
        generation = int(getattr(self, "_artwork_generation", 0) or 0)
        item_identity = self._identity
        path = text_type(self.item.get("_player_cover_cache") or u"").strip()
        provider_cache = text_type(self.item.get("_player_cover_cache_fallback") or u"").strip()
        fallback_path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "player", "player_tivimate_circle_fallback_r278.png")
        _logo_log('load poster: cache=%s fallback_exists=%s' % (bool(path), os.path.isfile(fallback_path)))
        # Never leave the circle empty while the real poster is prepared.
        if not getattr(self, '_cover_cached_path', None) or not os.path.isfile(gui_text(self._cover_cached_path)):
            self._displayHudPosterPath(fallback_path)

        # r428: series details always passes the parent-series poster URL in
        # _player_cover.  Reuse the existing artwork queue only when that poster
        # is not cached yet; this is player-only and does not touch episode art.
        if not path or not os.path.exists(path):
            if provider_cache and os.path.exists(provider_cache):
                path = provider_cache
            else:
                cover_url = text_type(self.item.get("_player_cover") or
                                      self.item.get("stream_icon") or
                                      self.item.get("cover_big") or
                                      self.item.get("poster_url") or
                                      self.item.get("poster_path") or u"").strip()
                if re.match(r"^/[A-Za-z0-9_-]{8,}\.(?:png|jpe?g|webp)$", cover_url, re.I):
                    try:
                        from .poster_manager import tmdb_poster_url
                        cover_url = tmdb_poster_url(cover_url) or cover_url
                    except Exception:
                        pass
                # Movies and episodes both require the same cached-artwork
                # resolution; previously movies never requested missing posters.
                if cover_url:
                    try:
                        cached = cached_artwork(cover_url, "posters")
                        if cached and os.path.isfile(cached):
                            path = cached
                    except Exception:
                        pass
                if cover_url and not os.path.isfile(path) and not getattr(self, "_hud_poster_request_pending", False):
                    self._hud_poster_request_pending = True
                    def poster_done(cached_path):
                        self._hud_poster_request_pending = False
                        try:
                            if (generation == getattr(self, "_artwork_generation", -1)
                                    and item_identity == getattr(self, "_identity", "")
                                    and not self._closing and cached_path and os.path.exists(cached_path)):
                                self.item["_player_cover_cache"] = cached_path
                                self._loadHudPoster()
                        except Exception:
                            pass
                    def poster_failed(_path):
                        self._hud_poster_request_pending = False
                    try:
                        request_artwork(cover_url, "posters", poster_done, priority=80, errback=poster_failed)
                    except Exception:
                        self._hud_poster_request_pending = False
                if not path or not os.path.isfile(path):
                    path = fallback_path
                if not os.path.exists(path):
                    return

        # Python 3 uses Pillow to create a transparent circular PNG.  DreamOS
        # Python 2 often lacks Pillow; run the exact crop+alpha operation in a
        # single background converter with native ffmpeg/convert fallback.
        # Never display the raw rectangular movie poster while converting.
        if os.path.abspath(path) == os.path.abspath(fallback_path):
            self._displayHudPosterPath(fallback_path)
            return
        try:
            from .player_circle_cache import request as request_round
            previous_identity = self._identity
            def _round_ready(round_path):
                if (not self._closing and
                        previous_identity == getattr(self, '_identity', None) and
                        generation == getattr(self, '_artwork_generation', -1)):
                    if round_path and os.path.isfile(round_path):
                        self._displayHudPosterPath(round_path)
                    else:
                        # Preserve the real movie artwork if neither encoder
                        # exists.  The issue remains diagnosable in E2 logs.
                        self._displayHudPosterPath(path)
            # Catch-up shows the channel logo: fit it inside the circle
            # instead of zoom-cropping it like a movie poster.
            result = request_round(path, _round_ready, logo=bool(self.item.get('_catchup')))
            if result is not True and result is not False and result and os.path.isfile(result):
                self._displayHudPosterPath(result)
            elif result is True:
                self._displayHudPosterPath(fallback_path)
            else:
                self._displayHudPosterPath(path)
        except Exception as exc:
            print('[TiviMateE2Py27] HUD circle scheduling: %s' % exc)
            self._displayHudPosterPath(path)

    def _loadProviderLogo(self):
        """Show the packaged provider logo from existing item/package metadata.

        No network lookup, timer or extra service query is used here.
        """
        try:
            self["providerLogo"].hide()
        except Exception:
            pass

        provider = text_type(
            self.item.get("_server_package_provider")
            or self.item.get("_tmdb_provider")
            or self.item.get("provider")
            or u""
        ).strip().lower()
        package_name = text_type(
            self.item.get("_server_package_name")
            or self.item.get("package_name")
            or self.item.get("category_name")
            or u""
        ).strip().lower()
        title = text_type(self.item.get("name") or self.item.get("title") or u"").strip().lower()
        hint = " ".join((provider, package_name, title[:24]))

        key = ""
        spaced_hint = " " + hint.replace("_", " ").replace("-", " ") + " "
        # Provider/package logos first, then content-category logos.  Everything
        # is resolved from metadata already attached to the item: no network,
        # timer or additional playback query is introduced here.
        if provider in ("netflix", "nf") or "netflix" in hint or title.startswith("nf -") or title.startswith("nf-"):
            key = "netflix"
        elif provider in ("prime", "amazon", "primevideo", "prime video") or "prime video" in hint or "amazon prime" in hint or title.startswith("pv -"):
            key = "prime"
        elif provider in ("disney", "disney+") or "disney" in hint:
            key = "disney"
        elif provider == "shahid" or "shahid" in hint or u"شاهد" in hint:
            key = "shahid"
        elif provider == "tod" or " tod " in spaced_hint:
            key = "tod"
        elif provider == "viu" or " viu " in spaced_hint:
            key = "viu"
        elif provider == "hulu" or " hulu " in spaced_hint:
            key = "hulu"
        elif "imdb" in hint:
            key = "imdb"
        elif "ufc" in hint:
            key = "ufc"
        elif "wwe" in hint or "wrestling" in hint or u"مصارعة" in hint:
            key = "wrestling"
        elif "horror" in hint or u"رعب" in hint:
            key = "horror"
        elif "action" in hint or u"اكشن" in hint or u"أكشن" in hint:
            key = "action"
        elif "anime" in hint or u"انمي" in hint or u"أنمي" in hint:
            key = "anime"
        elif "kids" in hint or "kidz" in hint or "children" in hint or u"اطفال" in hint or u"أطفال" in hint:
            key = "kids"
        elif "asian" in hint or u"آسيو" in hint or u"اسيو" in hint:
            key = "asian"
        elif "indian" in hint or "bollywood" in hint or u"هندي" in hint:
            key = "indian"
        elif "ramadan" in hint or u"رمضان" in hint:
            key = "ramadan"
        elif "theater" in hint or "theatre" in hint or u"مسرح" in hint:
            key = "theater"
        elif "music" in hint or u"موسيقى" in hint or u"موسيقي" in hint:
            key = "music"
        elif "foreign" in hint or u"اجنبي" in hint or u"أجنبي" in hint:
            key = "foreign"
        elif "series" in hint or "tv shows" in hint or u"مسلسلات" in hint:
            key = "series"
        elif "movie" in hint or "movies" in hint or u"افلام" in hint or u"أفلام" in hint:
            key = "movies"

        base = os.path.dirname(__file__)
        player_dir = os.path.join(base, "skins", "player")
        paths = {
            "netflix": os.path.join(player_dir, "player_provider_netflix_r285.png"),
            "prime": os.path.join(player_dir, "player_provider_prime_r285.png"),
            "disney": os.path.join(player_dir, "player_provider_disney_r285.png"),
            "shahid": os.path.join(player_dir, "player_provider_shahid_r285.png"),
            "tod": os.path.join(player_dir, "player_provider_tod_r285.png"),
            "viu": os.path.join(player_dir, "player_package_viu_r405.png"),
            "hulu": os.path.join(player_dir, "player_package_hulu_r405.png"),
            "imdb": os.path.join(player_dir, "player_package_imdb_r405.png"),
            "action": os.path.join(player_dir, "player_package_action_r405.png"),
            "horror": os.path.join(player_dir, "player_package_horror_r405.png"),
            "kids": os.path.join(player_dir, "player_package_kids_r405.png"),
            "anime": os.path.join(player_dir, "player_package_anime_r405.png"),
            "asian": os.path.join(player_dir, "player_package_asian_r405.png"),
            "indian": os.path.join(player_dir, "player_package_indian_r405.png"),
            "wrestling": os.path.join(player_dir, "player_package_wrestling_r405.png"),
            "ufc": os.path.join(player_dir, "player_package_ufc_r405.png"),
            "ramadan": os.path.join(player_dir, "player_package_ramadan_r405.png"),
            "theater": os.path.join(player_dir, "player_package_theater_r405.png"),
            "music": os.path.join(player_dir, "player_package_music_r405.png"),
            "foreign": os.path.join(player_dir, "player_package_foreign_r405.png"),
            "movies": os.path.join(player_dir, "player_package_movies_r405.png"),
            "series": os.path.join(player_dir, "player_package_series_r405.png"),
        }
        logo = paths.get(key, "")
        if not logo or not os.path.exists(logo):
            return
        try:
            self["providerLogo"].instance.setPixmapFromFile(logo)
            self["providerLogo"].show()
        except Exception:
            try:
                self["providerLogo"].setPixmapFromFile(logo)
                self["providerLogo"].show()
            except Exception:
                pass

    def _resetMovieLogo(self):
        # Invalidate an old episode/engine's result before changing the HUD.
        self._movie_logo_request = getattr(self, "_movie_logo_request", 0) + 1
        self._movie_logo_mailbox = []
        self._movie_logo_visible = False
        try:
            self["movieLogo"].hide()
            self["titleLabel"].show()
        except Exception:
            pass

    def _displayHudMovieLogo(self, path):
        """GUI thread only; the worker has prepared a validated alpha PNG."""
        if self._closing or not path or not os.path.isfile(path):
            return False
        try:
            logo = self["movieLogo"]
            widget = logo.instance
            if widget is None:
                return False
            from .transparent_pixmap import _png_size
            size = widget.size()
            exact = _png_size(path) == (int(size.width()), int(size.height()))
            if not exact:
                return False
            path = gui_text(path)
            try:
                widget.setScale(0)
            except Exception:
                pass
            ptr = None
            if LoadPixmap is not None:
                try:
                    ptr = LoadPixmap(path=path)
                except Exception:
                    pass
            painted = False
            if ptr is not None:
                try:
                    widget.setPixmap(ptr)
                    painted = True
                except Exception:
                    pass
            if not painted:
                # Older OpenATV builds can load the exact-size PNG directly.
                widget.setPixmapFromFile(path)
            logo.show()
            self["titleLabel"].hide()
            self._movie_logo_visible = True
            _logo_log('title logo displayed')
            return True
        except Exception as exc:
            _logo_log('title logo paint failed: %s' % type(exc).__name__)
            return False

    def _applyPendingMovieLogo(self):
        # Existing GUI monitor drains one result; no reactor dependency and no
        # extra timer, worker-to-native widget access or image prefetch.
        mailbox = getattr(self, "_movie_logo_mailbox", None)
        if not mailbox:
            return
        token, identity, path = mailbox.pop()
        if (not self._closing and token == getattr(self, "_movie_logo_request", -1)
                and identity == self._identity):
            self._displayHudMovieLogo(path)

    def _loadMovieLogo(self):
        """One bounded, cache-first title-logo task for the current VOD HUD."""
        self._resetMovieLogo()
        token = self._movie_logo_request
        mailbox = self._movie_logo_mailbox
        identity = self._identity
        item = dict(self.item or {})
        if item.get("_catchup"):
            return
        try:
            size = self["movieLogo"].instance.size()
            canvas = (int(size.width()), int(size.height()))
            if min(canvas) <= 0:
                return
        except Exception:
            return

        def cancelled():
            return (self._closing or token != getattr(self, "_movie_logo_request", -1)
                    or identity != getattr(self, "_identity", None))

        def worker():
            try:
                from .logo_manager import logo_language, localized_logo_url
                from .transparent_pixmap import _alpha_logo, _png_size, _cached_fit, _fit
                from .genre_ultra_artwork import _download_transparent_logo
                from .title_logo_ultra_bridge import resolve_title_logo, cached_identity_logo
                locale = logo_language()
                handoff = text_type(item.get("_player_movie_logo") or u"").strip()
                if text_type(item.get("_player_movie_logo_lang") or u"").lower() != locale:
                    handoff = u""
                ident = text_type(item.get("tmdb_id") or item.get("_tmdb_id") or
                                  item.get("tmdb") or item.get("tmdbid") or item.get("tmdbId") or u"").strip()
                try:
                    ident = ident if int(ident) > 0 else u""
                except (ValueError, TypeError):
                    ident = u""
                is_series = bool(text_type(item.get("_tmdb_kind") or item.get("_kind") or
                    item.get("kind") or u"").lower() in ("series", "tv", "episode") or
                    item.get("series_name") or item.get("series_id") or
                    item.get("episode_num") not in (None, "") or item.get("episode_number") not in (None, ""))
                kind = "series" if is_series else "vod"
                media = "tv" if is_series else "movie"
                title = ((item.get("series_name") or item.get("_tmdb_title")) if is_series else None) or item.get("title") or item.get("name") or u""

                def publish(path):
                    if cancelled() or not path or not _alpha_logo(path):
                        return False
                    if _png_size(path) != canvas or not path.lower().endswith('.png'):
                        # Fit off the GUI thread, retaining alpha and normal disk cache.
                        path = (_cached_fit(path, canvas[0], canvas[1], 'center', True) or
                                _fit(path, canvas[0], canvas[1], 'center', True))
                    if not path or cancelled() or _png_size(path) != canvas:
                        return False
                    mailbox.append((token, identity, path))
                    return True

                # Cache only first: use Details' selected logo, then shared identity.
                try:
                    if handoff and publish(cached_artwork(handoff, "logos")):
                        return
                except Exception:
                    pass
                try:
                    if ident and publish(cached_identity_logo(kind, ident, (300, 72), title,
                                                              item, item, cancelled, preferred_only=True)):
                        return
                except Exception:
                    pass
                if cancelled():
                    return
                # Only the requested HUD logo can be fetched during playback.
                # Direct transparent downloader works even on non-running Twisted.
                if handoff:
                    try:
                        if publish(_download_transparent_logo(handoff, {})):
                            return
                    except Exception:
                        pass
                if cancelled():
                    return
                client = TMDbClient()
                if not ident and title and client.configured():
                    try:
                        found = client.search_title(title, kind, item.get("year") or None) or {}
                        ident = text_type(found.get("id") or u"").strip()
                        if int(ident or "0") <= 0:
                            ident = u""
                    except Exception:
                        ident = u""
                if not ident or cancelled():
                    return
                try:
                    if publish(resolve_title_logo(client, kind, ident, title=title,
                                 details=item, item=item, canvas=(300, 72), cancelled=cancelled)):
                        return
                except Exception:
                    pass
                if cancelled() or not client.configured():
                    return
                url = localized_logo_url(client, media, ident, details=item, item=item, title=title)
                if url and not cancelled():
                    publish(_download_transparent_logo(url, {}))
            except Exception as exc:
                _logo_log('title logo lookup failed: %s' % type(exc).__name__)
        try:
            thread_factory(target=worker, name="TiviMateMovieLogo", daemon=True).start()
        except Exception as exc:
            _logo_log('title logo worker failed: %s' % type(exc).__name__)

    def _tryVodFallback(self, reason):
        """Try each installed backend once, for movies only, on a real start failure.

        Keep the user's chosen engine unchanged on disk. The next attempt runs
        on the Enigma2 GUI timer, never from an asynchronous worker/thread.
        """
        if (self._closing or self._playback_confirmed or self._fallback_pending or
                getattr(self, "_episode_items", None) or
                text_type(self.item.get("_kind") or u"").lower() in
                    ("series", "episode", "tv", "show")):
            return False
        try:
            available = set(int(item[0]) for item in _available_stream_types())
            tried = set(int(item) for item in self._vod_attempted_types)
            next_type = next((st for st in (4097, 5002, 5001)
                              if st in available and st not in tried), None)
            if next_type is None:
                _vti_vod_diag("ENGINES_EXHAUSTED", self.servicetype, reason)
                return False
            _vti_vod_diag("ENGINE_FALLBACK", self.servicetype, reason)
            self._fallback_next_type = next_type
            self._fallback_pending = True
            for timer in (self._startup_guard_timer, self._monitor_timer,
                          self._memory_guard_timer):
                try:
                    timer.stop()
                except Exception:
                    pass
            self._showNotification("Trying player %s" % next_type,
                                   MessageBox.TYPE_INFO, 3)
            self._fallback_timer.start(100, True)
            return True
        except Exception:
            self._fallback_pending = False
            self._fallback_next_type = None
            return False

    def _executeVodFallback(self):
        if self._closing or not self._fallback_pending:
            return
        target = self._fallback_next_type
        self._fallback_pending = False
        self._fallback_next_type = None
        if target is None:
            return
        self.servicetype = int(target)
        self._started = False  # Never store resume for a failed engine attempt.
        self._automatic_vod_retry = True
        self.playStream()

    def _loadDeferredVodArtwork(self):
        if not getattr(self, "_vod_artwork_pending", False):
            return
        self._vod_artwork_pending = False
        for loader in (self._loadProviderLogo, self._loadHudPoster, self._loadMovieLogo):
            try:
                loader()
            except Exception:
                pass  # Artwork is never allowed to interrupt video playback.

    def playStream(self):
        if self._closing:
            return
        next_episode_notice.hide(self)
        if not self.streamurl:
            self._showNotification("Stream URL unavailable", MessageBox.TYPE_ERROR, 6)
            return
        from .playback_priority import enter
        enter(self)
        auto_retry = bool(self._automatic_vod_retry)
        self._automatic_vod_retry = False
        if not auto_retry:
            self._vod_attempted_types = []
        try:
            self._vod_attempted_types.append(int(self.servicetype))
        except Exception:
            pass
        _vti_vod_diag("ENGINE_START", self.servicetype,
                      "AUTO_RETRY" if auto_retry else "INITIAL")
        # Keep the fallback title, but defer network artwork until video starts.
        if not auto_retry:
            self._vod_artwork_pending = True
            self._resetMovieLogo()
            try:
                self._refreshHudTitle()
            except Exception:
                pass

        # Preserve the current media position before an explicit engine restart.
        if self._started:
            self._saveResume()
            self._savePreferences()

        # r407 startup fix: replace the active service directly.
        # On Enigma2/4097, stopService() can emit an EOF from the previous
        # service during startup and make a valid VOD appear stuck on
        # "Starting 4097". playService() already replaces the current service.
        self._started = False
        self._playback_confirmed = False
        self._seen_service_start = False
        self._startup_guard_expanded = False
        self._startup_failed = False
        self._memory_guard_level = 0
        self._owned_vod_ref = ''
        self._service_started_at = time.time()
        self._startup_eof_count = 0
        self._last_pts_seen = 0
        self._last_pts_change_at = time.time()
        self._stall_notice_sent = False
        self._resume_applied = False
        self._resume_attempts = 0
        self._resume_seek_count = 0
        self._resume_verify_cycles = 0
        self._resume_grace_until = 0.0
        self._resume_started_at = 0.0
        self._resume_phase = "probe"
        self._resume_target = self._loadResumeTarget()
        if int(self._resume_target or 0) > 0:
            self._resume_grace_until = time.time() + 16.0
        self._subtitle_restore_attempted = False
        self._tech_badge_values = {"resolution": "", "aspect": "", "video": "", "audio": ""}

        self._preparePlaybackBuffer()
        self._noticeEngineDowngrade()
        # Start Ultra's one-shot watchdog before giving control to the decoder.
        # It is intentionally a GUI eTimer: no worker may call Enigma2 nav APIs.
        try:
            self._startup_guard_timer.stop()
            self._startup_guard_timer.start(VOD_BUFFER_STARTUP_TIMEOUT_MS if self._buffer_job is not None else VOD_STARTUP_TIMEOUT_MS, True)
            self._memory_guard_timer.stop()   # memory guard removed: never closes or refreshes a film
        except Exception:
            pass
        try:
            # Keep the short Enigma2 busy spinner hidden while the service engine
            # accepts the new VOD service. This does not change playback timing.
            try:
                setSpinnerOnOff(0)
            except Exception:
                pass
            try:
                reference = self._serviceReference()
                try:
                    self._owned_vod_ref = reference.toString()
                except Exception:
                    self._owned_vod_ref = ''
                result = self.session.nav.playService(reference)
            finally:
                try:
                    setSpinnerOnOff(1)
                except Exception:
                    pass
            if result is False or (type(result) is int and result != 0):
                _vti_vod_diag("ENGINE_REJECTED", self.servicetype)
                raise RuntimeError("service engine rejected the stream")
            if self._fallback_pending or self._startup_failed:
                return
            self._started = True
            self["streamtype"].setText(str(self.servicetype))
            self._updateServiceTypeBadge()
            self._monitor_timer.start(1000, False)
            # r393: re-enable the existing resume/checkpoint path. No new timer/hook.
            if self.ENABLE_RESUME_SUPPORT:
                self._checkpoint_timer.start(30000, False)
                if int(self._resume_target or 0) > 0 and not self._resume_applied:
                    # Some engines never send evStart: probe anyway.
                    self._resume_started_at = time.time() + 1.5
                    self._resume_attempts = 0
                    self._scheduleResumeProbe()
            self._prefs_timer.start(1800, True)
            self.refreshInfobar()
        except Exception as exc:
            _vti_vod_diag("ENGINE_EXCEPTION", self.servicetype,
                          type(exc).__name__)
            self._stopPlaybackBuffer()
            self._startupFailed("Playback failed: %s" % type(exc).__name__,
                                reason="ENGINE_EXCEPTION")

    def _noticeEngineDowngrade(self):
        """Say why 5001/5002 was replaced by 4097 instead of switching silently."""
        if getattr(self, "_engine_notice_done", False):
            return
        self._engine_notice_done = True
        try:
            from .service_compat import take_recent_downgrade
            missing = int(take_recent_downgrade() or 0)
        except Exception:
            missing = 0
        if missing in (5001, 5002) and int(self.servicetype) == 4097:
            name = "ExtePlayer3" if missing == 5002 else "GstPlayer"
            self._showNotification(u"%d (%s) is not installed  \u2022  playing with 4097" % (missing, name),
                                   MessageBox.TYPE_INFO, 8)

    def _showBufferBadge(self, megabytes=0):
        """Violet BUFFER pill in the HUD badge row while the buffer is in use."""
        try:
            if megabytes:
                self._setTechnicalBadgePixmap("bufferBadge", "tbs_buffer_%d.png" % int(megabytes))
            else:
                self["bufferBadge"].hide()
        except Exception:
            pass

    def _stopPlaybackBuffer(self):
        job = self._buffer_job
        self._buffer_job = None
        self._buffer_play_url = ""
        self._showBufferBadge(0)
        if job is not None:
            try:
                from .playback_buffer import stop_buffer
                stop_buffer(job)
            except Exception:
                pass

    def _preparePlaybackBuffer(self):
        self._stopPlaybackBuffer()
        if self.item.get("_catchup"):
            return
        if self._buffer_bypass_once:
            self._buffer_bypass_once = False
            return
        value = _player_buffer_mb()
        if not value:
            return
        url = self.streamurl or ""
        try:
            url = url.strip()
        except Exception:
            return
        # Never proxy HLS playlists; decoder handles their segment/key resolution.
        if (not url.startswith(("http://", "https://")) or "|" in url
                or re.search(r"\.m3u8?(?:[?#]|$)", url, re.I)):
            return
        try:
            from .playback_buffer import start_buffer
            self._buffer_job = start_buffer(url, value, key=self._identity)
            self._buffer_play_url = self._buffer_job.local_url
            self._buffer_mb = int(value)
            self._showBufferBadge(value)
            self._showNotification(u"Buffer %d MB  \u2022  preparing smooth playback..." % int(value),
                                   MessageBox.TYPE_INFO, 8)
        except Exception as exc:
            self._stopPlaybackBuffer()
            print("[TiviMateE2Py27] playback buffer skipped: %s" % exc)

    def _fallbackPlaybackBuffer(self):
        # Never restart completed playback or create an endless fallback loop.
        if self._closing or self._buffer_job is None:
            return False
        self._saveResume()
        self._savePreferences()
        self._stopPlaybackBuffer()
        self._buffer_bypass_once = True
        self._showNotification(u"Buffer skipped  \u2022  playing directly", MessageBox.TYPE_INFO, 4)
        self.playStream()
        return True

    def openPlaybackBufferMenu(self):
        choices = [("Off" if size == 0 else "%d MB" % size, size) for size in BUFFER_SIZES]
        return self._openVODOptions('PLAYBACK BUFFER (MOVIES / EPISODES)', choices, self._bufferSelected)

    def _bufferSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        try:
            value = int(selected[1])
            if _save_player_buffer_mb(value):
                self._showNotification("Buffer: %s (next playback)" % ("Off" if value == 0 else "%d MB" % value),
                                       MessageBox.TYPE_INFO, 4)
        except Exception:
            pass

    def _serviceStarted(self):
        if self._closing or self._startup_failed or self._fallback_pending:
            return
        try:
            from .track_restore import service_started as _track_memory_start
            _track_memory_start(self)
        except Exception:
            pass
        # evStart is only a decoder-start signal; actual video confirmation
        # still comes from the existing PTS/geometry monitor.
        self._seen_service_start = True
        self._last_pts_change_at = time.time()
        self._resume_attempts = 0

        if (self.ENABLE_RESUME_SUPPORT and int(self._resume_target or 0) > 0 and not self._resume_applied
                and int(self._resume_seek_count or 0) == 0):
            self._resume_started_at = time.time()
            self._resume_phase = "probe"
            self._scheduleResumeProbe()
    def _serviceFailed(self):
        if (self._closing or self._startup_failed or self._fallback_pending or
                self._playback_confirmed):
            return
        _vti_vod_diag("TUNE_FAILED", self.servicetype)
        self._startupFailed("Service Type %s could not start" % self.servicetype,
                            reason="TUNE_FAILED")

    def _serviceEOF(self):
        if self._closing or self._startup_failed or self._fallback_pending:
            return
        # An upstream/proxy error during startup must not pretend the movie ended.
        if self._buffer_job is not None and not self._playback_confirmed:
            job = self._buffer_job
            if getattr(job, "direct_only", False) or getattr(job, "failed", ""):
                if self._fallbackPlaybackBuffer():
                    return
        # UltraStalker-style resume shield: some ServiceApp/ExtEplayer3 builds
        # emit transient EOF while the decoder is still becoming seekable.
        if int(self._resume_target or 0) > 0 and time.time() < float(self._resume_grace_until or 0.0):
            return
        # 4097 can emit an early EOF while GStreamer is still opening a URL.
        if not self._playback_confirmed:
            self._startup_eof_count += 1
            if time.time() - self._service_started_at < (BUFFER_STARTUP_GRACE_SECONDS if self._buffer_job is not None else STARTUP_GRACE_SECONDS):
                self._showNotification("Opening %s ..." % self.servicetype, MessageBox.TYPE_INFO, 3)
                return
            self._startupFailed("No playable video on %s" % self.servicetype,
                                reason="EARLY_EOF")
            return

        next_episode_notice.hide(self)
        seek, position, duration = self._seekData()
        if duration and position >= int(duration * COMPLETE_RATIO):
            self._clearResume()
            # Series: continue automatically with the following episode when
            # the current episode reaches its real EOF.  Movies keep the
            # existing end-of-playback behaviour.
            if (self._episode_items and 0 <= self._episode_index < (len(self._episode_items) - 1)
                    and not getattr(self, "_next_notice_cancelled", False)):
                self._showNotification("Playing next episode", MessageBox.TYPE_INFO, 2)
                self._playEpisodeIndex(self._episode_index + 1)
                return
            self._showNotification("End of episode" if self._episode_items else "End of movie", MessageBox.TYPE_INFO, 2)
        else:
            self._saveResume()
            self._showNotification("Stream ended", MessageBox.TYPE_INFO, 3)

    def _seekData(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if not seek:
                return None, 0, 0
            pos_result = seek.getPlayPosition()
            len_result = seek.getLength()
            position = int(pos_result[1]) if pos_result and pos_result[0] == 0 and pos_result[1] > 0 else 0
            duration = int(len_result[1]) if len_result and len_result[0] == 0 and len_result[1] > 0 else 0
            return seek, position, duration
        except Exception:
            return None, 0, 0

    def _videoGeometry(self):
        if iServiceInformation is None:
            return 0, 0
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return 0, 0
            width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
            height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
            return max(0, width), max(0, height)
        except Exception:
            return 0, 0


    def _technicalItemHints(self):
        """Return technical hints already carried by the current VOD item.

        This is a local metadata fallback only; it performs no network request.
        Enigma2 service.info() remains authoritative whenever it reports a
        concrete value.
        """
        item = self.item if isinstance(getattr(self, "item", None), dict) else {}
        nested = item.get("info") if isinstance(item.get("info"), dict) else {}

        def first(keys):
            for src in (item, nested):
                for key in keys:
                    value = src.get(key)
                    if value not in (None, ""):
                        return str(value).strip()
            return ""

        resolution = ""
        quality_text = " ".join(filter(None, [
            first(("resolution", "quality", "video_resolution", "stream_quality")),
            first(("name", "title", "stream_name")),
        ])).upper()
        if any(token in quality_text for token in ("2160", "4K", "UHD")):
            resolution = "2160p"
        elif any(token in quality_text for token in ("1080", "FHD", "FULL HD")):
            resolution = "1080p"
        elif "720" in quality_text or " HD " in (" %s " % quality_text):
            resolution = "720p"
        elif "576" in quality_text:
            resolution = "576p"
        elif "480" in quality_text or " SD " in (" %s " % quality_text):
            resolution = "480p"

        video = ""
        codec_text = first(("video_codec", "codec", "video", "vcodec", "video_type")).upper()
        if "H265" in codec_text or "H.265" in codec_text or "HEVC" in codec_text or "X265" in codec_text:
            video = "HEVC"
        elif "H264" in codec_text or "H.264" in codec_text or "AVC" in codec_text or "X264" in codec_text:
            video = "H.264"
        elif "VP9" in codec_text:
            video = "VP9"
        elif "VP8" in codec_text:
            video = "VP8"
        elif "MPEG2" in codec_text or "MPEG-2" in codec_text:
            video = "MPEG2"
        elif "MPEG4" in codec_text or "MPEG-4" in codec_text:
            video = "MPEG4"
        elif "VC1" in codec_text or "VC-1" in codec_text:
            video = "VC-1"
        elif "XVID" in codec_text:
            video = "XVID"

        aspect = ""
        aspect_text = first(("aspect", "aspect_ratio", "display_aspect_ratio", "dar")).replace(" ", "")
        if aspect_text in ("16:9", "16/9", "1.7778", "1.78"):
            aspect = "16:9"
        elif aspect_text in ("4:3", "4/3", "1.3333", "1.33"):
            aspect = "4:3"
        elif aspect_text in ("2.35:1", "2.35", "2.39:1", "2.39", "21:9"):
            aspect = "2.35:1"

        return resolution, aspect, video

    def _technicalStreamInfo(self, width=0, height=0):
        """Read current stream technical data from the active Enigma2 service.

        Uses the already-existing playback monitor.  No new timer or hook is
        introduced.  Direct service values are preferred and geometry is kept
        as a safe fallback for images/service types that expose less metadata.
        """
        resolution = ""
        aspect = ""
        video = ""
        audio_name = ""

        try:
            width = int(width or 0)
            height = int(height or 0)
        except Exception:
            width, height = 0, 0

        service = None
        info = None
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
        except Exception:
            service = None
            info = None

        # Refresh geometry directly from the active service when the caller
        # still has 0/old values.  This is the same service.info() path already
        # used by _videoGeometry(), not a network request.
        if info is not None and iServiceInformation is not None:
            try:
                iw = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
                ih = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
                if iw > 0:
                    width = iw
                if ih > 0:
                    height = ih
            except Exception:
                pass

        # Resolution class: use both dimensions.  Cinemascope 1920x800/816
        # is still a 1080-class source, and 3840x1600 is still 2160/4K-class.
        if width > 0 or height > 0:
            if width >= 3000 or height >= 1800:
                resolution = "2160p"
            elif width >= 1800 or height >= 1000:
                resolution = "1080p"
            elif width >= 1200 or height >= 700:
                resolution = "720p"
            elif width >= 900 or height >= 560:
                resolution = "576p"
            elif width >= 700 or height >= 460:
                resolution = "480p"

        # Prefer the Enigma2 aspect value only when the image exposes a value
        # we can identify safely.  Otherwise derive it from the actual video
        # geometry, which is reliable across ServiceApp/4097 variants.
        if info is not None and iServiceInformation is not None:
            try:
                aspect_key = getattr(iServiceInformation, "sAspect", None)
                if aspect_key is not None:
                    av = int(info.getInfo(aspect_key))
                    # Common Enigma2 aspect encodings seen across images.
                    if av in (2, 3, 4, 5, 6):
                        aspect = "16:9"
                    elif av in (0, 1):
                        aspect = "4:3"
            except Exception:
                pass
        if not aspect and width > 0 and height > 0:
            try:
                ratio = float(width) / float(height)
                if abs(ratio - (16.0 / 9.0)) < 0.14:
                    aspect = "16:9"
                elif abs(ratio - (4.0 / 3.0)) < 0.11:
                    aspect = "4:3"
                elif 2.18 <= ratio <= 2.52:
                    aspect = "2.35:1"
            except Exception:
                pass

        # Video codec.  Some images return a numeric enum, while others return
        # -2 and expose the value through getInfoString().  Handle both.
        if info is not None and iServiceInformation is not None:
            try:
                video_type_key = getattr(iServiceInformation, "sVideoType", None)
                if video_type_key is not None:
                    raw_vtype = info.getInfo(video_type_key)
                    video_map = {
                        0: "MPEG2", 1: "H.264", 2: "H.263", 3: "VC-1",
                        4: "MPEG4", 5: "VC-1", 6: "MPEG1", 7: "HEVC",
                        8: "VP8", 9: "VP9", 10: "XVID", 11: "AVS",
                        12: "AVS2", 13: "VVC",
                    }
                    try:
                        iv = int(raw_vtype)
                    except Exception:
                        iv = -1
                    video = video_map.get(iv, "")
                    if not video and iv == -2:
                        try:
                            txt = str(info.getInfoString(video_type_key) or "").upper()
                        except Exception:
                            txt = ""
                        if "H265" in txt or "H.265" in txt or "HEVC" in txt:
                            video = "HEVC"
                        elif "H264" in txt or "H.264" in txt or "AVC" in txt:
                            video = "H.264"
                        elif "VP9" in txt:
                            video = "VP9"
                        elif "VP8" in txt:
                            video = "VP8"
                        elif "MPEG2" in txt or "MPEG-2" in txt:
                            video = "MPEG2"
                        elif "MPEG4" in txt or "MPEG-4" in txt:
                            video = "MPEG4"
                        elif "VC1" in txt or "VC-1" in txt:
                            video = "VC-1"
            except Exception:
                pass

        # Current selected audio track.  Keep the real track description as
        # source and normalize only to badge names we actually ship.
        try:
            tracks = service and service.audioTracks()
            if tracks and int(tracks.getNumberOfTracks()) > 0:
                index = int(tracks.getCurrentTrack())
                track = tracks.getTrackInfo(index)
                desc = str(track.getDescription() or "").strip()
                upper = desc.upper().replace("_", " ")
                if "E-AC3" in upper or "EAC3" in upper or "EC-3" in upper or "DD+" in upper or "DOLBY DIGITAL PLUS" in upper:
                    audio_name = "E-AC3"
                elif "TRUEHD" in upper:
                    audio_name = "TRUEHD"
                elif "AC3" in upper or "AC-3" in upper or "DOLBY DIGITAL" in upper:
                    audio_name = "AC3"
                elif "DTS" in upper:
                    audio_name = "DTS"
                elif "AAC" in upper:
                    audio_name = "AAC"
                elif "MP3" in upper or "MPEG LAYER 3" in upper:
                    audio_name = "MP3"
        except Exception:
            pass

        # If Enigma2 has not exposed video metadata yet (common on some
        # service types during startup/after a seek), use only metadata that
        # already arrived with this VOD item.  Never overwrite a concrete
        # service.info() value with a hint.
        try:
            hint_resolution, hint_aspect, hint_video = self._technicalItemHints()
            if not resolution and hint_resolution:
                resolution = hint_resolution
            if not aspect and hint_aspect:
                aspect = hint_aspect
            if not video and hint_video:
                video = hint_video
        except Exception:
            pass

        return resolution, aspect, video, audio_name

    def _setTechnicalBadgePixmap(self, widget_name, filename):
        widget = self[widget_name]
        if not filename:
            try:
                widget.hide()
            except Exception:
                pass
            return
        if filename.startswith("tbs_"):
            path = os.path.join(PLUGIN_PATH, "skins", "live_infobar", "badges", filename)
        else:
            path = os.path.join(PLUGIN_PATH, "tivimate_infobar", "common", filename)
        if not os.path.exists(path):
            try:
                widget.hide()
            except Exception:
                pass
            return
        try:
            widget.instance.setPixmapFromFile(path)
        except Exception:
            try:
                widget.setPixmapFromFile(path)
            except Exception:
                return
        try:
            widget.show()
        except Exception:
            pass

    def _updateTechnicalBadges(self, width=0, height=0):
        try:
            resolution, aspect, video, audio_name = self._technicalStreamInfo(width, height)
            resolution_files = {"2160p": "tbs_res_2160p.png", "4K": "tbs_res_2160p.png", "1080p": "tbs_res_1080p.png",
                                "720p": "tbs_res_720p.png", "576p": "tbs_res_576p.png", "480p": "tbs_res_480p.png"}
            aspect_files = {"16:9": "tbs_aspect_16_9.png", "4:3": "tbs_aspect_4_3.png", "2.35:1": "tbs_aspect_2_35_1.png"}
            video_files = {"H.264": "tbs_video_h264.png", "HEVC": "tbs_video_hevc.png", "VP9": "tbs_video_vp9.png",
                           "VP8": "tbs_video_vp8.png", "MPEG2": "tbs_video_mpeg2.png", "MPEG4": "tbs_video_mpeg4.png",
                           "VC-1": "tbs_video_vc1.png", "XVID": "tbs_video_xvid.png", "AVS": "tbs_video_avs.png",
                           "AVS2": "tbs_video_avs2.png"}
            audio_files = {"AAC": "tbs_audio_aac.png", "AC3": "tbs_audio_ac3.png", "E-AC3": "tbs_audio_eac3.png",
                           "DTS": "tbs_audio_dts.png", "MP3": "tbs_audio_mp3.png"}

            # During a seek, service.info() can transiently return 0/empty for
            # video geometry and codec.  Do not turn a valid badge off because
            # of that temporary gap; replace it only when a new valid value is
            # reported.
            last = getattr(self, "_tech_badge_values", None)
            if not isinstance(last, dict):
                last = {"resolution": "", "aspect": "", "video": "", "audio": ""}
            if resolution in resolution_files:
                last["resolution"] = resolution
            if aspect in aspect_files:
                last["aspect"] = aspect
            if video in video_files:
                last["video"] = video
            if audio_name in audio_files:
                last["audio"] = audio_name
            self._tech_badge_values = last

            self._setTechnicalBadgePixmap("resolutionBadge", resolution_files.get(last.get("resolution")))
            self._setTechnicalBadgePixmap("aspectBadge", aspect_files.get(last.get("aspect")))
            self._setTechnicalBadgePixmap("videoBadge", video_files.get(last.get("video")))
            self._setTechnicalBadgePixmap("audioBadge", audio_files.get(last.get("audio")))
        except Exception:
            pass
        # Lock reflects HTTPS transport; network icon reflects an IP stream URL.
        try:
            is_secure = str(self.streamurl or "").lower().startswith("https://")
            (self["lockIcon"].show() if is_secure else self["lockIcon"].hide())
        except Exception:
            pass

    @staticmethod
    def _clock(pts):
        seconds = max(0, int(pts or 0) // PTS)
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return "%d:%02d:%02d" % (hours, minutes, seconds) if hours else "%02d:%02d" % (minutes, seconds)

    def _updateServiceTypeBadge(self):
        # r153: numeric service type stays in the footer. The deprecated icon
        # was rendered at (0, 0) by older Enigma2 skins despite (-300, -300).
        try:
            self["serviceTypeText"].setText(str(int(self.servicetype)))
        except Exception:
            pass

    def _updatePlayerAnalogClock(self):
        # Reuse the existing 1-second playback monitor; no extra timer/hook.
        self._updateServiceTypeBadge()
        try:
            now_tm = time.localtime()
            try:
                self["playerDate"].setText(time.strftime("%a  %d %b %Y", now_tm).upper())
                self["playerTime"].setText(time.strftime("%H:%M", now_tm))
            except Exception:
                pass
            # Analog clock removed: VTi drew its off-screen hands at the top-left corner.
        except Exception:
            pass


    def _checkStartupGuard(self):
        """Ultra 12s guard, plus 6s when evStart arrived without video.

        A decoder can emit evStart before rendering a single video frame. Never
        loop the engine or silently switch service types on failure.
        """
        if (self._closing or self._startup_failed or self._playback_confirmed or
                self._fallback_pending):
            return
        # Probe a final time, because a video frame can land between 1s polls.
        try:
            seek, position, duration = self._seekData()
            width, height = self._videoGeometry()
            if position > 0 or (width > 0 and height > 0):
                self._playback_confirmed = True
                return
        except Exception:
            pass
        if self._seen_service_start and not self._startup_guard_expanded:
            self._startup_guard_expanded = True
            try:
                self._startup_guard_timer.start(VOD_BUFFER_VERIFY_MS if self._buffer_job is not None else VOD_DECODER_VERIFY_MS, True)
            except Exception:
                pass
            return
        self._startupFailed('Video did not start on Service Type %s' % self.servicetype,
                            reason="STARTUP_TIMEOUT")

    def _startupFailed(self, message, reason="STARTUP_FAILURE"):
        if (self._closing or self._startup_failed or self._playback_confirmed or
                self._fallback_pending):
            return
        if self._buffer_job is not None and self._fallbackPlaybackBuffer():
            return
        _vti_vod_diag("START_FAILURE", self.servicetype, reason)
        if self._tryVodFallback(reason):
            return
        self._startup_failed = True
        if self.item.get("_catchup"):
            tried = getattr(self, "_replay_tried_urls", set())
            tried.add(self.streamurl)
            self._replay_tried_urls = tried
            for candidate in self.item.get("_catchup_candidates") or []:
                if candidate and candidate not in tried:
                    self._replay_retry_url = candidate
                    try:
                        self._startup_guard_timer.stop()
                        self._monitor_timer.stop()
                        self._memory_guard_timer.stop()
                        self._startup_exit_timer.start(150, True)
                    except Exception:
                        self._startupFailureExit()
                    return
        try:
            self._startup_guard_timer.stop()
            self._monitor_timer.stop()
            self._memory_guard_timer.stop()
        except Exception:
            pass
        self._showNotification(message, MessageBox.TYPE_ERROR, 5)
        try:
            self._startup_exit_timer.start(500, True)
        except Exception:
            self._startupFailureExit()

    def _startupFailureExit(self):
        if self._closing or not self._startup_failed:
            return
        retry_url = getattr(self, "_replay_retry_url", None)
        if retry_url:
            self._replay_retry_url = None
            self.streamurl = retry_url
            self._started = False
            self._startup_failed = False
            self.playStream()
            return
        # Save no progress on a never-started film. Enigma2's nav operations
        # remain on the GUI thread; do not send unsafe Stop/Play from threads.
        self._closing = True
        self._artwork_generation += 1
        self._stopTimers()
        self._stopPlaybackBuffer()
        try:
            self._clearExternalSubtitle()
        except Exception:
            pass
        self._restoreOriginalService()
        try:
            self.close()
        except Exception:
            pass
        try:
            self.session.open(MessageBox,
                              'TiviMate: VOD could not start. Returned to the previous channel.',
                              MessageBox.TYPE_ERROR, timeout=6)
        except Exception:
            pass

    def _checkMemoryGuard(self):
        """Removed: the player no longer watches RAM, hides artwork, refreshes
        or closes a film. Enigma2 and the kernel manage memory themselves."""
        return

    def _monitorPlayback(self):
        if self._closing or self._startup_failed:
            return
        if self._buffer_job is not None:
            job = self._buffer_job
            if getattr(job, "failed", "") or (getattr(job, "direct_only", False) and not self._playback_confirmed):
                if self._fallbackPlaybackBuffer():
                    return
        seek, position, duration = self._seekData()
        width, height = self._videoGeometry()
        now = time.time()
        hud_visible = getattr(self, "shown", True)
        if hud_visible and self._memory_guard_level < 2:
            self._updatePlayerAnalogClock()
            self._tech_badge_tick = (int(getattr(self, "_tech_badge_tick", 0)) + 1) % 3
            if self._tech_badge_tick == 1:
                self._updateTechnicalBadges(width, height)

        if position > 0:
            self._last_position = position
        if duration > 0:
            self._last_duration = duration

        # Playback is confirmed by a moving PTS or a real decoded video geometry.
        # Do this before restoring late audio/subtitle tracks so ServiceApp is
        # already rendering the service when an embedded subtitle is enabled.
        if position > 0 or (width > 0 and height > 0):
            if not self._playback_confirmed:
                self._playback_confirmed = True
                self._stall_notice_sent = False
                try:
                    self._startup_guard_timer.stop()
                except Exception:
                    pass
                self._clearNotification()
                if self._buffer_job is not None:
                    self._showNotification(u"Buffer active  \u2022  %d MB ready ahead" %
                                           int(getattr(self, "_buffer_mb", 0) or 0), MessageBox.TYPE_INFO, 4)


        if position and position != self._last_pts_seen:
            self._last_pts_seen = position
            self._last_pts_change_at = now
            self._stall_notice_sent = False
        elif self._playback_confirmed and now - self._last_pts_change_at >= STALL_NOTICE_SECONDS and not self._stall_notice_sent:
            self._stall_notice_sent = True
            self._showNotification("Playback stalled - try another Service Type", MessageBox.TYPE_INFO, 5)
        elif not self._playback_confirmed and now - self._service_started_at >= STARTUP_GRACE_SECONDS and not self._stall_notice_sent:
            self._stall_notice_sent = True
            self._showNotification("No video yet on %s - try another Service Type" % self.servicetype, MessageBox.TYPE_INFO, 5)

        # Episode notice follows playback PTS even with a hidden infobar.
        next_episode_notice.tick(self, position, duration)
        # Service polling, checkpoint, subtitle and resume timers remain active.
        if not hud_visible:
            return
        if self._playback_confirmed:
            self._loadDeferredVodArtwork()
        self._applyPendingMovieLogo()
        # Update visual widgets only while the infobar is visible.
        try:
            self["vodPosition"].setText(self._clock(position))
            self["vodDuration"].setText(self._clock(duration) if duration else "--:--")
            # Only show a percentage when Enigma2 supplies a valid seek
            # timeline. Never invent elapsed time from the wall clock or
            # silently pretend that position > duration is a 100% movie.
            valid_timeline = bool(duration > 0 and position >= 0 and
                                  position <= duration + 2 * PTS)
            value = min(100, max(0, int((float(position) * 100.0) / duration))) if valid_timeline else 0
            self["vodProgress"].setValue(value)
        except Exception:
            pass
        try:
            from enigma import ePoint
            from .display_scale import sx, sy
            knob_x = 385 + int(985 * value / 100.0) - 15
            if knob_x != self._vodKnobX:
                self._vodKnobX = knob_x
                self["vodKnob"].instance.move(ePoint(sx(knob_x), sy(962)))
        except Exception:
            pass
        try:
            from enigma import eSize
            from .display_scale import sx, sy
            fill_w = max(1, int(985 * value / 100.0))
            if fill_w != self._vodFillW:
                self._vodFillW = fill_w
                # The pixmap is drawn unscaled from the left and clipped by the widget width.
                self["vodProgressFill"].instance.resize(eSize(sx(fill_w), sy(14)))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Resume store
    # ------------------------------------------------------------------
    def _resumeDb(self):
        return _read_json(PLAYER_RESUME_FILE)

    def _loadResumeTarget(self):
        if self.item.get("_catchup"):
            return 0
        # Same bookmark eligibility used by the UltraStalker reference player:
        # ignore only trivial starts (<10s) and bookmarks in the last 10s.
        if not self.ENABLE_RESUME_SUPPORT:
            return 0
        row = self._resumeDb().get(self._identity) or {}
        if not row.get("position"):
            # Continue Watching keeps the same identity in resume.json.
            try:
                watched = _read_json(CONTINUE_WATCHING_FILE).get(self._identity) or {}
                if isinstance(watched, dict) and watched.get("position"):
                    row = {"position": watched.get("position"),
                           "duration": watched.get("duration") or watched.get("length") or 0}
            except Exception:
                pass
        try:
            position = max(0, int(row.get("position", 0) or 0))
        except Exception:
            position = 0
        try:
            duration = max(0, int(row.get("duration", 0) or 0))
        except Exception:
            duration = 0
        if position < 10 * PTS:
            return 0
        if duration and (position >= duration or max(0, duration - position) <= 10 * PTS):
            return 0
        return position

    def _scheduleResumeProbe(self):
        if self._closing or self._resume_applied or int(self._resume_target or 0) <= 0:
            return
        attempt = max(0, int(self._resume_attempts or 0))
        delay = min(1200, 50 * (2 ** min(attempt, 4)))
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        try:
            self._resume_timer.start(int(delay), True)
        except Exception:
            pass

    def _resumeMayProbe(self, limit=30.0):
        """Keep trying while the stream is still opening (slow servers)."""
        started = float(self._resume_started_at or 0.0) or float(getattr(self, "_service_started_at", 0.0) or 0.0)
        return (time.time() - started) < float(limit)

    def _finishResume(self, available=True):
        self._resume_target = 0
        self._resume_grace_until = 0.0
        self._resume_applied = True
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        if not available:
            self._showNotification("Resume unavailable", MessageBox.TYPE_INFO, 2)

    def _cancelPendingResumeForManualSeek(self):
        if int(self._resume_target or 0) <= 0 or self._resume_applied:
            return
        self._resume_target = 0
        self._resume_grace_until = 0.0
        self._resume_applied = True
        try:
            self._resume_timer.stop()
        except Exception:
            pass

    def _resumeTick(self):
        """UltraStalker V6 resume lifecycle, adapted to the existing TiviMate timer.

        Start playback first, wait for evStart, verify a real seek interface, a
        valid duration and play position, allow at least 0.55s decoder settle,
        issue exactly one absolute seek, then verify it reached the bookmark.
        """
        if not self.ENABLE_RESUME_SUPPORT:
            self._finishResume(True)
            return
        if self._closing or self._resume_applied:
            try:
                self._resume_timer.stop()
            except Exception:
                pass
            return
        target = int(self._resume_target or 0)
        if target <= 0:
            self._finishResume(True)
            return

        # Verification phase after the one and only automatic seek.
        if int(self._resume_seek_count or 0) > 0:
            try:
                service = self.session.nav.getCurrentService()
                seekable = service.seek() if service else None
                pos = seekable.getPlayPosition() if seekable else None
                current = max(0, int(pos[1])) if pos and not pos[0] else 0
            except Exception:
                current = 0
            tolerance = 7 * PTS
            if current and abs(int(current) - target) <= tolerance:
                self._last_position = max(int(getattr(self, "_last_position", 0) or 0), current)
                self._showNotification("Resume %s" % self._clock(current), MessageBox.TYPE_INFO, 2)
                self._finishResume(True)
                self._syncExternalSubtitleAfterSeek()   # subtitles follow the jump
                return
            self._resume_verify_cycles += 1
            if self._resume_verify_cycles < 7:
                try:
                    self._resume_timer.stop()
                    self._resume_timer.start(350, True)
                except Exception:
                    pass
                return
            # Some engines ignore the first seek while still buffering: try
            # again (at most 3 seeks); manual seeks cancel this at once.
            if int(self._resume_seek_count or 0) < 3 and self._resumeMayProbe(45.0):
                try:
                    service = self.session.nav.getCurrentService()
                    seekable = service.seek() if service else None
                    if seekable is not None:
                        seekable.seekTo(int(target))
                        self._resume_seek_count = int(self._resume_seek_count or 0) + 1
                        self._resume_verify_cycles = 0
                        self._resume_timer.stop()
                        self._resume_timer.start(900, True)
                        return
                except Exception:
                    pass
            self._finishResume(False)
            return

        # Probe phase. ServiceApp/ExtEplayer3 may expose service.seek() at
        # evStart before seekTo() is actually honoured.
        if self._resume_started_at and (time.time() - self._resume_started_at) < 0.55:
            self._resume_attempts += 1
            self._scheduleResumeProbe()
            return
        try:
            service = self.session.nav.getCurrentService()
            seekable = service.seek() if service else None
        except Exception:
            seekable = None
        if seekable is None:
            self._resume_attempts += 1
            if self._resumeMayProbe():
                self._scheduleResumeProbe()
            else:
                self._finishResume(False)
            return

        native_probe = getattr(self, "isCurrentlySeekable", None)
        if callable(native_probe):
            try:
                state = native_probe()
                if isinstance(state, (tuple, list)):
                    state = (not state[0]) and (len(state) < 2 or bool(state[1]))
                if not bool(state):
                    self._resume_attempts += 1
                    if self._resumeMayProbe():
                        self._scheduleResumeProbe()
                    else:
                        self._finishResume(False)
                    return
            except Exception:
                pass

        try:
            length = seekable.getLength()
            position = seekable.getPlayPosition()
            length_ok = bool(length and not length[0] and int(length[1] or 0) > 30 * PTS)
            pos_ok = bool(position and not position[0] and int(position[1] or 0) >= 0)
        except Exception:
            length = None
            length_ok = False
            pos_ok = False
        if not (length_ok and pos_ok):
            self._resume_attempts += 1
            if self._resumeMayProbe():
                self._scheduleResumeProbe()
            else:
                self._finishResume(False)
            return

        try:
            effective_target = min(target, max(0, int(length[1]) - 10 * PTS))
            seekable.seekTo(int(effective_target))
            self._resume_target = int(effective_target)
            self._resume_seek_count = 1
            self._resume_verify_cycles = 0
            self._last_position = max(int(getattr(self, "_last_position", 0) or 0), int(effective_target))
            self._resume_timer.stop()
            self._resume_timer.start(450, True)
        except Exception:
            self._resume_attempts += 1
            if self._resume_seek_count == 0 and self._resumeMayProbe():
                self._scheduleResumeProbe()
            else:
                self._finishResume(False)

    def _checkpoint(self):
        if self.ENABLE_RESUME_SUPPORT:
            self._saveResume()

    def _saveContinueWatching(self):
        """Save Continue Watching history without enabling automatic Resume.

        This deliberately uses the existing Continue Watching database (resume.json)
        and never feeds a seek target back into playback.
        """
        _seek, position, duration = self._seekData()
        # ServiceApp can briefly report the pre-seek/zero PTS when EXIT follows a
        # large forward seek.  Keep the newest valid sample collected by the
        # existing playback monitor and never let that transient read erase it.
        last_position = int(getattr(self, "_last_position", 0) or 0)
        if position > 0:
            position = max(int(position), last_position)
            self._last_position = position
        else:
            position = last_position
        last_duration = int(getattr(self, "_last_duration", 0) or 0)
        if duration > 0:
            duration = max(int(duration), last_duration)
            self._last_duration = duration
        else:
            duration = last_duration

        # Do not create accidental cards from a title that was only opened briefly.
        if not position or position < RESUME_MIN_SECONDS * PTS:
            return

        db = _read_json(CONTINUE_WATCHING_FILE)
        key = str(self._identity or "")
        if not key:
            return

        # Finished titles are removed from Continue Watching.
        if duration and position >= int(duration * COMPLETE_RATIO):
            if key in db:
                db.pop(key, None)
                _write_json(CONTINUE_WATCHING_FILE, db)
            return

        item = dict(self.item or {})
        title = _clean_title(item.get("name") or item.get("title") or item.get("stream_name") or "")
        source_key = str(item.get("_source_key") or "")
        source_type = str(item.get("_source_type") or "xtream")
        try:
            service_type = int(self.servicetype or 4097)
        except Exception:
            service_type = 4097

        is_series = bool(
            item.get("series_name") or item.get("series_id") or
            item.get("episode_num") not in (None, "") or
            item.get("episode_number") not in (None, "") or
            item.get("_episode_items")
        )
        row = {
            "position": int(position),
            "length": int(duration or 0),
            "duration": int(duration or 0),
            "updated": int(time.time()),
            "title": title,
            "kind": "episode" if is_series else "movie",
            "source_key": source_key,
            "source_type": source_type,
            "service_type": service_type,
            "streamurl": str(self.streamurl or ""),
            "item": item,
        }
        if is_series:
            row["series_title"] = _clean_title(item.get("series_name") or item.get("_tmdb_title") or title)
            row["series_id"] = item.get("series_id") or ""
            row["season"] = item.get("season") or item.get("season_number") or ""
            row["episode"] = item.get("episode_num") or item.get("episode_number") or item.get("episode") or ""

        previous = db.get(key) if isinstance(db.get(key), dict) else {}
        # Continue Watching resolves its real backdrop after playback and
        # stores it in resume.json. A progress checkpoint MUST NOT replace the
        # whole record and throw away that artwork. Only carry saved artwork
        # forward for the same title/episode and kind; a reused server stream
        # ID must never inherit a different title's cached picture.
        try:
            same_media = bool(previous and
                text_type(previous.get("title") or u"").strip() == text_type(title or u"").strip() and
                str(previous.get("kind") or "") == str(row.get("kind") or ""))
            if same_media and is_series:
                for field in ("series_title", "season", "episode"):
                    a = str(previous.get(field) or "").strip()
                    b = str(row.get(field) or "").strip()
                    if a and b and a != b:
                        same_media = False
                        break
            if same_media:
                for field in ("content_id", "backdrop", "backdrop_content_id",
                              "poster", "tmdb_id", "year", "overview", "rating"):
                    if previous.get(field) not in (None, "") and not row.get(field):
                        row[field] = previous[field]
                # A player payload can omit details supplied during a previous
                # session. Keep only useful metadata/artwork, not old stream IDs.
                previous_item = previous.get("item") or {}
                if isinstance(previous_item, dict):
                    for field in ("tmdb_id", "tmdb", "_tmdb_id", "backdrop_path",
                                  "backdrop_url", "backdrop", "fanart", "background",
                                  "poster_path", "year", "release_date", "first_air_date"):
                        if previous_item.get(field) and not item.get(field):
                            item[field] = previous_item[field]
        except Exception:
            pass
        servers = dict(previous.get("servers") or {})
        if source_key and self.streamurl:
            servers[source_key] = {
                "source_key": source_key,
                "source_type": source_type,
                "streamurl": str(self.streamurl),
                "service_type": service_type,
                "item": item,
            }
        if servers:
            row["servers"] = servers

        db[key] = row
        _write_json(CONTINUE_WATCHING_FILE, db)

    def _saveResume(self):
        if self.item.get("_catchup"):
            return None
        # Keep call sites compatible, but never read/write resume state while disabled.
        if not self.ENABLE_RESUME_SUPPORT:
            return
        _seek, position, duration = self._seekData()
        if position > 0:
            self._last_position = position
        else:
            position = self._last_position
        if duration > 0:
            self._last_duration = duration
        else:
            duration = self._last_duration

        db = self._resumeDb()
        # Never erase a good resume merely because startup/decoder currently has no PTS.
        if not position or position < RESUME_MIN_SECONDS * PTS:
            return
        if duration and position >= int(duration * COMPLETE_RATIO):
            if self._identity in db:
                db.pop(self._identity, None)
                _write_json(PLAYER_RESUME_FILE, db)
            return
        db[self._identity] = {
            "position": int(position),
            "duration": int(duration or 0),
            "updated": int(time.time()),
            "title": _clean_title(self.item.get("name") or self.item.get("title") or ""),
        }
        _write_json(PLAYER_RESUME_FILE, db)

    def _clearResume(self):
        if not self.ENABLE_RESUME_SUPPORT:
            return
        db = self._resumeDb()
        if self._identity in db:
            db.pop(self._identity, None)
            _write_json(PLAYER_RESUME_FILE, db)

    # ------------------------------------------------------------------
    # Audio / subtitle preferences
    # ------------------------------------------------------------------
    def _prefsDb(self):
        return _read_json(PLAYER_PREFS_FILE)

    def _savePreferences(self):
        db = self._prefsDb()
        row = dict(db.get(self._identity) or {})
        # Audio selection is intentionally manual. Do not persist or restore
        # an audio track here, because track ordering can differ per service
        # and restoring it can move the UI selection away from the real audio.
        row.pop("audio_index", None)
        row.pop("audio_lang", None)
        row.pop("audio_desc", None)
        # Subtitle state is session-only: never save a path or cached delay.
        row.pop("subtitle_delay_ms", None)
        row.pop("external_subtitle_path", None)
        row["last_service_type"] = int(self.servicetype)
        db[self._identity] = row
        _write_json(PLAYER_PREFS_FILE, db)

    def _restorePreferences(self):
        # Never auto-enable a subtitle from an earlier playback session.
        # Playback starts without downloaded subtitles until explicitly chosen.
        self._subtitle_session_delay_ms = 0
        self._subtitle_restore_attempted = True

    def audioSelection(self):
        """Use the native decoder's audio tracks, with a visible VTi menu."""
        try:
            service = self.session.nav.getCurrentService()
            tracks = service and service.audioTracks()
            count = int(tracks.getNumberOfTracks()) if tracks is not None else 0
            if count <= 0:
                self._showNotification('No audio tracks reported by the stream', timeout=4)
                return False
            try:
                active = int(tracks.getCurrentTrack())
            except Exception:
                active = -1
            options = []
            for index in range(count):
                try:
                    info = tracks.getTrackInfo(index)
                    lang = gui_text(info.getLanguage() or '')
                    desc = gui_text(info.getDescription() or '')
                except Exception:
                    lang, desc = '', ''
                description = '  '.join(x for x in (lang, desc) if x) or 'Audio'
                status = '  [ACTIVE]' if index == active else ''
                options.append(('%02d    %s%s' % (index + 1, description, status), index))
            return self._openVODOptions('AUDIO TRACKS', options, self._vodAudioSelected)
        except Exception as exc:
            self._showNotification('Audio tracks unavailable: %s' % type(exc).__name__, timeout=4)
            return False

    def _vodAudioSelected(self, selected=None):
        self.unlockShow()
        if not selected:
            return
        try:
            index = int(selected[1])
            service = self.session.nav.getCurrentService()
            tracks = service and service.audioTracks()
            if tracks is None or not 0 <= index < int(tracks.getNumberOfTracks()):
                return
            tracks.selectTrack(index)
        except Exception as exc:
            self._showNotification('Audio selection failed: %s' % type(exc).__name__, timeout=4)

    def audioSelected(self, result=None):
        # Keep the native audio-selection callback where supported.
        try:
            parent = getattr(InfoBarAudioSelection, 'audioSelected', None)
            if callable(parent):
                return parent(self, result)
        except Exception:
            pass

    def openSubtitleSelection(self):
        """Select real embedded/server tracks using a z=35 modal on VTi."""
        self._manual_subtitle_menu_until = time.time() + 90
        try:
            service = self.session.nav.getCurrentService()
            native_sub = service and service.subtitle()
            rows = list(native_sub.getSubtitleList() or []) if native_sub else []
            options = [('OFF    Disable subtitles', None)]
            current = getattr(self, 'selected_subtitle', None)
            for index, subtitle in enumerate(rows):
                if not isinstance(subtitle, (tuple, list)):
                    continue
                language = ''
                try:
                    for piece in reversed(subtitle):
                        if isinstance(piece, (str, text_type)) and piece:
                            language = gui_text(piece)
                            break
                except Exception:
                    pass
                if not language:
                    language = 'Track %d' % (index + 1)
                try:
                    is_current = tuple(current) == tuple(subtitle)
                except Exception:
                    is_current = False
                status = '  [ACTIVE]' if is_current else ''
                options.append(('%02d    %s%s' % (index + 1, language, status), tuple(subtitle)))
            if len(options) == 1:
                options.append(('No server / embedded subtitle tracks in this stream', 'unavailable'))
            return self._openVODOptions('SERVER / EMBEDDED SUBTITLES', options,
                                        self._vodServerSubtitleSelected)
        except Exception as exc:
            self._showNotification('Subtitle tracks unavailable: %s' % type(exc).__name__, timeout=5)
            return False

    def _vodServerSubtitleSelected(self, selected=None):
        self.unlockShow()
        if not selected:
            return
        subtitle = selected[1]
        if subtitle == 'unavailable':
            self._showNotification('No server subtitles. Use TiviMate subtitle search.', timeout=4)
            return
        try:
            self._manual_subtitle_menu_until = time.time() + 90
            if subtitle is None:
                self._clearExternalSubtitle()
                self.enableSubtitle(None)
            elif not self.enableSubtitle(subtitle):
                self._showNotification('Receiver could not activate this subtitle track', timeout=4)
        except Exception as exc:
            self._showNotification('Server subtitle failed: %s' % type(exc).__name__, timeout=4)

    def _syncExternalSubtitleAfterSeek(self):
        """Resync the active external subtitle engine after a VOD seek.

        TiviMatePlayer uses InfoBarSeek directly rather than inheriting the
        subtitle controller mixin, so normal seek actions otherwise bypass
        TiviMateSubtitleSupport.playAfterSeek().
        """
        controller = (getattr(self, "_external_subs", None) or
                      getattr(self, "_tivimate_subtitles", None) or
                      getattr(self, "_subssupport", None) or
                      getattr(self, "_tivimate_subtitle_controller", None))
        if controller is None:
            return
        try:
            sync = getattr(controller, "playAfterSeek", None)
            if callable(sync):
                sync()
        except Exception as exc:
            print("[TiviMateE2] subtitle resync after seek failed: %s" % exc)

    def _episodeNumberSeek(self, digit):
        """Episode-only numeric skipping with the receiver's native intervals.

        All actual seeks run through doSeekRelative so resume cancellation and
        external-subtitle resync remain identical to the existing VOD player.
        No separate playback engine, worker, queue or timer is introduced.
        """
        if self._closing or self._startup_failed:
            return False
        intervals = {1: ("selfdefined_13", -1, 15),
                     3: ("selfdefined_13", 1, 15),
                     4: ("selfdefined_46", -1, 60),
                     6: ("selfdefined_46", 1, 60),
                     7: ("selfdefined_79", -1, 300),
                     9: ("selfdefined_79", 1, 300)}
        setting, direction, fallback = intervals.get(int(digit), (None, 0, 0))
        if not setting:
            return False
        seconds = fallback
        try:
            from Components.config import config
            entry = getattr(getattr(config, "seek", None), setting, None)
            if entry is not None:
                seconds = int(entry.value)
        except Exception:
            pass
        if seconds <= 0:
            return False
        seek, _position, duration = self._seekData()
        if seek is None:
            self._showNotification("Seeking is not available for this video", timeout=3)
            return False
        native_ok = duration > 0
        try:
            if seek.isCurrentlySeekable() == 0:
                native_ok = False
        except Exception:
            pass
        if not native_ok:
            # Engine reports no length / not seekable yet (common at the start
            # of HTTP VOD): ask the service directly instead of refusing.
            try:
                self._cancelPendingResumeForManualSeek()
                seek.seekRelative(1 if direction > 0 else -1, int(seconds * PTS))
                self._syncExternalSubtitleAfterSeek()
                self.refreshInfobar()
                return True
            except Exception as exc:
                print("[TiviMateE2] direct seek failed: %s" % exc)
                self._showNotification("This stream does not support seeking", timeout=3)
                return False
        try:
            self.doSeekRelative(int(direction * seconds * PTS))
            self.refreshInfobar()
            return True
        except Exception as exc:
            print("[TiviMateE2] episode number seek failed: %s" % exc)
            self._showNotification("Could not seek this episode", timeout=3)
            return False

    def doSeekRelative(self, pts):
        self._cancelPendingResumeForManualSeek()
        result = InfoBarSeek.doSeekRelative(self, pts)
        self._syncExternalSubtitleAfterSeek()
        return result

    def doSeek(self, pts):
        self._cancelPendingResumeForManualSeek()
        result = InfoBarSeek.doSeek(self, pts)
        self._syncExternalSubtitleAfterSeek()
        return result

    def enableSubtitle(self, subtitle):
        """Use the receiver-native embedded subtitle renderer (as Ultra does).

        Return True only when native selection is reflected in the active
        subtitle window. Manual choices are never persisted or reapplied.
        """
        # Never overwrite explicitly loaded/downloaded subtitle captions.
        if subtitle is not None and getattr(self, "_external_subtitle_owner", "") == "subssupport":
            path = str(getattr(self, "_external_subtitle_path", "") or "")
            if path and os.path.isfile(path):
                in_menu = time.time() <= float(getattr(self, "_manual_subtitle_menu_until", 0) or 0)
                started = float(getattr(self, "_service_started_at", 0) or 0)
                automatic = (getattr(self, "_auto_subtitle_call", False) or
                             (time.time() - started) < 25)
                if not in_menu and automatic:
                    return False   # automatic restore never replaces it
                # Manual choice from the subtitle menu: switch from the
                # downloaded subtitle to the server subtitle.
                self._clearExternalSubtitle()
                self._forgetSavedExternalSubtitle()

        try:
            # Enigma2 owns the native subtitle window's display, timing and
            # decoding. Do not swap it for the bundled embedded renderer.
            result = InfoBarSubtitleSupport.enableSubtitle(self, subtitle)
            if result is False:
                return False
        except Exception as exc:
            print("[TiviMateE2] native server subtitle activation failed: %s" % exc)
            return False

        # Disabling is a real user preference; no active renderer is expected.
        if subtitle is None:
            accepted = getattr(self, "selected_subtitle", None) is None
        else:
            current = getattr(self, "selected_subtitle", None)
            try:
                accepted = tuple(current) == tuple(subtitle)
            except (TypeError, ValueError):
                accepted = current == subtitle
            window = getattr(self, "subtitle_window", None)
            # Check that the receiver created a real subtitle display.
            # Do NOT require window.shown: the native display may be hidden
            # between timed cues even when its subtitle decoder is active.
            if window is None or getattr(window, "instance", True) is None:
                accepted = False
        if not accepted:
            if subtitle is not None:
                print("[TiviMateE2] native subtitle track not ready/visible: %r" % (subtitle,))
            return False

        return True

    # ------------------------------------------------------------------
    # TiviMate subtitle feature layer
    # ------------------------------------------------------------------
    def openSubsSupport(self):
        try:
            from .subtitle_picker_bridge import open_tivimate_subtitle_search
            title = _clean_title(self.item.get("name") or self.item.get("title") or self.item.get("stream_name") or "")
            if not open_tivimate_subtitle_search(self, title=title):
                stage = str(getattr(self, "_tivimate_subtitle_search_error", "") or "initialization")
                self._showNotification("Could not open TiviMate Subtitles (%s)" % stage,
                                       MessageBox.TYPE_ERROR, 5)
        except Exception as exc:
            self._showNotification("Subtitle error: %s" % exc, MessageBox.TYPE_ERROR, 5)

    def _subtitlePickerSource(self):
        """Use the active downloaded file or active SubsSupport engine for RED."""
        from .subtitle_cue_source import get_active_subtitle_rows
        return get_active_subtitle_rows(self)

    def openSubtitleEditor(self):
        """RED: open the large subtitle-line screen at the current movie time."""
        cues, subtitle_list = self._subtitlePickerSource()
        if not subtitle_list:
            self._showNotification("No readable subtitle is loaded", MessageBox.TYPE_INFO, 3)
            return
        self._subtitle_picker_cues = cues

        current_index = 0
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek and seek.getPlayPosition()
            if position and not position[0]:
                playback_ms = max(0, int(position[1] or 0) // 90)
                delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
                subtitle_time_ms = max(0, playback_ms - delay_ms)
                current_index = len(cues) - 1
                for cue_index, cue in enumerate(cues):
                    cue_start_ms = int(cue[0])
                    if cue_start_ms >= subtitle_time_ms:
                        current_index = cue_index
                        if cue_index > 0:
                            prev_ms = int(cues[cue_index - 1][0])
                            if abs(subtitle_time_ms - prev_ms) <= abs(cue_start_ms - subtitle_time_ms):
                                current_index = cue_index - 1
                        break
        except Exception:
            current_index = 0

        current_index = max(0, min(current_index, len(subtitle_list) - 1))
        try:
            from Plugins.Extensions.TiviMateE2Py27.subtitle_picker_original import SubtitlePicker
            self._openVODRaisedScreen(SubtitlePicker, self._subtitlePickerSelected,
                                       subtitle_list, current_index)
        except Exception as exc:
            print("[TiviMateE2] subtitle picker open failed: %s" % exc)
            self._showNotification("Could not open Subtitle Picker", MessageBox.TYPE_ERROR, 4)

    def _subtitlePickerSelected(self, selected=None):
        if selected is None:
            return
        fine_ms = 0
        if isinstance(selected, (tuple, list)) and len(selected) >= 2:
            try:
                fine_ms = int(selected[1] or 0)
            except Exception:
                fine_ms = 0
            selected = selected[0]
        try:
            index = int(selected)
        except Exception:
            return
        cues = list(getattr(self, "_subtitle_picker_cues", None) or [])
        if index < 0 or index >= len(cues):
            return
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek and seek.getPlayPosition()
            if not position or position[0]:
                return
            playback_ms = max(0, int(position[1] or 0) // 90)
            cue_start_ms = int(cues[index][0])
            delay_ms = playback_ms - cue_start_ms + fine_ms
            delay_ms = max(-120000, min(120000, delay_ms))
            controller = (getattr(self, "_external_subs", None) or
                          getattr(self, "_tivimate_subtitles", None) or
                          getattr(self, "_subssupport", None) or
                          getattr(self, "_tivimate_subtitle_controller", None))
            if controller is None:
                return
            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if callable(setter):
                setter(delay_ms)
            self._subtitle_session_delay_ms = delay_ms
            sync = getattr(controller, "playAfterSeek", None)
            if callable(sync):
                sync()
            self._savePreferences()
            self._showNotification("Subtitle synchronized: %+.1f sec" % (delay_ms / 1000.0), MessageBox.TYPE_INFO, 2)
        except Exception:
            pass

    def _stepSubtitleDialogue(self, direction):
        """VOD: align playback to the previous/next cue using one fixed delay."""
        controller = (getattr(self, "_external_subs", None) or
                      getattr(self, "_tivimate_subtitles", None) or
                      getattr(self, "_tivimate_subtitle_controller", None) or
                      getattr(self, "_subssupport", None))
        if controller is None:
            return
        try:
            cues, _rows = self._subtitlePickerSource()
            if not cues:
                return

            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            position = seek and seek.getPlayPosition()
            if not position or position[0]:
                return
            playback_ms = max(0, int(position[1] or 0) // 90)

            # Convert the current movie position to subtitle-timeline time using
            # the one currently active delay.  This avoids relying on the
            # subtitle engine's moving internal position/timers when stepping.
            current_delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
            getter = getattr(controller, "getSubsDelay", None)
            if callable(getter):
                try:
                    active_delay = getter()
                    if active_delay is not None:
                        current_delay_ms = int(round(float(active_delay)))
                except Exception:
                    pass
            subtitle_time_ms = playback_ms - current_delay_ms

            # Find the cue that corresponds most closely to the current
            # subtitle time, then select exactly one previous/next cue.
            current_index = 0
            for idx, cue in enumerate(cues):
                cue_start = int(cue[0])
                cue_end = int(cue[1]) if len(cue) > 1 else cue_start
                if cue_start <= subtitle_time_ms <= cue_end:
                    current_index = idx
                    break
                if cue_start <= subtitle_time_ms:
                    current_index = idx
                elif cue_start > subtitle_time_ms:
                    if idx > 0:
                        prev_start = int(cues[idx - 1][0])
                        if abs(cue_start - subtitle_time_ms) < abs(subtitle_time_ms - prev_start):
                            current_index = idx
                    break

            target_index = current_index + (-1 if int(direction) < 0 else 1)
            target_index = max(0, min(target_index, len(cues) - 1))
            if target_index == current_index:
                return

            target_start_ms = int(cues[target_index][0])
            new_delay_ms = playback_ms - target_start_ms
            new_delay_ms = max(-120000, min(120000, new_delay_ms))

            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if not callable(setter):
                return

            # Replace the previous value once.  Do not subscribe a callback and
            # do not call playAfterSeek here: both can cause the same adjustment
            # to be recalculated later.  The subtitle engine resumes from this
            # single absolute delay and the movie preference stores that value.
            setter(new_delay_ms)
            self._subtitle_session_delay_ms = new_delay_ms
            self._savePreferences()
        except Exception as exc:
            print("[TiviMateE2] VOD fixed subtitle dialogue step failed: %s" % exc)

    def subtitleFineMinus(self):
        self._stepSubtitleDialogue(-1)

    def subtitleFinePlus(self):
        self._stepSubtitleDialogue(1)

    def _activateVtiSRT(self, path):
        """Use the player's native Label for a real, readable SRT file.

        This cannot report success for an unparseable or empty subtitle. The
        provider/ASS/SSA paths remain under the original SubsSupport engine.
        """
        try:
            if not path or os.path.splitext(path)[1].lower() not in ('.srt', '.txt'):
                return False
            from .srt_overlay import parse_srt_file
            cues = parse_srt_file(path)
            if not cues:
                _vti_subtitle_diag('SRT_EMPTY_OR_INVALID')
                return False
            # A server/embedded subtitle must not paint over the downloaded
            # SRT caption in the independent native renderer.
            try:
                self.enableSubtitle(None)
            except Exception:
                pass
            previous = getattr(self, '_external_subs', None)
            if previous:
                try:
                    previous.pauseSubs()
                except Exception:
                    pass
                try:
                    previous.hideSubsDialog()
                except Exception:
                    pass
            self._clearSRTOverlay()
            direct = _VTiInPlayerSRT(self, path, cues)
            self._external_subs = direct
            self._external_subtitle_path = path
            self._external_subtitle_owner = 'vti_srt'
            self._subtitle_restore_attempted = True
            _vti_subtitle_diag('SRT_DIRECT_ACTIVATED', 'CUES_%d' % len(cues))
            return True
        except Exception as exc:
            _vti_subtitle_diag('SRT_DIRECT_ERROR', type(exc).__name__)
            return False

    def _clearSRTOverlay(self):
        try:
            self["srtOverlay"].setText("")
            self["srtOverlay"].hide()
        except Exception:
            pass

    def _tivimateSubtitleDelayChanged(self, delay_ms):
        try:
            value = int(delay_ms)
        except Exception:
            return
        if abs(value) <= 120000:
            self._subtitle_session_delay_ms = value
            self._savePreferences()

    def _forgetSavedExternalSubtitle(self):
        """Do not reload the downloaded subtitle next time for this item."""
        try:
            db = self._prefsDb()
            row = dict(db.get(self._identity) or {})
            if row.pop("external_subtitle_path", None) is not None:
                row["subtitle_delay_ms"] = 0
                db[self._identity] = row
                _write_json(PLAYER_PREFS_FILE, db)
            self._subtitle_session_delay_ms = 0
            self._subtitle_restore_attempted = True
        except Exception:
            pass

    def _clearExternalSubtitle(self):
        # Remember the active temporary file until the renderer has been stopped.
        _old_sub = getattr(self, "_external_subtitle_path", "") or ""
        seen = set()
        for obj in (self._external_subs, getattr(self, "_subssupport", None),
                    self._tivimate_subtitles, self._tivimate_subtitle_controller):
            if obj is None or id(obj) in seen:
                continue
            seen.add(id(obj))
            for method in ("pauseSubs", "hideSubs", "resetSubs"):
                try:
                    func = getattr(obj, method, None)
                    if callable(func):
                        func()
                except Exception:
                    pass
            # TiviMateSubtitleSupport is owned by the player bridge rather than
            # by the Screen itself, so Enigma2 will not call exitSubs() for us.
            # Finish the controller lifecycle explicitly before dropping the
            # references; this releases the SubsEngine, renderer dialog and
            # subtitle timers left behind by the previous movie/episode.
            try:
                func = getattr(obj, "exitSubs", None)
                if callable(func):
                    func()
            except Exception as exc:
                print("[TiviMateE2] external subtitle exit cleanup failed: %s" % exc)
        self._external_subs = None
        self._subssupport = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._external_subtitle_owner = ""
        self._clearSRTOverlay()
        # Only cleanup this player's temporary download, and do not remove
        # files outside the private /tmp working directory.
        try:
            _root = os.path.realpath("/tmp/tivimatee2-subtitles") + os.sep
            _path = os.path.realpath(_old_sub) if _old_sub else ""
            if _path.startswith(_root) and os.path.isfile(_path):
                os.remove(_path)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Service type handling
    # ------------------------------------------------------------------
    def cycleStreamTypeQuick(self):
        """Cycle Service Type directly from the dedicated TV key without opening a menu."""
        available = [int(item[0]) for item in _available_stream_types()]
        if not available:
            return
        try:
            current = int(self.servicetype)
        except Exception:
            current = available[0]
        try:
            index = available.index(current)
            target = available[(index + 1) % len(available)]
        except ValueError:
            target = available[0]
        # Quick TV-key cycling is session-only: do not persist it as the player default.
        self._switchPlaybackEngine(target, persist_choice=False)

    def toggleStreamType(self):
        choices = []
        for service_type, name in _available_stream_types():
            choices.append(("%s  •  %s" % (service_type, name), service_type))
        return self._openVODOptions('SERVICE TYPE', choices, self._engineSelected)

    def _engineSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        # A deliberate selection from the Service Type menu is the persistent/manual choice.
        self._switchPlaybackEngine(selected[1], persist_choice=True)

    def _switchPlaybackEngine(self, value, persist_choice=False):
        try:
            value = int(value)
        except Exception:
            return
        if value not in [item[0] for item in _available_stream_types()]:
            return
        if persist_choice:
            _save_player_type(value)
        if value == self.servicetype:
            return
        self._saveResume()
        self._savePreferences()
        self._clearExternalSubtitle()
        self.servicetype = value
        self.playStream()

    # ------------------------------------------------------------------
    # Player menu
    # ------------------------------------------------------------------
    def _raisePlayerPopup(self, dialog=None):
        """Only adjust a newly opened popup, never the working player HUD."""
        try:
            if dialog is None:
                dialog = getattr(self.session, 'current_dialog', None)
            if dialog is None or dialog is self:
                return
            window = getattr(dialog, 'instance', None)
            if window is not None and hasattr(window, 'setZPosition'):
                window.setZPosition(35)
        except Exception as exc:
            print('[TiviMateE2Py27] popup layering: %s' % exc)

    def _openVODOptions(self, title, options, callback):
        """Use the already-tested z=35 VOD modal for every simple submenu."""
        self.lockShow()
        try:
            dialog = _safe_open_screen(self.session, callback,
                                       _TiviMateVODOptions, options, title)
            if dialog is None:
                self.unlockShow()
                self._showNotification('Could not open %s' % title, timeout=4)
                return False
            return True
        except Exception as exc:
            self.unlockShow()
            self._showNotification('Menu error: %s' % type(exc).__name__, timeout=4)
            return False

    def _openVODRaisedScreen(self, screen_class, callback, *args):
        """Keep the original config/editor UI and logic, but draw above HUD.

        A screen-level skin override is set during construction, so VTi cannot
        substitute the lower-z skin after the screen has already opened.
        Callbacks release the HUD lock whether the screen is saved or canceled.
        """
        player = self
        class RaisedVODScreen(screen_class):
            def __init__(self, session, *screen_args, **screen_kwargs):
                screen_class.__init__(self, session, *screen_args, **screen_kwargs)
                _tivimate_raise_screen_skin(self, 35)

        def closeRaisedScreen(*result):
            player.unlockShow()
            if callable(callback):
                callback(*result)

        self.lockShow()
        dialog = _safe_open_screen(self.session, closeRaisedScreen,
                                   RaisedVODScreen, *args)
        if dialog is None:
            self.unlockShow()
            self._showNotification('Could not open %s' % screen_class.__name__, timeout=4)
            return False
        return True

    def openPlayerMenu(self):
        _vti_subtitle_diag('PLAYER_MENU_KEY')
        choices = [
            ("Subtitle Search", "subs"),
            ("Server Subtitles", "native_subs"),
            ("Audio Tracks / Language", "audio"),
            ("Edit Subtitle Timing", "subtitle_editor"),
            ("Subtitle Font & Style", "subtitle_style"),
            ("Subtitle Delay", "subtitle_delay"),
            ("Player Engine / Service Type", "engine"),
            ("Playback Buffer", "buffer"),
            ("Import Subtitle File", "subtitle_import"),
            ("Downloads Manager", "downloads"),
            ("Record / Download Current", "record"),
            ("Stop Recording", "stop_record"),
            ("Aspect Ratio", "aspect"),
        ]
        self.lockShow()
        try:
            dialog = self.session.openWithCallback(self._menuSelected,
                                                    _TiviMateVODOptions, choices)
            self._raisePlayerPopup(dialog)
            _vti_subtitle_diag('PLAYER_MENU_OPENED')
        except Exception as exc:
            self.unlockShow()
            _vti_subtitle_diag('PLAYER_MENU_FAILED', type(exc).__name__)
            self._showNotification('Player menu could not open: %s' % exc, timeout=5)

    def _menuSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        action = selected[1]
        if action == "subs":
            return self.openSubsSupport()
        if action == "native_subs":
            return self.openSubtitleSelection()
        if action == "audio":
            return self.audioSelection()
        if action == "subtitle_editor":
            return self.openSubtitleEditor()
        if action == "engine":
            return self.toggleStreamType()
        if action == "buffer":
            return self.openPlaybackBufferMenu()
        if action == "subtitle_style":
            return self.openSubtitleStyleSettings()
        if action == "subtitle_import":
            return self.openLocalSubtitleFile()
        if action == "subtitle_delay":
            return self.openSubtitleDelay()
        if action == "downloads":
            return self.openDownloadsManager()
        if action == "record":
            return self.startRecordingCurrent()
        if action == "stop_record":
            return self.stopRecordingCurrent()
        if action == "aspect":
            return self.nextAspectRatio()

    def openLocalSubtitleFile(self):
        """Import an existing subtitle file; do not change network search."""
        try:
            from .subtitle_local_picker import TiviMateLocalSubtitlePicker
            self._openVODRaisedScreen(TiviMateLocalSubtitlePicker, self._localSubtitleSelected)
        except Exception as exc:
            self._showNotification("Subtitle file picker unavailable: %s" % exc, timeout=5)

    def _localSubtitleSelected(self, path=None):
        if not path:
            return
        path = gui_text(path)
        if not os.path.isfile(path):
            self._showNotification("Subtitle file not found", timeout=4)
            return
        if os.path.splitext(path)[1].lower() not in (".srt", ".ass", ".ssa", ".sub", ".vtt", ".txt"):
            self._showNotification("Unsupported subtitle file", timeout=4)
            return
        try:
            from .subtitle_picker_bridge import _controller
            controller = _controller(self)
            try:
                self.enableSubtitle(None)
            except Exception:
                pass
            if not controller.activateSelectedSubs(path):
                raise RuntimeError("subtitle decoder rejected file")
            self._external_subs = controller
            self._subssupport = controller
            self._tivimate_subtitles = controller
            self._tivimate_subtitle_controller = controller
            self._external_subtitle_path = path
            self._external_subtitle_owner = "subssupport"
            self._subtitle_restore_attempted = True
            try:
                controller._tivimateDelayChangedCB = self._tivimateSubtitleDelayChanged
                if self._subtitle_session_delay_ms:
                    setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                    if callable(setter):
                        setter(self._subtitle_session_delay_ms)
            except Exception:
                pass
            try:
                controller.playAfterSeek()
            except Exception:
                pass
            self._savePreferences()
            self._showNotification("Subtitle imported: %s" % os.path.basename(path), timeout=4)
        except Exception as exc:
            self._showNotification("Subtitle import failed: %s" % exc, timeout=6)

    def openSubtitleStyleSettings(self):
        try:
            from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings, TiviMateSetupExternal
            settings = initTiviMateSettings()
            self._openVODRaisedScreen(TiviMateSetupExternal, self._unifiedSubtitleStyleSaved,
                                       settings.external)
        except Exception as exc:
            self._showNotification("Subtitle style unavailable: %s" % exc, MessageBox.TYPE_ERROR, 5)

    def _unifiedSubtitleStyleSaved(self, *args):
        """Apply one CC Font profile to external + server/embedded subtitles."""
        try:
            from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings
            settings = initTiviMateSettings()
            ext = settings.external
            emb = settings.embedded

            # Font face (regular / italic / bold), size and vertical position.
            for style in ("regular", "italic", "bold"):
                try:
                    getattr(emb.font, style).type.value = getattr(ext.font, style).type.value
                    getattr(emb.font, style).type.save()
                except Exception:
                    pass
            try:
                emb.font.size.value = ext.font.size.value
                emb.font.size.save()
            except Exception:
                pass
            try:
                emb.position.value = ext.position.value
                emb.position.save()
            except Exception:
                pass

            # Native/embedded renderer has one foreground + border/shadow set;
            # use the regular CC color as its common default.
            try:
                emb.color.value = ext.font.regular.color.value
                emb.color.save()
            except Exception:
                pass
            for name in ("color", "size", "xOffset", "yOffset"):
                try:
                    src = getattr(ext.shadow, name)
                    dst = getattr(emb.shadow, name)
                    dst.value = src.value
                    dst.save()
                except Exception:
                    pass

            # Keep Enigma2's own native size preference aligned as a fallback
            # on images where the custom embedded renderer is unavailable.
            try:
                from Components.config import config, configfile
                native_size = (getattr(getattr(config, "subtitles", None), "subtitle_fontsize", None) or
                               getattr(getattr(config, "subtitles", None), "subtitlefontsize", None))
                if native_size is not None:
                    native_size.value = int(ext.font.size.value)
                    native_size.save()
            except Exception:
                pass
            try:
                from Components.config import configfile
                configfile.save()
            except Exception:
                pass

            try:
                from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import applySubtitleFontAsReplacement
                applySubtitleFontAsReplacement(settings)
            except Exception as exc:
                print("[TiviMateE2] subtitle replacement font: %s" % exc)
            # Repaint the currently loaded external subtitle immediately.
            seen = set()
            for obj in (getattr(self, "_external_subs", None),
                        getattr(self, "_tivimate_subtitles", None),
                        getattr(self, "_tivimate_subtitle_controller", None)):
                if obj is None or id(obj) in seen:
                    continue
                seen.add(id(obj))
                try:
                    fn = getattr(obj, "reloadSubtitleStyle", None)
                    if callable(fn):
                        fn()
                except Exception:
                    pass

            # Rebuild/repaint active Server / Embedded subtitle using the same
            # profile, including the selected font face.
            if getattr(self, "_unified_embedded_ready", False):
                try:
                    self.resetEmbeddedSubs(True)
                    self.restartSubtitle()
                except Exception as exc:
                    print("[TiviMateE2] embedded CC style reload failed: %s" % exc)
        except Exception as exc:
            print("[TiviMateE2] unified CC style save failed: %s" % exc)

    def openSubtitleDelay(self):
        current = int(self._subtitle_session_delay_ms or 0)
        values = []
        for delay in range(-10000, 10001, 500):
            prefix = "✓ " if delay == current else ""
            values.append(("%s%+.1f sec" % (prefix, delay / 1000.0), delay))
        return self._openVODOptions('SUBTITLE DELAY', values, self._subtitleDelaySelected)

    def _subtitleDelaySelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        try:
            self._subtitle_session_delay_ms = int(selected[1])
        except Exception:
            return
        controller = self._external_subs or self._tivimate_subtitles or self._tivimate_subtitle_controller
        if controller is not None:
            try:
                func = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                if callable(func):
                    func(self._subtitle_session_delay_ms)
            except Exception:
                pass
        self._savePreferences()
        self._showNotification("Subtitle delay %+.1f sec" % (self._subtitle_session_delay_ms / 1000.0), MessageBox.TYPE_INFO, 3)

    def openDownloadsManager(self):
        try:
            from .download_manager import DownloadsManagerScreen
            self._openVODRaisedScreen(DownloadsManagerScreen, None)
        except Exception as exc:
            self._showNotification("Downloads unavailable: %s" % exc, MessageBox.TYPE_ERROR, 5)

    # ------------------------------------------------------------------
    # Recording / display
    # ------------------------------------------------------------------
    def startRecordingCurrent(self):
        if self._record_process is not None:
            self._showNotification("Recording already running", MessageBox.TYPE_INFO, 3)
            return
        folder = "/media/hdd/movie"
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except Exception:
                self._showNotification("HDD movie folder unavailable", MessageBox.TYPE_ERROR, 5)
                return
        title = re.sub(r"[^A-Za-z0-9._ -]+", "_", _clean_title(self.item.get("name") or self.item.get("title") or "TiviMate"))[:100]
        extension = os.path.splitext(self.streamurl.split("?", 1)[0])[1].lower()
        if extension not in (".ts", ".mp4", ".mkv", ".avi", ".mov"):
            extension = ".ts"
        output = os.path.join(folder, "%s-%s%s" % (title, time.strftime("%Y%m%d-%H%M%S"), extension))
        process = eConsoleAppContainer()
        self._record_process = process
        self._record_path = output
        if os.path.exists("/usr/bin/ffmpeg"):
            command = "/usr/bin/ffmpeg -y -loglevel error -i %s -c copy %s" % (repr(self.streamurl), repr(output))
        else:
            command = "/usr/bin/wget -c -O %s %s" % (repr(output), repr(self.streamurl))
        try:
            process.execute("/bin/sh", "sh", "-c", command)
            self._showNotification("Recording started", MessageBox.TYPE_INFO, 4)
        except Exception as exc:
            self._record_process = None
            self._showNotification("Recording failed: %s" % exc, MessageBox.TYPE_ERROR, 5)

    def stopRecordingCurrent(self):
        if self._record_process is None:
            self._showNotification("No recording running", MessageBox.TYPE_INFO, 3)
            return
        try:
            self._record_process.sendCtrlC()
        except Exception:
            try:
                self._record_process.kill()
            except Exception:
                pass
        self._record_process = None
        self._showNotification("Recording stopped", MessageBox.TYPE_INFO, 3)

    def nextAspectRatio(self, *args):
        self.ar_id_player += 1
        if self.ar_id_player > 6:
            self.ar_id_player = 0
        try:
            if eAVSwitch is not None:
                eAVSwitch.getInstance().setAspectRatio(self.ar_id_player)
            message = ASPECT_RATIOS.get(self.ar_id_player, "Auto")
        except Exception:
            message = "Aspect-ratio change failed"
        try:
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=1)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Episodes
    # ------------------------------------------------------------------
    def _episodeUrl(self, episode):
        source = self._episode_source or {}
        direct = text_type(episode.get('direct_source') or episode.get('stream_url') or episode.get('url') or u'').strip()
        try:
            kind = text_type(source.get('type') or u'').lower()
            if kind == 'stalker':
                from .core import StalkerClient
                result = StalkerClient(source).stream_url(episode, 'series') or direct
            elif direct.startswith((u'http://', u'https://')):
                result = direct
            elif kind in ('m3u', 'fg'):
                return ''
            else:
                from .core import XtreamClient
                result = XtreamClient(source).episode_url(episode)
            return native_episode_url_bytes(result) if result else ''
        except Exception:
            return ''

    def _playEpisodeIndex(self, index):
        if index < 0 or index >= len(self._episode_items):
            return
        next_episode_notice.hide(self)
        self._saveContinueWatching()
        self._saveResume()
        self._savePreferences()
        self._clearExternalSubtitle()
        episode = dict(self._episode_items[index] or {})
        if str((self._episode_source or {}).get("type") or "").lower() == "stalker":
            # Stalker link in the background: the picture keeps playing and
            # the remote keeps working while the portal answers.
            if getattr(self, "_episodeResolving", False):
                return
            self._episodeResolving = True
            try:
                self._showNotification("Loading episode...", MessageBox.TYPE_INFO, 3)
            except Exception:
                pass

            def done(url, index=index, episode=episode):
                self._episodeResolving = False
                if getattr(self, "_closing", False):
                    return
                self._startEpisodeIndex(index, episode, url)

            def failed(exc, index=index, episode=episode):
                self._episodeResolving = False
                if getattr(self, "_closing", False):
                    return
                direct = str(episode.get("url") or episode.get("stream_url") or "")
                self._startEpisodeIndex(index, episode, direct)
            from .bg_resolve import resolve_async
            resolve_async(lambda: self._episodeUrl(episode), done, failed)
            return
        self._startEpisodeIndex(index, episode, self._episodeUrl(episode))

    def _startEpisodeIndex(self, index, episode, url):
        if not url:
            self._showNotification("Episode URL unavailable", MessageBox.TYPE_ERROR, 4)
            return
        for key in ("series_name", "series_id", "_source_key", "_source_type", "_episode_items", "_episode_source"):
            if key in self.item and key not in episode:
                episode[key] = self.item[key]
        episode["_episode_items"] = list(self._episode_items)
        episode["_episode_index"] = index
        episode["_episode_source"] = dict(self._episode_source)
        next_episode_notice.reset(self)
        self.item = episode
        self._episode_index = index
        self.streamurl = native_episode_url_bytes(url)
        self._identity = _media_identity(self.item)
        self["titleLabel"].setText(gui_text(_clean_title(episode.get("name") or episode.get("title") or episode.get("series_name") or "Episode")))
        self.playStream()

    def nextEpisode(self):
        if self._episode_items:
            self._playEpisodeIndex(self._episode_index + 1)

    def prevEpisode(self):
        if self._episode_items:
            self._playEpisodeIndex(self._episode_index - 1)

    # ------------------------------------------------------------------
    # Exit / cleanup
    # ------------------------------------------------------------------
    def _stopTimers(self):
        next_episode_notice.destroy(self)
        for timer in (
            getattr(self, "_monitor_timer", None),
            getattr(self, "_startup_guard_timer", None),
            getattr(self, "_startup_exit_timer", None),
            getattr(self, "_fallback_timer", None),
            getattr(self, "_memory_guard_timer", None),
            getattr(self, "_checkpoint_timer", None),
            getattr(self, "_resume_timer", None),
            getattr(self, "_prefs_timer", None),
            getattr(self, "_notification_timer", None),
            getattr(self, "_hud_timer", None),
        ):
            try:
                if timer:
                    timer.stop()
            except Exception:
                pass

    def _restoreOriginalService(self):
        if self._restored_original_service:
            return
        self._restored_original_service = True
        # Ultra hard-stop principle: stop ONLY the stream this player owns.
        # If another screen already changed channel, do not stop its service.
        current_ref = None
        try:
            current = self.session.nav.getCurrentlyPlayingServiceReference()
            current_ref = current.toString() if current is not None else None
        except Exception:
            pass
        if (current_ref and self._owned_vod_ref and
                current_ref != self._owned_vod_ref):
            return
        try:
            self.session.nav.stopService()
        except Exception:
            # Native stop can fail on some images; don't kill arbitrary PIDs.
            pass
        if self.original_service:
            try:
                self.session.nav.playService(self.original_service)
            except Exception:
                pass

    def back(self):
        if self._closing:
            return
        if next_episode_notice.cancel_visible(self):
            return
        self._closing = True
        self._artwork_generation = int(getattr(self, "_artwork_generation", 0) or 0) + 1
        self._saveContinueWatching()
        self._saveResume()
        self._savePreferences()
        self._clearExternalSubtitle()
        self._stopTimers()
        self._stopPlaybackBuffer()
        # Restore the Enigma2 service that was active before TiviMate playback.
        # Example: if MBC was playing before opening a movie, Back/Exit returns
        # playback to MBC instead of leaving the IPTV/VOD service active.
        self._restoreOriginalService()
        try:
            self.close()
        except Exception:
            pass

    def _cleanup(self):
        try:
            self._artwork_generation = int(getattr(self, "_artwork_generation", 0) or 0) + 1
            self._stopPlaybackBuffer()
            if not self._closing:
                try:
                    self._saveContinueWatching()
                except Exception:
                    pass
            self._stopTimers()
            try:
                self._clearExternalSubtitle()
            except Exception:
                pass
            # If Enigma closed the screen externally, still restore the service once.
            if not self._restored_original_service:
                self._restoreOriginalService()

        finally:
            from .playback_priority import leave
            if leave(self):
                try:
                    from .artwork_queue import resume_after_vod
                    resume_after_vod()
                except Exception:
                    pass


TiviMatePlayer.skin = scale_skin(TiviMatePlayer.skin)
