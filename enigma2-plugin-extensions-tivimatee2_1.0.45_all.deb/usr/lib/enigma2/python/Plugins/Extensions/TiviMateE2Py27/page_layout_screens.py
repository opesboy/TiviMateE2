# -*- coding: utf-8 -*-
from __future__ import absolute_import
"""Four extra Movies / TV Shows page designs (PAGE DESIGN picker 05-08).

Each one reuses an existing, proven screen; only the opening source is marked
so that its MENU key shows the PAGE DESIGN picker (not the poster styles):

    royal   -> Royal Circles (circle_grid.CircleGridScreen, GENRE engine)
    circles -> Big circles   (MediaScreen, circle style)
    posters -> Big posters   (MediaScreen, large poster style)
    genre   -> GENRE poster  (genre_page.StandaloneGenreScreen)
"""

PAGE_FLAG = '_movies_page_layout'


def page_source(source, poster_style=None):
    """Copy of the server source opened as a Movies/TV Shows page."""
    data = dict(source or {})
    for key in ('_view_picker_context', '_view_style_override'):
        data.pop(key, None)
    data[PAGE_FLAG] = True
    if poster_style:
        data['_view_style_override'] = poster_style
    return data


def is_page_level(screen_or_source):
    """The root-page class marker survives GENRE's saved-server source reload.

    GENRE/Packages share the same poster screens but have no marker and must
    continue to show just their six poster views.
    """
    if getattr(screen_or_source, '_movies_page_root', False):
        return True
    source = (screen_or_source if isinstance(screen_or_source, dict)
              else getattr(screen_or_source, 'source', None))
    return bool(isinstance(source, dict) and source.get(PAGE_FLAG)
                and not source.get('_view_picker_context'))


def open_page_design_picker(screen):
    """MENU on one of these pages: PAGE DESIGN picker, then switch page."""
    from .movies_page_picker import MoviesPagePicker
    kind = 'series' if getattr(screen, 'kind', 'vod') == 'series' else 'vod'

    def chosen(choice=None):
        from .movies_layout_choice import PAGE_LAYOUTS, get_content_layout, save_content_layout, configured_movies_screen
        if choice not in PAGE_LAYOUTS or choice == get_content_layout(kind):
            return
        if not save_content_layout(kind, choice):
            return
        from .content_home import FastMoviesContentScreen
        target = configured_movies_screen(FastMoviesContentScreen, kind)
        source = dict(getattr(screen, 'source', {}) or {})
        for key in (PAGE_FLAG, '_view_style_override', '_view_picker_context'):
            source.pop(key, None)

        def returned(*_args):
            try:
                screen.close()
            except Exception:
                pass
        screen.session.openWithCallback(returned, target, source, kind)
    screen.session.openWithCallback(chosen, MoviesPagePicker, kind)


def handle_page_choice(screen, choice):
    """'page:new' / 'page:current' from the 8-design picker inside Packages
    or GENRE: save that Movies/TV Shows page design and open the page."""
    if not (isinstance(choice, str) and choice.startswith('page:')):
        return False
    layout = choice[5:]
    kind = 'series' if getattr(screen, 'kind', 'vod') == 'series' else 'vod'
    try:
        from .movies_layout_choice import save_content_layout, configured_movies_screen
        if save_content_layout(kind, layout):
            from .content_home import FastMoviesContentScreen
            target = configured_movies_screen(FastMoviesContentScreen, kind)
            source = dict(getattr(screen, 'source', {}) or {})
            for key in (PAGE_FLAG, '_view_style_override', '_view_picker_context',
                        '_genre_package_id', '_genre_package_kind', '_genre_badge_context'):
                source.pop(key, None)
            screen.session.open(target, source, kind)
    except Exception:
        pass
    return True


def _media_screen():
    from .ui import MediaScreen
    return MediaScreen


def _make_media_page(style):
    base = _media_screen()

    def __init__(self, session, source, kind='vod', *args, **kwargs):
        base.__init__(self, session, page_source(source, style), kind)
    # Same class name as the base screen: skin lookup and the existing
    # name checks (server switch, filter refresh) behave exactly the same.
    return type(base.__name__, (base,), {
        '__init__': __init__, '_movies_page_root': True})


_CACHE = {}
_ROOT_CACHE = {}


def root_page_screen(base):
    """Keep Movies/Series root mode for Apple and 24-grid pages as well.

    Their shared GENRE code may replace self.source with a saved server, so
    merely putting PAGE_FLAG in the source is not reliable.
    """
    if base in _ROOT_CACHE:
        return _ROOT_CACHE[base]
    def __init__(self, session, source, kind='vod', *args, **kwargs):
        base.__init__(self, session, page_source(source), kind, *args, **kwargs)
    cls = type(base.__name__, (base,), {
        '__init__': __init__, '_movies_page_root': True})
    _ROOT_CACHE[base] = cls
    return cls


def screen_for(layout):
    """Screen class for one of the four extra page designs (or None)."""
    if layout in _CACHE:
        return _CACHE[layout]
    cls = None
    if layout == 'royal':
        from .circle_grid import CircleGridScreen

        class MoviesRoyalCirclesPage(CircleGridScreen):
            _movies_page_root = True
            def __init__(self, session, source, kind='vod', *args, **kwargs):
                CircleGridScreen.__init__(self, session, page_source(source), kind)
        MoviesRoyalCirclesPage.__name__ = CircleGridScreen.__name__
        cls = MoviesRoyalCirclesPage
    elif layout == 'genre':
        from .genre_page import StandaloneGenreScreen

        class MoviesGenrePosterPage(StandaloneGenreScreen):
            _movies_page_root = True
            _GENRE_LIKE = True      # same pills / backdrop handling as GENRE Grid

            def __init__(self, session, source, kind='vod', *args, **kwargs):
                StandaloneGenreScreen.__init__(self, session, page_source(source), kind)
        MoviesGenrePosterPage.__name__ = StandaloneGenreScreen.__name__
        cls = MoviesGenrePosterPage
    elif layout == 'circles':
        cls = _make_media_page('circle')
    elif layout == 'posters':
        cls = _make_media_page('original')
    if cls is not None:
        _CACHE[layout] = cls
    return cls
