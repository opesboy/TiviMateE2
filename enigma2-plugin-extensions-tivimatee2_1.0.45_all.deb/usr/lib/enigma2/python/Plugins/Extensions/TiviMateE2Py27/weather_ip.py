# -*- coding: utf-8 -*-
"""Weather for the receiver's own location, found from its public IP.

Location comes from the first public IP lookup that answers (several free
providers, cached 12 h) and the temperature from Open-Meteo (no API key),
cached 30 minutes. If every service fails, the last good reading (up to 6 h)
is shown, and the reason is written to <cache>/weather/_error.log.
"""
from __future__ import absolute_import
import io
import json
import os
import threading
import time

from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen

from .cache_manager import get_cache_dir


def _get_json(url):
    response = urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2"}), timeout=TIMEOUT)
    try:
        raw = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    if isinstance(raw, bytes):
        raw = raw.decode("utf-8")
    return json.loads(raw)


GEO_URL = "https://ipapi.co/json/"
WEATHER_URL = ("https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s"
               "&current=temperature_2m,weather_code,is_day,relative_humidity_2m,wind_speed_10m")
# Several free location services: one is often rate-limited or blocked for
# a given ISP / VPN / shared IP. The first that answers with coordinates wins.
GEO_PROVIDERS = (
    ("ipapi.co", "https://ipapi.co/json/", "latitude", "longitude", "city", "country_name"),
    ("ipwho.is", "https://ipwho.is/", "latitude", "longitude", "city", "country"),
    ("freeipapi", "https://freeipapi.com/api/json", "latitude", "longitude", "cityName", "countryName"),
    # Plain HTTP fallback for receivers whose TLS/CA bundle is too old.
    ("ip-api.com", "http://ip-api.com/json/", "lat", "lon", "city", "country"),
)
WEATHER_URLS = (WEATHER_URL, WEATHER_URL.replace("https://", "http://", 1))
CACHE_SECONDS = 1800
GEO_CACHE_SECONDS = 12 * 3600      # location rarely changes; fewer geo requests
STALE_SECONDS = 6 * 3600           # show the last good reading if all fail
RETRY_AFTER_FAIL = 120
TIMEOUT = 6
_LOCK = threading.Lock()
_LAST_FAIL = [0.0]


def _folder():
    folder = get_cache_dir("weather")
    if not os.path.isdir(folder):
        os.makedirs(folder)
    return folder


def _cache_file():
    return os.path.join(_folder(), "current.json")


def _geo_file():
    return os.path.join(_folder(), "geo.json")


def _log(message):
    """Last weather failures, so a user can report WHY it is empty."""
    try:
        path = os.path.join(_folder(), "_error.log")
        lines = []
        if os.path.isfile(path):
            with io.open(path, "r", encoding="utf-8") as handle:
                lines = handle.read().splitlines()[-30:]
        lines.append(u"%s %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), message))
        with io.open(path, "w", encoding="utf-8") as handle:
            handle.write(u"\n".join(lines) + u"\n")
    except Exception:
        pass


def _load(path):
    try:
        with io.open(path, "r", encoding="utf-8") as handle:
            return json.loads(handle.read())
    except Exception:
        return None


def _save(path, data):
    try:
        payload = json.dumps(data)
        if not isinstance(payload, bytes):
            payload = payload.encode("utf-8")
        tmp = path + ".tmp"
        with io.open(tmp, "wb") as handle:
            handle.write(payload)
        os.rename(tmp, path)
    except Exception:
        pass


def _read_cache_data(max_age=CACHE_SECONDS):
    data = _load(_cache_file())
    try:
        if (isinstance(data, dict) and data.get("temp") is not None and
                time.time() - float(data.get("time", 0)) < max_age):
            return data
    except Exception:
        pass
    return None


def _read_cache():
    data = _read_cache_data()
    return (data or {}).get("text") or ""


def _number(value):
    try:
        number = float(value)
    except Exception:
        return None
    return number


def _locate():
    """{lat, lon, city, country} from the first working provider (cached)."""
    cached = _load(_geo_file())
    try:
        if (isinstance(cached, dict) and cached.get("lat") is not None and
                time.time() - float(cached.get("time", 0)) < GEO_CACHE_SECONDS):
            return cached
    except Exception:
        pass
    for name, url, lat_key, lon_key, city_key, country_key in GEO_PROVIDERS:
        try:
            geo = _get_json(url)
            if not isinstance(geo, dict):
                raise ValueError("not JSON object")
            lat, lon = _number(geo.get(lat_key)), _number(geo.get(lon_key))
            if lat is None or lon is None:
                reason = geo.get("reason") or geo.get("message") or geo.get("status") or "no coordinates"
                raise ValueError(reason)
            result = {"time": time.time(), "lat": lat, "lon": lon, "provider": name,
                      "city": geo.get(city_key) or u"", "country": geo.get(country_key) or u""}
            _save(_geo_file(), result)
            return result
        except Exception as error:
            _log(u"geo %s failed: %r" % (name, error))
    # Every provider failed: an older location is still better than nothing.
    if isinstance(cached, dict) and cached.get("lat") is not None:
        return cached
    return None


def _current(lat, lon):
    for url in WEATHER_URLS:
        try:
            cur = (_get_json(url % (lat, lon)) or {}).get("current") or {}
            if cur.get("temperature_2m") is not None:
                return cur
            raise ValueError("no temperature in answer")
        except Exception as error:
            _log(u"weather %s failed: %r" % (url.split("/")[2] + (" (http)" if url.startswith("http:") else ""), error))
    return None


_CONDITIONS = (
    ((0,), "clear", "Clear"), ((1,), "clear", "Mostly clear"), ((2,), "partly", "Partly cloudy"),
    ((3,), "cloudy", "Cloudy"), ((45, 48), "fog", "Fog"),
    ((51, 53, 55, 56, 57), "drizzle", "Drizzle"),
    ((61, 63, 65, 66, 67, 80, 81, 82), "rain", "Rain"),
    ((71, 73, 75, 77, 85, 86), "snow", "Snow"), ((95, 96, 99), "storm", "Thunderstorm"))


def _condition(code, is_day):
    for codes, icon, label in _CONDITIONS:
        if code in codes:
            if icon in ("clear", "partly"):
                icon += "_day" if is_day else "_night"
            return icon, label
    return ("partly_day" if is_day else "partly_night"), "Weather"


def fetch_weather():
    """Return {city, country, temp, icon, label, humidity, wind} or None."""
    with _LOCK:
        cached = _read_cache_data()
        if cached:
            return cached
        stale = _read_cache_data(STALE_SECONDS)
        if time.time() - _LAST_FAIL[0] < RETRY_AFTER_FAIL:
            return stale
        try:
            geo = _locate()
            if not geo:
                _LAST_FAIL[0] = time.time()
                return stale
            cur = _current(geo["lat"], geo["lon"])
            if not cur:
                _LAST_FAIL[0] = time.time()
                return stale
            temp = int(round(float(cur["temperature_2m"])))
            icon, label = _condition(int(cur.get("weather_code") or 0), bool(cur.get("is_day", 1)))
            city, country = geo.get("city") or u"", geo.get("country") or u""
            place = u", ".join(p for p in (city, country) if p)
            data = {"time": time.time(), "city": city, "country": country,
                    "temp": temp, "icon": icon, "label": label,
                    "humidity": cur.get("relative_humidity_2m"), "wind": cur.get("wind_speed_10m"),
                    "text": u"%s: %d°C" % (place or u"Weather", temp)}
            _save(_cache_file(), data)
            return data
        except Exception as error:
            _log(u"unexpected: %r" % (error,))
            _LAST_FAIL[0] = time.time()
            return stale


def fetch_weather_text():
    data = fetch_weather()
    return (data or {}).get("text") or ""


