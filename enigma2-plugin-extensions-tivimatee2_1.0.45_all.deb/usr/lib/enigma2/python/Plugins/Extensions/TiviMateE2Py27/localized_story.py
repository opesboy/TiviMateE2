# -*- coding: utf-8 -*-
"""App-language movie synopsis for Saga, Other Sources and Actor Spotlight.

This changes only the selected synopsis. The GENRE artwork/download/cache queues
and the separately configured TMDb language are intentionally untouched.
"""
import re
import threading

try:
    from .py27_futures import ThreadPoolExecutor
except ImportError:
    from concurrent.futures import ThreadPoolExecutor

from .i18n import get_language
from .tmdb_client import TMDbClient
from .cache_manager import stable_cache_key, persistent_cache_get, persistent_cache_set

_STORY_POOL = ThreadPoolExecutor(max_workers=2)
from .i18n import TMDB_LOCALES as _LANGUAGES  # every app language


def current_locale():
    try:
        return _LANGUAGES.get(str(get_language() or 'en').lower()[:2], 'en-US')
    except Exception:
        return 'en-US'


def _text(value):
    try:
        from .py27_compat import text_type
        return text_type(value or u'').strip()
    except Exception:
        try:
            return str(value or '').strip()
        except Exception:
            return u''


def _id(value):
    value = _text(value)
    try:
        return str(int(value)) if int(value) > 0 else ''
    except Exception:
        return ''


def _valid_overview(overview, locale):
    overview = _text(overview)
    if not overview:
        return False
    if locale.startswith('ar'):
        # TMDb sometimes leaves an English overview when the Arabic region is
        # requested. Accept only actual Arabic text for the Arabic first pass.
        return any(u'\u0600' <= ch <= u'\u06ff' for ch in overview)
    return True


def _release_year(row):
    if not isinstance(row, dict):
        return ''
    for key in ('_part_year', 'year', 'release_date', 'first_air_date'):
        match = re.search(r'(?:19|20)\d{2}', _text(row.get(key)))
        if match:
            return match.group(0)
    return ''


def load_story(kind, movie_id, title, year, locale, original=''):
    """Returns an app-localized story, or English if unavailable.

    TMDb.details_bundle uses the existing media-ID + locale disk cache. The
    separate short story cache avoids searching the same title on repeat views.
    Network calls happen only in the executor, never inside an Enigma widget.
    """
    kind = 'series' if kind == 'series' else 'vod'
    locale = locale if locale in _LANGUAGES.values() else 'en-US'
    movie_id = _id(movie_id)
    title = _text(title)
    year = _text(year)[:4]
    cache_key = stable_cache_key('spotlight_saga_story_v2', kind, movie_id, title.lower() if not movie_id else '', year, locale)
    try:
        cached = persistent_cache_get(cache_key)
        if isinstance(cached, dict) and cached.get('text') and cached.get('locale') == locale:
            return _text(cached['text'])
    except Exception:
        pass
    try:
        client = TMDbClient(language=locale)
        if not movie_id and title:
            result = client.search_artwork(title, kind, year or None) or {}
            movie_id = _id(result.get('id')) if isinstance(result, dict) else ''
        if not movie_id:
            return _text(original)
        local_details = client.details_bundle(movie_id, kind) or {}
        if kind == 'vod' and year and local_details:
            found_year = _release_year(local_details)
            if found_year and found_year != year:
                # Stalker portal media IDs are not always TMDb IDs. Do not
                # display the plot of another film just because IDs collide.
                result = client.search_artwork(title, kind, year) if title else {}
                new_id = _id(result.get('id')) if isinstance(result, dict) else ''
                if new_id and new_id != movie_id:
                    movie_id = new_id
                    local_details = client.details_bundle(movie_id, kind) or {}
                else:
                    return _text(original)
        local_text = _text(local_details.get('overview'))
        if _valid_overview(local_text, locale):
            output = local_text
        elif locale != 'en-US':
            english = TMDbClient(language='en-US').details_bundle(movie_id, kind) or {}
            output = _text(english.get('overview')) or _text(original)
        else:
            output = local_text or _text(original)
        if output:
            try:
                persistent_cache_set(cache_key, 'story_language', {'text': output, 'locale': locale}, 24 * 3600)
            except Exception:
                pass
        return output
    except Exception:
        return _text(original)


class LocalizedStoryMixin(object):
    """Keep a scoped synopsis stable across late provider/TMDb callbacks."""
    def _story_prepare(self, item, kind=None, verified_id=None, limit=250):
        if getattr(self, '_closed', True) or not isinstance(item, dict):
            return
        try:
            from enigma import eTimer
        except Exception:
            return
        kind = kind or getattr(self, 'kind', 'vod')
        locale = current_locale()
        media_id = _id(verified_id or item.get('_locked_tmdb_id') or
                       item.get('tmdb_id') or item.get('tmdb') or item.get('tmdbId'))
        title = _text(item.get('_part_title') or item.get('name') or item.get('title'))
        year = _release_year(item)
        token = getattr(self, '_hero_token', None)
        if not title and not media_id:
            return
        key = (token, kind, media_id, title, year, locale)
        if key == getattr(self, '_story_key', None):
            self._story_reapply()
            return
        self._story_key = key
        self._story_value = None
        self._story_limit = limit
        self._story_requested = False
        self._story_item = dict(item)
        cache = getattr(self, '_story_screen_cache', None)
        if cache is None:
            self._story_screen_cache = cache = {}
        remembered = cache.get((kind, media_id, title, year, locale))
        if remembered:
            self._story_value = remembered
            self._story_reapply()
            return
        if not hasattr(self, '_story_timer'):
            timer = self._story_timer = eTimer()
            timer.callback.append(self._story_launch)
            self.onClose.append(timer.stop)
        self._story_timer.stop()
        self._story_timer.start(280, True)

    def _story_launch(self):
        key = getattr(self, '_story_key', None)
        if not key or getattr(self, '_closed', True) or self._story_requested:
            return
        self._story_requested = True
        token, kind, movie_id, title, year, locale = key
        row = dict(getattr(self, '_story_item', {}) or {})
        original = _text(row.get('plot') or row.get('description') or row.get('overview') or '')
        def worker():
            value = load_story(kind, movie_id, title, year, locale, original)
            if not getattr(self, '_closed', True):
                try:
                    self._post_to_gui(self._story_deliver, key, value)
                except Exception:
                    pass
        try:
            _STORY_POOL.submit(worker)
        except Exception:
            self._story_requested = False

    def _story_deliver(self, key, value):
        if (getattr(self, '_closed', True) or key != getattr(self, '_story_key', None)
                or key[0] != getattr(self, '_hero_token', None)
                or key[-1] != current_locale()):
            return
        self._story_value = _text(value)
        if self._story_value:
            cache = self._story_screen_cache
            if len(cache) > 96:
                cache.clear()
            cache[(key[1], key[2], key[3], key[4], key[5])] = self._story_value
        self._story_reapply()

    def _story_reapply(self):
        key = getattr(self, '_story_key', None)
        value = getattr(self, '_story_value', None)
        if (key and value and key[0] == getattr(self, '_hero_token', None)
                and key[-1] == current_locale() and not getattr(self, '_closed', True)):
            try:
                # Keep each page's approved synopsis length and its labels.
                limit = getattr(self, '_story_limit', 250)
                text = u' '.join(_text(value).split())
                if len(text) > limit:
                    text = text[:limit].rstrip() + u'…'
                self['heroPlot'].setText(text)
            except Exception:
                pass
