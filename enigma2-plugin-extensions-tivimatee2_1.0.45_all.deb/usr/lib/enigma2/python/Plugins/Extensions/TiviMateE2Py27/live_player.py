# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import monotonic, thread_factory, text_type, gui_text
from .storage import get_data_root, data_path
import os, threading, time, json, re, base64

from Components.ActionMap import ActionMap
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from .vti_compat import safe_open_screen as _safe_open_screen
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from .pixmap_progress import PixmapProgress
from Components.ServiceEventTracker import InfoBarBase, ServiceEventTracker
from .vti_compat import VTiTextStaticText as StaticText  # Python2/VTi renderer needs UTF-8 bytes
from enigma import eTimer, ePicLoad, iPlayableService, iServiceInformation
from .alpha_picload import ePicLoad  # same PNG-alpha renderer as Python 3
# VTi legacy images may not export this cosmetic spinner switch.
try:
    from enigma import setSpinnerOnOff
except (ImportError, AttributeError):
    def setSpinnerOnOff(_enabled):
        return None
from .live_service import live_reference
from .service_compat import serviceapp_backend_available, compatible_service_type
from .ultra_live_decoder import UltraLiveDecoderGuard
from .stalker_live_pool import live_playback_client, invalidate_live_playback_client
from .stalker_vti_diag import note as _stalker_note, url_kind as _stalker_url_kind
from .live_epg_bridge import cached as _shared_live_epg_cached, remember as _shared_live_epg_remember, select_stalker_now_next as _shared_stalker_now_next, wait_for_visible_result as _shared_epg_wait
from .live_epg_handoff import read_handoff as _read_live_epg_handoff
from .ultra_epg_selection import epg_title as _ultra_epg_title
from .xtream_epg_normalizer import decode_xtream_epg_text as _decode_xtream_title, epg_row_title as _epg_row_title
from .epg_local import lookup_channel_epg, load_source_epg, epg_json_path
from .artwork_queue import request_artwork, cached_artwork
from .live_infobar_pill import prepare_pill_image
from .live_sports_artwork import classify_football, resolve_football_art, _log_sports
from .tmdb_client import TMDbClient
from .estalker_picon import direct_picon, resolve_picon_url
from .display_scale import scale_skin, scale_size
from .i18n import tr, tr_text
from Screens.ChoiceBox import ChoiceBox
from Plugins.Extensions.TiviMateE2Py27.py27_compat import wrap_choicebox as _wrap_choicebox
ChoiceBox = _wrap_choicebox(ChoiceBox)
from Screens.InfoBarGenerics import InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSummarySupport
from Screens.MessageBox import MessageBox
from .recording_manager import stalker_live_recorder
from Screens.Screen import Screen

try:
    from .core import XtreamClient, M3UClient, StalkerClient, get_source_client, cached_image, stalker_log, load_stalker_compat, save_stalker_compat
    from .stalker_task_handle import TaskHandle
    from .stalker_live_pool import STALKER_LIVE_EXECUTOR
except Exception as _source_import_error:
    _stalker_note('CORE_IMPORT_FAILED', error=type(_source_import_error).__name__)
    XtreamClient = M3UClient = StalkerClient = get_source_client = None
    TaskHandle = None
    STALKER_LIVE_EXECUTOR = None
    cached_image = None
    def load_stalker_compat(portal, mac): return {}
    def save_stalker_compat(portal, mac, **values): return {}
    def stalker_log(message):
        pass


# Bounded startup checks: a dead server/stream must not leave Enigma2
# opening indefinitely. These timers run on the GUI thread but do no I/O.
from .ultra_stalker_engine.core.executor import LazyThreadPoolExecutor
_INFOBAR_ART_EXECUTOR = LazyThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviInfobarArt")

LIVE_RESOLVE_TIMEOUT_SECONDS = 11
LIVE_STARTUP_TIMEOUT_SECONDS = 16
LIVE_STALKER_STARTUP_TIMEOUT_SECONDS = 12

PLAYER_CONFIG = data_path("player.json")
# Kept only as a read fallback for installations that used the earlier live-only setting.
LIVE_SETTINGS_FILE = data_path("channel_settings.json")

# Shared Live programme-poster index.  The Live list already consumes this
# file; the full-screen infobar now feeds it as soon as it resolves a poster.
LIVE_POSTER_INDEX_FILE = data_path("live_poster_index.json")
LIVE_INFOBAR_BACKDROP_INDEX_FILE = data_path("live_infobar_backdrops.json")


def _live_diag_safe_icon(value):
    """Return non-sensitive picon diagnostics (never credentials/query strings)."""
    raw = str(value or "").strip().replace("\\/", "/")
    if not raw:
        return "empty"
    try:
        clean = raw.split("?", 1)[0]
        # Do not persist usernames/passwords that some panels embed in paths.
        clean = re.sub(r"(?i)(username|password|user|pass)[=/][^/&]+", r"\1=<redacted>", clean)
        parts = clean.split("/")
        tail = "/".join(parts[-2:]) if len(parts) >= 2 else clean
        host = ""
        if "://" in clean:
            host = clean.split("://", 1)[1].split("/", 1)[0]
        return "present len=%d host=%s tail=%s" % (len(raw), host or "-", tail[-120:])
    except Exception:
        return "present len=%d" % len(raw)

def _live_diag_log(source, item, stage, **values):
    return None

def _remember_infobar_live_poster(title, url):
    key = re.sub(r"\s+", " ", text_type(title or "").strip().lower())
    url = str(url or "").strip()
    if not key or not url:
        return
    data = {}
    try:
        with open(LIVE_POSTER_INDEX_FILE, "r") as handle:
            raw = json.load(handle) or {}
        if isinstance(raw, dict):
            data = {text_type(k): text_type(v) for k, v in raw.items() if k and v}
    except Exception:
        pass
    if data.get(key) == url:
        return
    data[key] = url
    if len(data) > 1200:
        for old_key in list(data.keys())[:len(data) - 1000]:
            data.pop(old_key, None)
    try:
        folder = os.path.dirname(LIVE_POSTER_INDEX_FILE)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = LIVE_POSTER_INDEX_FILE + ".tmp"
        with open(tmp, "w") as handle:
            json.dump(data, handle, ensure_ascii=True, separators=(",", ":"))
        os.rename(tmp, LIVE_POSTER_INDEX_FILE)
    except Exception:
        pass


def _load_live_infobar_backdrops():
    try:
        with open(LIVE_INFOBAR_BACKDROP_INDEX_FILE, "r") as handle:
            value = json.load(handle)
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    return {}


def _remember_live_infobar_backdrop(title, url):
    key = re.sub(r"\s+", " ", text_type(title or "").strip().lower())
    url = str(url or "").strip()
    if not key or not url:
        return
    rows = _load_live_infobar_backdrops()
    if rows.get(key) == url:
        return
    rows[key] = url
    if len(rows) > 1200:
        for old in list(rows)[:len(rows)-1000]:
            rows.pop(old, None)
    tmp = LIVE_INFOBAR_BACKDROP_INDEX_FILE + ".tmp"
    try:
        with open(tmp, "w") as handle:
            json.dump(rows, handle, separators=(",", ":"))
        os.rename(tmp, LIVE_INFOBAR_BACKDROP_INDEX_FILE)
    except Exception:
        pass


STALKER_SERVICE_TYPES_FILE = data_path("stalker_service_types.json")

def _stalker_source_key(source):
    source = source or {}
    return "%s|%s" % (source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _load_stalker_live_service_type(source, fallback):
    if (source or {}).get("type") != "stalker":
        return fallback
    try:
        with open(STALKER_SERVICE_TYPES_FILE, "r") as handle:
            raw = json.load(handle) or {}
        value = int((raw.get(_stalker_source_key(source), {}) or {}).get("live", fallback))
        if value in (1, 4097, 5001, 5002):
            return value
    except Exception:
        pass
    return fallback


def _stalker_compat(source):
    source = source or {}
    return load_stalker_compat(source.get("portal") or source.get("url") or "", source.get("mac") or "")

def _save_stalker_engine(source, value):
    source = source or {}
    return save_stalker_compat(source.get("portal") or source.get("url") or "", source.get("mac") or "", live_engine=int(value))

def _available_service_types():
    values = [(4097, "GStreamer 4097 (default)")]
    if serviceapp_backend_available(5001):
        values.append((5001, "GstPlayer 5001"))
    else:
        values.append((5001, "GstPlayer 5001 (requires ServiceApp)"))
    if serviceapp_backend_available(5002):
        values.append((5002, "ExtePlayer3 5002"))
    return values

def _load_service_type():
    available = [value for value, _label in _available_service_types()]
    for path in (PLAYER_CONFIG, LIVE_SETTINGS_FILE):
        try:
            import json
            with open(path, "r") as handle:
                value = int((json.load(handle) or {}).get("service_type", 4097))
            if value in available:
                return value
        except Exception:
            pass
    return available[0] if available else 4097

def _save_service_type(value):
    try:
        import json
        folder = os.path.dirname(PLAYER_CONFIG)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = PLAYER_CONFIG + ".tmp"
        with open(tmp, "w") as handle:
            json.dump({"service_type": int(value)}, handle)
        os.rename(tmp, PLAYER_CONFIG)
    except Exception:
        pass


def _reminder_u(value):
    if isinstance(value, str):
        return value.decode("utf-8", "replace")
    return text_type(value if value is not None else u"")

class LiveInfoBarShowHide(object):
    STATE_HIDDEN = 0
    STATE_SHOWN = 1

    def __init__(self):
        self._ib_state = self.STATE_SHOWN
        self._hud_lock = 0
        self._ib_closed = False
        self._ib_manual_hidden = False
        self._ib_hide_deadline = 0.0
        self._ib_timer = eTimer()
        try:
            self._ib_timer_connection = self._ib_timer.timeout.connect(self._hideInfobar)
        except Exception:
            self._ib_timer.callback.append(self._hideInfobar)
        # Ultra's infobar-show handler does not perform synchronous metadata
        # work. Keep the visible OSD path paint-only; reuse a one-shot GUI
        # timer for EPG refresh after the requested channel is playing.
        self._ib_epg_timer = eTimer()
        try:
            self._ib_epg_timer_connection = self._ib_epg_timer.timeout.connect(self._deferredInfobarEpg)
        except Exception:
            self._ib_epg_timer.callback.append(self._deferredInfobarEpg)
        self.onShow.append(self._onShown)
        self.onHide.append(self._onHidden)
        self.onClose.append(self._closeInfobarTimers)

    # The existing subtitle bridge already calls these VOD HUD methods.
    # Implement them on Live itself; never change the subtitle loader or
    # the Session modal stack. Only the active player may repaint its HUD.
    def refreshInfobar(self):
        if (self._ib_closed or self.session.current_dialog is not self
                or not getattr(self.session, 'in_exec', False)):
            return
        self._ib_manual_hidden = False
        try:
            self.show()
            self._startHideTimer()
        except Exception:
            pass

    def lockShow(self):
        if self._ib_closed:
            return
        self._hud_lock += 1
        try:
            self._ib_timer.stop()
        except Exception:
            pass
        self.refreshInfobar()

    def unlockShow(self):
        self._hud_lock = max(0, self._hud_lock - 1)
        if not self._hud_lock:
            self.refreshInfobar()

    def _makeTimer(self, callback):
        # Supply the same one-shot return-to-player timer contract as VOD.
        # The existing bridge owns the callback, timing and retry count.
        # No provider/download/parser changes and no periodic timer.
        timer = eTimer()
        try:
            self._ib_return_connection = timer.timeout.connect(callback)
        except Exception:
            timer.callback.append(callback)
        return timer

    def _onShown(self):
        self._ib_state = self.STATE_SHOWN
        self._startHideTimer()

    def _onHidden(self):
        self._ib_state = self.STATE_HIDDEN
        self._ib_hide_deadline = 0.0
        try:
            self._ib_timer.stop()
        except Exception:
            pass

    def _closeInfobarTimers(self):
        self._ib_closed = True
        self._hud_lock = 0
        for timer in (self._ib_timer, self._ib_epg_timer,
                      getattr(self, "_subtitle_activation_timer", None)):
            try:
                timer.stop()
            except Exception:
                pass

        self._subtitle_activation_timer = None
        try:
            connection = getattr(self, '_ib_return_connection', None)
            if connection is not None and hasattr(connection, 'disconnect'):
                connection.disconnect()
        except Exception:
            pass
        self._ib_return_connection = None

    def _startHideTimer(self):
        try:
            self._ib_timer.stop()
            if self._ib_closed or self._hud_lock or self._ib_state == self.STATE_HIDDEN:
                return
            # DreamOS can delay or omit decoder-ready metadata. Never leave
            # the OSD visible indefinitely while waiting for that metadata.
            self._ib_hide_deadline = monotonic() + 5.0
            self._ib_timer.start(5000, True)
        except Exception:
            pass

    def _hideInfobar(self):
        if self._ib_closed or self._hud_lock or self._ib_state == self.STATE_HIDDEN:
            return
        try:
            # Ignore an already queued timeout from an older show request.
            remaining = self._ib_hide_deadline - monotonic()
            if remaining > 0:
                self._ib_timer.start(max(1, int(remaining * 1000 + 0.999)), True)
                return
            self.hide()
        except Exception:
            pass

    def toggleInfobar(self):
        # OK can arrive through both native key contexts (ok + toggleShow)
        # for ONE press. Ignore that duplicate, but let a real second press
        # hide the bar: on some images (DreamOS/Gemini) the user otherwise
        # had no way to remove an Infobar that stayed on screen.
        now = monotonic()
        last = float(getattr(self, '_ib_toggle_at', 0.0) or 0.0)
        if 0 <= now - last < 0.4:
            return 1
        self._ib_toggle_at = now
        if self._ib_state == self.STATE_SHOWN and not self._ib_closed:
            self._ib_manual_hidden = True
            try:
                self._ib_timer.stop()
                self.hide()
            except Exception:
                pass
            return 1
        self.showInfobar()
        return 1

    def _showTuningInfobar(self):
        # Delayed link resolution / video confirmation must respect OK-hide.
        if not self._ib_manual_hidden:
            self.showInfobar()

    def showInfobar(self):
        if self._ib_closed:
            return
        self._ib_manual_hidden = False
        # Rendering must never start EPG parsing/requests or poster lookups
        # inline with the OK press. The channel decoder keeps priority.
        try:
            self.show()
            self._startHideTimer()
            if (getattr(self, '_livePlaybackConfirmed', False)
                    and not getattr(self, '_liveStartupPending', False)
                    and not getattr(self, '_liveResolvePending', False)
                    and not getattr(self, '_epgSchedulePending', False)):
                self._ib_epg_timer.start(180, True)
        except Exception:
            pass

    def _deferredInfobarEpg(self):
        # Ultra-style OSD: schedule work after the paint, and only for a
        # confirmed service. No decoder reinitialisation or new service play.
        if (getattr(self, '_epgClosed', False)
                or getattr(self, '_liveResolvePending', False)
                or getattr(self, '_epgSchedulePending', False)):
            return
        # Python 2.7/VTi may miss evStart or report video dimensions late
        # after CH+/- zapping.  Once Navigation owns the exact new ref it is
        # safe to start the existing *asynchronous* EPG lookup, even before
        # the video readiness probe finishes. Never paint the old channel.
        if not getattr(self, '_livePlaybackConfirmed', False):
            if not getattr(self, '_liveStartupPending', False):
                return
            try:
                wanted = getattr(self, 'current_ref', None)
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                if (wanted is None or active is None or
                        wanted.toString() != active.toString()):
                    return
            except Exception:
                return
        try:
            if getattr(self, '_epg_ready', False):
                self._updateEpg()  # existing provider cache/throttle rules
            else:
                self._scheduleEpg()  # adopted PiG may have missed evStart
        except Exception:
            pass


class TiviMateLivePlayer(InfoBarBase, LiveInfoBarShowHide, InfoBarAudioSelection,
                         InfoBarSubtitleSupport, InfoBarSummarySupport, Screen):
    """Dedicated Live player. It intentionally does not inherit or modify the VOD player."""

    skin = '''<screen name="TiviMateLivePlayer" position="0,0" size="1920,1080" zPosition="10" backgroundColor="#ff000000" flags="wfNoBorder">
        <!-- r451: VOD-style Live infobar + actual color-key legend + native player technical badges. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/infobar_bg_premium.png" position="0,796" size="1920,284" alphatest="blend" zPosition="1"/>
        <!-- Weather pill (IP location + Open-Meteo), hidden until data arrives. -->
        <widget name="wxPill" position="1584,726" size="308,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/weather_pill.png" alphatest="blend" zPosition="8"/>
        <widget name="wxIcon" position="1610,745" size="40,40" alphatest="blend" scale="1" zPosition="9"/>
        <widget name="wxTemp" position="1656,742" size="68,46" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="9"/>
        <widget name="wxCity" position="1738,743" size="136,22" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="9"/>
        <widget name="wxCond" position="1738,765" size="136,20" font="Regular;14" foregroundColor="#FFC27A" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="9"/>

        <!-- Live EPG landscape art only: no black placeholder, no vertical poster. -->
        <!-- Always-visible transparent TiViMate fallback INSIDE the oval, not in the channel picon. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/tivimate_inside_oval.png" position="34,826" size="400,224" alphatest="blend" zPosition="4" />
        <widget name="livePoster" position="34,826" size="400,224" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="backdropFrame" position="34,826" size="400,224" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/oval_mask_frame.png" alphatest="blend" scale="1" zPosition="7"/>
        <eLabel position="452,840" size="2,190" backgroundColor="#40FFFFFF" zPosition="2"/>
        <eLabel position="1580,830" size="2,220" backgroundColor="#40FFFFFF" zPosition="2"/>

        <widget source="channel" render="Label" position="476,824" size="617,46" font="Regular;36" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="resolutionBadge" position="1100,826" size="112,42" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="aspectBadge" position="1222,826" size="96,42" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="videoBadge" position="1328,826" size="112,42" alphatest="blend" scale="1" zPosition="5"/>
        <widget name="audioBadge" position="1450,826" size="104,42" alphatest="blend" scale="1" zPosition="5"/>

        <widget name="nowTag" position="476,884" size="92,34" font="Regular;25" foregroundColor="#FFD84D" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNow" position="573,884" size="907,34" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="nextTag" position="476,927" size="92,31" font="Regular;22" foregroundColor="#28A9FF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <widget name="epgNext" position="573,927" size="907,31" font="Regular;22" foregroundColor="#C7D3DF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="4"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/progress_track.png" position="476,976" size="1004,14" alphatest="blend" zPosition="3"/>
        <widget name="epgProgress" position="476,976" size="1004,14" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/progress_fill.png" alphatest="blend" zPosition="4"/>
        <widget name="epgKnob" position="-100,-100" size="30,30" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/vod_player/progress_knob.png" alphatest="blend" zPosition="6"/>
        <!-- EPG synopsis / film year / rating; uses unused space below progress and does not cover playback. -->
        <widget name="epgDetails" position="476,993" size="694,37" font="Regular;17" foregroundColor="#E4EDF5" backgroundColor="#00000000" transparent="1" noWrap="0" zPosition="5"/>
        <widget name="epgProgressText" position="1185,997" size="295,31" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="4"/>

        <!-- right: channel picon only. r507 removes the counter/date/hint text
             below it and lets the picon use the full right-hand infobar panel. -->
        <widget name="piconNormalCard" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/picon_card_royal.png" position="1592,822" size="284,228" alphatest="blend" zPosition="3"/>
        <widget name="piconPlateWhite" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/picon_bg_white.png" position="1616,840" size="236,142" alphatest="blend" scale="1" zPosition="4"/>
        <widget name="piconPlateBlack" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/picon_bg_black.png" position="1616,840" size="236,142" alphatest="blend" scale="1" zPosition="4"/>
        <widget name="picon" position="1629,848" size="209,125" alphatest="blend" scale="1" zPosition="5"/>

        <!-- Color-key legend.  Every label below is wired to the same action map. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_red.png" position="475,1034" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="redKeyText" position="506,1029" size="210,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_green.png" position="725,1034" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="greenKeyText" position="756,1029" size="180,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_yellow.png" position="945,1034" size="22,22" alphatest="blend" zPosition="6"/>
        <widget name="yellowKeyText" position="976,1029" size="250,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" noWrap="1" zPosition="6"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/key_dot_blue.png" position="1235,1034" size="22,22" alphatest="blend" zPosition="6"/>
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/tv_key_chip.png" position="1340,1032" size="46,26" alphatest="blend" zPosition="6"/>
        <widget name="tvKeyText" position="1394,1029" size="176,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="6"/>
        <widget name="blueKeyText" position="1266,1029" size="70,32" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="6"/>
        <!-- EPG remote-key hint below the channel picon; no badge or opaque background. -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/epg_key_chip_royal.png" position="1640,1000" size="64,32" alphatest="blend" zPosition="7"/>
        <widget name="epgKeyText" position="1710,996" size="158,40" font="Regular;18" foregroundColor="#ECF0FF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" noWrap="1" zPosition="7"/>
    </screen>'''

    def __init__(self, session, source, channels, index=0, reuse_current=False, favorite_exit_stop=False, pending_link=None):
        Screen.__init__(self, session)
        # Initialise the oval-artwork worker state before any asynchronous
        # EPG/artwork callback can be registered (OpenATV crash-log guard).
        self._livePillClosed = False
        self._livePillLock = threading.Lock()
        self._livePillResults = []
        self._livePillWorkers = 0
        self._livePillRequestSeq = 0
        self.session = session
        self.source = source or {}
        self.channels = list(channels or [])
        self.reuse_current = bool(reuse_current)
        self.favorite_exit_stop = bool(favorite_exit_stop)
        self._pendingLiveLink = pending_link if isinstance(pending_link, dict) else None
        self._pendingLiveLinkIndex = int(index or 0)
        self._preserve_live_subtitles_on_close = False
        self.index = max(0, min(int(index or 0), max(0, len(self.channels) - 1)))
        compat = _stalker_compat(self.source) if self.source.get("type") == "stalker" else {}
        saved_auto_engine = compat.get("live_engine")
        self._auto_engine = bool(self.source.get("type") == "stalker" and not saved_auto_engine)
        if self.source.get("type") == "stalker":
            initial_engine = saved_auto_engine or _load_stalker_live_service_type(self.source, _load_service_type())
        else:
            initial_engine = self.source.get("service_type", _load_service_type())
        self.service_type = compatible_service_type(initial_engine or 4097)
        if self.source.get('type') == 'stalker':
            _stalker_note('PLAYER_OPEN', service=self.service_type,
                          auto=int(self._auto_engine), channels=len(self.channels),
                          client=int(get_source_client is not None))
        available_engines = [v for v, _label in _available_service_types()]
        preferred_order = [4097, 5002, 5001]
        self._engine_candidates = [v for v in preferred_order if v in available_engines and v != self.service_type]
        self._engine_attempted = [self.service_type]
        self.current_url = ""
        # Ultra-owned external player tracking. Native 4097 is never killed.
        self._ultraDecoderGuard = UltraLiveDecoderGuard()
        self._ultraExternalUrl = ""
        self._live_client = None
        # Stalker client startup reads cache, creates a session and may spawn
        # prefetch work. Leave that to the async link worker, never the GUI.
        try:
            if self.source.get("type") == "xtream":
                self._live_client = get_source_client(self.source)
        except Exception:
            self._live_client = None

        # Stalker create_link is a network operation. Never run it on the
        # Enigma2 UI thread; otherwise the system spinner appears while the
        # portal is resolving the channel URL.
        self._liveResolveToken = 0
        self._liveResolveHandle = None
        self._liveResolveResult = None
        self._liveResolvePending = False
        self._liveResolveDeadline = 0.0
        self._liveResolveTimer = eTimer()
        try:
            self._liveResolveTimer_connection = self._liveResolveTimer.timeout.connect(self._finishAsyncLiveResolve)
        except Exception:
            self._liveResolveTimer.callback.append(self._finishAsyncLiveResolve)
        # Fullscreen can take ownership of the browser's pending create_link.
        # No duplicate network request, and the Infobar opens immediately.
        self._handoffLinkTimer = eTimer()
        try:
            self._handoffLinkTimer_connection = self._handoffLinkTimer.timeout.connect(self._pollPendingLiveLink)
        except Exception:
            self._handoffLinkTimer.callback.append(self._pollPendingLiveLink)
        # Separate timeout for Enigma's native service engine after a URL was
        # resolved. evStart alone does not prove a playable video decoded.
        self._liveStartupTimer = eTimer()
        try:
            self._liveStartupTimer_connection = self._liveStartupTimer.timeout.connect(self._checkLiveStartup)
        except Exception:
            self._liveStartupTimer.callback.append(self._checkLiveStartup)
        self._liveStartupDeadline = 0.0
        self._liveStartupAt = 0.0
        self._liveStartupIndex = -1
        self._liveStartupKey = ""
        self._liveStartupPending = False
        self._livePlaybackConfirmed = False
        self._liveServiceStarted = False
        # Ultra player_golden57: suppress EOF/TuneFailed caused by replacing
        # the previous Enigma service; never infer a stall from UI polls.
        self._liveEventSuppressUntil = 0.0
        self._liveInterruptedRef = ""
        self._liveStartupSeenRef = False
        self._liveStartupMissingSince = 0.0
        self._liveTuneFailedRef = ""
        self._liveTuneFailedAt = 0.0
        self._liveVideoProbeSize = None
        self._liveVideoProbeAt = 0.0
        self._liveAudioProbeAt = 0.0
        self._liveSpinnerMuted = False
        self._liveAttemptKey = None
        self._watchdogBusy = False
        self._picon_token = 0
        self._picon_path = None
        self._subssupport = None
        self._external_subs = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._subtitle_session_delay_ms = 0
        # Live subtitles have their own channel/program context.  Keep it
        # independent from VOD/Series item metadata and reset it on zaps.
        self._live_epg_context = {}
        self._liveEpgPlot = u""
        self._infobarPosterYear = ""
        self._infobarPosterRating = 0.0
        self._live_subtitle_channel_key = ""
        self._subtitle_horizontal_offset = 0
        self._infobarPosterPath = ""
        self._infobarArtworkKind = "backdrops"
        self._original_service = None
        try:
            self._original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass
        try:
            from .quick_switch import remember as _remember_dvb
            _remember_dvb(self._original_service)
        except Exception:
            pass

        InfoBarBase.__init__(self)
        LiveInfoBarShowHide.__init__(self)
        InfoBarAudioSelection.__init__(self)
        InfoBarSubtitleSupport.__init__(self)
        InfoBarSummarySupport.__init__(self)

        self["channel"] = StaticText("")
        self["counter"] = StaticText("")
        self["clock"] = StaticText("")
        self["hint"] = StaticText(tr("↑↓ Change   MENU Player Engine   BLUE CC   RED Edit CC   EPG"))
        self["picon"] = Pixmap()
        self["piconNormalCard"] = Pixmap()
        self["piconPlateWhite"] = Pixmap()
        self["piconPlateBlack"] = Pixmap()
        self.onLayoutFinish.append(self._applyPiconBackground)
        self["livePoster"] = Pixmap()
        self["backdropFrame"] = Pixmap()
        self["resolutionBadge"] = Pixmap()
        self["aspectBadge"] = Pixmap()
        self["videoBadge"] = Pixmap()
        self["audioBadge"] = Pixmap()
        self._liveTechBadgeValues = {"resolution": "", "aspect": "", "video": "", "audio": ""}
        self._liveTechFastRefresh = 0
        for _name in ("resolutionBadge", "aspectBadge", "videoBadge", "audioBadge"):
            try:
                self[_name].hide()
            except Exception:
                pass
        self["redKeyText"] = Label("Edit CC")
        self["greenKeyText"] = Label(tr("Audio Tracks"))
        self["yellowKeyText"] = Label("Subtitle List")
        self["blueKeyText"] = Label("CC")
        self["epgKeyText"] = Label("6 TV Guide")
        self["tvKeyText"] = Label("7 Receiver")
        self["wxPill"] = Pixmap()
        self["wxIcon"] = Pixmap()
        self["wxTemp"] = Label("")
        self["wxCity"] = Label("")
        self["wxCond"] = Label("")
        self.onLayoutFinish.append(self._startInfobarWeather)
        self._livePosterToken = 0
        self._livePosterJob = None
        self._livePosterKey = None
        self._livePosterRetryAt = 0.0
        self._infobarPiconPending = None
        self._infobarPiconTimer = eTimer()
        try:
            self._infobarPiconTimer_connection = self._infobarPiconTimer.timeout.connect(self._finishDeferredPicon)
        except Exception:
            self._infobarPiconTimer.callback.append(self._finishDeferredPicon)
        self._livePosterTimer = eTimer()
        try:
            self._livePosterTimer.callback.append(self._startInfobarPosterLookup)
        except Exception:
            self._livePosterTimer_connection = self._livePosterTimer.timeout.connect(self._startInfobarPosterLookup)
        self._livePosterPoll = eTimer()
        try:
            self._livePosterPoll.callback.append(self._finishInfobarPosterLookup)
        except Exception:
            self._livePosterPoll_connection = self._livePosterPoll.timeout.connect(self._finishInfobarPosterLookup)
        self._livePillTimer = eTimer()
        try:
            self._livePillTimer.callback.append(self._finishInfobarPill)
        except Exception:
            self._livePillTimer_connection = self._livePillTimer.timeout.connect(self._finishInfobarPill)
        self._livePosterPic = ePicLoad()
        try:
            self._livePosterPic.PictureData.get().append(self._infobarPosterDecoded)
        except Exception:
            self._livePosterPicConn = self._livePosterPic.PictureData.connect(self._infobarPosterDecoded)
        try:
            self["livePoster"].hide()
            self["backdropFrame"].show()
        except Exception:
            pass
        self["nowTag"] = Label(tr("NOW"))
        self["epgNow"] = Label("")
        self["nextTag"] = Label(tr("NEXT"))
        self["epgNext"] = Label("")
        self["epgDetails"] = Label("")
        self["epgProgress"] = PixmapProgress()   # white-bar safe on VTi/HD images
        self["epgKnob"] = Pixmap()
        self._wrapEpgProgressKnob()
        self["epgProgressText"] = Label("")
        try:
            self["epgProgress"].setRange((0, 100))
        except Exception:
            pass

        self._pic = ePicLoad()
        try:
            self._pic.PictureData.get().append(self._piconDecoded)
        except Exception:
            self._pic_conn = self._pic.PictureData.connect(self._piconDecoded)

        self._clock_timer = eTimer()
        try:
            self._clock_timer_connection = self._clock_timer.timeout.connect(self._updateClock)
        except Exception:
            self._clock_timer.callback.append(self._updateClock)

        # Playback must start before any EPG JSON work.  The one-shot timer
        # lets the decoder settle, then reads the already-built in-memory/disk
        # cache without starting downloads or XML conversion in the player.
        self._epg_timer = eTimer()
        try:
            self._epg_timer_connection = self._epg_timer.timeout.connect(self._delayedEpg)
        except Exception:
            self._epg_timer.callback.append(self._delayedEpg)
        self._epg_ready = False
        self._epgSchedulePending = False
        # The JSON/XMLTV EPG can be many megabytes. Never decode it on the
        # Enigma2 GUI thread: one coalescing worker does all local lookups.
        self._epgAsyncToken = 0
        self._epgAsyncLock = threading.Lock()
        self._epgAsyncPending = None
        self._epgAsyncResult = None
        self._epgAsyncWorkerRunning = False
        self._epgClosed = False
        self._epgNextReadAt = 0.0
        self._epgNextRequestAt = 0.0
        self._epgAsyncPoll = eTimer()
        try:
            self._epgAsyncPoll_connection = self._epgAsyncPoll.timeout.connect(self._finishAsyncEpgLookup)
        except Exception:
            self._epgAsyncPoll.callback.append(self._finishAsyncEpgLookup)
        self._stalker_epg_token = 0
        self._stalker_epg_result = None
        self._stalker_epg_started_at = 0.0
        self._stalker_epg_poll = eTimer()
        try:
            self._stalker_epg_poll_connection = self._stalker_epg_poll.timeout.connect(self._finishStalkerPlayerEpg)
        except Exception:
            self._stalker_epg_poll.callback.append(self._finishStalkerPlayerEpg)

        # Xtream Live EPG follows the same provider-direct model as Stalker.
        self._xtream_epg_token = 0
        self._xtream_epg_result = None
        self._xtream_epg_started_at = 0.0
        self._xtream_epg_cache = {}
        self._xtream_epg_last_update = 0.0
        self._xtream_epg_poll = eTimer()
        try:
            self._xtream_epg_poll_connection = self._xtream_epg_poll.timeout.connect(self._finishXtreamPlayerEpg)
        except Exception:
            self._xtream_epg_poll.callback.append(self._finishXtreamPlayerEpg)

        self._engine_timer = eTimer()
        try:
            self._engine_timer_connection = self._engine_timer.timeout.connect(self._verifyAutoEngine)
        except Exception:
            self._engine_timer.callback.append(self._verifyAutoEngine)

        self._watchdog_timer = eTimer()
        try:
            self._watchdog_timer_connection = self._watchdog_timer.timeout.connect(self._sendStalkerWatchdog)
        except Exception:
            self._watchdog_timer.callback.append(self._sendStalkerWatchdog)

        self._catchup_result = None
        self._catchup_item = None
        self._catchup_timer = eTimer()
        try:
            self._catchup_timer_connection = self._catchup_timer.timeout.connect(self._finishXtreamCatchupFromInfobar)
        except Exception:
            self._catchup_timer.callback.append(self._finishXtreamCatchupFromInfobar)

        self["actions"] = ActionMap([
            "OkCancelActions", "DirectionActions", "InfobarShowHideActions",
            "ChannelSelectBaseActions", "InfobarChannelSelection", "InfoActions", "ColorActions", "NumberActions", "MenuActions",
            "InfobarInstantRecord", "RecordActions", "TiviMatePlayerActions"
        ], {
            "cancel": self.back,
            "red": self.openSubtitleEditor,
            "green": self.audioSelection,
            "yellow": self.openSubtitleSelection,
            "ok": self.toggleInfobar,
            "oklong": self.back,
            "toggleShow": self.toggleInfobar,
            "right": self.nextChannel,
            "left": self.prevChannel,
            "up": self.back,
            "down": self.back,
            "channelUp": self.nextChannel,
            "channelDown": self.prevChannel,
            "menu": self.openPlayerMenu,
            # INFO must always reopen the Live Infobar on different Enigma2 images.
            # Catch-up remains accessible in MENU; INFO must not silently
            # route every ordinary channel to the archive handler.
            "info": self.showInfobar,
            "0": self.cycleServiceType,
            "6": lambda: self.openFullDayEPG(),
            "7": self.quickSwitchSatellite,
            "blue": self.openSubsSupport,
            "subtitleFineMinus": self.subtitleFineMinus,
            "subtitleFinePlus": self.subtitleFinePlus,
            "instantRecord": self.toggleLiveRecording,
            "record": self.toggleLiveRecording,
            "tv": self.quickSwitchSatellite,
        }, -2)

        # Reuse the browser guide for the currently playing Live channel.
        from .full_day_epg import install_full_day_epg
        install_full_day_epg(self, self._current, lambda: self.source, info_opens_guide=True)

        live_events = {iPlayableService.evStart: self._serviceStarted}
        tune_failed = getattr(iPlayableService, "evTuneFailed", None)
        if tune_failed is not None:
            live_events[tune_failed] = self._serviceFailed
        stream_eof = getattr(iPlayableService, "evEOF", None)
        if stream_eof is not None:
            live_events[stream_eof] = self._serviceEof
        self._events = ServiceEventTracker(screen=self, eventmap=live_events)
        if self.reuse_current:
            self.onFirstExecBegin.append(self._showCurrentWithoutRestart)
        elif self._pendingLiveLink is not None:
            self.onFirstExecBegin.append(self._beginPendingLiveLink)
        else:
            self.onFirstExecBegin.append(self.playCurrent)
        self.onClose.append(self._cleanup)

    def _cancelPendingLiveLink(self):
        state = getattr(self, "_pendingLiveLink", None)
        self._pendingLiveLink = None
        try: self._handoffLinkTimer.stop()
        except Exception: pass
        if state is not None:
            handle = state.get("handle")
            if handle is not None:
                try: handle.cancel()
                except Exception: pass

    def _beginPendingLiveLink(self):
        """Show the Infobar NOW while Ultra's original worker finishes."""
        item = self._current()
        if item:
            # Mixed Favorites can belong to another provider than the hidden
            # Live browser.  A transferred URL must inherit *its* engine,
            # auth, subtitles and service reference, never the parent server.
            self._activateSourceForItem(item)
        if not item or self.source.get("type") != "stalker":
            self._cancelPendingLiveLink()
            self.playCurrent()
            return
        self._prepareLiveSubtitleChannel(item)
        try:
            self["channel"].setText(item.get("name") or item.get("title") or "IPTV")
            self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
            self["hint"].setText("Opening channel...  •  CH+/- Next channel")
        except Exception: pass
        self._muteLiveSpinner()
        try: self.showInfobar()
        except Exception: pass
        self._pollPendingLiveLink()

    def _pollPendingLiveLink(self):
        state = self._pendingLiveLink
        if state is None:
            return
        if self.index != self._pendingLiveLinkIndex:
            self._cancelPendingLiveLink()
            return
        # A fast channel change or a wrong Favorites card must never consume
        # another provider's old create_link result, even if indices coincide.
        if state.get("favorite"):
            item = self._current() or {}
            channel = str(item.get("stream_id") or item.get("ch_id") or
                          item.get("id") or item.get("url") or item.get("cmd") or
                          item.get("name") or "").strip()
            owner = item.get("_favorite_source") if isinstance(item.get("_favorite_source"), dict) else {}
            if (not channel or channel != state.get("source", (None, None))[1] or
                    str(owner.get("type") or "") != "stalker" or
                    owner != state.get("owner")):
                self._cancelPendingLiveLink()
                return
        result = state.get("result")
        if result is None:
            if monotonic() >= state.get("deadline", 0):
                self._cancelPendingLiveLink()
                self._liveStartFailure(tr("Server did not respond. Try another channel."))
            else:
                try: self._handoffLinkTimer.start(90, True)
                except Exception: pass
            return
        expected_token = state.get("token")
        self._pendingLiveLink = None
        try: self._handoffLinkTimer.stop()
        except Exception: pass
        try:
            token, row, _force, url, _error = result
        except Exception:
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        if token != expected_token or not url:
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        # The worker belongs to this exact Infobar selection now. Enigma's
        # decoder startup and fallbacks remain entirely inside the player.
        self._playResolvedCurrent(self._current(), url, self.index)

    def _showCurrentWithoutRestart(self):
        """Reopen the full-screen Live UI around the already playing service.

        This intentionally does not resolve stream_url/create_link and never
        calls playService, so selecting the same channel from the list cannot
        refresh or restart playback.
        """
        item = self._current()
        if not item:
            return
        name = item.get("name") or item.get("title") or "IPTV"
        try:
            self.current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            self.current_ref = None
        try:
            self._restorePreservedLiveSubtitle(item)
        except Exception:
            pass
        try:
            self.source["_tivimate_current_live_id"] = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            pass
        self["channel"].setText(name)
        self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
        # The Live browser already verified decoded media on this exact ref
        # before passing reuse_current=True. evStart happened *before* this
        # screen existed, so do not wait for another event that cannot arrive.
        # Adopt the live service without reissuing create_link/playService.
        if self.current_ref is None:
            # A previously verified PiG might stop between the browser's
            # check and opening this screen. Recover with one normal bounded
            # resolve, rather than leaving a black player indefinitely.
            self.playCurrent()
            return
        if self.reuse_current:
            # Adopted preview is older than this screen's PID baseline.
            # It remains owned by the Live browser, not by this player.
            self._livePlaybackConfirmed = True
            self._liveServiceStarted = True
            # Opening full-screen reuses the verified PiG without playService.
            # A delayed browser event must not end this adopted service.
            self._liveEventSuppressUntil = monotonic() + 1.25
            self._liveInterruptedRef = ""
            if self.source.get('type') == 'stalker':
                try:
                    self._watchdog_timer.stop()
                    self._watchdog_timer.start(30000, True)
                except Exception:
                    pass
        self.showInfobar()
        self["clock"].setText(time.strftime("%H:%M  %d/%m/%Y"))
        self._liveTechFastRefresh = 3
        try:
            self._clock_timer.start(1000, False)
        except Exception:
            pass
        self._loadPicon(item)


    def _current(self):
        if not self.channels:
            return {}
        return self.channels[self.index]

    def _activateSourceForItem(self, item):
        """Use the owning provider while zapping a mixed-source Favorites list.

        Normal Live lists keep the player's original source unchanged.  Global
        Favorites rows carry ``_favorite_source`` in memory; when present we
        switch only the provider context used to resolve/play that row.
        """
        fav_source = item.get("_favorite_source") if isinstance(item, dict) else None
        if not isinstance(fav_source, dict):
            return
        if fav_source is self.source or fav_source == self.source:
            return
        self.source = fav_source
        self._xtream_epg_cache.clear()
        self._live_client = None
        try:
            if self.source.get("type") == "xtream":
                self._live_client = get_source_client(self.source)
        except Exception:
            self._live_client = None

        compat = _stalker_compat(self.source) if self.source.get("type") == "stalker" else {}
        saved_auto_engine = compat.get("live_engine")
        self._auto_engine = bool(self.source.get("type") == "stalker" and not saved_auto_engine)
        try:
            if self.source.get("type") == "stalker":
                initial_engine = saved_auto_engine or _load_stalker_live_service_type(self.source, _load_service_type())
            else:
                initial_engine = self.source.get("service_type", _load_service_type())
            self.service_type = compatible_service_type(initial_engine or 4097)
        except Exception:
            self.service_type = int(_load_service_type() or 4097)
        available_engines = [v for v, _label in _available_service_types()]
        preferred_order = [4097, 5002, 5001]
        self._engine_candidates = [v for v in preferred_order if v in available_engines and v != self.service_type]
        self._engine_attempted = [self.service_type]

    def _urlFor(self, item):
        try:
            stype = self.source.get("type")
            if stype in ("xtream", "stalker"):
                client = self._live_client
                if client is None:
                    client = get_source_client(self.source)
                    self._live_client = client
                return client.stream_url(item, "live")
            if stype in ("m3u", "fg"):
                return item.get("url", "")
            return ""
        except Exception as exc:
            try:
                if self.source.get("type") == "stalker":
                    stalker_log("PLAYER resolve failed channel=%s error=%s" % (
                        (item or {}).get("name") or (item or {}).get("title") or "", exc))
            except Exception:
                pass
            return ""


    def _clearLiveTechnicalBadges(self):
        # r521: a zap must never show codec/resolution values from the
        # previous service while the decoder is switching to the new one.
        self._liveTechBadgeValues = {"resolution": "", "aspect": "", "video": "", "audio": ""}
        # r522: reuse the existing clock timer for a few quick local decoder-info
        # reads after zapping. No new timer/hook/network request is introduced.
        self._liveTechFastRefresh = 4
        for _name in ("resolutionBadge", "aspectBadge", "videoBadge", "audioBadge"):
            try:
                self[_name].hide()
            except Exception:
                pass

    def _clearLiveEpgUi(self, artwork_fallback=True):
        # r521: clear the old channel's programme text immediately. EPG is
        # scheduled only from the existing evStart callback after playback
        # starts, so zapping stays playback-first and the lookup is invisible.
        self._epgSchedulePending = False
        self._epg_ready = False
        self._live_epg_context = {}
        self._epgUpcomingEvent = None
        self._epgAsyncToken += 1
        self._epgNextReadAt = 0.0
        self._epgNextRequestAt = 0.0
        # Discard any in-flight provider result for the previous channel.
        self._stalker_epg_token += 1
        self._xtream_epg_token += 1
        self._stalker_epg_result = None
        self._xtream_epg_result = None
        try:
            self._stalker_epg_poll.stop()
            self._xtream_epg_poll.stop()
        except Exception:
            pass
        try:
            self._epgAsyncPoll.stop()
            with self._epgAsyncLock:
                self._epgAsyncPending = None
                self._epgAsyncResult = None
        except Exception:
            pass
        try:
            self._epg_timer.stop()
            self._ib_epg_timer.stop()
        except Exception:
            pass
        try:
            self._setLiveEpgLabel("epgNow", "")
            self._setLiveEpgLabel("epgNext", "")
            self._liveEpgPlot = u""
            self._infobarPosterYear = ""
            self._infobarPosterRating = 0.0
            self["epgDetails"].setText("")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
        except Exception:
            pass
        # Clear old channel artwork immediately when zapping. Keep the oval
        # frame and the static TiViMate fallback visible until new EPG art loads.
        try:
            if artwork_fallback:
                self._scheduleInfobarPoster("")
            else:
                self._livePosterToken += 1
                self._livePillRequestSeq += 1
                self._livePosterKey = None
                self._livePosterJob = None
                self._infobarPosterDecodeToken = -1
                self._livePosterTimer.stop()
                self._livePosterPoll.stop()
                self._showInfobarPosterFallback()
        except Exception:
            pass

    def _cancelLiveStartup(self):
        self._liveStartupSeenRef = False
        self._liveStartupMissingSince = 0.0
        self._liveTuneFailedRef = ""
        self._liveTuneFailedAt = 0.0
        self._liveServiceStarted = False
        self._liveVideoProbeSize = None
        self._liveVideoProbeAt = 0.0
        self._liveAudioProbeAt = 0.0
        self._liveStartupPending = False
        self._liveStartupDeadline = 0.0
        self._liveStartupAt = 0.0
        self._liveStartupKey = ""
        try:
            self._liveStartupTimer.stop()
        except Exception:
            pass

    def _cancelLiveResolve(self):
        old_handle = getattr(self, "_liveResolveHandle", None)
        self._liveResolveHandle = None
        if old_handle is not None:
            old_handle.cancel()
        self._liveResolveToken += 1
        self._liveResolvePending = False
        self._liveResolveDeadline = 0.0
        self._liveResolveStartedAt = 0.0
        self._liveResolveResult = None
        try:
            self._liveResolveTimer.stop()
        except Exception:
            pass

    def _muteLiveSpinner(self):
        # Enigma's native spinner can remain onscreen while a dead IPTV service
        # waits in the decoder. Temporarily mute it for this Live attempt only.
        if not self._liveSpinnerMuted:
            try:
                setSpinnerOnOff(0)
                self._liveSpinnerMuted = True
            except Exception:
                pass

    def _restoreLiveSpinner(self):
        # Never leak a global Enigma spinner override into other screens.
        if self._liveSpinnerMuted:
            self._liveSpinnerMuted = False
            try:
                setSpinnerOnOff(1)
            except Exception:
                pass

    def _liveStartFailure(self, message, stop_service=True):
        self._liveAttemptKey = None
        # Do not skip channels automatically, modify their links or retry a
        # whole server when a single channel fails. Remote zapping stays live.
        # A failed create_link does not imply the previous working service
        # should be stopped: only stop a failed service actually started for
        # this exact channel/ref.
        had_startup = bool(self._liveStartupPending)
        failing_ref = getattr(self, "current_ref", None)
        self._cancelLiveStartup()
        self._livePlaybackConfirmed = False
        # Release any native service loading before displaying the failure.
        self._restoreLiveSpinner()
        # Never keep a dead Stalker stream's session watchdog running.
        try:
            self._watchdog_timer.stop()
        except Exception:
            pass
        if stop_service and had_startup and failing_ref is not None:
            try:
                active_ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if active_ref and active_ref.toString() == failing_ref.toString():
                    # Ultra's baseline excludes pre-existing receiver processes.
                    # Stop this exact failed service before retiring its PIDs.
                    retired_url = str(getattr(self, 'current_url', '') or '')
                    if retired_url == getattr(self, '_ultraExternalUrl', ''):
                        self._ultraDecoderGuard.capture(retired_url)
                    self.session.nav.stopService()
                    if retired_url == getattr(self, '_ultraExternalUrl', ''):
                        self._ultraDecoderGuard.retire(retired_url)
                        self._ultraExternalUrl = ''
            except Exception:
                pass
        try:
            self._engine_timer.stop()
        except Exception:
            pass
        if self.source.get("type") == "stalker":
            _stalker_note('PLAYER_FAILED', link=int(bool(self.current_url)),
                          startup=int(had_startup), service=self.service_type)
            # A modal MessageBox steals CH+/CH- focus for four seconds. Keep
            # dead channels non-blocking and show a clear inline failure.
            try: self["hint"].setText(str(message) + "  •  CH+/- Next channel")
            except Exception: pass
            try: self._setLiveEpgLabel("epgNow", str(message))
            except Exception: pass
            try: self.showInfobar()
            except Exception: pass
        else:
            # A modal failure dialog blocks remote channel navigation for
            # several seconds. Keep failures inline on every Live source.
            try:
                self["hint"].setText(str(message) + "  •  CH+/- Next channel")
            except Exception:
                pass
            try:
                self._setLiveEpgLabel("epgNow", str(message))
            except Exception:
                pass
            try:
                self.showInfobar()
            except Exception:
                pass

    def _nativeLiveServicePresent(self):
        """A matching Navigation service must not be stopped on missing metadata."""
        if self.source.get('type') not in ('xtream', 'stalker'):
            return False
        try:
            nav = self.session.nav
            active = nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, 'current_ref', None)
            return bool(active is not None and expected is not None and
                        active.toString() == expected.toString() and
                        nav.getCurrentService() is not None)
        except Exception:
            return False

    def _checkLiveStartup(self):
        if not self._liveStartupPending:
            return
        if self._liveStartupIndex != self.index:
            self._cancelLiveStartup()
            return
        # A decoder can abandon a dead IPTV service without evTuneFailed.
        # Previously this silently occupied the entire 12/16-second startup
        # window even after Enigma stopped playing the attempted reference.
        # Fail fast only if the reference is truly absent; keep the original
        # full deadline for slow streams whose ref is still being buffered.
        if self._liveStartupReferenceLost():
            # The decoder can reject a Stalker service before the scheduled
            # 5.5-second automatic engine probe. In that case the original
            # code failed immediately and never tried the next already-known
            # playback engine. Reuse the SAME resolved URL and shared startup
            # deadline; do not create_link again or extend the timeout.
            if (self.source.get("type") == "stalker" and self._auto_engine and
                    self._engine_candidates and self.current_url and
                    time.time() < self._liveStartupDeadline):
                self._verifyAutoEngine()
                return
            self._liveStartFailure(tr("Channel could not start."), stop_service=True)
            return
        # An evTuneFailed can precede evStart. Do not leave a rejected decoder
        # hanging until the normal 12/16-second deadline if the SAME reference
        # still owns Navigation after a short settling interval. An unrelated
        # error from a previous channel can never match this expected ref.
        failed_ref = getattr(self, '_liveTuneFailedRef', '')
        failed_at = float(getattr(self, '_liveTuneFailedAt', 0.0) or 0.0)
        if failed_ref and failed_at and monotonic() - failed_at >= 0.7:
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, 'current_ref', None)
                still_failed = bool(active and expected and
                    active.toString() == expected.toString() == failed_ref)
            except Exception:
                still_failed = False
            self._liveTuneFailedRef = ''
            self._liveTuneFailedAt = 0.0
            if (still_failed and not self._nativeLiveServicePresent() and
                    not self._videoIsReady() and not self._audioOnlyIsReady()):
                if (self.source.get('type') == 'stalker' and self._auto_engine and
                        self._engine_candidates and self.current_url and
                        time.time() < self._liveStartupDeadline):
                    self._verifyAutoEngine()
                else:
                    self._liveStartFailure(tr('Channel could not start.'), stop_service=True)
                return
        # On some Enigma2 images evStart arrives before Navigation publishes
        # its reference. The event is then ignored by _serviceStarted and is
        # never re-emitted; a valid channel would otherwise time out after
        # 12/16 seconds. Recover only for the exact new reference after the
        # decoder has produced media metadata, never from an old ref alone.
        if not self._liveServiceStarted and time.time() - self._liveStartupAt >= 1.25:
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, "current_ref", None)
                if active and expected and active.toString() == expected.toString():
                    svc = self.session.nav.getCurrentService()
                    info = svc and svc.info()
                    if info and (int(info.getInfo(iServiceInformation.sVideoWidth) or 0) > 0 and
                                 int(info.getInfo(iServiceInformation.sVideoHeight) or 0) > 0):
                        self._liveServiceStarted = True
            except Exception:
                pass
        # Some Enigma images briefly expose the *previous* channel's video
        # dimensions while a new service opens. Give the new decoder a moment.
        media_ready = ((time.time() - self._liveStartupAt >= 1.5) and
                       (self._videoIsReady() or self._audioOnlyIsReady()))
        expired = time.time() >= self._liveStartupDeadline
        # On older Enigma2 decoders evStart/dimensions are not reliable.
        # At the deadline hand control to Navigation if the requested native
        # service still exists. No stopService, extra poll or decoder restart.
        native_owned = (expired and self._nativeLiveServicePresent())
        if media_ready or native_owned:
            self._livePlaybackConfirmed = True
            if not media_ready:
                # Native ownership alone is not decoded-media proof. Allow
                # a manual retry if the user is still seeing a black screen.
                self._liveAttemptKey = None
            if self.source.get('type') == 'stalker':
                _stalker_note('DECODER_READY' if media_ready else 'DECODER_NATIVE_OWNED',
                              service=self.service_type)
            self._cancelLiveStartup()
            self._restoreLiveSpinner()
            # EPG and decoder badge refresh follow usable video, not a
            # potentially stalled create_link/playService. Never hold playback
            # behind programme parsing or artwork requests.
            # Reading codecs and loading PNG badges on the first decoded
            # frame delays the OSD and channel transition on slow receivers.
            # The existing 1s metadata refresh does this after video starts.
            self._liveTechFastRefresh = max(3, int(getattr(self, '_liveTechFastRefresh', 0) or 0))
            try:
                self._clock_timer.start(1000, False)
            except Exception:
                pass
            self._scheduleEpg()
            # First OK must display the channel WITH its infobar. Restart the
            # five-second visibility window on decoded video, not on the
            # possibly slow first provider request or playService call.
            self._showTuningInfobar()
            # An engine is learned only after actual video was decoded.
            if self.source.get("type") == "stalker":
                try:
                    self._engine_timer.stop()
                    if self._auto_engine and media_ready:
                        _save_stalker_engine(self.source, self.service_type)
                        self._auto_engine = False
                    self._watchdog_timer.stop()
                    self._watchdog_timer.start(30000, True)
                except Exception:
                    pass
            return
        if time.time() >= self._liveStartupDeadline:
            self._liveStartFailure(tr("Channel unavailable - try another channel."), stop_service=True)
            return
        try:
            # Most successful tunes settle in their first three seconds.
            # Reduce the extra delay between decoded video and confirmation,
            # then revert to the original gentle poll for slow/dead channels.
            elapsed = time.time() - self._liveStartupAt
            self._liveStartupTimer.start(220 if elapsed < 3.0 else 350, True)
        except Exception:
            pass

    def _liveStartupReferenceLost(self):
        """A missing Enigma service is a failure; slow buffering is NOT.

        Enigma builds differ in when they publish a ref after playService.
        Allow five seconds on builds that have not reported one yet. Once the
        expected ref has been observed, a sustained 0.9s disappearance is
        strong evidence that native playback has already terminated.
        """
        if not self._liveStartupPending:
            return False
        now = monotonic()
        try:
            ref = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            same = bool(ref is not None and expected is not None and
                        ref.toString() == expected.toString())
        except Exception:
            # An unavailable navigation API isn't evidence of failure.
            return False
        if same:
            self._liveStartupSeenRef = True
            self._liveStartupMissingSince = 0.0
            return False
        if not self._liveStartupMissingSince:
            self._liveStartupMissingSince = now
        # Match the normal Live/Windows preview policy: a temporarily empty
        # Navigation reference may take five seconds to appear on OpenATV/Pure,
        # but an unchanged *different* active service means the new tune is
        # probably not taking over. Retire it sooner and keep CH+/- responsive.
        grace = (0.9 if self._liveStartupSeenRef else
                 (5.0 if ref is None else 1.8))
        return bool(now - self._liveStartupMissingSince >= grace)

    def _ultraLiveEventCurrent(self):
        """Port of Ultra's current-ref/event-suppression guard for Live.

        Like Ultra, allow a missing Navigation ref after EOF: Enigma may
        clear the finished service before dispatching its event. Reject an
        explicitly *different* active ref so a late event cannot end a zap.
        """
        if monotonic() < getattr(self, '_liveEventSuppressUntil', 0.0):
            return False
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, 'current_ref', None)
            if expected is None:
                return False
            # Ultra's player_golden57 permits an empty Navigation ref after
            # an EOF, but a different *nonempty* ref belongs to another zap.
            return active is None or active.toString() == expected.toString()
        except Exception:
            return False

    def _ultraLiveInterrupted(self, reason):
        """Ultra player_golden57._handle_runtime_interruption policy.

        After a confirmed Live stream fails, NEVER automatically stop/play
        a decoder or refresh its URL. That caused repeated native allocations
        on real receivers. Leave the current Navigation service alone and
        permit a *manual* retry by selecting the channel again.
        """
        if not self._livePlaybackConfirmed or self._liveStartupPending:
            return False
        if not self._ultraLiveEventCurrent():
            return False
        if self._nativeLiveServicePresent():
            # A transient native event is not evidence of an unavailable
            # channel. Navigation owns the live stream, as with bouquets.
            # Clear the duplicate-attempt gate so manual retry stays possible.
            self._liveAttemptKey = None
            return False
        try:
            ref_str = self.current_ref.toString()
        except Exception:
            return False
        if self._liveInterruptedRef == ref_str:
            return True
        self._liveInterruptedRef = ref_str
        self._livePlaybackConfirmed = False
        self._liveAttemptKey = None
        try: self._watchdog_timer.stop()
        except Exception: pass
        try: self._engine_timer.stop()
        except Exception: pass
        self._restoreLiveSpinner()
        # Inline status, not a modal MessageBox that prevents CH+/-.
        try: self['hint'].setText(tr('Stream interrupted - select channel to retry'))
        except Exception: pass
        try: self._setLiveEpgLabel("epgNow", tr('Stream interrupted'))
        except Exception: pass
        try: self.showInfobar()
        except Exception: pass
        self._scheduleLiveReconnect(ref_str)
        return True

    def _scheduleLiveReconnect(self, ref_str):
        """r153: reconnect a Live stream that the provider closed.

        Many providers end the HTTP connection after about a minute (token or
        connection rotation); every engine then reports EOF and the picture
        stopped for good. Reopen the SAME channel after a short pause, at most
        6 times in 10 minutes per channel, so a really dead stream does not
        loop. Any zap, Back or manual retry cancels the pending reconnect.
        """
        now = monotonic()
        history = getattr(self, "_liveReconnectHistory", None)
        if not isinstance(history, dict):
            history = self._liveReconnectHistory = {}
        recent = [t for t in history.get(ref_str, []) if now - t < 600.0]
        if len(recent) >= 6:
            history[ref_str] = recent
            return
        recent.append(now)
        history[ref_str] = recent
        index = int(getattr(self, "index", 0) or 0)

        def reconnect():
            if (getattr(self, "_epgClosed", False) or getattr(self, "_ib_closed", False)
                    or getattr(self, "_liveInterruptedRef", "") != ref_str
                    or int(getattr(self, "index", -1)) != index):
                return
            self._liveInterruptedRef = ""
            self._liveAttemptKey = None
            try: self['hint'].setText(tr('Reconnecting...'))
            except Exception: pass
            try:
                self.playCurrent()
            except Exception as exc:
                print("[TiviMateE2] live reconnect failed: %s" % exc)
        try:
            timer = self._liveReconnectTimer = eTimer()
            try:
                self._liveReconnectConn = timer.timeout.connect(reconnect)
            except Exception:
                timer.callback.append(reconnect)
            timer.start(1500 if len(recent) == 1 else 4000, True)
        except Exception as exc:
            print("[TiviMateE2] live reconnect scheduling failed: %s" % exc)

    def _serviceEof(self):
        if getattr(self, "_replayMenuPlaying", False):
            return
        """Ultra's evEOF policy: established Live never auto-restarts."""
        if not self._ultraLiveEventCurrent():
            return
        if self._livePlaybackConfirmed:
            self._ultraLiveInterrupted('EOF')
        elif self._liveStartupPending:
            # Failure during initial tuning is handled by the existing
            # bounded decoder startup/fallback logic, not a fresh create_link.
            self._serviceFailed()

    def _serviceFailed(self):
        if getattr(self, "_replayMenuPlaying", False):
            return
        # Ultra handles a genuine interruption after confirmed playback
        # without stopping and recreating native decoder instances.
        if (getattr(self, '_livePlaybackConfirmed', False) and
                not getattr(self, '_liveStartupPending', False)):
            self._ultraLiveInterrupted('tune failed')
            return
        # Startup still uses its original current-ref/deadline validation.
        # Ultra-style event suppression applies to confirmed playback only;
        # suppressing initial evTuneFailed could mask a genuinely bad engine.
        # Some engines emit a late error from the previously selected channel;
        # act only while the current selection is still opening.
        if self._liveStartupPending and self._liveStartupIndex == self.index:
            # A late evTuneFailed from the previous zap must not fail a newer
            # service. Only act on a ref that matches this attempt; otherwise
            # let the bounded startup deadline decide without a false failure.
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, "current_ref", None)
                # evTuneFailed can arrive late from the preceding service.
                # An empty or different navigation ref does NOT identify the
                # failed tune as our new channel. Let the bounded startup
                # probe decide rather than incorrectly aborting a fresh zap.
                if active is None or expected is None or active.toString() != expected.toString():
                    return
                if not self._liveServiceStarted and not self._liveStartupSeenRef:
                    # First evTuneFailed may be from the old service. Require
                    # a poll of the new ref before accepting the event.
                    return
                if time.time() - self._liveStartupAt < 0.65:
                    return
                self._liveTuneFailedRef = expected.toString()
                self._liveTuneFailedAt = monotonic()
                # Do not recurse into the full startup check from inside an
                # Enigma2 service callback; let its existing poll observe it.
                self._liveStartupTimer.start(350, True)
            except Exception:
                return

    def _playResolvedCurrent(self, item, url, expected_index=None):
        if not item or not url:
            return
        if expected_index is not None and int(expected_index) != int(self.index):
            return

        # Retrying an already-resolved Stalker URL under another decoder is
        # NOT a new channel. Avoid repeating EPG cancellation, artwork reset,
        # Picon decoding and UI timers for every engine candidate. These extra
        # GUI operations compete with native service startup on slow boxes.
        # The initial tune still clears stale EPG/technical data normally.
        same_engine_retry = bool(
            self.source.get("type") == "stalker" and self._auto_engine and
            self._liveStartupPending and self._liveStartupIndex == self.index and
            len(self._engine_attempted) > 1 and self.current_url == url)
        if not same_engine_retry:
            try:
                self._epg_timer.stop()
            except Exception:
                pass
            self._epgSchedulePending = False
            self._clearLiveEpgUi()
            self._clearLiveTechnicalBadges()
        previous_external_url = getattr(self, '_ultraExternalUrl', '')
        if previous_external_url and previous_external_url != url:
            self._ultraDecoderGuard.capture(previous_external_url)
        self.current_url = url
        # Stalker auto-engine retries must share the original deadline rather
        # than each restarting a full timeout on the same channel.
        key = "%s:%s:%s" % (str(self.source.get("type") or ""), self.index,
                                gui_text(item.get("id") or item.get("stream_id") or
                                    item.get("ch_id") or item.get("cmd") or
                                    item.get("name") or ""))
        old_key = self._liveStartupKey
        old_deadline = self._liveStartupDeadline
        self._liveStartupKey = key
        self._liveStartupIndex = self.index
        self._liveStartupAt = time.time()
        if key == old_key and self._auto_engine and old_deadline > time.time():
            self._liveStartupDeadline = old_deadline
        else:
            duration = (LIVE_STALKER_STARTUP_TIMEOUT_SECONDS if self.source.get("type") == "stalker"
                        else LIVE_STARTUP_TIMEOUT_SECONDS)
            self._liveStartupDeadline = time.time() + duration
        self._liveStartupPending = True
        self._livePlaybackConfirmed = False
        self._liveServiceStarted = False
        self._liveStartupSeenRef = False
        self._liveStartupMissingSince = 0.0
        self._liveTuneFailedRef = ""
        self._liveTuneFailedAt = 0.0
        self._liveVideoProbeSize = None
        self._liveVideoProbeAt = 0.0
        self._liveAudioProbeAt = 0.0
        self._liveEngineMediaGraceUsed = False
        try:
            self._liveStartupTimer.stop()
            # Poll a new decoder quickly while its first frames arrive;
            # readiness still requires the current ref + stable dimensions.
            self._liveStartupTimer.start(220, True)
        except Exception:
            pass
        try:
            self.source["_tivimate_current_live_id"] = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            pass
        name = item.get("name") or item.get("title") or "IPTV"
        if self.source.get("type") == "stalker":
            try:
                stalker_log("PLAYER service_type=%s channel=%s url=%s" % (
                    self.service_type, name, (url or "")[:180]))
            except Exception:
                pass
        effective_service_type = compatible_service_type(self.service_type)
        try:
            if effective_service_type == 1 and ".m3u8" in str(url).lower():
                effective_service_type = 4097
        except Exception:
            pass
        try:
            ref = live_reference(self.source, item, effective_service_type, url, name)
        except Exception as exc:
            print("[TiviMateE2] Live reference build failed: %s" % type(exc).__name__)
            self._liveStartFailure(tr("Channel could not start."), stop_service=False)
            return
        if self.source.get('type') == 'stalker':
            scheme, ext = _stalker_url_kind(url)
            _stalker_note('DECODER_OPEN', service=effective_service_type, scheme=scheme, format=ext)
        self.current_ref = ref
        self._liveEventSuppressUntil = monotonic() + 1.25
        self._liveInterruptedRef = ""
        try:
            # Do not restore the native Loading spinner immediately after
            # playService: disconnected IPTV services may buffer for seconds.
            # Restore when video decodes, playback fails, or this player closes.
            self._muteLiveSpinner()
            accepted = self.session.nav.playService(ref)
            # playService reports immediate rejection on some Enigma2 images.
            # Do not wait the full startup timeout for an already rejected ref.
            if accepted is not None and accepted != 0:
                if self.source.get('type') == 'stalker':
                    _stalker_note('DECODER_REJECT', service=effective_service_type,
                                  result=accepted if isinstance(accepted, (int, long)) else 'nonzero')
                self._handleImmediateLiveReject()
                return
        except Exception as exc:
            if self.source.get('type') == 'stalker':
                _stalker_note('DECODER_EXCEPTION', service=effective_service_type, error=type(exc).__name__)
            self._handleImmediateLiveReject()
            return

        # Only after Navigation accepted a replacement may Ultra-style cleanup
        # retire external processes associated with the old, different URL.
        # An engine retry uses the SAME URL, so never kill its pending decoder.
        if previous_external_url and previous_external_url != url:
            self._ultraDecoderGuard.retire(previous_external_url)
        self._ultraExternalUrl = url if effective_service_type in (5001, 5002, 8193, 8903) else ''
        if self._ultraExternalUrl:
            guard = getattr(self, '_ultraDecoderGuard', None)
            if guard is not None:
                guard.capture(self._ultraExternalUrl)

        if not same_engine_retry:
            self["channel"].setText(name)
            self["counter"].setText("%d / %d" % (self.index + 1, len(self.channels)))
            self._updateClock()
            try:
                self._clock_timer.start(10000, False)
            except Exception:
                pass
            # Cached Picons are queued once for the channel, not once per
            # decoder candidate. EPG stays deferred until video confirmation.
            self._showTuningInfobar()
            self._loadPicon(item)
            # Fast CH+/- on VTi must not depend on the Live browser being
            # reopened to populate NOW/NEXT for the selected channel.
            # Reuse the exact channel's RAM EPG first, then make one delayed
            # non-blocking refresh, guarded by the active service reference.
            try:
                if not text_type(self["epgNow"].getText() or u"").strip():
                    self._showCachedInfobarEpg(item)
                self._ib_epg_timer.start(1300, True)
            except Exception:
                pass

        if self.source.get("type") == "stalker" and self._auto_engine:
            # Previously both fallback timers used 5.5s. In a 12s shared
            # startup window, the last engine then received ~1s and could
            # never finish buffering. Give a compatible final candidate a
            # meaningful chance, without renewing the 12-second deadline.
            try:
                self._engine_timer.stop()
                if self._engine_candidates:
                    remaining_ms = int((self._liveStartupDeadline - time.time()) * 1000)
                    preferred_ms = 4600 if len(self._engine_attempted) == 1 else 3000
                    if remaining_ms > 1300:
                        self._engine_timer.start(min(preferred_ms, remaining_ms - 1200), True)
            except Exception:
                pass

    def _handleImmediateLiveReject(self):
        """Fast rejection: retry the next compatible engine on the SAME URL.

        Do not enter a new create_link request or extend the startup deadline.
        A rejection from a standalone engine or an exhausted engine list is
        reported immediately, rather than waiting for the full timer.
        """
        if (self.source.get('type') == 'stalker' and self._auto_engine and
                self._liveStartupPending and self._liveStartupIndex == self.index and
                self._engine_candidates and self.current_url and
                time.time() < self._liveStartupDeadline):
            self._verifyAutoEngine()
            return
        self._liveStartFailure(tr("Channel could not start."), stop_service=True)

    def _finishAsyncLiveResolve(self):
        if not self._liveResolvePending:
            return
        result = self._liveResolveResult
        # A resolved URL is useful even if the GUI polls slightly after its
        # deadline. Otherwise an already-completed link is discarded and the
        # user must retry the channel. The token/index checks below still
        # prevent stale links from playing after zapping.
        if result is None and time.time() >= self._liveResolveDeadline:
            self._cancelLiveResolve()
            self._liveStartFailure(tr("Server did not respond. Try another channel."))
            return
        self._liveResolveResult = None
        if result is None:
            try:
                # Fast response for a cached/healthy portal, fewer GUI timer
                # wakeups for a slow or dead portal after the first 800 ms.
                age = time.time() - float(getattr(self, '_liveResolveStartedAt', 0.0) or 0.0)
                self._liveResolveTimer.start(50 if age < 0.8 else 120, True)
            except Exception:
                pass
            return
        token, index, item, url = result
        if token != self._liveResolveToken or index != self.index:
            # A previous Stalker request finished after CH+/CH-. Continue
            # polling for the current request, not the obsolete result.
            try:
                self._liveResolveTimer.start(50, True)
            except Exception:
                pass
            return
        self._liveResolvePending = False
        self._liveResolveDeadline = 0.0
        self._liveResolveStartedAt = 0.0
        self._liveResolveHandle = None
        if not url:
            _stalker_note('LINK_FAILED', stage='resolved_empty')
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        self._playResolvedCurrent(item, url, index)


    def playCurrent(self):
        # CH+/- or a changed engine supersedes a transferred browser request.
        self._cancelPendingLiveLink()
        item = self._current()
        if not item:
            return
        # A repeated selection should not trigger a new portal request or
        # reinitialize the decoder. The service engine and provider are part
        # of the key so an explicit engine change still works normally.
        source = item.get('_favorite_source') if isinstance(item.get('_favorite_source'), dict) else self.source
        identity = (gui_text((source or {}).get('portal') or (source or {}).get('url') or ''),
                    str((source or {}).get('mac') or ''),
                    str((source or {}).get('type') or ''),
                    gui_text(item.get('stream_id') or item.get('ch_id') or item.get('id') or
                        item.get('url') or item.get('cmd') or item.get('name') or ''),
                    int(self.index), int(self.service_type))
        if identity == getattr(self, '_liveAttemptKey', None):
            if self._liveResolvePending or self._liveStartupPending:
                return
            if self._livePlaybackConfirmed and self.current_ref is not None:
                try:
                    current = self.session.nav.getCurrentlyPlayingServiceReference()
                    if current is not None and current.toString() == self.current_ref.toString():
                        return
                except Exception:
                    pass
        self._ib_manual_hidden = False
        # A previous channel's five-second infobar timer must not expire
        # while the new selection is still resolving/starting.
        try:
            self._ib_timer.stop()
        except Exception:
            pass
        self._muteLiveSpinner()
        self._activateSourceForItem(item)
        identity = (gui_text(self.source.get('portal') or self.source.get('url') or ''),
                    str(self.source.get('mac') or ''), str(self.source.get('type') or ''),
                    identity[3], int(self.index), int(self.service_type))
        self._prepareLiveSubtitleChannel(item)
        self._livePlaybackConfirmed = False
        # Late engine/watchdog timers from the previous channel must never
        # restart playback or send portal requests while zapping.
        try:
            self._engine_timer.stop()
            self._watchdog_timer.stop()
        except Exception:
            pass
        # Cancel any previous channel's playback timeout immediately. Keep
        # Stalker auto-engine retries on the same URL on a shared deadline.
        auto_retry = (self._auto_engine and self.source.get("type") == "stalker"
                      and bool(self._liveStartupPending)
                      and self._liveStartupIndex == self.index
                      and len(self._engine_attempted) > 1)
        if not auto_retry:
            self._cancelLiveStartup()
        self._cancelLiveResolve()
        # A failed channel may consume all automatic decoder alternatives.
        # Re-arm them on a NEW selection, not on same-URL engine retries.
        # Never overwrite an explicitly selected engine or a learned working
        # engine. Keep the current service type as first attempt.
        if (identity != getattr(self, '_liveAttemptKey', None) and
                self.source.get('type') == 'stalker' and self._auto_engine):
            try:
                available = [int(v) for v, _label in _available_service_types()]
                self._engine_candidates = [v for v in (4097, 5002, 5001)
                                           if v in available and v != int(self.service_type)]
                self._engine_attempted = [int(self.service_type)]
            except Exception:
                self._engine_candidates = []
                self._engine_attempted = [int(self.service_type)]
        self._liveAttemptKey = identity

        # Stalker create_link can take seconds. Resolve it in a worker so
        # Enigma2 never blocks and never shows its system Loading spinner.
        if self.source.get("type") == "stalker":
            self._liveResolveToken += 1
            token = self._liveResolveToken
            handle = TaskHandle(token, "stalker_live_link") if TaskHandle else None
            self._liveResolveHandle = handle
            index = int(self.index)
            selected = dict(item or {})
            self._liveResolveResult = None
            self._liveResolvePending = True
            _stalker_note('LINK_BEGIN', has_client=int(get_source_client is not None))
            self._liveResolveStartedAt = time.time()
            self._liveResolveDeadline = self._liveResolveStartedAt + LIVE_RESOLVE_TIMEOUT_SECONDS

            try:
                self["channel"].setText(selected.get("name") or selected.get("title") or "IPTV")
                self["counter"].setText("%d / %d" % (index + 1, len(self.channels)))
            except Exception:
                pass

            # Snapshot the provider before leaving the GUI thread; mixed
            # favorites can switch providers while an old link is resolving.
            client_source = dict(self.source or {})
            def worker():
                url = ""
                try:
                    if token != self._liveResolveToken or (handle is not None and handle.cancelled()):
                        return
                    # Ultra client sessions contain mutable auth/cookies. Reuse
                    # only within this executor worker, never across GUI/EPG or
                    # watchdog threads (same Ultra policy as list and Windows).
                    if get_source_client is None:
                        _stalker_note('LINK_CLIENT_MISSING')
                    else:
                        client = live_playback_client(client_source, get_source_client)
                        if client is not None and token == self._liveResolveToken:
                            url = client.stream_url(selected, "live", cancel_event=handle) or ""
                            scheme, ext = _stalker_url_kind(url)
                            _stalker_note('LINK_RESULT', status=('ok' if url else 'empty'), scheme=scheme, format=ext)
                        elif client is None:
                            _stalker_note('LINK_CLIENT_MISSING')
                except Exception as exc:
                    _stalker_note('LINK_EXCEPTION', error=type(exc).__name__)
                    # A failed transport can poison a worker-local session.
                    # Cancellation isn't a transport failure: retain its cache.
                    if not (handle is not None and handle.cancelled()):
                        invalidate_live_playback_client(client_source)
                    try:
                        stalker_log("PLAYER async resolve failed channel=%s error=%s" % (
                            selected.get("name") or selected.get("title") or "", exc))
                    except Exception:
                        pass
                if handle is not None and handle.cancelled():
                    return
                if token == self._liveResolveToken and self._liveResolvePending:
                    self._liveResolveResult = (token, index, selected, url)

            # The UltraStalker lazy executor keeps concurrent link resolves
            # bounded. Queued superseded channel jobs are cancelled, not run.
            try:
                if STALKER_LIVE_EXECUTOR is not None:
                    future = STALKER_LIVE_EXECUTOR.submit(
                        worker, _task_key=("live", id(self)), _replace_task_key=True
                    )
                    if handle is not None:
                        handle.future = future
                else:
                    thread = thread_factory(target=worker, name="TiviMateStalkerCreateLink")
                    thread.daemon = True
                    thread.start()
            except Exception as exc:
                self._cancelLiveResolve()
                self._liveStartFailure(tr("Channel link unavailable."))
                return
            try:
                self._liveResolveTimer.start(50, True)
            except Exception:
                pass
            return

        # Xtream/M3U links are local/cheap and keep the existing fast path.
        url = self._urlFor(item)
        if not url:
            self._liveStartFailure(tr("Channel link unavailable."))
            return
        self._playResolvedCurrent(item, url, self.index)


    def _sendStalkerWatchdog(self):
        if getattr(self, "_replayMenuPlaying", False):
            return
        if self.source.get("type") != "stalker" or not self._livePlaybackConfirmed:
            return
        source = dict(self.source or {})
        # A portal can hang forever on keepalive. Do not spawn another
        # unbounded thread every 30 seconds for the same stuck request.
        if getattr(self, '_watchdogBusy', False):
            try: self._watchdog_timer.start(30000, True)
            except Exception: pass
            return
        self._watchdogBusy = True
        def worker():
            try:
                # Ultra sessions may only be used by their owning thread.
                client = live_playback_client(source, get_source_client)
                if client is not None:
                    client.watchdog()
            except Exception:
                invalidate_live_playback_client(source)
            finally:
                self._watchdogBusy = False
        try:
            from .stalker_live_pool import STALKER_WATCHDOG_EXECUTOR
            STALKER_WATCHDOG_EXECUTOR.submit(
                worker, _task_key=("player-watchdog", id(self)), _replace_task_key=True)
        except Exception:
            self._watchdogBusy = False
        try: self._watchdog_timer.start(30000, True)
        except Exception: pass

    def _videoIsReady(self):
        """Conservative startup proof, scoped to THIS Enigma2 service.

        Video dimensions alone can be metadata left by the preceding channel.
        Wait for this service's evStart and two stable samples.  Enigma2 does
        not expose a portable decoded-frame/audio confirmation API here; this
        check deliberately does not claim that sound was verified.
        """
        try:
            if not self._liveStartupPending or not self._liveServiceStarted:
                return False
            playing = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            if not playing or not expected or playing.toString() != expected.toString():
                self._liveVideoProbeSize = None
                self._liveVideoProbeAt = 0.0
                return False
            service = self.session.nav.getCurrentService()
            info = service and service.info()
            if not info:
                return False
            width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
            height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
            if width <= 0 or height <= 0:
                self._liveVideoProbeSize = None
                self._liveVideoProbeAt = 0.0
                return False
            size = (width, height)
            now = time.time()
            if size != self._liveVideoProbeSize:
                self._liveVideoProbeSize = size
                self._liveVideoProbeAt = now
                return False
            return bool(now - self._liveVideoProbeAt >= 0.75)
        except Exception:
            return False

    def _audioOnlyIsReady(self):
        """Accept declared audio-only Live streams without a fictitious video.

        Enigma can provide an audio-only channel with a permanent 0x0 video
        geometry. Previously all such channels waited until startup timeout
        and were incorrectly stopped. Do NOT infer audio-only from missing
        dimensions alone: that also happens while a video stream buffers.
        Require an explicitly absent video PID and valid audio PID/track,
        with two stable readings from the expected current service.
        """
        try:
            if not self._liveStartupPending or not self._liveServiceStarted:
                self._liveAudioProbeAt = 0.0
                return False
            nav = self.session.nav
            playing = nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            if not playing or not expected or playing.toString() != expected.toString():
                self._liveAudioProbeAt = 0.0
                return False
            if time.time() - self._liveStartupAt < 3.0:
                return False
            service = nav.getCurrentService()
            info = service and service.info()
            if not info:
                return False
            # Missing PID support is UNKNOWN, not proof of audio-only.
            video_pid_type = getattr(iServiceInformation, "sVideoPID", None)
            audio_pid_type = getattr(iServiceInformation, "sAudioPID", None)
            if video_pid_type is None or audio_pid_type is None:
                return False
            if int(info.getInfo(video_pid_type)) != -1 or int(info.getInfo(audio_pid_type)) < 0:
                self._liveAudioProbeAt = 0.0
                return False
            tracks = service.audioTracks()
            if not tracks or int(tracks.getNumberOfTracks()) <= 0:
                self._liveAudioProbeAt = 0.0
                return False
            if not self._liveAudioProbeAt:
                self._liveAudioProbeAt = time.time()
                return False
            return (time.time() - self._liveAudioProbeAt >= 0.75)
        except Exception:
            self._liveAudioProbeAt = 0.0
            return False

    def _verifyAutoEngine(self):
        if self.source.get("type") != "stalker" or not self._auto_engine:
            return
        # Never restart a completed, cancelled or expired channel. In
        # particular a late engine timer must not keep a broken stream alive.
        if not self._liveStartupPending or self._liveStartupIndex != self.index:
            return
        if time.time() >= self._liveStartupDeadline:
            self._checkLiveStartup()
            return
        if self._videoIsReady() or self._audioOnlyIsReady():
            # Centralize confirmation and engine persistence in one place.
            self._checkLiveStartup()
            return
        # The first engine may already be furnishing new-service dimensions
        # while the two-sample decoder proof settles. Do not zap it away
        # prematurely. This grace can occur only once per engine attempt.
        if not getattr(self, '_liveEngineMediaGraceUsed', False):
            try:
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                service = self.session.nav.getCurrentService()
                info = service and service.info()
                expected = getattr(self, 'current_ref', None)
                if (active is not None and expected is not None and
                        active.toString() == expected.toString() and
                        self._liveServiceStarted and info is not None and
                        int(info.getInfo(iServiceInformation.sVideoWidth) or 0) > 0 and
                        int(info.getInfo(iServiceInformation.sVideoHeight) or 0) > 0 and
                        self._liveStartupDeadline - time.time() > 1.8):
                    self._liveEngineMediaGraceUsed = True
                    self._engine_timer.start(800, True)
                    return
            except Exception:
                pass
        if not self._engine_candidates:
            # Exhaustion applies to this channel only. Do not globally disable
            # auto-engine after one bad stream: a different channel might
            # work on another engine. A proven engine is persisted elsewhere.
            stalker_log("AUTO ENGINE exhausted attempted=%s" % self._engine_attempted)
            return
        if not self.current_url:
            return
        next_engine = int(self._engine_candidates.pop(0))
        self.service_type = next_engine
        self._engine_attempted.append(next_engine)
        stalker_log("AUTO ENGINE try service_type=%s" % next_engine)
        self["hint"].setText("Auto engine: %s" % next_engine)
        # The URL was already resolved for this exact channel. Retrying the
        # playback engine must not repeat slow Stalker create_link requests.
        self._playResolvedCurrent(self._current(), self.current_url, self.index)

    def cycleServiceType(self):
        values = [value for value, _label in _available_service_types()]
        try:
            pos = values.index(int(self.service_type))
        except Exception:
            pos = 0
        self.service_type = values[(pos + 1) % len(values)]
        _save_service_type(self.service_type)
        if self.source.get("type") == "stalker":
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE CC   EPG" % self.service_type)
        self.playCurrent()

    def _catchupDecodeText(self, value):
        try:
            text_type = unicode
        except NameError:
            text_type = str
        raw = value or ""
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8", "replace")
        elif not isinstance(raw, text_type):
            raw = text_type(raw)
        raw = raw.strip()
        try:
            if raw and re.match(r"^[A-Za-z0-9+/=]+$", raw) and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw).decode("utf-8").strip()
                if decoded and any(ch.isalnum() for ch in decoded) and all(ch.isprintable() if hasattr(ch, "isprintable") else ord(ch) >= 32 for ch in decoded):
                    return decoded
        except Exception:
            pass
        return raw

    def _catchupTimestamp(self, row, begin=True):
        row = row or {}
        keys = ("start_timestamp", "begin_timestamp", "start", "begin", "date_start") if begin else (
            "stop_timestamp", "end_timestamp", "stop", "end", "date_end"
        )
        for key in keys:
            raw = row.get(key)
            if raw in (None, ""):
                continue
            try:
                value = int(float(str(raw)))
                if value > 100000000000:
                    value = int(value / 1000)
                if value > 1000000000:
                    return value
            except Exception:
                pass
            text = str(raw or "").strip().replace("T", " ")
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d:%H-%M"):
                try:
                    return int(time.mktime(time.strptime(text[:19], fmt)))
                except Exception:
                    pass
        return 0

    def _replayMenuIdentity(self):
        item = self._current() or {}
        source = item.get("_favorite_source") or self.source or {}
        channel_id = (item.get("stream_id") or item.get("id") or item.get("ch_id")) if source.get("type") == "xtream" else (item.get("ch_id") or item.get("stream_id") or item.get("id"))
        return (dict(source), str(channel_id or ""), self.index)

    def _replayMenuStart(self, work, stage):
        if getattr(self, "_replayMenuBusy", False):
            return
        self._replayMenuBusy = True
        self._replayMenuToken = getattr(self, "_replayMenuToken", 0) + 1
        token = self._replayMenuToken
        self._replayMenuResult = None
        self._replayMenuDeadline = time.time() + 60
        self._replayMenuStage = stage
        self["hint"].setText(tr("Loading catch-up channels...") if stage == "events" else tr("Opening catch-up..."))
        self.showInfobar()
        def worker():
            try:
                result = (True, work())
            except Exception:
                result = (False, None)
            if token == getattr(self, "_replayMenuToken", None):
                self._replayMenuResult = result
        thread = threading.Thread(target=worker, name="TiviMateReplayMenu")
        thread.daemon = True
        thread.start()
        self._catchup_timer.start(150, True)

    def openCatchupFromInfobar(self):
        if getattr(self, "_replayMenuBusy", False):
            return
        item = dict(self._current() or {})
        source, channel_id, index = self._replayMenuIdentity()
        mode = source.get("type")
        if not channel_id or mode not in ("xtream", "stalker"):
            self.session.open(MessageBox, tr("Catch-up is not available for this channel."), MessageBox.TYPE_INFO, timeout=4)
            return
        self._replayMenuChannel = (source, channel_id, index)
        self._catchup_item = item
        def work():
            from .replay_compat import archive_flag, archive_days, event_time
            client = XtreamClient(source) if mode == "xtream" else StalkerClient(source)
            # Favorites / older cache may omit archive flags. Resolve only the
            # exact channel from its provider, never substitute another stream.
            if not archive_flag(item):
                try:
                    cid = str(item.get("category_id") or item.get("genre_id") or "")
                    rows = client.streams("live", cid) if mode == "xtream" else client.channels()
                    for row in rows or []:
                        rid = str((row.get("stream_id") or row.get("id") or row.get("ch_id") or "") if mode == "xtream" else (row.get("ch_id") or row.get("stream_id") or row.get("id") or ""))
                        if rid == channel_id:
                            item.update(row)
                            break
                except Exception:
                    pass
            days = archive_days(item)
            if mode == "xtream":
                rows = client.catchup_epg(channel_id, epg_channel_id=str(item.get("epg_channel_id") or item.get("epg_id") or ""))
            else:
                rows = client.catchup_programs(channel_id, hours=min(168, days * 24) if days else 72)
            now = int(time.time())
            seen = set()
            events = []
            for row in rows or []:
                if not isinstance(row, dict):
                    continue
                begin, end = event_time(row, True), event_time(row, False)
                if not begin or not end or not begin < end <= now or (days and begin < now - days * 86400):
                    continue
                if not (archive_flag(item) or archive_flag(row)):
                    continue
                event_channel = str(row.get("ch_id") or (row.get("stream_id") if mode == "xtream" else row.get("channel_id")) or "")
                if event_channel and event_channel != channel_id:
                    continue
                if mode == "stalker" and any(str(row.get(key)).lower() in ("0", "false", "no") for key in ("has_archive", "allow_archive") if row.get(key) is not None) and not archive_flag(row):
                    continue
                title = row.get("title") or row.get("name") or row.get("programme")
                if not title or begin in seen:
                    continue
                seen.add(begin)
                payload = dict(row)
                payload.update({"_begin": begin, "_end": end})
                events.append(payload)
            return sorted(events, key=lambda row: row["_begin"], reverse=True)
        self._replayMenuStart(work, "events")

    def _finishXtreamCatchupFromInfobar(self):
        result = getattr(self, "_replayMenuResult", None)
        if not getattr(self, "_replayMenuBusy", False):
            return
        if self._replayMenuIdentity() != self._replayMenuChannel or time.time() >= self._replayMenuDeadline:
            self._replayMenuToken += 1
            self._replayMenuBusy = False
            self._catchup_timer.stop()
            self["hint"].setText("")
            if self._replayMenuIdentity() == self._replayMenuChannel and getattr(self.session, "current_dialog", self) is self:
                self.session.open(MessageBox, tr("Catch-up server did not respond. Please retry."), MessageBox.TYPE_INFO, timeout=5)
            return
        if result is None:
            self._catchup_timer.start(150, True)
            return
        if getattr(self.session, "current_dialog", self) is not self:
            self._catchup_timer.start(150, True)
            return
        self._replayMenuBusy = False
        self._catchup_timer.stop()
        self["hint"].setText("")
        ok, data = result
        if not ok or not data:
            self.session.open(MessageBox, tr("No catch-up programmes are available for this channel.") if ok else tr("Unable to play catch-up"), MessageBox.TYPE_INFO, timeout=5)
            return
        if self._replayMenuStage == "link":
            self._replayMenuPlay(data)
            return
        choices = []
        for row in data:
            title = self._catchupDecodeText(row.get("title") or row.get("name") or row.get("programme"))
            choices.append((u"%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(row["_begin"])), title), row))
        self.session.openWithCallback(self._replayMenuEventSelected, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _replayMenuEventSelected(self, selected=None):
        if not selected or self._replayMenuIdentity() != self._replayMenuChannel:
            return
        source, sid, index = self._replayMenuChannel
        item, event = dict(self._catchup_item or {}), dict(selected[1])
        def work():
            from .replay_compat import xtream_urls
            if source.get("type") == "stalker":
                url = StalkerClient(source).create_catchup_link(item, event)
                if not url:
                    return None
                return (item, event, [url])
            base = str(source.get("url") or "").rstrip("/")
            user, password = str(source.get("username") or ""), str(source.get("password") or "")
            if not (base and user and password and sid):
                return None
            start = time.strftime("%Y-%m-%d:%H-%M", time.localtime(event["_begin"]))
            raw = str(event.get("start") or event.get("begin") or "").replace("T", " ")
            try:
                start = time.strftime("%Y-%m-%d:%H-%M", time.strptime(raw[:16], "%Y-%m-%d %H:%M"))
            except Exception:
                pass
            duration = max(1, int((event["_end"] - event["_begin"] + 59) / 60))
            output = str(source.get("output") or source.get("stream_format") or source.get("format") or "ts").lstrip(".")
            return (item, event, xtream_urls(base, user, password, sid, duration, start, output))
        self._replayMenuStart(work, "link")

    def _replayMenuPlay(self, data):
        try:
            from enigma import eServiceReference
            from .tivimate_player import TiviMatePlayer
            from .ui import _source_identity, _media_service_type
            item, event, urls = data
            source = self._replayMenuChannel[0]
            service_type = _media_service_type(source, "vod")
            title = self._catchupDecodeText(event.get("title") or event.get("name") or event.get("programme")) or item.get("name") or "Catch-up"
            ref = eServiceReference(service_type, 0, urls[0])
            ref.setName(title)
            item.update({"_source_type": source.get("type"), "_source_key": _source_identity(source), "_kind": "vod", "_catchup": True, "_catchup_url": urls[0], "_tivimate_playback_url": urls[0], "_catchup_candidates": urls, "_catchup_service_type": service_type, "_catchup_begin": event["_begin"], "_catchup_end": event["_end"], "name": title})
            self._replayMenuPlaying = True
            self._cancelPendingLiveLink()
            self._cancelLiveStartup()
            self._cancelLiveResolve()
            self._watchdog_timer.stop()
            self._engine_timer.stop()
            self._ib_epg_timer.stop()
            self._epg_timer.stop()
            self._clock_timer.stop()
            self.session.openWithCallback(self._replayMenuPlayerClosed, TiviMatePlayer, ref, item)
        except Exception:
            self._replayMenuPlaying = False
            self.session.open(MessageBox, tr("Unable to play catch-up"), MessageBox.TYPE_INFO, timeout=5)

    def _replayMenuPlayerClosed(self, *args):
        self._replayMenuPlaying = False
        self._liveAttemptKey = None
        self.playCurrent()

    def quickSwitchSatellite(self):
        """TV key: last satellite channel full screen; TV again returns here.

        One video decoder (e.g. Vu+ Zero 4K) cannot show both, so the IPTV
        channel is paused and replayed through the normal zap path on return.
        """
        try:
            from .quick_switch import last_dvb_ref, open_satellite, log as _qs_log
        except Exception as exc:
            try:
                open('/tmp/tivimate_tvswitch.log', 'a').write('import failed: %r\n' % (exc,))
            except Exception:
                pass
            return
        _qs_log('TV key pressed (open=%s)' % getattr(self, '_quickSwitchOpen', False))
        if getattr(self, '_quickSwitchOpen', False):
            return
        if last_dvb_ref() is None:
            try:
                self["hint"].setText("No receiver channel yet - watch one in Enigma2 first")
            except Exception:
                pass
            self.showInfobar()
            return
        # Nothing pending may re-zap IPTV while the satellite plays.
        for name in ('_cancelPendingLiveLink', '_cancelLiveResolve', '_cancelLiveStartup'):
            try:
                getattr(self, name)()
            except Exception:
                pass
        try:
            self._ib_timer.stop()
            self.hide()
        except Exception:
            pass
        self._quickSwitchOpen = True
        try:
            opened = open_satellite(self.session, self._quickSwitchBack)
        except Exception as exc:
            _qs_log('open failed: %r' % (exc,))
            opened = False
        if not opened:
            # Any failure must leave the IPTV player usable, never hidden.
            self._quickSwitchOpen = False
            try:
                self.show()
            except Exception:
                pass
            self.showInfobar()

    def _quickSwitchBack(self, *args):
        self._quickSwitchOpen = False
        if getattr(self, '_ib_closed', False):
            return
        # Force a fresh start of the same IPTV channel (new Stalker link too).
        self._liveAttemptKey = None
        self._livePlaybackConfirmed = False
        try:
            self.playCurrent()
        except Exception:
            pass
        self.showInfobar()

    def openPlayerEngineMenu(self):
        choices = []
        for value, label in _available_service_types():
            prefix = "✓ " if int(value) == int(self.service_type) else ""
            choices.append((prefix + label, value))
        # Keep archive access after reserving INFO for showing the Infobar.
        if (self.source or {}).get("type") in ("xtream", "stalker"):
            choices.append((tr("Catch-up / Archive"), "__catchup__"))
        if (self.source or {}).get("type") in ("xtream", "stalker", "m3u", "fg"):
            choices.append((tr("Refresh Playlist"), "__refresh_playlist__"))
        choices.append(("Receiver channel  (TV key)", "__satellite__"))
        try:
            from .epg_reminders import has as _reminder_has, upcoming as _reminders
            event = getattr(self, "_epgUpcomingEvent", None)
            if event and event[0] > time.time():
                channel = (event[3] or {}).get("name") or (event[3] or {}).get("title") or ""
                clock = time.strftime("%H:%M", time.localtime(event[0]))
                if _reminder_has(event[0], channel, event[2]):
                    choices.append((gui_text(u"Reminder set: %s %s" % (clock, _reminder_u(event[2]))), "__reminders__"))
                else:
                    choices.append((gui_text(tr_text("Remind me: %s %s") % (clock, _reminder_u(event[2]))), "__remind__"))
            if _reminders():
                choices.append((tr("My reminders (%d)") % len(_reminders()), "__reminders__"))
        except Exception:
            pass
        return self._openLiveOptions('LIVE OPTIONS / PLAYER ENGINE', choices, self._playerEngineSelected)

    def _addEpgReminder(self):
        event = getattr(self, "_epgUpcomingEvent", None)
        if not event:
            return
        begin, _stop, title, item = event
        item = dict(item or {})
        channel = item.get("name") or item.get("title") or ""
        try:
            from .epg_reminders import add
            ok = add(self.source, item, begin, title, channel, int(self.service_type or 4097))
        except Exception:
            ok = False
        clock = time.strftime("%H:%M", time.localtime(begin))
        message = gui_text(u"Reminder saved for %s\n%s" % (clock, _reminder_u(title))) if ok else "Could not save the reminder."
        self.session.open(MessageBox, message, MessageBox.TYPE_INFO if ok else MessageBox.TYPE_ERROR, timeout=5)

    def _openEpgReminders(self):
        try:
            from .epg_reminders import upcoming, label
            rows = upcoming()
        except Exception:
            rows = []
        if not rows:
            self.session.open(MessageBox, "No reminders.", MessageBox.TYPE_INFO, timeout=4)
            return
        choices = [(label(row) + "   (OK = delete)", row.get("id")) for row in rows]
        self.session.openWithCallback(self._epgReminderPicked, ChoiceBox,
                                      title="My reminders", list=choices)

    def _epgReminderPicked(self, selected):
        if not selected:
            return
        try:
            from .epg_reminders import remove
            remove(selected[1])
        except Exception:
            pass
        self._openEpgReminders()

    def _playerEngineSelected(self, selected):
        if not selected:
            return
        if selected[1] == "__catchup__":
            return self.openCatchupFromInfobar()
        if selected[1] == "__satellite__":
            return self.quickSwitchSatellite()
        if selected[1] == "__refresh_playlist__":
            from .playlist_refresh import open_refresh_dialog
            return open_refresh_dialog(self.session, self.source)
        if selected[1] == "__remind__":
            return self._addEpgReminder()
        if selected[1] == "__reminders__":
            return self._openEpgReminders()
        value = int(selected[1])
        if value == int(self.service_type):
            return
        self.service_type = value
        _save_service_type(value)
        if self.source.get("type") == "stalker":
            _save_stalker_engine(self.source, self.service_type)
            self._auto_engine = False
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE CC   EPG" % self.service_type)
        self.playCurrent()


    def _recordingBackend(self):
        return stalker_live_recorder

    def toggleLiveRecording(self):
        if self.source.get("type") != "stalker":
            self.session.open(MessageBox, "Live recording is available for Stalker portals only.", MessageBox.TYPE_INFO, timeout=5)
            return
        recorder = self._recordingBackend()
        if recorder.is_recording():
            ok, message = recorder.stop()
            if ok:
                self.session.open(MessageBox, "Live recording stopped.\n%s" % message, MessageBox.TYPE_INFO, timeout=5)
            else:
                self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=5)
            self._restorePlayerEngineAfterRecording()
            return

        item = self._current()
        url = self.current_url or self._urlFor(item)
        if not url:
            self.session.open(MessageBox, "No playable Live URL is available.", MessageBox.TYPE_ERROR, timeout=5)
            return

        self._record_pending_item = dict(item or {})
        self._record_pending_url = url
        self._record_previous_service_type = int(self.service_type)

        # Native Enigma2 recording produced black files with ServiceApp engines
        # (5001/5002) on several images.  Temporarily zap the same channel
        # with 4097, wait for the decoder to lock, then start RecordService.
        if int(self.service_type) != 4097:
            self.service_type = 4097
            self["hint"].setText("Recording engine: 4097")
            self.playCurrent()
            try:
                self._recordStartTimer.stop()
            except Exception:
                self._recordStartTimer = eTimer()
                try:
                    self._recordStartTimer_conn = self._recordStartTimer.timeout.connect(self._startLiveRecordingNow)
                except Exception:
                    try:
                        self._recordStartTimer.callback.append(self._startLiveRecordingNow)
                    except Exception:
                        self._recordStartTimer.timeout.get().append(self._startLiveRecordingNow)
            self.session.open(MessageBox, "Switching temporarily to 4097 for recording...", MessageBox.TYPE_INFO, timeout=3)
            self._recordStartTimer.start(2200, True)
            return

        self._startLiveRecordingNow()

    def _startLiveRecordingNow(self):
        item = getattr(self, "_record_pending_item", None) or self._current() or {}
        url = getattr(self, "_record_pending_url", "") or self.current_url or self._urlFor(item)
        channel = item.get("name") or item.get("title") or "IPTV Live"

        # Stalker links are session-bound and often reject a reused viewing
        # URL. Resolve a new create_link exclusively for this recording.
        if self.source.get("type") == "stalker":
            try:
                client = get_source_client(self.source) if get_source_client else None
                fresh_url = client.stream_url(item, "live") if client is not None else ""
                if not fresh_url:
                    raise RuntimeError("portal returned an empty recording link")
                url = fresh_url
                self._record_pending_url = fresh_url
                stalker_log("RECORD fresh link channel=%s url=%s" % (channel, fresh_url[:180]))
            except Exception as exc:
                self._restorePlayerEngineAfterRecording()
                self.session.open(MessageBox, "Stalker recording link failed.\n%s" % exc, MessageBox.TYPE_ERROR, timeout=8)
                return

        if not url:
            self._restorePlayerEngineAfterRecording()
            self.session.open(MessageBox, "No playable Live URL is available.", MessageBox.TYPE_ERROR, timeout=5)
            return
        try:
            if self.source.get("type") == "stalker":
                # A dedicated 4097 reference is used only by the Stalker
                # recorder. The viewing service remains untouched.
                service_ref = live_reference(self.source, item, 4097, url, channel)
            else:
                service_ref = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            service_ref = None
        recorder = self._recordingBackend()
        ok, message = recorder.start(url, channel, session=self.session, service_ref=service_ref)
        if not ok:
            self._restorePlayerEngineAfterRecording()
            self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=7)
            return
        self.session.open(MessageBox, "Starting Live recording...", MessageBox.TYPE_INFO, timeout=3)
        try:
            self._recordVerifyTimer.stop()
        except Exception:
            self._recordVerifyTimer = eTimer()
            try:
                self._recordVerifyTimer_conn = self._recordVerifyTimer.timeout.connect(self._verifyLiveRecording)
            except Exception:
                try:
                    self._recordVerifyTimer.callback.append(self._verifyLiveRecording)
                except Exception:
                    self._recordVerifyTimer.timeout.get().append(self._verifyLiveRecording)
        self._recordVerifyTimer.start(3500, True)

    def _restorePlayerEngineAfterRecording(self):
        previous = getattr(self, "_record_previous_service_type", None)
        self._record_previous_service_type = None
        self._record_pending_item = None
        self._record_pending_url = ""
        if previous is None or int(previous) == int(self.service_type):
            return
        self.service_type = int(previous)
        self["hint"].setText("Engine: %s   MENU Player Engine   BLUE CC   EPG" % self.service_type)
        self.playCurrent()

    def _verifyLiveRecording(self):
        recorder = self._recordingBackend()
        ok, message = recorder.verify()
        if ok:
            self.session.open(MessageBox, "Live recording started.\n%s" % message, MessageBox.TYPE_INFO, timeout=5)
            return
        if recorder.is_recording():
            try:
                self._recordVerifyTimer.start(2500, True)
            except Exception:
                pass
            return
        self._restorePlayerEngineAfterRecording()
        self.session.open(MessageBox, "Recording failed.\n%s" % message, MessageBox.TYPE_ERROR, timeout=8)

    def _liveSubtitleSessionStore(self):
        # Subtitle reuse after reopening Live was a cache by another name.
        return {}

    def _savePreservedLiveSubtitle(self):
        # Subtitles are session-only; never save the selected path or delay.
        self._discardPreservedLiveSubtitle()

    def _discardPreservedLiveSubtitle(self):
        try:
            self.source.pop("_tivimate_live_subtitle_session", None)
        except Exception:
            pass

    def _restorePreservedLiveSubtitle(self, item=None):
        self._discardPreservedLiveSubtitle()
        return False

    def _clearSubsSupport(self):
        """Release every Live subtitle controller reference as one lifecycle."""
        controllers = (
            getattr(self, "_external_subs", None),
            getattr(self, "_subssupport", None),
            getattr(self, "_tivimate_subtitles", None),
            getattr(self, "_tivimate_subtitle_controller", None),
        )
        _old_sub = getattr(self, "_external_subtitle_path", "") or ""
        self._external_subs = None
        self._subssupport = None
        self._tivimate_subtitles = None
        self._tivimate_subtitle_controller = None
        self._external_subtitle_path = ""
        self._external_subtitle_owner = ""
        self._subtitle_session_delay_ms = 0
        self._tivimate_subtitle_auto_search_key = None

        seen = set()
        for support in controllers:
            if support is None or id(support) in seen:
                continue
            seen.add(id(support))
            # The engine may emit one final delay event while shutting down;
            # do not call back into a closing Live player.
            try:
                support._tivimateDelayChangedCB = None
            except Exception:
                pass
            try:
                support.hideSubsDialog()
            except Exception:
                pass
            try:
                support.exitSubs()
            except Exception:
                pass
        # A subtitle is a temporary playback file, never a cache entry.
        try:
            _root = os.path.realpath("/tmp/tivimatee2-subtitles") + os.sep
            _path = os.path.realpath(_old_sub) if _old_sub else ""
            if _path.startswith(_root) and os.path.isfile(_path):
                os.remove(_path)
        except Exception:
            pass

    def _liveSubtitleChannelKey(self, item=None):
        item = item or self._current() or {}
        return gui_text(
            item.get("stream_id") or item.get("ch_id") or item.get("id") or
            item.get("url") or item.get("cmd") or item.get("name") or item.get("title") or ""
        ).strip()

    def _prepareLiveSubtitleChannel(self, item=None):
        """Reset subtitle state only when the actual Live channel changes."""
        key = self._liveSubtitleChannelKey(item)
        if key and key != getattr(self, "_live_subtitle_channel_key", ""):
            # Opening the channel list and selecting the same channel creates
            # a fresh player object. Preserve the saved subtitle for this key;
            # it is reattached after the new service emits evStart.
            preserved = self._liveSubtitleSessionStore()
            keep_preserved = (isinstance(preserved, dict) and
                              str(preserved.get("channel_key") or "") == key)
            self._clearSubsSupport()
            if not keep_preserved:
                self._discardPreservedLiveSubtitle()
            self._live_epg_context = {}
            self._live_subtitle_channel_key = key

    def _refreshLiveEpgDetails(self):
        """Paint existing Live EPG description and already-resolved TMDb metadata.

        Never fetch anything here.  This method runs only on the GUI thread.
        """
        pieces = []
        year = text_type(getattr(self, '_infobarPosterYear', '') or u'').strip()
        if len(year) == 4 and year.isdigit():
            pieces.append(year)
        try:
            rating = float(getattr(self, '_infobarPosterRating', 0.0) or 0.0)
            if 0.0 < rating <= 10.0:
                pieces.append('%.1f/10' % rating)
        except (ValueError, TypeError):
            pass
        # No programme synopsis under the Live EPG progress bar on Python 2.7.
        # Keep only the compact year/rating; the full plot stays available to
        # subtitle and poster metadata without being drawn in the Infobar.
        try:
            self['epgDetails'].setText(u'  |  '.join(text_type(v) for v in pieces))
        except Exception:
            pass

    def _setLiveEpgDescription(self, description):
        try:
            value = text_type(description or u'')
            self._liveEpgPlot = u' '.join(value.replace(u'\r', u' ').replace(u'\n', u' ').split())
        except Exception:
            self._liveEpgPlot = u''
        self._refreshLiveEpgDetails()

    def _setLiveEpgContext(self, title="", begin=0, duration=0):
        try:
            begin = int(begin or 0)
        except Exception:
            begin = 0
        try:
            duration = max(0, int(duration or 0))
        except Exception:
            duration = 0
        self._live_epg_context = {
            "title": text_type(title or u"").strip(),
            "begin": begin,
            "duration": duration,
        }

    def _subsSupportEpgContext(self):
        """Return the current Live programme title and elapsed seconds."""
        now = int(time.time())
        context = dict(getattr(self, "_live_epg_context", {}) or {})
        title = text_type(context.get("title") or u"").strip()
        begin = int(context.get("begin") or 0)
        duration = max(0, int(context.get("duration") or 0))
        if title:
            elapsed = max(0, now - begin) if begin else 0
            if duration > 0:
                elapsed = min(elapsed, duration)
            return title, elapsed

        # Xtream and Stalker use provider-direct EPG. Never fall back to
        # EPGImport/local XML for those Live source types.
        item = self._current()
        if str(self.source.get("type") or "") not in ("xtream", "stalker"):
            try:
                current, _upcoming = lookup_channel_epg(self.source, item, now)
                if current and len(current) > 2:
                    begin = int(current[0] or 0)
                    duration = max(0, int(current[1] or 0))
                    title = text_type(current[2] or u"").strip()
                    if title:
                        self._setLiveEpgContext(title, begin, duration)
                        elapsed = max(0, now - begin) if begin else 0
                        if duration > 0:
                            elapsed = min(elapsed, duration)
                        return title, elapsed
            except Exception:
                pass

        # Last-resort UI title.  Strip both a time range and a single leading
        # time used by Stalker EPG, but do not invent programme timing.
        try:
            import re
            title = text_type(self["epgNow"].getText() or u"").strip()
            title = re.sub(r"^\s*\d{1,2}[:.]\d{2}\s*[\-–—]\s*\d{1,2}[:.]\d{2}\s*", "", title).strip()
            title = re.sub(r"^\s*\d{1,2}[:.]\d{2}\s+", "", title).strip()
            if title and title.lower() not in ("no epg data", ""):
                return title, 0
        except Exception:
            pass
        return "", 0

    def _buildLiveSubtitleContext(self):
        item = self._current() or {}
        program_title, elapsed = self._subsSupportEpgContext()
        epg = dict(getattr(self, "_live_epg_context", {}) or {})
        channel_name = text_type(item.get("name") or item.get("title") or self["channel"].getText() or u"").strip()
        channel_id = self._liveSubtitleChannelKey(item)
        return {
            "media_type": "live",
            "source_type": str(self.source.get("type") or ""),
            "channel_name": channel_name,
            "channel_id": channel_id,
            "program_title": text_type(program_title or u"").strip(),
            "begin": int(epg.get("begin") or 0),
            "duration": int(epg.get("duration") or 0),
            "elapsed": int(elapsed or 0),
        }

    def _subsSupportSearchTitle(self):
        context = self._buildLiveSubtitleContext()
        return context.get("program_title") or context.get("channel_name") or ""

    def _showNotification(self, text, kind=None, timeout=4):
        """Show a short Enigma2 message from Live without depending on VOD HUD widgets."""
        try:
            _safe_open_screen(self.session, None, 
                MessageBox,
                str(text),
                MessageBox.TYPE_INFO if kind is None else kind,
                timeout=max(1, int(timeout or 4)),
            )
        except Exception as exc:
            print("[TiviMateE2] live notification failed: %s" % exc)

    def openSubsSupport(self):
        context = self._buildLiveSubtitleContext()
        title = context.get("program_title") or context.get("channel_name") or ""
        try:
            from .subtitle_picker_bridge import open_tivimate_subtitle_search
            if open_tivimate_subtitle_search(self, title, context=context):
                return
        except Exception as exc:
            print("[TiviMateE2] live subtitle search open failed: %s" % exc)
        stage = str(getattr(self, "_tivimate_subtitle_search_error", "") or "initialization")
        self._showNotification("TiviMate Subtitles could not open (%s)." % stage,
                               MessageBox.TYPE_ERROR, timeout=6)

    def _subtitlePickerSource(self):
        """Use the active downloaded file or active SubsSupport engine for RED."""
        from .subtitle_cue_source import get_active_subtitle_rows
        return get_active_subtitle_rows(self)

    def openSubtitleEditor(self):
        """RED: same large subtitle-line picker used by VOD, aligned to current EPG elapsed time."""
        cues, subtitle_list = self._subtitlePickerSource()
        if not subtitle_list:
            return self._liveMenuNotice('EDIT SUBTITLE TIMING', 'No readable subtitle is loaded')
        self._subtitle_picker_cues = cues
        current_index = 0
        try:
            _title, elapsed_sec = self._subsSupportEpgContext()
            playback_ms = max(0, int(float(elapsed_sec or 0) * 1000.0))
            delay_ms = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
            subtitle_time_ms = max(0, playback_ms - delay_ms)
            current_index = len(cues) - 1
            for cue_index, cue in enumerate(cues):
                cue_start_ms = int(cue[0])
                if cue_start_ms >= subtitle_time_ms:
                    current_index = cue_index
                    if cue_index > 0:
                        prev_ms = int(cues[cue_index - 1][0])
                        if abs(subtitle_time_ms - prev_ms) <= abs(cue_start_ms - subtitle_time_ms):
                            current_index = cue_index - 1
                    break
        except Exception:
            current_index = 0
        current_index = max(0, min(current_index, len(subtitle_list) - 1))
        try:
            from Plugins.Extensions.TiviMateE2Py27.subtitle_picker_original import SubtitlePicker
            self._openLivePopup(SubtitlePicker, self._subtitlePickerSelected, subtitle_list, current_index)
        except Exception as exc:
            print("[TiviMateE2] live subtitle picker open failed: %s" % exc)
            return

    def _subtitlePickerSelected(self, selected=None):
        if selected is None:
            return
        fine_ms = 0
        if isinstance(selected, (tuple, list)) and len(selected) >= 2:
            try:
                fine_ms = int(selected[1] or 0)
            except Exception:
                fine_ms = 0
            selected = selected[0]
        try:
            index = int(selected)
        except Exception:
            return
        cues = list(getattr(self, "_subtitle_picker_cues", None) or [])
        if index < 0 or index >= len(cues):
            return
        try:
            _title, elapsed_sec = self._subsSupportEpgContext()
            playback_ms = max(0, int(float(elapsed_sec or 0) * 1000.0))
            cue_start_ms = int(cues[index][0])
            delay_ms = max(-120000, min(120000, playback_ms - cue_start_ms + fine_ms))
            controller = (getattr(self, "_external_subs", None) or getattr(self, "_tivimate_subtitles", None) or getattr(self, "_subssupport", None) or getattr(self, "_tivimate_subtitle_controller", None))
            if controller is None:
                return
            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if callable(setter):
                setter(delay_ms)
            self._subtitle_session_delay_ms = delay_ms
            self._showNotification("Subtitle synchronized: %+.1f sec" % (delay_ms / 1000.0), MessageBox.TYPE_INFO, 2)
        except Exception:
            pass

    def _stepSubtitleDialogue(self, direction):
        """PREVIOUS/NEXT remote buttons select adjacent subtitle *cues*.

        Keep the stream running. Align the chosen cue to the current Live
        program elapsed time; never use the former 200-ms fine-delay behavior.
        """
        try:
            cues, _rows = self._subtitlePickerSource()
            if not cues:
                return
            controller = (getattr(self, "_external_subs", None)
                          or getattr(self, "_tivimate_subtitles", None)
                          or getattr(self, "_subssupport", None)
                          or getattr(self, "_tivimate_subtitle_controller", None))
            if controller is None:
                return
            setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
            if not callable(setter):
                return
            _title, elapsed = self._subsSupportEpgContext()
            playback_ms = max(0, int(float(elapsed or 0) * 1000))
            getter = getattr(controller, "getSubsDelay", None)
            current_delay = int(getattr(self, "_subtitle_session_delay_ms", 0) or 0)
            if callable(getter):
                try:
                    active = getter()
                    if active is not None:
                        current_delay = int(float(active))
                except Exception:
                    pass
            subtitle_ms = playback_ms - current_delay
            previous_index = getattr(self, "_subtitle_cue_step_index", None)
            previous_playback = getattr(self, "_subtitle_cue_step_playback_ms", None)
            # Keep repeated button presses relative to the last selected cue.
            # Recalculate after a major EPG time jump or a fresh subtitle file.
            signature = (getattr(self, "_external_subtitle_path", None), len(cues), cues[0][0], cues[-1][0])
            if (previous_index is not None and
                    getattr(self, "_subtitle_cue_step_signature", None) == signature and
                    previous_playback is not None and
                    abs(playback_ms - previous_playback) < 10000):
                current_index = int(previous_index)
            else:
                current_index = 0
                for idx, cue in enumerate(cues):
                    if int(cue[0]) <= subtitle_ms:
                        current_index = idx
                    else:
                        break
            target_index = max(0, min(len(cues) - 1, current_index + (1 if direction > 0 else -1)))
            if target_index == current_index:
                return
            target_ms = int(cues[target_index][0])
            # Avoid silently jumping to a different cue if the offset cannot
            # be represented by the subtitle engine's supported delay range.
            delay_ms = playback_ms - target_ms
            if not -120000 <= delay_ms <= 120000:
                return
            setter(delay_ms)
            self._subtitle_session_delay_ms = delay_ms
            self._subtitle_cue_step_index = target_index
            self._subtitle_cue_step_playback_ms = playback_ms
            self._subtitle_cue_step_signature = signature
        except Exception as exc:
            print("[TiviMateE2] Live subtitle cue step failed: %s" % exc)

    def subtitleFineMinus(self):
        self._stepSubtitleDialogue(-1)

    def subtitleFinePlus(self):
        self._stepSubtitleDialogue(1)

    def _openLiveOptions(self, title, options, callback):
        """Reuse the working VOD menu (z=35), without changing either renderer."""
        try:
            from .tivimate_player import _TiviMateVODOptions
        except Exception as exc:
            print("[TiviMateE2] live menu import failed: %s" % exc)
            return False
        return self._openLivePopup(_TiviMateVODOptions, callback, options, title)

    def _openLivePopup(self, screen_class, callback, *args):
        """Match the VOD modal lifecycle; raise the popup before readSkin."""
        from .tivimate_player import _tivimate_raise_screen_skin
        player = self
        class RaisedLiveScreen(screen_class):
            def __init__(self, session, *screen_args, **screen_kwargs):
                screen_class.__init__(self, session, *screen_args, **screen_kwargs)
                _tivimate_raise_screen_skin(self, 35)

        def closed(*result):
            player.unlockShow()
            if not player._ib_closed and callable(callback):
                callback(*result)

        self.lockShow()
        try:
            dialog = _safe_open_screen(self.session, closed, RaisedLiveScreen, *args)
        except Exception as exc:
            print("[TiviMateE2] live popup failed: %s" % exc)
            dialog = None
        if dialog is None:
            self.unlockShow()
            return False
        return True

    def openPlayerMenu(self):
        choices = [
            ("Subtitle Search", "subs"),
            ("Server Subtitles", "native_subs"),
            ("Audio Tracks / Language", "audio"),
            ("Edit Subtitle Timing", "subtitle_editor"),
            ("Subtitle Font & Style", "subtitle_style"),
            ("Subtitle Delay", "subtitle_delay"),
            (tr("TV Guide"), "full_day_epg"),
            ("Live Options / Player Engine", "engine"),
        ]
        return self._openLiveOptions('TIVIMATE PLAYER  /  SETTINGS', choices, self._liveMenuSelected)

    def _liveMenuSelected(self, selected=None):
        if not selected:
            return
        actions = {
            "subs": self.openSubsSupport,
            "native_subs": self.openSubtitleSelection,
            "audio": self.audioSelection,
            "subtitle_editor": self.openSubtitleEditor,
            "subtitle_style": self.openSubtitleStyleSettings,
            "subtitle_delay": self.openSubtitleDelay,
            "full_day_epg": self.openFullDayEPG,
            "engine": self.openPlayerEngineMenu,
        }
        action = actions.get(selected[1])
        if action is not None:
            return action()

    def _liveMenuNotice(self, title, message):
        return self._openLiveOptions(title, [(message, None)], None)

    def audioSelection(self):
        """Use the native decoder's audio tracks, with a visible VTi menu."""
        try:
            service = self.session.nav.getCurrentService()
            tracks = service and service.audioTracks()
            count = int(tracks.getNumberOfTracks()) if tracks is not None else 0
            if count <= 0:
                return self._liveMenuNotice('AUDIO TRACKS', 'No audio tracks reported by the stream')
            try:
                active = int(tracks.getCurrentTrack())
            except Exception:
                active = -1
            options = []
            for index in range(count):
                try:
                    info = tracks.getTrackInfo(index)
                    lang = gui_text(info.getLanguage() or '')
                    desc = gui_text(info.getDescription() or '')
                except Exception:
                    lang, desc = '', ''
                description = '  '.join(x for x in (lang, desc) if x) or 'Audio'
                status = '  [ACTIVE]' if index == active else ''
                options.append(('%02d    %s%s' % (index + 1, description, status), index))
            return self._openLiveOptions('AUDIO TRACKS', options, self._liveAudioSelected)
        except Exception as exc:
            self._showNotification('Audio tracks unavailable: %s' % type(exc).__name__, timeout=4)
            return False

    def _liveAudioSelected(self, selected=None):
        if not selected:
            return
        try:
            index = int(selected[1])
            service = self.session.nav.getCurrentService()
            tracks = service and service.audioTracks()
            if tracks is None or not 0 <= index < int(tracks.getNumberOfTracks()):
                return
            tracks.selectTrack(index)
        except Exception as exc:
            self._showNotification('Audio selection failed: %s' % type(exc).__name__, timeout=4)

    def openSubtitleSelection(self):
        """Select real embedded/server tracks using a z=35 modal on VTi."""
        try:
            service = self.session.nav.getCurrentService()
            native_sub = service and service.subtitle()
            rows = list(native_sub.getSubtitleList() or []) if native_sub else []
            options = [('OFF    Disable subtitles', None)]
            current = getattr(self, 'selected_subtitle', None)
            for index, subtitle in enumerate(rows):
                if not isinstance(subtitle, (tuple, list)):
                    continue
                language = ''
                try:
                    for piece in reversed(subtitle):
                        if isinstance(piece, (str, text_type)) and piece:
                            language = gui_text(piece)
                            break
                except Exception:
                    pass
                if not language:
                    language = 'Track %d' % (index + 1)
                try:
                    is_current = tuple(current) == tuple(subtitle)
                except Exception:
                    is_current = False
                status = '  [ACTIVE]' if is_current else ''
                options.append(('%02d    %s%s' % (index + 1, language, status), tuple(subtitle)))
            if len(options) == 1:
                options.append(('No server / embedded subtitle tracks in this stream', 'unavailable'))
            return self._openLiveOptions('SERVER / EMBEDDED SUBTITLES', options,
                                        self._liveServerSubtitleSelected)
        except Exception as exc:
            self._showNotification('Subtitle tracks unavailable: %s' % type(exc).__name__, timeout=5)
            return False

    def _liveServerSubtitleSelected(self, selected=None):
        if not selected or selected[1] == 'unavailable':
            return
        try:
            # Native Live selection only; do not change the external subtitle loader.
            self.enableSubtitle(selected[1])
        except Exception as exc:
            self._liveMenuNotice('SERVER / EMBEDDED SUBTITLES', 'Subtitle selection failed: %s' % type(exc).__name__)

    def openSubtitleStyleSettings(self):
        try:
            from .TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings, TiviMateSetupExternal
            settings = initTiviMateSettings()
            return self._openLivePopup(TiviMateSetupExternal, self._liveSubtitleStyleSaved, settings.external)
        except Exception as exc:
            return self._liveMenuNotice('SUBTITLE STYLE', 'Subtitle style unavailable: %s' % type(exc).__name__)

    def _liveSubtitleStyleSaved(self, *args):
        # Same font-profile/repaint logic as VOD, without editing the VOD file.
        from .tivimate_player import TiviMatePlayer
        fn = TiviMatePlayer._unifiedSubtitleStyleSaved
        return getattr(fn, 'im_func', getattr(fn, '__func__', fn))(self, *args)

    def openSubtitleDelay(self):
        current = int(getattr(self, '_subtitle_session_delay_ms', 0) or 0)
        values = []
        for delay in range(-10000, 10001, 500):
            prefix = "[ACTIVE] " if delay == current else ""
            values.append(("%s%+.1f sec" % (prefix, delay / 1000.0), delay))
        return self._openLiveOptions('SUBTITLE DELAY', values, self._liveSubtitleDelaySelected)

    def _liveSubtitleDelaySelected(self, selected=None):
        if not selected:
            return
        try:
            delay = int(selected[1])
            controller = (self._external_subs or self._tivimate_subtitles or
                          self._subssupport or self._tivimate_subtitle_controller)
            setter = getattr(controller, 'setTiviMateDelay', None) or getattr(controller, 'setSubsDelay', None)
            if callable(setter):
                setter(delay)
                self._subtitle_session_delay_ms = delay
            else:
                self._liveMenuNotice('SUBTITLE DELAY', 'No readable subtitle is loaded')
        except Exception as exc:
            self._liveMenuNotice('SUBTITLE DELAY', 'Subtitle delay failed: %s' % type(exc).__name__)

    def _setLiveTechnicalBadgePixmap(self, widget_name, filename):
        try:
            widget = self[widget_name]
        except Exception:
            return
        if not filename:
            try:
                widget.hide()
            except Exception:
                pass
            return
        if filename.startswith("tb_"):
            path = os.path.join(os.path.dirname(__file__), "skins", "live_infobar", "badges", filename)
        elif filename == "@dolby":
            path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "live", "dolby.png")
        else:
            path = os.path.join(os.path.dirname(__file__), "tivimate_infobar", "common", filename)
        if not os.path.exists(path):
            try:
                widget.hide()
            except Exception:
                pass
            return
        try:
            widget.instance.setPixmapFromFile(path)
        except Exception:
            try:
                widget.setPixmapFromFile(path)
            except Exception:
                return
        try:
            widget.show()
        except Exception:
            pass

    def _liveTechnicalStreamInfo(self):
        """Read already-playing service geometry/codecs; no network request."""
        resolution = aspect = video = audio_name = ""
        service = info = None
        width = height = 0
        try:
            service = self.session.nav.getCurrentService()
            info = service and service.info()
        except Exception:
            pass
        if info is not None:
            try:
                width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
                height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
            except Exception:
                width = height = 0
        if width > 0 or height > 0:
            if width >= 3000 or height >= 1800:
                resolution = "2160p"
            elif width >= 1800 or height >= 1000:
                resolution = "1080p"
            elif width >= 1200 or height >= 700:
                resolution = "720p"
            elif width >= 900 or height >= 560:
                resolution = "576p"
            elif width >= 700 or height >= 460:
                resolution = "480p"
            try:
                ratio = float(width) / float(height) if height else 0.0
                if abs(ratio - (16.0 / 9.0)) < 0.14:
                    aspect = "16:9"
                elif abs(ratio - (4.0 / 3.0)) < 0.11:
                    aspect = "4:3"
                elif 2.18 <= ratio <= 2.52:
                    aspect = "2.35:1"
            except Exception:
                pass
        if info is not None:
            try:
                key = getattr(iServiceInformation, "sVideoType", None)
                if key is not None:
                    raw = info.getInfo(key)
                    video_map = {0:"MPEG2",1:"H.264",3:"VC-1",4:"MPEG4",5:"VC-1",7:"HEVC",8:"VP8",9:"VP9",10:"XVID",11:"AVS",12:"AVS2"}
                    try:
                        iv = int(raw)
                    except Exception:
                        iv = -1
                    video = video_map.get(iv, "")
                    if not video and iv == -2:
                        try:
                            txt = str(info.getInfoString(key) or "").upper()
                        except Exception:
                            txt = ""
                        if "HEVC" in txt or "H265" in txt or "H.265" in txt:
                            video = "HEVC"
                        elif "H264" in txt or "H.264" in txt or "AVC" in txt:
                            video = "H.264"
                        elif "VP9" in txt:
                            video = "VP9"
            except Exception:
                pass
        try:
            tracks = service and service.audioTracks()
            if tracks and int(tracks.getNumberOfTracks()) > 0:
                index = int(tracks.getCurrentTrack())
                desc = str(tracks.getTrackInfo(index).getDescription() or "").upper().replace("_", " ")
                if "E-AC3" in desc or "EAC3" in desc or "EC-3" in desc or "DD+" in desc or "DOLBY DIGITAL PLUS" in desc:
                    audio_name = "E-AC3"
                elif ("AC3" in desc or "AC-3" in desc or "DOLBY DIGITAL" in desc
                      or "A/52" in desc or "A52" in desc or "DD 5.1" in desc
                      or desc.strip() == "DD"):
                    audio_name = "AC3"
                elif "DTS" in desc:
                    audio_name = "DTS"
                elif "AAC" in desc:
                    audio_name = "AAC"
                elif "MP3" in desc or "MPEG LAYER 3" in desc:
                    audio_name = "MP3"
        except Exception:
            pass
        # Some OpenATV service types expose Dolby only through service.info()
        # while the selected track description stays generic. Use that as a
        # fallback only when the track API did not identify the codec.
        if not audio_name and info is not None:
            try:
                audio_key = getattr(iServiceInformation, "sAudioType", None)
                if audio_key is not None:
                    try:
                        atxt = str(info.getInfoString(audio_key) or "").upper().replace("_", " ")
                    except Exception:
                        atxt = ""
                    if "E-AC3" in atxt or "EAC3" in atxt or "EC-3" in atxt or "DD+" in atxt or "DOLBY DIGITAL PLUS" in atxt:
                        audio_name = "E-AC3"
                    elif "AC3" in atxt or "AC-3" in atxt or "A/52" in atxt or "A52" in atxt or "DOLBY DIGITAL" in atxt:
                        audio_name = "AC3"
                    elif "DTS" in atxt:
                        audio_name = "DTS"
                    elif "AAC" in atxt:
                        audio_name = "AAC"
            except Exception:
                pass
        return resolution, aspect, video, audio_name

    def _updateLiveTechnicalBadges(self):
        try:
            resolution, aspect, video, audio_name = self._liveTechnicalStreamInfo()
            resolution_files = {"2160p": "tb_res_2160p.png", "4K": "tb_res_2160p.png", "1080p": "tb_res_1080p.png",
                                "720p": "tb_res_720p.png", "576p": "tb_res_576p.png", "480p": "tb_res_480p.png"}
            aspect_files = {"16:9": "tb_aspect_16_9.png", "4:3": "tb_aspect_4_3.png", "2.35:1": "tb_aspect_2_35_1.png"}
            video_files = {"H.264": "tb_video_h264.png", "HEVC": "tb_video_hevc.png", "VP9": "tb_video_vp9.png", "VP8": "tb_video_vp8.png",
                           "MPEG2": "tb_video_mpeg2.png", "MPEG4": "tb_video_mpeg4.png", "VC-1": "tb_video_vc1.png",
                           "XVID": "tb_video_xvid.png", "AVS": "tb_video_avs.png", "AVS2": "tb_video_avs2.png"}
            audio_files = {"AAC": "tb_audio_aac.png", "AC3": "tb_audio_ac3.png", "E-AC3": "tb_audio_eac3.png",
                           "DTS": "tb_audio_dts.png", "MP3": "tb_audio_mp3.png"}
            last = getattr(self, "_liveTechBadgeValues", {}) or {}
            if resolution in resolution_files: last["resolution"] = resolution
            if aspect in aspect_files: last["aspect"] = aspect
            if video in video_files: last["video"] = video
            if audio_name in audio_files: last["audio"] = audio_name
            self._liveTechBadgeValues = last
            self._setLiveTechnicalBadgePixmap("resolutionBadge", resolution_files.get(last.get("resolution")))
            self._setLiveTechnicalBadgePixmap("aspectBadge", aspect_files.get(last.get("aspect")))
            self._setLiveTechnicalBadgePixmap("videoBadge", video_files.get(last.get("video")))
            self._setLiveTechnicalBadgePixmap("audioBadge", audio_files.get(last.get("audio")))
        except Exception:
            pass

    def _ultraLiveStartEventCurrent(self):
        """Apply Ultra's current-service guard to evStart as well as EOF.

        When a fresh Stalker create_link is pending, Enigma2 may still be
        playing the previous channel. Its late evStart must not refresh the
        new channel's EPG, infobar or subtitles. Unlike EOF, a matching evStart
        is allowed during the short zap suppression grace: otherwise valid
        start events could be lost on fast decoders.
        """
        if getattr(self, '_liveResolvePending', False):
            return False
        if not (getattr(self, '_liveStartupPending', False) or
                getattr(self, '_livePlaybackConfirmed', False)):
            return False
        try:
            expected = getattr(self, 'current_ref', None)
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            return bool(expected is not None and active is not None and
                        expected.toString() == active.toString())
        except Exception:
            return False

    def _serviceStarted(self):
        if getattr(self, "_replayMenuPlaying", False):
            return
        # Ultra player_golden57._event_matches_current_reference: a late
        # evStart from the last channel must never touch the current UI.
        if not self._ultraLiveStartEventCurrent():
            return
        # Never attribute a delayed evStart from another service to this tune.
        # Ultra captures external ServiceApp processes after evStart, since
        # they can spawn asynchronously after Navigation.playService returns.
        try:
            expected = getattr(self, 'current_ref', None)
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            if (expected is not None and active is not None and
                    expected.toString() == active.toString() and
                    getattr(self, '_ultraExternalUrl', '')):
                self._ultraDecoderGuard.capture(self._ultraExternalUrl)
        except Exception:
            pass
        if self._liveStartupPending:
            try:
                current = self.session.nav.getCurrentlyPlayingServiceReference()
                expected = getattr(self, "current_ref", None)
                if current and expected and current.toString() == expected.toString():
                    self._liveServiceStarted = True
            except Exception:
                pass
        # evStart does not mean there is a decoded frame. The startup check
        # continues only until real video dimensions are available.
        if self._liveStartupPending:
            self._checkLiveStartup()
        # Selecting the same channel from the list can create a new player
        # and restart the native service. Reattach the saved external file so
        # RED still shows the track and the rendered subtitles do not vanish.
        if (not getattr(self, "_external_subtitle_path", "") and
                isinstance(self._liveSubtitleSessionStore(), dict)):
            try:
                self._restorePreservedLiveSubtitle(self._current())
            except Exception:
                pass
        # r522: evStart can arrive before all decoder metadata is populated.
        # Read once immediately, then temporarily reuse the existing clock
        # timer for quick local badge refreshes. EPG scheduling is unchanged.
        if not self._liveStartupPending:
            # A late/instant evStart must not block the GUI/decoder with PNG
            # badge decoding. Defer it through the existing clock timer.
            self._liveTechFastRefresh = max(3, int(getattr(self, '_liveTechFastRefresh', 0) or 0))
            if not getattr(self, '_epg_ready', False):
                self._scheduleEpg()
        try:
            if getattr(self, "_liveTechFastRefresh", 0) > 0:
                self._clock_timer.start(1000, False)
        except Exception:
            pass
        # The tune path owns visibility; duplicate evStart must not reopen OSD.

    def _favoriteSafeZap(self, delta):
        # CH+/CH- is an ActionMap callback: an uncaught provider/item exception
        # here restarts Enigma2. Keep the existing player and service list alive.
        if not self.channels:
            return
        old_index = self.index
        try:
            self.index = (self.index + int(delta)) % len(self.channels)
            if self.index != old_index:
                self._clearLiveEpgUi(artwork_fallback=False)
                self._infobarPiconPending = None
                self._infobarPiconReqId = int(getattr(self, '_infobarPiconReqId', 0) or 0) + 1
            self.playCurrent()
        except Exception as exc:
            self.index = old_index
            try:
                print("[TiviMateE2] Live zap failed safely: %r" % (exc,))
            except Exception:
                pass

    def nextChannel(self):
        self._favoriteSafeZap(1)

    def prevChannel(self):
        self._favoriteSafeZap(-1)
    def _showInfobarPosterFallback(self):
        """Keep the oval frame and its TiViMate logo visible if artwork is missing."""
        try:
            self["livePoster"].hide()
            self["backdropFrame"].show()
            self._infobarPosterPath = ""
        except Exception:
            pass

    def _scheduleInfobarPoster(self, title, description=""):
        title = text_type(title or "").strip()
        item = self._current() or {}
        key = (self.index, text_type(item.get("name") or item.get("title") or ""), title)
        if (title and key == self._livePosterKey and
                (self._infobarPosterPath or monotonic() < self._livePosterRetryAt)):
            return
        self._livePosterKey = key
        self._livePosterRetryAt = monotonic() + 45.0
        self._livePosterJob = None
        try: _INFOBAR_ART_EXECUTOR.cancel_task(("infobar-art", id(self)))
        except Exception: pass
        self._infobarPosterYear = ""
        self._infobarPosterRating = 0.0
        self._refreshLiveEpgDetails()
        self._livePosterToken += 1
        token = self._livePosterToken
        self._infobarFootballFixture = None
        self._infobarEpgDescription = ""
        self._infobarPosterPath = ""
        self._livePillRequestSeq += 1  # invalidate previous channel's pending crop
        self._infobarPosterDecodeToken = -1
        try:
            self._livePosterTimer.stop()
            self._livePosterPoll.stop()
            self["livePoster"].hide()
            self["backdropFrame"].show()
        except Exception:
            pass
        enabled = str(self.source.get("show_live_infobar_poster", True)).strip().lower() in ("1","true","yes","on","enabled")
        _live_diag_log(self.source, self._current(), "poster_schedule", enabled=enabled, title=title)
        if not enabled:
            return
        # Use the same title cleanup as the Live browser.  This only changes
        # the copy sent to TMDb; the displayed EPG title is untouched.
        clean = text_type(title or u"").strip()
        clean = re.sub(r"^\s*\[(?:HD|FHD|UHD|4K|HEVC|H265|H264|AR|ARA|EN|ENG)\]\s*", "", clean, flags=re.I)
        clean = re.sub(r"\s*\[(?:HD|FHD|UHD|4K|HEVC|H265|H264|AR|ARA|EN|ENG)\]\s*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*\((?:HD|FHD|UHD|4K|HEVC|H\.?265|H\.?264|AR|ARA|EN|ENG)\)\s*$", "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*[Ss]\s*\d{1,2}\s*[Ee]\s*\d{1,3}\b.*$".decode("utf-8"), "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*(?:EP(?:ISODE)?\.?|E)\s*#?\d{1,3}\b.*$".decode("utf-8"), "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*(?:الحلقة|حلقة)\s*\d{1,3}\b.*$".decode("utf-8"), "", clean, flags=re.I)
        clean = re.sub(r"\s*[\-–—|:]?\s*(?:الموسم)\s*\d{1,2}\s*(?:الحلقة|حلقة)\s*\d{1,3}\b.*$".decode("utf-8"), "", clean, flags=re.I)
        clean = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", clean)
        clean = re.sub(r"(?:\s*[\-–—|]\s*)?(?:HD|FHD|UHD|4K|1080P|720P|HEVC|H\.?265|H\.?264)\s*$".decode("utf-8"), "", clean, flags=re.I)
        clean = re.sub(r"\s+".decode("utf-8"), " ", clean).strip(u" -–—:|")
        if not clean:
            channel_name = text_type((self._current() or {}).get("name") or "")
            # A club-specific TV channel can display that club's fanart even
            # without EPG. Generic beIN/SSC channels cannot identify a match.
            self._infobarFootballFixture = classify_football("", gui_text(channel_name))
            if self._infobarFootballFixture:
                self._infobarPosterTitle = channel_name
                try: self._livePosterTimer.start(120, True)
                except Exception: self._startInfobarPosterLookup()
            else:
                _log_sports('no_epg_or_team')
                self._showInfobarPosterFallback()
            return
        self._infobarPosterTitle = clean
        # Football is a separate provider path: do not reuse a movie backdrop
        # from this title or show an old match's image as a current event.
        current_item = self._current() or {}
        channel_name = text_type(current_item.get("name") or current_item.get("title") or "")
        self._infobarFootballFixture = classify_football(gui_text(clean), gui_text(channel_name), gui_text(description))
        self._infobarEpgDescription = text_type(description or u"")[:300]
        if self._infobarFootballFixture:
            try: self._livePosterTimer.start(120, True)
            except Exception: self._startInfobarPosterLookup()
            return

        # Never mistake a generic football EPG entry for a TMDb film. If the
        # feed provides no club/match information, keep the TiViMate oval logo.
        if re.search(r"(?i)\b(?:football|soccer|live match|soccer live)\b|كرة\s*القدم|مباراة|مباراه|الدوري|كأس|كاس".decode("utf-8"), clean):
            _log_sports('sports_epg_without_identifiable_team')
            self._showInfobarPosterFallback()
            return

        key = re.sub(r"\s+", " ", clean.strip().lower())
        backdrop_url = str(_load_live_infobar_backdrops().get(key) or "").strip()
        if backdrop_url:
            cached = cached_artwork(backdrop_url, "backdrops") if cached_artwork else None
            if cached:
                self._showInfobarPoster(cached, token)
            else:
                def ready_backdrop(path):
                    if path and os.path.exists(path):
                        self._showInfobarPoster(path, token)
                request_artwork(backdrop_url, kind="backdrops", callback=ready_backdrop, priority=250)
            return

        # Do not reuse cached vertical movie posters in the Live infobar.
        # The Live list can keep using its own poster cache independently.
        try:
            self._livePosterTimer.start(120, True)
        except Exception:
            self._startInfobarPosterLookup()

    def _startInfobarPosterLookup(self):
        title = getattr(self, "_infobarPosterTitle", "")
        token = self._livePosterToken
        if not title or self._livePillClosed:
            return
        if self._livePosterJob is not None and self._livePosterJob[0] == token:
            return
        job = [token, None, monotonic() + 30.0]
        self._livePosterJob = job
        fixture = getattr(self, "_infobarFootballFixture", None)
        channel = (self._current() or {}).get("name") or (self._current() or {}).get("title") or ""
        description = getattr(self, "_infobarEpgDescription", "")
        def worker():
            if self._livePillClosed or token != self._livePosterToken:
                return
            if fixture:
                # Distinct metadata provider for matches; keep TMDb movie/series
                # titles unchanged and never fall back to unrelated film art.
                try:
                    sports_url, _matched = resolve_football_art(gui_text(title), gui_text(channel), description=gui_text(description))
                except Exception:
                    sports_url = ""
                _log_sports('football_worker_done', artwork_found=bool(sports_url), matches=bool(fixture))
                job[1] = (token, sports_url, 0.0, "", "backdrops", "", True, "")
                return
            url = ""
            rating = 0.0
            year = ""
            poster_path = ""
            overview = ""
            try:
                client = TMDbClient()
                movie = client.search_artwork(title, "vod", required_key="backdrop_path") or {}
                series = {} if movie else (client.search_artwork(title, "series", required_key="backdrop_path") or {})
                result = movie or series or {}
                backdrop_path = result.get("backdrop_path") or ""
                poster_path = result.get("poster_path") or ""
                overview = result.get("overview") or ""
                if backdrop_path:
                    url = "https://image.tmdb.org/t/p/w780" + backdrop_path
                try:
                    rating = float(result.get("vote_average") or result.get("rating") or 0.0)
                except Exception:
                    rating = 0.0
                date_value = str(result.get("release_date") or result.get("first_air_date") or "")
                if len(date_value) >= 4 and date_value[:4].isdigit():
                    year = date_value[:4]
            except Exception:
                pass
            poster_url = ("https://image.tmdb.org/t/p/w342" + poster_path) if poster_path else ""
            job[1] = (token, url, rating, year, "backdrops", poster_url, False, overview)
        try:
            future = _INFOBAR_ART_EXECUTOR.submit(worker, _task_key=("infobar-art", id(self)), _replace_task_key=True)
            if future.done() and future.exception() is not None:
                self._livePosterJob = None
                return
        except Exception:
            self._livePosterJob = None
            return
        try:
            self._livePosterPoll.start(120, True)
        except Exception:
            pass

    def _finishInfobarPosterLookup(self):
        try:
            self._livePosterPoll.stop()
        except Exception:
            pass
        job = self._livePosterJob
        if self._livePillClosed or job is None or job[0] != self._livePosterToken:
            return
        result = job[1]
        if result is None:
            if monotonic() < job[2]:
                try:
                    self._livePosterPoll.start(120, True)
                except Exception:
                    pass
            else:
                self._livePosterJob = None
            return
        self._livePosterJob = None
        token, url, rating, year, art_kind, poster_url, is_football, overview = result
        if token != self._livePosterToken:
            return
        _live_diag_log(self.source, self._current(), "poster_lookup", found=bool(url), title=getattr(self, "_infobarPosterTitle", ""), rating=rating, year=year)
        if not url:
            # Keep the programme poster already resolved by the Live list.
            if not getattr(self, "_infobarPosterPath", ""):
                self._showInfobarPosterFallback()
            return
        self._infobarPosterRating = rating
        self._infobarPosterYear = year
        # Search artwork already returned a TMDb overview; reuse it only when
        # EPG supplied no description. No additional lookup or worker.
        if not getattr(self, '_liveEpgPlot', u'') and overview and not is_football:
            self._setLiveEpgDescription(overview)
        else:
            self._refreshLiveEpgDetails()
        self._infobarArtworkKind = "backdrops"
        # Feed the exact poster resolved by the infobar back to the Live list.
        # This avoids a second TMDb search when the user leaves full-screen.
        try:
            if poster_url:
                _remember_infobar_live_poster(getattr(self, "_infobarPosterTitle", ""), poster_url)
            if art_kind == "backdrops" and not is_football:
                _remember_live_infobar_backdrop(getattr(self, "_infobarPosterTitle", ""), url)
        except Exception:
            pass
        cached = cached_artwork(url, "backdrops") if cached_artwork else None
        if cached:
            if is_football: _log_sports('sports_image_cached')
            self._showInfobarPoster(cached, token)
            return
        def ready(path):
            if is_football: _log_sports('sports_image_download', ok=bool(path and os.path.exists(path)))
            if path and os.path.exists(path):
                self._showInfobarPoster(path, token)
            elif token == self._livePosterToken:
                self._showInfobarPosterFallback()
        def failed(_reason=None):
            if is_football: _log_sports('sports_download_failed')
        request_artwork(url, kind="backdrops", callback=ready, priority=250, errback=failed)

    def _showInfobarPoster(self, path, token):
        if (getattr(self, "_livePillClosed", True) or
                token != getattr(self, "_livePosterToken", None) or
                not path or not os.path.exists(path)):
            return
        # Capturing the lock once prevents a delayed image worker from
        # accessing missing or reset state after a screen has been closed.
        lock = getattr(self, "_livePillLock", None)
        if lock is None:
            return
        self._infobarPosterPath = str(path)
        self._livePillRequestSeq += 1
        request_seq = self._livePillRequestSeq
        with lock:
            if self._livePillClosed:
                return
            self._livePillWorkers += 1

        def worker():
            try:
                try:
                    prepared = prepare_pill_image(path)
                except Exception:
                    prepared = path
                with lock:
                    if (not getattr(self, "_livePillClosed", True) and
                            token == getattr(self, "_livePosterToken", None) and
                            request_seq == getattr(self, "_livePillRequestSeq", None)):
                        self._livePillResults.append((token, request_seq, prepared or path))
            finally:
                with lock:
                    self._livePillWorkers = max(0, getattr(self, "_livePillWorkers", 0) - 1)

        try:
            job = thread_factory(target=worker, name="TiviMateLiveOval")
            job.daemon = True
            job.start()
        except Exception:
            with lock:
                self._livePillWorkers = max(0, self._livePillWorkers - 1)
            return
        try:
            self._livePillTimer.start(90, False)
        except Exception:
            pass

    def _finishInfobarPill(self):
        if getattr(self, "_livePillClosed", True):
            return
        lock = getattr(self, "_livePillLock", None)
        if lock is None:
            return
        with lock:
            results = self._livePillResults[:]
            self._livePillResults = []
            remaining = self._livePillWorkers
        if not remaining:
            try:
                self._livePillTimer.stop()
            except Exception:
                pass
        for token, request_seq, path in results:
            if token != self._livePosterToken or request_seq != self._livePillRequestSeq or not path or not os.path.isfile(path):
                continue
            try:
                self._infobarPosterDecodeToken = token
                # Directly load premasked PNG to preserve the capsule alpha.
                # ePicLoad on some Python 2.7 DreamOS builds flattens alpha.
                if (os.path.basename(path).startswith('pill_') and
                        path.lower().endswith('.png')):
                    try:
                        from Tools.LoadPixmap import LoadPixmap
                        ptr = LoadPixmap(path=path)
                        if ptr is not None and token == self._livePosterToken:
                            self['livePoster'].instance.setPixmap(ptr)
                            self['livePoster'].show()
                            self['backdropFrame'].show()
                            continue
                    except Exception:
                        pass
                # Decode original art only if every alpha-crop backend failed.
                self._livePosterPic.setPara((400, 224, 1, 1, False, 1, "#00000000"))
                self._livePosterPic.startDecode(path)
            except Exception:
                pass

    def _infobarPosterDecoded(self, info=None):
        try:
            if getattr(self, "_infobarPosterDecodeToken", -1) != self._livePosterToken:
                return
            ptr = self._livePosterPic.getData()
            if ptr is None:
                self._showInfobarPosterFallback()
                return
            # Native clipping on supported Enigma2 builds; Pillow crop already
            # carries alpha on receivers with python3-PIL installed.
            instance = self["livePoster"].instance
            if hasattr(instance, "setCornerRadius"):
                try:
                    instance.setCornerRadius(112)
                except TypeError:
                    try:
                        from enigma import eWidget
                        instance.setCornerRadius(112, eWidget.RADIUS_ALL)
                    except Exception:
                        pass
                except Exception:
                    pass
            instance.setPixmap(ptr)
            self["livePoster"].show()
            if getattr(self, "_infobarFootballFixture", None):
                _log_sports('sports_image_displayed')
            self["backdropFrame"].show()
        except Exception:
            pass


    def _loadPicon(self, item):
        # Let the OSD paint before reading/decoding artwork from receiver storage.
        self._infobarPiconReqId = int(getattr(self, '_infobarPiconReqId', 0) or 0) + 1
        self._infobarPiconPending = (self.index, dict(item or {}))
        try:
            self._infobarPiconTimer.stop()
            self._infobarPiconTimer.start(140, True)
        except Exception:
            self._finishDeferredPicon()

    def _finishDeferredPicon(self):
        pending = self._infobarPiconPending
        self._infobarPiconPending = None
        if pending and pending[0] == self.index and not self._livePillClosed:
            self._loadPiconNow(pending[1])

    def _applyPiconBackground(self):
        mode = str((self.source or {}).get('picon_background', 'normal') or 'normal').lower()
        for key, selected in (('piconNormalCard', 'normal'), ('piconPlateWhite', 'white'), ('piconPlateBlack', 'black')):
            widget = self[key]
            if mode == selected:
                widget.show()
            else:
                widget.hide()

    def _loadPiconNow(self, item):
        self._applyPiconBackground()
        # The channel picon is independent of the programme backdrop. The
        # TiViMate fallback logo belongs inside the left oval (in the skin).
        try:
            self._infobarPiconReqId = int(getattr(self, '_infobarPiconReqId', 0) or 0) + 1
        except Exception:
            self._infobarPiconReqId = 1
        req_id = self._infobarPiconReqId

        try:
            fallback = os.path.join(os.path.dirname(__file__), 'skins', 'common', 'te2_fallback.png')
            if os.path.isfile(fallback) and self['picon'].instance:
                self['picon'].instance.setPixmapFromFile(fallback)
                self['picon'].show()
            else:
                self['picon'].hide()
        except Exception:
            pass
        url = resolve_picon_url(item, self.source)
        _live_diag_log(self.source, item, "picon_request", has_url=bool(url), icon=_live_diag_safe_icon(url))
        if not url:
            return

        def current_id():
            return int(getattr(self, '_infobarPiconReqId', 0) or 0)

        def apply_path(path):
            if self._livePillClosed or req_id != current_id():
                return
            if not path or not os.path.isfile(path):
                _live_diag_log(self.source, item, "picon_result", result="no_valid_channel_picon")
                return
            try:
                if self['picon'].instance:
                    self['picon'].instance.setPixmapFromFile(path)
                    self['picon'].show()
                    _live_diag_log(self.source, item, "picon_result", result="shown", path=os.path.basename(str(path)))
            except Exception as exc:
                _live_diag_log(self.source, item, "picon_result", result="show_failed", error=repr(exc))

        direct_picon(url, (248, 148), req_id, current_id, apply_path, prefix='tivimate_epg_logo_')


    def _piconDecoded(self, info=None):
        return


    def _setLiveEpgLabel(self, key, value):
        """Paint DreamOS/Python 2.7 programme labels using UTF-8 bytes.

        Do not rely on the SIP C++ Label binding to convert a Python 2 unicode
        string through the default ASCII codec. Other Live list widgets use
        the same UTF-8 GUI representation and can already show Arabic EPG.
        """
        try:
            self[key].setText(gui_text(value if value is not None else u""))
            self[key].show()
            return True
        except Exception as exc:
            try:
                self[key].setText(text_type(value if value is not None else u""))
                self[key].show()
                return True
            except Exception as again:
                self._traceLiveEpg("label_error", label=key,
                                   err=type(exc).__name__ + "/" + type(again).__name__)
                return False

    def _traceLiveEpg(self, event, **fields):
        return None  # r146: diagnostics off
        """Small bounded diagnostic file; no channels, URLs, credentials or titles."""
        try:
            path = data_path("live_epg_diagnostic.log")
            if os.path.isfile(path) and os.path.getsize(path) > 64000:
                os.rename(path, path + ".old")
            parts = [time.strftime("%Y-%m-%d %H:%M:%S"), str(event),
                     "provider=" + str((self.source or {}).get("type") or ""),
                     "index=" + str(getattr(self, "index", -1))]
            for key, val in sorted(fields.items()):
                parts.append(str(key) + "=" + str(val)[:32])
            with open(path, "a") as handle:
                handle.write(" ".join(parts) + "\n")
        except Exception:
            pass

    def _showBrowserInfobarEpg(self, item=None):
        """Display verified browser Now/Next without re-resolving channel IDs.

        Live's visible list/Windows screen already resolved these titles.
        They belong to this copied channel row only. A fresh short_epg lookup
        still runs later and can replace the text with more current results.
        """
        if item is None:
            item = self._current()
        handoff = _read_live_epg_handoff(item)
        if not handoff:
            self._traceLiveEpg("handoff_missing")
            return False
        now, upcoming = handoff
        title = text_type(now.get('title') or u'').strip()
        if not title:
            return False
        current_clock = text_type(now.get('t_time') or u'').strip()
        self._setLiveEpgLabel("epgNow", (current_clock + u'   ' + title) if current_clock else title)
        nxt = text_type(upcoming.get('title') or u'').strip()
        next_clock = text_type(upcoming.get('t_time') or u'').strip()
        self._setLiveEpgLabel("epgNext", (next_clock + u'   ' + nxt) if next_clock and nxt else nxt)
        desc = now.get('description') or now.get('descr') or now.get('desc') or u''
        self._setLiveEpgDescription(desc)
        # Set even when no absolute timestamps are available: a subsequent
        # empty remote EPG result must not erase a valid visible programme.
        try:
            begin = int(now.get('start_timestamp') or 0)
            end = int(now.get('stop_timestamp') or 0)
        except (ValueError, TypeError, OverflowError):
            begin, end = 0, 0
        self._setLiveEpgContext(title, begin, max(0, end - begin))
        self._scheduleInfobarPoster(title, desc)
        self._traceLiveEpg("handoff_painted", next=int(bool(nxt)), timed=int(bool(begin)))
        if begin and end > begin:
            self._refreshEpgProgress()
        return True

    def _showCachedInfobarEpg(self, item=None):
        """Paint the exact channel's previously loaded Live-list EPG instantly.

        The list/Windows EPG worker already published positive results in the
        shared RAM bridge. Do not throw them away while a second request runs.
        This never touches disk or network and does not invent Now/Next titles.
        """
        if item is None:
            item = self._current()
        rows = _shared_live_epg_cached(self.source, item)
        if not rows:
            return False
        current = following = None
        provider = str((self.source or {}).get("type") or "").lower()
        if provider == "stalker":
            current, following = self._parseStalkerPlayerEpg(rows)
        else:
            current, following = self._parseXtreamPlayerEpg(rows)
            if current is None:
                # M3U/XMLTV and older panels sometimes have titles but no
                # usable absolute timestamps. Display those titles without
                # guessing a progress value or programme time.
                selected, next_row = _shared_stalker_now_next(rows)
                if selected:
                    begin, stop, raw = selected
                    current = (begin, stop, self._decodeXtreamEpgText(
                        _epg_row_title(raw)), raw)
                if next_row:
                    begin, stop, raw = next_row
                    following = (begin, stop, self._decodeXtreamEpgText(
                        _epg_row_title(raw)), raw)
        if not current:
            return False
        begin, end, title, row = current
        title = text_type(title or u"").strip()
        if not title:
            return False
        begin, end = int(begin or 0), int(end or 0)
        duration = max(0, end - begin)
        clock = self._formatEpgClock(begin, duration) if begin and duration else ""
        if provider == "stalker":
            clock = text_type(row.get("t_time") or "").strip() or clock
        self._setLiveEpgLabel("epgNow", (clock + u"   " + title) if clock else title)
        next_text = u""
        if following:
            nb, ne, nt, nr = following
            nt = text_type(nt or u"").strip()
            if nt:
                nb, ne = int(nb or 0), int(ne or 0)
                next_clock = self._formatEpgClock(nb, max(0, ne-nb)) if nb and ne > nb else ""
                if provider == "stalker":
                    next_clock = text_type(nr.get("t_time") or "").strip() or next_clock
                next_text = (next_clock + u"   " + nt) if next_clock else nt
        self._setLiveEpgLabel("epgNext", next_text)
        desc = row.get("descr") or row.get("description") or row.get("desc") or row.get("plot") or ""
        if provider != "stalker":
            desc = self._decodeXtreamEpgText(desc)
        self._setLiveEpgDescription(desc)
        if begin and duration:
            self._setLiveEpgContext(title, begin, duration)
            self._refreshEpgProgress()
        self._scheduleInfobarPoster(title, desc)
        return True

    def _scheduleEpg(self):
        # playService(), evStart and showInfobar can all fire for the same
        # channel. One pending timer is enough; do not postpone EPG over and
        # over while the first frames decode.
        if getattr(self, '_epgSchedulePending', False):
            return
        self._epgSchedulePending = True
        self._epg_ready = False
        self._epgAsyncToken += 1
        self._epgNextReadAt = 0.0
        self._epgNextRequestAt = 0.0
        self._xtream_epg_last_update = 0.0
        try:
            self._epg_timer.stop()
        except Exception:
            pass
        # A channel with verified EPG in the browser must not reopen with
        # empty Now/Next while the player schedules a redundant lookup.
        # On actual zaps _clearLiveEpgUi already cleared the previous channel.
        restored = False
        try:
            # The original Live/Windows GUI is authoritative for the channel
            # that opened fullscreen. Fall back to RAM bridge only on a miss.
            restored = (self._showBrowserInfobarEpg(self._current()) or
                        self._showCachedInfobarEpg(self._current()))
        except Exception:
            restored = False
        self._traceLiveEpg("epg_schedule", restored=int(bool(restored)),
                           cached=int(bool((getattr(self, "_live_epg_context", {}) or {}).get("title"))),
                           handoff=int(bool(_read_live_epg_handoff(self._current()))))
        if not restored and not (getattr(self, "_live_epg_context", {}) or {}).get("title"):
            self._setLiveEpgLabel("epgNow", "")
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
        try:
            self._epg_timer.start(900, True)
        except TypeError:
            self._epg_timer.start(650)
        except Exception:
            self._delayedEpg()

    def _delayedEpg(self):
        self._epgSchedulePending = False
        self._epg_ready = True
        self._updateEpg()

    def _stalkerEpgTimestamp(self, value):
        if value in (None,""): return 0
        try:
            if isinstance(value,(int,float)): return int(value)
        except Exception: pass
        raw=str(value or "").strip()
        try: return int(float(raw))
        except Exception: pass
        try: return int(time.mktime(time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S")))
        except Exception: return 0

    def _parseStalkerPlayerEpg(self, rows):
        # Identical programme selection as Live List and Windows.
        current, following = _shared_stalker_now_next(rows)
        def player_row(event):
            if event is None:
                return None
            begin, end, raw = event
            return (begin, end, _ultra_epg_title(raw), raw)
        return player_row(current), player_row(following)

    def _startStalkerPlayerEpg(self, item):
        if self.source.get("type")!="stalker": return False
        ch_id=str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or "").strip()
        if not ch_id: return False
        self._stalker_epg_token += 1
        token=self._stalker_epg_token
        self._stalker_epg_started_at = monotonic()
        shared_rows = _shared_live_epg_cached(self.source, item)
        if shared_rows:
            self._stalker_epg_result = (token, shared_rows)
            try: self._stalker_epg_poll.start(1, True)
            except Exception: pass
            return True
        source = dict(self.source or {})
        selected = dict(item or {})
        def worker():
            try:
                # EPG lane must not borrow the playback client's mutable
                # session. Read the shared Ultra-style EPG cache first.
                rows = _shared_epg_wait(source, selected, max_wait=0.7)
                if not rows:
                    current_client = live_playback_client(source, get_source_client)
                    if current_client is None:
                        raise RuntimeError("Stalker client unavailable")
                    rows = current_client.short_epg(ch_id,limit=10,force=False) or []
            except Exception:
                invalidate_live_playback_client(source)
                rows=[]
            if token == self._stalker_epg_token:
                self._stalker_epg_result=(token,rows)
        try:
            from .stalker_live_pool import LIVE_EPG_EXECUTOR
            self._stalker_epg_future = LIVE_EPG_EXECUTOR.submit(
                worker, _task_key=("player-short-epg", id(self)), _replace_task_key=True)
        except Exception:
            # A bounded pool may be closed during shutdown: never block GUI.
            self._stalker_epg_result = (token, [])
        try: self._stalker_epg_poll.start(100,True)
        except Exception: pass
        return True

    def _finishStalkerPlayerEpg(self):
        result=self._stalker_epg_result
        if result is None:
            if monotonic() - self._stalker_epg_started_at >= 7.0:
                # Late workers must not keep the infobar polling forever.
                self._stalker_epg_token += 1
                try: self._stalker_epg_future.cancel()
                except Exception: pass
                result = (self._stalker_epg_token, [])
            else:
                try: self._stalker_epg_poll.start(100,True)
                except Exception: pass
                return
        self._stalker_epg_result=None
        token,rows=result
        if token != self._stalker_epg_token: return
        _shared_live_epg_remember(self.source, self._current(), rows)
        current,upcoming=self._parseStalkerPlayerEpg(rows)
        try:
            # Next programme of THIS channel, for MENU > Remind me.
            self._epgUpcomingEvent = (int(upcoming[0]), int(upcoming[1]), upcoming[2], self._current()) if upcoming and upcoming[0] else None
        except Exception:
            self._epgUpcomingEvent = None
        self._traceLiveEpg("stalker_response", rows=len(rows or []),
                           now=int(bool(current)), next=int(bool(upcoming)))
        if not current:
            if (getattr(self, "_live_epg_context", {}) or {}).get("title"):
                self._epgNextRequestAt = time.time() + 60
                return
            self._setLiveEpgLabel("epgNow", tr("No EPG data"))
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
            self._epgNextRequestAt = time.time() + 60
            return
        now=int(time.time()); begin,stop,title,row=current; duration=max(0,stop-begin)
        if begin and duration:
            self._setLiveEpgContext(title, begin, duration)
        current_time=str(row.get("t_time") or "").strip()
        self._setLiveEpgLabel("epgNow", u"%s   %s"%(
            current_time or (self._formatEpgClock(begin,duration) if begin else ""),title))
        description = row.get("descr") or row.get("description") or row.get("descr_short") or row.get("plot") or ""
        self._setLiveEpgDescription(description)
        self._scheduleInfobarPoster(title, description)
        if upcoming:
            ub,us,ut,urow=upcoming; ud=max(0,us-ub)
            nt=str(urow.get("t_time") or "").strip()
            self._setLiveEpgLabel("epgNext", u"%s   %s"%(
                nt or (self._formatEpgClock(ub,ud) if ub else ""),ut))
        else: self._setLiveEpgLabel("epgNext", "")
        elapsed=max(0,now-begin)
        percent=min(100,max(0,int((elapsed*100)/duration))) if duration>0 else 0
        elapsed_min=int(elapsed/60); total_min=int((duration+59)/60) if duration else 0
        self["epgProgress"].setValue(percent)
        if total_min>0:
            self["epgProgressText"].setText("%d / %d min  •  %d%%"%(elapsed_min,total_min,percent))
            try:
                self["epgProgress"].show(); self["epgProgressText"].show()
            except Exception: pass

    def _decodeXtreamEpgText(self, value):
        # Use the same validated UTF-8/Base64 decoder as the live-list EPG;
        # do not accidentally decode a short plain programme name as Base64.
        return _decode_xtream_title(value)

    def _xtreamEpgTimestamp(self, row, start=True):
        keys = ("start_timestamp", "start", "begin_timestamp", "begin") if start else (
            "stop_timestamp", "end", "end_timestamp", "stop"
        )
        for key in keys:
            value = (row or {}).get(key)
            if value in (None, ""):
                continue
            try:
                stamp = int(float(value))
                if stamp > 100000000000:
                    stamp = int(stamp / 1000)
                if stamp > 1000000000:
                    return stamp
            except Exception:
                try:
                    return int(time.mktime(time.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")))
                except Exception:
                    pass
        return 0

    def _parseXtreamPlayerEpg(self, rows):
        """Normalise Xtream short-EPG rows for the Live infobar.

        Xtream panels can return a valid current programme while their EPG
        timestamps use a different panel clock.  Keep the provider data as the
        single source of truth, but normalise one clock offset for the whole
        returned schedule before the Live infobar/subtitle context consumes it.
        """
        now = int(time.time())
        events = []
        marked_current = None
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._xtreamEpgTimestamp(row, True)
            stop = self._xtreamEpgTimestamp(row, False)
            if not stop and begin:
                raw_duration = row.get("duration") or row.get("duration_sec") or row.get("duration_seconds") or 0
                duration = 0
                try:
                    duration = int(float(raw_duration))
                except Exception:
                    text = str(raw_duration or "").strip()
                    try:
                        parts = [int(x) for x in text.split(":")]
                        if len(parts) == 3:
                            duration = parts[0] * 3600 + parts[1] * 60 + parts[2]
                        elif len(parts) == 2:
                            duration = parts[0] * 60 + parts[1]
                    except Exception:
                        duration = 0
                if duration > 0:
                    stop = begin + duration
            title = _epg_row_title(row)
            if begin and title:
                if not stop or stop <= begin:
                    stop = begin + 3600
                event = (begin, stop, title, row)
                events.append(event)
                flag = row.get("now_playing")
                if flag is None:
                    flag = row.get("is_now")
                if flag is None:
                    flag = row.get("current")
                try:
                    is_current = str(flag).strip().lower() in ("1", "true", "yes", "now", "current")
                except Exception:
                    is_current = False
                if is_current and marked_current is None:
                    marked_current = event
        events.sort(key=lambda x: x[0])
        if not events:
            return None, None

        # First trust timestamps when they already contain the receiver clock.
        current = None
        upcoming = None
        for idx, event in enumerate(events):
            if event[0] <= now < event[1]:
                current = event
                upcoming = events[idx + 1] if idx + 1 < len(events) else None
                break

        # Some Xtream panels explicitly mark the current row but expose its
        # start/stop in the panel clock.  Derive one offset from that row and
        # apply it to every event.  A provider progress percentage, when
        # supplied, gives an exact elapsed position; otherwise anchor the
        # receiver clock to the middle of the marked interval.  The offset is
        # rounded to 15 minutes because real panel clock offsets are normally
        # timezone-sized values rather than arbitrary seconds.
        if current is None and marked_current is not None:
            mb, ms, _mt, mr = marked_current
            duration = max(1, ms - mb)
            pct = None
            for key in ("percentage", "percent", "progress", "progress_percent"):
                raw = mr.get(key)
                if raw in (None, ""):
                    continue
                try:
                    value = float(str(raw).replace("%", "").strip())
                    if 0.0 <= value <= 1.0:
                        value *= 100.0
                    if 0.0 <= value <= 100.0:
                        pct = value
                        break
                except Exception:
                    pass
            if pct is not None:
                provider_position = mb + int((duration * pct) / 100.0)
            else:
                provider_position = mb + int(duration / 2)
            raw_offset = now - provider_position
            quantum = 15 * 60
            offset = int(round(float(raw_offset) / quantum) * quantum)
            shifted = []
            for eb, es, et, er in events:
                shifted.append((eb + offset, es + offset, et, er))
            events = shifted
            marked_current = (mb + offset, ms + offset, marked_current[2], mr)
            for idx, event in enumerate(events):
                if event[0] <= now < event[1]:
                    current = event
                    upcoming = events[idx + 1] if idx + 1 < len(events) else None
                    break
            if current is None:
                current = marked_current
                for idx, event in enumerate(events):
                    if event[0] == current[0] and event[2] == current[2]:
                        upcoming = events[idx + 1] if idx + 1 < len(events) else None
                        break

        if current is None:
            # No explicit now-playing marker. Xtream short_epg timestamps can be
            # in the panel clock instead of the receiver clock. Choose the same
            # conservative fallback row as before, then (only when it does not
            # contain "now") derive one rounded panel->receiver offset from the
            # fallback interval and apply it to the full schedule. This keeps the
            # displayed EPG times and the progress bar on the same local clock.
            past = [event for event in events if event[0] <= now]
            future = [event for event in events if event[0] > now]
            if past:
                current = past[-1]
                for event in future:
                    if event[0] > current[0]:
                        upcoming = event
                        break
            else:
                current = events[0]
                upcoming = events[1] if len(events) > 1 else None

            if current is not None and not (current[0] <= now < current[1]):
                cb, cs, _ct, _cr = current
                duration = max(1, cs - cb)
                provider_position = cb + int(duration / 2)
                raw_offset = now - provider_position
                quantum = 15 * 60
                offset = int(round(float(raw_offset) / quantum) * quantum)
                shifted = [(eb + offset, es + offset, et, er) for eb, es, et, er in events]
                events = shifted
                current = None
                upcoming = None
                for idx, event in enumerate(events):
                    if event[0] <= now < event[1]:
                        current = event
                        upcoming = events[idx + 1] if idx + 1 < len(events) else None
                        break
                if current is None and events:
                    current = events[0]
                    upcoming = events[1] if len(events) > 1 else None

        return current, upcoming

    def _startXtreamPlayerEpg(self, item):
        if self.source.get("type") != "xtream":
            return False
        # Use the exact same Xtream channel identity order as the Live list.
        # Some panels/items expose ch_id/channel_id without stream_id.
        stream_id = str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or (item or {}).get("channel_id") or "").strip()
        if not stream_id:
            return False
        epg_channel_id = str((item or {}).get("epg_channel_id") or (item or {}).get("tvg_id") or (item or {}).get("epg_id") or "").strip()
        shared_rows = _shared_live_epg_cached(self.source, item)
        if shared_rows:
            self._xtream_epg_token += 1
            self._xtream_epg_result = (self._xtream_epg_token, shared_rows)
            try: self._xtream_epg_poll.start(1, True)
            except Exception: pass
            return True
        cache_key = (str(self.source.get("url") or ""), str(self.source.get("username") or ""), stream_id)
        cached = self._xtream_epg_cache.get(cache_key)
        if cached and (time.time() - float(cached[0] or 0)) < 900:
            self._xtream_epg_token += 1
            self._xtream_epg_result = (self._xtream_epg_token, list(cached[1] or []))
            try:
                self._xtream_epg_poll.start(1, True)
            except Exception:
                pass
            return True
        self._xtream_epg_token += 1
        token = self._xtream_epg_token
        self._xtream_epg_started_at = monotonic()
        self._xtream_epg_result = None
        source = dict(self.source or {})
        selected = dict(item or {})
        def worker():
            if self._epgClosed or token != self._xtream_epg_token:
                return
            try:
                current_client = live_playback_client(source, get_source_client)
                if current_client is None:
                    raise RuntimeError("Xtream client unavailable")
                rows = current_client.short_epg(stream_id, limit=10, epg_channel_id=epg_channel_id) or []
            except Exception:
                rows = []
            if not isinstance(rows, list):
                rows = []
            _live_diag_log(source, selected, "epg_short_api", lookup_stream_id=stream_id, lookup_epg_id=epg_channel_id, row_count=len(rows))
            # Ignore obsolete requests after a fast channel switch. Do not
            # poison a positive cache entry with a transient empty response.
            if token != self._xtream_epg_token:
                return
            positive_rows = [dict(r) for r in rows if isinstance(r, dict)]
            if positive_rows:
                self._xtream_epg_cache[cache_key] = (time.time(), positive_rows)
                if len(self._xtream_epg_cache) > 800:
                    oldest = sorted(self._xtream_epg_cache.items(), key=lambda kv: float(kv[1][0] or 0))[:120]
                    for key, _value in oldest:
                        self._xtream_epg_cache.pop(key, None)
            self._xtream_epg_result = (token, rows)
        try:
            from .stalker_live_pool import LIVE_EPG_EXECUTOR
            self._xtream_epg_future = LIVE_EPG_EXECUTOR.submit(worker,
                _task_key=("player-xtream-epg", id(self)), _replace_task_key=True)
        except Exception:
            self._xtream_epg_result = (token, [])
        try:
            self._xtream_epg_poll.start(100, True)
        except Exception:
            pass
        return True

    def _finishXtreamPlayerEpg(self):
        result = self._xtream_epg_result
        if result is None:
            if monotonic() - self._xtream_epg_started_at >= 7.0:
                self._xtream_epg_token += 1
                try: self._xtream_epg_future.cancel()
                except Exception: pass
                result = (self._xtream_epg_token, [])
            else:
                try:
                    self._xtream_epg_poll.start(100, True)
                except Exception:
                    pass
                return
        self._xtream_epg_result = None
        token, rows = result
        if token != self._xtream_epg_token:
            return
        _shared_live_epg_remember(self.source, self._current(), rows)
        current, upcoming = self._parseXtreamPlayerEpg(rows)
        try:
            # Next programme of THIS channel, for MENU > Remind me.
            self._epgUpcomingEvent = (int(upcoming[0]), int(upcoming[1]), upcoming[2], self._current()) if upcoming and upcoming[0] else None
        except Exception:
            self._epgUpcomingEvent = None
        self._traceLiveEpg("xtream_response", rows=len(rows or []),
                           now=int(bool(current)), next=int(bool(upcoming)))
        if not current:
            if (getattr(self, "_live_epg_context", {}) or {}).get("title"):
                self._epgNextReadAt = time.time() + 75
                return
            self._live_epg_context = {}
            self._setLiveEpgLabel("epgNow", tr("No EPG data"))
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
            self._epgNextReadAt = time.time() + 75
            return
        now = int(time.time())
        self._xtream_epg_last_update = time.time()
        begin, stop, title, row = current
        duration = max(0, stop - begin)
        self._setLiveEpgContext(title, begin, duration)
        self._setLiveEpgLabel("epgNow", u"%s   %s" % (self._formatEpgClock(begin, duration), title))
        description = self._decodeXtreamEpgText(row.get("descr") or row.get("description") or row.get("descr_short") or row.get("plot") or "")
        self._setLiveEpgDescription(description)
        self._scheduleInfobarPoster(title, description)
        if upcoming:
            ub, us, ut, _urow = upcoming
            self._setLiveEpgLabel("epgNext", u"%s   %s" % (self._formatEpgClock(ub, max(0, us - ub)), ut))
        else:
            self._setLiveEpgLabel("epgNext", "")
        elapsed = max(0, now - begin)
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        elapsed_min = int(elapsed / 60)
        total_min = int((duration + 59) / 60) if duration else 0
        self["epgProgress"].setValue(percent)
        if total_min > 0:
            self["epgProgressText"].setText("%d / %d min  •  %d%%" % (elapsed_min, total_min, percent))
            try:
                self["epgProgress"].show()
                self["epgProgressText"].show()
            except Exception:
                pass
        else:
            self["epgProgressText"].setText("")

    def _formatEpgClock(self, begin, duration):
        try:
            end = int(begin) + int(duration or 0)
            return "%s–%s" % (time.strftime("%H:%M", time.localtime(int(begin))), time.strftime("%H:%M", time.localtime(end)))
        except Exception:
            return ""

    def _refreshEpgProgress(self):
        """Local, cheap refresh only; never touch cache files or network."""
        context = getattr(self, "_live_epg_context", {}) or {}
        begin = int(context.get("begin") or 0)
        duration = max(0, int(context.get("duration") or 0))
        if not begin or not duration:
            return
        # Some DreamOS skin updates blank a Label while the progress widget
        # retains its context. Repaint from the verified EPG title, not from
        # guessed channel metadata. Never show a blank NOW over a live bar.
        title = text_type(context.get("title") or u"").strip()
        if title and not text_type(self["epgNow"].getText() or u"").strip():
            self._setLiveEpgLabel("epgNow", u"%s   %s" % (self._formatEpgClock(begin, duration), title))
        now = int(time.time())
        elapsed = max(0, now - begin)
        percent = min(100, int(elapsed * 100 / duration))
        self["epgProgress"].setValue(percent)
        self["epgProgressText"].setText("%d / %d min  •  %d%%" % (
            elapsed // 60, (duration + 59) // 60, percent))

    def _asyncEpgWorker(self):
        """One daemon worker per player: newer zaps replace queued lookups."""
        while True:
            with self._epgAsyncLock:
                job = self._epgAsyncPending
                self._epgAsyncPending = None
                if job is None or self._epgClosed:
                    self._epgAsyncWorkerRunning = False
                    return
            token, source, item = job
            try:
                value = lookup_channel_epg(source, item, int(time.time()))
            except Exception:
                value = (None, None)
            with self._epgAsyncLock:
                if not self._epgClosed and token == self._epgAsyncToken:
                    self._epgAsyncResult = (token, source.get("type"), item, value)

    def _requestAsyncLocalEpg(self, item):
        # Convert once to plain dictionaries so background work never reads
        # mutable player/source objects while a new channel is being opened.
        token = self._epgAsyncToken
        self._epgAsyncDeadline = monotonic() + 8.0
        try:
            source = dict(self.source or {})
            item_copy = dict(item or {})
        except Exception:
            return
        launch = False
        with self._epgAsyncLock:
            self._epgAsyncPending = (token, source, item_copy)
            self._epgAsyncResult = None
            if not self._epgAsyncWorkerRunning:
                self._epgAsyncWorkerRunning = True
                launch = True
        if launch:
            t = thread_factory(target=self._asyncEpgWorker, name="TiviMateLightEPG")
            t.daemon = True
            t.start()
        try:
            self._epgAsyncPoll.start(180, True)
        except TypeError:
            self._epgAsyncPoll.start(180)

    def _finishAsyncEpgLookup(self):
        with self._epgAsyncLock:
            result = self._epgAsyncResult
            self._epgAsyncResult = None
            running = self._epgAsyncWorkerRunning
        if result is None:
            if running and not self._epgClosed:
                if monotonic() < getattr(self, "_epgAsyncDeadline", 0):
                    try:
                        self._epgAsyncPoll.start(400, True)
                    except TypeError:
                        self._epgAsyncPoll.start(400)
                    return
                with self._epgAsyncLock:
                    self._epgAsyncToken += 1
                    self._epgAsyncPending = None
                    self._epgAsyncResult = None
                if self.source.get("type") == "xtream" and self._startXtreamPlayerEpg(self._current()):
                    self._epgNextReadAt = time.time() + 180
                else:
                    self._epgNextReadAt = time.time() + 60
            return
        token, source_type, item, events = result
        if self._epgClosed or token != self._epgAsyncToken:
            return
        current, upcoming = events
        self._traceLiveEpg("local_response", now=int(bool(current)),
                           next=int(bool(upcoming)))
        # A timed EPG row without a programme name is not valid NOW data.
        # Never let an empty-title local result replace verified provider
        # handoff with a progress-only bar and blank Now/Next labels.
        if current and not text_type(current[2] or u"").strip():
            current = None
        if not current:
            positive_rows = _shared_live_epg_cached(self.source, item)
            if source_type == "xtream" and positive_rows and self._startXtreamPlayerEpg(item):
                self._epgNextReadAt = time.time() + 180
                return
            if source_type == "xtream" and self._startXtreamPlayerEpg(item):
                # Only the remote provider fallback runs now, in its own thread.
                # The provider request is asynchronous. Normal EPG channels
                # retain their regular refresh interval; only empty results
                # are throttled for ten minutes when the worker finishes.
                self._epgNextReadAt = time.time() + 180
                return
            if (getattr(self, "_live_epg_context", {}) or {}).get("title"):
                self._epgNextReadAt = time.time() + 75
                return
            self._setLiveEpgLabel("epgNow", tr("No EPG data"))
            self._setLiveEpgLabel("epgNext", "")
            self._setLiveEpgDescription(u"")
            self["epgProgress"].setValue(0)
            self["epgProgressText"].setText("")
            self._epgNextReadAt = time.time() + 75
            return
        begin, duration, title, desc = current
        # Prepared XMLTV/native EPG can be fresher than portal short_epg.
        # Publish this successful infobar result so Windows paints it on return.
        bridge_rows = [{"title": title or "", "description": desc or "",
                        "start_timestamp": int(begin),
                        "stop_timestamp": int(begin) + int(duration or 0)}]
        if upcoming:
            ub, ud, ut, upcoming_desc = upcoming
            bridge_rows.append({"title": ut or "", "description": upcoming_desc or "",
                                "start_timestamp": int(ub),
                                "stop_timestamp": int(ub) + int(ud or 0)})
        _shared_live_epg_remember(self.source, item, bridge_rows)
        previous = (getattr(self, "_live_epg_context", {}) or {}).get("title")
        self._setLiveEpgContext(title, begin, duration)
        self._setLiveEpgDescription(desc)
        self._setLiveEpgLabel("epgNow", u"%s   %s" % (self._formatEpgClock(begin, duration), title or ""))
        if upcoming:
            ub, ud, ut, _u_desc = upcoming
            self._setLiveEpgLabel("epgNext", u"%s   %s" % (self._formatEpgClock(ub, ud), ut or ""))
        else:
            self._setLiveEpgLabel("epgNext", "")
        self._refreshEpgProgress()
        try:
            self["epgProgress"].show()
            self["epgProgressText"].show()
        except Exception:
            pass
        # Artwork network requests are independent and only needed when the
        # programme changes, not on each progress update.
        if title and (title != previous or not self._infobarPosterPath):
            self._scheduleInfobarPoster(title, desc)
        self._epgNextReadAt = time.time() + 75

    def _updateEpg(self, item=None):
        """No blocking JSON parsing, EPG API or XMLTV work on the GUI thread."""
        if self._epgClosed:
            return
        now = time.time()
        if self._live_epg_context:
            self._refreshEpgProgress()
        if self.source.get("type") == "stalker":
            if now < self._epgNextRequestAt:
                return
            self._epgNextRequestAt = now + 180
            if not self._startStalkerPlayerEpg(item or self._current()):
                self._setLiveEpgLabel("epgNow", tr("No EPG data"))
                self._epgNextRequestAt = now + 60
            return
        # Xtream/M3U/other source types: one asynchronous prepared-cache
        # lookup, then provider-direct Xtream short_epg only on a miss.
        if now < self._epgNextReadAt:
            return
        self._epgNextReadAt = now + 75
        self._requestAsyncLocalEpg(item or self._current())

    def _mbcAutoAudioTrack(self):
        """MBC-only audio-track helper; reuses existing Live refresh path."""
        try:
            item = self._current() or {}
            name = str(item.get("name") or item.get("title") or "").upper()
            if "MBC" not in name:
                return
            key = str(item.get("url") or item.get("stream_id") or item.get("id") or name)
            if getattr(self, "_mbcAudioTrackKey", "") == key:
                return
            service = self.session.nav.getCurrentService()
            tracks = service and service.audioTracks()
            if not tracks:
                return
            count = int(tracks.getNumberOfTracks() or 0)
            if count <= 0:
                return
            # Prefer an explicitly Arabic track, then AAC/MPEG audio.  This is
            # deliberately MBC-only and does not alter audio on other channels.
            current = int(tracks.getCurrentTrack() or 0)
            best = None
            fallback = None
            for i in range(count):
                try:
                    info = tracks.getTrackInfo(i)
                    desc = str(info.getDescription() or "").upper().replace("_", " ")
                    lang = str(info.getLanguage() or "").upper()
                except Exception:
                    desc, lang = "", ""
                text = lang + " " + desc
                if ("ARA" in text or "ARAB" in text):
                    best = i
                    break
                if fallback is None and ("AAC" in text or "MPEG" in text or "MP2" in text or "MP3" in text):
                    fallback = i
            target = best if best is not None else fallback
            if target is None:
                target = 0
            if int(target) != current:
                tracks.selectTrack(int(target))
            self._mbcAudioTrackKey = key
        except Exception:
            pass

    def _updateClock(self):
        if getattr(self, "_replayMenuPlaying", False):
            return
        try:
            self["clock"].setText(time.strftime("%H:%M  %d/%m/%Y"))
            # _updateClock is also called before playService on a zap. Keep
            # codec polling and audio track switching off the startup path.
            if (getattr(self, '_liveResolvePending', False)
                    or getattr(self, '_liveStartupPending', False)
                    or not getattr(self, '_livePlaybackConfirmed', False)):
                return
            self._updateLiveTechnicalBadges()
            self._mbcAutoAudioTrack()
            fast_refresh = int(getattr(self, "_liveTechFastRefresh", 0) or 0)
            if fast_refresh > 0:
                values = getattr(self, "_liveTechBadgeValues", {}) or {}
                # Resolution + video + audio are the useful decoder fields.
                # Aspect is optional on some streams, so do not wait for it.
                complete = bool(values.get("resolution") and values.get("video") and values.get("audio"))
                self._liveTechFastRefresh = 0 if complete else max(0, fast_refresh - 1)
                if self._liveTechFastRefresh <= 0:
                    try:
                        self._clock_timer.start(10000, False)
                    except Exception:
                        pass
                # Keep the fast local badge passes isolated from EPG work.
                return
            if self._epg_ready:
                self._updateEpg()
        except Exception:
            pass

    def back(self):
        # Closing the full-screen player to browse the Live list is temporary.
        # Preserve the selected subtitle file/delay so reopening the same
        # channel can reattach it without a new search or download.
        self._preserve_live_subtitles_on_close = True
        item = self._current() or {}
        live_id = str(
            item.get("stream_id") or item.get("ch_id") or item.get("id") or
            item.get("url") or item.get("cmd") or item.get("name") or ""
        ).strip()
        # Normal Live: keep the active service when returning to the browser.
        # Favorites may explicitly request stop-on-exit.  Stopping every Live
        # service here breaks reopening/zapping after Back on some Enigma2 images.
        if getattr(self, "favorite_exit_stop", False):
            try:
                expected = getattr(self, 'current_ref', None)
                active = self.session.nav.getCurrentlyPlayingServiceReference()
                if expected is not None and active is not None and active.toString() == expected.toString():
                    self._ultraDecoderGuard.capture(self._ultraExternalUrl)
                    self.session.nav.stopService()
                    self._ultraDecoderGuard.retire(self._ultraExternalUrl)
                    self._ultraExternalUrl = ''
            except Exception:
                pass
        # Returning from a verified playing channel permits one-OK Infobar
        # re-entry from the browser.  Carry an exact service-reference token;
        # never use a matching title/channel number alone as playback proof.
        returned_ref = ""
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            expected = getattr(self, "current_ref", None)
            if (bool(getattr(self, "_livePlaybackConfirmed", False)) and
                    active is not None and expected is not None and
                    active.toString() == expected.toString()):
                returned_ref = active.toString()
        except Exception:
            pass
        owner = item.get("_favorite_source") if isinstance(item.get("_favorite_source"), dict) else self.source
        owner = owner or {}
        owner_key = "%s|%s|%s|%s" % (
            owner.get("type", ""),
            str(owner.get("url") or owner.get("host") or owner.get("server") or
                owner.get("portal") or "").rstrip("/"),
            owner.get("username", ""), owner.get("mac", ""))
        self.close((self.index, live_id, returned_ref, owner_key))

    _WX_LABELS = {"ar": {"Clear": "صافي", "Mostly clear": "صافي غالباً", "Partly cloudy": "غائم جزئياً",
                         "Cloudy": "غائم", "Fog": "ضباب", "Drizzle": "رذاذ", "Rain": "أمطار",
                         "Snow": "ثلوج", "Thunderstorm": "عواصف رعدية", "Weather": "الطقس"}}

    def _wrapEpgProgressKnob(self):
        """Move a glowing knob with the EPG progress bar (0-100) and mirror its visibility."""
        bar = self["epgProgress"]
        knob = self["epgKnob"]
        orig_set, orig_show, orig_hide = bar.setValue, bar.show, bar.hide
        state = {"x": None, "visible": True}

        def place(value):
            try:
                from enigma import ePoint
                from .display_scale import sx, sy
                value = max(0, min(100, int(value or 0)))
                x = 476 + int(1004 * value / 100.0) - 15
                if x != state["x"] and knob.instance:
                    state["x"] = x
                    knob.instance.move(ePoint(sx(x), sy(968)))
                if state["visible"] and value > 0:
                    knob.show()
                else:
                    knob.hide()
            except Exception:
                pass

        def set_value(value):
            orig_set(value)
            place(value)

        def show():
            orig_show(); state["visible"] = True
            try: place(bar.getValue() if hasattr(bar, "getValue") else 1)
            except Exception: pass

        def hide():
            orig_hide(); state["visible"] = False
            try: knob.hide()
            except Exception: pass

        bar.setValue, bar.show, bar.hide = set_value, show, hide

    def _startInfobarWeather(self):
        for name in ("wxPill", "wxIcon", "wxTemp", "wxCity", "wxCond"):
            try: self[name].hide()
            except Exception: pass
        def work():
            try:
                from .weather_ip import fetch_weather
                data = fetch_weather()
            except Exception:
                data = None
            if not data:
                return
            def apply():
                if getattr(self, "_livePillClosed", False):
                    return
                try:
                    from .i18n import get_language
                    lang = get_language()
                except Exception:
                    lang = "en"
                label = text_type(self._WX_LABELS.get(lang, {}).get(data.get("label")) or
                                  tr_text(data.get("label") or ""))
                icon = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live_infobar/weather/%s.png" % (data.get("icon") or "partly_day")
                try:
                    self["wxIcon"].instance.setPixmapFromFile(icon)
                except Exception:
                    pass
                self["wxTemp"].setText(gui_text(u"%d\u00b0" % int(data.get("temp", 0))))
                self["wxCity"].setText(gui_text(data.get("city") or data.get("country") or u""))
                extra = label
                if data.get("humidity") is not None:
                    extra += u"  •  %d%%" % int(data.get("humidity"))
                self["wxCond"].setText(gui_text(extra))
                for name in ("wxPill", "wxIcon", "wxTemp", "wxCity", "wxCond"):
                    try: self[name].show()
                    except Exception: pass
            try:
                from twisted.internet import reactor
                reactor.callFromThread(apply)
            except Exception:
                pass
        thread_factory(target=work, name="TiviMateInfobarWeather", daemon=True).start()

    def _releaseClosedLiveResources(self):
        """Break native signal references only after the player is closing."""
        for name in ("_ib_timer", "_ib_epg_timer", "_liveResolveTimer",
                     "_handoffLinkTimer", "_liveStartupTimer", "_infobarPiconTimer",
                     "_livePosterTimer", "_livePosterPoll", "_livePillTimer",
                     "_clock_timer", "_epg_timer", "_epgAsyncPoll",
                     "_stalker_epg_poll", "_xtream_epg_poll", "_engine_timer",
                     "_watchdog_timer", "_catchup_timer"):
            timer = getattr(self, name, None)
            if timer is not None:
                try:
                    timer.stop()
                except Exception:
                    pass
                try:
                    callbacks = timer.callback
                    for cb in list(callbacks):
                        if getattr(cb, '__self__', getattr(cb, 'im_self', None)) is self:
                            callbacks.remove(cb)
                except Exception:
                    pass
            attr = name + "_connection"
            try:
                conn = getattr(self, attr, None)
                if conn is not None and hasattr(conn, 'disconnect'):
                    conn.disconnect()
            except Exception:
                pass
            if hasattr(self, attr):
                setattr(self, attr, None)
        for name, callback, connection in (
                ("_livePosterPic", self._infobarPosterDecoded, "_livePosterPicConn"),
                ("_pic", self._piconDecoded, "_pic_conn")):
            decoder = getattr(self, name, None)
            try:
                callbacks = decoder.PictureData.get()
                if callback in callbacks:
                    callbacks.remove(callback)
            except Exception:
                pass
            try:
                conn = getattr(self, connection, None)
                if conn is not None and hasattr(conn, 'disconnect'):
                    conn.disconnect()
            except Exception:
                pass
            setattr(self, connection, None)
            setattr(self, name, None)
        # Do not touch the service/decoder, recording timers or disk cache.

    def _cleanup(self):
        self._replayMenuToken = getattr(self, "_replayMenuToken", 0) + 1
        self._replayMenuBusy = False
        self._cancelPendingLiveLink()
        self._livePillClosed = True
        try: _INFOBAR_ART_EXECUTOR.cancel_task(("infobar-art", id(self)))
        except Exception: pass
        self._liveAttemptKey = None
        self._restoreLiveSpinner()
        # A player can close while infobar images/EPG are still in flight.
        # Cancel their UI polling and invalidate all late image completions.
        self._livePosterToken += 1
        self._livePillRequestSeq += 1
        self._livePosterJob = None
        self._infobarPiconPending = None
        self._infobarPiconReqId = int(getattr(self, "_infobarPiconReqId", 0) or 0) + 1
        for name in ("_livePosterTimer", "_livePosterPoll", "_livePillTimer", "_infobarPiconTimer"):
            try:
                timer = getattr(self, name, None)
                if timer is not None:
                    timer.stop()
            except Exception:
                pass
        self._cancelLiveStartup()
        self._cancelLiveResolve()
        self._epgClosed = True
        self._epgAsyncToken += 1
        try:
            self._epgAsyncPoll.stop()
            with self._epgAsyncLock:
                self._epgAsyncPending = None
                self._epgAsyncResult = None
        except Exception:
            pass
        try:
            self._liveResolveTimer.stop()
        except Exception:
            pass
        if getattr(self, "_preserve_live_subtitles_on_close", False):
            self._savePreservedLiveSubtitle()
        else:
            self._discardPreservedLiveSubtitle()
        self._clearSubsSupport()
        try:
            self._clock_timer.stop()
            self._epg_timer.stop()
            try:
                self._stalker_epg_poll.stop()
                self._stalker_epg_token += 1
            except Exception:
                pass
            try:
                self._xtream_epg_poll.stop()
                self._xtream_epg_token += 1
            except Exception:
                pass
            self._engine_timer.stop()
            self._watchdog_timer.stop()
            try:
                self._catchup_timer.stop()
            except Exception:
                pass
            self._ib_timer.stop()
            self._ib_epg_timer.stop()
        except Exception:
            pass
        # DreamOS/Python2 signal.connect() returns an eConnection which must
        # remain alive while the screen is open, then be released on close.
        # Do not leave the callback retaining the player after it exits.
        for name in ("_ib_epg_timer_connection", "_clock_timer_connection",
                     "_epg_timer_connection", "_epgAsyncPoll_connection",
                     "_stalker_epg_poll_connection", "_xtream_epg_poll_connection"):
            connection = getattr(self, name, None)
            if connection is not None:
                try:
                    connection.disconnect()
                except Exception:
                    pass
                try:
                    setattr(self, name, None)
                except Exception:
                    pass
        self._releaseClosedLiveResources()
        # Do not restore the DVB service when closing only the full-screen
        # Live player. The IPTV service must continue while browsing channels
        # and packages. MediaScreen restores the original receiver service only
        # when the user finally exits the Live section.


# Resolve the native FHD/WQHD layout only after the full player class exists.
TiviMateLivePlayer.skin = scale_skin(TiviMateLivePlayer.skin)
