import re
# -*- coding: utf-8 -*-
import os
from .storage import data_path
import traceback
from .py27_compat import text_type


def _u(value):
    """Unicode for Arabic/UTF-8 IPTV title and path fields on Python 2.7."""
    return text_type(value if value is not None else u"")


def _preferred_language():
    # Enigma2's saved subtitle-search language is the user's selection.  The
    # separate SubDL settings are a fallback, not a reason to reset it to Arabic.
    code = u""
    try:
        from Components.config import config
        prefs = getattr(getattr(config.plugins, "subtitlesSupportPro", None), "search", None)
        code = _u(getattr(getattr(prefs, "lang1", None), "value", "") or "").strip().lower()
    except Exception:
        pass
    if not code:
        try:
            from .subdl_client import load_settings
            code = _u((load_settings() or {}).get("language") or "ar").strip().lower()
        except Exception:
            code = "ar"
    aliases = {"ara":"ar", "arabic":"ar", "eng":"en", "english":"en",
               "fra":"fr", "fre":"fr", "tur":"tr"}
    return aliases.get(code, code[:2] if len(code) > 2 else code) or "ar"


def _set_language(settings, language_code=None):
    # Only override the saved selection when a caller explicitly supplies a
    # language.  Previously EVERY search copied subdl.json's language into
    # lang1/lang2/lang3, discarding languages picked via the Search Settings UI.
    explicit = _u(language_code or "").strip().lower()
    if explicit:
        code = explicit
        for name in ("lang1", "lang2", "lang3"):
            try:
                entry = getattr(settings, name)
                entry.value = code
                entry.save()
            except Exception:
                pass
    else:
        code = _u(getattr(getattr(settings, "lang1", None), "value", "") or "").strip().lower()
        if not code:
            code = _preferred_language()
        # Populate only missing fields; preserve all three preferred languages
        # even if they differ from one another.
        for name in ("lang1", "lang2", "lang3"):
            try:
                entry = getattr(settings, name)
                if not _u(getattr(entry, "value", "") or "").strip():
                    entry.value = code
                    entry.save()
            except Exception:
                pass

    for name, value in (("manualSearch", False),
                        ("openParamsDialogOnSearch", False),
                        ("useFilePath", False)):
        try:
            entry = getattr(settings, name)
            entry.value = value
            try:
                entry.save()
            except Exception:
                pass
        except Exception:
            pass
    return code


def _controller(owner):
    obj=getattr(owner,"_tivimate_subtitles",None)
    if obj is not None: return obj
    from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSupport
    obj=TiviMateSubtitleSupport(getattr(owner,"session"),defaultPath=data_path("subtitles"),forceDefaultPath=False,autoLoad=False,showGUIInfoMessages=True,embeddedSupport=False,preferEmbedded=False,searchSupport=True)
    owner._tivimate_subtitles=obj
    owner._tivimate_subtitle_controller=obj
    return obj


def _cached_poster(owner):
    # Keep the hand-off file scoped to the Enigma2 session.  A single global
    # pointer allowed a late callback from another player/session to replace
    # the current poster while the picker was opening.
    session = getattr(owner, "session", None)
    pointer="/tmp/tivimate_subtitles_poster_%s.path" % id(session); path=""
    item=getattr(owner,"item",{}) or {}

    # r478: Subtitle Search must never inherit the VOD player's circular HUD
    # derivative. Reuse only the original rectangular artwork already on disk.
    # No network request, timer, hook, or playback-path change is introduced.
    def _rect_source(candidate):
        try:
            p=str(candidate or "").strip()
            if not p:
                return ""
            if os.path.exists(p) and ".tivimate-circle-" not in os.path.basename(p):
                return p
            # Player circle files are generated as:
            #   <original-root>.tivimate-circle-rXXX.png
            # Recover the already-cached original poster beside that derivative.
            marker=".tivimate-circle-"
            base=os.path.basename(p)
            if marker in base:
                prefix=p[:p.rfind(marker)]
                for ext in (".jpg", ".jpeg", ".png", ".webp"):
                    original=prefix+ext
                    if os.path.exists(original):
                        return original
        except Exception:
            pass
        return ""

    # Prefer the raw player cache fields; these are rectangular server/TMDb art.
    for key in ("_player_cover_cache", "_player_cover_cache_fallback"):
        try:
            path=_rect_source(item.get(key))
            if path:
                break
        except Exception:
            pass

    # Resolve the original URL through the existing artwork cache only.
    if not path:
        try:
            from .artwork_queue import cached_artwork
            for key in ("_player_cover","stream_icon","cover_big","cover","movie_image","poster_url","poster_path"):
                url=item.get(key)
                if not url:
                    continue
                p=cached_artwork(url,"posters")
                path=_rect_source(p)
                if path:
                    break
        except Exception:
            pass

    # Last local-only fallback: recover the original beside any player circle.
    if not path:
        try:
            for attr in ("_cover_cached_path", "_infobarPosterPath"):
                path=_rect_source(getattr(owner,attr,""))
                if path:
                    break
        except Exception:
            pass

    try:
        if path:
            with open(pointer,"w") as f:
                f.write(path)
        elif os.path.exists(pointer):
            os.remove(pointer)
    except Exception:
        pass


def _content_kind(owner):
    item=getattr(owner,"item",{}) or {}
    text=u" ".join(_u(item.get(k, "") or u"").lower() for k in ("content_type","type","stream_type","media_type"))
    if any(x in text for x in ("series","episode","tvshow","tv show")): return "episode"
    for k in ("season","season_number","episode","episode_num","episode_number","series_name","series_id"):
        if item.get(k) not in (None,"",0,"0"): return "episode"
    return "movie"


def _subtitle_latin_title(value):
    """Accept a real Latin-script metadata title, never transliterate guesses."""
    try:
        from .subtitle_title import clean_subtitle_title
        text = clean_subtitle_title(value)
    except Exception:
        text = _u(value or u"").strip()
    # A year or quality tag alone must not be treated as an English title.
    return text if re.search(r"[A-Za-z]{2}", text) else ""


def _existing_english_subtitle_title(owner):
    """Read already-known English names without changing the TMDb UI locale."""
    item = getattr(owner, "item", {}) or {}
    if (getattr(owner, "_subtitle_english_item_key", None) == id(item)):
        name = _subtitle_latin_title(getattr(owner, "_subtitle_english_title", ""))
        if name:
            return name
    # These fields are metadata titles, not the active localized display title.
    if _content_kind(owner) == "episode":
        # Episode original_title can mean the *episode* title. Prefer the
        # English show name for SxxExx subtitle searches.
        keys = ("series_name_en", "english_series_name", "series_original_name",
                "_tmdb_en_title", "_tmdb_english_title", "_subtitle_english_title",
                "english_title", "title_en", "original_name", "series_name")
    else:
        keys = ("_tmdb_en_title", "_tmdb_english_title", "_subtitle_english_title",
                "english_title", "title_en", "original_title", "original_name",
                "movie_name", "title")
    for key in keys:
        name = _subtitle_latin_title(item.get(key))
        if name:
            return name
    return ""


def _english_subtitle_tmdb_lookup(item, is_episode):
    """Background-only English TMDb lookup; reuse the established disk cache."""
    try:
        raw_id = (item.get("series_tmdb_id") or item.get("_series_tmdb_id") or
                  item.get("tmdb_id") or item.get("_tmdb_id") or item.get("tmdb"))
        tmdb_id = int(str(raw_id or "0"))
        if tmdb_id <= 0:
            return ""
        from .tmdb_client import TMDbClient
        tmdb = TMDbClient(language="en-US")
        if not tmdb.configured():
            return ""
        data = tmdb.details_bundle(tmdb_id, "series" if is_episode else "vod") or {}
        # en-US 'title'/'name' is the translated title where available.
        for key in (("name", "original_name") if is_episode else ("title", "original_title")):
            title = _subtitle_latin_title(data.get(key))
            if title:
                return title
    except Exception:
        pass
    return ""


def _tivimate_best_title(owner, fallback=""):
    """Return the real current TiviMate movie/series title."""
    item = getattr(owner, "item", {}) or {}
    # Subtitle search has its own English name. Do NOT alter the player label.
    english = _existing_english_subtitle_title(owner)
    if english:
        return english
    candidates = []

    # Player/runtime attributes first: these are often cleaner than provider labels.
    for attr in (
        "movie_title", "series_title", "content_title", "current_title",
        "service_title", "title", "name"
    ):
        try:
            value = getattr(owner, attr, None)
            if value:
                candidates.append(value)
        except Exception:
            pass

    # Xtream/Stalker/TiviMate item fields.
    for key in (
        "_tmdb_title", "series_name", "series_title", "show_name",
        "movie_name", "vod_name", "stream_name", "channel_name",
        "original_title", "name", "title"
    ):
        try:
            value = item.get(key)
            if value:
                candidates.append(value)
        except Exception:
            pass

    if fallback:
        candidates.append(fallback)

    for value in candidates:
        try:
            text = _u(value).strip()
        except Exception:
            continue
        if not text:
            continue

        # Remove only obvious provider/quality decorations; preserve the real title.
        text = re.sub(r"^\s*(?:MOVIES?|VOD|TV\s*SHOWS?|SERIES)\s*[:\-|]\s*", "", text, flags=re.I)
        text = re.sub(r"\s*[\[\(\{](?:4K|UHD|FHD|FULL\s*HD|1080P|720P|2160P|HEVC|H\.?265|H\.?264|AR|EN|MULTI)[^\]\)\}]*[\]\)\}]\s*", " ", text, flags=re.I)
        text = re.sub(r"\s+(?:4K|UHD|FHD|FULL\s*HD|1080P|720P|2160P|HEVC)\s*$", "", text, flags=re.I)
        text = re.sub(r"\s+", " ", text).strip(" -|:_")
        if text:
            return text
    return ""

def _tivimate_player_movie_title_year(owner, fallback_title=""):
    """Use only data already present in the current TiviMate player.

    Returns (clean_title, year).  No TMDb/API/network lookup is performed.
    """
    item = getattr(owner, "item", {}) or {}
    title = _tivimate_best_title(owner, fallback_title) or _u(fallback_title or u"").strip()

    year = 0
    # Prefer values already attached to the playing item/player.
    for key in ("year", "release_year", "_tmdb_year"):
        try:
            value = item.get(key)
        except Exception:
            value = None
        text = _u(value or u"").strip()
        m = re.search(r"\b((?:19|20)\d{2})\b", text)
        if m:
            year = int(m.group(1))
            break

    if not year:
        for attr in ("year", "release_year", "movie_year", "content_year"):
            try:
                value = getattr(owner, attr, None)
            except Exception:
                value = None
            text = _u(value or u"").strip()
            m = re.search(r"\b((?:19|20)\d{2})\b", text)
            if m:
                year = int(m.group(1))
                break

    # Last fallback: the year already visible in the player title, e.g.
    # "The Odyssey (2026)".  Strip only a trailing year from the search title.
    title_text = _u(title or u"").strip()
    m = re.search(r"(?:[\s\-_.]*[\(\[]?((?:19|20)\d{2})[\)\]]?)\s*$", title_text)
    if m:
        if not year:
            year = int(m.group(1))
        title_text = title_text[:m.start()].strip(" -|:_.")

    return title_text or _u(title or u"").strip(), year


def _tivimate_search_title(owner, fallback_title=""):
    item = getattr(owner, "item", {}) or {}
    base_title = _tivimate_best_title(owner, fallback_title)
    if not base_title:
        return ""

    kind = _content_kind(owner)
    if kind == "episode":
        # Prefer explicit series/show title over an episode-only title.
        series = ""
        english_series = _existing_english_subtitle_title(owner)
        if english_series:
            series = english_series
        for key in (() if series else ("series_name", "series_title", "show_name", "_tmdb_title")):
            try:
                val = item.get(key)
            except Exception:
                val = None
            if val:
                series = _u(val).strip()
                break
        if not series:
            series = base_title

        season = item.get("season_number", item.get("season", ""))
        episode = item.get("episode_number", item.get("episode_num", item.get("episode", "")))

        try:
            if str(season).strip().isdigit() and str(episode).strip().isdigit():
                # Avoid duplicating SxxExx when it is already present.
                if not re.search(r"\bS\d{1,2}E\d{1,3}\b", series, re.I):
                    return "%s S%02dE%02d" % (series, int(season), int(episode))
        except Exception:
            pass
        return series

    return base_title

def _tivimate_content_key(owner):
    """Stable key for the currently playing movie/episode within this player.

    Used only to decide whether BLUE should auto-search on first open.
    A new movie/episode gets one auto search; later opens are manual.
    """
    item = getattr(owner, "item", {}) or {}
    parts = []
    for attr in ("stream_url", "url", "play_url", "service_url", "current_url"):
        try:
            value = getattr(owner, attr, None)
        except Exception:
            value = None
        if value:
            parts.append(_u(value))
            break
    for key in ("stream_id", "episode_id", "movie_id", "series_id", "id"):
        try:
            value = item.get(key)
        except Exception:
            value = None
        if value not in (None, ""):
            parts.append(_u(value))
    title = _tivimate_search_title(owner, _tivimate_best_title(owner, ""))
    if title:
        parts.append(_u(title))
    return u"|".join(parts) or _u(id(owner))


def _bridge_debug_log(stage, exc=None):
    return None  # r146: diagnostics off
    # Persistent diagnostic for RED / More Info subtitle selection.
    try:
        from datetime import datetime
        path = data_path("subtitle_selection_debug.log")
        with open(path, "a") as fp:
            from .py27_compat import text_type
            line = u"%s %s %s\n" % (datetime.now().isoformat(), text_type(stage), text_type(exc or ""))
            fp.write(line.encode("utf-8", "replace"))
    except Exception:
        pass


def _subtitle_file_diagnostic(path):
    try:
        if not path or not os.path.isfile(path):
            return "missing subtitle file: %r" % (path,)
        with open(path, "rb") as f:
            sample = f.read(65536)
        decoded = sample.decode("utf-8-sig", "replace")
        arabic = sum(1 for c in decoded if "\u0600" <= c <= "\u06ff")
        latin = sum(1 for c in decoded if ("a" <= c.lower() <= "z"))
        return "subtitle path=%r bytes=%d arabic_chars=%d latin_chars=%d" % (path, os.path.getsize(path), arabic, latin)
    except Exception as exc:
        return "subtitle diagnostic error=%r" % (exc,)


def _subtitle_focus_state(session, owner, phase):
    """Log only Enigma2 dialog state (never stream URL, credentials, subtitle text)."""
    try:
        import time
        current = getattr(session, 'current_dialog', None)
        stack = getattr(session, 'dialog_stack', None) or []
        own = (current is owner)
        action_states = []
        for name in ('actions', 'menuActions', 'numberActions'):
            try:
                act = owner[name]
                action_states.append('%s:%s' % (name, getattr(act, 'enabled', '?')))
            except Exception:
                action_states.append('%s:missing' % name)
        line = '%s %s player_active=%s current=%s in_exec=%s stack=%s player_shown=%s hud_lock=%s %s\n' % (
            time.strftime('%Y-%m-%d %H:%M:%S'), phase, own,
            type(current).__name__ if current else 'None',
            getattr(session, 'in_exec', '?'), len(stack),
            getattr(owner, 'shown', '?'), getattr(owner, '_hud_lock', '?'),
            ','.join(action_states))
        with open('/tmp/tivimate_subtitle_focus.log', 'ab') as fh:
            fh.write(line.encode('utf-8', 'replace'))
    except Exception:
        pass


def _subtitle_restore_player_keys(owner, session, phase):
    """Never bind keys on a suspended or unrelated modal screen."""
    _subtitle_focus_state(session, owner, phase)
    if getattr(session, 'current_dialog', None) is not owner or not getattr(session, 'in_exec', False):
        return False
    for name in ('actions', 'menuActions', 'numberActions'):
        try:
            owner[name].setEnabled(True)
        except Exception:
            pass
    try:
        owner.refreshInfobar()
    except Exception:
        pass
    _subtitle_focus_state(session, owner, phase + '_restored')
    return True


def _subtitle_search_pause(owner, controller, is_live):
    """Honour 'Pause video on opening subtitles menu' for the BLUE search too.
    Only a video that is really playing is paused, and only that one is resumed."""
    owner._subtitle_search_paused = False
    if is_live:
        return
    try:
        if controller is not None:
            pro = controller.subsProSettings
        else:
            from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings
            pro = initTiviMateSettings()
        if not pro.pauseVideoOnSubtitlesMenu.value:
            return
    except Exception:
        return
    try:
        if getattr(owner, "seekstate", None) == getattr(owner, "SEEK_STATE_PLAY", object()):
            owner.pauseService()
            owner._subtitle_search_paused = True
    except Exception as exc:
        _bridge_debug_log("pause before subtitle search failed", exc)


def _subtitle_search_resume(owner):
    if not getattr(owner, "_subtitle_search_paused", False):
        return
    owner._subtitle_search_paused = False
    try:
        if getattr(owner, "_closing", False):
            return
        if getattr(owner, "seekstate", None) == getattr(owner, "SEEK_STATE_PAUSE", object()):
            owner.unPauseService()
    except Exception as exc:
        _bridge_debug_log("resume after subtitle search failed", exc)


def open_tivimate_subtitle_search(owner, title=None, language_code=None, context=None,
                                  _english_lookup_done=False):
    """Search English metadata title; preserve the selected subtitle language."""
    session = getattr(owner, "session", None)
    # Expose only the failed initialization phase to the UI. Detailed exception
    # information remains in the existing local diagnostic log.
    owner._tivimate_subtitle_search_error = ""
    if session is None:
        owner._tivimate_subtitle_search_error = "session"
        return False

    live_context = dict(context or {}) if isinstance(context, dict) else {}
    is_live = str(live_context.get("media_type") or "").lower() == "live"

    if not is_live and not _english_lookup_done:
        item = getattr(owner, "item", {}) or {}
        english = _existing_english_subtitle_title(owner)
        if not english:
            # Do not make TMDb network calls from the Enigma2 GUI thread.
            # Only resolve when the current player title is not English and
            # a real TMDb ID is already known. Never mistake provider IDs for TMDb.
            current = _tivimate_best_title(owner, title)
            raw_id = (item.get("series_tmdb_id") or item.get("_series_tmdb_id") or
                      item.get("tmdb_id") or item.get("_tmdb_id") or item.get("tmdb"))
            try:
                valid_id = int(str(raw_id or "0")) > 0
            except Exception:
                valid_id = False
            if valid_id and not _subtitle_latin_title(current):
                pending_key = id(item)
                if getattr(owner, "_subtitle_english_pending_key", None) == pending_key:
                    return True
                try:
                    from twisted.internet import threads
                    owner._subtitle_english_pending_key = pending_key
                    item_snapshot = dict(item)
                    is_episode = _content_kind(owner) == "episode"
                    deferred = threads.deferToThread(_english_subtitle_tmdb_lookup,
                                                     item_snapshot, is_episode)

                    def done(result):
                        if getattr(owner, "_subtitle_english_pending_key", None) == pending_key:
                            owner._subtitle_english_pending_key = None
                        if getattr(owner, "_closing", False) or id(getattr(owner, "item", None)) != pending_key:
                            return result
                        name = _subtitle_latin_title(result) if result else u""
                        if name:
                            owner._subtitle_english_item_key = pending_key
                            owner._subtitle_english_title = name
                        open_tivimate_subtitle_search(
                            owner, title, language_code, context, _english_lookup_done=True)
                        return result

                    deferred.addBoth(done)
                    return True
                except Exception:
                    owner._subtitle_english_pending_key = None
                    # If TMDb is unavailable, continue with the existing title.
                    pass

    if is_live:
        # Live has no VOD item metadata.  Use only the programme/channel
        # context supplied by LivePlayer and never classify owner.item as a movie.
        clean_title = _u(live_context.get("program_title") or title or live_context.get("channel_name") or u"").strip()
        player_movie_title, player_movie_year = clean_title, 0
        content_key = "live:%s:%s:%s" % (
            live_context.get("channel_id") or "",
            live_context.get("begin") or 0,
            clean_title.lower(),
        )
    else:
        clean_title = _tivimate_best_title(owner, title)
        if not clean_title:
            return False

        # Movie title/year come only from information already available in the
        # current player.  This deliberately performs no TMDb/API/network lookup.
        player_movie_title, player_movie_year = _tivimate_player_movie_title_year(owner, clean_title)
        if _content_kind(owner) == "movie" and player_movie_title:
            clean_title = player_movie_title
        content_key = _tivimate_content_key(owner)

    if not clean_title:
        return False

    # Auto-search exactly once for each currently playing movie/episode or
    # Live programme. Opening BLUE again shows the normal manual search screen.
    previous_key = getattr(owner, "_tivimate_subtitle_auto_search_key", None)
    auto_search_on_open = previous_key != content_key
    if auto_search_on_open:
        owner._tivimate_subtitle_auto_search_key = content_key

    stage = "import"
    try:
        from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSearch, E2SubsSeeker
        _bridge_debug_log("import ok")

        stage = "settings"
        # DreamOS may reject the native subtitle overlay during construction.
        # Do not let overlay setup prevent opening the provider search UI.
        controller = (getattr(owner, "_tivimate_subtitles", None) or
                      getattr(owner, "_tivimate_subtitle_controller", None))
        if controller is None:
            from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_subtitles import initTiviMateSettings
            settings = initTiviMateSettings().search
        else:
            settings = controller.subsProSettings.search
        _bridge_debug_log("settings ok; overlay deferred=%s" % (controller is None))
        item = {} if is_live else (getattr(owner, "item", {}) or {})
        kind = "live" if is_live else _content_kind(owner)

        # Live title is already normalized by LivePlayer's EPG context.
        # VOD/Series keep their existing metadata-aware title builder.
        search_title = clean_title if is_live else (_tivimate_search_title(owner, clean_title) or clean_title)

        # The VOD player may expose a provider-decorated name even when the
        # movie/year are correctly identified (e.g. "TGP - It Ends (2026)").
        # Normalize the provider prefix BEFORE sending requests, and send the
        # year through the provider's dedicated field, not twice in the query.
        # Never apply this to Live EPG titles or season/episode search labels.
        if kind == "movie" and not is_live:
            try:
                from .subtitle_title import clean_subtitle_title
                normalized = clean_subtitle_title(search_title).strip()
                year_match = re.search(r"\s*[\(\[]?((?:19|20)\d{2})[\)\]]?\s*$", normalized)
                if year_match:
                    without_year = normalized[:year_match.start()].strip(" ._:-|")
                    if without_year:
                        if not player_movie_year:
                            player_movie_year = int(year_match.group(1))
                        normalized = without_year
                if normalized:
                    search_title = normalized
            except Exception as exc:
                _bridge_debug_log("subtitle title normalization failed", exc)

        # Language + manual behaviour.
        _set_language(settings, language_code)
        try:
            settings.manualSearch.value = False
        except Exception:
            pass

        # BLUE search is a real multi-source search.
        # Never keep a previously selected single provider.
        for attr in ("provider", "movieProvider", "tvshowProvider"):
            try:
                getattr(settings, attr).value = "all"
            except Exception:
                pass
        try:
            settings.openParamsDialogOnSearch.value = False
        except Exception:
            pass
        try:
            settings.useFilePath.value = False
        except Exception:
            pass

        # IMPORTANT:
        # Populate search parameters directly.  We open the screen with
        # resetSearchParams=False so its parser cannot erase TiviMate's title.
        try:
            settings.title.value = search_title
        except Exception:
            pass

        if kind == "episode":
            try:
                settings.type.value = "tv_show"
            except Exception:
                pass

            season = item.get("season_number", item.get("season", item.get("_subdl_season", 0)))
            episode = item.get("episode_number", item.get("episode_num",
                      item.get("episode", item.get("_subdl_episode", 0))))

            try:
                settings.season.value = int(season or 0)
            except Exception:
                pass
            try:
                settings.episode.value = int(episode or 0)
            except Exception:
                pass
            try:
                settings.year.value = 0
            except Exception:
                pass
        elif kind == "live":
            # The provider engine requires a movie/tv_show search type, but
            # Live itself remains a separate context: no VOD year/season/item
            # metadata is injected.  Search only the current EPG/channel title.
            try:
                settings.type.value = "movie"
            except Exception:
                pass
            try:
                settings.season.value = 0
                settings.episode.value = 0
                settings.year.value = 0
            except Exception:
                pass
        else:
            try:
                settings.type.value = "movie"
            except Exception:
                pass
            try:
                settings.season.value = 0
                settings.episode.value = 0
            except Exception:
                pass

            # Use only the year already known by the current player.  If the
            # item fields do not expose it, _tivimate_player_movie_title_year()
            # has already extracted a trailing year from the displayed title.
            try:
                settings.year.value = int(player_movie_year or 0)
            except Exception:
                pass

        stage = "seeker"
        seeker = E2SubsSeeker(session, settings, debug=True)
        _bridge_debug_log("seeker ok: %d providers" % len(getattr(seeker, "seekers", []) or []))

        # Keep multiple public providers active even if an older saved config
        # had previously disabled them. API-key providers are left to their
        # own saved credential/enable state.
        # Activate the complete provider engine imported from the second
        # SubsSupport package. Providers that failed to import keep error!=None
        # and are skipped by the seeker engine.
        try:
            for p in seeker.seekers:
                if getattr(p, "error", None) is None:
                    try:
                        p.settings_provider.setSetting("enabled", True)
                    except Exception:
                        pass
        except Exception:
            pass

        # BLUE is always a real multi-source search.
        try:
            settings.provider.value = "all"
            settings.movieProvider.value = "all"
            settings.tvshowProvider.value = "all"
        except Exception:
            pass

        def _activate_selected(subfile=None):
            if not subfile:
                return
            # A subtitle download/search callback can arrive after Back has
            # closed LivePlayer. Never reactivate a subtitle controller/dialog on a
            # player whose onClose cleanup has already run.
            if getattr(owner, "_epgClosed", False) or getattr(owner, "_closing", False):
                _bridge_debug_log("ignored subtitle result for closed player")
                return
            _bridge_debug_log("selected language=%s %s" % (_preferred_language(), _subtitle_file_diagnostic(subfile)))
            # A provider can label an English file as Arabic. Validate the
            # downloaded text before replacing the currently active subtitle.
            # This is deliberately limited to Arabic; other languages retain
            # their original provider selection behavior.
            if _preferred_language() == "ar":
                try:
                    # Parse text as Unicode, not str() bytes on Python 2.
                    # ASS/SSA and non-SRT files must not be treated as missing
                    # Arabic merely because the lightweight SRT reader cannot
                    # parse that format.
                    from .srt_overlay import parse_srt_file, _decode
                    from .py27_compat import text_type
                    sample = u""
                    if text_type(subfile).lower().endswith((".srt", ".txt")):
                        try:
                            cues = list(parse_srt_file(subfile) or [])
                            sample = u" ".join(text_type(cue[2]) for cue in cues[:120] if len(cue) >= 3)
                        except Exception as exc:
                            _bridge_debug_log("SRT text inspection failed; will check raw file", exc)
                    if not sample:
                        with open(subfile, "rb") as src:
                            sample = _decode(src.read(262144))
                    sample = text_type(sample)
                    arabic_count = sum(1 for c in sample if u"\u0600" <= c <= u"\u06ff")
                    latin_count = sum(1 for c in sample if u"a" <= c.lower() <= u"z")
                    # Reject clearly English results mislabeled Arabic. Never
                    # silently reject a real Arabic subtitle due to English
                    # metadata/header text in ASS/SSA files.
                    if arabic_count < 3 and latin_count > 30:
                        _bridge_debug_log("REJECTED non-Arabic subtitle: arabic=%d latin=%d" % (arabic_count, latin_count))
                        try:
                            owner._showNotification("Selected subtitle is not Arabic. Choose another result.", 1, 6)
                        except Exception:
                            pass
                        return
                except Exception as exc:
                    # A failed language inspection must not block activation.
                    # The full SubsSupport loader performs real parsing below.
                    _bridge_debug_log("Arabic subtitle inspection failed; trying SubsSupport", exc)
            # On VTi the downloaded SRT renderer is an eLabel on the VOD player
            # itself, not an independent Session dialog behind the video plane.
            # This intentionally does not change Live/ASS/SSA or the providers.
            if not is_live:
                activate_direct = getattr(owner, '_activateVtiSRT', None)
                if callable(activate_direct):
                    try:
                        if activate_direct(subfile):
                            _bridge_debug_log('in-player SRT overlay activated')
                            try:
                                owner._savePreferences()
                            except Exception:
                                pass
                            return
                    except Exception as exc:
                        _bridge_debug_log('in-player SRT activation error', exc)
            # Create the native renderer only when a file is selected.
            # On DreamOS search must remain usable even if the overlay fails.
            try:
                active_controller = controller or _controller(owner)
                _bridge_debug_log("overlay ready for selected subtitle")
            except Exception as exc:
                _bridge_debug_log("FAILED selected subtitle overlay", exc)
                try:
                    owner._showNotification("Subtitle renderer error; check subtitle_selection_debug.log", 1, 6)
                except Exception:
                    pass
                return
            # Do not rewrite subtitle cue blocks. The previous Arabic-only
            # filter dropped valid French/Turkish subtitle files and could
            # corrupt cue timing. Keep the provider's original file intact.
            try:
                try:
                    owner.enableSubtitle(None)
                except Exception as exc:
                    _bridge_debug_log("native subtitle disable failed before external load", exc)
                # r333: use the same new-file activation sequence as the
                # original SubsSupport callback: pause -> reset engine -> load on
                # the same service -> refresh if replacing an already-loaded file,
                # otherwise resume the engine on the first external subtitle.
                if is_live:
                    # Set the clock before loading: loadSubs()/resume() consult
                    # getVideoTime() and otherwise start at the first cue.
                    try:
                        engine = getattr(active_controller, "_TiviMateSubtitleSupport__subsEngine", None)
                        begin = int(live_context.get("begin") or 0)
                        duration = int(live_context.get("duration") or 0)
                        # Providers are inconsistent here: accept epoch ms as
                        # well as the documented epoch-second form.
                        if begin > 100000000000:
                            begin //= 1000
                        import time as _time
                        if begin > 0 and begin <= _time.time() and (not duration or _time.time() <= begin + duration + 120):
                            engine._tivimate_live_program_begin = begin
                            engine._tivimate_live_program_duration = max(0, duration)
                        elif engine is not None:
                            engine._tivimate_live_program_begin = 0
                            engine._tivimate_live_program_duration = 0
                    except Exception as exc:
                        _bridge_debug_log("live subtitle clock setup failed", exc)
                if active_controller.activateSelectedSubs(subfile):
                    previous_external = getattr(owner, '_external_subs', None)
                    if previous_external is not None and previous_external is not active_controller:
                        try:
                            previous_external.exitSubs()
                        except Exception:
                            pass
                    _bridge_debug_log("external subtitle activation success")
                    # Explicitly sync/show after activation for both VOD and
                    # Live; engine.resume() alone may not paint the first cue.
                    try:
                        active_controller.playAfterSeek()
                    except Exception as exc:
                        _bridge_debug_log("initial subtitle timing sync failed", exc)
                    # r295: keep the exact controller that successfully loaded
                    # the subtitle as the single active controller for RED/sync.
                    owner._external_subs = active_controller
                    owner._subssupport = active_controller
                    owner._tivimate_subtitles = active_controller
                    owner._tivimate_subtitle_controller = active_controller
                    previous_file = _u(getattr(owner, "_external_subtitle_path", "") or "")
                    if previous_file != _u(subfile):
                        # A different subtitle file has its own timing: never
                        # carry the old file's delay over.
                        owner._subtitle_session_delay_ms = 0
                    owner._external_subtitle_path = _u(subfile)
                    owner._external_subtitle_owner = "subssupport"
                    # User-selected external subtitle wins over delayed saved-track restore.
                    owner._subtitle_restore_attempted = True
                    # A SubsSupport-loaded file must be rendered only by
                    # SubsSupport. Clear a stale TiviMate overlay without
                    # touching search/providers or the active controller.
                    try:
                        clear_overlay = getattr(owner, "_clearSRTOverlay", None)
                        if callable(clear_overlay):
                            clear_overlay()
                    except Exception:
                        pass
                    try:
                        active_controller._tivimateDelayChangedCB = getattr(owner, "_tivimateSubtitleDelayChanged", None)
                    except Exception:
                        pass
                    # Restore only the already-known per-movie delay.
                    try:
                        delay_ms = int(getattr(owner, "_subtitle_session_delay_ms", 0) or 0)
                        setter = getattr(active_controller, "setTiviMateDelay", None) or getattr(active_controller, "setSubsDelay", None)
                        if callable(setter) and delay_ms:
                            setter(delay_ms)
                        save = getattr(owner, "_savePreferences", None)
                        if callable(save):
                            save()
                    except Exception:
                        pass
                    # Do not force playAfterSeek() after activation. SubsSupport
                    # either resumes the engine for the first file or refreshes the
                    # renderer when replacing an already-loaded external subtitle.
                else:
                    _bridge_debug_log("SubsSupport parser/activation returned False for %r" % (subfile,))
                    try:
                        owner._showNotification("Subtitle file could not be activated; check subtitle_selection_debug.log", 1, 6)
                    except Exception:
                        pass
            except Exception as exc:
                _bridge_debug_log("selected subtitle activation failed: %r" % (subfile,), exc)

        def selected(subfile=None):
            # Session.processDelay calls the selection callback AFTER it has
            # popped/restored the player's ActionMaps on both legacy and new E2.
            # Never call session.popCurrent() here: on legacy VTi that can pop
            # an additional dialog and leave the player unresponsive.
            _subtitle_focus_state(session, owner, 'search_callback')
            if getattr(owner, '_subtitle_search_hud_locked', False):
                owner._subtitle_search_hud_locked = False
                try:
                    owner.unlockShow()
                except Exception:
                    pass
            if getattr(owner, '_closing', False) or getattr(owner, '_epgClosed', False):
                return
            _subtitle_restore_player_keys(owner, session, 'search_return')
            if not subfile:
                return
            try:
                pending = getattr(owner, '_subtitle_activation_timer', None)
                if pending is not None:
                    pending.stop()
            except Exception:
                pass
            attempts = [0]

            def activate_when_returned():
                owner._subtitle_activation_timer = None
                if getattr(owner, '_closing', False) or getattr(owner, '_epgClosed', False):
                    return
                # No overlay/dialog is created until the real player is the
                # currently executing screen. Do not reactivate unrelated modals.
                if not _subtitle_restore_player_keys(owner, session, 'pre_activation'):
                    attempts[0] += 1
                    if attempts[0] <= 10:
                        try:
                            timer = owner._makeTimer(activate_when_returned)
                            owner._subtitle_activation_timer = timer
                            timer.start(150, True)
                        except Exception:
                            pass
                    else:
                        _subtitle_focus_state(session, owner, 'activation_aborted_not_modal')
                    return
                _activate_selected(subfile)
                _subtitle_restore_player_keys(owner, session, 'post_activation')

            try:
                timer = owner._makeTimer(activate_when_returned)
                owner._subtitle_activation_timer = timer
                # Wait for VTi's delayed close processing to settle; do not
                # manipulate the modal stack ourselves.
                timer.start(250, True)
            except Exception:
                activate_when_returned()

        _cached_poster(owner)

        # resetSearchParams=False is intentional:
        # the search screen must use the title/type/season/episode from TiviMate.
        stage = "openWithCallback"
        _bridge_debug_log("opening search screen: title=%r kind=%r auto=%r" % (search_title, kind, auto_search_on_open))
        # Session.pushCurrent saves the player's current shown state. When
        # subtitles are opened while the auto-hidden HUD is off, VTi restores
        # a hidden player. Lock the HUD visible until the search callback.
        if callable(getattr(owner, 'lockShow', None)):
            try:
                owner.lockShow()
                owner._subtitle_search_hud_locked = True
            except Exception:
                owner._subtitle_search_hud_locked = False
        _subtitle_focus_state(session, owner, 'before_search_open')
        from .vti_compat import safe_open_screen
        _subtitle_search_pause(owner, controller, is_live)

        def selected_and_resume(*cb_args, **cb_kwargs):
            _subtitle_search_resume(owner)
            return selected(*cb_args, **cb_kwargs)

        opened = safe_open_screen(
            session,
            selected_and_resume,
            TiviMateSubtitleSearch,
            seeker,
            settings,
            None,
            [search_title],
            False,
            False,
            auto_search_on_open
        )
        if opened is None:
            _subtitle_search_resume(owner)
            if getattr(owner, '_subtitle_search_hud_locked', False):
                owner._subtitle_search_hud_locked = False
                try:
                    owner.unlockShow()
                except Exception:
                    pass
            _subtitle_focus_state(session, owner, 'search_open_failed')
            owner._tivimate_subtitle_search_error = "screen (see /home/root/tivimatee2_vti_screen_errors.log)"
            _bridge_debug_log("openWithCallback failed; player restored")
            return False
        _bridge_debug_log("openWithCallback ok")
        return True
    except Exception as exc:
        _subtitle_search_resume(owner)
        if getattr(owner, '_subtitle_search_hud_locked', False):
            owner._subtitle_search_hud_locked = False
            try:
                owner.unlockShow()
            except Exception:
                pass
        _subtitle_focus_state(session, owner, 'search_exception')
        # Display the missing module/symbol, not only the generic word 'import'.
        # Keep full traceback in the persistent log for further diagnosis.
        try:
            message = _u(exc).replace(u"\n", u" ").strip()
        except Exception:
            message = u""
        detail = (u"%s: %s" % (type(exc).__name__, message))[:105]
        owner._tivimate_subtitle_search_error = (stage + u" - " + detail) if detail else stage
        _bridge_debug_log("FAILED at %s (%s)" % (stage, type(exc).__name__), exc)
        try:
            _bridge_debug_log(traceback.format_exc())
        except Exception:
            pass
        return False

