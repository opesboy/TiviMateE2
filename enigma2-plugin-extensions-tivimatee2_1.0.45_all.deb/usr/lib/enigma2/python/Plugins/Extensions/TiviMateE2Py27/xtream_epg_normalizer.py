# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch, text_type
"""Xtream Live EPG decoding and timestamp conversion for all Live skins.

Do not manufacture a current event by shifting an unrelated schedule. Xtream
short EPG is supplied by its panel; UltraStalker's M3U adapter has no Xtream
EPG implementation (epg() returns []).
"""
import base64
import re
import time
from Plugins.Extensions.TiviMateE2Py27.py27_html import unescape

_B64 = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")


def decode_xtream_epg_text(value):
    if value is None:
        return ""
    if isinstance(value, bytes):
        raw = value.decode('utf-8', 'replace').strip()
    else:
        raw = text_type(value).strip()
    if not raw:
        return ""
    encoded = "".join(raw.split())
    # Protect plain English labels like News, Film, SHOW and Star. Strict UTF-8
    # alone cannot distinguish some short ordinary titles from Base64 bytes.
    if len(encoded) >= 8 and len(encoded) % 4 != 1 and py27_fullmatch(_B64, encoded):
        try:
            decoded_bytes = base64.b64decode(encoded + "=" * (-len(encoded) % 4))
            decoded = decoded_bytes.decode('utf-8', 'strict').strip()
            if (len(decoded) >= 3 and any(ch.isalnum() for ch in decoded)
                    and all(ord(ch) >= 32 or ch in '\n\t' for ch in decoded)):
                raw = decoded
        except (ValueError, UnicodeError, TypeError):
            # Only malformed candidate Base64 reaches here; the raw provider
            # title always remains available without a lossy replacement decode.
            pass
    return " ".join(unescape(raw).split())


def epg_row_title(row):
    """Return the actual programme title from common Xtream/XMLTV fields.

    Do not use a plot/description as a made-up title. All text goes through
    the same Base64/UTF-8 decoder as the provider Live list.
    """
    if not isinstance(row, dict):
        return u""
    for key in ("title", "name", "programme", "event_name", "epg_title",
                "program_title", "event_title", "now_title"):
        value = row.get(key)
        if value not in (None, u""):
            title = decode_xtream_epg_text(value)
            if title:
                return title
    return u""
