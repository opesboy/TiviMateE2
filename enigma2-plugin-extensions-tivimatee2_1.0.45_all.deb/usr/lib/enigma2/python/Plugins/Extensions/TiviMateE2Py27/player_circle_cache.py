# -*- coding: utf-8 -*-
"""320x320 circular VOD poster with REAL PNG transparency on Python 2 DreamOS.

Does not alter the downloaded source artwork.  Unlike ePixmap.setCornerRadius,
this works on older DreamOS builds because the image itself contains alpha.
All image processing is outside the Enigma2 GUI thread; one concurrent worker.
"""
from __future__ import absolute_import
import hashlib
import os
import subprocess
import threading

from .storage import data_path
from .py27_compat import which, subprocess_run
from .py27_futures import ThreadPoolExecutor

_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='TiviPlayerCircle')
_LOCK = threading.RLock()
_PENDING = {}
_MAX_PENDING = 8
_SIZE = 320


def _key(source, logo=False):
    # Refer to cached source bytes, not os.utime() used for LRU retention.
    # Avoid regenerating a 320px PNG every time the same poster is revisited.
    from .round_artwork import _source_key
    identity = _source_key(source) + ('|logo-r1' if logo else '|round-r4')
    if not isinstance(identity, bytes):
        identity = identity.encode('utf-8')
    return hashlib.sha256(identity).hexdigest()[:28]


def _destination(source, logo=False):
    return data_path('player_circles', '%s_%s.png' % ('logo' if logo else 'round', _key(source, logo)))


def cached(source, logo=False):
    try:
        if not source or not os.path.isfile(source):
            return ''
        target = _destination(source, logo)
        if os.path.isfile(target) and os.path.getsize(target) > 2000:
            return target
    except Exception:
        pass
    return ''


def _pillow(source, target):
    from PIL import Image, ImageDraw
    img = Image.open(source)
    try:
        img = img.convert('RGBA')
        w, h = img.size
        ratio = max(float(_SIZE) / max(1, w), float(_SIZE) / max(1, h))
        nw, nh = max(_SIZE, int(w * ratio + 0.5)), max(_SIZE, int(h * ratio + 0.5))
        method = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
        img = img.resize((nw, nh), method)
        # Same framing as Royal Circles: a little above centre.
        x, y = (nw - _SIZE)//2, int((nh - _SIZE) * 0.40)
        img = img.crop((x, y, x + _SIZE, y + _SIZE))
        # Full-bleed smooth edge, no inner white rim (gold ring is outside).
        big = _SIZE * 3
        alpha = Image.new('L', (big, big), 0)
        ImageDraw.Draw(alpha).ellipse((0, 0, big - 1, big - 1), fill=255)
        alpha = alpha.resize((_SIZE, _SIZE), method)
        img.putalpha(alpha)
        img.save(target, 'PNG')
    finally:
        try: img.close()
        except Exception: pass


def _ffmpeg(source, target):
    tool = which('ffmpeg')
    if not tool:
        raise RuntimeError('ffmpeg not found')
    # Old-compatible scale/crop and alpha channel, no dependency on PIL.
    # Source stays untouched; the square is center-cropped before the mask.
    vf = ("scale=320:320:force_original_aspect_ratio=increase,"
          "crop=320:320:(iw-320)/2:(ih-320)*0.4,format=rgba,"
          "geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':"
          "a='if(lte((X-159.5)*(X-159.5)+(Y-159.5)*(Y-159.5),25440),255,0)'")
    subprocess_run([tool, '-nostdin', '-loglevel', 'error', '-y', '-i', source,
                    '-vf', vf, '-frames:v', '1', '-c:v', 'png', target],
                   timeout=12, check=True, stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE)


def _imagemagick(source, target):
    tool = which('convert')
    if not tool:
        raise RuntimeError('ImageMagick not found')
    mask = os.path.join(os.path.dirname(__file__), 'tivimate_infobar',
                        'player', 'player_circle_alpha_mask_r2.png')
    if not os.path.isfile(mask):
        raise RuntimeError('PNG mask missing')
    subprocess_run([tool, source, '-auto-orient', '-resize', '320x320^',
                    '-gravity', 'center', '-extent', '320x320', mask,
                    '-alpha', 'off', '-compose', 'CopyOpacity', '-composite', target],
                   timeout=12, check=True, stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE)


# ---- channel logos (catch-up): fit the whole logo on a dark plate ----------
_PLATE = (17, 22, 34)
_LOGO_BOX = 238          # ~74% of the circle


def _pillow_logo(source, target):
    from PIL import Image, ImageDraw
    logo = Image.open(source)
    try:
        logo = logo.convert('RGBA')
        try:
            box = logo.getbbox()
            if box:
                logo = logo.crop(box)
        except Exception:
            pass
        w, h = logo.size
        ratio = min(float(_LOGO_BOX) / max(1, w), float(_LOGO_BOX) / max(1, h),
                    (_SIZE * 0.86) / max(1.0, (w * w + h * h) ** 0.5))
        nw, nh = max(1, int(w * ratio + 0.5)), max(1, int(h * ratio + 0.5))
        method = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
        logo = logo.resize((nw, nh), method)
        canvas = Image.new('RGBA', (_SIZE, _SIZE), _PLATE + (255,))
        canvas.paste(logo, ((_SIZE - nw) // 2, (_SIZE - nh) // 2), logo)
        big = _SIZE * 3
        alpha = Image.new('L', (big, big), 0)
        ImageDraw.Draw(alpha).ellipse((0, 0, big - 1, big - 1), fill=255)
        canvas.putalpha(alpha.resize((_SIZE, _SIZE), method))
        canvas.save(target, 'PNG')
    finally:
        try: logo.close()
        except Exception: pass


def _ffmpeg_logo(source, target):
    tool = which('ffmpeg')
    if not tool:
        raise RuntimeError('ffmpeg not found')
    fc = ("[1:v]scale=%d:%d:force_original_aspect_ratio=decrease,format=rgba[l];"
          "[0:v][l]overlay=(W-w)/2:(H-h)/2,format=rgba,"
          "geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':"
          "a='if(lte((X-159.5)*(X-159.5)+(Y-159.5)*(Y-159.5),25440),255,0)'") % (_LOGO_BOX - 30, _LOGO_BOX - 30)
    subprocess_run([tool, '-nostdin', '-loglevel', 'error', '-y',
                    '-f', 'lavfi', '-i', 'color=c=0x111622:s=320x320', '-i', source,
                    '-filter_complex', fc, '-frames:v', '1', '-c:v', 'png', target],
                   timeout=12, check=True, stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE)


def _imagemagick_logo(source, target):
    tool = which('convert')
    if not tool:
        raise RuntimeError('ImageMagick not found')
    mask = os.path.join(os.path.dirname(__file__), 'tivimate_infobar',
                        'player', 'player_circle_alpha_mask_r2.png')
    if not os.path.isfile(mask):
        raise RuntimeError('PNG mask missing')
    subprocess_run([tool, '-size', '320x320', 'xc:#111622', '(', source, '-auto-orient', '-trim', '+repage',
                    '-resize', '%dx%d' % (_LOGO_BOX - 30, _LOGO_BOX - 30), ')',
                    '-gravity', 'center', '-composite', mask,
                    '-alpha', 'off', '-compose', 'CopyOpacity', '-composite', target],
                   timeout=12, check=True, stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE)


def generate(source, logo=False):
    hit = cached(source, logo)
    if hit:
        return hit
    try:
        target = _destination(source, logo)
    except Exception:
        return ''
    temp = target + '.%d.png' % os.getpid()
    try:
        for method in ((_pillow_logo, _ffmpeg_logo, _imagemagick_logo) if logo else (_pillow, _ffmpeg, _imagemagick)):
            try:
                method(source, temp)
                if os.path.isfile(temp) and os.path.getsize(temp) > 2000:
                    # Rename atomically: never show a partially written PNG.
                    os.rename(temp, target)
                    return target
            except Exception as exc:
                print('[TiviMateE2Py27] circular poster %s: %s' % (method.__name__, exc))
            finally:
                try:
                    if os.path.exists(temp): os.unlink(temp)
                except Exception:
                    pass
    except Exception as exc:
        print('[TiviMateE2Py27] circular poster cache: %s' % exc)
    return ''


def request(source, callback, logo=False):
    """Return cached path when ready; otherwise schedule one conversion.

    Callback is dispatched to Enigma2's main thread, not called from worker.
    Return True when callback is scheduled, False when nothing can be done.
    """
    hit = cached(source, logo)
    if hit:
        return hit
    try:
        from twisted.internet import reactor
        if not hasattr(reactor, 'callFromThread'):
            return False
        if not source or not os.path.isfile(source):
            return False
        key = _key(source, logo)
    except Exception:
        return False
    with _LOCK:
        if key in _PENDING:
            if len(_PENDING[key]) < 12:
                _PENDING[key].append(callback)
            return True
        if len(_PENDING) >= _MAX_PENDING:
            return False
        _PENDING[key] = [callback]

    def work():
        path = generate(source, logo)
        with _LOCK:
            callbacks = _PENDING.pop(key, [])
        for cb in callbacks:
            try: reactor.callFromThread(cb, path)
            except Exception: pass
    try:
        _POOL.submit(work)
        return True
    except Exception:
        with _LOCK:
            _PENDING.pop(key, None)
        return False
