# -*- coding: utf-8 -*-
"""Search backend discovery and truthful display labels. No player dependencies."""
import os
import glob


def native_backend_dirs(root='/usr/lib/enigma2/python/Plugins/Extensions'):
    found = []
    for name in ('SubsSupport', 'SubsSupportPro'):
        path = os.path.join(root, name)
        if (any(os.path.isfile(os.path.join(path, f)) for f in
                ('seek.so', 'seek.py', 'seek.pyc', 'seek.pyo')) or
                glob.glob(os.path.join(path, 'seek.*.so'))):
            found.append(path)
    return found


# Display aliases only. Never use these labels for lookup, deduplication or download.
_DISPLAY_NAMES = {
    'opensubtitles.org': 'opensubtitles.org',
    'opensubtitles.stremio': 'opensubtitles.stremio',
    'opensubtitles.com': 'opensubtitles.com',
    'os.org.fnc': 'OS.org.FNC',
    'os.com.fnc': 'OS.com.FNC',
    'subdl.fnc': 'SubDL.FNC',
    'subdl.com': 'SubDL',
    'subdl': 'SubDL',
    'yify.fnc': 'Yify.FNC',
    'ytssubs': 'ytssubs',
    'subsyts': 'subsyts',
    'subf2m': 'subf2m',
    'indexsubtitle': 'indexsubtitle',
    'indexsubtitle.cc': 'indexsubtitle',
    'wyzie': 'wyzie',
    'subtitlecat': 'subtitlecat',
}


def provider_label(identifier, default=None):
    key = (identifier or '').strip().lower()
    return _DISPLAY_NAMES.get(key, default if default is not None else (identifier or ''))


def provider_display_name(row):
    provider = row.get('provider') or ''
    label = provider_label(provider)
    if provider.strip().lower() == 'wyzie':
        source = row.get('source') or ''
        if source and source.strip().lower() != 'wyzie':
            # Preserve provenance: a Wyzie result is not a native FNC result.
            return provider_label(source) + ' / Wyzie'
    return label
