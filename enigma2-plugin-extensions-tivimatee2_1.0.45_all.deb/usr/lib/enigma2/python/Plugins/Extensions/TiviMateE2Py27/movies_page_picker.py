# -*- coding: utf-8 -*-
"""Page design picker; GENRE and Packages use six existing designs."""
import os
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from .display_scale import scale_skin, sx, sy
from .movies_layout_choice import get_content_layout
from enigma import ePoint

_ASSETS = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker'
_CHOICES = ('new', 'current', 'grid24', 'apple', 'royal', 'circles', 'posters', 'genre')
# Only child screens (GENRE and Packages) use these six poster designs.
# Keep Movies/Series PAGE DESIGN unchanged with the full eight options.
_SIX_CHOICES = ('grid24', 'apple', 'royal', 'circles', 'posters', 'genre')
_COLS = 4
_CARDS = tuple((x, y) for y in (195, 575) for x in (75, 525, 975, 1425))
_SIX_CARDS = tuple((x, y) for y in (195, 575) for x in (265, 750, 1235))
_W, _H = 420, 300
# Poster designs keep their saved per-context style code.
# New and Classic remain available in the separate Movies/TV PAGE DESIGN picker.
_STYLE_OF = {'royal': 'circle3', 'circles': 'circle', 'posters': 'poster',
             'genre': 'genre', 'grid24': 'cinematic', 'apple': 'apple'}
_CARD_OF = dict((v, k) for k, v in _STYLE_OF.items())


def _pix(name, x, y, w, h, z, image):
    return ('<widget name="%s" position="%d,%d" size="%d,%d" pixmap="%s/%s" '
            'alphatest="blend" scale="1" zPosition="%d" />' % (name, x, y, w, h, _ASSETS, image, z))


class MoviesPagePicker(Screen):
    skin = scale_skin(
        '<screen name="MoviesPagePicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05060A">'
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s/picker8_bg.jpg" alphatest="off" scale="1" zPosition="1" />' % _ASSETS
        + ''.join(_pix('dim%d' % i, x, y, _W, _H, 2, 'picker8_dim.png') for i, (x, y) in enumerate(_CARDS))
        + _pix('designFocus', _CARDS[0][0] - 20, _CARDS[0][1] - 20, _W + 40, _H + 40, 3, 'picker8_focus.png')
        + _pix('activeBadge', _CARDS[0][0] + _W - 166, _CARDS[0][1] + 16, 150, 40, 4, 'picker_active.png')
        + '</screen>')

    # Same premium card artwork, gold focus and ACTIVE label as PAGE DESIGN,
    # but GENRE/Packages show six cards in a balanced 3x2 grid.
    skin_six = scale_skin(
        '<screen name="MoviesPagePicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05060A">'
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s/picker6_bg.jpg" alphatest="off" scale="1" zPosition="1" />' % _ASSETS
        + ''.join(_pix('dim%d' % i, x, y, _W, _H, 2, 'picker8_dim.png') for i, (x, y) in enumerate(_SIX_CARDS))
        + _pix('designFocus', _SIX_CARDS[0][0] - 20, _SIX_CARDS[0][1] - 20, _W + 40, _H + 40, 3, 'picker8_focus.png')
        + _pix('activeBadge', _SIX_CARDS[0][0] + _W - 166, _SIX_CARDS[0][1] + 16, 150, 40, 4, 'picker_active.png')
        + '</screen>')

    def __init__(self, session, kind='vod', context=None, category_styles=False):
        # Separate the PAGE DESIGN picker from the GENRE/Packages poster picker.
        # The main Movies/Series picker always has ALL 8 page layouts (including
        # 01 NEW and 02 CLASSIC), even if a stale context leaks from navigation.
        # Only the dedicated PosterViewPicker explicitly requests 6 styles.
        category_styles = (category_styles is True)
        if category_styles:
            self.skin = self.__class__.skin_six
        Screen.__init__(self, session)
        self.kind = 'series' if kind == 'series' else 'vod'
        self.choices = _SIX_CHOICES if category_styles else _CHOICES
        self.cards = _SIX_CARDS if category_styles else _CARDS
        self.cols = 3 if category_styles else _COLS
        self.context = (context or 'package') if category_styles else None
        if self.context:
            from .view_style_picker import get_style
            active = _CARD_OF.get(get_style(context, self.kind))
        else:
            active = get_content_layout(self.kind)
        self.active = self.choices.index(active) if active in self.choices else -1
        self.index = self.active if self.active >= 0 else 0
        self._finished = False
        for i in range(len(self.cards)):
            self['dim%d' % i] = Pixmap()
        self['designFocus'] = Pixmap()
        self['activeBadge'] = Pixmap()
        self['actions'] = ActionMap(['OkCancelActions', 'DirectionActions', 'ChannelSelectBaseActions',
            'InfobarChannelSelection', 'MenuActions'], {'ok': self.accept, 'cancel': self.cancel,
            'menu': self.cancel, 'left': self.left, 'right': self.right,
            'up': self.up, 'down': self.down, 'pageUp': self.left, 'pageDown': self.right,
            'channelUp': self.left, 'channelDown': self.right,
            'prevBouquet': self.left, 'nextBouquet': self.right}, -1)
        self.onLayoutFinish.append(self.prepare)

    def prepare(self):
        if self._finished:
            return
        try:
            if self.active >= 0:
                x, y = self.cards[self.active]
                self['activeBadge'].instance.move(ePoint(sx(x + _W - 166), sy(y + 16)))
                self['activeBadge'].show()
            else:
                self['activeBadge'].hide()
        except Exception:
            pass
        self._render_focus()

    def _render_focus(self):
        if self._finished:
            return
        x, y = self.cards[self.index]
        self['designFocus'].instance.move(ePoint(sx(x - 20), sy(y - 20)))
        self['designFocus'].show()
        for i in range(len(self.cards)):
            if i == self.index:
                self['dim%d' % i].hide()
            else:
                self['dim%d' % i].show()

    def left(self):
        self.index = (self.index - 1) % len(self.choices)
        self._render_focus()

    def right(self):
        self.index = (self.index + 1) % len(self.choices)
        self._render_focus()

    def up(self):
        self.index = (self.index - self.cols) % len(self.choices)
        self._render_focus()

    def down(self):
        self.index = (self.index + self.cols) % len(self.choices)
        self._render_focus()

    # Older callers may still use these names.
    previous = left
    next = right

    def cancel(self):
        if not self._finished:
            self._finished = True
            self.close(None)

    def accept(self):
        if not self._finished:
            self._finished = True
            chosen = self.choices[self.index]
            if self.context:
                style = _STYLE_OF.get(chosen)
                if style:
                    from .view_style_picker import save_style
                    save_style(self.context, self.kind, style)
                    self.close(style)
                else:
                    self.close('page:' + chosen)
                return
            self.close(chosen)
