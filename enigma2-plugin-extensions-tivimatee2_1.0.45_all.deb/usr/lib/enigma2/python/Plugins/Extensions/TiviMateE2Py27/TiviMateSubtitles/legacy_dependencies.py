# -*- coding: utf-8 -*-
"""Only use Python 2 compatible libraries; never reuse the Python 3 vendor tree."""
import os
import sys

def prepare():
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        import six
    except ImportError:
        import imp
        six = imp.load_source('six', os.path.join(here, '_vendor_six.py'))
    if not all(hasattr(six, name) for name in ('ensure_str', 'ensure_text', 'ensure_binary')):
        import imp
        bundled = imp.load_source('_tivimate_legacy_six', os.path.join(here, '_vendor_six.py'))
        for name in ('ensure_str', 'ensure_text', 'ensure_binary'):
            if not hasattr(six, name):
                setattr(six, name, getattr(bundled, name))
    # Some old receivers ship the compatible HTML parser inside their native
    # SubsSupport plugin instead of site-packages. Never import its seekers.
    extensions = os.path.dirname(os.path.dirname(here))
    # Optional packages already installed on the receiver: do not download
    # dependencies or import another plugin's provider modules automatically.
    candidates = [os.path.join(here, '_vendor_legacy')]
    for plugin in ('SubsSupport', 'SubsSupportPro'):
        native = os.path.join(extensions, plugin)
        for rel in ('libs', 'lib', 'modules', 'packages', '_vendor', ''):
            candidates.append(os.path.join(native, rel))
    try:
        from bs4 import BeautifulSoup
    except Exception:
        for path in candidates:
            if not os.path.isdir(os.path.join(path, 'bs4')):
                continue
            added = path not in sys.path
            if added:
                sys.path.append(path)
            try:
                from bs4 import BeautifulSoup
                break
            except Exception:
                if added:
                    sys.path.remove(path)
    return six
