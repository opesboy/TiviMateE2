# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import TimeoutError

import hashlib
import io
import json
import os
import socket
import time
import zipfile

from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode, urlparse
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import HTTPError, URLError
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen

from .core import BASE, fetch, load_json, save_json
from .subtitle_title import subtitle_title_candidates
from .storage import data_path

SETTINGS_FILE = os.path.join(BASE, "subdl.json")
API_V2_URL = "https://api.subdl.com/api/v2/subtitles/search"
API_V1_URL = "https://api.subdl.com/api/v1/subtitles"
DOWNLOAD_HOST = "dl.subdl.com"
API_HOST = "api.subdl.com"
DOWNLOAD_PREFIX = "https://" + DOWNLOAD_HOST
V2_DOWNLOAD_PREFIX = "https://" + API_HOST + "/api/v2/subtitles/"
DOWNLOAD_DIR = data_path("subtitles")
MAX_SUBTITLE_BYTES = 3 * 1024 * 1024
# SubDL can intermittently close or delay a connection.  Requests happen in a
# background player thread, so use only two short bounded retries for transient
# faults.  Authentication and rate-limit failures are never retried.
REQUEST_ATTEMPTS = 3
RETRY_DELAYS = (0.35, 0.90)
# The installed SubsSupport parser is most reliable with SubRip.  Limiting
# external SubDL results to SRT prevents unsupported ASS/VTT files from being
# downloaded and then rejected by the receiver.
SAFE_FORMATS = ("srt",)
# Some SubDL downloads are ZIP archives even when the selected result is SRT.
# Extraction stays in memory, accepts SRT only, and is bounded against archives
# with excessive members or expansion ratios.
MAX_ARCHIVE_MEMBERS = 64
MAX_ARCHIVE_EXPANSION_RATIO = 250

AUTH_ERROR = "The SubDL key is invalid or inactive. Put a valid key.txt on HDD/USB/MMC or /etc/enigma2, choose Import SubDL API Key, then try again."
NETWORK_ERROR = "Could not connect to SubDL. Check your internet connection and try again."
SERVICE_ERROR = "SubDL could not process the request right now. Try again later."
RATE_LIMIT_ERROR = "The temporary SubDL request limit was reached. Wait a moment, then try again."
PAID_DOWNLOAD_ERROR = "SubDL accepted the search but requires an active paid API plan for this download. The subtitle was not downloaded."

LANGUAGE_CHOICES = [
    ("Arabic", "ar"),
    ("English", "en"),
    ("Turkish", "tr"),
    ("French", "fr"),
    ("Spanish", "es"),
    ("Chinese", "zh"),
    ("German", "de"),
    ("Italian", "it"),
    ("Portuguese", "pt"),
    ("Russian", "ru"),
    ("Persian", "fa"),
    # Every other language of the subtitle language list (one entry per code).
    ("Bosnian", "bs"),
    ("Bulgarian", "bg"),
    ("Catalan", "ca"),
    ("Croatian", "hr"),
    ("Czech", "cs"),
    ("Danish", "da"),
    ("Dutch", "nl"),
    ("Estonian", "et"),
    ("Finnish", "fi"),
    ("Frisian", "fy"),
    ("Greek", "el"),
    ("Hindi", "hi"),
    ("Hungarian", "hu"),
    ("Icelandic", "is"),
    ("Indonesian", "id"),
    ("Kurdish", "ku"),
    ("Latvian", "lv"),
    ("Lithuanian", "lt"),
    ("Nepali", "ne"),
    ("Norwegian", "no"),
    ("Polish", "pl"),
    ("Romanian", "ro"),
    ("Serbian", "sr"),
    ("Slovak", "sk"),
    ("Slovenian", "sl"),
    ("Swedish", "sv"),
    ("Thai", "th"),
    ("Ukrainian", "uk"),
    ("Vietnamese", "vi"),
]
KIND_CHOICES = [
    ("Standard", "standard"),
    ("Hearing Impaired (HI)", "hi"),
    ("All Types", "all"),
]


def load_settings():
    data = load_json(SETTINGS_FILE, {}) or {}
    language = str(data.get("language") or "ar").lower()
    known_languages = [item[1] for item in LANGUAGE_CHOICES]
    if language not in known_languages:
        language = "ar"
    kind = str(data.get("kind") or "standard").lower()
    if kind not in ("standard", "hi", "all"):
        kind = "standard"
    return {
        "api_key": str(data.get("api_key") or "").strip(),
        "language": language,
        "kind": kind,
    }


def save_settings(api_key, language="ar", kind="standard"):
    api_key = str(api_key or "").strip()
    language = str(language or "ar").lower()
    kind = str(kind or "standard").lower()
    if language not in [item[1] for item in LANGUAGE_CHOICES]:
        language = "ar"
    if kind not in ("standard", "hi", "all"):
        kind = "standard"
    save_json(SETTINGS_FILE, {"api_key": api_key, "language": language, "kind": kind})
    return True


def _text(value):
    return str(value or "").strip()


def _number(value):
    try:
        return int(str(value).strip())
    except Exception:
        return None


def _language_code(value):
    """Normalize SubDL's ISO-639 labels to our two-letter UI codes."""
    raw = _text(value).lower().replace("_", "-")
    aliases = {
        "ar": "ar", "ara": "ar", "arabic": "ar",
        "en": "en", "eng": "en", "english": "en",
        "tr": "tr", "tur": "tr", "turkish": "tr",
        "fr": "fr", "fra": "fr", "fre": "fr", "french": "fr",
        "es": "es", "spa": "es", "spanish": "es",
    }
    return aliases.get(raw, raw[:2])


