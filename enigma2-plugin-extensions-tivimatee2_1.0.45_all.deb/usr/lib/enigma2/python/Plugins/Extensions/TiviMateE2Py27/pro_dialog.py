# -*- coding: utf-8 -*-
"""Professional replacement for the stock ChoiceBox: server switch and app font.

Same list in, same tuple out as ChoiceBox, so every caller keeps its callback.
"""
from __future__ import absolute_import
import os
import re

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePoint, gFont
from skin import parseColor

from .display_scale import scale_skin, sx, sy

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27"

try:
    text_type = unicode
except NameError:
    text_type = str


def _u(value):
    if isinstance(value, text_type):
        return value
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.decode("latin-1")
    return text_type(value or u"")


def _g(value):
    """Enigma2 GUI text on Python 2.7 is UTF-8 bytes."""
    value = _u(value)
    return value.encode("utf-8") if not isinstance(value, str) else value


ROWS = 9
PW, PH = 1460, 840
LX, LY, RW, RH = 40, 150, 800, 68          # list rows (panel coordinates)
SX, SY, SW = 910, 160, 480                 # side panel content


def _build_skin(kind):
    art = os.path.join(PLUGIN_PATH, "skins", "pro_dialog")
    x = ['<screen name="TiviProChoice_%s" position="center,center" size="%d,%d" flags="wfNoBorder" backgroundColor="transparent">' % (kind, PW, PH),
         '<ePixmap position="0,0" size="%d,%d" pixmap="%s/pro_panel_%s.png" alphatest="blend" zPosition="0" />' % (PW, PH, art, kind),
         '<widget name="title" position="130,30" size="900,46" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" noWrap="1" zPosition="3" />',
         '<widget name="subtitle" position="130,74" size="900,30" font="Regular;19" foregroundColor="#A0AAB9" transparent="1" noWrap="1" zPosition="3" />',
         '<widget name="count" position="1200,48" size="200,42" font="Regular;18" foregroundColor="#E2B84F" transparent="1" halign="center" valign="center" zPosition="3" />',
         '<widget name="selector" position="%d,%d" size="828,88" pixmap="%s/pro_row_sel.png" alphatest="blend" zPosition="2" />' % (LX - 14, LY - 14, art)]
    for i in range(ROWS):
        y = LY + i * RH
        x += ['<widget name="row%d" position="%d,%d" size="800,60" pixmap="%s/pro_row.png" alphatest="blend" zPosition="1" />' % (i, LX, y, art),
              '<widget name="num%d" position="%d,%d" size="34,34" font="Regular;17" foregroundColor="#E2B84F" transparent="1" halign="center" valign="center" zPosition="4" />' % (i, LX + 16, y + 12),
              '<widget name="dot%d" position="%d,%d" size="14,14" alphatest="blend" zPosition="4" />' % (i, LX + 68, y + 23),
              '<widget name="name%d" position="%d,%d" size="%d,60" font="Regular;25" foregroundColor="#E4E8EE" transparent="1" valign="center" noWrap="1" zPosition="4" />' % (i, LX + (98 if kind == "server" else 72), y, 560 if kind == "server" else 560),
              '<widget name="typebg%d" position="%d,%d" size="110,30" alphatest="blend" zPosition="4" />' % (i, LX + RW - 290, y + 15),
              '<widget name="type%d" position="%d,%d" size="110,30" font="Regular;15" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="5" />' % (i, LX + RW - 290, y + 15),
              '<widget name="active%d" position="%d,%d" size="130,32" pixmap="%s/pro_active.png" alphatest="blend" zPosition="5" />' % (i, LX + RW - 150, y + 14, art)]
    x += ['<widget name="sideHead" position="%d,%d" size="%d,30" font="Regular;18" foregroundColor="#E2B84F" transparent="1" zPosition="3" />' % (SX, SY + 14, SW),
          '<widget name="sideName" position="%d,%d" size="%d,56" font="Regular;40" foregroundColor="#FFFFFF" transparent="1" noWrap="1" zPosition="3" />' % (SX, SY + 60, SW),
          '<widget name="sideSub" position="%d,%d" size="%d,32" font="Regular;21" foregroundColor="#AAB4C3" transparent="1" noWrap="1" zPosition="3" />' % (SX, SY + 118, SW)]
    if kind == "server":
        for j in range(4):
            y = SY + 190 + j * 56
            x += ['<widget name="sideK%d" position="%d,%d" size="220,40" font="Regular;20" foregroundColor="#96A0AF" transparent="1" valign="center" zPosition="3" />' % (j, SX, y),
                  '<widget name="sideV%d" position="%d,%d" size="%d,40" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" halign="right" valign="center" noWrap="1" zPosition="3" />' % (j, SX + 200, y, SW - 200),
                  '<eLabel position="%d,%d" size="%d,1" backgroundColor="#2A2F3A" zPosition="2" />' % (SX, y + 46, SW)]
    else:
        x += ['<widget name="pvTitle" position="%d,%d" size="%d,56" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" noWrap="1" zPosition="3" />' % (SX, SY + 160, SW),
              '<widget name="pvMeta" position="%d,%d" size="%d,34" font="Regular;22" foregroundColor="#E6C878" transparent="1" noWrap="1" zPosition="3" />' % (SX, SY + 220, SW),
              '<widget name="pvPlot" position="%d,%d" size="%d,110" font="Regular;22" foregroundColor="#D2D8E2" transparent="1" zPosition="3" />' % (SX, SY + 266, SW),
              '<widget name="pvArabic" position="%d,%d" size="%d,44" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" halign="right" noWrap="1" zPosition="3" />' % (SX, SY + 384, SW),
              '<widget name="pvNums" position="%d,%d" size="%d,38" font="Regular;26" foregroundColor="#C8CED8" transparent="1" noWrap="1" zPosition="3" />' % (SX, SY + 436, SW),
              '<ePixmap position="%d,%d" size="200,44" pixmap="%s/pro_play.png" alphatest="blend" zPosition="2" />' % (SX, SY + 500, art),
              '<widget name="pvPlay" position="%d,%d" size="200,44" font="Regular;20" foregroundColor="#0A0C12" transparent="1" halign="center" valign="center" zPosition="3" />' % (SX, SY + 500)]
    x += ['<widget name="keyRed" position="84,%d" size="190,30" font="Regular;19" foregroundColor="#DCE1E8" transparent="1" valign="center" zPosition="3" />' % (PH - 54),
          '<widget name="keyGreen" position="314,%d" size="190,30" font="Regular;19" foregroundColor="#DCE1E8" transparent="1" valign="center" zPosition="3" />' % (PH - 54),
          '<widget name="keyBlue" position="544,%d" size="220,30" font="Regular;19" foregroundColor="#DCE1E8" transparent="1" valign="center" zPosition="3" />' % (PH - 54),
          '<widget name="page" position="%d,%d" size="300,30" font="Regular;19" foregroundColor="#8C96A5" transparent="1" halign="right" valign="center" zPosition="3" />' % (PW - 340, PH - 54),
          '</screen>']
    return scale_skin("\n".join(x))


_SKINS = {}


def _skin_for(kind):
    if kind not in _SKINS:
        _SKINS[kind] = _build_skin(kind)
    return _SKINS[kind]


def _strip_mark(label):
    text = _u(label).strip()
    current = False
    for mark in (u"✓", u"✔", u"√"):
        if text.startswith(mark):
            current = True
            text = text[len(mark):].strip()
    return text, current


class TiviProChoice(Screen):
    """Drop-in replacement for ChoiceBox (same list, same return value).

    kind="server": rows are (label, source_dict); kind="font": (label, font_key).
    The selected ORIGINAL tuple is returned, so every existing callback works.
    """

    def __init__(self, session, title="", list=None, kind="server", subtitle="", current=None):
        self.kind = "font" if kind == "font" else "server"
        self.skin = _skin_for(self.kind)
        Screen.__init__(self, session)
        # NOTE: the argument is called "list" (ChoiceBox compatibility).
        self._choices = [x for x in (list or []) if isinstance(x, (tuple, type([]))) and len(x) >= 2]
        self.rows = []
        active_index = 0
        for index, item in enumerate(self._choices):
            text, marked = _strip_mark(item[0])
            value = item[1]
            is_current = marked or (current is not None and value == current)
            if is_current:
                active_index = index
            self.rows.append((text, value, is_current))
        self.index = active_index
        self["title"] = Label(_g(title))
        self["subtitle"] = Label(_g(subtitle))
        count = len(self.rows)
        self["count"] = Label(_g(u"%d %s" % (count, u"fonts" if self.kind == "font" else u"servers")))
        self["selector"] = Pixmap()
        for i in range(ROWS):
            for name in ("row", "dot", "typebg", "active"):
                self["%s%d" % (name, i)] = Pixmap()
            for name in ("num", "name", "type"):
                self["%s%d" % (name, i)] = Label("")
        for name in ("sideHead", "sideName", "sideSub", "keyRed", "keyGreen", "keyBlue", "page"):
            self[name] = Label("")
        if self.kind == "server":
            for j in range(4):
                self["sideK%d" % j] = Label("")
                self["sideV%d" % j] = Label("")
        else:
            for name in ("pvTitle", "pvMeta", "pvPlot", "pvArabic", "pvNums", "pvPlay"):
                self[name] = Label("")
        self["keyRed"].setText(_g(u"EXIT  Close"))
        self["keyGreen"].setText(_g(u"OK  Select"))
        self["keyBlue"].setText(_g(u"◀ ▶  Page"))
        actions = {"ok": self.ok, "cancel": self.cancel, "red": self.cancel, "green": self.ok,
                   "up": self.up, "down": self.down, "left": self.pageUp, "right": self.pageDown,
                   "pageUp": self.pageUp, "pageDown": self.pageDown, "blue": self.pageDown}
        for n in range(1, 10):
            actions[str(n)] = (lambda k=n: self.number(k))
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions",
                                     "NumberActions", "ChannelSelectBaseActions"], actions, -1)
        self.onLayoutFinish.append(self.refresh)

    # ---------- navigation
    def _page(self):
        return self.index // ROWS

    def up(self):
        if self.rows:
            self.index = (self.index - 1) % len(self.rows)
            self.refresh()

    def down(self):
        if self.rows:
            self.index = (self.index + 1) % len(self.rows)
            self.refresh()

    def pageUp(self):
        if self.rows:
            self.index = max(0, self.index - ROWS)
            self.refresh()

    def pageDown(self):
        if self.rows:
            self.index = min(len(self.rows) - 1, self.index + ROWS)
            self.refresh()

    def number(self, n):
        target = self._page() * ROWS + (n - 1)
        if 0 <= target < len(self.rows):
            self.index = target
            self.refresh()
            self.ok()

    def ok(self):
        if self.rows:
            self.close(self._choices[self.index])
        else:
            self.close(None)

    def cancel(self):
        self.close(None)

    # ---------- painting
    def _font(self, key, size):
        try:
            return gFont(str(key), int(sy(size)))
        except Exception:
            return gFont("Regular", int(sy(size)))

    def refresh(self):
        """Never let a drawing problem crash Enigma2: log it and keep going."""
        try:
            self._refresh()
        except Exception as exc:
            try:
                import traceback
                with open("/tmp/tivimate_pro_dialog.log", "a") as handle:
                    handle.write("refresh failed: %r\n%s\n" % (exc, traceback.format_exc()))
            except Exception:
                pass

    def _refresh(self):
        if not self.rows:
            self["selector"].hide()
            for i in range(ROWS):
                for name in ("row", "dot", "typebg", "active", "num", "name", "type"):
                    self["%s%d" % (name, i)].hide()
            return
        page = self._page()
        start = page * ROWS
        pages = (len(self.rows) + ROWS - 1) // ROWS
        self["page"].setText(_g(u"Page %d / %d" % (page + 1, pages)) if pages > 1 else "")
        art = os.path.join(PLUGIN_PATH, "skins", "pro_dialog")
        for i in range(ROWS):
            pos = start + i
            widgets = [self["%s%d" % (n, i)] for n in ("row", "dot", "typebg", "active", "num", "name", "type")]
            if pos >= len(self.rows):
                for w in widgets:
                    w.hide()
                continue
            text, value, is_current = self.rows[pos]
            selected = (pos == self.index)
            self["row%d" % i].show()
            self["num%d" % i].setText(str(i + 1))
            self["num%d" % i].show()
            self["name%d" % i].setText(_g(text if self.kind == "font" else self._server_name(value, text)))
            try:
                name_widget = self["name%d" % i].instance
                if self.kind == "font":
                    name_widget.setFont(self._font(value, 25))
                name_widget.setForegroundColor(parseColor("#FFFFFF" if selected else "#E4E8EE"))
            except Exception:
                pass
            self["name%d" % i].show()
            if is_current:
                self["active%d" % i].show()
            else:
                self["active%d" % i].hide()
            if self.kind == "server" and isinstance(value, dict):
                stype = str(value.get("type") or "").lower()
                stype = stype if stype in ("xtream", "stalker", "m3u") else "xtream"
                try:
                    self["typebg%d" % i].instance.setPixmapFromFile("%s/pro_type_%s.png" % (art, stype))
                    self["typebg%d" % i].show()
                except Exception:
                    pass
                self["type%d" % i].setText({"xtream": "Xtream", "stalker": "Stalker", "m3u": "M3U"}[stype])
                self["type%d" % i].show()
                try:
                    self["dot%d" % i].instance.setPixmapFromFile("%s/pro_dot_%s.png" % (art, self._state(value)))
                    self["dot%d" % i].show()
                except Exception:
                    pass
            else:
                for n in ("dot", "typebg", "type"):
                    self["%s%d" % (n, i)].hide()
        sel_slot = self.index - start
        try:
            self["selector"].instance.move(ePoint(int(sx(LX - 14)), int(sy(LY - 14 + sel_slot * RH))))
            self["selector"].show()
        except Exception:
            pass
        self._side()

    # ---------- side panel
    @staticmethod
    def _server_name(source, fallback):
        if isinstance(source, dict):
            return _u(source.get("name") or source.get("server") or source.get("portal") or fallback)
        return fallback

    @staticmethod
    def _state(source):
        state = _u(source.get("_last_status") or u"").lower()
        if state in ("online", "ok", "active"):
            return "online"
        if state in ("offline", "error", "failed", "expired"):
            return "offline"
        if state in ("slow", "warning"):
            return "slow"
        return "checking"

    def _side(self):
        text, value, is_current = self.rows[self.index]
        if self.kind == "server":
            source = value if isinstance(value, dict) else {}
            self["sideHead"].setText(_g(u"SELECTED SERVER"))
            self["sideName"].setText(_g(self._server_name(source, text)))
            host = _u(source.get("url") or source.get("host") or source.get("server") or source.get("portal") or u"")
            host = re.sub(u"^https?://", u"", host).split(u"/")[0]
            self["sideSub"].setText(_g(host))
            stype = _u(source.get("type") or u"").lower()
            state = self._state(source)
            rows = [(u"Type", {u"xtream": u"Xtream Codes", u"stalker": u"Stalker Portal", u"m3u": u"M3U Playlist"}.get(stype, stype.upper())),
                    (u"Status", {u"online": u"● Online", u"offline": u"● Offline", u"slow": u"● Slow"}.get(state, u"Not checked yet")),
                    (u"Expires", _u(source.get("_last_expiry") or u"—")),
                    (u"In use", u"✓ Current server" if is_current else u"—")]
            colors = {u"online": "#46C878", u"offline": "#DC4646", u"slow": "#E6B43C"}
            for j, (k, v) in enumerate(rows):
                self["sideK%d" % j].setText(_g(k))
                self["sideV%d" % j].setText(_g(v))
                try:
                    color = colors.get(state, "#FFFFFF") if k == u"Status" else "#FFFFFF"
                    self["sideV%d" % j].instance.setForegroundColor(parseColor(color))
                except Exception:
                    pass
        else:
            self["sideHead"].setText(_g(u"LIVE PREVIEW"))
            self["sideName"].setText("")
            self["sideSub"].setText(_g(text))
            samples = (("pvTitle", u"The Last Mission", 38), ("pvMeta", u"2024  •  Action  •  2h 14m", 22),
                       ("pvPlot", u"A retired agent is pulled back into one last mission when an old enemy returns.", 22),
                       ("pvArabic", u"المهمة الأخيرة • أكشن", 28),
                       ("pvNums", u"0123456789", 26), ("pvPlay", u"▶  Play", 20))
            for name, sample, size in samples:
                self[name].setText(_g(sample))
                try:
                    self[name].instance.setFont(self._font(value, size))
                except Exception:
                    pass
