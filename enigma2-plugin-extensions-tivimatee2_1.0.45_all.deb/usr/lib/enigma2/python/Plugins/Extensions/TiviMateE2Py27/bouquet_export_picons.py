# -*- coding: utf-8 -*-
"""Save matching native Enigma2 picons after bouquet export, off GUI thread.

Never delete user picons or override existing names. Reuse the unified Live
cache/download implementation (the same one used by Ultra-style Live grid).
"""
from __future__ import absolute_import
from Plugins.Extensions.TiviMateE2Py27.compat import json_dump_text
from Plugins.Extensions.TiviMateE2Py27.py27_compat import thread_factory
import io
import os
import json
import tempfile
import threading
try:
    from Queue import Queue, Empty
except ImportError:  # DreamOS Python 2
    from Queue import Queue, Empty
from .bouquet_export import _item_key, _item_url, _service_prefix, _export_service_type

_PENDING = set()
_LOCK = threading.RLock()


# Native directories used by Enigma2 images. Keep Live URL-based artwork
# in the plugin cache; only service-reference export PNGs go here.
_NATIVE_PICON_DIRS = ('/media/hdd/picon', '/usr/share/enigma2/picon',
                      '/media/usb/picon', '/etc/enigma2/picon', '/picon')


def _picon_root():
    for path in _NATIVE_PICON_DIRS:
        if os.path.isdir(path) and os.access(path, os.W_OK | os.X_OK):
            return path
    # Same persistent default as the Python 3 exporter. Never use /tmp.
    target = '/usr/share/enigma2/picon'
    if not os.path.isdir(target):
        try:
            os.makedirs(target)
        except OSError:
            if not os.path.isdir(target):
                raise
    if not os.access(target, os.W_OK | os.X_OK):
        raise IOError('Native Enigma2 picon directory is not writable')
    return target


def _aliases(source, item, service_type):
    # Match the actual exported engine (type 1 is unsafe for non-TS URLs).
    engine = _export_service_type(source, item, service_type)
    prefix = _service_prefix(source, item, engine)
    fields = prefix.split(':')
    alias = list(fields)
    # Some E2 picon resolvers normalize IPTV type 4097/5002 to DVB type 1.
    alias[0] = '1'
    return list(dict.fromkeys((prefix.replace(':', '_') + '.png',
             '_'.join(alias) + '.png')))


def _copy_png(src, target):
    # Old images may have no Pillow or an older Pillow without LANCZOS.
    # Native PNG masters can be exported without any optional decoder.
    import shutil
    import struct
    if os.path.isfile(target):
        return True
    fd, tmp = tempfile.mkstemp(prefix='.tivimate-picon-', suffix='.png', dir=os.path.dirname(target))
    os.close(fd)
    try:
        with open(src, 'rb') as handle:
            head = handle.read(29)
        raw_png = False
        if len(head) >= 29 and head[:8] == b'\x89PNG\r\n\x1a\n' and head[12:16] == b'IHDR':
            width, height = struct.unpack('>II', head[16:24])
            raw_png = (0 < width <= 400 and 0 < height <= 240 and
                       bytearray(head)[24] == 8 and bytearray(head)[25] in (2, 6))
        if raw_png:
            shutil.copyfile(src, tmp)
        else:
            converted = False
            try:
                from PIL import Image
                image = Image.open(src)
                try:
                    image.seek(0)
                    resample = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS',
                                       getattr(Image, 'ANTIALIAS', 1))
                    image.thumbnail((400, 240), resample)
                    image.convert('RGBA').save(tmp, 'PNG', compress_level=4)
                    converted = True
                finally:
                    close = getattr(image, 'close', None)
                    if close:
                        close()
            except Exception:
                pass
            if not converted:
                from .py27_compat import which, subprocess_run
                ffmpeg = which('ffmpeg')
                if not ffmpeg:
                    return False
                subprocess_run([ffmpeg, '-nostdin', '-loglevel', 'error', '-y',
                                '-i', src, '-frames:v', '1', '-vf',
                                'scale=400:240:force_original_aspect_ratio=decrease',
                                '-pix_fmt', 'rgba', '-vcodec', 'png', tmp],
                               check=True, timeout=7)
        with open(tmp, 'rb') as handle:
            if handle.read(8) != b'\x89PNG\r\n\x1a\n':
                return False
        os.chmod(tmp, 0o644)
        if os.path.exists(target):
            return os.path.isfile(target)
        os.rename(tmp, target)
        tmp = ''
        return True
    except Exception:
        return False
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)


def _status_path():
    from .cache_manager import get_cache_dir
    return os.path.join(get_cache_dir('picons'), 'bouquet_export_status.json')


def read_export_picon_status():
    try:
        with io.open(_status_path(), 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return {}


def _write_status(status):
    # Store the summary in the selected cache, never /etc/enigma2.
    path = _status_path()
    stage = path + '.tmp'
    try:
        with io.open(stage, 'w', encoding='utf-8') as handle:
            json_dump_text(status, handle, ensure_ascii=False)
        os.rename(stage, path)
    except Exception:
        try:
            if os.path.exists(stage): os.unlink(stage)
        except Exception:
            pass


def _source_picon_url(item, source):
    from .estalker_picon import resolve_picon_url
    link = resolve_picon_url(item, source)
    if link:
        return link
    # Some M3U and Xtream importer versions preserve a logo under these
    # provider-defined fields instead of stream_icon. Use the same resolver.
    for key in ('tvg_logo', 'tvg-logo', 'logo_url', 'icon_url', 'epg_logo'):
        value = item.get(key)
        if value:
            candidate = resolve_picon_url({'stream_icon': value}, source)
            if candidate:
                return candidate
    return ''


def _export_one(source, item, stype, dest):
    from .estalker_picon import cached_picon_path, _download
    from .cache_manager import get_cache_dir
    try:
        if not isinstance(item, dict) or item.get('_placeholder'):
            return 'skipped'
        if not _item_key(item) or not _item_url(source, item):
            return 'skipped'
        icons = [os.path.join(dest, name) for name in _aliases(source, item, stype)]
        if all(os.path.isfile(path) for path in icons):
            return 'cached'
        # When a previous install wrote just one of the two standard service
        # reference variants, recreate the other without network requests.
        old = next((name for name in icons if os.path.isfile(name)), None)
        if not old:
            # Recover native filenames previously saved inside the Py27 cache.
            legacy = os.path.join(get_cache_dir('picons'), 'bouquet_export')
            old = next((os.path.join(legacy, os.path.basename(name))
                        for name in icons
                        if os.path.isfile(os.path.join(legacy, os.path.basename(name)))), None)
        if old:
            return 'cached' if all(_copy_png(old, name) for name in icons) else 'failed_write'
        link = _source_picon_url(item, source)
        if not link:
            return 'missing_url'
        image = cached_picon_path(link, (240, 100))
        if not image:
            image = _download(link, get_cache_dir('picons'))
        if not image or not os.path.isfile(image):
            return 'failed_download'
        return 'downloaded' if all(_copy_png(image, name) for name in icons) else 'failed_write'
    except Exception:
        return 'failed_download'


def _job(source, items, stype, dest):
    # Unlike screen painting (which is lazy), native bouquet export must
    # traverse ALL channels, not only the first visible 15/18 picons.
    valid = [entry for entry in items if isinstance(entry, dict) and not entry.get('_placeholder')]
    result = dict((key, 0) for key in ('cached', 'downloaded', 'missing_url',
                                      'failed_download', 'failed_write', 'skipped'))
    result.update({'total': len(valid), 'processed': 0, 'running': True})
    _write_status(result)
    work = Queue()
    for item in valid:
        work.put(item)
    lock = threading.RLock()

    def worker():
        while True:
            try:
                item = work.get_nowait()
            except Empty:
                return
            try:
                outcome = _export_one(source, item, stype, dest)
                with lock:
                    result[outcome] += 1
                    result['processed'] += 1
                    if result['processed'] % 8 == 0:
                        _write_status(result)
            finally:
                work.task_done()

    try:
        # Export-only workers, independent from the established Live grid's
        # Ultra download queues, batch sizes and concurrency settings.
        workers = []
        for unused in range(min(4, len(valid))):
            thread = thread_factory(target=worker, name='TiviMateBouquetPiconFetch')
            thread.daemon = True
            thread.start()
            workers.append(thread)
        for thread in workers:
            thread.join()
    finally:
        result['running'] = False
        _write_status(result)
        with _LOCK:
            _PENDING.discard((dest, str(source.get('name') or ''), stype))
    return result


def queue_export_picons(source, items, service_type, directory=None):
    """Nonblocking. Returns whether a worker started; existing picons reused."""
    if not items:
        return False
    # Only native export goes outside the Live cache. Resolve a persistent
    # Enigma2 directory; do not accept arbitrary external destinations.
    try:
        dest = _picon_root()
    except (OSError, IOError):
        return False
    key = (dest, str(source.get('name') or ''), int(service_type))
    with _LOCK:
        if key in _PENDING:
            return False
        _PENDING.add(key)
    worker = thread_factory(target=_job, args=(dict(source), list(items), int(service_type), dest),
                              name='TiviMateBouquetPicons')
    worker.daemon = True
    try:
        worker.start()
        return True
    except Exception:
        with _LOCK:
            _PENDING.discard(key)
        return False
