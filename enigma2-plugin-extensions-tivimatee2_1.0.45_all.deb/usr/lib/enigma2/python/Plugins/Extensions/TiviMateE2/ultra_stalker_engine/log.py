# -*- coding: utf-8 -*-
"""Small rotating logger with secret redaction and private file permissions."""
import logging
import logging.handlers
import os
import re
import urllib.parse
from .securefs import secure_private_dir

LOG_DIR = "/tmp/tivimate_ultra_protocol"
LOG_FILE = os.path.join(LOG_DIR, "plugin.log")
_LOGGER = None
_OPTIONAL_ONCE = set()

_MAC_RE = re.compile(r"(?i)\b(?:[0-9a-f]{2}:){5}[0-9a-f]{2}\b")
_SECRET_RE = re.compile(r"(?i)(token|authorization|api[_ -]?key|secret|credential|password|passwd|bearer|username)([\"'=:\s]+)([^&\s,}\"]+)")
_QUERY_RE = re.compile(r"(?i)([?&](?:token|auth|authorization|key|api_key|apikey|password|passwd|mac|play_token)=)([^&\s]+)")
_USERINFO_RE = re.compile(r"(?i)(https?://)([^/@\s:]+):([^/@\s]+)@")
_RAW_URL_RE = re.compile(r"(?i)https?://[^\s'\"<>]+")
_ENCODED_URL_RE = re.compile(r"(?i)https?%3A(?:%2F|/){2}[^\s'\"<>]+")

_AUTH_HEADER_RE = re.compile(r"(?i)\b(authorization)([\"'=:\s]+)(?:(?:bearer|basic)\s+)?([^&\s,}\"]+)")
_BEARER_RE = re.compile(r"(?i)\bbearer\s+([^&\s,}\"]+)")
_COOKIE_HEADER_RE = re.compile(r"(?im)\b(set-cookie|cookie)([\"'=:\s]+)([^\r\n]*)")


def get_logger():
    """Return the process logger without touching persistent configuration.

    This function is deliberately import-safe: many Ultra Stalker modules keep a
    module-level LOG reference, so consulting settings here would turn a harmless
    import into /etc/enigma2 I/O and possible config creation. Runtime startup
    applies the user's diagnostic preference explicitly via configure_logger().
    """
    global _LOGGER
    if _LOGGER is not None:
        return _LOGGER
    logger = logging.getLogger("TiviMateUltraProtocol")
    logger.setLevel(logging.WARNING)
    logger.propagate = False
    # Do not persist UltraStalker diagnostics in /tmp on any receiver.
    # Keep logger API intact for all current callers.
    for handler in tuple(logger.handlers):
        if isinstance(handler, logging.FileHandler):
            logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass
    if not logger.handlers:
        logger.addHandler(logging.NullHandler())
    _LOGGER = logger
    return logger


def configure_logger(diagnostic=None):
    """Apply runtime log verbosity after normal plugin/session startup.

    Persistent settings are read only when this function is explicitly called,
    never as a side effect of importing a module.
    """
    logger=get_logger()
    if diagnostic is None:
        try:
            from .storage import load_settings
            diagnostic=bool(load_settings().get("diagnostic_logging", False))
        except Exception:
            diagnostic=False
    enabled=bool(diagnostic)
    logger.setLevel(logging.DEBUG if enabled else logging.WARNING)
    try:
        from .core.runtime_log import configure_runtime_log
        configure_runtime_log(persistent=enabled)
    except Exception:
        pass
    return logger


def exception(message):
    try:
        get_logger().exception(message)
    except Exception:
        pass


