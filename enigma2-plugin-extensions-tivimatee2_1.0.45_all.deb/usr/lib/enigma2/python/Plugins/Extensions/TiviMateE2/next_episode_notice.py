# -*- coding: utf-8 -*-
"""A lazy, non-modal next-episode countdown, driven by the existing VOD tick."""
from __future__ import absolute_import
import os
import sys
from Components.Label import Label
from Screens.Screen import Screen
from .display_scale import scale_skin, sx, sy

PTS = 90000
WINDOW_SECONDS = 30


def _gui(value):
    if sys.version_info[0] < 3:
        from .py27_compat import gui_text
        return gui_text(value)
    return value


class NextEpisodeNotice(Screen):
    def __init__(self, session):
        asset = os.path.join(os.path.dirname(__file__), 'skins', 'common', 'next_episode_notice.png')
        self.skin = scale_skin('''<screen name="TiviMateNextEpisodeNotice" position="1220,838" size="620,170" zPosition="25" backgroundColor="#FF000000" flags="wfNoBorder">
            <ePixmap position="0,0" size="620,124" pixmap="%s" alphatest="blend" zPosition="1"/>
            <widget name="message" position="30,13" size="448,88" font="Regular;33" foregroundColor="#0010192B" backgroundColor="#00FFFFFF" transparent="1" halign="center" valign="center" zPosition="2"/>
            <widget name="seconds" position="480,13" size="108,88" font="Regular;46" foregroundColor="#0010192B" backgroundColor="#00FFFFFF" transparent="1" halign="center" valign="center" zPosition="2"/>
            <widget name="hint" position="10,126" size="590,40" font="Regular;27" foregroundColor="#00FFFFFF" backgroundColor="#FF000000" transparent="1" halign="right" valign="center" zPosition="2"/>
        </screen>''' % asset)
        Screen.__init__(self, session)
        from .i18n import tr_inline
        self['message'] = Label(_gui(tr_inline({'ar': u'تشغيل الحلقة التالية', 'fr': u'Épisode suivant', 'de': u'Nächste Folge'}, 'Play next episode')))
        self['seconds'] = Label('')
        self['hint'] = Label(_gui(tr_inline({'ar': u'اضغط على الخلف للإلغاء', 'fr': u'Retour pour annuler', 'de': u'Zurück zum Abbrechen'}, 'Press BACK to cancel')))
        self._remaining = None
        self._hud_position = None

    def update(self, remaining, hud_visible):
        if remaining != self._remaining:
            self['seconds'].setText(str(remaining))
            self._remaining = remaining
        if hud_visible != self._hud_position:
            try:
                from enigma import ePoint
                self.instance.move(ePoint(sx(1220), sy(645 if hud_visible else 838)))
                self._hud_position = hud_visible
            except Exception:
                pass


def hide(owner):
    if getattr(owner, '_next_notice_visible', False):
        owner._next_notice_visible = False
        try:
            owner._next_notice.hide()
        except Exception:
            pass


def cancel_visible(owner):
    if not getattr(owner, '_next_notice_visible', False):
        return False
    owner._next_notice_cancelled = True
    hide(owner)
    return True


def destroy(owner):
    hide(owner)
    notice = getattr(owner, '_next_notice', None)
    if notice is not None:
        owner._next_notice = None
        try:
            owner.session.deleteDialog(notice)
        except Exception:
            pass


def reset(owner):
    destroy(owner)
    owner._next_notice_cancelled = False
    owner._next_notice_failed = False


def tick(owner, position, duration):
    # No new eTimer, network traffic, or dialog for movies/last episodes.
    if not (owner._episode_items and 0 <= owner._episode_index < len(owner._episode_items) - 1):
        return
    if (getattr(owner, '_next_notice_cancelled', False) or
            getattr(owner, '_next_notice_failed', False) or
            getattr(owner, '_episodeResolving', False) or
            not owner._playback_confirmed or
            getattr(owner, '_startup_failed', False) or
            getattr(owner, '_fallback_pending', False) or
            getattr(owner.session, 'current_dialog', owner) is not owner or
            getattr(owner, '_hud_lock', 0) or
            duration <= WINDOW_SECONDS * PTS or position <= 0 or position > duration or
            duration - position > WINDOW_SECONDS * PTS):
        hide(owner)
        return
    remaining = int((duration - position + PTS - 1) // PTS)
    try:
        notice = getattr(owner, '_next_notice', None)
        if notice is None:
            notice = owner.session.instantiateDialog(NextEpisodeNotice)
            owner._next_notice = notice
        notice.update(remaining, bool(getattr(owner, 'shown', False)))
        if not getattr(owner, '_next_notice_visible', False):
            notice.show()
            owner._next_notice_visible = True
    except Exception:
        # A skin/display failure must not change the original EOF behaviour.
        destroy(owner)
        owner._next_notice_failed = True
