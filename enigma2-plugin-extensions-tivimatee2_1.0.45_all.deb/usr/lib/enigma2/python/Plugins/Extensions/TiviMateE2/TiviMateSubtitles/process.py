# -*- coding: utf-8 -*-
#################################################################################
#
#    This module is part of TiviMate Subtitles plugin
#    Coded by mx3L (c) 2014
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#################################################################################

from __future__ import absolute_import, division
import os
import traceback

from .parsers.baseparser import ParseError, NoSubtitlesParseError
from .seekers.utilities import getFileSize, SimpleLogger
from .utils import load, decode, toString

from six.moves.urllib.error import URLError, HTTPError


SUBTITLES_FILE_MAX_SIZE = 400 * 1024  # 400KB


class ParserNotFoundError(Exception):
    pass


class DecodeError(Exception):
    pass


class LoadError(Exception):
    pass


def _script_ratios(text):
    """(cyrillic, arabic) share of the script characters in text."""
    total = cyr = ara = 0
    for ch in text:
        cp = ord(ch)
        is_arabic = 0x0600 <= cp <= 0x06FF or 0xFB50 <= cp <= 0xFEFF
        if not (is_arabic or ch.isalpha()):
            continue
        total += 1
        if 0x0400 <= cp <= 0x04FF:
            cyr += 1
        elif is_arabic:
            ara += 1
    if total < 20:
        return 0.0, 0.0
    return cyr / float(total), ara / float(total)


def _cyrillic_encoding(raw):
    """'windows-1251' when the file is Cyrillic text in that code page, else None.

    Works whatever Encoding group is selected. Legacy code pages (the Arabic one
    included) decode almost any bytes without an error, so the normal
    first-success order shows Cyrillic files as garbage. Windows-1251 and
    Windows-1256 both turn every high byte into letters, so the test compares
    the two readings: Cyrillic text reads far better as 1251, while Arabic text
    reads equally well both ways and is left alone. UTF-8 files are not touched.
    """
    if not isinstance(raw, bytes):
        return None
    try:
        raw.decode('utf-8')
        return None
    except UnicodeDecodeError:
        pass
    try:
        cyr, _ara = _script_ratios(raw.decode('windows-1251'))
        _cyr, ara = _script_ratios(raw.decode('windows-1256'))
    except Exception:
        return None
    if cyr >= 0.5 and cyr - ara >= 0.3:
        return 'windows-1251'
    return None


class SubsLoader(object):
    def __init__(self, parsers_cls, encodings=None):
        self._parsers = [parser_cls() for parser_cls in parsers_cls]
        self._encodings = ['utf-8']
        if encodings:
            self._encodings = encodings
        self._row_parsing = False
        self.log = SimpleLogger('SubsLoader',)

    def toggle_row_parsing(self):
        if self._row_parsing:
            self.set_row_parsing(False)
        else:
            self.set_row_parsing(True)

    def set_row_parsing(self, val):
        for parser in self._parsers:
            parser.rowParse = val
        if val:
            self.log.info("setting row parsing for Parsers")
            self._row_parsing = True
        else:
            self.log.info("setting block parsing for Parsers")
            self._row_parsing = False

    def change_encodings(self, encodings):
        self.log.info("changing encoding group to: %s" % str(encodings))
        self._encodings = encodings

    def change_encoding(self, text, current_encoding):
        if current_encoding is not None and current_encoding not in self._encodings:
            current_encoding = None  # e.g. auto-detected Cyrillic: start the normal list
        try:
            decoded_text, encoding = decode(
                text, self._encodings, current_encoding)
        except Exception:
            traceback.print_exc()
            self.log.error("cannot decode subtitles'")
            raise DecodeError()

        return decoded_text, encoding

    def load(self, subfile, current_encoding=None, fps=None):
        filename = os.path.basename(subfile)
        self.log.info("<%s> loading ...", filename)
        while True:
            decoded_text, encoding = self._process_path(
                subfile, current_encoding)
            try:
                sublist = self._parse(
                    decoded_text, os.path.splitext(subfile)[1], fps)
            except NoSubtitlesParseError:
                # this could mean that subtitles file was decoded but
                # with not right encoding, we try to use other encodings
                if current_encoding == self._encodings[-1]:
                    raise
                self.log.info(
                    "<%s> no subtitles parsed, will try different encoding", filename)
                current_encoding = encoding
                continue
            self.log.info("<%s> successfully loaded", filename)
            return sublist, encoding

    def _process_path(self, subfile, current_encoding=None):
        filename = os.path.basename(subfile)
        size = getFileSize(subfile)
        if size and size > SUBTITLES_FILE_MAX_SIZE:
            self.log.error(
                "<%s> not supported subtitles size ({%d}KB > {%d}KB)!", filename, size // 1024, SUBTITLES_FILE_MAX_SIZE // 1024)
            raise LoadError('"%s" - not supported subtitles size: "%dKB"' %
                            (toString(os.path.basename(subfile)), size // 1024))
        try:
            text = load(subfile)
        except (URLError, HTTPError, IOError) as e:
            self.log.error("<%s> %s", filename, str(e))
            raise LoadError(subfile)
        if current_encoding is None:
            cyrillic = _cyrillic_encoding(text)
            if cyrillic:
                self.log.info("<%s> Cyrillic text detected, using %s", filename, cyrillic)
                return text.decode(cyrillic), cyrillic
        elif current_encoding not in self._encodings:
            # The detected Cyrillic encoding did not parse: go through the normal list.
            current_encoding = None
        try:
            decoded_text, encoding = decode(
                text, self._encodings, current_encoding)
        except Exception:
            self.log.error("<%s> %s", filename, "cannot decode")
            raise DecodeError(subfile)
        return decoded_text, encoding

    def _parse(self, text, ext=None, fps=None, strict=False):
        self.log.info("looking for '%s' parser", str(ext))
        for parser in self._parsers:
            if not ext:
                self.log.info("extension is not set, parsing without it ...")
                break
            if parser.canParse(ext):
                self.log.info("found <%s> parser", parser)
                self.log.info("<%s> parsing...", parser)
                try:
                    return parser.parse(text, fps)
                except ParseError as e:
                    self.log.error("<%s>: %s", parser, str(e))
                    if strict:
                        raise
        for parser in self._parsers:
            self.log.info("trying parsing with <%s>", parser)
            try:
                return parser.parse(text, fps)
            except NoSubtitlesParseError:
                if parser == self._parsers[-1]:
                    raise
                continue
            except ParseError as e:
                self.log.error("<%s>: %s", parser, str(e))
                continue
        raise ParserNotFoundError(str(ext))
