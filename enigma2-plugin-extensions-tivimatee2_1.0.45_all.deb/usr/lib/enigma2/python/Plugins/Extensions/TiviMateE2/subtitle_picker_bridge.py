import re
# -*- coding: utf-8 -*-
import os
import sys
from .storage import data_path
import traceback


def _pipeline_trace(stage, **fields):
    try:
        from .TiviMateSubtitles.subtitle_pipeline_log import trace
        trace(stage, **fields)
    except Exception:
        pass


def _pipeline_file_info(path):
    try:
        from .TiviMateSubtitles.subtitle_pipeline_log import file_info
        return file_info(path)
    except Exception:
        return {}


def _preferred_language():
    try:
        from .subdl_client import load_settings
        code = str((load_settings() or {}).get("language") or "ar").strip().lower()
    except Exception:
        code = "ar"
    aliases = {"ara":"ar","arabic":"ar","eng":"en","english":"en","fra":"fr","fre":"fr","tur":"tr"}
    return aliases.get(code, code[:2] if len(code) > 2 else code) or "ar"


def _set_language(settings, language_code=None):
    """Keep the user's Subtitle Search languages across every new search.

    SubDL's app-wide default is only a fallback. The three search-language
    preferences may differ and must not be silently overwritten.
    """
    explicit = str(language_code or "").strip().lower()
    current = str(getattr(getattr(settings, "lang1", None), "value", "") or "").strip().lower()
    code = explicit or current or _preferred_language()
    for name in ("lang1", "lang2", "lang3"):
        try:
            entry = getattr(settings, name)
            if explicit or not str(getattr(entry, "value", "") or "").strip():
                entry.value = code
                entry.save()
        except Exception:
            pass

    for name, value in (("manualSearch", False),
                        ("openParamsDialogOnSearch", False),
                        ("useFilePath", False)):
        try:
            entry = getattr(settings, name)
            entry.value = value
            entry.save()
        except Exception:
            pass
    return code


def _controller(owner):
    obj=getattr(owner,"_tivimate_subtitles",None)
    if obj is not None: return obj
    from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSupport
    obj=TiviMateSubtitleSupport(getattr(owner,"session"),defaultPath=data_path("subtitles"),forceDefaultPath=False,autoLoad=False,showGUIInfoMessages=True,embeddedSupport=False,preferEmbedded=False,searchSupport=True)
    owner._tivimate_subtitles=obj
    owner._tivimate_subtitle_controller=obj
    return obj


def _cached_poster(owner):
    # Keep the hand-off file scoped to the Enigma2 session.  A single global
    # pointer allowed a late callback from another player/session to replace
    # the current poster while the picker was opening.
    session = getattr(owner, "session", None)
    pointer="/tmp/tivimate_subtitles_poster_%s.path" % id(session); path=""
    item=getattr(owner,"item",{}) or {}

    # r478: Subtitle Search must never inherit the VOD player's circular HUD
    # derivative. Reuse only the original rectangular artwork already on disk.
    # No network request, timer, hook, or playback-path change is introduced.
    def _rect_source(candidate):
        try:
            p=str(candidate or "").strip()
            if not p:
                return ""
            if os.path.exists(p) and ".tivimate-circle-" not in os.path.basename(p):
                return p
            # Player circle files are generated as:
            #   <original-root>.tivimate-circle-rXXX.png
            # Recover the already-cached original poster beside that derivative.
            marker=".tivimate-circle-"
            base=os.path.basename(p)
            if marker in base:
                prefix=p[:p.rfind(marker)]
                for ext in (".jpg", ".jpeg", ".png", ".webp"):
                    original=prefix+ext
                    if os.path.exists(original):
                        return original
        except Exception:
            pass
        return ""

    # Prefer the raw player cache fields; these are rectangular server/TMDb art.
    for key in ("_player_cover_cache", "_player_cover_cache_fallback"):
        try:
            path=_rect_source(item.get(key))
            if path:
                break
        except Exception:
            pass

    # Resolve the original URL through the existing artwork cache only.
    if not path:
        try:
            from .artwork_queue import cached_artwork
            for key in ("_player_cover","stream_icon","cover_big","cover","movie_image","poster_url","poster_path"):
                url=item.get(key)
                if not url:
                    continue
                p=cached_artwork(url,"posters")
                path=_rect_source(p)
                if path:
                    break
        except Exception:
            pass

    # Last local-only fallback: recover the original beside any player circle.
    if not path:
        try:
            for attr in ("_cover_cached_path", "_infobarPosterPath"):
                path=_rect_source(getattr(owner,attr,""))
                if path:
                    break
        except Exception:
            pass

    try:
        if path:
            with open(pointer,"w") as f:
                f.write(path)
        elif os.path.exists(pointer):
            os.remove(pointer)
    except Exception:
        pass


def _content_kind(owner):
    item=getattr(owner,"item",{}) or {}
    text=" ".join(str(item.get(k,"") or "").lower() for k in ("content_type","type","stream_type","media_type"))
    if any(x in text for x in ("series","episode","tvshow","tv show")): return "episode"
    for k in ("season","season_number","episode","episode_num","episode_number","series_name","series_id"):
        if item.get(k) not in (None,"",0,"0"): return "episode"
    return "movie"


def _subtitle_latin_title(value):
    """Accept a real Latin-script metadata title, never transliterate guesses."""
    try:
        from .subtitle_title import clean_subtitle_title
        text = clean_subtitle_title(value)
    except Exception:
        text = str(value or "").strip()
    # A year or quality tag alone must not be treated as an English title.
    return text if re.search(r"[A-Za-z]{2}", text) else ""


def _existing_english_subtitle_title(owner):
    """Read already-known English names without changing the TMDb UI locale."""
    item = getattr(owner, "item", {}) or {}
    if (getattr(owner, "_subtitle_english_item_key", None) == id(item)):
        name = _subtitle_latin_title(getattr(owner, "_subtitle_english_title", ""))
        if name:
            return name
    # These fields are metadata titles, not the active localized display title.
    if _content_kind(owner) == "episode":
        # Episode original_title can mean the *episode* title. Prefer the
        # English show name for SxxExx subtitle searches.
        keys = ("series_name_en", "english_series_name", "series_original_name",
                "_tmdb_en_title", "_tmdb_english_title", "_subtitle_english_title",
                "english_title", "title_en", "original_name", "series_name")
    else:
        keys = ("_tmdb_en_title", "_tmdb_english_title", "_subtitle_english_title",
                "english_title", "title_en", "original_title", "original_name",
                "movie_name", "title")
    for key in keys:
        name = _subtitle_latin_title(item.get(key))
        if name:
            return name
    return ""


def _english_subtitle_tmdb_lookup(item, is_episode):
    """Background-only English TMDb lookup; reuse the established disk cache."""
    try:
        raw_id = (item.get("series_tmdb_id") or item.get("_series_tmdb_id") or
                  item.get("tmdb_id") or item.get("_tmdb_id") or item.get("tmdb"))
        tmdb_id = int(str(raw_id or "0"))
        if tmdb_id <= 0:
            return ""
        from .tmdb_client import TMDbClient
        tmdb = TMDbClient(language="en-US")
        if not tmdb.configured():
            return ""
        data = tmdb.details_bundle(tmdb_id, "series" if is_episode else "vod") or {}
        # en-US 'title'/'name' is the translated title where available.
        for key in (("name", "original_name") if is_episode else ("title", "original_title")):
            title = _subtitle_latin_title(data.get(key))
            if title:
                return title
    except Exception:
        pass
    return ""


def _tivimate_best_title(owner, fallback=""):
    """Return the real current TiviMate movie/series title."""
    item = getattr(owner, "item", {}) or {}
    # Subtitle search has its own English name. Do NOT alter the player label.
    english = _existing_english_subtitle_title(owner)
    if english:
        return english
    candidates = []

    # Player/runtime attributes first: these are often cleaner than provider labels.
    for attr in (
        "movie_title", "series_title", "content_title", "current_title",
        "service_title", "title", "name"
    ):
        try:
            value = getattr(owner, attr, None)
            if value:
                candidates.append(value)
        except Exception:
            pass

    # Xtream/Stalker/TiviMate item fields.
    for key in (
        "_tmdb_title", "series_name", "series_title", "show_name",
        "movie_name", "vod_name", "stream_name", "channel_name",
        "original_title", "name", "title"
    ):
        try:
            value = item.get(key)
            if value:
                candidates.append(value)
        except Exception:
            pass

    if fallback:
        candidates.append(fallback)

    for value in candidates:
        try:
            text = str(value).strip()
        except Exception:
            continue
        if not text:
            continue

        # Remove only obvious provider/quality decorations; preserve the real title.
        text = re.sub(r"^\s*(?:MOVIES?|VOD|TV\s*SHOWS?|SERIES)\s*[:\-|]\s*", "", text, flags=re.I)
        text = re.sub(r"\s*[\[\(\{](?:4K|UHD|FHD|FULL\s*HD|1080P|720P|2160P|HEVC|H\.?265|H\.?264|AR|EN|MULTI)[^\]\)\}]*[\]\)\}]\s*", " ", text, flags=re.I)
        text = re.sub(r"\s+(?:4K|UHD|FHD|FULL\s*HD|1080P|720P|2160P|HEVC)\s*$", "", text, flags=re.I)
        text = re.sub(r"\s+", " ", text).strip(" -|:_")
        if text:
            return text
    return ""

def _tivimate_player_movie_title_year(owner, fallback_title=""):
    """Use only data already present in the current TiviMate player.

    Returns (clean_title, year).  No TMDb/API/network lookup is performed.
    """
    item = getattr(owner, "item", {}) or {}
    title = _tivimate_best_title(owner, fallback_title) or str(fallback_title or "").strip()

    year = 0
    # Prefer values already attached to the playing item/player.
    from .TiviMateSubtitles.search_identity import title_year, year_value
    rows = [item] if isinstance(item, dict) else []
    for field in ("info", "_tmdb", "metadata", "movie_data", "vod_info"):
        nested = item.get(field) if isinstance(item, dict) else None
        if isinstance(nested, dict):
            rows.append(nested)
    for row in rows:
        for key in ("year", "release_year", "_tmdb_year", "release_date", "releaseDate", "releasedate", "release_date_utc"):
            found = year_value(row.get(key))
            if found:
                year = int(found)
                break
        if year:
            break

    if not year:
        for attr in ("year", "release_year", "movie_year", "content_year"):
            try:
                value = getattr(owner, attr, None)
            except Exception:
                value = None
            text = str(value or "").strip()
            m = re.search(r"\b((?:19|20)\d{2})\b", text)
            if m:
                year = int(m.group(1))
                break

    # Last fallback: the year already visible in the player title, e.g.
    # "The Odyssey (2026)".  Strip only a trailing year from the search title.
    title_text = str(title or "").strip()
    m = re.search(r"(?:[\s\-_.]*[\(\[]?((?:19|20)\d{2})[\)\]]?)\s*$", title_text)
    if m and title_text[:m.start()].strip(" -|:_ .") and (not year or int(m.group(1)) == year):
        if not year:
            year = int(m.group(1))
        title_text = title_text[:m.start()].strip(" -|:_ .")
    if not year:
        for row in rows:
            for field in ("original_title", "name", "title", "stream_name", "filename", "release_name"):
                _name, found = title_year(row.get(field), title_text)
                if found:
                    year = int(found)
                    break
            if year:
                break

    return title_text or str(title or "").strip(), year


def _tivimate_search_title(owner, fallback_title=""):
    item = getattr(owner, "item", {}) or {}
    base_title = _tivimate_best_title(owner, fallback_title)
    if not base_title:
        return ""

    kind = _content_kind(owner)
    if kind == "episode":
        # Prefer explicit series/show title over an episode-only title.
        series = ""
        english_series = _existing_english_subtitle_title(owner)
        if english_series:
            series = english_series
        for key in (() if series else ("series_name", "series_title", "show_name", "_tmdb_title")):
            try:
                val = item.get(key)
            except Exception:
                val = None
            if val:
                series = str(val).strip()
                break
        if not series:
            series = base_title

        season = item.get("season_number", item.get("season", ""))
        episode = item.get("episode_number", item.get("episode_num", item.get("episode", "")))

        try:
            if str(season).strip().isdigit() and str(episode).strip().isdigit():
                # Avoid duplicating SxxExx when it is already present.
                if not re.search(r"\bS\d{1,2}E\d{1,3}\b", series, re.I):
                    return "%s S%02dE%02d" % (series, int(season), int(episode))
        except Exception:
            pass
        return series

    return base_title


# We rank subtitle releases using ONLY real release strings on the currently
# playing item.  Xtream / Stalker numeric stream IDs and category names say
# nothing about whether the encode is BluRay, WEB-DL or CAM.
_RELEASE_HINT_TOKEN = re.compile(
    r"(?i)(?<![a-z])(?:blu[ ._-]?ray|bdremux|bd[ ._-]?rip|br[ ._-]?rip|"
    r"web[ ._-]?dl|web[ ._-]?rip|webrip|hdtv|hd[ ._-]?rip|dvd[ ._-]?rip|"
    r"hd[ ._-]?cam|cam[ ._-]?rip|cam|tele[ ._-]?sync|telesync)(?![a-z])"
)


def _tivimate_video_release_hint(owner):
    """Return a release filename/hint only when the item actually supplies it.

    No TMDb lookup, no FPS guess, and no change to the streamed URL or the
    subtitle search query. A missing release hint intentionally remains unknown.
    """
    item = getattr(owner, 'item', {}) or {}
    if not isinstance(item, dict):
        item = {}
    sources = [item]
    for key in ('info', '_episode_source'):
        nested = item.get(key)
        if isinstance(nested, dict):
            sources.append(nested)
    fields = ('release_name', 'video_release', 'video_release_type',
              'release_type', 'rip_type', 'original_filename',
              'original_file_name', 'file_name', 'file_title', 'filename',
              'stream_filename', 'source_file', 'name', 'stream_name', 'title')
    matches = []
    for row in sources:
        for priority, field in enumerate(fields):
            raw = row.get(field)
            if not isinstance(raw, (str, bytes)):
                continue
            if isinstance(raw, bytes):
                raw = raw.decode('utf-8', 'ignore')
            raw = raw.strip()[:350]
            if _RELEASE_HINT_TOKEN.search(raw):
                # The earliest explicit release metadata takes precedence.
                matches.append((priority, -len(raw), raw))
    def with_known_fps(name):
        if not name:
            return ''
        if re.search(r'(?i)(?:\d+(?:\.\d+)?[ ._-]*fps|fps[ ._-]*\d+)', name):
            return name
        for row in sources:
            for field in ('fps', 'frame_rate', 'framerate', 'video_fps'):
                try:
                    value = float(str(row.get(field) or '').lower().replace('fps', '').strip())
                    if 1000 < value < 61000:
                        value /= 1000.0
                    if 20 <= value <= 61:
                        return '%s %.3ffps' % (name, value)
                except (ValueError, TypeError):
                    pass
        return name

    if matches:
        return with_known_fps(sorted(matches)[0][2])

    # Only the path basename may contain a genuine release name. Never send
    # URL credentials, query parameters, or tokenised numeric paths to the UI.
    try:
        try:
            from urllib.parse import urlsplit, unquote
        except ImportError:
            from urlparse import urlsplit
            from urllib import unquote
        stream = getattr(owner, 'streamurl', '') or item.get('stream_url') or item.get('url') or ''
        filename = unquote(os.path.basename(urlsplit(str(stream)).path))[:350]
        if _RELEASE_HINT_TOKEN.search(filename):
            return with_known_fps(filename)
    except Exception:
        pass
    return ''


def _tivimate_content_key(owner):
    """Stable key for the currently playing movie/episode within this player.

    Used only to decide whether BLUE should auto-search on first open.
    A new movie/episode gets one auto search; later opens are manual.
    """
    item = getattr(owner, "item", {}) or {}
    parts = []
    for attr in ("stream_url", "url", "play_url", "service_url", "current_url"):
        try:
            value = getattr(owner, attr, None)
        except Exception:
            value = None
        if value:
            parts.append(str(value))
            break
    for key in ("stream_id", "episode_id", "movie_id", "series_id", "id"):
        try:
            value = item.get(key)
        except Exception:
            value = None
        if value not in (None, ""):
            parts.append(str(value))
    title = _tivimate_search_title(owner, _tivimate_best_title(owner, ""))
    if title:
        parts.append(str(title))
    return "|".join(parts) or str(id(owner))


def _bridge_debug_log(stage, exc=None):
    return None  # r146: diagnostics off
    # Persistent diagnostic for RED / More Info subtitle selection.
    try:
        from datetime import datetime
        path = data_path("subtitle_selection_debug.log")
        with open(path, "a") as fp:
            fp.write("%s %s %s\n" % (datetime.now().isoformat(), str(stage), str(exc or "")))
    except Exception:
        pass


def _subtitle_file_diagnostic(path):
    try:
        if not path or not os.path.isfile(path):
            return "missing subtitle file: %r" % (path,)
        with open(path, "rb") as f:
            sample = f.read(65536)
        decoded = sample.decode("utf-8-sig", "replace")
        arabic = sum(1 for c in decoded if "\u0600" <= c <= "\u06ff")
        latin = sum(1 for c in decoded if ("a" <= c.lower() <= "z"))
        return "subtitle path=%r bytes=%d arabic_chars=%d latin_chars=%d" % (path, os.path.getsize(path), arabic, latin)
    except Exception as exc:
        return "subtitle diagnostic error=%r" % (exc,)


def _subtitle_search_pause(owner, controller, is_live):
    """Honour 'Pause video on opening subtitles menu' for the BLUE search too.
    Only a video that is really playing is paused, and only that one is resumed."""
    owner._subtitle_search_paused = False
    if is_live:
        return
    try:
        if not controller.subsProSettings.pauseVideoOnSubtitlesMenu.value:
            return
    except Exception:
        return
    try:
        if getattr(owner, "seekstate", None) == getattr(owner, "SEEK_STATE_PLAY", object()):
            owner.pauseService()
            owner._subtitle_search_paused = True
    except Exception as exc:
        _bridge_debug_log("pause before subtitle search failed", exc)


def _subtitle_search_resume(owner):
    if not getattr(owner, "_subtitle_search_paused", False):
        return
    owner._subtitle_search_paused = False
    try:
        if getattr(owner, "_closing", False):
            return
        if getattr(owner, "seekstate", None) == getattr(owner, "SEEK_STATE_PAUSE", object()):
            owner.unPauseService()
    except Exception as exc:
        _bridge_debug_log("resume after subtitle search failed", exc)


def open_tivimate_subtitle_search(owner, title=None, language_code=None, context=None,
                                  _english_lookup_done=False):
    """Search English metadata title; preserve the selected subtitle language."""
    session = getattr(owner, "session", None)
    # Expose only the failed initialization phase to the UI. Detailed exception
    # information remains in the existing local diagnostic log.
    owner._tivimate_subtitle_search_error = ""
    if session is None:
        owner._tivimate_subtitle_search_error = "session"
        return False

    live_context = dict(context or {}) if isinstance(context, dict) else {}
    is_live = str(live_context.get("media_type") or "").lower() == "live"

    legacy_live = is_live and sys.version_info[0] == 2
    if legacy_live and getattr(owner, "_live_subtitle_search_open", False):
        return True

    if not is_live and not _english_lookup_done:
        item = getattr(owner, "item", {}) or {}
        english = _existing_english_subtitle_title(owner)
        if not english:
            # Do not make TMDb network calls from the Enigma2 GUI thread.
            # Only resolve when the current player title is not English and
            # a real TMDb ID is already known. Never mistake provider IDs for TMDb.
            current = _tivimate_best_title(owner, title)
            raw_id = (item.get("series_tmdb_id") or item.get("_series_tmdb_id") or
                      item.get("tmdb_id") or item.get("_tmdb_id") or item.get("tmdb"))
            try:
                valid_id = int(str(raw_id or "0")) > 0
            except Exception:
                valid_id = False
            if valid_id and not _subtitle_latin_title(current):
                pending_key = id(item)
                if getattr(owner, "_subtitle_english_pending_key", None) == pending_key:
                    return True
                try:
                    from twisted.internet import threads
                    owner._subtitle_english_pending_key = pending_key
                    item_snapshot = dict(item)
                    is_episode = _content_kind(owner) == "episode"
                    deferred = threads.deferToThread(_english_subtitle_tmdb_lookup,
                                                     item_snapshot, is_episode)

                    def done(result):
                        if getattr(owner, "_subtitle_english_pending_key", None) == pending_key:
                            owner._subtitle_english_pending_key = None
                        if getattr(owner, "_closing", False) or id(getattr(owner, "item", None)) != pending_key:
                            return result
                        name = _subtitle_latin_title(result) if isinstance(result, str) else ""
                        if name:
                            owner._subtitle_english_item_key = pending_key
                            owner._subtitle_english_title = name
                        open_tivimate_subtitle_search(
                            owner, title, language_code, context, _english_lookup_done=True)
                        return result

                    deferred.addBoth(done)
                    return True
                except Exception:
                    owner._subtitle_english_pending_key = None
                    # If TMDb is unavailable, continue with the existing title.
                    pass

    if is_live:
        # Live has no VOD item metadata.  Use only the programme/channel
        # context supplied by LivePlayer and never classify owner.item as a movie.
        clean_title = str(live_context.get("program_title") or title or live_context.get("channel_name") or "").strip()
        player_movie_title, player_movie_year = clean_title, 0
        content_key = "live:%s:%s:%s" % (
            live_context.get("channel_id") or "",
            live_context.get("begin") or 0,
            clean_title.lower(),
        )
    else:
        clean_title = _tivimate_best_title(owner, title)
        if not clean_title:
            return False

        # Movie title/year come only from information already available in the
        # current player.  This deliberately performs no TMDb/API/network lookup.
        player_movie_title, player_movie_year = _tivimate_player_movie_title_year(owner, clean_title)
        if _content_kind(owner) == "movie" and player_movie_title:
            clean_title = player_movie_title
        content_key = _tivimate_content_key(owner)

    if not clean_title:
        return False

    # Auto-search exactly once for each currently playing movie/episode or
    # Live programme. Opening BLUE again shows the normal manual search screen.
    previous_key = getattr(owner, "_tivimate_subtitle_auto_search_key", None)
    auto_search_on_open = previous_key != content_key
    if auto_search_on_open:
        owner._tivimate_subtitle_auto_search_key = content_key

    stage = "import"
    try:
        from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSearch, E2SubsSeeker
        _bridge_debug_log("import ok")

        stage = "controller"
        controller = _controller(owner)
        _bridge_debug_log("controller ok: %s" % controller.__class__.__name__)

        stage = "settings"
        settings = controller.subsProSettings.search
        _bridge_debug_log("settings ok")
        item = {} if is_live else (getattr(owner, "item", {}) or {})
        kind = "live" if is_live else _content_kind(owner)

        # Live title is already normalized by LivePlayer's EPG context.
        # VOD/Series keep their existing metadata-aware title builder.
        search_title = clean_title if is_live else (_tivimate_search_title(owner, clean_title) or clean_title)

        # The VOD player may expose a provider-decorated name even when the
        # movie/year are correctly identified (e.g. "TGP - It Ends (2026)").
        # Normalize the provider prefix BEFORE sending requests, and send the
        # year through the provider's dedicated field, not twice in the query.
        # Never apply this to Live EPG titles or season/episode search labels.
        if kind == "movie" and not is_live:
            try:
                from .subtitle_title import clean_subtitle_title
                normalized = clean_subtitle_title(search_title).strip()
                year_match = re.search(r"\s*[\(\[]?((?:19|20)\d{2})[\)\]]?\s*$", normalized)
                if year_match:
                    without_year = normalized[:year_match.start()].strip(" ._:-|")
                    if without_year and (not player_movie_year or int(year_match.group(1)) == player_movie_year):
                        if not player_movie_year:
                            player_movie_year = int(year_match.group(1))
                        normalized = without_year
                if normalized:
                    search_title = normalized
            except Exception as exc:
                _bridge_debug_log("subtitle title normalization failed", exc)

        # Language + manual behaviour.
        _set_language(settings, language_code)
        try:
            settings.manualSearch.value = False
        except Exception:
            pass

        # BLUE search is a real multi-source search.
        # Never keep a previously selected single provider.
        for attr in ("provider", "movieProvider", "tvshowProvider"):
            try:
                getattr(settings, attr).value = "all"
            except Exception:
                pass
        try:
            settings.openParamsDialogOnSearch.value = False
        except Exception:
            pass
        try:
            settings.useFilePath.value = False
        except Exception:
            pass

        # IMPORTANT:
        # Populate search parameters directly.  We open the screen with
        # resetSearchParams=False so its parser cannot erase TiviMate's title.
        try:
            settings.title.value = search_title
        except Exception:
            pass

        if kind == "episode":
            try:
                settings.type.value = "tv_show"
            except Exception:
                pass

            season = item.get("season_number", item.get("season", item.get("_subdl_season", 0)))
            episode = item.get("episode_number", item.get("episode_num",
                      item.get("episode", item.get("_subdl_episode", 0))))

            try:
                settings.season.value = int(season or 0)
            except Exception:
                pass
            try:
                settings.episode.value = int(episode or 0)
            except Exception:
                pass
            try:
                settings.year.value = 0
            except Exception:
                pass
        elif kind == "live":
            # The provider engine requires a movie/tv_show search type, but
            # Live itself remains a separate context: no VOD year/season/item
            # metadata is injected.  Search only the current EPG/channel title.
            try:
                settings.type.value = "movie"
            except Exception:
                pass
            try:
                settings.season.value = 0
                settings.episode.value = 0
                settings.year.value = 0
            except Exception:
                pass
        else:
            try:
                settings.type.value = "movie"
            except Exception:
                pass
            try:
                settings.season.value = 0
                settings.episode.value = 0
            except Exception:
                pass

            # Use only the year already known by the current player.  If the
            # item fields do not expose it, _tivimate_player_movie_title_year()
            # has already extracted a trailing year from the displayed title.
            try:
                settings.year.value = int(player_movie_year or 0)
            except Exception:
                pass

        stage = "seeker"
        seeker = E2SubsSeeker(session, settings, debug=True)
        _bridge_debug_log("seeker ok: %d providers" % len(getattr(seeker, "seekers", []) or []))

        # Keep multiple public providers active even if an older saved config
        # had previously disabled them. API-key providers are left to their
        # own saved credential/enable state.
        # Activate the complete provider engine imported from the second
        # SubsSupport package. Providers that failed to import keep error!=None
        # and are skipped by the seeker engine.
        try:
            for p in seeker.seekers:
                if getattr(p, "error", None) is None:
                    try:
                        p.settings_provider.setSetting("enabled", True)
                    except Exception:
                        pass
        except Exception:
            pass

        # BLUE is always a real multi-source search.
        try:
            settings.provider.value = "all"
            settings.movieProvider.value = "all"
            settings.tvshowProvider.value = "all"
        except Exception:
            pass

        def _apply_selected(subfile=None):
            _pipeline_trace("bridge.apply", **_pipeline_file_info(subfile))
            if not subfile:
                return
            # A subtitle download/search callback can arrive after Back has
            # closed LivePlayer. Never reactivate a controller/dialog on a
            # player whose onClose cleanup has already run.
            if getattr(owner, "_epgClosed", False) or getattr(owner, "_closing", False):
                _bridge_debug_log("ignored subtitle result for closed player")
                return
            _bridge_debug_log("selected language=%s %s" % (_preferred_language(), _subtitle_file_diagnostic(subfile)))
            # A provider can label an English file as Arabic. Validate the
            # downloaded text before replacing the currently active subtitle.
            # This is deliberately limited to Arabic; other languages retain
            # their original provider selection behavior.
            if _preferred_language() == "ar" and not legacy_live:
                try:
                    from .srt_overlay import parse_srt_file
                    cues = list(parse_srt_file(str(subfile)) or [])
                    sample = " ".join(str(cue[2]) for cue in cues[:120] if len(cue) >= 3)
                    arabic_count = sum(1 for c in sample if "\u0600" <= c <= "\u06ff")
                    latin_count = sum(1 for c in sample if ("a" <= c.lower() <= "z"))
                    if arabic_count < 3 or (latin_count > 30 and arabic_count * 3 < latin_count):
                        _pipeline_trace("bridge.language.rejected", cues=len(cues), arabic=arabic_count, latin=latin_count)
                        _bridge_debug_log("REJECTED non-Arabic subtitle: arabic=%d latin=%d" % (arabic_count, latin_count))
                        try:
                            owner._showNotification("Selected subtitle is not Arabic. Choose another result.", 1, 6)
                        except Exception:
                            pass
                        return
                except Exception as exc:
                    _pipeline_trace("bridge.language.error", error=type(exc).__name__)
                    _bridge_debug_log("Arabic subtitle content validation failed", exc)
                    return
            # Do not rewrite subtitle cue blocks. The previous Arabic-only
            # filter dropped valid French/Turkish subtitle files and could
            # corrupt cue timing. Keep the provider's original file intact.
            try:
                try:
                    owner.enableSubtitle(None)
                except Exception as exc:
                    _bridge_debug_log("native subtitle disable failed before external load", exc)
                # r333: use the same new-file activation sequence as the
                # original SubsSupport callback: pause -> reset engine -> load on
                # the same service -> refresh if replacing an already-loaded file,
                # otherwise resume the engine on the first external subtitle.
                if is_live:
                    # Set the clock before loading: loadSubs()/resume() consult
                    # getVideoTime() and otherwise start at the first cue.
                    try:
                        engine = getattr(controller, "_TiviMateSubtitleSupport__subsEngine", None)
                        begin = int(live_context.get("begin") or 0)
                        duration = int(live_context.get("duration") or 0)
                        # Providers are inconsistent here: accept epoch ms as
                        # well as the documented epoch-second form.
                        if begin > 100000000000:
                            begin //= 1000
                        import time as _time
                        if begin > 0 and begin <= _time.time() and (not duration or _time.time() <= begin + duration + 120):
                            engine._tivimate_live_program_begin = begin
                            engine._tivimate_live_program_duration = max(0, duration)
                        elif engine is not None:
                            engine._tivimate_live_program_begin = 0
                            engine._tivimate_live_program_duration = 0
                    except Exception as exc:
                        _bridge_debug_log("live subtitle clock setup failed", exc)
                if controller.activateSelectedSubs(subfile):
                    _pipeline_trace("bridge.controller.accepted")
                    _bridge_debug_log("external subtitle activation success")
                    # r295: keep the exact controller that successfully loaded
                    # the subtitle as the single active controller for RED/sync.
                    owner._external_subs = controller
                    owner._subssupport = controller
                    owner._tivimate_subtitles = controller
                    owner._tivimate_subtitle_controller = controller
                    previous_file = str(getattr(owner, "_external_subtitle_path", "") or "")
                    if previous_file != str(subfile):
                        # A different subtitle file has its own timing: never
                        # carry the old file's delay over (it made the new
                        # subtitle run ahead/behind).
                        owner._subtitle_session_delay_ms = 0
                    owner._external_subtitle_path = str(subfile)
                    # The engine has already accepted and replaced the old cue
                    # list; discard only the previous private temporary file.
                    try:
                        _root = os.path.realpath("/tmp/tivimatee2-subtitles") + os.sep
                        _old = os.path.realpath(previous_file) if previous_file else ""
                        if _old != os.path.realpath(subfile) and _old.startswith(_root) and os.path.isfile(_old):
                            os.remove(_old)
                    except Exception:
                        pass
                    owner._external_subtitle_owner = "subssupport"
                    # User-selected external subtitle wins over delayed saved-track restore.
                    owner._subtitle_restore_attempted = True
                    # A SubsSupport-loaded file must be rendered only by
                    # SubsSupport. Clear a stale TiviMate overlay without
                    # touching search/providers or the active controller.
                    try:
                        clear_overlay = getattr(owner, "_clearSRTOverlay", None)
                        if callable(clear_overlay):
                            clear_overlay()
                    except Exception:
                        pass
                    try:
                        controller._tivimateDelayChangedCB = getattr(owner, "_tivimateSubtitleDelayChanged", None)
                    except Exception:
                        pass
                    # Restore only the already-known per-movie delay.
                    try:
                        delay_ms = int(getattr(owner, "_subtitle_session_delay_ms", 0) or 0)
                        setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                        if callable(setter) and delay_ms:
                            setter(delay_ms)
                        save = getattr(owner, "_savePreferences", None)
                        if callable(save):
                            save()
                    except Exception:
                        pass
                    # Recheck the same renderer after modal restoration. Never
                    # reset timing or start a competing sync or second download.
                    try:
                        generation = getattr(owner, "_tivimate_subtitle_apply_generation", None)
                        def _refresh_active_subtitle():
                            if (getattr(owner, "_closing", False) or
                                    getattr(owner, "_epgClosed", False) or
                                    getattr(owner, "_tivimate_subtitle_apply_generation", None) != generation):
                                return
                            if getattr(owner, "_external_subs", None) is not controller:
                                return
                            if str(getattr(owner, "_external_subtitle_path", "") or "") != str(subfile):
                                return
                            if getattr(session, "current_dialog", owner) is not owner:
                                return
                            if getattr(owner, "seekstate", None) == getattr(owner, "SEEK_STATE_PAUSE", object()):
                                return
                            try:
                                controller.ensureSelectedSubs(subfile)
                            except Exception as exc:
                                _bridge_debug_log("external subtitle post-close recovery failed", exc)
                        from twisted.internet import reactor as _subtitle_reactor
                        for delay in (0.8, 2.0):
                            _subtitle_reactor.callLater(delay, _refresh_active_subtitle)
                    except Exception as exc:
                        _bridge_debug_log("subtitle refresh scheduling failed", exc)
                    return True
                # A cold decoder/player can reject the first hand-off while the
                # previous search screen is still closing. Retry just this
                # activation once; never start another provider download.
                return False
            except Exception as exc:
                _pipeline_trace("bridge.activation.error", error=type(exc).__name__)
                _bridge_debug_log("selected subtitle activation failed: %r" % (subfile,), exc)
                return False

        live_channel = getattr(owner, "_live_subtitle_channel_key", None)
        def selected(subfile=None):
            """Apply the downloaded subtitle only after the player has focus.

            A fixed sleep after the search closes is unreliable: on a cold
            decoder/slow image the parent player is not always active yet.
            Wait briefly for Enigma2 to restore the parent screen; keep the
            existing SubsSupport renderer, z-order and remote action maps.
            """
            _pipeline_trace("bridge.selected", **_pipeline_file_info(subfile))
            if not subfile and not legacy_live:
                return
            # Invalidate pending hand-offs if the user picks a newer subtitle.
            request_id = int(getattr(owner, "_tivimate_subtitle_apply_generation", 0) or 0) + 1
            owner._tivimate_subtitle_apply_generation = request_id
            state = {"done": False, "waits": 0, "attempts": 0, "pts_waits": 0}

            def trace_status(stage, detail=""):
                _pipeline_trace("bridge." + stage, detail=detail, request=request_id)
                # Local, bounded diagnostics for the first/second subtitle load.
                # Never log stream URLs, subtitle text, or provider credentials.
                try:
                    from datetime import datetime
                    path = "/tmp/tivimate_subtitle_activation.log"
                    if os.path.isfile(path) and os.path.getsize(path) > 32768:
                        with open(path, "w") as fp:
                            fp.write("[log rotated]\n")
                    with open(path, "a") as fp:
                        fp.write("%s %s %s\n" % (datetime.now().strftime("%H:%M:%S"), stage, detail))
                except Exception:
                    pass

            def pts_status():
                """True=valid clock, False=not yet ready, None=unsupported."""
                if is_live:
                    return None  # Live programme clock has a separate fallback.
                try:
                    service = session.nav.getCurrentService()
                    if service is None:
                        return False
                    seek = service.seek()
                    if seek is None:
                        return None
                    result = seek.getPlayPosition()
                    if not isinstance(result, (tuple, list)) or len(result) < 2:
                        return False
                    return int(result[0]) == 0 and int(result[1]) >= 0
                except (AttributeError, NotImplementedError):
                    return None
                except Exception:
                    return False

            trace_status("download-selected", "mode=%s" % ("live" if is_live else "vod"))

            # Enigma2's own timer is driven by its GUI event loop, including
            # images where Twisted callLater does not dispatch GUI callbacks.
            # Retain both timer and signal connection until the hand-off ends.
            try:
                previous = getattr(owner, "_tivimate_subtitle_apply_timer", None)
                if previous is not None:
                    previous.stop()
                pending = getattr(owner, "_tivimate_subtitle_apply_call", None)
                if pending is not None and pending.active():
                    pending.cancel()
            except Exception:
                pass
            owner._tivimate_subtitle_apply_timer = None
            owner._tivimate_subtitle_apply_connection = None

            def schedule(seconds):
                try:
                    timer = getattr(owner, "_tivimate_subtitle_apply_timer", None)
                    if timer is None:
                        from enigma import eTimer
                        timer = eTimer()
                        connection = None
                        signal = getattr(timer, "timeout", None)
                        if callable(getattr(signal, "connect", None)):
                            connection = signal.connect(run)
                        elif callable(getattr(getattr(timer, "callback", None), "append", None)):
                            timer.callback.append(run)
                        elif callable(getattr(signal, "get", None)):
                            signal.get().append(run)
                        else:
                            signal.append(run)
                        owner._tivimate_subtitle_apply_timer = timer
                        owner._tivimate_subtitle_apply_connection = connection
                    timer.start(max(1, int(seconds * 1000)), True)
                    _pipeline_trace("bridge.timer.scheduled", backend="enigma", request=request_id, ms=int(seconds * 1000))
                    return True
                except Exception as exc:
                    _pipeline_trace("bridge.timer.error", backend="enigma", error=type(exc).__name__, request=request_id)
                try:
                    from twisted.internet import reactor
                    owner._tivimate_subtitle_apply_call = reactor.callLater(seconds, run)
                    _pipeline_trace("bridge.timer.scheduled", backend="twisted", request=request_id, ms=int(seconds * 1000))
                    return True
                except Exception as exc:
                    _pipeline_trace("bridge.timer.error", backend="twisted", error=type(exc).__name__, request=request_id)
                    return False

            def finish_live():
                if not legacy_live:
                    return
                if getattr(owner, "_tivimate_subtitle_apply_generation", None) != request_id:
                    return
                owner._live_subtitle_search_open = False
                if (getattr(owner, "_epgClosed", False) or getattr(owner, "_ib_closed", False)
                        or live_channel != getattr(owner, "_live_subtitle_channel_key", None)):
                    return
                if getattr(session, "current_dialog", owner) is owner:
                    owner.showInfobar()

            def run():
                _pipeline_trace("bridge.timer.fired", request=request_id, done=state["done"])
                if state["done"]:
                    return
                if legacy_live and live_channel != getattr(owner, "_live_subtitle_channel_key", None):
                    state["done"] = True
                    finish_live()
                    return
                if (getattr(owner, "_closing", False) or
                        getattr(owner, "_epgClosed", False) or
                        getattr(owner, "_tivimate_subtitle_apply_generation", None) != request_id):
                    state["done"] = True
                    trace_status("handoff-cancelled", "closing=%s epgClosed=%s stale=%s" % (
                        bool(getattr(owner, "_closing", False)), bool(getattr(owner, "_epgClosed", False)),
                        getattr(owner, "_tivimate_subtitle_apply_generation", None) != request_id))
                    return
                # Some images finish modal close asynchronously. Applying a
                # renderer while the search is still current can steal focus.
                current = getattr(session, "current_dialog", owner)
                if current is not owner:
                    if state["waits"] < 60 and schedule(0.20):
                        state["waits"] += 1
                        if state["waits"] in (1, 10, 30, 60):
                            _pipeline_trace("bridge.dialog.wait", polls=state["waits"], dialog=type(current).__name__)
                        return
                    state["done"] = True
                    finish_live()
                    trace_status("handoff-skipped", "player-dialog-not-active")
                    _bridge_debug_log("subtitle hand-off skipped: player not active")
                    return
                if legacy_live and not subfile:
                    state["done"] = True
                    finish_live()
                    return
                # The UI can be active while the decoder has no readable PTS.
                # The subtitle engine would keep polling for PTS and appear
                # to start only on the user's second download. Wait briefly
                # for the real clock, then fall back for non-seekable streams.
                pts = pts_status()
                if not legacy_live and pts is False and state["pts_waits"] < 40:
                    if state["pts_waits"] == 0:
                        trace_status("player-clock", "not-ready")
                    state["pts_waits"] += 1
                    if schedule(0.25):
                        return
                if state["pts_waits"]:
                    trace_status("player-clock", "ready=%s polls=%d" % (
                        pts, state["pts_waits"]))
                state["attempts"] += 1
                trace_status("activate", "attempt=%d" % state["attempts"])
                try:
                    accepted = _apply_selected(subfile)
                except Exception as exc:
                    _bridge_debug_log("selected subtitle activation failed: deferred", exc)
                    accepted = False
                # Retry the *same file* once on a transient decoder failure.
                # Invalid-language rejection returns None, never retried.
                if accepted is False and state["attempts"] < 3 and schedule(0.75):
                    trace_status("activate", "retry-pending")
                    return
                state["done"] = True
                if legacy_live:
                    # The VOD renderer performs its delayed sync at 0.8s.
                    # Keep the Live HUD locked until that sync has completed.
                    try:
                        from twisted.internet import reactor
                        reactor.callLater(1.0, finish_live)
                    except Exception:
                        finish_live()
                try:
                    loaded = bool(controller.isSubsLoaded())
                except Exception:
                    loaded = False
                trace_status("activation-result", "accepted=%s loaded=%s attempts=%d" % (
                    accepted, loaded, state["attempts"]))
                if accepted is False and not loaded:
                    # A nonempty downloaded file is not necessarily a valid
                    # subtitle. Give a useful on-screen error instead of
                    # making the user search for logs or press RED blindly.
                    try:
                        notify = getattr(owner, "_showNotification", None)
                        if callable(notify):
                            notify("Subtitle could not be loaded. Choose another file.", timeout=6)
                    except Exception:
                        pass

            if not schedule(0.25):
                # Without an event-loop scheduler we must not open a new
                # dialog; the legacy immediate hand-off is the safe fallback.
                run()

        _cached_poster(owner)

        # resetSearchParams=False is intentional:
        # the search screen must use the title/type/season/episode from TiviMate.
        stage = "openWithCallback"
        _bridge_debug_log("opening search screen: title=%r kind=%r auto=%r" % (search_title, kind, auto_search_on_open))
        if legacy_live:
            owner._live_subtitle_search_open = True
            owner._ib_timer.stop()
        _subtitle_search_pause(owner, controller, is_live)

        def selected_and_resume(*cb_args, **cb_kwargs):
            _subtitle_search_resume(owner)
            return selected(*cb_args, **cb_kwargs)

        imdb_id = ''
        if kind == 'movie' and not is_live:
            from .TiviMateSubtitles.search_identity import imdb_value
            for row in (item, item.get('info'), item.get('_tmdb'), item.get('metadata')):
                if isinstance(row, dict):
                    imdb_id = next((imdb_value(row.get(k)) for k in ('imdb_id', 'imdbId', 'imdbID', 'imdb', 'imdbid') if imdb_value(row.get(k))), '')
                    if imdb_id:
                        break
        search_screen = session.openWithCallback(
            selected_and_resume,
            TiviMateSubtitleSearch,
            seeker,
            settings,
            None,
            [search_title],
            False,
            False,
            auto_search_on_open,
            '' if is_live else _tivimate_video_release_hint(owner),
            imdb_id
        )
        if legacy_live:
            search_screen = search_screen or getattr(session, "current_dialog", None)
            if isinstance(search_screen, TiviMateSubtitleSearch):
                search_screen._legacy_live_single_download = True
        _bridge_debug_log("openWithCallback ok")
        return True
    except Exception as exc:
        _subtitle_search_resume(owner)
        if legacy_live:
            owner._live_subtitle_search_open = False
        owner._tivimate_subtitle_search_error = stage
        _bridge_debug_log("FAILED at %s" % stage, exc)
        return False

