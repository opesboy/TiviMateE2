# -*- coding: utf-8 -*-
"""TV key in the TiviMate Live player: jump to the last Enigma2 channel
(satellite or an IPTV channel of the receiver bouquets)
and back to the same IPTV channel with one key.

Boxes like the Vu+ Zero 4K have a single video decoder (no PiP), so the two
sources are shown one at a time. The satellite channel plays full screen in
a light overlay screen; while it is open the overlay is the active InfoBar,
so the hidden TiviMate player receives no service events and never re-zaps.
"""
from __future__ import absolute_import

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eTimer

try:
    from Components.ServiceEventTracker import InfoBarBase
    _HAS_INFOBAR_BASE = True
except Exception:  # pragma: no cover - very old images
    _HAS_INFOBAR_BASE = False

    class InfoBarBase(object):
        def __init__(self, *args, **kwargs):
            pass

from .display_scale import scale_skin

_LAST_DVB = {'ref': None}
_LOG = '/tmp/tivimate_tvswitch.log'


def log(message):
    """Short TV-key diagnostic in /tmp (RAM, cleared on reboot, max ~20 KB)."""
    try:
        import os, time
        if os.path.exists(_LOG) and os.path.getsize(_LOG) > 20000:
            os.remove(_LOG)
        with open(_LOG, 'a') as handle:
            handle.write('%s %s\n' % (time.strftime('%H:%M:%S'), message))
    except Exception:
        pass
_SKIN_DIR = __file__.rsplit('/', 1)[0] + '/skins/common/'


def is_dvb_ref(ref):
    """True for a real satellite/cable/terrestrial service (not IPTV/file)."""
    try:
        if ref is None or int(ref.type) != 1:
            return False
        if ref.flags & (7 | 64 | 256 | 512):   # directory, bouquet, marker, invisible
            return False
        if ref.getPath():
            return False
        text = ref.toString().lower()
        return '://' not in text and '%3a//' not in text
    except Exception:
        return False


def is_playable_ref(ref):
    """Any real channel entry (satellite or IPTV), not a folder/marker."""
    try:
        if ref is None or ref.flags & (7 | 64 | 256 | 512):
            return False
        return bool(ref.toString())
    except Exception:
        return False


def _enigma_last_service():
    """The channel Enigma2 itself last zapped to (its own channel list only;
    TiviMate playback never updates this setting)."""
    try:
        from Components.config import config
        from enigma import eServiceReference
        value = config.tv.lastservice.value
        if value:
            ref = eServiceReference(value)
            if is_playable_ref(ref):
                return ref
    except Exception:
        pass
    return None


def is_enigma_ref(ref):
    """A receiver channel: satellite/DVB, or an IPTV channel of the Enigma2
    bouquets (recognised because Enigma2 itself zapped to it)."""
    if not is_playable_ref(ref):
        return False
    if is_dvb_ref(ref):
        return True
    last = _enigma_last_service()
    try:
        return last is not None and last.toString() == ref.toString()
    except Exception:
        return False


def remember(ref):
    if is_enigma_ref(ref):
        try:
            from enigma import eServiceReference
            _LAST_DVB['ref'] = eServiceReference(ref.toString())
        except Exception:
            _LAST_DVB['ref'] = ref


def remember_playing(session):
    try:
        remember(session.nav.getCurrentlyPlayingServiceReference())
    except Exception:
        pass


def last_dvb_ref():
    """Receiver channel to switch to with the TV key (satellite or IPTV)."""
    ref = _LAST_DVB.get('ref')          # last receiver channel seen (incl. overlay zaps)
    if is_playable_ref(ref):
        return ref
    last = _enigma_last_service()
    if last is not None:
        return last
    try:
        from Screens.InfoBar import InfoBar
        ref = InfoBar.instance.servicelist.getCurrentSelection()
        if is_playable_ref(ref):
            return ref
    except Exception:
        pass
    return None


def _service_name(ref):
    try:
        from ServiceReference import ServiceReference
        name = ServiceReference(ref).getServiceName() or ''
        if isinstance(name, bytes):
            name = name.decode('utf-8', 'replace')
        name = name.replace(u'\x86', u'').replace(u'\x87', u'').strip()
        if str is bytes:                      # Python 2.7: labels take UTF-8
            name = name.encode('utf-8')
        return name
    except Exception:
        return ''


class SatelliteOverlay(InfoBarBase, Screen):
    skin = scale_skin(
        '<screen name="TiviMateSatelliteOverlay" position="0,0" size="1920,1080" '
        'backgroundColor="#ff000000" flags="wfNoBorder">'
        '<ePixmap position="610,36" size="700,72" pixmap="' + _SKIN_DIR + 'quick_switch_pill.png" alphatest="blend" zPosition="1" />'
        '<widget name="title" position="700,40" size="590,36" font="Regular;28" foregroundColor="#FFFFFF" '
        'transparent="1" halign="left" valign="center" noWrap="1" zPosition="2" />'
        '<widget name="hint" position="700,74" size="590,28" font="Regular;20" foregroundColor="#B9C6F2" '
        'transparent="1" halign="left" valign="center" noWrap="1" zPosition="2" />'
        '</screen>')

    def __init__(self, session, ref):
        Screen.__init__(self, session)
        # Become the active InfoBar: service events now come here, not to
        # the hidden TiviMate player (popped again automatically on close).
        try:
            InfoBarBase.__init__(self, steal_current_service=True)
        except TypeError:
            InfoBarBase.__init__(self)
        except Exception:
            pass
        self.ref = ref
        self['title'] = Label(_service_name(ref) or 'Receiver')
        self['hint'] = Label('TV / EXIT: back to TiviMate   CH+/CH-: zap')
        self['actions'] = ActionMap(['OkCancelActions', 'InfobarChannelSelection', 'ChannelSelectBaseActions',
                                     'DirectionActions', 'InfoActions', 'TiviMatePlayerActions'], {
            'cancel': self.back, 'tv': self.back,
            'ok': self.showPill, 'info': self.showPill,
            'zapUp': self.zapUp, 'zapDown': self.zapDown,
            'channelUp': self.zapUp, 'channelDown': self.zapDown,
            'up': self.zapUp, 'down': self.zapDown,
        }, -2)
        self._hide_timer = eTimer()
        try:
            self._hide_conn = self._hide_timer.timeout.connect(self._hidePill)
        except Exception:
            self._hide_timer.callback.append(self._hidePill)
        self.onClose.append(self._hide_timer.stop)
        self.onFirstExecBegin.append(self._play)

    def _play(self):
        try:
            self.session.nav.playService(self.ref)
            _LAST_DVB['ref'] = self.ref
        except Exception:
            pass
        self.showPill()

    def showPill(self):
        for name in ('title', 'hint'):
            try:
                self[name].show()
            except Exception:
                pass
        try:
            self.show()
        except Exception:
            pass
        try:
            self._hide_timer.start(5000, True)
        except Exception:
            pass

    def _hidePill(self):
        try:
            self.hide()
        except Exception:
            pass

    def _zap(self, down):
        try:
            from Screens.InfoBar import InfoBar
            servicelist = InfoBar.instance.servicelist
            try:
                servicelist.servicelist.setCurrent(self.session.nav.getCurrentlyPlayingServiceReference())
            except Exception:
                pass
            if down:
                servicelist.moveDown()
            else:
                servicelist.moveUp()
            ref = servicelist.getCurrentSelection()
            if is_playable_ref(ref):
                self.ref = ref
                self.session.nav.playService(ref)
                _LAST_DVB['ref'] = ref       # from the Enigma2 channel list itself
                self['title'].setText(_service_name(ref) or 'Receiver')
        except Exception:
            pass
        self.showPill()

    def zapUp(self):
        self._zap(False)

    def zapDown(self):
        self._zap(True)

    def back(self):
        self.close(True)


def open_satellite(session, callback):
    """Open the satellite overlay; False when no DVB channel is known."""
    ref = last_dvb_ref()
    if ref is None:
        log('no receiver channel known')
        return False
    try:
        log('open receiver channel %s' % ref.toString())
    except Exception:
        pass
    session.openWithCallback(callback, SatelliteOverlay, ref)
    return True
