# -*- coding: utf-8 -*-
"""Keyboard + all-enabled-package VOD/series search rendered IN the active poster screen.

No search page is opened; GUI updates use one eTimer on the Enigma2 thread.
The existing provider/media and artwork caches are reused unchanged.
"""
import os
import threading
from types import MethodType
from enigma import eTimer
from Components.Pixmap import Pixmap
from Components.Label import Label
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    _text_type = unicode
except NameError:
    _text_type = str


def _to_text(value):
    if value is None:
        return u''
    if isinstance(value, _text_type):
        return value
    try:
        return value.decode('utf-8', 'ignore')
    except Exception:
        try:
            return _text_type(value)
        except Exception:
            return u''


def _capture(screen):
    if hasattr(screen, 'genre_items'):
        return ('genre', list(screen.genre_items or []),
                list(screen._poster_original_rows or []), screen.index,
                screen.page_start)
    if hasattr(screen, 'lastCategoryItems'):
        return ('media', list(screen.mediaItemsCurrent or []),
                list(screen.lastCategoryItems or []), screen.pageStart,
                screen.posterIndex, screen.focus)
    return ('home', list(screen.categoryItems or []),
            list(screen.latest or []), list(screen.backdrops or []),
            screen.categoryName, screen.latestStart, screen.latestIndex,
            screen.backdropStart, screen.backdropIndex, screen.focus)


def _paint(screen, rows, query, restore=False):
    """Only existing skin/layout renderers can draw a poster search result."""
    kind = 'genre' if hasattr(screen, 'genre_items') else ('media' if hasattr(screen, 'lastCategoryItems') else 'home')
    if kind == 'genre':
        try:
            screen._cancel_poster_jobs()
        except Exception:
            pass
        screen._poster_original_rows = list(rows or [])
        screen.genre_items = list(rows or []) if restore else screen._sort_poster_rows(rows)
        screen.index = 0
        screen.page_start = 0
        screen._rendered_page_key = None
        screen.render()
        if query:
            screen['status'].setText('Search all packages: %s  (%d)' % (query, len(rows or [])))
    elif kind == 'media':
        # The ordinary 5-poster/circular/big page draws the exact same layout.
        screen.lastCategoryItems = list(rows or [])
        screen.showItems(rows or [])
        screen.focus = 'items'
        try:
            screen['currentCategory'].setText('Search all packages: %s  (%d)' % (query, len(rows or [])))
        except Exception:
            pass
    else:
        screen.categoryItems = list(rows or [])
        screen.latest = screen._sortedItems(rows or [])
        screen.backdrops = list(rows or [])[:screen.BACKDROP_ITEM_LIMIT]
        screen.latestStart = screen.latestIndex = 0
        screen.backdropStart = screen.backdropIndex = 0
        screen.focus = 'latest'
        if query:
            screen.categoryName = 'Search: %s (%d)' % (query, len(rows or []))
        try:
            screen['backdropTitle'].setText('Search results')
        except Exception:
            pass
        screen._updateLatestTitle()
        screen.renderBackdrops()
        screen.renderLatest()
        screen.updateFocus()
        if screen.latest:
            screen.preview()


def install(screen):
    """Called by each poster screen after it creates its normal widgets."""
    state = {'token': 0, 'query': '', 'snapshot': None, 'closed': False,
             'reply': None, 'frame': 0, 'loading': False}
    screen._posterInlineState = state
    screen['posterInlineSearchStrip'] = Pixmap()
    screen['posterInlineSearchSpin'] = Pixmap()
    screen['posterInlineSearchText'] = Label('')
    screen['posterInlineSearchMoviesIcon'] = Pixmap()
    screen['posterInlineSearchMoviesCount'] = Label('')
    screen['posterInlineSearchSeriesIcon'] = Pixmap()
    screen['posterInlineSearchSeriesCount'] = Label('')
    visual_names = ('posterInlineSearchStrip', 'posterInlineSearchSpin',
                    'posterInlineSearchText', 'posterInlineSearchMoviesIcon',
                    'posterInlineSearchMoviesCount', 'posterInlineSearchSeriesIcon',
                    'posterInlineSearchSeriesCount')
    def hide_strip():
        for name in visual_names:
            try: screen[name].hide()
            except Exception: pass
    hide_strip()
    # OpenATV Screen.createGUIScreen executes function callbacks as source
    # code.  Always register a *bound method* for onLayoutFinish.
    # The previous closure here triggered: TypeError: exec() arg 1 must be
    # a string, bytes or code object when Movies/Series was opened.
    def _poster_inline_layout_ready(self):
        hide_strip()
    screen._posterInlineLayoutReady = MethodType(_poster_inline_layout_ready, screen)
    screen.onLayoutFinish.append(screen._posterInlineLayoutReady)
    timer = eTimer()
    try:
        screen._posterInlineTimerConn = timer.timeout.connect(lambda: tick())
    except Exception:
        try:
            timer.callback.append(lambda: tick())
        except Exception:
            timer.timeout.get().append(lambda: tick())
    screen._posterInlineTimer = timer

    def stop_visual(clear=True):
        state['loading'] = False
        try: timer.stop()
        except Exception: pass
        try: screen['posterInlineSearchSpin'].hide()
        except Exception: pass
        if clear:
            hide_strip()

    def update_strip(mode, count=0):
        # Match TiviMateE2Search._setSearchState exactly: searching ->
        # final results text, 16-frame spinner only while running.
        query = state['query'][:18]
        category = 'TV series' if screen.kind == 'series' else 'movies'
        if mode == 'searching':
            caption = 'Searching %s  "%s"' % (category, query)
        elif mode == 'error':
            caption = 'Search unavailable  "%s"' % query
        elif count:
            caption = 'Results for  "%s"' % query
        else:
            caption = 'No matches for  "%s"' % query
        screen['posterInlineSearchText'].setText(caption)
        if screen.kind == 'series':
            screen['posterInlineSearchMoviesCount'].setText('0')
            screen['posterInlineSearchSeriesCount'].setText(str(count))
        else:
            screen['posterInlineSearchMoviesCount'].setText(str(count))
            screen['posterInlineSearchSeriesCount'].setText('0')
        for name in visual_names:
            if name != 'posterInlineSearchSpin':
                try: screen[name].show()
                except Exception: pass
        if mode == 'searching':
            try: screen['posterInlineSearchSpin'].show()
            except Exception: pass
        else:
            try: screen['posterInlineSearchSpin'].hide()
            except Exception: pass

    def close():
        state['closed'] = True
        state['token'] += 1
        stop_visual()
        state['snapshot'] = None
        state['reply'] = None
    def _poster_inline_on_close(self):
        close()
    screen._posterInlineOnClose = MethodType(_poster_inline_on_close, screen)
    screen.onClose.append(screen._posterInlineOnClose)

    def restore():
        snap = state['snapshot']
        state['snapshot'] = None
        state['query'] = ''
        if not snap:
            return
        if snap[0] == 'genre':
            _paint(screen, snap[1], '', restore=True)
            screen._poster_original_rows = snap[2]
            screen.index = min(snap[3], max(0, len(screen.genre_items)-1))
            screen.page_start = snap[4]
            screen.render()
        elif snap[0] == 'media':
            screen.lastCategoryItems = snap[2]
            screen.showItems(snap[1])
            screen.pageStart = snap[3]
            screen.posterIndex = snap[4]
            screen.focus = snap[5]
            screen.renderPosterPage()
        else:
            screen.categoryName = snap[4]
            screen.categoryItems = snap[1]
            screen.latest = snap[2]
            screen.backdrops = snap[3]
            screen.latestStart, screen.latestIndex = snap[5], snap[6]
            screen.backdropStart, screen.backdropIndex, screen.focus = snap[7], snap[8], snap[9]
            try: screen['backdropTitle'].setText('Movies You Might Like' if screen.kind == 'vod' else 'TV Shows You Might Like')
            except Exception: pass
            screen._updateLatestTitle()
            screen.renderBackdrops()
            screen.renderLatest()
            screen.updateFocus()
            if screen.latest: screen.preview()

    def cancel(restore_view=True):
        state['token'] += 1
        state['reply'] = None
        stop_visual()
        if restore_view:
            restore()
        else:
            state['snapshot'] = None
            state['query'] = ''
    screen._cancelPosterInlineSearch = cancel

    def tick():
        if state['closed']:
            stop_visual()
            return
        reply = state['reply']
        if reply is not None:
            state['reply'] = None
            token, rows, error = reply
            if token == state['token']:
                stop_visual(clear=False)
                try:
                    if error:
                        update_strip('error', 0)
                    else:
                        _paint(screen, rows, state['query'])
                        update_strip('done', len(rows or []))
                except Exception:
                    # Do not leave Searching/spinner running after a failed paint.
                    update_strip('error', 0)
                return
        if not state['loading']:
            return
        state['frame'] = (state['frame'] + 1) % 16
        try:
            image = os.path.join(os.path.dirname(__file__), 'skins', 'loading',
                                 'spin_%02d.png' % state['frame'])
            screen['posterInlineSearchSpin'].instance.setPixmapFromFile(image)
        except Exception:
            pass
        timer.start(70, True)

    def complete(value):
        if value is None or state['closed']:
            return
        value = _to_text(value).strip()
        state['token'] += 1
        token = state['token']
        stop_visual()
        state['reply'] = None
        if not value:
            restore()
            return
        if state['snapshot'] is None:
            state['snapshot'] = _capture(screen)
        state['query'] = value
        state['loading'] = True
        state['frame'] = 0
        update_strip('searching', 0)
        try:
            image = os.path.join(os.path.dirname(__file__), 'skins', 'loading', 'spin_00.png')
            screen['posterInlineSearchSpin'].instance.setPixmapFromFile(image)
        except Exception:
            pass
        timer.start(70, True)
        source = dict(screen.source or {})
        kind = screen.kind
        def worker():
            rows, error = [], ''
            try:
                from .core import get_source_client
                from .filters import get_filtered_streams
                client = get_source_client(source)
                # Entire enabled library, never just selected category; existing
                # adult/package filters and RAM/disk caches are respected.
                catalog = get_filtered_streams(source, kind, client, use_cache=True)
                q = value.lower()
                first, other = [], []
                seen = set()
                for record in (catalog or []):
                    if not isinstance(record, dict):
                        continue
                    name = _to_text(record.get('name') or record.get('title')).strip().lower()
                    if not name or q not in name:
                        continue
                    key = (_to_text(record.get('stream_id') or record.get('series_id') or
                                    record.get('id') or ''), name,
                           _to_text(record.get('category_id') or ''))
                    if key in seen: continue
                    seen.add(key)
                    (first if name.startswith(q) else other).append(record)
                    if len(first) + len(other) >= 500:
                        break
                rows = first + other
            except Exception as exc:
                error = _to_text(exc)
            if not state['closed'] and token == state['token']:
                state['reply'] = (token, rows, error)
        t = threading.Thread(target=worker, name='TiviMateInlinePosterSearch')
        t.daemon = True
        t.start()
    def open_keyboard():
        if state['closed']:
            return
        title = 'Search all TV series packages' if screen.kind == 'series' else 'Search all movie packages'
        screen.session.openWithCallback(
            complete, VirtualKeyBoard, title=title, text=state['query'] or '')
    screen._openPosterInlineSearch = open_keyboard
