# -*- coding: utf-8 -*-
"""Record every HTTP request a subtitle provider makes (search subprocess).

Written to /tmp/tivimate_subtitle_search.txt (search) and
/tmp/tivimate_subtitle_download.txt (download): host, path, HTTP status,
size, time, or the error. One search run shows which site blocks, moved
or changed. Works on Python 2.7 and 3; never raises.
"""
from __future__ import absolute_import

import threading
import time

_LOCK = threading.Lock()
_ROWS = []
_MAX = 400


def _short(url):
    try:
        text = str(url)
    except Exception:
        return "?"
    from urllib.parse import urlsplit, urlunsplit
    try:
        parts = urlsplit(text)
        if parts.scheme in ('http', 'https'):
            # Never log signed URLs, API keys, or userinfo.
            text = urlunsplit((parts.scheme, parts.netloc.rsplit('@', 1)[-1], parts.path, '', ''))
    except Exception:
        return '[URL]'
    return text[:160]


def _add(method, url, status, size, started, error=None):
    row = "%-4s %-3s %7s %5.1fs %s%s" % (
        method, status if status is not None else "ERR",
        size if size is not None else "-", time.time() - started, _short(url),
        ("  !! %s" % (error if isinstance(error, str) else type(error).__name__)) if error is not None else "")
    with _LOCK:
        if len(_ROWS) < _MAX:
            _ROWS.append(row)


def _download_timeout(value):
    # Preserve a provider's longer timeout; allow slow connections/data reads.
    if value is None:
        return (15, 30)
    if isinstance(value, (int, float)) and value > 0:
        return (max(15, value), max(30, value))
    if isinstance(value, tuple) and len(value) == 2:
        return tuple(max(floor, item) if isinstance(item, (int, float)) and item > 0 else item
                     for item, floor in zip(value, (15, 30)))
    return value


def install(download=False):
    try:
        import requests
        original = requests.Session.request
        if not getattr(original, "_tivimate_traced", False):
            def traced(self, method, url, *args, **kwargs):
                started = time.time()
                if download:
                    kwargs['timeout'] = _download_timeout(kwargs.get('timeout'))
                try:
                    response = original(self, method, url, *args, **kwargs)
                except Exception as exc:
                    _add(method, url, None, None, started, exc)
                    raise
                if download and not kwargs.get("stream"):
                    # Content-Length describes compressed bytes when a content
                    # encoding is present. Only compare actual identity bodies.
                    declared = response.headers.get("Content-Length", "")
                    encoding = response.headers.get("Content-Encoding", "identity").lower().strip()
                    if (encoding in ("", "identity") and str(declared).isdigit()
                            and method.upper() != "HEAD" and response.status_code not in (204, 304)
                            and not response.headers.get("Transfer-Encoding")):
                        actual = len(response.content or b"")
                        if actual != int(declared):
                            exc = requests.exceptions.ChunkedEncodingError("Incomplete subtitle HTTP body")
                            _add(method, url, response.status_code, actual, started, exc)
                            raise exc
                try:
                    size = response.headers.get("Content-Length") or (
                        len(response.content) if not kwargs.get("stream") else "stream")
                    final = response.url if response.url != url else url
                    note = None
                    head = b""
                    if not kwargs.get("stream"):
                        head = (response.content or b"")[:2048].lower()
                    if b"cf-browser-verification" in head or b"just a moment" in head or b"cf-chl" in head:
                        note = "Cloudflare challenge page"
                    _add(method, final, response.status_code, size, started, note)
                except Exception:
                    pass
                return response
            traced._tivimate_traced = True
            requests.Session.request = traced
    except Exception:
        pass
    try:
        from six.moves.urllib import request as urlrequest
        original_open = urlrequest.urlopen
        if not getattr(original_open, "_tivimate_traced", False):
            def traced_open(url, *args, **kwargs):
                started = time.time()
                target = getattr(url, "full_url", None) or getattr(url, "get_full_url", lambda: url)()
                if download:
                    # urlopen timeout is scalar, and may be passed positionally.
                    import socket
                    if len(args) >= 2:
                        value = args[1]
                        if value is socket._GLOBAL_DEFAULT_TIMEOUT or (isinstance(value, (int, float)) and 0 < value < 30):
                            args = (args[0], 30) + args[2:]
                    else:
                        value = kwargs.get('timeout', socket._GLOBAL_DEFAULT_TIMEOUT)
                        if value is socket._GLOBAL_DEFAULT_TIMEOUT or (isinstance(value, (int, float)) and 0 < value < 30):
                            kwargs['timeout'] = 30
                try:
                    response = original_open(url, *args, **kwargs)
                except Exception as exc:
                    _add("GET", target, getattr(exc, "code", None), None, started, exc)
                    raise
                _add("GET", target, getattr(response, "code", None) or getattr(response, "status", None),
                     None, started)
                return response
            traced_open._tivimate_traced = True
            urlrequest.urlopen = traced_open
            try:
                import urllib.request as py3_request
                py3_request.urlopen = traced_open
            except Exception:
                pass
            try:
                import urllib2
                urllib2.urlopen = traced_open
            except Exception:
                pass
    except Exception:
        pass


def lines():
    with _LOCK:
        return list(_ROWS)


def write(path, header_lines):
    try:
        handle = open(path, "w")
        handle.write("\n".join(list(header_lines) + ["", "HTTP requests:"] + lines()) + "\n")
        handle.close()
    except Exception:
        pass
