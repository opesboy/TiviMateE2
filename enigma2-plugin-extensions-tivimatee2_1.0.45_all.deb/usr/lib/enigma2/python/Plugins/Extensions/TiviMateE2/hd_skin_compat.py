# -*- coding: utf-8 -*-
"""HD Satelit native-GUI artwork fixes; NO network calls or cache resets."""
import hashlib
import os
import threading
import re
from collections import OrderedDict
from .display_scale import scale_factors

_LOCK = threading.RLock()
_IMAGE_CACHE = [None]

# HD-Satelit: source artwork may be touched by the shared disk cache without
# changing its actual pixels. Never include file mtime in a derived image key.
# A short, bounded in-memory memo avoids rehashing the same image for each style.
_CONTENT_KEYS = OrderedDict()
_CONTENT_KEYS_LOCK = threading.RLock()
_CONTENT_KEYS_LIMIT = 384

def _source_content_key(path, source_stat):
    """Stable for mtime-only updates, new when the source bytes really change."""
    resolved = os.path.realpath(path)
    stamp = (resolved, source_stat.st_size,
             getattr(source_stat, 'st_mtime_ns', source_stat.st_mtime),
             getattr(source_stat, 'st_ctime_ns', source_stat.st_ctime),
             getattr(source_stat, 'st_ino', 0))
    with _CONTENT_KEYS_LOCK:
        cached = _CONTENT_KEYS.get(stamp)
        if cached is not None:
            _CONTENT_KEYS.move_to_end(stamp)
            return cached
    # Sampled fingerprint (size + head/middle/tail). Reading the WHOLE poster
    # on every LRU mtime touch made HD-Satelit re-hash each card and look
    # like it ignored the cache. Replaced artwork still changes these bytes.
    fingerprint = hashlib.sha1()
    size = int(source_stat.st_size or 0)
    fingerprint.update(('%d|' % size).encode('ascii'))
    with open(path, 'rb') as artwork:
        fingerprint.update(artwork.read(16384))
        if size > 49152:
            artwork.seek(size // 2)
            fingerprint.update(artwork.read(16384))
        if size > 16384:
            artwork.seek(max(0, size - 16384))
            fingerprint.update(artwork.read(16384))
    # The path remains part of each render key so different originals do not
    # unexpectedly share the same output. The digest catches same-size edits.
    key = fingerprint.hexdigest()[:24]
    with _CONTENT_KEYS_LOCK:
        _CONTENT_KEYS[stamp] = key
        _CONTENT_KEYS.move_to_end(stamp)
        while len(_CONTENT_KEYS) > _CONTENT_KEYS_LIMIT:
            _CONTENT_KEYS.popitem(last=False)
    return key

_CARD_INDEX = OrderedDict()
_CARD_INDEX_LIMIT = 1024


_FAIL_LOGGED = [0]


def _log_card_failure(path, reason):
    """Why an HD-Satelit card fell back to the small native decoder (max 40 lines)."""
    if _FAIL_LOGGED[0] >= 40:
        return
    _FAIL_LOGGED[0] += 1
    try:
        import time
        from .cache_manager import get_cache_dir
        with open(os.path.join(get_cache_dir('hd_round_faces'), '_fallback.log'), 'a') as log:
            log.write('%s %s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), reason, path))
    except Exception:
        pass


def _remember_card(fast_key, result):
    if not fast_key or not result:
        return
    with _CONTENT_KEYS_LOCK:
        _CARD_INDEX[fast_key] = result
        _CARD_INDEX.move_to_end(fast_key)
        while len(_CARD_INDEX) > _CARD_INDEX_LIMIT:
            _CARD_INDEX.popitem(last=False)


def _legacy_content_key(path):
    """Content key used by earlier builds (SHA1 of the whole file)."""
    fingerprint = hashlib.sha1()
    with open(path, 'rb') as artwork:
        while True:
            chunk = artwork.read(131072)
            if not chunk:
                break
            fingerprint.update(chunk)
    return fingerprint.hexdigest()[:24]


def _adopt_legacy(folder, legacy_name, result):
    """Reuse an already-built image from the previous naming; never rebuild it."""
    try:
        old = os.path.join(folder, legacy_name + '.png')
        if os.path.isfile(old) and os.path.getsize(old) > 100:
            try:
                os.rename(old, result)
            except OSError:
                import shutil
                shutil.copyfile(old, result)
            return True
    except Exception:
        pass
    return False


def hdsatelit_image():
    """Detect receiver image, not merely the desktop resolution.

    HD-Satelit can run FHD GUI even if the original theme was called HD.
    This guard keeps the proven Python-3 behaviour on all other images.
    """
    cached = _IMAGE_CACHE[0]
    if cached is not None:
        return cached
    matched = False
    for filename in ('/etc/image-version','/etc/issue','/etc/os-release',
                     '/etc/enigma2/image-version'):
        try:
            with open(filename,'r') as f:
                sample = f.read(4096).lower()
            if 'hdsatelit' in sample or 'hd satelit' in sample or 'hd-satelit' in sample:
                matched = True
                break
        except (IOError, OSError):
            pass
    _IMAGE_CACHE[0] = matched
    return matched

def visual_compat_image():
    return hdsatelit_image() or special_hd_gui()


def special_hd_gui():
    """Restrict all visual changes to actual native 1280x720 GUI desktops."""
    x,y = scale_factors()
    return 0.58 <= x <= 0.75 and 0.58 <= y <= 0.75

def scale_hd_images(xml):
    """Scale static pixmap assets alongside their HD-sized widget geometry."""
    if not special_hd_gui(): return xml
    def fix(m):
        tag=m.group(0)
        if 'pixmap=' not in tag or 'scale=' in tag:return tag
        return tag[:-2]+' scale="1" />'
    return re.sub(r'<(?:widget|ePixmap)\b[^>]*?/>',fix,xml)

def _cached_image(path, w, h, circular):
    if not visual_compat_image() or not path or not os.path.isfile(path):
        return ''
    try:
        w,h=int(w),int(h)
        if not (10<=w<=256 and 10<=h<=256):return ''
        from .pil_compat import install_pil_compat
        if not install_pil_compat(): return ''
        from PIL import Image, ImageOps, ImageDraw
        stat=os.stat(path)
        digest=hashlib.sha1(('%s|%s|%s|%s|%s|%s' % (path,stat.st_size,_source_content_key(path,stat),w,h,int(circular))).encode('utf-8')).hexdigest()[:20]
        from .cache_manager import get_cache_dir
        folder=get_cache_dir('hd_round_faces')
        if not os.path.isdir(folder): os.makedirs(folder)
        dest=os.path.join(folder,digest+'.png')
        if os.path.isfile(dest) and os.path.getsize(dest)>100:return dest
        try:
            legacy=hashlib.sha1(('%s|%s|%s|%s|%s|%s' % (path,stat.st_size,_legacy_content_key(path),w,h,int(circular))).encode('utf-8')).hexdigest()[:20]
            if _adopt_legacy(folder,legacy,dest):return dest
        except Exception:
            pass
        with _LOCK:
            if os.path.isfile(dest) and os.path.getsize(dest)>100:return dest
            with Image.open(path) as src:
                resample=getattr(Image, 'Resampling', Image).LANCZOS
                if circular:
                    size=max(w,h)
                    canvas=ImageOps.fit(src.convert('RGBA'),(size,size),method=resample)
                    circle=Image.new('L',(size,size),0)
                    ImageDraw.Draw(circle).ellipse((0,0,size-1,size-1),fill=255)
                    canvas.putalpha(circle)
                    img=canvas.resize((w,h),resample)
                else:
                    img=ImageOps.contain(src.convert('RGBA'),(w,h),method=resample)
                    padded=Image.new('RGBA',(w,h),(0,0,0,0))
                    padded.alpha_composite(img,((w-img.width)//2,(h-img.height)//2))
                    img=padded
            tmp=dest+'.tmp.%s'%os.getpid()
            try:
                img.save(tmp,format='PNG',compress_level=1)
                os.rename(tmp,dest)
            finally:
                if os.path.isfile(tmp):
                    try:os.remove(tmp)
                    except Exception:pass
        return dest
    except Exception:
        return ''

def fitted_round_icon(path,w,h):
    return _cached_image(path,w,h,False)

def fitted_round_actor(path,w,h):
    return _cached_image(path,w,h,True)


def fitted_rounded_card(path, width, height, radius=14, force=False):
    """Saga-like full-image poster: native card size, no crop or empty bars.

    Bounded background PNG preparation with real alpha rounded corners.
    The downloaded/cached original poster is never modified.
    force=True rounds the card on every receiver image, not only HD-Satelit.
    """
    if not (force or visual_compat_image()) or not path or not os.path.isfile(path):
        return ''
    result = ''
    try:
        width, height, radius = int(width), int(height), int(radius)
        try:
            st0 = os.stat(path)
            fast_key = (os.path.realpath(path), st0.st_size, getattr(st0, 'st_ino', 0), width, height, radius)
            with _CONTENT_KEYS_LOCK:
                known = _CARD_INDEX.get(fast_key)
            if known and os.path.isfile(known):
                return known
        except Exception:
            fast_key = None
        if not (40 <= width <= 700 and 40 <= height <= 700):
            _log_card_failure(path, 'size %dx%d out of range' % (width, height))
            return ''
        from .cache_manager import get_cache_dir
        stat = os.stat(path)
        # Version the derived thumbnail so previously cropped r245 images
        # can never be reused as an uncropped Saga-style poster.
        key = hashlib.sha1(('saga-complete-v3|%s|%s|%s|%s|%s|%s' %
                (path, stat.st_size, _source_content_key(path,stat), width, height, radius)).encode('utf-8')).hexdigest()[:20]
        folder = get_cache_dir('hd_round_faces')
        result = os.path.join(folder, key + '.png')
        if os.path.isfile(result) and os.path.getsize(result) > 100:
            _remember_card(fast_key, result)
            return result
        try:
            legacy = hashlib.sha1(('saga-complete-v3|%s|%s|%s|%s|%s|%s' %
                    (path, stat.st_size, _legacy_content_key(path), width, height, radius)).encode('utf-8')).hexdigest()[:20]
            if _adopt_legacy(folder, legacy, result):
                _remember_card(fast_key, result)
                return result
        except Exception:
            pass
        from .pil_compat import install_pil_compat
        if not install_pil_compat():
            _log_card_failure(path, 'Pillow not available')
            return ''
        from PIL import Image, ImageOps, ImageDraw
        if not os.path.isdir(folder):
            os.makedirs(folder)
        # Two different films must not serialize on the same global lock.
        # Atomic individual temp names also tolerate concurrent callers.
        with Image.open(path) as raw:
            iw, ih = raw.size
            if iw < 32 or ih < 24 or iw * ih > 30000000:
                return ''
            try:
                if raw.format == 'JPEG':
                    raw.draft('RGB', (width * 2, height * 2))
            except Exception:
                pass
            sample = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS', 3)
            # Saga uses exact-width/height resizing, not ImageOps.fit crop.
            # Preserve the COMPLETE original poster from top to bottom and
            # left to right. No transparent/black letterbox and no second
            # scaling of the already-painted widget on HD Satelit.
            fitted = raw.resize((width, height), sample)
            img = fitted.convert('RGB').convert('RGBA')
        r = max(3, min(radius, width // 4, height // 4))
        alpha = Image.new('L', (width, height), 0)
        d = ImageDraw.Draw(alpha)
        d.rectangle((r, 0, width-r-1, height-1), fill=255)
        d.rectangle((0, r, width-1, height-r-1), fill=255)
        for x, y in ((0, 0), (width-2*r, 0),
                     (0, height-2*r), (width-2*r, height-2*r)):
            d.ellipse((x, y, x+2*r-1, y+2*r-1), fill=255)
        img.putalpha(alpha)
        tmp = result + '.tmp.%s.%s' % (os.getpid(), threading.get_ident())
        try:
            img.save(tmp, 'PNG', compress_level=1)
            os.replace(tmp, result)
            _remember_card(fast_key, result)
        finally:
            if os.path.exists(tmp):
                try: os.unlink(tmp)
                except OSError: pass
        return result
    except Exception as error:
        _log_card_failure(path, 'error %r' % (error,))
        # Concurrent workers may have successfully created the same file.
        try:
            if os.path.isfile(result) and os.path.getsize(result) > 100:
                return result
        except Exception:
            pass
        return ''


# Circles are made in parallel: one lock per output file (the shared _LOCK made
# every circle wait for the previous one and for GENRE backdrop crops).
_CIRCLE_LOCKS = [threading.Lock() for _ in range(16)]
_CIRCLE_MASKS = {}


def _circle_mask(size, resample):
    """Smooth round alpha mask, made once per size and reused."""
    mask = _CIRCLE_MASKS.get(size)
    if mask is None:
        from PIL import Image, ImageDraw
        big = size * 4
        mask = Image.new('L', (big, big), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, big - 1, big - 1), fill=255)
        mask = mask.resize((size, size), resample)
        _CIRCLE_MASKS[size] = mask
    return mask


def cached_circle_poster(path, width, height):
    """Path of the already-made smooth circle for this poster, or '' (no work)."""
    try:
        width, height = int(width), int(height)
        if width != height or not path or not os.path.isfile(path):
            return ''
        from .cache_manager import get_cache_dir
        stat = os.stat(path)
        key = hashlib.sha1(('hds-circle-poster-v1|%s|%s|%s|%s' % (
            path, stat.st_size, _source_content_key(path, stat), width)).encode('utf-8')).hexdigest()[:24]
        result = os.path.join(get_cache_dir('hd_round_faces'), 'circle_' + key + '.png')
        if os.path.isfile(result) and os.path.getsize(result) > 200:
            return result
    except Exception:
        pass
    return ''


def fitted_circle_poster(path, width, height, force=False):
    """Derived HD Satelit circle poster with real RGBA transparency.

    Prepared off the GUI thread, preserving the original downloaded poster and
    the shared artwork queue. A stable on-disk derivative makes revisits fast.
    """
    if not (force or hdsatelit_image()) or not path or not os.path.isfile(path):
        return ''
    try:
        width, height = int(width), int(height)
        if width != height or not (64 <= width <= 512):
            return ''
        from .pil_compat import install_pil_compat
        if not install_pil_compat():
            # No Pillow: cut the circle with the receiver's ffmpeg or
            # ImageMagick instead of showing the square poster under the ring.
            return _tool_circle(path, width)
        from PIL import Image, ImageOps, ImageDraw
        from .cache_manager import get_cache_dir
        stat = os.stat(path)
        key = hashlib.sha1(('hds-circle-poster-v1|%s|%s|%s|%s' % (
            path, stat.st_size, _source_content_key(path,stat), width)).encode('utf-8')).hexdigest()[:24]
        folder = get_cache_dir('hd_round_faces')
        if not os.path.isdir(folder):
            os.makedirs(folder)
        result = os.path.join(folder, 'circle_' + key + '.png')
        if os.path.isfile(result) and os.path.getsize(result) > 200:
            return result
        try:
            legacy = hashlib.sha1(('hds-circle-poster-v1|%s|%s|%s|%s' % (
                path, stat.st_size, _legacy_content_key(path), width)).encode('utf-8')).hexdigest()[:24]
            old = os.path.join(folder, 'circle_' + legacy + '.png')
            if os.path.isfile(old) and os.path.getsize(old) > 200:
                os.rename(old, result)
                return result
        except Exception:
            pass
        with _CIRCLE_LOCKS[hash(result) % len(_CIRCLE_LOCKS)]:
            if os.path.isfile(result) and os.path.getsize(result) > 200:
                return result
            resample = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS',
                               getattr(Image, 'ANTIALIAS', 3))
            with Image.open(path) as source:
                iw, ih = source.size
                if iw < 32 or ih < 32 or iw * ih > 30000000:
                    return ''
                try:
                    # JPEG: decode directly at (at least) the circle size.
                    if source.format == 'JPEG':
                        source.draft('RGB', (width, height))
                except Exception:
                    pass
                canvas = ImageOps.fit(source.convert('RGB'), (width, height),
                                      method=resample, centering=(0.5, 0.40)).convert('RGBA')
            # Smooth edge (supersampled mask, made once per size).
            canvas.putalpha(_circle_mask(width, resample))
            tmp = result + '.%s.tmp' % threading.get_ident()
            try:
                canvas.save(tmp, format='PNG', compress_level=1)
                os.replace(tmp, result)
            finally:
                if os.path.isfile(tmp):
                    try: os.unlink(tmp)
                    except OSError: pass
            return result
    except Exception:
        return ''


def _tool_circle(path, size):
    import hashlib
    import shutil
    import subprocess
    try:
        if not path or not os.path.isfile(path) or not (32 <= size <= 512):
            return ""
        from .cache_manager import get_cache_dir
        folder = get_cache_dir("hd_round_faces")
        os.makedirs(folder, exist_ok=True)
        stat = os.stat(path)
        key = hashlib.sha1(("tool-circle-v1|%s|%s|%s|%s" % (
            path, stat.st_size, int(stat.st_mtime), size)).encode("utf-8")).hexdigest()[:24]
        result = os.path.join(folder, "circle_t_" + key + ".png")
        if os.path.isfile(result) and os.path.getsize(result) > 200:
            return result
        tmp = result + ".%d.tmp.png" % os.getpid()
        r = (size - 1) / 2.0
        commands = []
        ffmpeg = shutil.which("ffmpeg")
        if ffmpeg:
            vf = ("scale=%d:%d:force_original_aspect_ratio=increase,"
                  "crop=%d:%d:(iw-%d)/2:(ih-%d)*0.4,format=rgba,"
                  "geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':"
                  "a='if(lte((X-%.1f)*(X-%.1f)+(Y-%.1f)*(Y-%.1f),%.1f),255,0)'") % (
                size, size, size, size, size, size, r, r, r, r, r * r)
            commands.append([ffmpeg, "-nostdin", "-loglevel", "error", "-y", "-i", path,
                             "-vf", vf, "-frames:v", "1", "-c:v", "png", tmp])
        convert = shutil.which("convert")
        if convert:
            commands.append([convert, path, "-auto-orient", "-resize", "%dx%d^" % (size, size),
                             "-gravity", "center", "-extent", "%dx%d" % (size, size),
                             "(", "-size", "%dx%d" % (size, size), "xc:black", "-fill", "white",
                             "-draw", "circle %.1f,%.1f %.1f,0" % (r, r, r), ")",
                             "-alpha", "off", "-compose", "CopyOpacity", "-composite", "PNG32:" + tmp])
        for command in commands:
            try:
                subprocess.run(command, timeout=10, check=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if os.path.isfile(tmp) and os.path.getsize(tmp) > 200:
                    os.replace(tmp, result)
                    return result
            except Exception:
                pass
            finally:
                if os.path.isfile(tmp):
                    try:
                        os.unlink(tmp)
                    except OSError:
                        pass
    except Exception:
        pass
    return ""



def fitted_wide_backdrop(path, width, height, force=False):
    """Return a crop-to-fill JPEG for the *existing* HD Satelit card dimensions.

    Called from a worker only. Source artwork is never modified or deleted.
    A separate derived thumbnail avoids the black bars produced when ePicLoad
    letterboxes a source with the wrong aspect ratio.
    """
    if not (force or visual_compat_image()) or not path or not os.path.isfile(path):
        return ''
    try:
        width, height = int(width), int(height)
        if not (80 <= width <= 1920 and 60 <= height <= 720):
            return ''
        from .pil_compat import install_pil_compat
        if not install_pil_compat():
            return ''
        from PIL import Image, ImageOps
        from .cache_manager import get_cache_dir
        stat = os.stat(path)
        key = hashlib.sha1(('hds-wide-v1|%s|%s|%s|%s|%s' %
            (path, stat.st_size, _source_content_key(path,stat), width, height)).encode('utf-8')).hexdigest()[:24]
        folder = get_cache_dir('hd_round_faces')
        if not os.path.isdir(folder):
            os.makedirs(folder)
        result = os.path.join(folder, 'wide_' + key + '.jpg')
        if os.path.isfile(result) and os.path.getsize(result) > 200:
            return result
        try:
            legacy = hashlib.sha1(('hds-wide-v1|%s|%s|%s|%s|%s' %
                (path, stat.st_size, _legacy_content_key(path), width, height)).encode('utf-8')).hexdigest()[:24]
            old = os.path.join(folder, 'wide_' + legacy + '.jpg')
            if os.path.isfile(old) and os.path.getsize(old) > 200:
                os.rename(old, result)
                return result
        except Exception:
            pass
        with _LOCK:
            if os.path.isfile(result) and os.path.getsize(result) > 200:
                return result
            resample = getattr(getattr(Image, 'Resampling', Image), 'LANCZOS')
            with Image.open(path) as raw:
                if raw.width < 32 or raw.height < 24 or raw.width * raw.height > 30000000:
                    return ''
                cropped = ImageOps.fit(raw.convert('RGB'), (width, height),
                                       method=resample, centering=(0.5, 0.43))
                temp = result + '.%s.tmp' % threading.get_ident()
                try:
                    cropped.save(temp, format='JPEG', quality=85)
                    os.replace(temp, result)
                finally:
                    if os.path.isfile(temp):
                        try: os.unlink(temp)
                        except OSError: pass
        return result
    except Exception:
        return ''
