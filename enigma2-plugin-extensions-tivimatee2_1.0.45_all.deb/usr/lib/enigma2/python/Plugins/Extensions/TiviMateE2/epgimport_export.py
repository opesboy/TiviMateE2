# -*- coding: utf-8 -*-
"""Export every Xtream server to EPGImport (additive).

Files written under /etc/epgimport:
  tivimate.sources.xml          one category "TiviMate", one <source> per server
  tivimate_<server>.channels.xml  Live service reference -> XMLTV channel id
The internal EPG (epg_local) is not changed. Runs in a daemon thread. A log is
kept in the plugin data folder for troubleshooting.
"""
import glob
import os
import re
import threading
import time
from xml.sax.saxutils import escape

EPG_DIR = "/etc/epgimport"
SOURCES_FILE = "tivimate.sources.xml"  # EPGImport only reads *.sources.xml
OLD_SOURCES_FILES = ("tivimate_sources.xml",)
SERVICE_TYPE = 4097  # player default on images without a saved engine choice
_LOCK = threading.Lock()


def _slug(text):
    return re.sub(r"[^A-Za-z0-9_]+", "_", str(text or ""))[:40].strip("_") or "server"


def _log(message):
    try:
        from .storage import data_path
        with open(data_path("epgimport_export.log"), "a", encoding="utf-8") as handle:
            handle.write("%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), message))
    except Exception:
        pass


HDD_EPG_DIR = "/media/hdd/epgimport"


def _channels_dir():
    """HDD when a real writable HDD is mounted, otherwise /etc/epgimport."""
    try:
        from .storage import hdd_available
        if hdd_available():
            if not os.path.isdir(HDD_EPG_DIR):
                os.makedirs(HDD_EPG_DIR)
            if os.access(HDD_EPG_DIR, os.W_OK):
                return HDD_EPG_DIR
    except Exception as error:
        _log("HDD not usable for channels files: %s" % error)
    return EPG_DIR


def _write_channels(name, text):
    """Write one channels file. On HDD the real file lives on the disk and
    /etc/epgimport only keeps a link to it (no flash space used); EPGImport
    reads it through the link exactly as before."""
    target_dir = _channels_dir()
    flash_path = os.path.join(EPG_DIR, name)
    if target_dir == EPG_DIR:
        if os.path.islink(flash_path):
            os.remove(flash_path)
        _write_atomic(flash_path, text)
        return flash_path
    disk_path = os.path.join(target_dir, name)
    _write_atomic(disk_path, text)
    if os.path.islink(flash_path) and os.path.realpath(flash_path) == os.path.realpath(disk_path):
        return disk_path
    if os.path.lexists(flash_path):
        os.remove(flash_path)
    os.symlink(disk_path, flash_path)
    return disk_path


def _write_atomic(path, text):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        handle.write(text)
    os.replace(tmp, path)


BOUQUET_DIR = "/etc/enigma2"


def _receiver_bouquet_refs(source):
    """stream_id -> service references of THIS server's channels found in every
    bouquet on the receiver, whichever program created it (TiviMate, XKlass,
    XStreamity, a manual list...). Channels are recognised by their stream URL:
    same host, username and password, and the stream id as the last path part.
    """
    from urllib.parse import unquote, urlsplit

    found = {}
    def _host(value):
        value = str(value or "").strip()
        if value and "://" not in value:
            value = "http://" + value     # server saved without a scheme
        try:
            return (urlsplit(value).hostname or "").lower()
        except Exception:
            return ""

    host = _host(source.get("url"))
    user = str(source.get("username") or "")
    password = str(source.get("password") or "")
    if not (host and user and password):
        return found
    for path in sorted(glob.glob(os.path.join(BOUQUET_DIR, "userbouquet.*.tv")) +
                       glob.glob(os.path.join(BOUQUET_DIR, "userbouquet.*.radio"))):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as handle:
                lines = handle.readlines()
        except Exception:
            continue
        for line in lines:
            if not line.startswith("#SERVICE "):
                continue
            parts = line[9:].strip().split(":")
            if len(parts) < 11:
                continue
            # All-zero ids are shared by every channel of that list: EPG
            # written to them would land on all its channels at once.
            if all(field.strip("0") == "" for field in parts[3:6]):
                continue
            try:
                url = unquote(parts[10]).split("#", 1)[0]
                if "://" not in url:
                    url = "http://" + url
                bits = urlsplit(url)
            except Exception:
                continue
            if _host(url) != host:
                continue
            segments = [x for x in bits.path.split("/") if x]
            if len(segments) < 3 or segments[-3] != user or segments[-2] != password:
                continue
            stream_id = segments[-1].split(".", 1)[0]
            if not stream_id.isdigit():
                continue
            # EPGImport / eEPGCache store events on DVB type-1 references.
            # Keep the bouquet's own ids and only change the playback type
            # (4097/5001/5002 -> 1), exactly like XStreamity and XKlass do.
            # Same line format as BouquetMakerXtream / JediMaker / XKlass:
            # EPGImport needs a URL part for IPTV references.
            ref = "1:" + ":".join(parts[1:10]) + ":http%3a//example.m3u8"
            refs = found.setdefault(stream_id, [])
            if ref not in refs:
                refs.append(ref)
    return found


def _export_channels(source, slug):
    """Write the channels file for one Xtream server. Return its channel count."""
    from .core import get_source_client

    client = get_source_client(source)
    rows = client.streams("live") or []
    try:
        receiver_refs = _receiver_bouquet_refs(source)
    except Exception as error:
        receiver_refs = {}
        _log("bouquet scan failed for %s: %s" % (slug, error))
    lines = []
    channels = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        xmltv_id = str(row.get("epg_channel_id") or "").strip()
        if not xmltv_id:
            continue
        # Only channels that really exist in a bouquet on this receiver (from
        # TiviMate's own export or any other program). Writing every server
        # channel made /etc/epgimport several MB on flash for no benefit:
        # Enigma2 shows EPG only for services in its bouquets.
        refs = receiver_refs.get(str(row.get("stream_id") or "").strip(), [])
        if not refs:
            continue
        channel_id = escape(xmltv_id, {'"': "&quot;"})
        for one_ref in refs:
            line = '  <channel id="%s">%s</channel>' % (channel_id, escape(one_ref))
            if line not in lines:
                lines.append(line)
        channels += 1
    channels_name = "tivimate_%s.channels.xml" % slug
    where = _write_channels(channels_name, '<channels>\n%s\n</channels>\n' % "\n".join(lines))
    _log("%s: %d channels, %d references -> %s" % (slug, channels, len(lines), where))
    return channels


def export_all(sources):
    """Export all Xtream servers and rebuild the single TiviMate sources file."""
    from .epg_local import _xmltv_url

    os.makedirs(EPG_DIR, exist_ok=True)
    entries = []
    for source in sources or []:
        if not isinstance(source, dict) or source.get("type") != "xtream":
            continue
        xmltv = _xmltv_url(source)
        if not xmltv:
            _log("skip %s: no XMLTV url" % (source.get("name") or source.get("url")))
            continue
        name = str(source.get("name") or source.get("url") or "server")
        slug = _slug(name)
        try:
            count = _export_channels(source, slug)
            _log("exported %d channels for %s" % (count, name))
        except Exception as error:
            _log("channels failed for %s: %s" % (name, error))
            continue
        entries.append((name, slug, xmltv))
    if not entries:
        _log("no xtream servers to export")
        return 0
    body = []
    for name, slug, xmltv in entries:
        body.append(
            '    <source type="gen_xmltv" channels="tivimate_%s.channels.xml">\n'
            '      <description>TiviMate - %s</description>\n'
            '      <url>%s</url>\n'
            '    </source>' % (slug, escape(name), escape(xmltv)))
    sources_xml = (
        '<sources>\n'
        '  <sourcecat sourcecatname="TiviMate">\n'
        '%s\n'
        '  </sourcecat>\n'
        '</sources>\n') % "\n".join(body)
    _write_atomic(os.path.join(EPG_DIR, SOURCES_FILE), sources_xml)
    _log("wrote %s with %d servers" % (os.path.join(EPG_DIR, SOURCES_FILE), len(entries)))
    # Remove sources files written by earlier builds (wrong name / duplicate categories).
    old = glob.glob(os.path.join(EPG_DIR, "tivimate_*.sources.xml"))
    old += [os.path.join(EPG_DIR, n) for n in OLD_SOURCES_FILES]
    for path in old:
        if os.path.basename(path) != SOURCES_FILE and os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass
    # Drop channel files for servers that no longer exist.
    keep = set("tivimate_%s.channels.xml" % slug for _n, slug, _x in entries)
    for path in (glob.glob(os.path.join(EPG_DIR, "tivimate_*.channels.xml")) +
                 glob.glob(os.path.join(HDD_EPG_DIR, "tivimate_*.channels.xml"))):
        if os.path.basename(path) not in keep:
            try:
                os.remove(path)
            except OSError:
                pass
    return len(entries)


def start_export(sources=None):
    """Run the export in the background; never blocks the GUI.

    sources=None loads the saved server list inside the worker thread.
    """
    def work():
        if not _LOCK.acquire(blocking=False):
            return
        try:
            current = sources
            if current is None:
                from .core import get_sources
                current = get_sources()
            _log("export start: %d servers listed" % len(current or []))
            export_all(current)
        except Exception as error:
            _log("export failed: %s" % error)
        finally:
            _LOCK.release()
    threading.Thread(target=work, name="TiviMateEpgImportExport", daemon=True).start()
