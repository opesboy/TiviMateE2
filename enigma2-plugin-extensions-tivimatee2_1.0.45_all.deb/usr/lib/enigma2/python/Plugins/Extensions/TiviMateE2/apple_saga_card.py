# -*- coding: utf-8 -*-
"""Rounded Apple posters stored inside the SAME posters cache folder.

No extra subfolders are created. The original poster file stays unchanged;
this module builds one transparent rounded PNG beside it and reuses it.
"""
from __future__ import absolute_import
import hashlib
import os
import tempfile
import threading
try:
    from Queue import Queue
except ImportError:
    from queue import Queue

_SIZE = (190, 266)
_RADIUS = 12
_TASKS = Queue(30)
_STARTED = False
_LOCK = threading.Lock()
_INFLIGHT = {}
_PREFIX = 'poster_style_apple_v1_'

def _bytes(value):
    if isinstance(value, bytes):
        return value
    return value.encode('utf-8')

def _output(source):
    try:
        from .cache_manager import get_cache_dir
        stat = os.stat(source)
        if stat.st_size < 64:
            return ''
        stamp = u'apple-v1:%s:%d:%.6f:%dx%d:%d' % (
            os.path.realpath(source), stat.st_size, stat.st_mtime,
            _SIZE[0], _SIZE[1], _RADIUS)
        directory = get_cache_dir('posters')
        return os.path.join(directory, _PREFIX + hashlib.md5(_bytes(stamp)).hexdigest() + '.png')
    except Exception:
        return ''

def cached(source):
    target = _output(source)
    try:
        if target and os.path.isfile(target) and os.path.getsize(target) > 500:
            return target
    except (OSError, IOError):
        pass
    return ''

def _mask(width, height, radius):
    from PIL import Image, ImageDraw
    scale = 4
    w, h, r = width * scale, height * scale, radius * scale
    mask = Image.new('L', (w, h), 0)
    draw = ImageDraw.Draw(mask)
    draw.rectangle((r, 0, w-r-1, h-1), fill=255)
    draw.rectangle((0, r, w-1, h-r-1), fill=255)
    for x, y in ((0, 0), (w-2*r, 0), (0, h-2*r), (w-2*r, h-2*r)):
        draw.ellipse((x, y, x + 2*r - 1, y + 2*r - 1), fill=255)
    sample = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
    return mask.resize((_SIZE[0], _SIZE[1]), sample)

def prepare(source):
    hit = cached(source)
    if hit:
        return hit
    target = _output(source)
    if not target:
        return ''
    tmp = ''
    raw = None
    try:
        from .pil_compat import install_pil_compat
        if not install_pil_compat():
            return ''
        from PIL import Image
        raw = Image.open(source)
        w, h = raw.size
        if w < 24 or h < 24 or w * h > 24000000:
            return ''
        # Aspect-cover, matching the Apple poster card without letterboxing.
        scale = max(float(_SIZE[0]) / w, float(_SIZE[1]) / h)
        new_size = (max(_SIZE[0], int(round(w * scale))),
                    max(_SIZE[1], int(round(h * scale))))
        sampling = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
        content = raw.convert('RGB').resize(new_size, sampling)
        offx = (new_size[0] - _SIZE[0]) // 2
        offy = (new_size[1] - _SIZE[1]) // 2
        content = content.crop((offx, offy, offx + _SIZE[0], offy + _SIZE[1])).convert('RGBA')
        content.putalpha(_mask(_SIZE[0], _SIZE[1], _RADIUS))
        folder = os.path.dirname(target)
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except OSError:
                if not os.path.isdir(folder):
                    raise
        fd, tmp = tempfile.mkstemp(prefix='.apple_corner_', suffix='.png', dir=folder)
        os.close(fd)
        content.save(tmp, 'PNG')
        try:
            if not os.path.isfile(target):
                os.rename(tmp, target)
                tmp = ''
        except OSError:
            if not os.path.isfile(target):
                raise
        return target if os.path.isfile(target) else ''
    except Exception:
        return ''
    finally:
        try:
            if raw is not None:
                raw.close()
        except Exception:
            pass
        if tmp and os.path.isfile(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass

def _worker():
    while True:
        source = _TASKS.get()
        output = ''
        try:
            output = prepare(source)
        except Exception:
            output = ''
        finally:
            with _LOCK:
                callbacks = _INFLIGHT.pop(source, [])
            for notify in callbacks:
                try:
                    notify(output)
                except Exception:
                    pass
            _TASKS.task_done()

def enqueue(source, callback):
    global _STARTED
    with _LOCK:
        if source in _INFLIGHT:
            _INFLIGHT[source].append(callback)
            return True
        if not _STARTED:
            for i in range(2):
                worker = threading.Thread(target=_worker, name='TiviAppleCard%d' % i)
                worker.daemon = True
                worker.start()
            _STARTED = True
        _INFLIGHT[source] = [callback]
    try:
        _TASKS.put_nowait(source)
        return True
    except Exception:
        with _LOCK:
            _INFLIGHT.pop(source, None)
        return False
