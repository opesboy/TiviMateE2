# -*- coding: utf-8 -*-
"""Enabled-package scope for actor and movie-collection searches.

Shared by Python 3 and Python 2.7. This ONLY consults existing category/
stream caches; it does not alter artwork loading, cache layout, or UI.
"""
from __future__ import absolute_import

import hashlib

from .filters import (get_allowed_category_ids, get_cached_categories,
                      filter_categories, category_id_for_item,
                      is_adult_entry, adult_enabled, peek_category_streams_cache,
                      peek_filtered_streams_cache)

try:
    _text = unicode
except NameError:
    _text = str


def _to_text(value):
    if isinstance(value, bytes) and not isinstance(value, _text):
        return value.decode('utf-8', 'replace')
    return _text(value if value is not None else u'')


def scoped_result_key(cache, kind, source, identity, media_kind='vod'):
    """Change cached search results immediately when selected packages change."""
    allowed = get_allowed_category_ids(source, media_kind)
    selected = u'*' if allowed is None else u','.join(sorted(_to_text(x) for x in allowed))
    raw = u'v2|%s|%s|adult=%s' % (media_kind, selected,
                                  '1' if adult_enabled(source) else '0')
    signature = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:20]
    return cache.make_key(kind + '_filtered_v2', source, _to_text(identity) + u'|' + signature)


def enabled_package_ids(source, kind, preferred='', cache_only=False):
    """Ordered active IDs: explicit filter wins; never inject a disabled current package.

    Called from existing search workers, not the GUI thread. Category metadata
    is read from RAM/disk before any cold-cache server request.
    """
    allowed = get_allowed_category_ids(source, kind)
    if allowed is None and source.get('type') == 'xtream':
        # Complete Xtream catalog already cached: do not trigger category I/O.
        _rows, origin = peek_filtered_streams_cache(source, kind)
        if origin in ('ram-catalog', 'disk-catalog'):
            return []
    blocked_adult = set()
    try:
        categories, _origin = get_cached_categories(
            source, kind, wait_for_server=(allowed is None and not cache_only))
        if not adult_enabled(source):
            for cat in (categories or []):
                if isinstance(cat, dict) and is_adult_entry(cat):
                    blocked_adult.add(_to_text(cat.get('category_id') or cat.get('id') or
                                               cat.get('genre_id') or cat.get('group_id') or ''))
        categories = filter_categories(source, kind, categories or [])
    except Exception:
        categories = []
    names = {}
    order = []
    generic = set(('all', 'all movies', 'all films', 'all vod',
                   'كل الأفلام', 'جميع الأفلام', 'كل افلام', 'جميع افلام',
                   'كل المحتوى', 'recent added'))
    for cat in categories:
        if not isinstance(cat, dict):
            continue
        cid = _to_text(cat.get('category_id') or cat.get('id') or
                       cat.get('genre_id') or cat.get('group_id') or '').strip()
        name = _to_text(cat.get('category_name') or cat.get('name') or '').strip().lower()
        if not cid or cid == '__recent_added__' or name in generic:
            continue
        if allowed is not None and cid not in allowed:
            continue
        if cid not in names:
            names[cid] = name
            order.append(cid)
    # Explicit choices remain authoritative when the server's categories
    # metadata has not been downloaded yet.
    if allowed is not None:
        for cid in sorted(_to_text(x) for x in allowed):
            if cid not in order and cid not in blocked_adult and cid != '__recent_added__':
                order.append(cid)
    preferred = _to_text(preferred).strip()
    if preferred and preferred in order:
        order.remove(preferred)
        order.insert(0, preferred)
    elif preferred and allowed is None and preferred != '__recent_added__':
        order.insert(0, preferred)
    return order


def allowed_rows(source, kind, rows, package_id=None):
    """Exclude disabled and adult entries in EVERY search input, including RAM.

    Rows returned by a known enabled category may lack category_id on some
    Stalker portals; attach that verified category without changing the cache.
    Rows of unknown provenance cannot bypass an explicit package filter.
    """
    allowed = get_allowed_category_ids(source, kind)
    known = _to_text(package_id).strip()
    if allowed is not None and known and known not in allowed:
        return []
    result = []
    for entry in rows or []:
        if not isinstance(entry, dict):
            continue
        if not adult_enabled(source) and is_adult_entry(entry):
            continue
        cid = _to_text(entry.get('_source_category_id') or
                       entry.get('category_id') or entry.get('categoryId') or
                       entry.get('genre_id') or entry.get('group') or
                       entry.get('group-title') or '').strip()
        if not cid and not known:
            cid = _to_text(category_id_for_item(entry)).strip()
        if allowed is not None:
            if cid and cid not in allowed:
                continue
            if not cid and not (known and known in allowed):
                continue
        row = dict(entry)
        if known and not cid:
            row['_source_category_id'] = known
            row['category_id'] = known
        result.append(row)
    return result


def cached_package_rows(source, kind, ids, candidate_filter=None):
    """Return existing per-package RAM/disk contents and only the real misses."""
    hits, misses = [], []
    for cid in ids or []:
        rows, origin = peek_category_streams_cache(source, kind, cid)
        if origin == 'miss':
            misses.append(cid)
        else:
            if callable(candidate_filter):
                rows = (r for r in rows if candidate_filter(r))
            hits.extend(allowed_rows(source, kind, rows, cid))
    return hits, misses


