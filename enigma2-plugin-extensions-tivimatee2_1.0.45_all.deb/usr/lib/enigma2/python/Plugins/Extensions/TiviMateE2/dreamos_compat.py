# -*- coding: utf-8 -*-
"""DreamOS family detection shared by both interpreter builds.
Hardware alone does not identify DreamOS (a Dreambox may run OpenATV).
"""
import os
import re


def _read(root, path):
    try:
        with open(os.path.join(root, path.lstrip('/')), 'rb') as stream:
            return stream.read(8192).decode('utf-8', 'replace').lower()
    except (IOError, OSError):
        return ''


def is_dreamos(root='/'):
    def exists(path):
        return os.path.exists(os.path.join(root, path.lstrip('/')))
    if (exists('/etc/opendreambox') or
            exists('/usr/lib/enigma2/python/Components/DreamInfoHandler.py') or
            exists('/usr/lib/enigma2/python/Components/DreamInfoHandler.pyc') or
            exists('/usr/lib/enigma2/python/Components/DreamInfoHandler.pyo')):
        return True
    info = '\n'.join(_read(root, path) for path in
                     ('/etc/image-version', '/etc/os-release', '/etc/issue'))
    if re.search(r'\b(?:opendreambox|dreamos|dreambox[ -]+os|newnigma2|dream[ -]?elite|demonisat)\b', info):
        return True
    # These image names may be generic or add-ons; require corroboration.
    model = ' '.join(_read(root, path).strip() for path in
                     ('/proc/stb/info/model', '/proc/stb/info/boxtype', '/proc/stb/info/hwmodel'))
    dream_hardware = bool(re.search(r'\b(?:dm[0-9]+(?:uhd)?|dreambox[0-9]*|dreamone|dreamtwo|one|two)\b', model))
    if dream_hardware and exists('/usr/bin/dpkg'):
        if re.search(r'\b(?:merlin(?:[ -]?4)?|gemini(?:[ -]?gp4(?:\.2)?)?|gp4(?:\.2)?|titanium(?: edition)?|aio|oozoo[n]|oo[ -]zoo[ -]n|peter[ -]?pan|neverland|power[ -]?sat|sat[ -]?lodge|tdw|the dreambox world|open[ -]?ts|ts[ -]?image|dreamos[ -]?at)\b', info):
            return True
    return False
