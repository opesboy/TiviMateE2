# -*- coding: UTF-8 -*-
import os
import re
import requests
import time
from urllib.parse import quote_plus, unquote
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from ..utilities import languageTranslate, log, getFileSize
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

# Suppress insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from ..user_agents import get_random_ua
# Constants
HEADERS = {
    'User-Agent': get_random_ua(),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'text/html; charset=UTF-8',
    'Host': 'archive.org',
    'Referer': 'https://archive.org',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
    'Accept-Encoding': 'gzip, deflate'
}

SESSION = requests.Session()
MAIN_URL = "https://archive.org"
DEBUG_PRETEXT = "archive.org"
CACHE_DIR = "/var/volatile/tmp"
CACHE_FILE = os.path.join(CACHE_DIR, "archive_org_mora25r.html")
CACHE_TIMEOUT = 86400  # 24 hours in seconds

def get_url(url, referer=None):
    headers = {'User-Agent': HEADERS['User-Agent']}
    if referer:
        headers['Referer'] = referer
    
    response = SESSION.get(url, headers=headers, verify=False, timeout=10)
    return response.text.replace('\n', '')

def get_rating(downloads):
    return min(10, max(1, downloads // 50 + 1))

ROMAN_NUMERAL_MAP = [
    (r'\bII\b', '2'), (r'\bIII\b', '3'), (r'\bIV\b', '4'), (r'\bV\b', '5'),
    (r'\bVI\b', '6'), (r'\bVII\b', '7'), (r'\bVIII\b', '8'), (r'\bIX\b', '9'),
    (r'\bX\b', '10'), (r'\bXI\b', '11'), (r'\bXII\b', '12'), (r'\bXIII\b', '13'),
    (r'\bXIV\b', '14'), (r'\bXV\b', '15'), (r'\bXVI\b', '16'), (r'\bXVII\b', '17'),
    (r'\bXVIII\b', '18'), (r'\bXIX\b', '19'), (r'\bXX\b', '20'), (r'\bI\b', '1')
]

def generate_title_variations(text):
    """
    Generate variations of a title with both Roman numerals and digits
    """
    variations = [text]
    
    # Convert Roman numerals to digits
    digit_version = text
    for roman, digit in ROMAN_NUMERAL_MAP:
        digit_version = re.sub(roman, digit, digit_version, flags=re.IGNORECASE)
    if digit_version != text:
        variations.append(digit_version)
    
    # Convert digits to Roman numerals (reverse mapping)
    for roman, digit in ROMAN_NUMERAL_MAP:
        roman_version = re.sub(r'\b' + digit + r'\b', roman, text, flags=re.IGNORECASE)
        if roman_version != text and roman_version not in variations:
            variations.append(roman_version)
    
    return variations

def get_cached_content():
    # Subtitle archive lists must be queried afresh; never use stale HTML.
    return None


def save_content_to_cache(content):
    # Intentionally disabled: no persistent subtitle HTTP/HTML index cache.
    return None



def search_subtitles(file_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    # Check if title is blank or empty
    if not title or title.strip() == "":
        log(__name__, f"{DEBUG_PRETEXT} Title is blank, skipping search")
        return subtitles_list, "", msg

    title = re.sub(r' ▎', '▎', title)

    # Define bad strings to remove
    bad_strings = [
                "ae|", "al|", "ar|", "at|", "ba|", "be|", "bg|", "br|", "cg|", "ch|", "cz|", "da|", "de|", "dk|",
                "ee|", "en|", "es|", "eu|", "ex-yu|", "fi|", "fr|", "gr|", "hr|", "hu|", "in|", "ir|", "it|", "lt|",
                "mk|", "mx|", "nl|", "no|", "pl|", "pt|", "ro|", "rs|", "ru|", "se|", "si|", "sk|", "sp|", "tr|",
                "uk|", "us|", "yu|","ae▎", "al▎", "ar▎", "at▎", "ba▎", "be▎", "bg▎", "br▎", "cg▎", "ch▎", "cz▎", "da▎", "de▎", "dk▎",
                "ee▎", "en▎", "es▎", "eu▎", "ex-yu▎", "fi▎", "fr▎", "gr▎", "hr▎", "hu▎", "in▎", "ir▎", "it▎", "lt▎",
                "mk▎", "mx▎", "nl▎", "no▎", "pl▎", "pt▎", "ro▎", "rs▎", "ru▎", "se▎", "si▎", "sk▎", "sp▎", "tr▎",
                "uk▎", "us▎", "yu▎"
                "1080p", "4k", "720p", "hdrip", "hindi", "imdb", "vod", "x264"
            ]
    
    # Remove bad strings from title
    for bad in bad_strings:
        title = title.replace(bad, "")
    
    title = re.sub(r'[:,"&!?\-]', '', title).replace("  ", " ").strip()
    title = re.sub(r"'", '', title)
    title_variations = generate_title_variations(title)
    print(f"Title variations: {title_variations}")  # Debug print


    
    if tvshow:
        search_string = f"{tvshow} S{int(season):02d}E{int(episode):02d}" if title != tvshow else f"{tvshow} ({int(season):02d}{int(episode):02d})"
    else:
        search_string = f"{title} ({year})" if year else title
    
    log(__name__, f"{DEBUG_PRETEXT} Search string = {search_string}")
    # Modify get_subtitles_list to accept multiple titles
    for title_var in title_variations:
        get_subtitles_list(title_var, search_string, "ar", "Arabic", subtitles_list)
    return subtitles_list, "", msg

def get_subtitles_list(title, search_string, lang_short, lang_long, subtitles_list):
    url = f"{MAIN_URL}/download/mora25r"
    
    # Try to get content from cache first
    content = get_cached_content()
    
    if content is None:
        # Content not in cache or cache expired, download it
        log(__name__, f"{DEBUG_PRETEXT} Fetching: {url}")
        try:
            response = SESSION.get(url, headers=HEADERS, verify=False, timeout=10)
            response.raise_for_status()
            content = response.text
            save_content_to_cache(content)
        except requests.RequestException as e:
            log(__name__, f"{DEBUG_PRETEXT} Failed to fetch subtitles: {e}")
            return
    else:
        log(__name__, f"{DEBUG_PRETEXT} Using cached content from {CACHE_FILE}")
    
    try:
        encoded_title = quote_plus(title).replace('+', '.')
        subtitles = re.findall(rf'(<td><a href.+?>{encoded_title}.+?</a></td>)', content, re.IGNORECASE)
        
        for subtitle in subtitles:
            match = re.search(r'<td><a href="(.+?)">(.+?)</a></td>', subtitle)
            if match:
                id_, filename = match.groups()
                filename = filename.replace('.srt', '').strip()
                if filename not in ['Εργαστήρι Υποτίτλων', 'subs4series']:
                    log(__name__, f"{DEBUG_PRETEXT} Found subtitle: {filename} (id = {id_})")
                    subtitles_list.append({
                        'no_files': 1,
                        'filename': filename,
                        'sync': False,  # Archive provides no verified timing sync
                        '_tivimate_sync_unverified': True,
                        '_tivimate_language_unverified': True,
                        'id': id_,
                        'language_flag': '',  # Do not claim Arabic from archive category alone
                        'language_name': lang_long
                    })
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error parsing subtitles: {e}")

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_info = subtitles_list[pos]
    language = subtitle_info["language_name"]
    subtitle_id = subtitle_info["id"]    
    print(("subtitle_id", subtitle_id))
    download_link = f"{MAIN_URL}/download/mora25r/{subtitle_id}"
    print(download_link)
    log(__name__, f"{DEBUG_PRETEXT} Downloading from: {download_link}")

    try:
        response = SESSION.get(download_link, headers=HEADERS, verify=False, allow_redirects=True, timeout=15)
        response.raise_for_status()
    except requests.RequestException as e:
        log(__name__, f"{DEBUG_PRETEXT} Download failed: {e}")
        return False, language, None

    os.makedirs(tmp_sub_dir, exist_ok=True)
    local_tmp_file = os.path.join(tmp_sub_dir, subtitle_id)
    try:
        with open(local_tmp_file, "wb") as file:
            file.write(response.content)
        log(__name__, f"{DEBUG_PRETEXT} Subtitles saved to: {local_tmp_file}")
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error saving subtitle: {e}")
        return False, language, None

    packed = False
    subs_file = local_tmp_file
    try:
        with open(local_tmp_file, "rb") as file:
            file_header = file.read(2).decode(errors="ignore")
            if file_header.startswith("R"):
                packed = True
                subs_file = "rar"
            elif file_header.startswith("PK"):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error checking file type: {e}")
    
    log(__name__, f"{DEBUG_PRETEXT} Returning: packed={packed}, language={language}, subs_file={subs_file}")
    return packed, language, subs_file