# -*- coding: utf-8 -*-
"""Bounded local diagnostic for the Python 3 subtitle pipeline.
Only caller-supplied stage names and non-sensitive metadata are recorded.
"""
import os
import time
import stat
import sys

LOG = '/tmp/tivimate_subtitle.log'
LIMIT = 128 * 1024

def trace(stage, **fields):
    fd = None
    try:
        flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | getattr(os, 'O_NOFOLLOW', 0) | getattr(os, 'O_NONBLOCK', 0)
        fd = os.open(LOG, flags, 0o600)
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            return
        if info.st_size > LIMIT:
            os.ftruncate(fd, 0)
        safe = []
        for key, value in sorted(fields.items()):
            # Values must be numeric, booleans or controlled identifiers.
            value = str(value)[:100]
            value = ''.join(c if c.isalnum() or c in '._-:+' else '_' for c in value)
            safe.append('%s=%s' % (key, value))
        line = '%s pid=%d %s %s\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), os.getpid(), stage, ' '.join(safe))
        os.write(fd, line.encode('utf-8', 'replace'))
    except Exception:
        pass
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass

def file_info(path):
    result = {'exists': False, 'bytes': -1, 'kind': 'missing', 'ext': 'unknown'}
    try:
        if not path or not os.path.isfile(path):
            return result
        result['exists'] = True
        result['bytes'] = os.path.getsize(path)
        ext = os.path.splitext(path)[1].lower().lstrip('.')
        result['ext'] = ext if ext in ('srt', 'ass', 'ssa', 'sub', 'vtt', 'zip', 'rar', 'gz', 'txt') else 'other'
        with open(path, 'rb') as f:
            sample = f.read(8192)
        lower = sample.lstrip().lower()
        result['kind'] = ('empty' if not sample else 'zip' if sample.startswith(b'PK\x03\x04') else 'rar' if sample.startswith(b'Rar!') else 'gzip' if sample.startswith(b'\x1f\x8b') else 'html' if lower.startswith((b'<!doctype html', b'<html', b'<head')) else 'timed-text' if b'-->' in sample else 'other')
    except Exception as exc:
        result['kind'] = type(exc).__name__
    return result
