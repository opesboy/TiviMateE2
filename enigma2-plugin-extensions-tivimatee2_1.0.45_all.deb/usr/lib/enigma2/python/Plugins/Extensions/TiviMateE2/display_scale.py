# -*- coding: utf-8 -*-
"""Runtime screen-profile helper for TiviMate E2.

The plugin artwork was authored on a 1920x1080 design canvas.  Enigma2 can
create screens on larger desktops, but coordinates passed later through
``ePoint`` are physical pixels.  This module keeps the XML skin and those
runtime movements in the same coordinate system.
"""

import re
import os

BASE_WIDTH = 1920
BASE_HEIGHT = 1080
HD_WIDTH = 1280
HD_HEIGHT = 720
WQHD_WIDTH = 2560
WQHD_HEIGHT = 1440
PROFILE_FILE = "/etc/enigma2/tivimatee2_display_profile"


def load_profile_preference():
    """Return the UI profile: WQHD follows a WQHD skin automatically."""
    try:
        if is_wqhd_desktop():
            return "wqhd"
    except Exception:
        pass
    try:
        with open(PROFILE_FILE, "r") as handle:
            value = str(handle.read() or "").strip().lower()
        if value == "wqhd":
            return "wqhd"
    except Exception:
        pass
    return "fhd"


def save_profile_preference(value):
    """Persist only the explicit FHD/WQHD UI choice."""
    value = "wqhd" if str(value or "").strip().lower() == "wqhd" else "fhd"
    try:
        parent = os.path.dirname(PROFILE_FILE)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        with open(PROFILE_FILE, "w") as handle:
            handle.write(value + "\n")
        return True
    except Exception:
        return False

_PAIR_RE = re.compile(r'\b(position|size)\s*=\s*"\s*(-?\d+)\s*,\s*(-?\d+)\s*"')
_FONT_RE = re.compile(r'\bfont\s*=\s*"([^";]+);(\d+)"')
_BORDER_RE = re.compile(r'\bborderWidth\s*=\s*"(\d+)"')
_ITEM_HEIGHT_RE = re.compile(r'\bitemHeight\s*=\s*"(\d+)"')


def _round_pixel(value):
    """Round a coordinate predictably on Python 3."""
    value = float(value)
    if value >= 0:
        return int(value + 0.5)
    return int(value - 0.5)


_DESKTOP_MEMO = []


def desktop_size():
    """Return the active Enigma2 desktop dimensions, or the FHD baseline."""
    if _DESKTOP_MEMO:
        return _DESKTOP_MEMO[0]
    try:
        from enigma import getDesktop
        size = getDesktop(0).size()
        width = int(size.width())
        height = int(size.height())
        if width > 0 and height > 0:
            _DESKTOP_MEMO.append((width, height))
            return width, height
    except Exception:
        pass
    return BASE_WIDTH, BASE_HEIGHT


def _is_16_by_9(width, height):
    try:
        return abs((float(width) / float(height)) - (16.0 / 9.0)) < 0.04
    except Exception:
        return False


def scale_factors():
    """Scale factor from the FHD design canvas to the active GUI desktop.

    1920x1080 desktops are untouched. Any other GUI desktop is scaled:
    1280x720 (HD skins), 2560x1440 (WQHD) and 3840x2160 (UHD/4K skins).
    Before, only HD and WQHD were recognised, so on a 4K skin every page was
    drawn at 1920x1080 in the top-left quarter of the screen.  This is the
    Enigma2 GUI desktop, never the HDMI video mode.
    """
    width, height = desktop_size()
    if abs(width - BASE_WIDTH) <= 16 and abs(height - BASE_HEIGHT) <= 16:
        return 1.0, 1.0
    if width < 640 or height < 360:
        return 1.0, 1.0
    if is_wqhd_desktop(width, height):
        return float(WQHD_WIDTH) / BASE_WIDTH, float(WQHD_HEIGHT) / BASE_HEIGHT
    return float(width) / BASE_WIDTH, float(height) / BASE_HEIGHT


def is_wqhd_desktop(width=None, height=None):
    """True on a 2560x1440-class Enigma2 GUI desktop (WQHD skin active)."""
    if width is None or height is None:
        width, height = desktop_size()
    return (abs(width - WQHD_WIDTH) <= 32 and abs(height - WQHD_HEIGHT) <= 32
            and _is_16_by_9(width, height))


def profile_name():
    """Return the visible profile label used for diagnostics."""
    factor_x, factor_y = scale_factors()
    if factor_x < 1.0 and factor_y < 1.0:
        return "HD"
    return "WQHD" if factor_x > 1.0 and factor_y > 1.0 else "FHD"


def sx(value):
    """Scale an FHD horizontal coordinate to the active desktop."""
    return _round_pixel(float(value) * scale_factors()[0])


def sy(value):
    """Scale an FHD vertical coordinate to the active desktop."""
    return _round_pixel(float(value) * scale_factors()[1])


def scale_size(width, height):
    """Scale a width/height pair for image decoding or widget movement."""
    return sx(width), sy(height)


_PIXMAP_TAG_RE = re.compile(r'<(widget|ePixmap)\b([^>]*?)(/?)>')


def _scale_artwork(xml):
    """On a resized desktop every FHD image must be scaled to its (already
    resized) widget; otherwise it is drawn at its 1920-canvas size. Applies
    to pixmap widgets only (labels/video untouched)."""
    def fix(match):
        attrs = match.group(2)
        if ('scale=' in attrs or 'render=' in attrs or 'backgroundPixmap=' in attrs or
                re.search(r'name="(?:ramBar|cpuBar|storageBar)"', attrs) or
                ('pixmap=' not in attrs and 'alphatest=' not in attrs)):
            return match.group(0)
        return '<%s%s scale="1"%s>' % (match.group(1), attrs.rstrip(), match.group(3))
    try:
        return _PIXMAP_TAG_RE.sub(fix, xml)
    except Exception:
        return xml


_SCALED_MARK = '<!--tm-scaled-->'


def _mark_scaled(xml):
    """Tag a scaled skin so it can never be enlarged a second time."""
    match = re.search(r'<screen\b[^>]*?(/?)>', xml)
    if not match or match.group(1):
        return xml
    return xml[:match.end()] + _SCALED_MARK + xml[match.end():]


def scale_skin(xml):
    """Create a native-size skin string for the active FHD/WQHD desktop.

    Only explicit numerical layout attributes are transformed.  Values such
    as ``center,center`` and file names are left untouched, so dialog layouts
    and packaged artwork paths stay compatible with old Enigma2 images.
    """
    factor_x, factor_y = scale_factors()
    if factor_x == 1.0 and factor_y == 1.0:
        return xml
    if _SCALED_MARK in xml:
        return xml

    def replace_pair(match):
        return '%s="%d,%d"' % (
            match.group(1),
            _round_pixel(int(match.group(2)) * factor_x),
            _round_pixel(int(match.group(3)) * factor_y)
        )

    def replace_font(match):
        # Font parsing does not automatically follow an ePoint move.  Keep
        # it proportionate to the native-size position/size attributes.
        font_scale = min(factor_x, factor_y)
        return 'font="%s;%d"' % (
            match.group(1),
            max(1, _round_pixel(int(match.group(2)) * font_scale))
        )

    def replace_border(match):
        border_scale = min(factor_x, factor_y)
        return 'borderWidth="%d"' % max(1, _round_pixel(int(match.group(1)) * border_scale))

    def replace_item_height(match):
        return 'itemHeight="%d"' % max(1, _round_pixel(int(match.group(1)) * factor_y))

    xml = _PAIR_RE.sub(replace_pair, xml)
    xml = _FONT_RE.sub(replace_font, xml)
    xml = _BORDER_RE.sub(replace_border, xml)
    xml = _ITEM_HEIGHT_RE.sub(replace_item_height, xml)
    return _mark_scaled(_scale_artwork(xml))


