# -*- coding: utf-8 -*-
"""Rounded GENRE/Cinematic poster variants stored inside the SAME posters cache.

- Never downloads artwork.
- Never creates extra cache folders.
- Writes derived PNGs beside the original poster files in posters/.
- Keeps the original cached poster untouched.
"""
from __future__ import absolute_import
import hashlib
import os
import tempfile
import threading
try:
    from Queue import Queue
except ImportError:
    from queue import Queue

_QUEUE = Queue(48)
_LOCK = threading.Lock()
_PENDING = {}
_STARTED = [False]
_SIZES = ((170,205), (177,214), (232,348), (165,248))
_PREFIX = 'poster_style_saga_v1_'

def _bytes(value):
    if isinstance(value, bytes):
        return value
    return value.encode('utf-8')

def _key(source, size):
    try:
        st = os.stat(source)
        if st.st_size < 100:
            return ''
        w, h = [int(x) for x in size]
        if (w, h) not in _SIZES:
            return ''
        from .cache_manager import get_cache_dir
        folder = get_cache_dir('posters')
        raw = u'saga-v1|%s|%d|%0.6f|%d|%d' % (
            os.path.realpath(source), st.st_size, st.st_mtime, w, h)
        return os.path.join(folder, _PREFIX + hashlib.md5(_bytes(raw)).hexdigest() + '.png')
    except Exception:
        return ''


def cached(source, size):
    path = _key(source, size)
    try:
        if path and os.path.isfile(path) and os.path.getsize(path) > 300:
            return path
    except Exception:
        pass
    return ''

def _mask(width, height, radius):
    from PIL import Image, ImageDraw
    z = 4
    w, h, r = width * z, height * z, radius * z
    alpha = Image.new('L', (w, h), 0)
    draw = ImageDraw.Draw(alpha)
    draw.rectangle((r, 0, w-r-1, h-1), fill=255)
    draw.rectangle((0, r, w-1, h-r-1), fill=255)
    for x, y in ((0, 0), (w-2*r, 0), (0, h-2*r), (w-2*r, h-2*r)):
        draw.ellipse((x, y, x + 2*r - 1, y + 2*r - 1), fill=255)
    filt = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
    return alpha.resize((width, height), filt)

def prepare(source, size):
    cached_path = cached(source, size)
    if cached_path:
        return cached_path
    path = _key(source, size)
    if not path:
        return ''
    temp = ''
    try:
        from .pil_compat import install_pil_compat
        if not install_pil_compat():
            return ''
        from PIL import Image
        w, h = [int(x) for x in size]
        raw = Image.open(source)
        try:
            orig_w, orig_h = raw.size
            if orig_w < 25 or orig_h < 25 or orig_w * orig_h > 25000000:
                return ''
            filt = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', 3))
            # Match existing page-specific sizes exactly; only the corners change.
            card = raw.convert('RGB').resize((w, h), filt).convert('RGBA')
        finally:
            try:
                raw.close()
            except Exception:
                pass
        card.putalpha(_mask(w, h, max(9, min(17, int(round(w * 0.07))))))
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except OSError:
                if not os.path.isdir(folder):
                    raise
        fd, temp = tempfile.mkstemp(prefix='.rounded_', suffix='.png', dir=folder)
        os.close(fd)
        card.save(temp, 'PNG')
        try:
            if not os.path.exists(path):
                os.rename(temp, path)
                temp = ''
        except OSError:
            if not os.path.isfile(path):
                raise
        return path if os.path.isfile(path) else ''
    except Exception:
        return ''
    finally:
        if temp and os.path.isfile(temp):
            try:
                os.unlink(temp)
            except Exception:
                pass

def _worker():
    while True:
        source, size, key = _QUEUE.get()
        result = ''
        try:
            result = prepare(source, size)
        except Exception:
            pass
        with _LOCK:
            replies = _PENDING.pop(key, [])
        for callback in replies:
            try:
                callback(result)
            except Exception:
                pass
        _QUEUE.task_done()

def enqueue(source, size, callback):
    key = (source, tuple(size))
    with _LOCK:
        if key in _PENDING:
            _PENDING[key].append(callback)
            return True
        if not _STARTED[0]:
            for n in range(2):
                t = threading.Thread(target=_worker, name='SagaCardEdges%d' % n)
                t.daemon = True
                t.start()
            _STARTED[0] = True
        _PENDING[key] = [callback]
    try:
        _QUEUE.put_nowait((source, tuple(size), key))
        return True
    except Exception:
        with _LOCK:
            _PENDING.pop(key, None)
        return False
