# -*- coding: utf-8 -*-
"""Persistent Current / Cinematic layouts for Movies and TV Shows.

Movies and TV Shows save independent preferences, including on first use.
All entry points use one resolver, preserving GENRE and cache behaviour.
"""
import json
import os

# PAGE DESIGN choices 01-08 (05-08 open the screens in page_layout_screens.py).
PAGE_LAYOUTS = ('new', 'current', 'grid24', 'apple', 'royal', 'circles', 'posters', 'genre')

FILE = '/etc/enigma2/tivimatee2/movies_page_design.json'
SERIES_FILE = '/etc/enigma2/tivimatee2/series_page_design.json'


def _layout_from(path, fallback=None):
    try:
        with open(path, 'r') as fd:
            choice = json.load(fd).get('layout')
        if choice in PAGE_LAYOUTS:
            return choice
    except (OSError, TypeError, ValueError, AttributeError):
        pass
    return fallback


def get_movies_layout():
    return _layout_from(FILE, 'apple')


def get_content_layout(kind='vod'):
    # Independent from the very first launch: an unset TV preference must NOT
    # inherit the latest Movies selection, otherwise changing Movies changes TV.
    return _layout_from(SERIES_FILE, 'apple') if kind == 'series' else get_movies_layout()


def _write_layout(path, choice):
    if choice not in PAGE_LAYOUTS:
        return False
    tmp = path + '.tmp'
    try:
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        with open(tmp, 'w') as fd:
            json.dump({'layout': choice}, fd)
        os.replace(tmp, path)
        return True
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        return False


def save_movies_layout(choice):
    return _write_layout(FILE, choice)


def save_content_layout(kind, choice):
    if kind == 'vod':
        return save_movies_layout(choice)
    if kind == 'series':
        return _write_layout(SERIES_FILE, choice)
    return False


def configured_movies_screen(original_class, kind='vod'):
    if kind in ('vod', 'series') and get_content_layout(kind) in ('royal', 'circles', 'posters', 'genre'):
        try:
            from .page_layout_screens import screen_for
            screen = screen_for(get_content_layout(kind))
            if screen is not None:
                return screen
        except Exception:
            pass
    if kind in ('vod', 'series') and get_content_layout(kind) == 'apple':
        from .apple_movies_layout import AppleMoviesScreen, AppleSeriesScreen
        from .page_layout_screens import root_page_screen
        return root_page_screen(AppleSeriesScreen if kind == 'series' else AppleMoviesScreen)
    if kind in ('vod', 'series') and get_content_layout(kind) == 'new':
        from .movies_new_layout import NewMoviesContentScreen
        return NewMoviesContentScreen
    if kind in ('vod', 'series') and get_content_layout(kind) == 'grid24':
        from .cinematic_catalog import CinematicCatalogScreen
        from .page_layout_screens import root_page_screen
        return root_page_screen(CinematicCatalogScreen)
    return original_class
