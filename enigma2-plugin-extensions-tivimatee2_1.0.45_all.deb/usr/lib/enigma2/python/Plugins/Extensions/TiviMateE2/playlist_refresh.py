# -*- coding: utf-8 -*-
"""Manual, source-scoped catalogue refresh and replay navigation helpers."""
import os
import threading
import time
import uuid

try:
    text_type = unicode
except NameError:
    text_type = str


def _text(value):
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return text_type(value or '')


def replay_category(row):
    return _text(row.get('category_id') or row.get('genre_id') or '')


def replay_groups(rows, categories):
    present = set(replay_category(row) for row in (rows or []))
    groups = []
    seen = set()
    for row in categories or []:
        cid = _text(row.get('category_id'))
        if cid in present and cid not in seen:
            groups.append((cid, _text(row.get('category_name') or cid)))
            seen.add(cid)
    for cid in sorted(present - seen):
        groups.append((cid, cid or 'Other'))
    return groups


def replay_sort(rows, groups):
    order = dict((cid, pos) for pos, (cid, name) in enumerate(groups))
    return sorted(rows or [], key=lambda row: (order.get(replay_category(row), len(order)),
                  _text(row.get('name') or row.get('title')).lower()))


def replay_filter(rows, group=None, query=''):
    q = _text(query).strip().lower()
    return [row for row in (rows or []) if (group is None or replay_category(row) == group)
            and (not q or q in _text(row.get('name') or row.get('title')).lower())]


def replay_choices(rows, groups):
    counts = {}
    for row in rows or []:
        cid = replay_category(row)
        counts[cid] = counts.get(cid, 0) + 1
    return [(u'%s (%d)' % (name, counts[cid]), cid) for cid, name in groups if counts.get(cid)]


_LOCK = threading.RLock()
_BUSY = set()


def _remove(path):
    if path and os.path.isfile(path):
        os.remove(path)


def _invalidate_kind(source, kind, categories):
    from . import filters as f
    from . import core
    # Identify old and new package IDs without scanning or removing other sources.
    old, _age = f._load_cache_state(f._categories_cache_path(source, kind))
    source_key = f.source_filter_key(source)
    category_key = '%s|categories|%s' % (source_key, kind)
    memory = f._RAM_CATEGORY_CACHE.get(category_key)
    ids = set(_text(row.get('category_id')) for row in list(old or []) + list(categories or []) + list(memory[0] if memory else []))
    prefix = '%s|%s|' % (source_key, kind)
    for mapping in (f._RAM_STREAM_CACHE, f._RAM_STREAM_TIMES, f._STALKER_LIVE_RAM,
                    f._STALKER_LIVE_TIMES, f._EMPTY_XTREAM_UNTIL):
        for key in list(mapping):
            if key.startswith(prefix):
                ids.add(key[len(prefix):])
                mapping.pop(key, None)
    for cid in ids:
        _remove(f._cache_path(source, kind, cid))
    catalog_key = f._catalog_key(source, kind)
    f._RAM_CATALOG_CACHE.pop(catalog_key, None)
    _remove(f._catalog_cache_path(source, kind))
    f._RAM_CATEGORY_CACHE.pop(category_key, None)
    for key in (category_key, '%s|%s' % (source_key, kind)):
        f._CATEGORIES_RETRY_AT.pop(key, None)
    f._save_cache(f._categories_cache_path(source, kind), categories)
    f._RAM_CATEGORY_CACHE[category_key] = (list(categories), time.time())
    with core._CATALOG_LOCK:
        core._CATALOG_MEMORY.pop(core._catalog_key(source, kind), None)
    _remove(core._catalog_path(source, kind))


def _invalidate_home(source, kinds):
    from . import content_home as h
    for kind in kinds:
        _remove(h._content_landing_cache_path(source, kind))
    # Only this provider's home feed selections; image files and match caches remain.
    suffix = h._home_feed_cache_key('manual_refresh', source).split('|', 1)[1]
    with h._HOME_FEED_CACHE_LOCK:
        data = h._home_feed_cache_load()
        for key in list(data):
            if '|' in key and key.split('|', 1)[1] == suffix:
                data.pop(key, None)
        h._home_feed_cache_save(data)


def refresh_playlist(source):
    from . import core
    from . import filters as f
    source = dict(source or {})
    mode = source.get('type')
    if mode not in ('xtream', 'stalker', 'm3u', 'fg'):
        raise ValueError('Unsupported playlist type')
    client = core.get_source_client(source)
    if mode in ('m3u', 'fg'):
        with client._parsed_lock:
            client._parsed_entries.pop(client._cache_identity(), None)
        rows = list(client.entries() or [])
        if not rows:
            raise ValueError('Provider returned no playlist entries')
        core._catalog_put(core._catalog_key(source, 'live'), core._catalog_path(source, 'live'), rows)
        _invalidate_home(source, ('live', 'vod', 'series'))
        return {'playlist': len(rows)}, []

    kinds = ('live', 'vod', 'series')
    refreshed = {}
    failures = []
    if mode == 'stalker':
        # Force provider-side cache generation plus legacy local catalogue generation.
        # The latter is committed only once a usable response exists.
        ultra = getattr(client, '_ultra_client', None)
        if ultra is not None:
            ultra.refresh_content()
        generation = uuid.uuid4().hex
        client._manual_catalog_generation = generation
    for kind in kinds:
        try:
            rows = [row for row in (client.categories(kind) or []) if isinstance(row, dict) and row.get('category_id') is not None]
            if not rows:
                failures.append(kind)
                continue
            refreshed[kind] = rows
        except Exception:
            failures.append(kind)
    if not refreshed:
        raise ValueError('Provider returned no usable categories')
    if mode == 'stalker':
        key = core.stable_cache_key('stalker:manual_catalog_generation', client.configured_portal, client.mac)
        if not core.persistent_cache_set(key, 'stalker:manual_catalog_generation', generation, 315360000):
            raise IOError('Unable to save catalogue refresh state')
    for kind, rows in refreshed.items():
        _invalidate_kind(source, kind, rows)
    _invalidate_home(source, tuple(refreshed))
    return dict((kind, len(rows)) for kind, rows in refreshed.items()), failures


def open_refresh_dialog(session, source):
    # The progress dialog owns its timer. Network and disk operations never run on the GUI thread.
    from Screens.MessageBox import MessageBox
    from enigma import eTimer
    from .ui import _connect_timer
    from .i18n import tr_text as tr
    from .filters import source_filter_key
    source = dict(source or {})
    key = source_filter_key(source)
    with _LOCK:
        if key in _BUSY:
            session.open(MessageBox, tr('Playlist refresh is already running.'), MessageBox.TYPE_INFO)
            return
        _BUSY.add(key)
    state = {'result': None}
    try:
        dialog = session.open(MessageBox, tr('Refreshing playlist...'), MessageBox.TYPE_INFO)
        timer = eTimer()
        # Keep a reference for receiver images that do not retain local timer objects.
        dialog._manualPlaylistRefreshTimer = timer
        def poll():
            result = state['result']
            if result is None:
                timer.start(300, True)
                return
            timer.stop()
            ok, counts, failures = result
            if ok:
                labels = {'live': 'Live', 'vod': 'Movies', 'series': 'TV Shows', 'playlist': 'Playlist'}
                details = u'\n'.join(u'%s: %d' % (tr(labels[k]), counts[k]) for k in ('live', 'vod', 'series', 'playlist') if k in counts)
                message = tr('Playlist refreshed.') + u'\n' + details
                if failures:
                    message += u'\n' + tr('Not refreshed:') + u' ' + u', '.join(tr(labels[k]) for k in failures)
                if source.get('type') in ('xtream', 'stalker'):
                    message += u'\n' + tr('Reopen packages to load updated content.')
            else:
                message = tr('Playlist refresh failed. Check the provider and try again.')
            dialog['text'].setText(message)
        _connect_timer(timer, poll)
        dialog.onClose.append(timer.stop)
        def worker():
            try:
                counts, failures = refresh_playlist(source)
                state['result'] = (True, counts, failures)
            except Exception:
                state['result'] = (False, {}, [])
            finally:
                with _LOCK:
                    _BUSY.discard(key)
        thread = threading.Thread(target=worker, name='TiviMateManualPlaylistRefresh')
        thread.daemon = True
        thread.start()
        timer.start(300, True)
    except Exception:
        with _LOCK:
            _BUSY.discard(key)
        raise
