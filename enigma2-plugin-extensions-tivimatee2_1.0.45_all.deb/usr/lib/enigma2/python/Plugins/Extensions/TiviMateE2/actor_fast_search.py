# -*- coding: utf-8 -*-
"""Nonblocking, enabled-package-only filmography for actor Spotlight.

The screen opens before any TMDb or provider I/O. This worker runs only after
onLayoutFinish and emits cached/provider snapshots to its GUI timer. Image
queues and existing shared provider cache policies are intentionally untouched.
Compatible with Enigma2 Python 2.7 and 3.x.
"""
from __future__ import absolute_import

from .actor_match import ActorCredits, _row_tmdb_id
from .search_package_scope import (scoped_result_key, enabled_package_ids,
                                   cached_package_rows, allowed_rows)
from .filters import (get_allowed_category_ids, peek_filtered_streams_cache,
                      get_category_streams_batch, get_filtered_streams)
from .core import get_source_client
from . import search_result_cache

try:
    _text = unicode
except NameError:
    _text = str

def _safe_text(value):
    if isinstance(value, bytes) and not isinstance(value, _text):
        return value.decode('utf-8', 'replace')
    return _text(value if value is not None else u'')


def actor_lookup(source, kind, person_id, category_id='', context_rows=None,
                 server_rows=None, exclude_stream='', exclude_tmdb=''):
    """Build a screen-owned lookup(emit, cancelled) function (no network yet)."""
    source = dict(source or {})
    kind = 'series' if kind == 'series' else 'vod'
    person_id = str(person_id or '').strip()
    category_id = str(category_id or '').strip()
    # Do not copy potentially huge page catalogs on the GUI thread.
    context_rows = context_rows or ()
    server_rows = server_rows or ()
    exclude_stream = str(exclude_stream or '').strip()
    exclude_tmdb = str(exclude_tmdb or '').strip()

    def lookup(emit, cancelled):
        if cancelled():
            return
        key = scoped_result_key(search_result_cache, 'actor_' + kind,
                                source, person_id, media_kind=kind)
        cached = search_result_cache.get(key)
        if isinstance(cached, dict) and cached.get('complete'):
            rows = allowed_rows(source, kind, cached.get('rows') or [])
            emit(rows, True)
            return

        # Credits first: match exact TMDb ids and language-aware film titles.
        # On an uncached TMDb response this can take 15s, hence the open-first UI.
        credits = ActorCredits(person_id, kind)
        if cancelled():
            return
        if not credits.ok:
            emit([], 'error')  # Network failure is not a verified empty search.
            return

        matches, seen = [], set()
        last_sent = [None]
        def collect(rows, cid=''):
            changed = False
            for raw in allowed_rows(source, kind, rows, cid):
                if cancelled():
                    return changed
                if not credits.matches(raw):
                    continue
                sid = str(raw.get('stream_id') or raw.get('vod_id') or
                          raw.get('series_id') or raw.get('id') or '')
                tid = str(_row_tmdb_id(raw) or '')
                if kind == 'vod' and ((exclude_stream and sid == exclude_stream) or
                                     (exclude_tmdb and tid == exclude_tmdb)):
                    continue
                # Keep different provider IDs, avoid duplicates when an item is
                # present in both the package cache and the full catalog.
                marker = sid or (_safe_text(raw.get('name') or raw.get('title') or '').lower(),
                                 str(raw.get('_source_category_id') or raw.get('category_id') or cid))
                if marker in seen:
                    continue
                seen.add(marker)
                matches.append(dict(raw))
                changed = True
            return changed

        def publish(done=False):
            # Only emit when there is a changed result set or a changed status.
            marker = (len(matches), bool(done))
            if last_sent[0] != marker and not cancelled():
                last_sent[0] = marker
                emit(list(matches), bool(done))

        # Use RAM/disk and page-local rows before missing-package network scans.
        active_ids = enabled_package_ids(source, kind, category_id, cache_only=True)
        collect(context_rows, category_id)
        collect(server_rows)
        catalog, origin = peek_filtered_streams_cache(source, kind)
        collect(catalog)
        rows, misses = cached_package_rows(source, kind, active_ids)
        collect(rows)
        publish(False)
        if cancelled():
            return

        no_filter = get_allowed_category_ids(source, kind) is None
        catalog_complete = no_filter and origin in ('ram-catalog', 'disk-catalog')
        complete = True
        if not catalog_complete:
            # Server category metadata is resolved *after* initial cache output.
            # It can take time, but it no longer blocks opening the screen.
            all_ids = enabled_package_ids(source, kind, category_id, cache_only=False)
            if cancelled():
                return
            if all_ids:
                # Include packages discovered from fresh category metadata.
                ids = [cid for cid in all_ids if cid not in active_ids]
                if ids:
                    cached_more, missing_more = cached_package_rows(source, kind, ids)
                    collect(cached_more)
                    misses.extend(missing_more)
                    publish(False)
            if misses:
                client = get_source_client(source)
                # Bound requests to two concurrent categories, and stop queuing
                # new groups once user exits the Spotlight page.
                for pos in range(0, len(misses), 2):
                    if cancelled():
                        return
                    batch = misses[pos:pos + 2]
                    try:
                        fetched = get_category_streams_batch(
                            source, kind, client, batch,
                            use_cache=True, wait_for_server=True, max_workers=2)
                        received = set()
                        for cid, items, state in fetched:
                            if cancelled():
                                return
                            received.add(str(cid))
                            if state in ('error', 'loading', 'retry_later', 'empty_cooldown'):
                                complete = False
                            collect(items, str(cid))
                        if len(received) != len(batch):
                            complete = False
                    except Exception as exc:
                        complete = False
                        print('[TiviMateE2] Actor package lookup: %s' % exc)
                    publish(False)
            elif no_filter and not all_ids and source.get('type') == 'xtream':
                # A missing unfiltered catalog needs a single server fetch.
                if cancelled():
                    return
                try:
                    catalog = get_filtered_streams(source, kind,
                                                   get_source_client(source), use_cache=True)
                    collect(catalog)
                except Exception as exc:
                    complete = False
                    print('[TiviMateE2] Actor catalog lookup: %s' % exc)
                publish(False)
            elif no_filter and not all_ids and source.get('type') == 'stalker':
                complete = False
            # With an explicit package filter, an empty package list is a
            # legitimately empty selection, not permission to scan every group.
        if cancelled():
            return
        if complete:
            try:
                search_result_cache.put(key, {'rows': list(matches[:300]), 'complete': True})
            except Exception:
                pass
        publish(True)

    return lookup
