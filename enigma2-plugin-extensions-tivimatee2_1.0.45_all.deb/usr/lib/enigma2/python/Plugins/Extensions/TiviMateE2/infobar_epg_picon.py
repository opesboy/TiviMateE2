# -*- coding: utf-8 -*-
import os
import tempfile

def paint_epg_picon(owner, path):
    target = owner['picon']
    if target.instance is None:
        return False
    temp = None
    try:
        from PIL import Image, ImageDraw
        size = target.instance.size()
        w, h = max(1, size.width()), max(1, size.height())
        canvas = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        mask = Image.new('L', (w, h), 0)
        draw = ImageDraw.Draw(mask)
        r = max(1, min(w, h) // 9)
        draw.rectangle((r, 0, w-r-1, h-1), fill=255)
        draw.rectangle((0, r, w-1, h-r-1), fill=255)
        for x in (0, w-2*r):
            for y in (0, h-2*r):
                draw.ellipse((x,y,x+2*r-1,y+2*r-1), fill=255)
        with Image.open(path) as source:
            logo = source.convert('RGBA')
        bounds = logo.getbbox()
        if bounds:
            logo = logo.crop(bounds)
        ratio = min(float(w-2*r)/logo.size[0], float(h-2*r)/logo.size[1])
        logo = logo.resize((max(1,int(logo.size[0]*ratio)),max(1,int(logo.size[1]*ratio))), getattr(getattr(Image,'Resampling',Image),'LANCZOS',1))
        canvas.paste(logo, ((w-logo.size[0])//2,(h-logo.size[1])//2), logo)
        fd, temp = tempfile.mkstemp(prefix='tm_infobar_', suffix='.png')
        os.close(fd)
        canvas.save(temp, 'PNG')
        target.instance.setPixmapFromFile(temp)
        target.show()
        return True
    except Exception:
        target.instance.setPixmapFromFile(path)
        target.show()
        return True
    finally:
        if temp:
            try: os.unlink(temp)
            except OSError: pass
