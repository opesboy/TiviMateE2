# -*- coding: utf-8 -*-
"""TiviMateE2 global RAM governor.

Schedules bounded cache maintenance outside the GUI thread. Never drops
Linux page cache or clears active catalog/pixmap caches.
"""
from __future__ import absolute_import
import time
import threading
from .playback_priority import active as _vod_active

try:
    from enigma import eTimer
except Exception:
    eTimer = None

_TIMER = None
_TIMER_CONNECTION = None
_TRIM_LOCK = threading.Lock()
_LAST_TRIM = 0.0
INTERVAL_MS = 15000


def ui_opened():
    from .core import set_ui_cache_active as core_active
    from .epg_local import set_ui_cache_active as epg_active
    core_active(True)
    epg_active(True)


def ui_closed():
    # Home has already closed its own jobs; no player, subtitle or relay hooks.
    from .core import set_ui_cache_active as core_active
    from .epg_local import set_ui_cache_active as epg_active
    core_active(False)
    epg_active(False)
    try:
        from .stalker_bouquet_resolver import release_cached_rows
        release_cached_rows()
    except Exception:
        pass
    # Existing bounded worker, with its VOD gate, not a playback watchdog.
    _tick()


def cleanup(level=1):
    """Compatibility entry point: schedule the same non-blocking maintenance."""
    _tick()


def _trim_worker():
    try:
        if _vod_active():
            return
        values = {}
        with open('/proc/meminfo', 'r') as handle:
            for line in handle:
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        values[parts[0].rstrip(':')] = int(parts[1])
                    except ValueError:
                        pass
        total = values.get('MemTotal', 0)
        available = values.get('MemAvailable')
        if available is None:
            available = (values.get('MemFree', 0) + values.get('Buffers', 0) +
                         max(0, values.get('Cached', 0) - values.get('Shmem', 0)))
        from .cache_manager import trim_ram_artwork
        if _vod_active():
            return
        trim_ram_artwork(total, available)
        # Core owns its lock; only expire/bound its caches, no forced GC.
        from .core import runtime_memory_cleanup
        if not _vod_active():
            runtime_memory_cleanup(force_gc=False)
    except Exception:
        pass
    finally:
        _TRIM_LOCK.release()


def _tick():
    # GUI timer only dispatches a bounded background maintenance job.
    # Never clear active catalogs, pixmaps or force GC during navigation.
    global _LAST_TRIM
    if _vod_active():
        return
    now = time.time()
    if 0 <= now - _LAST_TRIM < 90:
        return
    if not _TRIM_LOCK.acquire(False):
        return
    try:
        worker = threading.Thread(target=_trim_worker, name='TiviMateRAMMaintenance')
        worker.daemon = True
        worker.start()
        _LAST_TRIM = now
    except Exception:
        _TRIM_LOCK.release()


def start():
    global _TIMER, _TIMER_CONNECTION
    if eTimer is None or _TIMER is not None:
        return
    try:
        _TIMER = eTimer()
        try:
            _TIMER.callback.append(_tick)
        except Exception:
            _TIMER_CONNECTION = _TIMER.timeout.connect(_tick)
        _TIMER.start(INTERVAL_MS, False)
    except Exception:
        _TIMER = None
        _TIMER_CONNECTION = None


def stop():
    global _TIMER, _TIMER_CONNECTION
    from .playback_priority import reset
    reset()
    try:
        if _TIMER is not None:
            _TIMER.stop()
            try:
                _TIMER.callback.remove(_tick)
            except Exception:
                pass
        if _TIMER_CONNECTION is not None and hasattr(_TIMER_CONNECTION, "disconnect"):
            _TIMER_CONNECTION.disconnect()
    except Exception:
        pass
    _TIMER = None
    _TIMER_CONNECTION = None
    # No forced collection during receiver shutdown.

