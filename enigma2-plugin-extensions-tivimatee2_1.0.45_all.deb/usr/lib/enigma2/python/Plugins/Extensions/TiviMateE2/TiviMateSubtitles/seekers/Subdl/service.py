import requests
import os
import re, json
import time
from urllib.parse import quote_plus, urljoin
from ..utilities import log
from .SubdlUtilities import get_language_info
from ..user_agents import get_api_user_agent, get_random_ua
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

SEARCH_URL = "https://api.subdl.com/api/v1/subtitles"
DOWNLOAD_URL = "https://dl.subdl.com"
API_TIMEOUT = 10
DOWNLOAD_TIMEOUT = 30
_TRANSIENT_HTTP = (408, 425, 429, 500, 502, 503, 504)


def _get_retry(url, **kwargs):
    """One retry for brief transport failures. No retries on 400/401/403."""
    for attempt in range(2):
        try:
            response = requests.get(url, **kwargs)
            status = response.status_code
            if attempt == 0 and status in _TRANSIENT_HTTP:
                # Don't silently wait through long quota/rate-limit windows.
                try:
                    wait = float(response.headers.get('Retry-After', '0') or 0)
                except (TypeError, ValueError):
                    wait = 2
                if status != 429 or wait <= 1:
                    response.close()
                    time.sleep(0.3)
                    continue
            return response
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError):
            if attempt:
                raise
            time.sleep(0.3)
    raise requests.exceptions.RequestException('SubDL request failed')

def build_api_headers():
    """Return headers for SubDL REST API requests."""
    return {
        "User-Agent": get_api_user_agent(),
        "Accept": "application/json",
    }

def build_download_headers():
    """Return browser-like headers for ordinary SubDL file downloads."""
    return {
        "User-Agent": get_random_ua(),
        "Accept": "application/octet-stream,*/*;q=0.8",
    }



def get_subdl_api():
    global settings_provider  # Ensure we're using the existing instance
    API_KEY = settings_provider.getSetting("Subdl_API_KEY")
    if API_KEY:
        return API_KEY
    pass  # debug output removed
    return None


def prepare_search_string(s):
    s = s.replace("'", "").strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)  # remove year from title
    s = quote_plus(s)
    return s


def get_subtitles_list_movie(searchstring, title, languageshort, languagelong, subtitles_list, year=None):
    """Fetches subtitles from the SubDL API and adds them to subtitles_list."""
    if not searchstring:
        pass  # debug output removed
        return

    API_KEY = get_subdl_api()
    if not API_KEY:
        pass  # debug output removed
        return

    try:
        params = {
            "api_key": API_KEY,
            "film_name": searchstring,
            "type": "movie",
            "imdb_id": None,
            "languages": languageshort,
            "subs_per_page": 30,
            "releases": 1,
            "unpack": 1,
            "client": "custom_integration"
        }

        if year:
            params["year"] = int(year)
        response = requests.get(SEARCH_URL, params=params, headers=build_api_headers(), timeout=API_TIMEOUT)
        response.raise_for_status()  # Raises exception for bad status codes

        json_data = response.json()
        status = json_data.get("status", False)

        if status:
            all_subs_data = json_data.get("subtitles", [])
            for item in all_subs_data:
                try:
                    language = item.get("lang")
                    filename = item.get("release_name")
                    id = item.get("url")
                    if language and filename and id:
                        subtitles_list.append({
                            'filename': filename,
                            'sync': False,  # release metadata alone cannot verify playback timing
                            'id': id,
                            'language_flag': languageshort,
                            'language_name': languagelong
                        })
                except Exception as e:
                    pass  # debug output removed
    except Exception as e:
        pass  # debug output removed

def get_subtitles_list_tv(searchstring, tvshow, season, episode, languageshort, languagelong, subtitles_list, year=None):
    """Fetches subtitles from the SubDL API and adds them to subtitles_list."""
    if not searchstring:
        pass  # debug output removed
        return

    API_KEY = get_subdl_api()
    if not API_KEY:
        pass  # debug output removed
        return

    try:
        params = {
            "api_key": API_KEY,
            "film_name": tvshow,
            "type": "tv",
            "imdb_id": None,
            "season_number": season,
            "episode_number": episode,
            "languages": languageshort,
            "subs_per_page": 30,
            "releases": 1,
            "unpack": 1,
            "client": "custom_integration"
        }

        if year:
            params["year"] = int(year)
        response = requests.get(SEARCH_URL, params=params, headers=build_api_headers(), timeout=API_TIMEOUT)
        response.raise_for_status()  # Raises exception for bad status codes

        json_data = response.json()
        status = json_data.get("status", False)

        if status:
            all_subs_data = json_data.get("subtitles", [])
            for item in all_subs_data:
                try:
                    language = item.get("lang")
                    filename = item.get("release_name")
                    id = item.get("url")
                    if language and filename and id:
                        subtitles_list.append({
                            'filename': filename,
                            'sync': False,  # release metadata alone cannot verify playback timing
                            'id': id,
                            'language_flag': languageshort,
                            'language_name': languagelong
                        })
                except Exception as e:
                    pass  # debug output removed
    except Exception as e:
        pass  # debug output removed


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""
    if not title and not tvshow and not file_original_path:
        return subtitles_list, "", msg
    if not title and not tvshow and file_original_path:
        try:
            filename = os.path.basename(file_original_path)
            match = re.match(r'^(.*?)(?:\.\d{4}|\.S\d{2}E\d{2}|\.\d{3,4}p|\.\w{2,3})?\.\w+$', filename)
            if match:
                title = match.group(1).replace('.', ' ').strip()
        except Exception:
            pass
    infos=[]
    seen_lang=set()
    for raw in (lang1,lang2,lang3):
        if not raw: continue
        try:
            info=get_language_info('Persian' if raw=='Farsi' else raw)
        except Exception:
            info=None
        if not info: continue
        code=(info.get('2et') or raw).upper()
        if code in seen_lang: continue
        seen_lang.add(code); infos.append((code,info.get('name') or raw))
    try:
        # SubDL supports comma separated language codes. One request avoids serial waits.
        codes=','.join(x[0] for x in infos)
        display={x[0].lower():x[1] for x in infos}
        API_KEY=get_subdl_api()
        if not API_KEY:
            return subtitles_list, "", "SubDL API key is required (configure provider settings)"
        if not codes:
            return subtitles_list, "", "No supported subtitle languages selected"
        is_tv=bool(tvshow)
        query=tvshow if is_tv else title
        params={"api_key":API_KEY,"film_name":query,"type":"tv" if is_tv else "movie",
                "languages":codes,"subs_per_page":30,"releases":1,"unpack":1,"client":"custom_integration"}
        imdb_id = os.environ.get('TIVIMATE_SEARCH_IMDB_ID', '')
        if not is_tv and re.fullmatch(r'tt\d{5,12}', imdb_id):
            params['imdb_id'] = imdb_id
        if year:
            try: params['year']=int(year)
            except Exception: pass
        if is_tv:
            try: params['season_number']=int(season)
            except Exception: pass
            try: params['episode_number']=int(episode)
            except Exception: pass
        response=_get_retry(SEARCH_URL,params=params,headers=build_api_headers(),timeout=API_TIMEOUT)
        response.raise_for_status(); data=response.json() or {}
        if data.get('status') is False:
            return subtitles_list, '', 'SubDL API rejected search (check credentials or quota)'
        seen=set()
        for item in data.get('subtitles') or []:
            raw_lang = (item.get('lang') or item.get('language') or '')
            lang = str(raw_lang).strip().lower()
            if lang not in display:
                for code, name in display.items():
                    if lang == str(name).strip().lower():
                        lang = code
                        break
                else:
                    aliases = {'arabic': 'ar', 'ara': 'ar', 'english': 'en', 'eng': 'en',
                               'persian': 'fa', 'farsi': 'fa', 'fas': 'fa', 'per': 'fa',
                               'french': 'fr', 'fra': 'fr', 'fre': 'fr', 'german': 'de',
                               'deu': 'de', 'ger': 'de', 'spanish': 'es', 'spa': 'es'}
                    lang = aliases.get(lang, lang)
            url=item.get('url') or item.get('download_url')
            if not url: continue
            release=item.get('release_name') or item.get('name') or item.get('file_name') or 'SubDL'
            k=(str(url),str(release).lower(),lang)
            # Never let a server's incorrect language metadata override the
            # subtitle language selected by the user (particularly Arabic).
            if lang not in display:
                continue
            if k in seen: continue
            seen.add(k)
            subtitles_list.append({'filename':release,'sync':False,'id':url,
                                   'language_flag':lang,'language_name':display.get(lang, lang or 'Unknown')})
    except Exception as e:
        return subtitles_list,"",str(e)
    return subtitles_list,"",msg

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_id = subtitles_list[pos]["id"]
    language = subtitles_list[pos]["language_name"]
    download_url = subtitle_id if str(subtitle_id).startswith(("http://", "https://")) else urljoin(DOWNLOAD_URL + "/", str(subtitle_id).lstrip("/"))
    response = _get_retry(download_url, headers=build_download_headers(), stream=True, timeout=DOWNLOAD_TIMEOUT, allow_redirects=True)
    local_tmp_file = zip_subs
    packed = False
    subs_file = ""

    try:
        response.raise_for_status()
        os.makedirs(tmp_sub_dir, exist_ok=True)
        with open(local_tmp_file, 'wb') as file:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    file.write(chunk)
        with open(local_tmp_file, 'rb') as f:
            header = f.read(120)
        if not header or header.lstrip().lower().startswith((b'<html', b'<!doctype', b'{"error', b'{"message')):
            return False, language, ''
        if header.startswith(b'Rar!'):
            packed, subs_file = True, 'rar'
        elif header.startswith(b'PK\x03\x04'):
            packed, subs_file = True, 'zip'
        else:
            subs_file = local_tmp_file
        return packed, language, subs_file
    except (OSError, requests.exceptions.RequestException) as e:
        log(__name__, 'SubDL download failed: %s' % e)
        return False, language, ''
    finally:
        response.close()
