# -*- coding: utf-8 -*-
"""Load the existing dependency fallbacks in a standalone subtitle worker.

The worker runs as a script, outside the Enigma2 plugin package initializer.
System libraries always take precedence; no package installation or GUI changes.
"""
import os
import sys


def prepare():
    app = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    vendor = os.path.join(app, '_vendor')
    # The main plugin already uses these bundled pure-Python libraries.
    for name in ('six', 'bs4', 'typing_extensions'):
        try:
            __import__(name)
        except ImportError:
            if os.path.isdir(vendor) and vendor not in sys.path:
                sys.path.append(vendor)
            break
    try:
        import requests
    except ImportError:
        if app not in sys.path:
            sys.path.append(app)
        import requests_compat
        requests_compat.install()
        import requests
    # A few seekers only use urllib3 for warning classes/disable_warnings.
    # Reuse the existing warning-only stub only in the fallback worker.
    if getattr(requests, '_tivimate_compat', False):
        try:
            import urllib3
        except ImportError:
            stub = requests.packages.urllib3
            sys.modules['urllib3'] = stub
            sys.modules['urllib3.exceptions'] = stub.exceptions
