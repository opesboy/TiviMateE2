# -*- coding: utf-8 -*-
"""Progress bar drawn with a plain pixmap that is clipped to the progress width.

Some receiver images (VTi, HD-Satelit, ...) ignore the ProgressBar
pixmap/backgroundPixmap attributes and paint a solid white bar instead.
A Pixmap widget is drawn unscaled from the left and clipped by the widget
size, so resizing its width shows exactly the played part on every image.
API compatible with Components.ProgressBar (setRange/setValue/value).
"""
from __future__ import absolute_import
from Components.Pixmap import Pixmap


class PixmapProgress(Pixmap):
    def __init__(self):
        Pixmap.__init__(self)
        self._range = (0, 100)
        self._value = 0
        self._full = None

    def applySkin(self, desktop, parent):
        ret = Pixmap.applySkin(self, desktop, parent)
        try:
            size = self.instance.size()
            self._full = (int(size.width()), int(size.height()))
        except Exception:
            self._full = None
        self._apply()
        return ret

    def setRange(self, value):
        try:
            self._range = (int(value[0]), int(value[1]))
        except Exception:
            pass
        self._apply()

    def getRange(self):
        return self._range

    def setValue(self, value):
        try:
            self._value = int(value)
        except Exception:
            self._value = 0
        self._apply()

    def getValue(self):
        return self._value

    value = property(getValue, setValue)
    range = property(getRange, setRange)

    def _apply(self):
        if not self.instance or not self._full:
            return
        low, high = self._range
        try:
            frac = (float(self._value) - low) / float(high - low) if high != low else 0.0
        except Exception:
            frac = 0.0
        frac = max(0.0, min(1.0, frac))
        width = max(1, int(round(self._full[0] * frac)))
        try:
            from enigma import eSize
            self.instance.resize(eSize(width, self._full[1]))
        except Exception:
            pass
