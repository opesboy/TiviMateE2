# -*- coding: utf-8 -*-
"""Small "Loading package" overlay shown while a Movies / TV package is fetched.

It is a separate dialog, so it works on top of every movies layout without
touching their skins. Shown after a short delay so cached packages that open
instantly never flash it.
"""
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer

from .display_scale import scale_skin

_A = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/loading/"
_FRAMES = 16
_SHOW_DELAY_MS = 700
_FRAME_MS = 70


def _connect(timer, func):
    try:
        timer.callback.append(func)
    except Exception:
        timer.timeout.connect(func)


class PackageLoadingOverlay(Screen):
    skin = scale_skin(
        '<screen name="TiviMatePackageLoading" position="660,455" size="600,170" flags="wfNoBorder" backgroundColor="#ff000000">'
        '<ePixmap pixmap="%spanel.png" position="0,0" size="600,170" alphatest="blend" zPosition="1" />'
        '<widget name="spinner" position="54,49" size="72,72" alphatest="blend" zPosition="3" />'
        '<widget name="title" position="172,40" size="400,46" font="Regular;32" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="3" />'
        '<widget name="sub" position="172,88" size="400,36" font="Regular;23" foregroundColor="#8FD3FF" backgroundColor="#00000000" transparent="1" valign="center" noWrap="1" zPosition="3" />'
        '</screen>' % _A)

    def __init__(self, session):
        Screen.__init__(self, session)
        self["spinner"] = Pixmap()
        self["title"] = Label("")
        self["sub"] = Label("")
        self._frame = 0
        self._timer = eTimer()
        _connect(self._timer, self._tick)

    def _tick(self):
        self._frame = (self._frame + 1) % _FRAMES
        try:
            self["spinner"].instance.setPixmapFromFile(_A + "spin_%02d.png" % self._frame)
        except Exception:
            pass

    def start(self, title, sub):
        self["title"].setText(title)
        self["sub"].setText(sub)
        self._tick()
        self._timer.start(_FRAME_MS, False)
        self.show()

    def stop(self):
        self._timer.stop()
        self.hide()


def _title():
    try:
        from .i18n import get_language
        if get_language() == "ar":
            return u"جاري تحميل الباقة"
    except Exception:
        pass
    return "Loading package"


def show_package_loading(screen, name=""):
    """Show the overlay for `screen` after a short delay (no flash on cache hits)."""
    try:
        state = getattr(screen, "_pkgLoading", None)
        if state is None:
            dialog = screen.session.instantiateDialog(PackageLoadingOverlay)
            delay = eTimer()
            state = {"dialog": dialog, "delay": delay, "name": "", "active": False}
            def fire(st=state):
                if st["active"]:
                    st["dialog"].start(_title(), st["name"])
            _connect(delay, fire)
            screen._pkgLoading = state
            def cleanup(st=state, sess=screen.session):
                try:
                    st["active"] = False
                    st["delay"].stop()
                    st["dialog"].stop()
                    sess.deleteDialog(st["dialog"])
                except Exception:
                    pass
            screen.onClose.append(cleanup)
        state["name"] = str(name or "")
        state["active"] = True
        state["delay"].start(_SHOW_DELAY_MS, True)
    except Exception:
        pass


def hide_package_loading(screen):
    state = getattr(screen, "_pkgLoading", None)
    if not state:
        return
    try:
        state["active"] = False
        state["delay"].stop()
        state["dialog"].stop()
    except Exception:
        pass
