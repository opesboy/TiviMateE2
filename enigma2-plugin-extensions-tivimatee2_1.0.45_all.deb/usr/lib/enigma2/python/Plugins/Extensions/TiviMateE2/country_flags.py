# -*- coding: utf-8 -*-
"""On-demand country flags for Movie and Series details.

TMDb supplies the production/origin country. The flag is downloaded only for
that country, in a separate, bounded worker pool (not the busy poster queue).
Small PNGs are cached on the configured HDD/USB/internal artwork root.
All Enigma widgets are updated from the GUI thread and late results cannot
replace the flag of a different screen/selection.
"""
import os
import re
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.request import Request, urlopen
from urllib.error import URLError

_CODE = re.compile(r"^[A-Z]{2}$")
_COUNTRY_CACHE = {}
_COUNTRY_LOCK = threading.RLock()
_POOL = ThreadPoolExecutor(max_workers=2)
_FAIL_TTL = 120
_COUNTRY_TTL = 43200
_NETWORK_STATUS = threading.local()


def country_code(bundle, kind):
    if not isinstance(bundle, dict):
        return ""
    is_tv = str(kind or "").lower() in ("series", "tv", "shows")
    fields = ("origin_country", "production_countries") if is_tv else ("production_countries", "origin_country")
    for field in fields:
        rows = bundle.get(field) or []
        if isinstance(rows, dict):
            rows = [rows]
        if not isinstance(rows, (tuple, list)):
            continue
        for row in rows:
            raw = (row.get("iso_3166_1") or row.get("country_code")) if isinstance(row, dict) else row
            code = str(raw or "").strip().upper()
            if _CODE.fullmatch(code):
                return code
    return ""


def _flags_dir():
    from .cache_manager import get_cache_dir
    return get_cache_dir("flags")


def _flag_path(code):
    return os.path.join(_flags_dir(), "country_%s.png" % code.lower())


def _valid_png(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) < 80:
            return False
        with open(path, "rb") as f:
            header = f.read(24)
        return (len(header) == 24 and header[:8] == b"\x89PNG\r\n\x1a\n"
                and header[12:16] == b"IHDR"
                and int.from_bytes(header[16:20], "big") > 0
                and int.from_bytes(header[20:24], "big") > 0)
    except Exception:
        return False


def country_flag_path(bundle, kind):
    code = country_code(bundle, kind)
    if not code:
        return ""
    path = _flag_path(code)
    return path if _valid_png(path) else ""


def _download(url):
    _NETWORK_STATUS.last = "unknown"
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0",
        "Accept": "image/png,image/*;q=0.8",
    })
    # Older Enigma2 receivers may have an outdated CA bundle. First attempt
    # verified TLS and use the same last-resort image-only SSL compatibility as
    # the existing artwork helper, restricted to known fixed flag hosts.
    try:
        try:
            response = urlopen(request, timeout=7)
        except (ssl.SSLCertVerificationError, URLError):
            # Never bypass TLS verification for downloaded artwork.
            # The regular local flag/fallback handling remains available.
            raise
        with response:
            data = response.read(192 * 1024 + 1)
        if len(data) > 192 * 1024 or len(data) < 80:
            _NETWORK_STATUS.last = "invalid image size"
            return b""
        if (data[:8] != b"\x89PNG\r\n\x1a\n" or
                data[12:16] != b"IHDR"):
            _NETWORK_STATUS.last = "response is not PNG"
            return b""
        _NETWORK_STATUS.last = "ok"
        return data
    except Exception as exc:
        _NETWORK_STATUS.last = type(exc).__name__
        return b""


def _fetch_flag(code):
    """Dedicated fetch; never block on poster/backdrop downloads."""
    path = _flag_path(code)
    if _valid_png(path):
        return path
    sources = (
        "https://flagcdn.com/w80/%s.png" % code.lower(),
        "https://flagsapi.com/%s/flat/64.png" % code,
    )
    failures = []
    for url in sources:
        data = _download(url)
        if not data:
            failures.append(url.split("/")[2] + ": " + str(getattr(_NETWORK_STATUS, "last", "unknown")))
            continue
        temp = "%s.part.%s.%s" % (path, os.getpid(), threading.get_ident())
        try:
            with open(temp, "wb") as fh:
                fh.write(data)
            if not _valid_png(temp):
                continue
            os.replace(temp, path)
            return path
        except Exception:
            pass
        finally:
            try:
                if os.path.exists(temp):
                    os.unlink(temp)
            except Exception:
                pass
    # Keep one tiny diagnostic record. If both flag hosts are blocked by the
    # receiver's DNS/TLS/firewall, the next failure can be diagnosed accurately
    # without guessing or adding any image to the IPK.
    try:
        with open(os.path.join(_flags_dir(), "last_download_failure.txt"), "w") as f:
            f.write("Country: %s\n%s\n" % (code, "\n".join(failures)))
    except Exception:
        pass
    return ""


def _country_from_tmdb(kind, tmdb_id):
    key = ("tv" if kind in ("tv", "series") else "movie", str(tmdb_id))
    now = time.time()
    with _COUNTRY_LOCK:
        cached = _COUNTRY_CACHE.get(key)
        if cached and now - cached[1] < (_COUNTRY_TTL if cached[0] else _FAIL_TTL):
            return cached[0]
    country = ""
    try:
        from .tmdb_client import TMDbClient
        # Request only metadata for the resolved TMDb ID. This request is run
        # in the flag worker, never on the UI thread.
        payload = TMDbClient()._get("/%s/%s" % key, {"language": "en-US"}) or {}
        country = country_code(payload, kind)
    except Exception:
        pass
    with _COUNTRY_LOCK:
        if len(_COUNTRY_CACHE) > 256:
            _COUNTRY_CACHE.clear()
        _COUNTRY_CACHE[key] = (country, time.time())
    return country


def _flag_may_show(widget):
    checker = getattr(widget, "_tivimate_flag_allowed", None)
    if checker is None:
        return True
    try:
        return bool(checker())
    except Exception:
        return False


def _fallback_draw(widget, path, token):
    if getattr(widget, "_tivimate_flag_token", None) != token:
        return
    try:
        if widget.instance and _valid_png(path):
            selected = path
            try:
                from .hd_skin_compat import visual_compat_image, fitted_round_icon
                if visual_compat_image() and str(path).lower().endswith('_round64.png'):
                    size = widget.instance.size()
                    selected = fitted_round_icon(path, size.width(), size.height()) or path
            except Exception: pass
            widget.instance.setPixmapFromFile(selected)
            widget._tivimate_flag_rendered = token
            if _flag_may_show(widget):
                widget.show()
            else:
                widget.hide()
    except Exception:
        pass


def _decode_flag(widget, path, token):
    if not path or getattr(widget, "_tivimate_flag_token", None) != token:
        return
    try:
        if not widget.instance:
            return
        from enigma import ePicLoad, eTimer
        from .alpha_picload import ePicLoad
        from .picload_compat import connect_picture_data
        loader = ePicLoad()
        widget._tivimate_flag_loader = loader

        def ready(_info=None):
            if (getattr(widget, "_tivimate_flag_token", None) != token or
                    getattr(widget, "_tivimate_flag_loader", None) is not loader):
                return
            try:
                pix = loader.getData()
                if pix and widget.instance:
                    widget.instance.setPixmap(pix)
                    widget._tivimate_flag_rendered = token
                    if _flag_may_show(widget):
                        widget.show()
                    else:
                        widget.hide()
                else:
                    _fallback_draw(widget, path, token)
            except Exception:
                _fallback_draw(widget, path, token)
            finally:
                if getattr(widget, "_tivimate_flag_loader", None) is loader:
                    widget._tivimate_flag_loader = None

        conn = connect_picture_data(loader, ready, widget, oneshot=True)
        if conn is None:
            _fallback_draw(widget, path, token)
            return
        size = widget.instance.size()
        w = max(1, size.width())
        h = max(1, size.height())
        loader.setPara((w, h, 0, 0, False, 1, "#00000000"))
        result = loader.startDecode(path)
        if isinstance(result, int) and result < 0:
            _fallback_draw(widget, path, token)
            return

        # Some Enigma2 builds silently fail to emit PictureData for tiny PNGs.
        # Fallback to the known-working Pixmap.setPixmapFromFile path after a
        # short timeout, without replacing a successful decoded image.
        timer = eTimer()
        widget._tivimate_flag_fallback_timer = timer
        def timeout():
            if (getattr(widget, "_tivimate_flag_token", None) == token and
                    getattr(widget, "_tivimate_flag_rendered", None) != token):
                _fallback_draw(widget, path, token)
            try:
                timer.stop()
            except Exception:
                pass
            if getattr(widget, "_tivimate_flag_fallback_timer", None) is timer:
                widget._tivimate_flag_fallback_timer = None
        try:
            widget._tivimate_flag_timer_conn = timer.timeout.connect(timeout)
        except Exception:
            timer.callback.append(timeout)
        timer.start(800, True)
    except Exception:
        _fallback_draw(widget, path, token)


def _gui_on_ready(widget, token, path):
    if getattr(widget, "_tivimate_flag_token", None) == token and path:
        _decode_flag(widget, path, token)


def _cached_country_code(kind, tmdb_id):
    """Return the verified country already fetched by the shared TMDb worker."""
    if not str(tmdb_id or "").isdigit():
        return ""
    key = ("tv" if kind in ("tv", "series") else "movie", str(tmdb_id))
    with _COUNTRY_LOCK:
        cached = _COUNTRY_CACHE.get(key)
        return str(cached[0] or "") if cached else ""


def _gui_on_flag_resolved(widget, token, path, code, resolved_callback=None):
    """Apply a visible flag and share its verified country on the GUI thread."""
    if not path or getattr(widget, "_tivimate_flag_token", None) != token:
        return
    _gui_on_ready(widget, token, path)
    if code and callable(resolved_callback):
        try:
            resolved_callback(code)
        except Exception:
            pass


def _flag_circle_face(flag, big, sampling):
    """Square face for a round flag that keeps the whole design visible.

    A plain centre crop of a 2:1 flag cuts the hoist side away (the red bar of
    the UAE, Kuwait's black trapezoid, Jordan/Palestine/Sudan triangles,
    Qatar/Bahrain serrations). Keep the hoist when the left edge differs from
    the right edge, and squeeze the remaining width a little instead of
    cutting it, so every part of the flag stays inside the circle.
    """
    from PIL import Image, ImageOps
    width, height = flag.size
    if width <= 0 or height <= 0:
        return flag.resize((big, big), sampling)
    if float(width) / height <= 1.05:
        return ImageOps.fit(flag, (big, big), method=sampling)
    hoist = False
    try:
        probe = flag.convert('RGB').resize((32, 16), sampling).load()
        diff = 0
        for y in range(16):
            left, right = probe[1, y], probe[30, y]
            diff += abs(left[0] - right[0]) + abs(left[1] - right[1]) + abs(left[2] - right[2])
        hoist = diff / 16.0 > 60
    except Exception:
        hoist = False
    ratio = float(width) / height
    squeeze = 1.4 if hoist else 1.2
    if hoist and ratio > 2.2:
        squeeze = 1.7          # very long flags (Qatar 11:28)
    keep = int(round(min(width, height * squeeze)))
    if not hoist:
        left = (width - keep) // 2
    elif ratio > 2.2:
        left = (width - keep) // 3
    else:
        left = 0
    return flag.crop((left, 0, left + keep, height)).resize((big, big), sampling)

def _apple_round_flag(path):
    """Circular country flag (64px, thin white ring) cached beside the flag."""
    if not path or not os.path.isfile(path):
        return ''
    target = path[:-4] + '_v2_round64.png'
    try:
        if os.path.isfile(target) and os.path.getmtime(target) >= os.path.getmtime(path):
            return target
        from PIL import Image, ImageOps, ImageDraw
        big = 192
        lanczos = Image.Resampling.LANCZOS if hasattr(Image, 'Resampling') else Image.LANCZOS
        with Image.open(path) as flag:
            face = _flag_circle_face(flag.convert('RGBA'), big, lanczos)
        mask = Image.new('L', (big, big), 0)
        ImageDraw.Draw(mask).ellipse((9, 9, big - 10, big - 10), fill=255)
        out = Image.new('RGBA', (big, big), (0, 0, 0, 0))
        out.paste(face, (0, 0), mask)
        ImageDraw.Draw(out).ellipse((4, 4, big - 5, big - 5), outline=(255, 255, 255, 235), width=8)
        out = out.resize((64, 64), lanczos)
        tmp = target + '.%s.tmp' % threading.current_thread().ident
        out.save(tmp, format='PNG')
        os.rename(tmp, target)
        return target
    except Exception:
        return ''


def _worker(kind, tmdb_id, code, round_style=False):
    if not code and tmdb_id:
        code = _country_from_tmdb(kind, tmdb_id)
    if not code:
        return ""
    raw = _fetch_flag(code)
    if raw and round_style:
        return _apple_round_flag(raw) or raw
    return raw


def show_country_flag(widget, bundle, kind, tmdb_id=None, visible_when=None, gui_dispatch=None, on_resolved=None, round_style=False):
    """Display a valid online flag using shared details cache and worker.

    An optional screen-owned GUI dispatcher lets screens that already use
    their eTimer mainloop queue avoid relying on Twisted integration.
    """
    try:
        widget._tivimate_flag_allowed = visible_when
        # Style only details; poster-card flags retain their original appearance.
        round_style = bool(round_style)
        token = int(getattr(widget, "_tivimate_flag_token", None) or 0) + 1
        widget._tivimate_flag_token = token
        widget._tivimate_flag_rendered = None
        try:
            old_timer = getattr(widget, "_tivimate_flag_fallback_timer", None)
            if old_timer:
                old_timer.stop()
        except Exception:
            pass
        widget.hide()
        code = country_code(bundle, kind)
        if code:
            path = country_flag_path(bundle, kind)
            if path:
                if round_style:
                    styled = path[:-4] + '_v2_round64.png'
                    try:
                        fresh = (_valid_png(styled) and
                                 os.path.getmtime(styled) >= os.path.getmtime(path))
                    except Exception:
                        fresh = False
                    if fresh:
                        _decode_flag(widget, styled, token)
                        if callable(on_resolved):
                            try:
                                on_resolved(code)
                            except Exception:
                                pass
                        return True
                    # Generate the 64px circular PNG on the existing flag pool.
                else:
                    _decode_flag(widget, path, token)
                    if callable(on_resolved):
                        try:
                            on_resolved(code)
                        except Exception:
                            pass
                    return True
        candidate = str(tmdb_id or (bundle or {}).get("id") or "").strip()
        if not code and (not candidate.isdigit() or int(candidate) < 1):
            return False
        # The fast Movies/TV screens already have an eTimer-driven GUI queue.
        # Deliver through it rather than Twisted: on some Pure2/OpenATV builds
        # a reactor may import but its callFromThread is not integrated with
        # the running Enigma2 mainloop. The flag would remain hidden forever.
        if callable(gui_dispatch):
            future = _POOL.submit(_worker, kind, candidate if not code else None, code, round_style)
            def deliver_with_screen_queue(completed):
                try:
                    path = completed.result()
                except Exception:
                    path = ""
                try:
                    known = code or (_cached_country_code(kind, candidate) if path else "")
                    gui_dispatch(_gui_on_flag_resolved, widget, token, path, known, on_resolved)
                except Exception:
                    pass
            future.add_done_callback(deliver_with_screen_queue)
            return True
        # Other consumers retain their existing Twisted/eTimer behaviour.
        try:
            from twisted.internet import reactor
            def deliver(future):
                try:
                    path = future.result()
                except Exception:
                    path = ""
                reactor.callFromThread(_gui_on_ready, widget, token, path)
            _POOL.submit(_worker, kind, candidate if not code else None, code, round_style).add_done_callback(deliver)
        except Exception:
            # Pure2 images without Twisted callbacks use one short-lived GUI
            # poller. It does not perform downloads on the UI thread.
            from enigma import eTimer
            future = _POOL.submit(_worker, kind, candidate if not code else None, code, round_style)
            timer = eTimer()
            widget._tivimate_flag_poll_timer = timer
            def poll():
                if getattr(widget, "_tivimate_flag_token", None) != token:
                    timer.stop()
                    return
                if future.done():
                    timer.stop()
                    try:
                        _gui_on_ready(widget, token, future.result())
                    except Exception:
                        pass
                else:
                    timer.start(250, True)
            try:
                widget._tivimate_flag_poll_conn = timer.timeout.connect(poll)
            except Exception:
                timer.callback.append(poll)
            timer.start(250, True)
        return True
    except Exception:
        return False
