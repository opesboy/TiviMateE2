# -*- coding: utf-8 -*-
"""Poster-only BLUE press/hold and same-page all-packages search."""
from Components.ActionMap import ActionMap
import os
from .display_scale import sx, sy


def add_footer_hint(skin):
    if 'name="posterInlineSearchStrip"' in skin:
        return skin
    if '</screen>' not in skin:
        raise ValueError('Poster skin has no closing screen tag')
    # Same pre-existing search strip asset, font sizes, icon sizes and
    # 34px spinner as the main TiviMateE2Search view. Anchor above the
    # footer on all poster layouts (including the 24-poster GENRE grid).
    search_skin = os.path.join(os.path.dirname(__file__), 'skins', 'search')
    bx, by = 578, 949
    widgets = (
        '<widget name="posterInlineSearchStrip" position="%d,%d" size="%d,%d" '
        'pixmap="%s" alphatest="blend" zPosition="89" />'
        '<widget name="posterInlineSearchSpin" position="%d,%d" size="%d,%d" '
        'alphatest="blend" scale="1" zPosition="90" />'
        '<widget name="posterInlineSearchText" position="%d,%d" size="%d,%d" '
        'font="Regular;%d" foregroundColor="#FFFFFF" backgroundColor="#00000000" '
        'transparent="1" valign="center" noWrap="1" zPosition="90" />'
        '<widget name="posterInlineSearchMoviesIcon" position="%d,%d" size="%d,%d" '
        'pixmap="%s" alphatest="blend" zPosition="90" />'
        '<widget name="posterInlineSearchMoviesCount" position="%d,%d" size="%d,%d" '
        'font="Regular;%d" foregroundColor="#FFD66E" backgroundColor="#00000000" '
        'transparent="1" valign="center" noWrap="1" zPosition="90" />'
        '<widget name="posterInlineSearchSeriesIcon" position="%d,%d" size="%d,%d" '
        'pixmap="%s" alphatest="blend" zPosition="90" />'
        '<widget name="posterInlineSearchSeriesCount" position="%d,%d" size="%d,%d" '
        'font="Regular;%d" foregroundColor="#7FB8FF" backgroundColor="#00000000" '
        'transparent="1" valign="center" noWrap="1" zPosition="90" />'
        % (sx(bx),sy(by),sx(764),sy(74),os.path.join(search_skin, 'searching_strip.png'),
           sx(bx+26),sy(by+20),sx(34),sy(34),
           sx(bx+72),sy(by+14),sx(400),sy(46),max(16,sy(21)),
           sx(bx+500),sy(by+24),sx(26),sy(26),os.path.join(search_skin,'count_movies.png'),
           sx(bx+534),sy(by+14),sx(88),sy(46),max(17,sy(22)),
           sx(bx+624),sy(by+24),sx(26),sy(26),os.path.join(search_skin,'count_series.png'),
           sx(bx+658),sy(by+14),sx(88),sy(46),max(17,sy(22))))
    return skin.replace('</screen>', widgets + '\n</screen>', 1)


def install_poster_blue_hold(screen, short_action, long_action=None):
    from .poster_inline_search import install
    install(screen)
    state = {'held': False}
    def on_make():
        state['held'] = False
        return 1  # Consume KEY_BLUE before ColorActions on VTi/OpenATV.
    def on_long():
        if state['held']:
            return 1
        state['held'] = True
        screen._openPosterInlineSearch()
        return 1
    def on_break():
        held = state['held']
        state['held'] = False
        if not held:
            screen._cancelPosterInlineSearch(True)
            short_action()
        return 1
    screen['posterBlueHoldActions'] = ActionMap(
        ['TiviMatePosterBlueActions'],
        {'posterBlueMake': on_make,
         'posterBlueLong': on_long,
         'posterBlueBreak': on_break}, -3)
