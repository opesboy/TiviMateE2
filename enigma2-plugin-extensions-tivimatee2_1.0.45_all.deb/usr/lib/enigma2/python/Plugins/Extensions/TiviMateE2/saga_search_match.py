# -*- coding: utf-8 -*-
"""Conservative, cached-first provider to TMDb movie-part matching.

This module contains no UI/network work and runs on Python 2.7 and Python 3.
Never return a guessed part based on a matching franchise token alone.
"""
from __future__ import absolute_import
import re

try:
    _text = unicode
except NameError:
    _text = str

_ROMAN = {'ii':'2', 'iii':'3', 'iv':'4', 'v':'5', 'vi':'6',
          'vii':'7', 'viii':'8', 'ix':'9', 'x':'10'}
_ARABIC_NUM = dict((ord(a), b) for a, b in zip(u'٠١٢٣٤٥٦٧٨٩', u'0123456789'))


def clean_alias(value, title_norm):
    try:
        text = title_norm(value)
    except Exception:
        return u''
    if not text:
        return u''
    try:
        text = text.translate(_ARABIC_NUM)
    except Exception:
        pass
    words = text.split()
    result = []
    for word in words:
        result.append(_ROMAN.get(word, word))
    # Explicit sequel descriptors are labels, not part of the unique title.
    result = [w for w in result if w not in ('part', 'chapter')]
    return u' '.join(result)


def prepare_parts(parts, title_norm):
    """Compute aliases once per saga, not for every server catalog row."""
    out = []
    for part, keys, year in parts:
        aliases = []
        for key in keys:
            value = clean_alias(key, title_norm)
            if value and value not in aliases:
                aliases.append(value)
        out.append((str(part.get('id') or '').strip(), year, aliases))
    return out


def choose_part(row, parts, title_norm, title_score, year_of, tmdb_id_of, prepared=None):
    """Return verified index or None; parts are (tmdb part, keys, year)."""
    if not isinstance(row, dict):
        return None
    if prepared is None:
        prepared = prepare_parts(parts, title_norm)
    try:
        row_id = str(tmdb_id_of(row) or '').strip()
    except Exception:
        row_id = ''
    if row_id:
        for index, (part_id, _year, _aliases) in enumerate(prepared):
            if part_id and row_id == part_id:
                return index
        # A provider row with a DIFFERENT explicit TMDb movie identity is
        # not a title-only candidate, regardless of shared franchise tokens.
        return None

    # Normalize only once for each candidate title. The parent caller handles
    # already disabled packages and adult rows before reaching here.
    extra = row.get('info') if isinstance(row.get('info'), dict) else {}
    titles = []
    for entry in (row, extra):
        for key in ('name', 'title', 'original_title', 'o_name', 'stream_display_name'):
            value = entry.get(key)
            if value:
                title = clean_alias(value, title_norm)
                if title and title not in titles:
                    titles.append(title)
    if not titles:
        return None
    try:
        stamp = str(row.get('release_date') or row.get('releaseDate') or
                    row.get('releasedate') or row.get('year') or '')[:4]
        year = int(stamp) if len(stamp) == 4 and stamp.isdigit() else int(year_of(row) or 0)
    except Exception:
        year = 0

    winner, highest = None, 0.0
    runner_up = 0.0
    # Compare the franchise/root title, not a bag of overlapping words.
    # "Boo 2! A Madea Halloween" must NEVER become "Halloween II".
    # Similarly, "Season of the Witch" alone is not Halloween III.
    title_words = [set(candidate.split()) for candidate in titles]
    title_prefixes = [next((word for word in candidate.split()
                            if word not in ('the', 'a', 'an', 'le', 'la', 'les')), '')
                      for candidate in titles]
    for index, (_id, part_year, aliases) in enumerate(prepared):
        # A different known release year disqualifies a remake or sequel.
        if part_year and year and abs(part_year-year) > 1:
            continue
        best_for_part = 0.0
        for candidate, candidate_words, prefix in zip(titles, title_words, title_prefixes):
            for wanted in aliases:
                if wanted == candidate:
                    score = 1.0
                else:
                    wanted_prefix = next((w for w in wanted.split()
                                          if w not in ('the', 'a', 'an', 'le', 'la', 'les')), '')
                    if not prefix or prefix != wanted_prefix:
                        continue
                    if not candidate_words.intersection(wanted.split()):
                        continue
                    try:
                        score = title_score(wanted, candidate)
                    except Exception:
                        score = 0.0
                if score > best_for_part:
                    best_for_part = score
        if best_for_part < 0.92:
            continue
        # Prefer the correct year when two franchise films share a title.
        if part_year and year and part_year == year:
            best_for_part += 0.025
        if best_for_part > highest:
            runner_up = highest
            winner, highest = index, best_for_part
        elif best_for_part > runner_up:
            runner_up = best_for_part
    # "Halloween" with no year cannot be assigned arbitrarily to one of
    # several identically named TMDb collection entries.
    if highest - runner_up < 0.02:
        return None
    return winner


def make_candidate_filter(parts, title_norm):
    """Cheap conservative prefilter for tens of thousands of cached titles.

    A TMDb ID always bypasses title filtering (translated/renamed films).
    For title matching, choose a possible row if ANY significant token from
    ANY TMDb alias occurs in its raw title. This is deliberately permissive:
    choose_part() still applies strict ID/year/title validation afterward.
    """
    prepared = prepare_parts(parts, title_norm)
    ids = set(p[0] for p in prepared if p[0])
    probes = set()
    for _tmdb, _year, aliases in prepared:
        for name in aliases:
            words = name.split()
            long_words = [w for w in words if len(w) >= 3]
            # Single short movie titles (It, Up, Pi) must remain searchable.
            probes.update(long_words if long_words else words)
    probes = tuple(sorted(probes, key=len, reverse=True))

    def decode(value):
        try:
            if isinstance(value, bytes):
                return value.decode('utf-8', 'replace').lower()
            return _text(value or u'').lower()
        except Exception:
            return u''

    def candidate(row):
        if not isinstance(row, dict):
            return False
        detail = row.get('info') if isinstance(row.get('info'), dict) else {}
        for mapping in (row, detail):
            for key in ('tmdb_id', 'tmdb', 'tmdbid', 'tmdbId'):
                value = mapping.get(key)
                if value not in (None, ''):
                    value = decode(value).strip()
                    if value in ids:
                        return True
                    try:
                        if str(int(float(value))) in ids:
                            return True
                    except Exception:
                        pass
        if not probes:
            return True  # Insufficient metadata: let strict matcher decide.
        raw = u' '.join(decode(mapping.get(k)) for mapping in (row, detail)
                       for k in ('name', 'title', 'original_title', 'o_name', 'stream_display_name'))
        return bool(raw) and any(word in raw for word in probes)

    return candidate
