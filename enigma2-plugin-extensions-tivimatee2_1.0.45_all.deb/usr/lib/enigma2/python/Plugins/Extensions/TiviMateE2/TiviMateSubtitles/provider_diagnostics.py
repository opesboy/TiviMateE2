# -*- coding: utf-8 -*-
import os
import re
import time
import threading
_LOCK = threading.Lock()
LOG = '/tmp/subtitle_provider_debug.log'

def error_reason(error):
    inner = getattr(error, 'wrapped_error', error)
    kind = inner.__class__.__name__
    try:
        value = str(inner)
    except Exception:
        value = ''
    match = re.search(r"(?:No module named|cannot import name)\s+['\"]?([A-Za-z0-9_.]+)", value)
    if match:
        return '%s: %s' % (kind, match.group(1))
    match = re.search(r'(?<![0-9])(?:401|403|404|429|500|502|503|504)(?![0-9])', value)
    if match:
        return '%s: HTTP %s' % (kind, match.group(0))
    low = value.lower()
    for words, label in ((('timeout', 'timed out'), 'timeout'), (('ssl', 'certificate', 'tls'), 'TLS/certificate'), (('api key', 'credential', 'unauthorized'), 'API credentials'), (('connection', 'resolve', 'network'), 'network')):
        if any(word in low for word in words):
            return '%s: %s' % (kind, label)
    return kind

def record(event, provider='', error=None, count=None):
    try:
        with _LOCK:
            if os.path.isfile(LOG) and os.path.getsize(LOG) > 128 * 1024:
                with open(LOG, 'w') as handle:
                    handle.write('Rotated subtitle provider log\n')
            safe_id = re.sub(r'[^A-Za-z0-9_.:-]', '', str(provider))[:60]
            row = '%s %s %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), event, safe_id)
            if count is not None:
                row += ' count=%d' % count
            if error is not None:
                row += ' ' + error_reason(error)
            with open(LOG, 'a') as handle:
                handle.write(row + '\n')
    except Exception:
        pass
