# -*- coding: utf-8 -*-
"""Actor Spotlight: a dedicated results page for one actor.

Left: portrait, name, birth facts and biography (TMDb person record).
Right: the actor's titles found on the active server, 12 large posters per
page, each captioned with the year and rating when available.

The page subclasses the GENRE grid so posters keep its exact provider ->
validation -> TMDb pipeline, sorting, favourites and Details hand-over.  Only
the layout, the page size and the actor panel are new.  Nothing here changes
the actor search itself: the rows are the ones Movie/Series Details found.
"""

import os
import re
import threading
import time
try:
    from .py27_futures import ThreadPoolExecutor
except ImportError:
    from concurrent.futures import ThreadPoolExecutor

from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer

from .alpha_picload import ePicLoad
from .cache_manager import stable_cache_key, persistent_cache_get, persistent_cache_set
from .display_scale import scale_skin, sx, sy, scale_size
from .display_titles import visible_title
from .genre_page import (StandaloneGenreScreen, GENRE_PILL_SPECS, _genre_pill_score,
                         _genre_pill_language, _genre_pill_age)
from .genre_ultra_artwork import request as fetch_artwork
from .i18n import tr, get_language
from .picload_compat import connect_picture_data
from .resolution_badge import (extract_resolution, extract_rating, extract_duration,
                               _year_genre_from_sources, _actual_media_genre)
from .rtl_text import DirectionalLabel, SynopsisLabel
from .localized_story import LocalizedStoryMixin
from .tmdb_client import TMDbClient

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
ART = os.path.join(PLUGIN_PATH, "skins", "actor")
POSTER_PLACEHOLDER = os.path.join(ART, "spot_poster_placeholder.png")

# 1920x1080 design canvas (display_scale converts it for HD / WQHD desktops).
COLS = 6
ROWS = 2
PAGE = COLS * ROWS
BASE_SLOTS = 24              # widgets the GENRE base class always creates
X = (648, 854, 1060, 1266, 1472, 1678)
Y = (250, 605)
POSTER_W = 182
POSTER_H = 273
FOCUS_PAD = 12
PHOTO_X, PHOTO_Y, PHOTO_W, PHOTO_H = 66, 122, 260, 392
PILL_X = 648
PILL_Y = 116
PILL_LIMIT = 1540            # the page counter column starts at x=1566
GOLD = "#F2CF85"
LOGO_W, LOGO_H = 192, 34
_SPOT_LOGO_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviSpotLogo")

_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

_TEXT = {
    "ar": {
        "ACTOR": u"ممثل",
        "movies on\nthis server": u"أفلام على\nهذا السيرفر",
        "movie on\nthis server": u"فيلم على\nهذا السيرفر",
        "TV shows on\nthis server": u"مسلسلات على\nهذا السيرفر",
        "TV show on\nthis server": u"مسلسل على\nهذا السيرفر",
        "out of %d\nTMDb credits": u"من أصل %d\nعملاً في TMDb",
        "BORN": u"الميلاد",
        "FROM": u"من",
        "KNOWN FOR %s": u"معروف بـ %s",
        "Acting": u"التمثيل", "Directing": u"الإخراج", "Writing": u"الكتابة", "Production": u"الإنتاج",
    },
    "fr": {
        "ACTOR": u"ACTEUR",
        "movies on\nthis server": u"films sur\nce serveur",
        "movie on\nthis server": u"film sur\nce serveur",
        "TV shows on\nthis server": u"séries sur\nce serveur",
        "TV show on\nthis server": u"série sur\nce serveur",
        "out of %d\nTMDb credits": u"sur %d\ncrédits TMDb",
        "BORN": u"NAISSANCE",
        "FROM": u"ORIGINE",
        "KNOWN FOR %s": u"CONNU POUR : %s",
        "Acting": u"INTERPRÉTATION", "Directing": u"RÉALISATION", "Writing": u"ÉCRITURE", "Production": u"PRODUCTION",
    },
    "tr": {
        "ACTOR": u"OYUNCU",
        "movies on\nthis server": u"film bu\nsunucuda",
        "movie on\nthis server": u"film bu\nsunucuda",
        "TV shows on\nthis server": u"dizi bu\nsunucuda",
        "TV show on\nthis server": u"dizi bu\nsunucuda",
        "out of %d\nTMDb credits": u"toplam %d\nTMDb yapımı",
        "BORN": u"DOĞUM",
        "FROM": u"YER",
        "KNOWN FOR %s": u"ALANI: %s",
        "Acting": u"OYUNCULUK", "Directing": u"YÖNETMENLİK", "Writing": u"YAZARLIK", "Production": u"YAPIM",
    },
}


_TEXT["de"] = {
    u'ACTOR': u'SCHAUSPIELER',
    u'Acting': u'Schauspiel',
    u'BORN': u'GEBOREN',
    u'Directing': u'Regie',
    u'FROM': u'AUS',
    u'KNOWN FOR %s': u'BEKANNT FÜR %s',
    u'Production': u'Produktion',
    u'TV show on\nthis server': u'Serie auf\ndiesem Server',
    u'TV shows on\nthis server': u'Serien auf\ndiesem Server',
    u'Writing': u'Drehbuch',
    u'movie on\nthis server': u'Film auf\ndiesem Server',
    u'movies on\nthis server': u'Filme auf\ndiesem Server',
    u'out of %d\nTMDb credits': u'von %d\nTMDb-Einträgen',
}

def _language():
    try:
        return str(get_language() or "en").lower()[:2]
    except Exception:
        return "en"


def _t(text):
    """Page-local labels; unknown languages and keys stay English."""
    return _TEXT.get(_language(), {}).get(text, text)


def _shorten(value, limit):
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    part = text[:limit].rstrip()
    cut = part.rfind(" ")
    if cut >= limit // 2:
        part = part[:cut]
    return part.rstrip(u" -_|:/,.؛،") + u"…"


def _person_number(person_id):
    try:
        value = int(str(person_id or "0").strip())
    except Exception:
        return 0
    return value if value > 0 else 0


def _parse_date(value):
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", str(value or "").strip())
    if not match:
        return None
    year, month, day = int(match.group(1)), int(match.group(2)), int(match.group(3))
    if not (1800 <= year <= 2200 and 1 <= month <= 12 and 1 <= day <= 31):
        return None
    return year, month, day


def _years_between(start, end):
    years = end[0] - start[0]
    if (end[1], end[2]) < (start[1], start[2]):
        years -= 1
    return years


def _format_date(parts):
    year, month, day = parts
    if _language() == "en":
        return "%d %s %d" % (day, _MONTHS[month - 1], year)
    return "%02d/%02d/%d" % (day, month, year)


def birth_line(birthday, deathday, today=None):
    """'14 May 1983 (43)' for the living, '1933 – 2020 (86)' otherwise."""
    born = _parse_date(birthday)
    if not born:
        return ""
    died = _parse_date(deathday)
    if died:
        age = _years_between(born, died)
        text = u"%d – %d" % (born[0], died[0])
        return (text + " (%d)" % age) if 0 < age < 125 else text
    if today is None:
        now = time.localtime()
        today = (now.tm_year, now.tm_mon, now.tm_mday)
    age = _years_between(born, today)
    text = _format_date(born)
    # A receiver without a valid clock (1970) must not invent an age.
    return (text + " (%d)" % age) if 0 < age < 125 else text


def birthplace_line(value):
    parts = [part.strip() for part in str(value or "").split(",") if part.strip()]
    if len(parts) > 2:
        parts = [parts[0], parts[-1]]
    return _shorten(", ".join(parts), 32)


def department_line(value):
    name = str(value or "").strip()
    if not name:
        return ""
    label = _TEXT.get(_language(), {}).get(name)
    if label is None:
        label = name.upper() if _language() == "en" else name
    return _t("KNOWN FOR %s") % label


_PERSON_LANGUAGES = {
    "ar": "ar-AE", "fr": "fr-FR", "tr": "tr-TR", "de": "de-DE", "en": "en-US",
}

_BIO_MISSING = {
    "ar": u"لا تتوفر نبذة عن الممثل.",
    "fr": u"Biographie indisponible.",
    "tr": u"Biyografi bulunamadı.",
    "de": u"Keine Biografie verfügbar.",
    "en": u"Biography unavailable.",
}


def _person_locale():
    # The application language, not the separately configured TMDb language.
    return _PERSON_LANGUAGES.get(_language(), "en-US")


def _bio_missing_text():
    return _BIO_MISSING.get(_language(), _BIO_MISSING["en"])


def _translated_biography(client, number, language):
    """Try the person's other regions for the same language; never mix languages."""
    try:
        translations = client._get("/person/%d/translations" % number) or {}
    except Exception:
        return ""
    if not isinstance(translations, dict):
        return ""
    primary = language.split("-", 1)[0].lower()
    region = language.split("-", 1)[1].upper() if "-" in language else ""
    candidates = []
    for item in translations.get("translations") or []:
        if not isinstance(item, dict) or str(item.get("iso_639_1") or "").lower() != primary:
            continue
        detail = item.get("data") or {}
        if not isinstance(detail, dict):
            continue
        biography = str(detail.get("biography") or "").strip()
        if biography:
            preferred = str(item.get("iso_3166_1") or "").upper() == region
            candidates.append((0 if preferred else 1, biography))
    if not candidates:
        return ""
    candidates.sort(key=lambda entry: entry[0])
    return candidates[0][1]


def load_person(person_id):
    """Person metadata and biography in app language, then English fallback.

    Reuse localized v2 cache records; retry existing empty entries once with
    English rather than making users wait for the old 24-hour empty TTL.
    """
    number = _person_number(person_id)
    if not number:
        return {}
    language = _person_locale()
    key = stable_cache_key("actor_spotlight_person_v2", number, language)
    try:
        saved = persistent_cache_get(key)
    except Exception:
        saved = None
    # A translated biography is already complete.  The marker also prevents
    # repeatedly fetching English if TMDb has neither language available.
    if isinstance(saved, dict) and saved.get("id"):
        if language == "en-US" or str(saved.get("biography") or "").strip() or saved.get("_bio_fallback_checked"):
            return saved
    else:
        saved = None

    try:
        client = TMDbClient()
    except Exception:
        return saved or {}
    data = dict(saved) if saved is not None else {}
    if not data:
        try:
            data = client._get("/person/%d" % number, {"language": language}) or {}
        except Exception:
            data = {}
        if not isinstance(data, dict):
            data = {}

    biography = str(data.get("biography") or "").strip()
    if not biography and language != "en-US":
        if saved is None:
            # Try other regions of the selected language before falling back.
            biography = _translated_biography(client, number, language)

    english_failed = False
    if not biography and language != "en-US":
        english_key = stable_cache_key("actor_spotlight_person_v2", number, "en-US")
        try:
            english_saved = persistent_cache_get(english_key)
        except Exception:
            english_saved = None
        english_data = english_saved if isinstance(english_saved, dict) and str(english_saved.get("biography") or "").strip() else None
        if english_data is None:
            try:
                english_data = client._get("/person/%d" % number, {"language": "en-US"}) or {}
            except Exception:
                english_data = {}
                english_failed = True
        if isinstance(english_data, dict):
            biography = str(english_data.get("biography") or "").strip()
            # Keep English cached separately so switching app language is fast.
            if english_data.get("id") and not (isinstance(english_saved, dict) and str(english_saved.get("biography") or "").strip()):
                en_record = {
                    "id": str(english_data.get("id")),
                    "name": str(english_data.get("name") or ""),
                    "biography": biography[:1200],
                    "birthday": str(english_data.get("birthday") or ""),
                    "deathday": str(english_data.get("deathday") or ""),
                    "place_of_birth": str(english_data.get("place_of_birth") or ""),
                    "known_for_department": str(english_data.get("known_for_department") or ""),
                    "profile_path": str(english_data.get("profile_path") or ""),
                }
                try:
                    persistent_cache_set(english_key, "actor_spotlight", en_record,
                                         (7 * 24 * 3600) if biography else (24 * 3600))
                except Exception:
                    pass
            # If local details failed too, English can supply the basic facts.
            if not data.get("id") and english_data.get("id"):
                data = english_data
    if not data.get("id"):
        return {}
    record = {
        "id": str(data.get("id")),
        "name": str(data.get("name") or ""),
        "biography": biography[:1200],
        "birthday": str(data.get("birthday") or ""),
        "deathday": str(data.get("deathday") or ""),
        "place_of_birth": str(data.get("place_of_birth") or ""),
        "known_for_department": str(data.get("known_for_department") or ""),
        "profile_path": str(data.get("profile_path") or ""),
        "_bio_fallback_checked": language != "en-US",
    }
    try:
        # A successful biography lives one week.  Missing details are retried
        # tomorrow (sooner after a temporary English TMDb request failure).
        ttl = 7 * 24 * 3600 if biography else (600 if english_failed else 24 * 3600)
        persistent_cache_set(key, "actor_spotlight", record, ttl)
    except Exception:
        pass
    return record


def _clean_role(value):
    text = " ".join(str(value or "").split())
    return _shorten(text, 26) if text else ""


def load_roles(person_id, kind):
    """Character names of one person by TMDb id / title key, cached 24 h.

    Same languages as the actor search (TMDb language, English, Arabic), so a
    provider title in any of them finds its credit.  Worker threads only.
    """
    number = _person_number(person_id)
    if not number:
        return {}
    from .actor_match import title_key, loose_key, _languages
    try:
        client = TMDbClient()
        languages = _languages(client)
    except Exception:
        return {}
    endpoint = "/person/%d/%s" % (number, "tv_credits" if kind == "series" else "movie_credits")
    key = stable_cache_key("actor_spotlight_roles_v2", endpoint, ",".join(languages))
    try:
        saved = persistent_cache_get(key)
        if isinstance(saved, dict) and saved.get("count"):
            return saved
    except Exception:
        pass
    payloads = [None] * len(languages)

    def fetch(index, language):
        try:
            payloads[index] = client._get(endpoint, {"language": language}) or {}
        except Exception:
            payloads[index] = None

    workers = []
    for index, language in enumerate(languages):
        worker = threading.Thread(target=fetch, args=(index, language), name="TiviActorRoles")
        worker.daemon = True
        worker.start()
        workers.append(worker)
    deadline = time.time() + 15
    for worker in workers:
        worker.join(max(0.1, deadline - time.time()))
    ids, keys, loose, seen = {}, {}, {}, set()
    title_ids = {}
    for payload in payloads:
        if not isinstance(payload, dict):
            continue
        for credit in payload.get("cast") or []:
            if not isinstance(credit, dict):
                continue
            credit_id = str(credit.get("id") or "").strip()
            if credit_id:
                seen.add(credit_id)
            # Credits IDs are verified TMDb identities, unlike provider stream IDs.
            credit_year = (str(credit.get("release_date") or credit.get("first_air_date") or "")[:4])
            for field in ("title", "original_title", "name", "original_name"):
                title = title_key(credit.get(field))
                if title and credit_id:
                    identity = title + "|" + credit_year
                    prev = title_ids.get(identity)
                    if prev is None:
                        title_ids[identity] = credit_id
                    elif prev != credit_id:
                        title_ids[identity] = ""  # ambiguous remake: no wrong logo
            role = _clean_role(credit.get("character")) or ids.get(credit_id, "")
            if not role:
                continue
            if credit_id:
                ids.setdefault(credit_id, role)
            for field in ("title", "original_title", "name", "original_name"):
                title = title_key(credit.get(field))
                if not title:
                    continue
                keys.setdefault(title, role)
                compact = loose_key(title)
                if len(compact) >= 3:
                    loose.setdefault(compact, role)
    result = {"count": len(seen), "ids": ids, "keys": keys, "loose": loose,
              "credit_ids": list(seen), "title_ids": title_ids}
    if seen:
        try:
            persistent_cache_set(key, "actor_spotlight", result, 24 * 3600)
        except Exception:
            pass
    return result


def verified_credit_id(roles, row):
    """Return only a TMDb ID proven to belong to this actor and exact title/year."""
    if not isinstance(roles, dict) or not isinstance(row, dict):
        return ""
    from .actor_match import title_key, _row_tmdb_id
    credits = roles.get("credit_ids") or []
    item_id = _row_tmdb_id(row)
    if item_id and item_id in credits:
        return item_id
    title_ids = roles.get("title_ids") or {}
    from .poster_logo_identity import movie_year
    year = movie_year(row)
    if not year:
        # Missing year: never risk attributing a same-name film to the wrong remake.
        return ""
    for field in ("name", "title", "original_title", "o_name"):
        title = title_key(row.get(field))
        if title:
            match = title_ids.get(title + "|" + year)
            if match:
                return match
    return ""


def build_skin():
    rows = [
        '<screen name="ActorSpotlightScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05070B">',
        '<eLabel position="0,0" size="1920,1080" backgroundColor="#05070B" zPosition="0" />',
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="off" scale="1" zPosition="1" />' % os.path.join(ART, "spotlight_bg.jpg"),

        # ---- actor panel -------------------------------------------------
        '<widget name="actorTag" position="104,58" size="440,34" font="Bold;21" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorPhoto" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="4" />' % (
            PHOTO_X, PHOTO_Y, PHOTO_W, PHOTO_H, os.path.join(ART, "actor_default.png")),
        '<ePixmap position="64,120" size="264,396" pixmap="%s" alphatest="blend" scale="1" zPosition="6" />' % os.path.join(ART, "actor_frame.png"),
        '<widget name="actorCount" position="352,276" size="196,104" font="Bold;84" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorCountLabel" position="356,384" size="192,58" font="Regular;21" foregroundColor="#F7F4EC" transparent="1" zPosition="5" />',
        '<eLabel position="356,450" size="56,2" backgroundColor="%s" zPosition="5" />' % GOLD,
        '<widget name="actorCredits" position="356,462" size="192,54" font="Regular;18" foregroundColor="#C7D5E0" transparent="1" zPosition="5" />',
        '<widget name="actorName" position="64,538" size="484,64" font="Bold;44" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorNameSmall" position="64,538" size="484,64" font="Bold;31" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorRole" position="64,606" size="484,28" font="Regular;19" foregroundColor="#C7D5E0" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorBornTag" position="64,652" size="118,30" font="Bold;16" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorBorn" position="186,652" size="362,30" font="Regular;21" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorFromTag" position="64,688" size="118,30" font="Bold;16" foregroundColor="%s" transparent="1" valign="center" noWrap="1" zPosition="5" />' % GOLD,
        '<widget name="actorFrom" position="186,688" size="362,30" font="Regular;21" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="actorBio" position="64,738" size="484,190" font="Regular;20" foregroundColor="#C7D5E0" transparent="1" zPosition="5" />',
        '<widget name="status" position="64,946" size="484,28" font="Regular;18" foregroundColor="#E5C478" transparent="1" valign="center" noWrap="1" zPosition="5" />',

        # ---- selected title ----------------------------------------------
        '<widget name="heroTitle" position="648,50" size="900,56" font="Bold;38" foregroundColor="#F7F4EC" transparent="1" valign="center" noWrap="1" zPosition="5" />',
    ]
    pill_fonts = {"genreCategories": 18, "genreQuality": 17}
    for name, width, inset, style in GENRE_PILL_SPECS:
        rows.append('<widget name="%sBg" position="%d,%d" size="%d,38" pixmap="%s" alphatest="blend" zPosition="8" />' % (
            name, PILL_X, PILL_Y, width, os.path.join(PLUGIN_PATH, "skins", "genre", "genre_pill_%s.png" % style)))
        rows.append('<widget name="%s" position="%d,%d" size="%d,38" font="Regular;%d" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" noWrap="1" zPosition="9" />' % (
            name, PILL_X + inset, PILL_Y, width - inset - (5 if inset <= 5 else 8), pill_fonts.get(name, 19)))
    rows.extend([
        '<widget name="heroPlot" position="648,166" size="900,64" font="Regular;21" foregroundColor="#E0E8F0" transparent="1" zPosition="5" />',
        '<ePixmap position="1566,50" size="294,62" pixmap="%s" alphatest="blend" zPosition="5" />' % os.path.join(PLUGIN_PATH, "skins", "genre", "genre_page_counter_gold_r136.png"),
        '<widget name="page" position="1566,62" size="294,38" font="Bold;25" foregroundColor="#FFE1A0" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />',
        '<widget name="heading" position="1566,122" size="294,34" font="Bold;22" foregroundColor="#F8D891" transparent="1" halign="center" valign="center" noWrap="1" zPosition="5" />',
        '<widget name="selector" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="10" />' % (
            X[0] - FOCUS_PAD, Y[0] - FOCUS_PAD, POSTER_W + 2 * FOCUS_PAD, POSTER_H + 2 * FOCUS_PAD, os.path.join(ART, "spot_focus.png")),

        # ---- remote legend -----------------------------------------------
        '<ePixmap position="20,1027" size="1880,52" pixmap="%s" alphatest="blend" scale="1" zPosition="35" />' % os.path.join(ART, "spot_toolbar.png"),
        '<widget name="footerSortValue" position="582,1054" size="170,20" font="Regular;15" foregroundColor="#C6CFDA" backgroundColor="#00000000" transparent="1" halign="left" valign="center" noWrap="1" zPosition="38" />',

        # ---- GENRE widgets this page does not show (names stay valid) ----
        '<widget name="heroBackdrop" position="0,0" size="1,1" alphatest="blend" />',
        '<widget name="heroLogo" position="0,0" size="1,1" alphatest="blend" />',
        '<widget name="packageLogo" position="0,0" size="1,1" alphatest="blend" />',
    ])
    for name in ("heroInfo", "heroMeta", "subheading", "footerServerName",
                 "redHint", "greenHint", "yellowHint", "blueHint", "menuHint"):
        rows.append('<widget name="%s" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % name)
    for index in range(10):
        rows.append('<widget name="nav%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % index)
    for index in range(8):
        rows.append('<widget name="genre%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % index)

    shell = os.path.join(ART, "spot_poster_shell.png")
    for slot in range(BASE_SLOTS):
        if slot >= PAGE:
            rows.extend([
                '<widget name="poster%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
                '<widget name="shell%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
                '<widget name="title%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % slot,
                '<widget name="meta%d" position="0,0" size="1,1" font="Regular;1" transparent="1" />' % slot,
                '<widget name="spotLogo%d" position="0,0" size="1,1" alphatest="blend" />' % slot,
            ])
            continue
        xpos, ypos = X[slot % COLS], Y[slot // COLS]
        rows.extend([
            '<widget name="poster%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="4" />' % (
                slot, xpos, ypos, POSTER_W, POSTER_H, POSTER_PLACEHOLDER),
            '<widget name="shell%d" position="%d,%d" size="%d,%d" pixmap="%s" alphatest="blend" scale="1" zPosition="5" />' % (
                slot, xpos, ypos, POSTER_W, POSTER_H, shell),
            '<widget name="title%d" position="%d,%d" size="%d,34" font="Bold;17" foregroundColor="#F7F4EC" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, xpos - 10, ypos + POSTER_H + 8, POSTER_W + 20),
            '<widget name="spotLogo%d" position="%d,%d" size="%d,%d" alphatest="blend" scale="1" zPosition="8" />' % (
                slot, xpos - 10, ypos + POSTER_H + 8, POSTER_W + 20, LOGO_H),
            '<widget name="meta%d" position="%d,%d" size="%d,24" font="Regular;15" foregroundColor="#C7D5E0" transparent="1" halign="center" valign="center" noWrap="1" zPosition="7" />' % (
                slot, xpos - 10, ypos + POSTER_H + 46, POSTER_W + 20),
        ])
    rows.append('</screen>')
    return scale_skin("\n".join(rows))


class ActorSpotlightScreen(LocalizedStoryMixin, StandaloneGenreScreen):
    """Actor results: portrait panel plus 12 large posters per page."""

    _PAGE_SOURCE_PREFIX = "actor_spotlight_"
    _CARD_SIZE = (POSTER_W, POSTER_H)     # read by the GENRE poster decoder
    skin = build_skin()

    def __init__(self, session, source, initial_kind="vod", initial_category_id=""):
        StandaloneGenreScreen.__init__(self, session, source, initial_kind, initial_category_id)
        person = self.source.get("_actor_search_person")
        self._spot_person = dict(person) if isinstance(person, dict) else {}
        self._spot_person_id = str(self._spot_person.get("id") or "").strip()
        self._spot_name = str(self.source.get("_actor_search_name") or
                              self._spot_person.get("name") or "").strip()
        self._spot_background_lookup = self.source.pop('_actor_background_lookup', None)
        self._spot_scan_reply = None
        self._spot_scan_finished = False
        self._spot_scan_error = False
        self._spot_scan_pending = callable(self._spot_background_lookup)
        self._spot_scan_lock = threading.Lock()
        self._spot_scan_timer = eTimer()
        self._spot_scan_timer.callback.append(self._spot_poll_scan)
        self.onClose.append(self._spot_scan_timer.stop)
        self._spot_roles = {}
        self._spot_credit_total = 0
        self._spot_photo_url = ""
        self._spot_photo_loader = None
        self._spot_logo_tokens = {}
        self._spot_logo_jobs = []
        self._spot_logo_decoders = {}
        self._spot_logo_page_key = None
        for slot in range(BASE_SLOTS):
            self["spotLogo%d" % slot] = Pixmap()
            self["spotLogo%d" % slot].hide()
        self.onClose.append(self._spot_close_logos)
        self["actorTag"] = Label(_t("ACTOR"))
        self["actorPhoto"] = Pixmap()
        self["actorCount"] = Label("")
        self["actorCountLabel"] = Label("")
        self["actorCredits"] = Label("")
        self["actorName"] = DirectionalLabel("")
        self["actorNameSmall"] = DirectionalLabel("")
        self["actorRole"] = Label("")
        self["actorBornTag"] = Label("")
        self["actorBorn"] = Label("")
        self["actorFromTag"] = Label("")
        self["actorFrom"] = Label("")
        self["actorBio"] = SynopsisLabel("")
        for slot in range(PAGE, BASE_SLOTS):
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        # Bound method on purpose: OpenATV exec()s non-method entries.
        self.onLayoutFinish.append(self._spot_begin)
        self.onLayoutFinish.append(self._spot_start_scan)

    def _spot_start_scan(self):
        lookup = self._spot_background_lookup
        self._spot_background_lookup = None
        if not callable(lookup) or self._closed:
            return
        self['status'].setText(tr('Searching...'))
        def send(rows, done=False):
            if self._closed:
                return
            with self._spot_scan_lock:
                # Replace stale partial snapshots; latest contains all matches.
                self._spot_scan_reply = (list(rows or []), done)
        def worker():
            try:
                lookup(send, lambda: bool(self._closed))
            except Exception as exc:
                print('[TiviMateE2] Actor background scan: %s' % exc)
            finally:
                with self._spot_scan_lock:
                    self._spot_scan_finished = True
        thread = threading.Thread(target=worker, name='TiviMateActorFastLookup')
        thread.daemon = True
        thread.start()
        self._spot_scan_timer.start(200, True)

    def _spot_poll_scan(self):
        if self._closed:
            return
        with self._spot_scan_lock:
            reply = self._spot_scan_reply
            self._spot_scan_reply = None
            finished = self._spot_scan_finished
        if reply is not None:
            rows, done = reply
            self._spot_apply_scan(rows)
            if done:
                self._spot_scan_pending = False
                self._spot_scan_error = (done == 'error')
        if finished:
            self._spot_scan_pending = False
        if self._spot_scan_pending:
            self['status'].setText(tr('Searching...'))
        elif self._spot_scan_error:
            self['status'].setText(tr('Actor search temporarily unavailable.'))
        elif not self.genre_items:
            self['status'].setText(tr('No matching titles in enabled packages.'))
        else:
            self['status'].setText('')
        if not finished:
            self._spot_scan_timer.start(200, True)

    @staticmethod
    def _spot_key_text(value):
        try:
            return value.decode('utf-8', 'replace') if isinstance(value, bytes) else u'%s' % (value or u'')
        except Exception:
            return u''

    @staticmethod
    def _spot_row_key(item):
        if not isinstance(item, dict):
            return ('', '')
        sid = item.get('stream_id') or item.get('series_id') or item.get('vod_id') or item.get('id')
        if sid:
            return ('id', ActorSpotlightScreen._spot_key_text(sid))
        return ('name', ActorSpotlightScreen._spot_key_text(item.get('name') or item.get('title')),
                ActorSpotlightScreen._spot_key_text(item.get('_source_category_id') or item.get('category_id')))

    def _spot_apply_scan(self, rows):
        if self._closed:
            return
        entries = [dict(r) for r in (rows or []) if isinstance(r, dict)]
        old = list(self._poster_original_rows or [])
        if [self._spot_row_key(x) for x in old] == [self._spot_row_key(x) for x in entries]:
            return
        selected = self._selected_item() or {}
        selected_key = self._spot_row_key(selected)
        previous_index = self.index
        self.source['_actor_search_rows'] = list(entries)
        self._poster_original_rows = list(entries)
        self.genre_items = self._sort_poster_rows(entries)
        self.index = min(previous_index, max(0, len(self.genre_items) - 1))
        if selected:
            for index, record in enumerate(self.genre_items):
                if self._spot_row_key(record) == selected_key:
                    self.index = index
                    break
        # render checks the visible poster identities; it keeps all existing
        # image jobs alive when newly discovered matches are on another page.
        self.render()

    @staticmethod
    def _spot_release_key(item):
        """Real movie release (year, month, day), never IPTV addition timestamp.

        Keep this standalone for Python 2.7/3 and for cached rows that only
        expose a year in their title. No network, disk I/O or image requests.
        """
        if not isinstance(item, dict):
            return (0, 0, 0)
        info = item.get("info")
        sources = (item, info) if isinstance(info, dict) else (item,)
        fields = ("release_date", "releaseDate", "releasedate",
                  "released", "first_air_date", "year", "release_year")
        for source in sources:
            for field in fields:
                raw = source.get(field)
                if raw is None or raw == "":
                    continue
                text = ActorSpotlightScreen._spot_key_text(raw).strip()
                match = re.match(r"^((?:18|19|20|21)\d{2})(?:[-/\.]([0-1]?\d))?(?:[-/\.]([0-3]?\d))?", text)
                if not match:
                    continue
                year = int(match.group(1))
                month = int(match.group(2) or 0)
                day = int(match.group(3) or 0)
                if month > 12 or (day and (month == 0 or day > 31)):
                    continue
                return (year, month, day)
        # Many IPTV listings only provide "Film (2023) [4K]".
        title = ActorSpotlightScreen._spot_key_text(item.get("name") or item.get("title"))
        match = re.search(r"(?<!\d)((?:18|19|20|21)\d{2})(?!\d)", title)
        if match:
            return (int(match.group(1)), 0, 0)
        return (0, 0, 0)

    def _sort_poster_rows(self, rows):
        # 'date' in a filmography means theatrical release, not when IPTV
        # provider added the stream. Keep all copies and all other sort modes.
        rows = list(rows or [])
        if getattr(self, "_poster_sort_mode", "date") != "date":
            return StandaloneGenreScreen._sort_poster_rows(self, rows)
        from .actor_match import title_key
        rows.sort(key=lambda item: title_key((item or {}).get("name") or
                                              (item or {}).get("title") or ""))
        rows.sort(key=self._spot_release_key, reverse=True)
        return rows

    def _refreshFooterSortValue(self):
        StandaloneGenreScreen._refreshFooterSortValue(self)
        if getattr(self, "_poster_sort_mode", "date") == "date":
            try:
                label = {"ar": u"الإصدار", "fr": "Sortie", "tr": u"Çıkış"}.get(_language(), "Release")
                self["footerSortValue"].setText(label)
            except Exception:
                pass

    # ------------------------------------------------------------ actor panel
    def _spot_begin(self):
        try:
            self._spot_set_name(self._spot_name)
            self._spot_update_counts()
        except Exception:
            pass
        self._spot_request_photo(self._spot_person.get("profile_path"))
        self._spot_load_person()

    def _spot_set_name(self, name):
        name = " ".join(str(name or "").split())
        long_name = len(name) > 17
        self["actorName"].setText("" if long_name else name)
        self["actorNameSmall"].setText(_shorten(name, 27) if long_name else "")

    def _spot_update_counts(self):
        try:
            total = len(self._poster_original_rows or self.genre_items or [])
            series = self.kind == "series"
            if total == 1:
                label = "TV show on\nthis server" if series else "movie on\nthis server"
            else:
                label = "TV shows on\nthis server" if series else "movies on\nthis server"
            self["actorCount"].setText(str(total) if total else "")
            self["actorCountLabel"].setText(_t(label) if total else "")
            credits = int(self._spot_credit_total or 0)
            # The current Details title is left out of the results, so only a
            # larger TMDb total is a meaningful "out of".
            self["actorCredits"].setText(
                (_t("out of %d\nTMDb credits") % credits) if total and credits > total else "")
        except Exception:
            pass

    def _spot_request_photo(self, profile_path):
        path = str(profile_path or "").strip()
        if path.startswith("http"):
            url = path
        elif path.startswith("/"):
            url = "https://image.tmdb.org/t/p/w342" + path
        else:
            return
        if url == self._spot_photo_url or self._closed:
            return
        self._spot_photo_url = url
        try:
            fetch_artwork(url, "actor", dict(self.source or {}), self._spot_photo_ready,
                          self._spot_photo_failed, self._post_to_gui)
        except Exception:
            pass

    def _spot_photo_failed(self, _path=None):
        """No portrait: the neutral default from the skin stays visible."""
        return

    def _spot_photo_ready(self, local):
        if getattr(self, "_closed", True) or not local or not os.path.isfile(local):
            return
        loader = ePicLoad()
        self._spot_photo_loader = loader

        def ready(_info=None, current=loader):
            try:
                if getattr(self, "_closed", True) or self._spot_photo_loader is not current:
                    return
                pointer = current.getData()
                widget = self["actorPhoto"]
                if pointer and widget.instance:
                    widget.instance.setPixmap(pointer)
                    widget.show()
            except Exception:
                pass

        try:
            connect_picture_data(loader, ready, self, oneshot=True)
            width, height = scale_size(PHOTO_W, PHOTO_H)
            loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(local)
        except Exception:
            pass

    def _spot_load_person(self):
        person_id = self._spot_person_id
        kind = self.kind
        if not person_id:
            return

        def worker():
            try:
                info = load_person(person_id)
            except Exception:
                info = {}
            if info and not getattr(self, "_closed", True):
                self._post_to_gui(self._spot_apply_person, info)
            try:
                roles = load_roles(person_id, kind)
            except Exception:
                roles = {}
            if roles and not getattr(self, "_closed", True):
                self._post_to_gui(self._spot_apply_roles, roles)

        thread = threading.Thread(target=worker, name="TiviMateActorSpotlight")
        thread.daemon = True
        thread.start()

    def _spot_apply_person(self, info):
        if getattr(self, "_closed", True) or not isinstance(info, dict):
            return
        try:
            self["actorRole"].setText(department_line(info.get("known_for_department")))
            born = birth_line(info.get("birthday"), info.get("deathday"))
            self["actorBornTag"].setText(_t("BORN") if born else "")
            self["actorBorn"].setText(born)
            place = birthplace_line(info.get("place_of_birth"))
            self["actorFromTag"].setText(_t("FROM") if place else "")
            self["actorFrom"].setText(place)
            self["actorBio"].setText(_shorten(info.get("biography") or _bio_missing_text(), 260))
        except Exception:
            pass
        if not self._spot_photo_url:
            self._spot_request_photo(info.get("profile_path"))

    def _spot_apply_roles(self, roles):
        if getattr(self, "_closed", True) or not isinstance(roles, dict):
            return
        self._spot_roles = roles
        try:
            self._spot_credit_total = int(roles.get("count") or 0)
        except Exception:
            self._spot_credit_total = 0
        self._spot_update_counts()
        self._spot_request_logos()
        self._spot_story_refresh()

    def _spot_caption(self, item):
        # Show the same release year used by the actor's filmography sort.
        year_number = self._spot_release_key(item)[0]
        year = str(year_number) if year_number else ""
        rating = str(item.get("rating") or item.get("rating_5based") or
                           item.get("vote_average") or "").strip()
        second = (u"★ " + rating[:4]) if rating and rating not in ("0", "0.0") else ""
        return u" · ".join(part for part in (year, second) if part)

    def _spot_story_refresh(self):
        item = self._selected_item() or {}
        if not item or not isinstance(item, dict):
            return
        verified = None
        if getattr(self, '_spot_roles', None):
            try:
                verified = verified_credit_id(self._spot_roles, item)
            except Exception:
                pass
        self._story_prepare(item, kind=self.kind, verified_id=verified, limit=200)

    # ------------------------------------------------------ title clearlogos
    def _spot_close_logos(self):
        for job in getattr(self, "_spot_logo_jobs", ()):
            try:
                job.cancel()
            except Exception:
                pass
        self._spot_logo_jobs = []
        self._spot_logo_tokens.clear()
        self._spot_logo_decoders.clear()

    def _spot_request_logos(self):
        # Identical title clearlogos for films and TV series; keep readable captions as fallback.
        if self.kind not in ("vod", "series") or getattr(self, "_closed", True):
            return
        if not self._spot_roles or not self.genre_items:
            return
        for slot in range(PAGE):
            index = self.page_start + slot
            if index >= len(self.genre_items):
                continue
            row = self.genre_items[index]
            if not isinstance(row, dict):
                continue
            media_id = verified_credit_id(self._spot_roles, row)
            if not media_id:
                continue
            token = (self._generation, index, media_id)
            if self._spot_logo_tokens.get(slot) == token:
                continue
            self._spot_logo_tokens[slot] = token
            title = str(row.get("name") or row.get("title") or "")
            snap = dict(row)
            try:
                from .title_logo_ultra_bridge import cached_identity_logo
                cached = cached_identity_logo(self.kind, media_id, (LOGO_W, LOGO_H), title, snap, snap)
            except Exception:
                cached = None
            if cached and os.path.isfile(cached):
                self._spot_show_logo(slot, token, cached)
                continue
            def worker(current_slot=slot, current_token=token, item=snap,
                       ident=media_id, name=title):
                try:
                    from .title_logo_ultra_bridge import resolve_title_logo
                    def obsolete():
                        return (getattr(self, "_closed", True) or
                                self._spot_logo_tokens.get(current_slot) != current_token)
                    if obsolete():
                        return
                    image = resolve_title_logo(TMDbClient(), self.kind, ident, title=name,
                                               item=item, canvas=(LOGO_W, LOGO_H),
                                               cancelled=obsolete)
                    if image and not obsolete():
                        self._post_to_gui(self._spot_show_logo, current_slot, current_token, image)
                except Exception:
                    pass  # readable movie/series title remains the default fallback
            try:
                self._spot_logo_jobs.append(_SPOT_LOGO_POOL.submit(worker))
            except Exception:
                self._spot_logo_tokens.pop(slot, None)

    def _spot_show_logo(self, slot, token, path):
        if (getattr(self, "_closed", True) or
                self._spot_logo_tokens.get(slot) != token or
                not os.path.isfile(path)):
            return
        widget = self["spotLogo%d" % slot]
        # Alpha-preserving renderer on old VTi, pure/EGAMI and Python3.
        try:
            from .transparent_pixmap import show_widget
            if show_widget(widget, path, align="center"):
                self["title%d" % slot].hide()
                return
        except Exception:
            pass
        # A failed PNG paint leaves the text visible instead of a black box.

    # ------------------------------------------- GENRE behaviour not used here
    def _adjust_movie_logo_size(self):
        return

    def _request_hero_artwork(self, token, url, category, widget, origin="provider"):
        # The stage belongs to the actor: no film backdrop or clearlogo.
        return

    def _show_hero_image(self, token, name, path):
        return

    def _set_hero_logo_state(self, active):
        self._hero_logo_active = False
        try:
            self["heroTitle"].setText(visible_title(getattr(self, "_hero_plain_title", ""), 44))
        except Exception:
            pass

    def open_poster_server(self):
        # These results belong to the server they were searched on.
        return

    def filter_poster_server(self):
        return

    # ------------------------------------------------------------- hero text
    def _set_hero_text(self, info):
        StandaloneGenreScreen._set_hero_text(self, info)
        badges = {}
        try:
            sources = getattr(self, "_hero_text_sources", {}) or {}
            item = self._selected_item() or {}
            provider = sources.get("provider") or {}
            catalog = sources.get("catalog") or {}
            verified = sources.get("tmdb_verified") or {}
            tmdb = sources.get("tmdb") or {}
            year_value, _genres = _year_genre_from_sources([info, provider, item, catalog])
            ordered = (provider, item, verified, tmdb, catalog)
            badges = {
                "genreYear": year_value or str(info.get("year") or "").strip()[:4],
                "genreCategories": _actual_media_genre(verified, tmdb, sources.get("tmdb_search") or {},
                                                       provider, info, item, catalog),
                "genreRating": _genre_pill_score(extract_rating(info, verified, tmdb, item)),
                "genreDuration": extract_duration(info, provider, item, catalog),
                "genreLanguage": _genre_pill_language(*ordered),
                "genreAge": _genre_pill_age(*ordered),
                "genreQuality": extract_resolution(item, catalog, provider),
            }
        except Exception:
            badges = {}
        self._render_genre_metadata_pills(badges)
        try:
            self["heroMeta"].setText("")
            self["heroPlot"].setText(_shorten(info.get("description"), 200))
            self._story_reapply()
        except Exception:
            pass

    def _render_genre_metadata_pills(self, values):
        xpos = PILL_X
        for name, width, inset, _style in GENRE_PILL_SPECS:
            text = str((values or {}).get(name) or "").strip()
            if name == "genreCategories" and len(text) > 30:
                text = text[:28].rstrip(u" ,،") + u"…"
            widget = self[name]
            background = self[name + "Bg"]
            widget.setText(text)
            if not text or xpos + width > PILL_LIMIT:
                widget.hide()
                background.hide()
                continue
            try:
                background.instance.move(ePoint(sx(xpos), sy(PILL_Y)))
                widget.instance.move(ePoint(sx(xpos + inset), sy(PILL_Y)))
                background.show()
                widget.show()
            except Exception:
                widget.hide()
                background.hide()
                continue
            xpos += width + 8

    # ------------------------------------------------------------------ grid
    def _set_placeholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(POSTER_PLACEHOLDER)
        except Exception:
            pass

    def _render_empty(self, message):
        try:
            self._hero_timer.stop()
        except Exception:
            pass
        self._hero_token = None
        self._hero_text_token = None
        self._hero_text_sources = {}
        self._hero_plain_title = ""
        self._hero_logo_active = False
        self["heading"].setText(tr("TV SHOWS") if self.kind == "series" else tr("MOVIES"))
        self["page"].setText("1 / 1")
        self["status"].setText(message)
        self["heroTitle"].setText("")
        self["heroMeta"].setText("")
        self["heroPlot"].setText("")
        for name, _width, _inset, _style in GENRE_PILL_SPECS:
            self[name].setText("")
            self[name].hide()
            self[name + "Bg"].hide()
        self._rendered_page_key = None
        for slot in range(BASE_SLOTS):
            self["title%d" % slot].setText("")
            self["meta%d" % slot].setText("")
            self["spotLogo%d" % slot].hide()
            self["title%d" % slot].show()
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        try:
            self["selector"].hide()
        except Exception:
            pass

    def render(self):
        total = len(self.genre_items)
        pages = max(1, (total + PAGE - 1) // PAGE)
        self.page_start = (self.index // PAGE) * PAGE if total else 0
        self["heading"].setText(tr("TV SHOWS") if self.kind == "series" else tr("MOVIES"))
        self["page"].setText("%d / %d" % (self.page_start // PAGE + 1, pages))
        self._spot_update_counts()
        selected = self._selected_item() or {}
        self._schedule_hero()
        self._update_hero_info(self._hero_token, {
            "title": str(selected.get("name") or selected.get("title") or ""),
            "year": str(selected.get("year") or selected.get("release_date") or "")[:4],
            "rating": str(selected.get("rating") or selected.get("vote_average") or ""),
            "description": str(selected.get("plot") or selected.get("description") or
                               selected.get("overview") or selected.get("storyline") or
                               selected.get("plot_outline") or "").strip(),
            # The virtual category is the actor's name, never a film genre.
            "category": "",
        }, "catalog")

        self._spot_story_refresh()

        # Moving inside a page only moves the focus ring (no poster reloads).
        visible = self.genre_items[self.page_start:self.page_start + PAGE]
        page_key = (self._generation, self.page_start,
                    tuple(self._spot_row_key(item) for item in visible))
        if page_key != self._rendered_page_key:
            self._spot_close_logos()
            self._cancel_poster_jobs()
            self._rendered_page_key = page_key
            self._poster_resolved_priority.clear()
            self._poster_tmdb_started.clear()
            for slot in range(PAGE):
                item_index = self.page_start + slot
                item = self.genre_items[item_index] if item_index < total else None
                if not isinstance(item, dict):
                    self._poster_tokens.pop(slot, None)
                    self["poster%d" % slot].hide()
                    self["shell%d" % slot].hide()
                    self["title%d" % slot].setText("")
                    self["meta%d" % slot].setText("")
                    self["spotLogo%d" % slot].hide()
                    self["title%d" % slot].show()
                    continue
                self["poster%d" % slot].show()
                self["shell%d" % slot].show()
                self["spotLogo%d" % slot].hide()
                self["title%d" % slot].show()
                self["title%d" % slot].setText(
                    visible_title(str(item.get("name") or item.get("title") or ""), 19))
                self["meta%d" % slot].setText(self._spot_caption(item))
                self._set_placeholder(slot)
                self._load_poster(slot, item, item_index)
            self._spot_request_logos()

        if total:
            slot = self.index - self.page_start
            self["selector"].instance.move(ePoint(sx(X[slot % COLS] - FOCUS_PAD),
                                                  sy(Y[slot // COLS] - FOCUS_PAD)))
            self["selector"].show()
        else:
            self["selector"].hide()

    # ------------------------------------------------------------ navigation
    def left(self):
        if self.genre_items and self.index % COLS:
            self.index -= 1
            self.render()

    def right(self):
        if (self.genre_items and self.index + 1 < len(self.genre_items)
                and self.index % COLS < COLS - 1):
            self.index += 1
            self.render()

    def up(self):
        if self.genre_items and self.index >= COLS:
            self.index -= COLS
            self.render()

    def down(self):
        if not self.genre_items:
            return
        last = len(self.genre_items) - 1
        if self.index + COLS <= last:
            self.index += COLS
            self.render()
        elif self.index // COLS < last // COLS:
            # A shorter last row: land on its final poster instead of stopping.
            self.index = last
            self.render()

    def page_up(self):
        if self.genre_items and self.index >= PAGE:
            self.index -= PAGE
            self.render()

    def page_down(self):
        if not self.genre_items:
            return
        last = len(self.genre_items) - 1
        if self.index // PAGE < last // PAGE:
            self.index = min(last, self.index + PAGE)
            self.render()

    # ------------------------------------------------------------ view styles
    def open_view_style_menu(self):
        from .view_style_picker import SpotlightViewPicker
        self.session.openWithCallback(self._view_style_chosen, SpotlightViewPicker,
                                      "actor", self.kind, True)

    def _view_style_chosen(self, choice=None):
        if choice == "spotlight":
            return      # already here
        return StandaloneGenreScreen._view_style_chosen(self, choice)
