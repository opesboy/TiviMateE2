# -*- coding: utf-8 -*-
"""Shared Recent Added source for Movies/Series pages and new-content notices.

Visible Recent Add keeps its 25 items; the watcher may scan up to 250
without changing the UI. The caller runs provider requests in a worker.
"""
import re
import time
import hashlib
import threading

_FEED_CACHE = {}
_FEED_GATES = {}
_FEED_LOCK = threading.Lock()
# Align RAM freshness with the durable Recent snapshot. A 120-second TTL
# triggered repeated full-provider scans while the saved view was still fresh.
_FEED_TTL = 600
_FEED_RETRY_UNTIL = {}


class RecentFeedCancelled(Exception):
    """The user left Recent; avoid starting any more provider requests."""
    pass


def _check_cancel(cancelled):
    if cancelled is not None and cancelled():
        raise RecentFeedCancelled()


def _sort_time(row):
    row = row or {}
    for field in ("added", "date_added", "added_at", "created_at", "timestamp", "last_modified"):
        raw = row.get(field)
        if raw is None or raw == "":
            continue
        try:
            value = int(float(str(raw).strip()))
            if value > 100000000000:
                value //= 1000
            if value > 0:
                return value
        except (ValueError, TypeError, OverflowError):
            pass
        for fmt, n in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%dT%H:%M:%S", 19), ("%Y-%m-%d", 10)):
            try:
                return int(time.mktime(time.strptime(str(raw)[:n], fmt)))
            except (ValueError, TypeError, OverflowError):
                pass
    return 0


def _category_id(row):
    """Normalize category identifiers exactly like the visible Recent page."""
    for field in ("category_id", "id", "genre_id", "group_id"):
        value = row.get(field)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _cache_key(source, kind, ids):
    src = source or {}
    # Never retain raw usernames, passwords or stream URLs in the RAM key.
    secret = "|".join(str(src.get(key) or "") for key in
                      ("type", "url", "path", "username", "password", "mac"))
    raw = "%s|%s|%s" % (secret, kind, "\x00".join(sorted(ids)))
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()


def _load_provider_items(source, kind, client, ids, limit, cancelled=None):
    media_type = str((source or {}).get("type") or "").lower()
    _check_cancel(cancelled)
    merged = []
    if kind in ("vod", "series") and media_type in ("xtream", "m3u"):
        # Single provider-wide call; M3U must not reload its playlist per
        # category.  Filter the result locally by the enabled package IDs.
        all_rows = client.streams(kind, "") or []
        _check_cancel(cancelled)
        allowed = set(ids)
        for pos, item in enumerate(all_rows):
            if (pos & 255) == 0:
                _check_cancel(cancelled)
            if not isinstance(item, dict):
                continue
            cid = str(item.get("category_id") or item.get("categoryId") or
                      item.get("genre_id") or item.get("group_id") or
                      item.get("group") or "").strip()
            if cid in allowed:
                merged.append(item)
    elif kind in ("vod", "series") and media_type == "stalker" and hasattr(client, "recent_media_filtered"):
        merged = list(client.recent_media_filtered(kind, ids, limit) or [])
        _check_cancel(cancelled)
    else:
        for cid in ids:
            _check_cancel(cancelled)
            rows = client.streams(kind, cid) or []
            _check_cancel(cancelled)
            merged.extend(row for row in rows if isinstance(row, dict))

    # Some Xtream portals return a provider-wide list with category keys that
    # cannot be matched to the actual package IDs. A nonempty list is not a
    # successful scan if none of its rows belongs to an enabled package.
    allowed_categories = set(ids)
    provider_has_allowed = any(
        isinstance(item, dict) and str(
            item.get("category_id") or item.get("categoryId") or
            item.get("genre_id") or item.get("group_id") or
            item.get("group") or "").strip() in allowed_categories
        for item in merged
    ) if media_type == "xtream" else bool(merged)
    if (not merged or not provider_has_allowed) and media_type in ("xtream", "stalker") and kind in ("vod", "series"):
        # Some portals expose the category only through per-package endpoints.
        # An eight-package fallback is NOT a correct all-packages Recent feed:
        # it silently labels an arbitrary subset as the newest content.
        # Recover every enabled package, or report an incomplete scan instead.
        try:
            from .filters import peek_category_streams_cache, get_category_streams_batch
            recovered = []
            missing = []
            for cid in ids:
                _check_cancel(cancelled)
                rows, _origin = peek_category_streams_cache(source, kind, cid)
                if rows:
                    for item in rows:
                        if isinstance(item, dict):
                            entry = dict(item)
                            entry["category_id"] = cid
                            recovered.append(entry)
                else:
                    missing.append(cid)
            if missing:
                # Small batches preserve the existing 3-worker cap while allowing
                # a blue/red package switch to stop the NEXT batch immediately.
                # The old unbounded batch queued every missing package in advance.
                for offset in range(0, len(missing), 3):
                    _check_cancel(cancelled)
                    batch = missing[offset:offset + 3]
                    fetched = get_category_streams_batch(
                        source, kind, client, batch,
                        use_cache=True, wait_for_server=True, max_workers=3)
                    _check_cancel(cancelled)
                    completed = {str(cid): (rows, origin) for cid, rows, origin in fetched}
                    if any(cid not in completed or
                           completed[cid][1] in ("loading", "error", "empty_cooldown")
                           for cid in batch):
                        raise RuntimeError("Recent Added catalogue is incomplete")
                    for cid in batch:
                        for item in completed[cid][0] or []:
                            if isinstance(item, dict):
                                entry = dict(item)
                                entry["category_id"] = cid
                                recovered.append(entry)
            merged = recovered
        except Exception:
            # Never label a partial or arbitrary package subset as the
            # most recently added across *all* permitted packages.
            raise

    _check_cancel(cancelled)
    ordered = []
    dedup = set()
    for pos, item in enumerate(merged):
        if (pos & 255) == 0:
            _check_cancel(cancelled)
        if not isinstance(item, dict):
            continue
        key = str(item.get("stream_id") or item.get("series_id") or
                  item.get("vod_id") or item.get("id") or "")
        if not key:
            key = str(item.get("name") or item.get("title") or "")
        if not key or key in dedup:
            continue
        dedup.add(key)
        ordered.append((pos, dict(item)))
    # Keep server order for undated rows (same behavior as Recent Add).
    dated, undated = [], []
    for pos, item in ordered:
        stamp = _sort_time(item)
        if stamp:
            dated.append((stamp, pos, item))
        else:
            undated.append((pos, item))
    dated.sort(key=lambda row: (-row[0], row[1]))
    return ([item for _, _, item in dated] + [item for _, item in undated])[:limit]


def recent_added_items(source, kind, client, categories, limit=25, cancelled=None):
    """Return a common Recent feed for the UI and new-content watcher.

    The visible page continues to request 25; notifications request a wider
    window. The short in-memory cache also shares a provider-wide Xtream
    response between calls, without freezing the feed for the 15-min interval.
    Errors propagate, and empty/error responses do not poison the cache.
    """
    limit = max(1, min(250, int(limit or 25)))
    categories = [row for row in (categories or []) if isinstance(row, dict)]
    ids = list(dict.fromkeys(_category_id(row) for row in categories))
    ids = [cid for cid in ids if cid]
    if not ids:
        return []
    cache_key = _cache_key(source, kind, ids)
    with _FEED_LOCK:
        gate = _FEED_GATES.setdefault(cache_key, threading.Lock())
    # Do not wait indefinitely behind an earlier scan after the user has
    # already selected another package. Python 2.7 supports acquire(False).
    # A second Recent screen must not wait forever behind a stalled
    # provider-wide scan. Display the last verified feed when available;
    # otherwise return a bounded retryable failure to its GUI worker.
    wait_deadline = time.time() + 3.0
    while not gate.acquire(False):
        _check_cancel(cancelled)
        with _FEED_LOCK:
            old = _FEED_CACHE.get(cache_key)
            if old and old[1] and old[2] >= limit:
                # The screen will refresh on the next visit. A stale snapshot
                # is still preferable to another blank Loading screen.
                return [dict(x) for x in old[1][:limit]]
        if time.time() >= wait_deadline:
            raise RuntimeError("Recent Added scan already in progress")
        time.sleep(0.12)
    try:
        _check_cancel(cancelled)
        with _FEED_LOCK:
            cached = _FEED_CACHE.get(cache_key)
            if cached and time.time() - cached[0] < _FEED_TTL and cached[2] >= limit:
                return [dict(x) for x in cached[1][:limit]]
            if _FEED_RETRY_UNTIL.get(cache_key, 0) > time.time():
                raise RuntimeError("Recent Added provider retry cooldown")
        # An Xtream/M3U provider-wide scan returns the whole catalogue anyway.
        # Save 200 ranked rows even when Home asked for only 25, so opening the
        # full Recent page does not trigger a SECOND identical provider scan.
        media_type = str((source or {}).get("type") or "").lower()
        scan_limit = max(200, limit) if media_type in ("xtream", "m3u") else limit
        try:
            rows = _load_provider_items(source, kind, client, ids, scan_limit,
                                        cancelled=cancelled)
            _check_cancel(cancelled)
        except RecentFeedCancelled:
            raise
        except Exception:
            with _FEED_LOCK:
                _FEED_RETRY_UNTIL[cache_key] = time.time() + 90.0
            raise
        with _FEED_LOCK:
            if rows:
                _FEED_CACHE[cache_key] = (time.time(), rows, scan_limit)
                _FEED_RETRY_UNTIL.pop(cache_key, None)
                for old_key, value in list(_FEED_CACHE.items()):
                    if time.time() - value[0] >= _FEED_TTL:
                        _FEED_CACHE.pop(old_key, None)
                if len(_FEED_CACHE) > 20:
                    for old_key, _ in sorted(_FEED_CACHE.items(), key=lambda kv: kv[1][0])[:-20]:
                        _FEED_CACHE.pop(old_key, None)
            else:
                # A disconnected or empty portal must not be rescanned on
                # every keypress/open; no empty response poisons a good cache.
                _FEED_RETRY_UNTIL[cache_key] = time.time() + 90.0
            if len(_FEED_RETRY_UNTIL) > 64:
                now = time.time()
                for key, until in list(_FEED_RETRY_UNTIL.items()):
                    if until <= now:
                        _FEED_RETRY_UNTIL.pop(key, None)
        return [dict(x) for x in rows[:limit]]
    finally:
        gate.release()
