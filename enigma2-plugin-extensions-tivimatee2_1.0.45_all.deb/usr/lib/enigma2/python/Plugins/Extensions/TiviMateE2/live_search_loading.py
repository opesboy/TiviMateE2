# -*- coding: utf-8 -*-
"""Live-only search strip, drawn inside the existing Live screen.
No separate eWindow: old image compositors can no longer paint a black box
behind the strip. Network/search workers and remote focus are unchanged.
"""
from __future__ import absolute_import
import os
import time
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import eTimer
from .display_scale import scale_skin

_ART = os.path.join(os.path.dirname(__file__), 'skins', 'loading') + os.sep
_SEARCH_ART = os.path.join(os.path.dirname(__file__), 'skins', 'search') + os.sep
_NAMES = ('liveSearchStrip', 'liveSearchSpin', 'liveSearchCaption', 'liveSearchQuery')


def _connect(timer, cb):
    try:
        return timer.timeout.connect(cb)
    except (AttributeError, TypeError):
        timer.callback.append(cb)


def add_live_search_skin(skin):
    # The parent skin is already scaled; scale only these new widgets.
    fragment = scale_skin(
        '<widget name="liveSearchStrip" pixmap="%slive_search_strip_alpha.png" '
        'position="578,949" size="764,74" scale="1" alphatest="blend" transparent="1" zPosition="90" />'
        '<widget name="liveSearchSpin" pixmap="%sspin_00.png" position="604,969" '
        'size="34,34" scale="1" alphatest="blend" transparent="1" zPosition="91" />'
        '<widget name="liveSearchCaption" position="650,963" size="400,46" '
        'font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#ff000000" '
        'transparent="1" valign="center" noWrap="1" zPosition="92" />'
        '<widget name="liveSearchQuery" position="1092,963" size="228,46" font="Regular;22" '
        'foregroundColor="#FFD66E" backgroundColor="#ff000000" transparent="1" '
        'valign="center" halign="center" noWrap="1" zPosition="92" />'
        % (_SEARCH_ART, _ART))
    return skin.replace('</screen>', fragment + '</screen>', 1)


class LiveSearchIndicator(object):
    def __init__(self, screen):
        self.screen = screen
        screen['liveSearchStrip'] = Pixmap()
        screen['liveSearchSpin'] = Pixmap()
        screen['liveSearchCaption'] = Label('Searching LIVE channels...')
        screen['liveSearchQuery'] = Label('')
        self.frame = 0
        self.since = 0
        self.active = False
        self.query = ''
        self.delay = eTimer()
        self.timer = eTimer()
        self.delay_conn = _connect(self.delay, self.start)
        self.timer_conn = _connect(self.timer, self.tick)
        self.hide()
        screen.onLayoutFinish.append(self.hide)
        screen.onClose.append(self.close)

    def hide(self):
        for name in _NAMES:
            try:
                self.screen[name].hide()
            except Exception:
                pass

    def request(self, query):
        self.stop()
        self.query = query
        self.active = True
        self.delay.start(220, True)

    def start(self):
        if not self.active:
            return
        try:
            query = self.query
            if isinstance(query, bytes):
                query = query.decode('utf-8', 'ignore')
            self.screen['liveSearchQuery'].setText((query or u'LIVE')[:18])
        except Exception:
            self.screen['liveSearchQuery'].setText('LIVE')
        self.since = time.time()
        self.frame = 0
        for name in _NAMES:
            try:
                self.screen[name].show()
            except Exception:
                pass
        self.tick()
        self.timer.start(70, False)

    def tick(self):
        if not self.active or time.time() - self.since > 25:
            self.stop()
            return
        try:
            self.screen['liveSearchSpin'].instance.setPixmapFromFile(_ART + ('spin_%02d.png' % self.frame))
        except Exception:
            pass
        self.frame = (self.frame + 1) % 16

    def stop(self):
        self.active = False
        self.delay.stop()
        self.timer.stop()
        self.hide()

    def close(self):
        self.stop()
        self.screen = None


def install_live_search(screen):
    screen._liveSearchIndicator = LiveSearchIndicator(screen)


def show_live_search(screen, query):
    try:
        screen._liveSearchIndicator.request(query)
    except Exception:
        pass


def hide_live_search(screen):
    try:
        screen._liveSearchIndicator.stop()
    except Exception:
        pass
