# -*- coding: utf-8 -*-
"""Discover search: TMDb discover (genre / country / year / rating / sort)
matched against the ACTIVE server's own catalogue.

Only titles that the server really has are returned, so every result is
playable.  NETWORK/CPU WORK ONLY - never call from the Enigma2 GUI thread.
Compatible with Python 2.7 and 3.x.
"""
from __future__ import absolute_import

import re
import threading
import time

try:
    _text = unicode  # noqa: F821  (Python 2)
except NameError:
    _text = str


def _u(value):
    if value is None:
        return u""
    if isinstance(value, bytes) and not isinstance(value, _text):
        return value.decode("utf-8", "replace")
    return _text(value)


# name, TMDb movie genre id, TMDb TV genre id (None = not available)
GENRES = (
    ("Action", 28, 10759), ("Adventure", 12, 10759), ("Animation", 16, 16),
    ("Comedy", 35, 35), ("Crime", 80, 80), ("Documentary", 99, 99),
    ("Drama", 18, 18), ("Family", 10751, 10751), ("Fantasy", 14, 10765),
    ("Horror", 27, None), ("Kids", None, 10762), ("Mystery", 9648, 9648),
    ("Romance", 10749, None), ("Sci-Fi", 878, 10765), ("Thriller", 53, None),
    ("History", 36, None), ("War", 10752, 10768), ("Music", 10402, None),
    ("Reality", None, 10764), ("Western", 37, 37),
)

COUNTRIES = (
    ("US", "United States"), ("GB", "United Kingdom"), ("ARABIC", "Arabic"),
    ("ASIA", "Asia"), ("CA", "Canada"), ("FR", "France"), ("DE", "Germany"),
)

# Region -> one or more TMDb discover filters (each is queried separately and
# merged, so no undocumented OR syntax is relied on).
_REGION_QUERIES = {
    "ARABIC": [("with_original_language", "ar")],
    "ASIA": [("with_original_language", code) for code in ("ko", "ja", "zh", "hi", "th")],
}


def region_queries(code):
    code = _u(code or u"")
    if not code:
        return [None]
    return _REGION_QUERIES.get(code, [("with_origin_country", code)])

DEFAULTS = {"kind": "vod", "sort": "popular", "rating": 0, "year": "",
            "genre": "", "country": ""}


def genres_for(kind):
    index = 2 if kind == "series" else 1
    return [(name, row[index]) for row in GENRES for name in (row[0],) if row[index]]


def active_count(filters):
    f = dict(DEFAULTS, **(filters or {}))
    return sum(1 for key in ("rating", "year", "genre", "country") if f.get(key)) + \
        (1 if f.get("sort") != "popular" else 0)


def describe(filters, translate=None):
    f = dict(DEFAULTS, **(filters or {}))
    t = translate or (lambda value: value)
    parts = []
    if f.get("genre"):
        parts.append(_u(t(_u(f["genre"]))))
    if f.get("country"):
        parts.append(_u(t(dict(COUNTRIES).get(f["country"], f["country"]))))
    if f.get("year"):
        parts.append({"2010s": "2010-2019", "2000s": "2000-2009", "old": "< 2000"}.get(f["year"], _u(f["year"])))
    if f.get("rating"):
        parts.append(u"%s+" % f["rating"])
    return u"  \u2022  ".join(parts) or _u(t(u"TV Shows" if f.get("kind") == "series" else u"Movies"))


# ---------------------------------------------------------------- matching --
_YEAR = re.compile(r"(?<!\d)(19[3-9]\d|20[0-4]\d)(?!\d)")
_NOISE = re.compile(
    u"\\b(?:4k|uhd|fhd|fullhd|hd|sd|hdr|dv|hevc|x265|x264|h264|h265|multi|dual|vip|"
    u"netflix|nf|amazon|amzn|prime|arabic|english|eng|sub|subs|dubbed|dub|"
    u"مدبلج|مترجم)\\b", re.U | re.I)


def title_key(value):
    text = _u(value).lower().replace(u"&", u" and ")
    text = re.sub(u"\\([^)]*\\)|\\[[^\\]]*\\]|\\{[^}]*\\}", u" ", text)
    # Provider prefixes like "AR: " / "EN | " / "TGP - ".
    text = re.sub(u"^\\s*[a-z0-9]{2,4}\\s*[:|\\-]\\s+", u" ", text)
    text = _YEAR.sub(u" ", text)
    text = _NOISE.sub(u" ", text)
    text = re.sub(u"[\\W_]+", u" ", text, flags=re.U)
    return u" ".join(text.split())


def _row_year(row):
    for key in ("year", "releaseDate", "release_date", "releasedate"):
        match = _YEAR.search(_u(row.get(key) or u""))
        if match:
            return int(match.group(1))
    found = _YEAR.findall(_u(row.get("name") or row.get("title") or u""))
    return int(found[-1]) if found else 0


def _row_tmdb(row):
    for key in ("tmdb_id", "tmdb", "_tmdb_id", "tmdbid"):
        value = _u(row.get(key) or u"").strip()
        if value.isdigit() and value != u"0":
            return value
    return u""


# ---------------------------------------------------------------- TMDb -------
def _discover_params(filters, kind):
    f = dict(DEFAULTS, **(filters or {}))
    movie = kind != "series"
    date_key = "primary_release_date" if movie else "first_air_date"
    params = {"include_adult": "false"}
    sort = f.get("sort") or "popular"
    if sort == "newest":
        params["sort_by"] = "%s.desc" % date_key
        params["%s.lte" % date_key] = time.strftime("%Y-%m-%d")
        params["vote_count.gte"] = 5
    elif sort == "top":
        params["sort_by"] = "vote_average.desc"
        params["vote_count.gte"] = 200
    else:
        params["sort_by"] = "popularity.desc"
    year = _u(f.get("year") or u"")
    if year == u"2010s":
        params["%s.gte" % date_key], params["%s.lte" % date_key] = "2010-01-01", "2019-12-31"
    elif year == u"2000s":
        params["%s.gte" % date_key], params["%s.lte" % date_key] = "2000-01-01", "2009-12-31"
    elif year == u"old":
        params["%s.lte" % date_key] = "1999-12-31"
    elif year.isdigit():
        params["primary_release_year" if movie else "first_air_date_year"] = int(year)
    if f.get("rating"):
        params["vote_average.gte"] = float(f["rating"])
        params.setdefault("vote_count.gte", 30)
    if f.get("genre"):
        ids = dict(genres_for(kind))
        if ids.get(_u(f["genre"])):
            params["with_genres"] = ids[_u(f["genre"])]
    return params


def _fetch_page(client, media, params, page, out, state, index):
    query = dict(params)
    query["page"] = page
    try:
        payload = client._get("/discover/%s" % media, query) or {}
    except Exception:
        return
    if isinstance(payload, dict):
        state["ok"] = True
        try:
            state["total"][index] = int(payload.get("total_pages") or 0)
        except Exception:
            pass
        out[(index, page)] = payload.get("results") or []


def tmdb_discover_batches(filters, kind, max_pages=50, batch_pages=6, cancelled=None):
    """Yield (titles, ok) batches in TMDb order until max_pages are read.

    A region with several languages is paged per language and interleaved.
    At most 3 TMDb requests run at the same time.
    """
    from .tmdb_client import TMDbClient
    client = TMDbClient()
    media = "tv" if kind == "series" else "movie"
    base = _discover_params(filters, kind)
    queries = region_queries(dict(DEFAULTS, **(filters or {})).get("country"))
    params = []
    for query in queries:
        item = dict(base)
        if query:
            item[query[0]] = query[1]
        params.append(item)
    state = {"ok": False, "total": [500] * len(params)}
    page, read = 1, 0
    while read < max_pages:
        if cancelled and cancelled():
            return
        jobs = []
        while len(jobs) < batch_pages and read + len(jobs) < max_pages:
            live = [i for i in range(len(params)) if page <= state["total"][i]]
            if not live:
                break
            for index in live:
                jobs.append((index, page))
            page += 1
        if not jobs:
            return
        out = {}
        for start in range(0, len(jobs), 3):
            threads = []
            for index, number in jobs[start:start + 3]:
                worker = threading.Thread(target=_fetch_page, name="TiviDiscover",
                                          args=(client, media, params[index], number, out, state, index))
                worker.daemon = True
                worker.start()
                threads.append(worker)
            for worker in threads:
                worker.join(12)
        read += len(jobs)
        titles = []
        for key in sorted(out, key=lambda k: (k[1], k[0])):
            titles.extend(x for x in out[key] if isinstance(x, dict))
        yield titles, state["ok"]
        if not out:
            return


def tmdb_discover(filters, kind, pages=10, cancelled=None):
    """Compatibility: first `pages` pages as one list. Returns (rows, ok)."""
    rows, ok, seen = [], False, set()
    for titles, good in tmdb_discover_batches(filters, kind, max_pages=pages, batch_pages=pages, cancelled=cancelled):
        ok = ok or good
        for item in titles:
            if item.get("id") not in seen:
                seen.add(item.get("id"))
                rows.append(item)
    return rows, ok


# ---------------------------------------------------------------- server -----
def _server_catalog(source, kind):
    from .filters import peek_filtered_streams_cache, get_filtered_streams
    from .core import get_source_client
    rows, origin = [], ""
    try:
        cached, origin = peek_filtered_streams_cache(source, kind)
        rows = list(cached or [])
    except Exception:
        rows = []
    # A package-only cache is a small part of the server: read the full list.
    if not rows or origin not in ("ram-catalog", "disk-catalog"):
        try:
            full = list(get_filtered_streams(source, kind, get_source_client(source), use_cache=True) or [])
            if len(full) >= len(rows):
                rows = full
        except Exception:
            pass
    return [row for row in rows if isinstance(row, dict)]


def _added(row):
    for key in ("added", "last_modified"):
        try:
            value = int(float(_u(row.get(key) or u"0") or 0))
        except (TypeError, ValueError):
            value = 0
        if value:
            return value
    return 0


def discover(source, filters, cancelled=None, limit=300, wanted=100):
    """Return (rows, status). status: 'ok' | 'tmdb_error' | 'no_catalog'.

    TMDb is read page by page (up to 50 pages = 1000 titles) until `wanted`
    titles of THIS server are found.
    """
    f = dict(DEFAULTS, **(filters or {}))
    kind = "series" if f.get("kind") == "series" else "vod"
    catalog = _server_catalog(source, kind)
    if cancelled and cancelled():
        return [], "ok"
    if not catalog:
        return [], "no_catalog"
    by_id, by_key = {}, {}
    for row in catalog:
        tid = _row_tmdb(row)
        if tid:
            by_id.setdefault(tid, []).append(row)
        keys = set()
        for field in ("name", "title", "o_name", "original_name"):
            key = title_key(row.get(field))
            if len(key) >= 2:
                keys.add(key)
        for key in keys:
            by_key.setdefault(key, []).append(row)
    found, seen, ok, rank = [], set(), False, 0
    seen_titles = set()
    for titles, good in tmdb_discover_batches(f, kind, cancelled=cancelled):
        ok = ok or good
        for item in titles:
            tid = _u(item.get("id") or u"")
            if not tid or tid in seen_titles:
                continue
            seen_titles.add(tid)
            rank += 1
            date = _u(item.get("release_date") or item.get("first_air_date") or u"")
            year = int(date[:4]) if date[:4].isdigit() else 0
            candidates = list(by_id.get(tid, ()))
            for field in ("title", "original_title", "name", "original_name"):
                for row in by_key.get(title_key(item.get(field)), ()):
                    row_tid = _row_tmdb(row)
                    if row_tid and row_tid != tid:
                        continue
                    row_year = _row_year(row)
                    if year and row_year and abs(year - row_year) > 1:
                        continue
                    candidates.append(row)
            for row in candidates:
                sid = _u(row.get("stream_id") or row.get("series_id") or row.get("id") or row.get("cmd") or u"")
                marker = sid or (title_key(row.get("name")), _u(row.get("category_id")))
                if marker in seen:
                    continue
                seen.add(marker)
                entry = dict(row)
                if not _row_tmdb(entry):
                    entry["tmdb_id"] = tid
                entry["_discover_rank"] = rank
                found.append(entry)
        if len(found) >= wanted or (cancelled and cancelled()):
            break
    if not ok and not found:
        return [], "tmdb_error"
    sort = f.get("sort") or "popular"
    if sort == "az":
        found.sort(key=lambda r: title_key(r.get("name") or r.get("title")))
    elif sort == "added":
        found.sort(key=_added, reverse=True)
    else:
        found.sort(key=lambda r: (r.get("_discover_rank", 0), -_added(r)))
    return found[:limit], "ok"
