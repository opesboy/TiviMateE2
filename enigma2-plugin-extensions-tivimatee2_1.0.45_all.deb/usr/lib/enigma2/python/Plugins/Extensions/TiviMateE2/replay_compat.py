# -*- coding: utf-8 -*-
"""Replay-only compatibility helpers, shared with Python 2.7."""
import time
try:
    from urllib.parse import quote, urlencode
except ImportError:
    from urllib import quote, urlencode

def event_time(row, start=True):
    keys = ("start_timestamp", "begin_timestamp", "start", "begin", "time", "date_start") if start else ("stop_timestamp", "end_timestamp", "end", "stop", "time_to", "date_end")
    for key in keys:
        raw = row.get(key)
        if raw in (None, ""):
            continue
        try:
            n = int(float(raw))
            if n > 100000000000:
                n //= 1000
            if n > 1000000000:
                return n
        except (ValueError, TypeError, OverflowError):
            pass
        for fmt, size in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%d %H:%M", 16), ("%Y-%m-%d:%H-%M", 16)):
            try:
                return int(time.mktime(time.strptime(str(raw).replace("T", " ")[:size], fmt)))
            except (ValueError, TypeError, OverflowError):
                pass
    if not start:
        try:
            duration = int(float(row.get("duration") or row.get("length") or 0))
            begin = event_time(row, True)
            if begin and 0 < duration <= 86400:
                return begin + duration
        except (ValueError, TypeError, OverflowError):
            pass
    return 0

def archive_days(item, default=0):
    for key in ("tv_archive_duration", "archive_duration"):
        try:
            days = int(float(item.get(key) or 0))
            if days > 0:
                return days
        except (TypeError, ValueError, OverflowError):
            pass
    return default

def archive_flag(item):
    return archive_days(item) > 0 or any(str(item.get(key) or "").strip().lower() in ("1", "true", "yes", "on") for key in ("tv_archive", "archive", "has_archive", "allow_archive"))

def xtream_urls(base, user, password, sid, duration, start, output="ts"):
    base = base.rstrip("/")
    output = output if output in ("ts", "m3u8") else "ts"
    primary = "%s/timeshift/%s/%s/%d/%s/%s.%s" % (base, quote(user, safe=""), quote(password, safe=""), duration, start, quote(sid, safe=""), output)
    alternate = "%s/streaming/timeshift.php?%s" % (base, urlencode([("username", user), ("password", password), ("stream", sid), ("start", start), ("duration", duration)]))
    return [primary, alternate]
