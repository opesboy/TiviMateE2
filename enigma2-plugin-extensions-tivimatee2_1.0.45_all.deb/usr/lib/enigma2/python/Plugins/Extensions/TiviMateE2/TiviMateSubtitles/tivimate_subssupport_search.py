# -*- coding: utf-8 -*-
'''
Created on Aug 2, 2014

@author: marko
'''
from __future__ import absolute_import
from __future__ import print_function

import sys
import json
# import time
import traceback

try:
    import six
except Exception:
    six = None

stdout = None

# Native backend diagnostics only; do not log credentials or subtitle URLs.
try:
    from .provider_diagnostics import record as _native_diag
except (ImportError, ValueError):
    from provider_diagnostics import record as _native_diag
_native_search = False


class Messages(object):
    MESSAGE_CAPTCHA_CALLBACK = 1
    MESSAGE_UPDATE_CALLBACK = 2
    MESSAGE_DELAY_CALLBACK = 3
    MESSAGE_CANCELLED_SCRIPT = 4
    MESSAGE_FINISHED_SCRIPT = 5
    MESSAGE_ERROR_SCRIPT = 6
    MESSAGE_CHOOSE_FILE_CALLBACK = 7
    MESSAGE_OVERWRITE_CALLBACK = 8


def _json_safe(value):
    """Return a json.dumps-safe value on both Python 2 and Python 3."""
    try:
        # Removed unused 'string_types' variable to fix F841
        text_type = six.text_type if six is not None else str
        binary_type = six.binary_type if six is not None else bytes
    except Exception:
        text_type = str
        binary_type = bytes

    if value is None or isinstance(value, (bool, int, float)):
        return value

    # Python 2: keep unicode as unicode, decode byte strings where possible.
    if six is not None and six.PY2:
        if isinstance(value, text_type):
            return value
        if isinstance(value, binary_type):
            try:
                return value.decode('utf-8')
            except Exception:
                return value.decode('utf-8', 'ignore')
    else:
        if isinstance(value, binary_type):
            try:
                return value.decode('utf-8', 'ignore')
            except Exception:
                return str(value)
        if isinstance(value, text_type):
            return value

    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return dict((_json_safe(k), _json_safe(v)) for k, v in value.items())

    # Exceptions/custom objects are not JSON serializable. Send readable text.
    try:
        if six is not None and six.PY2:
            return text_type(value)
        return str(value)
    except Exception:
        return ""


import threading
_IPC_WRITE_LOCK = threading.Lock()

def send(mtype, m):
    dump = json.dumps({'message': mtype, 'value': _json_safe(m)})
    dump = "%07d%s" % (len(dump) + 7, dump)
    with _IPC_WRITE_LOCK:
        stdout.write(dump)
        stdout.flush()


def recieve():
    return json.loads(sys.stdin.read(int(sys.stdin.read(7))))


def delayCB(seconds):
    send(Messages.MESSAGE_DELAY_CALLBACK, seconds)
    recieve()


def captchaCB(image):
    send(Messages.MESSAGE_CAPTCHA_CALLBACK, image)
    return recieve()


def messageCB(text):
    print('messageCB:', text)


def updateCB(*args):
    if _native_search and len(args) >= 3 and args[0] != '__ss_bridge_count__':
        value = args[2]
        count = len(value.get('list') or []) if isinstance(value, dict) else 0
        _native_diag('native result' if args[1] else 'native failure', args[0], count=count)
    send(Messages.MESSAGE_UPDATE_CALLBACK, args)


def chooseFileCB(*args):
    send(Messages.MESSAGE_CHOOSE_FILE_CALLBACK, args)
    return recieve()


def overwriteFileCB(*args):
    send(Messages.MESSAGE_OVERWRITE_CALLBACK, args)
    return recieve()


def scriptError(e):
    try:
        from provider_diagnostics import record, error_reason
        record('worker failed', error=e)
        reason = error_reason(e)
    except Exception:
        reason = e.__class__.__name__
    if stdout is not None:
        send(Messages.MESSAGE_ERROR_SCRIPT, {'error_code': getattr(e, 'code', 0),
             'provider': getattr(e, 'provider', '') or '', 'message': reason})


def scriptFinished(subtitlesDict):
    send(Messages.MESSAGE_FINISHED_SCRIPT, subtitlesDict)


def scriptCancelled(subtitlesDict):
    send(Messages.MESSAGE_CANCELLED_SCRIPT, subtitlesDict)


def searchSubtitles(seeker, options):
    seekers = options.get('providers')
    title = options.get('title')
    filepath = options.get('filepath')
    langs = options.get('langs')
    year = options.get('year')
    tvshow = options.get('tvshow')
    season = options.get('season')
    episode = options.get('episode')
    timeout = options.get('timeout', 10)
    return seeker.getSubtitles(seekers, updateCB, title, filepath, langs, year, tvshow, season, episode, timeout)


def downloadSubtitles(seeker, options):
    overwriteFileCBTmp = None
    if options.get('settings').get('ask_overwrite'):
        overwriteFileCBTmp = overwriteFileCB

    return seeker.downloadSubtitle(
        options.get("selected_subtitle"),
        options.get("subtitles_dict"),
        chooseFileCB,
        options.get("path"),
        options.get("filename"),
        overwriteFileCBTmp,
        options.get("settings"))


def _tivimate_is_yify(provider):
    """YIFY/YTS (ytssubs) is enabled again, like SubsSupport."""
    return False


def main():
    global stdout, _native_search, six
    stdout = sys.stdout
    # The original stdout is the binary/JSON IPC channel to Enigma2.
    # Silence subprocess print/debug output without creating a /tmp log.
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = sys.stdout
    from provider_diagnostics import record as _startup_diag
    _startup_diag('worker entered', __import__('os').path.basename(__file__))
    options = recieve()
    _startup_diag('worker received request', __import__('os').path.basename(__file__))
    from worker_dependencies import prepare
    prepare()
    import six
    _startup_diag('worker dependencies ready', __import__('os').path.basename(__file__))
    if options.get('download'):
        try:
            from tivimate_http_trace import install as _trace_install
            _trace_install(download=True)
        except Exception:
            pass
    print('[SS-bridge] %s' % ('download' if options.get('download') else 'search'))
    try:
        sys.stdout.flush()
    except Exception:
        pass
    # The actual installed SubsSupport backend is used at RUNTIME.  Its
    # architecture-specific service.so modules and keys are NEVER copied into
    # TiviMate, ensuring the provider implementation matches the working plugin
    # on this particular receiver (Pure2/OpenATV architectures may differ).
    import os
    from provider_source_catalog import native_backend_dirs, native_backend_id
    candidates = native_backend_dirs()
    requested_backend = options.get('_tivimate_native_backend')
    if requested_backend:
        candidates = [path for path in candidates if native_backend_id(path) == requested_backend]
    native_dir = candidates[0] if candidates else ''
    use_native = bool(options.get('_tivimate_use_subssupport'))
    using_native = False
    native_seek_available = bool(candidates)
    _native_diag('native backend selected', native_backend_id(native_dir) if native_dir else 'none')
    if options.get('_tivimate_native_only') and not native_seek_available:
        _native_diag('native backend not installed')
        if options.get('download'):
            raise RuntimeError('Selected native subtitle backend is not installed')
        if options.get('search'):
            updateCB('__ss_bridge_count__', True, {'count': 0, 'native': False})
        return {}
    if use_native and native_seek_available:
        try:
            sys.path.insert(0, native_dir)
            import seek as native_seek
            loaded_path = os.path.realpath(getattr(native_seek, '__file__', '') or '')
            if not loaded_path.startswith(os.path.realpath(native_dir) + os.sep):
                raise ImportError('native seek resolved outside SubsSupport')
            SubsSeeker = native_seek.SubsSeeker
            using_native = True
            _native_diag('native backend import OK')
            print('[SS-bridge] using installed SubsSupport native SubsSeeker')
        except Exception as exc:
            _native_diag('native backend import failed', error=exc)
            # An incompatible native binary must NOT break subtitles on this
            # receiver. Fall back to TiviMate's providers for this search.
            print('[SS-bridge] native import failed; using TiviMate: %r' % (exc,))
            if native_dir in sys.path:
                sys.path.remove(native_dir)
            for module_name in list(sys.modules):
                if module_name == 'seek' or module_name == 'seekers' or module_name.startswith('seekers.'):
                    del sys.modules[module_name]
            if options.get('_tivimate_native_only'):
                if options.get('download'):
                    raise RuntimeError('Selected native subtitle backend failed to import')
                if options.get('search'):
                    updateCB('__ss_bridge_count__', True, {'count': 0, 'native': False})
                return {}
    if not using_native:
        try:
            from .seek import SubsSeeker
        except (ValueError, ImportError):
            from seek import SubsSeeker
    seeker = SubsSeeker(options.get('download_path', '/tmp/'),
                        options.get('tmp_path', '/tmp/'),
                        captchaCB, delayCB, messageCB,
                        None if using_native else options.get('settings'))
    if options.get('search'):
        p = options['search']
        if using_native:
            langs = p.get('langs') or []
            try:
                native_providers = seeker.getProviders(langs, not bool(p.get('tvshow')), bool(p.get('tvshow')))
            except TypeError:
                native_providers = seeker.getProviders(langs)
                native_providers = [s for s in native_providers if (getattr(s, 'tvshow_search', True) if p.get('tvshow') else getattr(s, 'movie_search', True))]
            native_providers = [entry for entry in native_providers
                                if not _tivimate_is_yify(entry)]
            p = dict(p, providers=[entry.id for entry in native_providers])
            _native_search = True
            _native_diag('native selected providers', count=len(native_providers))
            selected_ids = set(entry.id for entry in native_providers)
            for entry in getattr(seeker, 'seekers', []):
                if entry.id not in selected_ids:
                    _native_diag('native registered but skipped', entry.id)
                if getattr(entry, 'error', None) is not None:
                    _native_diag('native import failed', entry.id, entry.error)
            for entry in native_providers:
                _native_diag('native selected', entry.id)
        else:
            native_providers = [pid for pid in (p.get('providers') or [])
                                if not _tivimate_is_yify(pid)]
            p = dict(p, providers=native_providers)
        # This metadata message allows the TiviMate UI to count the REAL number
        # of SubsSupport providers instead of assuming its old Python registry.
        updateCB('__ss_bridge_count__', True, {'count': len(p.get('providers') or []), 'native': using_native})
        if not native_providers:
            return {}
        found = searchSubtitles(seeker, p)
        if isinstance(found, dict):
            found = dict((k, v) for k, v in found.items() if not _tivimate_is_yify(k))
        return found
    elif options.get('download'):
        return downloadSubtitles(seeker, options['download'])


if __name__ == '__main__':
    try:
        scriptFinished(main())
        stdout.close()
        sys.stdout.close()
        sys.exit(0)
    except KeyboardInterrupt:
        scriptCancelled({})
        stdout.close()
        sys.stdout.flush()
        sys.stdout.close()
        sys.exit(0)
    except Exception as e:
        traceback.print_exc()
        scriptError(e)
        stdout.close()
        sys.stdout.close()
        sys.exit(1)
