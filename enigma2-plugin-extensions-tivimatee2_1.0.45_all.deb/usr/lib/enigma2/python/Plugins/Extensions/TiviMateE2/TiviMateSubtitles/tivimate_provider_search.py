# -*- coding: utf-8 -*-
'''
Created on Aug 2, 2014

@author: marko
'''
from __future__ import absolute_import
from __future__ import print_function

import sys
import json
# import time
import traceback

try:
    import six
except Exception:
    six = None

stdout = None


class Messages(object):
    MESSAGE_CAPTCHA_CALLBACK = 1
    MESSAGE_UPDATE_CALLBACK = 2
    MESSAGE_DELAY_CALLBACK = 3
    MESSAGE_CANCELLED_SCRIPT = 4
    MESSAGE_FINISHED_SCRIPT = 5
    MESSAGE_ERROR_SCRIPT = 6
    MESSAGE_CHOOSE_FILE_CALLBACK = 7
    MESSAGE_OVERWRITE_CALLBACK = 8


def _json_safe(value):
    """Return a json.dumps-safe value on both Python 2 and Python 3."""
    try:
        # Removed unused 'string_types' variable to fix F841
        text_type = six.text_type if six is not None else str
        binary_type = six.binary_type if six is not None else bytes
    except Exception:
        text_type = str
        binary_type = bytes

    if value is None or isinstance(value, (bool, int, float)):
        return value

    # Python 2: keep unicode as unicode, decode byte strings where possible.
    if six is not None and six.PY2:
        if isinstance(value, text_type):
            return value
        if isinstance(value, binary_type):
            try:
                return value.decode('utf-8')
            except Exception:
                return value.decode('utf-8', 'ignore')
    else:
        if isinstance(value, binary_type):
            try:
                return value.decode('utf-8', 'ignore')
            except Exception:
                return str(value)
        if isinstance(value, text_type):
            return value

    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, dict):
        return dict((_json_safe(k), _json_safe(v)) for k, v in value.items())

    # Exceptions/custom objects are not JSON serializable. Send readable text.
    try:
        if six is not None and six.PY2:
            return text_type(value)
        return str(value)
    except Exception:
        return ""


import threading
_IPC_WRITE_LOCK = threading.Lock()

def send(mtype, m):
    dump = json.dumps({'message': mtype, 'value': _json_safe(m)})
    dump = "%07d%s" % (len(dump) + 7, dump)
    with _IPC_WRITE_LOCK:
        stdout.write(dump)
        stdout.flush()


def recieve():
    return json.loads(sys.stdin.read(int(sys.stdin.read(7))))


def delayCB(seconds):
    send(Messages.MESSAGE_DELAY_CALLBACK, seconds)
    recieve()


def captchaCB(image):
    send(Messages.MESSAGE_CAPTCHA_CALLBACK, image)
    return recieve()


def messageCB(text):
    print('messageCB:', text)


def updateCB(*args):
    send(Messages.MESSAGE_UPDATE_CALLBACK, args)


def chooseFileCB(*args):
    send(Messages.MESSAGE_CHOOSE_FILE_CALLBACK, args)
    return recieve()


def overwriteFileCB(*args):
    send(Messages.MESSAGE_OVERWRITE_CALLBACK, args)
    return recieve()


def scriptError(e):
    try:
        from provider_diagnostics import record, error_reason
        record('worker failed', error=e)
        reason = error_reason(e)
    except Exception:
        reason = e.__class__.__name__
    if stdout is not None:
        send(Messages.MESSAGE_ERROR_SCRIPT, {'error_code': getattr(e, 'code', 0),
             'provider': getattr(e, 'provider', '') or '', 'message': reason})


def scriptFinished(subtitlesDict):
    send(Messages.MESSAGE_FINISHED_SCRIPT, subtitlesDict)


def scriptCancelled(subtitlesDict):
    send(Messages.MESSAGE_CANCELLED_SCRIPT, subtitlesDict)


def searchSubtitles(seeker, options):
    seekers = options.get('providers')
    title = options.get('title')
    filepath = options.get('filepath')
    langs = options.get('langs')
    year = options.get('year')
    tvshow = options.get('tvshow')
    season = options.get('season')
    episode = options.get('episode')
    timeout = options.get('timeout', 10)
    from search_identity import imdb_value
    import os
    os.environ['TIVIMATE_SEARCH_IMDB_ID'] = imdb_value(options.get('imdb_id')) if not tvshow else ''
    found = seeker.getSubtitles(seekers, updateCB, title, filepath, langs, year, tvshow, season, episode, timeout)
    _write_search_report(options, found)
    return found


def _write_search_report(options, found):
    """Small per-provider report: /tmp/tivimate_subtitle_search.txt."""
    try:
        lines = ['title=%r year=%r tvshow=%r season=%r episode=%r langs=%r' % (
            options.get('title'), options.get('year'), options.get('tvshow'),
            options.get('season'), options.get('episode'), options.get('langs')),
            'providers=%r' % (options.get('providers'),), '']
        for provider, payload in sorted((found or {}).items()):
            if not isinstance(payload, dict):
                lines.append('%s: %r' % (provider, payload))
                continue
            rows = payload.get('list') or []
            note = payload.get('message') or payload.get('msg') or ''
            import re
            note = re.sub(r'https?://[^\s]+', '[URL]', str(note))
            note = re.sub(r'(?i)(api[_ -]?key|authorization|bearer)[=: ]+[^\s,]+', r'\1=[REDACTED]', note)
            lines.append('%-16s status=%s results=%d %s' % (
                provider, payload.get('status'), len(rows), str(note)[:300]))
        try:
            from tivimate_http_trace import write as _trace_write
        except Exception:
            _trace_write = None
        if _trace_write is not None:
            _trace_write('/tmp/tivimate_subtitle_search.txt', lines)
        else:
            handle = open('/tmp/tivimate_subtitle_search.txt', 'w')
            handle.write('\n'.join(lines) + '\n')
            handle.close()
    except Exception:
        pass


def downloadSubtitles(seeker, options):
    # Preserve the existing player/IPC contract. Record the real outcome of
    # downloads in the existing diagnostic file, without leaking signed URLs
    # or provider API keys into the log.
    try:
        from .subtitle_pipeline_log import trace, file_info
    except ImportError:
        from subtitle_pipeline_log import trace, file_info
    selected = options.get("selected_subtitle") or {}
    provider = selected.get("provider") or "unknown"
    trace("worker.download.start", provider=provider)
    result = None
    error_note = ''
    try:
        result = _downloadSubtitles(seeker, options)
        trace("worker.download.result", provider=provider, **file_info(result))
        return result
    except Exception as e:
        trace("worker.download.error", provider=provider, error=type(e).__name__)
        try:
            error_note = '%s: %s' % (e.__class__.__name__, str(e))
            # Remove URL and bearer token fragments before writing diagnostics.
            import re
            error_note = re.sub(r'https?://[^\s\"\']+', '[URL]', error_note)
            error_note = re.sub(r'(?i)(api[_ -]?key|authorization|bearer)[=: ]+[^\s,]+', r'\1=[REDACTED]', error_note)
        except Exception:
            error_note = 'Unknown download error'
        raise
    finally:
        try:
            import os
            from tivimate_http_trace import write as _trace_write
            selected = (options.get('selected_subtitle') or {})
            lines = [
                'provider=%r' % (selected.get('provider'),),
                'file=%r' % (selected.get('filename'),),
                'status=%s' % ('ERROR' if error_note else ('OK' if result and os.path.isfile(result) else 'NO_FILE')),
            ]
            if error_note:
                lines.append('reason=%s' % error_note[:240])
            _trace_write('/tmp/tivimate_subtitle_download.txt', lines)
        except Exception:
            pass

def _downloadSubtitles(seeker, options):
    overwriteFileCBTmp = None
    if options.get('settings').get('ask_overwrite'):
        overwriteFileCBTmp = overwriteFileCB

    return seeker.downloadSubtitle(
        options.get("selected_subtitle"),
        options.get("subtitles_dict"),
        chooseFileCB,
        options.get("path"),
        options.get("filename"),
        overwriteFileCBTmp,
        options.get("settings"))


def main():
    global stdout, six
    stdout = sys.stdout
    # The original stdout is the binary/JSON IPC channel to Enigma2.
    # Silence subprocess print/debug output without creating a /tmp log.
    sys.stdout = open('/dev/null', 'w')
    sys.stderr = sys.stdout
    from provider_diagnostics import record as _startup_diag
    _startup_diag('worker entered', __import__('os').path.basename(__file__))
    options = recieve()
    _startup_diag('worker received request', __import__('os').path.basename(__file__))
    from worker_dependencies import prepare
    prepare()
    import six
    _startup_diag('worker dependencies ready', __import__('os').path.basename(__file__))
    try:
        import os as _os
        sys.path.insert(1, _os.path.dirname(_os.path.abspath(__file__)))
        from tivimate_http_trace import install as _trace_install
        _trace_install(download=bool(options.get("download")))
    except Exception:
        pass
    print('recieved options: %r' % options)
    try:
        sys.stdout.flush()
    except Exception:
        pass
    try:
        from .seek import SubsSeeker
    except (ValueError, ImportError):
        from seek import SubsSeeker
    seeker = SubsSeeker(options.get('download_path', '/tmp/'),
                        options.get('tmp_path', '/tmp/'),
                        captchaCB, delayCB, messageCB,
                        options.get('settings'))
    if options.get('search'):
        return searchSubtitles(seeker, options['search'])
    elif options.get('download'):
        return downloadSubtitles(seeker, options['download'])


def _hard_exit(code):
    # r153: os._exit so a provider thread stuck past the search deadline can
    # never keep this worker (and the Enigma2 search screen) alive.
    try:
        sys.stdout.flush()
    except Exception:
        pass
    import os as _os
    _os._exit(code)


if __name__ == '__main__':
    try:
        scriptFinished(main())
        stdout.close()
        sys.stdout.close()
        _hard_exit(0)
    except KeyboardInterrupt:
        scriptCancelled({})
        stdout.close()
        sys.stdout.flush()
        sys.stdout.close()
        _hard_exit(0)
    except Exception as e:
        traceback.print_exc()
        scriptError(e)
        stdout.close()
        sys.stdout.close()
        _hard_exit(1)
