# -*- coding: utf-8 -*-
"""VOD ownership and background-work gate; never touches Enigma2 services."""
from __future__ import absolute_import
import threading

_LOCK = threading.Lock()
_OWNERS = set()
_IDLE = threading.Event()
_IDLE.set()


def active():
    return not _IDLE.is_set()


def enter(owner):
    with _LOCK:
        _OWNERS.add(id(owner))
        _IDLE.clear()


def leave(owner):
    """Return True only when the last actual playback owner leaves."""
    with _LOCK:
        key = id(owner)
        if key not in _OWNERS:
            return False
        _OWNERS.discard(key)
        if not _OWNERS:
            _IDLE.set()
            return True
    return False


def wait_for_idle(timeout):
    # Background workers only; never call from the Enigma2 GUI thread.
    _IDLE.wait(timeout)


def reset():
    """Release waiting workers on Enigma2 session shutdown."""
    with _LOCK:
        _OWNERS.clear()
        _IDLE.set()
