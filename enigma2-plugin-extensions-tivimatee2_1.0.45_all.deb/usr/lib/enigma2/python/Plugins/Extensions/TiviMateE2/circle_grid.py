# -*- coding: utf-8 -*-
"""Circle posters in three rows (3 x 8 per page), built on the GENRE engine.

Same look as the circle style (gold ring, glowing focus) but laid out like
GENRE, so paging, queues, caches, sort and favourites are all unchanged.
"""
import os
import re
from concurrent.futures import ThreadPoolExecutor

from enigma import ePoint

from .display_scale import sx, sy
from .genre_page import (StandaloneGenreScreen, GENRE_POSTER_SKIN, GRID_X, GRID_Y,
                         GRID_COLUMNS, PLUGIN_PATH)

POSTER_ATTRS = {"cornerRadius": str(int(sx(98)))}   # native round clip (fallback)


def _make_circle(path, size):
    from .hd_skin_compat import fitted_circle_poster
    result = fitted_circle_poster(path, size, size, force=True)
    return result


D = 196                      # circle diameter (1920x1080 design units)
RING = os.path.join(PLUGIN_PATH, "skins", "poster", "circle_grid_ring.png")
FOCUS = os.path.join(PLUGIN_PATH, "skins", "poster", "circle_grid_focus.png")
PLACEHOLDER = os.path.join(PLUGIN_PATH, "skins", "poster", "circle_grid_placeholder.png")
_POOL = ThreadPoolExecutor(max_workers=2)
_WARM_POOL = ThreadPoolExecutor(max_workers=1)   # next-page pre-cuts only


def _cx(column):
    return GRID_X[column] - 6          # circle centred on the original card


def _cy(row):
    return GRID_Y[row] + 2


def _set(skin, name, x, y, w, h, attrs=None, drop=()):
    pattern = r'(<widget\s+name="%s"\s+)([^>]*)(/>)' % re.escape(name)

    def repl(match):
        a = match.group(2)
        a = re.sub(r'position="[^"]*"', 'position="%d,%d"' % (sx(x), sy(y)), a, count=1)
        a = re.sub(r'size="[^"]*"', 'size="%d,%d"' % (sx(w), sy(h)), a, count=1)
        for key in drop:
            a = re.sub(r'\s+%s="[^"]*"' % key, '', a)
        for key, value in (attrs or {}).items():
            if re.search(r'\b%s="[^"]*"' % key, a):
                a = re.sub(r'\b%s="[^"]*"' % key, '%s="%s"' % (key, value), a, count=1)
            else:
                a = a.rstrip() + ' %s="%s" ' % (key, value)
        return match.group(1) + a + match.group(3)
    return re.sub(pattern, repl, skin, count=1)


def build_circle_skin():
    skin = GENRE_POSTER_SKIN.replace('name="StandaloneGenreScreen"', 'name="CircleGridScreen"', 1)
    for row in range(len(GRID_Y)):
        for column in range(GRID_COLUMNS):
            slot = row * GRID_COLUMNS + column
            x, y = _cx(column), _cy(row)
            skin = _set(skin, "poster%d" % slot, x, y, D, D, dict(POSTER_ATTRS, pixmap=PLACEHOLDER), drop=("cornerRadius",))
            skin = _set(skin, "shell%d" % slot, x - 20, y - 18, 236, 250, {"pixmap": RING})
            skin = _set(skin, "newBadge%d" % slot, x - 6, y - 6, 112, 112)
            # Nothing under the circles: the year/meta label is parked off-screen.
            skin = _set(skin, "meta%d" % slot, -2000, -2000, 10, 10)
            skin = _set(skin, "stars%d" % slot, -2000, -2000, 10, 10)
    skin = _set(skin, "selector", _cx(0) - 34, _cy(0) - 34, 264, 264, {"pixmap": FOCUS})
    return skin


class CircleGridScreen(StandaloneGenreScreen):
    """GENRE engine (3 rows x 8, paging, queues, caches) with circle posters."""
    _CARD_SIZE = (D, D)
    _GENRE_LIKE = True          # same pills / backdrop handling as GENRE Grid
    skin = build_circle_skin()

    def _set_stars(self, slot, item):
        """Stars belong to GENRE posters only; Royal circles stay clean."""
        try:
            self["stars%d" % slot].hide()
        except Exception:
            pass

    def _set_placeholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(PLACEHOLDER)
        except Exception:
            pass

    def render(self, *args, **kwargs):
        result = StandaloneGenreScreen.render(self, *args, **kwargs)
        # Circles only: nothing under them (no year, no rating).
        try:
            for slot in range(len(GRID_Y) * GRID_COLUMNS):
                self["meta%d" % slot].hide()
        except Exception:
            pass
        try:
            if self.genre_items:
                slot = self.index - self.page_start
                row, column = slot // GRID_COLUMNS, slot % GRID_COLUMNS
                self["selector"].instance.move(ePoint(sx(_cx(column) - 34), sy(_cy(row) - 34)))
        except Exception:
            pass
        return result

    def _next_page_warm_ready(self, path):
        """Pre-cut next-page circles one at a time (disk cache, worker only)."""
        if getattr(self, "_closed", True) or not path:
            return
        size = int(sx(D))
        if getattr(self, "_circle_warm_busy", 0) >= 2:
            return      # never queue more than two pre-cuts ahead of visible work

        def worker():
            try:
                if not getattr(self, "_closed", True):
                    _make_circle(path, size)
            except Exception:
                pass
            self._circle_warm_busy = max(0, getattr(self, "_circle_warm_busy", 1) - 1)
        try:
            self._circle_warm_busy = getattr(self, "_circle_warm_busy", 0) + 1
            _WARM_POOL.submit(worker)
        except RuntimeError:
            self._circle_warm_busy = max(0, self._circle_warm_busy - 1)

    def _decode_poster(self, slot, path, token, item, origin, resolved_url=""):
        """Crop the cached poster to a real round PNG (worker), then paint it."""
        if getattr(self, "_closed", True) or self._poster_tokens.get(slot) != token:
            return
        if not path or not os.path.isfile(path):
            return StandaloneGenreScreen._decode_poster(self, slot, path, token, item, origin, resolved_url)
        priority = 2 if origin in ("provider", "provider_detail") else 1
        if self._poster_resolved_priority.get(slot, 0) > priority:
            return
        size = int(sx(D))

        def worker():
            # Page changed before this job started: skip the crop so fast
            # paging never piles up stale work in the 2-thread pool.
            if getattr(self, "_closed", True) or self._poster_tokens.get(slot) != token:
                return
            try:
                prepared = _make_circle(path, size)
            except Exception:
                prepared = ""
            self._post_to_gui(apply, prepared)

        def apply(prepared):
            if getattr(self, "_closed", True) or self._poster_tokens.get(slot) != token:
                return
            if self._poster_resolved_priority.get(slot, 0) > priority:
                return
            pointer = None
            if prepared and os.path.isfile(prepared):
                try:
                    from Tools.LoadPixmap import LoadPixmap
                    pointer = LoadPixmap(path=prepared)
                except Exception:
                    pointer = None
            if pointer is not None and self["poster%d" % slot].instance:
                self["poster%d" % slot].instance.setPixmap(pointer)
                self["poster%d" % slot].show()
                self._poster_resolved_priority[slot] = priority
            else:
                # No Pillow / unreadable file: the normal GENRE decoder.
                StandaloneGenreScreen._decode_poster(self, slot, path, token, item, origin, resolved_url)
        try:
            _POOL.submit(worker)
        except RuntimeError:
            StandaloneGenreScreen._decode_poster(self, slot, path, token, item, origin, resolved_url)
