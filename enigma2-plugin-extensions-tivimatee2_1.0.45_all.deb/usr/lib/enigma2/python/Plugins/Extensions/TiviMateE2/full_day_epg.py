# -*- coding: utf-8 -*-
"""Read-only full-day guide. No playback or archive actions."""
import base64
import json
import os
import datetime
import re
import threading
import time

try:
    text_type = unicode
except NameError:
    text_type = str


def text(value):
    if isinstance(value, text_type):
        return value
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return text_type(value or '')


def ui_text(value):
    value = text(value)
    return value.encode('utf-8') if text_type is not str else value


def day_bounds(now):
    date = datetime.date.fromtimestamp(now)
    tomorrow = date + datetime.timedelta(days=1)
    return (int(time.mktime(date.timetuple())), int(time.mktime(tomorrow.timetuple())))


def provider_text(value, encoded=False):
    value = text(value).strip()
    if encoded and len(value) >= 4 and len(value) % 4 == 0 and re.match(r'^[A-Za-z0-9+/]+={0,2}$', value):
        try:
            raw = value.encode('ascii')
            decoded = base64.b64decode(raw)
            if base64.b64encode(decoded) == raw:
                candidate = decoded.decode('utf-8').strip()
                if candidate and all(c.isprintable() if hasattr(c, 'isprintable') else ord(c) >= 32 or c in '\r\n\t' for c in candidate) and any(c.isalnum() for c in candidate):
                    return candidate
        except Exception:
            pass
    return value


def normalise(rows, start, end, encoded=False, channel_id=None):
    from .replay_compat import event_time
    result = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if channel_id:
            reported = text(row.get('ch_id') or row.get('channel_id') or '')
            if reported not in ('', '0', text(channel_id)):
                continue
        begin, stop = event_time(row, True), event_time(row, False)
        title = provider_text(row.get('title') or row.get('name') or row.get('programme') or row.get('event_name'), encoded)
        desc = provider_text(row.get('description') or row.get('descr') or row.get('desc') or row.get('plot'), encoded)
        if title and begin < end and stop > start and stop > begin > 0:
            result[(begin, stop)] = (begin, stop, title, desc)
    return sorted(result.values(), key=lambda x: (x[0], x[1]))


def local_rows(source, item, start, end):
    from .epg_local import load_source_epg, _smart_epg_id, source_epg_offset_seconds
    epg = load_source_epg(source)
    if not epg:
        return []
    key = text(item.get('epg_channel_id') or item.get('tvg_id') or item.get('epg_id')).strip().lower()
    if key not in epg:
        key = _smart_epg_id(source, item, epg)
    shift = source_epg_offset_seconds(source)
    result = []
    for row in epg.get(key, []) or []:
        try:
            begin, stop = int(row[0]) + shift, int(row[1]) + shift
            if begin < end and stop > start and stop > begin:
                result.append((begin, stop, text(row[2]), text(row[3])))
        except (ValueError, TypeError, IndexError):
            pass
    return sorted(result, key=lambda x: (x[0], x[1]))


def merge_rows(primary, secondary):
    result = list(primary)
    for row in secondary:
        if not any(row[0] < old[1] and row[1] > old[0] for old in result):
            result.append(row)
    return sorted(result, key=lambda x: (x[0], x[1]))


def fetch_day(source, item, now, cancelled):
    from .core import XtreamClient, StalkerClient
    start, end = day_bounds(now)
    try:
        local = local_rows(source, item, start, end)
    except Exception:
        local = []
    kind = text(source.get('type')).lower()
    rows = []
    if cancelled.is_set():
        return local
    try:
        if kind == 'xtream':
            cid = text(item.get('stream_id') or item.get('id') or item.get('ch_id'))
            epg_id = text(item.get('epg_channel_id') or item.get('tvg_id') or item.get('epg_id'))
            client = XtreamClient(source)
            if cid or epg_id:
                # Full table does not require the channel to advertise Catch-up.
                rows = normalise(client.catchup_epg(cid, epg_channel_id=epg_id), start, end, True)
                # Some full tables contain historical programmes only.
                if not cancelled.is_set() and not any(r[0] > now for r in rows):
                    extra = normalise(client.short_epg(cid, limit=20, epg_channel_id=epg_id), start, end, True)
                    rows = merge_rows(rows, extra)
        elif kind == 'stalker':
            cid = text(item.get('ch_id') or item.get('stream_id') or item.get('id'))
            if cid:
                client = StalkerClient(source)
                date = time.strftime('%Y-%m-%d', time.localtime(now))
                for page in range(0, 8):
                    if cancelled.is_set():
                        break
                    try:
                        payload = client._call_retry(_cancel_event=cancelled, type='epg', action='get_simple_data_table', ch_id=cid, date=date, p=page, JsHttpRequest='1-xml')
                        batch = client._normalise_short_epg_rows(payload, cid)
                    except Exception:
                        break
                    events = normalise(batch, start, end, channel_id=cid)
                    combined = merge_rows(rows, events)
                    if page > 1 and len(combined) == len(rows):
                        break
                    rows = combined
                if not cancelled.is_set() and not any(r[0] > now for r in rows):
                    extra = normalise(client.short_epg(cid, limit=20), start, end, channel_id=cid)
                    rows = merge_rows(rows, extra)
    except Exception:
        pass
    return merge_rows(rows, local)


from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from enigma import eTimer, ePicLoad, eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_HALIGN_CENTER, RT_VALIGN_CENTER
from Components.Pixmap import Pixmap
from Components.MultiContent import MultiContentEntryText
try:
    from Components.MultiContent import MultiContentEntryPixmapAlphaBlend
except ImportError:
    from Components.MultiContent import MultiContentEntryPixmapAlphaTest as MultiContentEntryPixmapAlphaBlend
from Components.ProgressBar import ProgressBar
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, scale_size, sx, sy
from .i18n import tr, get_language

_LABELS = {'Full Day EPG': {'ar': 'جدول برامج اليوم', 'fr': 'Guide TV du jour', 'tr': 'Günlük TV rehberi', 'de': 'Tagesprogramm'}, 'Loading EPG...': {'ar': 'جاري تحميل دليل البرامج...', 'fr': 'Chargement du guide TV...', 'tr': 'TV rehberi yükleniyor...', 'de': 'EPG wird geladen...'}, 'EPG request is busy. Please try again.': {'ar': 'دليل البرامج مشغول، يرجى المحاولة مرة أخرى.', 'fr': 'Guide TV occupé. Réessayez.', 'tr': 'TV rehberi meşgul. Tekrar deneyin.', 'de': 'EPG-Anfrage läuft. Bitte erneut versuchen.'}, 'EPG request timed out.': {'ar': 'انتهت مهلة تحميل دليل البرامج.', 'fr': 'Délai de chargement dépassé.', 'tr': 'TV rehberi isteği zaman aşımına uğradı.', 'de': 'EPG-Anfrage abgelaufen.'}, 'NOW': {'ar': 'الآن', 'fr': 'MAINTENANT', 'tr': 'ŞİMDİ', 'de': 'JETZT'}, 'Available programmes for today': {'ar': 'البرامج المتاحة لهذا اليوم', 'fr': 'Programmes disponibles aujourd’hui', 'tr': 'Bugünün mevcut programları', 'de': 'Verfügbare Sendungen heute'}, 'No EPG data available for this channel.': {'ar': 'لا توجد بيانات دليل برامج لهذه القناة.', 'fr': 'Aucun guide TV disponible pour cette chaîne.', 'tr': 'Bu kanal için TV rehberi bulunamadı.', 'de': 'Keine EPG-Daten für diesen Sender verfügbar.'}}

def guide_tr(key):
    return _LABELS.get(key, {}).get(get_language()) or tr(key)


# One bounded request at a time even if the guide is opened and closed rapidly.
_worker_slot = threading.BoundedSemaphore(1)

# The guide remains read-only. All artwork comes from the existing shared cache.
_art_slot = threading.BoundedSemaphore(1)
# Relative to this file: on Python 2.7 images the TiviMateE2 (Python 3)
# folder is removed after install, so a fixed path lost all guide artwork.
_SKIN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'skins', 'common') + '/'
_ART_FILE = _SKIN_DIR + 'epg_guide_royal.jpg'

_EXTRA_LABELS = {
    'Programme artwork': ('صورة البرنامج', 'Visuel du programme', 'Program görseli', 'Programmbild'),
    'Programme details': ('تفاصيل البرنامج', 'Détails du programme', 'Program bilgileri', 'Programmdetails'),
    'Today': ('اليوم', "Aujourd’hui", 'Bugün', 'Heute'),
    'Past': ('انتهى', 'Terminé', 'Bitti', 'Vorbei'),
    'Next': ('قادم', 'À venir', 'Sırada', 'Danach'),
    'No poster': ('لا يوجد بوستر', 'Aucune affiche', 'Afiş yok', 'Kein Poster'),
    'Back': ('رجوع', 'Retour', 'Geri', 'Zurück'),
    'Select programme': ('اختيار البرنامج', 'Choisir un programme', 'Program seç', 'Sendung wählen'),
    'Page up / down': ('الصفحة السابقة / التالية', 'Page précédente / suivante', 'Önceki / sonraki sayfa', 'Seite hoch / runter'),
    'Loading poster...': ('جاري تحميل البوستر...', 'Chargement de l’affiche...', 'Afiş yükleniyor...', 'Poster wird geladen...'),
    'Remaining': ('متبقي %d دقيقة', 'Reste %d min', '%d dk kaldı', 'Noch %d Min.'),
    'programmes': ('برنامج', 'programmes', 'program', 'Sendungen'),
    'Today programmes': ('برامج اليوم', 'Programmes du jour', 'Bugünün programları', 'Heutige Sendungen'),
    'Close guide': ('إغلاق الدليل', 'Fermer le guide', 'Rehberi kapat', 'Guide schließen'),
}
for _key, _values in _EXTRA_LABELS.items():
    _LABELS[_key] = dict(zip(('ar', 'fr', 'tr', 'de'), _values))


def _timer_connect(timer, callback):
    try:
        return timer.timeout.connect(callback)
    except Exception:
        try:
            timer.callback.append(callback)
        except Exception:
            timer.timeout.get().append(callback)
    return None


def _interval(row):
    return '%s - %s' % (time.strftime('%H:%M', time.localtime(row[0])), time.strftime('%H:%M', time.localtime(row[1])))


def _row_state(row, now):
    if row[0] <= now < row[1]:
        return 'NOW', 0x7A3CE6
    if row[1] <= now:
        return 'Past', 0x5F6687
    return 'Next', 0x96AFE6


_PILL = None


def _pill_pixmap():
    global _PILL
    if _PILL is None:
        try:
            from Tools.LoadPixmap import LoadPixmap
            _PILL = LoadPixmap(_SKIN_DIR + 'epg_pill_now.png') or False
        except Exception:
            _PILL = False
    return _PILL or None


class GuideProgrammeList(MenuList):
    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', sy(26)))
        self.l.setFont(1, gFont('Regular', sy(24)))
        self.l.setFont(2, gFont('Regular', sy(20)))
        self.l.setItemHeight(sy(64))

    def entries(self, rows, now):
        result = []
        pill = _pill_pixmap()
        for row in rows:
            state, colour = _row_state(row, now)
            past = state == 'Past'
            start = time.strftime('%H:%M', time.localtime(row[0]))
            stop = u'\u2013 ' + text(time.strftime('%H:%M', time.localtime(row[1])))
            entry = [row,
                MultiContentEntryText(pos=(sx(20), 0), size=(sx(80), sy(64)), font=1, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=ui_text(start), color=0x5F6687 if past else 0xBEC8E6, color_sel=0xFFFFFF),
                MultiContentEntryText(pos=(sx(100), 0), size=(sx(110), sy(64)), font=2, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=ui_text(stop), color=0x5F6687 if past else 0x96A0C3, color_sel=0xF0F4FF),
                MultiContentEntryText(pos=(sx(222), 0), size=(sx(520), sy(64)), font=0, flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=ui_text(row[2]), color=0x6E7595 if past else 0xF6F8FF, color_sel=0xFFFFFF)]
            if state == 'NOW' and pill is not None:
                entry.append(MultiContentEntryPixmapAlphaBlend(pos=(sx(756), sy(16)), size=(sx(88), sy(32)), png=pill))
                entry.append(MultiContentEntryText(pos=(sx(756), sy(16)), size=(sx(88), sy(32)), font=2, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=ui_text(guide_tr(state)), color=colour, color_sel=colour))
            else:
                entry.append(MultiContentEntryText(pos=(sx(746), 0), size=(sx(108), sy(64)), font=2, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER, text=ui_text(guide_tr(state)), color=colour, color_sel=0xFFFFFF))
            result.append(entry)
        return result


_SKIN = '''<screen name="TiviMateFullDayEPG" position="center,center" size="1920,1080" flags="wfNoBorder" zPosition="35" backgroundColor="#04061A">
    <ePixmap position="0,0" size="1920,1080" pixmap="''' + _ART_FILE + '''" scale="1" zPosition="0" />
    <widget name="logo" position="118,57" size="124,74" alphatest="blend" scale="1" zPosition="2" />
    <widget name="channel" position="276,46" size="1000,62" font="Regular;44" foregroundColor="#F6F8FF" transparent="1" noWrap="1" zPosition="2" />
    <widget name="heading" position="278,106" size="1000,38" font="Regular;24" foregroundColor="#5AD2FF" transparent="1" noWrap="1" zPosition="2" />
    <widget name="clock" position="1430,40" size="380,70" font="Regular;56" halign="right" foregroundColor="#F6F8FF" transparent="1" zPosition="2" />
    <widget name="date" position="1430,112" size="380,32" font="Regular;22" halign="right" foregroundColor="#96A0C3" transparent="1" zPosition="2" />
    <widget name="brand" position="1430,146" size="380,26" font="Regular;18" halign="right" foregroundColor="#6E7595" transparent="1" zPosition="2" />
    <widget source="session.VideoPicture" render="Pig" position="110,180" size="760,428" backgroundColor="transparent" transparent="0" zPosition="1" />
    <ePixmap position="110,180" size="760,428" pixmap="''' + _SKIN_DIR + '''epg_video_mask.png" alphatest="blend" zPosition="3" />
    <ePixmap position="130,200" size="96,36" pixmap="''' + _SKIN_DIR + '''epg_live_badge.png" alphatest="blend" zPosition="4" />
    <widget name="poster" position="130,657" size="168,252" alphatest="blend" scale="1" zPosition="2" />
    <ePixmap position="130,657" size="168,252" pixmap="''' + _SKIN_DIR + '''epg_poster_mask.png" alphatest="blend" zPosition="3" />
    <widget name="poster_hint" position="130,868" size="168,34" font="Regular;18" foregroundColor="#96A0C3" halign="center" valign="center" transparent="1" zPosition="4" />
    <widget name="details_heading" position="560,656" size="284,32" font="Regular;21" foregroundColor="#5AD2FF" halign="right" transparent="1" noWrap="1" zPosition="2" />
    <widget name="poster_title" position="326,652" size="400,48" font="Regular;32" foregroundColor="#F6F8FF" transparent="1" noWrap="1" zPosition="2" />
    <widget name="poster_meta" position="326,704" size="518,32" font="Regular;21" foregroundColor="#96A0C3" transparent="1" noWrap="1" zPosition="2" />
    <widget name="progress" position="336,752" size="508,10" pixmap="''' + _SKIN_DIR + '''epg_progress_royal.png" backgroundColor="#2A2654" borderWidth="0" zPosition="3" />
    <widget name="progress_pct" position="336,772" size="200,30" font="Regular;19" foregroundColor="#5AD2FF" transparent="1" zPosition="2" />
    <widget name="progress_left" position="544,772" size="300,30" font="Regular;19" foregroundColor="#96A0C3" halign="right" transparent="1" zPosition="2" />
    <widget name="detail" position="326,812" size="520,100" font="Regular;21" foregroundColor="#CDD4EB" transparent="1" zPosition="2" />
    <widget name="list_heading" position="1300,198" size="476,40" font="Regular;24" foregroundColor="#F6F8FF" halign="right" transparent="1" zPosition="2" />
    <widget name="status" position="944,202" size="400,34" font="Regular;20" foregroundColor="#96A0C3" transparent="1" zPosition="2" />
    <widget name="events" position="928,268" size="864,640" itemHeight="64" scrollbarMode="showOnDemand" backgroundColor="#161334" backgroundColorSelected="#161334" foregroundColor="#F6F8FF" foregroundColorSelected="#FFFFFF" selectionPixmap="''' + _SKIN_DIR + '''epg_sel_royal.png" transparent="0" zPosition="2" />
    <widget name="back_hint" position="220,968" size="330,34" font="Regular;22" foregroundColor="#CDD4EB" valign="center" transparent="1" zPosition="2" />
    <widget name="select_hint" position="650,968" size="330,34" font="Regular;22" foregroundColor="#CDD4EB" valign="center" transparent="1" zPosition="2" />
    <widget name="page_hint" position="1080,968" size="330,34" font="Regular;22" foregroundColor="#CDD4EB" valign="center" transparent="1" zPosition="2" />
    <widget name="epg_hint" position="1510,968" size="300,34" font="Regular;22" foregroundColor="#CDD4EB" valign="center" transparent="1" zPosition="2" />
</screen>'''


def _is_openpli():
    try:
        from Components.SystemInfo import BoxInfo
        if 'openpli' in str(BoxInfo.getItem('distro') or '').lower():
            return True
    except Exception:
        pass
    try:
        from boxbranding import getImageDistro
        if 'openpli' in str(getImageDistro() or '').lower():
            return True
    except Exception:
        pass
    for path in ('/etc/image-version', '/etc/issue', '/etc/os-release'):
        try:
            with open(path, 'r') as handle:
                if 'openpli' in handle.read(4096).lower():
                    return True
        except Exception:
            pass
    return False


# OpenPLi-only private context. Register just the two physical guide keys,
# not a wildcard action callback or a replacement for the image keymap.
_PLI_GUIDE_CONTEXT = 'TiviMateOpenPLiGuideActions'
_PLI_GUIDE_DOMAIN = 'TiviMateE2.OpenPLiGuide.r201'
_pli_guide_keys = ()


def _register_pli_guide_keys():
    global _pli_guide_keys
    if _pli_guide_keys:
        return True
    try:
        from enigma import eActionMap
        from keyids import KEYIDS
        actionmap = eActionMap.getInstance()
        registered = []
        for name in ('KEY_EPG', 'KEY_PROGRAM'):
            key = KEYIDS.get(name)
            if key is None or key in registered:
                continue
            try:
                # Make only: one press opens the guide; its release cannot
                # immediately close the newly opened screen.
                actionmap.bindKey(_PLI_GUIDE_DOMAIN, 'generic', key, 1,
                                  _PLI_GUIDE_CONTEXT, 'fullDayEPG')
                registered.append(key)
                try:
                    from Tools.KeyBindings import addKeyBinding
                    addKeyBinding(_PLI_GUIDE_DOMAIN, key, _PLI_GUIDE_CONTEXT,
                                  'fullDayEPG', 1)
                except Exception:
                    pass
            except Exception as exc:
                _guide_log('Guide key registration failed: %s / %s' % (name, type(exc).__name__))
        _pli_guide_keys = tuple(registered)
        _guide_log('Private guide key IDs: %s' % (str(_pli_guide_keys),))
        return bool(_pli_guide_keys)
    except Exception as exc:
        _guide_log('Private guide setup failed: ' + type(exc).__name__)
        return False


def _guide_binding():
    if _is_openpli():
        if _register_pli_guide_keys():
            return _PLI_GUIDE_CONTEXT, 'fullDayEPG', -20
        # If a receiver lacks bindKey, retain the previous native fallback.
        try:
            from Tools.KeyBindings import queryKeyBinding
            from keyids import KEYIDS
            key = KEYIDS.get('KEY_EPG')
            for context, action in (('InfobarEPGActions', 'showEventInfoSingleEPG'),
                                    ('ChannelSelectEPGActions', 'epg'),
                                    ('HotkeyActions', 'epg')):
                if key is not None and any(k == key and flags & 2 for k, flags in queryKeyBinding(context, action)):
                    return context, action, -20
        except Exception:
            pass
    return 'TiviMateFullDayEPGActions', 'fullDayEPG', -3


def _guide_log(message):
    # Small, local diagnostic. Never record channel names, URLs or credentials.
    if not _is_openpli():
        return
    try:
        path = '/tmp/tivimate_tvguide.log'
        mode = 'w' if os.path.isfile(path) and os.path.getsize(path) >= 16384 else 'a'
        with open(path, mode) as handle:
            handle.write(time.strftime('%H:%M:%S') + ' ' + str(message) + '\n')
    except Exception:
        pass


class FullDayEPGScreen(Screen):
    def __init__(self, session, source, item, compatible=False):
        # Some receiver images omit the PIG renderer or its session source.
        # The programme list must still open even without video preview.
        skin = _SKIN
        try:
            if compatible:
                raise RuntimeError('Compatibility mode: no video renderer')
            from Components.Renderer.Pig import Pig
            globals_screen = getattr(session, 'screen', None)
            if globals_screen is None or globals_screen['VideoPicture'] is None:
                raise RuntimeError('No VideoPicture source')
        except Exception:
            skin = re.sub(r'<widget source="session.VideoPicture"[^>]*/>', '', skin)
        if compatible:
            # Selection pixmaps are cosmetic and not supported by all listboxes.
            skin = re.sub(r' selectionPixmap="[^"]*"', '', skin)
        self.skin = scale_skin(skin)
        Screen.__init__(self, session)
        self.source = dict(source)
        self.item = dict(item)
        self.now = int(time.time())
        self.rows = []
        self.result = None
        self.cancelled = threading.Event()
        self._art_token = 0
        self._art_key = None
        self._art_pending = None
        self._art_result = None
        self._art_active = False
        self._art_memo = {}
        self._decode_loader = None
        self._decode_conn = None
        self._decode_serial = 0
        self['brand'] = Label(ui_text(u'TiviMateE2  \u2022  TV Guide'))
        self['heading'] = Label(ui_text(guide_tr('Full Day EPG')))
        self['channel'] = Label(ui_text(item.get('name') or item.get('title') or ''))
        self['date'] = Label(time.strftime('%Y-%m-%d', time.localtime(self.now)))
        self['clock'] = Label(time.strftime('%H:%M', time.localtime(self.now)))
        self['poster'] = Pixmap()
        self['logo'] = Pixmap()
        self['progress'] = ProgressBar()
        self['progress_pct'] = Label('')
        self['progress_left'] = Label('')
        self['poster_hint'] = Label('')
        self['poster_title'] = Label('')
        self['poster_meta'] = Label('')
        self['list_heading'] = Label(ui_text(guide_tr('Today programmes')))
        self['events'] = GuideProgrammeList()
        self['details_heading'] = Label(ui_text(guide_tr('Programme details')))
        self['detail'] = Label('')
        self['status'] = Label(ui_text(guide_tr('Loading EPG...')))
        self['back_hint'] = Label(ui_text(guide_tr('Back')))
        self['select_hint'] = Label(ui_text(guide_tr('Select programme')))
        self['page_hint'] = Label(ui_text(guide_tr('Page up / down')))
        self['epg_hint'] = Label(ui_text(guide_tr('Close guide')))
        guide_context, guide_action, guide_priority = _guide_binding()
        contexts = ['OkCancelActions', 'DirectionActions', 'NavigationActions', 'ColorActions']
        actions = {
            'cancel': self.close, 'red': self.close,
            'up': self['events'].up, 'down': self['events'].down,
            'left': self['events'].pageUp, 'right': self['events'].pageDown,
            'pageUp': self['events'].pageUp, 'pageDown': self['events'].pageDown,
            'ok': self._detail}
        if guide_context == 'TiviMateFullDayEPGActions':
            contexts.append(guide_context)
            actions[guide_action] = self.close
        self['actions'] = ActionMap(contexts, actions, -3)
        if guide_context != 'TiviMateFullDayEPGActions':
            self['guideCloseActions'] = ActionMap([guide_context], {guide_action: self.close}, guide_priority)
        self['events'].onSelectionChanged.append(self._detail)
        self.timer = eTimer()
        self._art_timer = eTimer()
        self._timer_conn = _timer_connect(self.timer, self._poll)
        self._art_conn = _timer_connect(self._art_timer, self._poll_art)
        self.onClose.append(self._stop)
        self.onLayoutFinish.append(self._start)

    def _load_logo(self):
        """Channel logo in the header plate, via the shared picon cache."""
        try:
            from .estalker_picon import resolve_picon_url, direct_picon
            url = resolve_picon_url(self.item, self.source)
        except Exception:
            return
        if not url:
            return
        self._logo_req = int(getattr(self, '_logo_req', 0) or 0) + 1
        req = self._logo_req

        def current():
            return int(getattr(self, '_logo_req', 0) or 0)

        def apply_path(path):
            if self.cancelled.is_set() or req != current() or not path or not os.path.isfile(path):
                return
            try:
                if self['logo'].instance:
                    self['logo'].instance.setPixmapFromFile(path)
                    self['logo'].show()
            except Exception:
                pass
        try:
            direct_picon(url, (248, 148), req, current, apply_path, prefix='tivimate_epg_logo_')
        except Exception:
            pass

    def _set_progress(self, row):
        now = int(time.time())
        duration = max(1, int(row[1] - row[0]))
        if row[0] <= now < row[1]:
            pct = max(0, min(100, int((now - row[0]) * 100 // duration)))
            minutes = max(1, (row[1] - now + 59) // 60)
            label = text(guide_tr('Remaining'))
            left = label % minutes if '%d' in label else u'%d min left' % minutes
        elif row[1] <= now:
            pct, left = 100, text(guide_tr('Past'))
        else:
            pct, left = 0, text(guide_tr('Next'))
        try:
            self['progress'].setValue(pct)
        except Exception:
            pass
        self['progress_pct'].setText(ui_text(u'%d%%' % pct))
        self['progress_left'].setText(ui_text(left))

    def _start(self):
        _guide_log('Guide layout finished')
        self['logo'].hide()
        self._load_logo()
        self['poster'].hide()
        if not _worker_slot.acquire(False):
            self['status'].setText(ui_text(guide_tr('EPG request is busy. Please try again.')))
            return
        def worker():
            try:
                self.result = fetch_day(self.source, self.item, self.now, self.cancelled)
            except Exception:
                self.result = []
            finally:
                _worker_slot.release()
        self.started = time.time()
        try:
            thread = threading.Thread(target=worker, name='TiviMateFullDayEPG')
            thread.daemon = True
            thread.start()
        except Exception:
            _worker_slot.release()
            self.result = []
        self.timer.start(150, True)

    def _poll(self):
        if self.cancelled.is_set():
            return
        if self.result is None:
            if time.time() - self.started < 45:
                self.timer.start(150, True)
            else:
                self.cancelled.set()
                self['status'].setText(ui_text(guide_tr('EPG request timed out.')))
            return
        self.rows = self.result
        index = 0
        for i, row in enumerate(self.rows):
            if row[0] <= self.now < row[1]:
                index = i
        self['events'].setList(self['events'].entries(self.rows, self.now))
        if self.rows:
            self['events'].moveToIndex(index)
            self['status'].setText(ui_text(u'%d  ' % len(self.rows) + text(guide_tr('programmes'))))
        else:
            self['status'].setText(ui_text(guide_tr('No EPG data available for this channel.')))
            self['detail'].setText(ui_text(guide_tr('No EPG data available for this channel.')))
        self._detail()

    def _detail(self):
        if not self.rows or self.cancelled.is_set():
            return
        try:
            index = self['events'].getSelectedIndex()
            row = self.rows[index]
        except (IndexError, TypeError):
            return
        self['detail'].setText(ui_text(row[3] or row[2]))
        self['poster_title'].setText(ui_text(row[2]))
        self['poster_meta'].setText(ui_text(_interval(row) + u'   \u2022   ' + str((row[1]-row[0])//60) + ' min'))
        self._set_progress(row)
        key = text(row[2]).strip()
        if key == self._art_key:
            return
        self._art_key = key
        self._art_token += 1
        self['poster'].hide()
        self['poster_hint'].setText(ui_text(guide_tr('Loading poster...')))
        self['poster_hint'].show()
        self._art_pending = (self._art_token, key, time.time() + 0.35)
        self._art_timer.start(400, True)

    def _poll_art(self):
        if self.cancelled.is_set():
            return
        if self._art_result is not None:
            token, title, url = self._art_result
            self._art_result = None
            self._art_active = False
            if len(self._art_memo) >= 60:
                self._art_memo.clear()
            self._art_memo[title] = url
            if token == self._art_token:
                self._request_poster(token, url)
        pending = self._art_pending
        if pending and not self._art_active and time.time() >= pending[2]:
            token, title, _ = pending
            if title in self._art_memo:
                self._art_pending = None
                self._request_poster(token, self._art_memo[title])
            elif _art_slot.acquire(False):
                self._art_pending = None
                self._art_active = True
                def worker():
                    url = ''
                    try:
                        # Existing strict TMDb identity matching, with its disk cache.
                        from .tmdb_client import TMDbClient
                        from .storage import data_path
                        try:
                            with open(data_path('live_poster_index.json'), 'r') as handle:
                                index = json.load(handle)
                            url = index.get(re.sub(r'\s+', ' ', title.strip().lower()), '') if isinstance(index, dict) else ''
                        except Exception:
                            pass
                        if not url and not self.cancelled.is_set():
                            client = TMDbClient()
                            result = client.search_artwork(title, 'vod', required_key='poster_path') or {}
                            if not result and not self.cancelled.is_set():
                                result = client.search_artwork(title, 'series', required_key='poster_path') or {}
                            path = result.get('poster_path') or ''
                            if path.startswith('/'):
                                url = 'https://image.tmdb.org/t/p/w342' + path
                    except Exception:
                        pass
                    finally:
                        self._art_result = (token, title, url)
                        _art_slot.release()
                try:
                    job = threading.Thread(target=worker, name='TiviMateEPGPoster')
                    job.daemon = True
                    job.start()
                except Exception:
                    _art_slot.release()
                    self._art_active = False
                    self._request_poster(token, '')
        if self._art_pending is not None or self._art_active:
            self._art_timer.start(200, True)

    def _request_poster(self, token, url):
        if self.cancelled.is_set() or token != self._art_token:
            return
        def failed(*args):
            if not self.cancelled.is_set() and token == self._art_token:
                self['poster_hint'].setText(ui_text(guide_tr('No poster')))
        if not url:
            failed()
            return
        try:
            from .artwork_queue import cached_artwork, request_artwork
            path = cached_artwork(url, 'posters')
            if path:
                self._decode_poster(token, path)
            else:
                request_artwork(url, kind='posters', callback=lambda path: self._decode_poster(token, path), errback=failed, priority=200)
        except Exception:
            failed()

    def _decode_poster(self, token, path):
        if self.cancelled.is_set() or token != self._art_token:
            return
        if not path or not os.path.isfile(path):
            self['poster_hint'].setText(ui_text(guide_tr('No poster')))
            return
        try:
            # Reuse one decoder; a stale callback cannot paint a different title.
            if self._decode_loader is not None:
                self._deferred_decode = (token, path)
                return
            self._decode_serial += 1
            serial = self._decode_serial
            loader = ePicLoad()
            self._decode_loader = loader
            self._deferred_decode = None
            def ready(*args):
                if serial != self._decode_serial:
                    return
                try:
                    if not self.cancelled.is_set() and token == self._art_token:
                        ptr = loader.getData()
                        if ptr is not None:
                            self['poster'].instance.setPixmap(ptr)
                            self['poster'].show()
                            self['poster_hint'].hide()
                        else:
                            self['poster_hint'].setText(ui_text(guide_tr('No poster')))
                finally:
                    self._decode_loader = None
                    self._decode_conn = None
                    deferred = self._deferred_decode
                    self._deferred_decode = None
                    if deferred and not self.cancelled.is_set():
                        self._decode_poster(*deferred)
            self._decode_conn = connect_picture_data(loader, ready, oneshot=True)
            size = scale_size(168,252)
            loader.setPara((size[0],size[1],1,1,False,1,'#00241E54'))
            if loader.startDecode(path) not in (0, None):
                raise RuntimeError('poster decode failed')
        except Exception:
            self._decode_loader = None
            self._decode_conn = None
            self['poster_hint'].setText(ui_text(guide_tr('No poster')))

    def _stop(self):
        self.cancelled.set()
        self.timer.stop()
        self._art_timer.stop()
        self._art_pending = None
        self._art_token += 1
        self._decode_serial += 1
        self._decode_loader = None
        self._decode_conn = None


# Screen-owned EPG action only. No wildcard, global key callback, or
# modification to the receiver's keymap. The host manages execBegin/execEnd.
def install_full_day_epg(screen, selected, source, info_opens_guide=False):
    context, action, priority = _guide_binding()
    _guide_log('Live guide action: %s / %s' % (context, action))

    def open_guide():
        _guide_log('Guide requested')
        if getattr(screen.session, 'current_dialog', screen) is not screen:
            _guide_log('Guide request ignored: Live is not current dialog')
            return 0
        try:
            item = selected()
            if not item or not isinstance(item, dict) or item.get('_replay_folder'):
                _guide_log('Guide request ignored: no selected live channel')
                return 1
            owner = item.get('_favorite_source') or source() or {}
            try:
                screen.session.open(FullDayEPGScreen, owner, item)
            except Exception as exc:
                _guide_log('Guide open failed: ' + type(exc).__name__)
                # Only retry if session did not switch to a partly created dialog.
                if not _is_openpli() or getattr(screen.session, 'current_dialog', screen) is not screen:
                    raise
                _guide_log('Trying guide without PIG / selection pixmap')
                screen.session.open(FullDayEPGScreen, owner, item, True)
        except Exception as exc:
            import traceback
            traceback.print_exc()
            _guide_log('Guide final failure: ' + type(exc).__name__)
            if _is_openpli() and getattr(screen.session, 'current_dialog', screen) is screen:
                try:
                    from Screens.MessageBox import MessageBox
                    screen.session.open(MessageBox, 'TV Guide: ' + type(exc).__name__ + '\n/tmp/tivimate_tvguide.log', type=MessageBox.TYPE_ERROR, timeout=8)
                except Exception:
                    pass
        return 1

    screen['fullDayEPGActions'] = ActionMap([context], {action: open_guide}, priority)
    screen.openFullDayEPG = open_guide

    # OpenPLi's short INFO uses its native release actions. Only the Live
    # player opts in; the catalogue and every other image keep their INFO.
    if info_opens_guide and _is_openpli():
        def open_info_guide():
            _guide_log('INFO pressed: opening TV Guide')
            return open_guide()

        # Reuse the existing player INFO handler (plugin-local make event).
        # Also accept the native OpenPLi release actions if that keymap is
        # used instead. No raw receiver-wide binding or keymap replacement.
        screen['actions'].actions['info'] = open_info_guide
        screen['pliInfoGuideNative'] = ActionMap(
            ['InfobarEPGActions'], {'showEventInfo': open_info_guide}, -20)
        screen['pliInfoGuideHotkey'] = ActionMap(
            ['HotkeyActions'], {'info': open_info_guide}, -20)
