# -*- coding: utf-8 -*-
"""Native Stalker bouquet -> EPGImport XMLTV bridge (Python 2.7 / 3).

Only exported channels are mapped. Uses the existing loopback bouquet service;
no new listening port, GUI work, permanent timer or portal requests at boot.
"""
from __future__ import absolute_import
import glob
import hashlib
import io
import os
import re
import tempfile
import threading
import time
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape
try:
    from urllib.parse import unquote, urlsplit
except ImportError:
    from urllib import unquote
    from urlparse import urlsplit
from .stalker_bouquet_resolver import _load, _identity, _sha, _text, HOST, PORT

EPG_DIR = '/etc/epgimport'
BOUQUET_DIR = '/etc/enigma2'
SOURCE_NAME = 'tivimate.stalker.sources.xml'
PREFIX = 'tivimate-stalker-'
PATH_RE = re.compile(r'^/epg/([a-f0-9]{64})\.xml$')
TOKEN_RE = re.compile(r'^/s/([a-f0-9]{32})$')
_MAP_LOCK = threading.Lock()
_FETCH_LOCK = threading.Lock()
_CACHE_AGE = 1800
_MAX_FILE = 12 * 1024 * 1024


def _mkdir(path):
    try:
        os.makedirs(path)
    except OSError:
        if not os.path.isdir(path):
            raise


def _clean(value, maximum=4096):
    # XML 1.0 forbids control characters, lone surrogates and FFFE/FFFF.
    return re.sub(u'[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]', u'', _text(value))[:maximum].strip()


def _atomic(path, data):
    fd, temp = tempfile.mkstemp(prefix='.tivimate-epg-', dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
        os.chmod(temp, 0o644)
        os.rename(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def _xml_bytes(root):
    return b'<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding='utf-8')


def _channel_id(item):
    return _text(item.get('ch_id') or item.get('stream_id') or item.get('id')).strip()


def _mapped(directory, sources):
    """Read actual service refs rather than inventing IDs or matching names."""
    registry = _load(directory)
    known = dict((_sha(_identity(s)), s) for s in sources or []
                 if isinstance(s, dict) and s.get('type') == 'stalker')
    groups = {}
    files = sorted(glob.glob(os.path.join(directory, 'userbouquet.*.tv')) +
                   glob.glob(os.path.join(directory, 'userbouquet.*.radio')))
    for path in files:
        try:
            with io.open(path, 'r', encoding='utf-8', errors='replace') as handle:
                for line in handle:
                    if not line.startswith('#SERVICE '):
                        continue
                    parts = line[9:].strip().split(':')
                    if len(parts) < 11 or not any(p.strip('0') for p in parts[3:7]):
                        continue
                    url = urlsplit(unquote(parts[10]))
                    if url.hostname != HOST or url.port != PORT:
                        continue
                    match = TOKEN_RE.match(url.path)
                    if not match:
                        continue
                    token = match.group(1)
                    saved = registry.get(token) or {}
                    sid = saved.get('source')
                    item = saved.get('item') or {}
                    cid = _channel_id(item)
                    if sid not in known or not cid:
                        continue
                    channels = groups.setdefault(sid, (known[sid], {}))[1]
                    entry = channels.setdefault(token, {'cid': cid, 'name': _clean(item.get('name') or cid, 256), 'refs': set()})
                    # Same type-1 IPTV reference convention as Xtream exporter.
                    entry['refs'].add('1:' + ':'.join(parts[1:10]) + ':http%3a//example.m3u8')
        except (IOError, OSError, ValueError):
            continue
    return groups


def _sources():
    from .core import get_sources
    return get_sources()


def sync_sources(directory=BOUQUET_DIR):
    """Publish EPGImport source and channel mapping, without portal traffic."""
    with _MAP_LOCK:
        groups = _mapped(directory, _sources())
        if not groups and not os.path.exists(os.path.join(EPG_DIR, SOURCE_NAME)):
            return 0
        _mkdir(EPG_DIR)
        root = ET.Element('sources')
        cat = ET.SubElement(root, 'sourcecat', {'sourcecatname': 'TiviMate Stalker'})
        keep = set()
        for sid, (source, channels) in sorted(groups.items()):
            name = PREFIX + sid + '.channels.xml'
            keep.add(name)
            mapping = ET.Element('channels')
            for token, entry in sorted(channels.items()):
                for ref in sorted(entry['refs']):
                    ET.SubElement(mapping, 'channel', {'id': 'stalker.' + token}).text = ref
            _atomic(os.path.join(EPG_DIR, name), _xml_bytes(mapping))
            node = ET.SubElement(cat, 'source', {'type': 'gen_xmltv', 'channels': name})
            # Include a short stable identity to distinguish same-name accounts.
            ET.SubElement(node, 'description').text = u'TiviMate - Stalker - %s [%s]' % (_clean(source.get('name') or 'Stalker', 120), sid[:8])
            ET.SubElement(node, 'url').text = 'http://%s:%d/epg/%s.xml' % (HOST, PORT, sid)
        dest = os.path.join(EPG_DIR, SOURCE_NAME)
        if groups:
            _atomic(dest, _xml_bytes(root))
        elif os.path.exists(dest):
            os.unlink(dest)
        for path in glob.glob(os.path.join(EPG_DIR, PREFIX + '*.channels.xml')):
            if os.path.basename(path) not in keep:
                try:
                    os.unlink(path)
                except OSError:
                    pass
        return len(groups)


def start_export(directory=BOUQUET_DIR):
    def work():
        try:
            sync_sources(directory)
        except Exception:
            pass
    t = threading.Thread(target=work, name='TiviMateStalkerEPGMap')
    t.daemon = True
    t.start()


def _bulk_rows(payload, allowed):
    """Support keyed MAG schedules and flat event arrays; never guess channel."""
    output = {}
    wrappers = ('js', 'data', 'epg', 'items', 'list', 'epg_listings', 'programs', 'results', 'channels', 'events')
    def visit(value, inherited='', depth=0):
        if depth > 8:
            return
        if isinstance(value, list):
            for row in value:
                visit(row, inherited, depth + 1)
        elif isinstance(value, dict):
            cid = _text(value.get('ch_id') or value.get('channel_id') or value.get('stream_id')).strip()
            if cid in ('', '0'):
                cid = inherited
            if cid in allowed and any(k in value for k in ('start_timestamp', 'begin_timestamp', 'start', 'begin', 'time', 'date_start')):
                if any(value.get(k) for k in ('title', 'name', 'programme', 'event_name')):
                    rows = output.setdefault(cid, [])
                    if len(rows) < 180:
                        rows.append(value)
                    return
            for key, child in value.items():
                key = _text(key)
                if key in allowed and isinstance(child, (list, dict)):
                    visit(child, key, depth + 1)
                elif key in wrappers and isinstance(child, (list, dict)):
                    visit(child, cid, depth + 1)
    visit(payload)
    return output


def _events(rows, cid, now):
    from .replay_compat import event_time
    out = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        actual = _text(row.get('ch_id') or row.get('channel_id') or row.get('stream_id')).strip()
        if actual not in ('', '0', cid):
            continue
        begin, end = event_time(row, True), event_time(row, False)
        if not end:
            # Some MAG portals use time_to as a relative duration.
            try:
                duration = int(row.get('time_to') or 0)
                if 0 < duration <= 86400:
                    end = begin + duration
            except (ValueError, TypeError, OverflowError):
                pass
        title = _clean(row.get('title') or row.get('name') or row.get('programme') or row.get('event_name'), 512)
        desc = _clean(row.get('description') or row.get('descr') or row.get('desc') or row.get('plot'), 1024)
        if title and begin > 0 and begin < end <= begin + 86400 and end > now - 3600 and begin < now + 3 * 86400:
            out[(begin, end, title)] = (begin, end, title, desc)
    return sorted(out.values())[:120]


def _cache_path(sid, channels):
    from .storage import data_path
    stamp = hashlib.sha256('|'.join(sorted(channels)).encode('ascii')).hexdigest()[:16]
    return data_path('epgimport_stalker', sid + '-' + stamp + '.xml')


def _stamp(epoch):
    return time.strftime('%Y%m%d%H%M%S +0000', time.gmtime(epoch))


def _publish(path, channels, events):
    """Stream XML to disk, no giant XML object or string retained in RAM."""
    fd, tmp = tempfile.mkstemp(prefix='.stalker-epg-', dir=os.path.dirname(path))
    size = 0
    try:
        with os.fdopen(fd, 'wb') as f:
            def put(value):
                data = value.encode('utf-8')
                f.write(data)
                return len(data)
            size += put(u'<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="TiviMate Stalker">\n')
            for token, entry in sorted(channels.items()):
                size += put(u'<channel id="stalker.%s"><display-name>%s</display-name></channel>\n' % (token, escape(entry['name'])))
            count = 0
            for token, entry in sorted(channels.items()):
                for begin, end, title, desc in events.get(entry['cid'], []):
                    line = u'<programme channel="stalker.%s" start="%s" stop="%s"><title>%s</title><desc>%s</desc></programme>\n' % (token, _stamp(begin), _stamp(end), escape(title), escape(desc))
                    if size + len(line.encode('utf-8')) + 16 > _MAX_FILE:
                        break
                    size += put(line)
                    count += 1
            put(u'</tv>\n')
        if not count:
            return False
        os.rename(tmp, path)
        return True
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def _prior_events(path, channels, now):
    """Reuse only valid previous events when a portal supplies partial data."""
    out = {}
    if not os.path.isfile(path) or os.path.getsize(path) > _MAX_FILE:
        return out
    try:
        # Files are created by this plugin, not parsed directly from a provider.
        with open(path, 'rb') as f:
            for event, node in ET.iterparse(f, events=('end',)):
                if node.tag == 'programme':
                    token = node.get('channel', '').replace('stalker.', '', 1)
                    entry = channels.get(token)
                    if entry:
                        import calendar
                        begin = calendar.timegm(time.strptime(node.get('start'), '%Y%m%d%H%M%S +0000'))
                        end = calendar.timegm(time.strptime(node.get('stop'), '%Y%m%d%H%M%S +0000'))
                        if end > now - 3600 and begin < now + 3 * 86400:
                            out.setdefault(entry['cid'], set()).add((begin, end, _clean(node.findtext('title'), 512), _clean(node.findtext('desc'), 1024)))
                    node.clear()
                elif node.tag == 'channel':
                    node.clear()
        return dict((cid, sorted(rows)[:120]) for cid, rows in out.items())
    except Exception:
        return {}


def _generate(source, channels, path, cancel):
    from .core import get_source_client
    now = int(time.time())
    ids = set(entry['cid'] for entry in channels.values())
    client = get_source_client(source)
    events = _prior_events(path, channels, now)
    # Prefer one MAG bulk EPG request. Many portals return js.data keyed by ID.
    try:
        payload = client._call_retry(_cancel_event=cancel, type='itv', action='get_epg_info', period=24, JsHttpRequest='1-xml')
        bulk = _bulk_rows(payload, ids)
        for cid, rows in bulk.items():
            fresh = _events(rows, cid, now)
            if fresh:
                events[cid] = fresh
        del payload, bulk
    except Exception:
        pass
    if cancel.is_set():
        return False
    # Publish bulk data immediately; fallback only for channels without current
    # or future events, sequentially and within a bounded time budget.
    if any(events.values()):
        _publish(path, channels, events)
    missing = sorted(cid for cid in ids if not any(r[1] > now for r in events.get(cid, [])))
    for index, cid in enumerate(missing):
        if cancel.is_set():
            break
        try:
            rows = client.short_epg(cid, limit=20)
            fresh = _events(rows, cid, now)
            if fresh:
                events[cid] = fresh
                if index == 0 or index % 8 == 7 or not os.path.exists(path):
                    _publish(path, channels, events)
        except Exception:
            pass
    return _publish(path, channels, events)


def get_feed(sid, directory=BOUQUET_DIR):
    """Return a local XMLTV path. Single background fetch for the receiver.

    The HTTP worker may wait briefly for first data; never blocks the GUI.
    Old snapshots remain usable while refreshing. A failed first request gives
    HTTP 503, not a fabricated or empty EPG.
    """
    groups = _mapped(directory, _sources())
    if sid not in groups:
        return None
    source, channels = groups[sid]
    path = _cache_path(sid, channels)
    if os.path.isfile(path) and time.time() - os.path.getmtime(path) < _CACHE_AGE:
        return path
    if _FETCH_LOCK.acquire(False):
        cancel = threading.Event()
        def work():
            # Bound the fallback loop; a single in-flight portal call still
            # obeys its own transport timeout. No forced thread termination.
            timer = threading.Timer(90.0, cancel.set)
            timer.daemon = True
            timer.start()
            try:
                _generate(source, channels, path, cancel)
            except Exception:
                pass
            finally:
                timer.cancel()
                _FETCH_LOCK.release()
        t = threading.Thread(target=work, name='TiviMateStalkerEPGImport')
        t.daemon = True
        try:
            t.start()
        except Exception:
            _FETCH_LOCK.release()
            raise
    # Existing cached file is served immediately. First import waits at most
    # 20 seconds for bulk or first fallback result to be published.
    until = time.time() + 20
    while not os.path.isfile(path) and _FETCH_LOCK.locked() and time.time() < until:
        time.sleep(0.2)
    return path if os.path.isfile(path) else None
