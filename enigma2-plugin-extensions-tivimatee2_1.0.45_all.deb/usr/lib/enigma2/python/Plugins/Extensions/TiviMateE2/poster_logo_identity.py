# -*- coding: utf-8 -*-
"""Verified logo identity for titles containing a release year.

No GUI or poster requests here: the optional TMDb lookup runs only in logo
workers; verified identities survive GUI restarts in the ordinary cache.
Never use IPTV stream IDs as TMDb IDs and never match by title alone when
multiple movies share a name (remakes).
"""
import re
import threading
import time

try:
    from .py27_compat import text_type as _text
except ImportError:
    try:
        _text = unicode
    except NameError:
        _text = str

_YEAR_SUFFIX = re.compile(u"^(.*?)\\s*[\\(\\[（]\\s*((?:19|20)\\d{2})\\s*[\\)\\]）]\\s*$", re.U)
_YEAR_TRAIL = re.compile(u"^(.*?)\\s+(?:[-–—]\\s*)?((?:19|20)\\d{2})\\s*$", re.U)
_YEAR_VALUE = re.compile(u"^(?:19|20)\\d{2}(?:$|[-/.])", re.U)
_TECH_TAIL = re.compile(r"\s*[\[\(]\s*(?:4k|8k|uhd|fhd|hd|1080p|2160p|720p|hdr|hevc|x265|x264|sub|dub)\s*[\]\)]\s*$", re.I | re.U)
_TECH_PLAIN = re.compile(r"\s+(?:4k|8k|uhd|fhd|1080p|2160p|720p|hdr|hevc|x265|x264)\s*$", re.I | re.U)
_LOCK = threading.RLock()
_MEMO = {}


def _as_text(value):
    try:
        if isinstance(value, bytes):
            return value.decode('utf-8', 'replace')
        return _text(value if value is not None else u'')
    except Exception:
        try:
            return _text(str(value or ''))
        except Exception:
            return u''


def split_title_year(value):
    """Only strip a terminal *metadata* year, never a number within a title."""
    text = u' '.join(_as_text(value).split())
    try:
        from .display_titles import clean_display_title
        # Strip IPTV tags such as [4K] after the year, not the movie title.
        text = clean_display_title(text) or text
    except Exception:
        pass
    for _ in range(3):
        result = _TECH_PLAIN.sub(u'', _TECH_TAIL.sub(u'', text)).strip()
        if result == text:
            break
        text = result
    for regex in (_YEAR_SUFFIX, _YEAR_TRAIL):
        hit = regex.match(text)
        if hit and hit.group(1).strip() and any(c.isalpha() for c in hit.group(1)):
            # A future number like "Blade Runner 2049" is part of the title.
            if regex is _YEAR_TRAIL and int(hit.group(2)) > max(2027, time.localtime().tm_year + 2):
                continue
            return hit.group(1).strip(), hit.group(2)
    return text, ''


def movie_year(row):
    if not isinstance(row, dict):
        return ''
    for entry in (row, row.get('info') if isinstance(row.get('info'), dict) else {}):
        for name in ('release_date', 'releaseDate', 'year', 'release_year', 'first_air_date'):
            year = _as_text(entry.get(name)).strip()[:4]
            if _YEAR_VALUE.match(year):
                return year
    for name in ('name', 'title', '_part_title', 'original_title'):
        _, year = split_title_year(row.get(name))
        if year:
            return year
    return ''


def existing_id(row):
    if not isinstance(row, dict):
        return ''
    for entry in (row, row.get('info') if isinstance(row.get('info'), dict) else {}):
        for name in ('_locked_tmdb_id', 'tmdb_id', 'tmdb', 'tmdbId', 'tmdbid'):
            value = _as_text(entry.get(name)).strip()
            if value.isdigit() and int(value) > 0:
                return str(int(value))
    return ''


def verified_search_id(client, title, row, kind='vod', cancelled=None):
    """Worker-only search when provider lacks a verified ID; year is mandatory."""
    cancelled = cancelled or (lambda: False)
    if cancelled():
        return ''
    ident = existing_id(row)
    if ident:
        return ident
    name, title_year = split_title_year(title)
    year = title_year or movie_year(row)
    if not name or not year:
        return ''
    from .actor_match import title_key
    from .cache_manager import stable_cache_key, persistent_cache_get, persistent_cache_set
    lookup_key = (str(kind), title_key(name), year)
    if not lookup_key[1]:
        return ''
    with _LOCK:
        if lookup_key in _MEMO:
            return _MEMO[lookup_key]
        key = stable_cache_key('year_logo_title_id_v1', *lookup_key)
        try:
            saved = persistent_cache_get(key)
            if isinstance(saved, dict):
                saved_id = _as_text(saved.get('tmdb_id'))
                if saved_id.isdigit() and int(saved_id) > 0:
                    _MEMO[lookup_key] = saved_id
                    return saved_id
        except Exception:
            pass
        if cancelled():
            return ''
        try:
            result = client.search_title(name, kind, year=year) or {}
        except Exception:
            return ''
        if cancelled() or not isinstance(result, dict):
            return ''
        found_year = _as_text(result.get('release_date') or result.get('first_air_date'))[:4]
        found_id = _as_text(result.get('id'))
        # Year verification prevents using a remake's cached logo by accident.
        if found_year != year or not found_id.isdigit() or int(found_id) < 1:
            return ''
        try:
            confirmed = bool(client.title_matches(name, result, kind))
        except Exception:
            confirmed = False
        if not confirmed:
            return ''
        _MEMO[lookup_key] = found_id
        try:
            persistent_cache_set(key, 'year_logo_identity', {'tmdb_id': found_id}, 90*86400)
        except Exception:
            pass
        return found_id
