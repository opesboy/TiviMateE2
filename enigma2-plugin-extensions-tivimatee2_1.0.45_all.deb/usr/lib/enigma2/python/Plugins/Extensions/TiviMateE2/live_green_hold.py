# -*- coding: utf-8 -*-
"""LIVE-only GREEN short/hold dispatcher (Python 2.7 and 3).

Short GREEN = search, hold GREEN = filter.

Earlier versions decided only on the key *release* after a "long" event.
Some Enigma2 images send no long event, and some send no release after a
long press, so holding GREEN never opened the filter. Now a hold is
detected by a GUI timer from the key press itself (the native long event,
when present, just triggers it sooner); the filter opens exactly once and
the following release is swallowed.
"""
from Components.ActionMap import ActionMap

try:
    from enigma import eTimer
except Exception:  # pragma: no cover
    eTimer = None

HOLD_MS = 650


def install_live_green_hold(screen, search_action, filter_action):
    state = {'down': False, 'fired': False}
    timer = eTimer() if eTimer is not None else None

    def fire_hold():
        if state['down'] and not state['fired']:
            state['fired'] = True
            if timer is not None:
                timer.stop()
            filter_action()

    if timer is not None:
        try:
            state['conn'] = timer.timeout.connect(fire_hold)
        except Exception:
            timer.callback.append(fire_hold)
        try:
            screen.onClose.append(timer.stop)
        except Exception:
            pass

    def on_make():
        state['down'] = True
        state['fired'] = False
        if timer is not None:
            timer.stop()
            timer.start(HOLD_MS, True)
        return 1

    def on_long():
        fire_hold()
        return 1

    def on_break():
        if timer is not None:
            timer.stop()
        was_down, fired = state['down'], state['fired']
        state['down'] = False
        state['fired'] = False
        if was_down and not fired:
            search_action()
        return 1

    screen['liveGreenHoldActions'] = ActionMap(
        ['TiviMateLiveGreenActions'],
        {'liveGreenMake': on_make,
         'liveGreenLong': on_long,
         'liveGreenBreak': on_break}, -3)
