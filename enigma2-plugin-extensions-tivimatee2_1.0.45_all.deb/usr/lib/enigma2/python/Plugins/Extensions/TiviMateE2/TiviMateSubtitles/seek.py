# -*- coding: UTF-8 -*-
#################################################################################
#
#    This module is part of SubsSupport plugin
#    Coded by mx3L (c) 2014
#
#    This program is free software; you can redistribute it and/or
#    modify it under the terms of the GNU General Public License
#    as published by the Free Software Foundation; either version 2
#    of the License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#################################################################################

from __future__ import absolute_import
import os
import shutil
import socket
import threading
import time
import traceback
import zipfile
import re
import tempfile
try:
    from .parsers.ass2srt import Ass2srt
except (ValueError, ImportError):
    from parsers.ass2srt import Ass2srt


try:
    from .seekers import SubtitlesDownloadError, SubtitlesSearchError, \
        SubtitlesErrors, Addic7edSeeker, SubtitlesmoraSeeker, NovalermoraSeeker, ElsubtitleSeeker, SubtitlecatSeeker, OpenSubtitles2Seeker, OpenSubtitlesComFNCSeeker, TitulkyComSeeker, \
        PodnapisiSeeker, Subf2mSeeker, LocalDriveSeeker, IndexsubtitleSeeker, SubsytsSeeker, MoviesubtitlesSeeker, Sub_Scene_comSeeker, SubdlSeeker, \
         TitloviSeeker, MySubsSeeker, SubsourceSeeker, FoursubSeeker, YtssubsSeeker, WyzieSeeker, TvsubsSeeker
    from .seekers.seeker import BaseSeeker
    from .seekers.utilities import languageTranslate, langToCountry, \
        getCompressedFileType, detectSearchParams
    from .utils import SimpleLogger, toString
except (ValueError, ImportError):
    from seekers import SubtitlesDownloadError, SubtitlesSearchError, \
        SubtitlesErrors, Addic7edSeeker, SubtitlesmoraSeeker, NovalermoraSeeker, ElsubtitleSeeker, SubtitlecatSeeker, OpenSubtitles2Seeker, OpenSubtitlesComFNCSeeker, TitulkyComSeeker, \
        PodnapisiSeeker, Subf2mSeeker, LocalDriveSeeker, IndexsubtitleSeeker, SubsytsSeeker, MoviesubtitlesSeeker, Sub_Scene_comSeeker, SubdlSeeker, \
         TitloviSeeker, MySubsSeeker, SubsourceSeeker, FoursubSeeker, YtssubsSeeker, WyzieSeeker, TvsubsSeeker
    from seekers.seeker import BaseSeeker
    from seekers.utilities import languageTranslate, langToCountry, \
        getCompressedFileType, detectSearchParams
    from utils import SimpleLogger, toString

import six


try:
    from .seekers.utilities import normalize_search_languages as _normalize_search_languages
except (ImportError, ValueError):
    from seekers.utilities import normalize_search_languages as _normalize_search_languages

SUBTITLES_SEEKERS = []
SUBTITLES_SEEKERS.append(LocalDriveSeeker)
# Current no-API providers first (2026 refresh).
SUBTITLES_SEEKERS.append(MoviesubtitlesSeeker)
SUBTITLES_SEEKERS.append(SubtitlesmoraSeeker)
SUBTITLES_SEEKERS.append(Subf2mSeeker)
SUBTITLES_SEEKERS.append(Addic7edSeeker)
SUBTITLES_SEEKERS.append(SubtitlecatSeeker)
SUBTITLES_SEEKERS.append(TvsubsSeeker)
SUBTITLES_SEEKERS.append(PodnapisiSeeker)
# Independent API providers.
SUBTITLES_SEEKERS.append(SubdlSeeker)
# Keep the legacy Os.org.fnc ID and settings intact.
SUBTITLES_SEEKERS.append(OpenSubtitles2Seeker)
# Additional Os.com.fnc entry, using the same maintained REST backend.
SUBTITLES_SEEKERS.append(OpenSubtitlesComFNCSeeker)
SUBTITLES_SEEKERS.append(WyzieSeeker)
SUBTITLES_SEEKERS.append(SubsourceSeeker)
# Remaining/legacy providers are still available, but searched after the current set.
SUBTITLES_SEEKERS.append(SubsytsSeeker)
SUBTITLES_SEEKERS.append(YtssubsSeeker)
SUBTITLES_SEEKERS.append(ElsubtitleSeeker)
SUBTITLES_SEEKERS.append(MySubsSeeker)
SUBTITLES_SEEKERS.append(FoursubSeeker)
SUBTITLES_SEEKERS.append(IndexsubtitleSeeker)
SUBTITLES_SEEKERS.append(TitulkyComSeeker)
SUBTITLES_SEEKERS.append(TitloviSeeker)
SUBTITLES_SEEKERS.append(Sub_Scene_comSeeker)
SUBTITLES_SEEKERS.append(NovalermoraSeeker)

def _diag_print(*args, **kwargs):
    return None


try:
    from .provider_diagnostics import error_reason as _tm_provider_error, record as _tm_diag
except (ImportError, ValueError):
    from provider_diagnostics import error_reason as _tm_provider_error, record as _tm_diag


class ErrorSeeker(BaseSeeker):
    def __init__(self, wseeker_cls, tmp_path, download_path, settings=None, settings_provider=None, captcha_cb=None, delay_cb=None, message_cb=None):
        self.id = wseeker_cls.id
        self.error = wseeker_cls.error
        self.provider_name = wseeker_cls.provider_name
        self.supported_langs = wseeker_cls.supported_langs
        self.description = getattr(wseeker_cls, 'description', "")
        self.tvshow_search = getattr(wseeker_cls, 'tvshow_search', True)
        self.movie_search = getattr(wseeker_cls, 'movie_search', True)
        self.default_settings = getattr(wseeker_cls, 'default_settings', dict())
        # Failed providers still appear in settings; callbacks are not file paths.
        BaseSeeker.__init__(self, tmp_path, download_path, settings, settings_provider, logo=None)
        _tm_diag('provider import or init failed', self.id, self.error)

    def close(self):
        pass


# Validate the actual downloaded data before SubsSupport returns a success path.
# Provider filenames and HTTP status are not evidence of a subtitle file.
_SUB_TIME = re.compile(r"^(?:(\d{1,3}):)?(\d{1,2}):(\d{2})[,.](\d{1,3})$")
_SUB_ARROW = re.compile(r"\s*-->\s*")
_SUB_MICRODVD = re.compile(r"(?m)^\{(\d+)\}\{(\d+)\}(.+)$")
_SUB_ASS_TIME = re.compile(r"^\d+:\d{2}:\d{2}\.\d{1,2}$")
_MAX_SUBTITLE_BYTES = 400 * 1024  # matches SubsLoader's size limit


def _subtitle_time_ms(value):
    m = _SUB_TIME.match(value.strip())
    if not m:
        return None
    h, minute, sec, frac = m.groups()
    if int(minute) >= 60 or int(sec) >= 60:
        return None
    return ((int(h or 0) * 3600 + int(minute) * 60 + int(sec)) * 1000
            + int(frac.ljust(3, '0')[:3]))


def _decode_subtitle_data(raw):
    if raw.startswith((b'\xff\xfe', b'\xfe\xff')):
        try:
            return raw.decode('utf-16')
        except UnicodeError:
            return None
    for encoding in ('utf-8-sig', 'utf-8', 'cp1256', 'cp1252', 'iso-8859-6'):
        try:
            return raw.decode(encoding)
        except UnicodeError:
            pass
    return None


def _subtitle_cues(text):
    """Return actual timed subtitle cues, not merely a timestamp header."""
    text = text.replace('\r\n', '\n').replace('\r', '\n').lstrip('\ufeff')
    cues = []
    for block in re.split(r'\n[ \t]*\n+', text):
        lines = block.strip().split('\n')
        for i, line in enumerate(lines):
            if '-->' not in line:
                continue
            parts = _SUB_ARROW.split(line.strip(), 1)
            if len(parts) != 2:
                continue
            # WebVTT can append position/alignment settings after the end time.
            end_token = parts[1].split()[0] if parts[1].split() else ''
            start = _subtitle_time_ms(parts[0]); end = _subtitle_time_ms(end_token)
            if start is None or end is None or end <= start:
                continue
            body = '\n'.join(lines[i + 1:]).strip()
            visible = re.sub(r'<[^>]*>|\{[^}]*\}', '', body).strip()
            if not visible or body.lower().startswith(('<!doctype', '<html')):
                continue
            cues.append((start, end, body))
            break
    return cues


def _subtitle_format(path):
    """(format, text, cues) or raise with a clear cause."""
    try:
        if not os.path.isfile(path) or os.path.getsize(path) == 0:
            raise ValueError('empty subtitle file')
        if os.path.getsize(path) > _MAX_SUBTITLE_BYTES:
            raise ValueError('subtitle exceeds supported size')
        with open(path, 'rb') as f:
            raw = f.read(_MAX_SUBTITLE_BYTES + 1)
        text = _decode_subtitle_data(raw)
        if text is None:
            raise ValueError('unknown subtitle text encoding')
        beginning = text.lstrip('\ufeff \t\r\n').lower()
        if beginning.startswith(('<!doctype', '<html', '<head', '<body', '{"error"', '{"message"', '{"status"')):
            raise ValueError('provider returned a web/error page')
        if '\x00' in text[:200]:
            raise ValueError('binary file instead of subtitles')
        cues = _subtitle_cues(text)
        if cues:
            # A good first cue does not excuse a broken or empty later cue.
            # Do not require an arbitrary number of captions: forced tracks
            # can legitimately contain just one caption.
            timing_lines = re.findall(r'(?m)^\s*(?:\d{1,3}:)?\d{1,2}:\d{2}[^\n]*?-->[^\n]*', text)
            if len(timing_lines) != len(cues):
                raise ValueError('incomplete or malformed timed subtitle cues')
            if beginning.startswith('webvtt') or path.lower().endswith('.vtt'):
                return 'vtt', text, cues
            return 'srt', text, cues
        # ASS and SSA use Dialogue lines.  Those are parsed by AssParser.
        count = 0
        for line in text.splitlines():
            if not line.lstrip().lower().startswith('dialogue:'):
                continue
            fields = line.split(':', 1)[1].split(',', 9)
            if len(fields) >= 10 and _SUB_ASS_TIME.match(fields[1].strip()) and _SUB_ASS_TIME.match(fields[2].strip()) and fields[9].strip():
                count += 1
        if count >= 2:
            return 'ass', text, ()
        # MicroDVD and SubViewer subtitles use .sub extensions.
        if _SUB_MICRODVD.search(text) or re.search(r'(?m)^\d{1,2}:\d{2}:\d{2}[,.]\d+\s*,\s*\d{1,2}:\d{2}:\d{2}[,.]\d+', text):
            return 'sub', text, ()
    except (IOError, OSError) as exc:
        raise ValueError('subtitle could not be read: %s' % exc)
    raise ValueError('no readable timed subtitle lines')


def _validated_subtitle(path, tmp_path):
    """Select a playable filename; normalize VTT and dotted SRT to SRT."""
    fmt, text, cues = _subtitle_format(path)
    ext = os.path.splitext(path)[1].lower()
    # UTF-16 is a valid download, but the playback parser typically works
    # with UTF-8/legacy single-byte encodings. Normalize UTF-16 once.
    with open(path, 'rb') as original:
        utf16 = original.read(2) in (b'\xff\xfe', b'\xfe\xff')
    if (fmt == 'srt' and ext in ('.srt', '.sub') and not utf16
            and not re.search(r'(?m)^\s*\d{1,3}:\d{2}:\d{2}\.\d+\s*-->', text)):
        return path
    if fmt == 'ass' and ext in ('.ass', '.ssa'):
        return path
    if fmt == 'sub' and ext == '.sub':
        return path
    # SubRipParser only handles comma timestamps. Use the same format for VTT,
    # mislabeled .txt, .sub or dot-timestamped SRT, preserving cue text.
    if fmt == 'ass':
        raise ValueError('ASS subtitle has an unsupported filename extension')
    if fmt == 'sub':
        raise ValueError('MicroDVD subtitle has an unsupported filename extension')
    os.makedirs(tmp_path, exist_ok=True)
    stem = re.sub(r'[^A-Za-z0-9_-]', '_', os.path.splitext(os.path.basename(path))[0])[:45]
    fd, output = tempfile.mkstemp(prefix=stem + '_', suffix='.srt', dir=tmp_path)
    try:
        with os.fdopen(fd, 'wb') as f:
            for i, (start, end, body) in enumerate(cues, 1):
                def stamp(ms):
                    return '%02d:%02d:%02d,%03d' % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)
                f.write(('%d\n%s --> %s\n%s\n\n' % (i, stamp(start), stamp(end), body)).encode('utf-8'))
        # This final check matches the file sent to the subtitle renderer.
        if not _subtitle_cues(_decode_subtitle_data(open(output, 'rb').read())):
            raise ValueError('normalized subtitle has no readable cues')
    except Exception:
        try:
            os.unlink(output)
        except OSError:
            pass
        raise
    return output


class SubsSeeker(object):
    SUBTILES_EXTENSIONS = ['.srt', '.sub', '.ass', '.ssa', '.vtt', '.txt']

    def __init__(self, download_path, tmp_path, captcha_cb, delay_cb, message_cb, settings=None, settings_provider_cls=None, settings_provider_args=None, debug=False, providers=None):
        self.log = SimpleLogger(self.__class__.__name__, log_level=debug and SimpleLogger.LOG_DEBUG or SimpleLogger.LOG_INFO)
        self.download_path = toString(download_path)
        self.tmp_path = toString(tmp_path)
        self.seekers = []
        providers = providers or SUBTITLES_SEEKERS
        for seeker in providers:
            provider_id = seeker.id
            default_settings = dict(seeker.default_settings)
            default_settings['enabled'] = {'type': 'yesno', 'default': True, 'label': 'Enabled', 'pos': -1}
            seeker.default_settings = default_settings
            provider_settings = (settings or {}).get(provider_id)
            settings_provider = None
            if settings_provider_cls is not None:
                try:
                    settings_provider = settings_provider_cls(provider_id, default_settings, settings_provider_args)
                except Exception as exc:
                    _tm_diag('provider settings initialization failed', provider_id, exc)
                    # Keep the row visible and isolate the failure. Do not silently
                    # run a provider with different credentials or enabled state.
                    broken = type('Unavailable_' + seeker.__name__, (seeker,), {'error': exc})
                    self.seekers.append(ErrorSeeker(broken, tmp_path, download_path,
                        provider_settings, None, captcha_cb, delay_cb, message_cb))
                    continue
            if getattr(seeker, 'error', None) is not None:
                self.seekers.append(ErrorSeeker(seeker, tmp_path, download_path,
                    provider_settings, settings_provider, captcha_cb, delay_cb, message_cb))
            else:
                self._append_seeker(seeker, tmp_path, download_path,
                    provider_settings, settings_provider, captcha_cb, delay_cb, message_cb)


    def _append_seeker(self, seeker, *args):
        try:
            self.seekers.append(seeker(*args))
        except Exception as exc:
            # A broken optional provider cannot prevent the others from loading.
            try:
                broken = type('Unavailable_' + seeker.__name__, (seeker,), {'error': exc})
                self.seekers.append(ErrorSeeker(broken, *args))
            except Exception:
                _tm_diag("provider constructor failed", seeker.id, exc)


    def getSubtitlesSimple(self, updateCB=None, title=None, filepath=None, langs=None):
        title, year, tvshow, season, episode = detectSearchParams(title or filepath)
        seekers = self.getProviders(langs)
        return self.getSubtitles(seekers, updateCB, title, filepath, langs, year, tvshow, season, episode)

    def getSubtitles(self, providers, updateCB=None, title=None, filepath=None, langs=None, year=None, tvshow=None, season=None, episode=None, timeout=10):
        langs = _normalize_search_languages(langs)
        self.log.info('getting subtitles list - title: %s, filepath: %s, year: %s, tvshow: %s, season: %s, episode: %s' % (
            toString(title), toString(filepath), toString(year), toString(tvshow), toString(season), toString(episode)))
        subtitlesDict = {}
        threads = []
        # r306: protect low-powered Enigma2 receivers from a network storm.
        # BLUE search still queries the same providers, but at most four provider
        # workers may perform network/parser work at the same time.  The search
        # already runs in the external tivimate_provider_search.py process, so
        # this cap reduces CPU/TLS/socket pressure without touching the GUI/player.
        # r337: honor the caller/provider timeout.  The previous hard 8-second
        # ceiling caused slower providers to be cut off before returning results.
        try:
            timeout = float(timeout)
        except Exception:
            timeout = 10.0
        previous_socket_timeout = socket.getdefaulttimeout()
        socket.setdefaulttimeout(timeout)
        lock = threading.Lock()
        provider_slots = threading.BoundedSemaphore(4)

        def _boundedSearch(*args):
            provider_slots.acquire()
            try:
                return self._searchSubtitles(*args)
            finally:
                provider_slots.release()
        try:
            for provider in providers or []:
                if isinstance(provider, six.string_types):
                    provider_id = provider
                    provider = self.getProvider(provider)
                else:
                    provider_id = getattr(provider, 'id', 'unknown')
                if provider is None or getattr(provider, 'error', None) is not None:
                    reason = 'Provider unavailable' if provider is None else _tm_provider_error(getattr(provider, 'error', None))
                    subtitlesDict[provider_id] = {'message': reason, 'status': False, 'list': []}
                    if updateCB is not None:
                        updateCB(provider_id, False, reason)
                    continue
                worker = threading.Thread(target=_boundedSearch, args=(lock, subtitlesDict, updateCB, provider, title, filepath, langs, season, episode, tvshow, year))
                worker._tm_provider = provider_id
                worker.setDaemon(True)
                threads.append(worker)
            for worker in threads:
                worker.start()
            # Give queued providers a fair chance within the 100-second GUI watchdog.
            waves = max(1, (len(threads) + 3) // 4)
            deadline = time.time() + min(90.0, max(30.0, timeout * (waves + 1) + 15.0))
            while any(worker.is_alive() for worker in threads):
                if time.time() >= deadline:
                    break
                time.sleep(0.2)
            with lock:
                for worker in threads:
                    if worker.is_alive() and worker._tm_provider not in subtitlesDict:
                        subtitlesDict[worker._tm_provider] = {'message': 'Provider timeout', 'status': False, 'list': []}
                        _tm_diag('provider deadline exceeded', worker._tm_provider)
                subtitlesDict = dict(subtitlesDict)
        finally:
            socket.setdefaulttimeout(previous_socket_timeout)
        return subtitlesDict

    def getSubtitlesList(self, subtitles_dict, provider=None, langs=None, synced=False, nonsynced=False):
        """Merge provider results, tolerating incomplete legacy FNC metadata.

        Some providers return language_name without country (or the reverse),
        omit sync, or send malformed entries.  One incomplete row should not
        cause the entire search-result screen to fail.
        """
        subtitles_list = []
        for provider_id, payload in (subtitles_dict or {}).items():
            if provider and provider != provider_id:
                continue
            if not isinstance(payload, dict):
                continue
            for sub in payload.get('list', []) or []:
                if not isinstance(sub, dict):
                    continue
                if not sub.get('provider'):
                    sub['provider'] = provider_id
                if not sub.get('language_name'):
                    sub['language_name'] = sub.get('language') or sub.get('lang') or sub.get('country') or 'Unknown'
                if not sub.get('country'):
                    sub['country'] = (langToCountry(languageTranslate(sub.get('language_name'), 0, 2)) or
                                      sub.get('lang') or '')
                sub.setdefault('sync', False)
                subtitles_list.append(sub)
        if synced:
            subtitles_list = [sub for sub in subtitles_list if sub.get('sync')]
        elif nonsynced:
            subtitles_list = [sub for sub in subtitles_list if not sub.get('sync')]
        if langs:
            valid_languages = [languageTranslate(lang, 0, 2) for lang in langs]
            subtitles_list = [sub for sub in subtitles_list
                              if languageTranslate(sub.get('language_name'), 0, 2) in valid_languages]
        return subtitles_list

    def sortSubtitlesList(self, subtitles_list, langs=None, sort_langs=False, sort_rank=False, sort_sync=False, sort_provider=False):
        def sortLangs(x):
            for idx, lang in enumerate(langs):
                if languageTranslate(x['language_name'], 0, 2) == lang:
                    return idx
            return len(langs)
        if langs and sort_langs:
            return sorted(subtitles_list, key=sortLangs)
        if sort_provider:
            return sorted(subtitles_list, key=lambda x: x['provider'])
        if sort_rank:
            return subtitles_list
        if sort_sync:
            return sorted(subtitles_list, key=lambda x: x['sync'], reverse=True)
        return subtitles_list

    def downloadSubtitle(self, selected_subtitle, subtitles_dict, choosefile_cb, path=None, fname=None, overwrite_cb=None, settings=None):
        self.log.info('downloading subtitle "%s" with settings "%s"' % (selected_subtitle['filename'], toString(settings) or {}))
        if settings is None:
            settings = {}
        seeker = None
        for provider_id in subtitles_dict.keys():
            if selected_subtitle in subtitles_dict[provider_id]['list']:
                seeker = self.getProvider(provider_id)
                break
        if seeker is None:
            self.log.error('provider for "%s" subtitle was not found', selected_subtitle.get('filename', ''))
            raise SubtitlesDownloadError(msg='Subtitle provider was not found; search again and select a fresh result')
        # Retry once for a transient empty/invalid payload before showing the
        # chooser. Never repeat a paid API download or a local file operation.
        provider_tag = re.sub(r'[^a-z0-9]', '', str(provider_id).lower())
        limited = any(tag in provider_tag for tag in ('localdrive', 'opensubtitles', 'osorg', 'oscom', 'subdl', 'subsource', 'wyzie'))
        max_attempts = 1 if limited else 2
        for attempt in range(max_attempts):
            try:
                lang, filepath = seeker.download(subtitles_dict[provider_id], selected_subtitle)[1:3]
            except SubtitlesDownloadError as exc:
                # Retry only explicit transient failures, not credentials,
                # CAPTCHA, quota or arbitrary provider errors.
                detail = (str(exc) + ' ' + str(getattr(exc, 'wrapped_error', ''))).lower()
                transient = (getattr(exc, 'code', None) == SubtitlesErrors.TIMEOUT_ERROR or
                             (getattr(exc, 'code', None) == SubtitlesErrors.UNKNOWN_ERROR and
                              any(token in detail for token in ('timed out', 'timeout', 'returned no subtitle file', 'empty subtitle', 'incomplete subtitle http body'))))
                if attempt + 1 < max_attempts and transient:
                    time.sleep(0.8)
                    continue
                raise
            reasons = []
            good_files = []
            if filepath and os.path.isfile(filepath):
                try:
                    compressed = getCompressedFileType(filepath)
                    candidates = self._unpack_subtitles(filepath, self.tmp_path) if compressed else [filepath]
                except (zipfile.BadZipFile, EOFError, IOError, OSError, ValueError) as exc:
                    reasons.append(str(exc))
                    candidates = []
                for candidate in candidates:
                    try:
                        good_files.append(_validated_subtitle(toString(candidate), self.tmp_path))
                    except (ValueError, IOError, OSError) as exc:
                        reasons.append('%s: %s' % (os.path.basename(toString(candidate)), exc))
            else:
                reasons.append('missing temporary subtitle file')
            if good_files:
                break
            self.log.error('No valid subtitle cues after download: %s' % '; '.join(reasons[:4]))
            if attempt + 1 < max_attempts:
                time.sleep(0.8)
        subfiles = good_files
        if not subfiles:
            raise SubtitlesDownloadError(msg='Downloaded file contains no playable subtitles')
        if len(subfiles) == 0:
            self.log.error("no subtitles were downloaded!")
            raise SubtitlesDownloadError(msg="[error] no subtitles were downloaded")
        elif len(subfiles) == 1:
            self.log.debug('found one subtitle: "%s"', str(subfiles))
            subfile = subfiles[0]
        else:
            self.log.debug('found more subtitles: "%s"', str(subfiles))
            subfile = choosefile_cb(subfiles)
            if subfile is None:
                self.log.debug('no subtitles file choosed!')
                return
            self.log.debug('selected subtitle: "%s"', subfile)
        ext = os.path.splitext(subfile)[1].lower()
        # if ext == '.ass':
            # conv = Ass2srt(subfile)
            # srt_path = conv.output_name()       # same base name, .srt
            # conv.to_srt(name=srt_path)          # write .srt
            # subfile = srt_path
            # ext = '.srt'
        if ext not in self.SUBTILES_EXTENSIONS:
            ext = os.path.splitext(toString(selected_subtitle['filename']))[1]
            if ext not in self.SUBTILES_EXTENSIONS:
                ext = '.srt'
        if fname is None:
            filename = os.path.basename(subfile)
            save_as = settings.get('save_as', 'default')
            if save_as == 'version':
                self.log.debug('filename creating by "version" setting')
                filename = toString(selected_subtitle['filename'])
				# Sanitize the filename to remove slashes and double dots
                filename = re.sub(r'[\\/]', '_', filename)  # Replace slashes with underscores
                filename = re.sub(r'\.\.', '.', filename)  # Replace double dots with a single dot
                # The selected provider name may end in .vtt or .txt even
                # when the validated payload has been converted to SRT.
                # Always save using the real, validated file extension.
                if os.path.splitext(filename)[1].lower() != ext:
                    filename = os.path.splitext(filename)[0] + ext
            elif save_as == 'video':
                self.log.debug('filename creating by "video" setting')
                videopath = toString(subtitles_dict[seeker.id]['params'].get('filepath'))
                filename = os.path.splitext(os.path.basename(videopath))[0] + ext

            if settings.get('lang_to_filename', False):
                lang_iso639_1_2 = toString(languageTranslate(lang, 0, 2))
                self.log.debug('appending language "%s" to filename', lang_iso639_1_2)
                filename, ext = os.path.splitext(filename)
                filename = "%s.%s%s" % (filename, lang_iso639_1_2, ext)
        else:
            self.log.debug('using provided filename')
            filename = toString(fname) + ext
        self.log.debug('filename: "%s"', filename)
        download_path = os.path.join(toString(self.download_path), filename)
        if path is not None:
            self.log.debug('using custom download path: "%s"', path)
            download_path = os.path.join(toString(path), filename)
        self.log.debug('download path: "%s"', download_path)

		# Ensure the destination directory exists
        os.makedirs(os.path.dirname(download_path), exist_ok=True)

        if os.path.isfile(download_path) and overwrite_cb is not None:
            ret = overwrite_cb(download_path)
            if ret is None:
                self.log.debug('overwrite cancelled, returning temp path')
                return subfile
            elif not ret:
                self.log.debug('not overwriting, returning temp path')
                return subfile
            elif ret:
                self.log.debug('overwriting')
                try:
                    shutil.move(subfile, download_path)
                    return _validated_subtitle(download_path, self.tmp_path)
                except Exception as e:
                    self.log.error('moving "%s" to "%s" - %s' % (
						os.path.split(subfile)[-2:],
						os.path.split(download_path)[-2:]), str(e))
                    return subfile
        try:
            shutil.move(subfile, download_path)
        except Exception as e:
            self.log.error('moving "%s" to "%s" - %s', (
				os.path.split(subfile)[-2:],
				os.path.split(download_path)[-2:]), str(e))
            return subfile
        return _validated_subtitle(download_path, self.tmp_path)

    def getProvider(self, provider_id):
        for s in self.seekers:
            if s.id == provider_id:
                return s

    def getProviders(self, langs=None, movie=True, tvshow=True, include_unavailable=False, dedupe_aliases=True):
        """Stable provider priority, excluding disabled or broken imports.

        Preserve SUBTITLES_SEEKERS registration order. A set used to reshuffle
        the search order at each run and could push slow/legacy sites ahead of
        providers with working APIs. ErrorSeeker cannot deliver callbacks, so
        it must not be counted among the active jobs.
        """
        wanted = set(_normalize_search_languages(langs))
        providers = []
        for provider in self.seekers:
            if not include_unavailable and getattr(provider, 'error', None) is not None:
                continue
            try:
                if not provider.settings_provider.getSetting('enabled'):
                    continue
            except Exception:
                continue
            if wanted and not wanted.intersection(provider.supported_langs):
                continue
            if (movie and provider.movie_search) or (tvshow and provider.tvshow_search):
                providers.append(provider)
        # Os.org.fnc and Os.com.fnc use the same OpenSubtitles.com API.
        # Never issue two copies of a search, especially on slow Enigma2 boxes.
        legacy = next((p for p in providers if p.id == 'opensubtitles.com'), None)
        modern = next((p for p in providers if p.id == 'os.com.fnc'), None)
        if dedupe_aliases and legacy is not None and modern is not None:
            def has_key(p):
                try:
                    return bool(str(p.settings_provider.getSetting('OpenSubtitles_API_KEY')).strip())
                except Exception:
                    return False
            # Prefer the modern entry when it has a key.  Otherwise preserve
            # the existing API settings and searches of the older entry.
            if has_key(modern) or not has_key(legacy):
                providers.remove(legacy)
            else:
                providers.remove(modern)
        return providers


    def _filterWrongMovieYear(self, subtitles, requested_year, tvshow):
        """Preserve real provider matches even when their release year differs.

        Providers frequently put a video *release* year rather than the film
        year in filenames.  Year is used for ranking in the result screen;
        dropping rows here made successful Arabic provider searches look empty.
        """
        return subtitles

    def _searchSubtitles(self, lock, subtitlesDict, updateCB, seeker, title, filepath, langs, season, episode, tvshow, year):
        # r488 diagnostic only: record each provider start/result/failure in the
        # existing /tmp/tivimatesubtitles.log owned by tivimate_provider_search.py.
        # No extra HTTP calls, timers, hooks, retries or search-path changes.
        started = time.time()
        _tm_diag('search start', seeker.id)
        try:
            _diag_print("[TiviMateProviderDiag] START id=%s name=%s title=%r year=%r tvshow=%r season=%r episode=%r langs=%r" % (
                getattr(seeker, 'id', ''), getattr(seeker, 'provider_name', ''),
                title, year, tvshow, season, episode, langs))
        except Exception:
            pass
        try:
            subtitles = seeker.search(title, filepath, langs, season, episode, tvshow, year)
            subtitles = self._filterWrongMovieYear(subtitles, year, tvshow)
        except Exception as e:
            elapsed = time.time() - started
            _tm_diag('search failed', seeker.id, e)
            try:
                _diag_print("[TiviMateProviderDiag] FAIL id=%s name=%s elapsed=%.2fs error=%s: %s" % (
                    getattr(seeker, 'id', ''), getattr(seeker, 'provider_name', ''),
                    elapsed, e.__class__.__name__, str(e)))
            except Exception:
                pass
            traceback.print_exc()
            with lock:
                subtitlesDict[seeker.id] = {'message': str(e), 'status': False, 'list': []}
                if updateCB is not None:
                    updateCB(seeker.id, False, e)
        else:
            elapsed = time.time() - started
            _tm_diag('search completed', seeker.id, count=len(subtitles.get('list') or []) if isinstance(subtitles, dict) else 0)
            try:
                items = subtitles.get('list') or [] if isinstance(subtitles, dict) else []
                message = (subtitles.get('msg') or subtitles.get('message') or '') if isinstance(subtitles, dict) else ''
                _diag_print("[TiviMateProviderDiag] DONE id=%s name=%s elapsed=%.2fs results=%d message=%r" % (
                    getattr(seeker, 'id', ''), getattr(seeker, 'provider_name', ''),
                    elapsed, len(items), message))
            except Exception:
                pass
            with lock:
                subtitles['status'] = True
                subtitlesDict[seeker.id] = subtitles
                if updateCB is not None:
                    updateCB(seeker.id, True, subtitles)

    def _unpack_subtitles(self, filepath, dest_dir, max_recursion=3):
        compressed = getCompressedFileType(filepath)
        if compressed == 'zip':
            self.log.debug('found "zip" archive, unpacking...')
            subfiles = self._unpack_zipsub(filepath, dest_dir)
        elif compressed == 'rar':
            self.log.debug('found "rar" archive, unpacking...')
            subfiles = self._unpack_rarsub(filepath, dest_dir)
        else:
            self.log.error('unsupported archive - %s', compressed)
            raise Exception(_("unsupported archive %s", compressed))
        for s in list(subfiles):
            if os.path.splitext(s)[1].lower() in ('.rar', '.zip') and max_recursion > 0:
                subfiles.extend(self._unpack_subtitles(s, dest_dir, max_recursion - 1))
        subfiles = [f for f in subfiles if os.path.splitext(f)[1].lower() in self.SUBTILES_EXTENSIONS]
        return subfiles

    def _unpack_zipsub(self, zippath, destdir):
        zf = zipfile.ZipFile(zippath)
        namelist = zf.infolist()

        subsfiles = []
        allowed_exts = self.SUBTILES_EXTENSIONS + ['.rar', '.zip']

        for member in namelist:
            subsfn = member.filename
            # Ignore folders, enormous entries and suspicious archives.
            if subsfn.endswith('/') or member.file_size > _MAX_SUBTITLE_BYTES:
                continue
            ext = os.path.splitext(subsfn)[1].lower()
            if ext not in allowed_exts:
                continue

            # Keep path info to avoid overwriting (episode folders, etc.)
            safe_name = subsfn.replace('\\', '/').strip('/').replace('/', '_')
            outpath = os.path.join(destdir, safe_name)

            with open(outpath, "wb") as outfile:
                outfile.write(zf.read(member))

            subsfiles.append(outpath)

        subsfiles.sort()
        return subsfiles

    def _unpack_rarsub(self, rar_path, dest_dir):
        try:
            import rarfile
        except ImportError:
            self.log.error('rarfile lib not available -  pip install rarfile')
            raise
        rf = rarfile.RarFile(rar_path)
        namelist = rf.namelist()
        subsfiles = []
        for subsfn in namelist:
            if os.path.splitext(subsfn)[1] in self.SUBTILES_EXTENSIONS + ['.rar', '.zip']:
                filename = os.path.basename(subsfn)
                outfile = open(os.path.join(dest_dir, filename), 'wb')
                outfile.write(rf.read(subsfn))
                outfile.flush()
                outfile.close()
                subsfiles.append(os.path.join(dest_dir, filename))
        return subsfiles
