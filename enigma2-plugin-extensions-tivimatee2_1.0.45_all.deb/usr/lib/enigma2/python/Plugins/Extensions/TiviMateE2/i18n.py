# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
import json
import os

LANG_FILE = data_path("language.json")
# Every language of the subtitle language list. en/ar/fr/tr/de have built-in
# tables below; every language also has lang/<code>.json (filled-in strings).
SUPPORTED = ("ar", "en", "fr", "tr", "de", "es", "it", "pt", "ru", "fa", "zh",
             "bg", "bs", "ca", "hr", "cs", "da", "nl", "et", "fi", "fy", "el",
             "hi", "hu", "is", "id", "ku", "lv", "lt", "ne", "no", "pl",
             "ro", "sr", "sk", "sl", "sv", "th", "uk", "vi")
# TMDb locale for each language (metadata, stories and actor biographies).
TMDB_LOCALES = {
    "en": "en-US", "ar": "ar-AE", "fr": "fr-FR", "tr": "tr-TR", "de": "de-DE",
    "es": "es-ES", "it": "it-IT", "pt": "pt-PT", "ru": "ru-RU", "fa": "fa-IR",
    "zh": "zh-CN", "bg": "bg-BG", "bs": "bs-BA", "ca": "ca-ES", "hr": "hr-HR",
    "cs": "cs-CZ", "da": "da-DK", "nl": "nl-NL", "et": "et-EE", "fi": "fi-FI",
    "fy": "fy-NL", "el": "el-GR", "hi": "hi-IN", "hu": "hu-HU",
    "is": "is-IS", "id": "id-ID", "ku": "ku-TR", "lv": "lv-LV", "lt": "lt-LT",
    "ne": "ne-NP", "no": "no-NO", "pl": "pl-PL", "ro": "ro-RO", "sr": "sr-RS",
    "sk": "sk-SK", "sl": "sl-SI", "sv": "sv-SE", "th": "th-TH", "uk": "uk-UA",
    "vi": "vi-VN",
}
# Native names, used by the TMDb language setting.
LANGUAGE_NAMES = {
    "en": "English", "ar": "العربية", "fr": "Français", "tr": "Türkçe",
    "de": "Deutsch", "es": "Español", "it": "Italiano", "pt": "Português",
    "ru": "Русский", "fa": "فارسی", "zh": "中文", "bg": "Български",
    "bs": "Bosanski", "ca": "Català", "hr": "Hrvatski", "cs": "Čeština",
    "da": "Dansk", "nl": "Nederlands", "et": "Eesti", "fi": "Suomi",
    "fy": "Frysk", "el": "Ελληνικά", "hi": "हिन्दी",
    "hu": "Magyar", "is": "Íslenska", "id": "Bahasa Indonesia", "ku": "Kurdî",
    "lv": "Latviešu", "lt": "Lietuvių", "ne": "नेपाली", "no": "Norsk",
    "pl": "Polski", "ro": "Română", "sr": "Srpski", "sk": "Slovenčina",
    "sl": "Slovenščina", "sv": "Svenska", "th": "ไทย", "uk": "Українська",
    "vi": "Tiếng Việt",
}

def tmdb_locale(code):
    return TMDB_LOCALES.get(str(code or "en").lower()[:2], "en-US")

LANG_DIR = os.path.join(os.path.dirname(os.path.realpath(__file__)), "lang")
_FILE_TABLES = {}

def _file_table(code):
    """lang/<code>.json, loaded once. On Python 2 keys and values are UTF-8
    byte strings, like the rest of the plugin's text."""
    table = _FILE_TABLES.get(code)
    if table is not None:
        return table
    table = {}
    try:
        import io
        with io.open(os.path.join(LANG_DIR, code + ".json"), "r", encoding="utf-8") as handle:
            raw = json.load(handle) or {}
        try:
            unicode  # noqa: F821  (Python 2 only)
            for key, value in raw.items():
                table[key.encode("utf-8")] = value.encode("utf-8")
        except NameError:
            table = dict(raw)
    except Exception:
        table = {}
    _FILE_TABLES[code] = table
    return table

_TRANSLATIONS = {
    "tr": {
        "More Info": "Daha fazla bilgi",
        "Server Finder":"Sunucu Bulucu", "Search":"Ara", "Home":"Ana Sayfa", "Live":"Canlı", "Movies":"Filmler", "TV Shows":"Diziler", "Packages":"Paketler", "Settings":"Ayarlar",
        "Favorite":"Favori", "Favorites":"Favoriler", "English":"English", "Arabic":"العربية", "French":"Français", "Turkish":"Türkçe",
        "APPLICATION LANGUAGE":"UYGULAMA DİLİ", "ONLINE":"ÇEVRİMİÇİ", "IN USE":"KULLANIMDA", "OFFLINE":"ÇEVRİMDIŞI",
        "LIVE TV":"CANLI TV", "MOVIES":"FİLMLER", "TV SHOWS":"DİZİLER", "PACKAGES":"PAKETLER", "CONTENT":"İÇERİK",
        "Recently Added":"Son Eklenenler", "Continue Watching":"İzlemeye Devam Et", "Select a package":"Paket seç", "Select a category":"Kategori seç",
        "":"Paketler yükleniyor...", "":"Kategoriler yükleniyor...", "MOVIE CATEGORIES":"FİLM KATEGORİLERİ",
        "TV SHOW CATEGORIES":"DİZİ KATEGORİLERİ", "Developed by Opesboy":"Opesboy tarafından geliştirildi",
        "Language saved. Reopen the app to apply it.":"Dil kaydedildi. Uygulamak için uygulamayı yeniden açın.",
        "Unable to save settings.":"Ayarlar kaydedilemedi.", "No server selected • Press SETTINGS":"Sunucu seçilmedi • AYARLAR'a basın",
        "Movies You Might Like":"Beğenebileceğiniz Filmler", "TV Shows You Might Like":"Beğenebileceğiniz Diziler",
        "Popular Movies":"Popüler Filmler", "Popular Show":"Popüler İçerik", "Popular TV Shows":"Popüler Diziler", "More info":"Daha fazla bilgi", "Play":"Oynat",
        "Back":"Geri", "Select":"Seç", "Server":"Sunucu", "Servers":"Sunucular", "Backup":"Yedek", "Restore":"Geri Yükle",
        "Subtitle":"Altyazı", "Subtitles":"Altyazılar", "Cache":"Önbellek", "Refresh":"Yenile", "Delete":"Sil", "Save":"Kaydet"
    },
    "ar": {
        "More Info": "معلومات أكثر",
        "Server Finder": "بحث السيرفرات", "Resume": "متابعة المشاهدة", "GENRE": "التصنيفات",
        'Name': 'الاسم',
        'Rating': 'التقييم',
        'Date': 'التاريخ',
        "Search": "بحث", "Home": "الرئيسية", "Live": "البث المباشر", "Movies": "الأفلام",
        "TV Shows": "المسلسلات", "Packages": "الباقات", "Settings": "الإعدادات", "Favorite": "المفضلة", "Favorites": "المفضلة",
        "CONTROL CENTER": "مركز التحكم", "SETTINGS  •  SERVER MANAGER": "الإعدادات  •  إدارة السيرفرات",
        "Manage playlists,\nconnections and metadata,\nand appearance settings.": "إدارة القوائم،\nالاتصالات والبيانات،\nوإعدادات المظهر.",
        "Use the colour keys below\nfor quick actions.": "استخدم الأزرار الملونة أدناه\nللإجراءات السريعة.",
        "APPLICATION LANGUAGE": "لغة التطبيق", "English": "English", "Arabic": "العربية", "French": "Français",
        "SERVER STATUS  •  CONNECTION & ACTIVE USE": "حالة السيرفر  •  الاتصال والاستخدام",
        "Yellow appears only when the server reports active use.": "يظهر اللون الأصفر فقط عند وجود استخدام نشط.",
        "ONLINE": "متصل", "IN USE": "قيد الاستخدام", "OFFLINE": "غير متصل",
        "Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates.": "اضغط 5 لإعدادات SUBDL والترجمة. واضغط 3 للتحديثات.",
        "RED - Edit Subtitles": "الأحمر - تعديل الترجمة",
        "↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles": "↑↓ تغيير   MENU محرك التشغيل   الأزرق SubsSupport   الأحمر تعديل الترجمة",
        "Edit Subtitles": "تعديل الترجمة", "Select a package": "اختر باقة", "Select a category": "اختر تصنيفًا",
        "": "جاري تحميل الباقات...", "": "جاري تحميل التصنيفات...",
        "LIVE TV": "التلفاز المباشر", "MOVIES": "الأفلام", "TV SHOWS": "المسلسلات",
        "MOVIE CATEGORIES": "تصنيفات الأفلام", "TV SHOW CATEGORIES": "تصنيفات المسلسلات",
        "PACKAGES": "الباقات", "CONTENT": "المحتوى", "Recently Added": "المضاف حديثا", "Continue Watching": "متابعة المشاهدة",
        "Popular Movies": "الأفلام الشائعة", "Popular Show": "المحتوى الشائع", "Popular TV Shows": "المسلسلات الشائعة",
        "Trending Movies": "الأفلام الرائجة", "Trending TV Shows": "المسلسلات الرائجة",
        "Movies You Might Like": "أفلام قد تعجبك", "TV Shows You Might Like": "مسلسلات قد تعجبك",
        "Recent Added Movies": "الأفلام المضافة حديثا", "Recent Added TV Shows": "المسلسلات المضافة حديثا",
        "RECENTLY ADDED": "المضاف حديثا", "FAVORITES": "المفضلة", "WATCH NOW": "شاهد الآن",
        "NOW": "الآن", "NEXT": "التالي", "Play": "تشغيل", "Add to My List": "أضف إلى قائمتي",
        "Movies  0": "الأفلام  0", "Shows  0": "المسلسلات  0",
        "Search for a channel, movie or series...": "ابحث عن قناة أو فيلم أو مسلسل...",
        "Press OK to start searching": "اضغط OK لبدء البحث", "YOUR SAVED CONTENT": "المحتوى المحفوظ",
        "ALL": "الكل", "LIVE": "مباشر", "SERIES": "مسلسلات", "MOVIE": "فيلم",
        "ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES": "الأسهم لاختيار الملصق  •  اضغط الأصفر مطولًا لإضافة فيلم أو مسلسل إلى المفضلة",
        "BLUE  CHANGE STYLE": "الأزرق  تغيير النمط",
        "Unable to save settings.": "تعذر حفظ الإعدادات.",
        "Language saved. Reopen the app to apply it.": "تم حفظ اللغة. أعد فتح التطبيق لتطبيقها.",
        "ADD A SOURCE": "إضافة مصدر", "ADD IPTV SOURCE": "إضافة مصدر IPTV", "UPDATE PLAYLIST": "تحديث القائمة", "EXIT": "خروج", "Choose the type of IPTV connection": "اختر نوع اتصال IPTV",
        "STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS": "بوابة STALKER  •  مباشر وأفلام ومسلسلات",
        "ADD XTREAM CODES PLAYLIST": "إضافة قائمة XTREAM CODES", "TMDb TRENDING SETTINGS": "إعدادات TMDb",
        "SERVER CONTENT FILTER": "تصفية محتوى السيرفر", "IMAGE CACHE": "ذاكرة الصور المؤقتة",
        "HOME APPEARANCE": "مظهر الرئيسية", "SOFTWARE UPDATES": "تحديثات البرنامج",
        "SUBDL SUBTITLE LANGUAGE": "لغة ترجمة SUBDL", "Download SubDL subtitles in": "تنزيل ترجمة SUBDL باللغة",
        "": "جاري التحميل...", "No results": "لا توجد نتائج", "Back": "رجوع",
        "Previous Category": "التصنيف السابق", "Next Category": "التصنيف التالي", "Remove from My List": "إزالة من قائمتي", "Filter": "تصفية", "No EPG data": "لا توجد بيانات EPG",
        'TiViMate': 'TiViMate',
        'IPTV EXPERIENCE': 'تجربة IPTV',
        'OK  KEYBOARD    GREEN  SAVE    RED  CANCEL': 'OK لوحة المفاتيح    الأخضر حفظ    الأحمر إلغاء',
        'Stalker requires your own Portal URL and MAG MAC address. No portal is included.': 'يتطلب Stalker رابط البوابة وعنوان MAG MAC الخاصين بك. لا توجد بوابة مرفقة.',
        'OK SELECT    EXIT BACK': 'OK اختيار    EXIT رجوع',
        'Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate.': 'أدخل رابط البوابة وعنوان MAG MAC الخاصين بك. لا توجد بوابة أو حساب مرفق مع TiViMate.',
        'Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server.': 'أدخل مفتاح TMDb API. تأتي بيانات الرائج من TMDb، بينما يستخدم التشغيل السيرفر المحدد.',
        'OK KEYBOARD    GREEN SAVE    RED CANCEL': 'OK لوحة المفاتيح    الأخضر حفظ    الأحمر إلغاء',
        'Load only the categories you need to keep lists, search, and images fast.': 'حمّل التصنيفات التي تحتاجها فقط للحفاظ على سرعة القوائم والبحث والصور.',
        'LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK': 'يمين/يسار القسم    OK تبديل    الأخضر حفظ    الأصفر تحديد الكل    الأزرق مسح الكل    EXIT رجوع',
        'GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK': 'الأخضر حفظ    الأزرق مسح الكاش    الأصفر تنظيف    EXIT رجوع',
        'Changes apply to the Home screen only. Restart the app after saving.': 'تُطبّق التغييرات على الشاشة الرئيسية فقط. أعد فتح التطبيق بعد الحفظ.',
        'GREEN  SAVE    RED  BACK': 'الأخضر حفظ    الأحمر رجوع',
        'Automatic checks only read a small verified update manifest. Press YELLOW to check now.': 'تقرأ عملية التحقق التلقائي ملف تحديث صغيرًا وموثوقًا فقط. اضغط الأصفر للتحقق الآن.',
        'GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK': 'الأخضر حفظ    الأصفر تحقق الآن    الأحمر رجوع',
        'Checking for a verified update...': 'جارٍ التحقق من تحديث موثوق...',
        'Downloading and verifying the update package...': 'جارٍ تنزيل حزمة التحديث والتحقق منها...',
        'Installing TiViMate E2 update...': 'جارٍ تثبيت تحديث TiViMate E2...',
        'This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager.': 'تُستخدم هذه اللغة مع زر SubDL الأصفر. استورد مفتاح SubDL API بشكل منفصل من إدارة السيرفرات.',
        'Searching...': 'جارٍ البحث...',
        'TiViMate IPTV EXPERIENCE': 'تجربة TiViMate IPTV',
        'Live TV  •  Movies  •  Series  •  beIN SPORTS': 'البث المباشر  •  الأفلام  •  المسلسلات  •  beIN SPORTS',
        'TIVIMATE  •  PREMIUM IPTV': 'TIVIMATE  •  IPTV مميز',
        'YOUR ENTERTAINMENT, ONE PLACE': 'ترفيهك في مكان واحد',
        'Browse, discover and enjoy your library in one unified experience.': 'تصفح واكتشف واستمتع بمكتبتك في تجربة موحدة.',
        'Choose a section. Heavy image downloads are disabled in this build for stability.': 'اختر قسمًا. تم تعطيل تنزيل الصور الثقيلة في هذه النسخة لضمان الاستقرار.',
        'OK Open    EXIT Back': 'OK فتح    EXIT رجوع',
        '': 'جارٍ تحميل معلومات المسلسل...',
        'LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back': 'يمين/يسار الحلقات    أعلى/أسفل تغيير الموسم    OK تشغيل    الأحمر مفضلة    EXIT رجوع',
        'LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back': 'يمين/يسار تنقل    أعلى/أسفل صفحات    OK اختيار    الأحمر التصنيف السابق    الأزرق التصنيف التالي    MENU المفضلة    الأخضر الباقات/التصنيفات    الأصفر ترتيب    EXIT رجوع',
        '': 'جارٍ تحميل القنوات المضافة حديثًا...',
        'Channel changed': 'تم تغيير القناة',
        'No content': 'لا يوجد محتوى',
        'Name': 'الاسم',
        'Rating': 'التقييم',
        'Playlist Name': 'اسم القائمة',
        'Protocol': 'البروتوكول',
        'Server URL': 'رابط السيرفر',
        'Port': 'المنفذ',
        'Username': 'اسم المستخدم',
        'Password': 'كلمة المرور',
        'Stream Format': 'صيغة البث',
        'EPG Time Offset': 'إزاحة توقيت EPG',
        '★ TMDb Poster in Live': '★ بوستر TMDb في البث المباشر',
        'Portal Name': 'اسم البوابة',
        'Portal URL': 'رابط البوابة',
        'MAG MAC Address': 'عنوان MAG MAC',
        'TMDb API Key': 'مفتاح TMDb API',
        'Metadata language': 'لغة البيانات',
        'Cache Location': 'موقع الكاش',
        'Maximum Size': 'الحجم الأقصى',
        'Delete Images Older Than': 'حذف الصور الأقدم من',
        'Home Skin': 'مظهر الرئيسية',
        'Automatic update check': 'التحقق التلقائي من التحديثات',
        'Update download failed.': 'فشل تنزيل التحديث.',
        'The verified package could not be installed.': 'تعذر تثبيت الحزمة الموثوقة.',
        'Update completed. Restart the Enigma2 GUI to use the new version.': 'اكتمل التحديث. أعد تشغيل واجهة Enigma2 لاستخدام النسخة الجديدة.',
        'The update installer returned an error.': 'أعاد مُثبت التحديث خطأً.',
        'Unable to save favorite': 'تعذر حفظ المفضلة',
        'Item is already in favorites': 'العنصر موجود بالفعل في المفضلة',
        'Added to favorites': 'تمت الإضافة إلى المفضلة',
        'Removed from favorites': 'تمت الإزالة من المفضلة',
        'Unable to remove this Favorite.': 'تعذرت إزالة هذا العنصر من المفضلة.',
        'No server selected • Press SETTINGS': 'لا يوجد سيرفر محدد • اضغط الإعدادات',
        'No seasons': 'لا توجد مواسم',
        '': 'جارٍ تحميل الباقات والتصنيفات...',
        'Open a package, select a channel, then press RED': 'افتح باقة وحدد قناة ثم اضغط الأحمر',
        'Select a movie or TV show first': 'حدد فيلمًا أو مسلسلًا أولًا',
        'Preparing series categories in the background...': 'جارٍ تجهيز تصنيفات المسلسلات في الخلفية...',
        'Select a series category': 'اختر تصنيف المسلسلات',
        'Select the category then press OK. Only this category will be loaded.': 'اختر التصنيف ثم اضغط OK. سيتم تحميل هذا التصنيف فقط.',
        'No favorite channels yet. Add channels with the red button.': 'لا توجد قنوات مفضلة بعد. أضف القنوات بالزر الأحمر.',
        'Select a series category then press OK.': 'اختر تصنيف المسلسلات ثم اضغط OK.',
        'No categories available.': 'لا توجد تصنيفات متاحة.',
        'The category is preparing in the background... the interface will not freeze.': 'يجري تجهيز التصنيف في الخلفية... لن تتجمد الواجهة.',
        'Stalker returned no packages. Check Portal URL and MAG MAC, then retry.': 'لم يُرجع Stalker أي باقات. تحقق من رابط البوابة وعنوان MAG MAC ثم أعد المحاولة.',
        'Stalker returned no items for this package. Try another package or refresh the source.': 'لم يُرجع Stalker محتوى لهذه الباقة. جرّب باقة أخرى أو حدّث المصدر.',
        'No saved items in this filter. Open a title and choose Add to My List.': 'لا توجد عناصر محفوظة في هذا الفلتر. افتح عنوانًا واختر أضف إلى قائمتي.',
        'YOUR LIBRARY': 'مكتبتك',
        'Choose a collection\nto browse titles from\nyour selected server.': 'اختر مجموعة\nلتصفح العناوين من\nالسيرفر المحدد.',
        'Press OK to open': 'اضغط OK للفتح',
        'Browse the collections available on your server': 'تصفح المجموعات المتاحة على سيرفرك',
        '': 'جارٍ تحميل المجموعات',
        'AVAILABLE COLLECTIONS': 'المجموعات المتاحة',
        '': 'جارٍ تحميل التفاصيل...',
        '▶  Watch': '▶  مشاهدة',
        'Other Sources': 'مصادر أخرى',
        'Actors': 'الممثلون',
        'Recommendations': 'اقتراحات',
        'OK Play     EXIT Back': 'OK تشغيل     EXIT رجوع',
        'UNABLE TO LOAD CATEGORIES': 'تعذر تحميل التصنيفات',
        'Check the selected server and try again': 'تحقق من السيرفر المحدد وحاول مرة أخرى',
        'NO COLLECTIONS': 'لا توجد مجموعات',
        'No enabled collections are available for this server': 'لا توجد مجموعات مفعلة لهذا السيرفر',
        '': 'يجري تحميل التصنيفات. حاول مجددًا بعد قليل.',
        'No enabled categories are available for this library.': 'لا توجد تصنيفات مفعلة لهذه المكتبة.',
        "Today's Trending Movies": 'أفلام اليوم الرائجة',
        "Today's Trending Series": 'مسلسلات اليوم الرائجة',
        'Latest Movies': 'أحدث الأفلام',
        'Latest Series': 'أحدث المسلسلات',
        'Latest Movies & TV Shows': 'أحدث الأفلام والمسلسلات',
        'Latest TV Shows': 'أحدث المسلسلات',
        '%d Home picks': '%d اختيارات للرئيسية',
        '%d recent TV shows': '%d مسلسلات حديثة',
        '%d recent movies': '%d أفلام حديثة',
        'Server: %s  •  %s': 'السيرفر: %s  •  %s',
        'Use OK to enter characters. GREEN saves. RED or EXIT cancels.': 'استخدم OK لإدخال الأحرف. الأخضر للحفظ. الأحمر أو EXIT للإلغاء.',
        'OK: Edit key   YELLOW: Import /tmp/tivimatee2/key.txt   GREEN: Save   EXIT: Close': 'OK تعديل المفتاح   الأصفر استيراد /tmp/tivimatee2/key.txt   الأخضر حفظ   EXIT إغلاق',
        'SubDL API Key  (OK to edit)': 'مفتاح SubDL API  (OK للتعديل)',
        'Default Subtitle Language': 'لغة الترجمة الافتراضية',
        'Default Subtitle Type': 'نوع الترجمة الافتراضي',
        'Developed by Opesboy': 'تطوير Opesboy',
        'Downloading TiviMate E2 update...': 'جارٍ تنزيل تحديث TiviMate E2...',
        'Installing TiviMate E2 update...': 'جارٍ تثبيت تحديث TiviMate E2...',
        'Press OK again to open the search keyboard': 'اضغط OK مرة أخرى لفتح لوحة البحث',
        'Stalker packages are ready. Open Categories and select a package to load its titles.': 'باقات Stalker جاهزة. افتح التصنيفات واختر باقة لتحميل محتواها.',
        'TiViMate E2 is already up to date.': 'TiViMate E2 محدث بالفعل.',
        'TiviMate E2': 'TiviMate E2',
        'Unable to start the update installer.': 'تعذر بدء مثبت التحديث.',
        'Unable to verify updates right now. You can try again later.': 'تعذر التحقق من التحديثات الآن. حاول لاحقًا.',
        'Select a movie poster first': 'حدد بوستر فيلم أولًا',
        'Movie is already in favorites': 'الفيلم موجود بالفعل في المفضلة',
        'Movie added to favorites': 'تمت إضافة الفيلم إلى المفضلة',
        'Series is already in favorites': 'المسلسل موجود بالفعل في المفضلة',
        'Series added to favorites': 'تمت إضافة المسلسل إلى المفضلة',
        'This title is not available on the server and cannot be added to favorites': 'هذا العنوان غير موجود على السيرفر ولا يمكن إضافته إلى المفضلة',
    },
    "fr": {
        "More Info": "Plus d’infos",
        "Server Finder": "Recherche de serveurs",
        'Name': 'Nom',
        'Rating': 'Note',
        'Date': 'Date',
        "Continue Watching": "Continuer à regarder",
        "Popular Movies": "Films populaires", "Popular Show": "Contenu populaire", "Popular TV Shows": "Séries populaires",
        "Trending Movies": "Films tendance", "Trending TV Shows": "Séries tendance",
        "Movies You Might Like": "Films qui pourraient vous plaire", "TV Shows You Might Like": "Séries qui pourraient vous plaire",
        "Recent Added Movies": "Films ajoutés récemment", "Recent Added TV Shows": "Séries ajoutées récemment",
        "Search": "Recherche", "Home": "Accueil", "Live": "Direct", "Movies": "Films",
        "TV Shows": "Séries", "Packages": "Bouquets", "Settings": "Paramètres", "Favorite": "Favoris", "Favorites": "Favoris",
        "CONTROL CENTER": "CENTRE DE CONTRÔLE", "SETTINGS  •  SERVER MANAGER": "PARAMÈTRES  •  GESTION DES SERVEURS",
        "Manage playlists,\nconnections and metadata,\nand appearance settings.": "Gérez les listes,\nles connexions, les métadonnées\net l’apparence.",
        "Use the colour keys below\nfor quick actions.": "Utilisez les touches colorées\npour les actions rapides.",
        "APPLICATION LANGUAGE": "LANGUE DE L’APPLICATION", "English": "English", "Arabic": "العربية", "French": "Français",
        "SERVER STATUS  •  CONNECTION & ACTIVE USE": "ÉTAT DU SERVEUR  •  CONNEXION ET UTILISATION",
        "Yellow appears only when the server reports active use.": "Le jaune apparaît uniquement lorsque le serveur signale une utilisation active.",
        "ONLINE": "EN LIGNE", "IN USE": "UTILISÉ", "OFFLINE": "HORS LIGNE",
        "Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates.": "Appuyez sur 5 pour SUBDL et les sous-titres. Appuyez sur 3 pour les mises à jour.",
        "RED - Edit Subtitles": "ROUGE - Modifier les sous-titres",
        "↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles": "↑↓ Changer   MENU Moteur   BLEU SubsSupport   ROUGE Modifier les sous-titres",
        "Edit Subtitles": "Modifier les sous-titres", "Select a package": "Choisir un bouquet", "Select a category": "Choisir une catégorie",
        "": "Chargement des bouquets...", "": "Chargement des catégories...",
        "LIVE TV": "TV EN DIRECT", "MOVIES": "FILMS", "TV SHOWS": "SÉRIES",
        "MOVIE CATEGORIES": "CATÉGORIES DE FILMS", "TV SHOW CATEGORIES": "CATÉGORIES DE SÉRIES",
        "PACKAGES": "BOUQUETS", "CONTENT": "CONTENU", "Recently Added": "Ajoutés récemment",
        "RECENTLY ADDED": "AJOUTÉS RÉCEMMENT", "FAVORITES": "FAVORIS", "WATCH NOW": "REGARDER",
        "NOW": "EN COURS", "NEXT": "À SUIVRE", "Play": "Lire", "Add to My List": "Ajouter à ma liste",
        "Movies  0": "Films  0", "Shows  0": "Séries  0",
        "Search for a channel, movie or series...": "Rechercher une chaîne, un film ou une série...",
        "Press OK to start searching": "Appuyez sur OK pour lancer la recherche", "YOUR SAVED CONTENT": "VOTRE CONTENU ENREGISTRÉ",
        "ALL": "TOUT", "LIVE": "DIRECT", "SERIES": "SÉRIE", "MOVIE": "FILM",
        "ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES": "FLÈCHES : SÉLECTIONNER  •  MAINTENEZ JAUNE POUR AJOUTER AUX FAVORIS",
        "BLUE  CHANGE STYLE": "BLEU  CHANGER LE STYLE",
        "Unable to save settings.": "Impossible d’enregistrer les paramètres.",
        "Language saved. Reopen the app to apply it.": "Langue enregistrée. Rouvrez l’application pour l’appliquer.",
        "ADD A SOURCE": "AJOUTER UNE SOURCE", "ADD IPTV SOURCE": "AJOUTER UNE SOURCE IPTV", "UPDATE PLAYLIST": "METTRE À JOUR", "EXIT": "QUITTER", "Choose the type of IPTV connection": "Choisissez le type de connexion IPTV",
        "STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS": "PORTAIL STALKER  •  DIRECT, FILMS ET SÉRIES",
        "ADD XTREAM CODES PLAYLIST": "AJOUTER UNE LISTE XTREAM CODES", "TMDb TRENDING SETTINGS": "PARAMÈTRES TMDb",
        "SERVER CONTENT FILTER": "FILTRE DU CONTENU SERVEUR", "IMAGE CACHE": "CACHE DES IMAGES",
        "HOME APPEARANCE": "APPARENCE DE L’ACCUEIL", "SOFTWARE UPDATES": "MISES À JOUR",
        "SUBDL SUBTITLE LANGUAGE": "LANGUE DES SOUS-TITRES SUBDL", "Download SubDL subtitles in": "Télécharger les sous-titres SubDL en",
        "": "Chargement...", "No results": "Aucun résultat", "Back": "Retour",
        "Previous Category": "Catégorie précédente", "Next Category": "Catégorie suivante", "Remove from My List": "Retirer de ma liste", "Filter": "Filtre", "No EPG data": "Aucune donnée EPG",
        'TiViMate': 'TiViMate',
        'IPTV EXPERIENCE': 'EXPÉRIENCE IPTV',
        'OK  KEYBOARD    GREEN  SAVE    RED  CANCEL': 'OK CLAVIER    VERT ENREGISTRER    ROUGE ANNULER',
        'Stalker requires your own Portal URL and MAG MAC address. No portal is included.': 'Stalker nécessite votre propre URL de portail et adresse MAG MAC. Aucun portail n’est inclus.',
        'OK SELECT    EXIT BACK': 'OK SÉLECTIONNER    EXIT RETOUR',
        'Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate.': 'Saisissez votre URL de portail et votre adresse MAG MAC. Aucun portail ni compte n’est fourni avec TiViMate.',
        'Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server.': 'Saisissez une clé API TMDb. Les métadonnées tendance viennent de TMDb ; la lecture utilise le serveur sélectionné.',
        'OK KEYBOARD    GREEN SAVE    RED CANCEL': 'OK CLAVIER    VERT ENREGISTRER    ROUGE ANNULER',
        'Load only the categories you need to keep lists, search, and images fast.': 'Chargez uniquement les catégories nécessaires pour garder les listes, la recherche et les images rapides.',
        'LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK': 'GAUCHE/DROITE SECTION    OK BASCULER    VERT ENREGISTRER    JAUNE TOUT SÉLECTIONNER    BLEU TOUT EFFACER    EXIT RETOUR',
        'GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK': 'VERT ENREGISTRER    BLEU VIDER LE CACHE    JAUNE NETTOYER    EXIT RETOUR',
        'Changes apply to the Home screen only. Restart the app after saving.': 'Les changements s’appliquent uniquement à l’accueil. Rouvrez l’application après l’enregistrement.',
        'GREEN  SAVE    RED  BACK': 'VERT ENREGISTRER    ROUGE RETOUR',
        'Automatic checks only read a small verified update manifest. Press YELLOW to check now.': 'La vérification automatique lit uniquement un petit manifeste de mise à jour vérifié. Appuyez sur JAUNE pour vérifier maintenant.',
        'GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK': 'VERT ENREGISTRER    JAUNE VÉRIFIER    ROUGE RETOUR',
        'Checking for a verified update...': 'Vérification d’une mise à jour fiable...',
        'Downloading and verifying the update package...': 'Téléchargement et vérification du paquet...',
        'Installing TiViMate E2 update...': 'Installation de la mise à jour TiViMate E2...',
        'This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager.': 'Cette langue est utilisée par le bouton jaune SubDL. Importez la clé API SubDL séparément depuis la gestion des serveurs.',
        'Searching...': 'Recherche...',
        'TiViMate IPTV EXPERIENCE': 'EXPÉRIENCE IPTV TiViMate',
        'Live TV  •  Movies  •  Series  •  beIN SPORTS': 'TV EN DIRECT  •  FILMS  •  SÉRIES  •  beIN SPORTS',
        'TIVIMATE  •  PREMIUM IPTV': 'TIVIMATE  •  IPTV PREMIUM',
        'YOUR ENTERTAINMENT, ONE PLACE': 'TOUT VOTRE DIVERTISSEMENT',
        'Browse, discover and enjoy your library in one unified experience.': 'Parcourez, découvrez et profitez de votre bibliothèque dans une seule expérience.',
        'Choose a section. Heavy image downloads are disabled in this build for stability.': 'Choisissez une section. Les téléchargements d’images lourdes sont désactivés pour la stabilité.',
        'OK Open    EXIT Back': 'OK OUVRIR    EXIT RETOUR',
        '': 'Chargement des détails de la série...',
        'LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back': 'GAUCHE/DROITE ÉPISODES    HAUT/BAS SAISON    OK LIRE    ROUGE FAVORI    EXIT RETOUR',
        'LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back': 'GAUCHE/DROITE NAVIGUER    HAUT/BAS PAGES    OK SÉLECTIONNER    ROUGE CATÉGORIE PRÉCÉDENTE    BLEU SUIVANTE    MENU FAVORIS    VERT BOUQUETS/CATÉGORIES    JAUNE TRIER    EXIT RETOUR',
        '': 'Chargement des chaînes ajoutées récemment...',
        'Channel changed': 'Chaîne changée',
        'No content': 'Aucun contenu',
        'Name': 'Nom',
        'Rating': 'Note',
        'Playlist Name': 'Nom de la liste',
        'Protocol': 'Protocole',
        'Server URL': 'URL du serveur',
        'Port': 'Port',
        'Username': 'Nom d’utilisateur',
        'Password': 'Mot de passe',
        'Stream Format': 'Format du flux',
        'EPG Time Offset': 'Décalage horaire EPG',
        '★ TMDb Poster in Live': '★ Affiche TMDb en direct',
        'Portal Name': 'Nom du portail',
        'Portal URL': 'URL du portail',
        'MAG MAC Address': 'Adresse MAG MAC',
        'TMDb API Key': 'Clé API TMDb',
        'Metadata language': 'Langue des métadonnées',
        'Cache Location': 'Emplacement du cache',
        'Maximum Size': 'Taille maximale',
        'Delete Images Older Than': 'Supprimer les images plus anciennes que',
        'Home Skin': 'Thème de l’accueil',
        'Automatic update check': 'Vérification automatique des mises à jour',
        'Update download failed.': 'Échec du téléchargement de la mise à jour.',
        'The verified package could not be installed.': 'Le paquet vérifié n’a pas pu être installé.',
        'Update completed. Restart the Enigma2 GUI to use the new version.': 'Mise à jour terminée. Redémarrez l’interface Enigma2 pour utiliser la nouvelle version.',
        'The update installer returned an error.': 'Le programme d’installation a renvoyé une erreur.',
        'Unable to save favorite': 'Impossible d’enregistrer le favori',
        'Item is already in favorites': 'L’élément est déjà dans les favoris',
        'Added to favorites': 'Ajouté aux favoris',
        'Removed from favorites': 'Retiré des favoris',
        'Unable to remove this Favorite.': 'Impossible de retirer ce favori.',
        'No server selected • Press SETTINGS': 'Aucun serveur sélectionné • Appuyez sur PARAMÈTRES',
        'No seasons': 'Aucune saison',
        '': 'Chargement des bouquets/catégories...',
        'Open a package, select a channel, then press RED': 'Ouvrez un bouquet, sélectionnez une chaîne puis appuyez sur ROUGE',
        'Select a movie or TV show first': 'Sélectionnez d’abord un film ou une série',
        'Preparing series categories in the background...': 'Préparation des catégories de séries en arrière-plan...',
        'Select a series category': 'Sélectionnez une catégorie de séries',
        'Select the category then press OK. Only this category will be loaded.': 'Sélectionnez la catégorie puis appuyez sur OK. Seule cette catégorie sera chargée.',
        'No favorite channels yet. Add channels with the red button.': 'Aucune chaîne favorite. Ajoutez-en avec le bouton rouge.',
        'Select a series category then press OK.': 'Sélectionnez une catégorie de séries puis appuyez sur OK.',
        'No categories available.': 'Aucune catégorie disponible.',
        'The category is preparing in the background... the interface will not freeze.': 'La catégorie se prépare en arrière-plan... l’interface ne se bloquera pas.',
        'Stalker returned no packages. Check Portal URL and MAG MAC, then retry.': 'Stalker n’a renvoyé aucun bouquet. Vérifiez l’URL du portail et l’adresse MAG MAC, puis réessayez.',
        'Stalker returned no items for this package. Try another package or refresh the source.': 'Stalker n’a renvoyé aucun contenu pour ce bouquet. Essayez un autre bouquet ou actualisez la source.',
        'No saved items in this filter. Open a title and choose Add to My List.': 'Aucun élément enregistré dans ce filtre. Ouvrez un titre et choisissez Ajouter à ma liste.',
        'YOUR LIBRARY': 'VOTRE BIBLIOTHÈQUE',
        'Choose a collection\nto browse titles from\nyour selected server.': 'Choisissez une collection\npour parcourir les titres de\nvotre serveur sélectionné.',
        'Press OK to open': 'Appuyez sur OK pour ouvrir',
        'Browse the collections available on your server': 'Parcourez les collections disponibles sur votre serveur',
        '': 'CHARGEMENT DES COLLECTIONS',
        'AVAILABLE COLLECTIONS': 'COLLECTIONS DISPONIBLES',
        '': 'Chargement des détails...',
        '▶  Watch': '▶  Regarder',
        'Other Sources': 'Autres sources',
        'Actors': 'Acteurs',
        'Recommendations': 'Recommandations',
        'OK Play     EXIT Back': 'OK Lire     EXIT Retour',
        'UNABLE TO LOAD CATEGORIES': 'IMPOSSIBLE DE CHARGER LES CATÉGORIES',
        'Check the selected server and try again': 'Vérifiez le serveur sélectionné et réessayez',
        'NO COLLECTIONS': 'AUCUNE COLLECTION',
        'No enabled collections are available for this server': 'Aucune collection activée n’est disponible pour ce serveur',
        '': 'Les catégories sont en cours de chargement. Réessayez dans un instant.',
        'No enabled categories are available for this library.': 'Aucune catégorie activée n’est disponible pour cette bibliothèque.',
        "Today's Trending Movies": 'Films tendance du jour',
        "Today's Trending Series": 'Séries tendance du jour',
        'Latest Movies': 'Derniers films',
        'Latest Series': 'Dernières séries',
        'Latest Movies & TV Shows': 'Derniers films et séries',
        'Latest TV Shows': 'Dernières séries',
        '%d Home picks': '%d sélections d’accueil',
        '%d recent TV shows': '%d séries récentes',
        '%d recent movies': '%d films récents',
        'Server: %s  •  %s': 'Serveur : %s  •  %s',
        'Use OK to enter characters. GREEN saves. RED or EXIT cancels.': 'Utilisez OK pour saisir des caractères. VERT enregistre. ROUGE ou EXIT annule.',
        'OK: Edit key   YELLOW: Import /tmp/tivimatee2/key.txt   GREEN: Save   EXIT: Close': 'OK : modifier la clé   JAUNE : importer /tmp/tivimatee2/key.txt   VERT : enregistrer   EXIT : fermer',
        'SubDL API Key  (OK to edit)': 'Clé API SubDL  (OK pour modifier)',
        'Default Subtitle Language': 'Langue de sous-titres par défaut',
        'Default Subtitle Type': 'Type de sous-titres par défaut',
        'Developed by Opesboy': 'Développé par Opesboy',
        'Downloading TiviMate E2 update...': 'Téléchargement de la mise à jour TiviMate E2...',
        'Installing TiviMate E2 update...': 'Installation de la mise à jour TiviMate E2...',
        'Press OK again to open the search keyboard': 'Appuyez de nouveau sur OK pour ouvrir le clavier de recherche',
        'Stalker packages are ready. Open Categories and select a package to load its titles.': 'Les bouquets Stalker sont prêts. Ouvrez les catégories et sélectionnez un bouquet pour charger ses titres.',
        'TiViMate E2 is already up to date.': 'TiViMate E2 est déjà à jour.',
        'TiviMate E2': 'TiviMate E2',
        'Unable to start the update installer.': 'Impossible de démarrer le programme d’installation.',
        'Unable to verify updates right now. You can try again later.': 'Impossible de vérifier les mises à jour maintenant. Réessayez plus tard.',
        'Select a movie poster first': 'Sélectionnez d’abord une affiche de film',
        'Movie is already in favorites': 'Le film est déjà dans les favoris',
        'Movie added to favorites': 'Film ajouté aux favoris',
        'Series is already in favorites': 'La série est déjà dans les favoris',
        'Series added to favorites': 'Série ajoutée aux favoris',
        'This title is not available on the server and cannot be added to favorites': 'Ce titre n’est pas disponible sur le serveur et ne peut pas être ajouté aux favoris',
    }
}

# Additional Arabic strings for the Live, packages, and settings interfaces.
_TRANSLATIONS["ar"].update({'ADD NEW SERVER': 'إضافة سيرفر جديد', 'Actor information is unavailable.': 'معلومات الممثل غير متوفرة.', 'Add an IPTV source first.': 'أضف مصدر IPTV أولاً.', 'Add to parental protection': 'إضافة إلى الرقابة الأبوية', 'Added package folder to Favorites': 'تمت إضافة مجلد الباقة إلى المفضلة', 'Added package to Favorites': 'تمت إضافة الباقة إلى المفضلة', 'Audio Tracks': 'المسارات الصوتية', 'BLUE  CLEAR ALL': 'الأزرق  مسح الكل', 'BLUE  TEST PORTAL': 'الأزرق  اختبار البوابة', 'Built-in TMDb access is active. Enter your own key only to override it.': 'مفتاح TMDb المدمج نشط. أدخل مفتاحك فقط لاستبداله.', 'CATCH-UP / ARCHIVE': 'إعادة المشاهدة / الأرشيف', 'Catch-up / Archive': 'إعادة المشاهدة / الأرشيف', 'Catch-up is not available for this channel.': 'إعادة المشاهدة غير متوفرة لهذه القناة.', 'Change parental PIN': 'تغيير رمز الرقابة الأبوية', 'Channel': 'القناة', 'Channel could not start.': 'تعذر تشغيل القناة.', 'Channel hidden. Use MENU to restore it.': 'تم إخفاء القناة. اضغط MENU لاستعادتها.', 'Channel link unavailable.': 'رابط القناة غير متوفر.', 'Channel locked.': 'القناة مقفلة.', 'Channel position saved.': 'تم حفظ موقع القناة.', 'Channel restored.': 'تمت استعادة القناة.', 'Channel unavailable - try another channel.': 'القناة غير متاحة، جرّب قناة أخرى.', 'Checking playable catch-up channels...': 'جارٍ فحص القنوات التي تدعم إعادة المشاهدة...', 'Choose a collection\nto browse titles from\nyour selected server.': 'اختر مجموعة\nلاستعراض المحتوى من\nالسيرفر المحدد.', 'Choose the server for Home': 'اختر سيرفر الصفحة الرئيسية', 'Choose the type of IPTV connection you want to add': 'اختر نوع اتصال IPTV المراد إضافته', 'Clear Continue Watching': 'مسح متابعة المشاهدة', 'Clear all Continue Watching history?': 'هل تريد مسح سجل متابعة المشاهدة كاملاً؟', 'Content locked.': 'المحتوى مقفل.', 'Disable move': 'إلغاء النقل', 'Enable Catch-up Package': 'تفعيل باقة إعادة المشاهدة', 'Enable move': 'تفعيل النقل', 'Enter new 4-digit PIN': 'أدخل رمزاً جديداً من 4 أرقام', 'Enter parental PIN': 'أدخل رمز الرقابة الأبوية', 'Favorite channel position saved.': 'تم حفظ ترتيب القناة المفضلة.', 'Favorite options': 'خيارات المفضلة', 'Favorites are already empty': 'المفضلة فارغة بالفعل', 'Favorites cleared': 'تم مسح المفضلة', 'GREEN  PLAY': 'الأخضر  تشغيل', 'Hide Adult Content': 'إخفاء محتوى البالغين', 'Hide this channel': 'إخفاء هذه القناة', 'Hide this package': 'إخفاء هذه الباقة', 'Hide this package?': 'هل تريد إخفاء هذه الباقة؟', 'Home Content': 'محتوى الرئيسية', 'Image Cache Retention': 'مدة الاحتفاظ بكاش الصور', 'Incorrect PIN': 'رمز غير صحيح', 'Internal Flash Free Space': 'المساحة الحرة للفلاش الداخلي', 'Internal Flash Image Limit': 'الحد الأقصى للصور في الفلاش الداخلي', 'LIVE FAVORITES': 'مفضلة البث المباشر', 'Latest': 'الأحدث', 'Live Stream Type': 'نوع بث القنوات', 'Live options': 'خيارات البث المباشر', 'Loading package channels...': 'جارٍ تحميل قنوات الباقة...', 'Lock removed.': 'تم إلغاء القفل.', 'Lock this channel': 'قفل هذه القناة', 'Lock this package': 'قفل هذه الباقة', 'MAG MACs / Alias': 'عناوين MAG MAC / الاسم المستعار', 'MOVIE FAVORITES': 'الأفلام المفضلة', 'Mark as Watched': 'تحديد كمشاهَد', 'Menu': 'القائمة', 'Move channel with UP/DOWN, then press OK to save.': 'انقل القناة بالسهمين أعلى/أسفل ثم اضغط OK للحفظ.', 'Move channel with arrows, then press OK to save.': 'حرّك القناة بالأسهم ثم اضغط OK للحفظ.', 'Move item with arrows, then press OK or BLUE to save.': 'حرّك العنصر بالأسهم، ثم اضغط OK أو الأزرق للحفظ.', 'Move this channel': 'نقل هذه القناة', 'Movie': 'فيلم', 'Movie images are still loading.': 'صور الفيلم ما زالت قيد التحميل.', 'Movies and TV Shows packages are available for Xtream and Stalker sources.': 'باقات الأفلام والمسلسلات متاحة لمصادر Xtream وStalker.', 'No Genre items to add': 'لا توجد عناصر تصنيف لإضافتها', 'No IPTV servers found.': 'لم يُعثر على سيرفرات IPTV.', 'No Other Sources': 'لا توجد مصادر أخرى', 'No active channel to restart': 'لا توجد قناة نشطة لإعادة تشغيلها', 'No catch-up channels are available on this server.': 'لا تتوفر قنوات إعادة المشاهدة على هذا السيرفر.', 'No catch-up programmes are available for this channel.': 'لا تتوفر برامج إعادة مشاهدة لهذه القناة.', 'No channels found in this package': 'لم يُعثر على قنوات في هذه الباقة', 'No channels left in this favorite package': 'لم تتبقَّ قنوات في الباقة المفضلة', 'No hidden channels.': 'لا توجد قنوات مخفية.', 'No hidden packages.': 'لا توجد باقات مخفية.', 'No recently watched Stalker items.': 'لا يوجد محتوى Stalker تمت مشاهدته مؤخراً.', 'OK Select     RED Delete     BLUE Test     EXIT Cancel': 'OK اختيار     الأحمر حذف     الأزرق اختبار     EXIT إلغاء', 'Open a Movies or TV Shows package first': 'افتح باقة أفلام أو مسلسلات أولاً', 'Original': 'الأصلية', 'PIN must contain exactly 4 digits.': 'يجب أن يتكون الرمز من 4 أرقام بالضبط.', 'Package hidden. Use MENU to restore it.': 'تم إخفاء الباقة. اضغط MENU لاستعادتها.', 'Package is already in Favorites': 'الباقة موجودة في المفضلة بالفعل', 'Package locked.': 'الباقة مقفلة.', 'Package restored.': 'تمت استعادة الباقة.', 'Page': 'الصفحة', 'Parental PIN changed.': 'تم تغيير رمز الرقابة الأبوية.', 'Pick up where you left off. Your movies and TV shows will appear here automatically.': 'تابع من حيث توقفت. ستظهر أفلامك ومسلسلاتك هنا تلقائياً.', 'Playing catch-up': 'جارٍ تشغيل إعادة المشاهدة', 'Portal based connection\nPortal URL and MAC address': 'اتصال عبر البوابة\nرابط البوابة وعنوان MAC', 'Portal returned no archive link': 'لم توفر البوابة رابط الأرشيف', 'Portal returned no playable URL': 'لم توفر البوابة رابطاً قابلاً للتشغيل', 'Preferred Subtitle Language': 'لغة الترجمة المفضلة', 'Press for Other Sources': 'اضغط للمصادر الأخرى', 'Programme start time is missing': 'وقت بدء البرنامج غير متوفر', 'RED  REMOVE': 'الأحمر  إزالة', 'Recently watched': 'شوهد مؤخراً', 'Remove from Continue Watching': 'إزالة من متابعة المشاهدة', 'Remove from parental protection': 'إزالة من الرقابة الأبوية', 'Removed package from Favorites': 'تمت إزالة الباقة من المفضلة', 'Restarting stream...': 'جارٍ إعادة تشغيل البث...', 'SERIES FAVORITES': 'المسلسلات المفضلة', 'SERVERS & WEB': 'السيرفرات والويب', 'SUBTITLE LANGUAGE': 'لغة الترجمة', 'Search for a movie or series...': 'ابحث عن فيلم أو مسلسل...', 'Search results': 'نتائج البحث', 'Searching Sources...': 'جارٍ البحث في المصادر...', 'Select Server': 'اختر سيرفر', 'Select a Live package first': 'اختر باقة قنوات أولاً', 'Select a channel': 'اختر قناة', 'Select a server type. You can edit it later from Server Manager.': 'اختر نوع السيرفر. يمكنك تعديله لاحقاً من إدارة السيرفرات.', 'Series Stream Type': 'نوع بث المسلسلات', 'Server Subtitles': 'ترجمة السيرفر', 'Server did not respond. Try another channel.': 'السيرفر لا يستجيب. جرّب قناة أخرى.', 'Show hidden channels': 'إظهار القنوات المخفية', 'Show hidden packages': 'إظهار الباقات المخفية', 'Source Type': 'نوع المصدر', 'Stalker Live player': 'مشغل قنوات Stalker', 'Stalker Movies player': 'مشغل أفلام Stalker', 'Stalker Series player': 'مشغل مسلسلات Stalker', 'Stalker player engines': 'محركات تشغيل Stalker', 'Stalker player engines saved.': 'تم حفظ محركات تشغيل Stalker.', 'Start watching and unfinished titles will appear here automatically.': 'ابدأ المشاهدة، وسيظهر المحتوى غير المكتمل هنا تلقائياً.', 'Stream restarted': 'تمت إعادة تشغيل البث', 'Subtitle Font Size': 'حجم خط الترجمة', 'TV Show': 'مسلسل', 'This channel does not advertise catch-up support.': 'هذه القناة لا تدعم إعادة المشاهدة.', 'This channel has no provider catch-up window.': 'لا تتوفر فترة إعادة مشاهدة لهذه القناة من المزود.', 'This movie is not available on the current server.': 'هذا الفيلم غير متاح على السيرفر الحالي.', 'This package cannot be hidden.': 'لا يمكن إخفاء هذه الباقة.', 'This package cannot be locked.': 'لا يمكن قفل هذه الباقة.', 'TiviMate Subtitles': 'ترجمة TiviMate', 'Try again in': 'أعد المحاولة بعد', 'Type': 'النوع', 'URL / File Path': 'الرابط / مسار الملف', 'Unable to build catch-up URL': 'تعذر إنشاء رابط إعادة المشاهدة', 'Unable to change channel': 'تعذر تغيير القناة', 'Unable to clear Favorites': 'تعذر مسح المفضلة', 'Unable to load package:\n%s': 'تعذر تحميل الباقة:\n%s', 'Unable to open Genres': 'تعذر فتح التصنيفات', 'Unable to play catch-up': 'تعذر تشغيل إعادة المشاهدة', 'Unable to play this item.': 'تعذر تشغيل هذا المحتوى.', 'Unable to restart stream': 'تعذر إعادة تشغيل البث', 'Subtitle Language': 'لغة الترجمة', 'Playback': 'التشغيل', 'Loading...': 'جارٍ التحميل...', 'Details': 'التفاصيل', 'Settings saved.': 'تم حفظ الإعدادات.'})

_TRANSLATIONS["ar"].update({'Choose a collection\\nto browse titles from\\nyour selected server.': 'اختر مجموعة\\nلاستعراض المحتوى من\\nالسيرفر المحدد.', 'Import a ready-made M3U/M3U8/TXT file. Existing URL playlists remain supported when editing.': 'استيراد ملف M3U/M3U8/TXT جاهز. تظل روابط القوائم مدعومة عند التعديل.', 'Manage IPTV servers,\\nStalker / Xtream and\\nmobile Web Control.': 'إدارة سيرفرات IPTV،\\nStalker وXtream،\\nوالتحكم عبر الويب.', 'Manage playlists,\\nconnections and metadata,\\nand appearance settings.': 'إدارة قوائم التشغيل،\\nالاتصالات والبيانات،\\nوإعدادات المظهر.', 'Portal based connection\\nPortal URL and MAC address': 'اتصال عبر البوابة\\nرابط البوابة وعنوان MAC', 'Press 4 WEB QR\\nPress 7 BACKUP & RESTORE\\nPress 8 SETTINGS (NEW)': 'اضغط 4 لرمز QR\\nاضغط 7 للنسخ والاستعادة\\nاضغط 8 للإعدادات الجديدة', 'Unable to load package:\\n%s': 'تعذر تحميل الباقة:\\n%s', 'Unable to save Stalker player engines.': 'تعذر حفظ محركات تشغيل Stalker.', 'Unable to save favorite package': 'تعذر حفظ الباقة المفضلة', 'Unable to save favorites': 'تعذر حفظ المفضلة', 'Unlock this channel': 'إلغاء قفل هذه القناة', 'Unlock this package': 'إلغاء قفل هذه الباقة', 'Untitled': 'بلا عنوان', 'Update completed. Restarting Enigma2 GUI...': 'اكتمل التحديث. جارٍ إعادة تشغيل واجهة Enigma2...', 'Use the colour keys below\\nfor quick actions.': 'استخدم الأزرار الملونة أدناه\\nللإجراءات السريعة.', 'VOD Stream Type': 'نوع بث الأفلام', 'Watch unavailable': 'المشاهدة غير متاحة', 'Xtream Live player': 'مشغل قنوات Xtream', 'Xtream Movies player': 'مشغل أفلام Xtream', 'Xtream Series player': 'مشغل مسلسلات Xtream', 'Xtream archive credentials are incomplete': 'بيانات دخول أرشيف Xtream غير مكتملة', 'Xtream player engines': 'محركات تشغيل Xtream', 'Xtream player engines saved.': 'تم حفظ محركات تشغيل Xtream.', 'YELLOW  INFO': 'الأصفر  معلومات', 'YOUR STORY CONTINUES HERE': 'أكمل قصتك هنا', 'Year': 'السنة', 'Your unfinished movies and TV shows will appear here.': 'ستظهر أفلامك ومسلسلاتك غير المكتملة هنا.', 'catch-up channels': 'قنوات إعادة المشاهدة', 'results': 'نتائج'})

_LANG_MEMO = {"value": None, "checked": 0.0, "mtime": None}

def get_language():
    # r146: tr() calls this for every string; VTi's slow-log showed it
    # (one JSON file read per call) in most GUI stalls. Re-check the file's
    # mtime at most every 2 s; save_language() updates the memo at once.
    import time as _time
    now = _time.time()
    memo = _LANG_MEMO
    if memo["value"] is not None and 0 <= now - memo["checked"] < 2.0:
        return memo["value"]
    try:
        mtime = os.path.getmtime(LANG_FILE)
    except Exception:
        mtime = None
    if memo["value"] is not None and mtime == memo["mtime"]:
        memo["checked"] = now
        return memo["value"]
    try:
        with open(LANG_FILE, "r") as handle:
            value = str((json.load(handle) or {}).get("language", "en"))
        value = (value if value in SUPPORTED else
                 ("ar" if value.lower() in ("he", "iw") else "en"))
    except Exception:
        value = "en"
    memo["value"], memo["checked"], memo["mtime"] = value, now, mtime
    return value

def save_language(value):
    value = (value if value in SUPPORTED else
                 ("ar" if value.lower() in ("he", "iw") else "en"))
    _LANG_MEMO["value"], _LANG_MEMO["checked"], _LANG_MEMO["mtime"] = value, 0.0, None
    try:
        folder = os.path.dirname(LANG_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = LANG_FILE + ".tmp"
        with open(tmp, "w") as handle:
            json.dump({"language": value}, handle)
        try:
            os.rename(tmp, LANG_FILE)
        except Exception:
            if os.path.exists(LANG_FILE):
                os.remove(LANG_FILE)
            os.rename(tmp, LANG_FILE)
        # Changing application language also resets the TMDb information language.
        # A later manual choice in TMDb Settings remains independent until the
        # application language is changed again. Preserve all existing credentials.
        try:
            from .tmdb_client import CONFIG_FILE as _tmdb_config_file
            _tmdb_lang = tmdb_locale(value)
            _tmdb_cfg = {}
            if os.path.isfile(_tmdb_config_file):
                with open(_tmdb_config_file, "r") as _tf:
                    _tmdb_cfg = json.load(_tf) or {}
            _tmdb_cfg["language"] = _tmdb_lang
            _tdir = os.path.dirname(_tmdb_config_file)
            if not os.path.isdir(_tdir):
                os.makedirs(_tdir)
            _ttmp = _tmdb_config_file + ".tmp"
            with open(_ttmp, "w") as _tf:
                json.dump(_tmdb_cfg, _tf)
            os.rename(_ttmp, _tmdb_config_file)
            try:
                os.chmod(_tmdb_config_file, 0o600)
            except Exception:
                pass
        except Exception:
            # Leave a correctly saved application language usable even if
            # metadata settings storage is temporarily unavailable.
            pass
        return True
    except Exception:
        return False

# German interface strings. Kept in i18n.py so the existing Python 2.7
# shared-file installer installs this table without extra runtime imports.
_TRANSLATIONS["de"] = {
    u'%d Home picks': u'%d Vorschläge auf der Startseite',
    u'%d recent TV shows': u'%d neue Serien',
    u'%d recent movies': u'%d neue Filme',
    u'ADD A SOURCE': u'QUELLE HINZUFÜGEN',
    u'ADD IPTV SOURCE': u'IPTV-QUELLE HINZUFÜGEN',
    u'ADD NEW SERVER': u'NEUEN SERVER HINZUFÜGEN',
    u'ADD XTREAM CODES PLAYLIST': u'XTREAM-CODES-PLAYLIST HINZUFÜGEN',
    u'ALL': u'ALLE',
    u'APPLICATION LANGUAGE': u'APP-SPRACHE',
    u'AVAILABLE COLLECTIONS': u'VERFÜGBARE FILMREIHEN',
    u'Actor information is unavailable.': u'Schauspielerinformationen sind nicht verfügbar.',
    u'Actors': u'Schauspieler',
    u'Add an IPTV source first.': u'Zuerst eine IPTV-Quelle hinzufügen.',
    u'Add to My List': u'Zur Merkliste hinzufügen',
    u'Add to parental protection': u'Zur Kindersicherung hinzufügen',
    u'Added package folder to Favorites': u'Paketordner zu Favoriten hinzugefügt',
    u'Added package to Favorites': u'Paket zu Favoriten hinzugefügt',
    u'Added to favorites': u'Zu Favoriten hinzugefügt',
    u'Arabic': u'Arabisch',
    u'Audio Tracks': u'Tonspuren',
    u'Automatic checks only read a small verified update manifest. Press YELLOW to check now.': u'Automatische Prüfungen lesen nur eine verifizierte Update-Liste. Mit GELB jetzt prüfen.',
    u'Automatic update check': u'Automatische Update-Prüfung',
    u'BLUE  CHANGE STYLE': u'BLAU  ANSICHT WECHSELN',
    u'BLUE  CLEAR ALL': u'BLAU  ALLES LÖSCHEN',
    u'BLUE  TEST PORTAL': u'BLAU  PORTAL TESTEN',
    u'Back': u'Zurück',
    u'Backup': u'Sicherung',
    u'Browse the collections available on your server': u'Verfügbare Filmreihen auf deinem Server durchsuchen',
    u'Browse, discover and enjoy your library in one unified experience.': u'Durchsuche, entdecke und genieße deine Mediathek an einem Ort.',
    u'CATCH-UP / ARCHIVE': u'NACHHOLEN / ARCHIV',
    u'CONTENT': u'INHALTE',
    u'CONTROL CENTER': u'KONTROLLZENTRUM',
    u'Cache': u'Cache',
    u'Cache Location': u'Cache-Speicherort',
    u'Catch-up / Archive': u'Nachholen / Archiv',
    u'Catch-up is not available for this channel.': u'Für diesen Kanal ist kein Catch-up verfügbar.',
    u'Change parental PIN': u'PIN der Kindersicherung ändern',
    u'Changes apply to the Home screen only. Restart the app after saving.': u'Änderungen gelten nur für die Startseite. App nach dem Speichern neu starten.',
    u'Channel': u'Kanal',
    u'Channel changed': u'Kanal gewechselt',
    u'Channel could not start.': u'Kanal konnte nicht gestartet werden.',
    u'Channel hidden. Use MENU to restore it.': u'Kanal ausgeblendet. Mit MENU wiederherstellen.',
    u'Channel link unavailable.': u'Kanal-Link nicht verfügbar.',
    u'Channel locked.': u'Kanal gesperrt.',
    u'Channel position saved.': u'Kanalposition gespeichert.',
    u'Channel restored.': u'Kanal wiederhergestellt.',
    u'Channel unavailable - try another channel.': u'Kanal nicht verfügbar – anderen Kanal versuchen.',
    u'Check the selected server and try again': u'Gewählten Server prüfen und erneut versuchen',
    u'Checking for a verified update...': u'Verifiziertes Update wird geprüft ...',
    u'Checking playable catch-up channels...': u'Catch-up-Kanäle werden überprüft ...',
    u'Choose a collection\nto browse titles from\nyour selected server.': u'Filmreihe wählen,\num Titel vom gewählten\nServer zu durchsuchen.',
    u'Choose a section. Heavy image downloads are disabled in this build for stability.': u'Bereich auswählen. Große Bilddownloads sind in dieser Version aus Stabilitätsgründen deaktiviert.',
    u'Choose the server for Home': u'Server für die Startseite wählen',
    u'Choose the type of IPTV connection': u'IPTV-Verbindungstyp auswählen',
    u'Choose the type of IPTV connection you want to add': u'Typ der hinzuzufügenden IPTV-Verbindung auswählen',
    u'Clear Continue Watching': u'Weiterschauen-Verlauf leeren',
    u'Clear all Continue Watching history?': u'Gesamten Weiterschauen-Verlauf löschen?',
    u'Content locked.': u'Inhalt gesperrt.',
    u'Continue Watching': u'Weiterschauen',
    u'Date': u'Datum',
    u'Default Subtitle Language': u'Standard-Untertitelsprache',
    u'Default Subtitle Type': u'Standard-Untertiteltyp',
    u'Delete': u'Löschen',
    u'Delete Images Older Than': u'Bilder löschen, die älter sind als',
    u'Developed by Opesboy': u'Entwickelt von Opesboy',
    u'Disable move': u'Verschieben beenden',
    u'Download SubDL subtitles in': u'SubDL-Untertitel herunterladen auf',
    u'Downloading TiviMate E2 update...': u'TiviMate E2-Update wird heruntergeladen ...',
    u'Downloading and verifying the update package...': u'Update-Paket wird heruntergeladen und geprüft ...',
    u'EPG Time Offset': u'EPG-Zeitverschiebung',
    u'EXIT': u'BEENDEN',
    u'Edit Subtitles': u'Untertitel bearbeiten',
    u'Enable Catch-up Package': u'Catch-up-Paket aktivieren',
    u'Enable move': u'Verschieben aktivieren',
    u'English': u'English',
    u'Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server.': u'TMDb-API-Schlüssel eingeben. Trendinformationen stammen von TMDb; die Wiedergabe erfolgt über den gewählten Server.',
    u'Enter new 4-digit PIN': u'Neue vierstellige PIN eingeben',
    u'Enter parental PIN': u'PIN der Kindersicherung eingeben',
    u'Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate.': u'Eigene Portal-URL und MAG-MAC-Adresse eingeben. Es sind keine Portale oder Konten enthalten.',
    u'FAVORITES': u'FAVORITEN',
    u'Favorite': u'Favorit',
    u'Favorite channel position saved.': u'Position des Favoritensenders gespeichert.',
    u'Favorite options': u'Favoritenoptionen',
    u'Favorites': u'Favoriten',
    u'Favorites are already empty': u'Favoriten sind bereits leer',
    u'Favorites cleared': u'Favoriten gelöscht',
    u'Filter': u'Filter',
    u'Font saved.': u'Schrift gespeichert.',
    u'French': u'Französisch',
    u'GENRE': u'GENRES',
    u'GREEN  PLAY': u'GRÜN  ABSPIELEN',
    u'GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK': u'GRÜN SPEICHERN    BLAU CACHE LÖSCHEN    GELB BEREINIGEN    EXIT ZURÜCK',
    u'GREEN  SAVE    RED  BACK': u'GRÜN SPEICHERN    ROT ZURÜCK',
    u'GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK': u'GRÜN SPEICHERN    GELB JETZT PRÜFEN    ROT ZURÜCK',
    u'German': u'Deutsch',
    u'HOME APPEARANCE': u'STARTSEITEN-DESIGN',
    u'Hide Adult Content': u'Erwachseneninhalte ausblenden',
    u'Hide this channel': u'Diesen Kanal ausblenden',
    u'Hide this package': u'Dieses Paket ausblenden',
    u'Hide this package?': u'Dieses Paket ausblenden?',
    u'Home': u'Startseite',
    u'Home Content': u'Inhalt der Startseite',
    u'Home Skin': u'Startseiten-Design',
    u'IMAGE CACHE': u'BILDCACHE',
    u'IN USE': u'IN BENUTZUNG',
    u'IPTV EXPERIENCE': u'IPTV-ERLEBNIS',
    u'Image Cache Retention': u'Aufbewahrung des Bildcaches',
    u'Incorrect PIN': u'Falsche PIN',
    u'Installing TiViMate E2 update...': u'TiViMate E2-Update wird installiert ...',
    u'Installing TiviMate E2 update...': u'TiviMate E2-Update wird installiert ...',
    u'Internal Flash Free Space': u'Freier interner Flash-Speicher',
    u'Internal Flash Image Limit': u'Bildlimit im internen Flash',
    u'Item is already in favorites': u'Bereits in den Favoriten',
    u'LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK': u'LINKS/RECHTS BEREICH    OK UMSCHALTEN    GRÜN SPEICHERN    GELB ALLE    BLAU KEINE    EXIT ZURÜCK',
    u'LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back': u'LINKS/RECHTS Folgen    HOCH/RUNTER Staffel    OK Abspielen    ROT Favorit    EXIT Zurück',
    u'LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back': u'LINKS/RECHTS Navigieren    HOCH/RUNTER Seiten    OK Auswählen    ROT Vorherige Kategorie    BLAU Nächste Kategorie    MENU Favoriten    GRÜN Pakete/Kategorien    GELB Sortieren    EXIT Zurück',
    u'LIVE': u'LIVE',
    u'LIVE FAVORITES': u'LIVE-TV-FAVORITEN',
    u'LIVE TV': u'LIVE-TV',
    u'Language saved. Reopen the app to apply it.': u'Sprache gespeichert. App neu öffnen, um sie anzuwenden.',
    u'Latest': u'Neueste',
    u'Latest Movies': u'Neueste Filme',
    u'Latest Movies & TV Shows': u'Neueste Filme und Serien',
    u'Latest Series': u'Neueste Serien',
    u'Latest TV Shows': u'Neueste Serien',
    u'Live': u'Live-TV',
    u'Live Stream Type': u'Live-Stream-Typ',
    u'Live TV  •  Movies  •  Series  •  beIN SPORTS': u'Live-TV  •  Filme  •  Serien  •  beIN SPORTS',
    u'Live options': u'Live-TV-Optionen',
    u'Load only the categories you need to keep lists, search, and images fast.': u'Nur benötigte Kategorien laden, damit Listen, Suche und Bilder schnell bleiben.',
    u'Loading package channels...': u'Paketkanäle werden geladen ...',
    u'Lock removed.': u'Sperre entfernt.',
    u'Lock this channel': u'Diesen Kanal sperren',
    u'Lock this package': u'Dieses Paket sperren',
    u'MAG MAC Address': u'MAG-MAC-Adresse',
    u'MAG MACs / Alias': u'MAG-MAC-Adressen / Alias',
    u'MOVIE': u'FILM',
    u'MOVIE CATEGORIES': u'FILMKATEGORIEN',
    u'MOVIE FAVORITES': u'FILMFAVORITEN',
    u'MOVIES': u'FILME',
    u'Manage playlists,\nconnections and metadata,\nand appearance settings.': u'Wiedergabelisten,\nVerbindungen, Metadaten\nund Design verwalten.',
    u'Mark as Watched': u'Als gesehen markieren',
    u'Maximum Size': u'Maximale Größe',
    u'Menu': u'Menü',
    u'Menu: Toggle movie series favorite': u'MENÜ: Filmreihe zu Favoriten hinzufügen oder entfernen',
    u'Metadata language': u'Metadatensprache',
    u'More Info': u'Mehr Infos',
    u'More info': u'Mehr Infos',
    u'Move channel with UP/DOWN, then press OK to save.': u'Kanal mit HOCH/RUNTER verschieben, mit OK speichern.',
    u'Move channel with arrows, then press OK to save.': u'Kanal mit Pfeiltasten verschieben, mit OK speichern.',
    u'Move item with arrows, then press OK or BLUE to save.': u'Element mit Pfeiltasten verschieben, mit OK oder BLAU speichern.',
    u'Move this channel': u'Diesen Kanal verschieben',
    u'Movie': u'Film',
    u'Movie Parts': u'Filmreihe',
    u'Movie Series': u'Filmreihe',
    u'Movie added to favorites': u'Film zu Favoriten hinzugefügt',
    u'Movie details are still loading.': u'Filmdetails werden noch geladen.',
    u'Movie images are still loading.': u'Filmbilder werden noch geladen.',
    u'Movie is already in favorites': u'Film ist bereits in den Favoriten',
    u'Movies': u'Filme',
    u'Movies  0': u'Filme  0',
    u'Movies You Might Like': u'Filme, die dir gefallen könnten',
    u'Movies and TV Shows packages are available for Xtream and Stalker sources.': u'Film- und Serienpakete sind für Xtream- und Stalker-Quellen verfügbar.',
    u'NEXT': u'ALS NÄCHSTES',
    u'NO COLLECTIONS': u'KEINE FILMREIHEN',
    u'NOW': u'JETZT',
    u'Name': u'Name',
    u'Next Category': u'Nächste Kategorie',
    u'No EPG data': u'Keine EPG-Daten',
    u'No Genre items to add': u'Keine Genre-Titel zum Hinzufügen',
    u'No IPTV servers found.': u'Keine IPTV-Server gefunden.',
    u'No Other Sources': u'Keine weiteren Quellen',
    u'No active channel to restart': u'Kein aktiver Kanal zum Neustart',
    u'No catch-up channels are available on this server.': u'Dieser Server bietet keine Catch-up-Kanäle.',
    u'No catch-up programmes are available for this channel.': u'Für diesen Kanal sind keine Catch-up-Sendungen verfügbar.',
    u'No categories available.': u'Keine Kategorien verfügbar.',
    u'No channels found in this package': u'Keine Kanäle in diesem Paket gefunden',
    u'No channels left in this favorite package': u'Keine Kanäle mehr in diesem Favoritenpaket',
    u'No collection available.': u'Keine Filmreihe verfügbar.',
    u'No content': u'Keine Inhalte',
    u'No enabled categories are available for this library.': u'Keine aktivierten Kategorien für diese Bibliothek verfügbar.',
    u'No enabled collections are available for this server': u'Keine aktivierten Filmreihen für diesen Server verfügbar',
    u'No favorite channels yet. Add channels with the red button.': u'Noch keine favorisierten Sender. Mit ROT hinzufügen.',
    u'No hidden channels.': u'Keine ausgeblendeten Kanäle.',
    u'No hidden packages.': u'Keine ausgeblendeten Pakete.',
    u'No parts of this movie were found on this server.': u'Auf diesem Server wurden keine weiteren Teile dieser Filmreihe gefunden.',
    u'No recently watched Stalker items.': u'Keine zuletzt angesehenen Stalker-Titel.',
    u'No results': u'Keine Ergebnisse',
    u'No saved items in this filter. Open a title and choose Add to My List.': u'Keine gespeicherten Titel in diesem Filter. Titel öffnen und zur Merkliste hinzufügen.',
    u'No seasons': u'Keine Staffeln',
    u'No server selected • Press SETTINGS': u'Kein Server ausgewählt • EINSTELLUNGEN drücken',
    u'OFFLINE': u'OFFLINE',
    u'OK  KEYBOARD    GREEN  SAVE    RED  CANCEL': u'OK TASTATUR    GRÜN SPEICHERN    ROT ABBRECHEN',
    u'OK KEYBOARD    GREEN SAVE    RED CANCEL': u'OK TASTATUR    GRÜN SPEICHERN    ROT ABBRECHEN',
    u'OK Open    EXIT Back': u'OK Öffnen    EXIT Zurück',
    u'OK SELECT    EXIT BACK': u'OK AUSWÄHLEN    EXIT ZURÜCK',
    u'OK Select     RED Delete     BLUE Test     EXIT Cancel': u'OK Auswählen     ROT Löschen     BLAU Testen     EXIT Abbrechen',
    u'OK: Edit key   YELLOW: Import /tmp/tivimatee2/key.txt   GREEN: Save   EXIT: Close': u'OK: Schlüssel bearbeiten   GELB: /tmp/tivimatee2/key.txt importieren   GRÜN: Speichern   EXIT: Schließen',
    u'ONLINE': u'ONLINE',
    u'Open a Movies or TV Shows package first': u'Zuerst ein Film- oder Serienpaket öffnen',
    u'Open a package, select a channel, then press RED': u'Paket öffnen, Kanal auswählen und ROT drücken',
    u'Original': u'Original',
    u'Other Sources': u'Weitere Quellen',
    u'PACKAGES': u'PAKETE',
    u'PIN must contain exactly 4 digits.': u'Die PIN muss genau vier Ziffern enthalten.',
    u'Package hidden. Use MENU to restore it.': u'Paket ausgeblendet. Mit MENU wiederherstellen.',
    u'Package is already in Favorites': u'Paket ist bereits in den Favoriten',
    u'Package locked.': u'Paket gesperrt.',
    u'Package restored.': u'Paket wiederhergestellt.',
    u'Packages': u'Pakete',
    u'Page': u'Seite',
    u'Parental PIN changed.': u'PIN der Kindersicherung geändert.',
    u'Password': u'Passwort',
    u'Pick up where you left off. Your movies and TV shows will appear here automatically.': u'Dort weiterschauen, wo du aufgehört hast. Filme und Serien erscheinen hier automatisch.',
    u'Play': u'Abspielen',
    u'Playing catch-up': u'Catch-up wird abgespielt',
    u'Playlist Name': u'Name der Playlist',
    u'Popular Movies': u'Beliebte Filme',
    u'Popular Show': u'Beliebte Inhalte',
    u'Popular TV Shows': u'Beliebte Serien',
    u'Port': u'Port',
    u'Portal Name': u'Portalname',
    u'Portal URL': u'Portal-URL',
    u'Portal based connection\nPortal URL and MAC address': u'Portalbasierte Verbindung\nPortal-URL und MAC-Adresse',
    u'Portal returned no archive link': u'Portal hat keinen Archiv-Link geliefert',
    u'Portal returned no playable URL': u'Portal hat keine abspielbare URL geliefert',
    u'Preferred Subtitle Language': u'Bevorzugte Untertitelsprache',
    u'Preparing series categories in the background...': u'Serienkategorien werden im Hintergrund vorbereitet ...',
    u'Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates.': u'5 für SUBDL-API-Schlüssel, Untertitelsprache oder Schrift. 3 für Updates.',
    u'Press OK again to open the search keyboard': u'OK erneut drücken, um die Suchtastatur zu öffnen',
    u'Press OK to open': u'Mit OK öffnen',
    u'Press OK to start searching': u'Mit OK die Suche starten',
    u'Press for Other Sources': u'Für weitere Quellen drücken',
    u'Previous Category': u'Vorherige Kategorie',
    u'Programme start time is missing': u'Startzeit der Sendung fehlt',
    u'Protocol': u'Protokoll',
    u'RECENTLY ADDED': u'NEU HINZUGEFÜGT',
    u'RED  REMOVE': u'ROT  ENTFERNEN',
    u'RED - Edit Subtitles': u'ROT – Untertitel bearbeiten',
    u'Rating': u'Bewertung',
    u'Recent Added Movies': u'Neu hinzugefügte Filme',
    u'Recent Added TV Shows': u'Neu hinzugefügte Serien',
    u'Recently Added': u'Kürzlich hinzugefügt',
    u'Recently watched': u'Zuletzt angesehen',
    u'Recommendations': u'Empfehlungen',
    u'Refresh': u'Aktualisieren',
    u'Remove from Continue Watching': u'Aus Weiterschauen entfernen',
    u'Remove from My List': u'Aus Merkliste entfernen',
    u'Remove from parental protection': u'Aus Kindersicherung entfernen',
    u'Removed from favorites': u'Aus Favoriten entfernt',
    u'Removed package from Favorites': u'Paket aus Favoriten entfernt',
    u'Restarting stream...': u'Stream wird neu gestartet ...',
    u'Restore': u'Wiederherstellen',
    u'Resume': u'Fortsetzen',
    u'SERIES': u'SERIEN',
    u'SERIES FAVORITES': u'SERIENFAVORITEN',
    u'SERVER CONTENT FILTER': u'SERVER-INHALTSFILTER',
    u'SERVER STATUS  •  CONNECTION & ACTIVE USE': u'SERVERSTATUS  •  VERBINDUNG UND NUTZUNG',
    u'SETTINGS  •  SERVER MANAGER': u'EINSTELLUNGEN  •  SERVERVERWALTUNG',
    u'SOFTWARE UPDATES': u'SOFTWARE-UPDATES',
    u'STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS': u'STALKER-PORTAL  •  LIVE, FILME & SERIEN',
    u'SUBDL SUBTITLE LANGUAGE': u'SUBDL-UNTERTITELSPRACHE',
    u'Save': u'Speichern',
    u'Search': u'Suche',
    u'Search for a channel, movie or series...': u'Kanal, Film oder Serie suchen ...',
    u'Search for a movie or series...': u'Film oder Serie suchen ...',
    u'Search results': u'Suchergebnisse',
    u'Searching Sources...': u'Quellen werden durchsucht ...',
    u'Searching...': u'Suche läuft ...',
    u'Select': u'Auswählen',
    u'Select Server': u'Server auswählen',
    u'Select a Live package first': u'Zuerst ein Live-TV-Paket auswählen',
    u'Select a category': u'Kategorie auswählen',
    u'Select a channel': u'Kanal auswählen',
    u'Select a movie or TV show first': u'Zuerst einen Film oder eine Serie auswählen',
    u'Select a movie poster first': u'Zuerst ein Filmplakat auswählen',
    u'Select a package': u'Paket auswählen',
    u'Select a series category': u'Serienkategorie auswählen',
    u'Select a series category then press OK.': u'Serienkategorie auswählen und OK drücken.',
    u'Select a server type. You can edit it later from Server Manager.': u'Servertyp wählen. Er kann später in der Serververwaltung geändert werden.',
    u'Select the category then press OK. Only this category will be loaded.': u'Kategorie auswählen und OK drücken. Nur diese Kategorie wird geladen.',
    u'Series Stream Type': u'Serien-Stream-Typ',
    u'Series added to favorites': u'Serie zu Favoriten hinzugefügt',
    u'Series is already in favorites': u'Serie ist bereits in den Favoriten',
    u'Server': u'Server',
    u'Server Finder': u'Server-Suche',
    u'Server Subtitles': u'Server-Untertitel',
    u'Server URL': u'Server-URL',
    u'Server did not respond. Try another channel.': u'Server antwortet nicht. Anderen Kanal versuchen.',
    u'Server: %s  •  %s': u'Server: %s  •  %s',
    u'Servers': u'Server',
    u'Settings': u'Einstellungen',
    u'Show hidden channels': u'Ausgeblendete Kanäle anzeigen',
    u'Show hidden packages': u'Ausgeblendete Pakete anzeigen',
    u'Shows  0': u'Serien  0',
    u'Source Type': u'Quelltyp',
    u'Stalker Live player': u'Stalker-Live-TV-Player',
    u'Stalker Movies player': u'Stalker-Filmplayer',
    u'Stalker Series player': u'Stalker-Serienplayer',
    u'Stalker packages are ready. Open Categories and select a package to load its titles.': u'Stalker-Pakete sind bereit. Kategorien öffnen und ein Paket auswählen.',
    u'Stalker player engines': u'Stalker-Wiedergabe-Engines',
    u'Stalker player engines saved.': u'Stalker-Wiedergabe-Engines gespeichert.',
    u'Stalker requires your own Portal URL and MAG MAC address. No portal is included.': u'Stalker benötigt deine eigene Portal-URL und MAG-MAC-Adresse. Kein Portal enthalten.',
    u'Stalker returned no items for this package. Try another package or refresh the source.': u'Stalker hat für dieses Paket keine Inhalte geliefert. Anderes Paket wählen oder Quelle aktualisieren.',
    u'Stalker returned no packages. Check Portal URL and MAG MAC, then retry.': u'Stalker hat keine Pakete geliefert. Portal-URL und MAG-MAC prüfen.',
    u'Start watching and unfinished titles will appear here automatically.': u'Beim Ansehen erscheinen nicht abgeschlossene Titel automatisch hier.',
    u'Stream Format': u'Stream-Format',
    u'Stream restarted': u'Stream neu gestartet',
    u'SubDL API Key  (OK to edit)': u'SubDL-API-Schlüssel (OK zum Bearbeiten)',
    u'Subtitle': u'Untertitel',
    u'Subtitle Font Size': u'Untertitel-Schriftgröße',
    u'Subtitles': u'Untertitel',
    u'TIVIMATE  •  PREMIUM IPTV': u'TIVIMATE  •  PREMIUM-IPTV',
    u'TMDb API Key': u'TMDb-API-Schlüssel',
    u'TMDb TRENDING SETTINGS': u'TMDb-TREND-EINSTELLUNGEN',
    u'TV SHOW CATEGORIES': u'SERIENKATEGORIEN',
    u'TV SHOWS': u'SERIEN',
    u'TV Show': u'Serie',
    u'TV Shows': u'Serien',
    u'TV Shows You Might Like': u'Serien, die dir gefallen könnten',
    u'The category is preparing in the background... the interface will not freeze.': u'Kategorie wird im Hintergrund vorbereitet – die Oberfläche bleibt bedienbar.',
    u'The update installer returned an error.': u'Das Update-Installationsprogramm hat einen Fehler gemeldet.',
    u'The verified package could not be installed.': u'Das verifizierte Paket konnte nicht installiert werden.',
    u'This channel does not advertise catch-up support.': u'Dieser Kanal bietet keinen Catch-up-Dienst.',
    u'This channel has no provider catch-up window.': u'Für diesen Kanal ist kein Catch-up-Zeitfenster verfügbar.',
    u'This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager.': u'Diese Sprache wird für die GELBE SubDL-Taste verwendet. Den API-Schlüssel separat in der Serververwaltung importieren.',
    u'This movie has no other parts.': u'Dieser Film hat keine weiteren Teile.',
    u'This movie is not available on the current server.': u'Dieser Film ist auf dem aktuellen Server nicht verfügbar.',
    u'This title is not available on the server and cannot be added to favorites': u'Dieser Titel ist auf dem Server nicht verfügbar und kann nicht zu Favoriten hinzugefügt werden',
    u'TiViMate': u'TiViMate',
    u'TiViMate E2 is already up to date.': u'TiViMate E2 ist bereits aktuell.',
    u'TiViMate IPTV EXPERIENCE': u'TiViMate IPTV-ERLEBNIS',
    u"Today's Trending Movies": u'Filmtrends von heute',
    u"Today's Trending Series": u'Serientrends von heute',
    u'Trending Movies': u'Filmtrends',
    u'Trending TV Shows': u'Serientrends',
    u'Turkish': u'Türkisch',
    u'UPDATE PLAYLIST': u'PLAYLIST AKTUALISIEREN',
    u'Unable to remove this Favorite.': u'Favorit konnte nicht entfernt werden.',
    u'Unable to save favorite': u'Favorit konnte nicht gespeichert werden',
    u'Unable to save movie series': u'Filmreihe konnte nicht gespeichert werden',
    u'Unable to save settings.': u'Einstellungen konnten nicht gespeichert werden.',
    u'Unable to start the update installer.': u'Update-Installationsprogramm konnte nicht gestartet werden.',
    u'Unable to verify updates right now. You can try again later.': u'Updates konnten nicht geprüft werden. Bitte später erneut versuchen.',
    u'Update completed. Restart the Enigma2 GUI to use the new version.': u'Update abgeschlossen. Enigma2-Oberfläche neu starten.',
    u'Update download failed.': u'Download des Updates fehlgeschlagen.',
    u'Use OK to enter characters. GREEN saves. RED or EXIT cancels.': u'Mit OK Zeichen eingeben. GRÜN speichert. ROT oder EXIT bricht ab.',
    u'Use the colour keys below\nfor quick actions.': u'Die Farbtasten unten\nfür Schnellaktionen verwenden.',
    u'Username': u'Benutzername',
    u'WATCH NOW': u'JETZT ANSEHEN',
    u'YOUR ENTERTAINMENT, ONE PLACE': u'UNTERHALTUNG AN EINEM ORT',
    u'YOUR LIBRARY': u'DEINE MEDIATHEK',
    u'YOUR SAVED CONTENT': u'DEINE GESPEICHERTEN INHALTE',
    u'Yellow appears only when the server reports active use.': u'Gelb wird nur angezeigt, wenn der Server eine aktive Nutzung meldet.',
    u'↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles': u'↑↓ Wechseln   MENU Player-Engine   BLAU SubsSupport   ROT Untertitel bearbeiten',
    u'▶  Watch': u'▶  Ansehen',
    u'★ TMDb Poster in Live': u'★ TMDb-Poster im Live-TV',
}

# Additional German Live / settings error messages.
_TRANSLATIONS["de"].update({
    u'ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES': u'PFEILE PLAKAT WÄHLEN    •    GELB GEDRÜCKT HALTEN, UM FILM / SERIE ZU FAVORITEN HINZUZUFÜGEN',
    u'Built-in TMDb access is active. Enter your own key only to override it.': u'Integrierter TMDb-Zugang ist aktiv. Nur bei Bedarf einen eigenen Schlüssel eingeben.',
    u'Choose a collection\\nto browse titles from\\nyour selected server.': u'Filmreihe wählen\\num Titel vom gewählten\\nServer zu durchsuchen.',
    u'Details': u'Details',
    u'Import a ready-made M3U/M3U8/TXT file. Existing URL playlists remain supported when editing.': u'Eine M3U/M3U8/TXT-Datei importieren. URL-Playlists bleiben bearbeitbar.',
    u'Loading...': u'Wird geladen ...',
    u'Manage IPTV servers,\\nStalker / Xtream and\\nmobile Web Control.': u'IPTV-Server,\\nStalker / Xtream und\\nWebsteuerung verwalten.',
    u'Manage playlists,\\nconnections and metadata,\\nand appearance settings.': u'Playlists,\\nVerbindungen, Metadaten und\\nDarstellung verwalten.',
    u'OK Play     EXIT Back': u'OK Abspielen     EXIT Zurück',
    u'Playback': u'Wiedergabe',
    u'Portal based connection\\nPortal URL and MAC address': u'Portalbasierte Verbindung\\nPortal-URL und MAC-Adresse',
    u'Press 4 WEB QR\\nPress 7 BACKUP & RESTORE\\nPress 8 SETTINGS (NEW)': u'4 WEB QR\\n7 SICHERN & WIEDERHERSTELLEN\\n8 EINSTELLUNGEN (NEU)',
    u'SERVERS & WEB': u'SERVER & WEB',
    u'SUBTITLE LANGUAGE': u'UNTERTITELSPRACHE',
    u'Settings saved.': u'Einstellungen gespeichert.',
    u'Subtitle Language': u'Untertitelsprache',
    u'This package cannot be hidden.': u'Dieses Paket kann nicht ausgeblendet werden.',
    u'This package cannot be locked.': u'Dieses Paket kann nicht gesperrt werden.',
    u'TiviMate E2': u'TiviMate E2',
    u'TiviMate Subtitles': u'TiviMate Untertitel',
    u'Try again in': u'Erneuter Versuch in',
    u'Type': u'Typ',
    u'UNABLE TO LOAD CATEGORIES': u'KATEGORIEN KONNTEN NICHT GELADEN WERDEN',
    u'URL / File Path': u'URL / Dateipfad',
    u'Unable to build catch-up URL': u'Catch-up-URL konnte nicht erstellt werden',
    u'Unable to change channel': u'Kanalwechsel fehlgeschlagen',
    u'Unable to clear Favorites': u'Favoriten konnten nicht gelöscht werden',
    u'Unable to load package:\n%s': u'Paket konnte nicht geladen werden:\n%s',
    u'Unable to load package:\\n%s': u'Paket konnte nicht geladen werden:\\n%s',
    u'Unable to open Genres': u'Genres konnten nicht geöffnet werden',
    u'Unable to play catch-up': u'Catch-up konnte nicht abgespielt werden',
    u'Unable to play this item.': u'Dieser Titel konnte nicht abgespielt werden.',
    u'Unable to restart stream': u'Stream konnte nicht neu gestartet werden',
    u'Unable to save Stalker player engines.': u'Stalker-Player-Engines konnten nicht gespeichert werden.',
    u'Unable to save favorite package': u'Favoritenpaket konnte nicht gespeichert werden',
    u'Unable to save favorites': u'Favoriten konnten nicht gespeichert werden',
    u'Unlock this channel': u'Kanal entsperren',
    u'Unlock this package': u'Paket entsperren',
    u'Untitled': u'Ohne Titel',
    u'Update completed. Restarting Enigma2 GUI...': u'Update abgeschlossen. Enigma2-Oberfläche wird neu gestartet ...',
    u'Use the colour keys below\\nfor quick actions.': u'Farbtasten unten für\\nSchnellaktionen verwenden.',
    u'VOD Stream Type': u'VOD-Stream-Typ',
    u'Watch unavailable': u'Wiedergabe nicht verfügbar',
    u'Xtream Live player': u'Xtream-Live-Player',
    u'Xtream Movies player': u'Xtream-Filmplayer',
    u'Xtream Series player': u'Xtream-Serienplayer',
    u'Xtream archive credentials are incomplete': u'Xtream-Archiv-Zugangsdaten sind unvollständig',
    u'Xtream player engines': u'Xtream-Wiedergabe-Engines',
    u'Xtream player engines saved.': u'Xtream-Wiedergabe-Engines gespeichert.',
    u'YELLOW  INFO': u'GELB  INFOS',
    u'YOUR STORY CONTINUES HERE': u'DEINE GESCHICHTE GEHT HIER WEITER',
    u'Year': u'Jahr',
    u'Your unfinished movies and TV shows will appear here.': u'Nicht abgeschlossene Filme und Serien erscheinen hier.',
    u'catch-up channels': u'Catch-up-Kanäle',
    u'results': u'Ergebnisse',
})

# Cinema sidebar navigation keys, shared with the application language selector.
for _lang, _labels in {
    "ar": {"Search": "البحث", "Server Finder": "بحث السيرفر", "Resume": "متابعة المشاهدة", "Favorites": "المفضلة", "Settings": "الإعدادات"},
    "fr": {"Search": "Recherche", "Server Finder": "Recherche de serveurs", "Resume": "Reprendre", "Favorites": "Favoris", "Settings": "Paramètres"},
    "tr": {"Search": "Ara", "Server Finder": "Sunucu Bulucu", "Resume": "Devam", "Favorites": "Favoriler", "Settings": "Ayarlar"},
}.items():
    _TRANSLATIONS.setdefault(_lang, {}).update(_labels)

_TRANSLATIONS["ar"].update({'Font saved.': 'تم حفظ الخط.', 'Movie Parts': 'أجزاء الفيلم', 'Searching...': 'جارٍ البحث...', 'This movie has no other parts.': 'هذا الفيلم ليس له أجزاء أخرى.', 'No parts of this movie were found on this server.': 'لم يُعثر على أجزاء هذا الفيلم في هذا السيرفر.', 'Movie details are still loading.': 'تفاصيل الفيلم ما زالت قيد التحميل.'})

# Official collection/series label; the old Movie Parts key remains as a
# compatibility alias for plugins that still request it.
for _series_lang, _series_label in {
    'ar': u'سلسلة الأفلام', 'fr': u'Série de films', 'tr': u'Film Serisi',
}.items():
    _TRANSLATIONS.setdefault(_series_lang, {})['Movie Series'] = _series_label
    _TRANSLATIONS[_series_lang]['Movie Parts'] = _series_label

# Manual playlist refresh and archive navigation.
_TRANSLATIONS.setdefault('ar', {}).update({
    'Refresh Playlist': u"تحديث قائمة التشغيل",
    'Catch-up categories': u"تصنيفات إعادة المشاهدة",
    'All catch-up channels': u"جميع قنوات إعادة المشاهدة",
    'GREEN: Search / Hold GREEN: Categories': u"الأخضر: بحث / ضغط مطول: التصنيفات",
    'Refreshing playlist...': u"جارٍ تحديث قائمة التشغيل...",
    'Playlist refreshed.': u"تم تحديث قائمة التشغيل.",
    'Not refreshed:': u"لم يتم تحديث:",
    'Reopen packages to load updated content.': u"أعد فتح الباقات لتحميل المحتوى المحدث.",
    'Playlist refresh failed. Check the provider and try again.': u"فشل تحديث القائمة. تحقق من المزود وحاول مجدداً.",
    'Playlist refresh is already running.': u"تحديث القائمة قيد التنفيذ.",
})
_TRANSLATIONS.setdefault('fr', {}).update({
    'Refresh Playlist': u"Actualiser la playlist",
    'Catch-up categories': u"Catégories de replay",
    'All catch-up channels': u"Toutes les chaînes replay",
    'GREEN: Search / Hold GREEN: Categories': u"VERT : rechercher / appui long : catégories",
    'Refreshing playlist...': u"Actualisation de la playlist...",
    'Playlist refreshed.': u"Playlist actualisée.",
    'Not refreshed:': u"Non actualisé :",
    'Reopen packages to load updated content.': u"Rouvrez les bouquets pour charger le contenu actualisé.",
    'Playlist refresh failed. Check the provider and try again.': u"Échec de l’actualisation. Vérifiez le fournisseur et réessayez.",
    'Playlist refresh is already running.': u"Actualisation déjà en cours.",
})
_TRANSLATIONS.setdefault('tr', {}).update({
    'Refresh Playlist': u"Listeyi yenile",
    'Catch-up categories': u"Tekrar izleme kategorileri",
    'All catch-up channels': u"Tüm tekrar izleme kanalları",
    'GREEN: Search / Hold GREEN: Categories': u"YEŞİL: Ara / uzun bas: Kategoriler",
    'Refreshing playlist...': u"Liste yenileniyor...",
    'Playlist refreshed.': u"Liste yenilendi.",
    'Not refreshed:': u"Yenilenmedi:",
    'Reopen packages to load updated content.': u"Güncel içerik için paketleri yeniden açın.",
    'Playlist refresh failed. Check the provider and try again.': u"Liste yenilenemedi. Sağlayıcıyı kontrol edip tekrar deneyin.",
    'Playlist refresh is already running.': u"Liste zaten yenileniyor.",
})
_TRANSLATIONS.setdefault('de', {}).update({
    'Refresh Playlist': u"Wiedergabeliste aktualisieren",
    'Catch-up categories': u"Replay-Kategorien",
    'All catch-up channels': u"Alle Replay-Sender",
    'GREEN: Search / Hold GREEN: Categories': u"GRÜN: Suche / lange drücken: Kategorien",
    'Refreshing playlist...': u"Wiedergabeliste wird aktualisiert...",
    'Playlist refreshed.': u"Wiedergabeliste aktualisiert.",
    'Not refreshed:': u"Nicht aktualisiert:",
    'Reopen packages to load updated content.': u"Pakete erneut öffnen, um neue Inhalte zu laden.",
    'Playlist refresh failed. Check the provider and try again.': u"Aktualisierung fehlgeschlagen. Anbieter prüfen und erneut versuchen.",
    'Playlist refresh is already running.': u"Aktualisierung läuft bereits.",
})

# Manual playlist refresh and archive navigation.
_TRANSLATIONS.setdefault('ar', {}).update({
    'Refresh Playlist': u"تحديث قائمة التشغيل",
    'Catch-up categories': u"تصنيفات إعادة المشاهدة",
    'All catch-up channels': u"جميع قنوات إعادة المشاهدة",
    'GREEN: Search / Hold GREEN: Categories': u"الأخضر: بحث / ضغط مطول: التصنيفات",
    'Refreshing playlist...': u"جارٍ تحديث قائمة التشغيل...",
    'Playlist refreshed.': u"تم تحديث قائمة التشغيل.",
    'Not refreshed:': u"لم يتم تحديث:",
    'Reopen packages to load updated content.': u"أعد فتح الباقات لتحميل المحتوى المحدث.",
    'Playlist refresh failed. Check the provider and try again.': u"فشل تحديث القائمة. تحقق من المزود وحاول مجدداً.",
    'Playlist refresh is already running.': u"تحديث القائمة قيد التنفيذ.",
})
_TRANSLATIONS.setdefault('fr', {}).update({
    'Refresh Playlist': u"Actualiser la playlist",
    'Catch-up categories': u"Catégories de replay",
    'All catch-up channels': u"Toutes les chaînes replay",
    'GREEN: Search / Hold GREEN: Categories': u"VERT : rechercher / appui long : catégories",
    'Refreshing playlist...': u"Actualisation de la playlist...",
    'Playlist refreshed.': u"Playlist actualisée.",
    'Not refreshed:': u"Non actualisé :",
    'Reopen packages to load updated content.': u"Rouvrez les bouquets pour charger le contenu actualisé.",
    'Playlist refresh failed. Check the provider and try again.': u"Échec de l’actualisation. Vérifiez le fournisseur et réessayez.",
    'Playlist refresh is already running.': u"Actualisation déjà en cours.",
})
_TRANSLATIONS.setdefault('tr', {}).update({
    'Refresh Playlist': u"Listeyi yenile",
    'Catch-up categories': u"Tekrar izleme kategorileri",
    'All catch-up channels': u"Tüm tekrar izleme kanalları",
    'GREEN: Search / Hold GREEN: Categories': u"YEŞİL: Ara / uzun bas: Kategoriler",
    'Refreshing playlist...': u"Liste yenileniyor...",
    'Playlist refreshed.': u"Liste yenilendi.",
    'Not refreshed:': u"Yenilenmedi:",
    'Reopen packages to load updated content.': u"Güncel içerik için paketleri yeniden açın.",
    'Playlist refresh failed. Check the provider and try again.': u"Liste yenilenemedi. Sağlayıcıyı kontrol edip tekrar deneyin.",
    'Playlist refresh is already running.': u"Liste zaten yenileniyor.",
})
_TRANSLATIONS.setdefault('de', {}).update({
    'Refresh Playlist': u"Wiedergabeliste aktualisieren",
    'Catch-up categories': u"Replay-Kategorien",
    'All catch-up channels': u"Alle Replay-Sender",
    'GREEN: Search / Hold GREEN: Categories': u"GRÜN: Suche / lange drücken: Kategorien",
    'Refreshing playlist...': u"Wiedergabeliste wird aktualisiert...",
    'Playlist refreshed.': u"Wiedergabeliste aktualisiert.",
    'Not refreshed:': u"Nicht aktualisiert:",
    'Reopen packages to load updated content.': u"Pakete erneut öffnen, um neue Inhalte zu laden.",
    'Playlist refresh failed. Check the provider and try again.': u"Aktualisierung fehlgeschlagen. Anbieter prüfen und erneut versuchen.",
    'Playlist refresh is already running.': u"Aktualisierung läuft bereits.",
})

def tr(text):
    # Empty widget text is not a translation key. Keep Live/EPG fields empty
    # instead of showing an unrelated loading message in Arabic.
    if text == "" or text is None:
        return ""
    code = get_language()
    value = _TRANSLATIONS.get(code, {}).get(text)
    if value is None and code != "en":
        value = _file_table(code).get(text)
    return value if value else text

def tr_text(text):
    """tr() as unicode text on Python 2 too (for code built on u'' strings)."""
    value = tr(text)
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.decode("utf-8", "replace")
    return value

def tr_inline(table, english):
    """Inline {"ar": ..., "fr": ...} labels: the table's own text when it has
    the current language, otherwise the language files, otherwise English."""
    value = (table or {}).get(get_language())
    return value if value else tr(english)

_NAV_ICONS = {}
def nav_label(key):
    """Translated navigation label. Icons are lightweight static PNG assets in the skin."""
    return tr(key)

# ---------------------------------------------------------------------------
# Menus in every TiviMate screen follow the app language.
#
# Option menus (Enigma2 ChoiceBox: player MENU, Live options, backups ...)
# and fixed captions written inside screen skins (top bars such as
# "Search  Home  Live  Movies") were plain English. Both are now passed
# through tr() when a TiviMate screen creates them; screens of other
# plugins are never touched.
# ---------------------------------------------------------------------------
import re as _re
import sys as _sys

_SKIN_TEXT_RE = _re.compile(r'(\stext=")([^"]+)(")')
try:
    _TEXT_TYPES = (str, bytes, unicode)  # noqa: F821 (Python 2)
except NameError:
    _TEXT_TYPES = (str, bytes)

def _called_from_tivimate(depth=12):
    try:
        frame = _sys._getframe(2)
    except Exception:
        return False
    while frame is not None and depth > 0:
        name = str(frame.f_globals.get("__name__") or "")
        if "TiviMateE2" in name and not name.endswith(".i18n"):
            return True
        frame = frame.f_back
        depth -= 1
    return False

def _xml_text(value):
    if isinstance(value, bytes):
        return value.replace(b"&", b"&amp;").replace(b"<", b"&lt;").replace(b'"', b"&quot;")
    return value.replace("&", "&amp;").replace("<", "&lt;").replace('"', "&quot;")

def translate_skin_texts(skin):
    """text="..." captions of a skin string, in the app language."""
    if not skin or 'text="' not in skin or get_language() == "en":
        return skin

    def repl(match):
        original = match.group(2)
        value = tr(original.replace("&amp;", "&"))
        if not value or value == original:
            return match.group(0)
        if isinstance(value, bytes) and not isinstance(original, bytes):
            try:
                value = value.decode("utf-8")
            except Exception:
                return match.group(0)
        return match.group(1) + _xml_text(value) + match.group(3)
    try:
        return _SKIN_TEXT_RE.sub(repl, skin)
    except Exception:
        return skin

def _install_menu_translation():
    try:
        from Screens.ChoiceBox import ChoiceBox
    except Exception:
        ChoiceBox = None
    if ChoiceBox is not None and not getattr(ChoiceBox.__init__, "_tivimate_tr", False):
        original_choice = ChoiceBox.__init__

        def _menu_rows(rows):
            return [((tr(item[0]),) + tuple(item[1:])) if isinstance(item, tuple) and item and item[0]
                    else item for item in rows]

        def choice_init(self, session, *args, **kwargs):
            # Same arguments in, same order out: only the visible texts change.
            if _called_from_tivimate() and get_language() != "en":
                try:
                    args = list(args)
                    if args and isinstance(args[0], _TEXT_TYPES) and args[0]:
                        args[0] = tr(args[0])
                    if len(args) > 1 and isinstance(args[1], (tuple, type([]))):
                        args[1] = _menu_rows(args[1])
                    for key in ("title", "text"):
                        if isinstance(kwargs.get(key), _TEXT_TYPES) and kwargs[key]:
                            kwargs[key] = tr(kwargs[key])
                    for key in ("list", "choiceList"):
                        if isinstance(kwargs.get(key), (tuple, type([]))):
                            kwargs[key] = _menu_rows(kwargs[key])
                except Exception:
                    pass
            return original_choice(self, session, *args, **kwargs)
        choice_init._tivimate_tr = True
        ChoiceBox.__init__ = choice_init
    try:
        from Screens.Screen import Screen
    except Exception:
        return
    if not getattr(Screen.__init__, "_tivimate_tr", False):
        original_screen = Screen.__init__

        def screen_init(self, *args, **kwargs):
            original_screen(self, *args, **kwargs)
            try:
                if "TiviMateE2" in type(self).__module__:
                    skin = getattr(self, "skin", None)
                    if isinstance(skin, _TEXT_TYPES):
                        translated = translate_skin_texts(skin)
                        if translated is not skin and translated != skin:
                            self.skin = translated
            except Exception:
                pass
        screen_init._tivimate_tr = True
        Screen.__init__ = screen_init

try:
    _install_menu_translation()
except Exception:
    pass

# Arabic labels for multi-select / move / delete in Live lists and Favorites.
for _ms_key, _ms_val in {
    'Select channels to move': 'تحديد عدة قنوات',
    'Select packages to move': 'تحديد عدة باقات',
    'Move selected (%d)': 'نقل المحدد (%d)',
    'Delete selected (%d)': 'حذف المحدد (%d)',
    'Add selected to Favorites (%d)': 'إضافة المحدد إلى المفضلة (%d)',
    'Cancel selection': 'إلغاء التحديد',
    'Selection cancelled.': 'تم إلغاء التحديد.',
    '%d selected': 'المحدد: %d',
    'OK mark/unmark   MENU move/delete/favorite   EXIT cancel': 'OK تحديد/إلغاء   MENU نقل/حذف/مفضلة   EXIT خروج',
    'Mark at least one channel with OK first.': 'حدد قناة واحدة على الأقل بزر OK أولاً.',
    'Mark at least one item with OK first.': 'حدد عنصراً واحداً على الأقل بزر OK أولاً.',
    'Remove %d channels from Favorites?': 'حذف %d قناة من المفضلة؟',
    'Delete %d channels from this package?\nThey can be restored from MENU > Show hidden channels.': 'حذف %d قناة من هذه الباقة؟\nتقدر ترجعها من MENU > إظهار القنوات المخفية.',
    '%d channels removed from Favorites.': 'تم حذف %d قناة من المفضلة.',
    '%d channels deleted. MENU > Show hidden channels restores them.': 'تم حذف %d قناة. لاسترجاعها: MENU > إظهار القنوات المخفية.',
    '★ %d channels added to FAVORITES': '★ تمت إضافة %d قناة إلى المفضلة',
    'Selected channels are already in FAVORITES': 'القنوات المحددة موجودة في المفضلة',
    'Unable to update favorites': 'تعذر تحديث المفضلة',
    'Remove %d items from Favorites?': 'حذف %d عنصر من المفضلة؟',
    '%d items removed from Favorites.': 'تم حذف %d عنصر من المفضلة.',
    '%d channels moved and saved.': 'تم نقل %d قناة وحفظ الترتيب.',
    'Remove from Favorites': 'حذف من المفضلة',
    'Remove from this folder': 'حذف من هذا المجلد',
    'Play channel': 'تشغيل القناة',
    'Channel information': 'معلومات القناة',
    'Move this package': 'نقل هذه الباقة',
    'Open package': 'فتح الباقة',
    'Remove this package': 'حذف هذه الباقة',
    'Unlock this channel': 'فتح قفل هذه القناة',
}.items():
    _TRANSLATIONS.setdefault("ar", {}).setdefault(_ms_key, _ms_val)
_TRANSLATIONS.setdefault("ar", {}).setdefault('Add, edit and switch servers  •  Web QR', 'إضافة وتعديل وتبديل السيرفرات  •  QR الويب')

# r153: Search filter screen.
for _sf_key, _sf_val in {
    'Filter': 'فلترة', 'SORT BY': 'الترتيب حسب', 'RATING': 'التقييم', 'YEAR': 'السنة',
    'GENRE': 'النوع', 'ADDED': 'المضاف حديثاً', 'ANY': 'الكل', 'ALL': 'الكل', 'OLDER': 'أقدم',
    '%d active': 'فلاتر مفعّلة: %d',
    'OK select     GREEN apply     RED reset     EXIT back': 'OK اختيار     الأخضر تطبيق     الأحمر مسح     EXIT رجوع',
    'No results match the filter': 'لا توجد نتائج مطابقة للفلترة',
}.items():
    _TRANSLATIONS.setdefault("ar", {}).setdefault(_sf_key, _sf_val)

# r153: Search by filter (discover).
for _ds_key, _ds_val in {
    'Search by filter': 'البحث بالفلترة', 'TYPE': 'النوع', 'POPULAR': 'الأكثر شعبية', 'NEWEST': 'الأحدث',
    'TOP RATED': 'الأعلى تقييماً', 'COUNTRY OR REGION': 'الدولة أو المنطقة', 'Searching...': 'جارٍ البحث...',
    'OK select     GREEN search     RED reset     EXIT back': 'OK اختيار     الأخضر بحث     الأحمر مسح     EXIT رجوع',
    'TMDb is not reachable. Try again.': 'تعذر الوصول إلى TMDb. حاول مرة أخرى.',
    'The server catalogue is not loaded yet. Try again.': 'قائمة السيرفر لم تُحمّل بعد. حاول مرة أخرى.',
    'No titles on this server match the filter': 'لا توجد عناوين على هذا السيرفر مطابقة للفلترة',
    'Action': 'أكشن', 'Adventure': 'مغامرة', 'Animation': 'أنمي ورسوم', 'Comedy': 'كوميدي', 'Crime': 'جريمة',
    'Documentary': 'وثائقي', 'Drama': 'دراما', 'Family': 'عائلي', 'Fantasy': 'فانتازيا', 'Horror': 'رعب',
    'Kids': 'أطفال', 'Mystery': 'غموض', 'Romance': 'رومانسي', 'Sci-Fi': 'خيال علمي', 'Thriller': 'إثارة',
    'History': 'تاريخي', 'War': 'حرب', 'Music': 'موسيقى', 'Reality': 'واقعي', 'Western': 'غربي',
    'United States': 'أمريكا', 'United Kingdom': 'بريطانيا', 'Egypt': 'مصر', 'Saudi Arabia': 'السعودية',
    'UAE': 'الإمارات', 'Kuwait': 'الكويت', 'Syria': 'سوريا', 'Lebanon': 'لبنان', 'Morocco': 'المغرب',
    'Turkey': 'تركيا', 'India': 'الهند', 'South Korea': 'كوريا', 'Japan': 'اليابان', 'China': 'الصين',
    'France': 'فرنسا', 'Spain': 'إسبانيا', 'Germany': 'ألمانيا', 'Italy': 'إيطاليا', 'Canada': 'كندا',
    'Mexico': 'المكسيك',
}.items():
    _TRANSLATIONS.setdefault("ar", {}).setdefault(_ds_key, _ds_val)

_TRANSLATIONS.setdefault("ar", {}).setdefault('Arabic', 'عربي')
_TRANSLATIONS.setdefault("ar", {}).setdefault('Asia', 'آسيا')

# r153: French / Turkish / German for Search-by-filter, selection and new hints.
_R153_LANGS = {
    "fr": {
        'More results left': 'Plus de résultats à gauche', 'More results right': 'Plus de résultats à droite',
        'Filter': 'Filtre', 'Search by filter': 'Recherche par filtre', 'TYPE': 'TYPE', 'SORT BY': 'TRIER PAR',
        'POPULAR': 'POPULAIRES', 'NEWEST': 'RÉCENTS', 'TOP RATED': 'MIEUX NOTÉS', 'ADDED': 'AJOUTÉS',
        'RATING': 'NOTE', 'ANY': 'TOUTES', 'YEAR': 'ANNÉE', 'ALL': 'TOUT', 'OLDER': 'PLUS ANCIENS',
        'GENRE': 'GENRE', 'COUNTRY OR REGION': 'PAYS OU RÉGION', 'Searching...': 'Recherche...',
        '%d active': '%d actifs',
        'OK select     GREEN search     RED reset     EXIT back': 'OK choisir     VERT rechercher     ROUGE effacer     EXIT retour',
        'TMDb is not reachable. Try again.': 'TMDb est inaccessible. Réessayez.',
        'The server catalogue is not loaded yet. Try again.': "Le catalogue du serveur n'est pas encore chargé. Réessayez.",
        'No titles on this server match the filter': 'Aucun titre de ce serveur ne correspond au filtre',
        'Action': 'Action', 'Adventure': 'Aventure', 'Animation': 'Animation', 'Comedy': 'Comédie',
        'Crime': 'Policier', 'Documentary': 'Documentaire', 'Drama': 'Drame', 'Family': 'Famille',
        'Fantasy': 'Fantastique', 'Horror': 'Horreur', 'Kids': 'Enfants', 'Mystery': 'Mystère',
        'Romance': 'Romance', 'Sci-Fi': 'Science-fiction', 'Thriller': 'Thriller', 'History': 'Histoire',
        'War': 'Guerre', 'Music': 'Musique', 'Reality': 'Téléréalité', 'Western': 'Western',
        'United States': 'États-Unis', 'United Kingdom': 'Royaume-Uni', 'Arabic': 'Arabe', 'Asia': 'Asie',
        'Canada': 'Canada', 'France': 'France', 'Germany': 'Allemagne',
        'Select channels to move': 'Sélectionner des chaînes', 'Move selected (%d)': 'Déplacer la sélection (%d)',
        'Delete selected (%d)': 'Supprimer la sélection (%d)', 'Add selected to Favorites (%d)': 'Ajouter la sélection aux favoris (%d)',
        'Cancel selection': 'Annuler la sélection', 'Add, edit and switch servers  •  Web QR': 'Ajouter, modifier et changer de serveur  •  QR Web',
    },
    "tr": {
        'More results left': 'Soldaki diğer sonuçlar', 'More results right': 'Sağdaki diğer sonuçlar',
        'Filter': 'Filtre', 'Search by filter': 'Filtreyle ara', 'TYPE': 'TÜR', 'SORT BY': 'SIRALA',
        'POPULAR': 'POPÜLER', 'NEWEST': 'EN YENİ', 'TOP RATED': 'EN İYİ PUAN', 'ADDED': 'EKLENEN',
        'RATING': 'PUAN', 'ANY': 'HEPSİ', 'YEAR': 'YIL', 'ALL': 'TÜMÜ', 'OLDER': 'DAHA ESKİ',
        'GENRE': 'KATEGORİ', 'COUNTRY OR REGION': 'ÜLKE VEYA BÖLGE', 'Searching...': 'Aranıyor...',
        '%d active': '%d etkin',
        'OK select     GREEN search     RED reset     EXIT back': 'OK seç     YEŞİL ara     KIRMIZI sıfırla     EXIT geri',
        'TMDb is not reachable. Try again.': "TMDb'ye ulaşılamıyor. Tekrar deneyin.",
        'The server catalogue is not loaded yet. Try again.': 'Sunucu kataloğu henüz yüklenmedi. Tekrar deneyin.',
        'No titles on this server match the filter': 'Bu sunucuda filtreye uyan başlık yok',
        'Action': 'Aksiyon', 'Adventure': 'Macera', 'Animation': 'Animasyon', 'Comedy': 'Komedi',
        'Crime': 'Suç', 'Documentary': 'Belgesel', 'Drama': 'Dram', 'Family': 'Aile',
        'Fantasy': 'Fantastik', 'Horror': 'Korku', 'Kids': 'Çocuk', 'Mystery': 'Gizem',
        'Romance': 'Romantik', 'Sci-Fi': 'Bilim Kurgu', 'Thriller': 'Gerilim', 'History': 'Tarih',
        'War': 'Savaş', 'Music': 'Müzik', 'Reality': 'Realite', 'Western': 'Western',
        'United States': 'ABD', 'United Kingdom': 'Birleşik Krallık', 'Arabic': 'Arapça', 'Asia': 'Asya',
        'Canada': 'Kanada', 'France': 'Fransa', 'Germany': 'Almanya',
        'Select channels to move': 'Kanal seç', 'Move selected (%d)': 'Seçilenleri taşı (%d)',
        'Delete selected (%d)': 'Seçilenleri sil (%d)', 'Add selected to Favorites (%d)': 'Seçilenleri favorilere ekle (%d)',
        'Cancel selection': 'Seçimi iptal et', 'Add, edit and switch servers  •  Web QR': 'Sunucu ekle, düzenle, değiştir  •  Web QR',
    },
    "de": {
        'More results left': 'Mehr Ergebnisse links', 'More results right': 'Mehr Ergebnisse rechts',
        'Filter': 'Filter', 'Search by filter': 'Suche per Filter', 'TYPE': 'TYP', 'SORT BY': 'SORTIEREN NACH',
        'POPULAR': 'BELIEBT', 'NEWEST': 'NEUESTE', 'TOP RATED': 'BESTE BEWERTUNG', 'ADDED': 'HINZUGEFÜGT',
        'RATING': 'BEWERTUNG', 'ANY': 'ALLE', 'YEAR': 'JAHR', 'ALL': 'ALLE', 'OLDER': 'ÄLTER',
        'GENRE': 'GENRE', 'COUNTRY OR REGION': 'LAND ODER REGION', 'Searching...': 'Suche läuft...',
        '%d active': '%d aktiv',
        'OK select     GREEN search     RED reset     EXIT back': 'OK wählen     GRÜN suchen     ROT zurücksetzen     EXIT zurück',
        'TMDb is not reachable. Try again.': 'TMDb ist nicht erreichbar. Bitte erneut versuchen.',
        'The server catalogue is not loaded yet. Try again.': 'Der Serverkatalog ist noch nicht geladen. Bitte erneut versuchen.',
        'No titles on this server match the filter': 'Keine Titel auf diesem Server passen zum Filter',
        'Action': 'Action', 'Adventure': 'Abenteuer', 'Animation': 'Animation', 'Comedy': 'Komödie',
        'Crime': 'Krimi', 'Documentary': 'Dokumentation', 'Drama': 'Drama', 'Family': 'Familie',
        'Fantasy': 'Fantasy', 'Horror': 'Horror', 'Kids': 'Kinder', 'Mystery': 'Mystery',
        'Romance': 'Liebesfilm', 'Sci-Fi': 'Science-Fiction', 'Thriller': 'Thriller', 'History': 'Historie',
        'War': 'Krieg', 'Music': 'Musik', 'Reality': 'Reality', 'Western': 'Western',
        'United States': 'USA', 'United Kingdom': 'Großbritannien', 'Arabic': 'Arabisch', 'Asia': 'Asien',
        'Canada': 'Kanada', 'France': 'Frankreich', 'Germany': 'Deutschland',
        'Select channels to move': 'Kanäle auswählen', 'Move selected (%d)': 'Auswahl verschieben (%d)',
        'Delete selected (%d)': 'Auswahl löschen (%d)', 'Add selected to Favorites (%d)': 'Auswahl zu Favoriten (%d)',
        'Cancel selection': 'Auswahl abbrechen', 'Add, edit and switch servers  •  Web QR': 'Server hinzufügen, bearbeiten, wechseln  •  Web-QR',
    },
    "ar": {
        'More results left': 'نتائج أكثر يسار', 'More results right': 'نتائج أكثر يمين',
    },
}
for _r153_lang, _r153_table in _R153_LANGS.items():
    for _r153_key, _r153_val in _r153_table.items():
        _TRANSLATIONS.setdefault(_r153_lang, {}).setdefault(_r153_key, _r153_val)
for _k_lang, _k_table in {
    "ar": {'Select': 'اختيار', 'Search': 'بحث', 'Reset': 'مسح', 'Back': 'رجوع'},
    "fr": {'Select': 'Choisir', 'Search': 'Rechercher', 'Reset': 'Effacer', 'Back': 'Retour'},
    "tr": {'Select': 'Seç', 'Search': 'Ara', 'Reset': 'Sıfırla', 'Back': 'Geri'},
    "de": {'Select': 'Auswählen', 'Search': 'Suchen', 'Reset': 'Zurücksetzen', 'Back': 'Zurück'},
}.items():
    for _k_key, _k_val in _k_table.items():
        _TRANSLATIONS.setdefault(_k_lang, {}).setdefault(_k_key, _k_val)
