# -*- coding: UTF-8 -*-
import os
import re
import requests
import time
from urllib.parse import quote_plus, unquote
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from ..utilities import languageTranslate, log, getFileSize
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

# Suppress insecure request warnings
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from ..user_agents import get_random_ua
# Constants
HEADERS = {
    'User-Agent': get_random_ua(),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'text/html; charset=UTF-8',
    'Host': 'archive.org',
    'Referer': 'https://archive.org',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
    'Accept-Encoding': 'gzip, deflate'
}

SESSION = requests.Session()
MAIN_URL = "https://archive.org"
DEBUG_PRETEXT = "archive.org"
CACHE_DIR = "/var/volatile/tmp"
CACHE_FILE = os.path.join(CACHE_DIR, "archive_org_mora25r.html")
CACHE_TIMEOUT = 86400  # 24 hours in seconds

def get_url(url, referer=None):
    headers = {'User-Agent': HEADERS['User-Agent']}
    if referer:
        headers['Referer'] = referer
    
    response = SESSION.get(url, headers=headers, verify=False)
    return response.text.replace('\n', '')

def get_rating(downloads):
    return min(10, max(1, downloads // 50 + 1))

ROMAN_NUMERAL_MAP = [
    (r'\bII\b', '2'), (r'\bIII\b', '3'), (r'\bIV\b', '4'), (r'\bV\b', '5'),
    (r'\bVI\b', '6'), (r'\bVII\b', '7'), (r'\bVIII\b', '8'), (r'\bIX\b', '9'),
    (r'\bX\b', '10'), (r'\bXI\b', '11'), (r'\bXII\b', '12'), (r'\bXIII\b', '13'),
    (r'\bXIV\b', '14'), (r'\bXV\b', '15'), (r'\bXVI\b', '16'), (r'\bXVII\b', '17'),
    (r'\bXVIII\b', '18'), (r'\bXIX\b', '19'), (r'\bXX\b', '20'), (r'\bI\b', '1')
]

def generate_title_variations(text):
    """
    Generate variations of a title with both Roman numerals and digits
    """
    variations = [text]
    
    # Convert Roman numerals to digits
    digit_version = text
    for roman, digit in ROMAN_NUMERAL_MAP:
        digit_version = re.sub(roman, digit, digit_version, flags=re.IGNORECASE)
    if digit_version != text:
        variations.append(digit_version)
    
    # Convert digits to Roman numerals (reverse mapping)
    for roman, digit in ROMAN_NUMERAL_MAP:
        roman_version = re.sub(r'\b' + digit + r'\b', roman, text, flags=re.IGNORECASE)
        if roman_version != text and roman_version not in variations:
            variations.append(roman_version)
    
    return variations

def get_cached_content():
    """
    Get content from cache if available and not expired
    """
    if os.path.exists(CACHE_FILE):
        # Check if cache is still valid
        if time.time() - os.path.getmtime(CACHE_FILE) < CACHE_TIMEOUT:
            try:
                with open(CACHE_FILE, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                log(__name__, f"{DEBUG_PRETEXT} Error reading cache: {e}")
    
    return None

def save_content_to_cache(content):
    """
    Save content to cache file
    """
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(CACHE_FILE, 'w', encoding='utf-8') as f:
            f.write(content)
        log(__name__, f"{DEBUG_PRETEXT} Content cached to {CACHE_FILE}")
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error saving cache: {e}")

def search_subtitles(file_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""

    # Check if title is blank or empty
    if not title or title.strip() == "":
        log(__name__, f"{DEBUG_PRETEXT} Title is blank, skipping search")
        return subtitles_list, "", msg

    title = re.sub(r' ▎', '▎', title)

    # Define bad strings to remove
    bad_strings = [
                "ae|", "al|", "ar|", "at|", "ba|", "be|", "bg|", "br|", "cg|", "ch|", "cz|", "da|", "de|", "dk|",
                "ee|", "en|", "es|", "eu|", "ex-yu|", "fi|", "fr|", "gr|", "hr|", "hu|", "in|", "ir|", "it|", "lt|",
                "mk|", "mx|", "nl|", "no|", "pl|", "pt|", "ro|", "rs|", "ru|", "se|", "si|", "sk|", "sp|", "tr|",
                "uk|", "us|", "yu|","ae▎", "al▎", "ar▎", "at▎", "ba▎", "be▎", "bg▎", "br▎", "cg▎", "ch▎", "cz▎", "da▎", "de▎", "dk▎",
                "ee▎", "en▎", "es▎", "eu▎", "ex-yu▎", "fi▎", "fr▎", "gr▎", "hr▎", "hu▎", "in▎", "ir▎", "it▎", "lt▎",
                "mk▎", "mx▎", "nl▎", "no▎", "pl▎", "pt▎", "ro▎", "rs▎", "ru▎", "se▎", "si▎", "sk▎", "sp▎", "tr▎",
                "uk▎", "us▎", "yu▎"
                "1080p", "4k", "720p", "hdrip", "hindi", "imdb", "vod", "x264"
            ]
    
    # Remove bad strings from title
    for bad in bad_strings:
        title = title.replace(bad, "")
    
    title = re.sub(r'[:,"&!?\-]', '', title).replace("  ", " ").strip()
    title = re.sub(r"'", '', title)
    title_variations = generate_title_variations(title)
    print(f"Title variations: {title_variations}")  # Debug print


    
    if tvshow:
        search_string = f"{tvshow} S{int(season):02d}E{int(episode):02d}" if title != tvshow else f"{tvshow} ({int(season):02d}{int(episode):02d})"
    else:
        search_string = f"{title} ({year})" if year else title
    
    log(__name__, f"{DEBUG_PRETEXT} Search string = {search_string}")
    # Archive.org mora25r is an Arabic subtitle archive. Respect the user's selected languages instead of advertising Arabic results under another language.
    selected_languages = [lang for lang in (lang1, lang2, lang3) if lang]
    selected_iso = []
    for lang in selected_languages:
        try:
            iso = languageTranslate(lang, 0, 2)
        except Exception:
            iso = None
        if iso and iso not in selected_iso:
            selected_iso.append(iso)
    if selected_iso and "ar" not in selected_iso:
        log(__name__, f"{DEBUG_PRETEXT} Arabic archive skipped for selected languages: {selected_languages}")
        return subtitles_list, "", msg

    # Keep the provider search/download unchanged; only validate year/release metadata
    # before marking a result as synchronized.
    for title_var in title_variations:
        get_subtitles_list(title_var, search_string, "ar", "Arabic", subtitles_list, year, season, episode, bool(tvshow), file_path)
    return subtitles_list, "", msg

def _normalized_release_text(value):
    value = unquote(value or "")
    value = re.sub(r"\.[a-z0-9]{2,4}$", "", value, flags=re.IGNORECASE)
    value = re.sub(r"[^a-z0-9]+", " ", value.lower())
    return " ".join(value.split())

def _archive_release_markers(value):
    compact = _normalized_release_text(value).replace(" ", "")
    markers = set()
    groups = (
        (("2160p",), "2160p"), (("1080p",), "1080p"), (("720p",), "720p"),
        (("webdl", "web-dl"), "webdl"), (("webrip",), "webrip"),
        (("bluray", "bdrip", "brrip"), "bluray"), (("hdtv",), "hdtv"),
        (("x265", "h265", "hevc"), "hevc"), (("x264", "h264", "avc"), "h264"),
        (("netflix", "nf"), "nf"), (("amazon", "amzn"), "amzn"),
    )
    for needles, marker in groups:
        if any(n.replace("-", "") in compact for n in needles):
            markers.add(marker)
    return markers

def _archive_result_sync(filename, title, file_path, year, season, episode, is_tvshow):
    """Match Archive results using the same direct release-name idea as Subf2m.

    Keep hard guards for an explicitly conflicting movie year and for TV episode
    identity, but do not require extra quality/source/codec markers just to set sync.
    """
    subtitle_release = _normalized_release_text(filename)
    video_release = _normalized_release_text(os.path.basename(file_path or ""))
    normalized_title = _normalized_release_text(title)

    # Same core idea as Subf2m: a direct release-name containment is enough.
    direct_release_match = bool(video_release and subtitle_release and (
        video_release in subtitle_release or subtitle_release in video_release
    ))

    # Archive filenames are not always byte-for-byte release names.  When they
    # contain the full title, allow that as the equivalent close-name match.
    title_tokens = [t for t in normalized_title.split() if len(t) > 1]
    title_match = bool(title_tokens) and all(t in subtitle_release.split() for t in title_tokens)
    if not (direct_release_match or title_match):
        return False

    if is_tvshow:
        try:
            marker = "s%02de%02d" % (int(season), int(episode))
            compact_sub = subtitle_release.replace(" ", "")
            compact_video = video_release.replace(" ", "")
            # If either side carries an episode marker, it must be the requested one.
            found_markers = re.findall(r"s\d{1,2}e\d{1,2}", compact_sub + " " + compact_video)
            if found_markers and marker not in found_markers:
                return False
        except Exception:
            return False

    requested_year = str(year).strip() if year else ""
    years_in_filename = re.findall(r"(?:19|20)\d{2}", filename or "")
    if requested_year and years_in_filename and requested_year not in years_in_filename:
        return False

    # Do not reject a sync only because WEB-DL/BluRay/resolution/codec markers
    # are missing.  This mirrors Subf2m's permissive release-name sync behavior.
    return True

def get_subtitles_list(title, search_string, lang_short, lang_long, subtitles_list, year=None, season=None, episode=None, is_tvshow=False, file_path=""):
    url = f"{MAIN_URL}/download/mora25r"
    
    # Try to get content from cache first
    content = get_cached_content()
    
    if content is None:
        # Content not in cache or cache expired, download it
        log(__name__, f"{DEBUG_PRETEXT} Fetching: {url}")
        try:
            response = SESSION.get(url, headers=HEADERS, verify=False)
            response.raise_for_status()
            content = response.text
            save_content_to_cache(content)
        except requests.RequestException as e:
            log(__name__, f"{DEBUG_PRETEXT} Failed to fetch subtitles: {e}")
            return
    else:
        log(__name__, f"{DEBUG_PRETEXT} Using cached content from {CACHE_FILE}")
    
    try:
        encoded_title = quote_plus(title).replace('+', '.')
        subtitles = re.findall(rf'(<td><a href.+?>{encoded_title}.+?</a></td>)', content, re.IGNORECASE)
        
        for subtitle in subtitles:
            match = re.search(r'<td><a href="(.+?)">(.+?)</a></td>', subtitle)
            if match:
                id_, filename = match.groups()
                filename = filename.replace('.srt', '').strip()
                if filename not in ['Εργαστήρι Υποτίτλων', 'subs4series']:
                    years_in_filename = re.findall(r'(?:19|20)\d{2}', filename)
                    requested_year = str(year).strip() if year else ''
                    if requested_year and years_in_filename and requested_year not in years_in_filename:
                        log(__name__, f"{DEBUG_PRETEXT} Skipping year mismatch: {filename} (wanted {requested_year})")
                        continue
                    synced = _archive_result_sync(filename, title, file_path, year, season, episode, is_tvshow)
                    log(__name__, f"{DEBUG_PRETEXT} Found subtitle: {filename} (id = {id_}, sync={synced})")
                    subtitles_list.append({
                        'no_files': 1,
                        'filename': filename,
                        'sync': synced,
                        'id': id_,
                        'language_flag': f'flags/{lang_short}.gif',
                        'language_name': lang_long
                    })
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error parsing subtitles: {e}")

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_info = subtitles_list[pos]
    language = subtitle_info["language_name"]
    subtitle_id = subtitle_info["id"]    
    print(("subtitle_id", subtitle_id))
    download_link = f"{MAIN_URL}/download/mora25r/{subtitle_id}"
    print(download_link)
    log(__name__, f"{DEBUG_PRETEXT} Downloading from: {download_link}")

    try:
        response = SESSION.get(download_link, headers=HEADERS, verify=False, allow_redirects=True)
        response.raise_for_status()
    except requests.RequestException as e:
        log(__name__, f"{DEBUG_PRETEXT} Download failed: {e}")
        return False, language, None

    os.makedirs(tmp_sub_dir, exist_ok=True)
    local_tmp_file = os.path.join(tmp_sub_dir, subtitle_id)
    try:
        with open(local_tmp_file, "wb") as file:
            file.write(response.content)
        log(__name__, f"{DEBUG_PRETEXT} Subtitles saved to: {local_tmp_file}")
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error saving subtitle: {e}")
        return False, language, None

    packed = False
    subs_file = local_tmp_file
    try:
        with open(local_tmp_file, "rb") as file:
            file_header = file.read(2).decode(errors="ignore")
            if file_header.startswith("R"):
                packed = True
                subs_file = "rar"
            elif file_header.startswith("PK"):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file
    except Exception as e:
        log(__name__, f"{DEBUG_PRETEXT} Error checking file type: {e}")
    
    log(__name__, f"{DEBUG_PRETEXT} Returning: packed={packed}, language={language}, subs_file={subs_file}")
    return packed, language, subs_file