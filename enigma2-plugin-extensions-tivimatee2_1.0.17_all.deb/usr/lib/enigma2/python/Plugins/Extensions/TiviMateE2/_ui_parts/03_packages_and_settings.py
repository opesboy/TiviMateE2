def _content_package_control_key(source, kind):
    return "%s|%s" % (_source_identity(source or {}), str(kind or "vod"))

def _load_content_package_controls(source, kind):
    data = load_json(CONTENT_PACKAGE_CONTROLS_FILE, {}) or {}
    row = data.get(_content_package_control_key(source, kind)) or {}
    return {
        "pin": str(row.get("pin") or "0000"),
        "locked": set(str(x) for x in (row.get("locked") or [])),
        "order": [str(x) for x in (row.get("order") or []) if str(x)],
    }

def _save_content_package_controls(source, kind, state):
    data = load_json(CONTENT_PACKAGE_CONTROLS_FILE, {}) or {}
    data[_content_package_control_key(source, kind)] = {
        "pin": str((state or {}).get("pin") or "0000"),
        "locked": sorted(set(str(x) for x in ((state or {}).get("locked") or []))),
        "order": [str(x) for x in ((state or {}).get("order") or []) if str(x)],
    }
    return save_json(CONTENT_PACKAGE_CONTROLS_FILE, data)



PACKAGE_ORDER_SKIN = r"""<screen name="PackageOrderScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#02060B">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_cinematic_bg_r209.jpg" alphatest="blend" zPosition="0"/>
<eLabel position="0,0" size="1920,128" backgroundColor="#050A10" zPosition="1"/>
<eLabel position="48,126" size="1824,2" backgroundColor="#153653" zPosition="2"/>
<ePixmap position="64,26" size="306,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="4"/>
<widget name="title" position="430,25" size="1000,52" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" zPosition="4"/>
<eLabel position="432,78" size="900,30" text="Choose package order" font="Regular;22" foregroundColor="#8EA7BA" transparent="1" zPosition="4"/>
<widget name="card0" position="260,250" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name0" position="330,300" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="card1" position="1010,250" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name1" position="1080,300" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="card2" position="260,510" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name2" position="330,560" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="card3" position="1010,510" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name3" position="1080,560" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="focus" position="254,244" size="662,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_focus_r208.png" alphatest="blend" zPosition="7"/>
<widget name="hint" position="250,800" size="1420,45" font="Regular;24" foregroundColor="#B9D7EA" transparent="1" halign="center" zPosition="4"/>
<eLabel position="58,930" size="1804,2" backgroundColor="#17324B" zPosition="2"/>
<eLabel position="650,970" size="18,18" backgroundColor="#15964C" zPosition="4"/><eLabel position="680,958" size="250,42" text="OK  Apply" font="Regular;22" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<eLabel position="1010,970" size="18,18" backgroundColor="#B83232" zPosition="4"/><eLabel position="1040,958" size="300,42" text="EXIT  Back" font="Regular;22" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
</screen>"""

class PackageOrderScreen(Screen):
    MODES = (("original","Original"),("latest","Latest"),("az","A to Z"),("za","Z to A"))
    POS = ((254,244),(1004,244),(254,504),(1004,504))
    def __init__(self, session, current="original", kind="vod"):
        self.skin=PACKAGE_ORDER_SKIN
        Screen.__init__(self,session)
        self.current=current if current in dict(self.MODES) else "original"
        self.index=next((i for i,x in enumerate(self.MODES) if x[0]==self.current),0)
        self["title"]=Label("PACKAGE ORDER  •  %s" % ("TV SHOWS" if kind=="series" else "MOVIES"))
        self["hint"]=Label("Select how the packages themselves are ordered")
        self["focus"]=Pixmap()
        for i,(mode,label) in enumerate(self.MODES):
            self["card%d"%i]=Pixmap(); self["name%d"%i]=Label(("●  " if mode==self.current else "○  ")+label)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.apply,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down},-1)
        self.onLayoutFinish.append(self.render)
    def render(self):
        for i,(mode,label) in enumerate(self.MODES): self["name%d"%i].setText(("●  " if mode==self.current else "○  ")+label)
        try:
            x,y=self.POS[self.index]; self["focus"].instance.move(ePoint(sx(x),sy(y)))
        except Exception: pass
    def left(self): self.index=max(0,self.index-1); self.render()
    def right(self): self.index=min(3,self.index+1); self.render()
    def up(self): self.index=max(0,self.index-2); self.render()
    def down(self): self.index=min(3,self.index+2); self.render()
    def apply(self):
        self.current=self.MODES[self.index][0]; self.close(self.current)

# ---------------------------------------------------------------------------
# Movie Genres - standalone page (not part of Movies Packages)
# ---------------------------------------------------------------------------

MOVIE_GENRES_SKIN = r"""<screen name="MovieGenresScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050608">
<ePixmap position="0,-8" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_background.jpg" alphatest="blend" scale="1" zPosition="0"/>
<widget name="title" position="65,25" size="1200,50" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
<widget name="page" position="1525,30" size="330,40" font="Regular;22" foregroundColor="#CFCFCF" transparent="1" halign="right" zPosition="5"/>
<widget name="card0" position="247,186" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label0" position="247,328" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell0" position="247,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card1" position="612,186" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label1" position="612,328" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell1" position="612,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card2" position="977,186" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label2" position="977,328" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell2" position="977,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card3" position="1342,186" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label3" position="1342,328" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell3" position="1342,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card4" position="247,456" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label4" position="247,598" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell4" position="247,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card5" position="612,456" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label5" position="612,598" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell5" position="612,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card6" position="977,456" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label6" position="977,598" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell6" position="977,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card7" position="1342,456" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label7" position="1342,598" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell7" position="1342,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card8" position="247,726" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label8" position="247,868" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell8" position="247,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card9" position="612,726" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label9" position="612,868" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell9" position="612,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card10" position="977,726" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label10" position="977,868" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell10" position="977,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="card11" position="1342,726" size="330,166" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label11" position="1342,868" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell11" position="1342,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="selector" position="247,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_focus_silver.png" alphatest="blend" zPosition="8" scale="1"/>
<eLabel position="540,1010" size="18,18" backgroundColor="#C62828" zPosition="12"/><widget name="redHint" position="568,998" size="160,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
<eLabel position="750,1010" size="18,18" backgroundColor="#15964C" zPosition="12"/><widget name="greenHint" position="778,998" size="180,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
<eLabel position="980,1010" size="18,18" backgroundColor="#D8B323" zPosition="12"/><widget name="yellowHint" position="1008,998" size="100,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
<eLabel position="1130,1010" size="18,18" backgroundColor="#2878D8" zPosition="12"/><widget name="blueHint" position="1158,998" size="170,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
</screen>"""

class MovieGenresScreen(Screen):
    PAGE_SIZE = 12
    EXCLUDE_WORDS = (
        "sport","sports","football","soccer","wwe","wrestling","ufc","mma","boxing","basketball","tennis",
        "formula 1","formula1","f1","racing","race","music","musical","songs","song","radio","concert",
        "theatre","theater","stage play","plays","مسرح","مسرحيات","اغاني","أغاني","موسيقى","رياضة","رياضي",
        "كرة قدم","مصارعة","ملاكمة"
    )
    def __init__(self, session, source, initial_kind="vod", initial_index=None, auto_choose=False):
        self.skin=MOVIE_GENRES_SKIN
        Screen.__init__(self,session)
        self.source=dict(source or {})
        self.kind="series" if str(initial_kind)=="series" else "vod"
        # Restore the last Genre server for this media kind before the first render.
        # This prevents opening on one server and jumping to the saved server later.
        try:
            _genre_server_file="/etc/enigma2/tivimatee2_genre_server.json"
            _genre_server_data=load_json(_genre_server_file,{}) or {}
            _saved_server_key=str(_genre_server_data.get(self.kind) or "")
            if _saved_server_key:
                for _candidate in list(get_sources() or []):
                    if isinstance(_candidate,dict) and _source_identity(_candidate)==_saved_server_key:
                        _stype=str(_candidate.get("type") or "").lower()
                        if _stype in ("xtream","stalker","m3u") and not (_stype=="m3u" and not _m3u_source_has_kind(_candidate,self.kind)):
                            self.source=dict(_candidate); break
        except Exception:
            pass
        self.rows=[]; self.index=0; self.pageStart=0; self._token=0
        # Persistent package -> backdrop mapping.  This is separate from the
        # downloaded image cache: reopening GENRE can resolve the package art
        # immediately without scanning package contents again.
        self._packageBackdropFile="/etc/enigma2/tivimatee2_genre_package_backdrops.json"
        self._packageBackdropCache={}
        try:
            _all_backdrops=load_json(self._packageBackdropFile,{}) or {}
            _backdrop_scope=_content_package_control_key(self.source,self.kind)
            _scope_cache=_all_backdrops.get(_backdrop_scope,{})
            if isinstance(_scope_cache,dict): self._packageBackdropCache=_scope_cache
        except Exception:
            self._packageBackdropCache={}
        # Persist Genre package ordering per server and media kind.
        # Movies and TV Shows intentionally keep independent selections.
        self.sortMode="original"
        self._latestOrderCache={}
        try:
            _genre_order_file="/etc/enigma2/tivimatee2_genre_package_order.json"
            _genre_order_data=load_json(_genre_order_file,{}) or {}
            _genre_order_key=_content_package_control_key(self.source,self.kind)
            _saved_mode=str(_genre_order_data.get(_genre_order_key) or "latest")
            if _saved_mode in ("original","latest","az","za"):
                self.sortMode=_saved_mode
            # Keep the last resolved Latest timestamps so reopening Genre never
            # flashes provider/Original order while background refresh runs.
            _latest_file="/etc/enigma2/tivimatee2_genre_latest_order.json"
            _latest_data=load_json(_latest_file,{}) or {}
            _cached=_latest_data.get(_genre_order_key,{})
            if isinstance(_cached,dict): self._latestOrderCache=_cached
        except Exception:
            pass
        self["title"]=Label("TV SHOWS PACKAGES" if self.kind=="series" else "MOVIES PACKAGES")
        self["page"]=Label("")
        self["redHint"]=Label("Delete Package")
        self["greenHint"]=Label("Package Filter")
        self["yellowHint"]=Label("ORDER")
        self["blueHint"]=Label("Switch Server")
        self["selector"]=Pixmap()
        for i in range(self.PAGE_SIZE):
            self["card%d"%i]=Pixmap(); self["label%d"%i]=Label(""); self["shell%d"%i]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "ok":self.choose,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,
            "pageUp":self.pageUp,"pageDown":self.pageDown,
            "red":self.deleteSelectedPackage,"green":self.openPackageFilter,"yellow":self.openPackageOrder,"yellowlong":self.addSelectedPackageFavourite,"blue":self.serverSwitch},-1)
        self.onLayoutFinish.append(self.start)
    def _applyPackageOrder(self):
        if self.sortMode=="latest":
            # _latest_key is the newest real title timestamp in the package.
            # Unknown packages stay behind dated packages in original provider order.
            self.rows.sort(key=lambda r:(int(r.get("_latest_key") or 0), -int(r.get("_provider_order") or 0)), reverse=True)
        elif self.sortMode=="az":
            self.rows.sort(key=lambda r:str(r.get("name") or "").casefold())
        elif self.sortMode=="za":
            self.rows.sort(key=lambda r:str(r.get("name") or "").casefold(), reverse=True)
        else:
            self.rows.sort(key=lambda r:r.get("_provider_order",0))

    def _mediaLatestStamp(self, item):
        if not isinstance(item,dict): return 0
        import datetime
        def _stamp(value):
            if value in (None,""): return 0
            try:
                n=int(float(value))
                if n>100000000000: n//=1000
                if n>100000000: return n
            except Exception: pass
            txt=str(value).strip().replace("Z","").replace("T"," ")
            for fmt,size in (("%Y-%m-%d %H:%M:%S",19),("%Y-%m-%d",10),("%Y/%m/%d %H:%M:%S",19),("%Y/%m/%d",10)):
                try: return int(time.mktime(datetime.datetime.strptime(txt[:size],fmt).timetuple()))
                except Exception: pass
            return 0
        for key in ("added","added_timestamp","added_at","date_added","created_at","timestamp"):
            ts=_stamp(item.get(key))
            if ts: return ts
        for key in ("release_date","releaseDate","releasedate","release_date_utc","first_air_date"):
            ts=_stamp(item.get(key))
            if ts: return ts
        try:
            year=int(str(item.get("year") or "")[:4])
            if 1800<=year<=2200: return int(time.mktime(datetime.datetime(year,1,1).timetuple()))
        except Exception: pass
        return 0

    def _refreshLatestPackageOrder(self, token):
        # Resolve the newest actual title in every package. Cache first; only a
        # package with no cached catalogue contacts the server. Never infer age
        # from category_id because providers do not guarantee chronological IDs.
        if self.sortMode!="latest": return
        source=dict(self.source); rows=list(self.rows)
        def worker():
            try: client=get_source_client(source)
            except Exception: client=None
            changed=False
            for row in rows:
                if token!=self._token or self.sortMode!="latest": return
                try:
                    items,_=get_category_streams(source,row.get("kind"),client,row.get("id"),use_cache=True,wait_for_server=False)
                    if not items:
                        items,_=get_category_streams(source,row.get("kind"),client,row.get("id"),use_cache=True,wait_for_server=True)
                    latest=max([self._mediaLatestStamp(x) for x in list(items or [])] or [0])
                except Exception: latest=0
                row["_latest_key"]=latest
                changed=True
            if not changed or token!=self._token or self.sortMode!="latest": return
            # Persist the resolved timestamps before repainting. Next entry can
            # apply Latest immediately, then refresh silently in background.
            try:
                _latest_file="/etc/enigma2/tivimatee2_genre_latest_order.json"
                _latest_data=load_json(_latest_file,{}) or {}
                _key=_content_package_control_key(source,self.kind)
                _latest_data[_key]={str(x.get("id")):int(x.get("_latest_key") or 0) for x in rows}
                save_json(_latest_file,_latest_data)
                self._latestOrderCache=dict(_latest_data[_key])
            except Exception:
                pass
            def done():
                if token!=self._token or self.sortMode!="latest": return
                byid={str(x.get("id")):x for x in rows}
                for current in self.rows:
                    resolved=byid.get(str(current.get("id")))
                    if resolved is not None: current["_latest_key"]=resolved.get("_latest_key",0)
                self._applyPackageOrder(); self.index=0; self.pageStart=0; self.render()
            try: reactor.callFromThread(done)
            except Exception: done()
        t=threading.Thread(target=worker,name="TiviMateGenreLatestPackages"); t.daemon=True; t.start()

    def addSelectedPackageFavourite(self):
        # Long YELLOW saves the selected Movies/TV Shows package as one
        # Favorites folder. It does not expand the package into title rows.
        if not self.rows or self.index < 0 or self.index >= len(self.rows):
            return
        row = self.rows[self.index] if isinstance(self.rows[self.index], dict) else {}
        cid = str(row.get("id") or "").strip()
        title = str(row.get("name") or "").strip()
        if not cid or not title:
            return
        marker_file = "/etc/enigma2/tivimatee2_media_package_favorites.json"
        marker_key = "%s|%s|%s" % (favourite_source_id(self.source), self.kind, cid)
        try:
            try:
                with open(marker_file, "r") as h:
                    markers = json.load(h) or {}
            except Exception:
                markers = {}
            if marker_key in markers:
                self.session.open(MessageBox, "Package is already in Favorites", MessageBox.TYPE_INFO, timeout=3)
                return
            back = row.get("backdrop") or ""
            markers[marker_key] = {
                "source_id": favourite_source_id(self.source),
                "kind": self.kind,
                "category_id": cid,
                "title": title,
                "backdrop": str(back or "")
            }
            folder = os.path.dirname(marker_file)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = marker_file + ".tmp"
            with open(tmp, "w") as h:
                json.dump(markers, h, sort_keys=True)
            os.rename(tmp, marker_file)
            self.session.open(MessageBox, "Added package folder to Favorites", MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, "Favorite package error: %s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def deleteSelectedPackage(self):
        if not self.rows or self.index < 0 or self.index >= len(self.rows): return
        row=self.rows[self.index] if isinstance(self.rows[self.index],dict) else {}
        cid=str(row.get("id") or "").strip(); name=str(row.get("name") or "").strip()
        if not cid:return
        self._pendingDeletePackage=(cid,name)
        self.session.openWithCallback(self._confirmDeletePackage,MessageBox,"Delete this package?\n"+name,MessageBox.TYPE_YESNO)

    def _confirmDeletePackage(self,answer=False):
        pending=getattr(self,"_pendingDeletePackage",None); self._pendingDeletePackage=None
        if not answer or not pending:return
        cid,name=pending
        try:
            data=_load_all_filters(); key=_source_filter_key(self.source); entry=data.setdefault(key,{})
            allowed=entry.get(self.kind)
            if allowed is None:
                allowed=[str(row.get("id") or "") for row in self.rows if str(row.get("id") or "")]
            allowed=[str(x) for x in (allowed or []) if str(x)!=cid]
            entry[self.kind]=allowed; data[key]=entry
            if not _save_all_filters(data):
                self.session.open(MessageBox,"Unable to delete package.",MessageBox.TYPE_ERROR,timeout=3); return
            self.rows=[row for row in self.rows if str(row.get("id") or "")!=cid]
            if self.index>=len(self.rows):self.index=max(0,len(self.rows)-1)
            try:clear_catalog_memory()
            except Exception:pass
            self.render()
        except Exception as exc:
            self.session.open(MessageBox,"Delete package error: %s" % exc,MessageBox.TYPE_ERROR,timeout=4)

    def openPackageOrder(self):
        self.session.openWithCallback(self._packageOrderSelected,PackageOrderScreen,self.sortMode,self.kind)

    def _packageOrderSelected(self,mode=None):
        mode=str(mode or "")
        if mode not in ("original","latest","az","za"):return
        self.sortMode=mode
        try:
            _genre_order_file="/etc/enigma2/tivimatee2_genre_package_order.json"
            _genre_order_data=load_json(_genre_order_file,{}) or {}
            _genre_order_data[_content_package_control_key(self.source,self.kind)]=mode
            save_json(_genre_order_file,_genre_order_data)
        except Exception:
            pass
        self._applyPackageOrder(); self.index=0; self.pageStart=0; self.render()
        if self.sortMode=="latest": self._refreshLatestPackageOrder(self._token)

    def openPackageFilter(self):
        stype=str((self.source or {}).get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self.session.open(MessageBox,"Package filtering is available for Xtream Codes and Stalker Portal.",MessageBox.TYPE_INFO,timeout=4); return
        self.session.openWithCallback(self._packageFilterClosed,ServerCategoryFilter,dict(self.source),self.kind,True)

    def _packageFilterClosed(self,changed=None):
        try:clear_catalog_memory()
        except Exception:pass
        self.rows=[]; self.index=0; self.pageStart=0; self.start()

    def _serverChoices(self):
        rows=[]; current_key=_source_identity(self.source)
        for source in list(get_sources() or []):
            if not isinstance(source,dict):continue
            stype=str(source.get("type") or "").lower()
            if stype not in ("xtream","stalker","m3u"):continue
            if stype=="m3u" and not _m3u_source_has_kind(source,self.kind):continue
            name=str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            kind="Xtream" if stype=="xtream" else "Stalker" if stype=="stalker" else "M3U"
            prefix="✓ " if _source_identity(source)==current_key else ""
            rows.append(("%s%s  [%s]"%(prefix,name,kind),dict(source)))
        return rows

    def serverSwitch(self):
        choices=self._serverChoices()
        if not choices:
            self.session.open(MessageBox,"No compatible IPTV servers found.",MessageBox.TYPE_INFO,timeout=3); return
        self.session.openWithCallback(self._serverSwitchSelected,ChoiceBox,title="SERVER SWITCH",list=choices)

    def _serverSwitchSelected(self,choice=None):
        if not choice:return
        try:source=choice[1]
        except Exception:return
        if not isinstance(source,dict):return
        self.source=dict(source); self.rows=[]; self.index=0; self.pageStart=0
        try:
            # Persist the Genre server independently for Movies and TV Shows.
            _genre_server_file="/etc/enigma2/tivimatee2_genre_server.json"
            _genre_server_data=load_json(_genre_server_file,{}) or {}
            _genre_server_data[self.kind]=_source_identity(self.source)
            save_json(_genre_server_file,_genre_server_data)
            save_json(MAIN_SOURCE_FILE,{"key":_source_identity(self.source)})
        except Exception:pass
        # Load ORDER + cached Latest for the newly selected server before rendering it.
        self.sortMode="latest"; self._latestOrderCache={}
        try:
            _key=_content_package_control_key(self.source,self.kind)
            _orders=load_json("/etc/enigma2/tivimatee2_genre_package_order.json",{}) or {}
            _mode=str(_orders.get(_key) or "latest")
            if _mode in ("original","latest","az","za"): self.sortMode=_mode
            _latest=load_json("/etc/enigma2/tivimatee2_genre_latest_order.json",{}) or {}
            _cached=_latest.get(_key,{})
            if isinstance(_cached,dict): self._latestOrderCache=_cached
        except Exception:pass
        self.start()

    def _excluded(self,name):
        t=str(name or "").casefold()
        return any(w.casefold() in t for w in self.EXCLUDE_WORDS)
    def start(self):
        self._token+=1; token=self._token; source=dict(self.source)
        def make_rows(cats):
            rows=[]; seen=set(); kind=self.kind
            try: cats=filter_categories(source,kind,cats or [])
            except Exception: cats=cats or []
            for entry in cats or []:
                if isinstance(entry,dict):
                    name=str(entry.get("category_name") or entry.get("name") or entry.get("title") or "").strip()
                    cid=str(entry.get("category_id") or entry.get("id") or "").strip()
                elif isinstance(entry,(list,tuple)) and len(entry)>=2:
                    name=str(entry[0] or "").strip(); cid=str(entry[1] or "").strip()
                else: continue
                if not name or not cid or self._excluded(name): continue
                key=(kind,cid)
                if key in seen: continue
                cached_latest=0
                try: cached_latest=int(self._latestOrderCache.get(str(cid),0) or 0)
                except Exception: cached_latest=0
                cached_backdrop=str(self._packageBackdropCache.get(str(cid)) or "").strip()
                seen.add(key); rows.append({"name":name,"id":cid,"kind":kind,"backdrop":cached_backdrop,"_provider_order":len(rows),"_latest_key":cached_latest})
            return rows
        def paint(rows, reset=True):
            if token!=self._token:return
            self.rows=rows
            self._applyPackageOrder()
            if reset:self.index=0; self.pageStart=0
            elif self.rows:self.index=min(self.index,len(self.rows)-1)
            # Latest must be the first package order the user sees.  When no
            # persisted Latest timestamps exist yet, do not flash provider/
            # Original order first; resolve Latest in the worker and let its
            # completion perform the first render.
            _latest_ready = any(int(x.get("_latest_key") or 0) > 0 for x in self.rows)
            if self.sortMode=="latest" and not _latest_ready:
                self._refreshLatestPackageOrder(token)
                return
            self.render()
            if self.sortMode=="latest": self._refreshLatestPackageOrder(token)
            self._loadPackageBackdrops(token)
        def worker():
            client=None; cached=[]
            try:
                client=get_source_client(source)
                cached,_=get_cached_categories(source,self.kind,client=client,wait_for_server=False)
            except Exception: cached=[]
            rows=make_rows(cached)
            if rows:
                try: reactor.callFromThread(paint,rows,True)
                except Exception: paint(rows,True)
            # Refresh categories after the cached list is already on screen.
            try:
                fresh,_=get_cached_categories(source,self.kind,client=client,wait_for_server=True)
                fresh_rows=make_rows(fresh)
            except Exception: fresh_rows=[]
            if fresh_rows and [(x["id"],x["name"]) for x in fresh_rows] != [(x["id"],x["name"]) for x in rows]:
                try: reactor.callFromThread(paint,fresh_rows,not bool(rows))
                except Exception: paint(fresh_rows,not bool(rows))
            elif not rows and fresh_rows:
                try: reactor.callFromThread(paint,fresh_rows,True)
                except Exception: paint(fresh_rows,True)
        t=threading.Thread(target=worker,name="TiviMateGenrePackages"); t.daemon=True; t.start()

    def _loadPackageBackdrops(self, token):
        # Artwork never blocks package names. Resolve one backdrop per package
        # from package content, cache first; server/TMDb work stays background.
        source=dict(self.source); rows=self.rows
        def worker():
            try: client=get_source_client(source)
            except Exception: client=None
            for idx,row in enumerate(list(rows)):
                if token!=self._token:return
                # A persisted mapping means package discovery is complete.
                # render() handles disk-cache hit or a silent background image
                # download; never block the package list for artwork.
                if str(row.get("backdrop") or "").strip():
                    continue
                try:
                    # Cache first. If the cached slice has titles but none of them
                    # can resolve a real backdrop, fetch the complete package and
                    # continue walking later titles. This is important for Arabic
                    # series packages where the first cached titles often have no art.
                    items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=True,wait_for_server=False)
                    tmdb=TMDbClient(); tmdb_kind="series" if row["kind"]=="series" else "vod"
                    def resolve_backdrop(candidates):
                        for candidate in [x for x in (candidates or []) if isinstance(x,dict)]:
                            back=candidate.get("backdrop_path") or candidate.get("backdrop") or candidate.get("backdrop_url") or candidate.get("fanart") or candidate.get("background") or ""
                            if isinstance(back,list): back=back[0] if back else ""
                            if not back:
                                tid=str(candidate.get("tmdb_id") or candidate.get("tmdb") or candidate.get("tmdbid") or "").strip()
                                if tid:
                                    try: back=(tmdb.details_bundle(tid,tmdb_kind) or {}).get("backdrop_path") or ""
                                    except Exception: back=""
                            if not back:
                                title=str(candidate.get("name") or candidate.get("title") or "").strip()
                                if title:
                                    try: back=(tmdb.search_artwork(title,kind=tmdb_kind,year=candidate.get("year"),required_key="backdrop_path") or {}).get("backdrop_path") or ""
                                    except Exception: back=""
                            if back: return back
                        return ""
                    back=resolve_backdrop(items)
                    if not back:
                        try:
                            full_items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=False,wait_for_server=True)
                        except Exception:
                            full_items=[]
                        back=resolve_backdrop(full_items)
                    if not back: continue
                    if isinstance(back,str):
                        back=back.strip().replace(chr(92)+"/","/")
                        if back.startswith("["):
                            try:
                                arr=json.loads(back); back=arr[0] if arr else ""
                            except Exception: pass
                        if back.startswith("/") and not back.startswith("//"): back=backdrop_url(back)
                    if back:
                        row["backdrop"]=str(back)
                        # Save the mapping as soon as it is resolved.  The next
                        # GENRE open uses this URL immediately; cached_artwork()
                        # then serves the already-downloaded file without a scan.
                        try:
                            self._packageBackdropCache[str(row["id"])]=str(back)
                            _all_backdrops=load_json(self._packageBackdropFile,{}) or {}
                            _backdrop_scope=_content_package_control_key(source,row["kind"])
                            _all_backdrops[_backdrop_scope]=dict(self._packageBackdropCache)
                            save_json(self._packageBackdropFile,_all_backdrops)
                        except Exception:
                            pass
                        def repaint(i=idx):
                            if token==self._token and self.pageStart <= i < self.pageStart+self.PAGE_SIZE:self.render()
                        try: reactor.callFromThread(repaint)
                        except Exception: pass
                except Exception: pass
        t=threading.Thread(target=worker,name="TiviMateGenreArtwork"); t.daemon=True; t.start()
    def render(self):
        total=len(self.rows)
        if total:
            self.pageStart=(self.index//self.PAGE_SIZE)*self.PAGE_SIZE
        page=(self.pageStart//self.PAGE_SIZE)+1 if total else 1
        pages=max(1,(total+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["page"].setText("%d / %d"%(page,pages))
        for slot in range(self.PAGE_SIZE):
            pos=self.pageStart+slot; row=self.rows[pos] if pos<total else None
            self["label%d"%slot].setText(row["name"] if row else "")
            if not row:
                self["card%d"%slot].hide(); self["shell%d"%slot].hide(); continue
            self["card%d"%slot].show(); self["shell%d"%slot].show()
            try:self["card%d"%slot].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg")
            except Exception:pass
            url=row.get("backdrop") or ""
            if url:
                cached=cached_artwork(url,"backdrops")
                if cached and os.path.exists(cached):
                    try:self["card%d"%slot].instance.setPixmapFromFile(cached)
                    except Exception:pass
                else:
                    expected=(pos,url)
                    def ready(path, s=slot, exp=expected):
                        try:
                            p=self.pageStart+s
                            if p!=exp[0] or p>=len(self.rows) or self.rows[p].get("backdrop")!=exp[1]:return
                            self["card%d"%s].instance.setPixmapFromFile(path)
                        except Exception:pass
                    try:request_artwork(url,"backdrops",ready,priority=35)
                    except Exception:pass
        if total:
            slot=self.index-self.pageStart; x=[247,612,977,1342][slot%4]; y=[178,448,718][slot//4]
            try:
                focus_colors=("cyan","silver","red","green","orange","purple")
                focus_name="genre_package_focus_%s.png" % focus_colors[self.index % len(focus_colors)]
                focus_path=os.path.join(PLUGIN_PATH,"skins","genre",focus_name)
                self["selector"].instance.setPixmapFromFile(focus_path)
            except Exception: pass
            try:self["selector"].instance.move(ePoint(sx(x),sy(y))); self["selector"].show()
            except Exception:pass
        else:
            try:self["selector"].hide()
            except Exception:pass
    def left(self):
        if self.rows:self.index=max(0,self.index-1); self.render()
    def right(self):
        if self.rows:self.index=min(len(self.rows)-1,self.index+1); self.render()
    def up(self):
        if self.rows:self.index=max(0,self.index-4); self.render()
    def down(self):
        if self.rows:self.index=min(len(self.rows)-1,self.index+4); self.render()
    def pageUp(self):
        if self.rows:self.index=max(0,self.index-self.PAGE_SIZE); self.render()
    def pageDown(self):
        if self.rows:self.index=min(len(self.rows)-1,self.index+self.PAGE_SIZE); self.render()
    def choose(self):
        if not self.rows:return
        row=dict(self.rows[self.index]); source=dict(self.source)
        def worker():
            items=[]
            try:
                client=get_source_client(source)
                # Genre package opening is cache-first.  Only contact the server
                # when this package has no cached content, so sorting never adds
                # a server request on every visit.
                items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=True,wait_for_server=False)
                if not items:
                    items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=True,wait_for_server=True)
            except Exception:pass
            # Newest -> oldest, locally. Prefer provider added timestamps; when
            # unavailable, fall back to release date/year. Python's stable sort
            # preserves provider order when no useful date exists.
            def newest_key(item):
                # Real newest-first ordering for Genre package contents.
                # Provider `added` is authoritative when present; release date/year
                # is the fallback. Do not use last_modified because many providers
                # update old records and that makes them look falsely new.
                if not isinstance(item, dict):
                    return (0, 0)
                import datetime
                def _stamp(value):
                    if value in (None, ""):
                        return 0
                    try:
                        n = int(float(value))
                        # Accept seconds or milliseconds since epoch.
                        if n > 100000000000:
                            n //= 1000
                        if n > 100000000:
                            return n
                    except Exception:
                        pass
                    txt = str(value).strip().replace("Z", "").replace("T", " ")
                    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d"):
                        try:
                            return int(time.mktime(datetime.datetime.strptime(txt[:19] if "%H" in fmt else txt[:10], fmt).timetuple()))
                        except Exception:
                            pass
                    return 0
                for key in ("added", "added_timestamp", "added_at", "date_added", "created_at", "timestamp"):
                    ts = _stamp(item.get(key))
                    if ts:
                        return (3, ts)
                for key in ("release_date", "releaseDate", "releasedate", "release_date_utc", "first_air_date"):
                    ts = _stamp(item.get(key))
                    if ts:
                        return (2, ts)
                try:
                    year = int(str(item.get("year") or "")[:4])
                    if 1800 <= year <= 2200:
                        return (1, year)
                except Exception:
                    pass
                return (0, 0)
            try: items=sorted(list(items or []),key=newest_key,reverse=True)
            except Exception: items=list(items or [])
            def done():
                if not items:
                    self.session.open(MessageBox,"No content in this package.",MessageBox.TYPE_INFO,timeout=3); return
                self.session.open(MediaScreen,source,row["kind"],None,row["name"],list(items))
            try:reactor.callFromThread(done)
            except Exception:done()
        t=threading.Thread(target=worker,name="TiviMateOpenGenrePackage"); t.daemon=True; t.start()

# ---------------------------------------------------------------------------
# Package browser screens
# ---------------------------------------------------------------------------

class HomePackageBrowserScreen(Screen):
    skin = PROFESSIONAL_PACKAGE_BROWSER_SKIN
    CARD_ROW_Y = [225,318,411,504,597,690]
    NAV_Y = [119,204,289,391,489,574]

    def __init__(self, session, source, kind):
        self.kind="series" if str(kind)=="series" else "vod"
        # Glass package bars are an MOVIES-only experiment; Series remains exactly as r66.
        self.skin = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN if self.kind=="vod" else PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN
        Screen.__init__(self, session)
        self.source=dict(source or {})
        self.rows=[]
        self.index=0
        self.pageStart=0
        # Default to the provider/server order exactly as received.
        # Date/latest remains available manually with YELLOW sort.
        self.sortMode="original"
        self.focusMode="packages"
        self.navIndex=3
        self["background"]=Pixmap()
        self["sideSelector"]=Pixmap()
        self["packageSelector"]=Pixmap()
        self["packageTextFocusBg"]=Pixmap()
        self["clock"]=Label("")
        self["date"]=Label("")
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["count"]=Label("")
        self["serverName"]=Label("")
        self["serverNameBold"]=Label("")
        self["back"]=Label("BACK")
        self["open"]=Label("SERVER")
        self["info"]=Label("PACKAGE FILTER")
        self["sort"]=Label("LATEST")
        self["packageFocusBold"]=Label("")
        self["packageMenuHint"]=Label("MENU  •  PARENTAL / HIDE")
        self.moveMode=False
        self._pendingPackageOpen=None
        for i,name in enumerate(["LIVE TV","MOVIES","TV SHOWS","PACKAGES","FAVORITES","SETTINGS"]):
            self["nav%d"%i]=Label(name)
        for i in range(6):
            self["row%d"%i]=Label("")
            self["meta%d"%i]=Label("")
            self["logo%d"%i]=Pixmap()
            self["desc%d"%i]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions","MenuActions"],{
            "ok":self.choose,"cancel":self.close,"red":self.close,
            "up":self.up,"down":self.down,"left":self.left,"right":self.right,
            "pageUp":self.pageUp,"pageDown":self.pageDown,
            "green":self.openPackageFilter,
            "yellow":self.togglePackageSort,"blue":self.serverSwitch,"menu":self.openPackageMenu
        },-1)
        self._loadToken=0
        self._loadResult=None
        self._loadTimer=eTimer()
        _connect_timer(self._loadTimer,self._finishLoad)
        # r284: package list paints text first. Logos are decoded only after the
        # page is already visible, one slot at a time, and then kept in a tiny
        # in-memory slot/path cache so navigation does not decode the same PNG
        # repeatedly. This keeps package opening independent from logo work.
        self._logoTimer=eTimer()
        _connect_timer(self._logoTimer,self._loadNextVisibleLogo)
        self._logoPathCache={}
        self._slotLogoState={}
        self._logoQueue=[]
        self.clockTimer=eTimer()
        _connect_timer(self.clockTimer,self.updateClock)
        self.onLayoutFinish.append(self.start)

    def start(self):
        bg=os.path.join(PLUGIN_PATH,"skins","home","home_packages_luxury_movies.jpg" if self.kind=="vod" else "home_packages_luxury_series.jpg")
        focus=os.path.join(PLUGIN_PATH,"skins","packages","movie_package_card_focus_r60.png" if self.kind=="vod" else "series_package_card_focus_r60.png")
        try:self["background"].instance.setPixmapFromFile(bg)
        except Exception:pass
        try:self["packageSelector"].instance.setPixmapFromFile(focus)
        except Exception:pass
        try:self["packageTextFocusBg"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages","package_text_focus_bg_r180.png"))
        except Exception:pass
        if self.kind=="series":
            try:self["title"].instance.setForegroundColor(parseColor("#B48CFF"))
            except Exception:pass
            try:self["count"].instance.setForegroundColor(parseColor("#B48CFF"))
            except Exception:pass
        else:
            try:self["title"].instance.setForegroundColor(parseColor("#E5B243"))
            except Exception:pass
            try:self["count"].instance.setForegroundColor(parseColor("#E5B243"))
            except Exception:pass
        # Show only the currently active server name on both Movies and TV Shows package pages.
        try:
            active_name = str(self.source.get("name") or self.source.get("title") or "").strip()
            self["serverName"].setText(active_name[:32])
            self["serverNameBold"].setText(active_name[:32])
        except Exception:
            pass
        self.updateClock()
        try:self.clockTimer.start(30000)
        except Exception:pass
        self._renderNavFocus()
        try:self["packageFocusBold"].hide()
        except Exception:pass
        self.load()

    def _renderNavFocus(self):
        try:
            y=self.NAV_Y[self.navIndex]
            self["sideSelector"].instance.move(ePoint(sx(15),sy(y)))
            self["sideSelector"].show()
        except Exception:
            pass
        # Same text color everywhere; the moving gold glass bar is the only focus.
        for i in range(6):
            try:
                self["nav%d"%i].instance.setForegroundColor(parseColor("#FFFFFF" if i==self.navIndex and self.focusMode=="nav" else "#E8E8E8"))
            except Exception:
                pass

    def _openNavItem(self):
        if self.navIndex==0:
            self.session.open(MediaScreen,self.source,"live"); return
        if self.navIndex==1:
            self.session.open(ContentHomeScreen,self.source,"vod"); return
        if self.navIndex==2:
            self.session.open(ContentHomeScreen,self.source,"series"); return
        if self.navIndex==3:
            self.focusMode="packages"
            self._renderNavFocus()
            self.render()
            return
        if self.navIndex==4:
            self.session.open(FavoritesScreen); return
        if self.navIndex==5:
            self.session.open(SettingsDashboard); return

    def left(self):
        self.focusMode="nav"
        self._renderNavFocus()

    def right(self):
        self.focusMode="packages"
        self._renderNavFocus()
        self.render()

    def updateClock(self):
        now=datetime.now()
        try:self["clock"].setText(now.strftime("%I:%M %p").lstrip("0"))
        except Exception:pass
        try:self["date"].setText(now.strftime("%A, %d %b %Y"))
        except Exception:pass

    def _brandLogo(self,name):
        # r284: only resolve lightweight package assets. Do not fall back to the
        # old server/filter television icons; unknown collections use the new
        # Movies / TV Shows collection mark instead. Resolution is cached.
        cache_key=(self.kind,str(name or ""))
        if cache_key in self._logoPathCache:
            return self._logoPathCache.get(cache_key) or None
        branded = package_logo_path(name)
        if not branded:
            branded = package_logo_for_key("movies" if self.kind == "vod" else "series")
        if branded and not os.path.exists(branded):
            branded=None
        self._logoPathCache[cache_key]=branded or ""
        return branded

    def _rowLogo(self,row):
        try:
            name,cid=row[0],str(row[1] or "")
        except Exception:
            return None
        if cid == "__recent_added__":
            return package_logo_for_key("recent_movies" if self.kind == "vod" else "recent_series")
        if cid == "__netflix__":
            return package_logo_for_key("netflix")
        if cid == "__prime_video__":
            return package_logo_for_key("prime")
        return self._brandLogo(name)

    def _queueVisibleLogos(self,delay=180):
        # Text/cards are already visible when this starts. Only visible slots are
        # decoded, then further slots are handled after navigation.
        q=[]
        for slot in range(6):
            pos=self.pageStart+slot
            if 0 <= pos < len(self.rows):
                q.append((slot,pos))
        self._logoQueue=q
        try:
            self._logoTimer.stop()
        except Exception:
            pass
        if q:
            try:self._logoTimer.start(int(delay),True)
            except Exception:pass

    def _loadNextVisibleLogo(self):
        if not self._logoQueue:
            return
        slot,pos=self._logoQueue.pop(0)
        try:
            if pos < 0 or pos >= len(self.rows) or pos != self.pageStart+slot:
                raise ValueError("stale logo slot")
            row=self.rows[pos]
            path=self._rowLogo(row)
            state=(str(row[1] or ""),path or "")
            if self._slotLogoState.get(slot) != state:
                if path:
                    self["logo%d"%slot].instance.setPixmapFromFile(path)
                    self["logo%d"%slot].show()
                else:
                    self["logo%d"%slot].hide()
                self._slotLogoState[slot]=state
        except Exception:
            try:self["logo%d"%slot].hide()
            except Exception:pass
        if self._logoQueue:
            try:self._logoTimer.start(85,True)
            except Exception:pass

    def load(self):
        self._loadToken+=1
        token=self._loadToken
        source=dict(self.source)
        kind=self.kind
        self._loadResult=None
        def worker():
            try:
                cats,origin=get_cached_categories(source,kind,get_source_client(source),wait_for_server=True)
                cats=filter_categories(source,kind,cats or [])
                rows=[(
                    "RECENT ADDED",
                    "__recent_added__",
                    "",
                    "LATEST " + ("MOVIES" if kind=="vod" else "SERIES"),
                    10**18,
                    -1
                )]
                appearance=_load_home_appearance()

                def _provider_score(_name,_provider):
                    _text=str(_name or "").strip().lower()
                    _compact=re.sub(r"[^a-z0-9]+"," ",_text).strip()
                    _tokens=[_x for _x in _compact.split() if _x]
                    _resolved=package_provider_key(_name)

                    _base=-1
                    if _provider=="netflix":
                        if "netflix" in _compact:_base=700
                        elif _resolved=="netflix":_base=660
                        elif "nf" in _tokens:_base=620
                    elif _provider=="prime":
                        if "prime video" in _compact:_base=700
                        elif "amazon prime" in _compact:_base=680
                        elif _resolved=="prime":_base=660
                        elif "prime" in _tokens or "amz" in _tokens or "amzn" in _tokens:_base=620

                    if _base<0:
                        return -1

                    _movie_tokens=("movie","movies","film","films","vod","cinema")
                    _series_tokens=("series","tv","show","shows","serial")
                    _has_movie=any(_x in _tokens for _x in _movie_tokens)
                    _has_series=any(_x in _tokens for _x in _series_tokens)

                    if kind=="vod":
                        if _has_movie:_base+=140
                        if _has_series:_base-=220
                    elif kind=="series":
                        if _has_series:_base+=140
                        if _has_movie:_base-=220
                    return _base

                def _best_real_provider(_provider):
                    # r377: package-list rendering must never fan out into one
                    # stream request per category just to identify Netflix/Prime.
                    # Use category metadata only; opening the selected package will
                    # fetch its streams through the normal RAM/disk/server cache path.
                    _best=None
                    for _cat in cats:
                        _name=str((_cat or {}).get("category_name") or "")
                        _cid=str((_cat or {}).get("category_id") or "")
                        _score=_provider_score(_name,_provider)
                        if _score<0 or not _cid:
                            continue
                        try:
                            _count=int((_cat or {}).get("count") or (_cat or {}).get("num") or (_cat or {}).get("total") or (_cat or {}).get("items_count") or 0)
                        except Exception:
                            _count=0
                        # Correct provider/section match first; server-provided count
                        # is only a tie-breaker and never triggers network I/O here.
                        _candidate=(_score,_count,_cid,_name)
                        if _best is None or _candidate[:2] > _best[:2]:
                            _best=_candidate
                    return _best

                _netflix_target=_best_real_provider("netflix") if appearance.get("show_netflix_package") else None
                _prime_target=_best_real_provider("prime") if appearance.get("show_prime_package") else None

                if appearance.get("show_netflix_package"):
                    rows.append((
                        "NETFLIX",
                        "__netflix__",
                        "",
                        "SERVER • TMDB ORDER" if _netflix_target else "NOT FOUND",
                        10**17,
                        -2,
                        (_netflix_target[2] if _netflix_target else ""),
                        (_netflix_target[3] if _netflix_target else "NETFLIX")
                    ))
                if appearance.get("show_prime_package"):
                    rows.append((
                        "PRIME VIDEO",
                        "__prime_video__",
                        "",
                        "SERVER • TMDB ORDER" if _prime_target else "NOT FOUND",
                        10**16,
                        -3,
                        (_prime_target[2] if _prime_target else ""),
                        (_prime_target[3] if _prime_target else "PRIME VIDEO")
                    ))
                for order,x in enumerate(cats):
                    name=x.get("category_name") or "Other"
                    cid=str(x.get("category_id") or "")
                    raw=x.get("count") or x.get("num") or x.get("total") or x.get("items_count") or ""
                    meta=(str(raw)+" "+("MOVIES" if kind=="vod" else "SHOWS")) if raw not in ("",None) else ""
                    # Numeric category IDs normally increase as providers add new groups.
                    # Keep the original provider order as a fallback for non-numeric IDs.
                    try: newest_key=int(cid)
                    except Exception: newest_key=-1
                    # r284: do not decode or even resolve row logos while the
                    # package catalogue is being built. Text opens first.
                    rows.append((name,cid,"",meta,newest_key,order))
                self._loadResult=(token,rows,"")
            except Exception as exc:
                self._loadResult=(token,[],str(exc))
        t=threading.Thread(target=worker,name="TiviMatePackagesCards")
        t.daemon=True
        t.start()
        try:self._loadTimer.start(100,False)
        except Exception:pass

    def _finishLoad(self):
        result=self._loadResult
        if not result:
            try:self._loadTimer.start(100,False)
            except Exception:pass
            return
        self._loadResult=None
        token,rows,error=result
        if token!=self._loadToken:return
        if error:
            self.rows=[]
            self["count"].setText("0 PACKAGES")
            self["row0"].setText("Unable to load packages")
            return
        self.rows=rows or []
        _state=_load_content_package_controls(self.source,self.kind)
        if _state.get("order"):
            self.sortMode="custom"
        self._applyPackageSort(reset=True)
        self["count"].setText("%d PACKAGE%s"%(len(self.rows),"" if len(self.rows)==1 else "S"))
        self.render()
        # Warm package contents after the package page is already painted.
        # This changes no navigation/UI: RAM/disk cache is reused first and only
        # cold packages touch the provider.  The visible packages are warmed
        # first so opening one shortly after entering Movies/TV Shows is fast.
        self._prefetchPackageContents()

    def _prefetchPackageContents(self):
        source=dict(self.source or {})
        kind=self.kind
        if source.get("type") not in ("xtream","stalker"):
            return
        ids=[]
        for row in list(self.rows or []):
            try: cid=str(row[1] or "").strip()
            except Exception: cid=""
            if not cid or cid.startswith("__") or cid in ids:
                continue
            ids.append(cid)
        if not ids:
            return
        # Current six cards first, then the remaining provider order.
        visible=[]
        for pos in range(self.pageStart, min(self.pageStart+6, len(self.rows))):
            try: cid=str(self.rows[pos][1] or "").strip()
            except Exception: cid=""
            if cid and not cid.startswith("__") and cid in ids and cid not in visible:
                visible.append(cid)
        ordered=visible+[cid for cid in ids if cid not in visible]

        def worker():
            try:
                client=get_source_client(source)
                for n,cid in enumerate(ordered):
                    try:
                        get_category_streams(source,kind,client,cid,use_cache=True,wait_for_server=True)
                    except Exception:
                        pass
                    # Keep the receiver/provider responsive after the visible row set.
                    if n >= len(visible):
                        time.sleep(0.08)
            except Exception:
                pass
        t=threading.Thread(target=worker,name="TiviMatePackageWarm")
        t.daemon=True
        t.start()

    def _applyPackageSort(self, reset=False):
        state=_load_content_package_controls(self.source,self.kind)
        custom_order=list(state.get("order") or [])
        if self.sortMode=="custom" and custom_order:
            rank=dict((cid,i) for i,cid in enumerate(custom_order))
            self.rows.sort(key=lambda row:(rank.get(str(row[1]),10**6), str(row[0] or "").casefold()))
            self["sort"].setText("MOVE")
            if reset:
                self.index=0; self.pageStart=0
            return
        pin_order={"__recent_added__":0, "__netflix__":1, "__prime_video__":2}
        pinned = [row for row in self.rows if str(row[1]) in pin_order]
        pinned.sort(key=lambda row: pin_order.get(str(row[1]), 99))
        normal = [row for row in self.rows if str(row[1]) not in pin_order]
        if self.sortMode=="az":
            normal.sort(key=lambda row: str(row[0] or "").casefold())
            self["sort"].setText("A TO Z")
        elif self.sortMode=="za":
            normal.sort(key=lambda row: str(row[0] or "").casefold(), reverse=True)
            self["sort"].setText("Z TO A")
        elif self.sortMode=="original":
            # Preserve the provider/server category order exactly as received.
            normal.sort(key=lambda row: row[5])
            self["sort"].setText("ORIGINAL")
        else:
            # Latest first: higher numeric category IDs first. When a provider
            # uses non-numeric IDs, newly appended provider rows are shown first.
            normal.sort(key=lambda row: (row[4] if row[4] >= 0 else row[5]), reverse=True)
            self["sort"].setText("LATEST")
        self.rows = pinned + normal
        if reset:
            self.index=0
            self.pageStart=0

    def togglePackageSort(self):
        # Movies + TV Shows: open an explicit package-order chooser.
        # Each entry uses a compact round marker; the selected mode is filled.
        labels = (("original", "Original"), ("latest", "Latest"), ("az", "A to Z"), ("za", "Z to A"))
        choices=[]
        for mode,label in labels:
            marker = "●" if self.sortMode == mode else "○"
            choices.append(("%s  %s" % (marker,label), mode))
        self.session.openWithCallback(self._packageSortSelected, ChoiceBox, title="PACKAGE ORDER", list=choices)

    def _packageSortSelected(self, answer):
        if not answer:
            return
        try:
            mode=str(answer[1])
        except Exception:
            return
        if mode not in ("original","latest","az","za"):
            return
        self.sortMode=mode
        self._applyPackageSort(reset=True)
        self.render()

    def render(self):
        if self.rows:
            if self.index<self.pageStart:self.pageStart=self.index
            if self.index>=self.pageStart+6:self.pageStart=self.index-5
        for slot in range(6):
            pos=self.pageStart+slot
            row=self.rows[pos] if 0<=pos<len(self.rows) else None
            if row:
                name,cid,logo,meta=row[:4]
                self["row%d"%slot].setText(name)
                self["meta%d"%slot].setText(meta or ("MOVIES" if self.kind=="vod" else "SERIES"))
                if cid=="__netflix__":
                    self["desc%d"%slot].setText("Netflix Collection")
                elif cid=="__prime_video__":
                    self["desc%d"%slot].setText("Prime Video Collection")
                else:
                    self["desc%d"%slot].setText("Movies Collection" if self.kind=="vod" else "Series Collection")
                # r284: never make the initial card paint wait on PNG decode.
                # Keep an already-cached logo only if this exact row still owns
                # the slot; otherwise paint text first and defer the logo.
                expected=(str(cid or ""),)
                state=self._slotLogoState.get(slot)
                if not state or state[:1] != expected:
                    self["logo%d"%slot].hide()
            else:
                self["row%d"%slot].setText("")
                self["meta%d"%slot].setText("")
                self["desc%d"%slot].setText("")
                self["logo%d"%slot].hide()
        # Keep every non-selected package quiet and readable.  The focused row
        # gets a local dark glass strip, slightly larger title and brighter meta.
        for slot in range(6):
            try:
                self["row%d"%slot].instance.setFont(gFont("Regular",27))
                self["row%d"%slot].instance.setForegroundColor(parseColor("#F0F0F0"))
                self["desc%d"%slot].instance.setForegroundColor(parseColor("#C8BFD2"))
                self["meta%d"%slot].instance.setForegroundColor(parseColor("#D7D0E1"))
            except Exception:
                pass
        if self.rows and self.focusMode=="packages":
            slot=self.index-self.pageStart
            try:
                self["packageSelector"].instance.move(ePoint(sx(475),sy(self.CARD_ROW_Y[slot])))
            except Exception:pass
            try:
                self["packageTextFocusBg"].instance.move(ePoint(sx(655),sy(self.CARD_ROW_Y[slot]+7)))
                self["packageTextFocusBg"].show()
            except Exception:pass
            try:
                self["row%d"%slot].instance.setFont(gFont("Regular",31))
                self["row%d"%slot].instance.setForegroundColor(parseColor("#FFD34E"))
                self["desc%d"%slot].instance.setForegroundColor(parseColor("#FFF1BF"))
                self["meta%d"%slot].instance.setForegroundColor(parseColor("#FFD34E"))
                focused_name=str(self.rows[self.index][0] or "")
                self["packageFocusBold"].setText(focused_name)
                self["packageFocusBold"].instance.move(ePoint(sx(676),sy(self.CARD_ROW_Y[slot]+7)))
                self["packageFocusBold"].show()
            except Exception:
                pass
            self["packageSelector"].show()
        else:
            self["packageSelector"].hide()
            try:self["packageTextFocusBg"].hide()
            except Exception:pass
            try:self["packageFocusBold"].hide()
            except Exception:pass
        # Paint package names/cards first. Logo decoding starts only after the
        # first visible frame, then proceeds one logo at a time.
        self._queueVisibleLogos(420)

    def up(self):
        if self.focusMode=="nav":
            self.navIndex=(self.navIndex-1)%6
            self._renderNavFocus()
            return
        if not self.rows:return
        if self.moveMode and self.index>0:
            self.rows[self.index-1],self.rows[self.index]=self.rows[self.index],self.rows[self.index-1]
            self.index-=1
            self._savePackageOrder()
        else:
            self.index=(self.index-1)%len(self.rows)
        self.render()

    def down(self):
        if self.focusMode=="nav":
            self.navIndex=(self.navIndex+1)%6
            self._renderNavFocus()
            return
        if not self.rows:return
        if self.moveMode and self.index<len(self.rows)-1:
            self.rows[self.index+1],self.rows[self.index]=self.rows[self.index],self.rows[self.index+1]
            self.index+=1
            self._savePackageOrder()
        else:
            self.index=(self.index+1)%len(self.rows)
        self.render()

    def pageUp(self):
        if self.focusMode=="nav":return
        if not self.rows:return
        self.index=max(0,self.index-6)
        self.render()

    def pageDown(self):
        if self.focusMode=="nav":return
        if not self.rows:return
        self.index=min(len(self.rows)-1,self.index+6)
        self.render()

    def choose(self):
        if self.focusMode=="nav":
            self._openNavItem()
            return
        if not self.rows:return
        row=self.rows[self.index]
        cid=str(row[1] or "")
        state=_load_content_package_controls(self.source,self.kind)
        if cid and cid in state.get("locked",set()):
            self._pendingPackageOpen=row
            self.session.openWithCallback(self._packagePinForOpen,VirtualKeyBoard,title=tr("Enter parental PIN"),text="")
            return
        self._openPackageRow(row)

    def _packagePinForOpen(self,value=None):
        row=self._pendingPackageOpen; self._pendingPackageOpen=None
        if not row:return
        state=_load_content_package_controls(self.source,self.kind)
        if str(value or "").strip()!=str(state.get("pin") or "0000"):
            self.session.open(MessageBox,tr("Incorrect PIN"),MessageBox.TYPE_ERROR,timeout=3); return
        self._openPackageRow(row)

    def _openPackageRow(self,row):
        name,cid,logo,meta=row[:4]
        result={"name":name,"id":cid,"_source":dict(self.source)}
        if cid in ("__netflix__","__prime_video__"):
            result["target_id"]=str(row[6] or "") if len(row)>6 else ""
            result["target_name"]=str(row[7] or name) if len(row)>7 else name
        if cid:
            try:
                target_id = str(result.get("target_id") or cid)
                target_name = result.get("target_name") or name
                self.session.open(MediaScreen, dict(self.source), self.kind, target_id, target_name)
            except Exception:
                self.close(result)

    def _savePackageOrder(self):
        state=_load_content_package_controls(self.source,self.kind)
        state["order"]=[str(row[1]) for row in self.rows if str(row[1] or "")]
        _save_content_package_controls(self.source,self.kind,state)
        self.sortMode="custom"
        try:self["sort"].setText("MOVE")
        except Exception:pass

    def openPackageMenu(self):
        if self.focusMode!="packages" or not self.rows:return
        row=self.rows[self.index]; name=str(row[0] or ""); cid=str(row[1] or "")
        if not cid:return
        state=_load_content_package_controls(self.source,self.kind)
        locked=cid in state.get("locked",set())
        choices=[
            (tr("GENRE"),"genre"),
            ((tr("Remove from parental protection") if locked else tr("Add to parental protection")),"parental"),
            (tr("Hide this package"),"hide"),
            ((tr("Disable move") if self.moveMode else tr("Enable move")),"move"),
            (tr("Change parental PIN"),"change_pin"),
        ]
        self.session.openWithCallback(self._packageMenuSelected,ChoiceBox,title=name,list=choices)

    def _packageMenuSelected(self,choice=None):
        if not choice or not self.rows:return
        action=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
        row=self.rows[self.index]; cid=str(row[1] or ""); name=str(row[0] or "")
        if action=="genre":
            try:
                self.session.open(MovieGenresScreen, dict(self.source), self.kind)
            except Exception as exc:
                self.session.open(MessageBox, tr("Unable to open Genres")+":\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)
            return
        if action=="parental":
            state=_load_content_package_controls(self.source,self.kind)
            locked=set(state.get("locked") or [])
            if cid in locked:locked.discard(cid)
            else:locked.add(cid)
            state["locked"]=locked; _save_content_package_controls(self.source,self.kind,state)
            self.render(); return
        if action=="hide":
            if cid.startswith("__"):
                self.session.open(MessageBox,tr("This package cannot be hidden."),MessageBox.TYPE_INFO,timeout=3); return
            self._pendingHidePackage=(cid,name)
            self.session.openWithCallback(self._confirmHidePackage,MessageBox,tr("Hide this package?")+"\n"+name,MessageBox.TYPE_YESNO)
            return
        if action=="move":
            self.moveMode=not self.moveMode
            if self.moveMode:
                self.sortMode="custom"; self._savePackageOrder()
                self["packageMenuHint"].setText("MOVE MODE  •  UP/DOWN move package  •  MENU disable move")
            else:
                self["packageMenuHint"].setText("MENU  •  PARENTAL / HIDE")
            self.render(); return
        if action=="change_pin":
            self.session.openWithCallback(self._packageNewPinEntered,VirtualKeyBoard,title=tr("Enter new 4-digit PIN"),text="")

    def _confirmHidePackage(self,answer=False):
        pending=getattr(self,"_pendingHidePackage",None); self._pendingHidePackage=None
        if not answer or not pending:return
        cid,name=pending
        data=_load_all_filters(); key=_source_filter_key(self.source); entry=data.setdefault(key,{})
        allowed=entry.get(self.kind)
        if allowed is None:
            allowed=[str(row[1]) for row in self.rows if str(row[1] or "") and not str(row[1]).startswith("__")]
        allowed=[str(x) for x in (allowed or []) if str(x)!=cid]
        entry[self.kind]=allowed; data[key]=entry
        if _save_all_filters(data):
            self.rows=[row for row in self.rows if str(row[1])!=cid]
            if self.index>=len(self.rows):self.index=max(0,len(self.rows)-1)
            try:clear_catalog_memory()
            except Exception:pass
            self["count"].setText("%d PACKAGE%s"%(len(self.rows),"" if len(self.rows)==1 else "S"))
            self.render()

    def _packageNewPinEntered(self,value=None):
        value=str(value or "").strip()
        if not(len(value)==4 and value.isdigit()):
            self.session.open(MessageBox,tr("PIN must contain exactly 4 digits."),MessageBox.TYPE_ERROR,timeout=3); return
        state=_load_content_package_controls(self.source,self.kind); state["pin"]=value
        _save_content_package_controls(self.source,self.kind,state)
        self.session.open(MessageBox,tr("Parental PIN changed."),MessageBox.TYPE_INFO,timeout=3)

    def openPackageFilter(self):
        # GREEN filters the currently open package kind for THIS server.
        # Movies -> VOD categories, TV Shows -> Series categories.
        stype = str((self.source or {}).get("type") or "").lower()
        if stype not in ("xtream", "stalker"):
            label = "Movie" if self.kind == "vod" else "TV Shows"
            self.session.open(MessageBox, "%s package filtering is available for Xtream Codes and Stalker Portal." % label, MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(
            self._packageFilterClosed,
            ServerCategoryFilter,
            dict(self.source),
            self.kind,
            True
        )

    # Compatibility alias for older callers.
    def openMoviePackageFilter(self):
        return self.openPackageFilter()

    def _packageFilterClosed(self, changed=None):
        # Reload the visible package list after saving; filter data itself is
        # persisted per-server by ServerCategoryFilter / filters.py.
        try:
            clear_catalog_memory()
        except Exception:
            pass
        self.rows=[]
        self.index=0
        self.pageStart=0
        try:self["count"].setText("")
        except Exception:pass
        self.load()

    def _moviePackageFilterClosed(self, changed=None):
        return self._packageFilterClosed(changed)

    def _serverChoices(self):
        rows=[]
        current_key=_source_identity(self.source)
        for source in list(get_sources() or []):
            if not isinstance(source,dict):
                continue
            # Movies/TV Shows: M3U is shown only when its cached playlist proves
            # that this section exists. Live-only M3U never leaks into VOD/Series.
            stype=str(source.get("type") or "").lower()
            if stype not in ("xtream","stalker","m3u"):
                continue
            if stype == "m3u" and not _m3u_source_has_kind(source, self.kind):
                continue
            name=str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            kind="Xtream" if stype=="xtream" else "Stalker" if stype=="stalker" else "M3U"
            prefix="✓ " if _source_identity(source)==current_key else ""
            rows.append(("%s%s  [%s]"%(prefix,name,kind),dict(source)))
        return rows

    def serverSwitch(self):
        choices=self._serverChoices()
        if not choices:
            self.session.open(MessageBox,"No compatible IPTV servers found.",MessageBox.TYPE_INFO,timeout=3)
            return
        self.session.openWithCallback(
            self._serverSwitchSelected,
            ChoiceBox,
            title="SERVER SWITCH",
            list=choices
        )

    def _serverSwitchSelected(self,choice=None):
        if not choice:
            return
        try:
            source=choice[1]
        except Exception:
            return
        if not isinstance(source,dict):
            return
        self.source=dict(source)
        try:
            save_json(MAIN_SOURCE_FILE,{"key":_source_identity(self.source)})
        except Exception:
            pass
        self.rows=[]
        self.index=0
        self.pageStart=0
        self["count"].setText("")
        for slot in range(6):
            self["row%d"%slot].setText("")
            self["meta%d"%slot].setText("")
            self["desc%d"%slot].setText("")
            try:self["logo%d"%slot].hide()
            except Exception:pass
        self.load()

    def showInfo(self):
        if not self.rows:return
        name,cid,logo,meta=self.rows[self.index][:4]
        self.session.open(MessageBox,name,MessageBox.TYPE_INFO,timeout=3)


PACKAGE_SELECTOR_SKIN = r"""<screen name="ContentPackagesScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/packages_selector_fullscreen.jpg" alphatest="blend" scale="1" zPosition="0"/>
<eLabel position="0,135" size="390,610" backgroundColor="#050608" zPosition="2"/>
<widget name="navFocus" position="0,174" size="360,64" alphatest="blend" zPosition="4"/>
<ePixmap position="42,190" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="6"/><widget name="nav0" position="78,182" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<ePixmap position="42,262" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="6"/><widget name="nav1" position="78,254" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<ePixmap position="42,334" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="6"/><widget name="nav2" position="78,326" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<ePixmap position="42,406" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="6"/><widget name="nav3" position="78,398" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<ePixmap position="42,478" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/genre.png" alphatest="blend" zPosition="6"/><widget name="nav4" position="78,470" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<ePixmap position="42,550" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="6"/><widget name="nav5" position="78,542" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<ePixmap position="42,622" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="6"/><widget name="nav6" position="78,614" size="260,48" font="Regular;27" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="5"/>
<widget name="cardFocus" position="520,320" size="470,545" alphatest="blend" zPosition="6"/>

<!-- Real package clock: generated hands update from receiver local time. -->
<widget name="packageClockFace" position="1578,18" size="116,116" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_clock_r108/face.png" alphatest="blend" zPosition="8"/>
<widget name="packageClockHour" position="1578,18" size="116,116" alphatest="blend" zPosition="9"/>
<widget name="packageClockMinute" position="1578,18" size="116,116" alphatest="blend" zPosition="10"/>
<widget name="packageDate" position="1712,42" size="190,64" font="Regular;20" foregroundColor="#F4F4F0" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="10"/>
</screen>"""

class ContentPackagesScreen(Screen):
    skin = PACKAGE_SELECTOR_SKIN
    NAV_Y = [174,246,318,390,462,534,606]
    CARD_X = [520,1010]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source=dict(source or {})
        self.choice=0
        self.navIndex=3
        self.mode="cards"
        self["navFocus"]=Pixmap(); self["cardFocus"]=Pixmap()
        self["packageClockFace"]=Pixmap()
        self["packageClockHour"]=Pixmap()
        self["packageClockMinute"]=Pixmap()
        self["packageDate"]=Label("")
        for i,name in enumerate(["LIVE TV","MOVIES","TV SHOWS","PACKAGES","GENRE","FAVORITES","SETTINGS"]): self["nav%d"%i]=Label(name)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "left":self.left,"right":self.right,"up":self.up,"down":self.down,"ok":self.ok,"cancel":self.close,"red":self.close
        },-1)
        self._packageClockTimer=eTimer()
        _connect_timer(self._packageClockTimer,self._updatePackageClock)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._stopPackageClock)

    def _ready(self):
        try:self["navFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages","packages_nav_focus_r52.png"))
        except Exception:pass
        try:self["cardFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages","packages_card_focus_r52.png"))
        except Exception:pass
        self._updatePackageClock()
        try:self._packageClockTimer.start(30000, False)
        except Exception:pass
        self._renderFocus()

    def _stopPackageClock(self):
        try:self._packageClockTimer.stop()
        except Exception:pass

    def _updatePackageClock(self):
        now=datetime.now()
        minute=int(now.minute)
        hour=int(now.hour)%12
        # Hour hand advances every five minutes, not only once per hour.
        hour_slot=(hour*12 + int(minute/5)) % 144
        clock_root=os.path.join(PLUGIN_PATH,"skins","packages","package_clock_r108")
        try:
            self["packageClockHour"].instance.setPixmapFromFile(
                os.path.join(clock_root,"h%03d.png"%hour_slot)
            )
        except Exception:pass
        try:
            self["packageClockMinute"].instance.setPixmapFromFile(
                os.path.join(clock_root,"m%02d.png"%minute)
            )
        except Exception:pass
        try:
            self["packageDate"].setText(now.strftime("%A\n%d %b %Y"))
        except Exception:pass

    def _renderFocus(self):
        try:self["navFocus"].instance.move(ePoint(sx(0),sy(self.NAV_Y[self.navIndex])))
        except Exception:pass
        if self.mode=="cards":
            self["cardFocus"].show()
            try:self["cardFocus"].instance.move(ePoint(sx(self.CARD_X[self.choice]),sy(320)))
            except Exception:pass
        else:self["cardFocus"].hide()

    def up(self):
        self.mode="nav"; self.navIndex=(self.navIndex-1)%7; self._renderFocus()
    def down(self):
        self.mode="nav"; self.navIndex=(self.navIndex+1)%7; self._renderFocus()
    def left(self):
        if self.mode=="cards": self.choice=0
        else: self.mode="cards"; self.choice=0
        self._renderFocus()
    def right(self):
        if self.mode=="cards": self.choice=1
        else: self.mode="cards"; self.choice=1
        self._renderFocus()

    def ok(self):
        if self.mode=="nav":
            if self.navIndex==0:self.session.open(MediaScreen,self.source,"live"); return
            if self.navIndex==1:self.session.open(ContentHomeScreen,self.source,"vod"); return
            if self.navIndex==2:self.session.open(ContentHomeScreen,self.source,"series"); return
            if self.navIndex==3:self.mode="cards"; self._renderFocus(); return
            if self.navIndex==4:
                self.session.openWithCallback(self._packageGenreSelected,TiviMateGenreSelectScreen); return
            if self.navIndex==5:self.session.open(FavoritesScreen); return
            if self.navIndex==6:self.session.open(SettingsDashboard); return
        kind="vod" if self.choice==0 else "series"
        self._homePackageKind=kind
        try:
            self.source=dict(_load_main_source(self.source) or self.source)
        except Exception:
            pass
        self.session.openWithCallback(self._homePackageBrowserClosed,HomePackageBrowserScreen,self.source,kind)

    def _packageGenreSelected(self, selected=None):
        if not selected:
            return
        try:
            kind = selected[1] if isinstance(selected, (tuple, list)) else str(selected)
            self.session.openWithCallback(self._returnToPackageGenreSelector, MovieGenresScreen, dict(self.source), kind)
        except Exception as exc:
            self.session.open(MessageBox, tr("Unable to open Genres")+":\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def _returnToPackageGenreSelector(self, *args):
        self.session.openWithCallback(self._packageGenreSelected, TiviMateGenreSelectScreen)

    def _homePackageBrowserClosed(self, selected=None, *args):
        self._packageSelected(getattr(self,"_homePackageKind","vod"),selected)
    def _packageSelected(self,kind,selected=None):
        if not selected or not isinstance(selected,dict):return
        selected_source=selected.get("_source")
        if isinstance(selected_source,dict):
            self.source=dict(selected_source)
        cid=str(selected.get("id") or ""); name=selected.get("name") or ""
        if cid in ("__netflix__","__prime_video__"):
            target_id=str(selected.get("target_id") or "")
            target_name=str(selected.get("target_name") or name)
            if not target_id:
                self.session.open(
                    MessageBox,
                    "%s package with content was not found on this server." % name,
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
                return
            provider="netflix" if cid=="__netflix__" else "prime"
            routed_source=dict(self.source or {})
            routed_source["_package_provider_override"]=provider
            routed_source["_package_provider_category_id"]=target_id
            self.session.open(MediaScreen,routed_source,kind,target_id,target_name)
            return
        if cid=="__recent_added__":
            self.session.open(MediaScreen,self.source,kind,cid,name)
            return
        if cid:self.session.open(MediaScreen,self.source,kind,cid,name)



IMAGE_CACHE_CLEAN_BLUE_SKIN = r"""<screen name="ImageCacheSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#070A0E">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#070A0E" zPosition="0"/>
    <eLabel position="0,0" size="1920,96" backgroundColor="#0A0E13" zPosition="1"/>
    <widget name="cacheBrand" position="42,13" size="300,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" scale="1" zPosition="4"/>

    <eLabel position="520,0" size="150,96" text="Search" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="670,0" size="130,96" text="Home" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="800,0" size="120,96" text="Live" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="920,0" size="140,96" text="Movies" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1060,0" size="170,96" text="TV Shows" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1230,0" size="160,96" text="Settings" font="Regular;22" foregroundColor="#8B6CFF" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1260,82" size="100,3" backgroundColor="#8B6CFF" zPosition="4"/>

    <widget name="title" position="95,155" size="1200,52" font="Regular;38" foregroundColor="#F4F7FA" transparent="1" zPosition="4"/>
    <eLabel position="95,225" size="1730,2" backgroundColor="#6F5AA8" zPosition="2"/>

    <eLabel position="95,270" size="1730,510" backgroundColor="#161B27" borderColor="#6F5AA8" borderWidth="2" cornerRadius="12" zPosition="1"/>
    <widget name="config" position="125,300" size="1670,430" font="Regular;25" itemHeight="92" scrollbarMode="showOnDemand"
        foregroundColor="#E8EDF2" backgroundColor="#161B27"
        selectionForegroundColor="#FFFFFF" selectionBackgroundColor="#26A7E8"
        transparent="0" zPosition="4"/>

    <widget name="hint" position="180,800" size="1560,48" font="Regular;20" foregroundColor="#AEB9C4" transparent="1" halign="center" valign="center" zPosition="4"/>
    <eLabel position="95,862" size="1730,2" backgroundColor="#6F5AA8" zPosition="2"/>

    <eLabel position="120,900" size="390,76" text="GREEN\nSAVE" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#21C7D9" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="540,900" size="390,76" text="YELLOW\nCLEAN UP" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#8F55D9" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="960,900" size="390,76" text="BLUE\nCLEAR CACHE" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#9A56D8" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="1380,900" size="390,76" text="EXIT\nBACK" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#34485D" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <widget name="keys" position="0,1035" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


# ---------------------------------------------------------------------------
# Settings screens
# ---------------------------------------------------------------------------

class ImageCacheSettings(Screen, ConfigListScreen):
    skin = IMAGE_CACHE_CLEAN_BLUE_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["cacheBrand"] = Pixmap()
        cfg = get_cache_settings()
        self["title"] = Label(tr("IMAGE CACHE"))
        self["hint"] = Label("")
        self["keys"] = Label(tr("GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK"))
        self.location = ConfigSelection(default=str(cfg.get("location", "auto")), choices=[
            ("auto", "Auto: HDD → USB → MMC → Internal Flash"),
            ("hdd", "HDD /media/hdd"),
            ("usb", "USB /media/usb"),
            ("mmc", "MMC /media/mmc"),
            ("internal", "Internal Flash"),
            ("tmp", "Temporary /tmp"),
        ])
        self.retention = ConfigSelection(default=str(cfg.get("retention_days", 0)), choices=[
            ("0", "Unlimited — Keep images"),
            ("7", "1 Week"), ("14", "2 Weeks"), ("21", "3 Weeks"), ("30", "30 Days")
        ])
        self.flashLimit = ConfigSelection(default=str(cfg.get("flash_image_limit", 20)), choices=[
            ("20", "20 Posters + 20 Backdrops"),
            ("40", "40 Posters + 40 Backdrops"),
            ("60", "60 Posters + 60 Backdrops"),
            ("100", "100 Posters + 100 Backdrops")
        ])
        self.flashReserve = ConfigSelection(default=str(cfg.get("flash_min_free_mb", 30)), choices=[
            ("0", "Disabled"), ("20", "20 MB"), ("30", "30 MB — Recommended"), ("50", "50 MB")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Cache Location"), self.location),
            getConfigListEntry(tr("Image Cache Retention"), self.retention),
            getConfigListEntry(tr("Internal Flash Image Limit"), self.flashLimit),
            getConfigListEntry(tr("Internal Flash Free Space"), self.flashReserve),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "blue": self.clearNow, "yellow": self.cleanNow,
            "red": self.close, "cancel": self.close
        }, -1)
        self["sectionNav"] = ActionMap(["DirectionActions"], {
            "up": self._sectionUp, "down": self._sectionDown,
        }, -2)
        self.onLayoutFinish.append(self.updateHint)

    def _sectionUp(self):
        try:
            if self["config"].getCurrentIndex() > 0:
                return ConfigListScreen.keyUp(self)
        except Exception:
            return ConfigListScreen.keyUp(self)
        return ConfigListScreen.keyUp(self)

    def _sectionDown(self):
        try:
            idx = self["config"].getCurrentIndex()
            total = len(self["config"].list or [])
            if idx < max(0, total - 1):
                return ConfigListScreen.keyDown(self)
        except Exception:
            return ConfigListScreen.keyDown(self)
        self.session.open(SubDLSubtitleLanguageSettings)

    def updateHint(self):
        root, size, files = cache_status()
        self["hint"].setText("Current location: %s  •  %.1f MB  •  %d files" % (root, size / 1048576.0, files))

    def save(self):
        if save_cache_settings(
                self.location.value, 0, int(self.retention.value),
                int(self.flashLimit.value), int(self.flashReserve.value)):
            cleanup_cache()
            self.updateHint()
            self.session.open(MessageBox, "Cache settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save cache settings.", MessageBox.TYPE_ERROR)

    def clearNow(self):
        if clear_cache():
            try:
                clear_catalog_memory()
            except Exception:
                pass
            self.updateHint()
            self.session.open(MessageBox, "Poster and backdrop cache cleared. Data caches were kept.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to clear image cache.", MessageBox.TYPE_ERROR)

    def cleanNow(self):
        cleanup_cache()
        self.updateHint()
        self.session.open(MessageBox, "Poster/backdrop cache cleaned. Metadata, Recent, TMDb and database caches were kept.", MessageBox.TYPE_INFO)


from .display_scale import load_profile_preference, save_profile_preference

POSTER_SETTINGS_R199_SKIN = r'''<screen name="HomeAppearanceSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#030811">
 <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_settings_cards_r199.jpg" alphatest="blend" zPosition="0"/>
 <widget name="focus" position="55,300" size="410,550" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r199.png" alphatest="blend" zPosition="8"/>
 <widget name="title0" position="85,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="title1" position="530,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="title2" position="975,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="title3" position="1420,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="desc0" position="92,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="desc1" position="537,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="desc2" position="982,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="desc3" position="1427,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="value0" position="88,765" size="344,44" font="Regular;25" foregroundColor="#1FA8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="value1" position="533,765" size="344,44" font="Regular;25" foregroundColor="#A847F5" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="value2" position="978,765" size="344,44" font="Regular;25" foregroundColor="#00D2CC" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="value3" position="1423,765" size="344,44" font="Regular;25" foregroundColor="#FF6B2D" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title4" position="0,0" size="1,1" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6"/>
 <widget name="desc4" position="0,0" size="1,1" font="Regular;19" foregroundColor="#C8D2DC" transparent="1" halign="center" zPosition="6"/>
 <widget name="value4" position="0,0" size="1,1" font="Regular;24" foregroundColor="#56C8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title5" position="0,0" size="1,1" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6"/>
 <widget name="desc5" position="0,0" size="1,1" font="Regular;19" foregroundColor="#C8D2DC" transparent="1" halign="center" zPosition="6"/>
 <widget name="value5" position="0,0" size="1,1" font="Regular;24" foregroundColor="#56C8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="hint" position="510,1012" size="900,30" font="Regular;19" foregroundColor="#8795A3" transparent="1" halign="center" zPosition="5"/>
</screen>'''

class HomeAppearanceSettings(Screen):
    skin = POSTER_SETTINGS_R199_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        current = _load_home_appearance()
        tmdb = load_tmdb_settings()
        self.index = 0
        self.skinChoices = [("skin2_dark", "Skin 2 — Default")]
        self.contentChoices = [("popular_movies", "Popular Show"),("popular_series", "Popular TV Shows"),("trending_movies", "Movies You Might Like"),("trending_series", "TV Shows You Might Like")]
        self.backdropChoices = [("w780", "780px (Default)"),("w1920", "1920px"),("original", "Original")]
        self.displayChoices = [("none", "Default"),("netflix", "Netflix"),("prime", "Prime Video"),("both", "Netflix + Prime")]
        self.posterStyleChoices = [("original", "Original"),("circle", "Circle Poster")]
        self.resolutionChoices = [("fhd", "FHD — 1920×1080 (Default)"),("wqhd", "High Resolution — WQHD 2560×1440")]
        self.homeSkin = current.get("skin", "skin2_dark")
        self.homeContent = current.get("content", "popular_movies")
        self.backdropQuality = tmdb.get("backdrop_quality", "w780")
        self.posterStyle = current.get("poster_style", "original")
        self.displayProfile = load_profile_preference()
        nf = bool(current.get("show_netflix_package", False)); pr = bool(current.get("show_prime_package", False))
        self.displayMode = "both" if nf and pr else ("netflix" if nf else ("prime" if pr else "none"))
        self["focus"] = Pixmap()
        self["title0"] = Label("SKIN STYLE"); self["title1"] = Label("HOME CONTENT"); self["title2"] = Label("POSTER VIEW"); self["title3"] = Label("DISPLAY OPTIONS")
        self["title4"] = Label("")
        self["title5"] = Label("")
        self["desc0"] = Label("Choose your preferred\nskin style")
        self["desc1"] = Label("Choose the content shown\non Home")
        self["desc2"] = Label("Choose poster style\nand size")
        self["desc3"] = Label("Show optional provider\npackages")
        self["desc4"] = Label("")
        self["desc5"] = Label("")
        for i in range(6): self["value%d"%i] = Label("")
        self["hint"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions","DirectionActions","ColorActions"], {"up": self.prevCard, "down": self.nextCard, "left": self.prevValue, "right": self.nextValue, "ok": self.save, "green": self.save, "cancel": self.close, "red": self.close}, -1)
        self.onLayoutFinish.append(self._refresh)

    def _pairs(self):
        return [(self.skinChoices,"homeSkin"),(self.contentChoices,"homeContent"),(self.posterStyleChoices,"posterStyle"),(self.displayChoices,"displayMode")]
    def _label(self, choices, value):
        for k,v in choices:
            if k == value: return v
        return choices[0][1]
    def _refresh(self):
        xs=[55,500,945,1390]
        try:
            if self.index < 4:
                self["focus"].show()
                self["focus"].instance.move(ePoint(sx(xs[self.index]),sy(300)))
            else:
                self["focus"].hide()
        except Exception:pass
        self["title4"].setText("")
        self["title5"].setText("")
        self["value0"].setText("‹  %s  ›" % self._label(self.skinChoices,self.homeSkin))
        self["value1"].setText("‹  %s  ›" % self._label(self.contentChoices,self.homeContent))
        self["value2"].setText("‹  %s  ›" % self._label(self.posterStyleChoices,self.posterStyle))
        self["value3"].setText("‹  %s  ›" % self._label(self.displayChoices,self.displayMode))
        self["value4"].setText("")
        self["value5"].setText("")
    def prevCard(self): self.index=(self.index-1)%4; self._refresh()
    def nextCard(self): self.index=(self.index+1)%4; self._refresh()
    def _step(self, delta):
        choices, attr = self._pairs()[self.index]; cur=getattr(self,attr); keys=[x[0] for x in choices]
        try:i=keys.index(cur)
        except Exception:i=0
        setattr(self,attr,keys[(i+delta)%len(keys)]); self._refresh()
    def prevValue(self): self._step(-1)
    def nextValue(self): self._step(1)
    def save(self):
        nf=self.displayMode in ("netflix","both"); pr=self.displayMode in ("prime","both")
        ok1=_save_home_appearance(self.homeSkin,self.homeContent,"none","none",nf,pr,poster_style=self.posterStyle)
        if ok1: self.session.open(MessageBox,"Skin, poster & display settings saved.",MessageBox.TYPE_INFO)
        else: self.session.open(MessageBox,"Unable to save appearance settings.",MessageBox.TYPE_ERROR)


class TiviMateUpdatePreviewCode(Screen):
    """Local visual preview of the Online Update design. No network/update actions."""
    skin = """
    <screen name="TiviMateUpdatePreviewCode" position="center,center" size="1200,800" flags="wfNoBorder" backgroundColor="transparent">
        <ePixmap position="0,0" size="1200,800" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/update_online_r470.jpg" alphatest="blend" zPosition="0" />
        <eLabel position="355,202" size="500,54" backgroundColor="#121b24" cornerRadius="10" zPosition="1" />
        <widget name="heading" position="355,205" size="500,48" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" halign="center" valign="center" zPosition="2" />
        <eLabel position="158,292" size="265,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="currentLabel" position="165,298" size="250,34" font="Regular;25" foregroundColor="#D7E8FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="425,292" size="330,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="currentValue" position="435,298" size="315,34" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="158,343" size="265,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="latestLabel" position="165,349" size="250,34" font="Regular;25" foregroundColor="#D7E8FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="425,343" size="330,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="latestValue" position="435,349" size="315,34" font="Regular;25" foregroundColor="#31B9FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="158,403" size="265,48" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="notesLabel" position="165,409" size="250,34" font="Regular;25" foregroundColor="#D7E8FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="425,403" size="700,125" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="notes" position="435,412" size="680,105" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" valign="top" zPosition="2" />
        <eLabel position="895,258" size="230,140" backgroundColor="#121b24" zPosition="5" />
        <eLabel position="895,398" size="230,135" backgroundColor="#121b24" zPosition="1" />
        <eLabel position="89,608" size="515,86" backgroundColor="#17324A" cornerRadius="18" zPosition="1" />
        <widget name="previewText" position="105,620" size="485,60" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" halign="center" valign="center" zPosition="2" />
        <eLabel position="640,608" size="495,86" backgroundColor="#1D252E" cornerRadius="18" zPosition="1" />
        <widget name="closeText" position="655,620" size="465,60" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" halign="center" valign="center" zPosition="2" />
        <widget name="updateFocus" position="89,608" size="515,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
        <widget name="cancelFocus" position="640,608" size="495,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self["heading"] = Label("")
        self["currentLabel"] = Label("")
        self["currentValue"] = Label("")
        self["latestLabel"] = Label("")
        self["latestValue"] = Label("")
        self["notesLabel"] = Label("")
        self["notes"] = Label("")
        self["previewText"] = Label("")
        self["closeText"] = Label("")
        self["updateFocus"] = Pixmap()
        self["cancelFocus"] = Pixmap()
        self._focusIndex = 0
        self.onLayoutFinish.append(self._refreshFocus)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "left": self._focusUpdate,
            "right": self._focusCancel,
            "ok": self.close,
            "green": self.close,
            "red": self.close,
            "cancel": self.close,
        }, -1)

    def _refreshFocus(self):
        if self._focusIndex == 0:
            self["updateFocus"].show()
            self["cancelFocus"].hide()
        else:
            self["updateFocus"].hide()
            self["cancelFocus"].show()

    def _focusUpdate(self):
        self._focusIndex = 0
        self._refreshFocus()

    def _focusCancel(self):
        self._focusIndex = 1
        self._refreshFocus()


class TiviMateUpdatePrompt(Screen):
    """Branded update confirmation: image + movable focus + OK only."""
    skin = """
    <screen name="TiviMateUpdatePrompt" position="center,center" size="1200,800" flags="wfNoBorder" backgroundColor="transparent">
        <ePixmap position="0,0" size="1200,800" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/update_online_r470.jpg" alphatest="blend" zPosition="0" />
        <widget name="updateFocus" position="89,608" size="515,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
        <widget name="cancelFocus" position="640,608" size="495,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
    </screen>
    """

    def __init__(self, session, candidate=None, timeout=None):
        Screen.__init__(self, session)
        self.candidate = candidate or {}
        self["updateFocus"] = Pixmap()
        self["cancelFocus"] = Pixmap()
        self._focusIndex = 0
        self.onLayoutFinish.append(self._refreshFocus)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "left": self._focusUpdate,
            "right": self._focusCancel,
            "ok": self._focusedOk,
            "cancel": self._cancel,
        }, -1)

    def _refreshFocus(self):
        if self._focusIndex == 0:
            self["updateFocus"].show()
            self["cancelFocus"].hide()
        else:
            self["updateFocus"].hide()
            self["cancelFocus"].show()

    def _focusUpdate(self):
        self._focusIndex = 0
        self._refreshFocus()

    def _focusCancel(self):
        self._focusIndex = 1
        self._refreshFocus()

    def _focusedOk(self):
        if self._focusIndex == 0:
            self._accept()
        else:
            self._cancel()

    def _accept(self):
        self.close(True)

    def _cancel(self):
        self.close(False)


class UpdateSettingsScreen(Screen, ConfigListScreen):
    """Settings and user-confirmed manual update flow for verified packages."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="UpdateSettingsScreen"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = _load_update_settings()
        self.autoCheck = ConfigSelection(default="on" if cfg.get("auto_check", True) else "off", choices=[
            ("on", "On"), ("off", "Off")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Automatic update check"), self.autoCheck)
        ], session=session)
        self["title"] = Label(tr("SOFTWARE UPDATES"))
        self["hint"] = Label(tr("Automatic checks only read a small verified update manifest. Press YELLOW to check now."))
        self["keys"] = Label(tr("GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "yellow": self.manualCheck, "ok": self.save,
            "red": self.close, "cancel": self.close
        }, -1)
        self._checkPending = None
        self._downloadPending = None
        self._candidate = None
        self._installProcess = None
        self._checkInProgress = False
        self._downloadInProgress = False
        self._checkTimer = eTimer()
        self._downloadTimer = eTimer()
        _connect_timer(self._checkTimer, self._pollCheck)
        _connect_timer(self._downloadTimer, self._pollDownload)
        self.onClose.append(self._stopTimers)

    def _stopTimers(self):
        for timer in (getattr(self, "_checkTimer", None), getattr(self, "_downloadTimer", None)):
            try:
                timer.stop()
            except Exception:
                pass

    def save(self):
        enabled = self.autoCheck.value == "on"
        if _save_update_settings(enabled):
            state = "enabled" if enabled else "disabled"
            self["hint"].setText("Automatic update checks are %s. Press YELLOW to check now." % state)
            self.session.open(MessageBox, "Update settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save update settings.", MessageBox.TYPE_ERROR)

    def manualCheck(self):
        if self._checkInProgress or self._downloadInProgress or self._installProcess:
            return
        self._checkInProgress = True
        self._checkPending = None
        self["hint"].setText(tr("Checking for a verified update..."))

        def worker():
            try:
                self._checkPending = check_for_update()
            except Exception:
                self._checkPending = {}

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateCheck")
            thread.daemon = True
            thread.start()
            self._checkTimer.start(200, True)
        except Exception:
            self._checkPending = {}
            self._pollCheck()

    def _pollCheck(self):
        if self._checkPending is None:
            try:
                self._checkTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._checkPending or {}
        self._checkPending = None
        self._checkInProgress = False
        if not result.get("available"):
            if result.get("reason") == "current":
                self["hint"].setText(tr("TiViMate E2 is already up to date."))
                self.session.open(MessageBox, "No update is available. TiViMate E2 is already up to date.", MessageBox.TYPE_INFO)
            else:
                self["hint"].setText(tr("Unable to verify updates right now. You can try again later."))
                self.session.open(MessageBox, "Unable to check for updates. Please try again later.", MessageBox.TYPE_ERROR)
            return
        self._candidate = result
        self.session.openWithCallback(self._confirmUpdate, TiviMateUpdatePrompt, result)

    def _confirmUpdate(self, answer):
        if not answer or not self._candidate:
            return
        package = self._candidate.get("package")
        if not package:
            return
        self._downloadInProgress = True
        self._downloadPending = None
        self["hint"].setText("")

        def worker():
            self._downloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateDownload")
            thread.daemon = True
            thread.start()
            self._downloadTimer.start(200, True)
        except Exception:
            self._downloadPending = {"ok": False, "message": "Unable to start download"}
            self._pollDownload()

    def _pollDownload(self):
        if self._downloadPending is None:
            try:
                self._downloadTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._downloadPending or {}
        self._downloadPending = None
        self._downloadInProgress = False
        if not result.get("ok"):
            self["hint"].setText(tr("Update download failed."))
            self.session.open(MessageBox, "Update download failed.\n\n%s" % (result.get("message") or "Please try again later."), MessageBox.TYPE_ERROR); return
        command = install_command(result)
        if not command:
            self["hint"].setText(tr("The verified package could not be installed."))
            self.session.open(MessageBox, "The verified update package could not be installed.", MessageBox.TYPE_ERROR); return
        self["hint"].setText(tr("Installing TiViMate E2 update..."))
        try:
            process = eConsoleAppContainer()
            self._installProcess = process
            try:
                process.appClosed.append(self._installFinished)
            except Exception:
                process.appClosed.get().append(self._installFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            self["hint"].setText(tr("Unable to start the update installer."))
            self.session.open(MessageBox, "Unable to start the update installer.", MessageBox.TYPE_ERROR)

    def _installFinished(self, status):
        self._installProcess = None
        if status == 0:
            self["hint"].setText(tr("Update completed. Restart the Enigma2 GUI to use the new version."))
            self.session.open(MessageBox, "TiViMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.", MessageBox.TYPE_INFO)
        else:
            self["hint"].setText(tr("The update installer returned an error."))
            self.session.open(MessageBox, "The update installer returned an error. Your current installation has not been changed.", MessageBox.TYPE_ERROR)


SUBTITLE_LANGUAGE_CLEAN_BLUE_SKIN = r"""<screen name="SubDLSubtitleLanguageSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#070A0E">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#070A0E" zPosition="0"/>
    <eLabel position="0,0" size="1920,96" backgroundColor="#0A0E13" zPosition="1"/>
    <widget name="cacheBrand" position="42,13" size="300,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" scale="1" zPosition="4"/>

    <eLabel position="520,0" size="150,96" text="Search" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="670,0" size="130,96" text="Home" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="800,0" size="120,96" text="Live" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="920,0" size="140,96" text="Movies" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1060,0" size="170,96" text="TV Shows" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1230,0" size="160,96" text="Settings" font="Regular;22" foregroundColor="#8B6CFF" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1260,82" size="100,3" backgroundColor="#8B6CFF" zPosition="4"/>

    <eLabel position="80,158" size="330,42" text="CONTROL CENTER" font="Regular;30" foregroundColor="#F4F7FA" backgroundColor="#070A0E" zPosition="3"/>
    <eLabel position="80,220" size="330,2" backgroundColor="#312B46" zPosition="2"/>
    <eLabel position="70,250" size="350,118" backgroundColor="#0D1218" borderColor="#403754" borderWidth="1" cornerRadius="12" zPosition="2"/>
    <eLabel position="92,270" size="300,34" text="IMAGE CACHE" font="Regular;27" foregroundColor="#E6E1F8" backgroundColor="#0D1218" zPosition="3"/>
    <eLabel position="92,312" size="300,42" text="Manage image cache and location" font="Regular;18" foregroundColor="#9EA8B4" backgroundColor="#0D1218" zPosition="3"/>
    <eLabel position="70,382" size="350,118" backgroundColor="#171427" borderColor="#6F5AA8" borderWidth="2" cornerRadius="12" zPosition="2"/>
    <eLabel position="92,402" size="300,34" text="SUBTITLE LANGUAGE" font="Regular;25" foregroundColor="#B9A9FF" backgroundColor="#171427" zPosition="3"/>
    <eLabel position="92,444" size="300,42" text="Language and subtitle font size" font="Regular;18" foregroundColor="#B9C1CC" backgroundColor="#171427" zPosition="3"/>

    <widget name="title" position="480,165" size="1080,50" font="Regular;36" foregroundColor="#F4F7FA" transparent="1" zPosition="4"/>
    <eLabel position="480,230" size="1240,2" backgroundColor="#312B46" zPosition="2"/>

    <eLabel position="480,270" size="1240,500" backgroundColor="#0D1218" borderColor="#6F5AA8" borderWidth="2" cornerRadius="12" zPosition="1"/>
    <widget name="config" position="505,292" size="1190,450" font="Regular;25" itemHeight="82" scrollbarMode="showOnDemand"
        foregroundColor="#E8EDF2" backgroundColor="#0D1218"
        selectionForegroundColor="#FFFFFF" selectionBackgroundColor="#51409B"
        transparent="0" zPosition="4"/>

    <widget name="hint" position="500,800" size="1180,58" font="Regular;20" foregroundColor="#AEB9C4" transparent="1" halign="center" valign="center" zPosition="4"/>
    <eLabel position="480,862" size="1240,2" backgroundColor="#312B46" zPosition="2"/>

    <eLabel position="630,900" size="420,76" text="GREEN  SAVE &amp; APPLY" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#5C45C9" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="1080,900" size="420,76" text="RED  BACK" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#563C6B" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <widget name="keys" position="0,1035" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


class SubDLSubtitleLanguageSettings(Screen, ConfigListScreen):
    """Preferred subtitle language for server tracks, SubsSupport fallback and SubDL."""
    skin = SUBTITLE_LANGUAGE_CLEAN_BLUE_SKIN

    def __init__(self, session, focus_font=False):
        Screen.__init__(self, session)
        self.session = session
        self._focus_font = bool(focus_font)
        self["cacheBrand"] = Pixmap()
        current = load_subdl_settings()
        # LANGUAGE_CHOICES is stored as (display name, ISO code), while
        # ConfigSelection expects (value, display label). Keep the ISO code as
        # the single persisted value used by server + all external providers.
        self.targetLanguage = ConfigSelection(
            default=current.get("language", "ar"),
            choices=[(code, name) for name, code in SUBDL_LANGUAGE_CHOICES],
        )
        try:
            native_font = getattr(getattr(config, "subtitles", None), "subtitle_fontsize", None)
            subtitle_font_default = str(getattr(native_font, "value", "34") or "34")
        except Exception:
            subtitle_font_default = "34"
        common_font_sizes = [str(x) for x in range(16, 50, 2)]
        if subtitle_font_default not in common_font_sizes:
            subtitle_font_default = "34"
        self.subtitleFont = ConfigSelection(
            default=subtitle_font_default,
            choices=[(v, "%s px" % v) for v in common_font_sizes],
        )
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Preferred Subtitle Language"), self.targetLanguage),
            getConfigListEntry(tr("Subtitle Font Size"), self.subtitleFont),
        ], session=session)
        if self._focus_font:
            try:
                self["config"].setCurrentIndex(1)
            except Exception:
                pass
        self["title"] = Label(tr("SUBTITLE LANGUAGE"))
        self["hint"] = Label(tr(
            "This language is used for automatic server subtitles first, then SubsSupport fallback, and for manual SubDL searches."
        ))
        self["keys"] = Label(tr("GREEN  SAVE    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close,
        }, -1)
        self["sectionNav"] = ActionMap(["DirectionActions"], {
            "up": self._sectionUp, "down": self._sectionDown,
        }, -2)

    def _sectionUp(self):
        try:
            if self["config"].getCurrentIndex() > 0:
                return ConfigListScreen.keyUp(self)
        except Exception:
            return ConfigListScreen.keyUp(self)
        self.session.open(ImageCacheSettings)

    def _sectionDown(self):
        return ConfigListScreen.keyDown(self)

    def _saveUnifiedSubtitleFont(self):
        value = str(self.subtitleFont.value)
        applied = False
        try:
            native = config.subtitles.subtitle_fontsize
            try:
                native.setValue(value)
            except Exception:
                native.value = value
            try:
                native.save()
            except Exception:
                pass
            applied = True
        except Exception:
            pass
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings
            subs = initSubsSettings()
            for section_name in ("external", "embedded"):
                try:
                    section = getattr(subs, section_name, None)
                    font = getattr(section, "font", None) if section is not None else None
                    setting = getattr(font, "size", None) if font is not None else None
                    if setting is None:
                        continue
                    try:
                        setting.setValue(value)
                    except Exception:
                        setting.value = value
                    try:
                        setting.save()
                    except Exception:
                        pass
                    applied = True
                except Exception:
                    pass
        except Exception:
            pass
        try:
            configfile.save()
        except Exception:
            pass
        return applied

    def save(self):
        try:
            current = load_subdl_settings()
            save_subdl_settings(
                current.get("api_key", ""),
                self.targetLanguage.value,
                current.get("kind", "standard"),
            )
            try:
                from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.subtitles import initSubsProSettings
                pro_settings = initSubsProSettings()
                for name in ("lang1", "lang2", "lang3"):
                    entry = getattr(pro_settings.search, name)
                    try:
                        entry.setValue(self.targetLanguage.value)
                    except Exception:
                        entry.value = self.targetLanguage.value
                    try:
                        entry.save()
                    except Exception:
                        pass
            except Exception:
                pass
            self._saveUnifiedSubtitleFont()
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save the SubDL subtitle language.", MessageBox.TYPE_ERROR, timeout=5)


WEB_ACCESS_SKIN = scale_skin(r'''<screen name="TiviMateE2WebAccess" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_web_blue.png" alphatest="blend" zPosition="0" />
    <ePixmap position="72,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="title" position="500,126" size="1320,58" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="subtitle" position="500,188" size="1320,34" font="Regular;22" foregroundColor="#56E5FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <ePixmap position="84,284" size="430,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/web_mobile_device.png" alphatest="blend" zPosition="3" />
    <widget name="leftTitle" position="92,794" size="414,42" font="Regular;30" foregroundColor="#48E4FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="leftHint" position="82,838" size="434,62" font="Regular;20" foregroundColor="#E5F2FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <widget name="qrTitle" position="610,264" size="420,42" font="Regular;30" foregroundColor="#53E7FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <eLabel position="626,326" size="388,388" backgroundColor="#FFFFFF" zPosition="3" />
    <widget name="qr" position="654,354" size="332,332" alphatest="blend" zPosition="5" />
    <widget name="qrHint" position="620,742" size="400,68" font="Regular;20" foregroundColor="#DCEBFA" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <eLabel position="1160,305" size="22,22" backgroundColor="#24E882" zPosition="4" />
    <widget name="status" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="addressLabel" position="1195,358" size="560,32" font="Regular;22" foregroundColor="#57E1FF" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="url" position="1195,416" size="560,54" font="Regular;29" foregroundColor="#71E4FF" backgroundColor="#00000000" transparent="1" zPosition="5" valign="center" />
    <widget name="help" position="1195,522" size="560,230" font="Regular;24" foregroundColor="#E5F2FF" backgroundColor="#00000000" transparent="1" valign="top" zPosition="5" />
    <widget name="hint" position="1195,788" size="560,60" font="Regular;21" foregroundColor="#82DFFF" backgroundColor="#00000000" transparent="1" zPosition="5" halign="left" valign="center" />
    <widget name="footer" position="560,932" size="1270,48" font="Regular;22" foregroundColor="#C9D8E8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
</screen>''')

class WebAccessScreen(Screen):
    skin = WEB_ACCESS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label("")
        self["subtitle"] = Label("")
        self["leftTitle"] = Label("Control your IPTV")
        self["leftHint"] = Label("Manage servers and playlists from your mobile phone or computer.")
        self["qrTitle"] = Label("SCAN QR CODE")
        self["qrHint"] = Label("Point your phone camera at the QR code")
        self["addressLabel"] = Label("Web Address")
        self["qr"] = Pixmap()
        self["status"] = Label("")
        self["url"] = Label("")
        self["help"] = Label("Manage servers from your phone:\n• Add / edit Xtream\n• Add / edit Stalker + MAC\n• M3U playlists\n• IPTV Finder and maintenance")
        self["hint"] = Label("")
        self["footer"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close, "ok": self.close, "red": self.close,
            "green": self.refreshAccess
        }, -1)

        try:
            from .storage import data_path
            self._qrPath = data_path("runtime", "web_access_qr.png")
        except Exception:
            self._qrPath = "/media/hdd/.tivimatee2-cache/runtime/web_access_qr.png" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/runtime/web_access_qr.png"
        self.onLayoutFinish.append(self.refreshAccess)

    def refreshAccess(self):
        try:
            from .web_manager import start_web_manager, web_manager_status
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get("ip") or "127.0.0.1")
            port = int(status.get("port") or 8088)
            running = bool(status.get("running"))
            url = "http://%s:%d" % (ip, port)
            self["status"].setText("Web Server: %s" % ("ON" if running else "OFF"))
            self["url"].setText(url)
            if running and ip not in ("127.0.0.1", "0.0.0.0"):
                from .web_qr import make_qr_png
                make_qr_png(url, self._qrPath, scale=9, border=4)
                try:
                    self["qr"].instance.setPixmap(LoadPixmap(self._qrPath))
                    self["qr"].show()
                except Exception:
                    pass
            else:
                self["hint"].setText("No LAN address detected. Connect the receiver to your network and press GREEN to refresh.")
        except Exception as error:
            self["status"].setText("Web Server: ERROR")
            self["url"].setText("")
            self["hint"].setText("Could not start Web Manager: %s" % error)



def _extract_xtream_expiry(reply):
    """Return Xtream expiry from common panel fields.

    Standard Xtream panels expose ``user_info.exp_date``.  Some compatible
    panels rename the field.  A present-but-empty/zero exp_date is treated as
    Unlimited, while a completely missing field stays unknown.
    """
    if not isinstance(reply, dict):
        return ""
    user = reply.get("user_info") if isinstance(reply.get("user_info"), dict) else {}
    keys = ("exp_date", "expiry", "expire", "expire_date", "expiration_date", "expiration", "end_date")
    for container in (user, reply):
        if not isinstance(container, dict):
            continue
        for key in keys:
            if key not in container:
                continue
            value = container.get(key)
            raw = str(value or "").strip()
            if raw and raw.lower() not in ("0", "none", "null", "false", "n/a", "-"):
                return raw
            # Standard panels use a null/0 exp_date for unlimited accounts.
            if key == "exp_date":
                return "Unlimited"
    return ""


def _xtream_expiry_is_past(value):
    raw = str(value or "").strip()
    if not raw or raw.lower() in ("unlimited", "never", "lifetime"):
        return False
    try:
        number = float(raw)
        if number > 100000000000:
            number /= 1000.0
        if number > 946684800:
            return number < time.time()
    except Exception:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(raw, fmt) < datetime.now()
        except Exception:
            pass
    return False


def _xtream_state_from_reply(reply):
    report = evaluate_reply("xtream", reply)
    user = reply.get("user_info") if isinstance(reply, dict) and isinstance(reply.get("user_info"), dict) else {}
    status = str(user.get("status") or "").strip().lower()
    auth = str(user.get("auth") if "auth" in user else "").strip().lower()
    expiry = _extract_xtream_expiry(reply)
    if status in ("expired", "disabled", "banned", "blocked", "inactive") or _xtream_expiry_is_past(expiry):
        state = "expired"
    elif auth in ("0", "false", "no"):
        state = "offline"
    else:
        state = report.get("state", "offline")
    return state, expiry


def _format_server_expiry(value):
    """Return a compact human-readable subscription expiry or em dash."""
    raw = str(value or "").strip()
    if not raw or raw.lower() in ("0", "none", "null", "false", "unknown", "n/a", "-"):
        return "—"
    if raw.lower() in ("unlimited", "never", "lifetime"):
        return "Unlimited"
    # Xtream normally returns Unix seconds.
    try:
        number = int(float(raw))
        if 946684800 <= number <= 4102444800:
            return datetime.fromtimestamp(number).strftime("%d/%m/%Y")
    except Exception:
        pass
    # Common Stalker / panel date formats.
    match = re.search(r"((?:19|20)\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", raw)
    if match:
        return "%02d/%02d/%04d" % (int(match.group(3)), int(match.group(2)), int(match.group(1)))
    match = re.search(r"(\d{1,2})[-/.](\d{1,2})[-/.]((?:19|20)\d{2})", raw)
    if match:
        return "%02d/%02d/%04d" % (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    return "—"

class ServerStatusList(MenuList):
    """MenuList that preserves source rows while drawing a local health dot.

    The source dictionary remains the first element of every row, so ServerManager
    keeps the same selection, scrolling, action-key and source-editing behaviour.
    """
    STATUS_PIXMAPS = {
        "online": os.path.join(PLUGIN_PATH, "skins/server/server_status_online_r123.png"),
        "busy": os.path.join(PLUGIN_PATH, "skins/server/server_status_busy_r123.png"),
        "checking": os.path.join(PLUGIN_PATH, "skins/server/server_status_checking_r123.png"),
        "offline": os.path.join(PLUGIN_PATH, "skins/server/server_status_offline_r123.png"),
        "expired": os.path.join(PLUGIN_PATH, "skins/server/server_status_offline_r123.png"),
    }
    TYPE_PIXMAPS = {
        "xtream": os.path.join(PLUGIN_PATH, "skins/server/web_xtream_icon.png"),
        "stalker": os.path.join(PLUGIN_PATH, "skins/server/web_stalker_icon.png"),
    }

    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 36))
            self.l.setItemHeight(88)
        except Exception:
            pass
        self._pixmaps = {}
        for name, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._pixmaps[name] = None
        self._type_pixmaps = {}
        for name, path in self.TYPE_PIXMAPS.items():
            try:
                self._type_pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._type_pixmaps[name] = None

    def setSources(self, sources, states, expiries=None):
        expiries = expiries or {}
        rows = [self._makeRow(
            source,
            states.get(self._key(source), "checking"),
            expiries.get(self._key(source), "")
        ) for source in sources]
        self.setList(rows)

    @staticmethod
    def _display_name(source):
        source = source or {}
        name = str(source.get("name") or "").strip()
        url = str(source.get("url") or source.get("portal") or "").strip()
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    @staticmethod
    def _key(source):
        endpoint = source.get("url") or source.get("host") or source.get("server") or source.get("portal") or ""
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("name", ""), endpoint, source.get("username", ""))

    def _makeRow(self, source, state, expiry=""):
        source = source or {}
        source_type = str(source.get("type") or "").lower()
        name = self._display_name(source)
        alias = str(source.get("mac_alias") or "").strip()
        if alias and alias.lower() not in name.lower():
            name = "%s • %s" % (name, alias)

        title = "%s  •  %s" % (name, source_type.upper() if source_type else "SERVER")
        expiry_text = "Expire: %s" % _format_server_expiry(expiry)
        status_pixmap = self._pixmaps.get(state) or self._pixmaps.get("checking")
        type_pixmap = self._type_pixmaps.get(source_type)

        row = [
            source,
            MultiContentEntryPixmapAlphaBlend(
                pos=(0, 8), size=(1000, 78),
                png=LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server/server_row_r67.png"))
            ),
        ]
        if type_pixmap is not None:
            row.append(MultiContentEntryPixmapAlphaBlend(
                pos=(22, 16), size=(56, 56), png=type_pixmap
            ))

        row.extend([
            MultiContentEntryText(
                pos=(100, 0), size=(590, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=title,
                color=0x00F5F8FC, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(700, 0), size=(300, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=expiry_text,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(1075, 28), size=(32, 32), png=status_pixmap
            ),
        ])
        return row



class LiveServerChoiceList(MenuList):
    STATUS_PIXMAPS = {
        "active": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_green.png"),
        "unknown": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_yellow.png"),
        "inactive": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "blocked": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "expired": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "unchecked": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_grey.png"),
    }

    def __init__(self, rows=None):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 24))
            self.l.setItemHeight(78)
        except Exception:
            pass
        self._pixmaps = {}
        for state, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[state] = LoadPixmap(path)
            except Exception:
                self._pixmaps[state] = None
        try:
            self._type_pixmap_xtream = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server/live_switch_xtream.png"))
        except Exception:
            self._type_pixmap_xtream = None
        try:
            self._type_pixmap_stalker = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server/live_switch_stalker.png"))
        except Exception:
            self._type_pixmap_stalker = None
        self.setRows(rows or [])

    @staticmethod
    def _display_name(source):
        source = source or {}
        name = str(source.get("name") or "").strip()
        url = str(source.get("url") or source.get("portal") or "").strip()
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    @staticmethod
    def _format_estalker_expiry(value):
        raw = str(value or "").strip()
        if not raw:
            return ""
        if raw.lower() in ("unknown", "none", "null", "0", "-"):
            return "Unknown"
        if raw.lower() in ("unlimited", "never", "lifetime"):
            return "Unlimited"
        try:
            number = int(float(raw))
            # EStalker treats bare numeric expiry as unknown in its list.
            if number > 0:
                return "Unknown"
        except Exception:
            pass
        return raw

    @staticmethod
    def _parse_estalker_expiry(value):
        raw = str(value or "").strip()
        if not raw:
            return None
        for fmt in (
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d",
            "%d/%m/%Y", "%m/%d/%Y",
            "%B %d, %Y, %I:%M %p", "%B %d, %Y"
        ):
            try:
                return datetime.strptime(raw, fmt)
            except Exception:
                pass
        return None

    def _estalker_row_info(self, source):
        source = source or {}
        stype = str(source.get("type") or "").lower()
        name = self._display_name(source)
        mac = str(source.get("mac") or "").strip().upper()
        expiry = str(source.get("_last_expiry") or "").strip()
        status = str(source.get("_last_status") or "").strip().lower()
        blocked = str(source.get("_last_blocked") or "0")
        portal = str(source.get("portal") or source.get("url") or "")

        # Xtream status is based on the last real API probe, not just reachability.
        if stype == "xtream":
            xt_expiry = str(source.get("_last_expiry") or source.get("expiry") or source.get("exp_date") or "").strip()
            display_expiry = _format_server_expiry(xt_expiry)
            if str(xt_expiry).lower() in ("unlimited", "never", "lifetime"):
                display_expiry = "Unlimited"
            elif display_expiry == "—":
                display_expiry = "Unknown"

            if status == "expired" or _xtream_expiry_is_past(xt_expiry):
                return {
                    "type": "xtream", "name": name, "mac": "", "expiry": display_expiry,
                    "message": "EXPIRED", "led": "expired"
                }
            if status == "busy":
                return {
                    "type": "xtream", "name": name, "mac": "", "expiry": display_expiry,
                    "message": "BUSY", "led": "unknown"
                }
            if status == "offline":
                return {
                    "type": "xtream", "name": name, "mac": "", "expiry": display_expiry,
                    "message": "OFFLINE", "led": "inactive"
                }
            return {
                "type": "xtream", "name": name, "mac": "", "expiry": display_expiry,
                "message": "ONLINE", "led": "active"
            }

        # Stalker display state comes from one authoritative local helper.
        compat = {}
        if stype == "stalker":
            try:
                compat = get_stalker_account_state(source) or {}
            except Exception:
                compat = {}

            expiry = str(compat.get("expiry") or expiry or "").strip()
            blocked = str(compat.get("blocked") or blocked or "0")
            portal = str(compat.get("portal") or portal or "")
            if compat.get("status") not in (None, ""):
                status = str(compat.get("status"))

        expires = self._format_estalker_expiry(expiry)
        message = "Active"
        led = "active"

        parsed_date = self._parse_estalker_expiry(expiry)
        if parsed_date and parsed_date < datetime.now():
            message = "Expired"
            led = "expired"
        elif blocked == "1":
            message = "Blocked"
            led = "blocked"
        elif str(source.get("_last_status") or "").lower() == "offline":
            message = "Not active"
            led = "inactive"
        elif stype == "stalker" and not compat:
            message = "Unknown"
            led = "unknown"
        elif "stalker" not in portal.lower() and str(status) not in ("", "0", "None") and expiry:
            message = "Unknown"
            led = "unknown"

        return {
            "type": stype, "name": name, "mac": mac, "expiry": expires,
            "message": message, "led": led
        }

    def _row(self, source, selected_here=False):
        info = self._estalker_row_info(source)
        pixmap = self._pixmaps.get(info["led"]) or self._pixmaps.get("unchecked")
        selected_text = u"✓" if selected_here else ""

        # Compact neon layout used by the professional Live Server screen.
        status_color = 0x0067E89A
        if info["led"] == "unknown":
            status_color = 0x00FFD44A
        elif info["led"] in ("inactive", "blocked"):
            status_color = 0x00FF6B78
        elif info["led"] == "expired":
            status_color = 0x00FF6B78

        if info["type"] == "xtream":
            pill_text = "ONLINE"
            pill_color = 0x0067E89A
            msg = str(info.get("message") or "").upper()
            if msg == "BUSY":
                pill_text = "BUSY"
                pill_color = 0x00FFD44A
            elif msg in ("EXPIRED", "OFFLINE"):
                pill_text = "EXPIRED" if msg == "EXPIRED" else "OFFLINE"
                pill_color = 0x00FF6B78
            return [
                source,
                MultiContentEntryText(
                    pos=(8, 0), size=(28, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=selected_text, color=0x00FFD34A, color_sel=0x00FFD34A
                ),
                MultiContentEntryPixmapAlphaBlend(
                    pos=(42, 18), size=(40, 40), png=self._type_pixmap_xtream
                ),
                MultiContentEntryText(
                    pos=(94, 0), size=(300, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=info["name"], color=0x00F5F8FC, color_sel=0x00FFFFFF
                ),
                MultiContentEntryText(
                    pos=(405, 0), size=(185, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=info["expiry"], color=0x00D5DDE8, color_sel=0x00FFFFFF
                ),
                MultiContentEntryText(
                    pos=(600, 0), size=(120, 76), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=info["message"], color=status_color, color_sel=status_color
                ),
                MultiContentEntryPixmapAlphaBlend(
                    pos=(730, 27), size=(23, 24), png=pixmap
                ),
                MultiContentEntryText(
                    pos=(770, 12), size=(185, 52), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                    text=pill_text, color=pill_color, color_sel=pill_color
                ),
            ]

        pill_text = "ONLINE"
        pill_color = 0x0067E89A
        msg = str(info.get("message") or "").lower()
        if msg in ("unknown", "busy"):
            pill_text = "BUSY"
            pill_color = 0x00FFD44A
        elif msg in ("expired", "blocked", "not active", "offline"):
            pill_text = "EXPIRED" if msg == "expired" else "OFFLINE"
            pill_color = 0x00FF6B78

        return [
            source,
            MultiContentEntryText(
                pos=(8, 0), size=(28, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=selected_text, color=0x00FFD34A, color_sel=0x00FFD34A
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(42, 18), size=(40, 40), png=self._type_pixmap_stalker
            ),
            MultiContentEntryText(
                pos=(94, 5), size=(300, 32), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["name"], color=0x00F5F8FC, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(94, 38), size=(300, 29), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["mac"], color=0x008FA8C0, color_sel=0x00BFD7EA
            ),
            MultiContentEntryText(
                pos=(405, 0), size=(185, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["expiry"], color=0x00D5DDE8, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(600, 0), size=(120, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=info["message"], color=status_color, color_sel=status_color
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(730, 27), size=(23, 24), png=pixmap
            ),
            MultiContentEntryText(
                pos=(770, 12), size=(185, 52), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=pill_text, color=pill_color, color_sel=pill_color
            ),
        ]

    def setRows(self, rows):
        self.setList([self._row(source, selected) for source, selected in rows])


class LiveServerChoiceScreen(Screen):
    skin = """
    <screen name="LiveServerChoiceScreen" position="center,center" size="1540,820"
            title="Switch Live server" backgroundColor="#050D18">

        <!-- outer glow / frame -->
        <eLabel position="0,0" size="1540,820" backgroundColor="#07111F" zPosition="0" />
        <eLabel position="2,2" size="1536,816" backgroundColor="#0A1A2D" zPosition="1" />

        <!-- header -->
        <eLabel position="26,24" size="1018,112" backgroundColor="#081522" zPosition="2" />
        <widget name="title" position="62,42" size="720,48" font="Regular;36"
                foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="subtitle" position="62,92" size="920,28" font="Regular;20"
                foregroundColor="#9FB5C9" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <eLabel position="28,134" size="1014,2" backgroundColor="#148CFF" zPosition="4" />

        <!-- left server card -->
        <eLabel position="26,150" size="1018,592" backgroundColor="#071522" zPosition="2" />
        <eLabel position="42,162" size="986,52" backgroundColor="#0A1D31" zPosition="3" />
        <widget name="columns" position="66,172" size="930,32" font="Regular;19"
                foregroundColor="#A9BDD0" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="servers" position="48,220" size="978,468"
                backgroundColor="#071522" backgroundColorSelected="#12345A"
                foregroundColor="#FFFFFF" foregroundColorSelected="#FFFFFF"
                itemHeight="78" scrollbarMode="showOnDemand"
                itemCornerRadius="10" itemCornerRadiusSelected="10" zPosition="5" />

        <!-- footer controls -->
        <eLabel position="42,700" size="986,1" backgroundColor="#173451" zPosition="4" />
        <widget name="hint" position="62,710" size="940,28" font="Regular;18"
                foregroundColor="#D8E6F2" backgroundColor="#00000000" transparent="1" zPosition="5" />

        <!-- right web QR card -->
        <eLabel position="1064,24" size="450,718" backgroundColor="#071522" zPosition="2" />
        <eLabel position="1066,26" size="446,714" backgroundColor="#08192A" zPosition="3" />
        <widget name="qrTitle" position="1100,62" size="380,34" font="Regular;25"
                foregroundColor="#48CFFF" backgroundColor="#00000000" transparent="1"
                halign="center" zPosition="5" />
        <widget name="qrSubtitle" position="1100,102" size="380,28" font="Regular;18"
                foregroundColor="#DCEAF5" backgroundColor="#00000000" transparent="1"
                halign="center" zPosition="5" />

        <eLabel position="1121,156" size="338,338" backgroundColor="#FFFFFF" zPosition="4" />
        <widget name="qr" position="1141,176" size="298,298" alphatest="blend" zPosition="6" />

        <eLabel position="1110,522" size="18,18" backgroundColor="#24E882" zPosition="5" />
        <widget name="webStatus" position="1140,510" size="330,40" font="Regular;22"
                foregroundColor="#67E89A" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="webUrl" position="1094,560" size="390,62" font="Regular;20"
                foregroundColor="#70DFFF" backgroundColor="#00000000" transparent="1"
                halign="center" valign="center" zPosition="5" />
        <widget name="webHint" position="1100,632" size="380,58" font="Regular;17"
                foregroundColor="#9FB5C9" backgroundColor="#00000000" transparent="1"
                halign="center" valign="center" zPosition="5" />

        <!-- clock -->
        <widget name="clock" position="1198,758" size="286,34" font="Regular;27"
                foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1"
                halign="right" zPosition="5" />
        <widget name="date" position="1120,792" size="364,22" font="Regular;17"
                foregroundColor="#91A8BB" backgroundColor="#00000000" transparent="1"
                halign="right" zPosition="5" />
    </screen>
    """

    def __init__(self, session, rows):
        Screen.__init__(self, session)
        self["title"] = Label("")
        self["subtitle"] = Label("")
        self["columns"] = Label("SERVER NAME                         EXPIRY                 STATUS                    ONLINE")
        self._serverRows = [(dict(source), bool(selected)) for source, selected in (rows or [])]
        self["servers"] = LiveServerChoiceList(self._serverRows)
        self["hint"] = Label("")

        self["qrTitle"] = Label("SCAN TO CONNECT")
        self["qrSubtitle"] = Label("WEB SERVER")
        self["qr"] = Pixmap()
        self["webStatus"] = Label("Web server: STARTING")
        self["webUrl"] = Label("")
        self["webHint"] = Label("Phone and receiver must be on the same local network.")
        self["clock"] = Label("")
        self["date"] = Label("")


        try:
            from .storage import data_path
            self._qrPath = data_path("runtime", "tivimatee2_live_server_qr.png")
        except Exception:
            self._qrPath = "/media/hdd/.tivimatee2-cache/runtime/tivimatee2_live_server_qr.png" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/runtime/tivimatee2_live_server_qr.png"
        self._clockTimer = eTimer()
        _connect_timer(self._clockTimer, self._refreshClock)
        self._statusProbeTimer = eTimer()
        _connect_timer(self._statusProbeTimer, self._finishServerProbe)
        self._statusProbeResult = None
        self._statusProbeClosed = False

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.ok,
                "cancel": self.close,
                "up": self["servers"].up,
                "down": self["servers"].down,
                "pageUp": self["servers"].pageUp,
                "pageDown": self["servers"].pageDown,
                "red": self.deleteCurrent,
                "yellow": self.ok,
                "blue": self.testCurrent,
            }, -1
        )

        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._cleanupProfessionalUI)

    def _layoutReady(self):
        self._refreshClock()
        try:
            self._clockTimer.start(30000, False)
        except Exception:
            pass
        self._refreshWebCard()
        self._startServerProbe()

    def _refreshClock(self):
        try:
            now = datetime.now()
            self["clock"].setText(now.strftime("%I:%M %p").lstrip("0"))
            self["date"].setText(now.strftime("%d %B %Y"))
        except Exception:
            pass

    def _refreshWebCard(self):
        try:
            from .web_manager import start_web_manager, web_manager_status
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get("ip") or "127.0.0.1")
            port = int(status.get("port") or 8088)
            running = bool(status.get("running"))
            url = "http://%s:%d" % (ip, port)

            self["webStatus"].setText("Web server %s" % ("ON" if running else "OFF"))
            self["webUrl"].setText(url if running else "")

            if running and ip not in ("127.0.0.1", "0.0.0.0"):
                from .web_qr import make_qr_png
                folder = os.path.dirname(self._qrPath)
                if folder and not os.path.isdir(folder):
                    os.makedirs(folder)
                make_qr_png(url, self._qrPath, scale=8, border=4)
                try:
                    if self["qr"].instance:
                        self["qr"].instance.setPixmap(LoadPixmap(self._qrPath))
                    self["qr"].show()
                except Exception:
                    pass
            else:
                self["webHint"].setText("Connect the receiver to LAN/Wi-Fi to enable QR access.")
        except Exception:
            self["webStatus"].setText("Web server OFF")
            self["webUrl"].setText("")
            self["webHint"].setText("Web Manager is unavailable on this receiver.")

    def _startServerProbe(self):
        if self._statusProbeClosed or not self._serverRows:
            return
        rows = [(dict(source), selected) for source, selected in self._serverRows]

        def worker():
            updated = []
            for source, selected in rows:
                stype = str(source.get("type") or "").lower()
                try:
                    if stype == "xtream":
                        reply = XtreamClient(source).test()
                        state, expiry = _xtream_state_from_reply(reply)
                    elif stype == "stalker":
                        reply = StalkerClient(source).test()
                        state = "online" if isinstance(reply, dict) and reply.get("ok") else "offline"
                        expiry = str(reply.get("expiry") or "") if isinstance(reply, dict) else ""
                        if _xtream_expiry_is_past(expiry):
                            state = "expired"
                    else:
                        reply = get_source_client(source).test()
                        state = "online" if reply else "offline"
                        expiry = ""
                except Exception:
                    state, expiry = "offline", ""
                source["_last_status"] = state
                source["_last_status_at"] = int(time.time())
                if expiry:
                    source["_last_expiry"] = str(expiry)
                updated.append((source, selected))
            self._statusProbeResult = updated

        thread = threading.Thread(target=worker, name="TiviMateLiveServerStatus")
        thread.daemon = True
        thread.start()
        try:
            self._statusProbeTimer.start(120, False)
        except Exception:
            pass

    def _finishServerProbe(self):
        if self._statusProbeClosed:
            return
        result = self._statusProbeResult
        if result is None:
            try:
                self._statusProbeTimer.start(120, False)
            except Exception:
                pass
            return
        self._statusProbeResult = None
        self._serverRows = result
        try:
            self["servers"].setRows(result)
        except Exception:
            pass
        try:
            saved = list(get_sources() or [])
            for new_source, _selected in result:
                new_key = _source_identity(new_source)
                for idx, old_source in enumerate(saved):
                    if _source_identity(old_source) == new_key:
                        saved[idx].update({
                            "_last_status": new_source.get("_last_status", ""),
                            "_last_status_at": new_source.get("_last_status_at", 0),
                        })
                        if new_source.get("_last_expiry"):
                            saved[idx]["_last_expiry"] = new_source.get("_last_expiry")
                        break
            set_sources(saved)
        except Exception:
            pass
        self["hint"].setText("OK  Select        RED  Delete        YELLOW  Switch server        BLUE  Test server        EXIT  Close")

    def _cleanupProfessionalUI(self):
        self._statusProbeClosed = True
        try:
            self._statusProbeTimer.stop()
        except Exception:
            pass
        try:
            self._clockTimer.stop()
        except Exception:
            pass
        try:
            if os.path.exists(self._qrPath):
                os.remove(self._qrPath)
        except Exception:
            pass

    def _currentSource(self):
        row = self["servers"].getCurrent()
        return row[0] if row and isinstance(row[0], dict) else None

    def deleteCurrent(self):
        source = self._currentSource()
        if not source:
            return
        self.close(("delete", dict(source)))

    def testCurrent(self):
        source = self._currentSource()
        if not source:
            return
        self.close(("test", dict(source)))

    def ok(self):
        row = self["servers"].getCurrent()
        source = row[0] if row else None
        self.close(dict(source) if isinstance(source, dict) else None)



BACKUP_SCHEMA_VERSION = 1
BACKUP_FOLDER = data_path("backups")

_BACKUP_FILE_GROUPS = {
    "filters": [
        data_path("category_filters.json"),
        data_path("stalker_hidden.json"),
        data_path("xtream_hidden.json"),
        data_path("stalker_pin.json"),
        data_path("xtream_pin.json"),
    ],
    "favorites": [data_path("favorites.json")],
    "app_settings": [
        data_path("channel_settings.json"), data_path("live_source.json"),
        data_path("home_appearance.json"), data_path("update_settings.json"),
        data_path("active_source.json"), data_path("language.json"),
        data_path("tmdb.json"), data_path("cache_settings.json"),
        data_path("recording.json"), data_path("subdl.json"),
        data_path("backup_auto_settings.json"),
    ],
    "continue": [data_path("resume.json")],
    "player": [
        data_path("player.json"), data_path("player_preferences.json"),
        data_path("xtream_service_types.json"), data_path("stalker_service_types.json"),
    ],
}


def _backup_read_file(path):
    try:
        if not os.path.exists(path):
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            raw = handle.read()
        try:
            return {"format": "json", "value": json.loads(raw)}
        except Exception:
            return {"format": "text", "value": raw}
    except Exception:
        return None


def _backup_write_file(path, record):
    if not isinstance(record, dict):
        return False
    try:
        ensure_dir(os.path.dirname(path))
        tmp = path + ".restore.tmp"
        if record.get("format") == "json":
            raw = json.dumps(record.get("value"), ensure_ascii=False, indent=2, sort_keys=True)
        else:
            raw = str(record.get("value") or "")
        with open_text(tmp, "w", encoding="utf-8") as handle:
            handle.write(raw)
        atomic_replace(tmp, path)
        return True
    except Exception:
        return False


def _backup_group_count(group):
    try:
        if group == "servers":
            return len(get_sources() or [])
        if group == "filters":
            total = 0
            for path in _BACKUP_FILE_GROUPS["filters"]:
                data = load_json(path, {}) or {}
                if isinstance(data, dict):
                    for value in data.values():
                        if isinstance(value, dict):
                            for key in ("live", "vod", "series", "categories", "channels"):
                                rows = value.get(key)
                                if isinstance(rows, (list, tuple, set)):
                                    total += len(rows)
                        elif isinstance(value, list):
                            total += len(value)
            return total
        if group == "favorites":
            try:
                return int(favourites_count() or 0)
            except Exception:
                data = load_json(data_path("favorites.json"), {}) or {}
                return len(data.get("items") or []) if isinstance(data, dict) else 0
        if group == "continue":
            data = load_json(data_path("resume.json"), {}) or {}
            return len(data) if isinstance(data, dict) else 0
        if group in ("app_settings", "player"):
            return sum(1 for path in _BACKUP_FILE_GROUPS.get(group, []) if os.path.exists(path))
    except Exception:
        pass
    return 0


def _create_selected_backup(selected):
    ensure_dir(BACKUP_FOLDER)
    payload = {
        "schema": BACKUP_SCHEMA_VERSION,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "groups": {},
    }
    for group in selected:
        if group == "servers":
            payload["groups"][group] = {"servers": get_sources() or []}
            continue
        files = {}
        for path in _BACKUP_FILE_GROUPS.get(group, []):
            record = _backup_read_file(path)
            if record is not None:
                files[os.path.basename(path)] = record
        payload["groups"][group] = {"files": files}
    stamp = time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_FOLDER, "tivimatee2-backup-%s.json" % stamp)
    tmp = path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    atomic_replace(tmp, path)
    return path


def _latest_backup_file():
    try:
        rows = [os.path.join(BACKUP_FOLDER, name) for name in os.listdir(BACKUP_FOLDER)
                if name.startswith("tivimatee2-backup-") and name.endswith(".json")]
        rows = [path for path in rows if os.path.isfile(path)]
        return max(rows, key=os.path.getmtime) if rows else ""
    except Exception:
        return ""


def _restore_selected_backup(path, selected):
    with open_text(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle) or {}
    groups = payload.get("groups") or {}
    restored = []
    for group in selected:
        record = groups.get(group)
        if not isinstance(record, dict):
            continue
        if group == "servers":
            servers = record.get("servers") or []
            set_sources(servers)
            write_playlists(servers)
            restored.append(group)
            continue
        by_name = record.get("files") or {}
        for target in _BACKUP_FILE_GROUPS.get(group, []):
            saved = by_name.get(os.path.basename(target))
            if saved is not None:
                _backup_write_file(target, saved)
        restored.append(group)
    return restored




BACKUP_AUTO_SETTINGS_FILE = data_path("backup_auto_settings.json")

def _backup_files():
    try:
        ensure_dir(BACKUP_FOLDER)
        rows = [os.path.join(BACKUP_FOLDER, name) for name in os.listdir(BACKUP_FOLDER)
                if name.startswith("tivimatee2-backup-") and name.endswith(".json")]
        rows = [path for path in rows if os.path.isfile(path)]
        return sorted(rows, key=os.path.getmtime, reverse=True)
    except Exception:
        return []

def _backup_all_groups():
    return set(["servers", "filters", "favorites", "app_settings", "continue", "player"])

def _backup_auto_settings():
    data = load_json(BACKUP_AUTO_SETTINGS_FILE, {}) or {}
    return {
        "enabled": bool(data.get("enabled", False)),
        "last_run": int(data.get("last_run", 0) or 0),
    }

def _save_backup_auto_settings(settings):
    try:
        save_json(BACKUP_AUTO_SETTINGS_FILE, settings)
        return True
    except Exception:
        return False


def run_auto_backup_if_due(force=False):
    """Create the configured daily backup without requiring the Backup screen."""
    settings = _backup_auto_settings()
    if not settings.get("enabled"):
        return False
    now = int(time.time())
    last_run = int(settings.get("last_run", 0) or 0)
    if not force and last_run and (now - last_run) < 86400:
        return False
    try:
        _create_selected_backup(_backup_all_groups())
        settings["last_run"] = now
        _save_backup_auto_settings(settings)
        return True
    except Exception:
        return False

def _backup_validate_file(path):
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle) or {}
        return isinstance(payload, dict) and isinstance(payload.get("groups"), dict)
    except Exception:
        return False

def _backup_import_candidates():
    roots = ["/media/hdd", "/media/usb", "/media/mmc", "/media/net", "/tmp"]
    rows = []
    seen = set()
    for root in roots:
        if not os.path.isdir(root):
            continue
        try:
            for name in os.listdir(root):
                path = os.path.join(root, name)
                if os.path.isfile(path) and name.endswith(".json") and ("backup" in name.lower()):
                    if path not in seen and _backup_validate_file(path):
                        seen.add(path); rows.append(path)
        except Exception:
            pass
    return rows

BACKUP_DASHBOARD_R135_SKIN = r"""<screen name="TiviMateBackupRestore" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#01060B">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/backup_dashboard_r198.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus" position="234,292" size="476,344" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/backup_focus_r198.png" alphatest="blend" zPosition="10"/>
    <widget name="status0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


class BackupRestoreScreen(Screen):
    skin = scale_skin(BACKUP_DASHBOARD_R135_SKIN)

    POSITIONS = [(234,292), (729,292), (1225,292), (234,634), (729,634), (1225,634)]

    def __init__(self, session):
        Screen.__init__(self, session)
        self.index = 0
        self["focus"] = Pixmap()
        for i in range(6):
            self["status%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.openCurrent, "cancel": self.close,
                "left": self.left, "right": self.right,
                "up": self.up, "down": self.down,
                "green": self.openCurrent,
                "yellow": self.showInfo,
                "blue": self.manageBackups,
                "red": self.close,
            }, -1
        )
        self.onLayoutFinish.append(self._layoutReady)

    def _layoutReady(self):
        self._maybeAutoBackup()
        self.refresh()
        self._focus()

    def _focus(self):
        try:
            x, y = self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x), sy(y)))
            self["focus"].show()
        except Exception:
            pass

    def left(self):
        row = self.index // 3
        col = self.index % 3
        self.index = row * 3 + ((col - 1) % 3)
        self._focus()

    def right(self):
        row = self.index // 3
        col = self.index % 3
        self.index = row * 3 + ((col + 1) % 3)
        self._focus()

    def up(self):
        self.index = (self.index - 3) % 6
        self._focus()

    def down(self):
        self.index = (self.index + 3) % 6
        self._focus()

    def _backupCount(self):
        return len(_backup_files())

    def _latestText(self):
        path = _latest_backup_file()
        if not path:
            return "No backup yet"
        try:
            return "Last: " + time.strftime("%d %b %Y", time.localtime(os.path.getmtime(path)))
        except Exception:
            return "Backup available"

    def _externalStorageText(self):
        for path, label in (
            ("/media/usb", "USB Ready"),
            ("/media/hdd", "HDD Ready"),
            ("/media/mmc", "MMC Ready"),
            ("/media/net", "Network Ready"),
        ):
            try:
                if os.path.ismount(path) or os.path.isdir(path):
                    return label
            except Exception:
                pass
        return "No External Storage"

    def refresh(self):
        count = self._backupCount()
        auto = _backup_auto_settings()
        self["status0"].setText("%d Backup%s" % (count, "" if count == 1 else "s"))
        self["status1"].setText(self._latestText())
        self["status2"].setText("AUTO  %s" % ("ON" if auto.get("enabled") else "OFF"))
        self["status3"].setText("%d Backup%s" % (count, "" if count == 1 else "s"))
        self["status4"].setText(self._externalStorageText())
        self["status5"].setText("%d Available" % count)

    def openCurrent(self):
        actions = (
            self.createBackup,
            self.restoreBackup,
            self.toggleAutoBackup,
            self.manageBackups,
            self.importBackup,
            self.deleteBackup,
        )
        if 0 <= self.index < len(actions):
            actions[self.index]()

    def createBackup(self):
        try:
            path = _create_selected_backup(_backup_all_groups())
            auto = _backup_auto_settings()
            if auto.get("enabled"):
                auto["last_run"] = int(time.time())
                _save_backup_auto_settings(auto)
            self.refresh()
            self.session.open(MessageBox, "Backup created successfully.\n\n%s" % path, MessageBox.TYPE_INFO, timeout=7)
        except Exception as exc:
            self.session.open(MessageBox, "Backup failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def _backupChoices(self):
        choices = []
        for path in _backup_files():
            try:
                stamp = time.strftime("%d %b %Y  %H:%M", time.localtime(os.path.getmtime(path)))
            except Exception:
                stamp = os.path.basename(path)
            choices.append(("%s   •   %s" % (stamp, os.path.basename(path)), path))
        return choices

    def restoreBackup(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backup file is available yet.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._restoreSelected, ChoiceBox, title="RESTORE BACKUP", list=choices)

    def _restoreSelected(self, selected=None):
        if not selected:
            return
        path = selected[1]
        self.session.openWithCallback(
            lambda answer, p=path: self._restoreConfirmed(p) if answer else None,
            MessageBox,
            "Restore all available settings from:\n%s ?" % os.path.basename(path),
            MessageBox.TYPE_YESNO
        )

    def _restoreConfirmed(self, path):
        try:
            restored = _restore_selected_backup(path, _backup_all_groups())
            self.refresh()
            self.session.open(
                MessageBox,
                "Restore completed: %s\n\nRestart TiviMateE2 / Enigma2 to reload restored settings." %
                (", ".join(restored) if restored else "no matching sections"),
                MessageBox.TYPE_INFO, timeout=8
            )
        except Exception as exc:
            self.session.open(MessageBox, "Restore failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def toggleAutoBackup(self):
        settings = _backup_auto_settings()
        settings["enabled"] = not bool(settings.get("enabled"))
        if settings["enabled"] and not settings.get("last_run"):
            settings["last_run"] = 0
        _save_backup_auto_settings(settings)
        self._maybeAutoBackup(force=False)
        self.refresh()
        self.session.open(
            MessageBox,
            "Automatic daily backup is %s." % ("ON" if settings["enabled"] else "OFF"),
            MessageBox.TYPE_INFO, timeout=4
        )

    def _maybeAutoBackup(self, force=False):
        run_auto_backup_if_due(force=force)

    def manageBackups(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backups to manage.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._manageSelected, ChoiceBox, title="MANAGE BACKUPS", list=choices)

    def _manageSelected(self, selected=None):
        if not selected:
            return
        path = selected[1]
        choices = [
            ("RESTORE", ("restore", path)),
            ("INFO", ("info", path)),
            ("DELETE", ("delete", path)),
        ]
        self.session.openWithCallback(self._manageAction, ChoiceBox, title=os.path.basename(path), list=choices)

    def _manageAction(self, selected=None):
        if not selected:
            return
        action, path = selected[1]
        if action == "restore":
            self._restoreSelected(("restore", path))
        elif action == "delete":
            self._deletePathAsk(path)
        else:
            self._showBackupInfo(path)

    def _showBackupInfo(self, path):
        try:
            with open_text(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle) or {}
            groups = sorted((payload.get("groups") or {}).keys())
            created = payload.get("created_at") or "Unknown"
            text = "File: %s\nCreated: %s\nSections: %s" % (
                os.path.basename(path), created, ", ".join(groups) if groups else "None"
            )
        except Exception:
            text = "Unable to read backup information."
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=8)

    def importBackup(self):
        candidates = _backup_import_candidates()
        if not candidates:
            self.session.open(
                MessageBox,
                "No compatible backup JSON was found on HDD, USB, MMC, network storage or /tmp.",
                MessageBox.TYPE_INFO, timeout=6
            )
            return
        choices = [(os.path.basename(path) + "   •   " + os.path.dirname(path), path) for path in candidates]
        self.session.openWithCallback(self._importSelected, ChoiceBox, title="IMPORT BACKUP", list=choices)

    def _importSelected(self, selected=None):
        if not selected:
            return
        src = selected[1]
        if not _backup_validate_file(src):
            self.session.open(MessageBox, "Invalid backup file.", MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            ensure_dir(BACKUP_FOLDER)
            name = os.path.basename(src)
            if not name.startswith("tivimatee2-backup-"):
                name = "tivimatee2-backup-import-%s.json" % time.strftime("%Y%m%d-%H%M%S")
            dst = os.path.join(BACKUP_FOLDER, name)
            if os.path.exists(dst):
                dst = os.path.join(BACKUP_FOLDER, "tivimatee2-backup-import-%s.json" % time.strftime("%Y%m%d-%H%M%S"))
            with open(src, "rb") as rf:
                data = rf.read()
            tmp = dst + ".tmp"
            with open(tmp, "wb") as wf:
                wf.write(data)
            atomic_replace(tmp, dst)
            self.refresh()
            self.session.open(MessageBox, "Backup imported successfully.", MessageBox.TYPE_INFO, timeout=5)
        except Exception as exc:
            self.session.open(MessageBox, "Import failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=6)

    def deleteBackup(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backups to delete.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._deleteSelected, ChoiceBox, title="DELETE BACKUP", list=choices)

    def _deleteSelected(self, selected=None):
        if selected:
            self._deletePathAsk(selected[1])

    def _deletePathAsk(self, path):
        self.session.openWithCallback(
            lambda answer, p=path: self._deletePath(p) if answer else None,
            MessageBox,
            "Delete backup?\n%s" % os.path.basename(path),
            MessageBox.TYPE_YESNO
        )

    def _deletePath(self, path):
        try:
            os.remove(path)
            self.refresh()
            self.session.open(MessageBox, "Backup deleted.", MessageBox.TYPE_INFO, timeout=4)
        except Exception as exc:
            self.session.open(MessageBox, "Delete failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def showInfo(self):
        descriptions = [
            "Create a full backup of servers, filters, favourites, application settings, history and player preferences.",
            "Restore all matching settings from a selected backup file.",
            "Toggle automatic backup. When enabled, one backup is created per day when TiviMateE2 starts.",
            "Browse existing backups and restore, inspect or delete them.",
            "Import a compatible backup JSON from external storage.",
            "Choose and permanently delete an existing backup file.",
        ]
        self.session.open(MessageBox, descriptions[self.index], MessageBox.TYPE_INFO, timeout=7)



SUBTITLE_DASHBOARD_SKIN = r"""<screen name="SubtitleDashboard" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/subtitle_dashboard_r119.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus" position="53,278" size="895,310" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/subtitle_focus_r177.png" alphatest="blend" zPosition="8"/>
</screen>"""

class SubtitleDashboard(Screen):
    skin = SUBTITLE_DASHBOARD_SKIN
    POSITIONS=[(53,278),(972,278),(53,610),(972,610)]

    def __init__(self,session):
        Screen.__init__(self,session)
        self.index=0
        self["focus"]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "ok":self.openCurrent,"cancel":self.close,
            "left":self.left,"right":self.right,"up":self.up,"down":self.down,
        },-1)
        self.onLayoutFinish.append(self._focus)

    def _focus(self):
        try:
            x,y=self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:pass

    def left(self):
        self.index=self.index-1 if self.index%2 else self.index+1
        self._focus()
    def right(self):
        self.left()
    def up(self):
        self.index=(self.index-2)%4; self._focus()
    def down(self):
        self.index=(self.index+2)%4; self._focus()

    def openCurrent(self):
        if self.index==0:
            # IMPORT SUBTITLE tile now opens the existing Add API dashboard.
            self.openSubtitleApiManager(); return
        if self.index==1:
            self.session.open(SubDLSubtitleLanguageSettings); return
        if self.index==2:
            # IMAGE CACHE tile: open the actual image-cache settings screen.
            self.session.open(ImageCacheSettings); return
        if self.index==3:
            # EXTERNAL SUBTITLE tile opens the existing advanced font/style editor.
            self.openExternalSubtitleFont(); return

    def openSubtitleApiManager(self):
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import (
                TiviMateSubtitleApiManager, E2SubsSeeker, initTiviMateSettings
            )
            settings = initTiviMateSettings()
            seeker = E2SubsSeeker(self.session, settings.search, debug=False)
            self.session.open(TiviMateSubtitleApiManager, seeker)
        except Exception as exc:
            self.session.open(
                MessageBox,
                "Could not open Subtitle API settings.\n\n%s" % exc,
                MessageBox.TYPE_ERROR,
                timeout=7,
            )

    def importSubDLKey(self):
        try:
            value=_read_subdl_import_key()
            current=load_subdl_settings()
            save_subdl_settings(value,current.get("language","ar"),current.get("kind","standard"))
            removed=_remove_subdl_import_file()
            msg=("SubDL key imported and saved. Temporary key file removed." if removed else
                 "SubDL key imported and saved. Remove the imported key file manually to protect your key.")
            self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=6)
        except IOError:
            self.session.open(MessageBox,
                "Put one SubDL API key in key.txt on HDD, USB, MMC or /etc/enigma2, then select Import Subtitle.",
                MessageBox.TYPE_INFO,timeout=7)
        except ValueError:
            self.session.open(MessageBox,"Invalid SubDL key file. It must contain exactly one API key.",MessageBox.TYPE_ERROR,timeout=7)
        except Exception:
            self.session.open(MessageBox,"Could not import the SubDL key.",MessageBox.TYPE_ERROR,timeout=7)

    def openServerSubtitleFont(self):
        try:
            subtitles=getattr(config,"subtitles",None)
            setting=getattr(subtitles,"subtitle_fontsize",None) if subtitles is not None else None
            if setting is None: raise RuntimeError("native subtitle font setting unavailable")
            current=str(getattr(setting,"value","") or "")
            sizes=[]
            try:
                for entry in (getattr(setting,"choices",None) or []):
                    value=entry[0] if isinstance(entry,(tuple,list)) else entry
                    value=str(value)
                    if value.isdigit() and value not in sizes:sizes.append(value)
            except Exception:sizes=[]
            if not sizes:sizes=[str(x) for x in range(16,50,2)]
            choices=[("%s px%s"%(v,"  •  Current" if v==current else ""),v) for v in sizes]
            self.session.openWithCallback(self._serverFontSelected,ChoiceBox,title="SERVER SUBTITLE FONT",list=choices)
        except Exception:
            self.session.open(MessageBox,"Native Enigma2 subtitle font settings are not available on this image.",MessageBox.TYPE_ERROR,timeout=6)

    def _serverFontSelected(self,choice=None):
        if not choice:return
        try:
            value=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
            setting=config.subtitles.subtitle_fontsize
            setting.value=str(value)
            try:setting.save()
            except Exception:pass
            try:configfile.save()
            except Exception:pass
            self.session.open(MessageBox,"Server subtitle font size saved: %s"%value,MessageBox.TYPE_INFO,timeout=3)
        except Exception:
            self.session.open(MessageBox,"Could not save the native subtitle font size.",MessageBox.TYPE_ERROR,timeout=5)

    def openExternalSubtitleFont(self):
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import (
                initTiviMateSettings, TiviMateSetupExternal
            )
            settings = initTiviMateSettings()
            external = getattr(settings, "external", None)
            if external is None:
                raise RuntimeError("missing external subtitle settings")
            self.session.open(TiviMateSetupExternal, external)
        except Exception as exc:
            self.session.open(
                MessageBox,
                "Could not open External Subtitle font settings.\n\n%s" % exc,
                MessageBox.TYPE_ERROR,
                timeout=7,
            )



E2_IPTV_FINDER_SKIN = scale_skin(r"""<screen name="TiviMateE2IPTVFinder" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/finder/finder_final_approved.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="title" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="subtitle" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="brand" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterAll" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterStalker" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterXtream" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterM3U" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="daysBox" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="searchBox" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="summary" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="status" position="1190,154" size="520,60" font="Regular;22" foregroundColor="#DDE7F0" transparent="1" halign="right" valign="center" zPosition="18"/>
    <widget name="quickAnim" position="1725,154" size="65,60" font="Regular;28" foregroundColor="#67E89A" transparent="1" halign="center" valign="center" zPosition="19"/>
    <widget name="typeLogoTop" position="980,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="typeLogoXtream" position="910,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="typeLogoStalker" position="980,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="typeLogoM3U" position="1050,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="sourceLogoTop" position="1120,160" size="48,48" alphatest="blend" scale="1" zPosition="21"/>
    <widget name="pageNumbers" position="330,154" size="555,60" font="Regular;29" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="18"/>
    <widget name="tableHead" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailIcon" position="0,0" size="1,1" alphatest="blend"/>
    <widget name="detailType" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailOnline" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailUrl" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailInfo" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailAction" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="hint" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="list" position="286,225" size="1580,660" backgroundColor="#00101A" foregroundColor="#F4FAFF" transparent="1" scrollbarMode="showOnDemand" zPosition="10" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/finder/finder_row_focus_cyan.png" selectionBackgroundColor="#00101A" selectionForegroundColor="#FFFFFF"/>
    <widget name="fieldUrl" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="fieldUser" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="fieldPass" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="fieldMac" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
</screen>""")

class IPTVFinderResultList(MenuList):
    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 23))
            self.l.setFont(1, gFont("Regular", 21))
            self.l.setFont(2, gFont("Regular", 20))
            self.l.setItemHeight(66)
        except Exception:
            pass

        self._finder_type_pixmaps = {}
        for _kind, _rel in {
            "xtream": "skins/server/finder_xtream_round_small.png",
            "stalker": "skins/server/finder_stalker_round_small.png",
            "m3u": "skins/server/finder_m3u_round_small.png",
        }.items():
            try:
                self._finder_type_pixmaps[_kind] = LoadPixmap(os.path.join(PLUGIN_PATH, _rel))
            except Exception:
                self._finder_type_pixmaps[_kind] = None

        # Reuse the exact Live Server LED assets.
        self._finder_leds = {}
        for _state, _rel in {
            "online": "skins/live/estalker_led_green.png",
            "reachable": "skins/live/estalker_led_yellow.png",
            "offline": "skins/live/estalker_led_red.png",
            "unknown": "skins/live/estalker_led_grey.png",
        }.items():
            try:
                self._finder_leds[_state] = LoadPixmap(os.path.join(PLUGIN_PATH, _rel))
            except Exception:
                self._finder_leds[_state] = None

    def _rowMac(self, row):
        try:
            direct = str((row or {}).get("mac") or "").strip().upper().replace("-", ":")
            if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$", direct):
                return direct
            post = (row or {}).get("post") if isinstance((row or {}).get("post"), dict) else {}
            macs = post.get("macs") or []
            if not isinstance(macs, (list, tuple)):
                macs = [macs]
            for entry in macs:
                if isinstance(entry, dict):
                    value = str(entry.get("mac") or entry.get("value") or "")
                else:
                    value = str(entry or "")
                value = value.strip().upper().replace("-", ":")
                if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$", value):
                    return value
        except Exception:
            pass
        return ""

    def setResults(self, rows):
        self.setList([self._row(row) for row in (rows or [])])

    def _row(self, row):
        row = row or {}
        url = str(row.get("url") or "")
        kind = str(row.get("kind") or "").lower()
        raw_expiry = str(row.get("expiry") or row.get("_last_expiry") or "").strip()
        scan = str(row.get("_scan") or row.get("status") or "FOUND").strip().upper()

        try:
            expiry_txt = _format_server_expiry(raw_expiry)
        except Exception:
            expiry_txt = "—"
        if expiry_txt == "—":
            expiry_txt = "--"

        online = scan in ("VALID", "ONLINE", "OK", "WORKING")
        reachable = scan in ("REACHABLE", "PORTAL", "PORTAL ONLY")
        offline = scan in ("DEAD", "INVALID", "OFFLINE")
        if online:
            led = self._finder_leds.get("online")
            status_text = "ONLINE"
            status_color = 0x0067E89A
        elif reachable:
            led = self._finder_leds.get("reachable") or self._finder_leds.get("unknown")
            status_text = "PORTAL"
            status_color = 0x00F6B717
        elif offline:
            led = self._finder_leds.get("offline")
            status_text = "OFFLINE"
            status_color = 0x00FF6B78
        else:
            led = self._finder_leds.get("unknown")
            status_text = "--"
            status_color = 0x0098A6B8

        entries = [row]

        type_pix = self._finder_type_pixmaps.get(kind)
        if type_pix is not None:
            entries.append(MultiContentEntryPixmapAlphaBlend(
                pos=(16,19), size=(28,28), png=type_pix
            ))

        # Keep Stalker portal + MAC on the same row in separate clean columns.
        if kind == "stalker":
            mac_txt = self._rowMac(row)
            entries.append(MultiContentEntryText(
                pos=(54,0), size=(700,66), font=0,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=url[:72],
                color=0x00F4FAFF, color_sel=0x00FFFFFF
            ))
            entries.append(MultiContentEntryText(
                pos=(770,0), size=(330,66), font=1,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=("MAC  " + mac_txt) if mac_txt else "MAC  --",
                color=0x00D7F4FF, color_sel=0x00FFFFFF
            ))
            entries.append(MultiContentEntryText(
                pos=(1120,0), size=(225,66), font=1,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=expiry_txt,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ))
        else:
            entries.append(MultiContentEntryText(
                pos=(54,0), size=(790,66), font=0,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=((str(row.get("display_name") or "") + "  •  " + url) if row.get("display_name") else url)[:84],
                color=0x00F4FAFF, color_sel=0x00FFFFFF
            ))
            entries.append(MultiContentEntryText(
                pos=(875,0), size=(230,66), font=1,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=expiry_txt,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ))

        # FAST catalogue rows are not server probes.  Do not show the generic
        # ONLINE/OFFLINE indicator for them; it is meaningful only for real
        # Stalker/Xtream/traditional M3U checks.
        _post = row.get("post") if isinstance(row.get("post"), dict) else {}
        _finder_source = str(_post.get("finder_source") or row.get("finder_source") or "").strip().lower()
        _fast_service = str(row.get("fast_service") or "").strip().lower()
        _fast_sources = ("samsungtv", "xiaomitv", "xumotv", "xumo", "freetv", "localnow", "lgchannels", "roku", "tubitv", "vizio", "tclplus", "freelivesports")
        _is_fast_row = bool(
            _fast_service in _fast_sources or
            _finder_source in _fast_sources or
            row.get("samsung_group") or row.get("xiaomi_group") or
            url.lower().startswith("fastm3u://")
        )
        if not _is_fast_row:
            if led is not None:
                entries.append(MultiContentEntryPixmapAlphaBlend(
                    pos=(1370,21), size=(23,24), png=led
                ))
            entries.append(MultiContentEntryText(
                pos=(1404,0), size=(150,66), font=2,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=status_text,
                color=status_color, color_sel=status_color
            ))
        return entries

class TiviMateE2IPTVFinder(Screen):
    skin = E2_IPTV_FINDER_SKIN
    def __init__(self,session):
        Screen.__init__(self,session)
        self._generation=0; self._running=False; self._scan_running=False; self._results=[]; self._all_results=[]; self._page=0; self._page_size=100; self._mode="all"; self._source="all"; self._days=0
        self._quick_anim_step=0
        self._quick_anim_timer=eTimer()
        try:self._quick_anim_timer.callback.append(self._quickAnimTick)
        except Exception:
            try:self._quick_anim_timer.timeout.connect(self._quickAnimTick)
            except Exception:pass
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["brand"]=Label("TiviMateE2  •  SEARCH  •  CHECK")
        self["filterAll"]=Label("▦  ALL"); self["filterStalker"]=Label("STALKER")
        self["filterXtream"]=Label("XTREAM"); self["filterM3U"]=Label("M3U")
        self["daysBox"]=Label("ALL DATES"); self["searchBox"]=Label("⌕  SEARCH")
        self["summary"]=Label("Press GREEN to search")
        self["status"]=Label("")
        self["quickAnim"]=Label("")
        self["typeLogoTop"]=Pixmap()
        self["typeLogoXtream"]=Pixmap()
        self["typeLogoStalker"]=Pixmap()
        self["typeLogoM3U"]=Pixmap()
        self["sourceLogoTop"]=Pixmap()
        self["pageNumbers"]=Label("0 RESULTS")
        self["tableHead"]=Label("TYPE   SERVER / URL                         EXPIRY            ONLINE")
        self["list"]=IPTVFinderResultList()
        self["detailIcon"]=Pixmap(); self["detailType"]=Label("SELECT SERVER")
        self["detailOnline"]=Label(""); self["detailUrl"]=Label("")
        self["detailInfo"]=Label("Choose a working result to view its information.")
        self["detailAction"]=Label("OK  •  ADD SERVER")
        self["hint"]=Label("")
        self["fieldUrl"]=Label("")
        self["fieldUser"]=Label("")
        self["fieldPass"]=Label("")
        self["fieldMac"]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions"],{
            "cancel":self.close,"red":self.quickCheckPage,"ok":self.openCurrent,"green":self.startSearch,
            "yellow":self.cycleSource,"blue":self.cycleType,
            "up":self._up,"down":self._down,"left":self._pageUp,"right":self._pageDown},-1)
        self.onLayoutFinish.append(self._finderReady); self.onClose.append(self._closed)
        # Create the Finder log immediately, before layout callbacks run.
        self._finder_log_path = self._finderLog("FINDER_INIT", source=self._source, mode=self._mode)

    def _finderLog(self, event, **fields):
        # Persistent Finder diagnostics on HDD. Secrets are never written.
        try:
            import datetime
            # Pick a writable persistent mount automatically. Some images do not mount storage as /media/hdd.
            candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/media/mmc", "/media/sdcard"]
            try:
                for name in os.listdir("/media"):
                    path = os.path.join("/media", name)
                    if path not in candidates:
                        candidates.append(path)
            except Exception:
                pass
            root = None
            for path in candidates:
                try:
                    if os.path.isdir(path) and os.access(path, os.W_OK):
                        root = path
                        break
                except Exception:
                    pass
            if root is None:
                root = "/tmp"
            base = os.path.join(root, "tivimatee2")
            if not os.path.isdir(base):
                os.makedirs(base)
            def safe(k, v):
                k=str(k or "").lower()
                if any(x in k for x in ("pass","password","user","username","mac","token","cookie","auth")):
                    return "<redacted>"
                v=str(v if v is not None else "")
                # Strip credentials from common Xtream-style query strings.
                v=re.sub(r'([?&](?:username|password|token)=)[^&\s]+', r'\1<redacted>', v, flags=re.I)
                return v[:800]
            parts=["%s=%s"%(k,safe(k,v)) for k,v in sorted(fields.items())]
            line="[%s] %s%s\n"%(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),str(event),(" | "+" | ".join(parts)) if parts else "")
            log_path=os.path.join(base,"finder_debug.log")
            with open(log_path,"a") as fh:
                fh.write(line); fh.flush()
                try: os.fsync(fh.fileno())
                except Exception: pass
            return log_path
        except Exception:
            return None

    def _finderReady(self):
        self._finderLog("FINDER_OPEN", source=self._source, mode=self._mode)
        self._setFilters()
        self["status"].setText("READY — PRESS GREEN")
        _lp = self._finder_log_path or self._finderLog("FINDER_READY", source=self._source, mode=self._mode)
        self._finder_log_path = _lp
        if _lp:
            self["summary"].setText("DEBUG LOG: %s" % _lp)
        else:
            self["summary"].setText("DEBUG LOG: WRITE FAILED")
        self["searchBox"].setText("GREEN = SEARCH")

    def _closed(self):
        self._finderLog("FINDER_CLOSE", results=len(self._results or []), running=self._running, scan_running=self._scan_running)
        self._generation+=1; self._running=False
    def _up(self):
        try:self["list"].up()
        except Exception:pass
        self._updateDetail()
    def _down(self):
        try:self["list"].down()
        except Exception:pass
        self._updateDetail()
    def _pageUp(self):
        self._showResultPage(self._page-1)
    def _pageDown(self):
        self._showResultPage(self._page+1)

    def _showResultPage(self,page=0):
        total=len(self._all_results or [])
        if total<=0:
            self._page=0; self._results=[]
            self["list"].setResults([])
            self._updateTopTypeAndNumbers()
            return
        pages=max(1,(total+self._page_size-1)//self._page_size)
        page=max(0,min(int(page or 0),pages-1))
        self._page=page
        start=page*self._page_size
        end=min(total,start+self._page_size)
        self._results=list(self._all_results[start:end])
        self["list"].setResults(self._results)
        self["status"].setText("PAGE %d/%d  •  %d-%d / %d"%(page+1,pages,start+1,end,total))
        self._updateTopTypeAndNumbers()
        self["summary"].setText("100 PER PAGE  •  LEFT/RIGHT = PAGE  •  MENU = QUICK CHECK  •  OK = ADD")
        if self._results:self._updateDetail()
        else:self._clearDetail()

    def _updateTopTypeAndNumbers(self):
        # YELLOW Source: show a compact visual badge beside the existing
        # XT/STB/M3U type icons. This is display-only and does not change
        # Finder search/source logic.
        try:
            source_files={
                "iptvlinks":"finder_source_links.png",
                "stbstalker":"finder_source_stb.png",
                "stalker429":"finder_source_stb.png",
                "stbtelegram":"finder_source_telegram.png",
                "iptvorg":"finder_source_iptvorg.png",
                "samsungtv":"finder_source_samsung.png",
                "xiaomitv":"finder_source_xiaomi.png",
                "freetv":"finder_source_freetv.png",
                "xumotv":"finder_source_xumo.png",
                "localnow":"finder_source_localnow.png",
                "lgchannels":"finder_source_lg.png",
                "roku":"finder_source_roku.png",
                "tubitv":"finder_source_tubi.png",
                "vizio":"finder_source_vizio.png",
                "tclplus":"finder_source_tcl.png","freelivesports":"finder_source_freelivesports.png",
            }
            sw=self["sourceLogoTop"]
            sf=source_files.get(self._source)
            if sf:
                sw.instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","server",sf))
                sw.show()
            else:
                sw.hide()
        except Exception:
            pass

        # One clean circular logo only. BLUE changes TYPE; YELLOW can force
        # the natural family for fixed sources such as STB Stalker/IPTV-Org.
        try:
            logo_files={
                "xtream":"finder_xtream_top_clean.png",
                "stalker":"finder_stalker_top_clean.png",
                "m3u":"finder_m3u_top_clean.png",
            }
            source_kind={"stbstalker":"stalker", "stalker429":"stalker", "iptvorg":"m3u", "samsungtv":"m3u", "xiaomitv":"m3u", "freetv":"m3u", "xumotv":"m3u", "localnow":"m3u", "lgchannels":"m3u", "roku":"m3u", "tubitv":"m3u", "vizio":"m3u", "tclplus":"m3u", "freelivesports":"m3u"}.get(self._source)
            active=source_kind or self._mode
            w=self["typeLogoTop"]
            trio=(
                ("typeLogoXtream","xtream"),
                ("typeLogoStalker","stalker"),
                ("typeLogoM3U","m3u"),
            )
            if active == "all":
                try:w.hide()
                except Exception:pass
                for name,kind in trio:
                    path=os.path.join(PLUGIN_PATH,"skins","server",logo_files[kind])
                    try:self[name].instance.setPixmapFromFile(path)
                    except Exception:pass
                    try:self[name].show()
                    except Exception:pass
            elif active in logo_files:
                for name,kind in trio:
                    try:self[name].hide()
                    except Exception:pass
                path=os.path.join(PLUGIN_PATH,"skins","server",logo_files[active])
                try:w.instance.setPixmapFromFile(path)
                except Exception:pass
                try:w.show()
                except Exception:pass
            else:
                try:w.hide()
                except Exception:pass
                for name,kind in trio:
                    try:self[name].hide()
                    except Exception:pass
        except Exception:
            pass

        try:
            total=len(self._all_results or [])
            if total<=0:
                self["pageNumbers"].setText("0 RESULTS")
                return
            pages=max(1,(total+self._page_size-1)//self._page_size)
            page=max(0,min(int(self._page or 0),pages-1))
            start=page*self._page_size
            end=min(total,start+self._page_size)
            self["pageNumbers"].setText("PAGE %d / %d     %d - %d / %d"%(page+1,pages,start+1,end,total))
        except Exception:
            try:self["pageNumbers"].setText("0 RESULTS")
            except Exception:pass

    def _setFilters(self):
        names={"all":"▦  ALL","stalker":"STALKER","m3u":"M3U"}
        self["filterAll"].setText(("▶  " if self._mode=="all" else "")+"ALL")
        self["filterStalker"].setText(("▶  " if self._mode=="stalker" else "")+"STALKER")
        self["filterXtream"].setText(("▶  " if self._mode=="xtream" else "")+"XTREAM")
        self["filterM3U"].setText(("▶  " if self._mode=="m3u" else "")+"M3U")
        self["daysBox"].setText("ALL DATES")
        self._updateTopTypeAndNumbers()

    def cycleSource(self):
        sources=("all","iptvlinks","stbstalker","stalker429","stbtelegram","iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports")
        try:self._source=sources[(sources.index(self._source)+1)%len(sources)]
        except Exception:self._source="all"
        labels={"all":"ALL SOURCES","iptvlinks":"IPTV LINKS","stbstalker":"STB STALKER","stalker429":"STALKER429","stbtelegram":"TELEGRAM","iptvorg":"IPTV-ORG","samsungtv":"SAMSUNG TV PLUS","xiaomitv":"XIAOMI TV+","xumotv":"XUMO PLAY","freetv":"FREE TV","localnow":"LOCAL NOW","lgchannels":"LG CHANNELS","roku":"ROKU CHANNEL","tubitv":"TUBI LIVE TV","vizio":"VIZIO WATCHFREE+","tclplus":"TCL TV+","freelivesports":"FREE LIVE SPORTS"}
        self["status"].setText("SOURCE: %s  •  TYPE: %s"%(labels.get(self._source,self._source.upper()),str(self._mode or "all").upper()))
        self["summary"].setText("GREEN = SEARCH  •  YELLOW = SOURCE  •  BLUE = TYPE")
        self._updateTopTypeAndNumbers()
    def cycleType(self):
        vals=("all","stalker","xtream","m3u")
        try:self._mode=vals[(vals.index(self._mode)+1)%len(vals)]
        except Exception:self._mode="xtream"
        labels={"all":"ALL","stalker":"STALKER","xtream":"XTREAM","m3u":"M3U"}
        self["status"].setText("TYPE: %s"%labels.get(self._mode,"ALL"))
        self._setFilters()

    def cycleDays(self):
        self._days=0
        self["daysBox"].setText("ALL DATES")


    def _finderTxtPath(self, scanned=False):
        try:
            from Plugins.Extensions.TiviMateE2.storage import data_path
            name="finder_valid.txt" if scanned else "finder_results.txt"
            return data_path("finder",name)
        except Exception:
            return "/tmp/tivimatee2_finder_valid.txt" if scanned else "/tmp/tivimatee2_finder_results.txt"

    def _rowMac(self,row):
        try:
            direct=str((row or {}).get("mac") or "").strip().upper().replace("-",":")
            if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$",direct):
                return direct
            post=(row or {}).get("post") if isinstance((row or {}).get("post"),dict) else {}
            macs=post.get("macs") or []
            if not isinstance(macs,(list,tuple)):
                macs=[macs]
            for entry in macs:
                if isinstance(entry,dict):
                    value=str(entry.get("mac") or entry.get("value") or "")
                else:
                    value=str(entry or "")
                value=value.strip().upper().replace("-",":")
                if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$",value):
                    return value
        except Exception:
            pass
        return ""

    def _writeFinderTxt(self,rows,scanned=False):
        path=self._finderTxtPath(scanned)
        try:
            parent=os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
        except Exception:
            pass
        with open(path,"w") as fh:
            fh.write("# TiviMateE2 IPTV Finder\n")
            fh.write("# TYPE\tSTATUS\tHTTP\tMS\tURL\tMAC\tEXPIRY\n")
            for row in (rows or []):
                kind=str((row or {}).get("kind") or "").lower()
                status=str((row or {}).get("_scan") or "FOUND")
                code=str(int((row or {}).get("_code") or 0) or "")
                ms=str(int((row or {}).get("_ms") or 0) or "")
                url=str((row or {}).get("url") or "").replace("\r","").replace("\n","")
                mac=self._rowMac(row)
                try:
                    expiry=str(
                        (row or {}).get("expiry")
                        or (row or {}).get("_last_expiry")
                        or (((row or {}).get("post") or {}).get("expiry"))
                        or (((row or {}).get("source_post") or {}).get("expiry"))
                        or ""
                    ).strip()
                except Exception:
                    expiry=""
                fh.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\n"%(kind,status,code,ms,url,mac,expiry))
        return path

    def _readFinderTxt(self,scanned=False):
        path=self._finderTxtPath(scanned)
        rows=[]
        try:
            with open(path,"r") as fh:
                for raw in fh:
                    raw=raw.rstrip("\r\n")
                    if not raw or raw.startswith("#"):
                        continue
                    parts=raw.split("\t",6)
                    while len(parts)<7:
                        parts.append("")
                    kind,status,code,ms,url,mac,expiry=parts
                    if not url:
                        continue
                    row={"kind":kind,"url":url,"_scan":status}
                    if mac:
                        row["mac"]=mac
                    if expiry:
                        row["expiry"]=expiry
                    try: row["_code"]=int(code or 0)
                    except Exception: row["_code"]=0
                    try: row["_ms"]=int(ms or 0)
                    except Exception: row["_ms"]=0
                    rows.append(row)
        except Exception:
            pass
        return rows

    def _scanTarget(self,row):
        """Return a public endpoint to probe without performing a login/handshake."""
        url=str((row or {}).get("url") or "").strip()
        if not url:
            return ""
        try:
            p=urlparse(url if "://" in url else "http://"+url)
            if p.scheme not in ("http","https") or not p.netloc:
                return ""
            kind=str((row or {}).get("kind") or "").lower()
            # For credential-bearing playlist/Xtream URLs, probe only the public host.
            if kind in ("xtream","m3u") and (p.query or "get.php" in (p.path or "").lower()):
                return "%s://%s/"%(p.scheme,p.netloc)
            return url
        except Exception:
            return ""

    def _quickReachabilityTarget(self,row):
        """Return a lightweight public URL target appropriate for this Finder type."""
        row=row or {}
        kind=str(row.get("kind") or "").lower()
        raw=str(row.get("url") or "").strip()
        if not raw:
            return ""

        # M3U: check the exact public playlist URL.
        if kind=="m3u":
            return raw

        # Xtream: only check scheme + host + port. Do not submit credentials.
        if kind=="xtream":
            try:
                from urllib.parse import urlsplit
            except Exception:
                from urlparse import urlsplit
            try:
                p=urlsplit(raw if "://" in raw else "http://"+raw)
                if p.scheme and p.netloc:
                    return "%s://%s/"%(p.scheme,p.netloc)
            except Exception:
                pass
            return raw

        # Stalker: keep the public portal path when present. /c and
        # /stalker_portal/c are legitimate portal forms; do not strip them.
        if kind=="stalker":
            clean=raw.rstrip("/")
            low=clean.lower()
            if low.endswith("/c") or "/stalker_portal/c" in low:
                return clean+"/"
            return raw

        return raw

    def _quickAnimTick(self):
        if not self._scan_running:
            self._stopQuickAnim()
            return
        frames=("●","◉","○","◉")
        self._quick_anim_step=(self._quick_anim_step+1)%len(frames)
        try:self["quickAnim"].setText(frames[self._quick_anim_step])
        except Exception:pass

    def _startQuickAnim(self):
        self._quick_anim_step=0
        try:self["quickAnim"].setText("●")
        except Exception:pass
        try:self._quick_anim_timer.start(220,False)
        except Exception:pass

    def _stopQuickAnim(self):
        try:self._quick_anim_timer.stop()
        except Exception:pass
        try:self["quickAnim"].setText("")
        except Exception:pass

    def quickCheckPage(self):
        """Fast public reachability check for the currently visible Finder page only."""
        self._finderLog("QUICK_CHECK_REQUEST", page=self._page, rows=len(self._results or []), source=self._source, mode=self._mode)
        # Do not fail silently when another operation is really still active.
        if self._running:
            try:
                self["status"].setText("SEARCH STILL RUNNING")
                self["summary"].setText("Wait for SEARCH to finish, then press MENU QUICK CHECK")
            except Exception:
                pass
            return
        if self._scan_running:
            try:
                self["status"].setText("QUICK CHECK RUNNING...")
            except Exception:
                pass
            return

        rows=list(self._results or [])
        if not rows:
            self.session.open(MessageBox,"Run SEARCH first.",MessageBox.TYPE_INFO,timeout=3)
            return

        self._scan_running=True
        self._startQuickAnim()
        generation=self._generation
        page=self._page
        total=len(rows)

        # Reset only this visible page to UNKNOWN before the new check.
        fresh=[]
        for row in rows:
            item=dict(row)
            item["_scan"]="FOUND"
            item["_code"]=0
            item["_ms"]=0
            fresh.append(item)
        self._results=list(fresh)
        try:
            self["list"].setResults(self._results)
            self["status"].setText("CHECK 0/%d"%total)
            self["summary"].setText("QUICK CHECK • current page only • results update live")
        except Exception:
            pass

        worker=threading.Thread(target=self._quickCheckWorker,args=(generation,page,fresh))
        worker.daemon=True
        worker.start()

    def _quickCheckWorker(self,generation,page,rows):
        # Small fixed pool using the existing threading module: no timer/hook/module added.
        total=len(rows)
        results=[dict(x) for x in rows]
        cursor=[0]
        done=[0]
        online=[0]
        reachable=[0]
        lock=threading.Lock()

        try:
            from .web_manager import _public_reachability
        except Exception:
            _public_reachability=None

        def _push_one(idx,item,done_count,online_count,reachable_count):
            def _apply():
                if generation!=self._generation:
                    return
                start=page*self._page_size
                pos=start+idx
                if pos < len(self._all_results):
                    self._all_results[pos]=item
                if self._page==page and idx < len(self._results):
                    self._results[idx]=item
                    try:
                        self["list"].setResults(self._results)
                        try:
                            self["list"].moveToIndex(idx)
                        except Exception:
                            pass
                        self._updateDetail()
                    except Exception:
                        pass
                try:
                    self["status"].setText("CHECK %d/%d  •  ONLINE %d  •  PORTAL %d"%(done_count,total,online_count,reachable_count))
                except Exception:
                    pass
            try:
                if reactor is not None:
                    reactor.callFromThread(_apply)
                else:
                    _apply()
            except Exception:
                try:_apply()
                except Exception:pass

        def _finish_all():
            def _finish():
                if generation!=self._generation:
                    self._scan_running=False
                    self._stopQuickAnim()
                    return
                self._scan_running=False
                self._stopQuickAnim()
                if self._page==page:
                    self._results=list(results)
                    try:
                        self["list"].setResults(self._results)
                        self._updateDetail()
                    except Exception:
                        pass
                try:
                    self["status"].setText("QUICK: %d ONLINE • %d PORTAL / %d"%(online[0],reachable[0],total))
                    self["summary"].setText("GREEN = MAC VERIFIED  •  YELLOW = PORTAL ONLY  •  RED = OFFLINE")
                except Exception:
                    pass
            try:
                if reactor is not None:
                    reactor.callFromThread(_finish)
                else:
                    _finish()
            except Exception:
                try:_finish()
                except Exception:pass

        def _worker():
            while True:
                with lock:
                    if cursor[0] >= total:
                        return
                    idx=cursor[0]
                    cursor[0]+=1

                item=dict(rows[idx])
                target=self._quickReachabilityTarget(item)
                kind=str(item.get("kind") or "").lower()
                if not target:
                    item["_scan"]="INVALID"
                    item["_code"]=0
                    item["_ms"]=0
                elif kind=="stalker":
                    # A green Stalker row must prove that this exact MAC can
                    # authenticate. Public HTTP reachability alone is yellow.
                    # Show CHECKING immediately so RED never appears frozen.
                    mac=self._rowMac(item)
                    verified=False
                    started=time.time()
                    checking=dict(item)
                    checking["_scan"]="CHECKING"
                    _push_one(idx,checking,done[0],online[0],reachable[0])
                    if mac:
                        try:
                            reply=StalkerClient({"type":"stalker","url":str(item.get("url") or target),"mac":mac,"service_type":4097,"_finder_check":True}).test() or {}
                            item["_handshake"]=bool(reply.get("handshake"))
                            item["_profile"]=bool(reply.get("profile"))
                            item["_categories"]=int(reply.get("categories") or 0)
                            if reply.get("expiry"):
                                item["expiry"]=str(reply.get("expiry"))
                            verified=bool(reply.get("ok"))
                        except Exception:
                            verified=False
                    item["_ms"]=int((time.time()-started)*1000)
                    if verified:
                        item["_scan"]="VALID"
                        item["_code"]=200
                    else:
                        if _public_reachability is not None:
                            try:
                                state,code,ms,final=_public_reachability(target)
                                item["_code"]=int(code or 0)
                                item["_ms"]=max(int(item.get("_ms") or 0),int(ms or 0))
                                item["_scan"]="REACHABLE" if state=="reachable" else "DEAD"
                            except Exception:
                                item["_scan"]="DEAD"
                                item["_code"]=0
                        else:
                            item["_scan"]="DEAD"
                            item["_code"]=0
                else:
                    try:
                        state,code,ms,final=_public_reachability(target)
                        item["_code"]=int(code or 0)
                        item["_ms"]=int(ms or 0)
                        item["_scan"]="VALID" if state=="reachable" else "DEAD"
                    except Exception:
                        item["_scan"]="DEAD"
                        item["_code"]=0
                        item["_ms"]=0

                with lock:
                    results[idx]=item
                    done[0]+=1
                    scan_state=str(item.get("_scan") or "").upper()
                    if scan_state=="VALID":
                        online[0]+=1
                    elif scan_state=="REACHABLE":
                        reachable[0]+=1
                    d=done[0]
                    o=online[0]
                    y=reachable[0]

                # Update this exact row immediately instead of waiting for all 100.
                _push_one(idx,item,d,o,y)

        # Eight Finder-only workers keep the UI responsive while reducing waits on dead portals.
        workers=[]
        count=min(8,total)
        for _n in range(count):
            t=threading.Thread(target=_worker)
            t.daemon=True
            workers.append(t)
            t.start()
        # Never let one dead provider keep the Finder worker alive forever.
        # This worker is already off the Enigma2 UI thread; use one short
        # shared deadline and return whatever checks completed.
        _deadline=time.time()+6.0
        for t in workers:
            _remaining=_deadline-time.time()
            if _remaining<=0:
                break
            t.join(_remaining)

        _finish_all()

    def scanAll(self):
        if self._running or self._scan_running:
            return
        # Always scan exactly what SEARCH wrote to the TXT file.
        rows=self._readFinderTxt(False)
        if not rows:
            self.session.open(MessageBox,"Run SEARCH first. No Finder TXT results are available.",MessageBox.TYPE_INFO,timeout=4)
            return
        self._scan_running=True
        self["status"].setText("SCANNING ALL...")
        self["summary"].setText("Checking %d saved TXT results..."%len(rows))
        generation=self._generation
        worker=threading.Thread(target=self._scanWorker,args=(generation,rows))
        worker.daemon=True
        worker.start()

    def _scanWorker(self,generation,rows):
        checked=[]
        valid=[]
        try:
            from .web_manager import _public_reachability, _urlopen_text
            for row in rows:
                item=dict(row)
                kind=str(item.get("kind") or "").lower()
                target=self._scanTarget(item)
                if not target:
                    item["_scan"]="INVALID"; item["_code"]=0; item["_ms"]=0
                    checked.append(item)
                    continue

                if kind=="m3u":
                    # Validate the exact saved URL, not a shortened host URL.
                    try:
                        started=time.time()
                        code,final,body=_urlopen_text(str(item.get("url") or ""),timeout=6,max_bytes=524288)
                        item["_code"]=int(code or 0)
                        item["_ms"]=int((time.time()-started)*1000)
                        text=str(body or "")
                        head=text[:524288].lstrip("\ufeff\r\n\t ")
                        upper=head.upper()

                        # Detect HLS first: media manifests also contain
                        # #EXTINF, so checking #EXTINF first wrongly marked
                        # direct streams as full IPTV playlists.
                        if 200 <= int(code or 0) < 400 and "#EXTM3U" in upper and (
                            "#EXT-X-STREAM-INF" in upper or "#EXT-X-TARGETDURATION" in upper or "#EXT-X-MEDIA-SEQUENCE" in upper
                        ):
                            item["_scan"]="HLS STREAM"
                        # A downloadable IPTV channel list is VALID even when
                        # the public URL itself has no .m3u suffix.
                        elif 200 <= int(code or 0) < 400 and "#EXTM3U" in upper and "#EXTINF" in upper:
                            item["_scan"]="VALID"
                            valid.append(item)
                        else:
                            item["_scan"]="DEAD"
                    except Exception:
                        item["_scan"]="DEAD"; item["_code"]=0; item["_ms"]=0
                    checked.append(item)
                    continue

                # Stalker is VALID only when this exact MAC authenticates.
                # A portal that merely answers HTTP is kept as REACHABLE/yellow.
                if kind=="stalker":
                    mac=self._rowMac(item)
                    verified=False
                    started=time.time()
                    if mac:
                        try:
                            reply=StalkerClient({"type":"stalker","url":str(item.get("url") or target),"mac":mac,"service_type":4097,"_finder_check":True}).test() or {}
                            item["_handshake"]=bool(reply.get("handshake"))
                            item["_profile"]=bool(reply.get("profile"))
                            item["_categories"]=int(reply.get("categories") or 0)
                            if reply.get("expiry"):
                                item["expiry"]=str(reply.get("expiry"))
                            verified=bool(reply.get("ok"))
                        except Exception:
                            verified=False
                    item["_ms"]=int((time.time()-started)*1000)
                    if verified:
                        item["_scan"]="VALID"; item["_code"]=200
                        valid.append(item)
                    else:
                        try:
                            state,code,ms,final=_public_reachability(target)
                            item["_code"]=int(code or 0); item["_ms"]=max(int(item.get("_ms") or 0),int(ms or 0))
                            item["_scan"]="REACHABLE" if state=="reachable" else "DEAD"
                        except Exception:
                            item["_scan"]="DEAD"; item["_code"]=0
                else:
                    try:
                        state,code,ms,final=_public_reachability(target)
                        item["_code"]=int(code or 0); item["_ms"]=int(ms or 0)
                        if state=="reachable":
                            item["_scan"]="VALID"
                            valid.append(item)
                        else:
                            item["_scan"]="DEAD"
                    except Exception:
                        item["_scan"]="DEAD"; item["_code"]=0; item["_ms"]=0
                checked.append(item)
        except Exception:
            checked=[dict(x,**{"_scan":"INVALID"}) for x in rows]
            valid=[]

        try:
            self._writeFinderTxt(checked,False)
            self._writeFinderTxt(valid,True)
        except Exception:
            pass

        def _finish():
            if generation!=self._generation:
                self._scan_running=False
                return
            self._scan_running=False
            # Reload the checked TXT so every original Finder row keeps its
            # VALID/DEAD/NO MAC state. The row renderer then turns VALID into
            # the same green LED + ONLINE presentation as Live Server.
            self._all_results=self._readFinderTxt(False)
            self._page=0
            valid_count=sum(1 for _r in self._all_results if str((_r or {}).get("_scan") or "").upper()=="VALID")
            if self._all_results:
                self._showResultPage(0)
                self["status"].setText("VALID: %d / %d"%(valid_count,len(self._all_results)))
                reachable_count=sum(1 for _r in self._all_results if str((_r or {}).get("_scan") or "").upper()=="REACHABLE")
                self["summary"].setText("SCAN complete • GREEN = MAC VERIFIED • YELLOW = PORTAL ONLY • RED = OFFLINE")
                self["status"].setText("VALID: %d • PORTAL: %d / %d"%(valid_count,reachable_count,len(self._all_results)))
            else:
                self._results=[]
                self["list"].setResults([])
                self["status"].setText("VALID: 0 / %d"%len(rows))
                self["summary"].setText("SCAN complete • no results")
                self._clearDetail()
        try:
            if reactor is not None:reactor.callFromThread(_finish)
            else:_finish()
        except Exception:
            try:_finish()
            except Exception:pass


    def startSearch(self):
        self._finderLog("SEARCH_REQUEST", source=self._source, mode=self._mode, days=self._days)
        if self._running:return
        self._setFilters(); self._running=True; self._generation+=1; generation=self._generation
        self["status"].setText("SEARCHING..."); self["searchBox"].setText("⌕  CHECKING...")
        self["summary"].setText("Searching selected source... please wait")
        self._results=[]; self._all_results=[]; self._page=0; self["list"].setResults([]); self._clearDetail()
        worker=threading.Thread(target=self._worker,args=(generation,)); worker.daemon=True; worker.start()

    def _worker(self,generation):
        rows=[]; error=""
        self._finderLog("SEARCH_WORKER_START", generation=generation, source=self._source, mode=self._mode)
        try:
            from .web_manager import _fetch_discovery,_discovery_items
            posts=[]; source_errors=[]
            samsung_region_keys=[]
            source_ids=("iptvlinks","stbstalker","stalker429","stbtelegram","iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports") if self._source=="all" else (self._source,)
            for source_id in source_ids:
                if source_id in ("xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports"):
                    # FAST sources are exposed as compact rows below; do not download
                    # their playlists during SEARCH. Download only when OPEN is pressed.
                    continue
                if source_id == "samsungtv":
                    # Samsung TV Plus is an isolated public FAST source.
                    # Channel metadata is refreshed at search time; no timer/hook is added.
                    try:
                        req=Request("https://i.mjh.nz/SamsungTVPlus/.channels.json.gz",headers={"User-Agent":"Mozilla/5.0"})
                        raw=urlopen(req,timeout=12).read(4*1024*1024)
                        data=json.loads(gzip.decompress(raw).decode("utf-8","ignore"))
                        regions=(data or {}).get("regions") or {}
                        samsung_region_keys=[str(x).lower() for x in regions.keys()]
                        # Load every region exposed by the Samsung TV Plus catalog.
                        # Keep region-specific channel IDs/feeds; only identical stream URLs
                        # are de-duplicated so alternate regional feeds remain available.
                        region_channels=[]
                        for rk in sorted(regions.keys(),key=lambda x:str(x).lower()):
                            rchannels=((regions.get(rk) or {}).get("channels") or {})
                            for cid,ch in rchannels.items():
                                if not isinstance(ch,dict) or ch.get("license_url"):
                                    continue
                                region_channels.append((str(rk).upper(),str(cid),ch))
                        m3us=[]; seen_streams=set()
                        slug_fmt=str((data or {}).get("slug") or "sam-{id}.m3u8")
                        for rk,cid,ch in sorted(region_channels,key=lambda x:(x[0],int((x[2] or {}).get("chno") or 999999),str((x[2] or {}).get("name") or ""))):
                            slug=slug_fmt.format(id=cid)
                            u="https://jmp2.uk/%s"%slug.lstrip("/")
                            if u in seen_streams:
                                continue
                            seen_streams.add(u)
                            m3us.append(u)
                        if m3us:
                            posts.append({"title":"Samsung TV Plus","date":"","expiry":"","urls":[],"macs":[],"xtreams":[],"m3us":m3us,"finder_source":"samsungtv"})
                        else:
                            source_errors.append("samsungtv: no public channels")
                    except Exception as e:
                        source_errors.append("samsungtv: %s"%str(e)[:60])
                    continue
                if source_id == "xiaomitv":
                    # Xiaomi TV+ public FAST source. Apsattv publishes a legal
                    # Xiaomi playlist; Finder exposes compact category packages.
                    # No timer/hook is added: the playlist is refreshed only on SEARCH/OPEN.
                    try:
                        _xiaomi_url="https://www.apsattv.com/xiaomi.m3u"
                        req=Request(_xiaomi_url,headers={"User-Agent":"Mozilla/5.0"})
                        raw=urlopen(req,timeout=12).read(8*1024*1024)
                        txt=raw.decode("utf-8","replace") if isinstance(raw,bytes) else str(raw)
                        _count=txt.count("#EXTINF")
                        if _count>0:
                            posts.append({"title":"Xiaomi TV+","date":"","expiry":"","urls":[],"macs":[],"xtreams":[],"m3us":[_xiaomi_url],"finder_source":"xiaomitv","channel_count":_count})
                        else:
                            source_errors.append("xiaomitv: empty playlist")
                    except Exception as e:
                        source_errors.append("xiaomitv: %s"%str(e)[:60])
                    continue
                if source_id == "iptvorg":
                    # Isolated IPTV-Org source. Existing Telegram/STB/IPTVLinks code is untouched.
                    # Start from a bundled public catalog so this source never depends on GitHub Raw.
                    catalog=[]
                    try:
                        catalog_path=os.path.join(PLUGIN_PATH,"data","iptvorg_catalog.txt")
                        with open(catalog_path,"r") as fh:
                            for line in fh:
                                u=str(line or "").strip()
                                if u.startswith("https://iptv-org.github.io/iptv/") and u.endswith(".m3u") and u not in catalog:
                                    catalog.append(u)
                    except Exception:
                        pass
                    # If GitHub Raw is reachable on the receiver, merge the current official catalog.
                    try:
                        from .web_manager import _urlopen_text
                        code,final,body=_urlopen_text("https://raw.githubusercontent.com/iptv-org/iptv/master/PLAYLISTS.md",timeout=10,max_bytes=262144)
                        if 200 <= int(code or 0) < 400 and body:
                            found=re.findall(r'https://iptv-org\.github\.io/iptv/[^\s`<>"\\\']+?\.m3u',str(body),re.I)
                            for u in found:
                                u=str(u or "").strip()
                                if u and u not in catalog:
                                    catalog.append(u)
                    except Exception:
                        pass
                    if catalog:
                        # Pin the large official aggregate playlists first.
                        pinned = [
                            "https://iptv-org.github.io/iptv/index.m3u",
                            "https://iptv-org.github.io/iptv/index.country.m3u",
                            "https://iptv-org.github.io/iptv/index.language.m3u",
                            "https://iptv-org.github.io/iptv/index.category.m3u",
                            "https://iptv-org.github.io/iptv/index.region.m3u",
                            "https://iptv-org.github.io/iptv/languages/ara.m3u",
                        ]
                        ordered=[]
                        for u in pinned + catalog:
                            if u and u not in ordered:
                                ordered.append(u)
                        catalog=ordered
                        posts.append({"title":"IPTV-Org Public Playlists","date":"","expiry":"","urls":[],"macs":[],"xtreams":[],"m3us":catalog,"finder_source":"iptvorg"})
                    else:
                        source_errors.append("iptvorg: catalog unavailable")
                    continue
                _src,_posts,_err=_fetch_discovery(source_id,limit=1000,days=(30 if source_id=="stbtelegram" else 0))
                if _posts: posts.extend(_posts)
                if _err: source_errors.append("%s: %s"%(source_id,str(_err)[:60]))
            error=" | ".join(source_errors)

            # STALKER429 is a fixed portal preset only. No MAC/credential is bundled.
            # It appears immediately after STB STALKER in Source and uses the existing
            # Stalker 429-aware checker when the user supplies an authorized MAC.
            _stalker429_fixed = (self._source == "stalker429")

            # Use the requested type directly. Keep the discovery URL exactly as returned
            # by _discovery_items; do not truncate it before writing the TXT file.
            items=_discovery_items(posts,mode=("m3u" if self._source in ("iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports") and self._mode in ("all","m3u") else self._mode),max_candidates=1000000)
            if _stalker429_fixed and self._mode in ("all","stalker"):
                items.insert(0,{"kind":"stalker","url":"https://stbstalker.alaaeldinee.com/","display_name":"STALKER429","finder_source":"stalker429","post":{"title":"STALKER429","finder_source":"stalker429","macs":[]}})
            elif _stalker429_fixed:
                items=[]

            # IPTV-Org is M3U only: never leak its pinned playlists into STALKER/XTREAM.
            if self._source in ("iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports") and self._mode not in ("all","m3u"):
                items=[]
            rows=[]
            for x in items:
                if not isinstance(x,dict) or not str(x.get("url") or "").strip():
                    continue
                row=dict(x)
                try:
                    row["expiry"]=str(row.get("expiry") or ((row.get("post") or {}).get("expiry")) or ((row.get("source_post") or {}).get("expiry")) or "").strip()
                except Exception:
                    row["expiry"]=""
                # Friendly names for the six large IPTV-Org bundles pinned at the top.
                if str(((row.get("post") or {}).get("finder_source") or "")) == "iptvorg":
                    _u=str(row.get("url") or "").strip()
                    _names={
                        "https://iptv-org.github.io/iptv/index.m3u":"ALL",
                        "https://iptv-org.github.io/iptv/index.country.m3u":"ALL BY COUNTRY",
                        "https://iptv-org.github.io/iptv/index.language.m3u":"ALL BY LANGUAGE",
                        "https://iptv-org.github.io/iptv/index.category.m3u":"ALL BY CATEGORY",
                        "https://iptv-org.github.io/iptv/index.region.m3u":"ALL BY REGION",
                        "https://iptv-org.github.io/iptv/languages/ara.m3u":"ARABIC",
                    }
                    row["display_name"]=_names.get(_u,"")
                    row["_iptvorg_priority"]={u:i for i,u in enumerate(_names.keys())}.get(_u,1000)
                rows.append(row)
            if self._source == "iptvorg":
                rows.sort(key=lambda x:(int(x.get("_iptvorg_priority",1000)),str(x.get("url") or "")))
            elif self._source in ("iptvlinks", "stbstalker", "stbtelegram"):
                # These sources are chronological. Preserve Blogger/message order so
                # page 1 starts with the newest published post.  Do not re-sort IPTV
                # Links by URL text, because that hides the newest M3U post.
                pass
            else:
                rows.sort(key=lambda x:(str(x.get("kind") or ""),str(x.get("url") or "")))

            # SEARCH output is persisted first; UI reloads the same TXT file.
            self._writeFinderTxt(rows,False)
            rows=self._readFinderTxt(False)

            # Samsung TV Plus: show one selectable playlist per region instead of
            # hundreds of raw channel URLs. MIDDLE EAST combines UAE + Saudi + Egypt.
            # The actual local M3U is built only when the user opens/adds the row.
            if self._source == "samsungtv" and self._mode in ("all","m3u"):
                _region_names={
                    "ae":"UAE", "sa":"SAUDI ARABIA", "eg":"EGYPT", "us":"USA", "gb":"UNITED KINGDOM",
                    "ca":"CANADA", "au":"AUSTRALIA", "nz":"NEW ZEALAND", "de":"GERMANY", "fr":"FRANCE",
                    "es":"SPAIN", "it":"ITALY", "at":"AUSTRIA", "ch":"SWITZERLAND", "nl":"NETHERLANDS",
                    "be":"BELGIUM", "pt":"PORTUGAL", "ie":"IRELAND", "se":"SWEDEN", "no":"NORWAY",
                    "fi":"FINLAND", "dk":"DENMARK", "kr":"SOUTH KOREA", "in":"INDIA", "br":"BRAZIL",
                    "mx":"MEXICO"}
                _keys=[]
                for _rk in samsung_region_keys:
                    if _rk and _rk not in _keys: _keys.append(_rk)
                _groups=[("ALL REGIONS","all"),("ARABIC - ALL REGIONS","arabic-all")]
                for _rk in sorted(_keys,key=lambda x:(_region_names.get(x,x.upper()),x)):
                    _groups.append((_region_names.get(_rk,_rk.upper()),_rk))
                rows=[]
                for _name,_gid in _groups:
                    rows.append({"kind":"m3u",
                                 "url":"https://i.mjh.nz/SamsungTVPlus/.channels.json.gz#tivimatee2-region-"+_gid,
                                 "display_name":_name, "samsung_group":_gid,
                                 "_scan":"FOUND","_code":0,"_ms":0})

            # Xiaomi TV+: compact category packages, with ALL always first.
            # Each row builds a local filtered M3U when opened.
            if self._source == "xiaomitv" and self._mode in ("all","m3u"):
                _xiaomi_groups=[
                    ("ALL","all"),
                    ("EUROPE","europe"),
                    ("MIDDLE EAST","middle_east"),
                    ("ASIA","asia"),
                    ("NORTH AMERICA","north_america"),
                    ("LATIN AMERICA","latin_america"),
                    ("AFRICA","africa"),
                    ("OTHER","other"),
                ]
                rows=[]
                for _name,_gid in _xiaomi_groups:
                    rows.append({"kind":"m3u",
                                 "url":"https://www.apsattv.com/xiaomi.m3u#tivimatee2-"+_gid,
                                 "display_name":_name,"xiaomi_group":_gid,
                                 "_scan":"READY","_code":0,"_ms":0})

            # Xumo Play and Free TV: compact public source rows.
            # Playlists are downloaded only when opened, keeping Finder search fast.
            if self._source in ("all","xumotv") and self._mode in ("all","m3u"):
                if self._source == "xumotv":
                    rows=[]
                rows.append({"kind":"m3u","url":"fastm3u://xumo/all",
                             "display_name":"XUMO PLAY - LIVE",
                             "fast_service":"xumo","fast_region":"all","_scan":"READY","_code":0,"_ms":0})

            if self._source in ("all","freetv") and self._mode in ("all","m3u"):
                if self._source == "freetv":
                    rows=[]
                rows.append({"kind":"m3u","url":"fastm3u://freetv/world",
                             "display_name":"FREE TV - WORLD",
                             "fast_service":"freetv","fast_region":"world","_scan":"READY","_code":0,"_ms":0})

            # Additional public FAST sources for compatibility testing on Enigma2.
            # Keep SEARCH instant: playlists are fetched only when the row is opened.
            _extra_fast=(
                ("localnow","LOCAL NOW - LIVE","us"),
                ("roku","ROKU CHANNEL - LIVE","all"),
                ("tubitv","TUBI LIVE TV","all"),
            )
            for _sid,_label,_region in _extra_fast:
                if self._source in ("all",_sid) and self._mode in ("all","m3u"):
                    if self._source == _sid:
                        rows=[]
                    rows.append({"kind":"m3u","url":"fastm3u://%s/%s"%(_sid,_region),
                                 "display_name":_label,"fast_service":_sid,"fast_region":_region,
                                 "_scan":"READY","_code":0,"_ms":0})

            # Additional independent FAST playlists. Each source has its own upstream URL;
            # do not alias these names to any existing TiviMateE2 source.
            _independent_fast=(
                ("vizio","VIZIO WATCHFREE+ - LIVE","all"),
                ("tclplus","TCL TV+ - LIVE","all"),
                ("freelivesports","FREE LIVE SPORTS","all"),
            )
            for _sid,_label,_region in _independent_fast:
                if self._source in ("all",_sid) and self._mode in ("all","m3u"):
                    if self._source == _sid:
                        rows=[]
                    rows.append({"kind":"m3u","url":"fastm3u://%s/%s"%(_sid,_region),
                                 "display_name":_label,"fast_service":_sid,"fast_region":_region,
                                 "_scan":"READY","_code":0,"_ms":0})

            # LG Channels: expose every currently published APSATTV region as its own
            # lightweight row. Only the selected country's playlist is downloaded on OPEN.
            _lg_regions=(
                ("UAE","ae"),("USA","us"),("UK","gb"),("CANADA","ca"),("AUSTRALIA","au"),
                ("GERMANY","de"),("FRANCE","fr"),("ITALY","it"),("SPAIN","es"),("PORTUGAL","pt"),
                ("AUSTRIA","at"),("BELGIUM","be"),("SWITZERLAND","ch"),("DENMARK","dk"),("FINLAND","fi"),
                ("IRELAND","ie"),("LUXEMBOURG","lu"),("NETHERLANDS","nl"),("NORWAY","no"),("SWEDEN","se"),
                ("POLAND","pl"),("ARGENTINA","ar"),("BRAZIL","br"),("CHILE","cl"),("COLOMBIA","co"),
                ("MEXICO","mx"),("PERU","pe"),("INDIA","in"),("JAPAN","jp"),("KOREA","kr"),
                ("SINGAPORE","sg"),("NEW ZEALAND","nz"),
            )
            if self._source in ("all","lgchannels") and self._mode in ("all","m3u"):
                if self._source == "lgchannels":
                    rows=[]
                # ALL first: APSATTV combined LG playlist. Keep country rows below it.
                rows.append({"kind":"m3u","url":"fastm3u://lgchannels/all",
                             "display_name":"LG CHANNELS - ALL",
                             "fast_service":"lgchannels","fast_region":"all",
                             "_scan":"READY","_code":0,"_ms":0})
                for _country,_region in _lg_regions:
                    rows.append({"kind":"m3u","url":"fastm3u://lgchannels/%s"%_region,
                                 "display_name":"LG CHANNELS - %s"%_country,
                                 "fast_service":"lgchannels","fast_region":_region,
                                 "_scan":"READY","_code":0,"_ms":0})

            # IPTV-Org: guarantee the six aggregate playlists are real rows at the
            # very beginning of page 1, even if discovery parsing filtered them.
            # When searching ALL sources, keep IPTV-Org ALL as the first result too.
            if self._source == "all" and self._mode in ("all","m3u"):
                _all_url="https://iptv-org.github.io/iptv/index.m3u"
                rows=[{"kind":"m3u","url":_all_url,"display_name":"ALL","_scan":"FOUND","_code":0,"_ms":0}] + [r for r in rows if str((r or {}).get("url") or "").strip()!=_all_url]

            if self._source == "iptvorg" and self._mode in ("all","m3u"):
                _pinned = [
                    ("ALL", "https://iptv-org.github.io/iptv/index.m3u"),
                    ("ALL BY COUNTRY", "https://iptv-org.github.io/iptv/index.country.m3u"),
                    ("ALL BY LANGUAGE", "https://iptv-org.github.io/iptv/index.language.m3u"),
                    ("ALL BY CATEGORY", "https://iptv-org.github.io/iptv/index.category.m3u"),
                    ("ALL BY REGION", "https://iptv-org.github.io/iptv/index.region.m3u"),
                    # Arabic block: keep overlapping playlists on purpose. A channel may
                    # exist in more than one list with a different stream, so do not
                    # collapse the Arabic sources into one deduplicated result.
                    ("ARABIC - LANGUAGE", "https://iptv-org.github.io/iptv/languages/ara.m3u"),
                    ("ARABIC - ARAB WORLD", "https://iptv-org.github.io/iptv/regions/arab.m3u"),
                    ("ARABIC - GCC", "https://iptv-org.github.io/iptv/regions/gcc.m3u"),
                    ("ARABIC - MENA", "https://iptv-org.github.io/iptv/regions/mena.m3u"),
                    ("ARABIC - MIDDLE EAST", "https://iptv-org.github.io/iptv/regions/mideast.m3u"),
                    ("ARABIC - MAGHREB", "https://iptv-org.github.io/iptv/regions/maghreb.m3u"),
                    ("ARABIC - SPORTS / BEIN / SKY", "https://iptv-org.github.io/iptv/categories/sports.m3u"),
                    ("ARABIC - UAE", "https://iptv-org.github.io/iptv/countries/ae.m3u"),
                    ("ARABIC - SAUDI ARABIA", "https://iptv-org.github.io/iptv/countries/sa.m3u"),
                    ("ARABIC - QATAR / BEIN", "https://iptv-org.github.io/iptv/countries/qa.m3u"),
                    ("ARABIC - KUWAIT", "https://iptv-org.github.io/iptv/countries/kw.m3u"),
                    ("ARABIC - BAHRAIN", "https://iptv-org.github.io/iptv/countries/bh.m3u"),
                    ("ARABIC - OMAN", "https://iptv-org.github.io/iptv/countries/om.m3u"),
                    ("ARABIC - EGYPT", "https://iptv-org.github.io/iptv/countries/eg.m3u"),
                    ("ARABIC - IRAQ", "https://iptv-org.github.io/iptv/countries/iq.m3u"),
                    ("ARABIC - JORDAN", "https://iptv-org.github.io/iptv/countries/jo.m3u"),
                    ("ARABIC - LEBANON", "https://iptv-org.github.io/iptv/countries/lb.m3u"),
                    ("ARABIC - SYRIA", "https://iptv-org.github.io/iptv/countries/sy.m3u"),
                    ("ARABIC - PALESTINE", "https://iptv-org.github.io/iptv/countries/ps.m3u"),
                    ("ARABIC - YEMEN", "https://iptv-org.github.io/iptv/countries/ye.m3u"),
                    ("ARABIC - LIBYA", "https://iptv-org.github.io/iptv/countries/ly.m3u"),
                    ("ARABIC - TUNISIA", "https://iptv-org.github.io/iptv/countries/tn.m3u"),
                    ("ARABIC - ALGERIA", "https://iptv-org.github.io/iptv/countries/dz.m3u"),
                    ("ARABIC - MOROCCO", "https://iptv-org.github.io/iptv/countries/ma.m3u"),
                    ("SPORTS - UK / SKY", "https://iptv-org.github.io/iptv/countries/uk.m3u"),
                ]
                _pin_urls=set(u for _n,u in _pinned)
                _arabic_hidden_urls=set(u for n,u in _pinned if n.startswith("ARABIC -") or n.startswith("SPORTS - UK"))
                _rest=[r for r in rows if str((r or {}).get("url") or "").strip() not in _pin_urls and str((r or {}).get("url") or "").strip() not in _arabic_hidden_urls]
                _groups = [
                    ("ARABIC ALL", "all"),
                    ("GENERAL", "general"),
                    ("MBC • SHAHID", "mbcshahid"),
                    ("MOVIES", "movies"),
                    ("SERIES & ENTERTAINMENT", "entertainment"),
                    ("SPORTS", "sports"),
                    ("KIDS", "kids"),
                    ("CULTURE", "culture"),
                    ("RELIGION", "religion"),
                ]
                _group_rows=[]
                for _name,_gid in _groups:
                    _group_rows.append({"kind":"m3u","url":"https://iptv-org.github.io/iptv/languages/ara.m3u#tivimatee2-"+_gid,
                                        "display_name":_name,"iptvorg_group":_gid,"_scan":"READY","_code":0,"_ms":0})
                # Keep the Arabic section compact: the aggregate packages above are
                # the only Arabic package rows. Do not expose the old per-country /
                # per-region Arabic rows again underneath them.
                _global_pinned = [(n,u) for n,u in _pinned if not (n.startswith("ARABIC -") or n.startswith("SPORTS - UK"))]
                rows=_group_rows + [{"kind":"m3u","url":u,"display_name":n,"_scan":"FOUND","_code":0,"_ms":0} for n,u in _global_pinned] + _rest

                # IPTV-Org cleanup: remove XXX/XXXXX entries and collapse only exact
                # duplicate URLs. Keep same channel name when its stream URL differs.
                _clean_rows=[]
                _seen_urls=set()
                for _r in rows:
                    _u=str((_r or {}).get("url") or "").strip()
                    _n=str((_r or {}).get("display_name") or "").strip()
                    _hay=("%s %s"%(_n,_u)).lower()
                    if re.search(r"x{3,}",_hay):
                        continue
                    _key=_u
                    if _key and _key in _seen_urls:
                        continue
                    if _key:
                        _seen_urls.add(_key)
                    _clean_rows.append(_r)
                rows=_clean_rows
        except Exception as exc:
            error=str(exc)

        def _finish():
            if generation!=self._generation:return
            self._running=False
            self._all_results=list(rows)
            self._page=0
            self["searchBox"].setText("⌕  SEARCH")
            if rows:
                self._showResultPage(0)
                try:
                    self["summary"].setText("SOURCE: %s  •  TYPE: %s  •  %d RESULTS"%(str(self._source or "all").upper(),str(self._mode or "all").upper(),len(rows)))
                except Exception:
                    pass
            else:
                self["status"].setText("FOUND: 0")
                self["summary"].setText(("No results found")+(("   •   "+error[:80]) if error else ""))
                self._clearDetail()
        try:
            if reactor is not None:reactor.callFromThread(_finish)
            else:_finish()
        except Exception:
            try:_finish()
            except Exception:pass

    def _clearDetail(self):
        try:self["detailIcon"].hide()
        except Exception:pass
        self["detailType"].setText("SELECT SERVER"); self["detailOnline"].setText(""); self["detailUrl"].setText("")
        self["detailInfo"].setText("Choose a working result to view its information.")
        try:
            self["fieldUrl"].setText("")
            self["fieldUser"].setText("")
            self["fieldPass"].setText("")
            self["fieldMac"].setText("")
        except Exception:
            pass

    def _selectedRow(self):
        if not self._results:return None
        try:index=int(self["list"].getSelectedIndex())
        except Exception:index=0
        return self._results[index] if 0<=index<len(self._results) else None

    def _updateDetail(self):
        row=self._selectedRow()
        if not row:self._clearDetail(); return
        kind=str(row.get("kind") or "iptv").lower(); url=str(row.get("url") or "")
        host=url.replace("http://","").replace("https://","").split("/")[0]
        port="—"
        try:
            parsed=urlparse(url if "://" in url else "http://"+url); port=str(parsed.port or (443 if parsed.scheme=="https" else 80))
        except Exception:pass
        self["detailType"].setText({"stalker":"STALKER","xtream":"XTREAM","m3u":"M3U"}.get(kind,kind.upper()))
        scan=str(row.get("_scan") or "FOUND").upper()
        self["detailOnline"].setText("●  "+scan); self["detailUrl"].setText(host[:38])
        self["detailInfo"].setText("Response Time     %d ms\n\nServer                 %s\n\nPort                     %s\n\nHTTP                    %s"%(int(row.get("_ms") or 0),host[:30],port,int(row.get("_code") or 0) or "—"))
        icon_path={"stalker":"skins/server/web_stalker_icon.png","xtream":"skins/server/web_xtream_icon.png","m3u":"skins/server/icon_m3u_r123.png"}.get(kind)
        try:
            if icon_path:
                pix=LoadPixmap(os.path.join(PLUGIN_PATH,icon_path)); self["detailIcon"].instance.setPixmap(pix); self["detailIcon"].show()
            else:self["detailIcon"].hide()
        except Exception:pass
        try:
            show_url=str(url or "")
            show_user=""
            show_pass=""
            show_mac=""

            if kind=="xtream":
                try:
                    from .web_manager import _xtream_from_m3u_url
                    xt=_xtream_from_m3u_url(url) or {}
                    show_url=str(xt.get("url") or url).rstrip("/")
                    show_user=str(xt.get("username") or "")
                    show_pass=str(xt.get("password") or "")
                except Exception:
                    pass
            elif kind=="stalker":
                show_mac=self._rowMac(row)
            # M3U intentionally uses URL only.

            self["fieldUrl"].setText(show_url[:72])
            self["fieldUser"].setText(show_user[:40])
            self["fieldPass"].setText(show_pass[:40])
            self["fieldMac"].setText(show_mac[:24])
        except Exception:
            pass

    def openCurrent(self):
        row=self._selectedRow()
        if not row:return
        kind=str(row.get("kind") or "").lower()
        url=str(row.get("url") or "").strip()
        if not url:return
        self._finderLog("OPEN_RESULT", kind=kind, source=self._source, url=url, fast_service=row.get("fast_service") or "")
        source=None

        # Xumo Play / Free TV. Download only on OPEN and keep a local cache.
        _fast_service=str(row.get("fast_service") or "").strip().lower()
        _fast_region=str(row.get("fast_region") or "all").strip().lower()
        if kind=="m3u" and _fast_service in ("xumo","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports"):
            source=None
            _cache_ttl=6*60*60
            _path="/etc/enigma2/tivimatee2_%s_%s.m3u"%(_fast_service,_fast_region)
            _fast_map={
                "xumo":("https://www.apsattv.com/xumo.m3u","XUMO PLAY - LIVE"),
                "freetv":("https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8","FREE TV - WORLD"),
                "localnow":("https://www.apsattv.com/localnow.m3u?","LOCAL NOW - LIVE"),
                "lgchannels":(("https://www.apsattv.com/lg.m3u" if _fast_region == "all" else ("https://raw.githubusercontent.com/JulioCesarXY/EPG-LG-Channels/main/lg_channels_us.m3u" if _fast_region == "us" else "https://www.apsattv.com/%slg.m3u"%_fast_region)),"LG CHANNELS - %s"%_fast_region.upper()),
                "roku":("https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/roku_all.m3u","ROKU CHANNEL - LIVE"),
                "tubitv":("https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/tubi_all.m3u","TUBI LIVE TV"),
                "vizio":("https://www.apsattv.com/vizio.m3u","VIZIO WATCHFREE+ - LIVE"),
                "tclplus":("https://www.apsattv.com/tclplus.m3u","TCL TV+ - LIVE"),
                "freelivesports":("https://www.apsattv.com/freelivesports.m3u","FREE LIVE SPORTS"),
            }
            _remote,_name=_fast_map[_fast_service]
            _need=True
            try:
                if os.path.exists(_path) and os.path.getsize(_path)>64:
                    _age=time.time()-os.path.getmtime(_path)
                    _need=not (0 <= _age < _cache_ttl)
            except Exception:
                _need=True
            if _need:
                # Network download must never run on the Enigma2 main/UI thread.
                # Start one lightweight background fetch and reopen the row only
                # after the local cache is ready.
                _token=(str(_fast_service),str(_fast_region))
                if getattr(self,"_fast_open_loading",None)==_token:
                    return
                self._fast_open_loading=_token
                try:
                    self["status"].setText("LOADING %s..."%_name)
                except Exception:
                    pass
                def _fetch_fast():
                    _err=None
                    try:
                        _req=Request(_remote,headers={"User-Agent":"Mozilla/5.0 (Enigma2; TiviMateE2)","Accept":"application/x-mpegURL,text/plain,*/*"})
                        _raw=urlopen(_req,timeout=5).read(12*1024*1024)
                        _txt=_raw.decode("utf-8","replace") if isinstance(_raw,bytes) else str(_raw or "")
                        if not _txt.lstrip().startswith("#EXTM3U") or "#EXTINF" not in _txt or "http" not in _txt:
                            raise Exception("Downloaded playlist is invalid")
                        # Tubi's generated public playlist can arrive flattened, with
                        # #EXTINF records and their stream URLs on the same physical
                        # line. M3UClient expects the URL on the following line.
                        # Normalize Tubi only; keep every other FAST source untouched.
                        if _fast_service == "tubitv":
                            _txt=re.sub(r"[ \t]+(?=#EXTINF:)", "\n", _txt)
                            _fixed=[]
                            for _line in _txt.splitlines():
                                if _line.startswith("#EXTINF") and "," in _line:
                                    _comma=_line.find(",")
                                    _m=re.search(r"[ \t]+(https?://\S+)\s*$", _line[_comma+1:])
                                    if _m:
                                        _abs=_comma+1+_m.start()
                                        _fixed.append(_line[:_abs].rstrip())
                                        _fixed.append(_m.group(1).strip())
                                        continue
                                _fixed.append(_line)
                            _txt="\n".join(_fixed)+"\n"
                        _tmp=_path+".tmp"
                        with open(_tmp,"w") as _fh:
                            _fh.write(_txt)
                            if not _txt.endswith("\n"):_fh.write("\n")
                        os.rename(_tmp,_path)
                    except Exception as _exc:
                        _err=_exc
                    def _done():
                        self._fast_open_loading=None
                        if _err is not None and not (os.path.exists(_path) and os.path.getsize(_path)>64):
                            self.session.open(MessageBox,"Could not load %s.\n\n%s"%(_name,_err),MessageBox.TYPE_ERROR,timeout=6)
                            return
                        self.openCurrent()
                    try:
                        if reactor is not None: reactor.callFromThread(_done)
                        else: _done()
                    except Exception:
                        pass
                _t=threading.Thread(target=_fetch_fast)
                _t.daemon=True
                _t.start()
                return
            source={"type":"m3u","name":_name,"url":_path,"path":_path,"m3u_mode":"file","service_type":4097,
                    "fast_service":_fast_service,"fast_region":_fast_region}
        # Samsung TV Plus grouped playlists: one row per region. Build a local M3U
        # from the current public catalog only when the row is opened/added.
        _samsung_group=str(row.get("samsung_group") or "").strip().lower()
        if source is None and kind=="m3u" and _samsung_group:
            try:
                req=Request("https://i.mjh.nz/SamsungTVPlus/.channels.json.gz",headers={"User-Agent":"Mozilla/5.0"})
                raw=urlopen(req,timeout=4).read(4*1024*1024)
                data=json.loads(gzip.decompress(raw).decode("utf-8","ignore"))
                regions=(data or {}).get("regions") or {}
                _region_map={str(k).lower():v for k,v in regions.items()}
                if _samsung_group in ("all","arabic-all"):
                    _wanted=sorted(_region_map.keys())
                elif _samsung_group=="middleeast":
                    # Samsung MENA catalogs have used both country keys and
                    # aggregate Middle-East keys across catalog revisions.
                    # Accept all known aliases instead of assuming ae/sa/eg only.
                    _me_aliases=("ae","sa","eg","mena","me","middleeast","middle-east","mideast","gcc")
                    _wanted=[x for x in _me_aliases if x in _region_map]
                    # Some catalogs expose a descriptive region key rather than a code.
                    for _rk in sorted(_region_map.keys()):
                        _norm=re.sub(r"[^a-z]","",str(_rk).lower())
                        if _norm in ("middleeast","middleeastnorthafrica","mena","gcc") and _rk not in _wanted:
                            _wanted.append(_rk)
                else:
                    _wanted=[_samsung_group] if _samsung_group in _region_map else []
                _slug_fmt=str((data or {}).get("slug") or "sam-{id}.m3u8")
                _entries=[]; _seen=set()
                for _rk in _wanted:
                    _chs=((_region_map.get(_rk) or {}).get("channels") or {})
                    for _cid,_ch in sorted(_chs.items(),key=lambda kv:(int((kv[1] or {}).get("chno") or 999999),str((kv[1] or {}).get("name") or ""))):
                        if not isinstance(_ch,dict) or _ch.get("license_url"): continue
                        if _samsung_group=="arabic-all":
                            # Arabic channels across every Samsung region. Prefer explicit
                            # language metadata; Arabic script in title is a safe fallback.
                            _nm=str(_ch.get("name") or "")
                            _lang_parts=[]
                            for _lk in ("language","lang","languages","audio_language","audio_languages"):
                                _lv=_ch.get(_lk)
                                if isinstance(_lv,(list,tuple)):
                                    _lang_parts.extend([str(x).lower() for x in _lv])
                                elif _lv:
                                    _lang_parts.append(str(_lv).lower())
                            _lang_text=" ".join(_lang_parts)
                            _is_ar_lang=bool(re.search(r"(^|[^a-z])(ar|ara|arabic)([^a-z]|$)",_lang_text))
                            _is_ar_name=bool(re.search(u"[\u0600-\u06ff]",_nm))
                            # Known Arabic FAST brands/titles that may use Latin names.
                            _latin=_nm.lower()
                            _ar_brands=("shahid","khaleej","khaleeji","bab al hara","shamiyat","shami","aflam z","rotana","al arabiya","al jazeera arabic")
                            _is_ar_brand=any(x in _latin for x in _ar_brands)
                            if not (_is_ar_lang or _is_ar_name or _is_ar_brand):
                                continue
                        _slug=_slug_fmt.format(id=str(_cid))
                        _stream="https://jmp2.uk/%s"%_slug.lstrip("/")
                        if _stream in _seen: continue
                        _seen.add(_stream)
                        _name=str(_ch.get("name") or _cid).strip()
                        _logo=str(_ch.get("logo") or _ch.get("image") or "").strip()
                        _meta='#EXTINF:-1 tvg-id="%s" group-title="Samsung TV Plus - %s"%s,%s'%(str(_cid),_rk.upper(),(' tvg-logo="%s"'%_logo if _logo else ''),_name)
                        _entries.append((_meta,_stream))
                if not _entries:
                    self.session.open(MessageBox,"No Samsung TV Plus channels were returned for this region.",MessageBox.TYPE_INFO,timeout=5)
                    return
                _safe=re.sub(r"[^a-z0-9_-]+","_",_samsung_group)
                _path="/etc/enigma2/tivimatee2_samsung_%s.m3u"%_safe
                _samsung_epg_region=_samsung_group if _samsung_group not in ("all","arabic-all","middleeast") else "all"
                _samsung_epg="https://i.mjh.nz/SamsungTVPlus/%s.xml.gz"%_samsung_epg_region
                with open(_path,"w") as _fh:
                    _fh.write('#EXTM3U url-tvg="%s"\n'%_samsung_epg)
                    for _meta,_stream in _entries:
                        _fh.write(_meta+"\n"+_stream+"\n")
                source={"type":"m3u","name":str(row.get("display_name") or "SAMSUNG TV PLUS"),"url":_path,"path":_path,"m3u_mode":"file","service_type":4097,"epg_url":_samsung_epg,"fast_service":"samsung","fast_region":_samsung_group}
            except Exception as exc:
                self.session.open(MessageBox,"Could not build Samsung TV Plus region package.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=7)
                return
        elif source is None:
            source=None

        # Xiaomi TV+ grouped packages. Fetch the current public Xiaomi M3U only
        # when the user opens the selected category, then filter locally.
        _xiaomi_group=str(row.get("xiaomi_group") or "").strip().lower()
        if source is None and kind=="m3u" and _xiaomi_group:
            try:
                _srcurl="https://www.apsattv.com/xiaomi.m3u"
                req=Request(_srcurl,headers={"User-Agent":"Mozilla/5.0"})
                raw=urlopen(req,timeout=4).read(8*1024*1024)
                _txt=raw.decode("utf-8","replace") if isinstance(raw,bytes) else str(raw)
                _lines=_txt.replace("\r\n","\n").replace("\r","\n").split("\n")
                _xiaomi_header=next((x.strip() for x in _lines if x.strip().startswith("#EXTM3U")),"#EXTM3U")
                _xiaomi_epg=""
                try:
                    _hm=dict(re.findall(r'([\w-]+)="([^"]*)"',_xiaomi_header)); _hm.update(dict(re.findall(r"([\w-]+)='([^']*)'",_xiaomi_header)))
                    _xiaomi_epg=str(_hm.get("url-tvg") or _hm.get("x-tvg-url") or "").strip()
                except Exception:
                    _xiaomi_epg=""
                # Region classifier. Prefer country/region metadata when the
                # playlist provides it; fall back to channel-name/location hints.
                _regions={
                    "middle_east":("uae","united arab emirates","saudi","saudi arabia","ksa","qatar","kuwait","bahrain","oman","iraq","jordan","lebanon","egypt","israel","turkey","turkiye","arab","mena","middle east"),
                    "latin_america":("mexico","mexican","brazil","brasil","argentina","colombia","peru","chile","bolivia","uruguay","paraguay","ecuador","panama","guatemala","costa rica","el salvador","latam","latin america"),
                    "north_america":("usa","u.s.","united states","american","canada","canadian","north america"),
                    "africa":("south africa","morocco","maroc","tunisia","nigeria","kenya","algeria","africa","african"),
                    "asia":("india","indian","malaysia","vietnam","cambodia","laos","myanmar","indonesia","singapore","philippines","thailand","korea","korean","japan","japanese","hong kong","macau","taiwan","asia","asian"),
                    "europe":("uk","united kingdom","britain","british","england","spain","spanish","france","french","italy","italian","germany","german","portugal","poland","greece","ukraine","romania","czech","hungary","croatia","lithuania","slovakia","slovenia","sweden","norway","denmark","finland","bulgaria","latvia","cyprus","malta","estonia","iceland","netherlands","belgium","switzerland","austria","ireland","europe","european"),
                }
                def _region(_meta):
                    _low=(" "+str(_meta or "").lower()+" ").replace("_"," ").replace("-"," ")
                    for _gid in ("middle_east","latin_america","north_america","africa","asia","europe"):
                        if any((" "+_x+" ") in _low for _x in _regions.get(_gid,())):
                            return _gid
                    return "other"
                _entries=[]; _i=0
                while _i<len(_lines):
                    _meta=_lines[_i].strip()
                    if _meta.startswith("#EXTINF"):
                        _j=_i+1
                        while _j<len(_lines) and (not _lines[_j].strip() or _lines[_j].lstrip().startswith("#")):
                            _j+=1
                        if _j<len(_lines):
                            _stream=_lines[_j].strip()
                            if _stream and not _stream.startswith("#"):
                                _c=_region(_meta)
                                if _xiaomi_group=="all" or _c==_xiaomi_group:
                                    _entries.append((_meta,_stream))
                            _i=_j
                    _i+=1
                if not _entries:
                    self.session.open(MessageBox,"No Xiaomi TV+ channels were returned for this category.",MessageBox.TYPE_INFO,timeout=5)
                    return
                _safe=re.sub(r"[^a-z0-9_-]+","_",_xiaomi_group)
                _path="/etc/enigma2/tivimatee2_xiaomi_%s.m3u"%_safe
                with open(_path,"w") as _fh:
                    _fh.write((_xiaomi_header or "#EXTM3U")+"\n")
                    _seen=set()
                    for _meta,_stream in _entries:
                        _key=str(_stream or "").strip()
                        if _key in _seen: continue
                        _seen.add(_key)
                        _fh.write(_meta+"\n"+_stream+"\n")
                source={"type":"m3u","name":str(row.get("display_name") or "XIAOMI TV+"),"url":_path,"path":_path,"m3u_mode":"file","service_type":4097,"fast_service":"xiaomi","fast_region":_xiaomi_group}
                if _xiaomi_epg:
                    source["epg_url"]=_xiaomi_epg
            except Exception as exc:
                self.session.open(MessageBox,"Could not build Xiaomi TV+ package.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=7)
                return
        elif source is None and not _samsung_group:
            source=None

        # IPTV-Org grouped Arabic playlists: build one local M3U from all relevant
        # official public playlists. Exact duplicate stream URLs are collapsed when
        # the local group is written; different URLs for the same channel are kept.
        _iptvorg_group=str(row.get("iptvorg_group") or "").strip().lower()
        if source is None and kind=="m3u" and _iptvorg_group:
            try:
                from .web_manager import _urlopen_text
                _base="https://iptv-org.github.io/iptv/"
                _arab_codes=set(("ae","sa","qa","kw","bh","om","eg","iq","jo","lb","sy","ps","ye","ly","tn","dz","ma","sd","so","mr","dj","km"))
                _urls=[
                    _base+"languages/ara.m3u", _base+"regions/arab.m3u", _base+"regions/gcc.m3u",
                    _base+"regions/mena.m3u", _base+"regions/mideast.m3u", _base+"regions/maghreb.m3u"
                ] + [_base+"countries/%s.m3u"%x for x in sorted(_arab_codes)]
                if _iptvorg_group=="sports":
                    _urls += [_base+"categories/sports.m3u", _base+"countries/uk.m3u"]
                _keywords={
                    "general":("group-title=\"general\"","group-title='general'","group-title=general"," general","public"),
                    "sports":("sport","bein","be in","sky sport","ssc","alkass","ad sports","dubai sports","riyadi"),
                    "mbc":("mbc",),
                    "shahid":("shahid",),
                    "mbcshahid":("mbc","shahid","al arabiya","alarabiya","al hadath","alhadath","العربية","الحدث"),
                    "movies":("movie","movies","film","cinema","aflam","افلام","أفلام"),
                    "entertainment":("entertainment","series","drama","comedy","lifestyle","music","مسلسل","دراما","ترفيه"),
                    "news":("news","اخبار","أخبار"),
                    "kids":("kids","children","cartoon","animation","family","طفل","اطفال","أطفال","كرتون"),
                    "culture":("culture","documentary","education","science","travel","ثقاف","وثائق","تعليم","علوم"),
                    "religion":("religious","religion","quran","islam","دين","قرآن","اسلام"),
                }
                _entries=[]
                for _srcurl in _urls:
                    try:
                        _code,_final,_body=_urlopen_text(_srcurl,timeout=8,max_bytes=8388608)
                        if not _body: continue
                        _txt=_body.decode("utf-8","replace") if isinstance(_body,bytes) else str(_body)
                        _lines=_txt.replace("\r\n","\n").replace("\r","\n").split("\n")
                        _i=0
                        while _i < len(_lines):
                            _meta=_lines[_i].strip()
                            if _meta.startswith("#EXTINF"):
                                _j=_i+1
                                while _j<len(_lines) and (not _lines[_j].strip() or _lines[_j].lstrip().startswith("#")):
                                    _j+=1
                                if _j<len(_lines):
                                    _stream=_lines[_j].strip()
                                    if _stream and not _stream.startswith("#"):
                                        _low=_meta.lower()
                                        _keep=(_iptvorg_group=="all")
                                        if not _keep:
                                            _keep=any(k in _low for k in _keywords.get(_iptvorg_group,()))
                                        if _iptvorg_group=="sports" and ("bein" in _low or "be in" in _low or "sky sport" in _low):
                                            _keep=True
                                        if _keep: _entries.append((_meta,_stream))
                                    _i=_j
                            _i+=1
                    except Exception:
                        continue
                if not _entries:
                    self.session.open(MessageBox,"No channels were returned for this IPTV-Org group.",MessageBox.TYPE_INFO,timeout=5)
                    return
                # Stable Arabic channel order inside every generated package:
                # MBC first, then Gulf networks by country, then Egypt/Levant/Iraq/Maghreb,
                # and finally the remaining Arabic channels. This changes presentation only.
                _country_markers=(
                    (0,("mbc",)),
                    (10,("uae","emirates","dubai","abu dhabi","abudhabi","sharjah","الإمارات","دبي","أبوظبي","الشارقة")),
                    (11,("saudi","ksa","saudi arabia","السعودية","السعوديه")),
                    (12,("kuwait","الكويت")),
                    (13,("qatar","doha","قطر","الدوحة")),
                    (14,("bahrain","البحرين")),
                    (15,("oman","muscat","عمان","مسقط")),
                    (20,("egypt","masr","cairo","مصر","القاهرة")),
                    (30,("lebanon","beirut","لبنان","بيروت","syria","sham","سوريا","الشام","jordan","الأردن","palestine","فلسطين")),
                    (40,("iraq","baghdad","العراق","بغداد")),
                    (50,("morocco","المغرب","algeria","الجزائر","tunisia","تونس","libya","ليبيا","mauritania","موريتانيا")),
                )
                def _arabic_channel_rank(_item):
                    _m=str(_item[0] or "").lower().replace("_"," ").replace("-"," ")
                    _name=_m.rsplit(",",1)[-1].strip()
                    _rank=80
                    for _r,_marks in _country_markers:
                        if any(_x in _m for _x in _marks):
                            _rank=_r; break
                    _num=re.search(r"(?:^|\s)(\d{1,3})(?:\s|$)",_name)
                    _n=int(_num.group(1)) if _num else 999
                    return (_rank,_name.split()[0] if _name else "",_n,_name)
                _entries.sort(key=_arabic_channel_rank)

                # Combined MBC/Shahid/news package. Keep MBC first, Shahid second,
                # and MBC-group news (Al Arabiya/Al Hadath) last.
                if _iptvorg_group in ("mbc","mbcshahid"):
                    _mbc_order=("mbc 1","mbc1","mbc 2","mbc2","mbc 3","mbc3","mbc 4","mbc4","mbc 5","mbc5",
                                "mbc action","mbc max","mbc drama","mbc bollywood","mbc masr 2","mbc masr","mbc iraq")
                    def _mbc_rank(_item):
                        _m=str(_item[0] or "").lower().replace("_"," ").replace("-"," ")
                        for _ix,_key in enumerate(_mbc_order):
                            if _key in _m:
                                return (0,_ix,_m)
                        if "mbc" in _m:
                            return (0,900,_m)
                        if "shahid" in _m:
                            return (1,0,_m)
                        if any(_k in _m for _k in ("al arabiya","alarabiya","al hadath","alhadath","العربية","الحدث")):
                            return (2,0,_m)
                        return (3,0,_m)
                    _entries.sort(key=_mbc_rank)
                _safe=re.sub(r"[^a-z0-9_-]+","_",_iptvorg_group)
                _path="/etc/enigma2/tivimatee2_iptvorg_arabic_%s.m3u"%_safe
                with open(_path,"w") as _fh:
                    _fh.write("#EXTM3U\n")
                    _seen_streams=set()
                    for _meta,_stream in _entries:
                        # De-duplicate the actual stream link across all overlapping
                        # Arabic IPTV-Org source playlists. Normalize harmless textual
                        # differences only; keep query strings because they may identify
                        # genuinely different feeds.
                        _stream_key=str(_stream or "").strip().replace("&amp;","&")
                        _hash=_stream_key.find("#")
                        if _hash>0:
                            _stream_key=_stream_key[:_hash]
                        _stream_key=_stream_key.rstrip("/")
                        if _stream_key in _seen_streams:
                            continue
                        _seen_streams.add(_stream_key)
                        _fh.write(_meta+"\n"+_stream+"\n")
                # MBC & SHAHID only: prefer service type 5002 for its HLS/audio handling.
                # Other IPTV-Org groups keep the normal 4097 player path.
                _svc_type=(5002 if _iptvorg_group in ("mbc","shahid","mbcshahid") else 4097)
                source={"type":"m3u","name":str(row.get("display_name") or "ARABIC IPTV-ORG"),"url":_path,"path":_path,"m3u_mode":"file","service_type":_svc_type}
            except Exception as exc:
                self.session.open(MessageBox,"Could not build Arabic IPTV-Org package.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=7)
                return
        elif source is None and not _samsung_group and not _xiaomi_group:
            source=None
        try:
            if source is not None:
                pass
            elif kind=="xtream":
                from .web_manager import _xtream_from_m3u_url
                xt=_xtream_from_m3u_url(url)
                if not xt:
                    self.session.open(MessageBox,"Xtream credentials were not found in this result.",MessageBox.TYPE_ERROR,timeout=5)
                    return
                host=str(xt.get("url") or "").rstrip("/")
                name=host.replace("http://","").replace("https://","").split("/")[0] or "Xtream Server"
                source={
                    "type":"xtream","name":name,"url":host,
                    "username":str(xt.get("username") or ""),
                    "password":str(xt.get("password") or ""),
                    "output":str(xt.get("output") or "ts"),
                    "service_type":4097
                }
            elif kind=="m3u":
                # Telegram often publishes an Xtream get.php playlist URL in
                # an M3U-labelled post.  Preserve its username/password by
                # adding it as Xtream instead of stripping it down to a fake
                # /playlist.m3u8 style source.
                try:
                    from .web_manager import _xtream_from_m3u_url
                    xt=_xtream_from_m3u_url(url)
                except Exception:
                    xt=None
                if xt:
                    host=str(xt.get("url") or "").rstrip("/")
                    name=host.replace("http://","").replace("https://","").split("/")[0] or "Xtream Server"
                    source={
                        "type":"xtream","name":name,"url":host,
                        "username":str(xt.get("username") or ""),
                        "password":str(xt.get("password") or ""),
                        "output":str(xt.get("output") or "ts"),
                        "service_type":4097
                    }
                else:
                    try:
                        parsed=urlparse(url)
                        if str(parsed.path or "").lower().endswith(".m3u8"):
                            self.session.open(MessageBox,"This result is a direct HLS stream, not a full M3U playlist. It was not added.",MessageBox.TYPE_INFO,timeout=5)
                            return
                    except Exception:
                        pass
                    host=url.replace("http://","").replace("https://","").split("/")[0]
                    source={"type":"m3u","name":str(row.get("display_name") or host or "M3U Server"),"url":url,"m3u_mode":"url","service_type":4097}
            elif kind=="stalker":
                host=url.replace("http://","").replace("https://","").split("/")[0]
                mac=self._rowMac(row)
                if not mac:
                    # Reuse only a MAC already saved for this same portal.
                    try:
                        target_host=host.lower()
                        for saved in (get_sources() or []):
                            if str(saved.get("type") or "").lower()!="stalker":
                                continue
                            saved_url=str(saved.get("url") or "").strip()
                            saved_host=saved_url.replace("http://","").replace("https://","").split("/")[0].lower()
                            candidate=str(saved.get("mac") or "").strip().upper().replace("-",":")
                            if saved_host==target_host and re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$",candidate):
                                mac=candidate
                                break
                    except Exception:
                        mac=""
                if not mac:
                    self.session.open(MessageBox,"This Stalker result has no MAC attached to it. It was not added.",MessageBox.TYPE_INFO,timeout=5)
                    return
                source={"type":"stalker","name":host or "Stalker Portal","url":url,"mac":mac,"service_type":4097}
            else:
                return
        except Exception as exc:
            self.session.open(MessageBox,"Could not prepare this server.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=6)
            return

        # Persist origin so Home -> Switch Server can distinguish manually
        # configured IPTV servers from anything added through Server Finder.
        source["_from_server_finder"] = True
        _post = row.get("post") if isinstance(row.get("post"), dict) else {}
        _origin = str(_post.get("finder_source") or row.get("finder_source") or row.get("fast_service") or "server_finder").strip().lower()
        source["finder_source"] = _origin or "server_finder"

        self._pendingAddSource=source
        label={"xtream":"Xtream","stalker":"Stalker","m3u":"M3U"}.get(kind,kind.upper())
        self.session.openWithCallback(
            self._confirmAddServer,
            MessageBox,
            "Add this %s server to Server & Playlists?\n\n%s"%(label,str(source.get("name") or url)),
            type=MessageBox.TYPE_YESNO,
            default=True
        )

    def _confirmAddServer(self,answer=False):
        source=getattr(self,"_pendingAddSource",None)
        self._pendingAddSource=None
        if not answer or not isinstance(source,dict):
            return
        try:
            srcs=list(get_sources() or [])
            stype=str(source.get("type") or "").lower()
            duplicate=False
            for item in srcs:
                if str(item.get("type") or "").lower()!=stype:
                    continue
                if stype=="xtream":
                    if ((str(item.get("url") or "").rstrip("/")==str(source.get("url") or "").rstrip("/")) and
                        str(item.get("username") or "")==str(source.get("username") or "")):
                        duplicate=True; break
                elif stype=="stalker":
                    if ((str(item.get("url") or "").rstrip("/")==str(source.get("url") or "").rstrip("/")) and
                        str(item.get("mac") or "").upper()==str(source.get("mac") or "").upper()):
                        duplicate=True; break
                elif stype=="m3u":
                    if str(item.get("url") or "").strip()==str(source.get("url") or "").strip():
                        duplicate=True; break
            if duplicate:
                self.session.open(MessageBox,"This server already exists in Server & Playlists.",MessageBox.TYPE_INFO,timeout=4)
                return

            srcs.append(source)
            set_sources(srcs)
            write_playlists(srcs)
            try:
                from .web_manager import _save_service_types
                _save_service_types(source,4097)
            except Exception:
                pass

            # Verify persistence before reporting success.  A discovered Stalker
            # portal without a MAC is intentionally stored as discovery_pending
            # so it appears in Server & Playlists and can be completed later.
            saved_ok = False
            for item in (get_sources() or []):
                if str(item.get("type") or "").lower() != stype:
                    continue
                if stype == "stalker":
                    same_url = str(item.get("url") or "").rstrip("/") == str(source.get("url") or "").rstrip("/")
                    same_mac = str(item.get("mac") or "").strip().upper() == str(source.get("mac") or "").strip().upper()
                    if same_url and same_mac:
                        saved_ok = True; break
                elif stype == "xtream":
                    if (str(item.get("url") or "").rstrip("/") == str(source.get("url") or "").rstrip("/") and
                        str(item.get("username") or "") == str(source.get("username") or "")):
                        saved_ok = True; break
                elif stype == "m3u" and str(item.get("url") or "").strip() == str(source.get("url") or "").strip():
                    saved_ok = True; break
            if not saved_ok:
                raise RuntimeError("Server was not persisted")

            self["detailAction"].setText("✓  SERVER ADDED")
            msg = "%s added successfully to Server & Playlists." % {"xtream":"Xtream server","stalker":"Stalker portal","m3u":"M3U playlist"}.get(stype,"Server")
            if stype=="m3u":
                msg += "\n\nSaved exact URL (%d chars)." % len(str(source.get("url") or ""))
            if stype == "stalker" and not str(source.get("mac") or "").strip():
                msg += "\n\nPortal saved. Add your authorised MAC in Server & Playlists before playback."
            self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=5)
        except Exception as exc:
            self.session.open(MessageBox,"Could not add server.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=6)



SERVER_HUB_SKIN = r"""<screen name="ServerHub" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_cards_bg_r123.jpg" alphatest="blend" scale="1" zPosition="0"/>

    <widget name="brand" position="72,42" size="390,52" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="title" position="600,38" size="720,46" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
    <widget name="subtitle" position="550,86" size="820,30" font="Regular;19" foregroundColor="#B8C2CB" transparent="1" halign="center" zPosition="5"/>
    <widget name="clock" position="1580,38" size="220,42" font="Regular;33" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
    <widget name="date" position="1550,80" size="280,28" font="Regular;17" foregroundColor="#C8D0D8" transparent="1" halign="center" zPosition="5"/>

    <widget name="focus" position="60,185" size="560,320" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_focus_r123.png" alphatest="blend" zPosition="20"/>

    <widget name="bg0" position="60,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon0" position="92,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name0" position="265,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type0" position="265,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state0" position="265,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry0" position="265,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host0" position="265,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions0" position="90,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg1" position="680,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon1" position="712,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name1" position="885,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type1" position="885,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state1" position="885,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry1" position="885,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host1" position="885,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions1" position="710,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg2" position="1300,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon2" position="1332,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name2" position="1505,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type2" position="1505,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state2" position="1505,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry2" position="1505,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host2" position="1505,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions2" position="1330,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg3" position="60,545" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon3" position="92,598" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name3" position="265,575" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type3" position="265,616" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state3" position="265,662" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry3" position="265,704" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host3" position="265,746" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions3" position="90,814" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg4" position="680,545" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon4" position="712,598" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name4" position="885,575" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type4" position="885,616" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state4" position="885,662" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry4" position="885,704" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host4" position="885,746" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions4" position="710,814" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg5" position="1300,545" size="560,320" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_add_r123.png" alphatest="blend" zPosition="2"/>
    <widget name="icon5" position="1332,598" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_add_r123.png" alphatest="blend" zPosition="4"/>
    <widget name="name5" position="1505,590" size="320,38" font="Regular;27" foregroundColor="#F1C84C" transparent="1" zPosition="5"/>
    <widget name="type5" position="1505,648" size="300,78" font="Regular;18" foregroundColor="#D5DEE6" transparent="1" valign="top" zPosition="5"/>
    <widget name="state5" position="1505,744" size="290,30" font="Regular;17" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>

    <widget name="pageText" position="780,896" size="360,32" font="Regular;18" foregroundColor="#D9E1E8" transparent="1" halign="center" zPosition="5"/>
    <widget name="footer" position="85,985" size="1750,42" font="Regular;19" foregroundColor="#E8EDF2" transparent="1" halign="center" valign="center" zPosition="5"/>
</screen>"""

class ServerHub(Screen):
    skin = SERVER_HUB_SKIN
    POSITIONS=[(60,185),(680,185),(1300,185),(60,545),(680,545),(1300,545)]
    PAGE_SIZE=5

    CARD_BG={
        "xtream":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_xtream_r123.png",
        "stalker":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_stalker_r123.png",
        "m3u":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_m3u_r123.png",
        "generic":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_generic_r123.png"
    }
    CARD_ICON={
        "xtream":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_xtream_r123.png",
        "stalker":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_stalker_r123.png",
        "m3u":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_m3u_r123.png",
        "generic":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_generic_r123.png"
    }

    def __init__(self,session):
        Screen.__init__(self,session)
        self.index=0
        self.page=0
        self.sources=[]
        self["brand"]=Label("TiviMate")
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["clock"]=Label("")
        self["date"]=Label("")
        self["focus"]=Pixmap()
        for i in range(5):
            self["bg%d"%i]=Pixmap()
            self["icon%d"%i]=Pixmap()
            self["name%d"%i]=Label("")
            self["type%d"%i]=Label("")
            self["state%d"%i]=Label("")
            self["expiry%d"%i]=Label("")
            self["host%d"%i]=Label("")
            self["actions%d"%i]=Label("")
        self["bg5"]=Pixmap()
        self["icon5"]=Pixmap()
        self["name5"]=Label("ADD NEW SERVER")
        self["type5"]=Label("Xtream Codes\nStalker Portal\nM3U Playlist")
        self["state5"]=Label("OK  •  Select")
        self["pageText"]=Label("")
        self["footer"]=Label("")

        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions","NumberActions"],{
            "ok":self.openCurrent,
            "cancel":self.close,
            "left":self.left,
            "right":self.right,
            "up":self.up,
            "down":self.down,
            "green":self.openAdd,
            "yellow":self.editSelected,
            "red":self.deleteSelected,
            "blue":self.openSelectedServerFilter,
            "0":self.openIPTVFinder
        },-1)

        self._clockTimer=eTimer()
        _connect_timer(self._clockTimer,self.updateClock)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._cleanup)

    def _ready(self):
        self.refresh()
        self.updateClock()
        try:self._clockTimer.start(30000,False)
        except Exception:pass

    def _cleanup(self):
        try:self._clockTimer.stop()
        except Exception:pass

    def updateClock(self):
        try:
            import time
            now=time.localtime()
            self["clock"].setText(time.strftime("%H:%M",now))
            self["date"].setText(time.strftime("%a, %d %b %Y",now))
        except Exception:pass

    @staticmethod
    def _sourceKey(source):
        source=source or {}
        return "%s|%s|%s|%s"%(
            source.get("type",""),
            (source.get("url") or source.get("path") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
            source.get("username",""),
            source.get("mac","")
        )

    def _setPixmap(self,widget,path):
        try:
            pix=LoadPixmap(path)
            if pix is not None:
                widget.instance.setPixmap(pix)
        except Exception:pass

    def _hideServerCard(self,i):
        for key in ("bg","icon","name","type","state","expiry","host","actions"):
            try:self["%s%d"%(key,i)].hide()
            except Exception:pass

    def _showServerCard(self,i):
        for key in ("bg","icon","name","type","state","expiry","host","actions"):
            try:self["%s%d"%(key,i)].show()
            except Exception:pass

    def refresh(self):
        self.sources=list(get_sources() or [])
        max_page=max(0,(len(self.sources)-1)//self.PAGE_SIZE)
        if self.page>max_page:self.page=max_page
        self._render()

    @staticmethod
    def _formatExpiry(value):
        raw=str(value or "").strip()
        if not raw or raw in ("0", "—", "None"):
            return "—"
        try:
            import time
            num=float(raw)
            if num > 100000000000:
                num /= 1000.0
            if num > 1000000000:
                return time.strftime("%d %b %Y", time.localtime(num))
        except Exception:
            pass
        return raw[:22]

    def _render(self):
        start=self.page*self.PAGE_SIZE
        visible=self.sources[start:start+self.PAGE_SIZE]

        for i in range(5):
            if i>=len(visible):
                self._hideServerCard(i)
                continue

            self._showServerCard(i)
            src=visible[i]
            stype=str(src.get("type") or "generic").strip().lower()
            if stype not in ("xtream","stalker","m3u"):
                stype="generic"

            self._setPixmap(self["bg%d"%i],self.CARD_BG[stype])
            self._setPixmap(self["icon%d"%i],self.CARD_ICON[stype])

            name=str(src.get("name") or ("Server %d"%(start+i+1)))
            pretty={"xtream":"Xtream Codes","stalker":"Stalker Portal","m3u":"M3U Playlist","generic":"IPTV Source"}[stype]
            expiry=str(src.get("_last_expiry") or src.get("expiry") or src.get("exp_date") or "—")
            host=str(src.get("url") or src.get("host") or src.get("server") or src.get("portal") or "")
            host=host.replace("http://","").replace("https://","").split("/")[0]

            self["name%d"%i].setText(name[:25])
            self["type%d"%i].setText(pretty)
            self["state%d"%i].setText("●  Configured")
            self["expiry%d"%i].setText("Expires: %s"%self._formatExpiry(expiry))
            self["host%d"%i].setText(host[:34] if host else "Local / configured source")
            self["actions%d"%i].setText("YELLOW Edit   •   RED Delete   •   OK Open")

        pages=max(1,(len(self.sources)+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["pageText"].setText("Page %d / %d"%(self.page+1,pages))
        self._focus()

    def _focus(self):
        try:
            x,y=self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:pass

    def left(self):
        row=self.index//3
        col=(self.index%3-1)%3
        self.index=row*3+col
        self._focus()

    def right(self):
        row=self.index//3
        col=(self.index%3+1)%3
        self.index=row*3+col
        self._focus()

    def up(self):
        if self.index>=3:
            self.index-=3
            self._focus()
            return
        if self.page>0:
            self.page-=1
            self.index=min(self.index+3,5)
            self._render()
            return
        self.index=min(self.index+3,5)
        self._focus()

    def down(self):
        if self.index<3:
            self.index+=3
            self._focus()
            return
        max_page=max(0,(len(self.sources)-1)//self.PAGE_SIZE)
        if self.page<max_page:
            self.page+=1
            self.index=max(0,self.index-3)
            self._render()
            return
        self.index=max(0,self.index-3)
        self._focus()

    def _selectedIndex(self):
        if self.index==5:return -1
        pos=self.page*self.PAGE_SIZE+self.index
        return pos if 0<=pos<len(self.sources) else -1

    def _selected(self):
        pos=self._selectedIndex()
        return self.sources[pos] if pos>=0 else None

    def openCurrent(self):
        if self.index==5:
            self.openAdd()
            return
        if self._selected() is not None:
            self.editSelected()

    def openIPTVFinder(self):
        self.session.open(TiviMateE2IPTVFinder)


    def openAdd(self):
        self.session.openWithCallback(self._chooseSourceType,SourceTypePicker)

    def _chooseSourceType(self,source_type=None):
        if source_type=="xtream":
            self.session.openWithCallback(self._saveNew,PlaylistEditor,None)
        elif source_type=="stalker":
            self.session.openWithCallback(self._saveNew,StalkerPortalEditor,None)
        elif source_type=="m3u":
            self.session.openWithCallback(self._saveNew,M3UPlaylistEditor,None)

    def _saveNew(self,source=None):
        if not isinstance(source,dict):return
        srcs=list(get_sources() or [])
        srcs.append(source)
        set_sources(srcs)
        write_playlists(srcs)
        self.refresh()
        try:self.session.open(MessageBox,"Server saved.",MessageBox.TYPE_INFO,timeout=3)
        except Exception:pass

    def editSelected(self):
        source=self._selected()
        if not source:return
        pos=self._selectedIndex()
        callback=lambda edited=None:self._replaceAt(pos,source,edited)
        stype=str(source.get("type") or "").lower()
        if stype=="xtream":
            self.session.openWithCallback(callback,PlaylistEditor,source)
        elif stype=="stalker":
            self.session.openWithCallback(callback,StalkerPortalEditor,source)
        elif stype=="m3u":
            self.session.openWithCallback(callback,M3UPlaylistEditor,source)

    def _replaceAt(self,pos,old,new=None):
        if not isinstance(new,dict):return
        srcs=list(get_sources() or [])
        replaced=False
        if 0<=pos<len(srcs) and (srcs[pos]==old or self._sourceKey(srcs[pos])==self._sourceKey(old)):
            srcs[pos]=new
            replaced=True
        if not replaced:
            old_key=self._sourceKey(old)
            for i,item in enumerate(srcs):
                if item==old or self._sourceKey(item)==old_key:
                    srcs[i]=new
                    replaced=True
                    break
        if not replaced:srcs.append(new)
        set_sources(srcs)
        write_playlists(srcs)
        self.refresh()

    def openSelectedServerFilter(self):
        source=self._selected()
        if not isinstance(source,dict):
            self.session.open(
                MessageBox,
                "Select a server card first.",
                MessageBox.TYPE_INFO,
                timeout=3
            )
            return
        stype=str(source.get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self.session.open(
                MessageBox,
                "Packages/channel filtering is available for Xtream Codes and Stalker Portal.",
                MessageBox.TYPE_INFO,
                timeout=5
            )
            return
        self.session.openWithCallback(
            self._serverFilterClosed,
            ServerCategoryFilter,
            dict(source)
        )

    def _serverFilterClosed(self, changed=None):
        if changed:
            try:
                clear_catalog_memory()
            except Exception:
                pass
        self.refresh()

    def deleteSelected(self):
        source=self._selected()
        if not source:return
        name=str(source.get("name") or "server")
        self.session.openWithCallback(
            lambda answer:self._deleteConfirmed(answer,source),
            MessageBox,
            "Delete %s?"%name,
            MessageBox.TYPE_YESNO
        )

    def _deleteConfirmed(self,answer,source):
        if not answer:return
        key=self._sourceKey(source)
        srcs=[item for item in list(get_sources() or []) if not (item==source or self._sourceKey(item)==key)]
        set_sources(srcs)
        write_playlists(srcs)
        self.index=0
        self.refresh()



CACHE_STORAGE_PICKER_SKIN = r"""<screen name="CacheStoragePicker" position="600,280" size="720,470" flags="wfNoBorder" backgroundColor="#07101A">
    <eLabel position="0,0" size="720,470" backgroundColor="#07101A" zPosition="0"/>
    <eLabel position="0,0" size="720,5" backgroundColor="#31B4FF" zPosition="2"/>
    <widget name="title" position="45,35" size="630,46" font="Regular;31" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="4"/>
    <widget name="subtitle" position="45,85" size="630,30" font="Regular;18" foregroundColor="#8FA2B1" transparent="1" halign="center" zPosition="4"/>
    <widget name="focus" position="70,145" size="580,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" zPosition="5"/>
    <widget name="row0" position="92,158" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="row1" position="92,238" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="row2" position="92,318" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="hint" position="45,410" size="630,28" font="Regular;17" foregroundColor="#7E909F" transparent="1" halign="center" zPosition="4"/>
</screen>"""

class CacheStoragePicker(Screen):
    skin = CACHE_STORAGE_PICKER_SKIN
    CHOICES = [("auto", "AUTO  •  HDD → USB → INTERNAL"), ("usb", "USB  •  removable storage"), ("internal", "INTERNAL  •  receiver flash")]
    def __init__(self, session, current="auto"):
        Screen.__init__(self, session)
        keys=[x[0] for x in self.CHOICES]
        try:self.index=keys.index(str(current or "auto"))
        except Exception:self.index=0
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["focus"]=Pixmap()
        for i,(_k,label) in enumerate(self.CHOICES): self["row%d"%i]=Label(label)
        self["hint"]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"], {"up":self.up,"down":self.down,"ok":self.ok,"cancel":self.close}, -1)
        self.onLayoutFinish.append(self._focus)
    def _focus(self):
        try:self["focus"].instance.move(ePoint(sx(70),sy(145 + self.index*80)))
        except Exception:pass
    def up(self): self.index=(self.index-1)%len(self.CHOICES); self._focus()
    def down(self): self.index=(self.index+1)%len(self.CHOICES); self._focus()
    def ok(self): self.close(self.CHOICES[self.index][0])

SETTINGS_DASHBOARD_SKIN = r"""<screen name="SettingsDashboard" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_default.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus0" position="64,340" size="667,212" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_0.png" alphatest="blend" zPosition="8"/>
    <widget name="focus1" position="752,340" size="658,215" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_1.png" alphatest="blend" zPosition="8"/>
    <widget name="focus2" position="64,569" size="667,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_2.png" alphatest="blend" zPosition="8"/>
    <widget name="focus3" position="752,570" size="658,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_3.png" alphatest="blend" zPosition="8"/>
    <widget name="focus4" position="65,772" size="1345,155" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_4.png" alphatest="blend" zPosition="8"/>
    <widget name="langFocus0" position="208,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus1" position="506,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus2" position="823,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus3" position="1121,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="statusTitle" position="1500,88" size="330,34" font="Regular;24" foregroundColor="#F1C84C" transparent="1" zPosition="9"/>
    <eLabel position="1500,128" size="72,3" backgroundColor="#E2B84B" zPosition="9"/>
    <widget name="serverName" position="1500,150" size="220,32" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" zPosition="9"/>
    <widget name="serverTypeIcon" position="1500,181" size="40,40" transparent="1" alphatest="blend" scale="1" zPosition="10"/>
    <widget name="serverType" position="1548,190" size="172,26" font="Regular;16" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <widget name="serverState" position="1725,153" size="105,30" font="Regular;16" foregroundColor="#71E65A" transparent="1" halign="right" zPosition="9"/>
    <widget name="expiryText" position="1500,224" size="330,30" font="Regular;17" foregroundColor="#74E95C" transparent="1" zPosition="9"/>
    <eLabel position="1500,266" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="serverCount" position="1500,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <widget name="favoriteCount" position="1612,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <widget name="bouquetCount" position="1725,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <eLabel position="1500,348" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="ramText" position="1500,368" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,402" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="ramBar" position="1500,402" size="330,10" borderWidth="0" foregroundColor="#57D55A" backgroundColor="#202932" zPosition="9"/>
    <widget name="cpuText" position="1500,436" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,470" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="cpuBar" position="1500,470" size="330,10" borderWidth="0" foregroundColor="#35A9E7" backgroundColor="#202932" zPosition="9"/>
    <widget name="storageText" position="1500,504" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,538" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="storageBar" position="1500,538" size="330,10" borderWidth="0" foregroundColor="#F0B63D" backgroundColor="#202932" zPosition="9"/>
    <widget name="cacheFocus" position="1492,586" size="346,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_cache_focus_r223.png" alphatest="blend" zPosition="10"/>
    <widget name="cacheTitle" position="1500,558" size="330,24" font="Regular;16" foregroundColor="#90A0AE" transparent="1" zPosition="9"/>
    <widget name="cacheStorage" position="1503,591" size="324,34" font="Regular;18" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="cacheInfo" position="1500,626" size="330,22" font="Regular;14" foregroundColor="#A9B5BF" transparent="1" zPosition="9"/>
    <widget name="flashLimitText" position="1503,653" size="324,30" font="Regular;16" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="flashReserveText" position="1503,687" size="324,30" font="Regular;16" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="cacheClear" position="1503,721" size="324,30" font="Regular;16" foregroundColor="#FF7676" transparent="1" valign="center" zPosition="11"/>
    <widget name="connectionsText" position="1500,765" size="330,24" font="Regular;16" foregroundColor="#4EB8FF" transparent="1" zPosition="9"/>
    <widget name="ipText" position="1500,794" size="330,24" font="Regular;15" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <widget name="uptimeText" position="1500,823" size="330,24" font="Regular;15" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <eLabel position="1500,854" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="serverDetail" position="1500,867" size="330,76" font="Regular;16" foregroundColor="#D9E1E8" transparent="1" valign="top" zPosition="9"/>
</screen>"""

class SettingsDashboard(Screen):
    skin = SETTINGS_DASHBOARD_SKIN
    ITEMS=[("servers","Server & Playlists"),("skin","Skin & Poster View"),("subtitle","Subtitle"),("backup","Backup & System"),("tmdb","TMDb Settings")]
    def __init__(self,session):
        Screen.__init__(self,session); self.index=0; self.focusZone="cards"
        self.languageIndex={"en":0,"ar":1,"fr":2,"tr":3}.get(get_language(),0)
        for i in range(5): self["focus%d"%i]=Pixmap()
        for i in range(4): self["langFocus%d"%i]=Pixmap()
        self["statusTitle"]=Label("SERVER STATUS")
        for n in ("serverName","serverType","serverState","expiryText","serverCount","favoriteCount","bouquetCount","ramText","cpuText","storageText","connectionsText","ipText","uptimeText","serverDetail","cacheTitle","cacheStorage","cacheInfo","flashLimitText","flashReserveText","cacheClear"): self[n]=Label("")
        self["serverTypeIcon"]=Pixmap()
        self["cacheFocus"]=Pixmap()
        self["ramBar"]=ProgressBar(); self["cpuBar"]=ProgressBar(); self["storageBar"]=ProgressBar()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{"ok":self.openCurrent,"cancel":self.close,"red":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,"green":self.openAddServer,"yellow":self.openServerHub,"blue":self.refreshStatus},-1)
        self._timer=eTimer(); _connect_timer(self._timer,self.refreshStatus); self._lastCpu=None
        self._expiryProbeRunning=False; self._expiryProbeDoneKey=None; self._expiryProbeResult=None
        self._expiryTimer=eTimer(); _connect_timer(self._expiryTimer,self._finishExpiryProbe)
        self.cacheIndex=0; self._cacheStatusAt=0.0; self._cacheSize=0; self._cacheFiles=0
        self.onLayoutFinish.append(self._ready); self.onClose.append(self._cleanup)
    def _ready(self):
        self._focus(); self.refreshStatus()
        try:self._timer.start(3000,False)
        except Exception:pass
    def _cleanup(self):
        try:self._timer.stop()
        except Exception:pass
        try:self._expiryTimer.stop()
        except Exception:pass
        self._expiryProbeRunning=False
        self._expiryProbeResult=None
    def _focus(self):
        for i in range(5):
            try:self["focus%d"%i].hide()
            except Exception:pass
            try:self["langFocus%d"%i].hide()
            except Exception:pass
        try:self["cacheFocus"].hide()
        except Exception:pass
        if self.focusZone == "language":
            try:self["langFocus%d"%self.languageIndex].show()
            except Exception:pass
        elif self.focusZone == "cache":
            try:
                y=(586,648,682,716)[max(0,min(3,self.cacheIndex))]
                self["cacheFocus"].instance.move(ePoint(sx(1492),sy(y)))
                self["cacheFocus"].show()
            except Exception:pass
        else:
            try:self["focus%d"%self.index].show()
            except Exception:pass
    def left(self):
        if self.focusZone == "language": self.languageIndex=(self.languageIndex-1)%4
        elif self.focusZone == "cache":
            self.focusZone="cards"; self.index=1 if self.cacheIndex==0 else 3
        else:
            if self.index == 4: return
            self.index=self.index-1 if self.index%2 else self.index+1
        self._focus()
    def right(self):
        if self.focusZone == "language": self.languageIndex=(self.languageIndex+1)%4
        elif self.focusZone == "cache": return
        elif self.index in (1,3):
            self.focusZone="cache"; self.cacheIndex=0 if self.index==1 else (3 if not is_internal_cache_active() else 1)
        elif self.index == 4: return
        else: self.index=self.index+1
        self._focus()
    def up(self):
        if self.focusZone == "language": return
        if self.focusZone == "cache":
            internal=is_internal_cache_active()
            if internal: self.cacheIndex=max(0,self.cacheIndex-1)
            else: self.cacheIndex=0
            self._focus(); return
        if self.index < 2: self.focusZone="language"
        elif self.index == 4: self.index=2
        else: self.index-=2
        self._focus()
    def down(self):
        if self.focusZone == "language":
            self.focusZone="cards"; self.index=0
        elif self.focusZone == "cache":
            internal=is_internal_cache_active()
            if internal: self.cacheIndex=min(3,self.cacheIndex+1)
            else: self.cacheIndex=3
        elif self.index < 2: self.index+=2
        elif self.index in (2,3): self.index=4
        self._focus()
    @staticmethod
    def _read(path,default=""):
        try:
            with open(path,"r") as h:return h.read().strip()
        except Exception:return default
    def _memory(self):
        vals={}
        try:
            with open("/proc/meminfo","r") as h:
                for line in h:
                    if ":" in line:
                        k,v=line.split(":",1); vals[k]=int(v.strip().split()[0])
        except Exception:pass
        total=int(vals.get("MemTotal",0)); avail=int(vals.get("MemAvailable",vals.get("MemFree",0))); used=max(0,total-avail); pct=int(round(100.0*used/total)) if total else 0
        return total,avail,pct
    def _cpu_usage(self):
        try:
            vals=[int(x) for x in self._read("/proc/stat","").splitlines()[0].split()[1:]]; idle=vals[3]+(vals[4] if len(vals)>4 else 0); total=sum(vals); now=(idle,total)
            if self._lastCpu is None:self._lastCpu=now; return 0
            idle_d=idle-self._lastCpu[0]; total_d=total-self._lastCpu[1]; self._lastCpu=now
            return max(0,min(100,int(round(100.0*(1.0-idle_d/float(total_d)))))) if total_d>0 else 0
        except Exception:return 0
    def _storage(self):
        try:
            target="/media/hdd" if os.path.ismount("/media/hdd") else "/"; st=os.statvfs(target); total=float(st.f_blocks*st.f_frsize); free=float(st.f_bavail*st.f_frsize); used=max(0.0,total-free); pct=int(round(100.0*used/total)) if total else 0; return total,free,pct
        except Exception:return 0.0,0.0,0
    def _ip(self):
        try:
            import socket; sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            try:sock.connect(("8.8.8.8",80)); return sock.getsockname()[0]
            finally:sock.close()
        except Exception:return "n/a"
    def _uptime(self):
        try:
            sec=int(float(self._read("/proc/uptime","0").split()[0])); d,r=divmod(sec,86400); h,r=divmod(r,3600); m=r//60; return ("%dd %dh %dm"%(d,h,m)) if d else ("%dh %dm"%(h,m))
        except Exception:return "n/a"
    def _connections(self):
        c=0
        for p in ("/proc/net/tcp","/proc/net/tcp6"):
            try:
                for line in self._read(p,"").splitlines()[1:]:
                    cols=line.split(); c += 1 if len(cols)>3 and cols[3]=="01" else 0
            except Exception:pass
        return c
    def _cacheDisplay(self):
        cfg=get_cache_settings() or {}; loc=str(cfg.get("location") or "auto").lower()
        labels={"hdd":"HDD","usb":"USB","internal":"INTERNAL","auto":"AUTO","mmc":"MMC","tmp":"TMP"}
        self["cacheTitle"].setText("CACHE STORAGE")
        self["cacheStorage"].setText("%s   •   OK to change" % labels.get(loc,loc.upper()))
        internal = is_internal_cache_active()
        if internal:
            lim=int(cfg.get("flash_image_limit",20) or 0); reserve=int(cfg.get("flash_min_free_mb",30) or 0)
            self["flashLimitText"].setText("FLASH IMAGES   •   %s   •   OK" % (str(lim) if lim else "Unlimited"))
            self["flashReserveText"].setText("FLASH RESERVE  •   %s   •   OK" % ((str(reserve)+" MB") if reserve else "Disabled"))
        else:
            self["flashLimitText"].setText(""); self["flashReserveText"].setText("")
        self["cacheClear"].setText("CLEAR CACHE   •   OK")
        try:
            root=get_cache_root(); st=os.statvfs(root); free=float(st.f_bavail*st.f_frsize)/(1024.0**3)
        except Exception:
            root=""; free=0.0
        now=time.time()
        if (not self._cacheStatusAt) or now-self._cacheStatusAt>60:
            try:
                _r,size,files=cache_status(); self._cacheSize=size; self._cacheFiles=files; self._cacheStatusAt=now
            except Exception:pass
        self["cacheInfo"].setText("Cache %.1f MB   •   Free %.1f GB" % (float(self._cacheSize)/1048576.0, free))
    def _openCacheStorage(self):
        cfg=get_cache_settings() or {}; current=str(cfg.get("location") or "auto").lower()
        choices=[
            ("AUTO  •  HDD → USB → MMC → INTERNAL", "auto"),
            ("HDD  •  /media/hdd", "hdd"),
            ("USB  •  /media/usb", "usb"),
            ("MMC  •  /media/mmc", "mmc"),
            ("INTERNAL  •  receiver flash", "internal"),
            ("TMP  •  temporary /tmp", "tmp"),
        ]
        self.session.openWithCallback(self._cacheStorageSelected, ChoiceBox, title="CACHE STORAGE  •  Current: %s" % current.upper(), list=choices)
    def _cacheStorageSelected(self, choice=None):
        if not choice:return
        value=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
        if value not in ("auto","hdd","usb","mmc","internal","tmp"): return
        cfg=get_cache_settings() or {}
        if save_cache_settings(value,0,int(cfg.get("retention_days",0) or 0),int(cfg.get("flash_image_limit",20) or 20),int(cfg.get("flash_min_free_mb",30) or 0)):
            self._cacheStatusAt=0.0; self._cacheDisplay()
            self.session.open(MessageBox, "Cache storage saved. New cached files will use %s." % value.upper(), MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to save cache storage.", MessageBox.TYPE_ERROR)
    def _cycleFlashLimit(self):
        cfg=get_cache_settings() or {}
        if not is_internal_cache_active(): return
        loc=str(cfg.get("location") or "auto").lower()
        vals=[20,40,60,100]; cur=int(cfg.get("flash_image_limit",20) or 20)
        try: new=vals[(vals.index(cur)+1)%len(vals)]
        except Exception: new=20
        if save_cache_settings(loc,0,int(cfg.get("retention_days",0) or 0),new,int(cfg.get("flash_min_free_mb",30) or 0)):
            self._cacheDisplay()

    def _cycleFlashReserve(self):
        cfg=get_cache_settings() or {}
        if not is_internal_cache_active(): return
        loc=str(cfg.get("location") or "auto").lower()
        vals=[0,20,30,50]; cur=int(cfg.get("flash_min_free_mb",30) or 0)
        try: new=vals[(vals.index(cur)+1)%len(vals)]
        except Exception: new=30
        if save_cache_settings(loc,0,int(cfg.get("retention_days",0) or 0),int(cfg.get("flash_image_limit",20) or 20),new):
            self._cacheDisplay()

    def _askClearCache(self):
        self.session.openWithCallback(self._clearCacheConfirmed, MessageBox, "Are you sure you want to clear the cache?", type=MessageBox.TYPE_YESNO, default=False)
    def _clearCacheConfirmed(self, answer=False):
        if not answer:return
        ok=clear_cache()
        if ok:
            try:clear_catalog_memory()
            except Exception:pass
            self._cacheStatusAt=0.0; self._cacheSize=0; self._cacheFiles=0; self._cacheDisplay()
            self.session.open(MessageBox, "Cache cleared successfully.", MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to clear cache.", MessageBox.TYPE_ERROR)

    @staticmethod
    def _formatDashboardExpiry(value):
        raw = str(value or "").strip()
        low = raw.lower()
        if not raw or low in ("0", "none", "null", "—"):
            return "—"
        if low in ("unlimited", "never", "lifetime"):
            return "Unlimited"
        try:
            num = float(raw)
            if num > 100000000000:
                num /= 1000.0
            if num > 1000000000:
                return time.strftime("%d %b %Y", time.localtime(num))
        except Exception:
            pass
        for fmt, size in (("%Y-%m-%d %H:%M:%S",19),("%Y-%m-%d",10),("%d/%m/%Y",10),("%d-%m-%Y",10)):
            try:
                dt = datetime.strptime(raw[:size], fmt)
                return dt.strftime("%d %b %Y")
            except Exception:
                pass
        return raw[:22]

    def _setDashboardType(self, active):
        stype = str((active or {}).get("type") or "").strip().lower()
        labels = {"xtream":"Xtream", "stalker":"Stalker", "m3u":"M3U", "fg":"M3U"}
        icons = {
            "xtream": os.path.join(PLUGIN_PATH,"skins","icon_xtream_r123.png"),
            "stalker": os.path.join(PLUGIN_PATH,"skins","icon_stalker_r123.png"),
            "m3u": os.path.join(PLUGIN_PATH,"skins","icon_m3u_r123.png"),
            "fg": os.path.join(PLUGIN_PATH,"skins","icon_m3u_r123.png"),
        }
        self["serverType"].setText(labels.get(stype, "IPTV" if stype else "NOT CONFIGURED"))
        try:
            path = icons.get(stype)
            if path and os.path.exists(path):
                self["serverTypeIcon"].instance.setPixmapFromFile(path)
                self["serverTypeIcon"].show()
            else:
                self["serverTypeIcon"].hide()
        except Exception:
            try:self["serverTypeIcon"].hide()
            except Exception:pass

    @staticmethod
    def _dashboardSourceKey(source):
        source=source or {}
        return "|".join((str(source.get("type") or ""), str(source.get("url") or source.get("portal") or ""), str(source.get("username") or source.get("mac") or "")))

    def _startExpiryProbe(self, active):
        if not active or self._expiryProbeRunning:
            return
        key=self._dashboardSourceKey(active)
        if key == self._expiryProbeDoneKey:
            return
        stype=str(active.get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self._expiryProbeDoneKey=key
            return
        self._expiryProbeRunning=True
        source=dict(active)
        def worker():
            expiry=""; ok=False
            try:
                if stype == "xtream":
                    reply=XtreamClient(source).test() or {}
                    if isinstance(reply,dict):
                        user=reply.get("user_info") if isinstance(reply.get("user_info"),dict) else {}
                        expiry=user.get("exp_date") or reply.get("exp_date") or ""
                        ok=bool(user or reply.get("server_info"))
                else:
                    reply=StalkerClient(source).test() or {}
                    if isinstance(reply,dict):
                        expiry=reply.get("expiry") or ""
                        ok=bool(reply.get("ok") or reply.get("profile") or reply.get("handshake"))
            except Exception:
                pass
            self._expiryProbeResult=(key,str(expiry or ""),ok)
        t=threading.Thread(target=worker,name="TiviMateDashboardExpiry")
        t.daemon=True; t.start()
        try:self._expiryTimer.start(150,False)
        except Exception:pass

    def _finishExpiryProbe(self):
        result=self._expiryProbeResult
        if result is None:
            try:self._expiryTimer.start(150,False)
            except Exception:pass
            return
        self._expiryProbeResult=None; self._expiryProbeRunning=False
        key,expiry,ok=result; self._expiryProbeDoneKey=key
        if expiry:
            try:
                sources=list(get_sources() or []); changed=False
                for src in sources:
                    if self._dashboardSourceKey(src)==key:
                        src["_last_expiry"]=expiry; changed=True; break
                if changed:set_sources(sources)
            except Exception:pass
            try:self["expiryText"].setText("Expires: %s" % self._formatDashboardExpiry(expiry))
            except Exception:pass

    def refreshStatus(self):
        sources=list(get_sources() or []); active=sources[0] if sources else {}
        if active:
            self["serverName"].setText(str(active.get("name") or "Server")[:22])
            self._setDashboardType(active)
            self["serverState"].setText("CONNECTED")
            expiry=str(active.get("_last_expiry") or active.get("expiry") or active.get("exp_date") or "").strip()
            self["expiryText"].setText("Expires: %s" % self._formatDashboardExpiry(expiry))
            self._startExpiryProbe(active)
        else:
            self["serverName"].setText("No server")
            self._setDashboardType({})
            self["serverState"].setText("")
            self["expiryText"].setText("Expires: —")
        self["serverCount"].setText("%d\nSERVERS"%len(sources))
        try:fav=int(favourites_count() or 0)
        except Exception:fav=0
        self["favoriteCount"].setText("%d\nFAVORITES"%fav)
        try:bq=len([x for x in os.listdir("/etc/enigma2") if x.startswith("userbouquet.") and x.endswith(".tv")])
        except Exception:bq=0
        self["bouquetCount"].setText("%d\nBOUQUETS"%bq)
        total,free,ram=self._memory(); self["ramText"].setText("RAM Usage  %d%%   •   Free %d MB"%(ram,free//1024 if free else 0)); self["ramBar"].setValue(ram)
        cpu=self._cpu_usage(); self["cpuText"].setText("CPU Usage  %d%%"%cpu); self["cpuBar"].setValue(cpu)
        tb,fb,sp=self._storage(); self["storageText"].setText("Storage  %d%%   •   Free %.1f GB"%(sp,fb/(1024**3) if fb else 0)); self["storageBar"].setValue(sp)
        self._cacheDisplay()
        self["connectionsText"].setText("Connections  %d Active"%self._connections()); self["ipText"].setText("IP Address  %s"%self._ip()); self["uptimeText"].setText("Uptime  %s"%self._uptime())
        if active:
            host=str(active.get("url") or active.get("host") or active.get("server") or active.get("portal") or ""); details=[]
            local_path=str(active.get("path") or "")
            if host: details.append("Host: %s"%host.replace("http://","").replace("https://","").split("/")[0][:34])
            elif local_path: details.append("Source: Imported M3U")
            details.append("Type: %s"%str(active.get("type") or "").upper())
            self["serverDetail"].setText("\n".join(details))
        else:self["serverDetail"].setText("Press GREEN to add a server.")
    def openAddServer(self): self.session.openWithCallback(self._sourceType,SourceTypePicker)
    def _sourceType(self,t=None):
        if t=="xtream":self.session.open(PlaylistEditor,None)
        elif t=="stalker":self.session.open(StalkerPortalEditor,None)
        elif t=="m3u":self.session.open(M3UPlaylistEditor,None)
    def openServerHub(self): self.session.open(ServerHub)
    def openCurrent(self):
        if self.focusZone == "cache":
            if self.cacheIndex==0:self._openCacheStorage()
            elif self.cacheIndex==1:self._cycleFlashLimit()
            elif self.cacheIndex==2:self._cycleFlashReserve()
            else:self._askClearCache()
            return
        if self.focusZone == "language":
            code=("en","ar","fr","tr")[self.languageIndex]
            if save_language(code):
                try:self.session.open(MessageBox, "Language saved. Reopen the app to apply it.", MessageBox.TYPE_INFO, timeout=3)
                except Exception:pass
            return
        a=self.ITEMS[self.index][0]
        if a=="servers": self.session.open(ServerHub); return
        if a=="skin": self.session.open(HomeAppearanceSettings); return
        if a=="subtitle": self.session.open(SubtitleDashboard); return
        if a=="backup": self.session.open(BackupRestoreScreen); return
        if a=="tmdb": self.session.open(TMDbSettings); return
