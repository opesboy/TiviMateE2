# -*- coding: utf-8 -*-
"""Remember the audio / embedded-subtitle LANGUAGE per movie or series.

Same rules as Ultra Stalker's track_prefs (R5.145):
* the LANGUAGE is stored (server_track_memory), never a track number;
* a series shares one entry for all its episodes, servers never share;
* only a title where the user explicitly chose a track has an entry;
* it is applied ONCE per playback, inside a short window (about 15 s), and
  any manual audio/subtitle action cancels the pending apply;
* a choice is captured only when it came from the user's own audio or
  subtitle menu, never from automatic start-up code.

install(player) wraps the player's own methods on the instance, so it works
the same on the Python 3 and Python 2.7 players. Never raises.
"""
from __future__ import absolute_import

_POLL_MS = 1500
_MAX_POLLS = 10


def _log(message):
    try:
        print("[TiviMateE2][tracks] %s" % message)
    except Exception:
        pass


def _store():
    from . import server_track_memory
    return server_track_memory


def _info_language(info):
    store = _store()
    for name in ("getLanguage", "getDescription"):
        try:
            getter = getattr(info, name, None)
            code = store.language(getter()) if callable(getter) else ""
        except Exception:
            code = ""
        if code:
            return code
    return ""


def _subtitle_language(entry):
    try:
        if entry and len(entry) > 4:
            return _store().language(entry[4])
    except Exception:
        pass
    return ""


class _TrackMemory(object):
    def __init__(self, player):
        self.player = player
        self.wanted = {}
        self.polls = 0
        self.audio_done = True
        self.sub_done = True
        self.user_sub_menu = False
        self.audio_before = ""
        self.timer = None
        self.timer_conn = None

    # -- helpers ------------------------------------------------------
    def item(self):
        item = getattr(self.player, "item", None)
        return item if isinstance(item, dict) else {}

    def service(self):
        try:
            return self.player.session.nav.getCurrentService()
        except Exception:
            return None

    def current_audio(self):
        try:
            service = self.service()
            tracks = service.audioTracks() if service else None
            if tracks is None:
                return ""
            count = int(tracks.getNumberOfTracks() or 0)
            current = int(tracks.getCurrentTrack())
            if current < 0 or current >= count:
                return ""
            return _info_language(tracks.getTrackInfo(current))
        except Exception:
            return ""

    def subtitle_list(self):
        try:
            service = self.service()
            subs = service.subtitle() if service else None
            if subs is None:
                return None
            return list(subs.getSubtitleList() or [])
        except Exception:
            return None

    # -- apply once ---------------------------------------------------
    def begin(self):
        self.stop()
        self.polls = 0
        self.audio_done = self.sub_done = True
        self.user_sub_menu = False
        try:
            store = _store()
            if not store.enabled():
                return
            pref = store.get(self.item())
        except Exception:
            pref = {}
        if not pref:
            return
        want_audio = str(pref.get("audio") or "")
        want_sub = str(pref.get("subtitle") or "")
        if want_sub == "off":
            want_sub = ""
        if not (want_audio or want_sub):
            return
        self.wanted = {"audio": want_audio, "sub": want_sub}
        self.audio_done = not want_audio
        self.sub_done = not want_sub
        try:
            from enigma import eTimer
            self.timer = eTimer()
            try:
                self.timer_conn = self.timer.timeout.connect(self.tick)
            except AttributeError:
                self.timer.callback.append(self.tick)
            self.timer.start(_POLL_MS, True)
        except Exception as exc:
            _log("timer failed: %s" % exc)

    def stop(self):
        try:
            if self.timer is not None:
                self.timer.stop()
        except Exception:
            pass
        self.timer = None
        self.timer_conn = None

    def tick(self):
        if getattr(self.player, "_closing", False) or (self.audio_done and self.sub_done):
            return
        self.polls += 1
        final = self.polls >= _MAX_POLLS
        service = self.service()
        if service is not None:
            if not self.audio_done:
                state = self.apply_audio(service, self.wanted.get("audio", ""))
                if state is True or (state is False and final):
                    self.audio_done = True
            if not self.sub_done:
                state = self.apply_subtitle(self.wanted.get("sub", ""))
                if state is True or (state is False and final):
                    self.sub_done = True
        if final:
            self.audio_done = self.sub_done = True
        if not (self.audio_done and self.sub_done) and self.timer is not None:
            try:
                self.timer.start(_POLL_MS, True)
            except Exception:
                pass

    def apply_audio(self, service, lang):
        """True = applied/already right, False = no such track, None = not ready."""
        try:
            tracks = service.audioTracks()
            if tracks is None:
                return None
            count = int(tracks.getNumberOfTracks() or 0)
            if count <= 0:
                return None
            try:
                current = int(tracks.getCurrentTrack())
            except Exception:
                current = -1
            for index in range(count):
                if _info_language(tracks.getTrackInfo(index)) == lang:
                    if index != current:
                        tracks.selectTrack(index)
                        _log("audio language restored: %s" % lang)
                    return True
            return False
        except Exception:
            return None

    def apply_subtitle(self, lang):
        entries = self.subtitle_list()
        if not entries:
            return None if entries is None else False
        current = getattr(self.player, "selected_subtitle", None)
        for entry in entries:
            if _subtitle_language(entry) != lang:
                continue
            try:
                if current is not None and tuple(current) == tuple(entry):
                    return True
            except Exception:
                pass
            try:
                self.player._auto_subtitle_call = True
                try:
                    self.original_enable(entry)
                finally:
                    self.player._auto_subtitle_call = False
                _log("subtitle language restored: %s" % lang)
            except Exception:
                pass
            return True
        return False

    # -- capture user choices ----------------------------------------
    def put(self, **values):
        try:
            _store().put(self.item(), **values)
        except Exception:
            pass


def install(player):
    """Attach per-title track memory to a TiviMate VOD player instance."""
    if getattr(player, "_tivimate_track_memory", None) is not None:
        return player._tivimate_track_memory
    memory = _TrackMemory(player)
    player._tivimate_track_memory = memory

    original_audio_selection = getattr(player, "audioSelection", None)
    original_audio_selected = getattr(player, "audioSelected", None)
    original_enable = getattr(player, "enableSubtitle", None)
    original_sub_menu = getattr(player, "openSubtitleSelection", None)
    original_sub_menu2 = getattr(player, "subtitleSelection", None)
    memory.original_enable = original_enable

    if callable(original_audio_selection):
        def audioSelection(*args, **kwargs):
            # The user takes over: no remembered language after this.
            memory.audio_done = True
            memory.audio_before = memory.current_audio()
            return original_audio_selection(*args, **kwargs)
        player.audioSelection = audioSelection

    if callable(original_audio_selected):
        def audioSelected(*args, **kwargs):
            result = original_audio_selected(*args, **kwargs)
            try:
                lang = memory.current_audio()
                if lang and lang != memory.audio_before:
                    memory.put(audio=lang)
            except Exception:
                pass
            return result
        player.audioSelected = audioSelected

    def _wrap_menu(original):
        def menu(*args, **kwargs):
            memory.sub_done = True
            memory.user_sub_menu = True
            return original(*args, **kwargs)
        return menu

    if callable(original_sub_menu):
        player.openSubtitleSelection = _wrap_menu(original_sub_menu)
    if callable(original_sub_menu2):
        player.subtitleSelection = _wrap_menu(original_sub_menu2)

    if callable(original_enable):
        def enableSubtitle(subtitle, *args, **kwargs):
            result = original_enable(subtitle, *args, **kwargs)
            if memory.user_sub_menu and result is not False:
                if subtitle is None:
                    memory.put(subtitle="off")
                else:
                    lang = _subtitle_language(subtitle)
                    if lang:
                        memory.put(subtitle=lang)
            return result
        player.enableSubtitle = enableSubtitle
    return memory


def service_started(player):
    memory = getattr(player, "_tivimate_track_memory", None)
    if memory is not None:
        memory.begin()


def stop(player):
    memory = getattr(player, "_tivimate_track_memory", None)
    if memory is not None:
        memory.stop()
