# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import requests , random
import json
import re, os
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus
from .YtssubsUtilities import geturl, get_language_info
from ..utilities import log
import base64


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Mobile/15E148 Safari/604.1"
]

def get_random_ua():
    return random.choice(USER_AGENTS)
HDR = {
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/json",
    "priority": "u=1, i",
    "User-Agent": get_random_ua()
    }
HDRDL = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "en-US,en;q=0.9",
    "content-type": "application/x-www-form-urlencoded",
    "priority": "u=1, i",
    "User-Agent": get_random_ua()
    }
session = requests.Session()

session.headers.update({
    "accept": "application/json, text/plain, */*",
    "accept-language": "en-US,en;q=0.9",
    "Referer": "https://yifysubtitles.ch",
    "User-Agent": get_random_ua()
})

BASE_URL = "https://yifysubtitles.ch"
debug_pretext = ""
def prepare_search_string(s):
    s = s.replace("'", "").strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)  # remove year from title
    s = s.replace(" :",":").replace(".", " ")
    print(("s_title", s))
    return s

def getallsubs(html_content, allowed_languages, filename=""):
    """ Extract subtitle links from YIFYSubtitles.ch subtitle page with multiple filenames """
    subtitles = []
    
    soup = BeautifulSoup(html_content, "html.parser")
    subtitle_rows = soup.select("tr[data-id]")  # Select subtitle rows
    
    for row in subtitle_rows:
        try:
            # Extract language
            language = row.select_one("td.flag-cell span.sub-lang").text.strip()

            # Extract download page link
            subtitle_link_tag = row.select_one("td a[href^='/subtitles/']")
            if not subtitle_link_tag:
                continue  # Skip if no valid link

            subtitle_page_link = subtitle_link_tag["href"]
            
            # Ensure correct `<br>` splitting, even if first two names are joined
            subtitle_names = re.split(r"<br\s*/?>", subtitle_link_tag.decode_contents(), flags=re.IGNORECASE)

            # Match language to the correct format
            language_info = get_language_info(language)
            if not language_info or language_info["name"] not in allowed_languages:
                continue

            # Add each subtitle variant separately
            for subtitle_name in subtitle_names:
                subtitle_name = BeautifulSoup(subtitle_name, "html.parser").text.strip()  # Clean HTML tags
                subtitle_name = re.sub(r"^subtitle\s*", "", subtitle_name, flags=re.IGNORECASE)  # Remove "subtitle" only at the start
                subtitle_name = re.sub(r"^\.+", "", subtitle_name)  # Remove leading dots (e.g., ".Moana" -> "Moana")

                if subtitle_name:
                    subtitles.append({
                        "filename": subtitle_name,
                        "sync": True,  # No sync info available
                        "link": BASE_URL + subtitle_page_link,
                        "language_name": language_info["name"],
                        "lang": language_info
                    })

        except Exception as e:
            print(f"Skipping subtitle due to error: {e}")
            continue

    return subtitles

def split_movie_title(movie_entry):
    """Extracts movie name and year from the API response."""
    movie_title = movie_entry.get("movie", "").strip()
    match = re.search(r"^(.*)\s+(\d{4})$", movie_title)  # Match "Title YYYY"

    if match:
        return match.group(1).strip(), match.group(2)  # (Movie Name, Year)
    return movie_title, None  # Return title as-is if no year found

def search_movie(title, year, languages, filename):
    """ Search for a movie on YIFYSubtitles.ch and retrieve subtitles """
    movie_title = prepare_search_string(title)
    try:
        # Prepare search URL
        search_url = f"https://yifysubtitles.ch/ajax/search/?mov={movie_title}"
        response = requests.get(search_url, headers=HDR, timeout=10)

        if response.status_code != 200:
            print(f"Error: Failed to fetch search results for '{movie_title}'")
            return []

        movies = response.json()
        if not movies:
            print(f"No results found for '{movie_title}'")
            return []

        # Try to find an exact year match
        best_match = None
        for movie in movies:
            movie_name, movie_year = split_movie_title(movie)
            if movie_year and movie_year == str(year):  # Exact match
                best_match = movie
                break  # Stop at first perfect match

        if not best_match:
            print(f"No exact year match found, selecting first result.")
            best_match = movies[0]  # Fallback to the first result if no exact match

        imdb_code = best_match.get("imdb")
        if not imdb_code:
            print(f"No IMDb code found for '{movie_title}'")
            return []

        # Fetch subtitles for the selected movie
        movie_url = f"https://yifysubtitles.ch/movie-imdb/{imdb_code}"
        movie_page = requests.get(movie_url, headers=HDR, timeout=10)

        if movie_page.status_code != 200:
            print(f"Error: Failed to fetch subtitle page for '{movie_title}'")
            return []

        return getallsubs(movie_page.text, languages, filename)

    except Exception as error:
        print(f"Error in search_movie: {error}")
        return []




def search_tvshow(title, season, episode, languages, filename):
    """ Search for a movie on YTS-Subs and retrieve subtitles """
    tv_title = prepare_search_string(title)
    try:
        # Search for the movie
        search_url = f"{BASE_URL}/search/ajax/{tv_title}"
        response = requests.get(search_url, headers=HDR, timeout=10)

        if response.status_code != 200:
            print(f"Error: Failed to fetch search results for '{tv_title}'")
            return []

        movies = response.json()
        if not movies:
            print(f"No results found for '{tv_title}'")
            return []

        # Select the best-matching movie (first result)
        selected_movie = movies[0]
        imdb_code = selected_movie.get("mov_imdb_code")
        if not imdb_code:
            print(f"No IMDb code found for '{tv_title}'")
            return []

        # Fetch subtitles for the selected movie
        movie_url = f"{BASE_URL}/movie-imdb/{imdb_code}"
        movie_page = requests.get(movie_url, timeout=10)

        if movie_page.status_code != 200:
            print(f"Error: Failed to fetch subtitle page for '{tv_title}'")
            return []

        return getallsubs(movie_page.text, languages, filename)

    except Exception as error:
        print(f"Error in search_movie: {error}")
        return []

def search_manual(title, languages, filename):
    """No title given: nothing to search."""
    return []


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):  # standard input
    log(__name__, "%s Search_subtitles = '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'" %
         (debug_pretext, file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack))
    if lang1 == 'Farsi':
        lang1 = 'Persian'
    if lang2 == 'Farsi':
        lang2 = 'Persian'
    if lang3 == 'Farsi':
        lang3 = 'Persian'
    if tvshow:
        sublist = search_tvshow(tvshow, season, episode, [lang1, lang2, lang3], file_original_path)
    elif title:
        sublist = search_movie(title, year, [lang1, lang2, lang3], file_original_path)
    else:
        try:
          sublist = search_manual(title, [lang1, lang2, lang3], file_original_path)
        except:
            print("error")
    return sublist, "", ""



import os
import io
import zipfile


def _yify_payload_type(payload):
    """zip / rar / subtitle text, or None for an HTML/Cloudflare page."""
    if not payload:
        return None
    if payload[:4] in (b"PK\x03\x04", b"PK\x05\x06"):
        try:
            if zipfile.is_zipfile(io.BytesIO(payload)):
                return "zip"
        except Exception:
            return None
        return None
    if payload.startswith(b"Rar!"):
        return "rar"
    head = payload[:2048].lstrip().lower()
    if head.startswith((b"<!doctype", b"<html", b"<?xml")) or b"<html" in head:
        return None
    for codec in ("utf-8-sig", "utf-16", "cp1256", "latin1"):
        try:
            body = payload[:16384].decode(codec)
        except (UnicodeError, LookupError):
            continue
        if re.search(r"\d{1,2}:\d{2}:\d{2}[,.]\d{2,3}\s*-->", body):
            return "subtitle"
    return None


def _yify_browser():
    browser = requests.Session()
    browser.headers.update({
        "User-Agent": HDRDL["User-Agent"],
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    return browser


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """Download a YIFY subtitle the way a browser does.

    yifysubtitles.ch rejects a bare request for /subtitle/<slug>.zip. Open the
    subtitle page first (cookies + Referer), then try the page's download
    button and the known archive URLs; accept only a real ZIP/RAR/SRT.
    """
    try:
        subtitle = subtitles_list[pos]
        page_url = subtitle["link"]
        language = subtitle.get("language_name", "")
        browser = _yify_browser()
        candidates = []
        try:
            page = browser.get(page_url, headers={"Referer": BASE_URL + "/"}, timeout=12, allow_redirects=True)
            print(("ytssubs page", page.status_code, page_url))
            if page.status_code == 200:
                soup = BeautifulSoup(page.text, "html.parser")
                for tag in soup.select("a.download-subtitle, a.btn-icon.download-subtitle, a[href$='.zip'], a[href*='/subtitle/']"):
                    href = (tag.get("href") or "").strip()
                    if href:
                        candidates.append(href if href.startswith("http") else BASE_URL + "/" + href.lstrip("/"))
        except Exception as error:
            print(("ytssubs page error", error))
        slug = page_url.rstrip("/").rsplit("/", 1)[-1]
        for url in ("%s/subtitle/%s.zip" % (BASE_URL, slug),
                    "https://yifysubtitles.ch/subtitle/%s.zip" % slug,
                    "https://yts-subs.com/subtitle/%s.zip" % slug):
            if url not in candidates:
                candidates.append(url)
        seen = set()
        for url in candidates:
            if url in seen or url.rstrip("/") == page_url.rstrip("/"):
                continue
            seen.add(url)
            try:
                response = browser.get(url, headers={"Referer": page_url,
                                                     "Accept": "application/zip,application/octet-stream,*/*;q=0.8"},
                                       timeout=15, allow_redirects=True)
            except Exception as error:
                print(("ytssubs download error", url, error))
                continue
            kind = _yify_payload_type(response.content) if response.status_code == 200 else None
            print(("ytssubs download", response.status_code, kind, len(response.content or b""), url))
            if not kind:
                continue
            if not os.path.isdir(tmp_sub_dir):
                os.makedirs(tmp_sub_dir)
            with open(zip_subs, "wb") as handle:
                handle.write(response.content)
            if kind in ("zip", "rar"):
                return True, language, kind
            return False, language, zip_subs
        print("ytssubs: no download URL returned a subtitle file")
        return False, "", ""
    except Exception as e:
        print(("Error downloading subtitle", e))
        return False, "", ""
