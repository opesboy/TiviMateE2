# -*- coding: utf-8 -*-
"""Save matching native Enigma2 picons after bouquet export, off GUI thread.

Never delete user picons or override existing names. Reuse the unified Live
cache/download implementation (the same one used by Ultra-style Live grid).
"""
from __future__ import absolute_import
import io
import os
import json
import tempfile
import threading
try:
    from queue import Queue, Empty
except ImportError:  # DreamOS Python 2
    from Queue import Queue, Empty
from .bouquet_export import _item_key, _item_url, _service_prefix

_PENDING = set()
_LOCK = threading.RLock()


def _picon_root():
    # Honour existing Enigma2 picon directory; persistent even with TMP cache.
    candidates = ('/media/hdd/picon', '/usr/share/enigma2/picon',
                  '/media/usb/picon', '/etc/enigma2/picon')
    for path in candidates:
        if os.path.isdir(path) and os.access(path, os.W_OK):
            return path
    # Do not create a folder under /tmp: exported native picons must survive reboot.
    target = '/usr/share/enigma2/picon'
    if not os.path.isdir(target):
        os.makedirs(target)
    return target


def _aliases(source, item, service_type):
    prefix = _service_prefix(source, item, service_type)
    fields = prefix.split(':')
    alias = list(fields)
    # Some E2 picon resolvers normalize IPTV type 4097/5002 to DVB type 1.
    alias[0] = '1'
    return list(dict.fromkeys((prefix.replace(':', '_') + '.png',
             '_'.join(alias) + '.png')))


def _copy_png(src, target):
    from PIL import Image
    if os.path.exists(target):
        return True
    fd, tmp = tempfile.mkstemp(prefix='.tivimate-picon-', suffix='.png', dir=os.path.dirname(target))
    os.close(fd)
    try:
        with Image.open(src) as image:
            image.seek(0)
            image.thumbnail((400, 240), getattr(getattr(Image, 'Resampling', Image), 'LANCZOS'))
            image.convert('RGBA').save(tmp, 'PNG', compress_level=4)
        if os.path.exists(target):
            return True
        os.rename(tmp, target)
        tmp = ''
        return True
    except Exception:
        return False
    finally:
        if tmp and os.path.exists(tmp):
            os.unlink(tmp)


def _status_path():
    from .cache_manager import get_cache_dir
    return os.path.join(get_cache_dir('picons'), 'bouquet_export_status.json')


def read_export_picon_status():
    try:
        with io.open(_status_path(), 'r', encoding='utf-8') as handle:
            return json.load(handle)
    except Exception:
        return {}


def _write_status(status):
    # Store the summary in the selected cache, never /etc/enigma2.
    path = _status_path()
    stage = path + '.tmp'
    try:
        with io.open(stage, 'w', encoding='utf-8') as handle:
            json.dump(status, handle, ensure_ascii=False)
        os.rename(stage, path)
    except Exception:
        try:
            if os.path.exists(stage): os.unlink(stage)
        except Exception:
            pass


def _source_picon_url(item, source):
    from .estalker_picon import resolve_picon_url
    link = resolve_picon_url(item, source)
    if link:
        return link
    # Some M3U and Xtream importer versions preserve a logo under these
    # provider-defined fields instead of stream_icon. Use the same resolver.
    for key in ('tvg_logo', 'tvg-logo', 'logo_url', 'icon_url', 'epg_logo'):
        value = item.get(key)
        if value:
            candidate = resolve_picon_url({'stream_icon': value}, source)
            if candidate:
                return candidate
    return ''


def _export_one(source, item, stype, dest):
    from .estalker_picon import cached_picon_path, _download
    from .cache_manager import get_cache_dir
    try:
        if not isinstance(item, dict) or item.get('_placeholder'):
            return 'skipped'
        if not _item_key(item) or not _item_url(source, item):
            return 'skipped'
        icons = [os.path.join(dest, name) for name in _aliases(source, item, stype)]
        if all(os.path.isfile(path) for path in icons):
            return 'cached'
        # When a previous install wrote just one of the two standard service
        # reference variants, recreate the other without network requests.
        old = next((name for name in icons if os.path.isfile(name)), None)
        if old:
            return 'cached' if all(_copy_png(old, name) for name in icons) else 'failed_write'
        link = _source_picon_url(item, source)
        if not link:
            return 'missing_url'
        image = cached_picon_path(link, (240, 100))
        if not image:
            image = _download(link, get_cache_dir('picons'))
        if not image or not os.path.isfile(image):
            return 'failed_download'
        return 'downloaded' if all(_copy_png(image, name) for name in icons) else 'failed_write'
    except Exception:
        return 'failed_download'


def _job(source, items, stype, dest):
    # Unlike screen painting (which is lazy), native bouquet export must
    # traverse ALL channels, not only the first visible 15/18 picons.
    valid = [entry for entry in items if isinstance(entry, dict) and not entry.get('_placeholder')]
    result = dict((key, 0) for key in ('cached', 'downloaded', 'missing_url',
                                      'failed_download', 'failed_write', 'skipped'))
    result.update({'total': len(valid), 'processed': 0, 'running': True})
    _write_status(result)
    work = Queue()
    for item in valid:
        work.put(item)
    lock = threading.RLock()

    def worker():
        while True:
            try:
                item = work.get_nowait()
            except Empty:
                return
            try:
                outcome = _export_one(source, item, stype, dest)
                with lock:
                    result[outcome] += 1
                    result['processed'] += 1
                    if result['processed'] % 8 == 0:
                        _write_status(result)
            finally:
                work.task_done()

    try:
        # Export-only workers, independent from the established Live grid's
        # Ultra download queues, batch sizes and concurrency settings.
        workers = []
        for unused in range(min(4, len(valid))):
            thread = threading.Thread(target=worker, name='TiviMateBouquetPiconFetch')
            thread.daemon = True
            thread.start()
            workers.append(thread)
        for thread in workers:
            thread.join()
    finally:
        result['running'] = False
        _write_status(result)
        with _LOCK:
            _PENDING.discard((dest, str(source.get('name') or ''), stype))
    return result


def queue_export_picons(source, items, service_type, directory=None):
    """Nonblocking. Returns whether a worker started; existing picons reused."""
    if not items:
        return False
    dest = directory or _picon_root()
    key = (dest, str(source.get('name') or ''), int(service_type))
    with _LOCK:
        if key in _PENDING:
            return False
        _PENDING.add(key)
    worker = threading.Thread(target=_job, args=(dict(source), list(items), int(service_type), dest),
                              name='TiviMateBouquetPicons')
    worker.daemon = True
    try:
        worker.start()
        return True
    except Exception:
        with _LOCK:
            _PENDING.discard(key)
        return False
