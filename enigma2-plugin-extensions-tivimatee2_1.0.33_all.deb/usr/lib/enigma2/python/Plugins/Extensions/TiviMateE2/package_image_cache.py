# -*- coding: utf-8 -*-
"""Compatibility shim: Packages badges are bundled local assets only.

This module deliberately performs no filesystem writes, network fetches,
background work, hashing, or per-server cache lookups.  Kept solely so an
older optional caller can import the API without causing a receiver crash.
GENRE's image cache and all poster/backdrop queues are not affected.
"""
from __future__ import absolute_import


def _logo_for_package(name, kind):
    from .package_logos import (package_popup_logo_path,
                                package_logo_for_key,
                                package_browser_logo_for_key)
    path = package_popup_logo_path(name, kind)
    if path:
        return path
    key = 'series' if str(kind).lower() == 'series' else 'movies'
    return (package_logo_for_key(key) or package_browser_logo_for_key(key) or '')


def cached_package_logo(source, kind, package_id, package_name, asset_path):
    """No-op for compatibility: always use the bundled logo path."""
    return asset_path or ''


def prime_package_logos(source, kind, rows):
    """Bulk Package-logo caching is intentionally disabled."""
    return None
