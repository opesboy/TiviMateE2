# -*- coding: utf-8 -*-
"""Unified episode labels (idea and rules from Ultra Stalker episode_labels).

Every episode is "Episode N"; a REAL episode name is added only when the
portal (or TMDb) has one, and the runtime is shown in minutes.

    "01", "Episode 7", "S01E07", "الحلقة 7"          -> no name
    "S1E2 Hide + Seek", "Episode 2 - Hide + Seek"    -> "Hide + Seek"
    "Show Name S01E03", "Show Name - 3"              -> no name
    "12 Angry Men"                                   -> "12 Angry Men"
    "00:45:12", "2712" (seconds), "45", "45 min"     -> "45 min"

TMDb episode names/runtimes found while fetching an episode still are kept
in a small JSON cache, so the next visit shows them at once.
Pure helpers; works on Python 2.7 and 3.
"""
from __future__ import absolute_import

import json
import os
import re
import threading

_NAME_KEYS = ("episode_name", "_episode_title", "episode_title", "title", "name")
_WORDS = (
    u"episode", u"episodio", u"épisode", u"ep", u"e", u"folge", u"bölüm", u"bolum",
    u"серия", u"эпизод", u"odcinek", u"aflevering", u"avsnitt", u"capítulo", u"capitulo", u"cap",
    u"الحلقة", u"الحلقه", u"حلقة", u"حلقه",
)
_WORD_ALT = u"|".join(sorted(set(re.escape(w) for w in _WORDS), key=len, reverse=True))
_RE_SXXEYY = re.compile(u"^\\s*s\\d{1,2}\\s*[._ -]?\\s*e\\s*\\d{1,4}(?!\\d)", re.I | re.U)
_RE_NXMM = re.compile(u"^\\s*\\d{1,2}x\\d{1,4}(?!\\d)", re.I | re.U)
_RE_WORD_NUM = re.compile(u"^\\s*(?:%s)\\.?\\s*0*\\d{1,4}(?!\\d)" % _WORD_ALT, re.I | re.U)
_RE_NUM_SEP = re.compile(u"^\\s*0*\\d{1,3}\\s*[-–—:.)]\\s+", re.U)
_RE_SEPARATORS = re.compile(u"^[\\s\\-–—:.|)\\]_/]+", re.U)
_RE_ONLY_NUMBER = re.compile(u"^[\\s\\d.\\-_:|/()\\[\\]]*$", re.U)
_RE_ONLY_WORD = re.compile(u"^\\s*(?:%s)\\.?\\s*$" % _WORD_ALT, re.I | re.U)
_RE_TAIL_WORD_NUM = re.compile(u"(?:^|[\\s\\-|:]+)(?:%s)\\.?\\s*0*\\d{1,4}\\s*$" % _WORD_ALT, re.I | re.U)
_RE_SERIES_PREFIX = re.compile(u"^(?:مسلسل|series|serie)\\s+", re.I | re.U)
_RE_TAIL_CODE = re.compile(u"\\s*[-|:]*\\s*(?:s\\d{1,2}\\s*[._ -]?\\s*e\\s*\\d{1,4}|\\d{1,2}x\\d{1,4})\\s*$", re.I | re.U)

try:
    _UNICODE = unicode  # noqa: F821  (Python 2.7)
except NameError:
    _UNICODE = str


def _u(value):
    if value is None:
        return u""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else u""
    if isinstance(value, bytes) and _UNICODE is not bytes:
        try:
            return value.decode("utf-8", "replace")
        except Exception:
            return u""
    try:
        return _UNICODE(value)
    except Exception:
        return u""


def _native(text):
    """Unicode text everywhere; Python 2.7 callers pass it through gui_text()."""
    return text


def _flat(value, limit=120):
    text = u" ".join(_u(value).replace(u"\n", u" ").replace(u"\r", u" ").split()).strip()
    if text.lower() in (u"none", u"null", u"n/a", u"0"):
        return u""
    return text[:limit]


def clean_episode_name(raw, series_title=u""):
    """The real episode name inside raw, or "" when it is only a number/code."""
    text = _flat(raw)
    if not text:
        return u""
    series = _flat(series_title)
    if series and text.lower().startswith(series.lower()):
        # "Show Name S01E03" / "Show Name - 3" / "Show Name: Pilot"
        text = _RE_SEPARATORS.sub(u"", text[len(series):]).strip()
    for _round in range(3):
        before = text
        for pattern in (_RE_SXXEYY, _RE_NXMM, _RE_WORD_NUM, _RE_NUM_SEP):
            match = pattern.match(text)
            if match:
                text = _RE_SEPARATORS.sub(u"", text[match.end():]).strip()
                break
        if text == before:
            break
    text = _RE_TAIL_CODE.sub(u"", text).strip()
    text = _RE_TAIL_WORD_NUM.sub(u"", text).strip()
    if not text or _RE_ONLY_NUMBER.match(text) or _RE_ONLY_WORD.match(text):
        return u""
    if series and _RE_SERIES_PREFIX.sub(u"", text).strip().lower() in (series.lower(), _RE_SERIES_PREFIX.sub(u"", series).strip().lower()):
        return u""
    return text[:80]


def episode_name(item, series_title=u""):
    """Best real episode name for a portal episode row ("" when none)."""
    if not isinstance(item, dict):
        return _native(u"")
    info = item.get("info") if isinstance(item.get("info"), dict) else {}
    for row in (item, info):
        for key in _NAME_KEYS:
            name = clean_episode_name(row.get(key), series_title)
            if name:
                return _native(name)
    return _native(clean_episode_name(item.get("_ep_tmdb_name"), series_title))


def _clock_minutes(text):
    parts = text.split(u":")
    if len(parts) not in (2, 3) or not all(p.strip().isdigit() for p in parts):
        return None
    nums = [int(p) for p in parts]
    if len(nums) == 3:
        return nums[0] * 60 + nums[1] + (1 if nums[2] >= 30 else 0)
    if nums[0] <= 3:
        return nums[0] * 60 + nums[1]          # "1:02" = 1 h 02 min
    return nums[0] + (1 if nums[1] >= 30 else 0)  # "45:12" = 45 min


def _minutes(value, unit):
    if value in (None, u"", ""):
        return None
    text = _u(value).strip().lower()
    if u":" in text:
        return _clock_minutes(text)
    match = re.search(u"\\d+(?:[.,]\\d+)?", text)
    if not match:
        return None
    try:
        number = float(match.group(0).replace(u",", u"."))
    except Exception:
        return None
    if number <= 0:
        return None
    if unit == "sec" or (unit == "auto" and (u"sec" in text or u"ث" in text)):
        return number / 60.0
    if unit == "min" or u"min" in text or u"د" in text:
        return number
    return number / 60.0 if number > 300 else number


def runtime_minutes(item):
    """Runtime in whole minutes (1..600) or 0."""
    if not isinstance(item, dict):
        return 0
    info = item.get("info") if isinstance(item.get("info"), dict) else {}
    groups = (
        ((item, info), ("runtime", "duration_min"), "min"),
        ((item, info), ("duration_secs",), "sec"),
        ((info, item), ("duration", "length", "movie_duration"), "auto"),
        ((item,), ("_ep_runtime",), "min"),
    )
    for rows, keys, unit in groups:
        for row in rows:
            for key in keys:
                minutes = _minutes(row.get(key), unit)
                if minutes is None:
                    continue
                minutes = int(round(minutes))
                if 1 <= minutes <= 600:
                    return minutes
    return 0


def runtime_text(item):
    minutes = runtime_minutes(item)
    return (u"%d min" % minutes) if minutes else u""


# ---------------------------------------------------------------------------
# Small cache of TMDb names/runtimes (tmdb_id:season:episode)
# ---------------------------------------------------------------------------
_LOCK = threading.Lock()
_CACHE = {"path": "", "data": None}
_MAX = 4000


def _cache_path():
    try:
        from .storage import data_path
        return data_path("episode_meta_v1.json")
    except Exception:
        return "/tmp/tivimate_episode_meta_v1.json"


def _load():
    path = _cache_path()
    if _CACHE["data"] is not None and _CACHE["path"] == path:
        return _CACHE["data"]
    data = {}
    try:
        with open(path, "rb") as handle:
            data = json.loads(handle.read().decode("utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    _CACHE["path"], _CACHE["data"] = path, data
    return data


def meta_get(tmdb_id, season, episode):
    key = "%s:%s:%s" % (tmdb_id, season, episode)
    with _LOCK:
        row = _load().get(key)
    return dict(row) if isinstance(row, dict) else {}


def meta_put(tmdb_id, season, episode, name=u"", runtime=0):
    name = _flat(name, 80)
    try:
        runtime = int(runtime or 0)
    except Exception:
        runtime = 0
    if not (name or runtime):
        return
    key = "%s:%s:%s" % (tmdb_id, season, episode)
    with _LOCK:
        data = _load()
        data[key] = {"name": name, "runtime": runtime}
        if len(data) > _MAX:
            for old in list(data)[: len(data) - _MAX]:
                data.pop(old, None)
        path = _cache_path()
        temp = path + ".tmp"
        try:
            with open(temp, "wb") as handle:
                handle.write(json.dumps(data, ensure_ascii=True).encode("utf-8"))
            os.rename(temp, path)
        except Exception:
            pass


def apply_meta(item, tmdb_id, season, episode):
    """Copy a cached TMDb name/runtime onto a portal episode row."""
    if not isinstance(item, dict) or not tmdb_id:
        return False
    row = meta_get(tmdb_id, season, episode)
    if not row:
        return False
    if row.get("name"):
        item["_ep_tmdb_name"] = row["name"]
    if row.get("runtime"):
        item["_ep_runtime"] = row["runtime"]
    return True


def preview_line(item, number, series_title=u"", lang="en"):
    """"Episode N  •  Real name  •  45 min" for the series details page."""
    number = _u(number)
    if lang == "fr":
        prefix = u"Épisode %s" % number
    elif lang == "en":
        prefix = u"Episode %s" % number
    else:
        prefix = u"الحلقة %s" % number
    parts = [prefix]
    name = episode_name(item, series_title)
    if name:
        parts.append(_u(name))
    runtime = runtime_text(item)
    if runtime:
        parts.append(_u(runtime))
    return u"  •  ".join(parts)
