# -*- coding: utf-8 -*-
"""Additive shims for old PIL / Pillow builds found on VTi (Python 2.7).

VTi images ship PIL 1.1.7 or an early Pillow. The artwork code (actor
circles, picons, logos, posters) uses newer Pillow APIs; on old builds each
call raised AttributeError and the image was silently dropped.

Only attributes that are MISSING are added; nothing existing is replaced, so
other plugins see exactly the same PIL as before.
"""

_INSTALLED = [False]


def install_pil_compat():
    if _INSTALLED[0]:
        return True
    try:
        from PIL import Image
    except Exception:
        return False
    _INSTALLED[0] = True
    cls = Image.Image

    # Resampling filters: Pillow 2.7 renamed ANTIALIAS to LANCZOS.
    best = getattr(Image, 'LANCZOS', None)
    if best is None:
        best = getattr(Image, 'ANTIALIAS', getattr(Image, 'BICUBIC', 3))
        try:
            Image.LANCZOS = best
        except Exception:
            pass
    for name, fallback in (('BICUBIC', 3), ('BILINEAR', 2), ('NEAREST', 0)):
        if not hasattr(Image, name):
            try:
                setattr(Image, name, fallback)
            except Exception:
                pass

    # Image objects as context managers (Pillow 2.x+).
    if not hasattr(cls, 'close'):
        def close(self):
            try:
                fp = getattr(self, 'fp', None)
                if fp is not None and getattr(self, '_exclusive_fp', True):
                    fp.close()
            except Exception:
                pass
            self.fp = None
        cls.close = close
    if not hasattr(cls, '__enter__'):
        cls.__enter__ = lambda self: self

        def __exit__(self, *args):
            try:
                self.close()
            except Exception:
                pass
            return False
        cls.__exit__ = __exit__

    # width / height properties (Pillow 2.9+).
    if not hasattr(cls, 'width'):
        try:
            cls.width = property(lambda self: self.size[0])
            cls.height = property(lambda self: self.size[1])
        except Exception:
            pass

    # getchannel (Pillow 4.3+).
    if not hasattr(cls, 'getchannel'):
        def getchannel(self, channel):
            bands = self.getbands()
            if isinstance(channel, basestring):
                index = bands.index(channel)
            else:
                index = int(channel)
            return self.split()[index]
        cls.getchannel = getchannel

    # Module-level alpha_composite (Pillow 2.0+).
    if not hasattr(Image, 'alpha_composite'):
        def alpha_composite(base, overlay):
            result = base.convert('RGBA').copy()
            layer = overlay.convert('RGBA')
            result.paste(layer, (0, 0), layer)
            return result
        Image.alpha_composite = alpha_composite

    # In-place Image.alpha_composite(im, dest) method (Pillow 4.2+).
    if not hasattr(cls, 'alpha_composite'):
        def alpha_composite_method(self, im, dest=(0, 0), source=(0, 0)):
            layer = im.convert('RGBA')
            if source and tuple(source) != (0, 0):
                layer = layer.crop(tuple(source) + layer.size)
            x, y = int(dest[0]), int(dest[1])
            box = (x, y, x + layer.size[0], y + layer.size[1])
            try:
                region = self.crop(box).convert('RGBA')
                merged = Image.alpha_composite(region, layer)
                self.paste(merged, (x, y))
            except Exception:
                self.paste(layer, (x, y), layer)
        cls.alpha_composite = alpha_composite_method

    # ImageOps.exif_transpose (Pillow 6.0+): identity on old builds.
    try:
        from PIL import ImageOps
        if not hasattr(ImageOps, 'exif_transpose'):
            ImageOps.exif_transpose = lambda image, *args, **kwargs: image
        # ImageOps.contain / cover (Pillow 8.3+, never on Python 2.7): used by
        # the Live infobar capsule and package artwork.
        if not hasattr(ImageOps, 'contain'):
            def contain(image, size, method=None):
                w, h = image.size
                ratio = min(float(size[0]) / w, float(size[1]) / h)
                new = (max(1, int(round(w * ratio))), max(1, int(round(h * ratio))))
                return image.resize(new, method if method is not None else best)
            ImageOps.contain = contain
        if not hasattr(ImageOps, 'cover'):
            def cover(image, size, method=None):
                w, h = image.size
                ratio = max(float(size[0]) / w, float(size[1]) / h)
                new = (max(1, int(round(w * ratio))), max(1, int(round(h * ratio))))
                return image.resize(new, method if method is not None else best)
            ImageOps.cover = cover
    except Exception:
        pass
    # ImageFilter.GaussianBlur (radius) exists on Pillow; very old PIL lacks it.
    try:
        from PIL import ImageFilter
        if not hasattr(ImageFilter, 'GaussianBlur'):
            ImageFilter.GaussianBlur = lambda radius=2: ImageFilter.BLUR
    except Exception:
        pass
    return True
