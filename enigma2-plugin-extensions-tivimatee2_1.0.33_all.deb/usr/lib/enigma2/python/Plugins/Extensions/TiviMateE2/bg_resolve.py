# -*- coding: utf-8 -*-
"""Run a slow call (portal login / create_link) off the Enigma2 GUI thread.

A Stalker link can take several seconds (handshake, profile, create_link).
Calling it inside a key handler froze the whole receiver UI meanwhile.
resolve_async() runs it in a worker and hands the result back on the GUI
thread through an eTimer poll. Works on Python 2.7 and 3.
"""
from __future__ import absolute_import

import threading

_KEEP = []


def resolve_async(func, on_done, on_error=None, timeout=45.0):
    state = {"done": False, "value": None, "error": None, "polls": 0}

    def worker():
        try:
            state["value"] = func()
        except Exception as exc:
            state["error"] = exc
        state["done"] = True

    thread = threading.Thread(target=worker, name="TiviMateResolve")
    thread.daemon = True
    thread.start()

    from enigma import eTimer
    timer = eTimer()
    holder = {"timer": timer}
    max_polls = int(float(timeout) * 10)

    def poll():
        state["polls"] += 1
        if not state["done"] and state["polls"] < max_polls:
            timer.start(100, True)
            return
        try:
            _KEEP.remove(holder)
        except ValueError:
            pass
        try:
            if not state["done"]:
                raise RuntimeError("Server did not answer in time")
            if state["error"] is not None:
                raise state["error"]
            on_done(state["value"])
        except Exception as exc:
            if on_error is not None:
                try:
                    on_error(exc)
                except Exception:
                    pass
    try:
        holder["conn"] = timer.timeout.connect(poll)
    except AttributeError:
        timer.callback.append(poll)
    _KEEP.append(holder)
    timer.start(100, True)
