# -*- coding: utf-8 -*-
"""Saved results of Movie Parts and Other Sources searches.

A repeated search of the same movie on the same server opens at once: the
result is kept in RAM and in <data root>/search_results_cache_v1.json, so it
also survives a GUI restart. Entries expire after 12 hours (empty results
after 30 minutes, the package cache may simply not have been loaded yet).
Works on Python 2.7 and 3.
"""
from __future__ import absolute_import

import json
import os
import threading
import time

_LOCK = threading.RLock()
_TTL = 12 * 3600
_EMPTY_TTL = 30 * 60
_MAX = 200
_STATE = {"data": None, "path": "", "dirty": False, "timer": None}

try:
    _UNICODE = unicode  # noqa: F821  (Python 2.7)
except NameError:
    _UNICODE = None


def _native(value):
    """JSON gives unicode on Python 2.7; the GUI there wants UTF-8 str."""
    if _UNICODE is None:
        return value
    if isinstance(value, _UNICODE):
        return value.encode("utf-8")
    if isinstance(value, dict):
        return dict((_native(k), _native(v)) for k, v in value.items())
    if isinstance(value, list):
        return [_native(v) for v in value]
    return value


def _path():
    try:
        from .storage import data_path
        return data_path("search_results_cache_v1.json")
    except Exception:
        return "/etc/enigma2/tivimatee2/search_results_cache_v1.json"


def _load():
    path = _path()
    if _STATE["data"] is not None and _STATE["path"] == path:
        return _STATE["data"]
    data = {}
    try:
        with open(path, "rb") as handle:
            data = json.loads(handle.read().decode("utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    _STATE["path"], _STATE["data"] = path, data
    return data


def _write():
    with _LOCK:
        _STATE["timer"] = None
        if not _STATE["dirty"]:
            return
        _STATE["dirty"] = False
        data = dict(_STATE["data"] or {})
    path = _path()
    temp = path + ".tmp"
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(temp, "wb") as handle:
            handle.write(json.dumps(data, ensure_ascii=True, default=str).encode("utf-8"))
        os.rename(temp, path)
    except Exception:
        pass


def _text(value):
    if _UNICODE is not None and isinstance(value, str):
        try:
            return value.decode("utf-8")
        except Exception:
            return value.decode("latin-1")
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return "%s" % (value,)


def make_key(kind, source, movie_id):
    source = source or {}
    parts = (kind, source.get("type") or "", source.get("url") or source.get("host") or "",
             source.get("username") or source.get("mac") or "", movie_id or "")
    return u"|".join(_text(p) for p in parts)


def get(key):
    with _LOCK:
        entry = _load().get(_text(key))
    if not isinstance(entry, dict):
        return None
    age = time.time() - float(entry.get("t") or 0)
    payload = entry.get("v")
    empty = not (isinstance(payload, dict) and payload.get("rows"))
    if age > (_EMPTY_TTL if empty else _TTL):
        return None
    return _native(payload)


def put(key, payload):
    with _LOCK:
        data = _load()
        data[_text(key)] = {"t": time.time(), "v": payload}
        if len(data) > _MAX:
            for old in sorted(data, key=lambda k: float((data[k] or {}).get("t") or 0))[:len(data) - _MAX]:
                data.pop(old, None)
        _STATE["dirty"] = True
        if _STATE["timer"] is None:
            # Write once in the background, never on the GUI thread.
            timer = threading.Timer(2.0, _write)
            timer.daemon = True
            _STATE["timer"] = timer
            timer.start()
