from .movies_layout_choice import configured_movies_screen
from .ultra_epg_selection import epg_title as ultra_epg_title
from enigma import eSize, gRGB
# Large Movies/TV pages use the same validated Ultra artwork path as GENRE.
# Keep the generic artwork queue as a compatibility fallback.
from .genre_ultra_artwork import request as _genre_ultra_request, request_transparent_logo as _genre_transparent_logo
from .logo_manager import provider_logo_url as _provider_logo_url
from .stalker_task_handle import TaskHandle as _UltraLiveTaskHandle
from .stalker_live_pool import STALKER_LIVE_EXECUTOR as _ULTRA_STALKER_LINK_POOL
from .stalker_live_pool import live_playback_client as _live_playback_client, invalidate_live_playback_client as _invalidate_playback_client
from .stalker_live_pool import STALKER_CATALOG_EXECUTOR as _ULTRA_STALKER_CATALOG_POOL
from .live_epg_bridge import cached as _shared_live_epg_cached, remember as _shared_live_epg_remember, select_stalker_now_next as _shared_stalker_now_next, begin_many as _shared_epg_begin, finish_many as _shared_epg_finish, normalize_epg_interval as _shared_epg_interval
from .stalker_live_pool import LIVE_EPG_EXECUTOR as _ULTRA_LIVE_EPG_POOL
from .ultra_stalker_engine.core.executor import LazyThreadPoolExecutor

# Ultra grid begins playService as soon as create_link resolves.  Keep our
# Enigma2-specific old-stream PID retirement away from that playback path.
# A single lazy worker uses the same bounded/reused-executor primitive as Ultra.
_ULTRA_LIVE_PREVIEW_CLEANUP = LazyThreadPoolExecutor(
    max_workers=1, thread_name_prefix="ultra-preview-cleanup")

# Same bounded, reusable executor policy as UltraStalker's EPG worker pool.
# Xtream warmups formerly created a fresh ThreadPoolExecutor for *each* page;
# changing bouquet quickly left several remote requests competing with the
# newly visible page.  Share a single pool across standard Live and Windows.
_ULTRA_VISIBLE_XTREAM_EPG_POOL = LazyThreadPoolExecutor(
    max_workers=6, thread_name_prefix="ultra-visible-xtream-epg")
from .ultra_live_decoder import UltraLiveDecoderGuard
LIVE_CHANNEL_ORDER_FILE = data_path("live_channel_order.json")
MEDIA_CONTENT_SORT_FILE = "/etc/enigma2/tivimatee2/media_content_sort.json"

def _load_media_content_sort(kind):
    if kind not in ("vod", "series"):
        return "default"
    try:
        state = load_json(MEDIA_CONTENT_SORT_FILE, {}) or {}
        mode = str(state.get(kind) or "latest").lower()
        return mode if mode in ("default", "latest", "name", "rating") else "latest"
    except Exception:
        return "latest"

def _save_media_content_sort(kind, mode):
    if kind not in ("vod", "series"):
        return
    try:
        state = load_json(MEDIA_CONTENT_SORT_FILE, {}) or {}
        state[kind] = mode
        parent = os.path.dirname(MEDIA_CONTENT_SORT_FILE)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        save_json(MEDIA_CONTENT_SORT_FILE, state)
    except Exception:
        pass

def _live_order_scope(source, category_id):
    return "%s|%s" % (_source_identity(source or {}), str(category_id or ""))

def _apply_live_channel_order(source, category_id, items):
    rows = list(items or [])
    try:
        state = load_json(LIVE_CHANNEL_ORDER_FILE, {}) or {}
        order = state.get(_live_order_scope(source, category_id)) or []
        if not order:
            return rows
        rank = {str(item_id): index for index, item_id in enumerate(order)}
        original = {id(row): index for index, row in enumerate(rows)}
        return sorted(rows, key=lambda row: (rank.get(str(_live_item_id(row)), len(rank) + original[id(row)])))
    except Exception:
        return rows

def _save_live_channel_order(source, category_id, items):
    try:
        state = load_json(LIVE_CHANNEL_ORDER_FILE, {}) or {}
        state[_live_order_scope(source, category_id)] = [str(_live_item_id(row)) for row in (items or []) if _live_item_id(row)]
        save_json(LIVE_CHANNEL_ORDER_FILE, state)
        return True
    except Exception:
        return False

_TOP_RESTORE_TIMERS = []


def restore_top_dialog_soon(session):
    """After a TiviMate window closes, make sure the window now on top is
    visible. Some images (OpenSPA...) left it hidden: the TV picture showed
    and EXIT had to be pressed again to get the plugin back. Only TiviMate's
    own hidden dialogs are touched. Timers live at module level so they also
    fire after the closing screen has been destroyed."""
    def restore():
        try:
            dialog = getattr(session, "current_dialog", None)
            if dialog is None:
                return
            module = str(getattr(type(dialog), "__module__", "") or "")
            if "TiviMateE2" not in module:
                return
            if getattr(dialog, "shown", True) is False:
                dialog.show()
        except Exception:
            pass
    for delay in (120, 450, 1000):
        try:
            timer = eTimer()
            try:
                timer.callback.append(restore)
            except AttributeError:
                _TOP_RESTORE_TIMERS.append(timer.timeout.connect(restore))
            timer.start(delay, True)
            _TOP_RESTORE_TIMERS.append(timer)
        except Exception:
            pass
    del _TOP_RESTORE_TIMERS[:-24]


class AnchoredMetadataLabel(DirectionalLabel):
    """Retain the configured Arabic font without moving metadata to the right.

    Only the large Movies/TV Shows metadata row uses this component: Arabic
    descriptions and localized film titles keep their original RTL alignment.
    """
    def _apply_direction(self):
        super(AnchoredMetadataLabel, self)._apply_direction()
        instance = getattr(self, "instance", None)
        if instance is not None:
            try:
                instance.setHAlign(RT_HALIGN_LEFT)
            except Exception:
                pass


class CenteredLargePageMetadataLabel(AnchoredMetadataLabel):
    """Center Arabic facts on the large Movies/TV pages, not only Arabic UI."""
    def __init__(self, text=""):
        self._tmdb_arabic_metadata = False
        try:
            from .tmdb_client import load_settings
            self._tmdb_arabic_metadata = str(load_settings().get("language") or "").lower().startswith("ar")
        except Exception:
            pass
        super(CenteredLargePageMetadataLabel, self).__init__(text)

    def _apply_direction(self):
        super(CenteredLargePageMetadataLabel, self)._apply_direction()
        try:
            instance = getattr(self, "instance", None)
            if instance is not None:
                from .rtl_text import metadata_uses_arabic
                if metadata_uses_arabic(self._directional_value, self._tmdb_arabic_metadata):
                    instance.setHAlign(1)  # eLabel.alignCenter
                else:
                    instance.setHAlign(RT_HALIGN_LEFT)
        except Exception:
            pass

    def onShow(self):
        super(CenteredLargePageMetadataLabel, self).onShow()
        self._apply_direction()


# Source-scoped, positive-only EPG indicators. Kept in RAM for quick re-entry;
# negative/unknown results never become false "EPG available" badges.
_LIVE_EPG_MARKS = {}
_LIVE_EPG_MARKS_LOCK = threading.RLock()
_LIVE_EPG_MARK_TTL = 10 * 60
_LIVE_EPG_MARK_LIMIT = 360

def _live_epg_mark_key(source, channel_id):
    return (_source_identity(source or {}), str(channel_id or "").strip())

def _live_epg_mark_present(source, channel_id):
    key = _live_epg_mark_key(source, channel_id)
    if not key[1]:
        return False
    with _LIVE_EPG_MARKS_LOCK:
        expiry = float(_LIVE_EPG_MARKS.get(key, 0) or 0)
        if expiry and expiry <= time.time():
            _LIVE_EPG_MARKS.pop(key, None)
        return expiry > time.time()

def _live_epg_mark_known(source, channel_id, rows):
    if not any(isinstance(row, dict) and
               (row.get("name") or row.get("title") or row.get("programme"))
               for row in (rows or [])):
        return False
    key = _live_epg_mark_key(source, channel_id)
    if not key[1]:
        return False
    with _LIVE_EPG_MARKS_LOCK:
        _LIVE_EPG_MARKS[key] = time.time() + _LIVE_EPG_MARK_TTL
        if len(_LIVE_EPG_MARKS) > _LIVE_EPG_MARK_LIMIT:
            for old_key in sorted(_LIVE_EPG_MARKS, key=_LIVE_EPG_MARKS.get)[:90]:
                _LIVE_EPG_MARKS.pop(old_key, None)
    return True


LIVE_STYLE_CIRCLE_SKIN = scale_skin('<screen name="LiveStyleCircleScreen" position="0,0" size="1920,1080" backgroundColor="#000000" flags="wfNoBorder">\n<widget name="background" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/live_appearance_opaque.png" zPosition="0" />\n<eLabel position="55,40" size="1810,1000" backgroundColor="#000000" cornerRadius="28" zPosition="1" />\n<eLabel position="80,65" size="1760,950" backgroundColor="#142331" cornerRadius="24" zPosition="2" />\n<eLabel position="88,73" size="1744,934" backgroundColor="#000000" cornerRadius="20" zPosition="3" />\n<eLabel position="55,40" size="1810,5" backgroundColor="#08C9E8" zPosition="2" />\n<widget name="titleIcon" position="115,83" size="90,58" font="Regular;42" foregroundColor="#08C9E8" transparent="1" halign="center" zPosition="5" />\n<widget name="title" position="220,78" size="1000,60" font="Regular;42" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />\n<widget name="version" position="1450,85" size="300,32" font="Regular;18" foregroundColor="#B9CDDA" transparent="1" halign="right" zPosition="5" />\n<widget name="hint" position="220,143" size="1350,32" font="Regular;21" foregroundColor="#B9CDDA" transparent="1" zPosition="5" />\n<eLabel position="120,210" size="790,300" backgroundColor="#101010" cornerRadius="18" zPosition="4" />\n<eLabel position="1010,210" size="790,300" backgroundColor="#101010" cornerRadius="18" zPosition="4" />\n<widget name="modeFrame" position="112,202" size="806,316" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/live_gold_mode_focus.png" alphatest="blend" zPosition="15" />\n<widget name="modeIcon0" position="165,255" size="130,100" font="Regular;72" foregroundColor="#08C9E8" transparent="1" halign="center" valign="center" zPosition="5" />\n<widget name="modeIcon1" position="1055,255" size="130,100" font="Regular;72" foregroundColor="#F5F2EC" transparent="1" halign="center" valign="center" zPosition="5" />\n<widget name="modeName0" position="320,260" size="520,48" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />\n<widget name="modeName1" position="1210,260" size="520,48" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />\n<widget name="modeDesc0" position="320,320" size="520,70" font="Regular;22" foregroundColor="#B9CDDA" transparent="1" zPosition="5" />\n<widget name="modeDesc1" position="1210,320" size="520,70" font="Regular;22" foregroundColor="#B9CDDA" transparent="1" zPosition="5" />\n<widget name="modeHint0" position="320,415" size="520,35" font="Regular;18" foregroundColor="#08C9E8" transparent="1" zPosition="5" />\n<widget name="modeHint1" position="1210,415" size="520,35" font="Regular;18" foregroundColor="#08C9E8" transparent="1" zPosition="5" />\n<eLabel position="112,555" size="1696,300" backgroundColor="#000000" cornerRadius="18" zPosition="2" />\n<widget name="colorTitle" position="120,565" size="1680,42" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />\n<eLabel position="157,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="165,658" size="120,120" backgroundColor="#08C9E8" cornerRadius="60" zPosition="4" /><widget name="colorName0" position="117,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="375,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="383,658" size="120,120" backgroundColor="#168CFF" cornerRadius="60" zPosition="4" /><widget name="colorName1" position="335,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="593,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="601,658" size="120,120" backgroundColor="#19C878" cornerRadius="60" zPosition="4" /><widget name="colorName2" position="553,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="811,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="819,658" size="120,120" backgroundColor="#F5BE16" cornerRadius="60" zPosition="4" /><widget name="colorName3" position="771,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="1029,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="1037,658" size="120,120" backgroundColor="#B124E8" cornerRadius="60" zPosition="4" /><widget name="colorName4" position="989,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="1247,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="1255,658" size="120,120" backgroundColor="#F5F2EC" cornerRadius="60" zPosition="4" /><widget name="colorName5" position="1207,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="1465,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="1473,658" size="120,120" backgroundColor="#74AEEF" cornerRadius="60" zPosition="4" /><widget name="colorName6" position="1425,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" /><eLabel position="1683,650" size="136,136" backgroundColor="#101010" cornerRadius="68" zPosition="2" /><eLabel position="1691,658" size="120,120" backgroundColor="#94A4BA" cornerRadius="60" zPosition="4" /><widget name="colorName7" position="1643,795" size="216,34" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" />\n<widget name="colorSelector" position="153,646" size="144,144" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/live_gold_color_focus.png" alphatest="blend" zPosition="15" />\n<eLabel position="120,935" size="1680,1" backgroundColor="#26313D" zPosition="2" />\n<widget name="footer" position="120,958" size="1680,35" font="Regular;21" foregroundColor="#F5F7FA" transparent="1" halign="center" zPosition="5" />\n</screen>')

class LiveStyleCircleScreen(Screen):
    ITEMS = (('Turquoise', 'turquoise'), ('Blue', 'blue'), ('Green', 'green'), ('Gold', 'gold'), ('Purple', 'purple'), ('Silver', 'silver'), ('Sky', 'sky'), ('Slate', 'slate'))
    COLOR_POSITIONS = tuple((165 + i * 218, 658) for i in range(8))

    def __init__(self, session, current=None, mode="list"):
        self.skin = LIVE_STYLE_CIRCLE_SKIN
        Screen.__init__(self, session)
        self.mode = 0 if str(mode or "list") == "windows" else 1
        current = str(current or "turquoise")
        self.color = next((i for i, item in enumerate(self.ITEMS) if item[1] == current), 0)
        self.focusSection = "mode"
        self["background"] = Pixmap()
        self["titleIcon"] = Label("▣")
        self["title"] = Label("LIVE APPEARANCE")
        self["version"] = Label("TiviMateE2  v%s-r%s" % (PLUGIN_VERSION, CURRENT_REVISION))
        self["hint"] = Label("Choose your view style and color theme for Live TV")
        self["modeIcon0"] = Label("▦")
        self["modeIcon1"] = Label("☷")
        self["modeName0"] = Label("Windows Grid")
        self["modeName1"] = Label("Standard List")
        self["modeDesc0"] = Label("Multi-window channel preview")
        self["modeDesc1"] = Label("Classic channel list layout")
        self["modeHint0"] = Label("")
        self["modeHint1"] = Label("")
        self["colorTitle"] = Label("THEME COLOR")
        for i, item in enumerate(self.ITEMS):
            self["colorName%d" % i] = Label(item[0])
        self["footer"] = Label("OK  Select        GREEN  Apply        RED  Back        EXIT  Close")
        self["modeFrame"] = Pixmap()
        self["colorSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self._ok, "green": self._ok, "cancel": self._cancel, "red": self._cancel,
            "left": self._left, "right": self._right, "up": self._up, "down": self._down
        }, -1)
        self.onLayoutFinish.append(self._refresh)

    def _refresh(self):
        try:
            if self.mode == 0:
                self["modeFrame"].instance.move(ePoint(sx(112), sy(202)))
            else:
                self["modeFrame"].instance.move(ePoint(sx(1002), sy(202)))
            x, y = self.COLOR_POSITIONS[self.color]
            self["colorSelector"].instance.move(ePoint(sx(x-12), sy(y-12)))
            self["modeFrame"].instance.setVisible(self.focusSection == "mode")
            self["colorSelector"].instance.setVisible(self.focusSection == "color")
        except Exception:
            pass

    def _left(self):
        if self.focusSection == "mode":
            self.mode = (self.mode - 1) % 2
        else:
            self.color = (self.color - 1) % len(self.ITEMS)
        self._refresh()

    def _right(self):
        if self.focusSection == "mode":
            self.mode = (self.mode + 1) % 2
        else:
            self.color = (self.color + 1) % len(self.ITEMS)
        self._refresh()

    def _up(self):
        self.focusSection = "mode"
        self._refresh()

    def _down(self):
        self.focusSection = "color"
        self._refresh()

    def _ok(self):
        self.close((self.ITEMS[self.color][0], ("windows" if self.mode == 0 else "list") + "|" + self.ITEMS[self.color][1]))

    def _cancel(self):
        self.close(None)

class MediaScreen(Screen):
    POSTER_X = [70, 450, 830, 1210, 1590]


    def __init__(self, session, source, kind, initialCategoryId=None, initialCategoryName=None, preloadedItems=None):
        if kind == "live":
            # Live has its own remembered server. Movies and TV Shows continue
            # using the Home/server-manager selection independently.
            # Keep the virtual beIN source selected instead of replacing it with
            # the persisted real provider.  The real provider is refreshed only
            # inside the private beIN wrapper so ChoiceBox selection/check state
            # remains active after opening the new MediaScreen.
            if isinstance(source, dict) and source.get("_virtual_bein"):
                base = _load_live_source(_bein_base_source(source))
                source = _make_bein_virtual_source(base)
            else:
                source = _load_live_source(source)
            # Home skins do not change Live: keep the stable, Picon-enabled list.
            # This layout intentionally has no visible EPG grid.
            self.skin = _live_skin_with_style(_load_channel_settings().get("live_theme", "turquoise"))
        else:
            self.posterViewStyle, _poster_spec = _vod_poster_style_spec((source.get("_view_style_override") if isinstance(source, dict) else None) or _load_home_appearance().get("poster_style", "original"))
            self.POSTER_X = list(_poster_spec["x"])
            self.posterY = int(_poster_spec["y"])
            self.skin = _vod_skin_with_poster_style(self.posterViewStyle)
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source = source
        self.kind = kind
        if kind in ("vod", "series"):
            from .server_footer_identity import compact_server_name, refresh_footer_label
            self["footerServerName"] = Label(compact_server_name(self.source))
            self.onShow.append(lambda: refresh_footer_label(self))
        self.initialCategoryId = str(initialCategoryId or "")
        self.initialCategoryName = initialCategoryName or ""
        self.preloadedItems = list(preloadedItems or [])
        self._movieGenreAllItems = list(source.get("_movie_genre_all_items") or []) if isinstance(source, dict) else []
        self._movieGenrePageSize = max(1, int(source.get("_movie_genre_page_size") or 30)) if isinstance(source, dict) else 30
        self._movieGenrePage = max(0, int(source.get("_movie_genre_page") or 0)) if isinstance(source, dict) else 0
        self._movieGenreLabel = str(source.get("_movie_genre_label") or "") if isinstance(source, dict) else ""
        # The ordinary Packages poster browser is a continuous strip: only the
        # five visible thumbnails are decoded at a time. Keep paging state for
        # independent Recent Add, actor and genre-result screens only.
        self._largePageAllItems = []
        self._largePageSize = 30
        self._largePage = 0
        # Every large Movies/TV Shows page needs the title-logo path. Normal
        # package pages often start without an initial category id and receive
        # it only after the user selects a category; gating this on
        # initialCategoryId made those pages show plain text only.
        self.packageTitleLogoEnabled = kind in ("vod", "series")
        self.activeCategoryName = self.initialCategoryName
        self.activePackageProvider = self._providerFromPackageName(self.initialCategoryName) if self.initialCategoryName else ""
        self.activeCategoryName = self.initialCategoryName
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self._liveMoveMode = False
        self._liveMoveOriginal = None
        # Live's ordinary channel OK: first mini preview, second full screen.
        # No pending package-to-player timer or automatic direct-play request.
        self._livePreviewOkIdentity = None
        self._loadedLiveCategoryKey = None
        # Cursor-only cache: never duplicate whole portal playlists in RAM.
        self._liveChannelCursorByCategory = {}
        self._windowsVisible = False
        self._windowsAutoTimer = None
        self._windowsAutoRetryCount = 0
        if kind == "live":
            # UltraStalker player-runtime PID baseline for ordinary Live and
            # Windows preview. No process that predates this browser is owned.
            self._ultraLiveDecoderGuard = UltraLiveDecoderGuard()
            self._windowsAutoTimer = eTimer()
            _connect_timer(self._windowsAutoTimer, self._autoOpenWindowsWhenReady)
            # Modal Windows->List handoff: do not restart the parent while the
            # style selector or the PiG-rendering window is still closing.
            self._windowsReturnTimer = eTimer()
            _connect_timer(self._windowsReturnTimer, self._resumeLiveListAfterWindows)
            self.onClose.append(self._stopWindowsAutoTimer)
            self.onClose.append(self._stopWindowsReturnTimer)
        self.categories = []
        self.focus = "rail" if kind == "live" else "top"
        self.posterIndex = 0
        self.searchQuery = ""
        # A package opened from Packages always starts with newest titles.
        # This is scoped to the selected package; it does not reorder package
        # folders or override global ordering in GENRE/actor result screens.
        self._packageLatestOnOpen = bool(
            kind in ("vod", "series") and (
                (self.initialCategoryId and self.initialCategoryId != "__recent_added__")
                or (isinstance(source, dict) and source.get("_genre_package_id"))
            )
        )
        self.sortMode = (
            "latest" if self._packageLatestOnOpen
            else (_load_media_content_sort(kind) if kind in ("vod", "series") else "default")
        )
        if kind in ("vod", "series"):
            # MediaScreen uses the common (non-Trailer) footer on both the
            # tall poster and circle styles. Show the real active sort mode.
            self["footerSortValue"] = Label("")
            self.onLayoutFinish.append(self._refreshPosterSortFooter)
            self.onShow.append(self._refreshPosterSortFooter)
        self.lastCategoryItems = []
        self.pageStart = 0
        self.downloads = []
        self.picloads = []
        # r264: always initialize poster request tracking before Recent Add/category rendering.
        self._poster_artwork_requests = {}
        self._poster_slot_tokens = {}
        self._poster_page_serial = 0
        self["brand"] = Label("tv")
        self["rail"] = MenuList([("▣  تلفاز", "live"), ("▤  أفلام", "vod"), ("▥  مسلسلات", "series")])
        self["title"] = Label("%s  •  %s" % (source.get("name", "IPTV"), {"live":tr("LIVE TV"), "vod":tr("MOVIES"), "series":tr("TV SHOWS")}.get(kind, kind)))
        self["category"] = LiveCategoryMenuList([]) if kind == "live" else MenuList([])
        if kind == "live":
            self.onClose.append(self["category"].stop_flag_requests)
        if kind != "live":
            self.topNames = [nav_label("Home"), nav_label("Search"), nav_label("Live"), nav_label("Movies"), nav_label("TV Shows"), nav_label("Packages"), nav_label("GENRE"), nav_label("Resume"), nav_label("Server Finder"), nav_label("Settings"), nav_label("Favorites")]
            self.topIndex = 3 if kind == "vod" else 4
            self.topX = [20 + 170 * i for i in range(11)]
            self.topW = [170] * 11
            for _i, _name in enumerate(self.topNames):
                self["top%d" % _i] = Label(_name)
            self["topSelector"] = Pixmap()
            self["sectionTitle"] = Label(tr("MOVIE CATEGORIES") if kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"] = Label("⌕")
            self["filterIcon"] = Label("☰")
            # Keep the package heading anchored to its original screen x=80,
            # regardless of Arabic BiDi and server-supplied RTL wording.
            self["currentCategory"] = AnchoredMetadataLabel("")
            self["titleLogo"] = Pixmap()
            self["packageLogo"] = Pixmap()
            self["ratingText"] = Label("")
            try:
                self["titleLogo"].hide()
                self["packageLogo"].hide()
                self["ratingText"].setText("")
            except Exception:
                pass
            self._titleLogoToken = ""
            self._titleLogoLoader = None
        self["channelTitle"] = DirectionalLabel(tr("Select a package") if kind == "live" else tr("Select a category"))
        self["nowLabel"] = Label(tr("CONTENT"))
        self["meta"] = CenteredLargePageMetadataLabel("") if kind in ("vod", "series") else DirectionalLabel("")
        self["desc"] = SynopsisLabel("" if kind == "live" else "")
        if kind in ("vod", "series"):
            from .resolution_badge import install_information_badge
            install_information_badge(self, "meta", position=(170, 485))
        if kind == "live":
            self["epgNowTime"] = Label("")
            self["epgNowTitle"] = Label("")
            self["epgNextTime"] = Label("")
            self["epgNextTitle"] = Label("")
            self["epgProgressText"] = Label("")
            from Components.ProgressBar import ProgressBar
            self["liveProgress"] = ProgressBar()
            self["liveProgress"].hide()
            self["livePoster"] = Pixmap()
            self["liveRatingText"] = Label("")
            self["liveStars"] = Label("")
            self["liveInfoMeta"] = DirectionalLabel("")
            try:
                self["liveRatingText"].setText("")
            except Exception:
                pass
            self["list"] = MenuList([])
            # One inexpensive overlay per visible Live row.  Badges use RAM
            # EPG results already available; never query a provider here.
            self.liveLocalEpgBadgeUntil = {}
            self.liveEpgBadgeShown = [False] * 15
            self.liveBadgeCacheGeneration = 0
            # Last visible 15-channel EPG batch warmed. Changed only when the
            # page or package changes, never for every arrow-key press.
            self._liveBadgeWarmPageKey = None
            self.liveBadgeCacheResults = []
            self.liveBadgeCachePolls = 0
            self.liveBadgeCacheRunning = False
            self.liveBadgeCacheLock = threading.RLock()
            self.liveBadgeCacheTimer = eTimer()
            _connect_timer(self.liveBadgeCacheTimer, self._applyLiveBadgeCache)
            self.onClose.append(self.liveBadgeCacheTimer.stop)
            for _epg_badge_idx in range(15):
                _epg_badge_name = "liveEpgBadge%d" % _epg_badge_idx
                self[_epg_badge_name] = Label("EPG")
                self[_epg_badge_name].hide()
            self["list"].onSelectionChanged.append(self._refreshLiveEpgBadges)
            self["liveCategoryScrollThumb"] = Label("")
            self["liveChannelScrollThumb"] = Label("")
            self["channelPicon"] = Pixmap()
            # The stock scrollbar ignores custom slider pictures on some OE-A/Pure2
            # builds. Update both independent themed thumbs on selection changes.
            for list_name in ("category", "list"):
                try:
                    self[list_name].onSelectionChanged.append(
                        lambda n=list_name: self._updateLiveScrollbar(n))
                except Exception:
                    pass
            self["pageInfo"] = Label("")
            self["styleHint"] = Label("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))

            # Small channel-row picons. They load only once per visible 15-row
            # page and use the existing direct_picon cache, so navigation stays fast.
            self.rowPiconLoaders = []
            self.rowPiconPaths = {}
            self.rowPiconPending = False
            self.rowPiconToken = 0
            self.rowPiconPage = -1
            self.rowPiconTimer = eTimer()
            self["clockTitle"] = Label("")
            self["categoryTitle"] = Label(tr("PACKAGES"))
            # Live browsing stays focused on channel lists, logos, and playback.
            self.channelSettings = _load_channel_settings()
            self.zapTimer = eTimer()
            _connect_timer(self.zapTimer, self._autoZapCurrent)
            # Resolve Stalker create_link outside the Enigma2 UI thread.
            # A dead/slow portal must never freeze Live navigation.
            self.liveZapResolveToken = 0
            self.liveZapResolveResult = None
            self.liveZapResolveHandle = None
            self.liveZapResolveDeadline = 0.0
            self.liveZapResolveCallback = None
            self.liveZapResolveTimer = eTimer()
            _connect_timer(self.liveZapResolveTimer, self._finishAsyncLiveZap)
            self.onClose.append(self._cancelLiveZapResolve)
            # playService(0) means only that Enigma accepted a ref. A dead
            # Stalker stream can still buffer forever. Verify actual decoder
            # readiness, with a bounded non-blocking watchdog shared by both
            # the normal Live list and Windows previews.
            self._livePreviewCheckTimer = eTimer()
            _connect_timer(self._livePreviewCheckTimer, self._pollLivePreviewCheck)
            self._livePreviewCheck = None
            # Only a decoder-verified preview may be reused across OK presses,
            # normal Live, and Windows. Enigma may retain an accepted but dead
            # service ref while the player is still buffering.
            self._livePreviewVerifiedRef = ""
            self.onClose.append(self._cancelLivePreviewCheck)
            self.livePiconLoader = ePicLoad()
            try: connect_picture_data(self.livePiconLoader, self._livePiconDecoded, self)
            except Exception: pass
            self.livePiconDownload = None
            self.livePiconToken = 0
            self.livePiconTimer = eTimer()
            _connect_timer(self.livePiconTimer, self._finishLivePicon)
            # TMDb Live poster is isolated from playback/EPG and starts only after a long idle.
            self.livePosterToken = 0
            self.livePosterResult = None
            self.livePosterTimer = eTimer()
            _connect_timer(self.livePosterTimer, self._startLivePosterLookup)
            self.livePosterPoll = eTimer()
            _connect_timer(self.livePosterPoll, self._finishLivePosterLookup)
            # A fresh ePicLoad is used per selected programme. Reusing a decoder
            # during fast navigation can silently drop the next PictureData event.
            self.livePosterLoader = None
            self.livePosterPath = ""
            self._livePosterDisplayedToken = -1
            self._liveKnownPosterUrl = ""
            self._livePosterTitle = ""
            self._liveTmdbDetailsCache = {}
            try: self["livePoster"].hide()
            except Exception: pass
            self.directEpgToken = 0
            self.directEpgResult = None
            # LG US local XMLTV readiness polling reuses directEpgTimer.
            # No additional timer/hook is created.
            self.fastLocalEpgPending = None
            self.directEpgTimer = eTimer()
            _connect_timer(self.directEpgTimer, self._finishDirectEpg)
            self.stalkerEpgDownloadedChannels = set()
            # Missing EPG is not a reason to resubmit the same visible page.
            self.stalkerEpgNoDataUntil = {}
            self.stalkerEpgNoDataSource = None
            self.stalkerShortEpgResults = {}
            self.stalkerEpgPending = []
            self.stalkerEpgBatchRunning = False
            self.stalkerEpgGeneration = 0
            self.stalkerEpgCancel = None
            self.stalkerEpgBatchKey = None
            self.stalkerEpgInFlight = ()
            self.stalkerEpgChannelRows = {}
            # Give an active stream-link request priority over bulk EPG.
            self._stalkerEpgPausedForPlay = False
            self._windowsScreen = None
            self.stalkerEpgClient = None
            self.stalkerEpgLock = threading.RLock()
            self.stalkerEpgApplyTimer = eTimer()
            _connect_timer(self.stalkerEpgApplyTimer, self._drainStalkerEpgUpdates)
            # Xtream uses the existing Live selection debounce timer for a
            # Stalker-style visible-page EPG prefetch. No additional timer or
            # selection hook is created. Cache only successful provider rows.
            self.xtreamShortEpgResults = {}
            self.xtreamEpgDownloadedChannels = set()
            self.xtreamEpgBatchRunning = False
            self.xtreamEpgLock = threading.RLock()
            # r446: Xtream EPG uses one provider client/cache path just like
            # Stalker (RAM -> persistent HDD cache -> provider API).
            self.xtreamEpgClient = None
            # r443: the highlighted Xtream channel has its own direct request
            # state.  The visible-page batch only warms the remaining rows.
            # Reuse directEpgTimer as the GUI poller; no extra timer/hook.
            self.xtreamEpgPendingDisplay = None
            self.xtreamDirectEpgInFlight = set()
            self.xtreamDirectEpgResults = {}
            self.xtreamDirectEpgSelected = ""
            self.xtreamDirectEpgFallback = ""
            # Negative EPG cache: channels with no guide must not issue a fresh
            # short_epg request every time the viewer returns to the row.
            # Retry after ten minutes so guide data can appear later.
            self.xtreamEpgMissUntil = {}
            # r461: Xtream Live renders channels in 15-row lazy batches.
            # The full category stays in RAM, but the MenuList only receives
            # the first 15 rows; another 15 are appended when navigation
            # reaches the end of the currently rendered batch.
            self.xtreamLiveBatchSize = 15
            self.xtreamLiveLoadedCount = 0

            # EStalker 1.45 Live compatibility state.
            self.stalkerLivePageSize = 14
            self.stalkerLiveAdultPageSize = 20
            self.stalkerLiveCategoryId = ""
            self.stalkerLiveTotal = 0
            self.stalkerLiveSlots = []
            self.stalkerLiveLoadedPages = set()
            self.stalkerLivePendingPages = set()
            self.stalkerLivePageDeadlines = {}
            self.stalkerLivePageRetryUntil = {}
            # Ultra TaskHandle objects cancel queued and active MAG requests
            # when the bouquet, page or browser changes.
            self.stalkerLivePageHandles = {}
            self.stalkerLivePageResult = None
            self.stalkerLivePageResults = []
            self.stalkerLivePageGeneration = 0
            self.stalkerLiveCancelEvent = threading.Event()
            self.stalkerLivePageTimer = eTimer()
            _connect_timer(self.stalkerLivePageTimer, self._finishStalkerLivePage)
            self.onClose.append(self._cancelStalkerCatalogueRequests)
            self.stalkerSelectionEpgTimer = eTimer()
            _connect_timer(self.stalkerSelectionEpgTimer, self._runStalkerSelectionEpg)
            try: self.oldService = self.session.nav.getCurrentlyPlayingServiceReference()
            except Exception: self.oldService = None
            self.lastZappedLiveId = None
            self.keepCurrentLiveService = False
            self._playingLiveItem = None
            self._playingLiveUrl = ""
            self.stalkerWatchdogClient = None
            self.stalkerWatchdogPending = False
            self.stalkerWatchdogTimer = eTimer()
            _connect_timer(self.stalkerWatchdogTimer, self._runStalkerWatchdog)
            try:
                shared_id = str((self.source or {}).get("_tivimate_current_live_id") or "").strip()
                if shared_id:
                    self.lastZappedLiveId = shared_id
                    self.keepCurrentLiveService = True
                    _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
                    _CURRENT_LIVE_CHANNEL["channel"] = shared_id
                elif _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source):
                    self.lastZappedLiveId = _CURRENT_LIVE_CHANNEL.get("channel") or None
                    self.keepCurrentLiveService = bool(self.lastZappedLiveId)
            except Exception:
                pass
            self.stalkerPinUnlockedUntil = 0
            self._pinPendingAction = None
            self._pinFailures = 0
            self._pinBlockedUntil = 0
        else:
            self["backdrop"] = Pixmap()
            self["contentProviderNetflix"] = Pixmap()
            self["contentProviderPrime"] = Pixmap()
            self["contentProviderDisney"] = Pixmap()
            self["contentProviderMax"] = Pixmap()
            self["contentProviderApple"] = Pixmap()
            self["contentProviderParamount"] = Pixmap()
            for i in range(5):
                self["poster%d" % i] = Pixmap()
                self["posterShell%d" % i] = Pixmap()
                try:
                    self["posterShell%d" % i].hide()
                except Exception:
                    pass
                if getattr(self, "posterViewStyle", "original") == "circle":
                    self["posterFocus%d" % i] = Pixmap()
                    try:
                        self["posterFocus%d" % i].hide()
                    except Exception:
                        pass
                self["posterLabel%d" % i] = Label("")
                self["posterYear%d" % i] = Label("")
                try:
                    self["posterYear%d" % i].hide()
                except Exception:
                    pass
                self["posterRateBg%d" % i] = Pixmap()
                try:
                    self["posterRateBg%d" % i].hide()
                except Exception:
                    pass
                self["posterRate%d" % i] = Label("")
            self["selector"] = Pixmap()
            self.backdropLoader = None
            self.backdropLoaders = []
            self.backdropDownloader = None
            self.infoTimer = eTimer()
            _connect_timer(self.infoTimer, self.loadSelectedInfo)
            self.fullInfoCache = {}
            self.infoProcesses = {}
            self.pendingInfoId = ""
        self.categoryLoadToken = 0
        self.categoryLoadResult = None
        self.catchupPackageActive = False
        self.catchupPackageResult = None
        self.catchupPackageToken = 0
        self.catchupPackageTimer = eTimer()
        _connect_timer(self.catchupPackageTimer, self._finishCatchupPackageLoad)
        self.categoryLoadTimer = eTimer()
        _connect_timer(self.categoryLoadTimer, self._finishCategoryLoad)
        # Catalog requests are independent from category item requests.  This keeps
        # opening any table responsive even when a provider is slow or unavailable.
        self.catalogLoadToken = 0
        self.catalogLoadResult = None
        self.catalogLoadPolls = 0
        self._catalogLoadStarted = 0.0
        self.catalogFirstOpenRetry = 0
        self.catalogRetryTimer = eTimer()
        _connect_timer(self.catalogRetryTimer, self._retryCatalogFirstOpen)
        self.catalogLoadTimer = eTimer()
        _connect_timer(self.catalogLoadTimer, self._finishCatalogLoad)
        self.onClose.append(self._stopCatalogLoadingTimers)
        self["keys"] = Label(tr("LEFT/RIGHT Navigate   UP/DOWN Pages   OK Select   RED Previous   BLUE Next   GREEN Server (long Filter)   YELLOW Sort (long Favorite)   MENU Poster Style   EXIT Back")) if kind != "live" else Label("")
        self["guideBar"] = Pixmap()
        if kind == "live": self._updateLiveKeys()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions", "NumberActions", "ChannelSelectBaseActions", "InfobarChannelSelection"], {
            "ok": self.ok, "cancel": self.cancelAction, "up": self.up, "down": self.down,
            "left": self.left, "right": self.right,
            "red": self.toggleCurrentFavourite if kind == "live" else self.previousCategory,
            "blue": self.openLiveColorMenu if kind == "live" else self.nextCategory,
            "green": self.openLiveFilter if kind == "live" else self.openPosterServer,
            "yellow": self.openLiveServerMenu if kind == "live" else self.toggleSort,
            "yellowlong": self.addCurrentFavourite,
            "greenlong": self.openPosterServerFilter,
            "menu": self.openLiveMainMenu if kind == "live" else self._openPosterViewPicker,
            "info": self.openLiveTools if kind == "live" else self.openFavorites,
            "pageUp": self.pageUp, "pageDown": self.pageDown,
            "channelUp": self.liveFastUp, "channelDown": self.liveFastDown,
            "nextBouquet": self.liveFastDown, "prevBouquet": self.liveFastUp,
            "0": self.openBeinSports
        }, -1)
        self.onLayoutFinish.append(self._prepareScreen)
        if kind == "live":
            self.onLayoutFinish.append(self._refreshLiveScrollbars)
            self.onLayoutFinish.append(self._refreshLiveEpgBadges)
            # Open the saved Windows view even if its catalogue is still loading.
            # Package selection takes place inside LiveWindowsScreen itself.
            self.onLayoutFinish.append(self._queueWindowsAutoOpen)
        if kind != "live":
            self.onLayoutFinish.append(self._updateServerPackageGridLogo)


    def openPosterServer(self):
        if self.kind not in ('vod', 'series'):
            return
        from .poster_remote_actions import open_server
        return open_server(self)

    def openPosterServerFilter(self):
        if self.kind not in ('vod', 'series'):
            return
        from .poster_remote_actions import open_filter
        return open_filter(self)

    def _openPosterViewPicker(self):
        from .view_style_picker import PosterViewPicker
        context = str(self.source.get('_view_picker_context') or 'package')
        self.session.openWithCallback(self._applyPosterViewChoice, PosterViewPicker, context, self.kind)

    def _applyPosterViewChoice(self, choice=None):
        if choice not in ('circle', 'poster', 'genre', 'cinematic'): return
        # Actor search is a virtual collection, never an ordinary package.
        # The screen's page may contain just 30 entries, so restore the
        # complete original actor matches rather than its visible page.
        if isinstance(self.source, dict) and self.source.get('_actor_search_name'):
            from .actor_results_layout import open_actor_results
            rows = self.source.get('_actor_search_rows') or self.preloadedItems
            open_actor_results(self.session, self.source, self.kind,
                               self.source.get('_actor_search_name'), rows, style=choice)
            return
        # Retain the selected provider category and its cached catalogue.
        category_id = str(getattr(self, 'activeCategoryId', '') or self.initialCategoryId or '')
        category_name = str(getattr(self, 'activeCategoryName', '') or self.initialCategoryName or '')
        context = str(self.source.get('_view_picker_context') or 'package')
        if choice == 'cinematic':
            from .cinematic_catalog import CinematicCatalogScreen
            self.session.open(CinematicCatalogScreen, dict(self.source), self.kind, category_id)
            return
        if choice == 'genre':
            from .genre_page import StandaloneGenreScreen
            self.session.open(StandaloneGenreScreen, dict(self.source), self.kind, category_id)
            return
        next_source = dict(self.source)
        next_source['_view_style_override'] = 'circle' if choice == 'circle' else 'original'
        self.session.open(MediaScreen, next_source, self.kind, category_id, category_name,
                          list(getattr(self, 'mediaItemsCurrent', []) or []))

    def noAction(self):
        return

    def openBeinSports(self):
        """Open the dedicated beIN SPORTS view from Live without changing servers."""
        if self.kind != "live":
            return
        try:
            self._loadBeinSports()
        except Exception as exc:
            try:
                self["desc"].setText("beIN SPORTS: %s" % exc)
            except Exception:
                pass

    def _liveServerStatusLabel(self, source):
        state = str((source or {}).get("_last_status") or "").strip().lower()
        if state == "busy":
            return u"🟡"
        if state == "online":
            return u"🟢"
        if state == "offline":
            return u"🔴"
        return u"⚪"

    def _compactLiveServerName(self, source):
        name = str((source or {}).get("name") or "").strip()
        url = str((source or {}).get("url") or (source or {}).get("portal") or "").strip()
        # Finder's old post-title names are noisy. Prefer provider host/IP for them.
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    def _sameLiveServer(self, left, right):
        left = left or {}
        right = right or {}
        if str(left.get("type") or "").lower() != str(right.get("type") or "").lower():
            return False

        source_type = str(left.get("type") or "").lower()
        if source_type == "stalker":
            left_mac = str(left.get("mac") or "").strip().upper()
            right_mac = str(right.get("mac") or "").strip().upper()
            if left_mac and right_mac and left_mac != right_mac:
                return False

            def hostport(source):
                raw = str(source.get("url") or source.get("portal") or source.get("host") or "").strip()
                try:
                    parsed = urlparse(raw if "://" in raw else "http://" + raw)
                    host = (parsed.hostname or "").lower()
                    port = parsed.port
                    if not port:
                        port = 443 if parsed.scheme == "https" else 80
                    return host, int(port)
                except Exception:
                    return raw.rstrip("/").lower(), 0

            return hostport(left) == hostport(right) and bool(left_mac or right_mac)

        return _source_identity(left) == _source_identity(right)

    def openLiveServerMenu(self):
        if self.kind != "live":
            return
        sources = get_sources()
        if not sources:
            self.session.open(MessageBox, tr("No server selected • Press SETTINGS"), MessageBox.TYPE_INFO)
            return
        base_current = _bein_base_source(self.source)
        current_key = _source_identity(base_current)
        rows = []
        for candidate in sources:
            selected_here = (
                not self.source.get("_virtual_bein") and
                self._sameLiveServer(candidate, base_current)
            )
            rows.append((dict(candidate), selected_here))
        self.session.openWithCallback(
            self._liveServerSelected, LiveServerChoiceScreen, rows
        )

    def _liveServerSelected(self, selected=None):
        if not selected:
            self._queueWindowsAutoOpen()
            return
        if isinstance(selected, tuple) and len(selected) == 2 and selected[0] in ("delete", "test"):
            action, source = selected
            if action == "delete":
                try:
                    sources = get_sources()
                    target = _source_identity(source)
                    kept = [item for item in sources if _source_identity(item) != target]
                    if len(kept) != len(sources):
                        set_sources(kept)
                        write_playlists(kept)
                except Exception:
                    pass
                return
            if action == "test":
                try:
                    source_type = source.get("type")
                    if source_type == "stalker":
                        details = StalkerClient(source).test()
                    elif source_type == "xtream":
                        details = XtreamClient(source).test()
                    else:
                        details = get_source_client(source).test()
                    msg = "ONLINE" if details else "Test completed"
                    self.session.open(MessageBox, msg, MessageBox.TYPE_INFO, timeout=5)
                except Exception as exc:
                    self.session.open(MessageBox, "Test failed: %s" % exc, MessageBox.TYPE_ERROR, timeout=6)
                return
        if isinstance(selected, dict):
            source = selected
        else:
            try:
                source = selected[1]
            except Exception:
                return
        if not isinstance(source, dict):
            return
        # Persist only a real provider.  beIN SPORTS is a view over that provider.
        if source.get("_virtual_bein"):
            _save_live_source(_bein_base_source(source))
        else:
            _save_live_source(source)
        try:
            self.close()
            self._openPageOnce(MediaScreen, dict(source), "live")
        except Exception:
            pass

    def openLiveMainMenu(self):
        if self.kind != "live":
            return
        # One main menu, shared by Classic and Windows modes. No duplicate
        # Change View or Export entries in the secondary Live Options list.
        from .live_menu_screen import LiveMenuScreen
        self.session.openWithCallback(self._liveMainMenuSelected, LiveMenuScreen)

    def _liveMainMenuSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) else selected
        if action == "change_live_view":
            self.openLiveViewMenu()
        elif action == "favorites":
            self.openFavorites()
        elif action == "export_enigma2":
            self._openBouquetExportMenu()
        elif action == "options":
            self.openLiveTools()

    def openLiveTools(self):
        if self.kind != "live":
            self.openFavorites(); return
        choices = []
        source_type = self.source.get("type")
        if self.focus == "items" and self.current() and source_type in ("stalker", "xtream", "m3u"):
            choices.append((tr("Move this channel"), "move_channel"))
        if source_type in ("stalker", "xtream", "m3u"):
            pin_state = _load_stalker_pin(self.source) if source_type == "stalker" else _load_xtream_pin(self.source)
            if self.focus == "category":
                choices.append((tr("Hide this package"), "hide_category"))
                row = self["category"].getCurrent()
                cid = str(row[1] or "") if row else ""
                if cid and not cid.startswith("__"):
                    if cid in pin_state["categories"]:
                        choices.append((tr("Unlock this package"), "unlock_category"))
                    else:
                        choices.append((tr("Lock this package"), "lock_category"))
            elif self.current():
                choices.append((tr("Hide this channel"), "hide_channel"))
                channel_id = _live_item_id(self.current())
                if channel_id in pin_state["channels"]:
                    choices.append((tr("Unlock this channel"), "unlock_channel"))
                else:
                    choices.append((tr("Lock this channel"), "lock_channel"))
            choices.append((tr("Change parental PIN"), "change_pin"))
            if source_type in ("stalker", "xtream"):
                choices.append(((tr("Stalker player engines") if source_type == "stalker" else tr("Xtream player engines")), "player_engines"))
            if source_type == "stalker":
                choices.append((tr("Recently watched"), "stalker_recent"))
            state = _load_stalker_hidden(self.source) if source_type == "stalker" else _load_xtream_hidden(self.source)
            if state["categories"]:
                choices.append((tr("Show hidden packages"), "show_hidden_packages"))
            if state["channels"]:
                choices.append((tr("Show hidden channels"), "show_hidden_channels"))
        self.session.openWithCallback(self._liveToolSelected, ChoiceBox, title="Live Options", list=choices)

    def _liveToolSelected(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        source_type = self.source.get("type")
        prefix = "stalker" if source_type == "stalker" else "xtream"
        if action == "skin": self.openLiveColorMenu(); return
        if action == "change_live_view": self.openLiveViewMenu(); return
        if action == "favorites": self.openFavorites(); return
        if action == "export_enigma2": self._openBouquetExportMenu(); return
        if action == "move_channel": self._startMoveCurrentLive(); return
        if action == "hide_category":
            self.focus = "category"
            self._hideCurrentLiveCategory(prefix)
            return
        if action == "hide_channel": self._hideCurrentLiveChannel(prefix); return
        if action == "show_hidden_packages": self._showHiddenLiveItems(prefix, "category"); return
        if action == "show_hidden_channels": self._showHiddenLiveItems(prefix, "channel"); return
        if action in ("lock_category", "lock_channel"):
            self._lockCurrentLiveItem(prefix, action == "lock_category"); return
        if action in ("unlock_category", "unlock_channel"):
            self._requestLivePin(prefix, ("unlock", action == "unlock_category")); return
        if action == "change_pin": self._requestLivePin(prefix, ("change_pin", None)); return
        if action == "player_engines":
            return self._openStalkerEngineSettings() if source_type == "stalker" else self._openXtreamEngineSettings()
        if action == "stalker_recent": self._openStalkerRecentlyWatched(); return

    def _openBouquetExportMenu(self, selected_item=None, items=None):
        if self.kind != "live":
            return
        if self.source.get("type") not in ("xtream", "m3u"):
            self.session.open(MessageBox, "Stalker requires an Ultra-style renewable stream resolver before safe bouquet export.", MessageBox.TYPE_INFO)
            return
        self._exportRows = list(items if items is not None else self.mediaItemsCurrent or [])
        self._exportItem = selected_item if selected_item is not None else self.current()
        choices = []
        if self._exportItem:
            choices.append(("Export selected channel", "channel"))
        if self._exportRows:
            choices.append(("Export current package (%d channels)" % len(self._exportRows), "package"))
            choices.append(("Save current package as M3U file (%d channels)" % len(self._exportRows), "m3u"))
        enabled = bool(self.channelSettings.get("export_picons", True))
        choices.append(("Download Picons with Export: %s" % ("ON" if enabled else "OFF"), "toggle_picons"))
        choices.append(("Picon Download Status", "picon_status"))
        if self._exportRows:
            choices.append(("Retry Missing Picons", "retry_picons"))
        if not choices:
            self.session.open(MessageBox, "Open a package with channels first.", MessageBox.TYPE_INFO)
            return
        self.session.openWithCallback(self._bouquetExportPicked, ChoiceBox,
                                      title="Export to Enigma2", list=choices)

    def _bouquetExportPicked(self, selected=None):
        if not selected:
            return
        selection = selected[1]
        if selection == "toggle_picons":
            self.channelSettings["export_picons"] = not bool(self.channelSettings.get("export_picons", True))
            _save_channel_settings(self.channelSettings)
            self._openBouquetExportMenu(selected_item=getattr(self, "_exportItem", None),
                                        items=getattr(self, "_exportRows", []))
            return
        if selection == "picon_status":
            from .bouquet_export_picons import read_export_picon_status
            state = read_export_picon_status()
            if not state:
                message = "No Picon export has been started."
            else:
                good = int(state.get("cached", 0)) + int(state.get("downloaded", 0))
                message = ("Picons: %d / %d ready\nProcessed: %d / %d%s"
                           "\nMissing logo URLs: %d\nDownload errors: %d\nWrite errors: %d" % (
                           good, int(state.get("total", 0)), int(state.get("processed", 0)),
                           int(state.get("total", 0)), " (running)" if state.get("running") else "",
                           int(state.get("missing_url", 0)),
                           int(state.get("failed_download", 0)),
                           int(state.get("failed_write", 0))))
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
            return
        if selection == "m3u":
            try:
                from .bouquet_export import export_m3u
                category_name = self.activeCategoryName or self.initialCategoryName
                count, path = export_m3u(self.source, category_name, list(self._exportRows))
                self.session.open(MessageBox, "%d channel(s) saved as M3U:\n%s" % (count, path), MessageBox.TYPE_INFO)
            except Exception as exc:
                self.session.open(MessageBox, "M3U export failed: %s" % exc, MessageBox.TYPE_ERROR)
            return
        if selection == "retry_picons":
            from .bouquet_export_picons import queue_export_picons
            stype = (_xtream_service_type(self.source, "live")
                     if self.source.get("type") == "xtream" else 4097)
            started = queue_export_picons(self.source, list(self._exportRows), stype)
            message = "Picon scan started for the entire package." if started else "Picon scan is already running."
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
            return
        self.session.openWithCallback(
            lambda confirmed: self._bouquetExportConfirmed(confirmed, selection),
            MessageBox, "Add these channels to the receiver's native Enigma2 bouquets? Existing bouquets will be preserved.",
            MessageBox.TYPE_YESNO)

    def _bouquetExportConfirmed(self, confirmed, selection):
        if not confirmed:
            return
        try:
            from .bouquet_export import export_bouquet, reload_enigma_bouquets
            rows = ([self._exportItem] if selection == "channel" else self._exportRows)
            category_id = self.selectedCategory() or self.initialCategoryId
            category_name = self.activeCategoryName or self.initialCategoryName
            stype = ( _xtream_service_type(self.source, "live")
                      if self.source.get("type") == "xtream" else 4097)
            count, filename = export_bouquet(self.source, category_id,
                                           category_name, rows, selection, stype)
            loaded = reload_enigma_bouquets()
            picons_started = False
            if self.channelSettings.get("export_picons", True):
                from .bouquet_export_picons import queue_export_picons
                picons_started = queue_export_picons(self.source, rows, stype)
            # Show the same short bouquet title as the native Enigma2 list,
            # not the internal hashed userbouquet.*.tv filename.
            display_name = (category_name or "Live") if selection == "package" else "Selected Channels"
            message = "%d channel(s) exported to %s" % (count, display_name)
            if picons_started:
                message += "\nPicons are being saved in the background."
            if not loaded:
                message += "\nRestart Enigma2 GUI to see the bouquet."
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
        except Exception as exc:
            self.session.open(MessageBox, "Export failed: %s" % exc, MessageBox.TYPE_ERROR)

    def _startMoveCurrentLive(self):
        if self.kind != "live" or self.focus != "items" or not self.current():
            return
        self._liveMoveMode = True
        self._liveMoveOriginal = list(self.mediaItemsCurrent or [])
        try: self["desc"].setText(tr("Move channel with UP/DOWN, then press OK to save."))
        except Exception: pass

    def _moveCurrentLiveBy(self, delta):
        if not self._liveMoveMode:
            return False
        try: index = int(self["list"].getSelectedIndex() or 0)
        except Exception: index = 0
        target = index + int(delta)
        rows = self.mediaItemsCurrent or []
        if target < 0 or target >= len(rows):
            return True
        rows[index], rows[target] = rows[target], rows[index]
        self.mediaItemsCurrent = rows
        if self.source.get("type") == "xtream":
            self.xtreamLiveLoadedCount = max(int(getattr(self, "xtreamLiveLoadedCount", 15) or 15), target + 1)
            self._renderXtreamLiveBatch(target, ensure_next=False)
        elif self.source.get("type") == "m3u":
            self.m3uLiveLoadedCount = max(int(getattr(self, "m3uLiveLoadedCount", 15) or 15), target + 1)
            self._renderM3uLiveBatch(target, ensure_next=False)
        else:
            display = [("%03d   %s" % (i + 1, row.get("name") or row.get("title") or "Unnamed Channel"), row) for i, row in enumerate(rows)]
            self["list"].setList(display); self["list"].moveToIndex(target)
        return True

    def _finishMoveCurrentLive(self):
        if not self._liveMoveMode:
            return False
        try: category_id = str(self.selectedCategory() or "")
        except Exception: category_id = ""
        _save_live_channel_order(self.source, category_id, self.mediaItemsCurrent)
        self._liveMoveMode = False
        self._liveMoveOriginal = None
        try: self["desc"].setText(tr("Channel position saved."))
        except Exception: pass
        return True

    def _liveStateFns(self, prefix):
        if prefix == "stalker":
            return _load_stalker_hidden, _save_stalker_hidden, _load_stalker_pin, _save_stalker_pin
        return _load_xtream_hidden, _save_xtream_hidden, _load_xtream_pin, _save_xtream_pin

    def _hideCurrentLiveCategory(self, prefix):
        row = self["category"].getCurrent()
        if not row: return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source); state["categories"].add(cid); state["category_names"][cid] = str(name or cid); save_hidden(self.source, state)
        rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
        self["category"].setList(rows); self["list"].setList([]); self.focus = "category"
        self["desc"].setText(tr("Package hidden. Use MENU to restore it."))

    def _hideCurrentLiveChannel(self, prefix):
        item = self.current()
        if not item: return
        channel_id = _live_item_id(item)
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source); state["channels"].add(channel_id); state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id); save_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))

    def _showHiddenLiveItems(self, prefix, kind):
        load_hidden, _save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source)
        choices = []
        if kind == "category":
            for cid in sorted(state["categories"]):
                choices.append((state["category_names"].get(cid, cid), (prefix, "category", cid)))
            title = tr("Show hidden packages")
            empty = tr("No hidden packages.")
        else:
            for chid in sorted(state["channels"]):
                choices.append((state["channel_names"].get(chid, chid), (prefix, "channel", chid)))
            title = tr("Show hidden channels")
            empty = tr("No hidden channels.")
        if not choices:
            self.session.open(MessageBox, empty, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenLiveItem, ChoiceBox, title=title, list=choices)

    def _restoreHiddenLiveItem(self, selected=None):
        if not selected: return
        try:
            prefix, kind, item_id = selected[1]
        except Exception:
            return
        load_hidden, save_hidden, _lp, _sp = self._liveStateFns(prefix)
        state = load_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        save_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _lockCurrentLiveItem(self, prefix, is_category=False):
        _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source)
        if is_category:
            row=self["category"].getCurrent(); item_id=str(row[1] or "") if row else ""
            if not item_id or item_id.startswith("__"): return
            state["categories"].add(item_id); state["category_names"][item_id]=str(row[0] or item_id)
        else:
            item=self.current(); item_id=_live_item_id(item) if item else ""
            if not item_id: return
            state["channels"].add(item_id); state["channel_names"][item_id]=str(item.get("name") or item.get("title") or item_id)
        save_pin(self.source,state); self["desc"].setText(tr("Content locked."))

    def _requestLivePin(self, prefix, action):
        self._pinSourcePrefix=prefix; self._pinPendingAction=action
        self.session.openWithCallback(self._livePinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _livePinEntered(self, value=None):
        if value is None: return
        prefix=getattr(self,"_pinSourcePrefix","xtream"); _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source)
        if str(value).strip()!=str(state.get("pin") or "0000"): self.session.open(MessageBox,tr("Incorrect PIN"),MessageBox.TYPE_ERROR); return
        kind,payload=self._pinPendingAction
        if kind=="unlock":
            is_category=bool(payload)
            if is_category:
                row=self["category"].getCurrent(); item_id=str(row[1] or "") if row else ""; state["categories"].discard(item_id); state["category_names"].pop(item_id,None)
            else:
                item_id=_live_item_id(self.current()); state["channels"].discard(item_id); state["channel_names"].pop(item_id,None)
            save_pin(self.source,state); self["desc"].setText(tr("Lock removed."))
        elif kind=="change_pin":
            self.session.openWithCallback(lambda v,p=prefix:self._liveNewPinEntered(p,v),VirtualKeyBoard,title=tr("Enter new 4-digit PIN"),text="")

    def _liveNewPinEntered(self, prefix, value=None):
        value=str(value or "").strip()
        if not(len(value)==4 and value.isdigit()): self.session.open(MessageBox,tr("PIN must contain exactly 4 digits."),MessageBox.TYPE_ERROR); return
        _lh,_sh,load_pin,save_pin=self._liveStateFns(prefix); state=load_pin(self.source); state["pin"]=value; save_pin(self.source,state); self.session.open(MessageBox,tr("Parental PIN changed."),MessageBox.TYPE_INFO)

    def _openXtreamEngineSettings(self):
        self._xtreamEngineValues=_load_xtream_service_types(self.source); self._chooseXtreamEngine("live")

    def _chooseXtreamEngine(self, kind):
        labels={"live":tr("Xtream Live player"),"vod":tr("Xtream Movies player"),"series":tr("Xtream Series player")}; current=int(self._xtreamEngineValues.get(kind,4097)); choices=[((u"✓ " if v==current else u"")+str(v),v) for v in STALKER_SERVICE_TYPE_CHOICES]
        self.session.openWithCallback(lambda selected,k=kind:self._xtreamEngineSelected(k,selected),ChoiceBox,title=labels[kind],list=choices)

    def _xtreamEngineSelected(self, kind, selected=None):
        if not selected:return
        try:value=int(selected[1])
        except Exception:return
        self._xtreamEngineValues[kind]=value; order=("live","vod","series")
        try:next_kind=order[order.index(kind)+1]
        except Exception:next_kind=None
        if next_kind:return self._chooseXtreamEngine(next_kind)
        _save_xtream_service_types(self.source,self._xtreamEngineValues); self.channelSettings["service_type"]=self._xtreamEngineValues["live"]; _save_channel_settings(self.channelSettings); self.session.open(MessageBox,tr("Xtream player engines saved."),MessageBox.TYPE_INFO,timeout=3)

    def _openXtreamCatchup(self):
        item = self.current()
        if not item:
            return
        if not (item.get("tv_archive") or item.get("archive") or item.get("has_archive") or item.get("tv_archive_duration")):
            self.session.open(MessageBox, tr("This channel does not advertise catch-up support."), MessageBox.TYPE_INFO); return

        self._xtreamCatchupItem = dict(item)
        self._xtreamCatchupResult = None
        self._xtreamCatchupId = getattr(self, "_xtreamCatchupId", 0) + 1
        request_id = self._xtreamCatchupId
        self._xtreamCatchupStarted = time.monotonic()
        try: self._xtreamCatchupTimer.stop()
        except Exception: pass
        try:
            self["desc"].setText("")
        except Exception:
            pass
        source = dict(self.source)
        stream_id = str(item.get("stream_id") or item.get("id") or "")
        epg_id = str(item.get("epg_channel_id") or item.get("epg_id") or "")

        def worker():
            rows, error = [], ""
            try:
                rows = XtreamClient(source).catchup_epg(stream_id, epg_channel_id=epg_id) or []
            except Exception as exc:
                error = str(exc)
            if request_id == getattr(self, "_xtreamCatchupId", None):
                self._xtreamCatchupResult = (rows, error)

        t = threading.Thread(target=worker, name="TiviMateXtreamCatchup")
        t.daemon = True
        t.start()
        self._xtreamCatchupTimer = eTimer()
        _connect_timer(self._xtreamCatchupTimer, self._finishXtreamCatchupLoad)
        try:
            self._xtreamCatchupTimer.start(120, False)
        except Exception:
            pass

    def _parseXtreamCatchupDate(self, value):
        text = str(value or "").strip().replace("T", " ")
        if not text:
            return None
        # XStreamity parses the provider's raw EPG wall-clock value and uses
        # that same wall-clock for the timeshift URL. Do not convert through
        # receiver localtime/UTC here.
        for fmt in (
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H-%M-%S",
            "%Y-%m-%d-%H:%M:%S",
            "%Y-%m-%d %H:%M",
        ):
            try:
                return datetime.strptime(text[:19] if "%S" in fmt else text[:16], fmt)
            except Exception:
                pass
        return None

    def _finishXtreamCatchupLoad(self):
        result = getattr(self, "_xtreamCatchupResult", None)
        if result is None:
            if time.monotonic() - getattr(self, "_xtreamCatchupStarted", time.monotonic()) >= 60.0:
                self._xtreamCatchupId = getattr(self, "_xtreamCatchupId", 0) + 1
                try: self._xtreamCatchupTimer.stop()
                except Exception: pass
                try: self["desc"].setText("Catch-up server did not respond. Please retry.")
                except Exception: pass
                return
            try:
                self._xtreamCatchupTimer.start(120, False)
            except Exception:
                pass
            return
        try:
            self._xtreamCatchupTimer.stop()
        except Exception:
            pass

        self._xtreamCatchupResult = None
        rows, error = result
        now = int(time.time())
        item = getattr(self, "_xtreamCatchupItem", {}) or {}

        # Xtream tv_archive_duration is the provider's archive window in days.
        try:
            archive_days = int(float(str(item.get("tv_archive_duration") or "0")))
        except Exception:
            archive_days = 0
        if archive_days <= 0:
            self.session.open(
                MessageBox,
                tr("This channel has no provider catch-up window."),
                MessageBox.TYPE_INFO
            )
            return

        cutoff = now - (archive_days * 86400)
        choices = []

        for row in rows or []:
            if not isinstance(row, dict):
                continue

            title = self._decodeEpgText(
                row.get("title") or row.get("name") or row.get("programme")
            )
            if not title:
                continue

            begin = self._epgTimestamp(row, True)
            finish = self._epgTimestamp(row, False)

            # Catch-up = a completed historical programme only.
            # Never show current or future EPG rows.
            if not begin or not finish:
                continue
            if finish > now:
                continue
            if begin < cutoff:
                continue
            if finish <= begin:
                continue

            raw_start = row.get("start") or row.get("begin") or ""
            raw_end = row.get("end") or row.get("stop") or ""
            start_dt = self._parseXtreamCatchupDate(raw_start)
            end_dt = self._parseXtreamCatchupDate(raw_end)

            if start_dt:
                catchup_date = start_dt.strftime("%Y-%m-%d:%H-%M")
            else:
                catchup_date = time.strftime(
                    "%Y-%m-%d:%H-%M", time.localtime(begin)
                )

            if start_dt and end_dt and end_dt > start_dt:
                duration = max(
                    1, int((end_dt - start_dt).total_seconds() / 60.0)
                )
            else:
                duration = max(1, int((finish - begin + 59) / 60))

            payload = dict(row)
            payload["_begin"] = begin
            payload["_end"] = finish
            payload["_catchup_date"] = catchup_date
            payload["_catchup_duration"] = duration
            payload["_catchup_raw_start"] = str(raw_start or "")
            payload["_catchup_raw_end"] = str(raw_end or "")

            label = "%s  %s" % (
                time.strftime("%d/%m %H:%M", time.localtime(begin)),
                title
            )
            choices.append((label, payload))

        # Newest archived programme first.
        try:
            choices.sort(
                key=lambda x: int((x[1] or {}).get("_begin") or 0),
                reverse=True
            )
        except Exception:
            pass

        if not choices:
            message = tr("No archived programmes are available inside this channel's catch-up window.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
            return

        self.session.openWithCallback(
            self._playXtreamCatchup,
            ChoiceBox,
            title=tr("Catch-up / Archive"),
            list=choices
        )


    def _playXtreamCatchup(self, selected=None):
        if not selected:
            return
        event = dict(selected[1] or {})
        item = getattr(self, "_xtreamCatchupItem", {}) or {}
        try:
            begin = int(event.get("_begin") or self._epgTimestamp(event, True) or 0)
            end = int(event.get("_end") or self._epgTimestamp(event, False) or 0)
            if not begin:
                raise RuntimeError(tr("Programme start time is missing"))
            if not end or end <= begin:
                end = begin + 3600

            # Match XStreamity: duration is minutes and catch-up playback uses
            # the VOD/Series player engine rather than the Live engine.
            duration = int(event.get("_catchup_duration") or 0)
            if duration <= 0:
                duration = max(1, int((end - begin + 59) / 60))
            source = self.source or {}
            base = str(source.get("url") or "").rstrip("/")
            user = str(source.get("username") or "")
            password = str(source.get("password") or "")
            sid = str(item.get("stream_id") or item.get("id") or "").strip()
            if not (base and user and password and sid):
                raise RuntimeError(tr("Xtream archive credentials are incomplete"))

            # XStreamity keeps the final stream component including its real
            # extension. Preserve .ts/.m3u8 from the provider instead of
            # hard-coding .ts.
            stream_name = ""
            for candidate in (
                item.get("url"), item.get("stream_url"), item.get("direct_source"),
                item.get("cmd")
            ):
                candidate = str(candidate or "").strip()
                if candidate and "/live/" in candidate:
                    stream_name = candidate.rsplit("/", 1)[-1].split("?", 1)[0]
                    if stream_name:
                        break

            if not stream_name:
                output = str(
                    source.get("output") or source.get("stream_format") or
                    source.get("format") or "ts"
                ).strip().lstrip(".")
                if not output:
                    output = "ts"
                stream_name = "%s.%s" % (sid, output)

            start_text = str(event.get("_catchup_date") or "").strip()
            if not start_text:
                start_text = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))

            # Build conservative fallbacks for provider timezone differences.
            # The first URL is unchanged. Alternatives are tried only if the
            # first one never actually starts playback.
            start_variants = []
            def add_start(value):
                value = str(value or "").strip()
                if value and value not in start_variants:
                    start_variants.append(value)

            add_start(start_text)
            add_start(time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin)))
            add_start(time.strftime("%Y-%m-%d:%H-%M", time.gmtime(begin)))
            try:
                base_dt = datetime.strptime(start_text, "%Y-%m-%d:%H-%M")
                add_start((base_dt - timedelta(hours=1)).strftime("%Y-%m-%d:%H-%M"))
                add_start((base_dt + timedelta(hours=1)).strftime("%Y-%m-%d:%H-%M"))
            except Exception:
                pass

            catchup_urls = []
            for candidate_start in start_variants:
                # Modern/common Xtream path form.
                candidate_url = "%s/timeshift/%s/%s/%d/%s/%s" % (
                    base, user, password, duration, candidate_start, stream_name
                )
                if candidate_url not in catchup_urls:
                    catchup_urls.append(candidate_url)

                # Older/classic Xtream endpoint used by a number of panels.
                # Keep stream as the numeric stream id, not filename.
                try:
                    query_url = (
                        "%s/streaming/timeshift.php?username=%s&password=%s"
                        "&stream=%s&start=%s&duration=%d"
                    ) % (
                        base, user, password, sid,
                        candidate_start.replace(":", "%3A"),
                        duration
                    )
                    if query_url not in catchup_urls:
                        catchup_urls.append(query_url)
                except Exception:
                    pass

            if not catchup_urls:
                raise RuntimeError(tr("Unable to build catch-up URL"))

            # Probe candidates before entering the player. Some providers publish
            # archive metadata but accept only one Xtream timeshift endpoint.
            def candidate_works(candidate):
                try:
                    req = Request(candidate)
                    try:
                        req.add_header("Range", "bytes=0-1023")
                    except Exception:
                        pass
                    response = urlopen(req, timeout=5)
                    try:
                        code = int(getattr(response, "getcode", lambda: 200)() or 200)
                    except Exception:
                        code = 200
                    try:
                        chunk = response.read(1024)
                    finally:
                        try:
                            response.close()
                        except Exception:
                            pass
                    return code in (200, 206) and bool(chunk)
                except Exception:
                    return False

            working_url = ""
            ordered_urls = []
            for candidate in catchup_urls:
                if candidate_works(candidate):
                    working_url = candidate
                    ordered_urls.append(candidate)
                    break

            if working_url:
                for candidate in catchup_urls:
                    if candidate != working_url:
                        ordered_urls.append(candidate)
                catchup_urls = ordered_urls
                url = working_url
            else:
                # Keep player retry as final fallback for unusual servers that
                # reject Range/probe requests but still play through Enigma2.
                url = catchup_urls[0]

            try:
                service_type = int(_load_xtream_service_types(self.source).get("vod", 4097))
            except Exception:
                service_type = 4097

            title = self._decodeEpgText(
                event.get("title") or event.get("name")
            ) or item.get("name") or "Catch-up"

            ref = eServiceReference(service_type, 0, url)
            ref.setName(title)

            play_item = dict(item)
            play_item["_source_type"] = "xtream"
            play_item["_source_key"] = _source_identity(self.source)
            play_item["_kind"] = "vod"
            play_item["_catchup"] = True
            play_item["_catchup_begin"] = begin
            play_item["_catchup_end"] = end
            play_item["_catchup_url"] = url
            play_item["_catchup_candidates"] = catchup_urls
            play_item["_catchup_service_type"] = service_type
            play_item["name"] = title

            self.session.openWithCallback(
                self.playerClosed, TiviMatePlayer, ref, play_item
            )
        except Exception as exc:
            self.session.open(
                MessageBox,
                "%s: %s" % (tr("Unable to play catch-up"), exc),
                MessageBox.TYPE_ERROR
            )


    def _openStalkerRecentlyWatched(self):
        if self.source.get("type") != "stalker":
            return
        rows = _load_stalker_recent(self.source, 30)
        choices = []
        for resume_key, row in rows:
            title = str(row.get("title") or tr("Untitled"))
            position = int(row.get("position", 0) or 0)
            length = int(row.get("length", 0) or 0)
            if length > 0:
                pct = max(0, min(99, int(position * 100 / length)))
                label = "%s  •  %d%%" % (title, pct)
            else:
                label = "%s  •  %02d:%02d" % (title, position // 60, position % 60)
            choices.append((label, (resume_key, row)))
        if not choices:
            self.session.open(MessageBox, tr("No recently watched Stalker items."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerRecentlyWatched, ChoiceBox, title=tr("Recently watched"), list=choices)

    def _playStalkerRecentlyWatched(self, selected=None):
        if not selected:
            return
        try:
            _resume_key_value, row = selected[1]
            item = dict(row.get("item") or {})
            kind = str(row.get("kind") or "vod")
            if kind not in ("vod", "series"):
                kind = "vod"
            item["_source_type"] = "stalker"
            item["_source_key"] = _source_identity(self.source)
            item["_kind"] = kind
            source = dict(self.source)

            def done(url, item=item, kind=kind, source=source):
                if not url:
                    self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), tr("Portal returned no playable URL")), MessageBox.TYPE_ERROR)
                    return
                ref = eServiceReference(_stalker_service_type(source, kind), 0, url)
                ref.setName(item.get("name") or item.get("title") or "IPTV")
                self.session.openWithCallback(self.playerClosed, TiviMatePlayer, ref, item)

            def failed(exc):
                self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)
            # Portal login + create_link off the GUI thread (no freeze).
            from .bg_resolve import resolve_async
            resolve_async(lambda: StalkerClient(source).stream_url(item, kind), done, failed)
        except Exception as exc:
            self.session.open(MessageBox, "%s\n%s" % (tr("Unable to play this item."), exc), MessageBox.TYPE_ERROR)

    def _openStalkerEngineSettings(self):
        if self.source.get("type") != "stalker":
            return
        self._stalkerEngineValues = _load_stalker_service_types(self.source)
        self._chooseStalkerEngine("live")

    def _chooseStalkerEngine(self, kind):
        labels = {"live": tr("Stalker Live player"), "vod": tr("Stalker Movies player"), "series": tr("Stalker Series player")}
        current = int(self._stalkerEngineValues.get(kind, 4097))
        choices = []
        for value in STALKER_SERVICE_TYPE_CHOICES:
            choices.append(((u"✓ " if value == current else u"") + str(value), value))
        self.session.openWithCallback(lambda selected, k=kind: self._stalkerEngineSelected(k, selected), ChoiceBox, title=labels.get(kind, kind), list=choices)

    def _stalkerEngineSelected(self, kind, selected=None):
        if not selected:
            return
        try:
            value = int(selected[1])
        except Exception:
            return
        if value not in STALKER_SERVICE_TYPE_CHOICES:
            return
        self._stalkerEngineValues[kind] = value
        order = ("live", "vod", "series")
        try:
            next_kind = order[order.index(kind) + 1]
        except Exception:
            next_kind = None
        if next_kind:
            return self._chooseStalkerEngine(next_kind)
        if _save_stalker_service_types(self.source, self._stalkerEngineValues):
            self.session.open(MessageBox, tr("Stalker player engines saved."), MessageBox.TYPE_INFO, timeout=3)
        else:
            self.session.open(MessageBox, tr("Unable to save Stalker player engines."), MessageBox.TYPE_ERROR)

    def _lockCurrentStalkerItem(self, is_category=False):
        if self.source.get("type") != "stalker":
            return
        state = _load_stalker_pin(self.source)
        if is_category:
            row = self["category"].getCurrent()
            if not row:
                return
            item_id = str(row[1] or "")
            if not item_id or item_id.startswith("__"):
                self.session.open(MessageBox, tr("This package cannot be locked."), MessageBox.TYPE_INFO); return
            state["categories"].add(item_id)
            state["category_names"][item_id] = str(row[0] or item_id)
            message = tr("Package locked.")
        else:
            item = self.current()
            if not item:
                return
            item_id = _live_item_id(item)
            if not item_id:
                return
            state["channels"].add(item_id)
            state["channel_names"][item_id] = str(item.get("name") or item.get("title") or item_id)
            message = tr("Channel locked.")
        _save_stalker_pin(self.source, state)
        try: self["desc"].setText(message)
        except Exception: pass

    def _requestStalkerPin(self, action):
        if time.time() < getattr(self, "_pinBlockedUntil", 0):
            wait = max(1, int(self._pinBlockedUntil - time.time()))
            self.session.open(MessageBox, "%s %s" % (tr("Try again in"), wait), MessageBox.TYPE_ERROR); return
        self._pinPendingAction = action
        self.session.openWithCallback(self._stalkerPinEntered, VirtualKeyBoard, title=tr("Enter parental PIN"), text="")

    def _stalkerPinEntered(self, value=None):
        if value is None:
            self._pinPendingAction = None
            return
        state = _load_stalker_pin(self.source)
        if str(value).strip() != str(state.get("pin") or "0000"):
            self._pinFailures = getattr(self, "_pinFailures", 0) + 1
            if self._pinFailures >= 3:
                self._pinBlockedUntil = time.time() + 30
                self._pinFailures = 0
            self._pinPendingAction = None
            self.session.open(MessageBox, tr("Incorrect PIN"), MessageBox.TYPE_ERROR); return
        self._pinFailures = 0
        action = self._pinPendingAction
        self._pinPendingAction = None
        if not action:
            return
        kind, payload = action
        if kind == "play":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLivePlayerNow()
        if kind == "category":
            self.stalkerPinUnlockedUntil = time.time() + 300
            return self._openLockedCategoryNow()
        if kind == "unlock":
            is_category = bool(payload)
            state = _load_stalker_pin(self.source)
            if is_category:
                row = self["category"].getCurrent()
                item_id = str(row[1] or "") if row else ""
                state["categories"].discard(item_id)
                state["category_names"].pop(item_id, None)
            else:
                item_id = _live_item_id(self.current())
                state["channels"].discard(item_id)
                state["channel_names"].pop(item_id, None)
            _save_stalker_pin(self.source, state)
            try: self["desc"].setText(tr("Lock removed."))
            except Exception: pass
            return
        if kind == "change_pin":
            self.session.openWithCallback(self._stalkerNewPinEntered, VirtualKeyBoard, title=tr("Enter new 4-digit PIN"), text="")

    def _stalkerNewPinEntered(self, value=None):
        value = str(value or "").strip()
        if not (len(value) == 4 and value.isdigit()):
            self.session.open(MessageBox, tr("PIN must contain exactly 4 digits."), MessageBox.TYPE_ERROR); return
        state = _load_stalker_pin(self.source)
        state["pin"] = value
        _save_stalker_pin(self.source, state)
        self.stalkerPinUnlockedUntil = time.time() + 300
        self.session.open(MessageBox, tr("Parental PIN changed."), MessageBox.TYPE_INFO)

    def _isCurrentStalkerCategoryLocked(self):
        if self.source.get("type") != "stalker":
            return False
        row = self["category"].getCurrent()
        cid = str(row[1] or "") if row else ""
        return bool(cid and cid in _load_stalker_pin(self.source)["categories"])

    def _isCurrentStalkerChannelLocked(self):
        if self.source.get("type") != "stalker":
            return False
        return _live_item_id(self.current()) in _load_stalker_pin(self.source)["channels"]

    def _hideCurrentStalkerCategory(self):
        row = self["category"].getCurrent()
        if not row:
            return
        name, cid = row[0], str(row[1] or "")
        if not cid or cid.startswith("__"):
            self.session.open(MessageBox, tr("This package cannot be hidden."), MessageBox.TYPE_INFO); return
        state = _load_stalker_hidden(self.source)
        state["categories"].add(cid)
        state["category_names"][cid] = str(name or cid)
        _save_stalker_hidden(self.source, state)
        try:
            rows = [x for x in list(self["category"].list or []) if str(x[1]) != cid]
            self["category"].setList(rows)
            self["list"].setList([])
            self.focus = "category"
            self["desc"].setText(tr("Package hidden. Use MENU to restore it."))
        except Exception:
            pass

    def _hideCurrentStalkerChannel(self):
        item = self.current()
        if not item:
            return
        channel_id = _live_item_id(item)
        if not channel_id:
            return
        state = _load_stalker_hidden(self.source)
        state["channels"].add(channel_id)
        state["channel_names"][channel_id] = str(item.get("name") or item.get("title") or channel_id)
        _save_stalker_hidden(self.source, state)
        self.showItems([x for x in self.mediaItemsCurrent if _live_item_id(x) != channel_id])
        try: self["desc"].setText(tr("Channel hidden. Use MENU to restore it."))
        except Exception: pass

    def _showHiddenStalkerPackages(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["category_names"].get(cid, cid), ("category", cid)) for cid in sorted(state["categories"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden packages."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden packages"), list=choices)

    def _showHiddenStalkerChannels(self):
        state = _load_stalker_hidden(self.source)
        choices = [(state["channel_names"].get(chid, chid), ("channel", chid)) for chid in sorted(state["channels"])]
        if not choices:
            self.session.open(MessageBox, tr("No hidden channels."), MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._restoreHiddenStalkerItem, ChoiceBox, title=tr("Show hidden channels"), list=choices)

    def _restoreHiddenStalkerItem(self, selected=None):
        if not selected:
            return
        try:
            kind, item_id = selected[1]
        except Exception:
            return
        state = _load_stalker_hidden(self.source)
        item_id = str(item_id)
        if kind == "category":
            state["categories"].discard(item_id)
            state["category_names"].pop(item_id, None)
            message = tr("Package restored.")
        else:
            state["channels"].discard(item_id)
            state["channel_names"].pop(item_id, None)
            message = tr("Channel restored.")
        _save_stalker_hidden(self.source, state)
        try:
            if kind == "category" and hasattr(self, "loadCategories"):
                self.loadCategories()
            elif kind == "channel" and hasattr(self, "loadSelectedCategory"):
                self.loadSelectedCategory()
        except Exception:
            pass
        try: self["desc"].setText(message)
        except Exception: pass

    def _openStalkerCatchup(self):
        item = self.current()
        if not item or self.source.get("type") != "stalker":
            return
        self._catchupItem = dict(item)
        self._catchupResult = None
        self._catchupRequestId = getattr(self, "_catchupRequestId", 0) + 1
        request_id = self._catchupRequestId
        self._catchupStarted = time.monotonic()
        try: self._catchupTimer.stop()
        except Exception: pass
        try: self["desc"].setText("")
        except Exception: pass
        source = dict(self.source)
        channel_id = _live_item_id(item)
        def worker():
            rows, error = [], ""
            try:
                rows = StalkerClient(source).short_epg(channel_id, limit=20, force=True) or []
            except Exception as exc:
                error = str(exc)
            if request_id == getattr(self, "_catchupRequestId", None):
                self._catchupResult = (rows, error)
        threading.Thread(target=worker, name="TiviMateStalkerCatchup", daemon=True).start()
        self._catchupTimer = eTimer()
        _connect_timer(self._catchupTimer, self._finishStalkerCatchupLoad)
        try: self._catchupTimer.start(150, False)
        except Exception: pass

    def _finishStalkerCatchupLoad(self):
        result = getattr(self, "_catchupResult", None)
        if result is None:
            if time.monotonic() - getattr(self, "_catchupStarted", time.monotonic()) >= 60.0:
                self._catchupRequestId = getattr(self, "_catchupRequestId", 0) + 1
                try: self._catchupTimer.stop()
                except Exception: pass
                try: self["desc"].setText("Catch-up server did not respond. Please retry.")
                except Exception: pass
                return
            try: self._catchupTimer.start(150, False)
            except Exception: pass
            return
        try: self._catchupTimer.stop()
        except Exception: pass
        self._catchupResult = None
        rows, error = result
        now = int(time.time())
        choices = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            archive = row.get("has_archive") or row.get("archive") or row.get("allow_archive") or row.get("tv_archive")
            if begin and begin < now and title and (archive not in (0, "0", False) or end <= now):
                label = "%s  %s" % (time.strftime("%d/%m %H:%M", time.localtime(begin)), title)
                choices.append((label, dict(row)))
        if not choices:
            message = tr("No catch-up programmes are available for this channel.")
            if error:
                message += "\n" + error
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO); return
        self.session.openWithCallback(self._playStalkerCatchup, ChoiceBox, title=tr("Catch-up / Archive"), list=choices)

    def _playStalkerCatchup(self, selected=None):
        if not selected:
            return
        event = selected[1]
        item = getattr(self, "_catchupItem", {}) or {}
        try:
            client = StalkerClient(dict(self.source))
            url = client.create_catchup_link(item, event)
            if not url:
                raise RuntimeError(tr("Portal returned no archive link"))
            service_type = _stalker_service_type(self.source, "live")
            ref = eServiceReference(service_type, 0, url)
            ref.setName(self._decodeEpgText(event.get("title") or event.get("name")) or item.get("name") or "Catch-up")
            self.session.nav.playService(ref)
            self["meta"].setText(tr("Playing catch-up"))
        except Exception as exc:
            self.session.open(MessageBox, "%s: %s" % (tr("Unable to play catch-up"), exc), MessageBox.TYPE_ERROR)

    def openLiveViewMenu(self):
        """Use the approved LIVE APPEARANCE screen, never the stock ChoiceBox.

        The same picker controls Windows/List and theme colors, in one place.
        """
        if self.kind != "live":
            return
        self.openLiveColorMenu()

    def openLiveColorMenu(self):
        if self.kind != "live":
            return
        current = self.channelSettings.get("live_theme", "turquoise")
        # The approved live picker already offers both display modes and colors.
        self.session.openWithCallback(self._liveStyleSelected, LiveStyleCircleScreen,
                                      current=current, mode=str(self.channelSettings.get("live_view_mode") or "list"))

    def _liveStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
            requested_mode = None
            if "|" in str(theme):
                requested_mode, theme = str(theme).split("|", 1)
        except Exception:
            return
        if requested_mode == "windows":
            self.channelSettings["live_theme"] = theme
            self.channelSettings["live_color"] = LIVE_STYLE_PALETTES.get(theme, {}).get("accent", "#008F95")
            _save_channel_settings(self.channelSettings)
            self._setLiveViewMode("windows")
            self._queueWindowsAutoOpen()
            return
        if requested_mode == "list":
            self.channelSettings["live_theme"] = theme
            self.channelSettings["live_color"] = LIVE_STYLE_PALETTES.get(theme, {}).get("accent", "#008F95")
            _save_channel_settings(self.channelSettings)
            self._setLiveViewMode("list")
            # Never open another modal after closing this screen from a callback.
            # The chosen list style is persisted and applied at next Live entry.
            return
        if theme == "windows":
            self._setLiveViewMode("windows")
            self._queueWindowsAutoOpen()
            return
        if theme == "list":
            self._setLiveViewMode("list")
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        self.channelSettings["live_theme"] = theme
        self.channelSettings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(self.channelSettings)
        # Avoid close/open reentrancy from the modal style selector.
        # Theme is saved and takes effect on next Live entry.

    def _setLiveViewMode(self, mode):
        if self.kind != "live":
            return
        mode = "windows" if mode == "windows" else "list"
        if self.channelSettings.get("live_view_mode") != mode:
            self.channelSettings["live_view_mode"] = mode
            _save_channel_settings(self.channelSettings)

    def _stopWindowsAutoTimer(self):
        try:
            if self._windowsAutoTimer:
                self._windowsAutoTimer.stop()
        except Exception:
            pass

    def _stopWindowsReturnTimer(self):
        try:
            self._windowsReturnTimer.stop()
        except Exception:
            pass

    def _resumeLiveListAfterWindows(self):
        """Restore the existing Live list after Windows/PiG has been destroyed.

        Avoid reloading the bouquet or opening any modal from a callback. The
        current package and selected channel have already been synchronized.
        """
        if self.kind != "live" or self._windowsVisible or self.channelSettings.get("live_view_mode") != "list":
            return
        try:
            self.show()
        except Exception:
            pass
        selected = getattr(self, "_windowsReturnSelection", None)
        self._windowsReturnSelection = None
        if selected is not None:
            index, packages_open = selected
            self.focus = "category" if packages_open else "items"
            if not packages_open and self.mediaItemsCurrent:
                try:
                    index = max(0, min(int(index), len(self.mediaItemsCurrent) - 1))
                    source_type = str(self.source.get("type") or "").lower()
                    if source_type == "xtream":
                        batch = max(1, int(getattr(self, "xtreamLiveBatchSize", 15) or 15))
                        if index >= int(getattr(self, "xtreamLiveLoadedCount", 0) or 0):
                            self.xtreamLiveLoadedCount = min(len(self.mediaItemsCurrent),
                                                             ((index // batch) + 1) * batch)
                            self._renderXtreamLiveBatch(index, ensure_next=False)
                        else:
                            self["list"].moveToIndex(index)
                    elif source_type == "m3u":
                        if index >= int(getattr(self, "m3uLiveLoadedCount", 0) or 0):
                            self.m3uLiveLoadedCount = min(len(self.mediaItemsCurrent),
                                                          ((index // 15) + 1) * 15)
                            self._renderM3uLiveBatch(index, ensure_next=False)
                        else:
                            self["list"].moveToIndex(index)
                    elif source_type == "stalker":
                        batch = 17
                        if index >= int(getattr(self, "stalkerLiveLoadedCount", 0) or 0):
                            self.stalkerLiveLoadedCount = min(len(self.mediaItemsCurrent),
                                                               ((index // batch) + 1) * batch)
                            self._renderStalkerLiveBatch(index, ensure_next=False)
                        else:
                            self["list"].moveToIndex(index)
                    else:
                        self["list"].moveToIndex(index)
                    self._livePreviewOkIdentity = None
                except Exception:
                    pass
        try:
            if self.focus == "items" and not (self.mediaItemsCurrent or []):
                self.focus = "category"
            self._updateLiveScrollbar("category")
            self._updateLiveScrollbar("list")
            self._refreshLiveEpgBadges()
            self._updateLiveKeys()
        except Exception:
            pass
        if self.focus == "items" and self.mediaItemsCurrent:
            # Use the standard Live cached/async path for just one channel.
            # This also returns the standard Infobar preview after releasing PiG.
            try:
                self.previewLive()
            except Exception:
                pass

    def _hasSelectedLiveWindowsChannels(self):
        """True only when the highlighted package owns the loaded channel data."""
        if self.kind != "live" or self.focus != "items":
            return False
        category_id = str(self.selectedCategory() or "")
        loaded_id = str(getattr(self, "_loadedLiveCategoryKey", "") or "")
        return bool(category_id and category_id == loaded_id and self.mediaItemsCurrent)

    def _queueWindowsAutoOpen(self):
        """Open persisted Windows Grid after the current modal closes.

        Avoid losing a one-shot open request if Enigma2 hasn't returned from
        the appearance chooser when the callback's timer fires.
        """
        if (self.kind == "live" and
                self.channelSettings.get("live_view_mode") == "windows" and
                not self._windowsVisible and self._windowsAutoTimer):
            self._windowsAutoRetryCount = 0
            try:
                self._windowsAutoTimer.stop()
                self._windowsAutoTimer.start(120, True)
            except Exception:
                pass

    def _windowsParentCanOpenModal(self):
        """Only the executing Live dialog may open a child (Enigma2 Session.open).

        During an asynchronous close session.current_dialog can be None while
        dialog_stack is still populated. Testing current_dialog alone is not
        enough: Session.open also requires session.in_exec to be true.
        If a firmware cannot expose both values, fail closed instead of
        risking a GUI-wide RuntimeError from the eTimer callback.
        """
        session = getattr(self, "session", None)
        return bool(session is not None and
                    getattr(session, "in_exec", False) and
                    getattr(session, "current_dialog", None) is self)

    def _autoOpenWindowsWhenReady(self):
        if (self.kind != "live" or self._windowsVisible or
                self.channelSettings.get("live_view_mode") != "windows"):
            return
        if not self._windowsParentCanOpenModal():
            # Style chooser or another Live dialog can still be closing.
            # Enigma2 resumes the parent asynchronously; do not open until
            # its modal execution has actually resumed. Keep the existing
            # bounded retry count and timer interval (no new loading loops).
            retry = int(getattr(self, "_windowsAutoRetryCount", 0) or 0)
            if retry < 40:
                self._windowsAutoRetryCount = retry + 1
                try:
                    self._windowsAutoTimer.start(200, True)
                except Exception:
                    pass
            return
        self._windowsAutoRetryCount = 0
        self._openLiveWindows()

    def _openLiveWindows(self):
        if self._windowsVisible or self.kind != "live":
            return
        # Also guard direct calls (e.g. reloadWindows) that bypass the timer.
        if not self._windowsParentCanOpenModal():
            if self.channelSettings.get("live_view_mode") == "windows":
                self._queueWindowsAutoOpen()
            return
        self._stopWindowsAutoTimer()
        self._windowsVisible = True
        try:
            self.session.openWithCallback(self._liveWindowsReturned, LiveWindowsScreen, self)
        except RuntimeError as exc:
            self._windowsVisible = False
            # Protect against modal-transition races without suppressing
            # unrelated programming errors in the new child screen.
            if "Modal open are allowed only" not in str(exc):
                raise
            if self.channelSettings.get("live_view_mode") == "windows":
                self._queueWindowsAutoOpen()
        except Exception:
            self._windowsVisible = False
            raise

    def _liveWindowsReturned(self, action=None):
        """Run requested Live action only after the grid has fully closed.

        OpenATV refuses a new modal dialog opened by a non-active parent.
        session.openWithCallback delivers this action after Live becomes active.
        """
        self._windowsVisible = False
        if not action:
            restore_top_dialog_soon(self.session)
            return
        if action == "closeLive":
            restore_top_dialog_soon(self.session)
            self.close()
            return
        if action == "reloadWindows":
            # The old Grid is already closed; reopen it with the new palette.
            self._openLiveWindows()
            return
        if action == "switchToList":
            # Windows close must finish before resuming the underlying Live
            # screen; synchronous preview refresh can freeze OpenATV here.
            self._setLiveViewMode("list")
            self._stopWindowsAutoTimer()
            try:
                self._windowsReturnTimer.stop()
                self._windowsReturnTimer.start(100, True)
            except Exception:
                self._resumeLiveListAfterWindows()
            return
        if isinstance(action, str) and action.startswith("liveTool:"):
            option = action.split(":", 1)[1]
            if option in ("hide_category", "change_pin", "player_engines"):
                self._liveToolSelected(("", option))
            return
        if action == "pin":
            self._requestStalkerPin(("play", None))
            return
        # Intentionally restricted to existing Live actions.
        allowed = (
            "openLiveColorMenu", "toggleCurrentFavourite",
            "openLiveFilter", "openLiveServerMenu", "openLiveTools",
            "openLiveMainMenu", "openBeinSports", "openFavorites", "ok",
            "reloadWindows",
        )
        if action in allowed:
            handler = getattr(self, action, None)
            if callable(handler):
                handler()

    def openFavorites(self):
        self.session.open(FavoritesScreen)

    def _moveCategory(self, direction):
        """Move through VOD/series categories without reopening or redesigning the screen."""
        if self.kind == "live":
            return
        try:
            rows = list(self["category"].list or [])
        except Exception:
            rows = []
        if not rows:
            try:
                self["meta"].setText("")
            except Exception:
                pass
            return
        try:
            current = int(self["category"].getSelectedIndex())
        except Exception:
            current = 0
        target = (current + int(direction)) % len(rows)
        try:
            self["category"].moveToIndex(target)
        except Exception:
            return
        try:
            selected = rows[target]
            self.initialCategoryName = selected[0] or ""
            self.initialCategoryId = str(selected[1] or "")
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def previousCategory(self):
        self._moveCategory(-1)

    def nextCategory(self):
        self._moveCategory(1)

    def toggleCurrentFavourite(self):
        # Prevent concurrent channel edits while an entire Live package is being
        # saved/removed in the worker. Otherwise favourites files could race.
        if getattr(self, "_liveFavPackageBusy", False):
            return
        # Red on LIVE category: all remote I/O and package expansion runs off-GUI.
        # No existing favourites file is touched until the selected channel list
        # has been loaded successfully, preventing empty-server removal.
        if self.kind == "live" and getattr(self, "focus", "") == "category":
            if getattr(self, "_liveFavPackageBusy", False):
                return
            cat_id = str(self.selectedCategory() or "")
            if not cat_id or cat_id.startswith("__"):
                self["meta"].setText(tr("Select a Live package first")); return
            source=dict(self.source or {})
            try:
                cat_row=self["category"].getCurrent()
                package_title=str((cat_row[0] if cat_row else "") or self.initialCategoryName or "Live package")
            except Exception:
                package_title=str(self.initialCategoryName or "Live package")
            self._liveFavPackageBusy=True
            self._liveFavPackageResult=None
            self._liveFavPackageToken = getattr(self, "_liveFavPackageToken", 0) + 1
            package_token = self._liveFavPackageToken
            self._liveFavPackageStarted = time.monotonic()
            self._liveFavPackageMutationStarted = False
            self["meta"].setText(tr("Loading package channels..."))
            def finish():
                result=getattr(self,"_liveFavPackageResult",None)
                if result is None:
                    elapsed = time.monotonic() - getattr(self, "_liveFavPackageStarted", time.monotonic())
                    if elapsed >= 60.0 and not getattr(self, "_liveFavPackageMutationStarted", False):
                        # A late server result must not mutate favorites after timeout.
                        self._liveFavPackageToken += 1
                        self._liveFavPackageBusy = False
                        try: self._liveFavPackageTimer.stop()
                        except Exception: pass
                        try: self["meta"].setText("Package server did not respond. Retry.")
                        except Exception: pass
                        return
                    if elapsed >= 60.0:
                        try: self["meta"].setText("Saving Favorites. Please do not press RED again.")
                        except Exception: pass
                    try:self._liveFavPackageTimer.start(1200 if elapsed >= 60.0 else 120,True)
                    except Exception:pass
                    return
                self._liveFavPackageBusy=False
                self._liveFavPackageResult=None
                try:self._liveFavPackageTimer.stop()
                except Exception:pass
                try:self["meta"].setText(result)
                except Exception:pass
            try:
                self._liveFavPackageTimer=eTimer()
                _connect_timer(self._liveFavPackageTimer,finish)
                self._liveFavPackageTimer.start(120,True)
            except Exception:
                self._liveFavPackageBusy=False
                self["meta"].setText("Unable to schedule favorites task")
                return
            def worker():
                message=""
                try:
                    client=get_source_client(source)
                    rows,_origin=get_category_streams(source,"live",client,cat_id,use_cache=True,wait_for_server=True)
                    rows=list(rows or [])
                    if not rows:
                        rows=[x for x in list(get_filtered_streams(source,"live",client) or []) if str((x or {}).get("category_id") or "")==cat_id]
                    rows=[x for x in rows if isinstance(x,dict) and (x.get("stream_id") or x.get("id") or x.get("url") or x.get("cmd"))]
                    if package_token != getattr(self, "_liveFavPackageToken", None):
                        return
                    self._liveFavPackageMutationStarted = True
                    if not rows:
                        message=tr("No channels found in this package")
                    else:
                        marker_file=favorites_path("live_package_favorites.json")
                        marker_key="%s|%s"%(favourite_source_id(source),cat_id)
                        try:
                            with open(marker_file,"r") as h:markers=json.load(h) or {}
                        except Exception: markers={}
                        active=marker_key in markers
                        changed=0
                        if active:
                            marker=markers.get(marker_key)
                            owned=marker.get("owned",[]) if isinstance(marker,dict) else (marker or [])
                            owned=set(str(x) for x in owned)
                            for x in rows:
                                xid=str(x.get("stream_id") or x.get("id") or x.get("url") or x.get("cmd") or "")
                                if xid in owned and is_favourite(source,"live",x):
                                    toggle_favourite(source,"live",x);changed+=1
                            markers.pop(marker_key,None)
                            message=tr("Removed package from Favorites")
                        else:
                            owned_records,saved=add_favourites(source,"live",rows)
                            if not saved:
                                message=tr("Unable to save favorite package")
                            else:
                                owned_streams=[]
                                for x in rows:
                                    if is_favourite(source,"live",x):
                                        xid=str(x.get("stream_id") or x.get("id") or x.get("url") or x.get("cmd") or "")
                                        if xid:owned_streams.append(xid)
                                markers[marker_key]={"source_id":favourite_source_id(source),"category_id":cat_id,"title":package_title,"owned":owned_streams}
                                changed=len(owned_records)
                                message=tr("Added package to Favorites")
                        if message!=tr("Unable to save favorite package"):
                            try:
                                folder=os.path.dirname(marker_file)
                                if folder and not os.path.isdir(folder):os.makedirs(folder)
                                tmp=marker_file+".tmp"
                                with open(tmp,"w") as h:json.dump(markers,h,sort_keys=True)
                                os.rename(tmp,marker_file)
                            except Exception:pass
                            message += "  (%d)"%changed
                except Exception as exc:
                    message="Favorites package error: %s"%exc
                if package_token == getattr(self, "_liveFavPackageToken", None):
                    self._liveFavPackageResult=message
            t=threading.Thread(target=worker,name="TiviMateLiveFavoritesBackground")
            t.daemon=True;t.start()
            return
        # RED on a highlighted Live channel toggles that single channel.
        item = None
        try:
            current_row = self["list"].getCurrent()
            item = current_row[1] if current_row else None
        except Exception:
            item = self.current()
        if not isinstance(item, dict):
            try:
                self["meta"].setText(tr("Open a package, select a channel, then press RED"))
            except Exception:
                pass
            return
        title = item.get("name") or item.get("title") or "Channel"
        try:
            fav_source = item.get("_favorite_source") if isinstance(item.get("_favorite_source"), dict) else self.source
            added, saved = toggle_favourite(fav_source, "live", item)
            if not saved:
                message = "Unable to update favorites"
            elif added:
                message = "★ Added %s to FAVORITES" % title
            else:
                message = "☆ Removed %s from FAVORITES" % title
                # When the user removes a row while viewing FAVORITES, refresh the
                # local list immediately. The provider package remains untouched.
                try:
                    if self.selectedCategory() == "__favorites__":
                        self.loadSelectedCategory()
                except Exception:
                    pass
            self["meta"].setText(message)
        except Exception as exc:
            try:
                self["meta"].setText("Favorites error: %s" % exc)
            except Exception:
                pass

    def yellowAction(self):
        # In Genre result pages, short YELLOW adds the complete Genre result set
        # (all pages) to Favorites. Everywhere else it keeps the original Sort.
        if self.kind in ("vod", "series") and self._movieGenreAllItems:
            rows = [x for x in self._movieGenreAllItems if isinstance(x, dict)]
            if not rows:
                try: self["meta"].setText(tr("No Genre items to add"))
                except Exception: pass
                return
            added, saved = add_favourites(self.source, self.kind, rows)
            try:
                if saved:
                    self["meta"].setText("Added Genre to Favorites  (%d new / %d total)" % (len(added), len(rows)))
                else:
                    self["meta"].setText(tr("Unable to save favorites"))
            except Exception:
                pass
            return
        return self.toggleSort()

    def addCurrentFavourite(self):
        # Long YELLOW on Movies/TV Shows saves the ACTIVE PACKAGE as one
        # Favorite folder.  It never expands the package into hundreds of titles.
        if self.kind not in ("vod", "series"):
            return
        cid = str(self.selectedCategory() or self.initialCategoryId or "").strip()
        title = str(getattr(self, "activeCategoryName", "") or self.initialCategoryName or "").strip()
        # Synthetic pages (recent/genre/search) are not server package folders.
        if not cid or cid.startswith("__") or not title:
            try: self["meta"].setText(tr("Open a Movies or TV Shows package first"))
            except Exception: pass
            return
        marker_file = favorites_path("media_package_favorites.json")
        marker_key = "%s|%s|%s" % (favourite_source_id(self.source), self.kind, cid)
        try:
            try:
                with open(marker_file, "r") as h: markers = json.load(h) or {}
            except Exception:
                markers = {}
            if marker_key in markers:
                self["meta"].setText(tr("Package is already in Favorites")); return
            # Reuse the package artwork rule: first usable backdrop from its content.
            backdrop = ""
            for row in list(getattr(self, "mediaItems", []) or []) + list(getattr(self, "_largePageAllItems", []) or []):
                if not isinstance(row, dict): continue
                backdrop = row.get("backdrop_path") or row.get("backdrop") or row.get("backdrop_url") or row.get("fanart") or row.get("background") or ""
                if isinstance(backdrop, list): backdrop = backdrop[0] if backdrop else ""
                if backdrop: break
            if isinstance(backdrop, str):
                backdrop = backdrop.strip().replace(chr(92)+"/", "/")
                if backdrop.startswith("/") and not backdrop.startswith("//"):
                    backdrop = backdrop_url(backdrop)
            markers[marker_key] = {"source_id": favourite_source_id(self.source), "kind": self.kind, "category_id": cid, "title": title, "backdrop": str(backdrop or "")}
            folder = os.path.dirname(marker_file)
            if folder and not os.path.isdir(folder): os.makedirs(folder)
            tmp = marker_file + ".tmp"
            with open(tmp, "w") as h: json.dump(markers, h, sort_keys=True)
            os.rename(tmp, marker_file)
            self["meta"].setText(tr("Added package folder to Favorites"))
        except Exception as exc:
            try: self["meta"].setText("Favorite package error: %s" % exc)
            except Exception: pass


    def _updateTopFocus(self):
        if self.kind == "live":
            return
        try:
            index = max(0, min(self.topIndex, len(self.topX) - 1))
            cell_w = self.topW[index]
            x = self.topX[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
            self["topSelector"].setVisible(self.focus == "top")
        except Exception:
            pass


    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def _openTopItem(self):
        if self.kind == "live":
            return
        if self.topIndex == 0:
            self._openPageOnce(TiviMateE2Home); return
        if self.topIndex == 1:
            self._openPageOnce(TiviMateE2Search, self.source); return
        if self.topIndex == 2:
            self._openPageOnce(MediaScreen, self.source, "live"); return
        if self.topIndex == 3:
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, "vod"), self.source, "vod"); return
        if self.topIndex == 4:
            self._openPageOnce(configured_movies_screen(FastMoviesContentScreen, "series"), self.source, "series"); return
        if self.topIndex == 5:
            self._openPageOnce(ContentPackagesScreen, self.source); return
        if self.topIndex == 6:
            choices = [(tr("Movies"), "vod"), (tr("TV Shows"), "series")]
            self.session.openWithCallback(self._mediaGenreSelected, ChoiceBox, title=tr("GENRE"), list=choices); return
        if self.topIndex == 7:
            self._openPageOnce(ContinueWatchingScreen, self.source); return
        if self.topIndex == 8:
            self._openPageOnce(TiviMateE2IPTVFinder); return
        if self.topIndex == 9:
            self._openPageOnce(SettingsDashboard); return
        if self.topIndex == 10:
            self._openPageOnce(FavoritesScreen); return

    def _mediaGenreSelected(self, selected=None):
        if not selected or not self.source:
            return
        kind = selected[1] if isinstance(selected, (tuple, list)) and len(selected) > 1 else selected
        if kind in ("vod", "series"):
            self._openPageOnce(MovieGenresScreen, dict(self.source), kind)

    def openCategoryMenu(self):
        if self.kind == "live":
            return
        try:
            self.session.openWithCallback(
                self._categoryMenuSelected, HomePackageBrowserScreen,
                self.source, self.kind
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open packages:\n%s" % exc, MessageBox.TYPE_ERROR)






    def _categoryMenuSelected(self, selected=None):
        if not selected:
            return
        cid = str(selected.get("id") or "")
        name = selected.get("name") or ""
        self.initialCategoryId = cid
        self.initialCategoryName = name
        self.activeCategoryName = name
        self.activePackageProvider = self._providerFromPackageName(name)
        self._updateServerPackageGridLogo()
        try:
            for pos, row in enumerate(self["category"].list):
                if str(row[1]) == cid:
                    self["category"].moveToIndex(pos)
                    break
        except Exception:
            pass
        self.focus = "items"
        self.loadSelectedCategory()

    def _updateLiveScrollbar(self, list_name):
        """Match the Live theme without relying on image-specific Enigma scrollbars.

        This runs only for GUI selection/list updates, never in an EPG worker.
        """
        if self.kind != "live" or list_name not in ("category", "list"):
            return
        thumb_name = ("liveCategoryScrollThumb" if list_name == "category"
                      else "liveChannelScrollThumb")
        try:
            menu = self[list_name]
            thumb = self[thumb_name]
            total = len(getattr(menu, "list", []) or [])
            visible = 15
            if total <= visible:
                thumb.hide()
                return
            index = max(0, min(total - 1, int(menu.getSelectedIndex() or 0)))
            track_y, track_h = 176, 760
            thumb_h = max(40, min(225, int(float(track_h) * visible / total)))
            y = track_y + int(round(float(track_h - thumb_h) * index / (total - 1)))
            x = 360 if list_name == "category" else 979
            if thumb.instance is not None:
                thumb.instance.resize(eSize(sx(9), sy(thumb_h)))
                thumb.instance.move(ePoint(sx(x), sy(y)))
                thumb.show()
        except Exception:
            # List scrolling must never fail because of a decorative scrollbar.
            pass

    def _liveRowHasEpg(self, item):
        """True only when actual programmes are already cached for this row.

        Stream metadata such as an epg_id is NOT proof that programmes exist.
        This check does no disk IO, XMLTV parsing, or provider/network work.
        """
        if not isinstance(item, dict) or item.get("_stalker_placeholder"):
            return False
        if str(item.get("name") or item.get("title") or "").lstrip().startswith("####"):
            return False
        row_source = item.get("_favorite_source") or self.source or {}
        kind = str(row_source.get("type") or "").lower()
        try:
            shared = _shared_live_epg_cached(row_source, item)
            if shared and any((r.get("title") or r.get("name") or r.get("programme")) for r in shared):
                return True
            if item.get("_favorite_source"):
                return False
            if kind == "stalker":
                channel_id = self._stalkerEpgChannelId(item)
                rows = self.stalkerShortEpgResults.get(channel_id) or []
            elif kind == "xtream":
                channel_id = self._xtreamEpgChannelId(item)
                rows = self._xtreamCachedShortEpg(item, max_age=900)
                if not rows and channel_id and time.time() < float(self.liveLocalEpgBadgeUntil.get(channel_id, 0) or 0):
                    return True
            else:
                return False
            if rows and any(isinstance(row, dict) and
                            (row.get("name") or row.get("title") or row.get("programme"))
                            for row in rows):
                return True
            return _live_epg_mark_present(self.source, channel_id)
        except Exception:
            return False

    def _refreshLiveEpgBadges(self):
        """Keep the 15 cyan EPG markers aligned while the list scrolls.

        The E2 listbox exposes its real top index; never infer an incorrect row
        from the highlighted index when a bouquet scrolls or is paged.
        """
        if self.kind != "live":
            return
        try:
            listbox = self["list"]
            if listbox.instance is None or self.focus != "items":
                raise ValueError("no visible channel list")
            rows = listbox.list or []
            try:
                top = int(listbox.instance.getTopIndex())
                if top < 0:
                    raise ValueError("invalid list top index")
            except (AttributeError, TypeError, ValueError):
                # Older OE-A/Pure2 lists may lack getTopIndex(). A missing
                # native accessor must not suppress all 15 EPG badges.
                selected = max(0, int(listbox.getSelectedIndex() or 0))
                top = max(0, min(selected, len(rows) - 15))
        except Exception:
            rows = []
            top = 0
        # When the channel list advances beyond the first visible batch,
        # reuse RAM/disk hits and warm that batch too. The worker remains
        # bounded and all networking stays off Enigma's GUI thread.
        if (rows and self.focus == "items" and
                not getattr(self, "_windowsVisible", False) and
                str((self.source or {}).get("type") or "").lower() == "xtream"):
            try:
                # Prefetch the next batch as soon as its first channel is
                # selected, instead of waiting until the old 15 rows have
                # completely scrolled out of view.
                selected_index = max(0, int(self["list"].getSelectedIndex() or 0))
                first_visible = (selected_index // 15) * 15
                key = (_source_identity(self.source), str(self.selectedCategory() or ""),
                       first_visible, len(self.mediaItemsCurrent or []))
                if key != getattr(self, "_liveBadgeWarmPageKey", None):
                    self._warmLiveBadgeCache()
            except Exception:
                pass
        for offset in range(15):
            try:
                row = rows[top + offset]
                item = row[1] if isinstance(row, (tuple, list)) and len(row) > 1 else None
                visible = bool(self._liveRowHasEpg(item))
            except Exception:
                visible = False
            if visible == self.liveEpgBadgeShown[offset]:
                continue
            self.liveEpgBadgeShown[offset] = visible
            try:
                widget = self["liveEpgBadge%d" % offset]
                if visible:
                    widget.show()
                else:
                    widget.hide()
            except Exception:
                pass

    def _warmLiveBadgeCache(self, visible_rows=None, visible_index=None, page_start=None):
        """Render proven Xtream EPG marks from disk, then warm the visible rows.

        Disk and provider IO happen only in a worker, never on remote keypress.
        The selected channel retains its existing higher-priority EPG request.
        Parallel requests are capped at six like Ultra. The selected channel
        retains its existing higher-priority EPG request and empty answers get
        no badge.
        """
        if self.kind != "live" or str((self.source or {}).get("type") or "").lower() != "xtream":
            return
        try:
            from .cache_manager import persistent_cache_get as _cache_get
            from concurrent.futures import FIRST_COMPLETED, wait
            src = dict(_bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source)
            rows = list(self.mediaItemsCurrent or [])
            if visible_rows is None:
                try:
                    idx = int(self["list"].getSelectedIndex() or 0)
                except Exception:
                    idx = 0
                # Standard Live retains its original 15-row lazy batch.
                start = (max(0, idx) // 15) * 15
                window_batch = False
                targets = [dict(row) for row in rows[start:start + 15] if isinstance(row, dict)]
            else:
                # Windows has ten cards. Follow its *actual visible page*,
                # rather than the hidden standard-list cursor or all channels
                # in a bouquet. Reuse the existing standard Live EPG warmer.
                window_batch = True
                start = max(0, int(page_start or 0))
                idx = start + max(0, int(visible_index or 0))
                targets = [dict(row) for row in list(visible_rows)[:10]
                           if isinstance(row, dict) and not row.get("_stalker_placeholder")]
            warm_key = (_source_identity(self.source), str(self.selectedCategory() or ""),
                        "windows" if window_batch else "list", start, len(rows))
            if warm_key == getattr(self, "_liveBadgeWarmPageKey", None):
                return
            self._liveBadgeWarmPageKey = warm_key
            self.liveBadgeCacheGeneration += 1
            with self.liveBadgeCacheLock:
                self.liveBadgeCacheResults[:] = []
            self.liveBadgeCachePolls = 0
            generation = self.liveBadgeCacheGeneration
            scope_source = dict(self.source)
            scope = _source_identity(scope_source)
            if not targets:
                return

            def worker():
                try:
                    client = XtreamClient(src)
                    found = []
                    for row in targets:
                        ch_id = self._xtreamEpgChannelId(row)
                        epg_id = str(row.get("epg_channel_id") or row.get("tvg_id") or row.get("epg_id") or "").strip()
                        if not ch_id or _live_epg_mark_present(scope_source, ch_id):
                            continue
                        cached = _cache_get(client._epg_cache_key(ch_id, epg_id, 10), None)
                        if isinstance(cached, list) and _live_epg_mark_known(scope_source, ch_id, cached):
                            found.append((ch_id, cached))
                    with self.liveBadgeCacheLock:
                        self.liveBadgeCacheResults.append((generation, scope, found, False))

                    # Let the package's first visible rows and picons paint
                    # before submitting optional EPG reads for missing visible
                    # channels, with at most two in flight at any time.
                    # Positive disk hits above were already published promptly.
                    time.sleep(0.65)
                    if generation != self.liveBadgeCacheGeneration:
                        return
                    # Warm all remaining visible rows, not just five. The
                    # selected channel keeps its own priority EPG lookup.
                    # Missing or failed EPG never gets a fabricated badge.
                    close = [(pos, row) for pos, row in enumerate(targets)
                             if pos != idx - start]
                    close.sort(key=lambda pair: abs(pair[0] - (idx - start)))
                    pending = []
                    for _pos, row in close:
                        ch_id = self._xtreamEpgChannelId(row)
                        if (not ch_id or _live_epg_mark_present(scope_source, ch_id)
                                or time.time() < float(getattr(self, "xtreamEpgMissUntil", {}).get(ch_id, 0) or 0)):
                            continue
                        pending.append(row)
                        if len(pending) >= 14:
                            break
                    if pending:
                        def read_one(row):
                            if generation != self.liveBadgeCacheGeneration:
                                return "", []
                            ch_id = self._xtreamEpgChannelId(row)
                            epg_id = str(row.get("epg_channel_id") or row.get("tvg_id") or row.get("epg_id") or "").strip()
                            try:
                                result = client.short_epg(ch_id, limit=10, epg_channel_id=epg_id,
                                                          single_request=True) or []
                                return ch_id, result
                            except Exception:
                                return ch_id, []
                        # Standard Live retains its existing six-lane warmer.
                        # For Windows, use the same two-lane bounded Xtream
                        # request policy already implemented in core.py's
                        # short_epg_batch. Ten grid cards need at most nine
                        # background misses; playback/selected EPG stays ahead.
                        lanes = 2 if window_batch else 6
                        # Ultra's bounded shared workers avoid creating fresh
                        # HTTP threads for each bouquet.  Enqueue only the
                        # current window's limited lanes at a time: stale jobs
                        # never fill the shared queue while the viewer navigates.
                        pending_iter = iter(pending)
                        futures = set()
                        def submit_next():
                            if generation != self.liveBadgeCacheGeneration:
                                return False
                            try:
                                next_row = next(pending_iter)
                            except StopIteration:
                                return False
                            futures.add(_ULTRA_VISIBLE_XTREAM_EPG_POOL.submit(read_one, next_row))
                            return True
                        try:
                            for _ in range(min(lanes, len(pending))):
                                submit_next()
                            while futures and generation == self.liveBadgeCacheGeneration:
                                done, futures = wait(futures, timeout=0.15, return_when=FIRST_COMPLETED)
                                for future in done:
                                    if generation != self.liveBadgeCacheGeneration:
                                        break
                                    try:
                                        ch_id, result = future.result()
                                    except Exception:
                                        ch_id, result = "", []
                                    if ch_id and _live_epg_mark_known(scope_source, ch_id, result):
                                        with self.liveBadgeCacheLock:
                                            self.liveBadgeCacheResults.append((generation, scope,
                                                                              [(ch_id, result)], False))
                                    submit_next()
                        finally:
                            # Workers already in flight finish normally; any
                            # *queued* jobs from the old page are withdrawn.
                            for future in futures:
                                if not future.done():
                                    future.cancel()
                except Exception:
                    pass
                finally:
                    with self.liveBadgeCacheLock:
                        self.liveBadgeCacheResults.append((generation, scope, [], True))

            self.liveBadgeCacheRunning = True
            threading.Thread(target=worker, name="TiviMateLiveBadgeWarm", daemon=True).start()
            self.liveBadgeCacheTimer.start(90, True)
        except Exception:
            self.liveBadgeCacheRunning = False

    def _applyLiveBadgeCache(self):
        try:
            with self.liveBadgeCacheLock:
                ready = list(self.liveBadgeCacheResults)
                self.liveBadgeCacheResults[:] = []
            finished = False
            updated = False
            for generation, scope, found, done in ready:
                if generation != self.liveBadgeCacheGeneration or scope != _source_identity(self.source):
                    continue
                finished = finished or done
                for ch_id, rows in found:
                    self._storeXtreamShortEpg({"stream_id": ch_id}, rows)
                    updated = True
            if finished:
                self.liveBadgeCacheRunning = False
            if updated:
                if not getattr(self, "_windowsVisible", False):
                    self._refreshLiveEpgBadges()
                # Windows reads the exact same positive RAM EPG data as the
                # ordinary list. Repaint ten cards without querying a server
                # or interrupting the active PiG/decoder preview.
                window = getattr(self, "_windowsScreen", None)
                if window is not None and not getattr(window, "_closed", True):
                    try:
                        window._windowsApplyUltraEpg()
                        window._refreshWindowsBadges()
                    except Exception:
                        pass
            # At most two remote requests run concurrently. Allow enough
            # polling time for the full visible batch on slower portals.
            if not finished and self.liveBadgeCachePolls < 180:
                self.liveBadgeCachePolls += 1
                self.liveBadgeCacheTimer.start(220, True)
        except Exception:
            pass

    def _refreshLiveScrollbars(self):
        if self.kind == "live":
            self._updateLiveScrollbar("category")
            self._updateLiveScrollbar("list")

    def _prepareScreen(self):
        try:
            idx = {"live": 0, "vod": 1, "series": 2}.get(self.kind, 0)
            self["rail"].moveToIndex(idx)
        except Exception:
            pass
        self.updateSectionLabels()
        if self.kind != "live":
            self._updateTopFocus()
        # Actor results: reuse this exact package poster view, but do not reload
        # categories or scan the provider. The rows were already matched against
        # the package that owns the movie details screen.
        if self.kind in ("vod", "series") and self.preloadedItems:
            self.activeCategoryName = self.initialCategoryName or self.activeCategoryName
            try:
                # Genre result pages must show PAGE 1/X immediately on first render,
                # not only after the user moves to the next page.
                if self._movieGenreAllItems:
                    size = max(1, int(self._movieGenrePageSize or 30))
                    pages = max(1, (len(self._movieGenreAllItems) + size - 1) // size)
                    page = max(0, min(int(self._movieGenrePage or 0), pages - 1))
                    label = self._movieGenreLabel or self.activeCategoryName
                    self["currentCategory"].setText(("%s  •  Page %d / %d" % (label, page + 1, pages)) if pages > 1 else label)
                else:
                    self["currentCategory"].setText(self.activeCategoryName)
            except Exception:
                pass
            self.focus = "items"
            self.lastCategoryItems = list(self.preloadedItems)
            # Package views can arrive with all items preloaded. Sort the FULL
            # package before slicing page 1 / page 2, never each page alone.
            if self._packageLatestOnOpen:
                self.lastCategoryItems = self._sortPackageNewest(self.lastCategoryItems)
            # Package cards coming from GENRE's package chooser carry all items
            # preloaded. Do not turn these into numbered 30-title pages. Actor
            # results and independent GENRE-result screens retain their paging.
            if self._isContinuousPackage():
                self._showContinuousPackage(self.lastCategoryItems)
            elif not self._movieGenreAllItems and len(self.lastCategoryItems) > self._largePageSize:
                self._largePageAllItems = _dedupe_content_rows(self.lastCategoryItems, self.kind)
                self._largePage = 0
                self._loadLargePackagePage(0, force=True)
            else:
                self.showItems(self.lastCategoryItems)
            return
        if self.kind in ("vod","series") and self.initialCategoryId in ("__server_netflix__","__server_prime__"):
            provider="netflix" if self.initialCategoryId=="__server_netflix__" else "prime"
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self.activePackageProvider=provider
            self._updateServerPackageGridLogo()
            self._loadMergedServerProvider(provider)
            return
        if self.kind == "live":
            self._updateLiveClock()
            try: self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
            except Exception: pass
            self._startStalkerWatchdog()
        self.loadCategories()

    def currentRailSection(self):
        current = self["rail"].getCurrent()
        return current[1] if current else self.kind

    def updateSectionLabels(self):
        label = {"live": "LIVE TV", "vod": "MOVIES", "series": "TV SHOWS"}.get(self.kind, self.kind)
        self["title"].setText("%s  •  %s" % (("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "IPTV")), label))
        if self.kind != "live":
            self["sectionTitle"].setText(tr("MOVIE CATEGORIES") if self.kind == "vod" else tr("TV SHOW CATEGORIES"))
            self["searchIcon"].setText("")

    def switchSection(self, section):
        if section == self.kind:
            # Enter the package column only. Never play a channel from the rail.
            self.focus = "category"
            if section == "live":
                self._livePreviewOkIdentity = None
            return
        if section == "live":
            self._openPageOnce(MediaScreen, self.source, "live")
            return
        # LIVE and VOD/Series use different widget sets/skins.  Do not mutate
        # a LIVE screen into a VOD/Series screen in-place: widgets such as
        # currentCategory/sectionTitle do not exist on the LIVE skin and
        # DreamOS raises KeyError when navigation tries to access them.
        if self.kind == "live":
            # Live has an independent remembered provider.  When leaving Live for
            # Movies/TV Shows, always restore the Home/VOD provider instead of
            # carrying the currently selected Live server into every section.
            fallback = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            target_source = _load_main_source(fallback)
            self._openPageOnce(MediaScreen, target_source, section)
            return
        self.kind = section
        self.focus = "category"
        self.searchQuery = ""
        self.sortMode = _load_media_content_sort(section) if section in ("vod", "series") else "default"
        self._refreshPosterSortFooter()
        self.mediaItems = []
        self.mediaItemsCurrent = []
        self.lastCategoryItems = []
        self.categories = []
        self.pageStart = 0
        self.posterIndex = 0
        try:
            self.infoTimer.stop()
        except Exception:
            pass
        self["category"].setList([])
        self["channelTitle"].setText(tr("Select a category"))
        self["meta"].setText("")
        self["desc"].setText("")
        try:
            self["currentCategory"].setText("")
        except Exception:
            pass
        self.updateSectionLabels()
        self.loadCategories()

    def loadCategories(self):
        """Load provider catalog data outside Enigma2's UI thread.

        Category lists are shared by LIVE, VOD, and Series.  The former direct
        provider calls could block every table while DNS/HTTP/M3U parsing ran.
        r87 shows a lightweight loading message and applies the ready result from
        a timer callback only after the worker has completed.
        """
        # Optional Netflix / Prime packages are true TMDb provider catalogs.
        # They intentionally bypass IPTV-server categories.
        _special_id=str(getattr(self,"initialCategoryId","") or "")
        if _special_id in ("__tmdb_netflix__", "__tmdb_prime__") and self.kind in ("vod","series"):
            self.catalogLoadToken += 1
            token=self.catalogLoadToken
            self._catalogLoadStarted = time.monotonic()
            self._catalogSlowNotice = False
            provider="netflix" if _special_id=="__tmdb_netflix__" else "prime"
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self.activePackageProvider=provider
            self.catalogLoadResult=None
            try:
                self["desc"].setText("")
                self["currentCategory"].setText(self.activeCategoryName)
            except Exception:
                pass
            self._updateServerPackageGridLogo()
            def _tmdb_provider_worker():
                try:
                    client=TMDbClient()
                    if not client.configured():
                        result=(token,"tmdb_provider",[],[],"TMDb is not configured",provider)
                    else:
                        items=client.provider_catalog(self.kind,provider,limit=50) or []
                        for _item in items:
                            if isinstance(_item,dict):
                                _item["_tmdb_provider"]=provider
                                _item["_server_package_provider"]=provider
                                _item["_server_package_name"]=self.activeCategoryName
                        result=(token,"tmdb_provider",[],items,"",provider)
                except Exception as exc:
                    result=(token,"tmdb_provider",[],[],str(exc),provider)
                self.catalogLoadResult=result
            threading.Thread(target=_tmdb_provider_worker,name="TiviMateTMDbProvider",daemon=True).start()
            try:self.catalogLoadTimer.start(120,True)
            except Exception:pass
            return

        self.catalogLoadToken += 1
        token = self.catalogLoadToken
        self.catalogLoadPolls = 0
        self._catalogLoadStarted = time.monotonic()
        self._catalogSlowNotice = False
        source = dict(self.source)
        kind = self.kind
        self.catalogLoadResult = None
        try:
            self["category"].setList([])
            self["list"].setList([])
        except Exception:
            pass
        try:
            self["desc"].setText("")
        except Exception:
            pass

        def worker():
            try:
                source_type = source.get("type")
                if kind == "live" and source.get("_virtual_bein"):
                    cached, fresh, stamp = _load_bein_cache(source)
                    if cached:
                        result = (token, "bein_virtual", [], cached, "", "cache")
                    else:
                        base = _bein_base_source(source)
                        client = get_source_client(base)
                        all_items = client.streams("live", "") or []
                        bein_items = [item for item in all_items if _is_bein_sports_channel(item)]
                        _save_bein_cache(base, bein_items)
                        result = (token, "bein_virtual", [], bein_items, "", "server")
                elif source_type in ("xtream", "stalker"):
                    if kind == "live":
                        # Stalker fast-open: RAM/disk immediately; on a cold cache,
                        # refresh the portal in the background instead of holding the page.
                        # Xtream keeps its existing cold-read behaviour.
                        _wait_live = False if source_type == "stalker" else True
                        categories, origin = get_cached_categories(
                            source, "live", client=None, wait_for_server=_wait_live
                        )
                        result = (token, source_type, categories or [], [], "", origin)
                    else:
                        categories, origin = get_cached_categories(
                            source, kind, get_source_client(source), wait_for_server=True
                        )
                        result = (token, source_type, categories or [], [], "", origin)
                elif source_type == "m3u":
                    _provider=str(source.get("fast_service") or source.get("finder_source") or "").lower()
                    _local_source=str(source.get("path") or source.get("url") or "")
                    _linear_live=(_provider in ("lgchannels","iptvorg") and
                                  str(source.get("m3u_mode") or "").lower()=="file" and
                                  os.path.isfile(_local_source))
                    if _linear_live:
                        # A Finder M3U was generated locally. Re-read it, rather
                        # than trusting an old 0-channel cache saved before it existed.
                        entries=M3UClient(source).entries()
                        for _item in entries:
                            _item["type"]="live"
                        origin="local_m3u"
                    else:
                        entries, origin = get_cached_catalog(source, "live", lambda: M3UClient(source).entries(), wait_for_server=True)
                    wanted = "vod" if kind == "vod" else "series" if kind == "series" else "live"
                    entries = [item for item in (entries or []) if M3UClient._entry_kind(item) == wanted]
                    result = (token, "m3u", [], entries or [], "", origin)
                elif source_type == "fg":
                    result = (token, "error", [], [], "FG Code test support was removed. Use Xtream, Stalker, or M3U.", "")
                else:
                    entries, origin = get_cached_catalog(source, "live", lambda: StalkerClient(source).channels(), wait_for_server=True)
                    result = (token, "stalker", [], entries or [], "", origin)
            except Exception as exc:
                result = (token, "error", [], [], str(exc), "")
            self.catalogLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2Catalog", daemon=True).start()
        try:
            self.catalogLoadTimer.start(120, True)
        except Exception:
            pass

    def _stopCatalogLoadingTimers(self):
        # Stop polling and invalidate worker results after leaving the screen.
        self.catalogLoadToken += 1
        self.categoryLoadToken += 1
        self.catchupPackageToken += 1
        self.catchupPackageActive = False
        self._xtreamCatchupId = getattr(self, "_xtreamCatchupId", 0) + 1
        self._catchupRequestId = getattr(self, "_catchupRequestId", 0) + 1
        self._liveFavPackageToken = getattr(self, "_liveFavPackageToken", 0) + 1
        for timer in (self.catalogLoadTimer, self.catalogRetryTimer, self.categoryLoadTimer,
                      getattr(self, "catchupPackageTimer", None),
                      getattr(self, "_xtreamCatchupTimer", None),
                      getattr(self, "_catchupTimer", None),
                      getattr(self, "_liveFavPackageTimer", None)):
            try:
                timer.stop()
            except Exception:
                pass

    def _retryCatalogFirstOpen(self):
        # Xtream/Stalker can be cold on the very first request after plugin start.
        # Retry once inside the same screen instead of forcing the user to Exit and re-enter.
        try:
            self.loadCategories()
        except Exception:
            pass

    def _finishCatalogLoad(self):
        result = self.catalogLoadResult
        if not result:
            elapsed = time.monotonic() - getattr(self, "_catalogLoadStarted", time.monotonic())
            # Do not change the verified Live/Ultra start guard.
            if self.kind == "live" and elapsed >= 9.0:
                self.catalogLoadToken += 1
                try: self["desc"].setText("Server did not respond. Switch server or retry.")
                except Exception: pass
                return
            if self.kind in ("vod", "series") and elapsed >= 20.0:
                # Stop the visible wait, but accept a useful worker result if
                # it arrives later.  Poll quietly at low frequency; exit after
                # a finite grace period instead of running a loading loop.
                if not getattr(self, "_catalogSlowNotice", False):
                    self._catalogSlowNotice = True
                    try: self["desc"].setText("Server is slow. You can retry this page.")
                    except Exception: pass
                if elapsed >= 60.0:
                    self.catalogLoadToken += 1
                    return
                delay = 1200
            else:
                delay = 200 if self.kind == "live" else 120
            try: self.catalogLoadTimer.start(delay, True)
            except Exception: pass
            return
        self.catalogLoadResult = None
        token, mode, categories, items, error, origin = result
        if token != self.catalogLoadToken:
            return
        if mode == "tmdb_provider":
            provider=str(origin or "").strip().lower()
            self.activePackageProvider=provider
            self.activeCategoryName="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
            self.initialCategoryName=self.activeCategoryName
            self._updateServerPackageGridLogo()
            if error:
                try:
                    self["desc"].setText("TMDb error:\n%s" % error)
                    self["currentCategory"].setText(self.activeCategoryName)
                except Exception:
                    pass
                self.mediaItems=[]
                self.mediaItemsCurrent=[]
                return
            self.categories=[]
            self.lastCategoryItems=list(items or [])
            self.mediaItems=list(items or [])
            try:self["currentCategory"].setText(self.activeCategoryName)
            except Exception:pass
            self.focus="items"
            self.showItems(self.lastCategoryItems)
            return
        if mode == "retry_series":
            try:
                self["desc"].setText("")
                self.catalogLoadTimer.start(500, False)
                self.catalogLoadResult = (token, "restart", [], [], "", "")
            except Exception:
                pass
            return
        if mode == "restart":
            self.loadCategories()
            return
        if mode == "error":
            if self.kind != "live" and self.source.get("type") in ("xtream", "stalker") and self.catalogFirstOpenRetry < 1:
                self.catalogFirstOpenRetry += 1
                try:
                    self["desc"].setText("")
                    self.catalogRetryTimer.start(700, True)
                except Exception:
                    self._retryCatalogFirstOpen()
                return
            try:
                self["desc"].setText(("Unable to load catalog:\\n%s" % error) if self.kind == "live" else ("خطأ في التحميل:\\n%s" % error))
            except Exception:
                pass
            return
        if mode == "bein_virtual":
            self.mediaItems = items or []
            self.mediaItemsCurrent = items or []
            self.categories = [{"category_name": u"⚽  beIN SPORTS", "category_id": "__bein_virtual__"}]
            self["category"].setList([(u"⚽  beIN SPORTS", "__bein_virtual__")])
            self._applyCategoryItems(items or [], "beIN SPORTS", origin or "cache")
            self.focus = "items"
            if not items:
                self["desc"].setText("No beIN SPORTS channels found in the selected server.")
            return
        if mode in ("xtream", "stalker"):
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all movies", "all films", "all vod", "all series", "كل الأفلام", "جميع الأفلام", "كل افلام", "جميع افلام", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            rows = []
            filtered = []
            for entry in categories:
                if not isinstance(entry, dict):
                    continue
                name = (entry.get("category_name") or "Other").strip()
                cid = str(entry.get("category_id", ""))
                if allowed_ids is not None and cid not in allowed_ids:
                    continue
                if self.kind == "live" and not _adult_source_enabled(self.source) and _adult_live_name(name):
                    continue
                if self.kind in ("vod", "series") and name.lower() in blocked:
                    continue
                filtered.append(entry)
                rows.append((name, cid))
            if self.kind == "live":
                if self.source.get("type") in ("stalker", "xtream"):
                    hidden_state = _load_stalker_hidden(self.source) if self.source.get("type") == "stalker" else _load_xtream_hidden(self.source)
                    filtered = [entry for entry in filtered if str(entry.get("category_id", "")) not in hidden_state["categories"]]
                special = [
                    {"category_name": u"★  " + tr("FAVORITES"), "category_id": "__favorites__"},
                    {"category_name": u"＋  " + tr("RECENTLY ADDED"), "category_id": "__recent_added__"},
                ]
                if bool((self.source or {}).get("catchup_enabled", False)):
                    special.append({"category_name": u"↶  " + tr("CATCH-UP / ARCHIVE"), "category_id": "__catchup__"})
                filtered = special + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            elif self.kind in ("vod", "series"):
                recent = {"category_name": tr("RECENTLY ADDED"), "category_id": "__recent_added__"}
                filtered = [recent] + filtered
                rows = [(entry.get("category_name") or "", str(entry.get("category_id") or "")) for entry in filtered]
            # Recent keeps the full filtered package list so RED/BLUE can
            # move to previous/next real packages.
            if self.kind in ("vod", "series") and self.initialCategoryId == "__recent_added__":
                pass
            self.categories = filtered
            if rows:
                self.catalogFirstOpenRetry = 0
            try:
                self["category"].setList(rows)
            except Exception:
                return
            if self.kind == "live" and not categories and mode == "stalker":
                # Special local folders (Favorites/Recent) are always present,
                # so `if not rows` below can never detect a dead Stalker server.
                # Poll a few times only while its first background refresh runs.
                if origin == "loading" and self.catalogFirstOpenRetry < 3:
                    self.catalogFirstOpenRetry += 1
                    try:
                        self["desc"].setText("Connecting to Stalker server...")
                        self.catalogRetryTimer.start(1100, True)
                    except Exception:
                        pass
                    return
                try:
                    self["desc"].setText("Stalker server did not respond. Switch server or retry.")
                except Exception:
                    pass
                return
            if not rows:
                # A cold Stalker Live cache is refreshed by a daemon worker. Keep
                # the GUI responsive and poll briefly for the new disk/RAM cache.
                if mode == "stalker" and self.kind == "live" and origin == "loading" and self.catalogFirstOpenRetry < 5:
                    self.catalogFirstOpenRetry += 1
                    try:
                        self["desc"].setText("")
                        self.catalogRetryTimer.start(900, True)
                    except Exception:
                        self._retryCatalogFirstOpen()
                    return
                if self.catalogFirstOpenRetry < 1:
                    self.catalogFirstOpenRetry += 1
                    try:
                        self["desc"].setText("")
                        self.catalogRetryTimer.start(700, True)
                    except Exception:
                        self._retryCatalogFirstOpen()
                    return
                if self.source.get("type") == "stalker" and origin == "empty":
                    self["desc"].setText(tr("Stalker returned no packages. Check Portal URL and MAG MAC, then retry."))
                else:
                    self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
                return
            had_initial_category = bool(self.initialCategoryId)
            if self.initialCategoryId:
                for pos, row in enumerate(rows):
                    if str(row[1]) == self.initialCategoryId:
                        try:
                            self["category"].moveToIndex(pos)
                        except Exception:
                            pass
                        break
                self.initialCategoryId = ""
            if self.kind == "series" and not had_initial_category:
                self.focus = "category"
                self["channelTitle"].setText(tr("Select a series category"))
                self["desc"].setText(tr("Select the category then press OK. Only this category will be loaded."))
            elif self.kind == "live":
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
                # Do not scan the ENTIRE Live catalogue for beIN when the user
                # is only choosing a normal package. beIN is loaded on demand.
                self._queueWindowsAutoOpen()
            else:
                self.loadSelectedCategory()
                self.focus = "items"
            return
        if mode == "m3u":
            self.mediaItems = items
            # LG Channels: EPG is intentionally disabled for every LG region,
            # including LG ALL and LG US.  Keep the Live catalog lightweight.
            try:
                _fs = str((self.source or {}).get("fast_service") or "").strip().lower()
                if _fs == "lgchannels":
                    self.source.pop("epg_url", None)
                elif _fs:
                    # Never inherit a generic/embedded FAST guide here.
                    self.source.pop("epg_url", None)
            except Exception:
                pass
            groups = sorted(set(entry.get("group", "Other") for entry in self.mediaItems))
            if self.kind == "live":
                hidden_groups = _load_xtream_hidden(self.source)["categories"]
                groups = [group for group in groups if str(group) not in hidden_groups]
            self.categories = [{"category_name": group, "category_id": group} for group in groups]
            rows = [(group, group) for group in groups]
            if self.kind == "live":
                rows = [(u"★  " + tr("FAVORITES"), "__favorites__"), (u"＋  " + tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [
                    {"category_name": name, "category_id": cid} for name, cid in rows
                ]
            elif self.kind in ("vod", "series"):
                rows = [(tr("RECENTLY ADDED"), "__recent_added__")] + rows
                self.categories = [{"category_name": name, "category_id": cid} for name, cid in rows]
            if self.kind in ("vod", "series") and self.initialCategoryId == "__recent_added__":
                pass
            self["category"].setList(rows)
            if self.kind == "live" and rows:
                self.focus = "category"
                self["categoryTitle"].setText(tr("PACKAGES"))
                self["channelTitle"].setText(tr("Select a package"))
                self["desc"].setText(tr("Select a package") + " - OK")
                self._hideRowPicons()
                # Do not scan the ENTIRE Live catalogue for beIN when the user
                # is only choosing a normal package. beIN is loaded on demand.
                self._queueWindowsAutoOpen()
            elif rows:
                self.loadSelectedCategory()
                self.focus = "items"
            else:
                self["desc"].setText("No packages available." if self.kind == "live" else "No categories available.")
                self._warnIfAccountExpired()
            return
        # Stalker has a single, already-built channel group.
        self.mediaItems = items
        self["category"].setList([("All Channels", "")])
        self.showItems(self.mediaItems)

    def _catchupVerifyCacheKey(self):
        try:
            return hashlib.sha1(_source_identity(self.source or {}).encode("utf-8")).hexdigest()
        except Exception:
            return hashlib.sha1(str(_source_identity(self.source or {})).encode("utf-8")).hexdigest()

    def _loadCatchupVerifyCache(self):
        try:
            if not os.path.isfile(CATCHUP_VERIFY_CACHE_FILE):
                return {}
            with open_text(CATCHUP_VERIFY_CACHE_FILE, "r") as handle:
                payload = json.load(handle) or {}
            row = (payload.get("sources") or {}).get(self._catchupVerifyCacheKey(), {})
            saved = int(row.get("saved") or 0)
            if not saved or int(time.time()) - saved > 43200:
                return {}
            channels = row.get("channels") or {}
            return channels if isinstance(channels, dict) else {}
        except Exception:
            return {}

    def _saveCatchupVerifyCache(self, channels):
        try:
            ensure_dir(os.path.dirname(CATCHUP_VERIFY_CACHE_FILE))
            payload = {}
            if os.path.isfile(CATCHUP_VERIFY_CACHE_FILE):
                try:
                    with open_text(CATCHUP_VERIFY_CACHE_FILE, "r") as handle:
                        payload = json.load(handle) or {}
                except Exception:
                    payload = {}
            sources = payload.get("sources")
            if not isinstance(sources, dict):
                sources = {}
            sources[self._catchupVerifyCacheKey()] = {
                "saved": int(time.time()),
                "channels": channels or {}
            }
            payload["sources"] = sources
            with open_text(CATCHUP_VERIFY_CACHE_FILE, "w") as handle:
                json.dump(payload, handle)
        except Exception:
            pass

    def _verifyXtreamCatchupChannel(self, source, item):
        try:
            days = int(float(str(item.get("tv_archive_duration") or "0")))
        except Exception:
            days = 0
        if str(item.get("tv_archive") or "").strip() != "1" or days <= 0:
            return False

        sid = str(item.get("stream_id") or item.get("id") or "")
        epgid = str(item.get("epg_channel_id") or item.get("epg_id") or "")
        try:
            events = XtreamClient(source).catchup_epg(sid, epg_channel_id=epgid) or []
        except Exception:
            return False

        now = int(time.time())
        cutoff = now - days * 86400
        usable = []
        for event in events:
            if not isinstance(event, dict):
                continue
            begin = self._epgTimestamp(event, True)
            end = self._epgTimestamp(event, False)
            if begin and end and end <= now and begin >= cutoff and end > begin:
                usable.append((begin, event))
        usable.sort(key=lambda x: x[0], reverse=True)

        # Use the same dual-endpoint logic already proven by the player.
        base = str(source.get("url") or "").rstrip("/")
        user = str(source.get("username") or "")
        password = str(source.get("password") or "")
        output = str(source.get("output") or source.get("stream_format") or source.get("format") or "ts").strip().lstrip(".") or "ts"
        stream_name = "%s.%s" % (sid, output)

        for begin, event in usable[:3]:
            finish = self._epgTimestamp(event, False)
            duration = max(1, int((finish - begin + 59) / 60))
            raw_start = event.get("start") or event.get("begin") or ""
            start_dt = self._parseXtreamCatchupDate(raw_start)
            if start_dt:
                primary = start_dt.strftime("%Y-%m-%d:%H-%M")
            else:
                primary = time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin))

            starts = []
            for value in (
                primary,
                time.strftime("%Y-%m-%d:%H-%M", time.localtime(begin)),
                time.strftime("%Y-%m-%d:%H-%M", time.gmtime(begin))
            ):
                if value and value not in starts:
                    starts.append(value)

            for start_text in starts:
                urls = [
                    "%s/timeshift/%s/%s/%d/%s/%s" % (base, user, password, duration, start_text, stream_name),
                    ("%s/streaming/timeshift.php?username=%s&password=%s&stream=%s&start=%s&duration=%d" %
                     (base, user, password, sid, start_text.replace(":", "%3A"), duration))
                ]
                for url in urls:
                    try:
                        req = Request(url)
                        try:
                            req.add_header("Range", "bytes=0-1023")
                        except Exception:
                            pass
                        resp = urlopen(req, timeout=4)
                        try:
                            code = int(getattr(resp, "getcode", lambda: 200)() or 200)
                        except Exception:
                            code = 200
                        try:
                            chunk = resp.read(1024)
                        finally:
                            try:
                                resp.close()
                            except Exception:
                                pass
                        if code in (200, 206) and chunk:
                            return True
                    except Exception:
                        pass
        return False

    def _loadCatchupPackage(self):
        """Show only channels whose Catch-up was confirmed playable."""
        if self.kind != "live" or self.source.get("type") not in ("xtream", "stalker"):
            return

        self.catchupPackageActive = True
        self.catchupPackageToken += 1
        token = self.catchupPackageToken
        source = dict(self.source or {})
        source_type = source.get("type")

        self["channelTitle"].setText(tr("Catch-up / Archive"))
        self["desc"].setText(tr("Checking playable catch-up channels..."))
        try:
            self["list"].setList([])
        except Exception:
            pass
        self.catchupPackageResult = None
        self._catchupPackageStarted = time.monotonic()

        def advertises_archive(row):
            row = row or {}
            if source_type == "xtream":
                try:
                    days = int(float(str(row.get("tv_archive_duration") or "0")))
                except Exception:
                    days = 0
                return str(row.get("tv_archive") or "").strip() == "1" and days > 0
            archive = row.get("tv_archive") or row.get("archive") or row.get("has_archive")
            duration = row.get("tv_archive_duration") or row.get("archive_duration") or 0
            if str(archive or "").strip().lower() in ("1", "true", "yes", "on"):
                return True
            try:
                return int(float(str(duration or "0"))) > 0
            except Exception:
                return False

        def worker():
            rows = []
            error = ""
            try:
                client = get_source_client(source)
                all_rows = list(get_filtered_streams(source, "live", client) or [])
                candidates = [dict(x or {}) for x in all_rows if advertises_archive(x)]

                # Open Catch-up immediately from channels that advertise archive support.
                # Actual programme availability/playback is checked only after the user selects a channel.
                rows = candidates
            except Exception as exc:
                error = str(exc)

            self.catchupPackageResult = (token, rows, error)

        t = threading.Thread(target=worker, name="TiviMateCatchupPackage")
        t.daemon = True
        t.start()

        try:
            self.catchupPackageTimer.stop()
        except Exception:
            pass
        try:
            self.catchupPackageTimer.start(120, True)
        except Exception:
            pass


    def _finishCatchupPackageLoad(self):
        result = self.catchupPackageResult
        if result is None:
            if not self.catchupPackageActive:
                return
            if time.monotonic() - getattr(self, "_catchupPackageStarted", time.monotonic()) >= 60.0:
                self.catchupPackageToken += 1  # Cancel any result from this stalled request.
                self.catchupPackageActive = False
                try: self.catchupPackageTimer.stop()
                except Exception: pass
                try: self["desc"].setText("Catch-up channels unavailable. Retry or switch package.")
                except Exception: pass
                return
            try:
                self.catchupPackageTimer.start(120, True)
            except Exception:
                pass
            return

        self.catchupPackageResult = None
        try:
            self.catchupPackageTimer.stop()
        except Exception:
            pass

        try:
            token, items, error = result
        except Exception:
            return

        if token != self.catchupPackageToken or not self.catchupPackageActive:
            return

        self.mediaItems = list(items or [])
        self.mediaItemsCurrent = list(items or [])
        self.showItems(self.mediaItemsCurrent)
        self.focus = "items"
        self["channelTitle"].setText(tr("Catch-up / Archive"))

        if self.mediaItemsCurrent:
            try:
                self["desc"].setText("%d %s" % (
                    len(self.mediaItemsCurrent), tr("catch-up channels")
                ))
            except Exception:
                pass
        else:
            message = tr("No catch-up channels are available on this server.")
            if error:
                message += "\n" + error
            try:
                self["desc"].setText(message)
            except Exception:
                pass


    def selectedCategory(self):
        # LIVE categories are always selected from the left category widget.
        c = self["category"].getCurrent()
        return c[1] if c else ""


    def _stalkerLivePlaceholder(self, index):
        return {
            "name": "",
            "title": "",
            "number": str(index + 1),
            "stream_id": "",
            "id": "",
            "ch_id": "",
            "stream_icon": "",
            "logo": "",
            "cmd": "",
            "category_id": str(self.stalkerLiveCategoryId or ""),
            "_stalker_live": True,
            "_stalker_placeholder": True,
        }

    def _renderStalkerLiveSlots(self, keep_index=None):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        rows = []
        for index, entry in enumerate(self.stalkerLiveSlots or []):
            entry = entry or self._stalkerLivePlaceholder(index)
            if entry.get("_stalker_placeholder"):
                rows.append((" ", entry))
            else:
                # UI numbering must always be continuous and independent of the
                # provider/MAG channel number.  Some Stalker portals start at 2
                # or reuse numbering on each 14-row page.
                number = str(index + 1)
                name = entry.get("name") or entry.get("title") or "CHANNEL"
                rows.append(("%s   %s" % (number, name), entry))
        self.mediaItemsCurrent = list(self.stalkerLiveSlots or [])
        self["list"].setList(rows)
        if keep_index is None:
            keep_index = 0
        try:
            self["list"].moveToIndex(max(0, min(int(keep_index), max(0, len(rows)-1))))
        except Exception:
            pass
        self.focus = "items"
        self._loadedLiveCategoryKey = str(getattr(self, "stalkerLiveCategoryId", "") or "")
        if not getattr(self, "_windowsVisible", False):
            self._refreshLiveEpgBadges()
        self._queueWindowsAutoOpen()
        try:
            self["pageInfo"].setText("%d / %d" % (
                (int(keep_index) + 1) if rows else 0,
                int(self.stalkerLiveTotal or len(rows))
            ))
        except Exception:
            pass

    def _cancelStalkerPageTasks(self):
        """Cancel Ultra task handles, not just stale UI generation numbers.

        Future.cancel removes queued jobs. Running Ultra HTTP requests observe
        TaskHandle.is_set(), so old catalogue work frees its worker lane.
        """
        handles = getattr(self, "stalkerLivePageHandles", {}) or {}
        self.stalkerLivePageHandles = {}
        for handle in list(handles.values()):
            try: handle.cancel()
            except Exception: pass

    def _cancelStalkerCatalogueRequests(self):
        self._cancelStalkerPageTasks()
        event = getattr(self, "stalkerLiveCancelEvent", None)
        if event is not None:
            try: event.set()
            except Exception: pass
        try: self.stalkerLivePageGeneration += 1
        except Exception: pass
        try: self.stalkerLivePageTimer.stop()
        except Exception: pass
        try: self.stalkerLivePendingPages.clear()
        except Exception: pass
        try: self.stalkerLivePageDeadlines.clear()
        except Exception: pass
        self.stalkerLivePageResult = None
        self.stalkerLivePageResults = []

    def _beginStalkerLiveCategory(self, category_id, name):
        # Revisit a recently viewed bouquet directly from RAM, as Ultra does.
        # Cache only real channel rows; placeholders can continue loading later.
        now = time.monotonic()
        source_id = _source_identity(self.source)
        store = getattr(self, '_stalkerBouquetRam', None)
        if not isinstance(store, dict):
            store = {}
            self._stalkerBouquetRam = store
        previous_id = str(getattr(self, 'stalkerLiveCategoryId', '') or '')
        old_rows = list(getattr(self, 'stalkerLiveSlots', []) or [])
        previous_source = getattr(self, '_stalkerLiveSourceIdentity', source_id)
        if (previous_source == source_id and previous_id and old_rows and
                not getattr(self, 'stalkerLiveAdultDirect', False)
                and any(row and not row.get('_stalker_placeholder') for row in old_rows)):
            previous_saved = store.get((source_id, previous_id))
            previous_stamp = previous_saved[0] if previous_saved else now
            store[(source_id, previous_id)] = (
                previous_stamp, list(old_rows),
                set(getattr(self, 'stalkerLiveLoadedPages', set()) or set()),
                int(getattr(self, 'stalkerLiveTotal', 0) or len(old_rows)))
        if len(store) > 12:
            for key, _value in sorted(store.items(), key=lambda pair: pair[1][0])[:4]:
                store.pop(key, None)
        cached = store.get((source_id, str(category_id or '')))
        # Ultra categories: show the last-good snapshot immediately, even
        # when its freshness TTL has elapsed. Refresh an expired page in the
        # existing bounded catalogue worker instead of blanking the UI.
        cached_stale = bool(cached and now - cached[0] > 180)
        self._cancelStalkerPageTasks()
        old_event = getattr(self, "stalkerLiveCancelEvent", None)
        if old_event is not None:
            try: old_event.set()
            except Exception: pass
        self.stalkerLiveCancelEvent = threading.Event()
        self.stalkerLivePageGeneration += 1
        generation = self.stalkerLivePageGeneration
        self.stalkerLiveCategoryId = str(category_id or "")
        self._stalkerLiveSourceIdentity = source_id
        # Some portals expose Adult bouquet names/categories normally but omit or
        # truncate their channels from get_all_channels.  Only when Adult is enabled
        # and the selected bouquet itself is Adult do we bypass local/full-catalogue
        # pages and ask get_ordered_list directly, matching EStalker behaviour.
        self.stalkerLiveAdultDirect = bool(
            _adult_source_enabled(self.source) and _adult_live_name(name)
        )
        self.stalkerLiveTotal = 0
        self.stalkerLiveSlots = []
        self.stalkerLiveLoadedPages = set()
        self.stalkerLivePendingPages = set()
        self.stalkerLivePageDeadlines = {}
        self.stalkerLivePageRetryUntil = {}
        self.stalkerLivePageHandles = {}
        self.stalkerLivePageResult = None
        self.stalkerLivePageResults = []
        self._resetStalkerVisibleEpg()

        try:
            # Ultra paints a cached category directly; clearing the widgets
            # first creates a fake Loading flash and a second expensive paint.
            if not (cached and not self.stalkerLiveAdultDirect):
                self["list"].setList([])
            self["channelTitle"].setText(name or tr("Select a channel"))
            self["desc"].setText("")
        except Exception:
            pass

        # A cache hit must paint immediately and must not connect to the portal.
        # Background page requests are only scheduled for still-missing slots.
        if cached and not self.stalkerLiveAdultDirect:
            _, cached_rows, cached_pages, cached_total = cached
            self.stalkerLiveSlots = list(cached_rows)
            self.stalkerLiveLoadedPages = set(cached_pages)
            self.stalkerLiveTotal = cached_total
            self._renderStalkerLiveSlots(0)
            if cached_stale:
                # Stale-while-revalidate: leave visible channels in place if
                # the portal is slow or offline. Only the first provider page
                # refreshes; Ultra's existing cancellation/bounded pool is used.
                self.stalkerLiveLoadedPages.discard(1)
            if 1 not in self.stalkerLiveLoadedPages:
                self._requestStalkerLivePage(1, generation, force_network=cached_stale)
            return
        # Constructing a Stalker client can do session/DNS work. Even the
        # disk-cache fast path must run in _requestStalkerLivePage's worker,
        # never on the Enigma2 remote-control/UI thread.
        if self.stalkerLiveAdultDirect:
            self._requestStalkerAdultFullCategory(generation)
        else:
            self._requestStalkerLivePage(1, generation)

    def _requestStalkerAdultFullCategory(self, generation):
        """Show the first 20 Adult channels quickly, then append the rest.

        Ministra returns 14 channels per MAG page.  We fetch only pages 1 and 2
        before first paint (enough for 20 rows), render those immediately, then
        continue collecting the remaining pages in a background worker.  The
        final list keeps one continuous 1..N numbering and never blocks opening
        the bouquet while all remaining pages are downloaded.
        """
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        handle = _UltraLiveTaskHandle(generation, "stalker-adult-first")
        self.stalkerLivePageHandles[1] = handle
        cancel_event = handle
        target_first = max(1, int(getattr(self, "stalkerLiveAdultPageSize", 20) or 20))

        def worker():
            first_items = []
            remainder = []
            total = 0
            next_page = 1
            error = ""
            try:
                if cancel_event is not None and cancel_event.is_set():
                    return
                client = get_source_client(source)
                page = 1
                while len(first_items) < target_first:
                    payload = client.live_page(
                        category_id, page, sortby="number", cancel_event=cancel_event,
                        force_network=True
                    ) or {}
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    rows = list(payload.get("items") or [])
                    if not rows:
                        break
                    if not total:
                        try: total = int(payload.get("total_items") or 0)
                        except Exception: total = 0
                    need = max(0, target_first - len(first_items))
                    first_items.extend(rows[:need])
                    if len(rows) > need:
                        remainder.extend(rows[need:])
                    has_more = bool(payload.get("has_more"))
                    page += 1
                    next_page = page
                    if not has_more:
                        break
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            if generation != self.stalkerLivePageGeneration or 1 not in self.stalkerLivePendingPages:
                return
            payload = {
                "items": list(first_items or []),
                "page": 1,
                "total_items": int(total or len(first_items)),
                "has_more": bool((total and len(first_items) < total) or remainder),
                "_adult_initial": True,
                "_adult_remainder": list(remainder or []),
                "_adult_next_page": int(next_page or 1),
            }
            self.stalkerLivePageResults.append((generation, 1, payload, error))
            self.stalkerLivePageResult = True

        self.stalkerLivePendingPages.add(1)
        self.stalkerLivePageDeadlines[1] = time.monotonic() + 12.0
        try:
            handle.future = _ULTRA_STALKER_CATALOG_POOL.submit(
                worker, _task_key=("stalker-adult-first", id(self)),
                _replace_task_key=True)
        except Exception as exc:
            self.stalkerLivePageHandles.pop(1, None)
            self.stalkerLivePendingPages.discard(1)
            self.stalkerLivePageDeadlines.pop(1, None)
            try: self["desc"].setText("Unable to start Stalker catalogue request")
            except Exception: pass
            return
        try:
            self.stalkerLivePageTimer.start(180, True)
        except Exception:
            pass

    def _requestStalkerAdultRemaining(self, generation, start_page, buffered=None, total_hint=0):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        handle = _UltraLiveTaskHandle(generation, "stalker-adult-remaining")
        self.stalkerLivePageHandles[2] = handle
        cancel_event = handle
        buffered = list(buffered or [])

        def worker():
            items = list(buffered)
            error = ""
            total = int(total_hint or 0)
            try:
                client = get_source_client(source)
                page = max(1, int(start_page or 1))
                requested_pages = 0
                while requested_pages < 120:
                    requested_pages += 1
                    if cancel_event is not None and cancel_event.is_set():
                        return
                    payload = client.live_page(
                        category_id, page, sortby="number", cancel_event=cancel_event,
                        force_network=True
                    ) or {}
                    rows = list(payload.get("items") or [])
                    if not rows:
                        break
                    items.extend(rows)
                    if not total:
                        try: total = int(payload.get("total_items") or 0)
                        except Exception: total = 0
                    if not bool(payload.get("has_more")):
                        break
                    page += 1
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            if generation != self.stalkerLivePageGeneration or 2 not in self.stalkerLivePendingPages:
                return
            payload = {
                "items": items,
                "page": 2,
                "total_items": int(total or (len(self.stalkerLiveSlots) + len(items))),
                "has_more": False,
                "_adult_append": True,
            }
            self.stalkerLivePageResults.append((generation, 2, payload, error))
            self.stalkerLivePageResult = True

        self.stalkerLivePendingPages.add(2)
        # Remainder is background-only; reuse Ultra's bounded catalogue lane.
        # Its own deadline is longer because it may contain multiple pages.
        self.stalkerLivePageDeadlines[2] = time.monotonic() + 90.0
        try:
            handle.future = _ULTRA_STALKER_CATALOG_POOL.submit(
                worker, _task_key=("stalker-adult-remaining", id(self)),
                _replace_task_key=True)
        except Exception:
            self.stalkerLivePageHandles.pop(2, None)
            self.stalkerLivePendingPages.discard(2)
            self.stalkerLivePageDeadlines.pop(2, None)
            return
        try:
            self.stalkerLivePageTimer.start(180, True)
        except Exception:
            pass

    def _requestStalkerLivePage(self, page, generation=None, force_network=False):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        try:
            page = max(1, int(page or 1))
        except Exception:
            page = 1
        if generation is None:
            generation = self.stalkerLivePageGeneration
        if generation != self.stalkerLivePageGeneration:
            return
        if page in self.stalkerLiveLoadedPages or page in self.stalkerLivePendingPages:
            return
        # Prevent repeated network requests when an unreachable portal times out.
        if time.monotonic() < self.stalkerLivePageRetryUntil.get(page, 0):
            try: self["desc"].setText("Server not responding. Retry the package shortly.")
            except Exception: pass
            return

        self.stalkerLivePendingPages.add(page)
        self.stalkerLivePageDeadlines[page] = time.monotonic() + 11.0
        request_deadline = self.stalkerLivePageDeadlines[page]
        source = dict(self.source)
        category_id = str(self.stalkerLiveCategoryId or "")
        handle = _UltraLiveTaskHandle(generation, ("stalker-page", page))
        self.stalkerLivePageHandles[page] = handle
        cancel_event = handle

        def worker():
            payload = None
            error = ""
            try:
                if cancel_event is not None and cancel_event.is_set():
                    return
                client = get_source_client(source)
                # Cache-first without ever constructing a client on the UI thread.
                if not (force_network or getattr(self, "stalkerLiveAdultDirect", False)):
                    payload = client.live_page_cached(category_id, page, sortby="number")
                if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
                    payload = client.live_page(
                        category_id, page, sortby="number", cancel_event=cancel_event,
                        force_network=bool(force_network or getattr(self, "stalkerLiveAdultDirect", False))
                    )
                if cancel_event is not None and cancel_event.is_set():
                    return
            except Exception as exc:
                if cancel_event is not None and cancel_event.is_set():
                    return
                try:
                    from .core import classify_stalker_error
                    _kind, error = classify_stalker_error(exc)
                except Exception:
                    error = str(exc)
            # A timed-out request may finish AFTER a later retry of the same
            # page. Its earlier result must not replace that newer request.
            if (generation != self.stalkerLivePageGeneration or
                    page not in self.stalkerLivePendingPages or
                    self.stalkerLivePageDeadlines.get(page) != request_deadline):
                return
            self.stalkerLivePageResults.append((generation, page, payload or {}, error))
            self.stalkerLivePageResult = True

        # Ultra's ORIGINAL lazy worker pool handles pagination instead of
        # starting an unlimited new thread for every requested MAG page.
        # Separate catalogue and playback lanes protect selected-channel Play.
        try:
            handle.future = _ULTRA_STALKER_CATALOG_POOL.submit(
                worker,
                _task_key=("stalker-page", id(self), int(page)),
                _replace_task_key=True)
        except Exception:
            # Do not launch an unbounded legacy Thread when the Ultra task
            # lane is unavailable; release the pending page and GUI instead.
            self.stalkerLivePageHandles.pop(page, None)
            self.stalkerLivePendingPages.discard(page)
            self.stalkerLivePageDeadlines.pop(page, None)
            self.stalkerLivePageRetryUntil[page] = time.monotonic() + 2.0
            try: self["desc"].setText("Unable to start Stalker request")
            except Exception: pass
            return
        try:
            self.stalkerLivePageTimer.start(180, True)
        except Exception:
            pass

    def _finishStalkerLivePage(self):
        results = getattr(self, "stalkerLivePageResults", None) or []
        result = results.pop(0) if results else None
        self.stalkerLivePageResult = bool(results)
        if not result:
            now = time.monotonic()
            expired = [page for page in list(self.stalkerLivePendingPages)
                       if now >= self.stalkerLivePageDeadlines.get(page, now + 1)]
            for page in expired:
                handle = self.stalkerLivePageHandles.pop(page, None)
                if handle is not None:
                    try: handle.cancel()
                    except Exception: pass
                self.stalkerLivePendingPages.discard(page)
                self.stalkerLivePageDeadlines.pop(page, None)
                self.stalkerLivePageRetryUntil[page] = now + 18.0
            if expired:
                try: self["desc"].setText("Stalker server did not respond. Switch server or retry.")
                except Exception: pass
            if self.stalkerLivePendingPages:
                try: self.stalkerLivePageTimer.start(180, True)
                except Exception: pass
            return

        generation, page, payload, error = result
        if generation != self.stalkerLivePageGeneration or page not in self.stalkerLivePendingPages:
            if getattr(self, "stalkerLivePageResults", None) or self.stalkerLivePendingPages:
                try: self.stalkerLivePageTimer.start(1, True)
                except Exception: pass
            return
        # A completed Ultra future no longer needs its cancellation handle.
        self.stalkerLivePageHandles.pop(page, None)
        self.stalkerLivePendingPages.discard(page)
        self.stalkerLivePageDeadlines.pop(page, None)
        # Another page may still be resolving; keep its poll alive.
        if self.stalkerLivePendingPages:
            try: self.stalkerLivePageTimer.start(180, True)
            except Exception: pass

        if error:
            try:
                self["desc"].setText(tr("Unable to load package:\n%s") % error)
            except Exception:
                pass
            return

        items = list((payload or {}).get("items") or [])
        total = int((payload or {}).get("total_items") or 0)
        has_more = bool((payload or {}).get("has_more"))

        if bool((payload or {}).get("_adult_initial")):
            clean = []
            for index, item in enumerate(items):
                row = dict(item or {})
                row["number"] = str(index + 1)
                clean.append(row)
            self.stalkerLiveSlots = clean
            self.stalkerLiveTotal = max(int(total or 0), len(clean))
            self.stalkerLiveLoadedPages = set([1])
            try:
                current_index = int(self["list"].getSelectedIndex() or 0)
            except Exception:
                current_index = 0
            self._renderStalkerLiveSlots(current_index)
            if not getattr(self, "_windowsVisible", False):
                self.previewLive()
            # Complete the bouquet only after the first 20 rows are already visible.
            remainder = list((payload or {}).get("_adult_remainder") or [])
            next_page = int((payload or {}).get("_adult_next_page") or 1)
            if bool((payload or {}).get("has_more")):
                self._requestStalkerAdultRemaining(
                    generation, next_page, buffered=remainder, total_hint=self.stalkerLiveTotal
                )
            return

        if bool((payload or {}).get("_adult_append")):
            base = [dict(x or {}) for x in list(self.stalkerLiveSlots or [])]
            seen = set()
            for row in base:
                key = str(row.get("ch_id") or row.get("stream_id") or row.get("id") or row.get("cmd") or row.get("name") or "")
                if key:
                    seen.add(key)
            for item in items:
                row = dict(item or {})
                key = str(row.get("ch_id") or row.get("stream_id") or row.get("id") or row.get("cmd") or row.get("name") or "")
                if key and key in seen:
                    continue
                if key:
                    seen.add(key)
                base.append(row)
            for index, row in enumerate(base):
                row["number"] = str(index + 1)
            self.stalkerLiveSlots = base
            self.stalkerLiveTotal = max(int(total or 0), len(base))
            page_size = max(1, int(getattr(self, "stalkerLiveAdultPageSize", 20) or 20))
            page_count = (len(base) + page_size - 1) // page_size
            self.stalkerLiveLoadedPages = set(range(1, page_count + 1))
            try:
                current_index = int(self["list"].getSelectedIndex() or 0)
            except Exception:
                current_index = 0
            self._renderStalkerLiveSlots(current_index)
            if not getattr(self, "_windowsVisible", False):
                self.previewLive()
            return

        if total <= 0:
            total = max(len(self.stalkerLiveSlots), (page - 1) * 14 + len(items))
            if has_more:
                total = max(total, page * 14 + 14)

        if total > len(self.stalkerLiveSlots):
            self.stalkerLiveSlots.extend(
                self._stalkerLivePlaceholder(i)
                for i in range(len(self.stalkerLiveSlots), total)
            )

        start = (page - 1) * 14
        needed = start + len(items)
        if needed > len(self.stalkerLiveSlots):
            self.stalkerLiveSlots.extend(
                self._stalkerLivePlaceholder(i)
                for i in range(len(self.stalkerLiveSlots), needed)
            )

        for offset, item in enumerate(items):
            pos = start + offset
            if pos < len(self.stalkerLiveSlots):
                self.stalkerLiveSlots[pos] = dict(item or {})

        self.stalkerLiveTotal = max(total, needed)
        self.stalkerLiveLoadedPages.add(page)
        if page == 1 and items:
            # Successful Ultra provider refresh replaces the freshness stamp;
            # failed or empty responses must never wipe last-good channels.
            try:
                store = getattr(self, '_stalkerBouquetRam', None)
                if isinstance(store, dict):
                    store[(_source_identity(self.source), str(self.stalkerLiveCategoryId or ''))] = (
                        time.monotonic(), list(self.stalkerLiveSlots),
                        set(self.stalkerLiveLoadedPages), int(self.stalkerLiveTotal))
            except Exception:
                pass

        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0

        self._renderStalkerLiveSlots(current_index)
        if not getattr(self, "_windowsVisible", False):
            self.previewLive()
        if getattr(self, "stalkerLivePageResults", None):
            try: self.stalkerLivePageTimer.start(1, True)
            except Exception: pass

    def _ensureStalkerLiveCurrentPage(self):
        if self.kind != "live" or self.source.get("type") != "stalker":
            return
        if bool(getattr(self, "stalkerLiveAdultDirect", False)):
            return
        try:
            index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            index = 0
        page = (index // 14) + 1
        if page not in self.stalkerLiveLoadedPages:
            self._requestStalkerLivePage(page)

    def _runStalkerSelectionEpg(self):
        if self.kind != "live":
            return
        item = self.current()
        # Ultra starts playback independently of optional programme metadata.
        # Keep RAM guide available, but never launch another selected-channel
        # lookup on an EPG miss while THIS channel's link/decoder is pending.
        # The already-running visible-page guide is not cancelled.
        if item and self.source.get("type") in ("stalker", "xtream"):
            pending_link = (getattr(self, "liveZapResolveHandle", None) is not None and
                            time.monotonic() < float(getattr(self, "liveZapResolveDeadline", 0) or 0))
            pending_decoder = getattr(self, "_livePreviewCheck", None) is not None
            if (pending_link or pending_decoder) and not _shared_live_epg_cached(self.source, item):
                try: self.stalkerSelectionEpgTimer.start(350, True)
                except Exception: pass
                return
        if item and str(item.get("name") or item.get("title") or "").lstrip().startswith("####"):
            # r523: package/separator rows inside the channel list are display
            # labels only. Never resolve EPG, poster, picon or channel metadata.
            return
        source_type = self.source.get("type")
        if source_type == "stalker":
            # Ultra's selected-channel RAM data is rendered immediately;
            # its visible-page wave runs separately from video playback.
            if item:
                fallback = (item.get("plot") or item.get("description") or "").strip()
                if self._applyStalkerShortEpg(item, fallback):
                    self._scheduleLivePoster(item)
            self._prefetchStalkerVisibleEpg()
        elif source_type == "xtream":
            # r462: reuse the existing selection debounce timer for Xtream.
            # Up/Down only moves the list; after scrolling settles, resolve EPG
            # for the currently highlighted channel once. This avoids doing a
            # local lookup/provider fallback on every key repeat.
            if item:
                self._updateLiveEpg(item)
                self._scheduleLivePoster(item)

    def _providerCategoryScore(self, name, provider):
        text=str(name or "").strip().lower()
        compact=re.sub(r"[^a-z0-9]+"," ",text).strip()
        tokens=[x for x in compact.split() if x]
        resolved=package_provider_key(name)
        if provider=="netflix":
            if "netflix" in compact:
                return 500
            if resolved=="netflix":
                return 450
            if "nf" in tokens:
                return 420
            if compact.startswith("nf ") or compact.endswith(" nf"):
                return 400
        elif provider=="prime":
            if "prime video" in compact:
                return 500
            if "amazon prime" in compact:
                return 480
            if resolved=="prime":
                return 450
            if "prime" in tokens:
                return 420
        return -1

    def _tmdbSortServerPackageItems(self, items, package_name, category_id="", provider_override=""):
        # A real server package is ALWAYS its exact category_id.  Never infer
        # Netflix/Prime behaviour from the package name: Display Options owns
        # the optional provider-wide collections and may explicitly request it.
        forced_provider=str(provider_override or "").strip().lower()
        if not forced_provider:
            try:
                forced_cid=str((self.source or {}).get("_package_provider_category_id") or "")
                if forced_cid and forced_cid==str(category_id or ""):
                    forced_provider=str((self.source or {}).get("_package_provider_override") or "").strip().lower()
            except Exception:
                forced_provider=""
        provider=forced_provider
        if provider not in ("netflix","prime"):
            return list(items or [])

        rows=list(items or [])
        if not rows:
            return rows

        try:
            ranked=TMDbClient().provider_catalog(self.kind,provider,limit=200) or []
        except Exception:
            return rows

        def _norm_title(value):
            value=str(value or "").lower()
            value=value.replace("&"," and ")
            # Remove provider/source prefixes and common IPTV decorations.
            value=re.sub(r"\b(?:netflix|nf|prime video|amazon prime|prime)\b"," ",value)
            value=re.sub(r"\b(?:4k|uhd|fhd|hd|sd|hdr|dolby|atmos|hevc|x265|x264)\b"," ",value)
            value=re.sub(r"\b(?:multi|dual|audio|arabic|english|eng|ar|sub|subs|dub|dubbed)\b"," ",value)
            value=re.sub(r"\b(?:19|20)\d{2}\b"," ",value)
            value=re.sub(r"\([^)]*\)|\[[^]]*\]|\{[^}]*\}"," ",value)
            value=re.sub(r"[^a-z0-9]+"," ",value)
            return " ".join(value.split())

        rank_by_id={}
        rank_by_title={}
        ranked_titles=[]
        for pos,row in enumerate(ranked):
            tid=str(row.get("tmdb_id") or row.get("tmdb") or row.get("id") or "").strip()
            if tid and tid not in rank_by_id:
                rank_by_id[tid]=pos
            title=row.get("name") or row.get("title") or row.get("original_name") or row.get("original_title") or ""
            key=_norm_title(title)
            if key and key not in rank_by_title:
                rank_by_title[key]=pos
                ranked_titles.append((key,pos))

        matched=[]
        unmatched=[]
        for original_pos,item in enumerate(rows):
            item=item or {}
            _info=item.get("info") if isinstance(item.get("info"),dict) else {}
            tid=str(
                item.get("tmdb_id") or item.get("tmdb") or item.get("tmdbid") or
                _info.get("tmdb_id") or _info.get("tmdb") or _info.get("tmdbid") or ""
            ).strip()
            score=None
            if tid and tid in rank_by_id:
                score=rank_by_id[tid]
            else:
                title=item.get("name") or item.get("title") or item.get("original_name") or ""
                key=_norm_title(title)
                if key in rank_by_title:
                    score=rank_by_title[key]
                elif key:
                    # Conservative containment fallback for decorated server titles.
                    candidates=[]
                    for rk,rpos in ranked_titles:
                        if len(key)>=6 and len(rk)>=6 and (key in rk or rk in key):
                            candidates.append((abs(len(key)-len(rk)),rpos))
                    if candidates:
                        candidates.sort()
                        score=candidates[0][1]
            if score is None:
                unmatched.append((original_pos,item))
            else:
                matched.append((score,original_pos,item))

        matched.sort(key=lambda x:(x[0],x[1]))
        ordered=[x[2] for x in matched] + [x[1] for x in unmatched]
        # Provider package contract: Netflix / Prime never expose more than
        # 200 items in this curated view, even if the server category has
        # hundreds or thousands of entries.
        return ordered[:200]

    def _loadMergedServerProvider(self, provider):
        provider=str(provider or "").strip().lower()
        label="NETFLIX" if provider=="netflix" else "PRIME VIDEO"
        self.categoryLoadToken += 1
        token=self.categoryLoadToken
        self.categoryLoadResult=None
        source=dict(self.source or {})
        kind=self.kind

        try:self["desc"].setText("")
        except Exception:pass

        def worker():
            try:
                cats,origin=get_cached_categories(
                    source,kind,get_source_client(source),wait_for_server=True
                )
                cats=filter_categories(source,kind,cats or [])
                matches=[]
                for cat in cats:
                    cname=str(cat.get("category_name") or "")
                    cid=str(cat.get("category_id") or "")
                    score=self._providerCategoryScore(cname,provider)
                    if score>=0 and cid:
                        matches.append((score,cid,cname))
                matches.sort(key=lambda x:x[0],reverse=True)

                merged=[]
                seen=set()
                used_names=[]
                # Merge all matching Netflix/Prime server packages, capped at 200.
                for score,cid,cname in matches:
                    try:
                        package_items,_origin=get_category_streams(
                            source,kind,get_source_client(source),cid,
                            use_cache=True,wait_for_server=(kind!="series")
                        )
                    except Exception:
                        package_items=[]
                    if package_items:
                        used_names.append(cname)
                    for item in list(package_items or []):
                        key=str(
                            (item or {}).get("stream_id") or
                            (item or {}).get("series_id") or
                            (item or {}).get("id") or
                            (item or {}).get("tmdb_id") or
                            ((item or {}).get("name") or (item or {}).get("title") or "")
                        )
                        if key and key in seen:
                            continue
                        if key:
                            seen.add(key)
                        merged.append(item)
                        if len(merged)>=200:
                            break
                    if len(merged)>=200:
                        break

                if merged:
                    merged=self._tmdbSortServerPackageItems(merged,label,provider_override=provider)
                    result=(token,merged,"server_tmdb_sorted","",label)
                elif matches:
                    result=(token,[],"server_empty","",label)
                else:
                    result=(token,[],"provider_not_found","",label)
            except Exception as exc:
                result=(token,[],"error",str(exc),label)
            self.categoryLoadResult=result

        threading.Thread(target=worker,name="TiviMateProviderMerge",daemon=True).start()
        try:self.categoryLoadTimer.start(120,True)
        except Exception:pass


    def loadSelectedCategory(self):
        cid=self.selectedCategory()
        if self.kind == "live":
            self._cancelPendingLiveSelection()
            self._loadedLiveCategoryKey = None
        if cid=="__server_netflix__":
            self._loadMergedServerProvider("netflix")
            return
        if cid=="__server_prime__":
            self._loadMergedServerProvider("prime")
            return
        c = self["category"].getCurrent()
        name = c[0] if c else (self.activeCategoryName or self.initialCategoryName or "")
        if name:
            self.activeCategoryName = name
        if self.kind == "live" and cid == "__favorites__":
            # Global Live Favorites: merge saved channels from every configured source.
            # The source object is attached only in memory so credentials are never
            # duplicated into favorites.json.
            items = []
            configured_sources = get_sources()
            for record in list_favourites("live"):
                fav_source = source_for_record(record, configured_sources)
                if not fav_source:
                    continue
                item = dict(record.get("item") or {})
                if item:
                    item["_favorite_source"] = fav_source
                    item["_favorite_record_id"] = record.get("id", "")
                    items.append(item)
            self._applyCategoryItems(items, tr("FAVORITES"), "local")
            if not items:
                self["desc"].setText(tr("No favorite channels yet. Add channels with the red button."))
            return
        if self.kind == "live" and cid in ("__bein_sports__", "__bein_virtual__"):
            self._loadBeinSports()
            return
        if self.kind == "live" and cid == "__recent_added__":
            self.catchupPackageActive = False
            self._loadRecentlyAdded()
            return
        if self.kind in ("vod", "series") and cid == "__recent_added__":
            self._loadRecentlyAddedMedia()
            return
        if self.kind == "live" and cid == "__catchup__":
            if bool((self.source or {}).get("catchup_enabled", False)):
                self._loadCatchupPackage()
            return
        self.catchupPackageActive = False

        # EStalker 1.45: Stalker Live never downloads the whole package here.
        # Open page 1 (14 rows) and fetch later pages only when selection enters them.
        if self.kind == "live" and self.source.get("type") == "stalker":
            if not cid:
                return
            self._beginStalkerLiveCategory(cid, name)
            return

        if not cid and self.source.get("type") in ("xtream", "stalker"):
            return
        self["desc"].setText("")
        if self.kind == "live" and self.source.get("type") == "xtream" and cid:
            # Repeat visits: paint directly from source/category-scoped RAM.
            # Never decode a JSON file or construct a network client on the
            # Enigma2 input/UI thread. The normal worker below handles cold
            # disk caches and first server requests without scanning others.
            hot_rows, hot_origin = peek_category_streams_ram(self.source, "live", cid)
            if hot_rows:
                self.categoryLoadToken += 1  # Invalidate older category workers.
                self.categoryLoadResult = None
                try: self.categoryLoadTimer.stop()
                except Exception: pass
                self._applyCategoryItems(hot_rows, name, hot_origin)
                return
        if self.source.get("type") in ("xtream", "stalker") and self.kind in ("live", "vod", "series"):
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            source = dict(self.source)
            kind = self.kind
            def worker():
                try:
                    items, origin = get_category_streams(source, kind, get_source_client(source), cid, use_cache=True, wait_for_server=(kind != "series"))
                    items = self._tmdbSortServerPackageItems(items or [], name, cid)
                    result = (token, items or [], origin, "", name)
                except Exception as exc:
                    result = (token, [], "error", str(exc), name)
                self.categoryLoadResult = result
            threading.Thread(target=worker, name="TiviMateE2Category", daemon=True).start()
            try: self.categoryLoadTimer.start(120, True)
            except Exception: pass
            return
        try:
            if self.source.get("type") in ("xtream", "stalker"): items=get_source_client(self.source).streams(self.kind,cid)
            elif self.source.get("type")=="m3u": items=[x for x in self.mediaItems if x.get("group")==cid]
            else: items=self.mediaItems
            self._applyCategoryItems(items or [], name, "server")
        except Exception as e:
            self.mediaItemsCurrent=[]
            if self.kind=="live": self["list"].setList([])
            self["desc"].setText(("Unable to load package:\n%s" % e) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % e))

    def _prewarmBeinSportsCache(self):
        """Build/refresh the beIN view quietly while the normal Live UI is open."""
        if self.kind != "live" or self.source.get("_virtual_bein"):
            return
        source = _bein_base_source(self.source)
        source_type = source.get("type")
        if source_type == "m3u":
            try:
                items = [item for item in (self.mediaItems or []) if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
            except Exception:
                pass
            return
        if source_type not in ("xtream", "stalker"):
            return
        cached, fresh, stamp = _load_bein_cache(source)
        if fresh:
            return
        def worker():
            try:
                client = get_source_client(source)
                all_items = client.streams("live", "") or []
                items = [item for item in all_items if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateE2BeinPrewarm", daemon=True).start()

    def _loadBeinSports(self):
        """Open beIN SPORTS from a fast per-server cache, refreshing in background."""
        source = _bein_base_source(self.source)
        source_type = source.get("type")
        cached, fresh, stamp = _load_bein_cache(source)
        if cached:
            self._applyCategoryItems(cached, "beIN SPORTS", "cache")
            if not fresh:
                self["desc"].setText("")
                self._prewarmBeinSportsCache()
            return
        self["desc"].setText("")
        if source_type == "m3u":
            items = [item for item in (self.mediaItems or []) if _is_bein_sports_channel(item)]
            _save_bein_cache(source, items)
            self._applyCategoryItems(items, "beIN SPORTS", "local")
            if not items:
                self["desc"].setText("No beIN SPORTS channels found in this source.")
            return
        if source_type not in ("xtream", "stalker"):
            self._applyCategoryItems([], "beIN SPORTS", "local")
            self["desc"].setText("beIN SPORTS is available for Xtream, Stalker and M3U sources.")
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        def worker():
            try:
                client = get_source_client(source)
                items = client.streams("live", "") or []
                items = [item for item in items if _is_bein_sports_channel(item)]
                _save_bein_cache(source, items)
                result = (token, items, "server", "", "beIN SPORTS")
            except Exception as exc:
                result = (token, [], "error", str(exc), "beIN SPORTS")
            self.categoryLoadResult = result
        threading.Thread(target=worker, name="TiviMateE2BeinSports", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, True)
        except Exception:
            pass

    def _sortPackageNewest(self, items):
        """Newest added first across the entire package, before pagination.

        Prefer the provider's real added timestamp. When unavailable, fall
        back to release date/year and then stable provider id/original order.
        Comparing YYYY0000 with YYYYMMDD avoids treating a year-only title as
        older than a title released the previous year.
        """
        rows = list(items or [])
        indexed = list(enumerate(rows))
        def order(pair):
            index, item = pair
            if not isinstance(item, dict):
                return (0, 0, 0, -index)
            stamp = self._recentAddedTimestamp(item)
            raw = str(item.get("releaseDate") or item.get("releasedate") or
                      item.get("release_date") or item.get("first_air_date") or
                      item.get("year") or "")
            digits = "".join(c for c in raw if c.isdigit())
            release = 0
            if len(digits) >= 4:
                try:
                    year = int(digits[:4])
                    if 1800 <= year <= 2200:
                        release = int((digits + "0000")[:8])
                except (ValueError, TypeError):
                    pass
            ident = item.get("stream_id") or item.get("series_id") or item.get("id") or 0
            try:
                ident = int(ident)
            except (ValueError, TypeError):
                ident = 0
            return (int(stamp or 0), release, ident, -index)
        indexed.sort(key=order, reverse=True)
        return [item for index, item in indexed]

    def _recentAddedTimestamp(self, item):
        keys = ("last_modified", "added", "added_at", "created_at", "date_added", "timestamp") if self.kind == "series" else ("added", "added_at", "created_at", "date_added", "timestamp")
        for key in keys:
            value = item.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                pass
            try:
                import datetime
                value = str(value).replace("Z", "").split(".")[0]
                return int(time.mktime(datetime.datetime.strptime(value[:19], "%Y-%m-%d %H:%M:%S").timetuple()))
            except Exception:
                pass
        return 0

    def _recentStateKey(self, source):
        raw = "%s|%s|%s|%s" % (
            source.get("type", ""), source.get("url", "").rstrip("/"),
            source.get("username", ""), source.get("mac", ""))
        try:
            raw = raw.encode("utf-8")
        except Exception:
            pass
        return hashlib.sha1(raw).hexdigest()

    def _recentIdentity(self, item, order=0):
        return str(item.get("stream_id") or item.get("id") or item.get("url") or
                   item.get("cmd") or item.get("name") or order)

    def _loadRecentlyAdded(self):
        """Load genuinely recent Live channels for the active server.

        Xtream is fetched in one complete request so category cache gaps cannot
        corrupt the result. Provider ``added`` timestamps are preferred when
        present; snapshot comparison is the fallback for Stalker/M3U providers.
        """
        self["desc"].setText("")
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        source = dict(self.source)
        from .recent_live_cache import get_recent_live_snapshot, save_recent_live_snapshot
        cached_recent, snapshot_fresh = get_recent_live_snapshot(source)
        # Verified cache first, always scoped to this exact server/account.
        if cached_recent:
            self._applyCategoryItems(cached_recent, tr("RECENTLY ADDED"), "cache")
            if snapshot_fresh:
                return
        current_items = list(self.mediaItems or [])

        def worker():
            try:
                client = get_source_client(source)
                stype = source.get("type")
                if stype in ("m3u", "fg"):
                    merged = current_items
                elif stype == "xtream":
                    merged = client.streams("live", "") or []
                elif stype == "stalker":
                    try:
                        merged = client.streams("live", "") or []
                    except Exception:
                        merged = client.live_streams("") or []
                else:
                    merged = current_items
                if stype in ("xtream", "stalker") and not merged:
                    raise RuntimeError("Live catalogue unavailable; retain last verified Recent Added")

                dedup = {}
                ordered_ids = []
                for order, item in enumerate(merged or []):
                    if not isinstance(item, dict):
                        continue
                    key = self._recentIdentity(item, order)
                    if key in dedup:
                        continue
                    dedup[key] = dict(item)
                    ordered_ids.append(key)

                state_path = os.path.join(BASE, "recent_live_state.json")
                all_state = load_json(state_path, {}) or {}
                state_key = self._recentStateKey(source)
                previous = all_state.get(state_key) or {}
                # Schema 2 invalidates snapshots produced by the old category-by-
                # category implementation, which could silently miss channels.
                if int(previous.get("schema", 0) or 0) != 2:
                    previous = {}
                known = set(str(value) for value in (previous.get("known") or []))
                existing_recent = previous.get("recent") or {}
                now = int(time.time())
                max_age = 30 * 24 * 60 * 60
                cutoff = now - max_age

                recent = {}
                # Provider timestamps are the most faithful source for Xtream.
                timestamped = 0
                for key in ordered_ids:
                    stamp = self._recentAddedTimestamp(dedup[key])
                    if stamp > 0:
                        timestamped += 1
                        if stamp >= cutoff and stamp <= now + 86400:
                            recent[key] = stamp

                # Preserve still-valid snapshot additions and detect new IDs on
                # providers that do not publish reliable timestamps.
                for key, seen_at in existing_recent.items():
                    try:
                        seen_at = int(seen_at)
                    except Exception:
                        continue
                    if key in dedup and now - seen_at <= max_age:
                        recent.setdefault(key, seen_at)
                if known:
                    for key in ordered_ids:
                        if key not in known and key not in recent:
                            recent[key] = now

                all_state[state_key] = {
                    "schema": 2,
                    "known": ordered_ids,
                    "recent": recent,
                    "updated": now,
                    "timestamped": timestamped,
                }
                save_json(state_path, all_state)

                recent_ids = [key for key in ordered_ids if key in recent]
                order_map = dict((key, pos) for pos, key in enumerate(ordered_ids))
                recent_ids.sort(key=lambda key: (recent.get(key, 0), order_map.get(key, 0)), reverse=True)
                items = [dedup[key] for key in recent_ids[:50]]
                if items:
                    save_recent_live_snapshot(source, items)
                    result = (token, items, "recent_added", "", tr("RECENTLY ADDED"))
                elif cached_recent:
                    result = (token, [], "recent_live_keep_cache", "", tr("RECENTLY ADDED"))
                else:
                    result = (token, [], "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                result = ((token, [], "recent_live_keep_cache", "", tr("RECENTLY ADDED"))
                          if cached_recent else (token, [], "error", str(exc), tr("RECENTLY ADDED")))
            self.categoryLoadResult = result

        threading.Thread(target=worker, name="TiviMateE2RecentAdded", daemon=True).start()
        try:
            self.categoryLoadTimer.start(120, True)
        except Exception:
            pass

    def _loadRecentlyAddedMedia(self):
        """Instant verified snapshot; network refresh has no UI loading state."""
        cached, fresh = _recent_media_cache_state(self.source, self.kind)
        self.categoryLoadToken += 1
        token = self.categoryLoadToken
        self.categoryLoadResult = None
        self._recentPreviewShown = bool(cached)
        self._recentWorkerPending = False
        try: self.categoryLoadTimer.stop()
        except Exception: pass
        if cached:
            self._applyCategoryItems(cached[:200], tr("RECENTLY ADDED"), "cache")
            if fresh:
                return
        else:
            # A new filter/server must never leave posters from the previously
            # selected package on screen while its Recent feed is being built.
            self._largePageAllItems = []
            self.mediaItemsCurrent = []
            self.lastCategoryItems = []
            self.renderPosterPage()
            # Hide the transient Recent loading notice only; keep the
            # background worker and last-good cache behavior intact.
            try: self["desc"].setText("")
            except Exception: pass

        self._recentWorkerPending = True
        # A prewarm started in Packages can publish a verified snapshot while
        # this screen waits for the same provider-wide catalogue lock.
        # Poll that saved snapshot occasionally, not the provider or posters.
        self._recentCachePollAt = time.monotonic() + 2.0
        source = dict(self.source)
        kind = self.kind
        # The synthetic Recent Added category is a navigation shortcut, NOT
        # an actual provider package. On a cold/slow catalogue it may be the
        # only category currently visible. Do not let that fake nonempty list
        # suppress the provider-category fallback in the worker.
        known_categories = [dict(row) for row in (self.categories or [])
                            if isinstance(row, dict)
                            and str(row.get("category_id") or "").strip()
                            and str(row.get("category_id")) != "__recent_added__"]

        def worker():
            try:
                from .filters import get_cached_categories, get_allowed_category_ids
                from .core import get_source_client
                from .recent_feed import recent_added_items
                allowed = get_allowed_category_ids(source, kind)
                categories = known_categories
                if not categories and source.get("type") != "m3u":
                    categories, _origin = get_cached_categories(
                        source, kind, wait_for_server=True)
                categories = [row for row in (categories or [])
                              if str(row.get("category_id") or "").strip()
                              and str(row.get("category_id")) != "__recent_added__"
                              and (allowed is None or str(row.get("category_id")) in allowed)]
                if not categories:
                    # Empty *enabled selection* is legitimate; however an
                    # unavailable Stalker/Xtream catalogue isn't evidence that
                    # the server has no recent movies or series. Never mark
                    # such a transient response as a successful empty feed.
                    if source.get("type") in ("stalker", "xtream") and (allowed is None or bool(allowed)):
                        raise RuntimeError("Recent Added categories temporarily unavailable; retry when the server responds")
                    result = []
                else:
                    client = get_source_client(source)
                    result = recent_added_items(source, kind, client, categories, 200)
                if result:
                    _save_recent_media_cache(source, kind, result)
                packet = (token, result, "recent_added", "", tr("RECENTLY ADDED"))
            except Exception as exc:
                packet = (token, [], "error", str(exc), tr("RECENTLY ADDED"))
            # Post the result for the existing GUI timer on ALL receiver images.
            # The former Twisted-only callback had no timer watchdog if the
            # server/prewarm gate never returned; the page could wait forever.
            if token == self.categoryLoadToken:
                self.categoryLoadResult = packet
                self._recentWorkerPending = False

        threading.Thread(target=worker, name="TiviMateRecentBackground", daemon=True).start()
        # An Enigma2 eTimer owns both completion and the finite wait guard.
        # Network/catalogue work stays in the existing single daemon worker.
        try: self.categoryLoadTimer.start(250, True)
        except Exception: pass


    def _finishCategoryLoad(self):
        # A slow/disconnected portal must not leave a category-loading timer
        # running indefinitely. Late worker results are ignored by token.
        token = self.categoryLoadToken
        if getattr(self, "_categoryPollToken", None) != token:
            self._categoryPollToken = token
            self._categoryPollSince = time.monotonic()
            self._seriesCategoryPolls = 0
            self._seriesItemPolls = 0
            self._categorySlowNotice = False
        result = self.categoryLoadResult
        is_recent = (self.kind in ("vod", "series") and
                     self.selectedCategory() == "__recent_added__")
        if not result:
            if is_recent:
                # An Xtream/Stalker catalogue may finish *after* 12 seconds.
                # On non-Twisted images the former 12-second cutoff invalidated
                # the response token, so the eventual success was saved to disk
                # but NEVER displayed until the user revisited the page.
                # Poll on Twisted and non-Twisted images alike.  When Packages
                # has already started the same Recent feed, its verified cache
                # may become ready before this worker gets the shared gate.
                elapsed = time.monotonic() - self._categoryPollSince
                now = time.monotonic()
                if (not getattr(self, "_recentPreviewShown", False) and
                        now >= getattr(self, "_recentCachePollAt", 0)):
                    self._recentCachePollAt = now + 4.0
                    try:
                        rows, _fresh = _recent_media_cache_state(self.source, self.kind)
                        if rows and self.selectedCategory() == "__recent_added__":
                            self._recentPreviewShown = True
                            self._applyCategoryItems(rows[:200], tr("RECENTLY ADDED"), "cache")
                    except Exception:
                        pass
                if elapsed >= 60.0:
                    # Stop the UI wait even if a portal/network call hangs.
                    # Its daemon may still publish a verified disk snapshot;
                    # no late callback may replace a different package screen.
                    self._recentWorkerPending = False
                    self.categoryLoadToken += 1
                    if not getattr(self, "_recentPreviewShown", False):
                        try:
                            self["desc"].setText("Recent Added is temporarily unavailable. Reopen to retry.")
                        except Exception: pass
                    return
                if getattr(self, "_recentWorkerPending", False):
                    delay = 1200 if elapsed >= 12.0 else 350
                    try: self.categoryLoadTimer.start(delay, True)
                    except Exception: pass
                return
            elapsed = time.monotonic() - self._categoryPollSince
            if self.kind in ("vod", "series") and elapsed >= 20.0:
                if not getattr(self, "_categorySlowNotice", False):
                    self._categorySlowNotice = True
                    try: self["desc"].setText("This package is slow. You can retry it.")
                    except Exception: pass
                if elapsed >= 60.0:
                    self.categoryLoadToken += 1
                    return
                delay = 1200  # Keep accepting late results without a visible LOADING loop.
            elif elapsed >= 20.0:
                self.categoryLoadToken += 1
                try: self["desc"].setText("Server response timed out. Try this package again.")
                except Exception: pass
                return
            else:
                delay = 220
            try: self.categoryLoadTimer.start(delay, True)
            except Exception: pass
            return
        self.categoryLoadResult = None
        token, items, origin, error, name = result
        if token != self.categoryLoadToken:
            return
        if self.kind == "live" and self.selectedCategory() == "__recent_added__" and origin == "recent_live_keep_cache":
            # Offline / empty responses may not clear previously painted Live.
            return
        if is_recent and origin == "recent_partial":
            self._recentPreviewShown = bool(items)
            self._applyCategoryItems(items, name, "cache")
            if getattr(self, "_recentWorkerPending", False):
                try: self.categoryLoadTimer.start(250, True)
                except Exception: pass
            return
        if is_recent and origin == "recent_added":
            had_preview = bool(getattr(self, "_recentPreviewShown", False))
            self._recentPreviewShown = bool(items) or had_preview
            if not items and had_preview:
                return
        if origin == "categories_loading":
            rows, cat_origin = get_cached_categories(self.source, "series")
            if not rows:
                self._seriesCategoryPolls += 1
                if self._seriesCategoryPolls >= 20 or cat_origin == "error":
                    try: self["desc"].setText("No series categories received. Try again later.")
                    except Exception: pass
                    return
                self.categoryLoadResult = (token, [], "categories_loading", "", "")
                try: self.categoryLoadTimer.start(500, True)
                except Exception: pass
                return
            self.categories = rows
            allowed_ids = get_allowed_category_ids(self.source, self.kind)
            blocked = {"all", "all series", "كل المسلسلات", "جميع المسلسلات", "كل المحتوى"}
            menu=[]; filtered=[]
            for x in rows:
                cname=(x.get("category_name") or "Other").strip(); ccid=str(x.get("category_id", ""))
                if allowed_ids is not None and ccid not in allowed_ids: continue
                if self.kind == "live" and not _adult_source_enabled(self.source) and _adult_live_name(cname): continue
                if cname.lower() in blocked: continue
                filtered.append(x); menu.append((cname, ccid))
            if self.kind == "live" and self.source.get("type") == "stalker":
                hidden_state = _load_stalker_hidden(self.source)
                filtered = [x for x in filtered if str(x.get("category_id", "")) not in hidden_state["categories"]]
                menu = [(x.get("category_name") or "Other", str(x.get("category_id", ""))) for x in filtered]
            self.categories=filtered; self["category"].setList(menu)
            self["desc"].setText(tr("Select a series category then press OK.")) if menu else self["desc"].setText(tr("No categories available."))
            return
        if origin == "stalker_search_all":
            self.showItems(items or [])
            try:
                self["meta"].setText("Search All • %d" % len(items or []))
            except Exception:
                pass
            return
        if origin=="provider_not_found":
            self.mediaItemsCurrent=[]
            try:
                self["desc"].setText("%s package was not found on this server." % name)
                self["currentCategory"].setText(name)
            except Exception:pass
            return
        if origin=="server_empty":
            self.mediaItemsCurrent=[]
            try:
                self["desc"].setText("%s packages were found, but they returned no content." % name)
                self["currentCategory"].setText(name)
            except Exception:pass
            return
        if error:
            if is_recent and getattr(self, "_recentPreviewShown", False):
                # Refresh errors must never erase a valid first-page preview.
                return
            self.mediaItemsCurrent=[]
            if is_recent:
                # A failed background scan must TERMINATE its empty UI state;
                # never leave a Loading placeholder with no retry guidance.
                self["desc"].setText("Recent Added is temporarily unavailable. Reopen to retry.")
            else:
                self["desc"].setText(("Unable to load package:\n%s" % error) if self.kind == "live" else ("تعذر تحميل التصنيف:\n%s" % error))
            return
        if self.source.get("type") == "stalker" and origin == "empty":
            self.mediaItemsCurrent=[]
            if self.kind == "live":
                self["list"].setList([])
            self["desc"].setText(tr("Stalker returned no items for this package. Try another package or refresh the source."))
            return
        if origin == "loading" and self.kind == "series":
            cid = self.selectedCategory()
            cached, new_origin = get_category_streams(self.source, "series", get_source_client(self.source), cid, use_cache=True, wait_for_server=False)
            if not cached and new_origin == "loading":
                self._seriesItemPolls += 1
                if self._seriesItemPolls >= 28:
                    self["desc"].setText("Server is taking too long. Please retry the package.")
                    return
                self["desc"].setText("")
                self.categoryLoadResult = (token, [], "loading", "", name)
                try: self.categoryLoadTimer.start(500, True)
                except Exception: pass
                return
            items, origin = cached, new_origin
        self._applyCategoryItems(items, name, origin)








    def _warnIfAccountExpired(self):
        """Empty Xtream packages: say WHY when the subscription is expired.

        Uses the same account reading as the server list (Expired / Expire:)
        once per screen, off the GUI thread. A working account shows nothing.
        """
        if str((self.source or {}).get("type") or "").lower() != "xtream":
            return
        if getattr(self, "_accountExpiryChecked", False):
            return
        self._accountExpiryChecked = True
        source = dict(self.source or {})

        def worker():
            try:
                reply = XtreamClient(source).test()
                state, expiry = _xtream_state_from_reply(reply)
            except Exception:
                return
            user = reply.get("user_info") if isinstance(reply, dict) and isinstance(reply.get("user_info"), dict) else {}
            refused = str(user.get("auth") if "auth" in user else "").strip().lower() in ("0", "false", "no")
            if state != "expired" and not refused:
                return
            if state != "expired":
                state = "offline"

            def show():
                try:
                    if getattr(self, "_closed", False) or self.instance is None:
                        return
                except Exception:
                    pass
                if state == "expired":
                    message = tr("Subscription expired")
                    shown = _format_server_expiry(expiry)
                    if shown and shown != "—":
                        message += "\n" + tr("Expire") + ": " + shown
                else:
                    message = tr("The server refused this account (inactive or wrong login).")
                message += "\n\n" + str((source.get("name") or source.get("url") or ""))
                try:
                    self.session.open(MessageBox, message, MessageBox.TYPE_ERROR, timeout=12)
                except Exception:
                    pass
            if reactor:
                reactor.callFromThread(show)
        thread = threading.Thread(target=worker, name="TiviMateAccountExpiry")
        thread.daemon = True
        thread.start()

    def _applyCategoryItems(self, items, name, origin="server"):
        items = [x for x in (items or []) if isinstance(x, dict)]
        if not items and origin in ("server", "ram", "cache"):
            self._warnIfAccountExpired()
        self.activeCategoryName = name or self.initialCategoryName or ""
        self.activePackageProvider = self._providerFromPackageName(self.activeCategoryName)
        self._updateServerPackageGridLogo()
        items = self._tagPackageProvider(items, self.activeCategoryName)
        self.lastCategoryItems = items or []
        # Package content order is global (before pagination), and the user's
        # persisted Movies/TV Shows choice is reloaded whenever a package opens.
        if self.kind in ("vod", "series"):
            # Recent has already been ordered by the provider's ADD date in
            # recent_feed. Re-sorting by movie release year / id can turn an
            # older upload into the first card, which is incorrect.
            is_recent_feed = (str(self.selectedCategory() or "") == "__recent_added__")
            self.sortMode = (
                "latest" if is_recent_feed or self._packageLatestOnOpen
                else _load_media_content_sort(self.kind)
            )
            self._refreshPosterSortFooter()
            if self.sortMode == "latest" and not is_recent_feed:
                self.lastCategoryItems = self._sortPackageNewest(self.lastCategoryItems)
            elif self.sortMode == "name":
                self.lastCategoryItems = sorted(self.lastCategoryItems, key=lambda x: (x.get("name") or x.get("title") or "").lower())
            elif self.sortMode == "rating":
                def _package_rating(entry):
                    try: return float(entry.get("rating") or entry.get("rating_5based") or 0)
                    except Exception: return 0.0
                self.lastCategoryItems = sorted(self.lastCategoryItems, key=_package_rating, reverse=True)
        if self.kind != "live":
            try:
                suffix = {"ram":" • ذاكرة", "disk":" • HDD", "stale":" • HDD • تحديث بالخلفية", "server":""}.get(origin, "")
                self["currentCategory"].setText(name + suffix)
            except Exception:
                pass
        if self.searchQuery:
            self._largePageAllItems = []
            self.applySearch(self.searchQuery)
        elif self._isContinuousPackage():
            # The entire package stays in list order (newest first); arrow
            # navigation crosses former page boundaries without a page switch.
            # Artwork work is still limited to the five visible poster slots.
            self._showContinuousPackage(self.lastCategoryItems)
        elif self.kind in ("vod", "series") and not self._movieGenreAllItems and not self.preloadedItems:
            # Recent Add is intentionally separate: keep 10 x 20 poster pages.
            self._largePageAllItems = _dedupe_content_rows(self.lastCategoryItems, self.kind)[:200]
            self._largePageSize = 20
            self._largePage = 0
            self._loadLargePackagePage(0, force=True)
        else:
            self._largePageAllItems = []
            self.showItems(self.lastCategoryItems)


    def _providerFromPackageName(self, name):
        return package_provider_key(name)

    def _updateServerPackageGridLogo(self):
        if self.kind == "live":
            return
        # The large Movies/TV page uses the same package badge assets as GENRE.
        # This covers ordinary genre names as well as Netflix/Prime and the
        # generic Movies/Series fallback badges.
        package_name = str(getattr(self, "activeCategoryName", "") or
                           getattr(self, "initialCategoryName", "") or "").strip()
        logo_path = ""
        try:
            logo_path = package_logo_path(package_name, self.kind) or package_browser_logo_path(package_name, self.kind)
            if not logo_path:
                logo_path = package_logo_for_key("movies" if self.kind == "vod" else "series")
            if logo_path and os.path.isfile(logo_path):
                # Fixed bundled asset, no Packages image-cache writes.
                self["packageLogo"].instance.setPixmapFromFile(logo_path)
                self["packageLogo"].show()
            else:
                self["packageLogo"].hide()
        except Exception:
            try:
                self["packageLogo"].hide()
            except Exception:
                pass
        mapping = {
            "netflix": "contentProviderNetflix",
            "prime": "contentProviderPrime",
            "disney": "contentProviderDisney",
            "max": "contentProviderMax",
            "apple": "contentProviderApple",
            "paramount": "contentProviderParamount",
        }
        provider = str(getattr(self, "activePackageProvider", "") or "").strip().lower()
        if not provider:
            try:
                package_name = str(getattr(self, "activeCategoryName", "") or
                                   getattr(self, "initialCategoryName", "") or "")
                provider = self._providerFromPackageName(package_name)
            except Exception:
                provider = ""
        # The dynamic packageLogo supersedes the old provider-only widgets.
        active = ""
        for widget_name in mapping.values():
            try:
                if widget_name == active:
                    self[widget_name].show()
                else:
                    self[widget_name].hide()
            except Exception:
                pass


    def _tagPackageProvider(self, items, package_name):
        if self.kind == "live":
            return list(items or [])
        provider = str(getattr(self, "activePackageProvider", "") or "").strip().lower()
        if not provider:
            provider = self._providerFromPackageName(package_name)

        tagged = []
        for item in list(items or []):
            if not isinstance(item, dict):
                tagged.append(item)
                continue
            row = dict(item)
            # Preserve the selected real package name even when the provider
            # alias is not recognized. Details can independently resolve the
            # platform logo from that explicit name, without using the title.
            _selected_package = str(package_name or "").strip()
            try:
                _mixed_package = str(self.selectedCategory() or "") in (
                    "__recent_added__", "__all__", "__actor_results__")
            except Exception:
                _mixed_package = False
            if _selected_package and not _mixed_package:
                row["_server_package_name"] = _selected_package
            if provider and not _mixed_package:
                row["_tmdb_provider"] = provider
                row["_server_package_provider"] = provider
            # Explicit source context: detail recommendations/backdrops must not
            # infer their origin from whatever page happens to be visible later.
            try:
                _current=str(self.selectedCategory() or "").strip()
                _cid=(str(row.get("category_id") or "").strip()
                      if _current == "__recent_added__" else
                      str(_current or row.get("category_id") or "").strip())
            except Exception:
                _cid=str(row.get("category_id") or "").strip()
            if _cid:
                row["_source_category_id"]=_cid
            row["_source_scope"]="movies_package" if self.kind=="vod" else "series_package"
            row["_source_server_id"]=_source_identity(self.source)
            tagged.append(row)
        return tagged


    def _repaintLiveList(self):
        """Full repaint after a batch is appended. A transparent list redrawn
        only in part left the rows above the cursor empty near the end of a
        package (OpenATV 8 / transparent eListbox)."""
        try:
            instance = self["list"].instance
        except Exception:
            instance = None
        if instance is None:
            return
        try:
            instance.invalidate()
            return
        except Exception:
            pass
        try:
            self["list"].hide()
            self["list"].show()
        except Exception:
            pass

    def _renderXtreamLiveBatch(self, keep_index=0, ensure_next=False):
        if self.kind != "live" or self.source.get("type") != "xtream":
            return False
        total = len(self.mediaItemsCurrent or [])
        batch = max(1, int(getattr(self, "xtreamLiveBatchSize", 15) or 15))
        loaded = int(getattr(self, "xtreamLiveLoadedCount", 0) or 0)
        if loaded <= 0:
            loaded = min(batch, total)
        elif ensure_next and loaded < total:
            loaded = min(total, loaded + batch)
        self.xtreamLiveLoadedCount = loaded
        rows = []
        try:
            from .favorites import favourite_id, favourite_ids_for_kind
            live_fav_ids = favourite_ids_for_kind("live")
        except Exception:
            live_fav_ids = None
        for index, entry in enumerate((self.mediaItemsCurrent or [])[:loaded]):
            name = entry.get("name") or entry.get("title") or "Unnamed Channel"
            try:
                marked = (favourite_id(self.source, "live", entry) in live_fav_ids
                          if live_fav_ids is not None else
                          is_favourite(self.source, "live", entry))
                mark = "★  " if marked else ""
            except Exception: mark = ""
            rows.append(("%03d   %s%s" % (index + 1, mark, name), entry))
        self["list"].setList(rows)
        if rows:
            try:
                self["list"].moveToIndex(max(0, min(int(keep_index), len(rows) - 1)))
            except Exception:
                pass
        try:
            shown = (int(keep_index) + 1) if rows else 0
            self["pageInfo"].setText("%d / %d" % (shown, total))
        except Exception:
            pass
        self._repaintLiveList()
        return True

    def _ensureXtreamNextLiveBatch(self):
        if self.kind != "live" or self.source.get("type") != "xtream" or self.focus != "items":
            return False
        total = len(self.mediaItemsCurrent or [])
        loaded = int(getattr(self, "xtreamLiveLoadedCount", 0) or 0)
        if loaded <= 0 or loaded >= total:
            return False
        try:
            index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            index = 0
        # Append only when the user has actually reached the last rendered row.
        if index < max(0, loaded - 1):
            return False
        self._renderXtreamLiveBatch(index, ensure_next=True)
        return True

    def _renderM3uLiveBatch(self, keep_index=0, ensure_next=False):
        if self.kind != "live" or self.source.get("type") != "m3u":
            return False
        total = len(self.mediaItemsCurrent or [])
        batch = 15
        loaded = int(getattr(self, "m3uLiveLoadedCount", 0) or 0)
        if loaded <= 0:
            loaded = min(batch, total)
        elif ensure_next and loaded < total:
            loaded = min(total, loaded + batch)
        self.m3uLiveLoadedCount = loaded
        rows = []
        try:
            from .favorites import favourite_id, favourite_ids_for_kind
            live_fav_ids = favourite_ids_for_kind("live")
        except Exception:
            live_fav_ids = None
        for index, entry in enumerate((self.mediaItemsCurrent or [])[:loaded]):
            name = entry.get("name") or entry.get("title") or "Unnamed Channel"
            try:
                marked = (favourite_id(self.source, "live", entry) in live_fav_ids
                          if live_fav_ids is not None else
                          is_favourite(self.source, "live", entry))
                mark = "★  " if marked else ""
            except Exception: mark = ""
            rows.append(("%03d   %s%s" % (index + 1, mark, name), entry))
        self["list"].setList(rows)
        if rows:
            try: self["list"].moveToIndex(max(0, min(int(keep_index), len(rows)-1)))
            except Exception: pass
        try:
            shown = (int(keep_index)+1) if rows else 0
            self["pageInfo"].setText("%d / %d" % (shown, total))
        except Exception: pass
        self._repaintLiveList()
        return True

    def _ensureM3uNextLiveBatch(self):
        if self.kind != "live" or self.source.get("type") != "m3u" or self.focus != "items":
            return False
        total = len(self.mediaItemsCurrent or [])
        loaded = int(getattr(self, "m3uLiveLoadedCount", 0) or 0)
        if loaded <= 0 or loaded >= total:
            return False
        try: index = int(self["list"].getSelectedIndex() or 0)
        except Exception: index = 0
        if index < max(0, loaded - 1):
            return False
        self._renderM3uLiveBatch(index, ensure_next=True)
        return True

    def _renderStalkerLiveBatch(self, keep_index=0, ensure_next=False):
        """Ultra-style first paint for Stalker: render only one visible page."""
        if self.kind != "live" or self.source.get("type") != "stalker":
            return False
        total = len(self.mediaItemsCurrent or [])
        batch = 17
        loaded = int(getattr(self, "stalkerLiveLoadedCount", 0) or 0)
        if loaded <= 0:
            loaded = min(batch, total)
        elif ensure_next and loaded < total:
            loaded = min(total, loaded + batch)
        self.stalkerLiveLoadedCount = loaded
        rows = []
        try:
            from .favorites import favourite_id, favourite_ids_for_kind
            live_fav_ids = favourite_ids_for_kind("live")
        except Exception:
            live_fav_ids = None
        for index, entry in enumerate((self.mediaItemsCurrent or [])[:loaded]):
            name = entry.get("name") or entry.get("title") or "Unnamed Channel"
            try:
                marked = (favourite_id(self.source, "live", entry) in live_fav_ids
                          if live_fav_ids is not None else
                          is_favourite(self.source, "live", entry))
                mark = "★  " if marked else ""
            except Exception: mark = ""
            rows.append(("%03d   %s%s" % (index + 1, mark, name), entry))
        self["list"].setList(rows)
        if rows:
            try: self["list"].moveToIndex(max(0, min(int(keep_index), len(rows) - 1)))
            except Exception: pass
        try:
            shown = (int(keep_index) + 1) if rows else 0
            self["pageInfo"].setText("%d / %d" % (shown, total))
        except Exception: pass
        self._repaintLiveList()
        return True

    def _ensureStalkerNextLiveBatch(self):
        if self.kind != "live" or self.source.get("type") != "stalker" or self.focus != "items":
            return False
        total = len(self.mediaItemsCurrent or [])
        loaded = int(getattr(self, "stalkerLiveLoadedCount", 0) or 0)
        if loaded <= 0 or loaded >= total:
            return False
        try: index = int(self["list"].getSelectedIndex() or 0)
        except Exception: index = 0
        if index < max(0, loaded - 1):
            return False
        return self._renderStalkerLiveBatch(index, ensure_next=True)

    def showItems(self, items):
        items = [x for x in (items or []) if isinstance(x, dict)]
        if self.kind == "live" and self.source.get("type") in ("stalker", "xtream", "m3u"):
            hidden_state = _load_stalker_hidden(self.source) if self.source.get("type") == "stalker" else _load_xtream_hidden(self.source)
            items = [x for x in (items or []) if _live_item_id(x) not in hidden_state["channels"]]
        elif self.kind in ("vod", "series"):
            # One seen-set for the whole screen list, not one per visual page.
            # This prevents the same title reappearing on page 2/3/4.
            items = _dedupe_content_rows(items or [], self.kind)
            # Keep the user's Movies/TV Shows content order across packages and restarts.
            # First install/default is Latest, as requested.
            mode = self.sortMode if self.sortMode in ("default", "latest", "name", "rating") else "latest"
            if mode == "latest" and self.selectedCategory() != "__recent_added__":
                # Recent already has server-added-date ordering. The generic
                # movie-year/id fallback must never re-sort it per page.
                items = self._sortPackageNewest(items)
            elif mode == "name":
                items = sorted(items, key=lambda x: (x.get("name") or x.get("title") or "").lower())
            elif mode == "rating":
                def _content_rating(entry):
                    try: return float(entry.get("rating") or entry.get("rating_5based") or 0)
                    except Exception: return 0.0
                items = sorted(items, key=_content_rating, reverse=True)
        if self.kind == "live" and self.source.get("type") in ("stalker", "xtream", "m3u"):
            try: items = _apply_live_channel_order(self.source, self.selectedCategory(), items)
            except Exception: pass
        self.mediaItemsCurrent = items or []
        self.pageStart = 0
        self.posterIndex = 0
        if self.kind == "live":
            self._resetStalkerVisibleEpg()
            # r461: Xtream list itself is lazy-rendered in 15-row batches.
            # Do not push the whole bouquet into MenuList at open time.
            if self.source.get("type") == "xtream":
                self.xtreamLiveLoadedCount = 0
                self._renderXtreamLiveBatch(0, ensure_next=False)
            elif self.source.get("type") == "m3u":
                self.m3uLiveLoadedCount = 0
                self._renderM3uLiveBatch(0, ensure_next=False)
            else:
                self.stalkerLiveLoadedCount = 0
                self._renderStalkerLiveBatch(0, ensure_next=False)
            self.focus = "items"
            self._loadedLiveCategoryKey = str(self.selectedCategory() or "")
            # The category screen must render all channels; never auto-open a player.
            try:
                current = next((entry for entry in self.categories if str(entry.get("category_id", "")) == str(self.selectedCategory())), None)
                if current:
                    self["categoryTitle"].setText(current.get("category_name") or "القنوات")
                self["pageInfo"].setText("1 / %d" % len(self.mediaItemsCurrent) if self.mediaItemsCurrent else "0 / 0")
            except Exception:
                pass
            if not getattr(self, "_windowsVisible", False):
                self.previewLive()
                self._refreshLiveEpgBadges()
                self._warmLiveBadgeCache()
            self._queueWindowsAutoOpen()
        else:
            self.renderPosterPage()


    def current(self):
        if self.kind=="live":
            if self.focus != "items": return None
            c=self["list"].getCurrent(); return c[1] if c else None
        idx=self.pageStart+self.posterIndex
        return self.mediaItemsCurrent[idx] if 0 <= idx < len(self.mediaItemsCurrent) else None

    def _setLiveEpgProgressVisible(self, visible):
        if self.kind != "live":
            return
        try:
            if visible:
                self["liveProgress"].show()
            else:
                self["liveProgress"].hide()
        except Exception:
            pass

    def _cachedLiveProgrammeTitle(self, item):
        """Read a current programme name from already available EPG RAM only.

        Never ask a portal/network or perform a TMDb search on a remote keypress.
        A missing EPG title is resolved by the existing deferred EPG mechanism.
        """
        if self.kind != "live" or not isinstance(item, dict):
            return ""
        try:
            row_source = item.get("_favorite_source") or self.source or {}
            source_type = str(row_source.get("type") or "").lower()
            shared_rows = _shared_live_epg_cached(row_source, item)
            if shared_rows:
                if source_type == "stalker":
                    selected, _next = _shared_stalker_now_next(shared_rows)
                    if selected:
                        return self._cleanLiveProgrammeTitle(selected[2].get("name") or selected[2].get("title") or "")
                elif source_type == "xtream":
                    now_ts = int(time.time())
                    selected = next((r for r in shared_rows if
                        self._epgTimestamp(r, True) <= now_ts <
                        (self._epgTimestamp(r, False) or self._epgTimestamp(r, True) + 3600)), shared_rows[0])
                    return self._cleanLiveProgrammeTitle(self._decodeEpgText(
                        selected.get("title") or selected.get("name") or selected.get("programme") or ""))
            if item.get("_favorite_source"):
                return ""  # Never read another source's channel ID from parent cache.
            
            if source_type == "stalker":
                rows = self.stalkerShortEpgResults.get(self._stalkerEpgChannelId(item)) or []
                current, _next = self._stalkerCurrentNext(rows)
                if current:
                    return self._cleanLiveProgrammeTitle(current[2].get("name") or current[2].get("title") or "")
            elif source_type == "xtream":
                rows = self._xtreamCachedShortEpg(item, max_age=900)
                if rows:
                    now_ts = int(time.time())
                    # Prefer an event active now. Some panels shift timestamps;
                    # like _applyXtreamShortEpgRows, fall back to the first row.
                    selected = rows[0]
                    for row in rows:
                        begin = self._epgTimestamp(row, True)
                        end = self._epgTimestamp(row, False)
                        if begin and begin <= now_ts < (end or begin + 3600):
                            selected = row
                            break
                    return self._cleanLiveProgrammeTitle(self._decodeEpgText(selected.get("title") or selected.get("name") or selected.get("programme") or ""))
        except Exception:
            pass
        return ""

    def _cancelPendingLiveSelection(self):
        """Never let an old channel preview retune after leaving its selection."""
        if getattr(self, "_livePreviewPendingIdentity", None) is None:
            return
        self._cancelLiveZapResolve()
        # Ultra Live cursor changes cancel obsolete link callbacks, but never
        # stop the already-starting decoder solely because the focus moved.
        self._cancelLivePreviewCheck(stop_failed=False)
        self._livePreviewPendingIdentity = None
        self._livePreviewOkIdentity = None
        self._liveFullscreenRequestedIdentity = None

    def previewLive(self):
        item = self.current()
        # Normal Live: a pending create_link belongs to the exact channel
        # selected on first OK. Changing row or package must retire that link
        # immediately. Previously the old worker could finish *after* focus
        # changed and retune the previous channel behind the user's cursor.
        # Windows has its own focus-token cancellation in _focusChanged().
        pending_identity = getattr(self, "_livePreviewPendingIdentity", None)
        if pending_identity is not None and pending_identity != self._selectedLiveOkIdentity(item):
            self._cancelPendingLiveSelection()
        # Leaving an unstarted Stalker service must release its decoder
        # rather than keep a native Loading spinner over the next channel.
        checking = getattr(self, "_livePreviewCheck", None)
        if checking is not None:
            selected_id = str((item or {}).get("stream_id") or (item or {}).get("ch_id") or
                              (item or {}).get("id") or (item or {}).get("cmd") or
                              (item or {}).get("name") or "")
            if (selected_id != checking["channel"] or
                    _source_identity(self.source) != checking["source"]):
                # Ultra only cancels stale callbacks during selection changes.
                # The playing PiG/decoder is retained until explicit new OK.
                self._cancelLivePreviewCheck(stop_failed=False)
        # Up/Down or package change starts a fresh two-OK sequence.
        if self._selectedLiveOkIdentity(item) != getattr(self, "_livePreviewOkIdentity", None):
            self._livePreviewOkIdentity = None
        if self._selectedLiveOkIdentity(item) != getattr(self, '_liveFullscreenRequestedIdentity', None):
            self._liveFullscreenRequestedIdentity = None
        if not item:
            return
        # Cancel artwork from the previous selected channel immediately. Reuse
        # cached EPG artwork before the deferred network EPG request begins.
        self._setLiveEpgProgressVisible(False)
        self._clearLiveTmdbDetails()
        if str(item.get("name") or item.get("title") or "").lstrip().startswith("####") or item.get("_stalker_placeholder"):
            self._scheduleLivePoster({}, "")
        else:
            self._scheduleLivePoster(item, self._cachedLiveProgrammeTitle(item))

        # r523: rows beginning with #### are package/separator labels inside
        # the channel list, not playable channels. Show only their label and
        # suppress all channel information work for that selection.
        item_title = str(item.get("name") or item.get("title") or "")
        if item_title.lstrip().startswith("####"):
            try:
                self.stalkerSelectionEpgTimer.stop()
            except Exception:
                pass
            try:
                self["channelTitle"].setText(item_title)
                self["meta"].setText("")
                self["desc"].setText("")
            except Exception:
                pass
            for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
                try:
                    self[key].setText("")
                except Exception:
                    pass
            try:
                self["liveProgress"].setValue(0)
            except Exception:
                pass
            for key in ("channelPicon", "livePoster"):
                try:
                    self[key].hide()
                except Exception:
                    pass
            self._clearLiveTmdbDetails()
            return

        # EStalker progressive page load.
        if self.source.get("type") == "stalker":
            self._ensureStalkerLiveCurrentPage()
            if item.get("_stalker_placeholder"):
                try:
                    self["channelTitle"].setText("")
                    self["meta"].setText("")
                    self["desc"].setText("")
                    self["channelPicon"].hide()
                    self["livePoster"].hide()
                except Exception:
                    pass
                self._clearLiveTmdbDetails()
                return

        self["channelTitle"].setText(item.get("name") or item.get("title") or "Unnamed Channel")
        self["meta"].setText("")

        # EStalker: clear old Picon then debounce current one for 250 ms.
        self._showLivePicon(item)

        if self.source.get("type") == "stalker":
            # r535: never resolve EPG while the selection is moving. Clear the
            # previous row cheaply and wait 5 seconds on the final highlighted
            # channel before doing the existing EPG lookup.
            for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
                try:
                    self[key].setText("")
                except Exception:
                    pass
            try:
                self["liveProgress"].setValue(0)
            except Exception:
                pass
            try:
                # RAM hit: draw now. Ultra EPG wave: begin without waiting
                # for a fixed 450ms selection debounce to expire.
                self._applyStalkerShortEpg(item)
                if not getattr(self, "_windowsVisible", False):
                    self._prefetchStalkerVisibleEpg()
            except Exception:
                pass

            # Cached programme artwork is allowed during fast Stalker browsing.
            # Uncached EPG/network lookups remain deferred by the existing timer.
        else:
            if self.source.get("type") == "xtream":
                # r462: do not run EPG lookup while Up/Down is moving. Clear the
                # previous channel's programme text cheaply, then let the existing
                # 5-second selection timer resolve only the final highlighted row.
                for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
                    try:
                        self[key].setText("")
                    except Exception:
                        pass
                try:
                    self["liveProgress"].setValue(0)
                except Exception:
                    pass
                try:
                    self["desc"].setText((item.get("plot") or item.get("description") or "").strip())
                except Exception:
                    pass
                try:
                    self.stalkerSelectionEpgTimer.stop()
                    self.stalkerSelectionEpgTimer.start(450, True)
                except Exception:
                    self._runStalkerSelectionEpg()
            else:
                self._updateLiveEpg(item)
                self._scheduleLivePoster(item)

        try:
            index = self["list"].getSelectedIndex() + 1
            total = self.stalkerLiveTotal if self.source.get("type") == "stalker" and self.stalkerLiveTotal else len(self.mediaItemsCurrent)
            self["pageInfo"].setText("%d / %d" % (index, total))
        except Exception:
            pass

        try:
            self.zapTimer.stop()
        except Exception:
            pass

    def _resetStalkerVisibleEpg(self):
        if self.kind != "live": return
        try:
            cancel = getattr(self, "stalkerEpgCancel", None)
            if cancel is not None:
                cancel.set()
        except Exception:
            pass
        self.stalkerEpgCancel = None
        self.stalkerEpgBatchKey = None
        self.stalkerEpgInFlight = ()
        self.stalkerEpgChannelRows = {}
        self.stalkerEpgGeneration = int(getattr(self, "stalkerEpgGeneration", 0) or 0) + 1
        self.stalkerEpgDownloadedChannels = set()
        # Positive indicators are kept in the small source-scoped shared cache.
        # Full EPG rows can be cleared here to bound memory across bouquets.
        self.stalkerShortEpgResults = {}
        self.stalkerEpgPending = []
        self.stalkerEpgBatchRunning = False
        try: self.stalkerEpgApplyTimer.stop()
        except Exception: pass

    def _stalkerEpgChannelId(self, item):
        return str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or "").strip()

    def _stalkerVisibleChannelIds(self, visible_rows=None):
        """Feed Ultra the selected/visible page, never all portal channels.

        Windows passes its actual ten grid rows. Standard Live passes the
        fifteen-item page containing the focused channel. Only provider IDs
        (ch_id first, not stream command) are acceptable EPG identifiers.
        """
        if self.kind != "live" or self.source.get("type") != "stalker":
            return []
        if visible_rows is None:
            rows = self.mediaItemsCurrent or []
            try:
                selected = max(0, int(self["list"].getSelectedIndex() or 0))
            except Exception:
                selected = 0
            start = (selected // 15) * 15
            visible_rows = ([rows[selected]] if selected < len(rows) else []) + list(rows[start:start + 15])
        visible, seen = [], set()
        for item in visible_rows:
            if not isinstance(item, dict) or item.get("_stalker_placeholder"):
                continue
            if str(item.get("name") or "").lstrip().startswith("####"):
                continue
            ch_id = self._stalkerEpgChannelId(item)
            if ch_id and ch_id not in seen:
                seen.add(ch_id)
                visible.append(ch_id)
        return visible

    def _stalkerCleanDescription(self, descr):
        value=str(descr or "").replace("\\r\\n","\\n")
        match=re.search(r"Description:\\s*(.+)",value,re.DOTALL)
        if not match: return value.strip()
        description=match.group(1)
        for label in ("Credits:","Director:","Producer:","Actor:","Category:"):
            pos=description.find(label)
            if pos!=-1:
                description=description[:pos]; break
        return description.strip()

    def _stalkerPortalLocalTimestamp(self, value):
        if value in (None,""): return 0
        try:
            if isinstance(value,(int,float)): return int(value)
        except Exception: pass
        raw=str(value or "").strip()
        try: return int(float(raw))
        except Exception: pass
        try: return int(time.mktime(time.strptime(raw[:19],"%Y-%m-%d %H:%M:%S")))
        except Exception: return 0

    def _storeStalkerShortEpg(self, entries):
        grouped={}
        for entry in entries or []:
            if not isinstance(entry,dict): continue
            ch_id=str(entry.get("ch_id") or "").strip()
            if not ch_id or ch_id=="None": continue
            grouped.setdefault(ch_id,[]).append(dict(entry))
        for ch_id,rows in grouped.items():
            self.stalkerShortEpgResults[ch_id]=rows
            _live_epg_mark_known(self.source, ch_id, rows)
            try:
                # Ultra batches only visible channels; use the prepared O(1)
                # ID lookup, never scan an entire 10,000-channel bouquet for
                # each completed programme.
                item = self.stalkerEpgChannelRows.get(ch_id)
                if item:
                    _shared_live_epg_remember(self.source, item, rows)
                    _shared_epg_finish(self.source, [item])
            except Exception:
                pass
            try: self.stalkerEpgNoDataUntil.pop(ch_id, None)
            except Exception: pass
        return bool(grouped)

    def _stalkerCurrentNext(self, rows):
        # Same Stalker programme selection as Windows and full-screen Infobar.
        return _shared_stalker_now_next(rows)

    def _applyStalkerShortEpg(self, item, fallback=""):
        rows=self.stalkerShortEpgResults.get(self._stalkerEpgChannelId(item)) or []
        current,upcoming=self._stalkerCurrentNext(rows)
        if not current: return False
        now=int(time.time()); begin,stop,row=current; duration=max(0,stop-begin)
        title=ultra_epg_title(row)
        desc=self._stalkerCleanDescription(row.get("descr") or row.get("description") or row.get("desc") or "")
        self["epgNowTime"].setText(str(row.get("t_time") or "").strip() or
                                   (self._formatEpgTime(begin,duration) if begin else ""))
        self["epgNowTitle"].setText(title)
        self._scheduleLivePosterForResolvedEpg(title)
        percent=min(100,max(0,int(((now-begin)*100)/duration))) if duration>0 else 0
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self["epgProgressText"].setText("%d%%"%percent)
        self._setLiveEpgProgressVisible(bool(title and begin and duration))
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            nb,ns,nrow=upcoming; nd=max(0,ns-nb)
            self["epgNextTime"].setText(str(nrow.get("t_time") or "").strip() or
                                        (self._formatEpgTime(nb,nd) if nb else ""))
            self["epgNextTitle"].setText(ultra_epg_title(nrow))
        else:
            self["epgNextTime"].setText(""); self["epgNextTitle"].setText("")
        return True

    def _queueStalkerEpgUpdate(self, kind, payload, generation):
        try:
            with self.stalkerEpgLock:
                self.stalkerEpgPending.append((kind,payload,generation))
        except Exception: pass

    def _drainStalkerEpgUpdates(self):
        """The E2 GUI is the sole writer of on-screen EPG widgets.

        Ultra invokes on_each from worker threads. They only enqueue rows;
        this timer applies each completed channel immediately on the UI thread.
        """
        try:
            with self.stalkerEpgLock:
                pending = list(self.stalkerEpgPending)
                self.stalkerEpgPending[:] = []
        except Exception:
            pending = []
        changed, done_seen = False, False
        for kind, payload, generation in pending:
            if generation != self.stalkerEpgGeneration:
                continue
            if kind == "partial":
                records = (payload or {}).get("js", [])
                if records:
                    changed = self._storeStalkerShortEpg(records) or changed
            elif kind == "done":
                done_seen = True
                try:
                    _shared_epg_finish(self.source, [self.stalkerEpgChannelRows[cid]
                        for cid in self.stalkerEpgInFlight if cid in self.stalkerEpgChannelRows])
                except Exception:
                    pass
                for ch_id in (payload or {}).get("failed_ids", []):
                    ch_id = str(ch_id)
                    self.stalkerEpgDownloadedChannels.discard(ch_id)
                    retry = (payload or {}).get("retry_after", {}).get(ch_id, 75)
                    try:
                        retry = max(20, min(120, int(retry)))
                    except Exception:
                        retry = 75
                    self.stalkerEpgNoDataUntil[ch_id] = time.time() + retry
                self.stalkerEpgBatchRunning = False
                self.stalkerEpgCancel = None
                self.stalkerEpgInFlight = ()
        if changed:
            # Repaint from RAM; never trigger a new portal request on this path.
            try:
                if not getattr(self, "_windowsVisible", False):
                    item = self.current()
                    if item and self.source.get("type") == "stalker":
                        self._applyStalkerShortEpg(item, (item.get("plot") or item.get("description") or "").strip())
                self._refreshLiveEpgBadges()
            except Exception:
                pass
            try:
                window = getattr(self, "_windowsScreen", None)
                if window is not None and not window._closed:
                    window._windowsApplyUltraEpg()
            except Exception:
                pass
        if done_seen:
            # A new page may have been selected while this wave finished.
            try:
                window = getattr(self, "_windowsScreen", None)
                if window is not None and not window._closed and not window._packagesOpen:
                    begin = window.page * window.PAGE_SIZE
                    self._prefetchStalkerVisibleEpg(visible_rows=window.grid_items[begin:begin + window.PAGE_SIZE])
                elif not getattr(self, "_windowsVisible", False):
                    self._prefetchStalkerVisibleEpg()
            except Exception:
                pass
        if getattr(self, "_stalkerEpgPausedForPlay", False) and not self.stalkerEpgBatchRunning:
            # The explicit user Play action wins until create_link resolves.
            # Never block the E2 UI thread while waiting.
            try:
                if (getattr(self, "liveZapResolveHandle", None) is not None and
                        time.monotonic() < float(getattr(self, "liveZapResolveDeadline", 0) or 0)):
                    self.stalkerEpgApplyTimer.start(200, True)
                else:
                    self._stalkerEpgPausedForPlay = False
                    self._prefetchStalkerVisibleEpg()
            except Exception:
                self._stalkerEpgPausedForPlay = False
        if self.stalkerEpgBatchRunning or self.stalkerEpgPending:
            try:
                self.stalkerEpgApplyTimer.start(100, True)
            except Exception:
                pass

    def _stalkerWindowsVisibleEpgPage(self):
        """Whether Windows owns a visible, playable Stalker channel page.

        The ten-channel Ultra EPG wave is part of painting this page, not a
        speculative background job.  Previewing its selected channel must
        not cancel that wave; a genuine page/bouquet change still retires it
        via the generation + cancellation guard in _prefetchStalkerVisibleEpg.
        """
        window = getattr(self, "_windowsScreen", None)
        return bool(self.kind == "live" and
                    (self.source or {}).get("type") == "stalker" and
                    getattr(self, "_windowsVisible", False) and
                    window is not None and
                    not getattr(window, "_closed", True) and
                    not getattr(window, "_packagesOpen", True) and
                    getattr(window, "_bouquetIdPending", None) is None)

    def _suspendStalkerEpgForLiveLink(self):
        """Cancel bulk guide traffic while the viewer opens a Stalker stream.

        An Ultra create_link request must never sit behind six speculative EPG
        HTTP calls on a fragile/free portal. The 100ms UI poll resumes guide
        work after the link request completes or its deadline expires.
        """
        if self.kind != "live" or (self.source or {}).get("type") != "stalker":
            return
        # Windows requests the guide for exactly its ten visible cards as
        # soon as a bouquet opens.  Cancelling it for the PiG preview 100 ms
        # later makes every bouquet appear to have missing EPG.  Keep this
        # already-running Ultra wave alive; its independent workers cannot
        # block the Enigma GUI.  Normal Live/full-screen keeps the old rule.
        if self._stalkerWindowsVisibleEpgPage():
            return
        self._stalkerEpgPausedForPlay = True
        try:
            if self.stalkerEpgCancel is not None:
                self.stalkerEpgCancel.set()
            _shared_epg_finish(self.source, [self.stalkerEpgChannelRows[cid]
                for cid in self.stalkerEpgInFlight if cid in self.stalkerEpgChannelRows])
            for channel_id in getattr(self, "stalkerEpgInFlight", ()):
                if not self.stalkerShortEpgResults.get(channel_id):
                    self.stalkerEpgDownloadedChannels.discard(channel_id)
            self.stalkerEpgGeneration += 1
            self.stalkerEpgBatchRunning = False
            self.stalkerEpgCancel = None
            self.stalkerEpgInFlight = ()
            with self.stalkerEpgLock:
                self.stalkerEpgPending[:] = []
            self.stalkerEpgApplyTimer.start(200, True)
        except Exception:
            pass

    def _prefetchStalkerVisibleEpg(self, visible_rows=None):
        """Use the actual UltraStalker six-lane epg_many() implementation.

        This replaces TiviMate's separate two-worker short_epg_batch path.
        Positive results are published per channel, so an unresponsive MAG
        channel cannot delay EPG for every other visible card.
        """
        if self.kind != "live" or self.source.get("type") != "stalker":
            return False
        # Ultra's Live grid resolves the selected create_link with TASKS while
        # guide data remains an independent job. TiviMate already has a
        # dedicated playback executor separate from its EPG executor: never
        # pause/restart guide work solely because the viewer pressed OK.
        # Keep the existing per-page limits and cache-first EPG behavior.
        self._stalkerEpgPausedForPlay = False
        # A hidden normal Live list must not cancel the active Windows wave.
        if visible_rows is None and getattr(self, "_windowsVisible", False):
            window = getattr(self, "_windowsScreen", None)
            if window is None or window._closed or window._packagesOpen:
                return False
            start = window.page * window.PAGE_SIZE
            visible_rows = window.grid_items[start:start + window.PAGE_SIZE]
        # Ultra submits the focused Live channel first.  Preserve each page's
        # existing 10/15-row request limits, but prioritize the highlighted
        # Windows card inside the same six-lane epg_many wave.  The sorted
        # batch identity below remains unchanged by cursor motion.
        if visible_rows is not None and self._stalkerWindowsVisibleEpgPage():
            try:
                active_window = self._windowsScreen
                focused_row = active_window.grid_items[active_window.focusIndex]
                focused_id = self._stalkerEpgChannelId(focused_row)
                if focused_id:
                    ordered_rows = list(visible_rows)
                    for pos, row in enumerate(ordered_rows):
                        if self._stalkerEpgChannelId(row) == focused_id:
                            if pos:
                                ordered_rows.insert(0, ordered_rows.pop(pos))
                            visible_rows = ordered_rows
                            break
            except (AttributeError, IndexError, TypeError, ValueError):
                pass
        visible = self._stalkerVisibleChannelIds(visible_rows=visible_rows)
        if not visible:
            return False
        src = self.source or {}
        scope = (str(src.get("url") or src.get("portal") or src.get("host") or ""),
                 str(src.get("mac") or src.get("mac_address") or ""))
        if getattr(self, "stalkerEpgNoDataSource", None) != scope:
            self.stalkerEpgNoDataSource = scope
            self.stalkerEpgNoDataUntil = {}
        now = time.time()
        for ch_id, expiry in list(self.stalkerEpgNoDataUntil.items()):
            if expiry <= now:
                self.stalkerEpgNoDataUntil.pop(ch_id, None)
        # Ignore cursor order inside the same visible page. Cancelling the
        # six-lane Ultra wave on every Up/Down would recreate the old lag.
        batch_key = (scope, tuple(sorted(visible)))
        if self.stalkerEpgBatchRunning:
            if batch_key == getattr(self, "stalkerEpgBatchKey", None):
                return True
            # Prior page must not compete with playback or paint stale EPG.
            try:
                if self.stalkerEpgCancel is not None:
                    self.stalkerEpgCancel.set()
                _shared_epg_finish(self.source, [self.stalkerEpgChannelRows[cid]
                    for cid in self.stalkerEpgInFlight if cid in self.stalkerEpgChannelRows])
            except Exception:
                pass
            for old_id in getattr(self, "stalkerEpgInFlight", ()):
                if not self.stalkerShortEpgResults.get(old_id):
                    self.stalkerEpgDownloadedChannels.discard(old_id)
            self.stalkerEpgInFlight = ()
            self.stalkerEpgGeneration += 1
            self.stalkerEpgBatchRunning = False
            with self.stalkerEpgLock:
                self.stalkerEpgPending[:] = []
        if visible_rows is None:
            try:
                selected = max(0, int(self["list"].getSelectedIndex() or 0))
            except Exception:
                selected = 0
            rows = self.mediaItemsCurrent or []
            start = (selected // 15) * 15
            visible_rows = rows[start:start + 15]
        self.stalkerEpgChannelRows = {
            self._stalkerEpgChannelId(row): row for row in visible_rows
            if isinstance(row, dict) and not row.get("_stalker_placeholder")
        }
        # Returning to a bouquet must reuse the same positive Ultra EPG that
        # Windows/Infobar already saw. _resetStalkerVisibleEpg clears the local
        # table between bouquets, but the source/channel-scoped RAM bridge is
        # intentionally retained. Rehydrate the visible page before deciding
        # which IDs need network access; never extend the cache TTL here.
        for cached_id in visible:
            if self.stalkerShortEpgResults.get(cached_id):
                continue
            cached_row = self.stalkerEpgChannelRows.get(cached_id)
            if not cached_row:
                continue
            try:
                cached_guide = _shared_live_epg_cached(self.source, cached_row)
                if cached_guide:
                    self.stalkerShortEpgResults[cached_id] = cached_guide
            except Exception:
                pass
        fetch = [ch_id for ch_id in visible
                 if ch_id not in self.stalkerEpgDownloadedChannels
                 and ch_id not in self.stalkerEpgNoDataUntil
                 and not (self.stalkerShortEpgResults.get(ch_id) or [])]
        self.stalkerEpgBatchKey = batch_key
        if not fetch:
            return True
        if self.stalkerEpgClient is None:
            try:
                self.stalkerEpgClient = StalkerClient(dict(self.source))
            except Exception:
                self.stalkerEpgClient = None
        client = self.stalkerEpgClient
        ultra = getattr(client, "_ultra_client", None) if client is not None else None
        if ultra is None or not hasattr(ultra, "epg_many"):
            # No silent two-worker fallback: report missing Ultra interface.
            for ch_id in fetch:
                self.stalkerEpgNoDataUntil[ch_id] = now + 45
            return False
        for ch_id in fetch:
            self.stalkerEpgDownloadedChannels.add(ch_id)
        self.stalkerEpgInFlight = tuple(fetch)
        try:
            _shared_epg_begin(self.source, [self.stalkerEpgChannelRows[ch_id]
                for ch_id in fetch if ch_id in self.stalkerEpgChannelRows])
        except Exception:
            pass
        generation = self.stalkerEpgGeneration
        cancel_event = threading.Event()
        self.stalkerEpgCancel = cancel_event
        self.stalkerEpgBatchRunning = True

        def on_each(ch_id, rows):
            if cancel_event.is_set() or generation != self.stalkerEpgGeneration:
                return
            records = []
            for row in rows or []:
                if isinstance(row, dict):
                    normalized = dict(row)
                    # Ultra has already validated any returned channel ID.
                    # Portals that emit ch_id=0 must still index the requested
                    # channel in TiviMate's in-memory guide.
                    normalized["ch_id"] = str(ch_id)
                    records.append(normalized)
            # A valid empty guide gets a cooldown; do not retry on every arrow.
            if records:
                self._queueStalkerEpgUpdate("partial", {"js": records}, generation)

        def run():
            result = {}
            try:
                result = ultra.epg_many(fetch, hours=10,
                                        cancel_event=cancel_event,
                                        on_each=on_each) or {}
            except Exception:
                pass
            if cancel_event.is_set():
                return
            failed = [ch_id for ch_id in fetch if not result.get(ch_id)]
            # A confirmed empty portal guide is not permanent. Retry on a
            # subsequent visit without hammering the portal on every arrow.
            retry = {ch_id: (45 if ch_id in result else 30) for ch_id in failed}
            self._queueStalkerEpgUpdate("done", {
                "failed_ids": failed, "retry_after": retry
            }, generation)

        try:
            thread = threading.Thread(target=run, name="TiviMateUltraVisibleEPG", daemon=True)
            thread.start()
            self.stalkerEpgApplyTimer.start(80, True)
            return True
        except Exception:
            cancel_event.set()
            self.stalkerEpgBatchRunning = False
            self.stalkerEpgCancel = None
            self.stalkerEpgInFlight = ()
            for ch_id in fetch:
                self.stalkerEpgDownloadedChannels.discard(ch_id)
            return False

    def _xtreamEpgChannelId(self, item):
        return str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or (item or {}).get("channel_id") or "").strip()

    def _xtreamVisibleItems(self):
        if self.kind != "live" or self.source.get("type") != "xtream":
            return []
        rows = self.mediaItemsCurrent or []
        try:
            current_index = int(self["list"].getSelectedIndex() or 0)
        except Exception:
            current_index = 0
        start = (current_index // 15) * 15
        visible = []
        seen = set()
        page_rows = list(rows[start:start + 15])
        # Fetch the highlighted channel first. This mirrors the perceived
        # Stalker behaviour: the row the user is looking at wins priority,
        # while the remaining visible rows warm in the background.
        selected = rows[current_index] if 0 <= current_index < len(rows) else None
        ordered = ([selected] if isinstance(selected, dict) else []) + page_rows
        for item in ordered:
            if not isinstance(item, dict):
                continue
            ch_id = self._xtreamEpgChannelId(item)
            if ch_id and ch_id not in seen:
                seen.add(ch_id)
                visible.append(dict(item))
        return visible

    def _xtreamCachedShortEpg(self, item, max_age=900):
        ch_id = self._xtreamEpgChannelId(item)
        if not ch_id:
            return []
        try:
            with self.xtreamEpgLock:
                cached = self.xtreamShortEpgResults.get(ch_id)
        except Exception:
            cached = None
        if not cached:
            return []
        try:
            stamp, rows = cached
            if max_age is not None and (time.time() - float(stamp or 0)) > float(max_age):
                return []
            return [dict(row) for row in (rows or []) if isinstance(row, dict)]
        except Exception:
            return []

    def _storeXtreamShortEpg(self, item, rows):
        clean = [dict(row) for row in (rows or []) if isinstance(row, dict)]
        if not clean:
            return False
        ch_id = self._xtreamEpgChannelId(item)
        if not ch_id:
            return False
        try:
            _live_epg_mark_known(self.source, ch_id, clean)
            with self.xtreamEpgLock:
                self.xtreamShortEpgResults[ch_id] = (time.time(), clean)
                if len(self.xtreamShortEpgResults) > 120:
                    oldest = sorted(self.xtreamShortEpgResults.items(), key=lambda kv: float((kv[1] or (0,))[0] or 0))[:30]
                    for key, _value in oldest:
                        self.xtreamShortEpgResults.pop(key, None)
            return True
        except Exception:
            return False

    def _getXtreamEpgClient(self):
        source = dict(_bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source)
        try:
            client = self.xtreamEpgClient
            if client is not None and getattr(client, "base", "") == str(source.get("url") or "").rstrip("/") and getattr(client, "user", "") == str(source.get("username") or ""):
                return client
        except Exception:
            pass
        try:
            self.xtreamEpgClient = XtreamClient(source)
        except Exception:
            self.xtreamEpgClient = None
        return self.xtreamEpgClient

    def _prefetchXtreamVisibleEpg(self):
        """r460: disabled for Xtream Live.

        Do not batch-fetch the visible 15 rows while the user scrolls. Each
        highlighted channel may use its own non-blocking short_epg fallback;
        the list itself never waits for EPG.
        """
        return False

    def _formatEpgTime(self, begin, duration=0):
        try:
            start = time.strftime("%H:%M", time.localtime(int(begin)))
            if duration:
                end = time.strftime("%H:%M", time.localtime(int(begin) + int(duration)))
                return "%s - %s" % (start, end)
            return start
        except Exception:
            return ""

    def _decodeEpgText(self, value):
        value = value or ""
        if not isinstance(value, str):
            try: value = str(value)
            except Exception: return ""
        # Xtream panels commonly return title/description as base64, but some
        # providers already return plain UTF-8. Decode only when it is valid.
        try:
            raw = value.strip()
            if raw and len(raw) % 4 == 0:
                decoded = base64.b64decode(raw).decode("utf-8", "replace").strip()
                if decoded and any(ch.isalnum() for ch in decoded):
                    return decoded
        except Exception:
            pass
        return value.strip()

    def _epgTimestamp(self, row, start=True):
        keys = ("start_timestamp", "start", "begin_timestamp", "begin") if start else ("stop_timestamp", "end", "end_timestamp", "stop")
        for key in keys:
            value = row.get(key)
            if value in (None, ""):
                continue
            try:
                return int(float(value))
            except Exception:
                try:
                    # Common panel format: 2026-08-02 03:30:00
                    return int(time.mktime(time.strptime(str(value)[:19], "%Y-%m-%d %H:%M:%S")))
                except Exception:
                    pass
        return 0

    def _applyXtreamShortEpgRows(self, rows, fallback="", error=""):
        """Apply Xtream short_epg rows on the GUI thread.

        r441 keeps parsing/display separate from networking so the selected
        channel can consume the same prefetch cache instead of racing a second
        direct request/token.
        """
        now_ts = int(time.time())
        parsed = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            begin = self._epgTimestamp(row, True)
            end = self._epgTimestamp(row, False)
            duration = max(0, end - begin)
            title = self._decodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            desc = self._decodeEpgText(row.get("description") or row.get("desc") or row.get("plot"))
            if begin and title:
                parsed.append((begin, duration, title, desc))
        parsed.sort(key=lambda x: x[0])
        current = None
        upcoming = None
        for event in parsed:
            begin, duration, title, desc = event
            finish = begin + duration if duration else begin + 3600
            if begin <= now_ts < finish:
                current = event
            elif begin > now_ts and upcoming is None:
                upcoming = event
        if current is None and parsed:
            # Xtream panels may return short_epg times in the panel clock.
            # Anchor the first returned (current) row to receiver time using a
            # rounded 15-minute offset, then keep the rest of the rows in the
            # same relative schedule. This prevents a valid current programme
            # from showing 0%% progress simply because its raw clock is shifted.
            fb, fd, _ft, _fx = parsed[0]
            finish = fb + (fd if fd > 0 else 3600)
            if not (fb <= now_ts < finish):
                duration_for_anchor = fd if fd > 0 else 3600
                provider_position = fb + int(duration_for_anchor / 2)
                raw_offset = now_ts - provider_position
                quantum = 15 * 60
                offset = int(round(float(raw_offset) / quantum) * quantum)
                parsed = [(b + offset, d, t, x) for b, d, t, x in parsed]
            current = parsed[0]
            upcoming = parsed[1] if len(parsed) > 1 else upcoming
        if not current:
            return False
        begin, duration, title, desc = current
        self._refreshLiveEpgBadges()
        self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
        self["epgNowTitle"].setText(title)
        self._scheduleLivePosterForResolvedEpg(title)
        elapsed = max(0, now_ts - begin)
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        self["epgProgressText"].setText("%d%%" % percent)
        try:
            self["liveProgress"].setValue(percent)
        except Exception:
            pass
        self._setLiveEpgProgressVisible(bool(title))
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            ub, ud, ut, _ = upcoming
            self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
            self["epgNextTitle"].setText(ut or "")
        else:
            self["epgNextTime"].setText("")
            self["epgNextTitle"].setText("")
        return True

    def _startXtreamSelectedEpg(self, item, fallback=""):
        """Start one priority Xtream short_epg request for the highlighted row.

        r443 deliberately keeps this independent from visible-page prefetch so
        a busy/finishing batch can never prevent the selected channel request.
        Repeated UI refreshes for the same channel reuse the in-flight request.
        """
        ch_id = self._xtreamEpgChannelId(item)
        if not ch_id:
            return False
        self.xtreamDirectEpgSelected = ch_id
        self.xtreamDirectEpgFallback = fallback or ""
        cached = self._xtreamCachedShortEpg(item, max_age=900)
        if cached:
            return self._applyXtreamShortEpgRows(cached, fallback)
        if time.time() < float(getattr(self, "xtreamEpgMissUntil", {}).get(ch_id, 0) or 0):
            self["epgNowTitle"].setText(tr("No EPG data"))
            self["desc"].setText(fallback or "")
            return True
        launch = False
        try:
            with self.xtreamEpgLock:
                if ch_id not in self.xtreamDirectEpgInFlight:
                    self.xtreamDirectEpgInFlight.add(ch_id)
                    self.xtreamDirectEpgResults.pop(ch_id, None)
                    launch = True
        except Exception:
            launch = True
        if launch:
            source = dict(_bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source)
            lookup_source = dict(self.source or {})
            request_item = dict(item)
            def worker():
                rows = []
                error = ""
                try:
                    client = self._getXtreamEpgClient()
                    if client is None:
                        raise RuntimeError("Xtream EPG client unavailable")
                    epg_channel_id = str(request_item.get("epg_channel_id") or request_item.get("tvg_id") or request_item.get("epg_id") or "").strip()
                    rows = client.short_epg(ch_id, limit=10, epg_channel_id=epg_channel_id, single_request=True) or []
                    if not isinstance(rows, list):
                        rows = []
                    if rows:
                        self._storeXtreamShortEpg(request_item, rows)
                except Exception as exc:
                    error = str(exc)
                    rows = []
                # The XMLTV fallback may parse a large HDD EPG JSON. Never do
                # it on Enigma2's GUI thread when the short API returns empty.
                local_events = (None, None)
                if not rows:
                    try:
                        local_events = lookup_channel_epg(lookup_source, request_item, int(time.time()))
                    except Exception:
                        pass
                try:
                    with self.xtreamEpgLock:
                        self.xtreamDirectEpgResults[ch_id] = (rows, error, request_item, fallback or "", local_events)
                        self.xtreamDirectEpgInFlight.discard(ch_id)
                except Exception:
                    self.xtreamDirectEpgResults[ch_id] = (rows, error, request_item, fallback or "", local_events)
                    try: self.xtreamDirectEpgInFlight.discard(ch_id)
                    except Exception: pass
            t = threading.Thread(target=worker, name="TiviMateXtreamSelectedEPG")
            t.daemon = True
            t.start()
        try:
            self.directEpgTimer.stop()
            self.directEpgTimer.start(80, True)
        except Exception:
            pass
        return True

    def _startDirectEpg(self, item, fallback=""):
        effective_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        source_type = effective_source.get("type")
        if source_type not in ("xtream", "stalker"):
            return False
        stream_id = str(item.get("ch_id") or item.get("stream_id") or item.get("id") or "").strip()
        if not stream_id:
            return False
        self.directEpgToken += 1
        token = self.directEpgToken
        self.directEpgResult = None
        source = dict(effective_source)
        def worker():
            result = []
            error = ""
            try:
                if source_type == "stalker":
                    client = self.stalkerEpgClient
                    if client is None:
                        client = StalkerClient(source)
                        self.stalkerEpgClient = client
                    result = client.short_epg(stream_id, limit=10)
                else:
                    client = self._getXtreamEpgClient()
                    if client is None:
                        client = XtreamClient(source)
                    epg_channel_id = str(item.get("epg_channel_id") or item.get("tvg_id") or "").strip()
                    result = client.short_epg(stream_id, limit=10, epg_channel_id=epg_channel_id)
                if not isinstance(result, list):
                    result = []
            except Exception as exc:
                error = str(exc)
            self.directEpgResult = (token, result, fallback, error)
        threading.Thread(target=worker, name="TiviMateDirectEPG", daemon=True).start()
        try: self.directEpgTimer.start(120, False)
        except Exception: pass
        return True

    def _finishDirectEpg(self):
        # LG US: the XMLTV worker runs in the background.  The first Live
        # lookup can therefore happen before epg.json exists.  Reuse the
        # existing directEpgTimer to re-check the highlighted channel until
        # the prepared cache becomes available; never block the GUI thread.
        if self.source.get("type") == "m3u" and self.fastLocalEpgPending:
            pending = self.fastLocalEpgPending
            item = self.current()
            wanted = str((pending or {}).get("key") or "")
            current_key = str((item or {}).get("tvg_id") or (item or {}).get("epg_channel_id") or (item or {}).get("stream_id") or "") if isinstance(item, dict) else ""
            if not isinstance(item, dict) or (wanted and current_key != wanted):
                self.fastLocalEpgPending = None
                return
            try:
                current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
            except Exception:
                current, upcoming = None, None
            if current:
                self.fastLocalEpgPending = None
                self._applyLocalEpgEvent(current, upcoming, str((pending or {}).get("fallback") or ""))
                return
            if time.time() < float((pending or {}).get("deadline") or 0):
                try: self.directEpgTimer.start(250, True)
                except Exception: pass
                return
            self.fastLocalEpgPending = None
            self["epgNowTitle"].setText(tr("No EPG data"))
            try: self["liveProgress"].setValue(0)
            except Exception: pass
            self["desc"].setText(str((pending or {}).get("fallback") or ""))
            return

        # r443: selected Xtream channel is independent from page prefetch.
        # Poll only its direct result; repeated list refreshes do not cancel it.
        if self.source.get("type") == "xtream":
            ch_id = str(getattr(self, "xtreamDirectEpgSelected", "") or "")
            if ch_id:
                result = None
                inflight = False
                try:
                    with self.xtreamEpgLock:
                        result = self.xtreamDirectEpgResults.pop(ch_id, None)
                        inflight = ch_id in self.xtreamDirectEpgInFlight
                except Exception:
                    result = self.xtreamDirectEpgResults.pop(ch_id, None)
                    inflight = ch_id in getattr(self, "xtreamDirectEpgInFlight", set())
                if result is not None:
                    rows, error, request_item, fallback, local_events = result
                    # Ignore stale responses from a previous highlighted channel.
                    if ch_id == str(getattr(self, "xtreamDirectEpgSelected", "") or ""):
                        if rows and self._applyXtreamShortEpgRows(rows, fallback, error):
                            getattr(self, "xtreamEpgMissUntil", {}).pop(ch_id, None)
                            return
                        current, upcoming = local_events or (None, None)
                        if current:
                            getattr(self, "xtreamEpgMissUntil", {}).pop(ch_id, None)
                            self._applyLocalEpgEvent(current, upcoming, fallback)
                            return
                        # Short retry for a temporary network error; ten minutes
                        # only when the provider and local EPG have no programme.
                        self.xtreamEpgMissUntil[ch_id] = time.time() + (60 if error else 600)
                        if len(self.xtreamEpgMissUntil) > 180:
                            for key in list(self.xtreamEpgMissUntil)[:40]:
                                self.xtreamEpgMissUntil.pop(key, None)
                        self["epgNowTitle"].setText(tr("No EPG data"))
                        try: self["liveProgress"].setValue(0)
                        except Exception: pass
                        self["desc"].setText(fallback or "")
                        return
                if inflight:
                    try: self.directEpgTimer.start(350, True)
                    except Exception: pass
                    return
                # No result/in-flight state: leave the neutral UI and let the
                # next selection refresh retry normally.
                return

        result = self.directEpgResult
        if result is None:
            try: self.directEpgTimer.start(120, False)
            except Exception: pass
            return
        self.directEpgResult = None
        token, rows, fallback, error = result
        if token != self.directEpgToken:
            return
        if self._applyXtreamShortEpgRows(rows, fallback, error):
            # Provider EPG can arrive after the initial Live poster lookup.
            # Schedule artwork only once the real programme title is available.
            try:
                selected = self.current()
                if selected:
                    self._scheduleLivePoster(selected)
            except Exception:
                pass
            return
        self["epgNowTitle"].setText(tr("No EPG data"))
        self._clearLiveTmdbDetails()
        self["desc"].setText(fallback or ("Provider EPG unavailable" if not error else "Provider EPG unavailable"))

    def _applyLocalEpgEvent(self, current, upcoming, fallback=""):
        now_ts = int(time.time())
        begin, duration, title, desc = current
        if str((self.source or {}).get("type") or "").lower() == "xtream" and title:
            try:
                current_item = self.current()
                ch_id = self._xtreamEpgChannelId(current_item)
                if ch_id:
                    self.liveLocalEpgBadgeUntil[ch_id] = time.time() + 600
                    _live_epg_mark_known(self.source, ch_id, [{"title": title}])
                    if len(self.liveLocalEpgBadgeUntil) > 120:
                        for key in list(self.liveLocalEpgBadgeUntil)[:30]:
                            self.liveLocalEpgBadgeUntil.pop(key, None)
                    self._refreshLiveEpgBadges()
            except Exception:
                pass
        self["epgNowTime"].setText(self._formatEpgTime(begin, duration))
        self["epgNowTitle"].setText(title or "")
        self._scheduleLivePosterForResolvedEpg(title)
        elapsed = max(0, now_ts - int(begin))
        percent = min(100, max(0, int((elapsed * 100) / duration))) if duration > 0 else 0
        self["epgProgressText"].setText("%d%%" % percent)
        try: self["liveProgress"].setValue(percent)
        except Exception: pass
        self._setLiveEpgProgressVisible(bool(title))
        self["desc"].setText((desc or fallback or "No programme description.")[:600])
        if upcoming:
            ub, ud, ut, _ = upcoming
            self["epgNextTime"].setText(self._formatEpgTime(ub, ud))
            self["epgNextTitle"].setText(ut or "")

    def _updateLiveEpg(self, item):
        """Provider-specific Live EPG; Stalker follows EStalker 1.45."""
        self._setLiveEpgProgressVisible(False)
        for key in ("epgNowTime", "epgNowTitle", "epgNextTime", "epgNextTitle", "epgProgressText"):
            try:
                self[key].setText("")
            except Exception:
                pass
        fallback = (item.get("plot") or item.get("description") or "").strip()

        if self.source.get("type") == "stalker":
            # EStalker uses portal short EPG for Stalker Live.
            if self._applyStalkerShortEpg(item, fallback):
                return
            try:
                self["liveProgress"].setValue(0)
                self["desc"].setText("")
            except Exception:
                pass
            return

        # r127: Xtream now follows the Stalker philosophy: ask the provider
        # directly by stream_id first.  The same-server XMLTV cache is used
        # only as a fallback when provider short_epg returns no rows.
        if self.source.get("type") == "xtream":
            try:
                cached = self._xtreamCachedShortEpg(item, max_age=900)
                if cached and self._applyXtreamShortEpgRows(cached, fallback):
                    return
            except Exception:
                pass
            # Neutral text is shown immediately; cached or newly arrived EPG
            # overwrites it, without a loading spinner or placeholder wait.
            self["epgNowTitle"].setText(tr("No EPG data"))
            if self._startXtreamSelectedEpg(item, fallback):
                try:
                    self["liveProgress"].setValue(0)
                except Exception:
                    pass
                self["desc"].setText(fallback or "")
                return
        else:
            # Keep the legacy local/eEPG behavior for non-Xtream providers,
            # except LG Channels where EPG is intentionally disabled.
            try:
                _fs = str((self.source or {}).get("fast_service") or "").strip().lower()
                if _fs != "lgchannels":
                    current, upcoming = lookup_channel_epg(self.source, item, int(time.time()))
                    if current:
                        self.fastLocalEpgPending = None
                        self._applyLocalEpgEvent(current, upcoming, fallback)
                        return
            except Exception:
                pass

            # LG US XMLTV is downloaded/parsed asynchronously when the M3U
            # catalog opens.  If the cache is not ready yet, keep Live fully
            # responsive and poll only the selected channel using the timer
            # already owned by this screen.
            try:
                _fs = str((self.source or {}).get("fast_service") or "").strip().lower()
                _fr = str((self.source or {}).get("fast_region") or "").strip().lower()
                if _fs == "lgchannels" and _fr == "us" and (self.source or {}).get("epg_url"):
                    ensure_source_epg(self.source)
                    key = str(item.get("tvg_id") or item.get("epg_channel_id") or item.get("stream_id") or "")
                    self.fastLocalEpgPending = {"key": key, "fallback": fallback or "", "deadline": time.time() + 12.0}
                    self["epgNowTitle"].setText("")
                    self["desc"].setText(fallback or "")
                    try:
                        self.directEpgTimer.stop()
                        self.directEpgTimer.start(250, True)
                    except Exception:
                        pass
                    return
            except Exception:
                self.fastLocalEpgPending = None

            try:
                cache = eEPGCache.getInstance()
                ref_string = epg_reference_string(self.source, item)
                events = ["IBDTEX", (ref_string, -1, -1, -1)]
                rows = [] if cache is None else (cache.lookupEvent(events) or [])
                if rows:
                    def event(row):
                        return (int(row[1] or 0), int(row[2] or 0), row[3] or "", row[4] or "")
                    current = event(rows[0])
                    upcoming = event(rows[1]) if len(rows) > 1 else None
                    self._applyLocalEpgEvent(current, upcoming, fallback)
                    return
            except Exception:
                pass

            if self._startDirectEpg(item, fallback):
                self["epgNowTitle"].setText("")
                self["desc"].setText(fallback or "")
                return

        self["epgNowTitle"].setText(tr("No EPG data"))
        try:
            self["liveProgress"].setValue(0)
        except Exception:
            pass
        self._clearLiveTmdbDetails()
        self["desc"].setText(fallback or "")

    def _cleanLiveProgrammeTitle(self, title):
        # Clean only the copy sent to TMDb.  The EPG title shown on screen is
        # untouched.  Providers commonly append quality/language/episode tags
        # that make an otherwise exact TMDb title miss.
        value = str(title or "").strip()
        if not value:
            return ""

        # Remove common technical wrappers without removing meaningful movie
        # punctuation such as the colon in "Mission: Impossible".
        value = re.sub(r"^\s*\[(?:HD|FHD|UHD|4K|HEVC|H265|H264|AR|ARA|EN|ENG)\]\s*", "", value, flags=re.I)
        value = re.sub(r"\s*\[(?:HD|FHD|UHD|4K|HEVC|H265|H264|AR|ARA|EN|ENG)\]\s*$", "", value, flags=re.I)
        value = re.sub(r"\s*\((?:HD|FHD|UHD|4K|HEVC|H\.?265|H\.?264|AR|ARA|EN|ENG)\)\s*$", "", value, flags=re.I)

        # Season/episode suffixes used by English and Arabic EPG providers.
        value = re.sub(r"\s*[\-–—|:]?\s*[Ss]\s*\d{1,2}\s*[Ee]\s*\d{1,3}\b.*$", "", value, flags=re.I)
        value = re.sub(r"\s*[\-–—|:]?\s*(?:EP(?:ISODE)?\.?|E)\s*#?\d{1,3}\b.*$", "", value, flags=re.I)
        value = re.sub(r"\s*[\-–—|:]?\s*(?:الحلقة|حلقة)\s*\d{1,3}\b.*$", "", value, flags=re.I)
        value = re.sub(r"\s*[\-–—|:]?\s*(?:الموسم)\s*\d{1,2}\s*(?:الحلقة|حلقة)\s*\d{1,3}\b.*$", "", value, flags=re.I)

        # Years and quality/language tokens are frequent trailing EPG metadata.
        value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", value)
        value = re.sub(r"(?:\s*[\-–—|]\s*)?(?:HD|FHD|UHD|4K|1080P|720P|HEVC|H\.?265|H\.?264)\s*$", "", value, flags=re.I)
        value = re.sub(r"\s+", " ", value).strip(" -–—:|")
        return value

    def _clearLiveTmdbDetails(self):
        if self.kind != "live":
            return
        try:
            self["liveInfoMeta"].setText("")
        except Exception:
            pass
        try:
            self["liveStars"].setText("")
        except Exception:
            pass
        try:
            show_pink_rating(self["liveRatingText"], None)
        except Exception:
            try:
                self["liveRatingText"].setText("")
            except Exception:
                pass

    def _applyLiveTmdbDetails(self, rating=None, year="", media_label=""):
        if self.kind != "live":
            return
        parts = []
        if year:
            parts.append(str(year))
        if media_label:
            parts.append(str(media_label))
        try:
            self["liveInfoMeta"].setText("  •  ".join(parts))
        except Exception:
            pass
        try:
            value = float(rating or 0.0)
        except Exception:
            value = 0.0
        try:
            show_pink_rating(self["liveRatingText"], value if value > 0 else None)
        except Exception:
            pass
        stars = ""
        if value > 0:
            filled = int(round(max(0.0, min(10.0, value)) / 2.0))
            filled = max(0, min(5, filled))
            stars = (u"★" * filled) + (u"☆" * (5 - filled))
        try:
            self["liveStars"].setText(stars)
        except Exception:
            pass

    def _scheduleLivePosterForResolvedEpg(self, programme_title):
        """Trigger Live artwork as soon as the highlighted programme is known.

        Xtream's async short EPG, local eEPGCache and M3U delayed XMLTV
        sometimes populate epgNowTitle after previewLive's initial cache probe.
        That initial probe has no title, so it cannot launch TMDb.  Use this
        single GUI-thread hook for every successful current-programme reveal;
        _scheduleLivePoster deduplicates a matching channel/title and reuses
        the infobar's shared persistent poster index/cache first.
        """
        if self.kind != "live" or self.focus != "items":
            return
        current = self.current()
        if not isinstance(current, dict) or current.get("_stalker_placeholder"):
            return
        name = str(current.get("name") or current.get("title") or "")
        if name.lstrip().startswith("####"):
            return
        title = self._cleanLiveProgrammeTitle(programme_title)
        if title and title not in ("No EPG data", tr("No EPG data")):
            self._scheduleLivePoster(current, title)

    def _scheduleLivePoster(self, item, title_override=None):
        candidate = self._cleanLiveProgrammeTitle(title_override if title_override is not None else self["epgNowTitle"].getText())
        # Same EPG programme on same channel: keep cache decode and the pending
        # worker instead of resetting/fetching again at the 2s EPG callback.
        channel_key = str((item or {}).get("ch_id") or (item or {}).get("stream_id") or (item or {}).get("id") or (item or {}).get("name") or "")
        if candidate and getattr(self, "_livePosterChannelKey", "") == channel_key and getattr(self, "_livePosterTitle", "") == candidate:
            return
        self._livePosterChannelKey = channel_key
        self.livePosterToken += 1
        self._livePosterItem = dict(item or {})
        self.livePosterResult = None
        self._liveKnownPosterUrl = ""
        self._livePosterTitle = candidate
        self.livePosterPath = ""
        self._livePosterDisplayedToken = -1
        try: self.livePosterTimer.stop()
        except Exception: pass
        try: self.livePosterPoll.stop()
        except Exception: pass
        try: self["livePoster"].hide()
        except Exception: pass
        poster_enabled = str(self.source.get("show_live_poster", True)).strip().lower() in ("1", "true", "yes", "on", "enabled")
        if not poster_enabled:
            return

        # A known programme must never wait for TMDb again.  Resolve its stable
        # URL from the tiny title index, then decode the already cached file
        # immediately.  Only a first-time title uses the delayed TMDb lookup.
        title = candidate
        if not title or title == "No EPG data" or title == tr("No EPG data"):
            return
        key = _live_poster_key(title)
        poster_index = _load_live_poster_urls()
        url = poster_index.get(key, "") if key else ""
        # Ultra-style background ownership: never synchronously parse the
        # shared infobar poster JSON on each remote-control focus movement.
        # On an in-RAM miss, _startLivePosterLookup reads the shared disk
        # index in its existing background worker, before contacting TMDb.
        token = self.livePosterToken
        if url:
            self._liveKnownPosterUrl = url
            # The infobar writes to the shared posters family, not a separate
            # live_tmdb_poster family. Check the exact same HDD/USB cache path.
            cached = cached_artwork(url, "posters")
            if cached:
                self._showLivePosterPath(cached, token)
            else:
                # The URL is known but its file was removed. Re-fetch directly in
                # the artwork queue while still resolving TMDb details below.
                def ready(path):
                    self._showLivePosterPath(path, token)
                request_artwork(url, kind="posters", callback=ready, priority=250)

        # Details in RAM can render with the cached poster immediately.
        existing = self._liveTmdbDetailsCache.get(key) if key else None
        if existing is not None:
            self._applyLiveTmdbDetails(*existing)
            return
        # First-time TMDb search is asynchronous; no blocking on remote keys.
        try: self.livePosterTimer.start(300, True)
        except Exception: self.livePosterTimer.start(300)

    def _startLivePosterLookup(self):
        item = getattr(self, "_livePosterItem", {}) or {}
        title = str(getattr(self, "_livePosterTitle", "") or "")
        if not title or title == "No EPG data" or title == tr("No EPG data"):
            return
        token = self.livePosterToken
        def worker():
            url = ""
            rating = 0.0
            year = ""
            media_label = ""
            # Infobar has its own persistent poster-index writer. Import an
            # entry discovered after this screen cached its index, *off* the
            # Enigma GUI thread. Reuse the existing cached poster before TMDb.
            lookup_key = _live_poster_key(title)
            if lookup_key:
                try:
                    with open_text(LIVE_POSTER_INDEX_FILE, "r") as handle:
                        stored = json.load(handle) or {}
                    if isinstance(stored, dict):
                        url = str(stored.get(lookup_key) or "").strip()
                except Exception:
                    pass
            if url:
                self.livePosterResult = (token, url, rating, year, media_label)
                return
            try:
                client = TMDbClient()
                result = client.search_artwork(title, "vod", required_key="poster_path")
                media_label = tr("Movies") if result else ""
                if not result:
                    result = client.search_artwork(title, "series", required_key="poster_path")
                    media_label = tr("TV Shows") if result else ""
                result = result or {}
                path = result.get("poster_path") or ""
                if path:
                    url = IMAGE_BASE + "w342" + path
                try:
                    rating = float(result.get("vote_average") or result.get("rating") or 0.0)
                except Exception:
                    rating = 0.0
                date_value = str(result.get("release_date") or result.get("first_air_date") or "")
                if len(date_value) >= 4 and date_value[:4].isdigit():
                    year = date_value[:4]
            except Exception:
                pass
            self.livePosterResult = (token, url, rating, year, media_label)
        t = threading.Thread(target=worker, name="TiviMateLivePosterTMDb")
        t.daemon = True
        t.start()
        try: self.livePosterPoll.start(250, False)
        except Exception: pass

    def _showLivePosterPath(self, path, token=None):
        token = self.livePosterToken if token is None else token
        if token != self.livePosterToken or not path or not os.path.exists(path):
            return
        # Decoder objects cannot be reused safely while an earlier decode is
        # pending on some OpenATV/Pure2 versions. Each request owns its decoder
        # and may paint only while its selection token is still current.
        try:
            loader = ePicLoad()
            self.livePosterLoader = loader
            self.livePosterPath = path

            def ready(_info=None, expected=token, ref=loader):
                # PictureData may arrive after Pure2/Enigma2 has torn down a
                # closed screen. Never access Live state outside the guard:
                # a late cached-poster decode must not crash Enigma2.
                try:
                    if (getattr(self, "kind", None) != "live" or
                            expected != getattr(self, "livePosterToken", None) or
                            getattr(self, "livePosterLoader", None) is not ref):
                        return
                    ptr = ref.getData()
                    if ptr is not None and self["livePoster"].instance:
                        self["livePoster"].instance.setPixmap(ptr)
                        self["livePoster"].show()
                        self._livePosterDisplayedToken = expected
                except Exception:
                    pass

            connect_picture_data(loader, ready, self, oneshot=True)
            loader.setPara((152, 222, 1, 1, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def _finishLivePosterLookup(self):
        result = self.livePosterResult
        if result is None:
            try: self.livePosterPoll.start(250, False)
            except Exception: pass
            return
        self.livePosterResult = None
        token, url, rating, year, media_label = result
        if token != self.livePosterToken:
            return
        self._applyLiveTmdbDetails(rating, year, media_label)
        title = str(getattr(self, "_livePosterTitle", "") or "")
        key = _live_poster_key(title)
        if key and url:
            self._liveTmdbDetailsCache[key] = (rating, year, media_label)
            if len(self._liveTmdbDetailsCache) > 100:
                self._liveTmdbDetailsCache.pop(next(iter(self._liveTmdbDetailsCache)), None)
        if not url:
            return
        if key:
            _save_live_poster_url(key, url)
        if str(getattr(self, "_liveKnownPosterUrl", "")) == str(url):
            # The infobar/browser URL is already on its way (or in the poster
            # cache). Do not enqueue duplicate downloads, but retry decoding
            # the existing file if the earlier Enigma picture signal was lost.
            cached = cached_artwork(url, "posters")
            if cached and self._livePosterDisplayedToken != token:
                self._showLivePosterPath(cached, token)
            return
        def ready(path):
            self._showLivePosterPath(path, token)
        cached = cached_artwork(url, "posters")
        if cached:
            self._showLivePosterPath(cached, token)
        else:
            request_artwork(url, kind="posters", callback=ready, priority=250)

    def _livePosterDecoded(self, picInfo=None):
        # Kept for compatibility with external skins; modern Live poster loads
        # use token-checked one-shot callbacks inside _showLivePosterPath.
        return

    def cancelAction(self):
        if self.kind == "live":
            self._cancelPendingLiveSelection()
            self._livePreviewOkIdentity = None
        if self.kind == "live" and getattr(self, "_liveMoveMode", False):
            original = getattr(self, "_liveMoveOriginal", None)
            self._liveMoveMode = False; self._liveMoveOriginal = None
            if original is not None:
                self.showItems(original)
            return
        if self.kind == "live" and self.focus == "items":
            if self.source.get("type") == "stalker":
                self._cancelStalkerCatalogueRequests()
                self.stalkerLiveCancelEvent = threading.Event()
            self.focus = "category"
            self["list"].setList([])
            self._refreshLiveEpgBadges()
            self["categoryTitle"].setText(tr("PACKAGES"))
            self["channelTitle"].setText(tr("Select a package"))
            self["meta"].setText("")
            self["desc"].setText(tr("Select a package") + " - OK")
            try:
                self["livePoster"].hide()
            except Exception:
                pass
            self._clearLiveTmdbDetails()
            self._hideRowPicons()
            return
        if self.kind == "live":
            try:
                self.stalkerWatchdogTimer.stop()
            except Exception:
                pass
            self.stalkerWatchdogPending = False
            self.stalkerWatchdogClient = None
            restore_top_dialog_soon(self.session)
        self.close()

    def _hideRowPicons(self):
        return


    def _refreshVisibleRowPicons(self):
        return


    def _finishRowPicons(self):
        return


    def _rowPiconDecoded(self, idx):
        return


    def _updateLiveClock(self):
        try:
            self["clockTitle"].setText(time.strftime("%Y/%m/%d   %H:%M", time.localtime()))
        except Exception:
            pass

    def _visibleLiveItems(self):
        items = self.mediaItemsCurrent or []
        if not items:
            return []
        try:
            idx = self["list"].getSelectedIndex()
        except Exception:
            idx = 0
        start = max(0, min(idx - 4, max(0, len(items) - 10)))
        return items[start:start + 10]

    def _updateLiveKeys(self):
        if self.kind != "live":
            return
        try:
            self["styleHint"].setText("YELLOW  SWITCH SERVER  •  %s" % ("beIN SPORTS" if self.source.get("_virtual_bein") else self.source.get("name", "SERVER")))
        except Exception:
            pass

    def toggleAutoZap(self):
        if self.kind != "live": return
        self.channelSettings["auto_zap"] = not self.channelSettings.get("auto_zap", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys()
        if self.channelSettings["auto_zap"]:
            try: self.zapTimer.stop()
            except Exception: pass
            self._autoZapCurrent()

    def toggleLivePicon(self):
        if self.kind != "live": return
        self.channelSettings["picon"] = not self.channelSettings.get("picon", True)
        _save_channel_settings(self.channelSettings); self._updateLiveKeys(); self.previewLive()

    def _cancelLiveZapResolve(self):
        """Ultra's cooperative cancel: retire both queued and running stale links."""
        old = getattr(self, "liveZapResolveHandle", None)
        self.liveZapResolveHandle = None
        self.liveZapResolveHandoffState = None
        if old is not None:
            try: old.cancel()
            except Exception: pass
        self.liveZapResolveToken = int(getattr(self, "liveZapResolveToken", 0) or 0) + 1
        self.liveZapResolveResult = None
        self.liveZapResolveDeadline = 0.0
        self.liveZapResolveCallback = None
        self.liveZapResolveSelection = None
        self.liveZapResolveSourceKey = None
        try: self.liveZapResolveTimer.stop()
        except Exception: pass

    def _handoffLiveLink(self, item, source):
        """Transfer the exact in-flight Ultra link request to the Infobar.

        Never hand over a link from a different server/channel, and never
        leave an old parent timer able to playService behind the player.
        The worker's TaskHandle moves with the result; the player owns its
        cancellation after this call.
        """
        if not isinstance(item, dict) or not isinstance(source, dict):
            return None
        if str(source.get("type") or "").lower() != "stalker":
            return None
        channel = str(item.get("stream_id") or item.get("ch_id") or
            item.get("id") or item.get("url") or item.get("cmd") or
            item.get("name") or "").strip()
        expected = (str(_source_identity(source)), channel)
        state = getattr(self, "liveZapResolveHandoffState", None)
        if (not channel or not isinstance(state, dict) or
                state.get("source") != expected or
                state.get("token") != getattr(self, "liveZapResolveToken", None) or
                state.get("handle") is not getattr(self, "liveZapResolveHandle", None)):
            return None
        # If this is already expired, use the normal bounded retry in the
        # full-screen player rather than handing off a dead task.
        if not state.get("result") and time.monotonic() >= state.get("deadline", 0):
            return None
        state["transferred"] = True
        self.liveZapResolveHandle = None
        self.liveZapResolveHandoffState = None
        self.liveZapResolveResult = None
        self.liveZapResolveDeadline = 0.0
        self.liveZapResolveCallback = None
        self.liveZapResolveSourceKey = None
        self.liveZapResolveSelection = None
        self.liveZapResolveToken += 1
        try: self.liveZapResolveTimer.stop()
        except Exception: pass
        return state

    def _cancelLivePreviewCheck(self, stop_failed=False):
        """Retire a Stalker preview without blocking the Enigma UI thread."""
        state = getattr(self, "_livePreviewCheck", None)
        self._livePreviewCheck = None
        try: self._livePreviewCheckTimer.stop()
        except Exception: pass
        if state and stop_failed:
            if self._livePreviewVerifiedRef == state["ref"]:
                self._livePreviewVerifiedRef = ""
            # An old preview can expire after a newer selection has started.
            # Stop only its own decoder ref; never erase the newer channel's
            # playing identity, URL or successful playback state.
            try:
                if _live_ref_is_active(self.session.nav, state["ref"]):
                    failed_url = str(state.get('url') or '')
                    guard = getattr(self, '_ultraLiveDecoderGuard', None)
                    if guard is not None and failed_url:
                        guard.capture(failed_url)
                    self.session.nav.stopService()
                    if guard is not None and failed_url:
                        guard.retire(failed_url)
            except Exception:
                pass
            owns_current = (_CURRENT_LIVE_CHANNEL.get("source") == state["source"] and
                            _CURRENT_LIVE_CHANNEL.get("channel") == state["channel"])
            if owns_current:
                self.keepCurrentLiveService = False
                self._playingLiveItem = None
                self._playingLiveUrl = ""
                _CURRENT_LIVE_CHANNEL["source"] = None
                _CURRENT_LIVE_CHANNEL["channel"] = None
                self.lastZappedLiveId = ""

    def _beginLivePreviewCheck(self, ref, item, callback=None, source=None):
        """Confirm a real video service, not only an accepted playService call.

        This is UI-thread polling only: no network call, and no Loading dialog.
        A failed preview is stopped within ten seconds so cursor navigation
        remains responsive. It also serves Windows mixed-source favorites.
        """
        self._cancelLivePreviewCheck()
        # An accepted playService reference is NOT proof of decoded media.
        # Forget the previous proof until THIS exact ref passes the probe.
        self._livePreviewVerifiedRef = ""
        ref_text = ref.toString() if hasattr(ref, "toString") else str(ref or "")
        if not ref_text:
            if callback is not None:
                try: callback(False)
                except Exception: pass
            return
        provider = source if isinstance(source, dict) else self.source
        channel = str((item or {}).get("stream_id") or (item or {}).get("ch_id") or
                      (item or {}).get("id") or (item or {}).get("cmd") or
                      (item or {}).get("name") or "")
        self._livePreviewCheck = {
            "ref": ref_text, "channel": channel,
            "url": str(getattr(self, '_playingLiveUrl', '') or ''),
            "source": _source_identity(provider),
            "deadline": time.monotonic() + 10.0, "began": time.monotonic(),
            "size": None, "stable_at": 0.0,
            "seen_ref": False, "missing_since": 0.0,
            "audio_seen_at": 0.0,
            "callbacks": [callback] if callback is not None else [],
        }
        try: self._livePreviewCheckTimer.start(220, True)
        except Exception: self._pollLivePreviewCheck()

    def _pollLivePreviewCheck(self):
        """Stop only the unchanged failed service, never a newer selection."""
        state = getattr(self, "_livePreviewCheck", None)
        if state is None:
            return
        ready = False
        try:
            from enigma import iServiceInformation
            nav = self.session.nav
            active = nav.getCurrentlyPlayingServiceReference()
            active_ref = active.toString() if active else ""
            if active_ref == state["ref"]:
                state["seen_ref"] = True
                state["missing_since"] = 0.0
            else:
                # playService(0) can return before Navigation publishes the
                # new reference. Failing on the very first 300 ms poll causes
                # false Loading/retry loops on slower Enigma2 images.
                # When a ref WAS seen, its sustained disappearance is strong
                # evidence of an aborted playback, so fail much sooner.
                now = time.monotonic()
                if not state.get("missing_since"):
                    state["missing_since"] = now
                # An empty ref is not the same as an active *different* ref.
                # Some OpenATV/Pure builds publish the accepted service after
                # playService returns. Give an unpublished ref the same five-
                # second grace used by full-screen Live. But once a ref was
                # actually seen and vanished, fail quickly as before.
                grace = (0.9 if state.get("seen_ref") else
                         (5.0 if not active_ref else 1.8))
                if now - state["missing_since"] < grace:
                    try: self._livePreviewCheckTimer.start(220 if time.monotonic() - state['began'] < 3.0 else 350, True)
                    except Exception: pass
                    return
                # Enigma can release a failing service before the 10s decoder
                # deadline. Retiring it silently left first-OK/Windows in a
                # pending state, so later presses seemed stuck on Loading.
                # Do not stopService here: the newly active ref may belong to
                # a legitimate later channel selected by the user.
                callbacks = list(state["callbacks"])
                self._cancelLivePreviewCheck()
                if (_CURRENT_LIVE_CHANNEL.get("source") == state["source"] and
                        _CURRENT_LIVE_CHANNEL.get("channel") == state["channel"]):
                    self._playingLiveItem = None
                    self._playingLiveUrl = ""
                    self.lastZappedLiveId = ""
                    self.keepCurrentLiveService = False
                    _CURRENT_LIVE_CHANNEL["source"] = None
                    _CURRENT_LIVE_CHANNEL["channel"] = None
                # If a newer service is already active, never cover its
                # UI with an error from the obsolete preview.
                if not active_ref:
                    try: self["meta"].setText("Channel unavailable  •  Try another")
                    except Exception: pass
                for cb in callbacks:
                    try: cb(False)
                    except Exception: pass
                return
            service = nav.getCurrentService()
            info = service and service.info()
            if info is not None:
                width = int(info.getInfo(iServiceInformation.sVideoWidth) or 0)
                height = int(info.getInfo(iServiceInformation.sVideoHeight) or 0)
                if width > 0 and height > 0:
                    # UltraStalker ui_grid_screens._check_preview_ready:
                    # positive video dimensions for the EXACT active service
                    # confirm the preview. The matching service reference is
                    # checked above and again before publishing success below.
                    # The former 0.6s stable + 1.1s age delays reported a
                    # running video as Loading long after Ultra considered it ready.
                    ready = True
                elif width <= 0 and height <= 0 and time.monotonic() - state["began"] >= 3.0:
                    # A buffering VIDEO can expose audio tracks before it
                    # decodes any video. The previous test accidentally
                    # reported that black preview as successfully playing.
                    # Only accept explicitly declared audio-only services.
                    video_pid_key = getattr(iServiceInformation, "sVideoPID", None)
                    audio_pid_key = getattr(iServiceInformation, "sAudioPID", None)
                    audio_only = False
                    if video_pid_key is not None and audio_pid_key is not None:
                        video_pid = int(info.getInfo(video_pid_key))
                        audio_pid = int(info.getInfo(audio_pid_key))
                        if video_pid == -1 and audio_pid >= 0:
                            tracks = service.audioTracks() if service else None
                            audio_only = bool(tracks and tracks.getNumberOfTracks() > 0)
                    if audio_only:
                        now = time.monotonic()
                        if not state["audio_seen_at"]:
                            state["audio_seen_at"] = now
                        else:
                            ready = (now - state["audio_seen_at"] >= 0.7)
                    else:
                        state["audio_seen_at"] = 0.0
        except Exception:
            pass
        if ready:
            # The same timer can be drained from the visible Windows screen.
            # If a reentrant callback switched the channel, do not publish
            # proof belonging to a retired preview.
            if getattr(self, "_livePreviewCheck", None) is not state:
                return
            try:
                current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if not current_ref or current_ref.toString() != state["ref"]:
                    return
            except Exception:
                return
            callbacks = list(state["callbacks"])
            # Only the currently active, sufficiently stable decoder can
            # authorize reuse. A failed ref never becomes a successful zap.
            try:
                guard = getattr(self, '_ultraLiveDecoderGuard', None)
                if guard is not None and state.get('url'):
                    guard.capture(state['url'])
            except Exception:
                pass
            self._livePreviewVerifiedRef = state["ref"]
            self._cancelLivePreviewCheck()
            try: self["meta"].setText("")
            except Exception: pass
            for cb in callbacks:
                try: cb(True)
                except Exception: pass
            return
        if time.monotonic() >= state["deadline"]:
            # A nested GUI callback may have retired the old preview while
            # this decoder poll ran; only its owning attempt may fail/stop.
            if getattr(self, "_livePreviewCheck", None) is not state:
                return
            callbacks = list(state["callbacks"])
            if self._livePreviewVerifiedRef == state["ref"]:
                self._livePreviewVerifiedRef = ""
            self._cancelLivePreviewCheck(stop_failed=True)
            try: self["meta"].setText("Channel unavailable  •  Try another")
            except Exception: pass
            for cb in callbacks:
                try: cb(False)
                except Exception: pass
            return
        try: self._livePreviewCheckTimer.start(220 if time.monotonic() - state['began'] < 3.0 else 350, True)
        except Exception: pass

    def _finishAsyncLiveZap(self):
        token = int(getattr(self, "liveZapResolveToken", 0) or 0)
        result = getattr(self, "liveZapResolveResult", None)
        deadline = float(getattr(self, "liveZapResolveDeadline", 0.0) or 0.0)
        # A moved normal-list cursor must retire the old request, including
        # its timeout UI/callback. This check must run BEFORE timeout handling.
        selected = getattr(self, "liveZapResolveSelection", None)
        if (selected is not None and not getattr(self, '_windowsVisible', False)
                and selected != self._selectedLiveOkIdentity(self.current())):
            self._cancelLiveZapResolve()
            return
        # Even if the portal never returns, stop polling; Ultra's task token
        # cancels the underlying request if the transport supports it.
        if result is None and deadline and time.monotonic() >= deadline:
            callback = getattr(self, "liveZapResolveCallback", None)
            self._cancelLiveZapResolve()
            try: self["meta"].setText("Channel unavailable  •  Try another")
            except Exception: pass
            if callback is not None:
                try: callback(False)
                except Exception: pass
            return
        if result is None:
            if deadline:
                try: self.liveZapResolveTimer.start(120, True)
                except Exception: pass
            return
        self.liveZapResolveResult = None
        try:
            request_token, item, force, url, error = result
        except Exception:
            self._cancelLiveZapResolve()
            return
        if request_token != token:
            return
        # Auto-zap and first-OK share this worker. The list may have moved
        # while a slow MAG portal was resolving the old channel. Reject that
        # response even when no explicit first-OK identity was recorded.
        requested_selection = getattr(self, 'liveZapResolveSelection', None)
        if (requested_selection is not None and not getattr(self, '_windowsVisible', False)
                and requested_selection != self._selectedLiveOkIdentity(self.current())):
            self._cancelLiveZapResolve()
            return
        # A normal-list OK may be followed by an immediate cursor move while
        # the portal is still resolving. Ignore that obsolete response even
        # if a delayed selection callback has not yet run previewLive().
        pending_identity = getattr(self, "_livePreviewPendingIdentity", None)
        if (pending_identity is not None and
                self._selectedLiveOkIdentity(self.current()) != pending_identity):
            self._cancelLiveZapResolve()
            self._livePreviewPendingIdentity = None
            return
        callback = getattr(self, "liveZapResolveCallback", None)
        # Retire this request before executing Enigma playService. A late
        # network reply can never retune the newer channel after a timeout.
        self.liveZapResolveHandle = None
        self.liveZapResolveHandoffState = None
        self.liveZapResolveDeadline = 0.0
        self.liveZapResolveCallback = None
        self.liveZapResolveSelection = None
        self.liveZapResolveSourceKey = None
        try: self.liveZapResolveTimer.stop()
        except Exception: pass
        if url:
            # The callback must wait for decoded video. An accepted service
            # ref is not yet a successfully playing Stalker channel.
            self._zapLiveItem(item, force, _resolved_url=url, _on_complete=callback)
        else:
            try: self["meta"].setText("Channel link unavailable")
            except Exception: pass
            if callback is not None:
                try: callback(False)
                except Exception: pass

    def _zapLiveItem(self, item, force=False, _resolved_url=None, _on_complete=None):
        if not item or self.kind != "live":
            return False
        try:
            def channel_identity(row):
                row = row or {}
                return str(
                    row.get("stream_id") or row.get("ch_id") or row.get("id") or
                    row.get("url") or row.get("cmd") or row.get("name") or ""
                ).strip()

            live_id = channel_identity(item)
            play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            checking = getattr(self, "_livePreviewCheck", None)
            if checking:
                if not force and checking["channel"] == live_id and checking["source"] == _source_identity(play_source):
                    # Navigation may publish the accepted ref asynchronously.
                    # Repeated OKs during that short transition must NOT stop
                    # the first attempt and restart the decoder unnecessarily.
                    same_ref = _live_ref_is_active(self.session.nav, checking["ref"])
                    publishing = False
                    if not same_ref and not checking.get("seen_ref"):
                        # Match the five-second unpublished-reference grace in
                        # _pollLivePreviewCheck. A second OK after 1.8 seconds
                        # must NOT discard a valid slow-starting decoder and
                        # issue playService/create_link again for the same card.
                        # A *different* active ref gets the short 1.8s grace.
                        now = time.monotonic()
                        if now < float(checking.get("deadline", 0) or 0):
                            try:
                                active = self.session.nav.getCurrentlyPlayingServiceReference()
                                grace = 5.0 if active is None else 1.8
                                publishing = now - checking["began"] < grace
                            except Exception:
                                publishing = False
                    if same_ref or publishing:
                        if _on_complete is not None:
                            checking["callbacks"].append(_on_complete)
                        return True  # Reuse ongoing verification, not another playService.
                self._cancelLivePreviewCheck(stop_failed=True)
            # A channel number is NOT proof that Enigma2 plays that service.
            # The old shortcut silently skipped the first zap after a failed
            # stream or when providers reuse IDs across bouquets. Reuse only
            # an exact already-playing service reference from the last good zap.
            if not force and live_id and getattr(self, "_playingLiveUrl", ""):
                try:
                    playing_row = getattr(self, "_playingLiveItem", None) or {}
                    same_channel = channel_identity(playing_row) == live_id
                    same_provider = _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source)
                    if same_channel and same_provider:
                        service_type = (_xtream_service_type(play_source, "live")
                            if play_source.get("type") == "xtream"
                            else int(play_source.get("service_type", self.channelSettings.get("service_type", 4097))))
                        previous_ref = live_reference(
                            play_source, item, service_type, self._playingLiveUrl,
                            item.get("name") or item.get("title") or "IPTV")
                        if (_live_ref_is_active(self.session.nav, previous_ref) and
                                self._livePreviewVerifiedRef == previous_ref.toString()):
                            self.lastZappedLiveId = live_id
                            self.keepCurrentLiveService = True
                            if _on_complete is not None:
                                try: _on_complete(True)
                                except Exception: pass
                            return True
                except Exception:
                    pass

            if _resolved_url is not None:
                url = _resolved_url
            elif play_source.get("type") == "stalker":
                # Repeated selections of the same channel while create_link
                # is in flight must share the result. Replacing a running
                # portal request with another identical request is slower and
                # can contribute to Stalker 429/rate-limit errors.
                request_key = (str(_source_identity(play_source)), live_id)
                if (not force and getattr(self, "liveZapResolveHandle", None) is not None
                        and getattr(self, "liveZapResolveSourceKey", None) == request_key
                        and time.monotonic() < float(getattr(self, "liveZapResolveDeadline", 0) or 0)):
                    if _on_complete is not None:
                        previous = getattr(self, "liveZapResolveCallback", None)
                        if previous is None:
                            self.liveZapResolveCallback = _on_complete
                        elif previous is not _on_complete:
                            def both(success, first=previous, second=_on_complete):
                                try: first(success)
                                except Exception: pass
                                try: second(success)
                                except Exception: pass
                            self.liveZapResolveCallback = both
                    return True
                # Ultra starts a cancellable create_link worker immediately.
                # EPG has a separate worker lane; do not synchronously cancel
                # its cache/page bookkeeping before submitting this request.
                # Use exactly the same Ultra TaskHandle and lazy bounded
                # executor as TiviMateLivePlayer, NOT a free-running Thread.
                self._cancelLiveZapResolve()
                token = self.liveZapResolveToken
                handle = _UltraLiveTaskHandle(token, "live_browser_link")
                self.liveZapResolveHandle = handle
                self.liveZapResolveCallback = _on_complete
                self.liveZapResolveSourceKey = request_key
                self.liveZapResolveSelection = (None if getattr(self, '_windowsVisible', False)
                                                 else self._selectedLiveOkIdentity(item))
                self.liveZapResolveDeadline = time.monotonic() + 11.0
                self.liveZapResolveResult = None
                state = {"token": token, "handle": handle,
                         "source": request_key, "deadline": self.liveZapResolveDeadline,
                         "result": None, "transferred": False}
                self.liveZapResolveHandoffState = state
                src = dict(play_source or {})
                row = dict(item or {})
                def resolve():
                    resolved = ""
                    error = ""
                    try:
                        if not handle.cancelled():
                            # Ultra's shared PortalSession, live-policy
                            # create_link, auth-only retry, and cooperative
                            # network cancellation all stay in this call.
                            # Same worker reuses its authenticated Ultra
                            # client; different workers never share sockets.
                            client = _live_playback_client(src, get_source_client)
                            resolved = client.stream_url(
                                row, "live", cancel_event=handle) or ""
                    except Exception as exc:
                        error = str(exc)
                        # Drop only an unhealthy portal connection, not a
                        # normally cancelled channel from a rapid cursor move.
                        if not handle.cancelled():
                            _invalidate_playback_client(src)
                    if handle.cancelled() or (token != self.liveZapResolveToken and
                            not state["transferred"]):
                        return
                    response = (token, row, force, resolved, error)
                    state["result"] = response
                    if not state["transferred"]:
                        self.liveZapResolveResult = response
                try:
                    handle.future = _ULTRA_STALKER_LINK_POOL.submit(
                        resolve, _task_key=("browser-zap", id(self)),
                        _replace_task_key=True)
                    self.liveZapResolveTimer.start(120, True)
                except Exception:
                    self._cancelLiveZapResolve()
                    if _on_complete is not None:
                        try: _on_complete(False)
                        except Exception: pass
                    return False
                return True
            elif play_source.get("type") == "xtream":
                url = get_source_client(play_source).stream_url(item, "live")
            elif play_source.get("type") in ("m3u", "fg"):
                url = item.get("url", "")
            else:
                url = ""
            if not url:
                if _on_complete is not None:
                    try: _on_complete(False)
                    except Exception: pass
                return False

            service_type = (
                _xtream_service_type(play_source, "live")
                if play_source.get("type") == "xtream"
                else int(play_source.get("service_type", self.channelSettings.get("service_type", 4097)))
            )
            ref = live_reference(
                play_source, item, service_type, url,
                item.get("name") or item.get("title") or "IPTV"
            )
            try:
                current_ref = self.session.nav.getCurrentlyPlayingServiceReference()
                if (not force and current_ref is not None and
                        current_ref.toString() == ref.toString() and
                        self._livePreviewVerifiedRef == ref.toString()):
                    self.lastZappedLiveId = live_id
                    self.keepCurrentLiveService = True
                    if _on_complete is not None:
                        try: _on_complete(True)
                        except Exception: pass
                    return True
            except Exception:
                pass
            # Ultra ui_grid_screens._try_preview_engine immediately calls
            # playService after the worker returns a link.  Do not scan /proc
            # before starting the new video; TiviMateE2's external-player
            # guard can retire the replaced URL after Navigation accepts it.
            guard = getattr(self, '_ultraLiveDecoderGuard', None)
            previous_external_url = str(getattr(self, '_playingLiveUrl', '') or '')
            # Do not publish a successful zap when Navigation rejects the ref.
            # A stale "playing" ID made the following OK/preview incorrectly
            # reuse a service that never started.
            result = self.session.nav.playService(ref)
            if not _live_play_accepted(result):
                if _on_complete is not None:
                    try: _on_complete(False)
                    except Exception: pass
                try: self["meta"].setText("Channel could not start")
                except Exception: pass
                return False
            self.lastZappedLiveId = live_id
            self._playingLiveItem = dict(item or {})
            self._playingLiveUrl = str(url or "")
            _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
            _CURRENT_LIVE_CHANNEL["channel"] = live_id
            try: self.source["_tivimate_current_live_id"] = live_id
            except Exception: pass
            self.keepCurrentLiveService = True
            if guard is not None:
                # Same lifecycle policy as Ultra: the old external player is
                # eligible for cleanup only AFTER a replacement was accepted.
                # Do the /proc enumeration in Ultra's reusable worker, not on
                # Enigma2's GUI thread.  Fast re-selection of the old URL must
                # never kill the newly active service.
                retired_url = (previous_external_url if previous_external_url != str(url) else "")
                capture_url = (str(url) if int(service_type) in (5001, 5002, 8193, 8903) else "")
                if retired_url or capture_url:
                    def cleanup_old_stream(retired=retired_url, captured=capture_url,
                                           old_guard=guard, owner=self):
                        try:
                            current = str(getattr(owner, '_playingLiveUrl', '') or '')
                            if retired and current != retired:
                                old_guard.retire(retired)
                            if captured and current == captured:
                                old_guard.capture(captured)
                        except Exception:
                            pass
                    try:
                        _ULTRA_LIVE_PREVIEW_CLEANUP.submit(cleanup_old_stream)
                    except Exception:
                        # Failure to enqueue cleanup may not block playback or
                        # justify a synchronous /proc scan in the OK callback.
                        pass
            # Do not mark Xtream/M3U as playing merely because playService
            # accepted the reference: the decoder may still be loading forever.
            # Use the same bounded, cancellable verification as Stalker in
            # both ordinary Live and Windows, with no blocking dialog.
            self._beginLivePreviewCheck(ref, item, _on_complete, play_source)
            return True
        except Exception as exc:
            try: self["meta"].setText("Unable to change channel: %s" % exc)
            except Exception: pass
            if _on_complete is not None:
                try: _on_complete(False)
                except Exception: pass
            return False


    def _stalkerPlaySource(self):
        if self.kind != "live":
            return None
        source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
        return source if isinstance(source, dict) else None

    def _startStalkerWatchdog(self):
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            return
        try:
            self.stalkerWatchdogTimer.stop()
        except Exception:
            pass
        try:
            self.stalkerWatchdogTimer.start(30000, False)
        except Exception:
            pass

    def _runStalkerWatchdog(self):
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            return
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference() is not None
        except Exception:
            active = False
        if not active or not getattr(self, "keepCurrentLiveService", False):
            try:
                self.stalkerWatchdogTimer.start(30000, False)
            except Exception:
                pass
            return
        if getattr(self, "stalkerWatchdogPending", False):
            try:
                self.stalkerWatchdogTimer.start(30000, False)
            except Exception:
                pass
            return

        self.stalkerWatchdogPending = True
        client = self.stalkerWatchdogClient
        source_snapshot = dict(source)

        def worker():
            try:
                connection = client or get_source_client(source_snapshot)
                if connection is not None:
                    connection.watchdog()
                    self.stalkerWatchdogClient = connection
            except Exception:
                pass
            finally:
                self.stalkerWatchdogPending = False

        thread = threading.Thread(target=worker, name="TiviMateStalkerWatchdog")
        thread.daemon = True
        thread.start()
        try:
            self.stalkerWatchdogTimer.start(30000, False)
        except Exception:
            pass

    def restartCurrentLiveStream(self):
        """Manual restart for the active Stalker Live channel."""
        if self.kind != "live":
            return
        source = self._stalkerPlaySource()
        if not source or source.get("type") != "stalker":
            self.openBeinSports()
            return

        item = getattr(self, "_playingLiveItem", None) or self.current()
        if not item:
            try:
                self["meta"].setText(tr("No active channel to restart"))
            except Exception:
                pass
            return

        try:
            self["meta"].setText(tr("Restarting stream..."))
        except Exception:
            pass

        if self._zapLiveItem(dict(item), True):
            try:
                self["meta"].setText(tr("Stream restarted"))
            except Exception:
                pass
        else:
            try:
                self["meta"].setText(tr("Unable to restart stream"))
            except Exception:
                pass


    def _autoZapCurrent(self):
        if not self.channelSettings.get("auto_zap", True):
            return
        if self._isCurrentStalkerChannelLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
            return
        item = self.current()
        if not item:
            return
        # Negative cache is only for automatic previews. Pressing OK still
        # allows an immediate explicit retry after a server recovers.
        failures = getattr(self, '_autoZapFailureUntil', None)
        if failures is None:
            failures = {}
            self._autoZapFailureUntil = failures
        key = (str(_source_identity(self.source)),
               str(item.get('stream_id') or item.get('ch_id') or item.get('id') or
                   item.get('url') or item.get('cmd') or item.get('name') or ''))
        now = time.monotonic()
        if now < failures.get(key, 0.0):
            return
        def completed(success):
            if success:
                failures.pop(key, None)
            else:
                failures[key] = time.monotonic() + 15.0
                if len(failures) > 80:
                    for old, expiry in list(failures.items()):
                        if expiry <= time.monotonic():
                            failures.pop(old, None)
                    while len(failures) > 80:
                        failures.pop(next(iter(failures)))
        # _zapLiveItem itself invokes the callback on synchronous failures;
        # avoid recording the same failed attempt twice.
        self._zapLiveItem(item, False, _on_complete=completed)

    def _showLivePicon(self, item):
        """One Live Picon path for every provider."""
        try:
            self._sidePiconReqId = int(getattr(self, "_sidePiconReqId", 0) or 0) + 1
        except Exception:
            self._sidePiconReqId = 1
        req_id = self._sidePiconReqId

        blank = os.path.join(PLUGIN_PATH, "skins", "common", "te2_fallback.png")
        try:
            if self["channelPicon"].instance and os.path.exists(blank):
                self["channelPicon"].instance.setPixmapFromFile(blank)
            self["channelPicon"].show()
        except Exception:
            pass

        item = item or {}
        from .estalker_picon import resolve_picon_url
        url = resolve_picon_url(item, self.source)

        if not url.startswith(("http://", "https://")):
            self._sidePiconPending = None
            return

        self._sidePiconPending = (req_id, url)
        try:
            from .estalker_picon import cached_picon_path
            # Ultra-like cache-first path: no 250 ms delay on a saved icon.
            if cached_picon_path(url, (220, 130)):
                self.livePiconTimer.stop()
                self._finishLivePicon()
                return
        except Exception:
            pass
        try:
            self.livePiconTimer.stop()
            self.livePiconTimer.start(150, True)
        except Exception:
            self._finishLivePicon()

    def _finishLivePicon(self):
        pending = getattr(self, '_sidePiconPending', None)
        self._sidePiconPending = None
        if not pending:
            return

        req_id, url = pending
        if req_id != int(getattr(self, '_sidePiconReqId', 0) or 0):
            return

        def current_id():
            return int(getattr(self, '_sidePiconReqId', 0) or 0)

        def apply_path(path):
            if req_id != current_id() or not path:
                return
            try:
                if self['channelPicon'].instance:
                    self['channelPicon'].instance.setPixmapFromFile(path)
                    self['channelPicon'].show()
            except Exception:
                pass

        direct_picon(
            url,
            (220, 130),
            req_id,
            current_id,
            apply_path,
            prefix='xst_live_picon_'
        )

    def _livePiconDecoded(self, picInfo=None):
        return



    def _applyFavouriteKindLayout(self, kind):
        # Live uses compact square/circular tiles; Movies/Series retain portrait posters.
        if kind == "live":
            self.POSTER_X = (345, 555, 765, 975, 1185, 1395)
            self.POSTER_Y = 365
            for slot in range(self.PAGE_SIZE):
                try:
                    self["poster%d" % slot].instance.resize(eSize(sx(130), sy(130)))
                    self["posterTitle%d" % slot].instance.move(ePoint(sx(self.POSTER_X[slot]-20), sy(505)))
                    self["posterTitle%d" % slot].instance.resize(eSize(sx(170), sy(62)))
                except Exception: pass
            try:
                self["posterSelector"].instance.resize(eSize(sx(144), sy(144)))
                self["posterSelector"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/live_focus_circle.png")
            except Exception: pass
        else:
            self.POSTER_X = (335, 555, 775, 995, 1215, 1435); self.POSTER_Y = 330
            for slot in range(self.PAGE_SIZE):
                try:
                    self["poster%d" % slot].instance.resize(eSize(sx(150), sy(220)))
                    self["posterTitle%d" % slot].instance.move(ePoint(sx(self.POSTER_X[slot]-10), sy(562)))
                    self["posterTitle%d" % slot].instance.resize(eSize(sx(170), sy(58)))
                except Exception: pass
            try:
                self["posterSelector"].instance.resize(eSize(sx(162), sy(232)))
                self["posterSelector"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/poster_focus_white.png")
            except Exception: pass

    def renderPosterPage(self):
        # Invalidate every former slot before the next page can receive a late
        # network/ePicLoad callback. Do not discard active loader references.
        self._poster_page_serial += 1
        self._poster_artwork_requests = {}
        for slot in range(5):
            idx=self.pageStart+slot
            item=self.mediaItemsCurrent[idx] if idx < len(self.mediaItemsCurrent) else None
            self._poster_slot_tokens[slot] = (self._poster_page_serial, idx)
            self._setVisibleWidget("poster%d"%slot, bool(item))
            # r410: keep card chrome/details hidden until the poster itself is ready.
            # This removes the temporary gray metadata blocks during initial loading.
            self._setVisibleWidget("posterShell%d"%slot, False)
            # Track whether this visible poster slot has actually decoded artwork.
            # Provider vod_info may arrive later and can fill a blank/broken slot.
            try:
                self._poster_slot_ready[slot] = False
            except Exception:
                self._poster_slot_ready = {slot: False}
            self._setVisibleWidget("posterLabel%d"%slot, False)
            self._setVisibleWidget("posterYear%d"%slot, False)
            self._setVisibleWidget("posterRateBg%d"%slot, False)
            self._setVisibleWidget("posterRate%d"%slot, False)
            # UI-only title: strip source/language/quality prefixes and clip
            # on a whole word. Leave the original item untouched for playback,
            # lookups, favorites and TMDb identity matching.
            # Large original cards show a centred name and a separate golden year.
            # Keep the optional circular poster style's existing caption unchanged.
            raw_caption = visible_title(item.get("name") or item.get("title") or "", 31) if item else ""
            if getattr(self, "posterViewStyle", "original") == "circle":
                self["posterLabel%d"%slot].setText(raw_caption)
                self["posterYear%d"%slot].setText("")
            else:
                caption = re.sub(r"\s*(?:\((?:19|20)\d{2}\)|\[(?:19|20)\d{2}\])\s*$", "", raw_caption).strip()
                self["posterLabel%d"%slot].setText(caption or raw_caption)
                self["posterYear%d"%slot].setText(self._posterDisplayYear(item) if item else "")
            rate = ""
            if item:
                try:
                    from .resolution_badge import extract_rating
                    valid_rating = extract_rating(item)
                    rate = valid_rating.replace("★", "").strip() if valid_rating else ""
                except Exception:
                    rate = ""
            # Identical score in the existing pink-star badge for both layouts.
            # Never show '0' as an IMDb/TMDb score for missing metadata.
            self["posterRate%d" % slot].setText(rate)
            self._setPlaceholder(slot)
            if item:
                # The large Movies/TV Shows page resolves provider URLs and
                # already-known TMDb posters before decoding. Do the same for
                # this small five-card grid so both reuse one poster cache.
                # No extra TMDb/server requests are introduced here.
                url = self._sharedVisiblePosterUrl(item)
                if url:
                    # Package poster grid: reveal disk/RAM cached posters immediately.
                    # Do not send already-cached artwork back through the shared queue;
                    # that made the whole row appear together after a short wait.
                    cached = cached_artwork(url, "posters")
                    if cached:
                        self._poster_artwork_requests[slot] = (url or "").strip().replace("\\/", "/")
                        # r430: a cached provider URL is not proof that the cached
                        # file is a decodable poster. Some IPTV servers return a
                        # tiny error/HTML file which artwork_queue can still cache.
                        # Validate it before decode; if unusable, discard it and
                        # continue through the existing TMDb title fallback.
                        if self._posterFileUsable(cached):
                            self._decodeSlot(slot, cached, item)
                        else:
                            try:
                                if cached and os.path.exists(cached):
                                    os.remove(cached)
                            except Exception:
                                pass
                            self._tmdbPosterSlotFallback(slot, item)
                    else:
                        self._loadPosterSlot(slot, url, item)
                else:
                    self._tmdbPosterSlotFallback(slot, item)
        self._setVisibleWidget("selector", bool(self.mediaItemsCurrent))
        self.moveSelector(); self.previewVod()
        # Poster speed test: after the five visible cards are queued at high
        # priority, prefetch a bounded part of the current category in the
        # background. request_artwork deduplicates existing/running files and
        # keeps only four network transfers active, so navigation stays usable.
        self._prefetchCategoryPosters()

    def _sharedVisiblePosterUrl(self, item):
        """Reuse a LARGE-page cached poster without extra network requests.

        Pure URL extraction + local cache probe. If nothing has been cached,
        return the existing provider value so the old downloader/TMDb fallback
        and the exact same limited prefetch window remain unchanged.
        """
        if not isinstance(item, dict):
            return ""
        # Recent Add stores provider catalogue rows separately from artwork.
        # A resolved TMDb/provider fallback is already saved by _decodeSlot in
        # the shared per-source poster index. The refreshed Recent list does
        # not contain that fallback URL, so a reopen otherwise repeats the
        # lookup/download despite the original image remaining on disk.
        # Reuse the verified cached winner, without new requests or queues.
        if self.selectedCategory() == "__recent_added__":
            try:
                from .poster_resolution_cache import cached_decoded_url
                winner = cached_decoded_url(self.source, self.kind, item)
                if winner:
                    return winner
            except Exception:
                pass
        raw = (item.get("stream_icon") or item.get("cover") or
               item.get("movie_image") or item.get("poster_path") or "")
        try:
            from .poster_manager import provider_poster_url, tmdb_poster_url
            # GENRE/large Home use a single poster cache even across TMDb sizes.
            candidate = tmdb_poster_url(item.get("_tmdb_poster"))
            if candidate and cached_artwork(candidate, "posters"):
                return candidate
            for key in ("_resolved_server_poster", "_player_cover"):
                value = item.get(key)
                if not value:
                    continue
                candidate = provider_poster_url(self.source, {"stream_icon": value})
                if candidate and cached_artwork(candidate, "posters"):
                    return candidate
            candidate = provider_poster_url(self.source, item)
            if candidate and cached_artwork(candidate, "posters"):
                return candidate
            # When an item lacks the older four fields, prefer the same server
            # URL already known to Home rather than starting a TMDb title search.
            return raw or ""
        except Exception:
            return raw

    def _prefetchCategoryPosters(self):
        if self.kind not in ("vod", "series"):
            return
        # Package grids only prefetch a small window around the current page.
        # Prefetching an entire large package can saturate disk/network and delays
        # the five posters the user is actually looking at. Cached files are skipped
        # by prefetch_artwork automatically.
        start = max(0, int(self.pageStart or 0))
        stop = min(len(self.mediaItemsCurrent or []), start + 10)
        urls = []
        for item in list((self.mediaItemsCurrent or [])[start:stop]):
            try:
                url = self._sharedVisiblePosterUrl(item)
                if url:
                    urls.append(url)
            except Exception:
                pass
        if self.selectedCategory() != "__recent_added__":
            prefetch_artwork(urls, "posters", priority=2)


    def _setVisibleWidget(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
                pass

    def _setPlaceholder(self, slot):
        try:
            if getattr(self, "posterViewStyle", "original") == "circle":
                # Keep the full-bleed base/focus circles at their fixed sizes.
                x = int(self.POSTER_X[slot])
                y = int(getattr(self, "posterY", 575))
                for name, offset, size in (("poster%d" % slot, 3, 264),
                                           ("posterFocus%d" % slot, 5, 260)):
                    try:
                        instance = self[name].instance
                        if instance:
                            instance.move(ePoint(sx(x + offset), sy(y + offset)))
                            instance.resize(eSize(*scale_size(size, size)))
                    except Exception:
                        pass
            placeholder = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/vod_circle_no_poster_r270.png" if getattr(self, "posterViewStyle", "original") == "circle" else "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_loading_transparent_r410.png"
            self["poster%d"%slot].instance.setPixmapFromFile(placeholder)
            if getattr(self, "posterViewStyle", "original") == "circle":
                try:
                    self["posterFocus%d" % slot].instance.setPixmapFromFile(placeholder)
                except Exception:
                    pass
        except Exception: pass

    def _posterFileUsable(self, path):
        return usable_poster_file(path, minimum_bytes=1024)

    def _tmdbPosterSearchTitles(self, title):
        """Return safe ordered TMDb query variants for small Series/Movie posters.

        Keep the provider title untouched for display.  The full title is always
        searched first.  Some Arabic IPTV catalogs append a descriptive suffix
        such as "القصة الكاملة دراما: لعبة جهنم"; when that very specific
        mid-title marker is present, also try the text before "دراما:".
        Titles where "دراما" is a normal word (for example "دراما الحب")
        or appears at the start are never shortened.
        """
        raw = str(title or "").strip()
        if not raw:
            return []
        out = [raw]
        try:
            match = re.match(r"^(.+?)\s+دراما\s*:\s*(.+)$", raw, flags=re.UNICODE)
            if match:
                base = re.sub(r"\s+", " ", match.group(1)).strip(" -|:/._")
                suffix = re.sub(r"\s+", " ", match.group(2)).strip()
                # Be conservative: require a meaningful multi-word base and suffix.
                if base and suffix and len(base.split()) >= 2 and base not in out:
                    out.append(base)
        except Exception:
            pass
        return out

    def _tmdbPosterSlotFallback(self, slot, item):
        title = (item or {}).get("name") or (item or {}).get("title") or (item or {}).get("original_title") or ""
        if not title:
            return
        token = "%s:%s:%s" % (self.kind, str((item or {}).get("stream_id") or (item or {}).get("series_id") or ""), str(title))
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = token
        expected_slot = self._poster_slot_tokens.get(slot)
        def worker():
            try:
                raw_year = (item or {}).get("year") or (item or {}).get("releaseDate") or (item or {}).get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                found = {}
                client = TMDbClient()
                for search_title in self._tmdbPosterSearchTitles(title):
                    found = client.search_artwork(search_title, self.kind, year, required_key="poster_path") or {}
                    if found.get("poster_path"):
                        break
                path = found.get("poster_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(path)
                def apply():
                    if (getattr(self, "_poster_artwork_requests", {}).get(slot) != token or
                            self._poster_slot_tokens.get(slot) != expected_slot):
                        return
                    self._loadPosterSlot(slot, url, None)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateCategoryPosterTMDB")
        thread.daemon = True
        thread.start()

    def _loadPosterSlot(self, slot, url, fallback_item=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_item is not None:
                self._tmdbPosterSlotFallback(slot, fallback_item)
            return
        requests = getattr(self, "_poster_artwork_requests", None)
        if requests is None:
            requests = {}
            self._poster_artwork_requests = requests
        requests[slot] = url
        expected_slot = self._poster_slot_tokens.get(slot)

        def done(path, s=slot, expected=url, item=fallback_item):
            if (getattr(self, "_poster_artwork_requests", {}).get(s) != expected or
                    self._poster_slot_tokens.get(s) != expected_slot):
                return
            if not self._posterFileUsable(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                if item is not None:
                    self._tmdbPosterSlotFallback(s, item)
                return
            self._decodeSlot(s, path, item)

        def failed(_path, s=slot, item=fallback_item):
            if (self._poster_slot_tokens.get(s) == expected_slot and
                    getattr(self, "_poster_artwork_requests", {}).get(s) == url and item is not None):
                self._tmdbPosterSlotFallback(s, item)

        cached = cached_artwork(url, "posters")
        if cached and self._posterFileUsable(cached):
            done(cached)
        else:
            if cached:
                try: os.remove(cached)
                except OSError: pass
            request_artwork(url, "posters", done, priority=110,
                            errback=failed if fallback_item is not None else None,
                            source=dict(self.source or {}))

    def _decodeSlot(self, slot, path, fallback_item=None):
        if getattr(self, "_poster_fit_closed", False):
            return
        expected_slot = self._poster_slot_tokens.get(slot)
        expected_request = self._poster_artwork_requests.get(slot)
        if not self._posterFileUsable(path):
            if fallback_item is not None:
                self._tmdbPosterSlotFallback(slot, fallback_item)
            return
        if getattr(self, "posterViewStyle", "original") == "circle":
            render_width, render_height = scale_size(264, 264)
        else:
            render_width, render_height = scale_size(270, 380)
        loader=ePicLoad(); self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader, item=fallback_item):
            try:
                if (getattr(self, "_poster_fit_closed", False) or
                        self._poster_slot_tokens.get(s) != expected_slot or
                        self._poster_artwork_requests.get(s) != expected_request):
                    # Stale decoder must still release its native reference.
                    try: self.picloads.remove(l)
                    except (ValueError, AttributeError): pass
                    return
                ptr = l.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
                    # Passive positive-only poster cache bridge. This does NOT
                    # alter the large page's downloader, decode or layout.
                    try:
                        from .poster_resolution_cache import remember_decoded
                        row = self.mediaItemsCurrent[self.pageStart + s]
                        remember_decoded(self.source, self.kind, row, expected_request)
                    except Exception:
                        pass
                    try:
                        self._poster_slot_ready[s] = True
                    except Exception:
                        self._poster_slot_ready = {s: True}
                    # Reveal the normal card shell/rating/title only with real artwork.
                    if getattr(self, "posterViewStyle", "original") != "circle":
                        self._setVisibleWidget("posterShell%d" % s, True)
                    self._setVisibleWidget("posterLabel%d" % s, True)
                    if str(self["posterYear%d" % s].getText() or "").strip():
                        self._setVisibleWidget("posterYear%d" % s, True)
                    if str(self["posterRate%d" % s].getText() or "").strip():
                        self._setVisibleWidget("posterRate%d" % s, True)
                        self._setVisibleWidget("posterRateBg%d" % s, True)
                    if getattr(self, "posterViewStyle", "original") == "circle":
                        try:
                            if self["posterFocus%d" % s].instance:
                                self["posterFocus%d" % s].instance.setPixmap(ptr)
                        except Exception:
                            pass
                elif item is not None:
                    # r430: valid-looking files can still fail Enigma2 image
                    # decoding (unsupported/corrupt payload). Fall back to TMDb
                    # instead of leaving the small poster blank.
                    self._tmdbPosterSlotFallback(s, item)
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        if getattr(self, "posterViewStyle", "original") == "circle":
            # Exact square fill: no aspect-fit bars or tiny rectangular image.
            # The source pixmap fills the full round opening. Focus scale=1
            # maps the same raster to the fixed 260px selected surface.
            loader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        else:
            # Original view keeps its existing exact-fill behaviour.
            loader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        loader.startDecode(path)

    def moveSelector(self):
        # Preserve the original 306px focus artwork diameter and keep its
        # position unchanged; the source poster fills its circular aperture.
        # Both poster surfaces have fixed round clipping, not a rectangle.
        try:
            circle_view = (getattr(self, "posterViewStyle", "original") == "circle")
            if self["selector"].instance:
                if circle_view:
                    x = int(self.POSTER_X[self.posterIndex])
                    y = int(getattr(self, "posterY", 610))
                    self["selector"].instance.move(ePoint(sx(x-18), sy(y-18)))
                    self["selector"].instance.resize(eSize(sx(306), sy(306)))
                else:
                    self["selector"].instance.move(ePoint(sx(self.POSTER_X[self.posterIndex]), sy(getattr(self, "posterY", 525))))
                self["selector"].show()
            for i in range(5):
                try:
                    selected = (i == self.posterIndex)
                    if circle_view:
                        fp = self["posterFocus%d" % i]
                        if selected:
                            fp.show()
                        else:
                            fp.hide()
                    label = self["posterLabel%d" % i].instance
                    if label:
                        # Keep large-page title text compact even on selection.
                        # The circle skin retains its original focus animation/font.
                        title_size = (25 if selected else 20) if circle_view else 19
                        label.setFont(gFont("Regular", max(14, sy(title_size))))
                        label.setForegroundColor(parseColor("#FFFFFF" if selected else "#D8DDE3"))
                    year_label = self["posterYear%d" % i].instance
                    if year_label:
                        year_label.setFont(gFont("Regular", max(13, sy(17))))
                        year_label.setForegroundColor(parseColor("#FFD34E" if selected else "#F1C84C"))
                    rate = self["posterRate%d" % i].instance
                    if rate:
                        rate.setForegroundColor(parseColor(
                            "#FFFFFF"))
                except Exception:
                    pass
        except Exception:
            pass

    def scheduleSelectedInfo(self):
        if self.kind not in ("vod", "series"):
            return
        try: self.infoTimer.stop()
        except Exception: pass
        # If the selected large-page poster is still blank, resolve provider
        # metadata/cache almost immediately. loadSelectedInfo() itself remains
        # cache-first (RAM -> provider_info disk cache -> server), so cached
        # provider posters paint on first open instead of waiting for navigation.
        # TV Shows: start provider-info prefetch almost immediately while the
        # user is still on the poster grid.  The completed get_series_info reply
        # is also seeded into the exact persistent cache used by SeriesDetails,
        # so the FIRST open can reuse it instead of issuing the same request again.
        delay = 80  # Movies and Series: resolve cached/provider artwork without the old 900ms movie delay.
        try:
            slot = int(getattr(self, "posterIndex", 0) or 0)
            if not bool(getattr(self, "_poster_slot_ready", {}).get(slot, False)):
                delay = 80
        except Exception:
            pass
        try: self.infoTimer.start(delay, True)
        except Exception: self.loadSelectedInfo()

    def loadSelectedInfo(self):
        if SAFE_TABLE_MODE:
            return
        item = self.current()
        if not item:
            return
        if str(self.source.get("type") or "").lower() not in ("xtream", "stalker"):
            self._loadSelectedTmdbInfo(item, metadata_only=True)
            return
        mid = str(item.get("stream_id") or item.get("series_id") or "")
        if not mid:
            self._loadSelectedTmdbInfo(item)
            return
        # Server IDs are not globally unique: do not reuse another provider's
        # movie/series info on the large page or in its persistent disk cache.
        key = provider_cache_key(self.kind, mid, self.source)
        cached = self.fullInfoCache.get(key)
        if cached is not None:
            self.applySelectedInfo(mid, cached, key)
            return
        if key in self.infoProcesses:
            return
        try:
            if self.source.get("type") == "stalker":
                self._loadSelectedTmdbInfo(item)
                return
            client = XtreamClient(self.source)
            action = "get_vod_info" if self.kind == "vod" else "get_series_info"
            try:
                from urllib.parse import urlencode
            except ImportError:
                from urllib import urlencode
            url = client.base + "/player_api.php?" + urlencode({
                "username": client.user,
                "password": client.password,
                "action": action,
                ("vod_id" if self.kind == "vod" else "series_id"): mid,
            })
            cache_dir = get_cache_dir("metadata")
            try:
                ensure_dir(cache_dir)
            except Exception:
                pass
            path = os.path.join(cache_dir, "provider_info_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            # Cache-first for provider-resolved large-page posters/info. The provider
            # response is already persisted here by INFO_FETCH; reuse it before any
            # new server request so applySelectedInfo can resolve the same poster URL
            # and request_artwork can immediately hit the persistent poster cache.
            try:
                if os.path.exists(path) and os.path.getsize(path) > 2:
                    with open_text(path, "r", encoding="utf-8") as f:
                        disk_data = json.load(f)
                    if isinstance(disk_data, dict) and disk_data:
                        self.fullInfoCache[key] = disk_data
                        self.applySelectedInfo(mid, disk_data, key)
                        return
            except Exception:
                pass
            proc = eConsoleAppContainer()
            self.infoProcesses[key] = proc
            self.pendingInfoId = mid
            def done(ret, k=key, m=mid, p=path):
                self.infoProcesses.pop(k, None)
                if ret != 0 or not os.path.exists(p):
                    current = self.current()
                    if current:
                        self._loadSelectedTmdbInfo(current)
                    return
                try:
                    with open_text(p, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    self.fullInfoCache[k] = data or {}
                    # Seed SeriesDetails' own Xtream disk cache from this
                    # background poster-grid prefetch.  Previously the grid wrote
                    # provider_info_*.json, but SeriesDetails used a different
                    # cache key and fetched get_series_info again on first open.
                    if self.kind == "series" and self.source.get("type") == "xtream" and isinstance(data, dict) and data:
                        try:
                            from .cache_manager import stable_cache_key, persistent_cache_set
                            xc = XtreamClient(self.source)
                            ck = stable_cache_key("xtream:series_info", xc.base, xc.user, xc.password, str(m))
                            persistent_cache_set(ck, "xtream_series_info", data, 6 * 60 * 60)
                        except Exception:
                            pass
                    self.applySelectedInfo(m, data or {}, k)
                except Exception:
                    pass
            try:
                proc.appClosed.append(done)
            except Exception:
                proc.appClosed.get().append(done)
            proc.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, INFO_FETCH, url, path)
        except Exception:
            return

    def _setLargePageFacts(self, year="", genres="", runtime=""):
        """Anchor year, category and a credible duration to the left.

        Reuse the same runtime formatting rules as the details pages.  When the
        provider returns a bogus placeholder such as ``0 min`` we hide it and
        fall back to structured runtime fields from the current item/provider
        cache/TMDb bundle, instead of painting an obviously wrong badge.
        """
        if self.kind not in ("vod", "series"):
            return
        raw_year = str(year or "").strip()
        match = re.search(r"\b(?:19|20)\d{2}\b", raw_year)
        year_text = match.group(0) if match else (raw_year[:4] if raw_year[:4].isdigit() else "")
        genre_text = str(genres or "").strip()
        runtime_text = ""
        try:
            from .resolution_badge import format_duration, extract_duration
            raw_runtime = runtime
            runtime_text = format_duration(raw_runtime)
            if not runtime_text:
                current = self.current() or {}
                media_id = str(current.get("stream_id") or current.get("series_id") or current.get("vod_id") or current.get("id") or "")
                source_key = provider_cache_key(self.kind, media_id, self.source) if media_id else ""
                provider_data = (self.fullInfoCache.get(source_key) or {}) if source_key else {}
                tmdb_data = {}
                remembered = getattr(self, "_selected_tmdb_metadata", None)
                if remembered and isinstance(remembered, (list, tuple)) and len(remembered) >= 3:
                    key = str(remembered[0] or "")
                    if (source_key and key.startswith(source_key + ":")) or not source_key:
                        tmdb_data = remembered[2] or {}
                runtime_text = extract_duration(current, provider_data, tmdb_data)
        except Exception:
            runtime_text = str(runtime or "").strip()
        if runtime_text in ("0 min", "0m", "0h 00m"):
            runtime_text = ""
        self["meta"].setText("    •    ".join(v for v in (year_text, genre_text, runtime_text) if v))

    def _applySelectedPosterBadgeRating(self, value):
        """Only update the current card's existing pink rating badge.

        Both large and round layouts reuse posterRate0..4. A late TMDb result
        is applied only to the currently selected slot; the asynchronous
        callers separately guard against stale selection tokens.
        """
        if self.kind not in ("vod", "series"):
            return
        try:
            from .resolution_badge import extract_rating
            badge = extract_rating({"vote_average": value})
            if not badge:
                return
            value_text = badge.replace("★", "").strip()
            slot = int(self.posterIndex)
            if not 0 <= slot < 5:
                return
            self["posterRate%d" % slot].setText(value_text)
            if bool(getattr(self, "_poster_slot_ready", {}).get(slot, False)):
                self._setVisibleWidget("posterRate%d" % slot, True)
                self._setVisibleWidget("posterRateBg%d" % slot, True)
        except Exception:
            pass

    def _setSelectedTmdbScore(self, token, vote_average):
        """Use exactly the same pink TMDb rating as movie details."""
        if self.kind not in ("vod", "series") or getattr(self, "_titleLogoToken", "") != token:
            return
        try:
            self._applySelectedPosterBadgeRating(vote_average)
        except Exception:
            pass

    def _stableSelectedMediaTitle(self, candidate, item):
        """Keep an Arabic title when late metadata describes the same entry."""
        value = str(candidate or "").strip()
        try:
            from .metadata_display import keep_arabic_on_late_update
            from .tmdb_client import TMDbClient
            current = item or self.current() or {}
            media_id = str(current.get("stream_id") or current.get("series_id") or current.get("vod_id") or current.get("id") or "")
            key = provider_cache_key(self.kind, media_id, self.source)
            # Protect rapid switching between catalogue rows with missing IDs.
            if not media_id:
                key += ":" + str(current.get("name") or current.get("title") or "")
            language = TMDbClient().language
            if getattr(self, "_stable_media_title_key", None) == key:
                value = keep_arabic_on_late_update(
                    getattr(self, "_stable_media_title_value", ""), value, language)
            self._stable_media_title_key = key
            self._stable_media_title_value = value
        except Exception:
            pass
        return value

    def _loadSelectedTmdbInfo(self, item, metadata_only=False):
        """Apply the selected TMDb language even when server artwork is present.

        Provider metadata paints instantly; TMDb may update text later. On a
        metadata-only refresh, do not change the already-working backdrop.
        """
        current = self.current() or {}
        title = (current.get("name") or current.get("title") or current.get("original_title") or
                 (item or {}).get("name") or (item or {}).get("title") or "")
        if not title:
            return
        item_id = str(current.get("stream_id") or current.get("series_id") or "")
        source_key = provider_cache_key(self.kind, item_id, self.source)
        expected = "%s:%s" % (source_key, title)
        self._tmdb_selected_token = expected
        snapshot = dict(item or {})
        media_kind = self.kind
        def worker():
            try:
                raw_year = (snapshot.get("year") or snapshot.get("releaseDate") or
                            snapshot.get("releasedate") or current.get("year") or "")
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                year = match.group(0) if match else None
                client = TMDbClient()
                tid = snapshot.get("tmdb_id") or snapshot.get("tmdb") or current.get("tmdb_id") or current.get("tmdb")
                found = {}
                if not tid:
                    found = client.search_artwork(title, media_kind, year) or {}
                    tid = found.get("id")
                bundle = client.details_bundle(tid, media_kind) if tid else found
                def apply():
                    if getattr(self, "_tmdb_selected_token", "") != expected:
                        return
                    if source_key != provider_cache_key(self.kind, item_id, self.source):
                        return
                    selected = self.current() or {}
                    current_title = selected.get("name") or selected.get("title") or selected.get("original_title") or ""
                    selected_id = str(selected.get("stream_id") or selected.get("series_id") or "")
                    if str(current_title) != str(title) or selected_id != item_id:
                        return
                    merged = dict(snapshot)
                    data = bundle or {}
                    language = str(client.language or "").lower()
                    # Use full server details cached by this EXACT source, not
                    # only the sparse row used when the TMDb request started.
                    provider_data = self.fullInfoCache.get(source_key) or {}
                    # Scoped to BOTH the source and selected item. The provider
                    # callback may arrive later and must retain this TMDb locale.
                    self._selected_tmdb_metadata = (expected, language, dict(data))
                    info = merge_metadata(merged, provider=provider_data,
                                          tmdb=data, language=language, kind=media_kind)
                    if data.get("id") or data.get("overview"):
                        stable_title = self._stableSelectedMediaTitle(info["title"] or title, selected)
                        self["channelTitle"].setText(visible_title(stable_title, 62))
                        self._setLargePageFacts(info["year"], info["genre"],
                            ("%s min" % info["runtime"]) if info["runtime"] else "")
                        # The pink rating only accepts a verified TMDb value.
                        if data.get("id") and info["official_rating"]:
                            self._applySelectedPosterBadgeRating(data.get("vote_average"))
                    if info["description"]:
                        self["desc"].setText(info["description"][:650])
                    if not metadata_only:
                        back = data.get("backdrop_path") or ""
                        if back:
                            if not str(back).startswith(("http://", "https://")):
                                back = backdrop_url(str(back))
                            self.loadBackdrop(back)
                # Native Enigma widgets must be updated on its UI thread.
                if reactor:
                    reactor.callFromThread(apply)
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateSelectedTMDB")
        thread.daemon = True
        thread.start()

    def applySelectedInfo(self, mid, data, expected_key=None):
        current = self.current()
        current_id = str((current or {}).get("stream_id") or (current or {}).get("series_id") or "")
        if current_id != str(mid):
            return
        # A request from another server can have the same stream/series ID.
        # Match the entire server-scoped key before touching any text/artwork.
        if expected_key is not None and expected_key != provider_cache_key(self.kind, mid, self.source):
            return
        item = current or {}
        info = (data or {}).get("info") or {}
        movie = (data or {}).get("movie_data") or {}
        merged = {}
        merged.update(item)
        merged.update(movie)
        merged.update(info)
        language = TMDbClient().language
        title_identity = str(item.get("name") or item.get("title") or item.get("original_title") or "")
        expected_locale_key = "%s:%s" % (provider_cache_key(self.kind, mid, self.source), title_identity)
        remembered = getattr(self, "_selected_tmdb_metadata", None)
        tmdb_data = (remembered[2] if remembered and
                     remembered[0] == expected_locale_key and
                     str(remembered[1]).lower() == str(language).lower() else {})
        display = merge_metadata(item, provider=data, tmdb=tmdb_data,
                                 language=language, kind=self.kind)
        title = display["title"]
        year = display["year"]
        rating = display["rating"]
        genre = display["genre"]
        try:
            from .resolution_badge import extract_rating
            provider_score = extract_rating(data, merged)
            if provider_score:
                self._applySelectedPosterBadgeRating(provider_score.replace("★", "").strip())
        except Exception:
            pass
        duration = display["runtime"] or merged.get("duration_secs") or ""
        stable_title = self._stableSelectedMediaTitle(title, item)
        self["channelTitle"].setText(visible_title(stable_title, 62))
        self._setLargePageFacts(year, genre, duration)
        self["desc"].setText((display["description"] or "لا توجد أية معلومات")[:650])
        back = merged.get("backdrop_path") or merged.get("backdrop") or merged.get("backdrop_url") or []
        if isinstance(back, list):
            back = back[0] if back else ""
        if isinstance(back, str):
            back = back.strip().replace(chr(92) + "/", "/")
            if back.startswith("["):
                try:
                    arr = json.loads(back)
                    back = arr[0] if arr else ""
                except Exception:
                    pass
            if back.startswith("/") and not back.startswith("//"):
                back = backdrop_url(back)
        # If the selected large Movies/TV page card is still blank, reuse the
        # provider poster returned by vod_info/series_info before any TMDb fallback.
        # This mirrors the details page behaviour without changing backdrop/meta.
        try:
            slot = int(getattr(self, "posterIndex", 0) or 0)
            ready = bool(getattr(self, "_poster_slot_ready", {}).get(slot, False))
            if not ready:
                # Sparse provider metadata can arrive without artwork fields even
                # though this movie poster is already present in the persistent
                # poster cache. Re-check the selected item cache here so the first
                # visible card is painted immediately; do not wait for a selection
                # change and do not start a new network request.
                item_poster = str(
                    item.get("stream_icon") or item.get("cover") or
                    item.get("movie_image") or item.get("poster_path") or ""
                ).strip().replace(chr(92) + "/", "/")
                if item_poster:
                    cached_poster = cached_artwork(item_poster, "posters")
                    if cached_poster and self._posterFileUsable(cached_poster):
                        self._poster_artwork_requests[slot] = item_poster
                        self._decodeSlot(slot, cached_poster, item)
                        ready = True
            if not ready:
                provider_poster = ""
                for src in (movie, info):
                    if not isinstance(src, dict):
                        continue
                    provider_poster = str(
                        src.get("stream_icon") or src.get("cover_big") or
                        src.get("cover") or src.get("movie_image") or
                        src.get("poster") or src.get("poster_url") or
                        src.get("poster_path") or src.get("image") or ""
                    ).strip().replace(chr(92) + "/", "/")
                    if provider_poster:
                        break
                if provider_poster:
                    self._loadPosterSlot(slot, provider_poster, item)
        except Exception:
            pass
        if back:
            self.loadBackdrop(back)
            # A complete English provider response is NOT complete localized
            # metadata when the user selected Arabic in TMDb Settings.
            needs_localized_text = (str(language).lower().startswith("ar") and
                                    any(not contains_arabic_text(display.get(field))
                                        for field in ("title", "description", "genre")))
            # Once this exact selection already has a localized TMDb bundle,
            # do not refetch it merely because TMDb has no translation for a
            # particular field. Its persistent cache will refresh on expiry.
            if not tmdb_data and (needs_localized_text or any(not display.get(field) for field in
                                                           ("title", "description", "year", "genre", "rating"))):
                self._loadSelectedTmdbInfo(merged, metadata_only=True)
        else:
            self._loadSelectedTmdbInfo(merged)

    def _showTitleText(self):
        if self.kind not in ("vod", "series"):
            return
        try:
            self["channelTitle"].show()
        except Exception:
            pass

    def _hideTitleText(self):
        if self.kind not in ("vod", "series"):
            return
        try:
            self["channelTitle"].hide()
        except Exception:
            pass

    def _posterDisplayYear(self, item):
        try:
            raw = " ".join(str((item or {}).get(k) or "") for k in ("year", "releaseDate", "releasedate", "release_date", "first_air_date", "name", "title"))
            m = re.search(r"\b(?:19|20)\d{2}\b", raw)
            return m.group(0) if m else ""
        except Exception:
            return ""

    def _hideTitleLogo(self):
        if self.kind not in ("vod", "series"):
            return
        try:
            self["titleLogo"].hide()
        except Exception:
            pass
        self._showTitleText()

    def _tmdbLogoUrl(self, bundle):
        from .logo_manager import best_tmdb_logo, tmdb_logo_url, preferred_logo_languages
        logos = ((bundle or {}).get("images") or {}).get("logos") or []
        return tmdb_logo_url(best_tmdb_logo(logos, preferred_logo_languages(details=bundle)), "w500")

    def _loadSelectedTitleLogo(self, item):
        if self.kind not in ("vod", "series") or not getattr(self, "packageTitleLogoEnabled", False):
            self._hideTitleLogo()
            return
        row = dict(item or {})
        title = row.get("name") or row.get("title") or row.get("original_title") or row.get("original_name") or ""
        if not str(title or "").strip():
            self._titleLogoToken = ""
            self._hideTitleLogo()
            return
        media_id = str(row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id") or "")
        from .logo_manager import logo_language
        token = "%s:%s:%s:%s" % (self.kind, media_id, str(title), logo_language())
        self._titleLogoToken = token
        self._hideTitleLogo()
        snapshot = dict(row)

        def worker():
            try:
                client = TMDbClient()
                # Match GENRE immediately, even when the catalogue row has no
                # TMDb id or TMDb search is unavailable.
                provider_logo = _provider_logo_url(self.source or {}, snapshot)
                if provider_logo:
                    def provider_ready(path):
                        if path and getattr(self, "_titleLogoToken", "") == token and reactor:
                            reactor.callFromThread(self._decodeTitleLogo, path, token)
                    _genre_transparent_logo(
                        provider_logo, dict(self.source or {}), provider_ready,
                        lambda _path: None,
                        lambda fn, value: reactor.callFromThread(fn, value) if reactor else fn(value))
                # Copy GENRE's verified identity flow. A provider's numeric
                # stream id is not automatically a TMDb id.
                year_text = " ".join(str(snapshot.get(k) or "") for k in ("year", "releaseDate", "releasedate", "release_date", "first_air_date"))
                year_match = re.search(r"(?:19|20)\d{2}", year_text)
                year = year_match.group(0) if year_match else None
                catalog_id = snapshot.get("tmdb_id") or snapshot.get("tmdb") or snapshot.get("tmdbId")
                found = (client.details_bundle(catalog_id, self.kind) if catalog_id else {}) or {}
                if found and not (found.get("title") or found.get("name")):
                    found = {}
                if not found:
                    found = client.search_artwork(title, self.kind, year) or {}
                tid = found.get("id") if isinstance(found, dict) else ""
                if not tid or getattr(self, "_titleLogoToken", "") != token:
                    return
                bundle = client.details_bundle(tid, self.kind) or found
                # The logo and the rating come from the same TMDb details
                # lookup. Do not issue a second network request per cursor move.
                vote = bundle.get("vote_average")
                if vote is not None and reactor:
                    reactor.callFromThread(self._setSelectedTmdbScore, token, vote)
                # Details responses often contain the provider clearlogo even
                # when the compact catalogue row does not. Pass both records,
                # exactly as the GENRE artwork resolver does.
                provider_logo = _provider_logo_url(self.source or {}, snapshot, bundle)
                if provider_logo:
                    def provider_ready(path):
                        if path and getattr(self, "_titleLogoToken", "") == token and reactor:
                            reactor.callFromThread(self._decodeTitleLogo, path, token)
                    _genre_transparent_logo(
                        provider_logo, dict(self.source or {}), provider_ready,
                        lambda _path: None,
                        lambda fn, value: reactor.callFromThread(fn, value) if reactor else fn(value))
                from .title_logo_ultra_bridge import resolve_title_logo
                image_path = resolve_title_logo(client, self.kind, tid, title=title,
                                                details=bundle, item=snapshot, canvas=(490, 130),
                                                cancelled=lambda: getattr(self, "_titleLogoToken", "") != token)
                if image_path and getattr(self, "_titleLogoToken", "") == token:
                    # ePicLoad and widget updates must execute on the GUI thread.
                    if reactor:
                        reactor.callFromThread(self._decodeTitleLogo, image_path, token)
            except Exception:
                pass

        thread = threading.Thread(target=worker, name="TiviMateTitleLogoTMDB")
        thread.daemon = True
        thread.start()

    def _decodeTitleLogo(self, path, token):
        if self.kind not in ("vod", "series") or not getattr(self, "packageTitleLogoEnabled", False) or getattr(self, "_titleLogoToken", "") != token:
            return
        loader = ePicLoad()
        self._titleLogoLoader = loader

        def ready(_info=None, expected=token, ref=loader):
            if getattr(self, "_titleLogoToken", "") != expected or self._titleLogoLoader is not ref:
                return
            try:
                ptr = ref.getData()
                if ptr and self["titleLogo"].instance:
                    self["titleLogo"].instance.setPixmap(ptr)
                    self["titleLogo"].show()
                    self._hideTitleText()
            except Exception:
                self._hideTitleLogo()

        connect_picture_data(loader, ready, self)
        width, height = scale_size(490, 130)
        loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def loadBackdrop(self, url):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            # Large package pages can select a title that has no backdrop of
            # its own. Reuse the permanent GENRE package image first instead
            # of leaving the whole 1920x1080 hero empty.
            try:
                source = self.source or {}
                kind = str(source.get("_genre_package_kind") or self.kind or "").strip()
                package_id = str(source.get("_genre_package_id") or self.initialCategoryId or "").strip()
                if kind in ("vod", "series") and package_id:
                    local = saved_genre_image(source, kind, package_id)
                    if local and os.path.isfile(local):
                        self._media_backdrop_request = local
                        self.decodeBackdrop(local)
                        return
                    # GENRE also keeps the successful source URL separately;
                    # use it when the permanent copy is not available yet.
                    cache_file = _genre_cache_file("package_backdrops.json")
                    saved = load_json(cache_file, {}) or {}
                    scope = _content_package_control_key(source, kind)
                    cached_url = str((saved.get(scope) or {}).get(package_id) or "").strip()
                    if cached_url:
                        url = cached_url.replace("\\/", "/")
            except Exception:
                pass
            if not url:
                return
        # When this Movies/TV Shows page was opened from GENRE, reuse the
        # first real backdrop that the page itself successfully resolves.
        # This avoids a second package scan and never stores GENERAL/empty art.
        try:
            package_id=str((self.source or {}).get("_genre_package_id") or "").strip()
            package_kind=str((self.source or {}).get("_genre_package_kind") or self.kind or "").strip()
            low=url.lower().replace("\\", "/")
            base=low.rsplit("/",1)[-1].split("?",1)[0]
            is_default=base in ("genre_default.jpg","genre_default.png","general.jpg","general.png")
            if package_id and package_kind in ("vod","series") and not is_default:
                if url.startswith("/"):
                    try: url=backdrop_url(url) or url
                    except Exception: pass
                cache_file=_genre_cache_file("package_backdrops.json")
                all_backdrops=load_json(cache_file,{}) or {}
                scope=_content_package_control_key(self.source,package_kind)
                scope_cache=all_backdrops.get(scope,{})
                if not isinstance(scope_cache,dict): scope_cache={}
                if not str(scope_cache.get(package_id) or "").strip():
                    scope_cache[package_id]=url
                    all_backdrops[scope]=scope_cache
                    save_json(cache_file,all_backdrops)
        except Exception:
            pass
        self._media_backdrop_request = url

        def done(path, expected=url):
            if getattr(self, "_media_backdrop_request", "") != expected:
                return
            if not path:
                return
            # GENRE packages keep the first real backdrop as a permanent image
            # file, rather than just a cached URL. Normal Movies/TV unaffected.
            try:
                genre_cid=str((self.source or {}).get("_genre_package_id") or "").strip()
                genre_kind=str((self.source or {}).get("_genre_package_kind") or self.kind or "")
                if genre_cid and genre_kind in ("vod", "series") and not saved_genre_image(self.source,genre_kind,genre_cid):
                    def store_genre_image(src=dict(self.source), kind=genre_kind, cid=genre_cid, image=path):
                        try: save_genre_image(src,kind,cid,image)
                        except Exception: pass
                    worker=threading.Thread(target=store_genre_image,name="TiviMateGenreSaveBackdrop")
                    worker.daemon=True; worker.start()
            except Exception:
                pass
            self.decodeBackdrop(path)

        # Use the exact GENRE downloader first: it validates image bytes,
        # preserves provider authentication and shares the persistent cache.
        source = dict(self.source or {})
        def ultra_ready(path):
            if path:
                done(path)
        def ultra_failed(_path):
            request_artwork(url, "backdrops", done, priority=115)
        def to_gui(fn, value):
            if reactor:
                reactor.callFromThread(fn, value)
            else:
                fn(value)
        try:
            _genre_ultra_request(url, "backdrops", source, ultra_ready, ultra_failed, to_gui)
        except Exception:
            request_artwork(url, "backdrops", done, priority=115)

    def decodeBackdrop(self, path):
        loader = ePicLoad()
        if not isinstance(getattr(self, "backdropLoaders", None), list):
            self.backdropLoaders = []
        self.backdropLoaders.append(loader)
        self.backdropLoader = loader
        def ready(_info=None, l=loader):
            try:
                ptr = l.getData()
                # Keep older native decoders alive until they finish; only the
                # newest selection is allowed to replace the visible backdrop.
                if self.backdropLoader is l and ptr and self["backdrop"].instance:
                    self["backdrop"].instance.setPixmap(ptr)
            except Exception:
                pass
            finally:
                try:
                    if l in self.backdropLoaders:
                        self.backdropLoaders.remove(l)
                    if self.backdropLoader is l:
                        self.backdropLoader = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(1920, 1080)
        loader.setPara((render_width,render_height,0,0,False,1,"#00000000"))
        loader.startDecode(path)

    def previewVod(self):
        item=self.current()
        self._tmdb_selected_token = ""  # invalidate previous selection's async localized metadata
        if not item:
            self._titleLogoToken = ""
            self._hideTitleLogo()
            self["ratingText"].setText("")
            self["channelTitle"].setText(tr("No content")); self["meta"].setText(""); self["desc"].setText(""); self["nowLabel"].setText(tr("0/0")); return
        # Clear the previous title's TMDb rating before async metadata arrives.
        # This also prevents a rating from being attributed to a new movie.
        self["ratingText"].setText("")
        self._loadSelectedTitleLogo(item)
        title=item.get("name") or item.get("title") or ""
        year=item.get("releaseDate") or item.get("year") or ""; genre=item.get("genre") or ""; dur=item.get("duration") or ""
        self["channelTitle"].setText(visible_title(
            self._stableSelectedMediaTitle(title, item), 62))
        self._setLargePageFacts(year, genre, dur)
        self["desc"].setText((item.get("plot") or item.get("description") or "لا توجد أية معلومات")[:600])
        self["nowLabel"].setText("%d / %d" % (self.pageStart+self.posterIndex+1, len(self.mediaItemsCurrent)))
        self.scheduleSelectedInfo()


    def _isContinuousPackage(self):
        """Only regular Movies/TV Shows package posters have no numbered pages."""
        if self.kind not in ("vod", "series") or self._movieGenreAllItems:
            return False
        if self.preloadedItems:
            # Preloaded actor/genre results keep their own existing paging.
            return bool(isinstance(self.source, dict) and self.source.get("_genre_package_id"))
        return not any(
            str(value or "") == "__recent_added__"
            for value in (getattr(self, "initialCategoryId", ""), getattr(self, "activeCategoryId", ""))
        )

    def _showContinuousPackage(self, items):
        """One ordered package list; rendering/decoding remains five at a time."""
        self._largePageAllItems = []
        self._largePage = 0
        # Caller has already sorted the complete package by selected order.
        # Deduplicate without resorting tens of thousands of items on UI thread.
        self.mediaItemsCurrent = _dedupe_content_rows(items or [], self.kind)
        self.pageStart = 0
        self.posterIndex = 0
        self.focus = "items"
        self.renderPosterPage()

    def _loadLargePackagePage(self, page, force=False):
        if not self._largePageAllItems:
            return False
        size = max(1, int(self._largePageSize or 30))
        pages = max(1, (len(self._largePageAllItems) + size - 1) // size)
        page = max(0, min(int(page), pages - 1))
        if page == self._largePage and self.mediaItemsCurrent and not force:
            return False
        self._largePage = page
        start = page * size
        self.showItems(self._largePageAllItems[start:start + size])
        self.focus = "items"
        try:
            label = self.activeCategoryName or self.initialCategoryName or (tr("MOVIES") if self.kind == "vod" else tr("TV SHOWS"))
            self["currentCategory"].setText(("%s  •  Page %d / %d" % (label, page + 1, pages)) if pages > 1 else label)
        except Exception:
            pass
        return True

    def _loadMovieGenrePage(self, page):
        if not self._movieGenreAllItems:
            return False
        size=max(1,int(self._movieGenrePageSize or 30))
        pages=max(1,(len(self._movieGenreAllItems)+size-1)//size)
        page=max(0,min(int(page),pages-1))
        # Always expose the Genre page counter, including the already-rendered
        # first page. Previously the early return skipped PAGE 1/X.
        try:
            self["currentCategory"].setText(("%s  •  Page %d / %d" % (self._movieGenreLabel, page + 1, pages)) if pages > 1 else self._movieGenreLabel)
        except Exception:
            pass
        if page==self._movieGenrePage and self.mediaItemsCurrent:
            return False
        self._movieGenrePage=page
        start=page*size
        self.showItems(self._movieGenreAllItems[start:start+size])
        self.focus="items"
        return True

    def left(self):
        if self.focus == "top":
            self.topIndex = max(0, self.topIndex - 1)
            self._updateTopFocus()
            return

        if self.kind == "live":
            # LIVE is column-based:
            # Channels -> Packages -> left rail.
            # LEFT must never behave like UP.
            if self.focus == "items":
                self.cancelAction()
                return
            if self.focus == "category":
                self.focus = "rail"
                self._updateTopFocus()
                return
            if self.focus == "rail":
                return
            return

        # Movies / TV Shows: horizontal movement inside the poster row only.
        if self.focus != "items":
            return
        if self.posterIndex > 0:
            self.posterIndex -= 1
            self.moveSelector(); self.previewVod()
        elif self.pageStart >= 5:
            self.pageStart -= 5
            self.posterIndex = 4
            self.renderPosterPage()
        elif self._largePageAllItems and self._largePage > 0:
            if self._loadLargePackagePage(self._largePage - 1):
                self.pageStart=max(0, ((len(self.mediaItemsCurrent)-1)//5)*5)
                self.posterIndex=max(0, min(4, len(self.mediaItemsCurrent)-self.pageStart-1))
                self.renderPosterPage()
        elif self._movieGenreAllItems and self._movieGenrePage > 0:
            if self._loadMovieGenrePage(self._movieGenrePage - 1):
                self.pageStart=max(0, len(self.mediaItemsCurrent)-5)
                self.posterIndex=max(0, min(4, len(self.mediaItemsCurrent)-self.pageStart-1))
                self.renderPosterPage()



    def right(self):
        if self.focus == "top":
            self.topIndex = min(len(self.topNames) - 1, self.topIndex + 1)
            self._updateTopFocus()
            return

        if self.kind == "live":
            # LIVE is column-based:
            # left rail -> Packages -> Channels.
            # RIGHT must never behave like DOWN.
            if self.focus == "rail":
                self.switchSection(self.currentRailSection())
                return
            if self.focus == "category":
                self._livePreviewOkIdentity = None
                self.loadSelectedCategory()
                self.focus = "items"
                self._updateTopFocus()
                return
            if self.focus == "items":
                return
            return

        # Movies / TV Shows: horizontal movement inside the poster row only.
        if self.focus != "items":
            return
        if self.pageStart + self.posterIndex + 1 >= len(self.mediaItemsCurrent):
            if self._largePageAllItems:
                size=max(1,int(self._largePageSize or 30))
                pages=max(1,(len(self._largePageAllItems)+size-1)//size)
                if self._largePage + 1 < pages:
                    self._loadLargePackagePage(self._largePage + 1)
            elif self._movieGenreAllItems:
                size=max(1,int(self._movieGenrePageSize or 30))
                pages=max(1,(len(self._movieGenreAllItems)+size-1)//size)
                if self._movieGenrePage + 1 < pages:
                    self._loadMovieGenrePage(self._movieGenrePage + 1)
            return
        if self.posterIndex < 4:
            self.posterIndex += 1
            self.moveSelector(); self.previewVod()
        else:
            self.pageStart += 5
            self.posterIndex = 0
            self.renderPosterPage()


    def up(self):
        if self.kind == "live" and getattr(self, "_liveMoveMode", False):
            self._moveCurrentLiveBy(-1); return
        if self.kind == "live":
            if self.focus == "rail":
                self["rail"].up()
            elif self.focus == "category":
                self._livePreviewOkIdentity = None
                self["category"].up()
            else:
                self["list"].up(); self.previewLive()
            return
        if self.focus == "items":
            self.focus = "top"
            self._updateTopFocus()


    def down(self):
        if self.kind == "live" and getattr(self, "_liveMoveMode", False):
            self._moveCurrentLiveBy(1); return
        if self.kind == "live":
            if self.focus == "rail":
                self["rail"].down()
            elif self.focus == "category":
                self._livePreviewOkIdentity = None
                self["category"].down()
            else:
                if self.source.get("type") == "xtream":
                    self._ensureXtreamNextLiveBatch()
                elif self.source.get("type") == "m3u":
                    self._ensureM3uNextLiveBatch()
                elif self.source.get("type") == "stalker":
                    self._ensureStalkerNextLiveBatch()
                self["list"].down(); self.previewLive()
            return
        if self.focus == "top":
            self.focus = "items"
            self._updateTopFocus()
            self.moveSelector(); self.previewVod()


    def liveFastUp(self):
        if self.kind != "live":
            return
        widget = self["list"] if self.focus == "items" else self["category"]
        try:
            widget.pageDown()
        except Exception:
            pass
        if self.focus == "items":
            self.previewLive()

    def liveFastDown(self):
        if self.kind != "live":
            return
        widget = self["list"] if self.focus == "items" else self["category"]
        try:
            widget.pageUp()
        except Exception:
            pass
        if self.focus == "items":
            self.previewLive()


    def channelPageUp(self):
        if self.kind != "live" or self.focus != "items":
            return
        try: self["list"].pageUp()
        except Exception:
            for _ in range(10): self["list"].up()
        self.previewLive()

    def channelPageDown(self):
        if self.kind != "live" or self.focus != "items":
            return
        if self.source.get("type") == "xtream":
            self._ensureXtreamNextLiveBatch()
        elif self.source.get("type") == "m3u":
            self._ensureM3uNextLiveBatch()
        elif self.source.get("type") == "stalker":
            self._ensureStalkerNextLiveBatch()
        try: self["list"].pageDown()
        except Exception:
            for _ in range(10): self["list"].down()
        self.previewLive()

    def pageUp(self):
        if self.kind != "live": return
        widget = self["list"] if self.focus == "items" else self["category"]
        try: widget.pageUp()
        except Exception:
            for _ in range(10): widget.up()
        if self.focus == "items": self.previewLive()

    def pageDown(self):
        if self.kind != "live": return
        widget = self["list"] if self.focus == "items" else self["category"]
        if self.focus == "items" and self.source.get("type") == "xtream":
            self._ensureXtreamNextLiveBatch()
        elif self.focus == "items" and self.source.get("type") == "m3u":
            self._ensureM3uNextLiveBatch()
        elif self.focus == "items" and self.source.get("type") == "stalker":
            self._ensureStalkerNextLiveBatch()
        try: widget.pageDown()
        except Exception:
            for _ in range(10): widget.down()
        if self.focus == "items": self.previewLive()

    def openLiveSearch(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard,
            title="Search channels", text=self.searchQuery or "")

    def openLiveFilter(self):
        if self.kind != "live":
            return
        self.session.openWithCallback(self._liveFilterClosed, ServerCategoryFilter, self.source)

    def _liveFilterClosed(self, changed=False):
        if self.kind != "live":
            return
        if not changed:
            self._queueWindowsAutoOpen()
            return
        self.searchQuery = ""
        self.sortMode = "default"
        self.lastCategoryItems = []
        self.mediaItemsCurrent = []
        self.focus = "category"
        try:
            pass
        except Exception:
            pass
        self.loadCategories()

    def toggleLiveSort(self):
        if self.kind != "live":
            return
        modes = ["default", "name", "added"]
        try:
            position = modes.index(self.sortMode)
        except Exception:
            position = 0
        self.sortMode = modes[(position + 1) % len(modes)]
        items = list(self.lastCategoryItems or [])
        if self.searchQuery and not (self.source.get("type") == "stalker"):
            query = self.searchQuery.lower()
            items = [entry for entry in items if query in (entry.get("name") or entry.get("title") or "").lower()]
        if self.sortMode == "name":
            items.sort(key=lambda entry: (entry.get("name") or entry.get("title") or "").lower())
            label = "A-Z"
        elif self.sortMode == "added":
            def added_value(entry):
                try:
                    return int(float(entry.get("added") or entry.get("added_timestamp") or 0))
                except Exception:
                    return 0
            items.sort(key=added_value, reverse=True)
            label = "Added"
        else:
            label = "Original"
        try:
            self["meta"].setText("Sort: %s" % label)
        except Exception:
            pass
        self.showItems(items)


    def _refreshPosterSortFooter(self):
        if self.kind not in ("vod", "series"):
            return
        mode = getattr(self, "sortMode", "latest")
        # These are the real modes in MediaScreen; do not advertise Z-A
        # when the underlying list actually uses rating sort.
        caption = {"default": "Original", "latest": "Date",
                   "name": "A-Z", "rating": "Rating"}.get(mode, "Date")
        try:
            self["footerSortValue"].setText(caption)
        except Exception:
            pass

    def toggleSort(self):
        if self.kind == "live":
            self.toggleLiveSort()
            return
        modes = ["default", "latest", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        _save_media_content_sort(self.kind, self.sortMode)
        self._refreshPosterSortFooter()
        items = list(self.lastCategoryItems or self.mediaItemsCurrent or [])
        if self.searchQuery:
            q = self.searchQuery.lower()
            items = [x for x in items if q in (x.get("name") or x.get("title") or "").lower()]
        if self.sortMode == "latest":
            items = self._sortPackageNewest(items)
            self["filterIcon"].setText(tr("Latest"))
        elif self.sortMode == "name":
            items.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
            self["filterIcon"].setText(tr("Name"))
        elif self.sortMode == "rating":
            def rating_value(x):
                try: return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception: return 0
            items.sort(key=rating_value, reverse=True)
            self["filterIcon"].setText(tr("Rating"))
        else:
            items = list(self.lastCategoryItems or [])
            self["filterIcon"].setText(tr("Original"))
        # Resort the entire package (not just a visible row), then keep the
        # continuous scroll. Recent Add / actor / GENRE paging is unaffected.
        if self._isContinuousPackage():
            self.lastCategoryItems = list(items)
            self._showContinuousPackage(self.lastCategoryItems)
        elif self.kind in ("vod", "series") and not self._movieGenreAllItems and not self.preloadedItems:
            self.lastCategoryItems = list(items)
            self._largePageAllItems = _dedupe_content_rows(self.lastCategoryItems, self.kind)[:200]
            self._largePageSize = 20
            self._largePage = 0
            self._loadLargePackagePage(0, force=True)
        else:
            self.showItems(items)

    def openSearch(self):
        if self.kind == "live":
            return
        self.session.openWithCallback(self.searchCallback, VirtualKeyBoard, title="Search content", text=self.searchQuery or "")

    def searchCallback(self, value=None):
        if value is None:
            return
        value = (value or "").strip()
        self.searchQuery = value
        if not value:
            self.showItems(self.lastCategoryItems)
            return
        self.applySearch(value)

    def applySearch(self, value):
        q = (value or "").strip().lower()
        if self.kind == "live" and self.source.get("type") == "stalker" and q:
            # Match EStalker level-2 Search All: query the portal-wide channel
            # list rather than filtering only the currently opened bouquet.
            self.categoryLoadToken += 1
            token = self.categoryLoadToken
            self.categoryLoadResult = None
            try:
                self["meta"].setText("Search All...")
            except Exception:
                pass
            source = dict(self.source)
            def worker():
                try:
                    rows = StalkerClient(source).search_all_live(q)
                    self.categoryLoadResult = (token, rows, "stalker_search_all", "", "Search All")
                except Exception as exc:
                    self.categoryLoadResult = (token, [], "error", str(exc), "Search All")
            t = threading.Thread(target=worker, name="TiviMateStalkerSearchAll")
            t.daemon = True
            t.start()
            try:
                self.categoryLoadTimer.start(120, True)
            except Exception:
                pass
            return

        items = []
        for x in (self.lastCategoryItems or []):
            name = (x.get("name") or x.get("title") or "").lower()
            plot = (x.get("plot") or x.get("description") or "").lower()
            if q in name or q in plot:
                items.append(x)
        self.showItems(items)
        try:
            caption = self["currentCategory"].getText() or ""
            if q:
                self["currentCategory"].setText((caption.split("  •  ")[0] if "  •  " in caption else caption) + "  •  Search")
        except Exception:
            pass

    def _cleanupLiveTempPicons(self):
        # Live-only exit cleanup: remove only temporary picon files created by
        # Live list / infobar. Persistent picon cache, EPG and all VOD artwork
        # stay untouched.
        prefixes = ("xst_live_picon_", "tivimate_infobar_picon_")
        folders = []
        try:
            folders.append(get_cache_dir("tmp"))
        except Exception:
            pass
        # Older builds used either spelling; keep cleanup compatible without
        # deleting the directory itself or unrelated temporary files.
        folders.extend((
            "/hdd/.tivimatee2_cache/tmp",
            "/media/hdd/.tivimatee2_cache/tmp",
            "/hdd/.tivimatee2-cache/tmp",
            "/media/hdd/.tivimatee2-cache/tmp",
        ))
        seen = set()
        for folder in folders:
            try:
                folder = str(folder or "").strip()
                if not folder:
                    continue
                real = os.path.realpath(folder)
                if real in seen or not os.path.isdir(real):
                    continue
                seen.add(real)
                for name in os.listdir(real):
                    if not any(name.startswith(prefix) for prefix in prefixes):
                        continue
                    path = os.path.join(real, name)
                    if os.path.isfile(path):
                        try:
                            os.remove(path)
                        except Exception:
                            pass
            except Exception:
                pass

    def close(self, *args, **kwargs):
        self._poster_fit_closed = True
        if self.kind == "live":
            try:
                self.zapTimer.stop(); self.livePiconTimer.stop(); self.rowPiconTimer.stop(); self.directEpgTimer.stop()
                self._cancelLiveZapResolve()
                self._cleanupLiveTempPicons()
                if self.oldService:
                    previous_url = str(getattr(self, '_playingLiveUrl', '') or '')
                    guard = getattr(self, '_ultraLiveDecoderGuard', None)
                    if guard is not None and previous_url:
                        guard.capture(previous_url)
                    restored = self.session.nav.playService(self.oldService)
                    if _live_play_accepted(restored) and guard is not None and previous_url:
                        guard.retire(previous_url)
            except Exception:
                pass
        return Screen.close(self, *args, **kwargs)

    def livePlayerClosed(self, result=None, keep_windows=False):
        self._livePreviewOkIdentity = None
        # This token comes only from a confirmed player that returned with the
        # exact same active Enigma2 service. It does not request playback.
        self._returnedLiveService = None
        index = None
        live_id = ""
        returned_ref = ""
        returned_source = ""
        try:
            if isinstance(result, (tuple, list)) and len(result) >= 2:
                index = result[0]
                live_id = str(result[1] or "").strip()
                if len(result) >= 4:
                    returned_ref = str(result[2] or "")
                    returned_source = str(result[3] or "")
            else:
                index = result
        except Exception:
            index = result

        try:
            if self.mediaItemsCurrent:
                # Keep the Live browser on the channel that is actually playing.
                # The full-screen player may move well beyond the first Xtream
                # 15-row lazy batch, so resolve the returned channel identity
                # against the full in-RAM bouquet before restoring the cursor.
                resolved_index = None
                if live_id:
                    for pos, row in enumerate(self.mediaItemsCurrent):
                        row = row or {}
                        row_id = str(
                            row.get("stream_id") or row.get("ch_id") or row.get("id") or
                            row.get("url") or row.get("cmd") or row.get("name") or ""
                        ).strip()
                        if row_id == live_id:
                            resolved_index = pos
                            break
                if resolved_index is None and index is not None:
                    resolved_index = max(0, min(int(index), len(self.mediaItemsCurrent) - 1))
                if resolved_index is not None:
                    index = resolved_index
                    if self.source.get("type") == "m3u":
                        batch = 15
                        needed = min(len(self.mediaItemsCurrent), ((index // batch) + 1) * batch)
                        if int(getattr(self, "m3uLiveLoadedCount", 0) or 0) < needed:
                            self.m3uLiveLoadedCount = needed
                            self._renderM3uLiveBatch(index, ensure_next=False)
                        else:
                            self["list"].moveToIndex(index)
                    elif self.source.get("type") == "xtream":
                        # Rebuild only enough of the existing lazy list to make
                        # the playing channel visible; no new catalogue request.
                        batch = max(1, int(getattr(self, "xtreamLiveBatchSize", 15) or 15))
                        needed = min(len(self.mediaItemsCurrent), ((index // batch) + 1) * batch)
                        if int(getattr(self, "xtreamLiveLoadedCount", 0) or 0) < needed:
                            self.xtreamLiveLoadedCount = needed
                            self._renderXtreamLiveBatch(index, ensure_next=False)
                        else:
                            self["list"].moveToIndex(index)
                    else:
                        self["list"].moveToIndex(index)
                    if not live_id:
                        item = self.mediaItemsCurrent[index] or {}
                        live_id = str(
                            item.get("stream_id") or item.get("ch_id") or item.get("id") or
                            item.get("url") or item.get("cmd") or item.get("name") or ""
                        ).strip()

                self._playingLiveIndex = index
                self._playingLiveId = live_id
                if live_id and returned_ref and returned_source and index is not None:
                    try:
                        row = self.mediaItemsCurrent[index] or {}
                        selected_source = (row.get("_favorite_source") if
                            isinstance(row.get("_favorite_source"), dict) else self.source)
                        if _source_identity(selected_source) == returned_source:
                            self._returnedLiveService = (returned_source, live_id, returned_ref)
                    except Exception:
                        pass
                if live_id:
                    self.lastZappedLiveId = live_id
                    self.keepCurrentLiveService = True
                    try:
                        self.source["_tivimate_current_live_id"] = live_id
                        _CURRENT_LIVE_CHANNEL["source"] = _source_identity(self.source)
                        _CURRENT_LIVE_CHANNEL["channel"] = live_id
                    except Exception:
                        pass

                # Refresh only EPG/Picon preview. Same-channel auto-zap is blocked below.
                if not keep_windows:
                    self.previewLive()
        except Exception:
            pass

        # Grid is still the active window. Showing the underlying MediaScreen
        # steals focus and makes the UI appear to switch back to List.
        if not keep_windows:
            try:
                self.show()
            except Exception:
                pass
        self._scheduleTopWindowRestore()

    def _scheduleTopWindowRestore(self):
        restore_top_dialog_soon(self.session)


    def _openLockedCategoryNow(self):
        self.loadSelectedCategory()
        self.focus = "items"

    def _reopenCurrentLivePlayer(self):
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = 0
        self._playingLiveIndex = index
        try:
            item = self.mediaItemsCurrent[index] or {}
            self._playingLiveId = str(
                item.get("stream_id") or item.get("ch_id") or item.get("id") or
                item.get("url") or item.get("cmd") or item.get("name") or ""
            ).strip()
        except Exception:
            self._playingLiveId = ""
        self.keepCurrentLiveService = True
        try:
            self.zapTimer.stop()
        except Exception:
            pass
        selected = self.mediaItemsCurrent[index] if 0 <= index < len(self.mediaItemsCurrent or []) else {}
        favorite_source = selected.get("_favorite_source") if isinstance((selected or {}).get("_favorite_source"), dict) else None
        play_source = favorite_source or (_bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source)
        self.session.openWithCallback(
            self.livePlayerClosed, TiviMateLivePlayer,
            play_source, list(self.mediaItemsCurrent or []), index, True
        )

    def _openLivePlayerNow(self, pending_link=None):
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = 0
        self._playingLiveIndex = index
        try:
            start_item = self.mediaItemsCurrent[index] or {}
            self._playingLiveId = str(
                start_item.get("stream_id") or start_item.get("ch_id") or start_item.get("id") or
                start_item.get("url") or start_item.get("cmd") or start_item.get("name") or ""
            ).strip()
        except Exception:
            self._playingLiveId = ""
        self.keepCurrentLiveService = True
        try:
            self.zapTimer.stop()
        except Exception:
            pass
        start_item = self.mediaItemsCurrent[index] if 0 <= index < len(self.mediaItemsCurrent or []) else {}
        fav_source = start_item.get("_favorite_source") if isinstance((start_item or {}).get("_favorite_source"), dict) else None
        if fav_source:
            play_source = _bein_base_source(fav_source) if fav_source.get("_virtual_bein") else fav_source
            # Global Favorites keeps the complete mixed-source list in the player.
            # Each row carries its own in-memory _favorite_source, so CH+/CH- and
            # left/right can resolve the next channel with the correct provider.
            self.session.openWithCallback(self.livePlayerClosed, TiviMateLivePlayer,
                                          play_source, list(self.mediaItemsCurrent or []), index,
                                          pending_link=pending_link)
        else:
            play_source = _bein_base_source(self.source) if self.source.get("_virtual_bein") else self.source
            self.session.openWithCallback(self.livePlayerClosed, TiviMateLivePlayer,
                                          play_source, list(self.mediaItemsCurrent or []), index,
                                          pending_link=pending_link)

    def playerClosed(self, *args):
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            self.show()
        except Exception:
            pass

    def _returnedLiveChannelIsActive(self, item, source=None):
        """True only for the SAME confirmed service returned by the Infobar.

        Unlike first-OK preview state, this survives Back from full-screen.
        Moving to another card never reuses playback unless it is still the
        same exact provider, channel and Enigma2 service reference.
        """
        if not isinstance(item, dict):
            return False
        token = getattr(self, "_returnedLiveService", None)
        if not token or len(token) != 3:
            return False
        owner = source or (item.get("_favorite_source") if
            isinstance(item.get("_favorite_source"), dict) else self.source)
        channel_id = str(item.get("stream_id") or item.get("ch_id") or
            item.get("id") or item.get("url") or item.get("cmd") or
            item.get("name") or "").strip()
        if not channel_id or token[:2] != (_source_identity(owner), channel_id):
            return False
        try:
            active = self.session.nav.getCurrentlyPlayingServiceReference()
            return bool(active is not None and active.toString() == token[2])
        except Exception:
            return False

    def _selectedLiveOkIdentity(self, item):
        """The exact highlighted channel and package, not the previous server."""
        if self.kind != "live" or self.focus != "items" or not isinstance(item, dict):
            return None
        if item.get("_stalker_placeholder") or str(item.get("name") or item.get("title") or "").lstrip().startswith("####"):
            return None
        try:
            index = self["list"].getSelectedIndex()
        except Exception:
            index = -1
        key = str(item.get("stream_id") or item.get("ch_id") or item.get("id") or
                  item.get("url") or item.get("cmd") or item.get("name") or "").strip()
        return (str(self.selectedCategory() or ""), int(index), key) if key else None

    def ok(self):
        if self.kind == "live" and getattr(self, "_liveMoveMode", False):
            self._finishMoveCurrentLive(); return
        if self.focus == "top":
            self._openTopItem(); return
        if self.focus == "rail":
            self.switchSection(self.currentRailSection())
            return
        if self.focus=="category":
            if self.kind == "live":
                # Package OK must ONLY show this package's channels.
                self._livePreviewOkIdentity = None
            self.loadSelectedCategory(); self.focus="items"; return
        item=self.current()
        if not item: return
        if self.kind == "live":
            # Retain catch-up/PIN behavior; ordinary Live channel OK is two-stage.
            if getattr(self, "catchupPackageActive", False):
                if self.source.get("type") == "stalker":
                    self._openStalkerCatchup()
                elif self.source.get("type") == "xtream":
                    self._openXtreamCatchup()
                return
            if self._isCurrentStalkerChannelLocked() and time.time() >= getattr(self, "stalkerPinUnlockedUntil", 0):
                self._requestStalkerPin(("play", None)); return

            selected_key = self._selectedLiveOkIdentity(item)
            if selected_key is None:
                return
            if self._returnedLiveChannelIsActive(item):
                # Back from an already-playing Infobar -> one OK to reopen.
                # Do not re-zap or re-fetch a Stalker portal link.
                self._cancelLiveZapResolve()
                if getattr(self, "_livePreviewCheck", None) is not None:
                    self._cancelLivePreviewCheck(stop_failed=False)
                self._reopenCurrentLivePlayer()
                return
            if selected_key in (getattr(self, "_livePreviewOkIdentity", None),
                                getattr(self, "_livePreviewPendingIdentity", None)):
                # Second OK is a UI request, not proof that video decoded.
                # Never block the Infobar behind a stalled/dead channel. Retire
                # any preview job below before the full-screen player owns it.
                self._liveFullscreenRequestedIdentity = None
                self._livePreviewOkIdentity = None
                self._livePreviewPendingIdentity = None
                reuse_current = False
                try:
                    play_source = (_bein_base_source(self.source)
                                   if self.source.get("_virtual_bein") else self.source)
                    row = getattr(self, "_playingLiveItem", None) or {}
                    row_key = str(row.get("stream_id") or row.get("ch_id") or
                                  row.get("id") or row.get("url") or
                                  row.get("cmd") or row.get("name") or "").strip()
                    url = str(getattr(self, "_playingLiveUrl", "") or "")
                    if (row_key == selected_key[2] and url and
                            _CURRENT_LIVE_CHANNEL.get("source") == _source_identity(self.source)):
                        service_type = (_xtream_service_type(play_source, "live")
                            if play_source.get("type") == "xtream" else
                            int(play_source.get("service_type", self.channelSettings.get("service_type", 4097))))
                        expected_ref = live_reference(play_source, item, service_type,
                            url, item.get("name") or item.get("title") or "IPTV")
                        reuse_current = bool(_live_ref_is_active(self.session.nav, expected_ref))
                except Exception:
                    reuse_current = False
                # Do not cancel and re-request an in-flight Stalker link.
                # The selected Infobar can poll the SAME Ultra TaskHandle.
                pending_link = (self._handoffLiveLink(item, play_source)
                                if not reuse_current else None)
                # Retire stale callbacks without stopping the selected stream.
                self._cancelLiveZapResolve()
                if getattr(self, "_livePreviewCheck", None) is not None:
                    self._cancelLivePreviewCheck(stop_failed=False)
                if reuse_current:
                    self._reopenCurrentLivePlayer()
                else:
                    self._openLivePlayerNow(pending_link=pending_link)
                return
            # First OK requests preview. Keep the exact selected identity even
            # if the stream has no link/video: second OK must open the Infobar.
            # This is only a UI latch, never playback success or a reuse token.
            self._livePreviewOkIdentity = selected_key
            if getattr(self, "_livePreviewPendingIdentity", None) == selected_key:
                checking = getattr(self, "_livePreviewCheck", None)
                # Block repeat-OK while either the portal or decoder verifies
                # this same channel, but a timed-out request is retryable.
                if (checking is not None or
                        (getattr(self, "liveZapResolveHandle", None) is not None and
                         time.monotonic() < float(getattr(self, "liveZapResolveDeadline", 0) or 0))):
                    return
            self._livePreviewPendingIdentity = selected_key
            self._liveFullscreenRequestedIdentity = None
            def preview_complete(success, expected=selected_key):
                if getattr(self, "_livePreviewPendingIdentity", None) == expected:
                    self._livePreviewPendingIdentity = None
                try:
                    if self._selectedLiveOkIdentity(self.current()) == expected:
                        # Failure must not turn the second OK into an endless
                        # first-OK retry. Playback success is tracked separately.
                        self._livePreviewOkIdentity = expected
                        if getattr(self, "_liveFullscreenRequestedIdentity", None) == expected:
                            self._liveFullscreenRequestedIdentity = None
                            if (success and not getattr(self, '_windowsVisible', False) and
                                    getattr(self, '_livePreviewVerifiedRef', '') and
                                    _live_ref_is_active(self.session.nav, self._livePreviewVerifiedRef)):
                                # Same active preview, no additional portal
                                # request or decoder restart. Called from the
                                # GUI-thread decoder result callback.
                                self.ok()
                    elif getattr(self, "_liveFullscreenRequestedIdentity", None) == expected:
                        self._liveFullscreenRequestedIdentity = None
                except Exception:
                    self._liveFullscreenRequestedIdentity = None
            if not self._zapLiveItem(item, False, _on_complete=preview_complete):
                if self._livePreviewPendingIdentity == selected_key:
                    self._livePreviewPendingIdentity = None
            return
        try:
            # Re-detect the platform from the active SERVER package at the
            # exact moment we open details. This guarantees the provider mark
            # survives even if the cached row was created before filtering.
            detail_item = dict(item or {})
            _active_name = str(getattr(self, "activeCategoryName", "") or
                               getattr(self, "initialCategoryName", "") or "").strip()
            _original_package = str(detail_item.get("_server_package_name") or "").strip()
            _selected_id = str(self.selectedCategory() or "").strip()
            _pseudo_package = _selected_id in ("__recent_added__", "__all__", "__actor_results__")
            package_name = (_original_package if _pseudo_package and _original_package
                            else _active_name or _original_package)
            if package_name and not _pseudo_package:
                detail_item["_server_package_name"] = package_name
            provider = str(getattr(self, "activePackageProvider", "") or
                           detail_item.get("_server_package_provider") or
                           detail_item.get("_tmdb_provider") or "").strip().lower()
            if not provider:
                provider = self._providerFromPackageName(package_name)
            if provider:
                detail_item["_tmdb_provider"] = provider
                detail_item["_server_package_provider"] = provider
                if package_name and not _pseudo_package:
                    detail_item["_server_package_name"] = package_name

            if self.kind == "series":
                _series_restart_log("MEDIA_OK_BEFORE_OPEN", detail_item, "category=%s" % str(package_name))
                self.session.open(SeriesDetailsScreen, self.source, detail_item)
                _series_restart_log("MEDIA_OK_AFTER_OPEN", detail_item)
                return

            if self.kind == "vod":
                # Server-package movies now open the SAME rich details page
                # used elsewhere (poster, metadata, actors, recommendations).
                # RECENT ADDED alone uses the user's saved movie-package filter
                # as its random recommendation pool. Normal packages are unchanged.
                _selected_cid=str(self.selectedCategory() or "").strip()
                _is_recent=(_selected_cid == "__recent_added__")
                _cid="" if _is_recent else str(detail_item.get("_source_category_id") or _selected_cid or "").strip()
                _scope="movies_recent_filtered" if _is_recent else "movies_package"
                detail_item["_source_scope"]=_scope
                detail_item["_source_server_id"]=_source_identity(self.source)
                if _cid:
                    detail_item["_source_category_id"]=_cid
                elif _is_recent:
                    detail_item.pop("_source_category_id", None)
                self.session.open(
                    MovieDetailsScreen,
                    self.source,
                    detail_item,
                    list(self.mediaItemsCurrent or []),
                    {"scope":_scope,"category_id":_cid,"items":list(self.mediaItemsCurrent or [])}
                )
                return

            # Non-VOD/Series fallback.
            if self.source.get("type") in ("xtream", "stalker"):
                url=get_source_client(self.source).stream_url(detail_item,self.kind)
            elif self.source.get("type")=="m3u":
                url=detail_item.get("url","")
            else:
                url=""
            if not url:
                raise Exception("لا يوجد رابط تشغيل")
            service_type = _stalker_service_type(self.source, self.kind) if self.source.get("type") == "stalker" else 4097
            service=eServiceReference(service_type,0,url)
            service.setName(detail_item.get("name") or detail_item.get("title") or "IPTV")
            detail_item["_source_type"] = self.source.get("type", "")
            detail_item["_source_key"] = _source_identity(self.source)
            detail_item["_kind"] = self.kind
            self.session.openWithCallback(self.playerClosed, TiviMatePlayer, service, detail_item)
        except Exception as e:
            self.session.open(MessageBox,"تعذر التشغيل:\n%s"%e,MessageBox.TYPE_ERROR)



FAVOURITES_SKIN = '''<screen name="TiviMateFavoritesLibrary" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#090A0C">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/library_background.jpg" alphatest="off" zPosition="0" />
    <widget name="favoriteBackdrop" position="0,0" size="1920,1080" alphatest="off" zPosition="1" />
    <widget name="title" position="72,52" size="720,55" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="filter" position="1280,60" size="560,42" font="Regular;24" foregroundColor="#D7DCE2" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
    <widget name="featuredLogo" position="1640,58" size="210,72" alphatest="blend" scale="1" zPosition="7" />
    <widget name="liveProgrammeLogo" position="770,420" size="380,140" alphatest="blend" scale="1" zPosition="7" />
    <widget name="featuredTitle" position="72,92" size="1100,46" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="6" />
    <widget name="featuredYear" position="72,150" size="90,38" font="Regular;22" foregroundColor="#38A8FF" backgroundColor="#00000000" transparent="1" zPosition="7" />
    <widget name="featuredRating" position="174,150" size="150,38" font="Regular;22" foregroundColor="#FFD21A" backgroundColor="#00000000" transparent="1" zPosition="7" />
    <widget name="featuredMeta" position="336,150" size="900,38" font="Regular;22" foregroundColor="#E2E2E2" backgroundColor="#00000000" transparent="1" zPosition="6" />
    <widget name="featuredDesc" position="72,224" size="1050,90" font="Regular;20" foregroundColor="#D0D0D0" backgroundColor="#00000000" transparent="1" zPosition="6" />
    <widget name="genreCrime" position="850,190" size="95,32" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#B00000" transparent="0" halign="center" valign="center" zPosition="8" />
    <widget name="genreDrama" position="956,190" size="105,32" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#164FA8" transparent="0" halign="center" valign="center" zPosition="8" />
    <widget name="status" position="72,176" size="1770,42" font="Regular;22" foregroundColor="#B7BDC5" backgroundColor="#00000000" transparent="1" zPosition="4" />
    <widget name="list" position="-20,-20" size="1,1" itemHeight="1" scrollbarMode="showNever" />
    <widget name="poster0" position="335,330" size="150,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <widget name="posterTitle0" position="325,562" size="170,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster1" position="555,330" size="150,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <widget name="posterTitle1" position="545,562" size="170,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster2" position="775,330" size="150,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <widget name="posterTitle2" position="765,562" size="170,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster3" position="995,330" size="150,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <widget name="posterTitle3" position="985,562" size="170,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster4" position="1215,330" size="150,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <widget name="posterTitle4" position="1205,562" size="170,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="poster5" position="1435,330" size="150,220" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png" alphatest="blend" zPosition="3" />
    <widget name="posterTitle5" position="1425,562" size="170,58" font="Regular;21" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
    <widget name="posterSelector" position="329,324" size="162,232" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/poster_focus_white.png" alphatest="blend" zPosition="12" />
    <widget name="keyRed" position="410,990" size="250,44" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#B00000" transparent="0" halign="center" valign="center" zPosition="9" />
    <widget name="keyGreen" position="690,990" size="250,44" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#168A36" transparent="0" halign="center" valign="center" zPosition="9" />
    <widget name="keyYellow" position="970,990" size="250,44" font="Regular;22" foregroundColor="#111111" backgroundColor="#E7C928" transparent="0" halign="center" valign="center" zPosition="9" />
    <widget name="keyBlue" position="1250,990" size="250,44" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#1D5EA8" transparent="0" halign="center" valign="center" zPosition="9" />
    <widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" zPosition="1" />
</screen>'''

FAVOURITES_SKIN = scale_skin(FAVOURITES_SKIN)


FAVORITES_CIRCLE_SKIN = scale_skin(r'''<screen name="TiviMateFavoritesCircle" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/background.jpg" alphatest="off" zPosition="0" />
    <widget name="selector" position="171,217" size="530,530" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/selector.png" alphatest="blend" zPosition="10" />
    <widget name="hint" position="560,980" size="800,42" font="Regular;24" foregroundColor="#D8D8D8" backgroundColor="#00000000" transparent="1" halign="center" zPosition="11" />
</screen>''')



# Optional BLUE > Windows layout for Live. Reuses the current channel list
# and existing playback engine; does not change provider requests or Live colors.
LIVE_WINDOWS_SKIN = scale_skin('<screen name="LiveWindowsScreen" position="0,0" size="1920,1080" backgroundColor="#0A1520" transparent="0" flags="wfNoBorder">\n<widget name="windowBackground" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_background.png" alphatest="blend" zPosition="0" />\n<widget name="header" position="114,27" size="1050,53" font="Regular;38" foregroundColor="#F4F8FC" transparent="1" zPosition="2" />\n<widget name="counter" position="1410,38" size="443,30" font="Regular;19" halign="right" foregroundColor="#CAD5DF" transparent="1" zPosition="2" />\n<widget source="session.VideoPicture" render="Pig" position="42,110" size="817,340" backgroundColor="transparent" transparent="0" zPosition="42" />\n<widget name="epgBackdrop" position="889,111" size="974,341" alphatest="blend" scale="1" zPosition="1" />\n<widget name="epgBackdropShade" position="889,111" size="974,341" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_info_shade_precise.png" alphatest="blend" zPosition="2" />\n<widget name="epgBackdropFrame" position="882,103" size="985,359" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="4" />\n<widget name="channelName" position="913,153" size="669,30" font="Regular;21" foregroundColor="#EAF2FA" transparent="1" zPosition="5" noWrap="1" />\n<widget name="epgLabel" position="913,124" size="672,25" font="Regular;19" foregroundColor="#73D5FF" transparent="1" zPosition="5" />\n<widget name="epgNow" position="913,189" size="676,53" font="Regular;28" foregroundColor="#FFFFFF" transparent="1" zPosition="5" noWrap="0" />\n<widget name="epgTime" position="913,251" size="674,26" font="Regular;19" foregroundColor="#FFD58F" transparent="1" zPosition="5" />\n<widget name="epgNext" position="913,303" size="671,30" font="Regular;19" foregroundColor="#8ED5FF" transparent="1" zPosition="5" />\n<widget name="epgDescription" position="913,376" size="676,63" font="Regular;17" foregroundColor="#C7D3E1" transparent="1" zPosition="5" noWrap="0" />\n<widget name="previewHint" position="570,417" size="270,23" font="Regular;15" halign="right" foregroundColor="#ADBCCC" transparent="1" zPosition="44" />\n<widget name="programmePoster" position="1645,121" size="200,324" alphatest="blend" zPosition="45" scale="1" />\n<widget name="stripFocus" position="44,461" size="344,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_strip_focus.png" alphatest="blend" zPosition="3" />\n<widget name="stripIcon0" position="-500,-500" size="1,1" alphatest="blend" scale="1" zPosition="4" />\n<widget name="stripName0" position="-500,-500" size="1,1" font="Regular;20" foregroundColor="#EAF7FF" transparent="1" valign="center" noWrap="1" zPosition="4" />\n<widget name="stripIcon1" position="-500,-500" size="1,1" alphatest="blend" scale="1" zPosition="4" />\n<widget name="stripName1" position="-500,-500" size="1,1" font="Regular;20" foregroundColor="#EAF7FF" transparent="1" valign="center" noWrap="1" zPosition="4" />\n<widget name="stripIcon2" position="-500,-500" size="1,1" alphatest="blend" scale="1" zPosition="4" />\n<widget name="stripName2" position="-500,-500" size="1,1" font="Regular;20" foregroundColor="#EAF7FF" transparent="1" valign="center" noWrap="1" zPosition="4" />\n<widget name="stripIcon3" position="-500,-500" size="1,1" alphatest="blend" scale="1" zPosition="4" />\n<widget name="stripName3" position="-500,-500" size="1,1" font="Regular;20" foregroundColor="#EAF7FF" transparent="1" valign="center" noWrap="1" zPosition="4" />\n<widget name="stripIcon4" position="-500,-500" size="1,1" alphatest="blend" scale="1" zPosition="4" />\n<widget name="stripName4" position="-500,-500" size="1,1" font="Regular;20" foregroundColor="#EAF7FF" transparent="1" valign="center" noWrap="1" zPosition="4" />\n<widget name="wBadge0" position="333,514" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon0" position="56,507" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName0" position="187,536" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge1" position="708,514" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon1" position="431,507" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName1" position="562,536" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge2" position="1083,514" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon2" position="806,507" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName2" position="937,536" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge3" position="1458,514" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon3" position="1181,507" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName3" position="1312,536" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge4" position="1833,514" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon4" position="1556,507" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName4" position="1687,536" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge5" position="333,719" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon5" position="56,712" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName5" position="187,741" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge6" position="708,719" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon6" position="431,712" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName6" position="562,741" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge7" position="1083,719" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon7" position="806,712" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName7" position="937,741" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge8" position="1458,719" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon8" position="1181,712" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName8" position="1312,741" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="wBadge9" position="1833,719" size="54,25" text="EPG" font="Regular;14" foregroundColor="#D6FFFF" backgroundColor="#155B68" transparent="0" cornerRadius="7" halign="center" valign="center" noWrap="1" zPosition="10" />\n<widget name="wIcon9" position="1556,712" size="126,160" alphatest="blend" scale="1" zPosition="5" />\n<widget name="wName9" position="1687,741" size="194,106" font="Regular;21" foregroundColor="#E7EDF5" transparent="1" halign="left" valign="center" noWrap="0" zPosition="5" />\n<widget name="focusTint" position="44,497" size="354,185" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_focus_tint.png" alphatest="blend" zPosition="4" />\n<widget name="focusFrame" position="44,497" size="354,185" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_focus.png" alphatest="blend" zPosition="8" />\n<widget name="footer" position="45,973" size="1830,22" font="Regular;16" foregroundColor="#BBD2E5" transparent="1" halign="center" zPosition="4" />\n<widget name="keyCircleRed" position="74,977" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_key_red.png" alphatest="blend" zPosition="71" />\n<widget name="keyRed" position="139,980" size="246,42" font="Regular;23" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="71" />\n<widget name="keyCircleGreen" position="443,977" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_key_green.png" alphatest="blend" zPosition="71" />\n<widget name="keyGreen" position="508,980" size="246,42" font="Regular;23" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="71" />\n<widget name="keyCircleYellow" position="812,977" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_key_yellow.png" alphatest="blend" zPosition="71" />\n<widget name="keyYellow" position="877,980" size="246,42" font="Regular;23" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="71" />\n<widget name="keyCircleBlue" position="1181,977" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_key_blue.png" alphatest="blend" zPosition="71" />\n<widget name="keyBlue" position="1246,980" size="246,42" font="Regular;23" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="71" />\n<widget name="keyCircleMenu" position="1550,977" size="48,48" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_key_menu.png" alphatest="blend" zPosition="71" />\n<widget name="keyMenu" position="1615,980" size="246,42" font="Regular;23" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="71" />\n<widget name="keyCircleBein" position="1900,1040" size="1,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_key_bein0.png" alphatest="blend" zPosition="71" />\n<widget name="pkgBase" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_packages_cards_bg.png" alphatest="off" zPosition="60" />\n<widget name="pkgHero" position="20,84" size="1880,390" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_package_hero_classic.jpg" alphatest="blend" zPosition="61" />\n<widget name="pkgTitle" position="112,30" size="1080,57" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" zPosition="62" />\n<widget name="pkgCount" position="1410,39" size="430,31" font="Regular;19" foregroundColor="#A7CAE8" transparent="1" halign="right" zPosition="62" />\n<widget name="pkgHint" position="81,925" size="1600,30" font="Regular;19" foregroundColor="#BFDAF4" transparent="1" zPosition="62" />\n<widget name="pkgFooter" position="1650,1048" size="180,23" font="Regular;13" foregroundColor="#D8EDF8" transparent="1" zPosition="62" />\n<widget name="pkgCircle0" position="64,550" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon0" position="87,566" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName0" position="153,529" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle1" position="439,550" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon1" position="462,566" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName1" position="528,529" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle2" position="814,550" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon2" position="837,566" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName2" position="903,529" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle3" position="1189,550" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon3" position="1212,566" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName3" position="1278,529" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle4" position="1564,550" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon4" position="1587,566" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName4" position="1653,529" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle5" position="64,755" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon5" position="87,771" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName5" position="153,734" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle6" position="439,755" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon6" position="462,771" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName6" position="528,734" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle7" position="814,755" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon7" position="837,771" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName7" position="903,734" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle8" position="1189,755" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon8" position="1212,771" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName8" position="1278,734" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgCircle9" position="1564,755" size="78,78" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="62" />\n<widget name="pkgIcon9" position="1587,771" size="48,48" alphatest="blend" scale="1" zPosition="64" />\n<widget name="pkgName9" position="1653,734" size="234,120" font="Regular;27" foregroundColor="#F2F6FC" transparent="1" valign="center" noWrap="0" zPosition="64" />\n<widget name="pkgFocus" position="44,497" size="354,185" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_focus.png" alphatest="blend" zPosition="68" />\n<widget name="programmePosterFrame" position="1638,114" size="214,338" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/transparent.png" alphatest="blend" zPosition="46" /><widget name="previewChannel" position="82,130" size="690,42" font="Regular;27" foregroundColor="#FFFFFF" transparent="1" zPosition="44" noWrap="1" /><widget name="programmePicon" position="1654,221" size="180,135" alphatest="blend" scale="1" zPosition="44" /><widget name="epgTimelineTrack" position="913,286" size="671,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_epg_timeline_track.png" alphatest="blend" zPosition="7" /><widget name="epgTimelineFill" position="913,286" size="671,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/live/windows_epg_timeline_fill.png" alphatest="blend" zPosition="8" /><widget name="epgBadgeLive" position="913,339" size="87,27" font="Regular;17" foregroundColor="#F0FDFF" backgroundColor="#186074" transparent="0" halign="center" valign="center" zPosition="8" /><widget name="epgBadgeGenre" position="1011,339" size="201,27" font="Regular;17" foregroundColor="#FFE1F3" backgroundColor="#693657" transparent="0" halign="center" valign="center" zPosition="8" /><widget name="epgBadgeDetail" position="1223,339" size="157,27" font="Regular;17" foregroundColor="#FFE7B1" backgroundColor="#59472E" transparent="0" halign="center" valign="center" zPosition="8" /></screen>')
def _windows_skin_with_style(theme):
    """Use the same saved palette as normal Live, including Windows graphics.

    The colors are pre-rendered at packaging time to avoid decoding and
    recoloring multi-megapixel screens on the receiver's UI thread.
    """
    theme = str(theme or "turquoise").lower()
    if theme not in LIVE_STYLE_PALETTES:
        theme = "turquoise"
    skin = LIVE_WINDOWS_SKIN
    themed = ("windows_background.png", "windows_packages_cards_bg.png",
              "windows_focus.png", "windows_focus_tint.png", "windows_strip_focus.png",
              "windows_info_frame.png")
    for item in themed:
        skin = skin.replace("/skins/live/" + item,
                            "/skins/live/themes/" + theme + "/" + item)
    # Recolor text highlights without touching standard Live or key labels.
    accent = LIVE_STYLE_PALETTES[theme]["progress"]
    skin = skin.replace('#65CEFF', accent)
    return skin

def _live_ref_is_active(nav, candidate):
    """Verify the actual Enigma2 service, not only a stale channel ID.

    Return False on uncertain state: a false negative can retry playback,
    whereas a false positive can leave the wrong/unstarted channel on screen.
    """
    try:
        active = nav.getCurrentlyPlayingServiceReference()
        if active is None or candidate is None:
            return False
        active_text = active.toString()
        candidate_text = candidate.toString() if hasattr(candidate, "toString") else str(candidate)
        return bool(active_text and candidate_text and active_text == candidate_text)
    except Exception:
        return False


def _live_play_accepted(result):
    """Enigma2 playService convention: 0 (or None on some images) is success."""
    return result is None or result == 0


class LiveWindowsScreen(Screen):
    PAGE_SIZE = 10
    COLS = 5
    X0, Y0, DX, DY = 44, 497, 375, 205

    def __init__(self, session, parent):
        # Grid background follows the same palette selected for Standard List.
        # Card backgrounds remain the original Windows default color.
        self.skin = _windows_skin_with_style(
            parent.channelSettings.get("live_theme", "turquoise"))
        Screen.__init__(self, session)
        self.parentLive = parent
        parent._windowsScreen = self
        # Do not display channels from a stale package while the Live catalog
        # is still on its package chooser. Windows will load the highlighted
        # or first real package in the background after appearing immediately.
        self.grid_items = []  # Enter Windows on the circular package grid, not stale channels.
        self._closed = False
        self._requestGeneration = 0
        self._piconQueue = []
        # Ultra-style Live artwork lane: keep a bounded set of active picon
        # requests and refill a free slot immediately when one finishes.
        # Cache hits still paint immediately and do not consume a slot.
        self._piconThreads = []
        self._piconParallel = 4  # bounded parallel misses; cached icons paint immediately
        self._piconTimer = eTimer()
        _connect_timer(self._piconTimer, self._loadNextPicon)
        self._epgToken = 0
        self._epgResult = None
        self._epgBusy = False
        self._epgActiveToken = None
        self._epgStartedAt = 0.0
        self._epgRetryAfter = 0.0
        self._windowsEpgMemo = {}  # (server, channel) -> (time, now, next)
        self._epgRefresh = eTimer()
        _connect_timer(self._epgRefresh, self._refreshSelectedEpg)
        self._epgTimer = eTimer()
        _connect_timer(self._epgTimer, self._requestSelectedEpg)
        self._epgPoll = eTimer()
        _connect_timer(self._epgPoll, self._pollSelectedEpg)
        self._windowsBadgeTimer = eTimer()
        _connect_timer(self._windowsBadgeTimer, self._refreshWindowsBadges)
        self._windowsBadgePolls = 0
        self._previewTimer = eTimer()
        _connect_timer(self._previewTimer, self._previewSelectedChannel)
        self._previewWatchTimer = eTimer()
        _connect_timer(self._previewWatchTimer, self._pollPreviewHealth)
        # Delay speculative live previews while the remote cursor is moving.
        # Do not delay the first playable channel when a package opens.
        self._lastWindowsFocusTime = 0.0
        self._autoPreviewFailedUntil = {}
        self._bouquetTimer = eTimer()
        _connect_timer(self._bouquetTimer, self._checkBouquetReady)
        # Stalker supplies a placeholder-filled catalogue, then resolves 14
        # channels per provider page asynchronously. Keep Windows in sync.
        self._stalkerGridTimer = eTimer()
        _connect_timer(self._stalkerGridTimer, self._refreshStalkerGrid)
        self._initialPackageTimer = eTimer()
        _connect_timer(self._initialPackageTimer, self._ensureInitialPackage)
        self._initialPackageTries = 0
        self._bouquetIdPending = None
        self._programmeLoader = None
        self._programmePiconLoader = None
        self._epgBackdropLoader = None
        self._epgBackdropToken = 0
        self._epgBackdropSearchBusy = False
        self._epgBackdropResult = None
        self._epgBackdropPending = None
        self._epgBackdropUrls = {}
        self._epgBackdropMisses = {}  # short negative TTL for unsupported programmes
        self._epgBackdropPoll = eTimer()
        _connect_timer(self._epgBackdropPoll, self._pollWindowsBackdrop)
        self._backdropPrepareTimer = eTimer()
        _connect_timer(self._backdropPrepareTimer, self._pollPreparedBackdrop)
        self._backdropPrepareBusy = False
        self._backdropPreparePending = None
        self._backdropPrepareResult = None
        self._posterToken = 0
        self._posterFollow = eTimer()
        _connect_timer(self._posterFollow, self._followParentLivePoster)
        self._posterFollowTries = 0
        self._posterFollowTitle = ""
        # Poster fallback and list/grid controls are owned by this modal screen.
        self._posterDisplayedToken = -1
        self._posterSearchResult = None
        self._posterSearchBusy = False
        self._posterNegativeTitles = set()
        self._posterFallbackTimer = eTimer()
        _connect_timer(self._posterFallbackTimer, self._fallbackPoster)
        self._posterSearchPoll = eTimer()
        _connect_timer(self._posterSearchPoll, self._pollFallbackPoster)
        self._toolbarIndex = None  # Legacy state; no focusable toolbar in Windows.
        self._packagesOpen = False
        self._packageRows = []
        self._packageSelection = 0
        # 48px icons are for package chooser only. Standard Live keeps its
        # original compact 24px icons, so the channel UI is never affected.
        self._packageIconPixmaps = {}
        self._packageLoading = False
        self._bouquetWaitUntil = 0.0
        self._previewOkIdentity = None  # Verified preview identity, never just cursor focus.
        self._previewRequestedIdentity = None  # Only explicit OK may start a new preview.
        self._previewServiceRef = None  # Actual ref of a successful mixed-favorite preview.
        self._favoritePreviewResult = None
        self._favoritePreviewPending = None
        self._favoritePreviewHandle = None
        self._favoritePreviewHandoffState = None
        self._favoritePreviewDeadline = 0.0
        self._favoritePreviewToken = 0
        self._favoritePreviewTimer = eTimer()
        _connect_timer(self._favoritePreviewTimer, self._finishFavoritePreview)
        # Reuse the already resolving Stalker preview on first OK instead of
        # cancelling its create_link() and sending a duplicate from the player.
        self._pendingFullscreenIdentity = None
        self._pendingFullscreenTimer = eTimer()
        _connect_timer(self._pendingFullscreenTimer, self._finishPendingFullscreen)
        self._selectedTilePosterSlot = None
        self._gridPosterLoaders = {}
        self._windowsUiReady = False
        self._windowsUiRetry = 0
        self._windowsUiRescueTimer = eTimer()
        _connect_timer(self._windowsUiRescueTimer, self._ensureWindowsUiVisible)
        self.onClose.append(self._windowsClosed)
        self.focusIndex = 0
        try:
            self.focusIndex = max(0, min(int(parent["list"].getSelectedIndex()), len(self.grid_items)-1))
        except Exception:
            pass
        self.page = self.focusIndex // self.PAGE_SIZE
        self["windowBackground"] = Pixmap()
        self["header"] = Label("LIVE TV  /  WINDOWS")
        self["counter"] = Label("")
        self["footer"] = Label("")
        # Circular remote-key legend shared by Windows packages and channels.
        self["keyRed"] = Label("Prev Package")
        self["keyGreen"] = Label("Filter")
        self["keyYellow"] = Label("Server")
        self["keyBlue"] = Label("Next Package")
        self["keyMenu"] = Label("Menu")
        self["keyBein"] = Label("0")
        for key in ("Red", "Green", "Yellow", "Blue", "Menu", "Bein"):
            self["keyCircle%s" % key] = Pixmap()
        self["epgLabel"] = Label("NOW PLAYING  •  EPG")
        self["channelName"] = Label("")
        self["epgNow"] = Label("EPG unavailable")
        self["epgTime"] = Label("")
        self["epgNext"] = Label("")
        self["epgDescription"] = Label("")
        self["previewHint"] = Label("CHANNEL PREVIEW")
        self["bouquetOverlay"] = Pixmap()
        self["bouquetTitle"] = Label("SELECT PACKAGE")
        self["bouquetCounter"] = Label("")
        self["bouquetFocus"] = Pixmap()
        self["bouquetHint"] = Label("UP/DOWN  Select     OK  Open package     EXIT  Channels")
        for pkg_slot in range(10):
            self["bouquetRow%d" % pkg_slot] = Label("")
            self["bouquetIcon%d" % pkg_slot] = Pixmap()
        # Package chooser is a full-screen 8x4 circular grid in this same modal
        # Windows screen.  All original Live category icons are reused.
        self["pkgBase"] = Pixmap()
        self["pkgHero"] = Pixmap()
        self["pkgTitle"] = Label("LIVE TV  /  PACKAGES")
        self["pkgCount"] = Label("")
        self["pkgHint"] = Label("OK  Open package    CH+/-  Pages")
        self["pkgFocus"] = Pixmap()
        self["pkgFooter"] = Label("")
        for pkg_slot in range(self.PAGE_SIZE):
            self["pkgCircle%d" % pkg_slot] = Pixmap()
            self["pkgIcon%d" % pkg_slot] = Pixmap()
            self["pkgName%d" % pkg_slot] = Label("")
        self["stripFocus"] = Pixmap()
        for strip_slot in range(5):
            self["stripIcon%d" % strip_slot] = Pixmap()
            self["stripName%d" % strip_slot] = Label("")
        self["programmePoster"] = Pixmap()
        self["programmePosterFrame"] = Pixmap()
        self["programmePicon"] = Pixmap()
        self["epgTimelineTrack"] = Pixmap()
        self["epgTimelineFill"] = Pixmap()
        self["epgBadgeLive"] = Label("")
        self["epgBadgeGenre"] = Label("")
        self["epgBadgeDetail"] = Label("")
        self["previewChannel"] = Label("")
        self["epgBackdropShade"] = Pixmap()
        self["epgBackdrop"] = Pixmap()
        self["epgBackdropFrame"] = Pixmap()
        self["focusFrame"] = Pixmap()
        self["focusTint"] = Pixmap()
        for i in range(self.PAGE_SIZE):
            self["wBadge%d" % i] = Label("EPG")
            self["wIcon%d" % i] = Pixmap()
            self["wName%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions",
             "InfoActions", "ChannelSelectBaseActions", "InfobarChannelSelection", "NumberActions"],
            {"ok": self._ok, "cancel": self._backAction, "left": self._left,
             "right": self._right, "up": self._up, "down": self._down,
             "pageUp": self._prevPage, "pageDown": self._nextPage,
             "channelUp": self._prevPage, "channelDown": self._nextPage,
             "nextBouquet": self._nextBouquet, "prevBouquet": self._prevBouquet,
             "blue": self._nextBouquet, "red": self._redPackageAction,
             "green": self._openFilter, "yellow": self._openServer,
             "yellowlong": self._openFavorites,
             "menu": self._openColorMenu, "info": self._openBouquetExportMenu,
             "0": self._openBeinSports}, -1)
        self._beinGridTimer = eTimer()
        _connect_timer(self._beinGridTimer, self._refreshBeinGrid)
        self._beinGridPending = False
        self._styleHandoffTimer = eTimer()
        _connect_timer(self._styleHandoffTimer, self._commitSwitchToList)
        self.onLayoutFinish.append(self._windowsReady)
        # Images differ in their callback ordering: onShow is a second safe
        # entry point if onLayoutFinish fired before the modal was drawable.
        self.onShow.append(self._windowsShown)

    def _windowsShown(self):
        if self._closed:
            return
        try:
            self._windowsUiRescueTimer.start(180, True)
        except Exception:
            pass

    def _windowsReady(self):
        # Keep the package interface visible from the first frame. The old
        # hide -> rebuild sequence could leave only the hardware PiG visible
        # if a receiver's layout callback or category list was incomplete.
        if self._closed or self._windowsUiReady:
            return
        self._packagesOpen = True
        try:
            self["windowBackground"].show()
            self["pkgBase"].show()
            self["pkgTitle"].show()
            self["pkgHint"].show()
        except Exception:
            pass
        try:
            self._chooseBouquet()
            self._windowsUiReady = True
        except Exception:
            # The category list may still be initializing. Keep full-screen
            # graphics and text visible while we retry on the GUI timer.
            self._windowsUiRetry += 1
            self._packagesOpen = True
            try:
                self._packageRows = self._packageChoices()
                self._packageSelection = 0
                self._drawPackageOverlay()
            except Exception:
                try: self["pkgHint"].setText("Preparing Live packages...")
                except Exception: pass
        if not self._packageRows:
            self._initialPackageTries = 0
            try: self._initialPackageTimer.start(180, True)
            except Exception: pass
        if not self._windowsUiReady:
            try: self._windowsUiRescueTimer.start(220, True)
            except Exception: pass

    def _ensureWindowsUiVisible(self):
        if self._closed:
            return
        if not self._windowsUiReady and self._windowsUiRetry < 12:
            self._windowsReady()
        elif self._packagesOpen:
            # Refresh only the package surface, never zap or refresh playback.
            try:
                self["pkgBase"].show()
                self._drawPackageOverlay()
            except Exception:
                pass

    def _ensureInitialPackage(self):
        """Wait for asynchronous category names; never auto-select a bouquet."""
        if self._closed or not self._packagesOpen or self._packageRows:
            return
        self._initialPackageTries += 1
        self._packageRows = self._packageChoices()
        if self._packageRows:
            self._packageSelection = 0
            self._drawPackageOverlay()
        elif self._initialPackageTries < 100:
            self._initialPackageTimer.start(250, True)
        else:
            self["pkgHint"].setText("No packages available    RED Back")

    def _backAction(self):
        # Channel grid -> the package grid, keeping the previously chosen
        # package highlighted. Never exit Live directly from channel cards.
        if not self._packagesOpen:
            try: self._previewTimer.stop()
            except Exception: pass
            try: self._epgTimer.stop()
            except Exception: pass
            self._chooseBouquet()
            return
        # Package grid -> normal Live exit. The saved Windows skin remains.
        self._exitToParentAction("closeLive")

    def _switchToList(self):
        # Never close Windows synchronously inside the nested appearance
        # selector callback. Let that selector leave the modal stack first.
        if self._closed:
            return
        try:
            self._styleHandoffTimer.stop()
            self._styleHandoffTimer.start(80, True)
        except Exception:
            self._commitSwitchToList()

    def _commitSwitchToList(self):
        if self._closed:
            return
        # Hand off the absolute channel index as data only. Touching the
        # parent's list while Windows/PiG is active can freeze the old screen.
        self.parentLive._windowsReturnSelection = (
            int(self.focusIndex), bool(self._packagesOpen))
        self.close("switchToList")

    def _windowsClosed(self):
        self._closed = True
        try:
            if getattr(self.parentLive, "_windowsScreen", None) is self:
                self.parentLive._windowsScreen = None
        except Exception:
            pass
        try: self._styleHandoffTimer.stop()
        except Exception: pass
        self._requestGeneration += 1
        for timer in (self._piconTimer, self._epgTimer, self._epgPoll, self._epgRefresh,
                      self._windowsBadgeTimer,
                      self._previewTimer, self._previewWatchTimer, self._bouquetTimer, self._initialPackageTimer, self._windowsUiRescueTimer, self._posterFollow,
                      self._posterFallbackTimer, self._posterSearchPoll, self._epgBackdropPoll,
                      self._backdropPrepareTimer, self._favoritePreviewTimer,
                      self._pendingFullscreenTimer, self._beinGridTimer,
                      self._stalkerGridTimer):
            try: timer.stop()
            except Exception: pass
        self._epgToken += 1
        try: self._epgRefresh.stop()
        except Exception: pass
        self._posterToken += 1
        self._epgBackdropToken += 1
        self._backdropPreparePending = None
        self._backdropPrepareResult = None
        self._cancelFavoritePreviewLink()
        try:
            self.parentLive._cancelLiveZapResolve()
            if getattr(self.parentLive, "_livePreviewCheck", None) is not None:
                self.parentLive._cancelLivePreviewCheck(stop_failed=True)
        except Exception: pass
        self._epgResult = None
        self._programmeLoader = None
        self._programmePiconLoader = None

    def _piconUrl(self, item):
        # Use one URL identity across ordinary Live, Windows and Infobar;
        # relative Stalker logos otherwise generate different disk-cache keys.
        from .estalker_picon import resolve_picon_url
        return resolve_picon_url(item, item.get("_favorite_source") or self.parentLive.source)

    def _windowsCachedTileProgramme(self, item):
        """Existing Live EPG RAM only; never fetch 10 channel guides on render."""
        if not isinstance(item, dict) or item.get("_stalker_placeholder"):
            return ""
        try:
            source = item.get("_favorite_source") or self.parentLive.source or {}
            kind = str(source.get("type") or "").lower()
            title = self.parentLive._cachedLiveProgrammeTitle(item)
            if not title:
                rows = _shared_live_epg_cached(source, item)
                if rows:
                    now, _next = self._windowsChooseEpg(rows, kind)
                    title = (now or {}).get('title') or ''
            return self._decodeWindowsEpg(title)[:45] if title else ""
        except Exception:
            return ""

    def _render(self, fresh_bouquet=False, preserve_preview=False):
        self._requestGeneration += 1
        generation = self._requestGeneration
        try: self._piconTimer.stop()
        except Exception: pass
        self._piconQueue = []
        # Cached thumbnails are all offloaded; prioritise the selected card
        # before other visible tiles so returning to a saved channel paints
        # its logo first even when a previous tile has a slow/broken logo.
        cached_windows_picons = []
        # Ultra-style one-shot favourite snapshot for a visible page.  Calling
        # is_favourite() ten times reads favorites.json ten times on the GUI
        # thread (usually from the HDD). No disk read per channel tile.
        try:
            from .favorites import favourite_id, favourite_ids_for_kind
            favourite_ids = favourite_ids_for_kind("live")
        except Exception:
            favourite_ids = None
        self._selectedTilePosterSlot = None
        # Do not lose track of in-flight network workers on a Stalker refresh.
        # Clearing this list allowed unbounded simultaneous requests.
        start = self.page * self.PAGE_SIZE
        total = len(self.grid_items)
        pages = max(1, (total+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["counter"].setText("Page %d / %d  •  %d Channels" % (self.page+1, pages, total))
        try:
            category_name = self.parentLive["categoryTitle"].getText() or "LIVE TV"
            self["header"].setText("TiviMate  |  " + str(category_name)[:38])
        except Exception:
            pass
        blank = os.path.join(PLUGIN_PATH, "skins", "common", "te2_fallback.png")
        for slot in range(self.PAGE_SIZE):
            absolute = start + slot
            logo = self["wIcon%d" % slot]
            if absolute >= total:
                self["wName%d" % slot].setText("")
                try: logo.hide()
                except Exception: pass
                try: self["wBadge%d" % slot].hide()
                except Exception: pass
                continue
            try: self["wBadge%d" % slot].hide()
            except Exception: pass
            item = self.grid_items[absolute] or {}
            name = ("Channel %d" % (absolute + 1) if item.get("_stalker_placeholder") else
                    str(item.get("name") or item.get("title") or "Channel").strip())
            try:
                fav_source = (item.get("_favorite_source")
                              if isinstance(item.get("_favorite_source"), dict)
                              else self.parentLive.source)
                is_fav = (favourite_id(fav_source, "live", item) in favourite_ids
                          if favourite_ids is not None
                          else is_favourite(fav_source, "live", item))
            except Exception:
                is_fav = False
            name_label = self["wName%d" % slot]
            now_title = self._windowsCachedTileProgramme(item)
            # Same RAM-positive-only EPG badge as standard Live, no network.
            try:
                known = bool(now_title or self.parentLive._liveRowHasEpg(item))
                key = self._windowsEpgIdentity(item)
                memo = self._windowsEpgMemo.get(key)
                known = known or bool(memo and memo[1] and time.time() - memo[0] < 600)
                if known:
                    self["wBadge%d" % slot].show()
            except Exception:
                pass
            if now_title:
                name_label.setText(("★  " if is_fav else "") + name[:24] + "\n" + "EPG  •  " + now_title[:24])
            else:
                name_label.setText(("★  " if is_fav else "") + name[:32])
            try:
                name_label.setForegroundColor(gRGB(255, 211, 64) if is_fav else gRGB(232, 240, 246))
            except Exception:
                pass
            try:
                if os.path.isfile(blank) and logo.instance:
                    logo.instance.setPixmapFromFile(blank)
                logo.show()
            except Exception:
                pass
            url = self._piconUrl(item)
            if url:
                # Ultra-style cache fast path: paint before EPG/Stalker/network.
                # Keep slow providers away from icons already present on disk.
                try:
                    from .estalker_picon import cached_picon_path
                    stored = cached_picon_path(url, (240, 100))
                except Exception:
                    stored = ''
                if stored:
                    try:
                        if logo.instance:
                            if slot != getattr(self, '_selectedTilePosterSlot', None):
                                cached_windows_picons.append((slot, stored))
                    except Exception:
                        pass
                else:
                    self._piconQueue.append((slot, url, generation))
        focused_slot = self.focusIndex - start
        for picon_slot, stored_path in sorted(
                cached_windows_picons, key=lambda pair: (pair[0] != focused_slot, pair[0])):
            self._paintCachedWindowsPicon(picon_slot, stored_path, generation)
        self._piconQueue.sort(key=lambda entry: (entry[0] != focused_slot, entry[0]))
        self._moveFocusFrame()
        self._drawPackageStrip()
        if preserve_preview:
            # An async Stalker page may fill OTHER cards while the currently
            # playing card is unchanged. Do not cancel and re-zap that service.
            try:
                row = self.grid_items[self.focusIndex]
                self._windowsTryCachedFocusedPicon(row)
            except Exception:
                pass
        else:
            # Page navigation should never use the package-first fast zap.
            self._initialEpgPaint = bool(fresh_bouquet)
            self._focusChanged()
        try:
            self._windowsBadgeTimer.stop()
            self._windowsBadgePolls = 0
            self._windowsBadgeTimer.start(1000, True)
        except Exception:
            pass
        # Stalker grid pages may still be placeholders when the user enters
        # the category. Request only the provider pages needed by the visible
        # 18 cards; a lightweight timer repaints them on completion.
        self._scheduleStalkerGridRefresh()
        kind = str((self.parentLive.source or {}).get("type") or "").lower()
        if kind == "stalker":
            try:
                # Ultra's source-validated epg_many: strictly ten visible IDs.
                self.parentLive._prefetchStalkerVisibleEpg(
                    visible_rows=self.grid_items[start:start + self.PAGE_SIZE])
            except Exception:
                pass
        elif kind == "xtream":
            try:
                # The ordinary Live list's own RAM/disk-first warmer, scoped
                # to the ten Windows cards on each newly opened package/page.
                self.parentLive._warmLiveBadgeCache(
                    visible_rows=self.grid_items[start:start + self.PAGE_SIZE],
                    visible_index=self.focusIndex - start, page_start=start)
            except Exception:
                pass
        # Start the first Ultra-style batch immediately. Remaining picons are
        # released in batches as the previous network workers finish.
        if self._piconQueue:
            try: self._piconTimer.start(1, True)
            except Exception: pass

    def _windowsApplyUltraEpg(self):
        """Ultra per-channel result painted on Enigma UI thread, without re-zap."""
        if self._closed or self._packagesOpen or not self.grid_items:
            return
        start = self.page * self.PAGE_SIZE
        for slot, row in enumerate(self.grid_items[start:start + self.PAGE_SIZE]):
            if not isinstance(row, dict) or row.get("_stalker_placeholder"):
                continue
            title = self._windowsCachedTileProgramme(row)
            if not title:
                continue
            try:
                label = self["wName%d" % slot]
                name = str(row.get("name") or row.get("title") or "Channel").strip()
                original = label.getText() or ""
                star = "★  " if original.startswith("★") else ""
                label.setText(star + name[:24] + "\nEPG  •  " + title[:24])
                self["wBadge%d" % slot].show()
            except Exception:
                pass
        try:
            row = self.grid_items[self.focusIndex]
            # Positive Ultra result is already in parent RAM and shared cache.
            self._windowsShowMemoEpg(row)
        except Exception:
            pass

    def _refreshWindowsBadges(self):
        """Repaint EPG marks from standard Live RAM; never query a provider."""
        if self._closed or self._packagesOpen or self._bouquetIdPending is not None:
            return
        # Parent Live may be hidden behind the Windows modal on some Enigma2
        # images. Drain completed Xtream EPG work from THIS active GUI timer,
        # so the ten green EPG indicators don't wait for the hidden screen.
        if not getattr(self, "_windowsBadgeDraining", False):
            self._windowsBadgeDraining = True
            try:
                if str((self.parentLive.source or {}).get("type") or "").lower() == "xtream":
                    self.parentLive._applyLiveBadgeCache()
            except Exception:
                pass
            finally:
                self._windowsBadgeDraining = False
        start = self.page * self.PAGE_SIZE
        for slot in range(self.PAGE_SIZE):
            idx = start + slot
            if idx >= len(self.grid_items):
                try: self["wBadge%d" % slot].hide()
                except Exception: pass
                continue
            row = self.grid_items[idx] or {}
            try:
                present = bool(self._windowsCachedTileProgramme(row) or self.parentLive._liveRowHasEpg(row))
                cached = self._windowsEpgMemo.get(self._windowsEpgIdentity(row))
                present = present or bool(cached and cached[1] and time.time() - cached[0] < 600)
                if present:
                    self["wBadge%d" % slot].show()
                else:
                    self["wBadge%d" % slot].hide()
            except Exception:
                pass
        self._windowsBadgePolls += 1
        # Some providers need more than twelve seconds for ten EPG results.
        # Keep cheap RAM-only badge repainting alive while that single bounded
        # batch is running, with a hard cap so no idle polling leaks occur.
        warming = bool(getattr(self.parentLive, "liveBadgeCacheRunning", False))
        if self._windowsBadgePolls < 12 or (warming and self._windowsBadgePolls < 60):
            try: self._windowsBadgeTimer.start(1000, True)
            except Exception: pass

    def _scheduleStalkerGridRefresh(self):
        if (getattr(self, '_closed', True) or self._packagesOpen or
                self._bouquetIdPending is not None or
                (self.parentLive.source or {}).get('type') != 'stalker'):
            return
        try:
            parent = self.parentLive
            if bool(getattr(parent, 'stalkerLiveAdultDirect', False)):
                return
            start = self.page * self.PAGE_SIZE
            stop = min(start + self.PAGE_SIZE, len(self.grid_items))
            loaded = getattr(parent, 'stalkerLiveLoadedPages', set()) or set()
            for page in range(start // 14 + 1, (max(start, stop - 1)) // 14 + 2):
                if page not in loaded:
                    parent._requestStalkerLivePage(page)
            self._stalkerGridTimer.start(240, True)
        except Exception:
            pass

    def _refreshStalkerGrid(self):
        if (getattr(self, '_closed', True) or self._packagesOpen or
                self._bouquetIdPending is not None or
                (self.parentLive.source or {}).get('type') != 'stalker'):
            return
        try:
            latest = list(getattr(self.parentLive, 'stalkerLiveSlots', []) or [])
            if latest:
                start = self.page * self.PAGE_SIZE
                stop = start + self.PAGE_SIZE
                previous = self.grid_items[start:stop]
                upcoming = latest[start:stop]
                def signature(rows):
                    return [(str((r or {}).get('name') or (r or {}).get('title') or ''),
                             str((r or {}).get('stream_id') or (r or {}).get('ch_id') or ''),
                             str((r or {}).get('stream_icon') or (r or {}).get('logo') or (r or {}).get('icon') or ''),
                             bool((r or {}).get('_stalker_placeholder'))) for r in rows]
                if len(latest) != len(self.grid_items) or signature(previous) != signature(upcoming):
                    previous_focus = (self.grid_items[self.focusIndex]
                        if 0 <= self.focusIndex < len(self.grid_items) else None)
                    self.grid_items = latest
                    self.focusIndex = max(0, min(self.focusIndex, len(latest) - 1))
                    self.page = self.focusIndex // self.PAGE_SIZE
                    selected_now = self.grid_items[self.focusIndex] if self.grid_items else None
                    focus_same = (previous_focus is not None and selected_now is not None
                                  and signature([previous_focus]) == signature([selected_now]))
                    self._render(preserve_preview=focus_same)
                    return
            self._scheduleStalkerGridRefresh()
        except Exception:
            self._scheduleStalkerGridRefresh()

    def _loadNextPicon(self):
        if self._closed:
            return
        # Reap finished workers and refill only the free slots. The previous
        # implementation waited for the whole batch to finish, which created a
        # visible pause after every four cards and was slower than Ultra.
        live = []
        for thread in list(getattr(self, "_piconThreads", []) or []):
            try:
                if thread is not None and thread.is_alive():
                    live.append(thread)
            except Exception:
                pass
        self._piconThreads = live
        if not self._piconQueue:
            return
        free = max(0, int(self._piconParallel) - len(live))
        if free <= 0:
            try: self._piconTimer.start(60, True)
            except Exception: pass
            return
        batch = self._piconQueue[:free]
        del self._piconQueue[:free]
        for slot, url, generation in batch:
            def active():
                return self._requestGeneration if not self._closed else -1
            def display(path, slot=slot, generation=generation):
                if self._closed or generation != self._requestGeneration or not path:
                    return
                try:
                    target = self["wIcon%d" % slot]
                    if target.instance:
                        if slot != getattr(self, '_selectedTilePosterSlot', None):
                            self._paintCachedWindowsPicon(slot, path, generation)
                        if slot == self.focusIndex % self.PAGE_SIZE:
                            self._windowsShowFocusedPicon(path, self._posterToken)
                except Exception:
                    pass
            try:
                thread = direct_picon(url, (240,100), generation, active, display,
                                      prefix="xst_live_picon_", progressive=True)
                if thread is not None and thread not in self._piconThreads:
                    self._piconThreads.append(thread)
            except Exception:
                pass

        if self._piconQueue:
            try: self._piconTimer.start(60 if self._piconThreads else 1, True)
            except Exception: pass

    def _moveFocusFrame(self):
        # Lightweight transparent theme tint below picons/text, plus the
        # existing silver outline above them. Both follow the same selection.
        if self._packagesOpen or not self.grid_items:
            for name in ("focusTint", "focusFrame"):
                try: self[name].hide()
                except Exception: pass
            return
        index = self.focusIndex % self.PAGE_SIZE
        x = self.X0 + (index % self.COLS) * self.DX
        y = self.Y0 + (index // self.COLS) * self.DY
        for name in ("focusTint", "focusFrame"):
            try:
                self[name].instance.move(ePoint(sx(x), sy(y)))
                self[name].show()
            except Exception:
                pass

    def _selectIndex(self, index):
        if not self.grid_items:
            return
        target_index = max(0, min(int(index), len(self.grid_items)-1))
        # Returning to an already selected card must not schedule another zap.
        if target_index == self.focusIndex and not self._packagesOpen:
            self._moveFocusFrame()
            return
        self.focusIndex = target_index
        new_page = self.focusIndex // self.PAGE_SIZE
        if new_page != self.page:
            self.page = new_page
            self._render()
        else:
            self._moveFocusFrame()
            self._focusChanged()

    def _paintToolbarFocus(self):
        # Selection stays exclusively on channel cards.
        return

    def _left(self):
        if self._packagesOpen:
            self._movePackageArrow(-1, 0)
            return
        if self.focusIndex % self.COLS > 0:
            self._selectIndex(self.focusIndex-1)

    def _right(self):
        if self._packagesOpen:
            self._movePackageArrow(1, 0)
            return
        if self.focusIndex % self.COLS < self.COLS-1:
            self._selectIndex(self.focusIndex+1)

    def _up(self):
        if self._packagesOpen:
            self._movePackageArrow(0, -1)
            return
        # Continue to the previous page when moving above the top grid row.
        # Indexes span all pages, so moving by COLS preserves the column.
        if self.grid_items and self.focusIndex >= self.COLS:
            self._selectIndex(self.focusIndex - self.COLS)

    def _down(self):
        if self._packagesOpen:
            self._movePackageArrow(0, 1)
            return
        # Continue to the next page when moving beyond the bottom grid row.
        # Keep the current column, and don't select an empty trailing slot.
        target = self.focusIndex + self.COLS
        if self.grid_items and target < len(self.grid_items):
            self._selectIndex(target)

    def _prevPage(self):
        if self._packagesOpen:
            self._movePackage(-self.PAGE_SIZE)
        elif self._toolbarIndex is None:
            self._selectIndex(self.focusIndex-self.PAGE_SIZE)

    def _nextPage(self):
        if self._packagesOpen:
            self._movePackage(self.PAGE_SIZE)
        elif self._toolbarIndex is None:
            self._selectIndex(self.focusIndex+self.PAGE_SIZE)

    def _focusChanged(self):
        """Only cache reads on keypress; EPG/network work runs after debounce."""
        # A pending full-screen transition belongs to the *previous* focus.
        # Never open an old channel after the user presses LEFT/RIGHT.
        self._pendingFullscreenIdentity = None
        try: self._pendingFullscreenTimer.stop()
        except Exception: pass
        self._epgToken += 1
        self._posterToken += 1
        self._epgBackdropToken += 1
        self._previewOkIdentity = None
        self._previewRequestedIdentity = None
        self._previewServiceRef = None
        try: self._previewWatchTimer.stop()
        except Exception: pass
        self._cancelFavoritePreviewLink()
        try:
            self.parentLive._cancelLiveZapResolve()
            if getattr(self.parentLive, "_livePreviewCheck", None) is not None:
                # Focus-only movement must not stop the video already starting
                # in Enigma2. A later deliberate OK owns decoder replacement.
                self.parentLive._cancelLivePreviewCheck(stop_failed=False)
        except Exception: pass
        self._posterDisplayedToken = -1
        self._posterFallbackTitle = ""
        self._posterSearchResult = None
        self._epgResult = None
        try:
            old_slot = getattr(self, "_selectedTilePosterSlot", None)
            if old_slot is not None:
                # Release the poster ownership BEFORE repainting. The shared
                # Ultra picon callback intentionally refuses to overwrite an
                # active programme poster; restoring first left a blank tile.
                self._selectedTilePosterSlot = None
                self._restoreTilePicon(old_slot)
        except Exception:
            pass
        try:
            self._epgRefresh.stop()
            self._posterFallbackTimer.stop()
            # Keep polling an in-flight poster worker until it completes; a
            # new selection must not inherit a permanently busy old request.
            if not self._posterSearchBusy:
                self._posterSearchPoll.stop()
            self._epgTimer.stop()
            self._previewTimer.stop()
            self._posterFollow.stop()
            self._posterFollowTitle = ""
            self["programmePoster"].hide()
            self["programmePicon"].hide()
            self["epgBackdrop"].hide()
            self["epgTimelineTrack"].hide()
            self["epgTimelineFill"].hide()
            self._programmePiconLoader = None
            for badge in ("epgBadgeLive", "epgBadgeGenre", "epgBadgeDetail"):
                self[badge].hide()
        except Exception:
            pass
        item = self.grid_items[self.focusIndex] if 0 <= self.focusIndex < len(self.grid_items) else {}
        self["channelName"].setText(str((item or {}).get("name") or (item or {}).get("title") or "Select channel")[:65])
        self["previewChannel"].setText(str((item or {}).get("name") or (item or {}).get("title") or "")[:40])
        try: self["previewHint"].setText("OK: Preview  •  OK again: Full Screen")
        except Exception: pass
        self["epgNow"].setText("" if item else "No channels")
        self["epgTime"].setText("")
        self["epgNext"].setText("")
        self["epgDescription"].setText("")
        # Navigation within a ten-card page must promote the newly focused
        # picon, not wait for earlier tiles on a slow logo host. Keep existing
        # in-flight downloads and the Ultra EPG page wave intact.
        try:
            slot = self.focusIndex % self.PAGE_SIZE
            from .estalker_picon import prioritize_picon
            prioritize_picon(self._piconUrl(item))
            if self._piconQueue:
                # A slow old page can occupy all four Windows scheduling
                # slots. Send the focused card straight to Ultra's bounded
                # executor with priority -1; don't create another HTTP pool.
                # It deduplicates an already in-flight URL automatically.
                urgent = next((task for task in self._piconQueue
                               if task[0] == slot and task[2] == self._requestGeneration), None)
                if urgent is not None:
                    self._piconQueue.remove(urgent)
                    _, url, generation = urgent
                    def active_generation():
                        return self._requestGeneration if not self._closed else -1
                    def show_focused(path, expected=generation, selected=slot):
                        if self._closed or expected != self._requestGeneration or not path:
                            return
                        # The cursor may move while this worker downloads;
                        # the original tile still needs its logo in the grid.
                        self._paintCachedWindowsPicon(selected, path, expected)
                        if selected == self.focusIndex % self.PAGE_SIZE:
                            self._windowsShowFocusedPicon(path, self._posterToken)
                    worker = direct_picon(url, (240, 100), generation,
                                          active_generation, show_focused,
                                          prefix="xst_live_picon_", priority=-1)
                    if worker is not None:
                        self._piconThreads.append(worker)
                self._piconQueue.sort(key=lambda task: (task[0] != slot, task[0]))
                self._piconTimer.start(1, True)
        except Exception:
            pass
        self._windowsTryCachedFocusedPicon(item)
        if not item or (item or {}).get("_stalker_placeholder"):
            return
        first_paint = bool(getattr(self, "_initialEpgPaint", False))
        self._initialEpgPaint = False
        if self._windowsShowMemoEpg(item):
            try: self._epgRefresh.start(60000, True)
            except Exception: pass
        else:
            # Standard Live begins showing its cached guide as soon as the
            # bouquet opens. Windows must not leave the EPG empty for 850ms.
            # Focus movements are still debounced to prevent request storms.
            try: self._epgTimer.start(35 if first_paint else 190, True)
            except Exception: pass
        # Navigation changes ONLY the highlighted channel and cached artwork.
        # Starting a stream/create_link is explicit: first OK previews, second
        # OK opens the full-screen Infobar. Never schedule a zap on cursor move
        # or on first entry into a package (normal list and Windows agree).
        try: self._previewTimer.stop()
        except Exception: pass

    def _cancelFavoritePreviewLink(self):
        handle = getattr(self, "_favoritePreviewHandle", None)
        self._favoritePreviewHandle = None
        self._favoritePreviewHandoffState = None
        if handle is not None:
            try: handle.cancel()
            except Exception: pass
        self._favoritePreviewToken += 1
        self._favoritePreviewPending = None
        self._favoritePreviewResult = None
        self._favoritePreviewDeadline = 0.0
        try: self._favoritePreviewTimer.stop()
        except Exception: pass

    def _handoffFavoritePreviewLink(self, row, source):
        """Give the *same* mixed-Stalker preview worker to the Infobar.

        Never transfer a request for a different provider/card. The worker
        continues independently of the Windows screen and writes its result
        into this shared state; cancellation belongs to the full-screen player.
        """
        if not isinstance(row, dict) or not isinstance(source, dict):
            return None
        if str(source.get("type") or "").lower() != "stalker":
            return None
        channel = str(row.get("stream_id") or row.get("ch_id") or
                      row.get("id") or row.get("url") or row.get("cmd") or
                      row.get("name") or "").strip()
        state = getattr(self, "_favoritePreviewHandoffState", None)
        key = (str(_source_identity(source)), channel)
        if (not channel or not isinstance(state, dict) or
                state.get("source") != key or
                state.get("token") != self._favoritePreviewToken or
                state.get("handle") is not self._favoritePreviewHandle or
                key != self._favoritePreviewPending):
            return None
        if state.get("result") is None and time.monotonic() >= state.get("deadline", 0):
            return None
        state["transferred"] = True
        self._favoritePreviewHandle = None
        self._favoritePreviewHandoffState = None
        self._favoritePreviewPending = None
        self._favoritePreviewResult = None
        self._favoritePreviewDeadline = 0.0
        self._favoritePreviewToken += 1
        try: self._favoritePreviewTimer.stop()
        except Exception: pass
        return state

    def _pollPreviewHealth(self):
        if self._closed or self._packagesOpen:
            return
        parent = self.parentLive
        # The hidden parent may not receive its timer callbacks on every image.
        # Drain completed Ultra link jobs and decoder checks from active Windows.
        try:
            if (getattr(parent, "liveZapResolveResult", None) is not None or
                    (getattr(parent, "liveZapResolveDeadline", 0) and
                     time.monotonic() >= parent.liveZapResolveDeadline)):
                parent._finishAsyncLiveZap()
            if getattr(parent, "_livePreviewCheck", None):
                parent._pollLivePreviewCheck()
            if (getattr(parent, "liveZapResolveHandle", None) is not None or
                    getattr(parent, "_livePreviewCheck", None) is not None):
                self._previewWatchTimer.start(350, True)
        except Exception:
            pass

    def _previewSelectedChannel(self):
        if self._closed or self._packagesOpen or self._bouquetIdPending is not None:
            return
        if not self.grid_items or not (0 <= self.focusIndex < len(self.grid_items)):
            return
        row = self.grid_items[self.focusIndex] or {}
        if row.get("_stalker_placeholder") or str(row.get("name") or "").startswith("####"):
            return
        try:
            parent = self.parentLive
            favorite_source = row.get("_favorite_source") if isinstance(row.get("_favorite_source"), dict) else None
            # Ultra grid starts its preview worker on the highlighted row.
            # NEVER resynchronise the hidden parent list on first OK: doing so
            # can synchronously rebuild Xtream/M3U batches, trigger artwork/EPG
            # callbacks and retire an already running decoder probe.
            if (self._windowsSelectedChannelLocked(row, favorite_source) and
                    time.time() >= getattr(parent, "stalkerPinUnlockedUntil", 0)):
                return
            if not favorite_source:
                token = self._favoritePreviewToken
                # Auto-preview failure backoff applies to every protocol.
                # Do not retry a dead card every time the cursor passes over
                # it; explicit OK still permits a fresh attempt.
                key = self._selectedFullscreenIdentity()
                if key and time.monotonic() < self._autoPreviewFailedUntil.get(key, 0.0):
                    try: self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
                    except Exception: pass
                    return
                def finished(success, expected=token, requested=key):
                    if self._closed or self._packagesOpen or expected != self._favoritePreviewToken:
                        return
                    # A slow decoder callback for a card already left by the
                    # cursor must never show its state over the new card.
                    if (requested != self._selectedFullscreenIdentity() or
                            requested != self._previewRequestedIdentity):
                        return
                    if requested:
                        if success:
                            self._autoPreviewFailedUntil.pop(requested, None)
                            self._previewOkIdentity = requested
                        else:
                            self._previewOkIdentity = None
                            self._autoPreviewFailedUntil[requested] = time.monotonic() + 15.0
                            if len(self._autoPreviewFailedUntil) > 80:
                                self._autoPreviewFailedUntil.clear()
                    try:
                        self["previewHint"].setText(
                            "CHANNEL PREVIEW  •  OK: Full Screen" if success
                            else "Preview unavailable  •  OK: Infobar")
                    except Exception: pass
                if not parent._zapLiveItem(row, False, _on_complete=finished):
                    finished(False)
                try: self._previewWatchTimer.start(350, True)
                except Exception: pass
                return
            source = dict(favorite_source)
            selected_row = dict(row)
            # Mixed favorites must obey the same negative-cache/backoff as
            # ordinary Windows channel cards. Otherwise every focus revisit
            # launches a new portal create_link on a dead favorite.
            focus_key = self._selectedFullscreenIdentity()
            if focus_key and time.monotonic() < self._autoPreviewFailedUntil.get(focus_key, 0.0):
                try: self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
                except Exception: pass
                return
            # Mixed favorite source: same Ultra cancellation policy as Live.
            self._cancelFavoritePreviewLink()
            token = self._favoritePreviewToken
            key = (str(_source_identity(source)), str(selected_row.get("stream_id") or
                   selected_row.get("ch_id") or selected_row.get("id") or
                   selected_row.get("url") or selected_row.get("cmd") or
                   selected_row.get("name") or ""))
            self._favoritePreviewPending = key
            self._favoritePreviewDeadline = time.monotonic() + 11.0
            playback_source = _bein_base_source(source) if source.get("_virtual_bein") else source
            is_stalker = playback_source.get("type") == "stalker"
            handle = _UltraLiveTaskHandle(token, "favorite_preview") if is_stalker else None
            self._favoritePreviewHandle = handle
            state = ({"token": token, "handle": handle, "source": key,
                      "deadline": self._favoritePreviewDeadline, "result": None,
                      "transferred": False, "favorite": True,
                      "owner": dict(source)} if is_stalker else None)
            self._favoritePreviewHandoffState = state
            # No perpetual Connecting indicator while scanning channel cards.
            def resolve():
                url = ""
                try:
                    if handle is not None and handle.cancelled():
                        return
                    if playback_source.get("type") in ("m3u", "fg"):
                        url = str(selected_row.get("url") or "")
                    elif is_stalker:
                        client = _live_playback_client(playback_source, get_source_client)
                        url = client.stream_url(
                            selected_row, "live", cancel_event=handle) or ""
                    else:
                        url = get_source_client(playback_source).stream_url(selected_row, "live") or ""
                except Exception:
                    if is_stalker and (handle is None or not handle.cancelled()):
                        _invalidate_playback_client(playback_source)
                if handle is not None and handle.cancelled():
                    return
                if state is not None:
                    # An owned handoff may complete after Windows is hidden or
                    # its preview token retired; it must still reach the player.
                    if (not handle.cancelled() and
                            (state["transferred"] or
                             (not self._closed and token == self._favoritePreviewToken
                              and key == self._favoritePreviewPending))):
                        state["result"] = (token, selected_row, False, url, "")
                if (not self._closed and token == self._favoritePreviewToken and
                        key == self._favoritePreviewPending and
                        not (state is not None and state["transferred"])):
                    self._favoritePreviewResult = (token, key, source, selected_row, url)
            try:
                if is_stalker:
                    handle.future = _ULTRA_STALKER_LINK_POOL.submit(
                        resolve, _task_key=("windows-favorite", id(self)),
                        _replace_task_key=True)
                else:
                    threading.Thread(target=resolve, name="TiviMateWindowsFavoritePreview", daemon=True).start()
                self._favoritePreviewTimer.start(160, True)
            except Exception:
                self._cancelFavoritePreviewLink()
                try: self["previewHint"].setText("Preview unavailable")
                except Exception: pass
        except Exception:
            pass

    @staticmethod
    def _windowsEpgTime(value):
        """Parse provider timestamps with the same formats as regular Live."""
        if value in (None, ""):
            return 0
        try:
            result = int(float(value))
            # Epoch milliseconds are common in third-party guide feeds.
            return result // 1000 if result > 10 ** 11 else result
        except Exception:
            pass
        raw = str(value).strip()
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
            try:
                return int(time.mktime(time.strptime(raw[:19] if fmt.endswith(":%S") else raw[:16], fmt)))
            except Exception:
                pass
        return 0

    @classmethod
    def _windowsNormaliseEpg(cls, event):
        """Convert local XMLTV tuples and Xtream/Stalker dictionaries to one shape."""
        if isinstance(event, (tuple, list)) and len(event) >= 4:
            try:
                start, duration = int(event[0]), max(0, int(event[1]))
            except Exception:
                return None
            return {"title": cls._decodeWindowsEpg(event[2]),
                    "description": cls._decodeWindowsEpg(event[3]),
                    "start_timestamp": start,
                    "stop_timestamp": start + duration,
                    "duration": duration}
        if not isinstance(event, dict):
            return None
        item = dict(event)
        item["title"] = cls._decodeWindowsEpg(
            item.get("title") or item.get("name") or item.get("programme") or item.get("event_name"))
        item["description"] = cls._decodeWindowsEpg(
            item.get("description") or item.get("descr") or item.get("desc") or item.get("plot"))
        start = 0
        for key in ("start_timestamp", "time", "start", "begin_timestamp", "begin"):
            start = cls._windowsEpgTime(item.get(key))
            if start:
                break
        stop = 0
        for key in ("stop_timestamp", "time_to", "stop", "end", "end_timestamp"):
            stop = cls._windowsEpgTime(item.get(key))
            if stop:
                break
        # Use the same Ultra-compatible time normalization in Windows,
        # regular Live and the full-screen Infobar. Do not invent a one-hour
        # end for untimed programmes: the progress bar must be accurate.
        start, stop = _shared_epg_interval(start, stop, item.get("duration"))
        duration = max(0, stop - start) if start and stop else 0
        item["start_timestamp"] = start
        item["stop_timestamp"] = stop
        item["duration"] = duration
        return item if item["title"] else None

    @classmethod
    def _windowsChooseEpg(cls, records, provider="", now_ts=None):
        """Time-ordered current/next selection; never blindly use rows[0:2]."""
        now_ts = int(now_ts if now_ts is not None else time.time())
        if provider == "stalker":
            selected, following = _shared_stalker_now_next(records, now_ts=now_ts)
            def with_ultra_title(event):
                if not event:
                    return None
                normalized = cls._windowsNormaliseEpg(event[2])
                title = ultra_epg_title(event[2])
                if normalized is None and title:
                    normalized = dict(event[2])
                    normalized["title"] = title
                if normalized is not None:
                    # The selector already resolved relative MAG stop times.
                    # Never overwrite these with the raw time_to value.
                    normalized["start_timestamp"] = event[0]
                    normalized["stop_timestamp"] = event[1]
                    normalized["duration"] = max(0, event[1] - event[0])
                return normalized
            return with_ultra_title(selected), with_ultra_title(following)
        items = [cls._windowsNormaliseEpg(row) for row in (records or [])]
        events = [r for r in items if r and r.get("start_timestamp")]
        events.sort(key=lambda r: int(r["start_timestamp"]))
        if not events:
            return None, None
        current = next((e for e in events if
                        e["start_timestamp"] <= now_ts < e["stop_timestamp"]), None)
        if current is None and provider == "xtream":
            # Match regular Live's 15-minute provider-clock correction only
            # when no event contains the receiver time.
            first = events[0]
            duration = int(first.get("duration") or 3600)
            provider_pos = int(first["start_timestamp"]) + duration // 2
            quantum = 900
            shift = int(round(float(now_ts - provider_pos) / quantum)) * quantum
            if abs(shift) <= 14 * 3600:
                shifted = []
                for old in events:
                    newer = dict(old)
                    newer["start_timestamp"] += shift
                    newer["stop_timestamp"] += shift
                    shifted.append(newer)
                events = shifted
                current = next((e for e in events if
                                e["start_timestamp"] <= now_ts < e["stop_timestamp"]), None)
        if current is None and provider == "stalker":
            # The full-screen infobar selects the first future event, or the
            # first returned one when portal clock offsets make none current.
            # Match its choice so Windows does not show blank EPG for a channel
            # whose infobar already displays a provider programme.
            current = next((e for e in events if e["start_timestamp"] > now_ts), events[0])
            index = events.index(current)
            return current, (events[index + 1] if index + 1 < len(events) else None)
        next_event = next((e for e in events if e["start_timestamp"] > now_ts and
                           (current is None or e["start_timestamp"] >= current["stop_timestamp"])), None)
        return current, next_event

    def _windowsEpgIdentity(self, row, source=None):
        source = source or row.get("_favorite_source") or self.parentLive.source or {}
        # Stalker EPG is keyed by ch_id in Ultra/Infobar; its stream_id can
        # refer to a playback command or be reused across categories.
        if str(source.get("type") or "").lower() == "stalker":
            channel_key = row.get("ch_id") or row.get("stream_id")
        else:
            channel_key = row.get("stream_id") or row.get("ch_id")
        return (str(_source_identity(source)), str(channel_key or
                row.get("id") or row.get("url") or row.get("name") or ""))

    def _windowsRememberEpg(self, key, now, next_event):
        if not key:
            return
        memo = self._windowsEpgMemo
        memo[key] = (time.time(), dict(now or {}), dict(next_event or {}))
        if len(memo) > 100:
            for old in sorted(memo, key=lambda k: memo[k][0])[:25]:
                memo.pop(old, None)

    def _windowsShowMemoEpg(self, row):
        key = self._windowsEpgIdentity(row)
        found = self._windowsEpgMemo.get(key)
        # The shared provider cache, also used by full-screen Infobar, wins
        # over even a positive but older Windows-local snapshot.
        # A negative Windows memo must never hide positive EPG just returned
        # by the full-screen infobar. Check its shared RAM first.
        # Infobar and Windows now read the SAME successful provider responses.
        try:
            source = row.get("_favorite_source") or self.parentLive.source or {}
            kind = str(source.get("type") or "").lower()
            rows = _shared_live_epg_cached(source, row)
            if rows:
                now, nxt = self._windowsChooseEpg(rows, kind)
                if now or nxt:
                    self._windowsRememberEpg(key, now, nxt)
                    self._showSelectedEpg(now or {}, nxt or {})
                    return True
            if not row.get("_favorite_source") and kind == "xtream":
                rows = self.parentLive._xtreamCachedShortEpg(row, max_age=900)
            elif not row.get("_favorite_source") and kind == "stalker":
                rows = list(self.parentLive.stalkerShortEpgResults.get(
                    self.parentLive._stalkerEpgChannelId(row)) or [])
            else:
                rows = []
            if rows:
                now, nxt = self._windowsChooseEpg(rows, kind)
                if now or nxt:
                    self._windowsRememberEpg(key, now, nxt)
                    self._showSelectedEpg(now or {}, nxt or {})
                    return True
        except Exception:
            pass
        try:
            if str((self.parentLive.source or {}).get("fast_service") or "").lower() != "lgchannels":
                cache = eEPGCache.getInstance()
                ref = epg_reference_string(row.get("_favorite_source") or self.parentLive.source, row)
                entries = cache.lookupEvent(["IBDTEX", (ref, -1, -1, -1)]) if cache and ref else []
                if entries:
                    events = [(int(e[1]), int(e[2]), e[3] or "", e[4] or "")
                              for e in entries[:4] if len(e) >= 5]
                    current, following = self._windowsChooseEpg(events)
                    if current:
                        self._windowsRememberEpg(key, current, following)
                        self._showSelectedEpg(current, following or {})
                        return True
        except Exception:
            pass
        if found and found[1] and time.time() - found[0] < 600:
            self._showSelectedEpg(found[1], found[2])
            return True
        if found and time.time() - found[0] < 180:
            return False
        return False

    def _requestSelectedEpg(self):
        """Reuse regular Live's provider-first flow and prepared local XMLTV cache."""
        if self._closed or self._packagesOpen or self._bouquetIdPending is not None or not self.grid_items:
            return
        # Ultra's first OK starts a cancellable create_link worker immediately.
        # Do not compete with it by starting a *second*, selected-card short_epg
        # request just because the selected channel has no guide in RAM.
        # Existing EPG (including the visible-page ten-channel wave) remains.
        selected_identity = self._selectedFullscreenIdentity()
        if (selected_identity is not None and
                selected_identity == getattr(self, "_previewRequestedIdentity", None)):
            parent = self.parentLive
            pending_link = (getattr(parent, "liveZapResolveHandle", None) is not None and
                            time.monotonic() < float(getattr(parent, "liveZapResolveDeadline", 0) or 0))
            pending_check = getattr(parent, "_livePreviewCheck", None) is not None
            pending_favorite = (getattr(self, "_favoritePreviewPending", None) is not None and
                                time.monotonic() < float(getattr(self, "_favoritePreviewDeadline", 0) or 0))
            if pending_link or pending_check or pending_favorite:
                try: self._epgTimer.start(350, True)
                except Exception: pass
                return
        if self._epgBusy:
            if self._epgActiveToken != self._epgToken:
                # The cursor moved: old network work may keep running, but it
                # must never own the *new* focused channel's UI for 6.5 sec.
                # Ultra's keyed bounded executor cancels queued obsolete jobs;
                # only two requests can run concurrently. The old worker is
                # unable to publish because it checks _epgActiveToken.
                self._epgActiveToken = None
                self._epgBusy = False
                self._epgResult = None
            else:
                # Exactly this selection already has a request in progress.
                return
        if not (0 <= self.focusIndex < len(self.grid_items)):
            return
        token = self._epgToken
        row = dict(self.grid_items[self.focusIndex] or {})
        if self._windowsShowMemoEpg(row):
            return
        source = dict(row.get("_favorite_source") or self.parentLive.source or {})
        kind = str(source.get("type") or "").lower()
        cached_rows = []
        # Xtream and Stalker already have a selected-channel cache in Live.
        # Read it before launching the thread; do not touch GUI state there.
        cached_rows = _shared_live_epg_cached(source, row)
        if not cached_rows and not row.get("_favorite_source"):
            try:
                if kind == "xtream":
                    cached_rows = self.parentLive._xtreamCachedShortEpg(row, max_age=900)
                elif kind == "stalker":
                    cid = self.parentLive._stalkerEpgChannelId(row)
                    cached_rows = list(self.parentLive.stalkerShortEpgResults.get(cid) or [])
            except Exception:
                cached_rows = []
        if cached_rows:
            current, upcoming = self._windowsChooseEpg(cached_rows, kind)
            if current or upcoming:
                self._windowsRememberEpg(self._windowsEpgIdentity(row), current, upcoming)
                self._showSelectedEpg(current or {}, upcoming or {})
                return
        stalker_no_data_cooldown = False
        if kind == "stalker" and not row.get("_favorite_source"):
            cid = self.parentLive._stalkerEpgChannelId(row)
            if cid in getattr(self.parentLive, "stalkerEpgDownloadedChannels", set()):
                # Ultra's bounded visible-page wave already owns this request.
                # Its per-channel completion will repaint this panel directly.
                return
            stalker_no_data_cooldown = (time.time() < float(
                getattr(self.parentLive, "stalkerEpgNoDataUntil", {}).get(cid, 0) or 0))
        self._epgBusy = True
        self._epgActiveToken = token
        self._epgStartedAt = time.monotonic()

        def worker():
            current, upcoming = None, None
            provider_rows = cached_rows
            if kind in ("xtream", "stalker"):
                if not provider_rows and kind == "stalker" and not stalker_no_data_cooldown:
                    try:
                        # Allow Ultra's in-flight visible-page guide to finish
                        # briefly on this WORKER, never block the GUI or start
                        # another network request if it already succeeded.
                        from .live_epg_bridge import wait_for_visible_result
                        provider_rows = wait_for_visible_result(source, row, max_wait=0.45)
                    except Exception:
                        provider_rows = []
                if not provider_rows and not stalker_no_data_cooldown:
                    try:
                        # Use the same channel identifier as the infobar and
                        # the shared get_source_client/PortalSession instance.
                        cid = str(row.get("ch_id") or row.get("stream_id") or row.get("id") or "")
                        if cid:
                            client = get_source_client(source)
                            if kind == "xtream":
                                provider_rows = client.short_epg(
                                    cid, limit=3,
                                    epg_channel_id=str(row.get("epg_channel_id") or row.get("tvg_id") or "")) or []
                            else:
                                provider_rows = client.short_epg(cid, limit=3, force=False) or []
                    except Exception:
                        provider_rows = []
                current, upcoming = self._windowsChooseEpg(provider_rows, kind)
            # Same local-cache fallback as standard Live; never perform HDD
            # XMLTV parsing or network calls on remote-control keypress.
            if current is None:
                try:
                    local_now, local_next = lookup_channel_epg(source, row, int(time.time()))
                    current = self._windowsNormaliseEpg(local_now)
                    upcoming = self._windowsNormaliseEpg(local_next) if local_next else upcoming
                except Exception:
                    pass
            # A result must be shared even when focus changed. The GUI never
            # reads an obsolete result, but infobar can reuse this provider RAM.
            if provider_rows:
                _shared_live_epg_remember(source, row, provider_rows)
            if not self._closed and token == self._epgActiveToken:
                self._epgResult = (token, current, upcoming,
                                   kind, row, provider_rows if not cached_rows else [])

        try:
            self._epgFuture = _ULTRA_LIVE_EPG_POOL.submit(
                worker, _task_key=("windows-epg", id(self)),
                _replace_task_key=True)
            self._epgPoll.start(180, True)
        except Exception:
            self._epgBusy = False
            self._epgActiveToken = None

    def _pollSelectedEpg(self):
        if self._closed:
            return
        result = self._epgResult
        if result is None:
            if self._epgBusy:
                if time.monotonic() - self._epgStartedAt > 6.5:
                    expired_token = self._epgActiveToken
                    self._epgActiveToken = None
                    self._epgBusy = False
                    self._epgStartedAt = 0.0
                    self._epgResult = None
                    if expired_token != self._epgToken:
                        # The focus moved. Load the *new* channel only.
                        try: self._epgTimer.start(1, True)
                        except Exception: pass
                    else:
                        # No retry storm for a silent provider. Navigation and
                        # Live playback remain usable with a missing guide.
                        try: self._showSelectedEpg({}, {})
                        except Exception: pass
                        try: self._epgRefresh.start(60000, True)
                        except Exception: pass
                else:
                    try: self._epgPoll.start(200, True)
                    except Exception: pass
            return
        self._epgBusy = False
        self._epgActiveToken = None
        self._epgStartedAt = 0.0
        self._epgResult = None
        token, current, upcoming, kind, item, provider_rows = result
        self._windowsRememberEpg(self._windowsEpgIdentity(item), current, upcoming)
        try: self._refreshWindowsBadges()
        except Exception: pass
        # Never paint stale EPG or cache results belonging to a previous server.
        if token != self._epgToken:
            try: self._epgTimer.start(70, True)
            except Exception: pass
            return
        if provider_rows and not item.get("_favorite_source"):
            try:
                if kind == "xtream":
                    self.parentLive._storeXtreamShortEpg(item, provider_rows)
                elif kind == "stalker":
                    cid = self.parentLive._stalkerEpgChannelId(item)
                    self.parentLive.stalkerShortEpgResults[cid] = provider_rows
            except Exception:
                pass
        if not current:
            # Regular Live also checks the receiver's native Enigma2 EPG cache.
            try:
                fast = str((self.parentLive.source or {}).get("fast_service") or "").lower()
                if fast != "lgchannels":
                    cache = eEPGCache.getInstance()
                    ref = epg_reference_string(item.get("_favorite_source") or self.parentLive.source, item)
                    entries = (cache.lookupEvent(["IBDTEX", (ref, -1, -1, -1)]) or []) if cache else []
                    if entries:
                        events = [(int(r[1]), int(r[2]), r[3] or "", r[4] or "") for r in entries if len(r) >= 5]
                        current, upcoming = self._windowsChooseEpg(events)
            except Exception:
                pass
        self._showSelectedEpg(current or {}, upcoming or {})
        # Refresh on the same selection, so programme changes do not require
        # exiting/re-entering Windows. Keep polling infrequent to avoid load.
        try: self._epgRefresh.start(60000, True)
        except Exception: pass

    def _refreshSelectedEpg(self):
        if self._closed or self._packagesOpen or not self.grid_items:
            return
        self._epgToken += 1
        self._epgResult = None
        try: self._epgTimer.start(50, True)
        except Exception: pass

    @staticmethod
    def _decodeWindowsEpg(value):
        """Show UTF-8 for Xtream base64 EPG, with safe plain-text fallback."""
        if isinstance(value, bytes):
            value = value.decode("utf-8", "replace")
        raw = str(value or "").strip()
        if not raw:
            return ""
        try:
            import base64
            import re as _epg_re
            condensed = "".join(raw.split())
            if (len(condensed) >= 8 and len(condensed) % 4 != 1 and
                    _epg_re.match(r"^[A-Za-z0-9+/]+={0,2}$", condensed)):
                candidate = base64.b64decode(condensed + "=" * (-len(condensed) % 4)).decode("utf-8", "strict").strip()
                if candidate and any(c.isalnum() for c in candidate) and all(c.isprintable() or c in "\n\t" for c in candidate):
                    raw = candidate
        except Exception:
            pass
        try:
            from html import unescape
            raw = unescape(raw)
        except Exception:
            pass
        return " ".join(raw.split())

    def _windowsTimeline(self, event):
        """Track EPG progress; unknown or invalid times never produce fake progress."""
        try:
            start = int(event.get("start_timestamp") or 0)
            stop = int(event.get("stop_timestamp") or 0)
            if not stop:
                stop = start + int(event.get("duration") or 0)
            if not start or stop <= start:
                self["epgTimelineFill"].hide()
                self["epgTimelineTrack"].hide()
                return ""
            now = int(time.time())
            elapsed = max(0, min(now - start, stop - start))
            pct = max(0, min(100, round(100 * float(elapsed) / (stop - start))))
            # Resizing the preloaded pixmap is much cheaper than creating new PNGs.
            self["epgTimelineTrack"].show()
            self["epgTimelineFill"].instance.resize(eSize(sx(max(1, round(679*pct/100))), sy(8)))
            if pct:
                self["epgTimelineFill"].show()
            else:
                self["epgTimelineFill"].hide()
            return "%s - %s  |  %d%%" % (
                time.strftime("%H:%M", time.localtime(start)),
                time.strftime("%H:%M", time.localtime(stop)),pct)
        except Exception:
            try:
                self["epgTimelineTrack"].hide()
                self["epgTimelineFill"].hide()
            except Exception: pass
            return ""

    @staticmethod
    def _windowsBadgeText(value):
        if isinstance(value, (list, tuple, set)):
            value = ", ".join(str(v) for v in value if v)
        elif isinstance(value, dict):
            value = str(value.get("name") or value.get("title") or "")
        return str(value or "").strip()

    def _windowsShowEpgBadges(self, event):
        try:
            self["epgBadgeLive"].setText("LIVE")
            self["epgBadgeLive"].show()
            genre = self._windowsBadgeText(event.get("genre") or event.get("genres") or
                                          event.get("category") or event.get("category_name"))
            rating = self._windowsBadgeText(event.get("rating") or event.get("parental_rating") or
                                           event.get("age_rating") or event.get("classification"))
            if genre:
                self["epgBadgeGenre"].setText(genre[:18])
                self["epgBadgeGenre"].show()
            else:
                self["epgBadgeGenre"].hide()
            if rating:
                self["epgBadgeDetail"].setText(rating[:12])
                self["epgBadgeDetail"].show()
            else:
                self["epgBadgeDetail"].hide()
        except Exception: pass

    def _windowsTryCachedFocusedPicon(self, item):
        if not isinstance(item, dict) or self._closed:
            return
        try:
            from .estalker_picon import cached_picon_path
            url = self._piconUrl(item)
            path = cached_picon_path(url, (240, 100)) if url else ""
            if path and os.path.isfile(path):
                self._windowsShowFocusedPicon(path, self._posterToken)
        except Exception: pass

    @staticmethod
    def _windowsInfoPiconPath(path):
        """Letterbox a channel logo in the info panel instead of stretching it."""
        if not path or not os.path.isfile(path):
            return path
        try:
            import hashlib
            from PIL import Image, ImageOps
            stat = os.stat(path)
            digest = hashlib.sha1(("%s|%s|%s|info180x135-v2" %
                (path, stat.st_size, int(stat.st_mtime))).encode("utf-8")).hexdigest()[:18]
            target = os.path.join(os.path.dirname(path), "windows_infol_logo_%s.png" % digest)
            if os.path.isfile(target) and os.path.getsize(target) > 100:
                return target
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
            with Image.open(path) as source:
                logo = ImageOps.contain(source.convert("RGBA"), (172, 110), method=resample)
                canvas = Image.new("RGBA", (180, 135), (0, 0, 0, 0))
                canvas.alpha_composite(logo, ((180-logo.width)//2, (135-logo.height)//2))
                tmp = target + ".new"
                try:
                    canvas.save(tmp, "PNG", optimize=True)
                    os.replace(tmp, target)
                finally:
                    if os.path.isfile(tmp): os.unlink(tmp)
            return target
        except Exception:
            return path

    def _windowsShowFocusedPicon(self, path, token):
        """Show a centred channel logo only until a genuine programme poster arrives."""
        if (getattr(self, "_closed", True) or
                token != getattr(self, "_posterToken", None) or
                getattr(self, "_posterDisplayedToken", None) == token or
                not path or not os.path.isfile(path)):
            return
        try:
            loader = ePicLoad()
            self._programmePiconLoader = loader
            def ready(_info=None, expected=token, ref=loader):
                # A delayed ePicLoad callback can arrive after close or while
                # the screen is still initializing on some Enigma2 builds.
                if (getattr(self, "_closed", True) or
                        expected != getattr(self, "_posterToken", None) or
                        getattr(self, "_posterDisplayedToken", None) == expected or
                        getattr(self, "_programmePiconLoader", None) is not ref):
                    return
                try:
                    pix = ref.getData()
                    if pix is not None and self["programmePicon"].instance:
                        self["programmePicon"].instance.setPixmap(pix)
                        self["programmePicon"].show()
                except Exception: pass
            connect_picture_data(loader, ready, self, oneshot=True)
            loader.setPara((180, 135, 1, 1, False, 1, "#00000000"))
            # Cache-first thumbnail path; PIL work happens on a worker, not
            # while moving the remote cursor through the 2x5 channel grid.
            from .picon_render_cache import request_windows_picon
            def decoded_thumb(converted, expected=token, ref=loader):
                if (converted and not getattr(self, "_closed", True) and
                        expected == getattr(self, "_posterToken", None) and
                        getattr(self, "_programmePiconLoader", None) is ref and
                        getattr(self, "_posterDisplayedToken", None) != expected):
                    try: ref.startDecode(converted)
                    except Exception: pass
            already = request_windows_picon(path, 'info', decoded_thumb)
            if already:
                decoded_thumb(already)
        except Exception: pass

    def _showSelectedEpg(self, now, nxt):
        title = self._decodeWindowsEpg(now.get("title") or now.get("name") or now.get("programme"))
        # Same behaviour as standard Live: once the highlighted channel's
        # guide is available, its visible grid card immediately shows NOW.
        if title and 0 <= self.focusIndex < len(self.grid_items):
            try:
                slot = self.focusIndex % self.PAGE_SIZE
                row = self.grid_items[self.focusIndex] or {}
                name = str(row.get("name") or row.get("title") or "Channel").strip()
                label = self["wName%d" % slot]
                old_text = label.getText() or ""
                star = "★  " if old_text.startswith("★") else ""
                label.setText(star + name[:24] + "\n▶ " + title[:29])
            except Exception:
                pass
        self["epgNow"].setText(title[:74] if title else "No EPG")
        try:
            begin = int(now.get("start_timestamp") or 0)
            duration = int(now.get("duration") or 0)
            epg_time = self.parentLive._formatEpgTime(begin, duration) if begin else ""
        except Exception:
            epg_time = ""
        if not title:
            try: self["epgTimelineTrack"].hide(); self["epgTimelineFill"].hide()
            except Exception: pass
        timed = self._windowsTimeline(now) if title else ""
        self["epgTime"].setText(timed or epg_time or self._decodeWindowsEpg(now.get("t_time") or "")[:55])
        if title:
            self._windowsShowEpgBadges(now)
        else:
            for badge in ("epgBadgeLive", "epgBadgeGenre", "epgBadgeDetail"):
                self[badge].hide()
        next_name = self._decodeWindowsEpg(nxt.get("title") or nxt.get("name") or nxt.get("programme"))
        self["epgNext"].setText(("NEXT  •  " + next_name[:80]) if next_name else "")
        description = self._decodeWindowsEpg(now.get("description") or now.get("descr") or now.get("desc") or now.get("plot"))
        self["epgDescription"].setText(description[:145])
        # Prefer explicit artwork from the selected programme (when the
        # provider supplies it); otherwise reuse the shared live cache and
        # finally resolve the same programme title through TMDb.
        # Never search by channel name -- that would display unrelated art.
        if title:
            def remote_artwork(*keys):
                for key in keys:
                    raw = str(now.get(key) or "").strip().replace("\\/", "/")
                    if raw.startswith(("https://", "http://")):
                        return raw
                return ""
            poster = remote_artwork("poster", "poster_url", "poster_path", "cover", "cover_url")
            back = remote_artwork("backdrop", "backdrop_url", "backdrop_path", "fanart", "background")
            if poster:
                self._windowsPosterUrl(poster, self._posterToken)
                # Broken server art should still fall through to TMDb.
                self._posterFallbackTitle = title
                try: self._posterFallbackTimer.start(2600, True)
                except Exception: pass
            else:
                self._showSelectedPoster(title)
            if back:
                self._displayWindowsBackdropUrl(back, self._epgBackdropToken)
            else:
                self._showWindowsBackdrop(title)

    def _showWindowsBackdrop(self, title):
        """Keep only the newest EPG artwork request; never lose it behind a stale worker."""
        token = self._epgBackdropToken
        cleaned = self.parentLive._cleanLiveProgrammeTitle(title)
        key = _live_poster_key(cleaned)
        if not key or self._closed:
            return
        # A completed earlier lookup is reused without an extra TMDb request.
        if key in self._epgBackdropUrls:
            self._displayWindowsBackdropUrl(self._epgBackdropUrls[key], token)
            return
        if time.time() < self._epgBackdropMisses.get(key, 0):
            return
        self._epgBackdropPending = (token, key, cleaned)
        if not self._epgBackdropSearchBusy:
            self._startWindowsBackdropSearch()
        else:
            self._epgBackdropPoll.start(250, True)

    def _startWindowsBackdropSearch(self):
        pending = self._epgBackdropPending
        if not pending or self._closed or self._epgBackdropSearchBusy:
            return
        self._epgBackdropPending = None
        token, key, title = pending
        self._epgBackdropSearchBusy = True
        def worker():
            url, poster = "", ""
            try:
                client = TMDbClient()
                data = client.search_artwork(title, "vod") or {}
                if not data.get("backdrop_path") and not data.get("poster_path"):
                    data = client.search_artwork(title, "series") or {}
                path = str(data.get("backdrop_path") or "")
                if path:
                    url = backdrop_url(path) if path.startswith("/") else path
                poster_path = str(data.get("poster_path") or "")
                if poster_path:
                    poster = ((IMAGE_BASE + "w342" + poster_path) if poster_path.startswith("/") else poster_path)
            except Exception:
                pass
            self._epgBackdropResult = (token, key, url, poster)
        t = threading.Thread(target=worker, name="TiviMateWindowsEpgBackdrop")
        t.daemon = True
        t.start()
        self._epgBackdropPoll.start(250, True)

    def _pollWindowsBackdrop(self):
        if self._closed:
            return
        result = self._epgBackdropResult
        if result is not None:
            self._epgBackdropResult = None
            self._epgBackdropSearchBusy = False
            token, key, url, poster = result
            if url:
                if len(self._epgBackdropUrls) >= 100:
                    self._epgBackdropUrls.clear()
                self._epgBackdropUrls[key] = url
            else:
                self._epgBackdropMisses[key] = time.time() + 180
                if len(self._epgBackdropMisses) > 100:
                    for stale in sorted(self._epgBackdropMisses, key=self._epgBackdropMisses.get)[:25]:
                        self._epgBackdropMisses.pop(stale, None)
            if poster:
                try: _save_live_poster_url(key, poster)
                except Exception: pass
                if token == self._epgBackdropToken and self._posterDisplayedToken != self._posterToken:
                    self._windowsPosterUrl(poster, self._posterToken)
            if token == self._epgBackdropToken and url:
                self._displayWindowsBackdropUrl(url, token)
            if self._epgBackdropPending:
                self._startWindowsBackdropSearch()
        if self._epgBackdropSearchBusy:
            self._epgBackdropPoll.start(250, True)

    def _displayWindowsBackdropUrl(self, url, token):
        if not url or self._closed or token != self._epgBackdropToken:
            return
        cached = cached_artwork(url, "backdrops")
        if cached and os.path.isfile(cached):
            self._paintWindowsBackdrop(cached, token)
        else:
            request_artwork(url, "backdrops", lambda path: self._paintWindowsBackdrop(path, token), priority=115)

    @staticmethod
    def _windowsFullBackdrop(path):
        """Fill the whole information panel, without side bands or stretching."""
        if not path or not os.path.isfile(path):
            return path
        try:
            import hashlib
            from PIL import Image, ImageOps
            st = os.stat(path)
            digest = hashlib.sha1(("%s|%d|%d|974x341-v2" %
                (path, st.st_size, int(st.st_mtime))).encode("utf-8")).hexdigest()[:18]
            output = os.path.join(os.path.dirname(path), "windows_back_%s.jpg" % digest)
            if os.path.isfile(output) and os.path.getsize(output) > 1024:
                return output
            filt = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
            with Image.open(path) as im:
                image = ImageOps.fit(im.convert("RGB"), (974, 341), method=filt)
                stage = output + ".new"
                try:
                    image.save(stage, "JPEG", quality=82)
                    os.replace(stage, output)
                    # Derivatives are optional; cap their disk footprint,
                    # including receivers running with internal flash only.
                    try:
                        directory = os.path.dirname(output)
                        entries = [os.path.join(directory, name) for name in os.listdir(directory)
                                   if name.startswith("windows_back_") and name.endswith(".jpg")]
                        if len(entries) > 75:
                            entries.sort(key=lambda name: os.path.getmtime(name), reverse=True)
                            for stale in entries[65:]:
                                try: os.unlink(stale)
                                except Exception: pass
                    except Exception:
                        pass
                finally:
                    if os.path.isfile(stage):
                        os.remove(stage)
            return output
        except Exception:
            return path

    def _paintWindowsBackdrop(self, path, token):
        if (self._closed or token != self._epgBackdropToken or
                not path or not os.path.isfile(path)):
            return
        self._backdropPreparePending = (path, token)
        self._startPrepareBackdrop()

    def _startPrepareBackdrop(self):
        if self._closed or self._backdropPrepareBusy or not self._backdropPreparePending:
            return
        path, token = self._backdropPreparePending
        self._backdropPreparePending = None
        self._backdropPrepareBusy = True
        def worker():
            result = self._windowsFullBackdrop(path)
            if not self._closed:
                self._backdropPrepareResult = (result, token)
        threading.Thread(target=worker, name="TiviMateWindowsBackdropFit", daemon=True).start()
        try: self._backdropPrepareTimer.start(180, True)
        except Exception: pass

    def _pollPreparedBackdrop(self):
        if self._closed:
            return
        result = self._backdropPrepareResult
        if result is not None:
            self._backdropPrepareResult = None
            self._backdropPrepareBusy = False
            path, token = result
            if token == self._epgBackdropToken and path and os.path.isfile(path):
                self._decodePreparedBackdrop(path, token)
            if self._backdropPreparePending:
                self._startPrepareBackdrop()
        if self._backdropPrepareBusy:
            try: self._backdropPrepareTimer.start(180, True)
            except Exception: pass

    def _decodePreparedBackdrop(self, path, token):
        try:
            loader = ePicLoad()
            self._epgBackdropLoader = loader
            def ready(_info=None, ref=loader, expected=token):
                if (getattr(self, '_closed', True) or
                        expected != getattr(self, '_epgBackdropToken', None) or
                        getattr(self, '_epgBackdropLoader', None) is not ref):
                    return
                try:
                    data = ref.getData()
                    if data is not None and self["epgBackdrop"].instance:
                        self["epgBackdrop"].instance.setPixmap(data)
                        self["epgBackdrop"].show()
                except Exception:
                    pass
            connect_picture_data(loader, ready, self, oneshot=True)
            loader.setPara((974, 341, 1, 1, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    @staticmethod
    def _windowsCoverPosterPath(path):
        """Fit artwork to the actual poster recess without stretching faces.

        A cached center-cropped derivative preserves aspect ratio and is reused
        on repeated visits. The original shared poster stays unchanged, so
        Classic/Genre/standard Live keep using their own artwork sizes. This
        helper is optional: receivers without Pillow keep the old decoder.
        """
        if not path or not os.path.isfile(path):
            return path
        try:
            import hashlib
            from PIL import Image, ImageOps
            stat = os.stat(path)
            key = "%s|%d|%d|windows-cover-200x324-v5" % (
                path, stat.st_size, int(stat.st_mtime))
            digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:20]
            target = os.path.join(os.path.dirname(path), "windows_cover_%s.jpg" % digest)
            if os.path.isfile(target) and os.path.getsize(target) > 512:
                return target
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
            with Image.open(path) as source:
                # EXIF portrait photos must be rotated before the center crop.
                try:
                    photo = ImageOps.exif_transpose(source)
                except Exception:
                    photo = source
                photo = ImageOps.fit(photo.convert("RGB"), (200, 324),
                                     method=resample, centering=(0.5, 0.5))
                stage = target + ".new"
                try:
                    photo.save(stage, "JPEG", quality=88, optimize=True)
                    os.replace(stage, target)
                finally:
                    try:
                        if os.path.isfile(stage): os.remove(stage)
                    except Exception:
                        pass
            return target
        except Exception:
            return path

    def _paintCachedWindowsPicon(self, slot, path, generation):
        """Render cached Windows logos without PIL work on the Enigma2 GUI."""
        if (getattr(self, "_closed", True) or
                generation != getattr(self, "_requestGeneration", None) or not path):
            return
        if slot == getattr(self, '_selectedTilePosterSlot', None):
            return
        from .picon_render_cache import request_windows_picon
        def ready(converted, s=slot, expected=generation):
            if (getattr(self, "_closed", True) or
                    expected != getattr(self, "_requestGeneration", None) or
                    s == getattr(self, '_selectedTilePosterSlot', None) or not converted):
                return
            try:
                target = self["wIcon%d" % s]
                if target.instance:
                    target.instance.setPixmapFromFile(converted)
                    target.show()
            except Exception:
                pass
        cached = request_windows_picon(path, 'tile', ready)
        if cached:
            ready(cached)

    @staticmethod
    def _windowsCardPiconPath(path):
        """Place wide PICON artwork in a portrait-sized tile without stretching."""
        if not path or not os.path.isfile(path):
            return path
        try:
            import hashlib
            from PIL import Image, ImageOps
            stat = os.stat(path)
            key = "%s|%d|%d|windows-logo-126x160-v2" % (
                path, stat.st_size, int(stat.st_mtime))
            digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:18]
            target = os.path.join(os.path.dirname(path), "windows_tilelogo_%s.png" % digest)
            if os.path.isfile(target) and os.path.getsize(target) > 100:
                return target
            resampling = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
            with Image.open(path) as src:
                im = ImageOps.contain(src.convert("RGBA"), (118, 84), method=resampling)
                canvas = Image.new("RGBA", (126, 160), (0, 0, 0, 0))
                canvas.alpha_composite(im, ((126-im.width)//2, (160-im.height)//2))
                temporary = target + ".new"
                try:
                    canvas.save(temporary, "PNG", optimize=True)
                    os.replace(temporary, target)
                finally:
                    if os.path.isfile(temporary): os.unlink(temporary)
            return target
        except Exception:
            return path

    @staticmethod
    def _windowsGridPosterPath(path):
        if not path or not os.path.isfile(path):
            return path
        try:
            import hashlib
            from PIL import Image, ImageOps
            stat = os.stat(path)
            key = "%s|%d|%d|windows-grid-126x160-v3" % (path, stat.st_size, int(stat.st_mtime))
            digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:20]
            target = os.path.join(os.path.dirname(path), "windows_grid_%s.png" % digest)
            if os.path.isfile(target) and os.path.getsize(target) > 512:
                return target
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
            with Image.open(path) as source:
                try:
                    photo = ImageOps.exif_transpose(source)
                except Exception:
                    photo = source
                photo = photo.convert("RGB")
                poster = ImageOps.fit(photo, (112, 146), method=resample, centering=(0.5, 0.5))
                canvas = Image.new("RGBA", (126, 160), (0, 0, 0, 0))
                canvas.paste(poster.convert("RGBA"), ((126 - 112) // 2, (160 - 146) // 2))
                stage = target + ".new"
                try:
                    canvas.save(stage, "PNG", optimize=True)
                    os.replace(stage, target)
                finally:
                    try:
                        if os.path.isfile(stage): os.remove(stage)
                    except Exception:
                        pass
            return target
        except Exception:
            return path

    def _paintSelectedTilePoster(self, path, token):
        if (getattr(self, '_closed', True) or
                token != getattr(self, '_posterToken', None) or
                not path or not os.path.isfile(path)):
            return
        if not self.grid_items or not (0 <= self.focusIndex < len(self.grid_items)):
            return
        slot = self.focusIndex % self.PAGE_SIZE
        if slot < 0 or slot >= self.PAGE_SIZE:
            return
        try:
            # Ultra's bounded artwork workers prepare the poster off the GUI
            # thread. PIL resizing on keypress used to stall bouquet changes.
            from .picon_render_cache import request_windows_grid_poster
            def prepared(cover_path, expected=token, s=slot):
                if (getattr(self, '_closed', True) or
                        expected != getattr(self, '_posterToken', None) or
                        s != self.focusIndex % self.PAGE_SIZE or
                        not cover_path or not os.path.isfile(cover_path)):
                    return
                try:
                    loader = ePicLoad()
                    self._gridPosterLoaders[s] = loader
                    def paint(_info=None, ref=loader, selected=s, requested=expected):
                        if (getattr(self, '_closed', True) or
                                requested != getattr(self, '_posterToken', None) or
                                selected != self.focusIndex % self.PAGE_SIZE or
                                self._gridPosterLoaders.get(selected) is not ref):
                            return
                        try:
                            data = ref.getData()
                            if data is not None and self["wIcon%d" % selected].instance:
                                self._selectedTilePosterSlot = selected
                                self["wIcon%d" % selected].instance.setPixmap(data)
                                self["wIcon%d" % selected].show()
                        except Exception:
                            pass
                    connect_picture_data(loader, paint, self, oneshot=True)
                    loader.setPara((126, 160, 1, 1, False, 1, "#00000000"))
                    loader.startDecode(cover_path)
                except Exception:
                    pass
            cached_path = request_windows_grid_poster(path, prepared)
            if cached_path:
                prepared(cached_path)
        except Exception:
            pass

    def _restoreTilePicon(self, slot):
        try:
            slot = int(slot)
        except Exception:
            return
        if slot < 0 or slot >= self.PAGE_SIZE:
            return
        absolute = self.page * self.PAGE_SIZE + slot
        if absolute < 0 or absolute >= len(self.grid_items):
            return
        item = self.grid_items[absolute] or {}
        target = self["wIcon%d" % slot]
        # Keep the old pixmap until the cached channel logo is ready. Clearing
        # the tile before the asynchronous Ultra thumbnail callback causes the
        # conspicuous empty rectangle seen when leaving a programme poster.
        url = self._piconUrl(item)
        if not url:
            try:
                blank = os.path.join(PLUGIN_PATH, "skins", "common", "te2_fallback.png")
                if os.path.isfile(blank) and target.instance:
                    target.instance.setPixmapFromFile(blank)
            except Exception:
                pass
            return
        try:
            from .estalker_picon import cached_picon_path
            stored = cached_picon_path(url, (240, 100))
        except Exception:
            stored = ''
        if stored and os.path.isfile(stored):
            try:
                if target.instance:
                    self._paintCachedWindowsPicon(slot, stored, self._requestGeneration)
                return
            except Exception:
                pass
        def active():
            return self._requestGeneration if not self._closed else -1
        def display(path, slot=slot, generation=self._requestGeneration):
            if self._closed or generation != self._requestGeneration or not path:
                return
            if slot == getattr(self, '_selectedTilePosterSlot', None):
                return
            try:
                target = self["wIcon%d" % slot]
                if target.instance:
                    self._paintCachedWindowsPicon(slot, path, generation)
            except Exception:
                pass
        try:
            direct_picon(url, (240, 100), self._requestGeneration, active, display, prefix="xst_live_picon_")
        except Exception:
            pass

    def _paintWindowsPoster(self, path, token):
        if (getattr(self, '_closed', True) or
                token != getattr(self, '_posterToken', None) or
                not path or not os.path.isfile(path)):
            return
        try:
            cover_path = self._windowsCoverPosterPath(path)
            loader = ePicLoad()
            self._programmeLoader = loader
            def paint(_info=None, expected=token, ref=loader, original=path):
                if (getattr(self, '_closed', True) or
                        expected != getattr(self, '_posterToken', None) or
                        getattr(self, '_programmeLoader', None) is not ref):
                    return
                try:
                    data = ref.getData()
                    if data is not None and self["programmePoster"].instance:
                        self["programmePoster"].instance.setPixmap(data)
                        self["programmePoster"].show()
                        self._posterDisplayedToken = expected
                        try: self._posterFallbackTimer.stop()
                        except Exception: pass
                        self._paintSelectedTilePoster(original, expected)
                except Exception:
                    pass
            connect_picture_data(loader, paint, self, oneshot=True)
            loader.setPara((200, 324, 1, 1, False, 1, "#00000000"))
            loader.startDecode(cover_path)
        except Exception:
            pass

    def _windowsPosterUrl(self, url, token):
        if not url or token != self._posterToken or self._closed:
            return
        cached = cached_artwork(url, "posters")
        if cached and os.path.isfile(cached):
            self._paintWindowsPoster(cached, token)
        else:
            request_artwork(url, kind="posters", callback=lambda path: self._paintWindowsPoster(path, token), priority=200)

    def _showSelectedPoster(self, title):
        title = self.parentLive._cleanLiveProgrammeTitle(self._decodeWindowsEpg(title))
        if not title:
            return
        token = self._posterToken
        key = _live_poster_key(title)
        url = _load_live_poster_urls().get(key, "")
        if url:
            self._windowsPosterUrl(url, token)
        else:
            # Use the shared poster already displayed by ordinary Live, if present.
            # Do not launch a second TMDb search here: the backdrop lane is
            # retrieving both image types in a single identity-safe lookup.
            try:
                parent = self.parentLive
                path = str(getattr(parent, "livePosterPath", "") or "")
                if path and os.path.isfile(path) and str(getattr(parent, "_livePosterTitle", "")) == title:
                    self._paintWindowsPoster(path, token)
            except Exception:
                pass
        # Separate delayed fallback is needed when regular Live's poster toggle
        # is disabled, or its worker was cancelled by a preview/service change.
        self._posterFallbackTitle = title
        try: self._posterFallbackTimer.start(4400, True)
        except Exception: pass

    def _followParentLivePoster(self):
        if self._closed or not self._posterFollowTitle or self._posterDisplayedToken == self._posterToken:
            return
        try:
            parent = self.parentLive
            if str(getattr(parent, "_livePosterTitle", "")) == self._posterFollowTitle:
                path = str(getattr(parent, "livePosterPath", "") or "")
                if path and os.path.isfile(path):
                    self._paintWindowsPoster(path, self._posterToken)
                    return
            shared = _load_live_poster_urls().get(_live_poster_key(self._posterFollowTitle), "")
            if shared:
                self._windowsPosterUrl(shared, self._posterToken)
                return
        except Exception:
            pass
        self._posterFollowTries += 1
        if self._posterFollowTries < 24:
            try: self._posterFollow.start(380, True)
            except Exception: pass

    def _fallbackPoster(self):
        if (self._closed or self._posterDisplayedToken == self._posterToken or
                not getattr(self, "_posterFallbackTitle", "")):
            return
        if self._posterSearchBusy:
            # Old worker still running: retry when free, do not start a race.
            try: self._posterFallbackTimer.start(400, True)
            except Exception: pass
            return
        title = self._posterFallbackTitle
        key = _live_poster_key(title)
        if (self._epgBackdropSearchBusy and
                (getattr(self, '_epgBackdropPending', None) is None or
                 self._epgBackdropPending[1] == key)):
            try: self._posterFallbackTimer.start(650, True)
            except Exception: pass
            return
        if key in self._posterNegativeTitles:
            return
        shared = _load_live_poster_urls().get(key, "")
        if shared:
            self._windowsPosterUrl(shared, self._posterToken)
            return
        token = self._posterToken
        self._posterSearchBusy = True
        def worker():
            url = ""
            try:
                client = TMDbClient()
                data = client.search_artwork(title, "vod", required_key="poster_path") or {}
                if not data.get("poster_path"):
                    data = client.search_artwork(title, "series", required_key="poster_path") or {}
                path = str(data.get("poster_path") or "")
                if path:
                    url = (IMAGE_BASE + "w342" + path) if path.startswith("/") else path
            except Exception:
                pass
            self._posterSearchResult = (token, key, url)
        thread = threading.Thread(target=worker, name="TiviMateWindowsPoster")
        thread.daemon = True
        thread.start()
        try: self._posterSearchPoll.start(250, True)
        except Exception: pass

    def _pollFallbackPoster(self):
        if self._closed:
            return
        result = self._posterSearchResult
        if result is None:
            if self._posterSearchBusy:
                try: self._posterSearchPoll.start(250, True)
                except Exception: pass
            return
        self._posterSearchBusy = False
        self._posterSearchResult = None
        token, key, url = result
        if url:
            _save_live_poster_url(key, url)
            if token == self._posterToken and self._posterDisplayedToken != token:
                self._windowsPosterUrl(url, token)
        else:
            self._posterNegativeTitles.add(key)
            if len(self._posterNegativeTitles) > 200:
                self._posterNegativeTitles.clear()
        if token != self._posterToken and self._posterDisplayedToken != self._posterToken:
            try: self._posterFallbackTimer.start(250, True)
            except Exception: pass

    def _packageChoices(self):
        try: rows = list(self.parentLive["category"].list or [])
        except Exception: rows = []
        # Render Favorites with the same card/title convention as ordinary
        # packages. Keep the category ID and index intact for all navigation.
        choices = []
        for idx, row in enumerate(rows):
            if not isinstance(row, (tuple, list)) or len(row) < 2:
                continue
            name = tr("FAVORITES") if str(row[1]) == "__favorites__" else str(row[0])
            choices.append((name, idx))
        return choices

    def _redPackageAction(self):
        if self._packagesOpen:
            self._backAction()
        else:
            self._prevBouquet()

    def _chooseBouquet(self):
        """Show the circular package grid, never the old list overlay."""
        self._pendingFullscreenIdentity = None
        try: self._pendingFullscreenTimer.stop()
        except Exception: pass
        self._cancelFavoritePreviewLink()
        try: self.parentLive._cancelLiveZapResolve()
        except Exception: pass
        if self._bouquetIdPending is not None:
            self._cancelPendingBouquet()
        self._packageLoading = False
        self._packageRows = self._packageChoices()
        try:
            current = int(self.parentLive["category"].getSelectedIndex())
        except Exception:
            current = 0
        self._packageSelection = next((i for i, row in enumerate(self._packageRows)
                                       if row[1] == current), 0)
        self._packagesOpen = True
        try: self._windowsBadgeTimer.stop()
        except Exception: pass
        try:
            self._packageReturnFocus = int(self.focusIndex)
        except Exception:
            self._packageReturnFocus = 0
        try:
            self._packageReturnCategoryId = str(getattr(self.parentLive, '_loadedLiveCategoryKey', '') or '')
            if self._packageReturnCategoryId and self.grid_items:
                cursors = self.parentLive._liveChannelCursorByCategory
                cursors[self._packageReturnCategoryId] = (int(self.focusIndex),
                   str((self.grid_items[self.focusIndex] or {}).get('ch_id') or
                       (self.grid_items[self.focusIndex] or {}).get('stream_id') or
                       (self.grid_items[self.focusIndex] or {}).get('id') or ''))
                if len(cursors) > 32:
                    cursors.pop(next(iter(cursors)), None)
        except Exception:
            self._packageReturnCategoryId = ''
        self._hidePackageStrip()
        # Do not allow high-z EPG art to overlay the package chooser.
        for key in ("programmePoster", "programmePicon", "programmePosterFrame", "previewChannel"):
            try: self[key].hide()
            except Exception: pass
        try: self["footer"].hide()
        except Exception: pass
        try:
            self._epgTimer.stop()
            self._previewTimer.stop()
            self._initialPackageTimer.stop()
        except Exception:
            pass
        self["keyRed"].setText("Back")
        self._drawPackageOverlay()
        if not self._packageRows:
            self._initialPackageTries = 0
            self._initialPackageTimer.start(180, True)

    def _hidePackageOverlay(self):
        self["keyRed"].setText("Prev Package")
        self._packagesOpen = False
        self._packageLoading = False
        for key in ("previewChannel",):
            try: self[key].show()
            except Exception: pass
        try:
            self["programmePosterFrame"].hide()
        except Exception:
            pass
        try: self["footer"].show()
        except Exception: pass
        try:
            if self.grid_items:
                self.focusIndex = max(0, min(int(getattr(self, '_packageReturnFocus', self.focusIndex) or 0), len(self.grid_items) - 1))
                self.page = self.focusIndex // self.PAGE_SIZE
        except Exception:
            pass
        legacy = ["bouquetOverlay", "bouquetTitle", "bouquetCounter", "bouquetFocus", "bouquetHint"]
        legacy += ["bouquetRow%d" % i for i in range(10)] + ["bouquetIcon%d" % i for i in range(10)]
        circular = ["pkgBase", "pkgHero", "pkgTitle", "pkgCount", "pkgHint", "pkgFocus", "pkgFooter"]
        circular += ["pkgCircle%d" % i for i in range(self.PAGE_SIZE)]
        circular += ["pkgIcon%d" % i for i in range(self.PAGE_SIZE)]
        circular += ["pkgName%d" % i for i in range(self.PAGE_SIZE)]
        for name in legacy + circular:
            try: self[name].hide()
            except Exception: pass
        self._moveFocusFrame()
        self._drawPackageStrip()

    def _hidePackageStrip(self):
        try: self["stripFocus"].hide()
        except Exception: pass
        for i in range(5):
            for part in ("stripIcon", "stripName"):
                try: self["%s%d" % (part, i)].hide()
                except Exception: pass

    def _drawPackageStrip(self):
        self._hidePackageStrip()
        return
        if self._packagesOpen or self._closed:
            self._hidePackageStrip()
            return
        try:
            rows = self._packageChoices()
            category = self.parentLive["category"]
            current = int(category.getSelectedIndex())
            selected = next((i for i, row in enumerate(rows) if row[1] == current), 0)
            start = (selected // 5) * 5
        except Exception:
            rows, category, selected, start = [], None, 0, 0
        for i in range(5):
            icon = self["stripIcon%d" % i]
            label = self["stripName%d" % i]
            if start+i >= len(rows):
                try: icon.hide(); label.hide()
                except Exception: pass
                continue
            title, idx = rows[start+i]
            label.setText(str(title)[:22])
            try: label.show()
            except Exception: pass
            try:
                category_id = str(category.list[idx][1])
                if category_id == "__favorites__":
                    pix = category._liveKindIcons.get("favorites")
                elif category_id == "__recent_added__":
                    pix = category._liveKindIcons.get("recent")
                else:
                    visual_type, key = package_visual(title)
                    pix = (category._liveCountryIcons.get(key) if visual_type == "country"
                           else category._liveKindIcons.get(key))
                    if pix is None:
                        pix = category._liveKindIcons.get(package_kind(title))
                if pix is None:
                    pix = category._liveKindIcons.get("general")
                if pix is not None and icon.instance:
                    icon.instance.setPixmap(pix)
                    icon.show()
                else:
                    icon.hide()
            except Exception:
                try: icon.hide()
                except Exception: pass
        try:
            slot = selected % 5
            self["stripFocus"].instance.move(ePoint(sx(60+368*slot),sy(435)))
            self["stripFocus"].show()
        except Exception:
            pass

    def _drawPackageOverlay(self):
        if not self._packagesOpen or self._closed:
            return
        rows = self._packageRows
        total = len(rows)
        start = (self._packageSelection // self.PAGE_SIZE) * self.PAGE_SIZE
        pages = max(1, (total+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["pkgTitle"].setText("TiviMate  |  PACKAGES")
        self["pkgCount"].setText("Page %d / %d   •   %d Packages" % (start//self.PAGE_SIZE+1, pages, total))
        self["pkgHint"].setText("Opening package..." if self._packageLoading else
                                ("OK  Open package   •   CH+/-  Pages   •   RED  Back" if total else
                                 "Preparing package list..."))
        for name in ("pkgBase", "pkgHero", "pkgTitle", "pkgCount", "pkgHint"):
            try: self[name].show()
            except Exception: pass
        try:
            category = self.parentLive["category"]
        except Exception:
            category = None
        # A single bounded file read replaces ten JSON reads per repaint.
        try:
            with open(favorites_path("live_package_favorites.json"), "r") as handle:
                markers = json.load(handle) or {}
            self._windowsFavouritePackageKeys = set(markers)
        except Exception:
            self._windowsFavouritePackageKeys = set()
        for slot in range(self.PAGE_SIZE):
            circle = self["pkgCircle%d" % slot]
            icon = self["pkgIcon%d" % slot]
            label = self["pkgName%d" % slot]
            if start+slot >= total:
                for widget in (circle, icon, label):
                    try: widget.hide()
                    except Exception: pass
                continue
            title, idx = rows[start+slot]
            category_id = ""
            try:
                category_id = str(category.list[idx][1] or "")
            except Exception:
                pass
            is_fav_package = self._isWindowsPackageFavourite(category_id)
            mark = "★  " if is_fav_package else ""
            # More of a long provider/package name fits in two readable lines.
            # Leave the actual category label intact for server lookups.
            display_name = str(title).replace("\r", " ").replace("\n", " ").strip()
            label.setText((mark + display_name)[:42])
            try:
                label.setForegroundColor(gRGB(255, 211, 64) if is_fav_package else gRGB(242, 246, 252))
            except Exception:
                pass
            label.show()
            circle.show()
            pix = None
            try:
                category_id = str(category.list[idx][1])
                if category_id == "__favorites__":
                    pix = category._liveKindIcons.get("favorites")
                elif category_id == "__recent_added__":
                    pix = category._liveKindIcons.get("recent")
                else:
                    visual_type, key = package_visual(title)
                    pix = (category._liveCountryIcons.get(key) if visual_type == "country"
                           else category._liveKindIcons.get(key))
                    if pix is None:
                        pix = category._liveKindIcons.get(package_kind(title))
                if pix is None:
                    pix = category._liveKindIcons.get("general")
                # Standard Live category glyphs are physically 24x24 pixels.
                # Simply assigning them to a 48x48 widget does not upscale
                # gPixmap on Enigma2; this made every package icon tiny.
                # Decode one pre-sized local asset per visual type instead.
                image_name = "general.png"
                if category_id == "__favorites__":
                    image_name = "heart.png"
                elif category_id == "__recent_added__":
                    image_name = "recent.png"
                else:
                    visual_type, key = package_visual(title)
                    candidate = (("flag_%s.png" % key) if visual_type == "country"
                                 else (str(key) + ".png"))
                    if os.path.isfile(os.path.join(PLUGIN_PATH, "skins", "live", "package_icons_48", candidate)):
                        image_name = candidate
                    else:
                        fallback = str(package_kind(title) or "general") + ".png"
                        if os.path.isfile(os.path.join(PLUGIN_PATH, "skins", "live", "package_icons_48", fallback)):
                            image_name = fallback
                resized = self._packageIconPixmaps.get(image_name)
                if resized is None:
                    file_path = os.path.join(PLUGIN_PATH, "skins", "live", "package_icons_48", image_name)
                    resized = LoadPixmap(file_path) if os.path.isfile(file_path) else None
                    if resized is not None:
                        self._packageIconPixmaps[image_name] = resized
                if icon.instance and (resized is not None or pix is not None):
                    icon.instance.setPixmap(resized if resized is not None else pix)
                    icon.show()
                else:
                    icon.hide()
            except Exception:
                try: icon.hide()
                except Exception: pass
        if total:
            slot = self._packageSelection % self.PAGE_SIZE
            cx, cy = self.X0 + self.DX*(slot%self.COLS), self.Y0 + self.DY*(slot//self.COLS)
            try:
                self["pkgFocus"].instance.move(ePoint(sx(cx), sy(cy)))
                self["pkgFocus"].show()
            except Exception:
                pass
        else:
            self["pkgFocus"].hide()

    def _movePackageFocusOnly(self, previous, was_loading=False):
        """Ultra-style cursor-only navigation: do not repaint ten package tiles."""
        if (was_loading or self._packagesOpen is False or
                previous // self.PAGE_SIZE != self._packageSelection // self.PAGE_SIZE):
            self._drawPackageOverlay()
            return
        slot = self._packageSelection % self.PAGE_SIZE
        x = self.X0 + self.DX * (slot % self.COLS)
        y = self.Y0 + self.DY * (slot // self.COLS)
        try:
            self["pkgFocus"].instance.move(ePoint(sx(x), sy(y)))
            self["pkgFocus"].show()
        except Exception:
            self._drawPackageOverlay()

    def _movePackage(self, amount):
        if not self._packageRows:
            return
        previous = self._packageSelection
        target = max(0, min(len(self._packageRows)-1,
                         previous + int(amount)))
        if target == previous:
            return
        was_loading = bool(self._packageLoading)
        if was_loading:
            self._cancelPendingBouquet()
        self._packageSelection = target
        self._movePackageFocusOnly(previous, was_loading)

    def _movePackageArrow(self, dx, dy):
        if not self._packageRows:
            return
        index = self._packageSelection
        col = index % self.COLS
        if dx and not (0 <= col+dx < self.COLS):
            return
        target = index + int(dx) + int(dy)*self.COLS
        if 0 <= target < len(self._packageRows) and target != index:
            was_loading = bool(self._packageLoading)
            if was_loading:
                self._cancelPendingBouquet()
            self._packageSelection = target
            self._movePackageFocusOnly(index, was_loading)

    def _activatePackage(self):
        if not self._packageRows or self._packageLoading:
            return
        selected = int(self._packageRows[self._packageSelection][1])
        self._packageLoading = True
        self._drawPackageOverlay()
        self._toolbarIndex = None
        self._selectBouquetIndex(selected)

    def _prevBouquet(self): self._shiftBouquet(-1)
    def _nextBouquet(self): self._shiftBouquet(1)

    def _shiftBouquet(self, step):
        """Navigate the real Live categories; never infer category ID from slot.

        Category indexes can be sparse after source filtering. Also do not lock
        navigation while a previous network fetch is outstanding: selecting a
        new category supersedes the old request and starts a fresh deadline.
        """
        try:
            step = int(step)
            if not step:
                return
            if self._packagesOpen:
                if self._packageLoading:
                    # Pending provider request can be cancelled by navigating.
                    self._cancelPendingBouquet()
                self._movePackage(step)
                return
            rows = self._packageChoices()
            if not rows:
                self._chooseBouquet()
                return
            current = int(self.parentLive["category"].getSelectedIndex())
            pos = next((i for i, (_, original) in enumerate(rows)
                        if original == current), -1)
            if pos < 0:
                pos = 0 if step > 0 else len(rows)-1
            else:
                pos = (pos + step) % len(rows)
            self._selectBouquetIndex(rows[pos][1])
        except Exception:
            try: self["previewHint"].setText("Unable to change package")
            except Exception: pass

    def _cancelPendingBouquet(self):
        self._bouquetIdPending = None
        self._bouquetWaitUntil = 0.0
        self._packageLoading = False
        try: self._bouquetTimer.stop()
        except Exception: pass
        # Invalidate the parent's old worker response before changing category.
        try:
            parent = self.parentLive
            parent.categoryLoadToken += 1
            parent.categoryLoadResult = None
            parent.categoryLoadTimer.stop()
        except Exception:
            pass

    def _selectBouquetIndex(self, index):
        """Reuse the regular Live provider loader and bound its wait time."""
        if self._closed:
            return
        self._cancelPendingBouquet()
        self._previewOkIdentity = None
        self._previewRequestedIdentity = None
        self._favoritePreviewToken += 1
        self._favoritePreviewPending = None
        parent = self.parentLive
        current_loaded = str(getattr(parent, "_loadedLiveCategoryKey", "") or "")
        # Previous/Next Package bypasses the package chooser: remember the
        # currently selected channel here as well, before changing category.
        # Otherwise returning to that bouquet silently resets the cursor.
        if current_loaded and not self._packagesOpen and self.grid_items:
            try:
                current_index = max(0, min(int(self.focusIndex), len(self.grid_items) - 1))
                current_row = self.grid_items[current_index] or {}
                current_id = str(current_row.get('ch_id') or
                                 current_row.get('stream_id') or
                                 current_row.get('id') or '')
                cursors = parent._liveChannelCursorByCategory
                cursors[current_loaded] = (current_index, current_id)
                if len(cursors) > 32:
                    cursors.pop(next(iter(cursors)), None)
            except Exception:
                pass
        try:
            remembered_focus = int(getattr(self, '_packageReturnFocus', self.focusIndex) or 0)
        except Exception:
            remembered_focus = 0
        try:
            parent["category"].moveToIndex(int(index))
            requested_id = str(parent.selectedCategory() or "")
            if requested_id and requested_id == current_loaded and self.grid_items:
                self.focusIndex = max(0, min(remembered_focus, len(self.grid_items) - 1))
                self.page = self.focusIndex // self.PAGE_SIZE
                self._packageLoading = False
                self._hidePackageOverlay()
                self["previewHint"].setText("CHANNEL PREVIEW")
                self._render(fresh_bouquet=True)
                return
            # Restore the last selected channel PER bouquet; preserve identity
            # if the portal reordered the bouquet since the previous visit.
            if requested_id != current_loaded:
                self._packageReturnFocus = int(parent._liveChannelCursorByCategory.get(requested_id, (0, ''))[0])
            if not requested_id:
                self._packageLoading = False
                if self._packagesOpen:
                    self["pkgHint"].setText("Package unavailable  •  Select another")
                return
            self._bouquetIdPending = requested_id
            self._bouquetWaitUntil = time.monotonic() + 16.0
            self._packageLoading = True
            if self._packagesOpen:
                self._drawPackageOverlay()
            else:
                self["header"].setText("TiviMate  |  Switching package")
                self["previewHint"].setText("Opening package...")
            parent.loadSelectedCategory()
            self._checkBouquetReady()
        except Exception:
            self._cancelPendingBouquet()
            if self._packagesOpen:
                self["pkgHint"].setText("Unable to load package  •  Select another")
            else:
                self["previewHint"].setText("Unable to load package")

    def _checkBouquetReady(self):
        if self._closed or self._bouquetIdPending is None:
            return
        parent = self.parentLive
        # When a modal grid owns the foreground, the underlying parent's
        # result timer may be suspended by a receiver image. Drain a ready
        # provider result via the original Live finish handler on the UI thread.
        if getattr(parent, "categoryLoadResult", None) is not None:
            try: parent._finishCategoryLoad()
            except Exception: pass
        if str(getattr(parent, "_loadedLiveCategoryKey", "") or "") == self._bouquetIdPending:
            self.grid_items = list(parent.mediaItemsCurrent or [])
            self._previewOkIdentity = None
            self._toolbarIndex = None
            try:
                remembered = int(getattr(self, '_packageReturnFocus', 0) or 0)
            except Exception:
                remembered = 0
            if self.grid_items:
                saved = parent._liveChannelCursorByCategory.get(self._bouquetIdPending, (remembered, ''))
                remembered = int(saved[0])
                wanted = str(saved[1] or '')
                if wanted and (remembered >= len(self.grid_items) or
                        str((self.grid_items[remembered] or {}).get('ch_id') or
                            (self.grid_items[remembered] or {}).get('stream_id') or
                            (self.grid_items[remembered] or {}).get('id') or '') != wanted):
                    remembered = next((i for i, candidate in enumerate(self.grid_items)
                        if str((candidate or {}).get('ch_id') or (candidate or {}).get('stream_id') or
                               (candidate or {}).get('id') or '') == wanted), remembered)
                self.focusIndex = max(0, min(remembered, len(self.grid_items) - 1))
                self._packageReturnFocus = self.focusIndex
                self.page = self.focusIndex // self.PAGE_SIZE
            else:
                self.focusIndex = 0
                self.page = 0
            self._cancelPendingBouquet()
            self._hidePackageOverlay()
            self["previewHint"].setText("CHANNEL PREVIEW")
            self._render(fresh_bouquet=True)
            return
        if time.monotonic() >= self._bouquetWaitUntil:
            self._cancelPendingBouquet()
            # Return to package tiles instead of showing an infinite Loading.
            if self._packagesOpen:
                self._drawPackageOverlay()
                self["pkgHint"].setText("Package timed out  •  Try another")
            else:
                self["header"].setText("LIVE TV  /  WINDOWS")
                self["previewHint"].setText("Package timed out  •  RED / BLUE to retry")
            return
        try: self._bouquetTimer.start(300, True)
        except Exception: pass

    def _syncParent(self):
        parent = self.parentLive
        parent.focus = "items"
        # Windows already stores an absolute bouquet index in focusIndex;
        # moving it to the normal Live list must preserve that exact channel.
        idx = max(0, min(int(self.focusIndex), len(self.grid_items)-1)) if self.grid_items else 0
        source_type = parent.source.get("type")
        try:
            if source_type == "xtream":
                batch = max(1,int(getattr(parent,"xtreamLiveBatchSize",15) or 15))
                loaded = int(getattr(parent,"xtreamLiveLoadedCount",0) or 0)
                if idx >= loaded:
                    parent.xtreamLiveLoadedCount = min(len(self.grid_items),((idx//batch)+1)*batch)
                    parent._renderXtreamLiveBatch(idx,ensure_next=False)
                else:
                    parent["list"].moveToIndex(idx)
            elif source_type == "m3u":
                loaded = int(getattr(parent,"m3uLiveLoadedCount",0) or 0)
                if idx >= loaded:
                    parent.m3uLiveLoadedCount = min(len(self.grid_items),((idx//15)+1)*15)
                    parent._renderM3uLiveBatch(idx,ensure_next=False)
                else:
                    parent["list"].moveToIndex(idx)
            else:
                parent["list"].moveToIndex(idx)
            parent._livePreviewOkIdentity = None
        except Exception:
            pass

    def _selectedFullscreenIdentity(self):
        """Key a deferred fullscreen action to the exact provider and card."""
        try:
            row = self.grid_items[self.focusIndex]
            source = (row.get('_favorite_source') if isinstance(row.get('_favorite_source'), dict)
                      else self.parentLive.source)
            key = str(row.get('stream_id') or row.get('ch_id') or row.get('id') or
                      row.get('url') or row.get('cmd') or row.get('name') or '').strip()
            return (str(_source_identity(source)), key, int(self.focusIndex)) if key else None
        except Exception:
            return None

    def _pendingPreviewIsActive(self):
        """Use the real Enigma2 service ref, never only a matching channel ID."""
        if not self.grid_items or not (0 <= self.focusIndex < len(self.grid_items)):
            return False
        row = self.grid_items[self.focusIndex] or {}
        parent = self.parentLive
        favorite_source = row.get('_favorite_source') if isinstance(row.get('_favorite_source'), dict) else None
        try:
            if favorite_source:
                return bool(self._previewServiceRef and
                            _live_ref_is_active(self.session.nav, self._previewServiceRef))
            source = _bein_base_source(parent.source) if parent.source.get('_virtual_bein') else parent.source
            actual_row = getattr(parent, '_playingLiveItem', None) or {}
            def identity(item):
                return str(item.get('stream_id') or item.get('ch_id') or item.get('id') or
                           item.get('url') or item.get('cmd') or item.get('name') or '').strip()
            url = str(getattr(parent, '_playingLiveUrl', '') or '')
            current_source = _CURRENT_LIVE_CHANNEL.get('source')
            if not (url and identity(actual_row) == identity(row) and
                    current_source in (_source_identity(source), _source_identity(parent.source))):
                return False
            st = (_xtream_service_type(source, 'live') if source.get('type') == 'xtream'
                  else int(source.get('service_type', parent.channelSettings.get('service_type', 4097))))
            ref = live_reference(source, row, st, url, row.get('name') or row.get('title') or 'IPTV')
            # An accepted Enigma2 service for this exact provider/channel is
            # sufficient for entering full-screen. Decoder/video proof is used
            # for preview health, NOT to lock the user out of the Infobar.
            # Ultra's player adopts this same service without a second zap.
            return bool(_live_ref_is_active(self.session.nav, ref))
        except Exception:
            return False

    def _finishPendingFullscreen(self):
        """Adopt the one pending Ultra preview without blocking remote navigation.

        Only the selected channel may transition. If the portal failed or a
        timeout retired the task, show the failure and let the next deliberate
        OK retry; do not silently create a second link request.
        """
        identity = self._pendingFullscreenIdentity
        if (identity is None or self._closed or self._packagesOpen or
                identity != self._selectedFullscreenIdentity()):
            self._pendingFullscreenIdentity = None
            return
        row = self.grid_items[self.focusIndex] or {}
        favorite = isinstance(row.get('_favorite_source'), dict)
        parent = self.parentLive
        # A hidden parent screen's Enigma timer may not tick on every image.
        # Consume *completed* results on the active Windows UI thread, or let
        # the existing deadline handler retire a stuck MAG request.
        if favorite:
            if (self._favoritePreviewResult is not None or
                    (self._favoritePreviewDeadline and
                     time.monotonic() >= self._favoritePreviewDeadline)):
                try: self._finishFavoritePreview()
                except Exception: pass
        elif (getattr(parent, 'liveZapResolveResult', None) is not None or
              (getattr(parent, 'liveZapResolveDeadline', 0) and
               time.monotonic() >= parent.liveZapResolveDeadline)):
            try: parent._finishAsyncLiveZap()
            except Exception: pass
        try:
            if getattr(parent, '_livePreviewCheck', None) is not None:
                parent._pollLivePreviewCheck()
        except Exception:
            pass
        pending = ((bool(self._favoritePreviewPending) if favorite else
                    getattr(parent, 'liveZapResolveHandle', None) is not None) or
                   getattr(parent, '_livePreviewCheck', None) is not None)
        # The mini preview may already be playing while its optional decoder
        # confirmation is still running. Do not keep the Infobar locked behind
        # that probe when the exact selected service reference is active.
        self._pendingFullscreenIdentity = None
        # The user's earlier second OK still means Infobar, never retry. _ok
        # now handles failed/pending previews safely on the selected channel.
        self._ok()

    def _windowsSelectedChannelLocked(self, row, favorite_source=None):
        """PIN test for the focused grid row, independent of the hidden list."""
        source = favorite_source or self.parentLive.source
        if not isinstance(source, dict) or source.get("type") != "stalker":
            return False
        try:
            return _live_item_id(row) in _load_stalker_pin(source)["channels"]
        except Exception:
            # Preserve parental protection if PIN state cannot be read.
            return True

    def _ok(self):
        if self._packagesOpen:
            self._activatePackage()
            return
        if not self.grid_items:
            return
        parent = self.parentLive
        item = self.grid_items[self.focusIndex] or {}
        if item.get("_stalker_placeholder") or str(item.get("name") or "").startswith("####"):
            return
        if getattr(parent, "catchupPackageActive", False):
            self._syncParent()
            self.close("ok")
            return
        favorite_source = item.get("_favorite_source") if isinstance(item.get("_favorite_source"), dict) else None
        if (self._windowsSelectedChannelLocked(item, favorite_source) and
                time.time() >= getattr(parent, "stalkerPinUnlockedUntil", 0)):
            # PIN belongs to the hidden parent; synchronise only when needed.
            self._syncParent()
            self.close("pin")
            return
        source = favorite_source or (_bein_base_source(parent.source) if parent.source.get("_virtual_bein") else parent.source)
        # Every protocol's running preview belongs to this exact channel.
        # Opening fullscreen during a decoder probe must adopt its verified
        # stream rather than stopping it and issuing a second playService().
        # Stalker additionally avoids a duplicate portal create_link request.
        identity = self._selectedFullscreenIdentity()
        if identity is None:
            return
        # Reopening the *same* channel after Back is one OK. A different
        # channel keeps the explicit preview -> Infobar two-OK sequence.
        returned_active = parent._returnedLiveChannelIsActive(item, source)
        if self._previewRequestedIdentity != identity and not returned_active:
            # Browsing does not play. First OK explicitly starts this card's
            # mini preview, including mixed-source favorites, with no fullscreen.
            self._previewRequestedIdentity = identity
            self._autoPreviewFailedUntil.pop(identity, None)
            # An absent EPG is never a prerequisite to playback in Ultra.
            # Cancel only a QUEUED focused-card lookup, not the ten-card wave;
            # the latter continues in its independent bounded worker pool.
            try:
                self._epgTimer.stop()
                future = getattr(self, "_epgFuture", None)
                if future is not None and future.cancel():
                    self._epgActiveToken = None
                    self._epgBusy = False
                    self._epgResult = None
                    self._epgPoll.stop()
            except Exception:
                pass
            self._previewSelectedChannel()
            # If guide data is still missing, resume its optional lookup
            # after link/decoder startup, never ahead of explicit OK.
            try: self._epgTimer.start(350, True)
            except Exception: pass
            return
        # Second OK must show the Infobar even when the preview failed or is
        # still pending. The handoff below cancels the old preview token before
        # the full-screen player starts, preventing a late background retune.
        self._pendingFullscreenIdentity = None
        try: self._pendingFullscreenTimer.stop()
        except Exception: pass
        # Ultra enters the full-screen player without repainting the hidden
        # bouquet. Parent list selection will be restored by livePlayerClosed.
        parent.focus = "items"
        # Second OK adopts the already playing preview without new create_link
        # or playService calls. Stop any pending preview request so it cannot
        # retune behind the full-screen player.
        previous_preview_identity = self._previewOkIdentity
        previous_preview_ref = getattr(self, "_previewServiceRef", None)
        pending_link = (self._handoffFavoritePreviewLink(item, source)
                        if favorite_source and not returned_active else
                        parent._handoffLiveLink(item, source)
                        if not favorite_source and not returned_active else None)
        self._previewOkIdentity = None
        self._previewServiceRef = None
        try: self._previewWatchTimer.stop()
        except Exception: pass
        self._cancelFavoritePreviewLink()
        try:
            self.parentLive._cancelLiveZapResolve()
            if getattr(self.parentLive, "_livePreviewCheck", None) is not None:
                # Handoff is not a failed preview: never stop the service
                # which the full-screen player is about to adopt.
                self.parentLive._cancelLivePreviewCheck(stop_failed=False)
        except Exception: pass
        try: self._previewTimer.stop()
        except Exception: pass
        try: self._favoritePreviewTimer.stop()
        except Exception: pass
        # Windows already starts the selected channel in its PIG preview.
        # Opening full-screen must adopt that live service, not resolve and
        # play it again (which also drops external Live subtitles).
        reuse_current = False
        try:
            channel_id = str(item.get("stream_id") or item.get("ch_id") or
                             item.get("id") or item.get("url") or
                             item.get("cmd") or item.get("name") or "").strip()
            source_id = _source_identity(source)
            if channel_id:
                if favorite_source:
                    # Favorite-source previews are owned by this card's
                    # source-ref pair; don't require a late decoder callback.
                    reuse_current = bool(previous_preview_ref and
                        _live_ref_is_active(self.session.nav, previous_preview_ref))
                else:
                    playing_item = getattr(parent, "_playingLiveItem", None) or {}
                    playing_id = str(playing_item.get("stream_id") or playing_item.get("ch_id") or
                        playing_item.get("id") or playing_item.get("url") or
                        playing_item.get("cmd") or playing_item.get("name") or "").strip()
                    url = getattr(parent, "_playingLiveUrl", "")
                    if (url and playing_id == channel_id and
                            _CURRENT_LIVE_CHANNEL.get("source") == source_id):
                        service_type = (_xtream_service_type(source, "live")
                            if source.get("type") == "xtream" else int(source.get(
                                "service_type", parent.channelSettings.get("service_type", 4097))))
                        expected_ref = live_reference(source, item, service_type, url,
                            item.get("name") or item.get("title") or "IPTV")
                        reuse_current = bool(_live_ref_is_active(self.session.nav, expected_ref))
        except Exception:
            reuse_current = False
        # A returned fullscreen service can be adopted even though Windows
        # reset its preview flag while the previous Infobar was closing.
        reuse_current = bool(reuse_current or returned_active)
        if reuse_current and pending_link is not None:
            # A preview became active during handoff. Its old URL worker is
            # now redundant; don't leave an orphan behind the adopted stream.
            try: pending_link["handle"].cancel()
            except Exception: pass
            pending_link = None
        parent._playingLiveIndex = self.focusIndex
        parent.keepCurrentLiveService = True
        try: parent.zapTimer.stop()
        except Exception: pass
        self.session.openWithCallback(self._playerClosed, TiviMateLivePlayer,
            source, list(self.grid_items), self.focusIndex, reuse_current=reuse_current,
            pending_link=(None if reuse_current else pending_link))

    def _isWindowsPackageFavourite(self, category_id):
        category_id = str(category_id or "").strip()
        if not category_id or category_id.startswith("__"):
            return False
        # The overlay reads this file once per actual page change. Repeated
        # left/right/up/down presses must never perform JSON disk I/O.
        key = "%s|%s" % (favourite_source_id(self.parentLive.source), category_id)
        return key in getattr(self, "_windowsFavouritePackageKeys", set())

    def _openWindowsFavoritesMenu(self):
        """MENU: toggle the highlighted channel or Live package favorite."""
        if self._packagesOpen:
            choices = [("★ Add/Remove package from Favorites", "package"),
                       ("Cancel", "cancel")]
        else:
            choices = [("★ Add/Remove channel from Favorites", "channel"),
                       ("Cancel", "cancel")]
        self.session.openWithCallback(self._windowsFavoritesSelected,
                                      ChoiceBox, title="Favorites", list=choices)

    def _windowsFavoritesSelected(self, selected=None):
        if not selected:
            return
        try:
            action = selected[1]
        except Exception:
            return
        if action == "cancel":
            return
        parent = self.parentLive
        try:
            if action == "package":
                # The parent already owns the provider category list and the
                # existing package-expansion favorite implementation.
                parent.focus = "category"
                parent.toggleCurrentFavourite()
                self._drawPackageOverlay()
                return
            self._syncParent()
            parent.toggleCurrentFavourite()
            self._render()
        except Exception:
            pass

    def _recordWindowsPreviewFailure(self, focus_key):
        """Avoid retry storms on a dead preview without blocking manual OK."""
        if focus_key is None:
            return
        failures = self._autoPreviewFailedUntil
        failures[focus_key] = time.monotonic() + 15.0
        if len(failures) > 80:
            now = time.monotonic()
            for key, deadline in list(failures.items()):
                if deadline <= now:
                    failures.pop(key, None)
            # Keep memory bounded even if the user scrolls hundreds of dead
            # channels; oldest entries are only a performance hint.
            while len(failures) > 80:
                failures.pop(next(iter(failures)))

    def _finishFavoritePreview(self):
        if self._closed or self._packagesOpen:
            return
        result = self._favoritePreviewResult
        if result is None:
            if (self._favoritePreviewPending is not None and
                    self._favoritePreviewDeadline and
                    time.monotonic() >= self._favoritePreviewDeadline):
                failed_focus = self._selectedFullscreenIdentity()
                self._cancelFavoritePreviewLink()
                self._recordWindowsPreviewFailure(failed_focus)
                try: self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
                except Exception: pass
                return
            if self._favoritePreviewPending is not None:
                try: self._favoritePreviewTimer.start(160, True)
                except Exception: pass
            return
        self._favoritePreviewResult = None
        token, key, source, row, url = result
        if token != self._favoritePreviewToken or key != self._favoritePreviewPending:
            if self._favoritePreviewPending is not None:
                try: self._favoritePreviewTimer.start(160, True)
                except Exception: pass
            return
        self._favoritePreviewPending = None
        self._favoritePreviewDeadline = 0.0
        self._favoritePreviewHandle = None
        if not source or not url:
            self._recordWindowsPreviewFailure(self._selectedFullscreenIdentity())
            try: self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
            except Exception: pass
            return
        try:
            st = (_xtream_service_type(source, "live") if source.get("type") == "xtream"
                  else int(source.get("service_type", 4097)))
            ref = live_reference(source, row, st, url, row.get("name") or "IPTV")
            # Favorite previews use a separate path from _zapLiveItem.
            # The channel ID alone cannot safely identify an active service.
            if not _live_ref_is_active(self.session.nav, ref):
                result = self.session.nav.playService(ref)
                if not _live_play_accepted(result):
                    self._previewOkIdentity = None
                    self._previewServiceRef = None
                    self._recordWindowsPreviewFailure(self._selectedFullscreenIdentity())
                    self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
                    return
            self.parentLive.keepCurrentLiveService = True
            # Record only this accepted service reference. A later second OK
            # must be able to open the Infobar while video-proof is pending.
            self._previewServiceRef = ref.toString()
            # Windows mixed-favourite thumbnails also need real decoder
            # verification; never retain a dead ref as a successful preview.
            preview_token = self._favoritePreviewToken
            def verified(success, expected_key=key, expected_token=preview_token):
                if self._closed or self._packagesOpen or expected_token != self._favoritePreviewToken:
                    return
                if success:
                    self._autoPreviewFailedUntil.pop(self._selectedFullscreenIdentity(), None)
                    self._previewOkIdentity = expected_key
                    self._previewServiceRef = ref.toString()
                    self["previewHint"].setText("CHANNEL PREVIEW  •  OK: Full Screen")
                else:
                    self._recordWindowsPreviewFailure(self._selectedFullscreenIdentity())
                    self._previewOkIdentity = None
                    self._previewServiceRef = None
                    self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
            self.parentLive._beginLivePreviewCheck(ref, row, verified, source)
            try: self._previewWatchTimer.start(350, True)
            except Exception: pass
        except Exception:
            self._recordWindowsPreviewFailure(self._selectedFullscreenIdentity())
            try: self["previewHint"].setText("Preview unavailable  •  OK: Infobar")
            except Exception: pass

    def _playerClosed(self, result=None):
        self._previewOkIdentity = None
        self._previewRequestedIdentity = None
        try: self.parentLive.livePlayerClosed(result, keep_windows=True)
        except Exception: pass
        try:
            idx = int(getattr(self.parentLive, "_playingLiveIndex", self.focusIndex))
            self._selectIndex(idx)
        except Exception:
            pass
        # The full-screen player closes to the grid, not the hidden List.
        try: self.show()
        except Exception: pass

    def _exitToParentAction(self, name):
        if self._packagesOpen:
            # The initial package screen has no selected channel. Preserve
            # the Live category focus for filters/server changes and Back.
            self.parentLive.focus = "category"
        else:
            self._syncParent()
        # Send an action back to the session callback. Do not open a modal
        # ChoiceBox/MessageBox from parent before this screen fully closes.
        self.close(name)

    def _openWindowsLiveOptions(self):
        # The grid owns the modal stack. Never open a dialog on its hidden parent.
        parent = self.parentLive
        source_type = (parent.source or {}).get("type")
        choices = [("Favorites", "favorites"), ("Hide this package", "hide_category"),
                   ("Change parental PIN", "change_pin"),
                   (("Stalker player engines" if source_type == "stalker" else "Xtream player engines"), "player_engines")]
        if source_type not in ("xtream", "stalker"):
            choices = [("Favorites", "favorites")]
        self.session.openWithCallback(self._windowsLiveOptionSelected, ChoiceBox,
                                      title="LIVE OPTIONS", list=choices)

    def _windowsLiveOptionSelected(self, selected=None):
        if not selected or self._closed:
            return
        action = selected[1]
        if action == "favorites":
            self._exitToParentAction("openFavorites")
            return
        # Parent-only operations are dispatched after the grid closes, so
        # OpenATV never opens a modal on an inactive parent screen.
        self._exitToParentAction("liveTool:" + action)

    def _openBeinSports(self):
        # Keep the Windows screen alive and populate its own channel grid.
        self._beinGridPending = True
        self._beinGridStarted = time.monotonic()
        self._hidePackageOverlay()
        self.grid_items = []
        self.page = 0
        self.focusIndex = 0
        self._render()
        try:
            self.parentLive.openBeinSports()
            self._beinGridTimer.start(180, True)
        except Exception:
            self._beinGridPending = False

    def _refreshBeinGrid(self):
        if self._closed or not self._beinGridPending:
            return
        parent = self.parentLive
        if time.monotonic() - self._beinGridStarted > 22:
            self._beinGridPending = False
            return
        if str(getattr(parent, "activeCategoryName", "")) == "beIN SPORTS":
            self.grid_items = list(getattr(parent, "lastCategoryItems", []) or [])
            self._beinGridPending = False
            self.page = 0
            self.focusIndex = 0
            self._render()
            return
        if getattr(parent, "categoryLoadResult", None) is not None:
            try: parent._finishCategoryLoad()
            except Exception: pass
        self._beinGridTimer.start(250, True)

    def _openBouquetExportMenu(self):
        if self._closed:
            return
        selected = (self.grid_items[self.focusIndex]
                    if not self._packagesOpen and 0 <= self.focusIndex < len(self.grid_items)
                    else None)
        self.parentLive._openBouquetExportMenu(selected_item=selected,
                                                items=list(self.parentLive.mediaItemsCurrent or self.grid_items or []))

    def _openColorMenu(self):
        # Same four-choice LIVE MENU as Classic, with the grid still visible.
        if self._closed:
            return
        from .live_menu_screen import LiveMenuScreen
        self.session.openWithCallback(self._windowsMainMenuPicked, LiveMenuScreen)

    def _windowsMainMenuPicked(self, selected=None):
        if not selected:
            return
        action = selected[1] if isinstance(selected, (tuple, list)) else selected
        if action == "change_live_view":
            # Windows shares the exact same approved visual selector as Classic.
            self._openLegacyColorMenu()
        elif action == "favorites":
            self._openFavorites()
        elif action == "export_enigma2":
            self._openBouquetExportMenu()
        elif action == "options":
            self._openTools()

    def _openLegacyColorMenu(self):
        # MENU goes straight to the existing Live Appearance selector.
        # Keep the grid as the modal parent; a hidden Live list parent is unsafe.
        if self._closed:
            return
        current = self.parentLive.channelSettings.get("live_theme", "turquoise")
        self.session.openWithCallback(self._windowsStyleSelected, LiveStyleCircleScreen, current=current, mode="windows")

    def _windowsStyleSelected(self, selected=None):
        if not selected:
            return
        try:
            theme = selected[1]
            requested_mode = None
            if "|" in str(theme):
                requested_mode, theme = str(theme).split("|", 1)
        except Exception:
            return
        if requested_mode == "list":
            settings = self.parentLive.channelSettings
            settings["live_theme"] = theme
            settings["live_color"] = LIVE_STYLE_PALETTES.get(theme, {}).get("accent", "#008F95")
            _save_channel_settings(settings)
            self._switchToList()
            return
        if requested_mode == "windows":
            settings = self.parentLive.channelSettings
            settings["live_theme"] = theme
            settings["live_color"] = LIVE_STYLE_PALETTES.get(theme, {}).get("accent", "#008F95")
            _save_channel_settings(settings)
            self.close("reloadWindows")
            return
        if theme == "list":
            self._switchToList()
            return
        if theme == "windows":
            return
        if theme not in LIVE_STYLE_PALETTES:
            return
        settings = self.parentLive.channelSettings
        settings["live_theme"] = theme
        settings["live_color"] = LIVE_STYLE_PALETTES[theme]["accent"]
        _save_channel_settings(settings)
        # Recreate the Grid after the ChoiceBox closes so the new background
        # palette is visible immediately while preserving the selected view.
        self.close("reloadWindows")

    def _openFavorites(self): self._exitToParentAction("openFavorites")
    def _toggleFavorite(self): self._exitToParentAction("toggleCurrentFavourite")
    def _openFilter(self): self._exitToParentAction("openLiveFilter")
    def _openServer(self): self._exitToParentAction("openLiveServerMenu")
    def _openTools(self): self._exitToParentAction("openLiveTools")

class FavoritesScreen(Screen):
    skin = FAVORITES_CIRCLE_SKIN
    CIRCLES = ((171, 217, "live"), (699, 207, "vod"), (1227, 206, "series"))

    def __init__(self, session):
        Screen.__init__(self, session)
        self.index = 0
        self["selector"] = Pixmap()
        self["hint"] = Label(tr("LEFT / RIGHT  •  OK SELECT  •  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.openSelected, "cancel": self.close,
            "left": self.left, "right": self.right,
            "up": self.left, "down": self.right
        }, -1)
        self.onLayoutFinish.append(self._moveSelector)

    def _moveSelector(self):
        try:
            x, y, _kind = self.CIRCLES[self.index]
            self["selector"].instance.move(ePoint(sx(x), sy(y)))
            self["selector"].show()
        except Exception:
            pass

    def left(self):
        self.index = (self.index - 1) % len(self.CIRCLES)
        self._moveSelector()

    def right(self):
        self.index = (self.index + 1) % len(self.CIRCLES)
        self._moveSelector()

    def openSelected(self):
        _x, _y, kind = self.CIRCLES[self.index]
        self.session.open(FavoritesLibraryScreen, kind)


class FavoritesLibraryScreen(Screen):
    """Full-screen local Favorite library for live channels, movies, and series."""
    skin = FAVOURITES_SKIN
    FILTERS = ((tr("ALL"), ""), (tr("LIVE"), "live"), (tr("MOVIES"), "vod"), (tr("TV SHOWS"), "series"))
    KIND_LABELS = {"live": tr("LIVE"), "vod": tr("MOVIE"), "series": tr("SERIES")}
    POSTER_X = (335, 555, 775, 995, 1215, 1435)
    POSTER_Y = 330
    PAGE_SIZE = 6

    def __init__(self, session, initial_kind=""):
        Screen.__init__(self, session)
        self.filterIndex = 0
        for _i, _entry in enumerate(self.FILTERS):
            if _entry[1] == initial_kind:
                self.filterIndex = _i
                break
        self.records = []
        self.pageStart = 0
        self.posterIndex = 0
        self.picloads = []
        self._poster_artwork_requests = {}
        self._poster_slot_tokens = {}
        self._poster_page_serial = 0
        self._moveMode = False
        self._moveOriginalIds = None
        self["title"] = Label("")
        self["filter"] = Label("")
        self["featuredTitle"] = Label("")
        self["featuredLogo"] = Pixmap()
        self["liveProgrammeLogo"] = Pixmap()
        self._liveProgrammeLogoToken = ""
        self["featuredMeta"] = Label("")
        from .resolution_badge import install_information_badge
        install_information_badge(self, "featuredMeta")
        self["featuredYear"] = Label("")
        self["featuredRating"] = Label("")
        self["featuredDesc"] = SynopsisLabel("")
        self["genreCrime"] = Label("")
        self["genreDrama"] = Label("")
        self._favoriteLogoRequest = ""
        self._favoriteInfoToken = ""
        self._favoriteInfoCache = {}
        self._favoriteInfoProcesses = {}
        self._favoriteLocaleToken = None
        self._favoriteLocaleCache = {}
        self._favoriteLocaleInput = None
        self._favoriteLocaleTimer = eTimer()
        _connect_timer(self._favoriteLocaleTimer, self._resolveFavouriteLocale)
        self.onClose.append(self._stopFavouriteLocale)
        self["favoriteBackdrop"] = Pixmap()
        self._favoriteBackdropRequest = ""
        self._favoriteBackdropLoaders = []
        # Live Favorites only: debounce expensive EPG/backdrop/programme work.
        # Every focus move restarts this one-shot timer; stale async results are
        # invalidated immediately so they cannot repaint the newly focused row.
        self._liveFavouriteDetailTimer = eTimer()
        _connect_timer(self._liveFavouriteDetailTimer, self._runLiveFavouriteDetails)
        self._liveFavouriteDetailToken = ""
        # Keep large local EPG JSON parsing off the Enigma2 UI thread.
        self._liveFavouriteEpgWarm = set()
        self._liveFavouriteEpgWarming = set()
        # Provider-direct EPG fallback for Live Favorites.  The player uses
        # provider short EPG when the local XMLTV cache has no match; Favorites
        # must do the same or the same channel can show EPG only after playback.
        self._liveFavouriteEpgTimer = eTimer()
        _connect_timer(self._liveFavouriteEpgTimer, self._finishLiveFavouriteProviderEpg)
        self._liveFavouriteEpgResult = None
        self._liveFavouriteEpgRequest = ""
        self["list"] = MenuList([])
        self["status"] = Label("")
        self["keys"] = Label("")
        self["keyRed"] = Label(tr("RED  REMOVE"))
        self["keyGreen"] = Label(tr("GREEN  PLAY"))
        self["keyYellow"] = Label(tr("YELLOW  INFO"))
        self["keyBlue"] = Label(tr("BLUE  CLEAR ALL"))
        for slot in range(self.PAGE_SIZE):
            self["poster%d" % slot] = Pixmap()
            self["posterTitle%d" % slot] = Label("")
        self["posterSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.openCurrent, "cancel": self.back,
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "red": self.removeCurrent, "green": self.openCurrent,
            "yellow": self.showCurrentInfo, "blue": self.clearAllFavorites,
            "menu": self.openMenu
        }, -1)
        self._liveFolder = None
        self._liveFolderLoading = False
        self._liveFolderToken = 0
        self._savedLiveRecords = []
        self.onLayoutFinish.append(self.reload)

    def clearAllFavorites(self):
        label, kind = self.FILTERS[self.filterIndex]
        target_kind = kind or ""
        if not self.records:
            self["status"].setText(tr("Favorites are already empty"))
            return
        scope = label if target_kind else tr("ALL")
        message = "Clear all %s favorites?" % scope
        self.session.openWithCallback(lambda answer: self._clearAllFavoritesConfirmed(answer, target_kind), MessageBox, message, MessageBox.TYPE_YESNO)

    def _clearAllFavoritesConfirmed(self, answer, kind):
        if not answer:
            return
        try:
            if clear_favourites(kind or None):
                # Live package-folder markers are part of Live Favorites too.
                if not kind or kind == "live":
                    try:
                        marker_file = favorites_path("live_package_favorites.json")
                        with open(marker_file, "w") as h:
                            json.dump({}, h)
                    except Exception:
                        pass
                self.pageStart = 0
                self.posterIndex = 0
                self.reload()
                self["status"].setText(tr("Favorites cleared"))
            else:
                self["status"].setText(tr("Unable to clear Favorites"))
        except Exception as exc:
            self["status"].setText("Unable to clear Favorites: %s" % exc)

    def showCurrentInfo(self):
        record = self._currentRecord()
        if not record:
            return
        item = dict(record.get("item") or {})
        title = self._recordTitle(record)
        parts = []
        for value in (
            item.get("now_title") or item.get("epg_title") or item.get("event_name") or item.get("programme") or "",
            item.get("description") or item.get("plot") or item.get("overview") or item.get("epg_description") or "",
        ):
            value = str(value or "").strip()
            if value and value != title and value not in parts:
                parts.append(value)
        year = str(item.get("year") or item.get("releaseDate") or "").strip()
        rating = str(item.get("rating") or item.get("rating_5based") or "").strip()
        meta = "  •  ".join(x for x in (year, ("★ " + rating) if rating else "") if x)
        body = title
        if meta:
            body += "\n" + meta
        if parts:
            body += "\n\n" + "\n\n".join(parts[:2])
        self.session.open(MessageBox, body, MessageBox.TYPE_INFO)

    def startMoveCurrent(self):
        if not self.records:
            return
        if self._moveMode:
            self._finishFavoriteMove()
            return
        self._moveMode = True
        self._moveOriginalIds = [record.get("id") for record in self.records]
        try:
            self["status"].setText(tr("Move item with arrows, then press OK or BLUE to save."))
        except Exception:
            pass

    def openMenu(self):
        record = self._currentRecord()
        if record and record.get("_saved_live_folder"):
            self._openSavedLiveFolder(record)
            return
        if record and record.get("kind") == "live" and not record.get("_live_package"):
            self.session.openWithCallback(self._favoriteMenuSelected, ChoiceBox, title=tr("Favorite options"), list=[(tr("Move this channel"), "move")])
        else:
            self.nextFilter()

    def _favoriteMenuSelected(self, selected=None):
        if not selected or selected[1] != "move":
            return
        self._moveMode = True
        self._moveOriginalIds = [record.get("id") for record in self.records]
        try: self["status"].setText(tr("Move channel with arrows, then press OK to save."))
        except Exception: pass

    def _moveFavoriteBy(self, delta):
        if not self._moveMode:
            return False
        index = self.pageStart + self.posterIndex
        target = index + int(delta)
        if target < 0 or target >= len(self.records):
            return True
        self.records[index], self.records[target] = self.records[target], self.records[index]
        self.pageStart = (target // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = target - self.pageStart
        self.renderPosterPage()
        return True

    def _finishFavoriteMove(self):
        if not self._moveMode:
            return False
        if save_manual_order([record.get("id") for record in self.records]):
            self._moveMode = False; self._moveOriginalIds = None
            try: self["status"].setText(tr("Favorite channel position saved."))
            except Exception: pass
        return True

    def _currentRecord(self):
        index = self.pageStart + self.posterIndex
        if 0 <= index < len(self.records):
            return self.records[index]
        return None

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _setPlaceholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(
                "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_placeholder.png"
            )
        except Exception:
            pass

    def _recordTitle(self, record):
        item = record.get("item") or {}
        return item.get("name") or record.get("title") or item.get("title") or "IPTV"

    def _recordArtwork(self, record):
        item = record.get("item") or {}
        return item.get("stream_icon") or item.get("cover") or item.get("movie_image") or item.get("cover_big") or ""

    def _applyFavouriteKindLayout(self, kind):
        # Favorites library layout: Live uses compact circular tiles; VOD/Series use portrait posters.
        if kind == "live":
            # Match the movie favourites' featured information hierarchy without
            # changing the movie/series skin or the Live channel tile positions.
            # Geometry changes are made only on the Enigma UI thread.
            for name, x, y, w, h, font_size in (
                ("featuredTitle", 72, 112, 1250, 66, 43),
                ("featuredYear", 72, 190, 95, 40, 24),
                ("featuredRating", 178, 190, 155, 40, 24),
                ("featuredMeta", 72, 188, 1160, 43, 24),
                ("featuredDesc", 72, 241, 1240, 82, 23),
            ):
                try:
                    widget = self[name].instance
                    widget.move(ePoint(sx(x), sy(y)))
                    widget.resize(eSize(sx(w), sy(h)))
                    widget.setFont(gFont("Regular", max(14, sy(font_size))))
                except Exception:
                    pass
            try:
                for key, x, y, w, h, font_size in (
                    ("featuredTitle", 72, 104, 1130, 52, 38),
                    ("featuredYear", 1320, 146, 100, 38, 23),
                    ("featuredRating", 1430, 146, 390, 38, 23),
                    ("featuredMeta", 1320, 194, 500, 42, 23),
                    ("featuredDesc", 72, 223, 1130, 92, 23),
                ):
                    widget = self[key].instance
                    widget.move(ePoint(sx(x), sy(y)))
                    widget.resize(eSize(sx(w), sy(h)))
                    widget.setFont(gFont("Regular", max(14, sy(font_size))))
                # Programme logo has its own lane below the channel cards;
                # renderPosterPage adapts it if a second Live lane is visible.
                self["liveProgrammeLogo"].instance.move(ePoint(sx(770), sy(625)))
                self["liveProgrammeLogo"].instance.resize(eSize(sx(380), sy(130)))
            except Exception:
                pass
            self.POSTER_X = (300, 525, 750, 975, 1200, 1425)
            self.POSTER_Y = 345
            for slot in range(self.PAGE_SIZE):
                try:
                    # Live tiles must move with their Live coordinates too; resizing
                    # the portrait widgets alone left the 144px focus ring 35px left.
                    self["poster%d" % slot].instance.move(ePoint(sx(self.POSTER_X[slot]), sy(self.POSTER_Y)))
                    self["poster%d" % slot].instance.resize(eSize(sx(130), sy(130)))
                    self["posterTitle%d" % slot].instance.move(ePoint(sx(self.POSTER_X[slot]-25), sy(500)))
                    self["posterTitle%d" % slot].instance.resize(eSize(sx(190), sy(62)))
                except Exception:
                    pass
            try:
                self["posterSelector"].instance.resize(eSize(sx(144), sy(144)))
                self["posterSelector"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/live_focus_circle.png")
            except Exception:
                pass
        else:
            self.POSTER_X = (335, 555, 775, 995, 1215, 1435)
            self.POSTER_Y = 330
            for slot in range(self.PAGE_SIZE):
                try:
                    self["poster%d" % slot].instance.resize(eSize(sx(150), sy(220)))
                    self["posterTitle%d" % slot].instance.move(ePoint(sx(self.POSTER_X[slot]-10), sy(562)))
                    self["posterTitle%d" % slot].instance.resize(eSize(sx(170), sy(58)))
                except Exception:
                    pass
            try:
                self["posterSelector"].instance.resize(eSize(sx(162), sy(232)))
                self["posterSelector"].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/poster_focus_white.png")
            except Exception:
                pass
        self._placeLiveFavouriteFactBadges(kind)

    def reload(self):
        # reload always returns to the folder overview. A previous live-folder
        # pointer must not make root icons look like folder children (e.g.
        # after CLEAR ALL or switching the favorites filter).
        self._liveFolder = None
        self._liveFolderLoading = False
        label, kind = self.FILTERS[self.filterIndex]
        self.records = list_favourites(kind or None)
        # Source credentials are resolved only in RAM (never saved in Favorites).
        # Read the configured sources ONCE per reload, not once for each poster.
        try:
            self._favouriteArtworkSources = get_sources()
        except Exception:
            self._favouriteArtworkSources = []
        self._favouriteArtworkContexts = {}
        if kind == "live":
            marker_file = favorites_path("live_package_favorites.json")
            try:
                with open(marker_file, "r") as h: markers = json.load(h) or {}
            except Exception:
                markers = {}
            owned_by_source = {}
            package_records = []
            for marker_key, marker in list(markers.items()):
                try:
                    sid, cid = marker_key.split("|", 1)
                except Exception:
                    continue
                if isinstance(marker, dict):
                    title = str(marker.get("title") or "Live package")
                    owned = marker.get("owned") or []
                else:
                    title = "Live package"
                    owned = marker or []
                owned_by_source.setdefault(sid, set()).update(str(x) for x in owned)
                package_records.append({"id":"live-package:"+marker_key, "source_id":sid, "kind":"live", "title":title, "_live_package":True, "category_id":str(cid), "item":{"name":title, "category_id":str(cid), "stream_icon":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/favorite_package_star.png"}})
            filtered = []
            for record in self.records:
                item = record.get("item") or {}
                xid = str(item.get("stream_id") or item.get("id") or item.get("url") or item.get("cmd") or "")
                if xid and xid in owned_by_source.get(record.get("source_id"), set()):
                    continue
                filtered.append(record)
            # Live Favorites ordering is intentionally grouped: saved package
            # tiles always stay above individually saved channel tiles.  Do not
            # let manual channel order or a newly-added channel jump ahead of a
            # package.  Keep the existing order inside each group.
            package_rows = [r for r in package_records if r.get("_live_package")]
            channel_rows = [r for r in filtered if not r.get("_live_package")]
            # A regular saved Live channel belongs inside ONE Favorites folder,
            # alongside the existing package folders (not as a second tile lane).
            # No migration/write is needed: the original favorites.json remains
            # the sole source of truth and its channel order is untouched.
            self._savedLiveRecords = list(channel_rows)
            saved_folder = []
            if channel_rows:
                saved_folder = [{
                    "id": "saved-live-favorites-folder", "kind": "live",
                    "title": tr("LIVE FAVORITES"), "_live_package": True,
                    "_saved_live_folder": True,
                    "item": {"name": tr("LIVE FAVORITES"),
                             "stream_icon": os.path.join(PLUGIN_PATH, "skins", "favorites_circle", "favorite_package_star.png")},
                }]
            self.records = saved_folder + package_rows
        elif kind in ("vod", "series"):
            marker_file = favorites_path("media_package_favorites.json")
            try:
                with open(marker_file, "r") as h: markers = json.load(h) or {}
            except Exception:
                markers = {}
            package_rows = []
            for marker_key, marker in list(markers.items()):
                if not isinstance(marker, dict) or str(marker.get("kind") or "") != kind:
                    continue
                title = str(marker.get("title") or ("Movies package" if kind == "vod" else "Series package"))
                back = str(marker.get("backdrop") or "")
                package_rows.append({"id":"media-package:"+marker_key, "source_id":str(marker.get("source_id") or ""), "kind":kind, "title":title, "_media_package":True, "category_id":str(marker.get("category_id") or ""), "item":{"name":title, "category_id":str(marker.get("category_id") or ""), "cover":back, "backdrop":back}})
            # Package folders always stay before individually saved titles.
            self.records = package_rows + [r for r in self.records if not r.get("_media_package")]
        self.pageStart = 0
        self.posterIndex = 0
        rows = [(self._recordTitle(record), record) for record in self.records]
        self["list"].setList(rows)
        self["title"].setText({"live": tr("LIVE FAVORITES"), "vod": tr("MOVIE FAVORITES"), "series": tr("SERIES FAVORITES")}.get(kind, tr("FAVORITES")))
        self["filter"].setText("")
        self._applyFavouriteKindLayout(kind)
        self.renderPosterPage()

    def renderPosterPage(self):
        # Live Favorites has two visual lanes: package folders on top and
        # individually saved channels below.  Keep the six logical slots for
        # navigation/paging, but position each visible tile by its group.
        self._liveSlotPositions = {}
        self._poster_page_serial += 1
        self._poster_artwork_requests = {}
        self._favouritePosterRecovery = {}
        live_view = (self.FILTERS[self.filterIndex][1] == "live")
        visible = self.records[self.pageStart:self.pageStart + self.PAGE_SIZE]
        package_slot = 0
        channel_slot = 0
        for slot in range(self.PAGE_SIZE):
            index = self.pageStart + slot
            record = self.records[index] if index < len(self.records) else None
            self._poster_slot_tokens[slot] = (self._poster_page_serial, index)
            self._setVisible("poster%d" % slot, bool(record))
            self._setVisible("posterTitle%d" % slot, bool(record))
            if live_view and record:
                is_package = bool(record.get("_live_package"))
                lane_index = package_slot if is_package else channel_slot
                if is_package:
                    package_slot += 1
                    tile_y, title_y = 345, 500
                else:
                    channel_slot += 1
                    # Channels inside the saved folder take the same top row
                    # that regular package-folder contents use. On the root
                    # screen there are no standalone saved-channel tiles.
                    if self._liveFolder is not None and self._liveFolder.get("saved"):
                        tile_y, title_y = 345, 500
                    else:
                        tile_y, title_y = 585, 740
                # Start each lane at the same left edge and keep the existing spacing.
                tile_x = self.POSTER_X[min(lane_index, len(self.POSTER_X)-1)]
                self._liveSlotPositions[slot] = (tile_x, tile_y)
                try:
                    self["poster%d" % slot].instance.move(ePoint(sx(tile_x), sy(tile_y)))
                    self["posterTitle%d" % slot].instance.move(ePoint(sx(tile_x-25), sy(title_y)))
                except Exception:
                    pass
            if not record:
                try:
                    self["posterTitle%d" % slot].setText("")
                except Exception:
                    pass
                continue
            title = self._recordTitle(record)
            kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
            self["posterTitle%d" % slot].setText("%s\n%s" % (kind, visible_title(title, 35) if record.get("kind") in ("vod", "series") else str(title)[:35]))
            self._setPlaceholder(slot)
            artwork = self._recordArtwork(record)
            if artwork:
                if str(artwork).startswith("/") and os.path.exists(str(artwork)):
                    self._poster_artwork_requests[slot] = str(artwork)
                    self._decodePoster(slot, str(artwork), record)
                else:
                    self._loadPoster(slot, artwork, record)
            else:
                self._loadFavouriteTmdbPoster(slot, record)
        if live_view:
            self._placeLiveProgrammeLogoBelowChannels()
        # Six visible cards get priority; warm only the following six, not the
        # entire persistent favorite library. Live-channel logos remain separate.
        next_rows = self.records[self.pageStart + self.PAGE_SIZE:
                                 self.pageStart + 2 * self.PAGE_SIZE]
        prefetch_artwork([self._recordArtwork(record) for record in next_rows
                          if record.get("kind") in ("vod", "series") and self._recordArtwork(record)],
                         "posters", priority=2)
        self._setVisible("posterSelector", bool(self.records))
        self._moveSelector()
        self._updateStatus()
        record = self._currentRecord()
        if record and record.get("kind") == "live" and not record.get("_live_package"):
            self._scheduleLiveFavouriteDetails()
        else:
            self._cancelLiveFavouriteDetails()
            self._updateFavouriteBackdrop()
            self._updateFavouriteInfo()

    def _cancelLiveFavouriteDetails(self):
        try:
            self._liveFavouriteDetailTimer.stop()
        except Exception:
            pass
        self._liveFavouriteDetailToken = ""
        # Invalidate callbacks already in flight.  Network work that has already
        # started cannot always be aborted safely, but its result is discarded.
        self._favoriteBackdropRequest = "live-focus-cancelled:%s" % time.time()
        self._favoriteLogoRequest = "live-focus-cancelled:%s" % time.time()

    def _placeLiveFavouriteFactBadges(self, kind):
        """Keep the quality/year/genre pills away from channel metadata.

        The common information-badge installer anchors the five pills next to
        featuredMeta at skin creation, which works for VOD but overlaps Live's
        dynamically repositioned featuredMeta.  Move only their widgets, not
        the common badge code or the image/artwork queues.
        """
        positions = (1314, 1407, 1501, 1682, 1809) if kind == "live" else (1256, 1349, 1443, 1624, 1751)
        y = 252 if kind == "live" else 151
        for name, x in zip(("infoResolution", "infoYear", "infoGenre",
                            "infoDuration", "infoRating"), positions):
            try:
                if self[name].instance:
                    self[name].instance.move(ePoint(sx(x), sy(y)))
            except Exception:
                pass

    def _placeLiveProgrammeLogoBelowChannels(self):
        """Always show the current programme logo below *all* visible Live tiles.

        Some Favorites views show a package row plus a second channel row.
        Put the logo below channel captions in either arrangement; never
        overlap the circles (or their text) when the EPG image arrives late.
        """
        row_positions = getattr(self, "_liveSlotPositions", {}) or {}
        second_lane = any(y >= 585 for x, y in row_positions.values())
        logo_y = 820 if second_lane else 625
        try:
            if self["liveProgrammeLogo"].instance:
                self["liveProgrammeLogo"].instance.move(ePoint(sx(770), sy(logo_y)))
                self["liveProgrammeLogo"].instance.resize(eSize(sx(380), sy(130)))
        except Exception:
            pass

    def _scheduleLiveFavouriteDetails(self):
        try:
            self._liveFavouriteDetailTimer.stop()
        except Exception:
            pass
        record = self._currentRecord()
        if not record or record.get("kind") != "live" or record.get("_live_package"):
            self._liveFavouriteDetailToken = ""
            return
        token = str(record.get("id") or "%s:%s" % (record.get("source_id", ""), self.pageStart + self.posterIndex))
        self._liveFavouriteDetailToken = token
        # Do not leave programme artwork/details from the previous channel on
        # screen while the user is still scrolling.
        self._favoriteBackdropRequest = "live-focus-wait:%s" % token
        self._favoriteLogoRequest = "live-focus-wait:%s" % token
        self._liveProgrammeLogoToken = "live-focus-wait:%s" % token
        try: self["liveProgrammeLogo"].hide()
        except Exception: pass
        try:
            self["favoriteBackdrop"].hide()
            self["featuredLogo"].hide()
            self["featuredTitle"].setText(self._recordTitle(record))
            self["featuredMeta"].setText("")
            self["featuredYear"].setText("")
            self["featuredRating"].setText("")
            self["featuredDesc"].setText("")
            self._setFavouriteGenreBadges("")
        except Exception:
            pass
        # Warm this source's local EPG cache in a worker.  The first JSON parse
        # can be large and used to show Enigma's spinner when done on focus.
        try:
            source = source_for_record(record, get_sources())
            sid = str((source or {}).get("id") or (source or {}).get("name") or record.get("source_id") or "")
            if source and sid not in self._liveFavouriteEpgWarm and sid not in self._liveFavouriteEpgWarming:
                self._liveFavouriteEpgWarming.add(sid)
                def warm_epg(src=dict(source), key=sid):
                    try: load_source_epg(src)
                    except Exception: pass
                    self._liveFavouriteEpgWarm.add(key)
                    self._liveFavouriteEpgWarming.discard(key)
                threading.Thread(target=warm_epg, name="TiviMateFavoriteEPGWarm", daemon=True).start()
        except Exception:
            pass
        try:
            self._liveFavouriteDetailTimer.start(3000, True)
        except TypeError:
            self._liveFavouriteDetailTimer.start(3000)

    def _runLiveFavouriteDetails(self):
        record = self._currentRecord()
        if not record or record.get("kind") != "live" or record.get("_live_package"):
            return
        token = str(record.get("id") or "%s:%s" % (record.get("source_id", ""), self.pageStart + self.posterIndex))
        if not self._liveFavouriteDetailToken or token != self._liveFavouriteDetailToken:
            return
        try:
            source = source_for_record(record, get_sources())
            sid = str((source or {}).get("id") or (source or {}).get("name") or record.get("source_id") or "")
            if sid and sid in self._liveFavouriteEpgWarming:
                # No spinner: wait in the background until the disk cache is ready.
                try: self._liveFavouriteDetailTimer.start(200, True)
                except TypeError: self._liveFavouriteDetailTimer.start(200)
                return
        except Exception:
            pass
        self._updateFavouriteBackdrop()
        self._updateFavouriteInfo()

    def _startLiveFavouriteProviderEpg(self, record, source, item):
        source_type = str((source or {}).get("type") or "")
        if source_type not in ("xtream", "stalker"):
            return False
        stream_id = str((item or {}).get("stream_id") or (item or {}).get("id") or (item or {}).get("ch_id") or "").strip()
        if not stream_id:
            return False
        token = str((record or {}).get("id") or "") + ":" + stream_id
        if token == self._liveFavouriteEpgRequest:
            return True
        self._liveFavouriteEpgRequest = token
        self._liveFavouriteEpgResult = None
        src = dict(source or {})
        row = dict(item or {})
        def worker():
            rows = []
            try:
                if source_type == "xtream":
                    epg_id = str(row.get("epg_channel_id") or row.get("tvg_id") or row.get("epg_id") or "").strip()
                    rows = XtreamClient(src).short_epg(stream_id, limit=10, epg_channel_id=epg_id) or []
                else:
                    rows = StalkerClient(src).short_epg(stream_id, limit=10) or []
            except Exception:
                rows = []
            self._liveFavouriteEpgResult = (token, rows)
        threading.Thread(target=worker, name="TiviMateFavoriteEPG", daemon=True).start()
        try: self._liveFavouriteEpgTimer.start(120, True)
        except TypeError: self._liveFavouriteEpgTimer.start(120)
        return True

    def _favoriteProviderTimestamp(self, value):
        if value in (None, ""):
            return 0
        try:
            number = int(float(value))
            if number > 100000000000: number //= 1000
            if number > 1000000000: return number
        except Exception:
            pass
        raw = str(value or "").strip().replace("T", " ").replace("Z", "")
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y%m%d%H%M%S"):
            try: return int(time.mktime(time.strptime(raw[:19] if "-" in fmt else raw[:14], fmt)))
            except Exception: pass
        return 0

    def _favoriteDecodeEpgText(self, value):
        text = str(value or "").strip()
        if not text: return ""
        try:
            import base64
            decoded = base64.b64decode(text).decode("utf-8", "ignore").strip()
            if decoded and sum(ch.isprintable() for ch in decoded) >= max(1, int(len(decoded) * .8)):
                return decoded
        except Exception:
            pass
        return text

    def _finishLiveFavouriteProviderEpg(self):
        result = self._liveFavouriteEpgResult
        if result is None:
            try: self._liveFavouriteEpgTimer.start(120, True)
            except TypeError: self._liveFavouriteEpgTimer.start(120)
            return
        self._liveFavouriteEpgResult = None
        token, rows = result
        record = self._currentRecord()
        if not record or record.get("kind") != "live" or record.get("_live_package"):
            return
        item = record.get("item") or {}
        stream_id = str(item.get("stream_id") or item.get("id") or item.get("ch_id") or "").strip()
        wanted = str(record.get("id") or "") + ":" + stream_id
        if token != wanted or token != self._liveFavouriteEpgRequest:
            return
        now = int(time.time()); parsed = []
        for row in rows or []:
            if not isinstance(row, dict): continue
            begin = self._favoriteProviderTimestamp(row.get("start_timestamp") or row.get("start") or row.get("begin") or row.get("time"))
            end = self._favoriteProviderTimestamp(row.get("stop_timestamp") or row.get("end") or row.get("stop"))
            duration = max(0, end - begin)
            title = self._favoriteDecodeEpgText(row.get("title") or row.get("name") or row.get("programme"))
            desc = self._favoriteDecodeEpgText(row.get("description") or row.get("desc") or row.get("plot"))
            if begin and title: parsed.append((begin, duration, title, desc))
        parsed.sort(key=lambda x:x[0])
        current = None
        for event in parsed:
            finish = event[0] + (event[1] if event[1] > 0 else 3600)
            if event[0] <= now < finish: current = event; break
        if current is None and parsed:
            current = parsed[0]
        if not current: return
        begin, duration, title, desc = current
        end = begin + duration if duration else 0
        timing = "%s - %s" % (time.strftime("%H:%M", time.localtime(begin)), time.strftime("%H:%M", time.localtime(end))) if begin and end else ""
        channel = self._recordTitle(record)
        try: self["featuredTitle"].setText(title or channel); self["featuredTitle"].show()
        except Exception: pass
        try: self["featuredMeta"].setText(str(channel)[:95])
        except Exception: pass
        try: self["featuredRating"].setText(timing)
        except Exception: pass
        try: self["featuredDesc"].setText(str(desc or "")[:500])
        except Exception: pass
        if title:
            self._loadFavouriteLiveProgrammeBackdrop(title)
            self._loadFavouriteLiveProgrammeLogo(title, getattr(self, "_liveFavouriteDetailToken", ""))

    def _setFavouriteGenreBadges(self, genre):
        text = str(genre or "").lower()
        for name, word in (("genreCrime", "crime"), ("genreDrama", "drama")):
            try:
                if word in text:
                    self[name].setText(word.title()); self[name].show()
                else:
                    self[name].setText(""); self[name].hide()
            except Exception:
                pass

    def _stopFavouriteLocale(self):
        self._favoriteLocaleToken = None
        try: self._favoriteLocaleTimer.stop()
        except Exception: pass

    def _scheduleFavouriteLocale(self, record, item):
        if not record or record.get("kind") not in ("vod", "series"):
            return
        try:
            locale = TMDbClient().language
        except Exception:
            return
        token = (str(record.get("id") or ""), str(record.get("kind")), locale)
        if not token[0]:
            return
        self._favoriteLocaleToken = token
        self._favoriteLocaleInput = (dict(record), dict(item or {}))
        try: self._favoriteLocaleTimer.stop()
        except Exception: pass
        cached = self._favoriteLocaleCache.get(token)
        if cached:
            self._applyFavouriteLocale(token, cached)
        else:
            try: self._favoriteLocaleTimer.start(350, True)
            except Exception: pass

    def _resolveFavouriteLocale(self):
        token = self._favoriteLocaleToken
        payload = self._favoriteLocaleInput
        if not token or not payload:
            return
        record, item = payload
        title = str(item.get("name") or item.get("title") or self._recordTitle(record) or "")
        if not title:
            return
        kind = token[1]
        def worker():
            try:
                client = TMDbClient()
                if client.language != token[2]:
                    return
                tid = item.get("tmdb_id") or item.get("tmdb") or ""
                if not tid:
                    raw_year = str(item.get("year") or item.get("releaseDate") or item.get("releasedate") or "")
                    year_match = re.search(r"\b(?:19|20)\d{2}\b", raw_year)
                    found = client.search_artwork(title, kind, year_match.group(0) if year_match else None) or {}
                    tid = found.get("id")
                if not tid:
                    return
                data = client.details_bundle(tid, kind) or {}
                if not data:
                    return
                info = merge_metadata(item, tmdb=data, language=client.language, kind=kind)
                incoming = {"title": info["title"], "overview": info["description"]}
                if reactor is not None:
                    reactor.callFromThread(self._applyFavouriteLocale, token, incoming)
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateFavoriteLocale")
        thread.daemon = True
        thread.start()

    def _applyFavouriteLocale(self, token, incoming):
        if self._favoriteLocaleToken != token:
            return
        record = self._currentRecord()
        if not record or str(record.get("id") or "") != token[0] or str(record.get("kind")) != token[1]:
            return
        stable = dict(incoming or {})
        if incoming.get("title"):
            previous = self["featuredTitle"].getText()
            chosen = keep_arabic_on_late_update(previous, incoming["title"], token[2])
            stable["title"] = chosen
            self["featuredTitle"].setText(str(chosen))
        if incoming.get("overview"):
            previous = self["featuredDesc"].getText()
            chosen = keep_arabic_on_late_update(previous, incoming["overview"], token[2])
            stable["overview"] = chosen
            self["featuredDesc"].setText(str(chosen)[:500])
        # Cache what the user actually sees. Otherwise a later provider reply
        # may reuse the raw English response and flip Arabic back to English.
        self._favoriteLocaleCache[token] = stable

    def _updateFavouriteInfo(self):
        self._favoriteLocaleToken = None
        try: self._favoriteLocaleTimer.stop()
        except Exception: pass
        record = self._currentRecord()
        if not record or record.get("kind") != "live":
            self._liveProgrammeLogoToken = ""
            try: self["liveProgrammeLogo"].hide()
            except Exception: pass
        if record and record.get("kind") == "live" and not record.get("_live_package"):
            item = record.get("item") or {}
            title = self._recordTitle(record)
            now_title = ""; desc = ""; timing = ""
            try:
                source = source_for_record(record, get_sources())
                current, upcoming = lookup_channel_epg(source, item, int(time.time())) if source else (None, None)
                if not current and source:
                    # Match Live Player behavior: local XMLTV first, then the
                    # provider's short EPG for Xtream/Stalker.
                    self._startLiveFavouriteProviderEpg(record, source, item)
                if current:
                    begin = int(current[0] or 0); duration = int(current[1] or 0)
                    now_title = str(current[2] or "")
                    desc = str(current[3] or "")
                    if begin and duration:
                        end = begin + duration
                        timing = "%s - %s" % (time.strftime("%H:%M", time.localtime(begin)), time.strftime("%H:%M", time.localtime(end)))
            except Exception:
                pass
            # Live favourites use the same featured layout as Movies: one
            # channel logo at top-right, programme/meta above the description.
            logo = item.get("stream_icon") or item.get("logo") or item.get("picon") or ""
            logo = str(logo or "").strip().replace("\\/", "/")
            if logo.startswith(("http://", "https://")):
                self._loadFavouriteLogo(logo)
            elif logo and os.path.exists(logo):
                try:
                    self["featuredLogo"].instance.setPixmapFromFile(logo); self["featuredLogo"].show()
                except Exception: pass
            else:
                try: self["featuredLogo"].hide()
                except Exception: pass
            try: self["featuredTitle"].setText(str(now_title or title)); self["featuredTitle"].show()
            except Exception: pass
            # One channel name only; separate EPG time and HD into the same
            # colored metadata widgets used by movie favorites.
            try: self["featuredMeta"].setText(str(title)[:95])
            except Exception: pass
            # If the saved channel has no fanart, resolve artwork for the
            # current EPG programme asynchronously. This mirrors the Movies
            # backdrop widget and never blocks Live navigation.
            direct_back = item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or item.get("fanart") or item.get("background") or ""
            if not direct_back and now_title:
                self._loadFavouriteLiveProgrammeBackdrop(now_title)
            self._loadFavouriteLiveProgrammeLogo(now_title, getattr(self, "_liveFavouriteDetailToken", ""))
            try: self["featuredYear"].setText("HD" if "HD" in str(title).upper().split() else "")
            except Exception: pass
            try: self["featuredRating"].setText(timing)
            except Exception: pass
            try: self["featuredDesc"].setText(desc[:500])
            except Exception: pass
            self._setFavouriteGenreBadges("")
            return
        if not record or record.get("kind") not in ("vod", "series"):
            try: self["featuredLogo"].hide()
            except Exception: pass
            try: self["featuredTitle"].setText("")
            except Exception: pass
            try: self["featuredMeta"].setText("")
            except Exception: pass
            try: self["featuredYear"].setText("")
            except Exception: pass
            try: self["featuredRating"].setText("")
            except Exception: pass
            try: self["featuredDesc"].setText("")
            except Exception: pass
            self._setFavouriteGenreBadges("")
            return
        item = record.get("item") or {}
        title = self._recordTitle(record)
        initial = merge_metadata(item, language=TMDbClient().language,
                                 kind=record.get("kind") or "vod")
        year = initial["year"]
        rating = initial["rating"]
        genre = initial["genre"]
        duration = initial["runtime"]
        seasons = item.get("seasons") or item.get("season_count") or item.get("number_of_seasons") or ""
        if isinstance(genre, (list, tuple)):
            genre = " • ".join([str(x.get("name") if isinstance(x, dict) else x) for x in genre if x])
        self._setFavouriteGenreBadges(genre)
        bits = []
        try: self["featuredYear"].setText(str(year)[:4] if year else "")
        except Exception: pass
        try: self["featuredRating"].setText(("★ %s" % str(rating)[:4]) if rating else "")
        except Exception: pass
        if record.get("kind") == "series" and seasons: bits.append("%s Seasons" % seasons)
        elif duration: bits.append(str(duration))
        other_genres = [g.strip() for g in re.split(r"[,•/]", str(genre or "")) if g.strip().lower() not in ("crime", "drama")]
        if other_genres: bits.append(" • ".join(other_genres[:3]))
        desc = initial["description"]
        try:
            self["featuredTitle"].setText(str(title)); self["featuredTitle"].show()
        except Exception: pass
        try: self["featuredMeta"].setText("   •   ".join(bits)[:150])
        except Exception: pass
        try: self["featuredDesc"].setText(str(desc)[:420])
        except Exception: pass
        logo = item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or ""
        logo = str(logo or "").strip().replace("\\/", "/")
        if logo.startswith(("http://", "https://")):
            self._loadFavouriteLogo(logo)
        else:
            self._favoriteLogoRequest = ""
            try: self["featuredLogo"].hide()
            except Exception: pass
        # A favourite row is intentionally small. Enrich the focused item from
        # the SAME saved provider (disk cache first, provider second), so rating,
        # plot, backdrop and provider logo are not limited to the saved row.
        self._loadFavouriteProviderInfo(record)
        self._scheduleFavouriteLocale(record, item)


    def _applyFavouriteProviderInfo(self, token, record, data):
        if self._favoriteInfoToken != token:
            return
        current = self._currentRecord()
        if not current or current.get("id") != record.get("id"):
            return
        item = dict(record.get("item") or {})
        info = (data or {}).get("info") or {}
        movie = (data or {}).get("movie_data") or {}
        merged = {}; merged.update(item); merged.update(movie); merged.update(info)
        language = TMDbClient().language
        locale_token = getattr(self, "_favoriteLocaleToken", None)
        localized = (self._favoriteLocaleCache.get(locale_token) or {}) if (
            locale_token and str(locale_token[0]) == str(record.get("id") or "") and
            str(locale_token[1]) == str(record.get("kind") or "") and
            str(locale_token[2]).lower() == str(language).lower()) else {}
        display = merge_metadata(item, provider=merged,
                                 tmdb={"title": localized.get("title"),
                                       "overview": localized.get("overview")},
                                 language=language, kind=record.get("kind") or "vod")
        title = display["title"] or self._recordTitle(record)
        year = display["year"]
        rating = display["rating"]
        genre = display["genre"]
        duration = display["runtime"] or merged.get("duration_secs") or ""
        seasons = merged.get("seasons") or merged.get("season_count") or merged.get("number_of_seasons") or ""
        if isinstance(genre, (list, tuple)):
            genre = " • ".join(str(x.get("name") if isinstance(x, dict) else x) for x in genre if x)
        self._setFavouriteGenreBadges(genre)
        bits=[]
        try: self["featuredYear"].setText(str(year)[:4] if year else "")
        except Exception: pass
        try: self["featuredRating"].setText(("★ %s/10" % str(rating)[:4].rstrip("/10")) if rating else "")
        except Exception: pass
        if record.get("kind") == "series" and seasons: bits.append("%s Seasons" % seasons)
        elif duration: bits.append(str(duration))
        other_genres = [g.strip() for g in re.split(r"[,•/]", str(genre or "")) if g.strip().lower() not in ("crime", "drama")]
        if other_genres: bits.append(" • ".join(other_genres[:3]))
        try: self["featuredTitle"].setText(str(title))
        except Exception: pass
        try: self["featuredMeta"].setText("   •   ".join(bits)[:180])
        except Exception: pass
        desc = display["description"]
        try: self["featuredDesc"].setText(str(desc)[:500])
        except Exception: pass
        back = merged.get("backdrop_path") or merged.get("backdrop") or merged.get("backdrop_url") or ""
        if isinstance(back, (list, tuple)): back = back[0] if back else ""
        if back:
            back = str(back).strip().replace("\\/", "/")
            if back.startswith("/"):
                try: back = backdrop_url(back)
                except Exception: pass
            self._loadFavouriteBackdrop(back)
        logo = merged.get("logo") or merged.get("title_logo") or merged.get("logo_path") or merged.get("clearlogo") or ""
        logo = str(logo or "").strip().replace("\\/", "/")
        if logo.startswith(("http://", "https://")):
            # Show a provider logo while the localized TMDb logo resolves.
            self._loadFavouriteLogo(logo)
        # The provider image can be English even with Arabic TMDb selected.
        # Avoid a second TMDb request for English when a provider logo exists.
        from .logo_manager import logo_language
        if not logo.startswith(("http://", "https://")) or logo_language() != "en":
            self._loadFavouriteTmdbLogo(record, merged)
        self._scheduleFavouriteLocale(record, merged)

    def _loadFavouriteProviderInfo(self, record):
        if not record or record.get("kind") not in ("vod", "series"):
            return
        item = record.get("item") or {}
        mid = str(item.get("stream_id") or item.get("series_id") or item.get("id") or "")
        token = "%s:%s:%s" % (record.get("kind"), record.get("source_id", ""), mid or self._recordTitle(record))
        self._favoriteInfoToken = token
        if token in self._favoriteInfoCache:
            self._applyFavouriteProviderInfo(token, record, self._favoriteInfoCache[token]); return
        source = source_for_record(record, get_sources())
        if not source or source.get("type") == "stalker" or not mid:
            self._loadFavouriteTmdbLogo(record, item); return
        try:
            client = XtreamClient(source)
            action = "get_vod_info" if record.get("kind") == "vod" else "get_series_info"
            try: from urllib.parse import urlencode
            except ImportError: from urllib import urlencode
            url = client.base + "/player_api.php?" + urlencode({"username":client.user,"password":client.password,"action":action,("vod_id" if record.get("kind")=="vod" else "series_id"):mid})
            # Never share provider details across IPTV sources with identical
            # stream IDs (the old `kind:id` cache caused wrong movie metadata).
            key = provider_cache_key(record.get("kind"), mid, source)
            cache_dir = get_cache_dir("metadata"); ensure_dir(cache_dir)
            path = os.path.join(cache_dir, "provider_info_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")
            try:
                if os.path.exists(path) and os.path.getsize(path) > 2:
                    with open_text(path,"r",encoding="utf-8") as h: data=json.load(h)
                    if isinstance(data,dict) and data:
                        self._favoriteInfoCache[token]=data; self._applyFavouriteProviderInfo(token,record,data); return
            except Exception: pass
            if token in self._favoriteInfoProcesses: return
            proc=eConsoleAppContainer(); self._favoriteInfoProcesses[token]=proc
            def done(ret, tok=token, rec=record, pth=path):
                self._favoriteInfoProcesses.pop(tok,None)
                if ret==0 and os.path.exists(pth):
                    try:
                        with open_text(pth,"r",encoding="utf-8") as h: data=json.load(h) or {}
                        self._favoriteInfoCache[tok]=data; self._applyFavouriteProviderInfo(tok,rec,data); return
                    except Exception: pass
                self._loadFavouriteTmdbLogo(rec, rec.get("item") or {})
            try: proc.appClosed.append(done)
            except Exception: proc.appClosed.get().append(done)
            proc.execute(PYTHON_EXECUTABLE,PYTHON_COMMAND,INFO_FETCH,url,path)
        except Exception:
            self._loadFavouriteTmdbLogo(record,item)

    def _loadFavouriteTmdbLogo(self, record, item):
        title=self._recordTitle(record)
        if not title: return
        token=self._favoriteInfoToken
        kind="series" if record.get("kind")=="series" else "vod"
        def worker():
            try:
                raw_year=(item or {}).get("year") or (item or {}).get("releasedate") or ""
                m=re.search(r"\b(?:19|20)\d{2}\b",str(raw_year)); year=m.group(0) if m else None
                from .logo_manager import localized_logo_url
                client=TMDbClient()
                tid=(item or {}).get("tmdb_id") or (item or {}).get("tmdb")
                if not tid:
                    found=client.search_artwork(title,kind,year) or {}
                    tid=found.get("id")
                if not tid: return
                bundle=client.details_bundle(tid,kind) or {}
                url=localized_logo_url(client,kind,tid,(bundle.get("images") or {}), details=bundle, item=item, title=title)
                if not url: return
                def apply():
                    if self._favoriteInfoToken==token: self._loadFavouriteLogo(url)
                if reactor: reactor.callFromThread(apply)
                else: apply()
            except Exception: pass
        t=threading.Thread(target=worker,name="TiviMateFavouriteLogo"); t.daemon=True; t.start()

    def _loadFavouriteLogo(self, url):
        url = str(url or "").strip().replace("\\/", "/")
        if not url or not url.startswith(("http://", "https://")):
            try: self["featuredLogo"].hide()
            except Exception: pass
            return
        self._favoriteLogoRequest = url
        def done(path, expected=url):
            if self._favoriteLogoRequest != expected: return
            try:
                if path and os.path.exists(path) and self["featuredLogo"].instance:
                    self["featuredLogo"].instance.setPixmapFromFile(path)
                    self["featuredLogo"].show()
                    if not (self._currentRecord() or {}).get("kind") == "live":
                        self["featuredTitle"].hide()
            except Exception: pass
        try: request_artwork(url, "logos", done, priority=110,
                             source=self._favouriteArtworkSource())
        except Exception: pass

    def _loadFavouriteLiveProgrammeLogo(self, programme_title, focus_token):
        """Resolve the current EPG title logo asynchronously; never block channel navigation."""
        title = str(programme_title or "").strip()
        token = "live-logo:%s:%s" % (focus_token, title)
        self._liveProgrammeLogoToken = token
        try: self["liveProgrammeLogo"].hide()
        except Exception: pass
        if not title:
            return
        def worker():
            try:
                client = TMDbClient()
                for kind in ("vod", "series"):
                    found = client.search_artwork(title, kind, None) or {}
                    tid = found.get("id")
                    bundle = client.details_bundle(tid, kind) if tid else found
                    from .logo_manager import localized_logo_url
                    url = localized_logo_url(client, kind, tid,
                                             (bundle or {}).get("images") or {}, details=bundle, title=title)
                    if not url:
                        continue
                    def apply(url=url):
                        if self._liveProgrammeLogoToken != token:
                            return
                        def done(file_path, expected=token):
                            if self._liveProgrammeLogoToken != expected:
                                return
                            try:
                                if file_path and os.path.exists(file_path) and self["liveProgrammeLogo"].instance:
                                    self["liveProgrammeLogo"].instance.setPixmapFromFile(file_path)
                                    self["liveProgrammeLogo"].show()
                            except Exception:
                                pass
                        request_artwork(url, "logos", done, priority=120)
                    if reactor: reactor.callFromThread(apply)
                    else: apply()
                    return
            except Exception:
                pass
        t = threading.Thread(target=worker, name="TiviMateLiveFavouriteProgrammeLogo")
        t.daemon = True
        t.start()

    def _loadFavouriteLiveProgrammeBackdrop(self, programme_title):
        title = str(programme_title or "").strip()
        if not title:
            return
        token = "live-epg:%s" % title
        self._favoriteBackdropRequest = token
        def worker():
            try:
                client = TMDbClient()
                # EPG does not tell us reliably whether an event is a movie or
                # a series. Try both and only accept a real backdrop result.
                found = client.search_artwork(title, "vod", None, required_key="backdrop_path") or {}
                if not found.get("backdrop_path"):
                    found = client.search_artwork(title, "series", None, required_key="backdrop_path") or {}
                path = found.get("backdrop_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else backdrop_url(str(path))
                def apply():
                    if self._favoriteBackdropRequest == token:
                        self._loadFavouriteBackdrop(url)
                if reactor: reactor.callFromThread(apply)
                else: apply()
            except Exception:
                pass
        t=threading.Thread(target=worker, name="TiviMateFavouriteLiveBackdrop"); t.daemon=True; t.start()

    def _recordBackdrop(self, record):
        item = (record or {}).get("item") or {}
        back = item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or item.get("backdropPath") or ""
        if isinstance(back, (list, tuple)):
            back = back[0] if back else ""
        back = str(back or "").strip().replace("\\/", "/")
        if back and not back.startswith(("http://", "https://")):
            try: back = backdrop_url(back)
            except Exception: pass
        return back

    def _resetFavouriteBackdrop(self):
        self._favoriteBackdropRequest = ""
        try: self["favoriteBackdrop"].hide()
        except Exception: pass

    def _updateFavouriteBackdrop(self):
        record = self._currentRecord()
        if record and record.get("kind") == "live" and not record.get("_live_package"):
            item = record.get("item") or {}
            # Live favourites: cache/artwork fields from the same saved channel only.
            back = item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url") or item.get("fanart") or item.get("background") or ""
            if isinstance(back, (list, tuple)): back = back[0] if back else ""
            back = str(back or "").strip().replace("\\/", "/")
            if back:
                if not back.startswith(("http://", "https://")):
                    try: back = backdrop_url(back)
                    except Exception: pass
                self._loadFavouriteBackdrop(back); return
            self._resetFavouriteBackdrop(); return
        if not record or record.get("kind") not in ("vod", "series"):
            self._resetFavouriteBackdrop(); return
        direct = self._recordBackdrop(record)
        if direct:
            self._loadFavouriteBackdrop(direct); return
        item = record.get("item") or {}
        title = self._recordTitle(record)
        kind = "series" if record.get("kind") == "series" else "vod"
        token = "lookup:%s:%s" % (kind, title)
        self._favoriteBackdropRequest = token
        def worker():
            try:
                # Same saved server metadata first where available, then artwork lookup.
                raw_year = item.get("year") or item.get("releaseDate") or item.get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                found = TMDbClient().search_artwork(title, kind, match.group(0) if match else None, required_key="backdrop_path") or {}
                path = found.get("backdrop_path") or ""
                if not path: return
                url = path if str(path).startswith(("http://", "https://")) else backdrop_url(str(path))
                def apply():
                    if self._favoriteBackdropRequest == token: self._loadFavouriteBackdrop(url)
                if reactor: reactor.callFromThread(apply)
                else: apply()
            except Exception: pass
        t=threading.Thread(target=worker, name="TiviMateFavouriteBackdrop"); t.daemon=True; t.start()

    def _loadFavouriteBackdrop(self, url):
        url = str(url or "").strip().replace("\\/", "/")
        if not url: self._resetFavouriteBackdrop(); return
        self._favoriteBackdropRequest = url
        def done(path, expected=url):
            if self._favoriteBackdropRequest != expected: return
            loader=ePicLoad(); self._favoriteBackdropLoaders.append(loader)
            def ready(_info=None, current=loader):
                try:
                    if self._favoriteBackdropRequest == expected:
                        ptr=current.getData()
                        if ptr and self["favoriteBackdrop"].instance:
                            self["favoriteBackdrop"].instance.setPixmap(ptr); self["favoriteBackdrop"].show()
                except Exception: pass
                try: self._favoriteBackdropLoaders.remove(current)
                except Exception: pass
            try: connect_picture_data(loader, ready, self)
            except Exception:
                try: loader.PictureData.connect(ready)
                except Exception: return
            try:
                w,h=scale_size(1920,1080); loader.setPara((w,h,0,0,False,1,"#00000000")); loader.startDecode(path)
            except Exception: pass
        request_artwork(url, "backdrops", done, priority=115,
                        source=self._favouriteArtworkSource())

    def _favouriteArtworkSource(self, record=None):
        record = record if isinstance(record, dict) else self._currentRecord()
        if not record:
            return {}
        try:
            key = str(record.get("source_id") or "")
            cached = getattr(self, "_favouriteArtworkContexts", {})
            if key in cached:
                return dict(cached[key])
            sources = getattr(self, "_favouriteArtworkSources", None)
            if sources is None:
                # For a recovery path entered before the first reload.
                sources = get_sources()
                self._favouriteArtworkSources = sources
            context = dict(source_for_record(record, sources) or {})
            if not isinstance(cached, dict):
                cached = {}
                self._favouriteArtworkContexts = cached
            cached[key] = context
            return dict(context)
        except Exception:
            return {}

    def _recoverFavouritePoster(self, slot, record):
        # A cache/server miss gets GENRE's provider-detail/TMDb recovery, not
        # another copy of the primary downloader. Keep Favorites' tile count
        # and all queue/prefetch limits as before.
        if not isinstance(record, dict) or record.get("kind") not in ("vod", "series"):
            return
        token = self._poster_slot_tokens.get(slot)
        request = self._poster_artwork_requests.get(slot)
        recovery_key = (token, request)
        active = getattr(self, "_favouritePosterRecovery", None)
        if not isinstance(active, dict):
            active = {}
            self._favouritePosterRecovery = active
        if active.get(slot) == recovery_key:
            return
        active[slot] = recovery_key
        def stale():
            return (self._poster_slot_tokens.get(slot) != token or
                    self._poster_artwork_requests.get(slot) != request)
        def resolved(path, _winner):
            if stale():
                return
            active.pop(slot, None)
            if usable_poster_file(path, minimum_bytes=128):
                self._decodePoster(slot, path, record)
            else:
                self._loadFavouriteTmdbPoster(slot, record)
        def missing():
            if not stale():
                active.pop(slot, None)
                self._loadFavouriteTmdbPoster(slot, record)
        try:
            from .shared_genre_posters import request_genre_poster
            if request_genre_poster(self._favouriteArtworkSource(record),
                                    record.get("item") or {}, record.get("kind"),
                                    resolved, failed=missing, cancelled=stale):
                return
        except Exception:
            pass
        missing()

    def _loadFavouriteTmdbPoster(self, slot, record):
        item = (record or {}).get("item") or {}
        title = self._recordTitle(record or {})
        kind = "series" if (record or {}).get("kind") == "series" else "vod"
        if not title:
            return
        token = "tmdb:%s:%s" % (kind, title)
        self._poster_artwork_requests[slot] = token
        expected_slot = self._poster_slot_tokens.get(slot)
        def worker():
            try:
                raw_year = item.get("year") or item.get("releaseDate") or item.get("releasedate") or ""
                match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                found = TMDbClient().search_artwork(title, kind, match.group(0) if match else None, required_key="poster_path") or {}
                path = found.get("poster_path") or ""
                if not path:
                    return
                url = path if str(path).startswith(("http://", "https://")) else "https://image.tmdb.org/t/p/w500" + str(path)
                def apply():
                    if (self._poster_artwork_requests.get(slot) != token or
                            self._poster_slot_tokens.get(slot) != expected_slot):
                        return
                    self._loadPoster(slot, url)
                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass
        thread = threading.Thread(target=worker, name="TiviMateFavouriteTMDB")
        thread.daemon = True
        thread.start()

    def _loadPoster(self, slot, url, fallback_record=None):
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        self._poster_artwork_requests[slot] = url
        expected_slot = self._poster_slot_tokens.get(slot)
        def done(path, s=slot, expected=url, record=fallback_record):
            if (self._poster_artwork_requests.get(s) != expected or
                    self._poster_slot_tokens.get(s) != expected_slot):
                return
            if not usable_poster_file(path, minimum_bytes=128):
                if record and record.get("kind") in ("vod", "series"):
                    self._recoverFavouritePoster(s, record)
                return
            self._decodePoster(s, path, record)
        def failed(_path, s=slot, record=fallback_record):
            if (record and record.get("kind") in ("vod", "series") and
                    self._poster_slot_tokens.get(s) == expected_slot and
                    self._poster_artwork_requests.get(s) == url):
                self._recoverFavouritePoster(s, record)

        cached = cached_artwork(url, "posters")
        if cached and usable_poster_file(cached, minimum_bytes=128):
            done(cached)
        else:
            request_artwork(url, "posters", done, priority=85, errback=failed,
                            source=self._favouriteArtworkSource(fallback_record))

    def _circleLiveArtwork(self, path):
        # Enigma Pixmap itself is rectangular, so make the cached Live logo a
        # real transparent circular PNG before ePicLoad decodes it.
        try:
            from PIL import Image, ImageDraw, ImageOps
            out = path + ".tivimate-circle.png"
            try:
                if os.path.exists(out) and os.path.getmtime(out) >= os.path.getmtime(path): return out
            except Exception:
                pass
            im = Image.open(path).convert("RGBA")
            # Keep the complete Live picon visible inside the circular tile.
            # The old ImageOps.fit() centre-cropped wide provider logos (for
            # example Sky Cinema).  Fit the whole image into a transparent
            # square with a small safe margin instead, preserving aspect ratio.
            side = max(96, min(max(im.size), 600))
            inner = max(1, int(side * 0.82))
            im.thumbnail((inner, inner), Image.LANCZOS)
            canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
            left = (side - im.size[0]) // 2
            top = (side - im.size[1]) // 2
            canvas.alpha_composite(im, (left, top))
            mask = Image.new("L", (side, side), 0)
            ImageDraw.Draw(mask).ellipse((1, 1, side-2, side-2), fill=255)
            canvas.putalpha(mask)
            canvas.save(out, "PNG")
            return out
        except Exception:
            return path

    def _decodePoster(self, slot, path, fallback_record=None):
        expected_slot = self._poster_slot_tokens.get(slot)
        expected_request = self._poster_artwork_requests.get(slot)
        if not usable_poster_file(path, minimum_bytes=128):
            if fallback_record and fallback_record.get("kind") in ("vod", "series"):
                self._loadFavouriteTmdbPoster(slot, fallback_record)
            return
        try:
            if self.FILTERS[self.filterIndex][1] == "live":
                path = self._circleLiveArtwork(path)
        except Exception:
            pass
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, current=loader):
            try:
                if (self._poster_slot_tokens.get(s) != expected_slot or
                        self._poster_artwork_requests.get(s) != expected_request):
                    try: self.picloads.remove(current)
                    except (ValueError, AttributeError): pass
                    return
                ptr = current.getData()
                if ptr and self["poster%d" % s].instance:
                    self["poster%d" % s].instance.setPixmap(ptr)
                    try:
                        self._poster_slot_ready[s] = True
                    except Exception:
                        self._poster_slot_ready = {s: True}
                elif fallback_record and fallback_record.get("kind") in ("vod", "series"):
                    self._loadFavouriteTmdbPoster(s, fallback_record)
            except Exception:
                pass
            try:
                if current in self.picloads:
                    self.picloads.remove(current)
            except Exception:
                pass
        try:
            connect_picture_data(loader, ready, self)
        except Exception:
            try:
                loader.PictureData.connect(ready)
            except Exception:
                pass
        try:
            current_kind = self.FILTERS[self.filterIndex][1]
            render_width, render_height = scale_size(130, 130) if current_kind == "live" else scale_size(150, 220)
            loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def _moveSelector(self):
        if not self.records:
            return
        try:
            if self.FILTERS[self.filterIndex][1] == "live":
                colors = ("cyan", "amber", "green", "magenta")
                color = colors[(self.pageStart + self.posterIndex) % len(colors)]
                self["posterSelector"].instance.setPixmapFromFile(
                    "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/favorites_circle/live_focus_%s.png" % color
                )
            if self.FILTERS[self.filterIndex][1] == "live":
                pos = getattr(self, "_liveSlotPositions", {}).get(self.posterIndex)
                if pos:
                    selector_x, selector_y = pos
                else:
                    selector_x, selector_y = self.POSTER_X[self.posterIndex], self.POSTER_Y
            else:
                selector_x, selector_y = self.POSTER_X[self.posterIndex], self.POSTER_Y
            self["posterSelector"].instance.move(ePoint(sx(selector_x - 7), sy(selector_y - 7)))
            self["posterSelector"].show()
        except Exception:
            pass

    def _updateStatus(self):
        total = len(self.records)
        record = self._currentRecord()
        if not record:
            self["status"].setText(tr("No saved items in this filter. Open a title and choose Add to My List."))
            return
        title = self._recordTitle(record)
        kind = self.KIND_LABELS.get(record.get("kind"), "IPTV")
        self["status"].setText("%s  •  %s     %d / %d" % (kind, title, self.pageStart + self.posterIndex + 1, total))

    def _selectFavoriteIndex(self, index):
        if not self.records:
            return
        index = max(0, min(int(index), len(self.records) - 1))
        self.pageStart = (index // self.PAGE_SIZE) * self.PAGE_SIZE
        self.posterIndex = index - self.pageStart
        self.renderPosterPage()

    def _liveLaneIndices(self, package_lane):
        return [i for i, record in enumerate(self.records)
                if bool(record.get("_live_package")) == bool(package_lane)]

    def left(self):
        if getattr(self, "_moveMode", False):
            self._moveFavoriteBy(-1); return
        index = self.pageStart + self.posterIndex
        if self.FILTERS[self.filterIndex][1] == "live":
            record = self._currentRecord()
            lane = self._liveLaneIndices(bool(record and record.get("_live_package")))
            try: pos = lane.index(index)
            except ValueError: pos = -1
            if pos > 0:
                self._selectFavoriteIndex(lane[pos - 1])
            return
        if index > 0:
            self._selectFavoriteIndex(index - 1)

    def right(self):
        if getattr(self, "_moveMode", False):
            self._moveFavoriteBy(1); return
        index = self.pageStart + self.posterIndex
        if self.FILTERS[self.filterIndex][1] == "live":
            record = self._currentRecord()
            lane = self._liveLaneIndices(bool(record and record.get("_live_package")))
            try: pos = lane.index(index)
            except ValueError: pos = -1
            if 0 <= pos < len(lane) - 1:
                self._selectFavoriteIndex(lane[pos + 1])
            return
        if index < len(self.records) - 1:
            self._selectFavoriteIndex(index + 1)

    def up(self):
        if getattr(self, "_moveMode", False):
            self._moveFavoriteBy(-1); return
        index = self.pageStart + self.posterIndex
        if self.FILTERS[self.filterIndex][1] == "live":
            record = self._currentRecord()
            if not record or record.get("_live_package"):
                return
            channels = self._liveLaneIndices(False)
            packages = self._liveLaneIndices(True)
            if not packages:
                return
            try: column = channels.index(index)
            except ValueError: column = 0
            self._selectFavoriteIndex(packages[min(column, len(packages) - 1)])
            return
        if index >= self.PAGE_SIZE:
            self._selectFavoriteIndex(index - self.PAGE_SIZE)

    def down(self):
        if getattr(self, "_moveMode", False):
            self._moveFavoriteBy(1); return
        index = self.pageStart + self.posterIndex
        if self.FILTERS[self.filterIndex][1] == "live":
            record = self._currentRecord()
            if not record or not record.get("_live_package"):
                return
            packages = self._liveLaneIndices(True)
            channels = self._liveLaneIndices(False)
            if not channels:
                return
            try: column = packages.index(index)
            except ValueError: column = 0
            self._selectFavoriteIndex(channels[min(column, len(channels) - 1)])
            return
        if index + self.PAGE_SIZE < len(self.records):
            self._selectFavoriteIndex(index + self.PAGE_SIZE)

    def back(self):
        self._cancelLiveFavouriteDetails()
        if self._liveFolder is not None:
            folder_id = str((self._liveFolder.get("record") or {}).get("id") or "")
            self._liveFolder = None
            self._liveFolderLoading = False
            self._liveFolderToken += 1
            self.reload()
            for index, row in enumerate(self.records):
                if row.get("id") == folder_id:
                    self._selectFavoriteIndex(index)
                    break
            return
        self.close()

    def _liveFolderExclusionKey(self, record):
        return "%s|%s" % (str(record.get("source_id") or ""), str(record.get("category_id") or ""))

    def _liveFolderChannelKey(self, item):
        import hashlib
        raw = json.dumps(item or {}, sort_keys=True, ensure_ascii=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _readLiveFolderExclusions(self):
        path = "/etc/enigma2/tivimatee2_live_favorite_exclusions.json"
        try:
            with open(path, "r") as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except (IOError, OSError, ValueError, TypeError):
            return {}

    def _saveLiveFolderExclusions(self, data):
        path = "/etc/enigma2/tivimatee2_live_favorite_exclusions.json"
        tmp = path + ".tmp"
        try:
            with open(tmp, "w") as handle:
                json.dump(data, handle, sort_keys=True)
                handle.flush()
                os.fsync(handle.fileno())
            os.rename(tmp, path)
            return True
        except Exception:
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass
            return False

    def _openSavedLiveFolder(self, record):
        """Display stored Live channels in one regular yellow Favorites folder.

        The items are ALREADY saved in favorites.json, so there is no server
        request, no replication of user data, and no new folder database.
        """
        if self._liveFolderLoading:
            return
        self._cancelLiveFavouriteDetails()
        self._liveFolder = {"record": dict(record), "saved": True}
        self.records = list(getattr(self, "_savedLiveRecords", ()) or ())
        self.pageStart = 0
        self.posterIndex = 0
        self["list"].setList([(self._recordTitle(row), row) for row in self.records])
        self["title"].setText(tr("LIVE FAVORITES"))
        self._applyFavouriteKindLayout("live")
        self.renderPosterPage()
        if not self.records:
            self["status"].setText(tr("No favorite channels yet. Add channels with the red button."))

    def _openLiveFavoriteFolder(self, record):
        if self._liveFolderLoading:
            return
        source = source_for_record(record, get_sources())
        if not source:
            self.session.open(MessageBox, "This package source no longer exists.", MessageBox.TYPE_INFO)
            return
        self._liveFolderLoading = True
        self._liveFolderToken = int(getattr(self, "_liveFolderToken", 0) or 0) + 1
        folder_token = self._liveFolderToken
        self._liveFolder = {"record": dict(record), "source": source, "token": folder_token}
        try: self["status"].setText(tr("Loading package channels..."))
        except Exception: pass
        cid = str(record.get("category_id") or "")
        title = str(record.get("title") or "Live package")
        def worker():
            rows = []
            try:
                client = get_source_client(source)
                rows, _origin = get_category_streams(source, "live", client, cid, use_cache=True, wait_for_server=True)
                rows = list(rows or [])
                if not rows:
                    rows = [x for x in list(get_filtered_streams(source, "live", client) or []) if str((x or {}).get("category_id") or x.get("group") or "") == cid]
            except Exception:
                rows = []
            def apply():
                if (self._liveFolder is None or
                        int((self._liveFolder or {}).get("token", -1)) != folder_token):
                    return
                self._liveFolderLoading = False
                excluded = set(self._readLiveFolderExclusions().get(self._liveFolderExclusionKey(record), []))
                self.records = [{"id":"folder-channel:%s:%s" % (record.get("id", ""), i), "source_id":record.get("source_id", ""), "kind":"live", "title":str((row or {}).get("name") or (row or {}).get("title") or "IPTV"), "_folder_channel":True, "item":dict(row or {})} for i,row in enumerate(rows) if isinstance(row, dict) and self._liveFolderChannelKey(row) not in excluded]
                self.pageStart = 0; self.posterIndex = 0
                self["list"].setList([(self._recordTitle(x), x) for x in self.records])
                self["title"].setText(tr("LIVE FAVORITES") + "  •  " + title)
                self._applyFavouriteKindLayout("live")
                self.renderPosterPage()
                if not self.records:
                    self["status"].setText(tr("No channels found in this package"))
            try:
                if reactor: reactor.callFromThread(apply)
                else: apply()
            except Exception:
                apply()
        t=threading.Thread(target=worker, name="TiviMateFavouriteFolder"); t.daemon=True; t.start()

    def nextFilter(self):
        self.filterIndex = (self.filterIndex + 1) % len(self.FILTERS)
        self.reload()

    def removeCurrent(self):
        record = self._currentRecord()
        if not record:
            return
        if record.get("_saved_live_folder"):
            # Deleting the folder tile must NEVER delete every saved channel.
            self["status"].setText("Open the Live Favorites folder to remove individual channels.")
            return
        if self._liveFolder is not None and self._liveFolder.get("saved"):
            # Remove only this saved channel from the persistent favorites.json.
            # Keep the folder open and retain the selection after removal.
            if not remove_record(record.get("id", "")):
                self["status"].setText(tr("Unable to remove this Favorite."))
                return
            selected = self.pageStart + self.posterIndex
            self.records.pop(selected)
            self._savedLiveRecords = list(self.records)
            self.pageStart = (max(0, min(selected, len(self.records)-1)) // self.PAGE_SIZE) * self.PAGE_SIZE
            self.posterIndex = max(0, min(selected, len(self.records)-1)) - self.pageStart
            self["list"].setList([(self._recordTitle(row), row) for row in self.records])
            self.renderPosterPage()
            if not self.records:
                self["status"].setText(tr("No channels left in this favorite package"))
            return
        if record.get("_folder_channel") and self._liveFolder is not None:
            folder_record = self._liveFolder.get("record") or {}
            folder_key = self._liveFolderExclusionKey(folder_record)
            channel_key = self._liveFolderChannelKey(record.get("item") or {})
            exclusions = self._readLiveFolderExclusions()
            excluded = set(exclusions.get(folder_key, []))
            excluded.add(channel_key)
            exclusions[folder_key] = sorted(excluded)
            if not self._saveLiveFolderExclusions(exclusions):
                self["status"].setText(tr("Unable to remove this Favorite."))
                return
            selected = self.pageStart + self.posterIndex
            self.records.pop(selected)
            selected = min(selected, len(self.records) - 1)
            self.pageStart = max(0, (selected // self.PAGE_SIZE) * self.PAGE_SIZE)
            self.posterIndex = max(0, selected - self.pageStart)
            self["list"].setList([(self._recordTitle(x), x) for x in self.records])
            self.renderPosterPage()
            if not self.records:
                self["status"].setText(tr("No channels left in this favorite package"))
            return
        if record.get("_media_package"):
            marker_file = favorites_path("media_package_favorites.json")
            marker_key = "%s|%s|%s" % (record.get("source_id", ""), record.get("kind", ""), record.get("category_id", ""))
            try:
                with open(marker_file, "r") as h: markers = json.load(h) or {}
                markers.pop(marker_key, None)
                tmp = marker_file + ".tmp"
                with open(tmp, "w") as h: json.dump(markers, h, sort_keys=True)
                os.rename(tmp, marker_file)
                self.reload(); return
            except Exception:
                self["status"].setText(tr("Unable to remove this Favorite.")); return
        if record.get("_live_package"):
            marker_file = favorites_path("live_package_favorites.json")
            marker_key = "%s|%s" % (record.get("source_id", ""), record.get("category_id", ""))
            try:
                with open(marker_file, "r") as h: markers = json.load(h) or {}
                marker = markers.get(marker_key)
                owned = marker.get("owned", []) if isinstance(marker, dict) else (marker or [])
                # Remove only legacy rows created by the old expand-package action.
                for saved in list_favourites("live"):
                    item = saved.get("item") or {}
                    xid = str(item.get("stream_id") or item.get("id") or item.get("url") or item.get("cmd") or "")
                    if saved.get("source_id") == record.get("source_id") and xid in set(str(x) for x in owned):
                        remove_record(saved.get("id", ""))
                markers.pop(marker_key, None)
                tmp = marker_file + ".tmp"
                with open(tmp, "w") as h: json.dump(markers, h, sort_keys=True)
                os.rename(tmp, marker_file)
                self.reload(); return
            except Exception:
                self["status"].setText(tr("Unable to remove this Favorite.")); return
        if remove_record(record.get("id", "")):
            self.reload()
        else:
            self["status"].setText(tr("Unable to remove this Favorite."))

    def openCurrent(self):
        if getattr(self, "_moveMode", False):
            self._finishFavoriteMove(); return
        record = self._currentRecord()
        if not record:
            return
        # The all-channels Favorites folder is a local view, not a provider
        # category; it must work even when its channels use different servers.
        if record.get("_saved_live_folder"):
            self._openSavedLiveFolder(record)
            return
        source = source_for_record(record, get_sources())
        if not source:
            self.session.open(MessageBox, "This item's source no longer exists. Press RED to remove it.", MessageBox.TYPE_INFO); return
        if record.get("_live_package"):
            self._openLiveFavoriteFolder(record); return
        if record.get("_media_package"):
            cid = str(record.get("category_id") or "")
            title = str(record.get("title") or "")
            self.session.open(MediaScreen, source, record.get("kind"), cid, title); return
        item = dict(record.get("item") or {})
        kind = record.get("kind")
        # A saved Genre is one Favorite tile, not a media item. Re-run the
        # same Genre query when opened so its contents stay current.
        if str(item.get("_genre_favorite") or "") == "1":
            try:
                genre_kind = "series" if str(item.get("_genre_kind") or kind) == "series" else "vod"
                genre_index = int(item.get("_genre_index") or 0)
                # Run the saved Genre query without opening the Genre selector.
                # Keep Favorites visible while the cache/server query runs; MediaScreen
                # is the first screen the user sees after selecting the shortcut.
                genre_dialog = self.session.instantiateDialog(MovieGenresScreen, dict(source), genre_kind, genre_index, False)
                genre_dialog._directGenreFavorite = True
                genre_dialog.choose()
            except Exception as exc:
                self.session.open(MessageBox, "Unable to open Genre Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)
            return
        try:
            if kind == "live":
                if self._liveFolder is not None and self._liveFolder.get("saved"):
                    # Mixed-server saved channels: the player already supports
                    # _favorite_source on each in-memory row for safe zapping.
                    # Never persist credentials in the favorites file.
                    sources = get_sources()
                    live_items = []
                    current_index = None
                    for row in self.records:
                        owner = source_for_record(row, sources)
                        if not owner:
                            continue
                        channel = dict(row.get("item") or {})
                        channel["_favorite_source"] = owner
                        if row is record:
                            current_index = len(live_items)
                        live_items.append(channel)
                    if current_index is None:
                        self.session.open(MessageBox, "The saved channel's server is unavailable.", MessageBox.TYPE_INFO)
                        return
                    self.session.open(TiviMateLivePlayer, source, live_items, current_index, False, True)
                    return
                if record.get("_folder_channel") and self._liveFolder is not None:
                    live_items = [dict(x.get("item") or {}) for x in self.records if x.get("_folder_channel")]
                    current_index = max(0, min(len(live_items)-1, self.pageStart + self.posterIndex))
                    self.session.open(TiviMateLivePlayer, source, live_items, current_index, False, True); return
                self.session.open(TiviMateLivePlayer, source, [item], 0, False, True); return
            if kind == "series":
                if source.get("type") != "xtream":
                    raise Exception("Series require an Xtream Codes source")
                item["_favorite_exit_stop"] = True
                self.session.open(SeriesDetailsScreen, source, item); return
            def _open_vod(url, item=item, source=source):
                item["_favorite_exit_stop"] = True
                service_type = int(_media_service_type(source, "vod"))
                service = eServiceReference(service_type, 0, url)
                service.setName(item.get("name") or item.get("title") or "IPTV")
                self.session.open(TiviMatePlayer, service, item)
            if source.get("type") == "xtream":
                url = XtreamClient(source).stream_url(item, "vod")
            elif source.get("type") in ("m3u", "fg"):
                url = item.get("url", "")
            else:
                # Stalker: portal login + create_link off the GUI thread.
                src = dict(source)

                def done(url):
                    if not url:
                        self.session.open(MessageBox, "Unable to open Favorite:\nNo playable URL", MessageBox.TYPE_ERROR)
                        return
                    _open_vod(url)

                def failed(exc):
                    self.session.open(MessageBox, "Unable to open Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)
                from .bg_resolve import resolve_async
                resolve_async(lambda: StalkerClient(src).stream_url(item, "vod"), done, failed)
                return
            if not url:
                raise Exception("No playable URL")
            _open_vod(url); return
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open Favorite:\n%s" % exc, MessageBox.TYPE_ERROR)
