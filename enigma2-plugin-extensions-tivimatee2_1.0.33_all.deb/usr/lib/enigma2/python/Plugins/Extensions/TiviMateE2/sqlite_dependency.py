# -*- coding: utf-8 -*-
"""Handle optional Python sqlite3 packages on lean Enigma2 images.

The package manager installs Recommends when possible.  If a receiver image
omits it, try once when TiviMate opens (never inside opkg's postinst and never
on Enigma2 boot). The subprocess is asynchronous on the Enigma GUI loop.
"""
import shutil

_INSTALL_PROCESS = None
_INSTALL_ATTEMPTED = False


def sqlite_ready():
    """Check the actual sqlite extension, not merely an importable wrapper."""
    try:
        import sqlite3
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("SELECT 1").fetchone()
        finally:
            conn.close()
        return True
    except Exception:
        return False


def _notice(session, message, error=False):
    try:
        from Screens.MessageBox import MessageBox
        mtype = MessageBox.TYPE_ERROR if error else MessageBox.TYPE_INFO
        session.open(MessageBox, message, type=mtype, timeout=12 if not error else 0)
    except Exception:
        pass


def _stage(session, phase):
    global _INSTALL_PROCESS
    try:
        from enigma import eConsoleAppContainer
        proc = eConsoleAppContainer()
        _INSTALL_PROCESS = proc  # prevent GC while process is active

        def _finished(ret):
            global _INSTALL_PROCESS
            _INSTALL_PROCESS = None
            try:
                returncode = int(ret)
            except Exception:
                returncode = 1
            if sqlite_ready():
                _notice(session, "SQLite installed successfully. Open TiviMate E2 again.")
                return
            if phase == "install":
                # A new image may have no package lists until opkg update.
                _stage(session, "refresh")
                return
            if phase == "refresh" and returncode == 0:
                _stage(session, "retry")
                return
            _notice(session,
                    "TiviMate E2 cannot start because Python SQLite is missing.\n"
                    "Automatic install failed or the image does not provide python3-sqlite3.\n"
                    "Check the image's package feeds and install python3-sqlite3.",
                    error=True)

        try:
            proc.appClosed.append(_finished)
        except Exception:
            proc.appClosed.get().append(_finished)
        opkg_bin = shutil.which('opkg')
        if not opkg_bin:
            _INSTALL_PROCESS = None
            _notice(session, "opkg is no longer available on this image.", error=True)
            return False
        import shlex
        if phase == "refresh":
            command = shlex.quote(opkg_bin) + " update"
        else:
            command = shlex.quote(opkg_bin) + " install python3-sqlite3"
        # Return immediately; a broken feed never blocks the Enigma2 UI.
        try:
            rc = proc.execute('/bin/sh', 'sh', '-c', command)
        except (TypeError, AttributeError):
            rc = proc.execute(command)
        if rc not in (0, None, True):
            _INSTALL_PROCESS = None
            _notice(session, "Unable to start SQLite installation. Check opkg on the receiver.", error=True)
            return False
        return True
    except Exception:
        _INSTALL_PROCESS = None
        _notice(session, "Automatic SQLite installation could not start on this image.", error=True)
        return False


def ensure_sqlite(session):
    """True if it is safe to open the full UI, False otherwise."""
    global _INSTALL_ATTEMPTED
    if sqlite_ready():
        return True
    if _INSTALL_PROCESS is not None:
        _notice(session, "Installing Python SQLite in the background. Please check again shortly.")
        return False
    if _INSTALL_ATTEMPTED:
        _notice(session,
                "SQLite is still missing. Automatic installation was already tried.\n"
                "Check package feeds for python3-sqlite3 and reopen TiviMate E2.",
                error=True)
        return False
    _INSTALL_ATTEMPTED = True
    if not shutil.which('opkg'):
        _notice(session, "SQLite is missing and this image has no opkg package manager.", error=True)
        return False
    _notice(session, "Python SQLite is missing. TiviMate E2 is trying to install it automatically.")
    _stage(session, 'install')
    return False


# ---------------------------------------------------------------------------
# Optional image packages (Pillow + SQLite).
# OpenPLi and other lean images do not ship Pillow / sqlite3 by default.
# Without Pillow the plugin cannot build circular posters/channels, actor
# circles or fitted transparent logos (black boxes instead); without sqlite3
# the UltraStalker store is unavailable. When TiviMate opens, missing ones
# are installed ONCE per boot in the background (never in postinst, never
# blocking the GUI); the user is asked to restart the GUI afterwards.
# ---------------------------------------------------------------------------
_OPTIONAL_FLAG = "/tmp/.tivimatee2_optional_packages_tried_v2"
_OPTIONAL_PROCESS = [None]


def _pillow_ready():
    try:
        from PIL import Image  # noqa: F401
        return True
    except Exception:
        return False


def _module_ready(name):
    try:
        __import__(name)
        return True
    except Exception:
        return False


def missing_optional_packages():
    missing = []
    if not _pillow_ready():
        missing.append("python3-pillow")
    if not sqlite_ready():
        missing.append("python3-sqlite3")
    # TiviMate Subtitles (blue key): requests, six and BeautifulSoup.
    try:
        import requests as _requests
        real_requests = not getattr(_requests, "_tivimate_compat", False)
    except Exception:
        real_requests = False
    if not real_requests:
        # The built-in stand-in keeps Stalker working meanwhile.
        missing.append("python3-requests")
    if not _module_ready("six"):
        missing.append("python3-six")
    if not _module_ready("bs4"):
        missing.append("python3-beautifulsoup4")
    return missing


def ensure_optional_packages(session):
    """Start a one-time background opkg install for missing packages."""
    import os
    try:
        if _OPTIONAL_PROCESS[0] is not None or os.path.exists(_OPTIONAL_FLAG):
            return
        missing = missing_optional_packages()
        if not missing:
            return
        opkg_bin = shutil.which("opkg")
        if not opkg_bin:
            return
        try:
            open(_OPTIONAL_FLAG, "w").close()
        except Exception:
            pass
        import shlex
        from enigma import eConsoleAppContainer
        pkgs = " ".join(shlex.quote(name) for name in missing)
        opkg = shlex.quote(opkg_bin)
        # Try the existing package lists first; refresh them only if needed.
        command = "%s install %s || { %s update && %s install %s; }" % (opkg, pkgs, opkg, opkg, pkgs)
        proc = eConsoleAppContainer()
        _OPTIONAL_PROCESS[0] = proc

        def _finished(ret):
            _OPTIONAL_PROCESS[0] = None
            still = missing_optional_packages()
            if not still:
                _notice(session, "TiviMate E2 installed %s.\nPlease restart the GUI (Menu > Standby > Restart GUI) to enable circular posters, transparent logos, Stalker and subtitles." % ", ".join(missing))
            else:
                _notice(session, "TiviMate E2 could not install %s from the image feed.\nInstall it from the image's software manager (needed for circular posters, transparent logos, Stalker and subtitles)." % ", ".join(still), error=True)
        try:
            proc.appClosed.append(_finished)
        except Exception:
            proc.appClosed.get().append(_finished)
        try:
            rc = proc.execute("/bin/sh", "sh", "-c", command)
        except (TypeError, AttributeError):
            rc = proc.execute(command)
        if rc not in (0, None, True):
            _OPTIONAL_PROCESS[0] = None
    except Exception:
        _OPTIONAL_PROCESS[0] = None
