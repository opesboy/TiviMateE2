# -*- coding: utf-8 -*-
from .storage import get_data_root, data_path
import json
import os

LANG_FILE = data_path("language.json")
SUPPORTED = ("en", "ar", "fr", "tr")

_TRANSLATIONS = {
    "tr": {
        "More Info": "Daha fazla bilgi",
        "Server Finder":"Sunucu Bulucu", "Search":"Ara", "Home":"Ana Sayfa", "Live":"Canlı", "Movies":"Filmler", "TV Shows":"Diziler", "Packages":"Paketler", "Settings":"Ayarlar",
        "Favorite":"Favori", "Favorites":"Favoriler", "English":"English", "Arabic":"العربية", "French":"Français", "Turkish":"Türkçe",
        "APPLICATION LANGUAGE":"UYGULAMA DİLİ", "ONLINE":"ÇEVRİMİÇİ", "IN USE":"KULLANIMDA", "OFFLINE":"ÇEVRİMDIŞI",
        "LIVE TV":"CANLI TV", "MOVIES":"FİLMLER", "TV SHOWS":"DİZİLER", "PACKAGES":"PAKETLER", "CONTENT":"İÇERİK",
        "Recently Added":"Son Eklenenler", "Continue Watching":"İzlemeye Devam Et", "Select a package":"Paket seç", "Select a category":"Kategori seç",
        "":"Paketler yükleniyor...", "":"Kategoriler yükleniyor...", "MOVIE CATEGORIES":"FİLM KATEGORİLERİ",
        "TV SHOW CATEGORIES":"DİZİ KATEGORİLERİ", "Developed by Opesboy":"Opesboy tarafından geliştirildi",
        "Language saved. Reopen the app to apply it.":"Dil kaydedildi. Uygulamak için uygulamayı yeniden açın.",
        "Unable to save settings.":"Ayarlar kaydedilemedi.", "No server selected • Press SETTINGS":"Sunucu seçilmedi • AYARLAR'a basın",
        "Movies You Might Like":"Beğenebileceğiniz Filmler", "TV Shows You Might Like":"Beğenebileceğiniz Diziler",
        "Popular Movies":"Popüler Filmler", "Popular Show":"Popüler İçerik", "Popular TV Shows":"Popüler Diziler", "More info":"Daha fazla bilgi", "Play":"Oynat",
        "Back":"Geri", "Select":"Seç", "Server":"Sunucu", "Servers":"Sunucular", "Backup":"Yedek", "Restore":"Geri Yükle",
        "Subtitle":"Altyazı", "Subtitles":"Altyazılar", "Cache":"Önbellek", "Refresh":"Yenile", "Delete":"Sil", "Save":"Kaydet"
    },
    "ar": {
        "More Info": "معلومات أكثر",
        "Server Finder": "بحث السيرفرات", "Resume": "متابعة المشاهدة", "GENRE": "التصنيفات",
        'Name': 'الاسم',
        'Rating': 'التقييم',
        'Date': 'التاريخ',
        "Search": "بحث", "Home": "الرئيسية", "Live": "البث المباشر", "Movies": "الأفلام",
        "TV Shows": "المسلسلات", "Packages": "الباقات", "Settings": "الإعدادات", "Favorite": "المفضلة", "Favorites": "المفضلة",
        "CONTROL CENTER": "مركز التحكم", "SETTINGS  •  SERVER MANAGER": "الإعدادات  •  إدارة السيرفرات",
        "Manage playlists,\nconnections and metadata,\nand appearance settings.": "إدارة القوائم،\nالاتصالات والبيانات،\nوإعدادات المظهر.",
        "Use the colour keys below\nfor quick actions.": "استخدم الأزرار الملونة أدناه\nللإجراءات السريعة.",
        "APPLICATION LANGUAGE": "لغة التطبيق", "English": "English", "Arabic": "العربية", "French": "Français",
        "SERVER STATUS  •  CONNECTION & ACTIVE USE": "حالة السيرفر  •  الاتصال والاستخدام",
        "Yellow appears only when the server reports active use.": "يظهر اللون الأصفر فقط عند وجود استخدام نشط.",
        "ONLINE": "متصل", "IN USE": "قيد الاستخدام", "OFFLINE": "غير متصل",
        "Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates.": "اضغط 5 لإعدادات SUBDL والترجمة. واضغط 3 للتحديثات.",
        "RED - Edit Subtitles": "الأحمر - تعديل الترجمة",
        "↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles": "↑↓ تغيير   MENU محرك التشغيل   الأزرق SubsSupport   الأحمر تعديل الترجمة",
        "Edit Subtitles": "تعديل الترجمة", "Select a package": "اختر باقة", "Select a category": "اختر تصنيفًا",
        "": "جاري تحميل الباقات...", "": "جاري تحميل التصنيفات...",
        "LIVE TV": "التلفاز المباشر", "MOVIES": "الأفلام", "TV SHOWS": "المسلسلات",
        "MOVIE CATEGORIES": "تصنيفات الأفلام", "TV SHOW CATEGORIES": "تصنيفات المسلسلات",
        "PACKAGES": "الباقات", "CONTENT": "المحتوى", "Recently Added": "المضاف حديثا", "Continue Watching": "متابعة المشاهدة",
        "Popular Movies": "الأفلام الشائعة", "Popular Show": "المحتوى الشائع", "Popular TV Shows": "المسلسلات الشائعة",
        "Trending Movies": "الأفلام الرائجة", "Trending TV Shows": "المسلسلات الرائجة",
        "Movies You Might Like": "أفلام قد تعجبك", "TV Shows You Might Like": "مسلسلات قد تعجبك",
        "Recent Added Movies": "الأفلام المضافة حديثا", "Recent Added TV Shows": "المسلسلات المضافة حديثا",
        "RECENTLY ADDED": "المضاف حديثا", "FAVORITES": "المفضلة", "WATCH NOW": "شاهد الآن",
        "NOW": "الآن", "NEXT": "التالي", "Play": "تشغيل", "Add to My List": "أضف إلى قائمتي",
        "Movies  0": "الأفلام  0", "Shows  0": "المسلسلات  0",
        "Search for a channel, movie or series...": "ابحث عن قناة أو فيلم أو مسلسل...",
        "Press OK to start searching": "اضغط OK لبدء البحث", "YOUR SAVED CONTENT": "المحتوى المحفوظ",
        "ALL": "الكل", "LIVE": "مباشر", "SERIES": "مسلسلات", "MOVIE": "فيلم",
        "ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES": "الأسهم لاختيار الملصق  •  اضغط الأصفر مطولًا لإضافة فيلم أو مسلسل إلى المفضلة",
        "BLUE  CHANGE STYLE": "الأزرق  تغيير النمط",
        "Unable to save settings.": "تعذر حفظ الإعدادات.",
        "Language saved. Reopen the app to apply it.": "تم حفظ اللغة. أعد فتح التطبيق لتطبيقها.",
        "ADD A SOURCE": "إضافة مصدر", "ADD IPTV SOURCE": "إضافة مصدر IPTV", "UPDATE PLAYLIST": "تحديث القائمة", "EXIT": "خروج", "Choose the type of IPTV connection": "اختر نوع اتصال IPTV",
        "STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS": "بوابة STALKER  •  مباشر وأفلام ومسلسلات",
        "ADD XTREAM CODES PLAYLIST": "إضافة قائمة XTREAM CODES", "TMDb TRENDING SETTINGS": "إعدادات TMDb",
        "SERVER CONTENT FILTER": "تصفية محتوى السيرفر", "IMAGE CACHE": "ذاكرة الصور المؤقتة",
        "HOME APPEARANCE": "مظهر الرئيسية", "SOFTWARE UPDATES": "تحديثات البرنامج",
        "SUBDL SUBTITLE LANGUAGE": "لغة ترجمة SUBDL", "Download SubDL subtitles in": "تنزيل ترجمة SUBDL باللغة",
        "": "جاري التحميل...", "No results": "لا توجد نتائج", "Back": "رجوع",
        "Previous Category": "التصنيف السابق", "Next Category": "التصنيف التالي", "Remove from My List": "إزالة من قائمتي", "Filter": "تصفية", "No EPG data": "لا توجد بيانات EPG",
        'TiViMate': 'TiViMate',
        'IPTV EXPERIENCE': 'تجربة IPTV',
        'OK  KEYBOARD    GREEN  SAVE    RED  CANCEL': 'OK لوحة المفاتيح    الأخضر حفظ    الأحمر إلغاء',
        'Stalker requires your own Portal URL and MAG MAC address. No portal is included.': 'يتطلب Stalker رابط البوابة وعنوان MAG MAC الخاصين بك. لا توجد بوابة مرفقة.',
        'OK SELECT    EXIT BACK': 'OK اختيار    EXIT رجوع',
        'Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate.': 'أدخل رابط البوابة وعنوان MAG MAC الخاصين بك. لا توجد بوابة أو حساب مرفق مع TiViMate.',
        'Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server.': 'أدخل مفتاح TMDb API. تأتي بيانات الرائج من TMDb، بينما يستخدم التشغيل السيرفر المحدد.',
        'OK KEYBOARD    GREEN SAVE    RED CANCEL': 'OK لوحة المفاتيح    الأخضر حفظ    الأحمر إلغاء',
        'Load only the categories you need to keep lists, search, and images fast.': 'حمّل التصنيفات التي تحتاجها فقط للحفاظ على سرعة القوائم والبحث والصور.',
        'LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK': 'يمين/يسار القسم    OK تبديل    الأخضر حفظ    الأصفر تحديد الكل    الأزرق مسح الكل    EXIT رجوع',
        'GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK': 'الأخضر حفظ    الأزرق مسح الكاش    الأصفر تنظيف    EXIT رجوع',
        'Changes apply to the Home screen only. Restart the app after saving.': 'تُطبّق التغييرات على الشاشة الرئيسية فقط. أعد فتح التطبيق بعد الحفظ.',
        'GREEN  SAVE    RED  BACK': 'الأخضر حفظ    الأحمر رجوع',
        'Automatic checks only read a small verified update manifest. Press YELLOW to check now.': 'تقرأ عملية التحقق التلقائي ملف تحديث صغيرًا وموثوقًا فقط. اضغط الأصفر للتحقق الآن.',
        'GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK': 'الأخضر حفظ    الأصفر تحقق الآن    الأحمر رجوع',
        'Checking for a verified update...': 'جارٍ التحقق من تحديث موثوق...',
        'Downloading and verifying the update package...': 'جارٍ تنزيل حزمة التحديث والتحقق منها...',
        'Installing TiViMate E2 update...': 'جارٍ تثبيت تحديث TiViMate E2...',
        'This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager.': 'تُستخدم هذه اللغة مع زر SubDL الأصفر. استورد مفتاح SubDL API بشكل منفصل من إدارة السيرفرات.',
        'Searching...': 'جارٍ البحث...',
        'TiViMate IPTV EXPERIENCE': 'تجربة TiViMate IPTV',
        'Live TV  •  Movies  •  Series  •  beIN SPORTS': 'البث المباشر  •  الأفلام  •  المسلسلات  •  beIN SPORTS',
        'TIVIMATE  •  PREMIUM IPTV': 'TIVIMATE  •  IPTV مميز',
        'YOUR ENTERTAINMENT, ONE PLACE': 'ترفيهك في مكان واحد',
        'Browse, discover and enjoy your library in one unified experience.': 'تصفح واكتشف واستمتع بمكتبتك في تجربة موحدة.',
        'Choose a section. Heavy image downloads are disabled in this build for stability.': 'اختر قسمًا. تم تعطيل تنزيل الصور الثقيلة في هذه النسخة لضمان الاستقرار.',
        'OK Open    EXIT Back': 'OK فتح    EXIT رجوع',
        '': 'جارٍ تحميل معلومات المسلسل...',
        'LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back': 'يمين/يسار الحلقات    أعلى/أسفل تغيير الموسم    OK تشغيل    الأحمر مفضلة    EXIT رجوع',
        'LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back': 'يمين/يسار تنقل    أعلى/أسفل صفحات    OK اختيار    الأحمر التصنيف السابق    الأزرق التصنيف التالي    MENU المفضلة    الأخضر الباقات/التصنيفات    الأصفر ترتيب    EXIT رجوع',
        '': 'جارٍ تحميل القنوات المضافة حديثًا...',
        'Channel changed': 'تم تغيير القناة',
        'No content': 'لا يوجد محتوى',
        'Name': 'الاسم',
        'Rating': 'التقييم',
        'Playlist Name': 'اسم القائمة',
        'Protocol': 'البروتوكول',
        'Server URL': 'رابط السيرفر',
        'Port': 'المنفذ',
        'Username': 'اسم المستخدم',
        'Password': 'كلمة المرور',
        'Stream Format': 'صيغة البث',
        'EPG Time Offset': 'إزاحة توقيت EPG',
        '★ TMDb Poster in Live': '★ بوستر TMDb في البث المباشر',
        'Portal Name': 'اسم البوابة',
        'Portal URL': 'رابط البوابة',
        'MAG MAC Address': 'عنوان MAG MAC',
        'TMDb API Key': 'مفتاح TMDb API',
        'Metadata language': 'لغة البيانات',
        'Cache Location': 'موقع الكاش',
        'Maximum Size': 'الحجم الأقصى',
        'Delete Images Older Than': 'حذف الصور الأقدم من',
        'Home Skin': 'مظهر الرئيسية',
        'Automatic update check': 'التحقق التلقائي من التحديثات',
        'Update download failed.': 'فشل تنزيل التحديث.',
        'The verified package could not be installed.': 'تعذر تثبيت الحزمة الموثوقة.',
        'Update completed. Restart the Enigma2 GUI to use the new version.': 'اكتمل التحديث. أعد تشغيل واجهة Enigma2 لاستخدام النسخة الجديدة.',
        'The update installer returned an error.': 'أعاد مُثبت التحديث خطأً.',
        'Unable to save favorite': 'تعذر حفظ المفضلة',
        'Item is already in favorites': 'العنصر موجود بالفعل في المفضلة',
        'Added to favorites': 'تمت الإضافة إلى المفضلة',
        'Removed from favorites': 'تمت الإزالة من المفضلة',
        'Unable to remove this Favorite.': 'تعذرت إزالة هذا العنصر من المفضلة.',
        'No server selected • Press SETTINGS': 'لا يوجد سيرفر محدد • اضغط الإعدادات',
        'No seasons': 'لا توجد مواسم',
        '': 'جارٍ تحميل الباقات والتصنيفات...',
        'Open a package, select a channel, then press RED': 'افتح باقة وحدد قناة ثم اضغط الأحمر',
        'Select a movie or TV show first': 'حدد فيلمًا أو مسلسلًا أولًا',
        'Preparing series categories in the background...': 'جارٍ تجهيز تصنيفات المسلسلات في الخلفية...',
        'Select a series category': 'اختر تصنيف المسلسلات',
        'Select the category then press OK. Only this category will be loaded.': 'اختر التصنيف ثم اضغط OK. سيتم تحميل هذا التصنيف فقط.',
        'No favorite channels yet. Add channels with the red button.': 'لا توجد قنوات مفضلة بعد. أضف القنوات بالزر الأحمر.',
        'Select a series category then press OK.': 'اختر تصنيف المسلسلات ثم اضغط OK.',
        'No categories available.': 'لا توجد تصنيفات متاحة.',
        'The category is preparing in the background... the interface will not freeze.': 'يجري تجهيز التصنيف في الخلفية... لن تتجمد الواجهة.',
        'Stalker returned no packages. Check Portal URL and MAG MAC, then retry.': 'لم يُرجع Stalker أي باقات. تحقق من رابط البوابة وعنوان MAG MAC ثم أعد المحاولة.',
        'Stalker returned no items for this package. Try another package or refresh the source.': 'لم يُرجع Stalker محتوى لهذه الباقة. جرّب باقة أخرى أو حدّث المصدر.',
        'No saved items in this filter. Open a title and choose Add to My List.': 'لا توجد عناصر محفوظة في هذا الفلتر. افتح عنوانًا واختر أضف إلى قائمتي.',
        'YOUR LIBRARY': 'مكتبتك',
        'Choose a collection\nto browse titles from\nyour selected server.': 'اختر مجموعة\nلتصفح العناوين من\nالسيرفر المحدد.',
        'Press OK to open': 'اضغط OK للفتح',
        'Browse the collections available on your server': 'تصفح المجموعات المتاحة على سيرفرك',
        '': 'جارٍ تحميل المجموعات',
        'AVAILABLE COLLECTIONS': 'المجموعات المتاحة',
        '': 'جارٍ تحميل التفاصيل...',
        '▶  Watch': '▶  مشاهدة',
        'Other Sources': 'مصادر أخرى',
        'Actors': 'الممثلون',
        'Recommendations': 'اقتراحات',
        'OK Play     EXIT Back': 'OK تشغيل     EXIT رجوع',
        'UNABLE TO LOAD CATEGORIES': 'تعذر تحميل التصنيفات',
        'Check the selected server and try again': 'تحقق من السيرفر المحدد وحاول مرة أخرى',
        'NO COLLECTIONS': 'لا توجد مجموعات',
        'No enabled collections are available for this server': 'لا توجد مجموعات مفعلة لهذا السيرفر',
        '': 'يجري تحميل التصنيفات. حاول مجددًا بعد قليل.',
        'No enabled categories are available for this library.': 'لا توجد تصنيفات مفعلة لهذه المكتبة.',
        "Today's Trending Movies": 'أفلام اليوم الرائجة',
        "Today's Trending Series": 'مسلسلات اليوم الرائجة',
        'Latest Movies': 'أحدث الأفلام',
        'Latest Series': 'أحدث المسلسلات',
        'Latest Movies & TV Shows': 'أحدث الأفلام والمسلسلات',
        'Latest TV Shows': 'أحدث المسلسلات',
        '%d Home picks': '%d اختيارات للرئيسية',
        '%d recent TV shows': '%d مسلسلات حديثة',
        '%d recent movies': '%d أفلام حديثة',
        'Server: %s  •  %s': 'السيرفر: %s  •  %s',
        'Use OK to enter characters. GREEN saves. RED or EXIT cancels.': 'استخدم OK لإدخال الأحرف. الأخضر للحفظ. الأحمر أو EXIT للإلغاء.',
        'OK: Edit key   YELLOW: Import /tmp/tivimatee2/key.txt   GREEN: Save   EXIT: Close': 'OK تعديل المفتاح   الأصفر استيراد /tmp/tivimatee2/key.txt   الأخضر حفظ   EXIT إغلاق',
        'SubDL API Key  (OK to edit)': 'مفتاح SubDL API  (OK للتعديل)',
        'Default Subtitle Language': 'لغة الترجمة الافتراضية',
        'Default Subtitle Type': 'نوع الترجمة الافتراضي',
        'Developed by Opesboy': 'تطوير Opesboy',
        'Downloading TiviMate E2 update...': 'جارٍ تنزيل تحديث TiviMate E2...',
        'Installing TiviMate E2 update...': 'جارٍ تثبيت تحديث TiviMate E2...',
        'Press OK again to open the search keyboard': 'اضغط OK مرة أخرى لفتح لوحة البحث',
        'Stalker packages are ready. Open Categories and select a package to load its titles.': 'باقات Stalker جاهزة. افتح التصنيفات واختر باقة لتحميل محتواها.',
        'TiViMate E2 is already up to date.': 'TiViMate E2 محدث بالفعل.',
        'TiviMate E2': 'TiviMate E2',
        'Unable to start the update installer.': 'تعذر بدء مثبت التحديث.',
        'Unable to verify updates right now. You can try again later.': 'تعذر التحقق من التحديثات الآن. حاول لاحقًا.',
        'Select a movie poster first': 'حدد بوستر فيلم أولًا',
        'Movie is already in favorites': 'الفيلم موجود بالفعل في المفضلة',
        'Movie added to favorites': 'تمت إضافة الفيلم إلى المفضلة',
        'Series is already in favorites': 'المسلسل موجود بالفعل في المفضلة',
        'Series added to favorites': 'تمت إضافة المسلسل إلى المفضلة',
        'This title is not available on the server and cannot be added to favorites': 'هذا العنوان غير موجود على السيرفر ولا يمكن إضافته إلى المفضلة',
    },
    "fr": {
        "More Info": "Plus d’infos",
        "Server Finder": "Recherche de serveurs",
        'Name': 'Nom',
        'Rating': 'Note',
        'Date': 'Date',
        "Continue Watching": "Continuer à regarder",
        "Popular Movies": "Films populaires", "Popular Show": "Contenu populaire", "Popular TV Shows": "Séries populaires",
        "Trending Movies": "Films tendance", "Trending TV Shows": "Séries tendance",
        "Movies You Might Like": "Films qui pourraient vous plaire", "TV Shows You Might Like": "Séries qui pourraient vous plaire",
        "Recent Added Movies": "Films ajoutés récemment", "Recent Added TV Shows": "Séries ajoutées récemment",
        "Search": "Recherche", "Home": "Accueil", "Live": "Direct", "Movies": "Films",
        "TV Shows": "Séries", "Packages": "Bouquets", "Settings": "Paramètres", "Favorite": "Favoris", "Favorites": "Favoris",
        "CONTROL CENTER": "CENTRE DE CONTRÔLE", "SETTINGS  •  SERVER MANAGER": "PARAMÈTRES  •  GESTION DES SERVEURS",
        "Manage playlists,\nconnections and metadata,\nand appearance settings.": "Gérez les listes,\nles connexions, les métadonnées\net l’apparence.",
        "Use the colour keys below\nfor quick actions.": "Utilisez les touches colorées\npour les actions rapides.",
        "APPLICATION LANGUAGE": "LANGUE DE L’APPLICATION", "English": "English", "Arabic": "العربية", "French": "Français",
        "SERVER STATUS  •  CONNECTION & ACTIVE USE": "ÉTAT DU SERVEUR  •  CONNEXION ET UTILISATION",
        "Yellow appears only when the server reports active use.": "Le jaune apparaît uniquement lorsque le serveur signale une utilisation active.",
        "ONLINE": "EN LIGNE", "IN USE": "UTILISÉ", "OFFLINE": "HORS LIGNE",
        "Press 5 SUBDL for API key import, subtitle language or font. Press 3 for Updates.": "Appuyez sur 5 pour SUBDL et les sous-titres. Appuyez sur 3 pour les mises à jour.",
        "RED - Edit Subtitles": "ROUGE - Modifier les sous-titres",
        "↑↓ Change   MENU Player Engine   BLUE SubsSupport   RED Edit Subtitles": "↑↓ Changer   MENU Moteur   BLEU SubsSupport   ROUGE Modifier les sous-titres",
        "Edit Subtitles": "Modifier les sous-titres", "Select a package": "Choisir un bouquet", "Select a category": "Choisir une catégorie",
        "": "Chargement des bouquets...", "": "Chargement des catégories...",
        "LIVE TV": "TV EN DIRECT", "MOVIES": "FILMS", "TV SHOWS": "SÉRIES",
        "MOVIE CATEGORIES": "CATÉGORIES DE FILMS", "TV SHOW CATEGORIES": "CATÉGORIES DE SÉRIES",
        "PACKAGES": "BOUQUETS", "CONTENT": "CONTENU", "Recently Added": "Ajoutés récemment",
        "RECENTLY ADDED": "AJOUTÉS RÉCEMMENT", "FAVORITES": "FAVORIS", "WATCH NOW": "REGARDER",
        "NOW": "EN COURS", "NEXT": "À SUIVRE", "Play": "Lire", "Add to My List": "Ajouter à ma liste",
        "Movies  0": "Films  0", "Shows  0": "Séries  0",
        "Search for a channel, movie or series...": "Rechercher une chaîne, un film ou une série...",
        "Press OK to start searching": "Appuyez sur OK pour lancer la recherche", "YOUR SAVED CONTENT": "VOTRE CONTENU ENREGISTRÉ",
        "ALL": "TOUT", "LIVE": "DIRECT", "SERIES": "SÉRIE", "MOVIE": "FILM",
        "ARROWS  SELECT POSTER     •     HOLD YELLOW ON A MOVIE / TV SHOW POSTER  =  ADD TO FAVORITES": "FLÈCHES : SÉLECTIONNER  •  MAINTENEZ JAUNE POUR AJOUTER AUX FAVORIS",
        "BLUE  CHANGE STYLE": "BLEU  CHANGER LE STYLE",
        "Unable to save settings.": "Impossible d’enregistrer les paramètres.",
        "Language saved. Reopen the app to apply it.": "Langue enregistrée. Rouvrez l’application pour l’appliquer.",
        "ADD A SOURCE": "AJOUTER UNE SOURCE", "ADD IPTV SOURCE": "AJOUTER UNE SOURCE IPTV", "UPDATE PLAYLIST": "METTRE À JOUR", "EXIT": "QUITTER", "Choose the type of IPTV connection": "Choisissez le type de connexion IPTV",
        "STALKER PORTAL  •  LIVE, MOVIES & TV SHOWS": "PORTAIL STALKER  •  DIRECT, FILMS ET SÉRIES",
        "ADD XTREAM CODES PLAYLIST": "AJOUTER UNE LISTE XTREAM CODES", "TMDb TRENDING SETTINGS": "PARAMÈTRES TMDb",
        "SERVER CONTENT FILTER": "FILTRE DU CONTENU SERVEUR", "IMAGE CACHE": "CACHE DES IMAGES",
        "HOME APPEARANCE": "APPARENCE DE L’ACCUEIL", "SOFTWARE UPDATES": "MISES À JOUR",
        "SUBDL SUBTITLE LANGUAGE": "LANGUE DES SOUS-TITRES SUBDL", "Download SubDL subtitles in": "Télécharger les sous-titres SubDL en",
        "": "Chargement...", "No results": "Aucun résultat", "Back": "Retour",
        "Previous Category": "Catégorie précédente", "Next Category": "Catégorie suivante", "Remove from My List": "Retirer de ma liste", "Filter": "Filtre", "No EPG data": "Aucune donnée EPG",
        'TiViMate': 'TiViMate',
        'IPTV EXPERIENCE': 'EXPÉRIENCE IPTV',
        'OK  KEYBOARD    GREEN  SAVE    RED  CANCEL': 'OK CLAVIER    VERT ENREGISTRER    ROUGE ANNULER',
        'Stalker requires your own Portal URL and MAG MAC address. No portal is included.': 'Stalker nécessite votre propre URL de portail et adresse MAG MAC. Aucun portail n’est inclus.',
        'OK SELECT    EXIT BACK': 'OK SÉLECTIONNER    EXIT RETOUR',
        'Enter your own Portal URL and MAG MAC address. No portal or account is bundled with TiViMate.': 'Saisissez votre URL de portail et votre adresse MAG MAC. Aucun portail ni compte n’est fourni avec TiViMate.',
        'Enter a TMDb API key. Trending metadata comes from TMDb; playback uses the selected server.': 'Saisissez une clé API TMDb. Les métadonnées tendance viennent de TMDb ; la lecture utilise le serveur sélectionné.',
        'OK KEYBOARD    GREEN SAVE    RED CANCEL': 'OK CLAVIER    VERT ENREGISTRER    ROUGE ANNULER',
        'Load only the categories you need to keep lists, search, and images fast.': 'Chargez uniquement les catégories nécessaires pour garder les listes, la recherche et les images rapides.',
        'LEFT/RIGHT  SECTION    OK  TOGGLE    GREEN  SAVE    YELLOW  SELECT ALL    BLUE  CLEAR ALL    EXIT  BACK': 'GAUCHE/DROITE SECTION    OK BASCULER    VERT ENREGISTRER    JAUNE TOUT SÉLECTIONNER    BLEU TOUT EFFACER    EXIT RETOUR',
        'GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK': 'VERT ENREGISTRER    BLEU VIDER LE CACHE    JAUNE NETTOYER    EXIT RETOUR',
        'Changes apply to the Home screen only. Restart the app after saving.': 'Les changements s’appliquent uniquement à l’accueil. Rouvrez l’application après l’enregistrement.',
        'GREEN  SAVE    RED  BACK': 'VERT ENREGISTRER    ROUGE RETOUR',
        'Automatic checks only read a small verified update manifest. Press YELLOW to check now.': 'La vérification automatique lit uniquement un petit manifeste de mise à jour vérifié. Appuyez sur JAUNE pour vérifier maintenant.',
        'GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK': 'VERT ENREGISTRER    JAUNE VÉRIFIER    ROUGE RETOUR',
        'Checking for a verified update...': 'Vérification d’une mise à jour fiable...',
        'Downloading and verifying the update package...': 'Téléchargement et vérification du paquet...',
        'Installing TiViMate E2 update...': 'Installation de la mise à jour TiViMate E2...',
        'This language is used by the YELLOW SubDL button. Import the SubDL API key separately from Server Manager.': 'Cette langue est utilisée par le bouton jaune SubDL. Importez la clé API SubDL séparément depuis la gestion des serveurs.',
        'Searching...': 'Recherche...',
        'TiViMate IPTV EXPERIENCE': 'EXPÉRIENCE IPTV TiViMate',
        'Live TV  •  Movies  •  Series  •  beIN SPORTS': 'TV EN DIRECT  •  FILMS  •  SÉRIES  •  beIN SPORTS',
        'TIVIMATE  •  PREMIUM IPTV': 'TIVIMATE  •  IPTV PREMIUM',
        'YOUR ENTERTAINMENT, ONE PLACE': 'TOUT VOTRE DIVERTISSEMENT',
        'Browse, discover and enjoy your library in one unified experience.': 'Parcourez, découvrez et profitez de votre bibliothèque dans une seule expérience.',
        'Choose a section. Heavy image downloads are disabled in this build for stability.': 'Choisissez une section. Les téléchargements d’images lourdes sont désactivés pour la stabilité.',
        'OK Open    EXIT Back': 'OK OUVRIR    EXIT RETOUR',
        '': 'Chargement des détails de la série...',
        'LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back': 'GAUCHE/DROITE ÉPISODES    HAUT/BAS SAISON    OK LIRE    ROUGE FAVORI    EXIT RETOUR',
        'LEFT/RIGHT Navigate    UP/DOWN Pages    OK Select    RED Previous Category    BLUE Next Category    MENU Favorite    GREEN Packages/Categories    YELLOW Sort    EXIT Back': 'GAUCHE/DROITE NAVIGUER    HAUT/BAS PAGES    OK SÉLECTIONNER    ROUGE CATÉGORIE PRÉCÉDENTE    BLEU SUIVANTE    MENU FAVORIS    VERT BOUQUETS/CATÉGORIES    JAUNE TRIER    EXIT RETOUR',
        '': 'Chargement des chaînes ajoutées récemment...',
        'Channel changed': 'Chaîne changée',
        'No content': 'Aucun contenu',
        'Name': 'Nom',
        'Rating': 'Note',
        'Playlist Name': 'Nom de la liste',
        'Protocol': 'Protocole',
        'Server URL': 'URL du serveur',
        'Port': 'Port',
        'Username': 'Nom d’utilisateur',
        'Password': 'Mot de passe',
        'Stream Format': 'Format du flux',
        'EPG Time Offset': 'Décalage horaire EPG',
        '★ TMDb Poster in Live': '★ Affiche TMDb en direct',
        'Portal Name': 'Nom du portail',
        'Portal URL': 'URL du portail',
        'MAG MAC Address': 'Adresse MAG MAC',
        'TMDb API Key': 'Clé API TMDb',
        'Metadata language': 'Langue des métadonnées',
        'Cache Location': 'Emplacement du cache',
        'Maximum Size': 'Taille maximale',
        'Delete Images Older Than': 'Supprimer les images plus anciennes que',
        'Home Skin': 'Thème de l’accueil',
        'Automatic update check': 'Vérification automatique des mises à jour',
        'Update download failed.': 'Échec du téléchargement de la mise à jour.',
        'The verified package could not be installed.': 'Le paquet vérifié n’a pas pu être installé.',
        'Update completed. Restart the Enigma2 GUI to use the new version.': 'Mise à jour terminée. Redémarrez l’interface Enigma2 pour utiliser la nouvelle version.',
        'The update installer returned an error.': 'Le programme d’installation a renvoyé une erreur.',
        'Unable to save favorite': 'Impossible d’enregistrer le favori',
        'Item is already in favorites': 'L’élément est déjà dans les favoris',
        'Added to favorites': 'Ajouté aux favoris',
        'Removed from favorites': 'Retiré des favoris',
        'Unable to remove this Favorite.': 'Impossible de retirer ce favori.',
        'No server selected • Press SETTINGS': 'Aucun serveur sélectionné • Appuyez sur PARAMÈTRES',
        'No seasons': 'Aucune saison',
        '': 'Chargement des bouquets/catégories...',
        'Open a package, select a channel, then press RED': 'Ouvrez un bouquet, sélectionnez une chaîne puis appuyez sur ROUGE',
        'Select a movie or TV show first': 'Sélectionnez d’abord un film ou une série',
        'Preparing series categories in the background...': 'Préparation des catégories de séries en arrière-plan...',
        'Select a series category': 'Sélectionnez une catégorie de séries',
        'Select the category then press OK. Only this category will be loaded.': 'Sélectionnez la catégorie puis appuyez sur OK. Seule cette catégorie sera chargée.',
        'No favorite channels yet. Add channels with the red button.': 'Aucune chaîne favorite. Ajoutez-en avec le bouton rouge.',
        'Select a series category then press OK.': 'Sélectionnez une catégorie de séries puis appuyez sur OK.',
        'No categories available.': 'Aucune catégorie disponible.',
        'The category is preparing in the background... the interface will not freeze.': 'La catégorie se prépare en arrière-plan... l’interface ne se bloquera pas.',
        'Stalker returned no packages. Check Portal URL and MAG MAC, then retry.': 'Stalker n’a renvoyé aucun bouquet. Vérifiez l’URL du portail et l’adresse MAG MAC, puis réessayez.',
        'Stalker returned no items for this package. Try another package or refresh the source.': 'Stalker n’a renvoyé aucun contenu pour ce bouquet. Essayez un autre bouquet ou actualisez la source.',
        'No saved items in this filter. Open a title and choose Add to My List.': 'Aucun élément enregistré dans ce filtre. Ouvrez un titre et choisissez Ajouter à ma liste.',
        'YOUR LIBRARY': 'VOTRE BIBLIOTHÈQUE',
        'Choose a collection\nto browse titles from\nyour selected server.': 'Choisissez une collection\npour parcourir les titres de\nvotre serveur sélectionné.',
        'Press OK to open': 'Appuyez sur OK pour ouvrir',
        'Browse the collections available on your server': 'Parcourez les collections disponibles sur votre serveur',
        '': 'CHARGEMENT DES COLLECTIONS',
        'AVAILABLE COLLECTIONS': 'COLLECTIONS DISPONIBLES',
        '': 'Chargement des détails...',
        '▶  Watch': '▶  Regarder',
        'Other Sources': 'Autres sources',
        'Actors': 'Acteurs',
        'Recommendations': 'Recommandations',
        'OK Play     EXIT Back': 'OK Lire     EXIT Retour',
        'UNABLE TO LOAD CATEGORIES': 'IMPOSSIBLE DE CHARGER LES CATÉGORIES',
        'Check the selected server and try again': 'Vérifiez le serveur sélectionné et réessayez',
        'NO COLLECTIONS': 'AUCUNE COLLECTION',
        'No enabled collections are available for this server': 'Aucune collection activée n’est disponible pour ce serveur',
        '': 'Les catégories sont en cours de chargement. Réessayez dans un instant.',
        'No enabled categories are available for this library.': 'Aucune catégorie activée n’est disponible pour cette bibliothèque.',
        "Today's Trending Movies": 'Films tendance du jour',
        "Today's Trending Series": 'Séries tendance du jour',
        'Latest Movies': 'Derniers films',
        'Latest Series': 'Dernières séries',
        'Latest Movies & TV Shows': 'Derniers films et séries',
        'Latest TV Shows': 'Dernières séries',
        '%d Home picks': '%d sélections d’accueil',
        '%d recent TV shows': '%d séries récentes',
        '%d recent movies': '%d films récents',
        'Server: %s  •  %s': 'Serveur : %s  •  %s',
        'Use OK to enter characters. GREEN saves. RED or EXIT cancels.': 'Utilisez OK pour saisir des caractères. VERT enregistre. ROUGE ou EXIT annule.',
        'OK: Edit key   YELLOW: Import /tmp/tivimatee2/key.txt   GREEN: Save   EXIT: Close': 'OK : modifier la clé   JAUNE : importer /tmp/tivimatee2/key.txt   VERT : enregistrer   EXIT : fermer',
        'SubDL API Key  (OK to edit)': 'Clé API SubDL  (OK pour modifier)',
        'Default Subtitle Language': 'Langue de sous-titres par défaut',
        'Default Subtitle Type': 'Type de sous-titres par défaut',
        'Developed by Opesboy': 'Développé par Opesboy',
        'Downloading TiviMate E2 update...': 'Téléchargement de la mise à jour TiviMate E2...',
        'Installing TiviMate E2 update...': 'Installation de la mise à jour TiviMate E2...',
        'Press OK again to open the search keyboard': 'Appuyez de nouveau sur OK pour ouvrir le clavier de recherche',
        'Stalker packages are ready. Open Categories and select a package to load its titles.': 'Les bouquets Stalker sont prêts. Ouvrez les catégories et sélectionnez un bouquet pour charger ses titres.',
        'TiViMate E2 is already up to date.': 'TiViMate E2 est déjà à jour.',
        'TiviMate E2': 'TiviMate E2',
        'Unable to start the update installer.': 'Impossible de démarrer le programme d’installation.',
        'Unable to verify updates right now. You can try again later.': 'Impossible de vérifier les mises à jour maintenant. Réessayez plus tard.',
        'Select a movie poster first': 'Sélectionnez d’abord une affiche de film',
        'Movie is already in favorites': 'Le film est déjà dans les favoris',
        'Movie added to favorites': 'Film ajouté aux favoris',
        'Series is already in favorites': 'La série est déjà dans les favoris',
        'Series added to favorites': 'Série ajoutée aux favoris',
        'This title is not available on the server and cannot be added to favorites': 'Ce titre n’est pas disponible sur le serveur et ne peut pas être ajouté aux favoris',
    }
}

# Additional Arabic strings for the Live, packages, and settings interfaces.
_TRANSLATIONS["ar"].update({'ADD NEW SERVER': 'إضافة سيرفر جديد', 'Actor information is unavailable.': 'معلومات الممثل غير متوفرة.', 'Add an IPTV source first.': 'أضف مصدر IPTV أولاً.', 'Add to parental protection': 'إضافة إلى الرقابة الأبوية', 'Added package folder to Favorites': 'تمت إضافة مجلد الباقة إلى المفضلة', 'Added package to Favorites': 'تمت إضافة الباقة إلى المفضلة', 'Audio Tracks': 'المسارات الصوتية', 'BLUE  CLEAR ALL': 'الأزرق  مسح الكل', 'BLUE  TEST PORTAL': 'الأزرق  اختبار البوابة', 'Built-in TMDb access is active. Enter your own key only to override it.': 'مفتاح TMDb المدمج نشط. أدخل مفتاحك فقط لاستبداله.', 'CATCH-UP / ARCHIVE': 'إعادة المشاهدة / الأرشيف', 'Catch-up / Archive': 'إعادة المشاهدة / الأرشيف', 'Catch-up is not available for this channel.': 'إعادة المشاهدة غير متوفرة لهذه القناة.', 'Change parental PIN': 'تغيير رمز الرقابة الأبوية', 'Channel': 'القناة', 'Channel could not start.': 'تعذر تشغيل القناة.', 'Channel hidden. Use MENU to restore it.': 'تم إخفاء القناة. اضغط MENU لاستعادتها.', 'Channel link unavailable.': 'رابط القناة غير متوفر.', 'Channel locked.': 'القناة مقفلة.', 'Channel position saved.': 'تم حفظ موقع القناة.', 'Channel restored.': 'تمت استعادة القناة.', 'Channel unavailable - try another channel.': 'القناة غير متاحة، جرّب قناة أخرى.', 'Checking playable catch-up channels...': 'جارٍ فحص القنوات التي تدعم إعادة المشاهدة...', 'Choose a collection\nto browse titles from\nyour selected server.': 'اختر مجموعة\nلاستعراض المحتوى من\nالسيرفر المحدد.', 'Choose the server for Home': 'اختر سيرفر الصفحة الرئيسية', 'Choose the type of IPTV connection you want to add': 'اختر نوع اتصال IPTV المراد إضافته', 'Clear Continue Watching': 'مسح متابعة المشاهدة', 'Clear all Continue Watching history?': 'هل تريد مسح سجل متابعة المشاهدة كاملاً؟', 'Content locked.': 'المحتوى مقفل.', 'Disable move': 'إلغاء النقل', 'Enable Catch-up Package': 'تفعيل باقة إعادة المشاهدة', 'Enable move': 'تفعيل النقل', 'Enter new 4-digit PIN': 'أدخل رمزاً جديداً من 4 أرقام', 'Enter parental PIN': 'أدخل رمز الرقابة الأبوية', 'Favorite channel position saved.': 'تم حفظ ترتيب القناة المفضلة.', 'Favorite options': 'خيارات المفضلة', 'Favorites are already empty': 'المفضلة فارغة بالفعل', 'Favorites cleared': 'تم مسح المفضلة', 'GREEN  PLAY': 'الأخضر  تشغيل', 'Hide Adult Content': 'إخفاء محتوى البالغين', 'Hide this channel': 'إخفاء هذه القناة', 'Hide this package': 'إخفاء هذه الباقة', 'Hide this package?': 'هل تريد إخفاء هذه الباقة؟', 'Home Content': 'محتوى الرئيسية', 'Image Cache Retention': 'مدة الاحتفاظ بكاش الصور', 'Incorrect PIN': 'رمز غير صحيح', 'Internal Flash Free Space': 'المساحة الحرة للفلاش الداخلي', 'Internal Flash Image Limit': 'الحد الأقصى للصور في الفلاش الداخلي', 'LIVE FAVORITES': 'مفضلة البث المباشر', 'Latest': 'الأحدث', 'Live Stream Type': 'نوع بث القنوات', 'Live options': 'خيارات البث المباشر', 'Loading package channels...': 'جارٍ تحميل قنوات الباقة...', 'Lock removed.': 'تم إلغاء القفل.', 'Lock this channel': 'قفل هذه القناة', 'Lock this package': 'قفل هذه الباقة', 'MAG MACs / Alias': 'عناوين MAG MAC / الاسم المستعار', 'MOVIE FAVORITES': 'الأفلام المفضلة', 'Mark as Watched': 'تحديد كمشاهَد', 'Menu': 'القائمة', 'Move channel with UP/DOWN, then press OK to save.': 'انقل القناة بالسهمين أعلى/أسفل ثم اضغط OK للحفظ.', 'Move channel with arrows, then press OK to save.': 'حرّك القناة بالأسهم ثم اضغط OK للحفظ.', 'Move item with arrows, then press OK or BLUE to save.': 'حرّك العنصر بالأسهم، ثم اضغط OK أو الأزرق للحفظ.', 'Move this channel': 'نقل هذه القناة', 'Movie': 'فيلم', 'Movie images are still loading.': 'صور الفيلم ما زالت قيد التحميل.', 'Movies and TV Shows packages are available for Xtream and Stalker sources.': 'باقات الأفلام والمسلسلات متاحة لمصادر Xtream وStalker.', 'No Genre items to add': 'لا توجد عناصر تصنيف لإضافتها', 'No IPTV servers found.': 'لم يُعثر على سيرفرات IPTV.', 'No Other Sources': 'لا توجد مصادر أخرى', 'No active channel to restart': 'لا توجد قناة نشطة لإعادة تشغيلها', 'No catch-up channels are available on this server.': 'لا تتوفر قنوات إعادة المشاهدة على هذا السيرفر.', 'No catch-up programmes are available for this channel.': 'لا تتوفر برامج إعادة مشاهدة لهذه القناة.', 'No channels found in this package': 'لم يُعثر على قنوات في هذه الباقة', 'No channels left in this favorite package': 'لم تتبقَّ قنوات في الباقة المفضلة', 'No hidden channels.': 'لا توجد قنوات مخفية.', 'No hidden packages.': 'لا توجد باقات مخفية.', 'No recently watched Stalker items.': 'لا يوجد محتوى Stalker تمت مشاهدته مؤخراً.', 'OK Select     RED Delete     BLUE Test     EXIT Cancel': 'OK اختيار     الأحمر حذف     الأزرق اختبار     EXIT إلغاء', 'Open a Movies or TV Shows package first': 'افتح باقة أفلام أو مسلسلات أولاً', 'Original': 'الأصلية', 'PIN must contain exactly 4 digits.': 'يجب أن يتكون الرمز من 4 أرقام بالضبط.', 'Package hidden. Use MENU to restore it.': 'تم إخفاء الباقة. اضغط MENU لاستعادتها.', 'Package is already in Favorites': 'الباقة موجودة في المفضلة بالفعل', 'Package locked.': 'الباقة مقفلة.', 'Package restored.': 'تمت استعادة الباقة.', 'Page': 'الصفحة', 'Parental PIN changed.': 'تم تغيير رمز الرقابة الأبوية.', 'Pick up where you left off. Your movies and TV shows will appear here automatically.': 'تابع من حيث توقفت. ستظهر أفلامك ومسلسلاتك هنا تلقائياً.', 'Playing catch-up': 'جارٍ تشغيل إعادة المشاهدة', 'Portal based connection\nPortal URL and MAC address': 'اتصال عبر البوابة\nرابط البوابة وعنوان MAC', 'Portal returned no archive link': 'لم توفر البوابة رابط الأرشيف', 'Portal returned no playable URL': 'لم توفر البوابة رابطاً قابلاً للتشغيل', 'Preferred Subtitle Language': 'لغة الترجمة المفضلة', 'Press for Other Sources': 'اضغط للمصادر الأخرى', 'Programme start time is missing': 'وقت بدء البرنامج غير متوفر', 'RED  REMOVE': 'الأحمر  إزالة', 'Recently watched': 'شوهد مؤخراً', 'Remove from Continue Watching': 'إزالة من متابعة المشاهدة', 'Remove from parental protection': 'إزالة من الرقابة الأبوية', 'Removed package from Favorites': 'تمت إزالة الباقة من المفضلة', 'Restarting stream...': 'جارٍ إعادة تشغيل البث...', 'SERIES FAVORITES': 'المسلسلات المفضلة', 'SERVERS & WEB': 'السيرفرات والويب', 'SUBTITLE LANGUAGE': 'لغة الترجمة', 'Search for a movie or series...': 'ابحث عن فيلم أو مسلسل...', 'Search results': 'نتائج البحث', 'Searching Sources...': 'جارٍ البحث في المصادر...', 'Select Server': 'اختر سيرفر', 'Select a Live package first': 'اختر باقة قنوات أولاً', 'Select a channel': 'اختر قناة', 'Select a server type. You can edit it later from Server Manager.': 'اختر نوع السيرفر. يمكنك تعديله لاحقاً من إدارة السيرفرات.', 'Series Stream Type': 'نوع بث المسلسلات', 'Server Subtitles': 'ترجمة السيرفر', 'Server did not respond. Try another channel.': 'السيرفر لا يستجيب. جرّب قناة أخرى.', 'Show hidden channels': 'إظهار القنوات المخفية', 'Show hidden packages': 'إظهار الباقات المخفية', 'Source Type': 'نوع المصدر', 'Stalker Live player': 'مشغل قنوات Stalker', 'Stalker Movies player': 'مشغل أفلام Stalker', 'Stalker Series player': 'مشغل مسلسلات Stalker', 'Stalker player engines': 'محركات تشغيل Stalker', 'Stalker player engines saved.': 'تم حفظ محركات تشغيل Stalker.', 'Start watching and unfinished titles will appear here automatically.': 'ابدأ المشاهدة، وسيظهر المحتوى غير المكتمل هنا تلقائياً.', 'Stream restarted': 'تمت إعادة تشغيل البث', 'Subtitle Font Size': 'حجم خط الترجمة', 'TV Show': 'مسلسل', 'This channel does not advertise catch-up support.': 'هذه القناة لا تدعم إعادة المشاهدة.', 'This channel has no provider catch-up window.': 'لا تتوفر فترة إعادة مشاهدة لهذه القناة من المزود.', 'This movie is not available on the current server.': 'هذا الفيلم غير متاح على السيرفر الحالي.', 'This package cannot be hidden.': 'لا يمكن إخفاء هذه الباقة.', 'This package cannot be locked.': 'لا يمكن قفل هذه الباقة.', 'TiviMate Subtitles': 'ترجمة TiviMate', 'Try again in': 'أعد المحاولة بعد', 'Type': 'النوع', 'URL / File Path': 'الرابط / مسار الملف', 'Unable to build catch-up URL': 'تعذر إنشاء رابط إعادة المشاهدة', 'Unable to change channel': 'تعذر تغيير القناة', 'Unable to clear Favorites': 'تعذر مسح المفضلة', 'Unable to load package:\n%s': 'تعذر تحميل الباقة:\n%s', 'Unable to open Genres': 'تعذر فتح التصنيفات', 'Unable to play catch-up': 'تعذر تشغيل إعادة المشاهدة', 'Unable to play this item.': 'تعذر تشغيل هذا المحتوى.', 'Unable to restart stream': 'تعذر إعادة تشغيل البث', 'Subtitle Language': 'لغة الترجمة', 'Playback': 'التشغيل', 'Loading...': 'جارٍ التحميل...', 'Details': 'التفاصيل', 'Settings saved.': 'تم حفظ الإعدادات.'})

_TRANSLATIONS["ar"].update({'Choose a collection\\nto browse titles from\\nyour selected server.': 'اختر مجموعة\\nلاستعراض المحتوى من\\nالسيرفر المحدد.', 'Import a ready-made M3U/M3U8/TXT file. Existing URL playlists remain supported when editing.': 'استيراد ملف M3U/M3U8/TXT جاهز. تظل روابط القوائم مدعومة عند التعديل.', 'Manage IPTV servers,\\nStalker / Xtream and\\nmobile Web Control.': 'إدارة سيرفرات IPTV،\\nStalker وXtream،\\nوالتحكم عبر الويب.', 'Manage playlists,\\nconnections and metadata,\\nand appearance settings.': 'إدارة قوائم التشغيل،\\nالاتصالات والبيانات،\\nوإعدادات المظهر.', 'Portal based connection\\nPortal URL and MAC address': 'اتصال عبر البوابة\\nرابط البوابة وعنوان MAC', 'Press 4 WEB QR\\nPress 7 BACKUP & RESTORE\\nPress 8 SETTINGS (NEW)': 'اضغط 4 لرمز QR\\nاضغط 7 للنسخ والاستعادة\\nاضغط 8 للإعدادات الجديدة', 'Unable to load package:\\n%s': 'تعذر تحميل الباقة:\\n%s', 'Unable to save Stalker player engines.': 'تعذر حفظ محركات تشغيل Stalker.', 'Unable to save favorite package': 'تعذر حفظ الباقة المفضلة', 'Unable to save favorites': 'تعذر حفظ المفضلة', 'Unlock this channel': 'إلغاء قفل هذه القناة', 'Unlock this package': 'إلغاء قفل هذه الباقة', 'Untitled': 'بلا عنوان', 'Update completed. Restarting Enigma2 GUI...': 'اكتمل التحديث. جارٍ إعادة تشغيل واجهة Enigma2...', 'Use the colour keys below\\nfor quick actions.': 'استخدم الأزرار الملونة أدناه\\nللإجراءات السريعة.', 'VOD Stream Type': 'نوع بث الأفلام', 'Watch unavailable': 'المشاهدة غير متاحة', 'Xtream Live player': 'مشغل قنوات Xtream', 'Xtream Movies player': 'مشغل أفلام Xtream', 'Xtream Series player': 'مشغل مسلسلات Xtream', 'Xtream archive credentials are incomplete': 'بيانات دخول أرشيف Xtream غير مكتملة', 'Xtream player engines': 'محركات تشغيل Xtream', 'Xtream player engines saved.': 'تم حفظ محركات تشغيل Xtream.', 'YELLOW  INFO': 'الأصفر  معلومات', 'YOUR STORY CONTINUES HERE': 'أكمل قصتك هنا', 'Year': 'السنة', 'Your unfinished movies and TV shows will appear here.': 'ستظهر أفلامك ومسلسلاتك غير المكتملة هنا.', 'catch-up channels': 'قنوات إعادة المشاهدة', 'results': 'نتائج'})

def get_language():
    try:
        with open(LANG_FILE, "r") as handle:
            value = str((json.load(handle) or {}).get("language", "en"))
        return value if value in SUPPORTED else "en"
    except Exception:
        return "en"

def save_language(value):
    value = value if value in SUPPORTED else "en"
    try:
        folder = os.path.dirname(LANG_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = LANG_FILE + ".tmp"
        with open(tmp, "w") as handle:
            json.dump({"language": value}, handle)
        try:
            os.rename(tmp, LANG_FILE)
        except Exception:
            if os.path.exists(LANG_FILE):
                os.remove(LANG_FILE)
            os.rename(tmp, LANG_FILE)
        # Changing application language also resets the TMDb information language.
        # A later manual choice in TMDb Settings remains independent until the
        # application language is changed again. Preserve all existing credentials.
        try:
            from .tmdb_client import CONFIG_FILE as _tmdb_config_file
            _tmdb_lang = {"ar": "ar-AE", "en": "en-US", "fr": "fr-FR", "tr": "tr-TR"}.get(value, "en-US")
            _tmdb_cfg = {}
            if os.path.isfile(_tmdb_config_file):
                with open(_tmdb_config_file, "r") as _tf:
                    _tmdb_cfg = json.load(_tf) or {}
            _tmdb_cfg["language"] = _tmdb_lang
            _tdir = os.path.dirname(_tmdb_config_file)
            if not os.path.isdir(_tdir):
                os.makedirs(_tdir)
            _ttmp = _tmdb_config_file + ".tmp"
            with open(_ttmp, "w") as _tf:
                json.dump(_tmdb_cfg, _tf)
            os.rename(_ttmp, _tmdb_config_file)
            try:
                os.chmod(_tmdb_config_file, 0o600)
            except Exception:
                pass
        except Exception:
            # Leave a correctly saved application language usable even if
            # metadata settings storage is temporarily unavailable.
            pass
        return True
    except Exception:
        return False

# Cinema sidebar navigation keys, shared with the application language selector.
for _lang, _labels in {
    "ar": {"Search": "البحث", "Server Finder": "بحث السيرفر", "Resume": "متابعة المشاهدة", "Favorites": "المفضلة", "Settings": "الإعدادات"},
    "fr": {"Search": "Recherche", "Server Finder": "Recherche de serveurs", "Resume": "Reprendre", "Favorites": "Favoris", "Settings": "Paramètres"},
    "tr": {"Search": "Ara", "Server Finder": "Sunucu Bulucu", "Resume": "Devam", "Favorites": "Favoriler", "Settings": "Ayarlar"},
}.items():
    _TRANSLATIONS.setdefault(_lang, {}).update(_labels)

_TRANSLATIONS["ar"].update({'Font saved.': 'تم حفظ الخط.', 'Movie Parts': 'أجزاء الفيلم', 'Searching...': 'جارٍ البحث...', 'This movie has no other parts.': 'هذا الفيلم ليس له أجزاء أخرى.', 'No parts of this movie were found on this server.': 'لم يُعثر على أجزاء هذا الفيلم في هذا السيرفر.', 'Movie details are still loading.': 'تفاصيل الفيلم ما زالت قيد التحميل.'})

def tr(text):
    # Empty widget text is not a translation key. Keep Live/EPG fields empty
    # instead of showing an unrelated loading message in Arabic.
    if text == "" or text is None:
        return ""
    return _TRANSLATIONS.get(get_language(), {}).get(text, text)


_NAV_ICONS = {}
def nav_label(key):
    """Translated navigation label. Icons are lightweight static PNG assets in the skin."""
    return tr(key)
