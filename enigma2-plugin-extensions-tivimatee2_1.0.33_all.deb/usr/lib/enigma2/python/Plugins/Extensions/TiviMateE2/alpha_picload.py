# -*- coding: utf-8 -*-
"""ePicLoad that keeps PNG transparency on every Enigma2 image.

Some images (EGAMI, VTi, older OpenPLi drivers) decode PNG files through
ePicLoad onto an opaque background, so transparent title/channel logos get a
black box, while the player (which loads the PNG file directly) shows them
correctly. This drop-in class behaves exactly like enigma.ePicLoad, except
that for a PNG with an alpha channel getData() returns the PNG itself, fitted
once to the requested box (aspect kept, centred, transparent padding, cached
on disk) and loaded with LoadPixmap, i.e. with its real alpha. JPEGs, opaque
PNGs and anything that cannot be fitted still use the native decoder.
"""
import os

from enigma import ePicLoad as _NativePicLoad

try:
    from .transparent_pixmap import (_png_size, _cached_fit, _fit, _schedule_fit,
                                     _SYNC_FIT_MAX_PIXELS)
except Exception:  # pragma: no cover - fitting helpers unavailable
    _png_size = None

_ALPHA_CACHE = {}


def _png_has_alpha(path):
    """True for RGBA / grey+alpha PNGs, or palette PNGs with a tRNS chunk."""
    try:
        key = (path, os.path.getmtime(path))
    except Exception:
        return False
    cached = _ALPHA_CACHE.get(key)
    if cached is not None:
        return cached
    result = False
    try:
        with open(path, "rb") as handle:
            head = handle.read(65536)
        if head[:8] == b"\x89PNG\r\n\x1a\n" and head[12:16] == b"IHDR":
            colour_type = bytearray(head[25:26])[0]
            result = colour_type in (4, 6) or b"tRNS" in head
    except Exception:
        result = False
    if len(_ALPHA_CACHE) > 512:
        _ALPHA_CACHE.clear()
    _ALPHA_CACHE[key] = result
    return result


class ePicLoad(object):
    def __init__(self, *args, **kwargs):
        object.__setattr__(self, "_native", _NativePicLoad(*args, **kwargs))
        object.__setattr__(self, "_box", None)
        object.__setattr__(self, "_path", None)

    @property
    def PictureData(self):
        return self._native.PictureData

    def setPara(self, para, *args, **kwargs):
        try:
            object.__setattr__(self, "_box", (int(para[0]), int(para[1])))
        except Exception:
            object.__setattr__(self, "_box", None)
        return self._native.setPara(para, *args, **kwargs)

    def startDecode(self, path, *args, **kwargs):
        object.__setattr__(self, "_path", path)
        return self._native.startDecode(path, *args, **kwargs)

    def _alpha_pixmap(self):
        path = self._path
        box = self._box
        if _png_size is None or not path or not box:
            return None
        try:
            if not str(path).lower().endswith(".png") or not os.path.isfile(path):
                return None
            if not _png_has_alpha(path):
                return None
            width, height = box
            if width <= 0 or height <= 0:
                return None
            dims = _png_size(path)
            if not dims:
                return None
            paint = path
            if tuple(dims) != (width, height):
                paint = _cached_fit(path, width, height)
                if not paint:
                    if dims[0] * dims[1] > _SYNC_FIT_MAX_PIXELS:
                        _schedule_fit(path, width, height)
                        return None
                    paint = _fit(path, width, height)
                if not paint:
                    return None
            from Tools.LoadPixmap import LoadPixmap
            return LoadPixmap(path=paint)
        except Exception:
            return None

    def getData(self, *args, **kwargs):
        ptr = self._alpha_pixmap()
        if ptr is not None:
            return ptr
        return self._native.getData(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._native, name)
