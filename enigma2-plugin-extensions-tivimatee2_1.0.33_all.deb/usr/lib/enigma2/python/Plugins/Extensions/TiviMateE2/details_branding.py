# -*- coding: utf-8 -*-
"""Recognize actual platform package branding for Movie/Series details.

Uses the same GENRE brand aliases and bundled artwork. No network requests,
no TMDb guesses, no changes to server data, and no genre-as-provider logos.
"""
from __future__ import absolute_import
import os
from .genre_package_badges import _BRANDS, _match, _norm
from .package_logos import package_provider_key

_ASSETS = os.path.join(os.path.dirname(__file__), 'skins', 'details', 'providers')
_BRAND_KEYS = frozenset(key for key, aliases in _BRANDS)


def _brand_from_label(label):
    normalized = _norm(label)
    if not normalized:
        return ''
    words = set(normalized.split())
    for key, aliases in _BRANDS:
        if normalized == key or any(_match(words, normalized, alias) for alias in aliases):
            return key
    # The Packages browser recognizes extra aliases (NET FLIX, NFX, etc.).
    # Keep Details consistent, but never treat generic genres as platforms.
    key = package_provider_key(label)
    return key if key in _BRAND_KEYS else ''


def detail_brand_logo(item, source_context=None):
    """Return a prepared provider logo only for explicit package provenance."""
    item = item if isinstance(item, dict) else {}
    context = source_context if isinstance(source_context, dict) else {}
    # Do NOT infer from title, plot, the IPTV server name or TMDb providers:
    # those may advertise a different platform from the package being viewed.
    labels = (
        item.get('_server_package_name'),
        item.get('_source_category_name'),
        item.get('category_name'),
        item.get('package_name'),
        item.get('group-title'),
        context.get('_server_package_name'),
        context.get('_source_category_name'),
        context.get('category_name'),
        context.get('package_name'),
        item.get('_server_package_provider'),
        item.get('_tmdb_provider'),
    )
    for label in labels:
        key = _brand_from_label(label)
        if key in _BRAND_KEYS:
            path = os.path.join(_ASSETS, '%s.png' % key)
            if os.path.isfile(path):
                return path
    return ''
