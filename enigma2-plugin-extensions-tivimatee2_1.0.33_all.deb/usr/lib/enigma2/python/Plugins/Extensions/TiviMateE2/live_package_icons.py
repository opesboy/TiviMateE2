# -*- coding: utf-8 -*-
"""Safe, optional, online country flags for the Live package list.

No network call runs on Enigma's GUI thread.  Flags are fetched one at a time,
only for visible packages, and the package list remains usable without them.
"""
from __future__ import absolute_import

import os
import re
import struct
import unicodedata
from urllib.request import Request, urlopen

from .cache_manager import get_cache_dir
from . import artwork_queue as _artwork_queue

# These labels are explicit country identifiers at the *start* of a package
# name.  Deliberately exclude AR (Arabic, not Argentina), EN, TR? TR is
# commonly Turkey (also Turkish); only treat prefix TR as a country label.
_COUNTRIES = {
    "UK": "gb", "GB": "gb", "USA": "us", "US": "us", "UAE": "ae", "AE": "ae",
    "KSA": "sa", "SA": "sa", "CA": "ca", "CAN": "ca", "AU": "au", "AUS": "au",
    "DE": "de", "GER": "de", "FR": "fr", "FRANCE": "fr", "IT": "it", "ITALY": "it",
    "ES": "es", "SPAIN": "es", "TR": "tr", "TURKEY": "tr", "RU": "ru", "RUSSIA": "ru",
    "IN": "in", "INDIA": "in", "PK": "pk", "EG": "eg", "EGYPT": "eg",
    "JP": "jp", "JAPAN": "jp", "KR": "kr", "KOREA": "kr", "CN": "cn", "CHINA": "cn",
    "NL": "nl", "PL": "pl", "PT": "pt", "BR": "br", "MX": "mx", "ZA": "za",
    "NZ": "nz", "SE": "se", "NO": "no", "DK": "dk", "FI": "fi",
    "QA": "qa", "QATAR": "qa", "KW": "kw", "OM": "om", "BH": "bh",
    "JO": "jo", "LB": "lb", "MA": "ma", "TN": "tn", "DZ": "dz", "IQ": "iq", "PS": "ps", "PALESTINE": "ps",
    "SY": "sy", "SYR": "sy", "SYRIA": "sy", "SYRIAN": "sy",
    "YE": "ye", "YEM": "ye", "YEMEN": "ye", "YEMENI": "ye",
    "MAR": "ma", "MAROC": "ma", "MOROCCO": "ma", "MOROCCAN": "ma", "MOROCAIN": "ma",
    "LBN": "lb", "LIBAN": "lb", "LEBANON": "lb", "LEBANESE": "lb",
    "IRAK": "iq", "IRAQ": "iq", "IRAQI": "iq",
    "TUN": "tn", "TUNIS": "tn", "TUNISE": "tn", "TUNISIA": "tn", "TUNISIE": "tn",
    "EMIRATES": "ae", "SAUDI": "sa", "SAUDIARABIA": "sa",
    # Real country names from bouquet providers (not just two-letter codes).
    # Every code here has an existing bundled local flag_XX.png asset.
    "GERMANY": "de", "GERMAN": "de", "DEUTSCHLAND": "de", "DEUTSCH": "de",
    "ALLEMAGNE": "de", "ALEMANIA": "de", "ALMANYA": "de",
    "UNITEDKINGDOM": "gb", "BRITAIN": "gb", "GREATBRITAIN": "gb", "ENGLAND": "gb",
    "AMERICA": "us", "UNITEDSTATES": "us", "UNITEDSTATESOFAMERICA": "us",
    "CANADA": "ca", "AUSTRALIA": "au", "AUSTRALIAN": "au",
    "FRANCA": "fr", "FRENCH": "fr", "FRANCIA": "fr",
    "ITALIA": "it", "ITALIAN": "it", "ESPANA": "es", "SPANISH": "es",
    "TURKIYE": "tr", "TURKIY": "tr", "TURKISH": "tr", "RUSSIAN": "ru",
    "INDIAN": "in", "PAKISTAN": "pk", "PAKISTANI": "pk",
    "JAPANESE": "jp", "SOUTHKOREA": "kr", "KOREAN": "kr", "CHINESE": "cn",
    "NETHERLANDS": "nl", "HOLLAND": "nl", "DUTCH": "nl",
    "POLAND": "pl", "POLISH": "pl", "PORTUGAL": "pt", "PORTUGUESE": "pt",
    "BRAZIL": "br", "BRASIL": "br", "BRAZILIAN": "br",
    "MEXICO": "mx", "MEXICAN": "mx", "SOUTHAFRICA": "za",
    "NEWZEALAND": "nz", "SWEDEN": "se", "SWEDISH": "se",
    "NORWAY": "no", "NORWEGIAN": "no", "DENMARK": "dk", "DANISH": "dk",
    "FINLAND": "fi", "FINNISH": "fi", "GREECE": "gr", "GREEK": "gr",
    "SWITZERLAND": "ch", "SWISS": "ch", "BELGIUM": "be", "BELGIAN": "be",
    "CZECHIA": "cz", "CZECHREPUBLIC": "cz", "CZECH": "cz",
    "QATARI": "qa", "KUWAIT": "kw", "KUWAITI": "kw", "OMAN": "om", "OMANI": "om",
    "BAHRAIN": "bh", "JORDAN": "jo", "JORDANIAN": "jo",
    "ALGERIA": "dz", "ALGERIAN": "dz", "SAUDIARABIAN": "sa",
    "SYRIAN": "sy", "YEMENI": "ye", "EMIRATI": "ae",
}
# Include all ISO flags already bundled locally, including CH, BE, GR and CZ.
_COUNTRIES.update({
    code.upper(): code for code in (
        "ae", "au", "be", "bh", "br", "ca", "ch", "cn", "cz", "de", "dk",
        "dz", "eg", "es", "fi", "fr", "gb", "gr", "in", "iq", "it", "jo",
        "jp", "kr", "kw", "lb", "ma", "mx", "nl", "no", "nz", "om",
        "pk", "pl", "ps", "pt", "qa", "ru", "sa", "se", "sy", "tn",
        "tr", "us", "ye", "za"
    )
})
# Full country words may occur after provider prefixes: VIP | GERMANY | HD.
# Do NOT match loose two-letter codes in arbitrary positions (e.g. IN, IT, US),
# and do not infer a flag from generic language markers AR/EN.
_FULL_COUNTRY_NAMES = {
    name.lower(): code for name, code in _COUNTRIES.items()
    if len(name) >= 4 and name not in (
        "GER", "AUS", "USA", "UAE", "KSA", "CAN", "MAR", "TUN", "LBN", "YEM", "SYR"
    )
}
# Spellings that appear as two or three separate words in IPTV bouquet titles.
_COUNTRY_PHRASES = (
    (("united", "kingdom"), "gb"), (("great", "britain"), "gb"),
    (("united", "states"), "us"), (("united", "states", "of", "america"), "us"),
    (("saudi", "arabia"), "sa"), (("south", "africa"), "za"),
    (("south", "korea"), "kr"), (("new", "zealand"), "nz"),
    (("czech", "republic"), "cz"), (("united", "arab", "emirates"), "ae"),
)

_PREFIX = re.compile(r"^\s*[\[\({]?\s*([A-Za-z]{2,12})(?=$|[\s\]\)}|:;,_./\\\-])")
_ARABIC_MARKS = re.compile(r"[\u064b-\u065f\u0670\u0640]")
# Only the actual explicit country label, not a server's language (AR = Arabic).
_ARABIC_COUNTRIES = (
    (("الامارات", "امارات", "اماراتيه", "دولة الامارات", "الامارات العربيه المتحده"), "ae"),
    (("قطر", "قطري", "قطريه"), "qa"),
    (("الكويت", "كويتي", "كويتيه"), "kw"),
    (("عمان", "العمانيه", "عماني", "عماني", "سلطنه عمان"), "om"),
    (("البحرين", "بحريني", "بحرينيه"), "bh"),
    (("الاردن", "اردن", "اردني", "اردنيه"), "jo"),
    (("فلسطين", "فلسطيني", "فلسطينيه"), "ps"),
    (("تونس", "تونسي", "تونسيه"), "tn"),
    (("الجزائر", "جزائري", "جزائريه"), "dz"),
    (("السعوديه", "سعوديه", "السعودي", "سعودي", "المملكه العربيه السعوديه"), "sa"),
    (("المغرب", "مغرب", "المغربي", "مغربي", "المغربيه", "مغربيه"), "ma"),
    (("لبنان", "اللبناني", "لبناني", "اللبنانيه", "لبنانيه"), "lb"),
    (("العراق", "عراق", "العراقي", "عراقي", "العراقيه", "عراقيه"), "iq"),
    (("مصر", "مصري", "مصريه"), "eg"),
    (("سوريا", "سوريه", "السوري", "سوري", "السوريه"), "sy"),
    (("اليمن", "يمن", "اليمني", "يمني", "اليمنيه", "يمنيه"), "ye"),
)


# Arabic words of countries already covered by the bundled flag assets.
_ARABIC_COUNTRIES = _ARABIC_COUNTRIES + (
    (("المانيا", "الالمانيه", "الماني", "المانيه"), "de"),
    (("فرنسا", "فرنسي", "فرنسيه"), "fr"),
    (("بريطانيا", "انجلترا", "المملكه المتحده", "بريطاني"), "gb"),
    (("امريكا", "امريكي", "امريكيه", "الولايات المتحده"), "us"),
    (("ايطاليا", "ايطالي", "ايطاليه"), "it"),
    (("اسبانيا", "اسباني", "اسبانيه"), "es"),
    (("تركيا", "تركي", "تركيه"), "tr"),
    (("روسيا", "روسي", "روسيه"), "ru"),
    (("كندا", "كندي", "كنديه"), "ca"),
    (("استراليا", "استرالي"), "au"),
    (("هولندا", "هولندي"), "nl"),
    (("بلجيكا", "بلجيكي"), "be"),
    (("سويسرا", "سويسري"), "ch"),
    (("بولندا", "بولندي"), "pl"),
    (("البرتغال", "برتغالي"), "pt"),
    (("البرازيل", "برازيلي"), "br"),
    (("المكسيك", "مكسيكي"), "mx"),
    (("اليونان", "يوناني"), "gr"),
    (("التشيك", "تشيكي"), "cz"),
    (("السويد", "سويدي"), "se"),
    (("النرويج", "نرويجي"), "no"),
    (("الدنمارك", "دنماركي"), "dk"),
    (("فنلندا", "فنلندي"), "fi"),
    (("الصين", "صيني"), "cn"),
    (("اليابان", "ياباني"), "jp"),
    (("كوريا", "كوري"), "kr"),
    (("الهند", "هندي"), "in"),
    (("باكستان", "باكستاني"), "pk"),
    (("جنوب افريقيا", "افريقيا الجنوبيه"), "za"),
    (("نيوزيلندا", "نيوزلندا"), "nz"),
)

def _normalized_name(name):
    value = unicodedata.normalize("NFKD", str(name or ""))
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = _ARABIC_MARKS.sub("", value)
    value = value.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    value = value.replace("ى", "ي").replace("ة", "ه")
    value = value.replace("٤", "4")
    return value.lower()


def _token_sequence(name):
    return re.findall(r"[a-z0-9]+|[\u0621-\u064a]+", _normalized_name(name))


def package_country(name):
    """Match an explicit country, including Arabic and AR-UAE/AR-TUNISE.

    Never interpret AR (Arabic) as Argentina. Specific country prefixes beat
    regional brands; plain MBC/إم بي سي deliberately uses the Saudi flag.
    """
    normalized = _normalized_name(name)
    tokens = _token_sequence(name)
    if not tokens:
        return ""
    # Explicit country first, including a language marker followed by country.
    prefix = tokens[0]
    if prefix.upper() in _COUNTRIES:
        return _COUNTRIES[prefix.upper()]
    if prefix in ("ar", "ara", "arabic", "عربي", "العربي", "العربيه", "en", "eng", "english"):
        if len(tokens) > 1:
            match = _COUNTRIES.get(tokens[1].upper())
            if match:
                return match
            for names, country in _ARABIC_COUNTRIES:
                if tokens[1] in names:
                    return country
    if prefix in ("vip", "premium", "world", "channels", "channel", "tv", "live", "iptv", "all") and len(tokens) > 1:
        short = tokens[1].upper()
        if len(short) in (2, 3) and short in _COUNTRIES:
            return _COUNTRIES[short]
    for names, country in _ARABIC_COUNTRIES:
        # Arabic region must be a whole word, not a substring of another title.
        if any(re.search(r"(?<![\u0621-\u064a])%s(?![\u0621-\u064a])" % re.escape(n), normalized) for n in names):
            return country
    # Match explicit full country names ANYWHERE in a bouquet title, without
    # confusing generic English/Arabic language markers with countries.
    # Most two-letter ISO codes are intentionally prefix-only to avoid false
    # matches with common words (IN / IT / US / TR).
    # Keep multiword names distinct: "United States", "United Kingdom"...
    for words, country in _COUNTRY_PHRASES:
        width = len(words)
        for pos in range(len(tokens) - width + 1):
            if tuple(tokens[pos:pos+width]) == words:
                return country
    for token in tokens:
        match = _FULL_COUNTRY_NAMES.get(token)
        if match:
            return match
    # STC is a Saudi brand; a specific documentary category will take priority
    # in package_visual() before this generic national fallback is displayed.
    if "stc" in tokens or "اس تي سي" in normalized or "اس تي سى" in normalized:
        return "sa"
    # Explicit full English country words after language/region delimiters.
    # The accepted prefix tokens above cover formats such as AR-MOROCCO.
    # Saudi broadcasters: regional prefixes such as UAE-ROTANA still take
    # priority above this brand fallback.
    compact = "".join(tokens)
    if ("myhd" in tokens or ("my" in tokens and "hd" in tokens and tokens.index("my") + 1 == tokens.index("hd"))
            or any(v in compact for v in ("ماياتشدي", "مايهد"))):
        return "sa"
    if "rotana" in tokens or "روتانا" in normalized:
        return "sa"
    # MBC is a Saudi channel group, even when prefixed by AR / Arabic label.
    if ("mbc" in tokens or any(v in normalized for v in ("ام بي سي", "امبيسي", "ام بي سى"))):
        return "sa"
    return ""


def package_special_icon(name):
    """Small local logos used only on explicit matching Live package titles."""
    value = _normalized_name(name)
    compact = re.sub(r"[\s\-_|:.]+", "", value)
    tokens = _token_sequence(name)
    if ("bein" in compact or "beinsport" in compact or "beinsports" in compact
            or "بيانسبورت" in compact or "بينسبورت" in compact or "بيانسبور" in compact
            or ("bein" in tokens and any(t in tokens for t in ("sport", "sports", "max", "prem", "4k")))):
        return "beinsport"
    # Do not mislabel 4K as a country or generic movie package.
    if ("4k" in tokens or "uhd" in tokens or "فوركي" in compact or "فوركاي" in compact
            or "٤ك" in value or "4ك" in value or "اولترااتشدي" in compact):
        return "4k"
    if "ufc" in tokens or "يوافسي" in compact or "يوفسي" in compact:
        return "ufc"
    if "wwe" in tokens or "دبليودبليواي" in compact or "دبليودبليوايي" in compact:
        return "wwe"
    if "netflix" in compact or "netflex" in compact or "نتفليكس" in compact or "نتفلكس" in compact or "نيتفليكس" in compact:
        return "netflix"
    if any(t in tokens for t in ("entertainment", "entertain", "showbiz", "variety")) or any(w in value for w in ("ترفيه", "ترفيهي", "ترفيهيه", "منوعات", "تسلية")):
        return "entertainment"
    # Full-title matching: "STC DOC TV" is documentary, while "STC" is Saudi.
    # Look for whole DOC tokens so channel names containing "doctor" are safe.
    stc = "stc" in tokens or "اس تي سي" in value or "اس تي سى" in value
    doc = any(t in tokens for t in ("doc", "docs", "documentary", "documentaries", "culture", "cultural")) or any(w in value for w in ("وثائقي", "وثائقيه", "ثقافي", "ثقافيه"))
    if stc and doc:
        return "documentary"
    # Al Kass sports channels: connected, spaced, transliterated and Arabic.
    if ("alkass" in tokens or "alkas" in tokens or "alkass" in compact
            or ("al" in tokens and "kass" in tokens)
            or any(w in value for w in ("الكاس", "الكأس", "قنوات الكاس", "قنوات الكأس"))):
        return "sport"
    # Arab Channel: a dedicated local icon rather than a generic country flag.
    if (re.search(r"\barab(?:ic)?[\s._|:-]+(?:channel|channels|chanel)\b", value)
            or "القنوات العربيه" in value or "قنوات عربيه" in value):
        return "arab_channel"
    # DStv broadcasts across Africa; do not falsely use a single country flag.
    if "dstv" in tokens or "dstv" in compact or "دي اس تي في" in value:
        return "africa"
    # OSN movie brand: keep OSN Sports/News/Series distinct when explicitly named.
    osn = "osn" in tokens or any(v in compact for v in ("اواسان", "اوسان"))
    if osn:
        if any(t in tokens for t in ("sport", "sports", "news", "series", "kids")):
            return ""
        return "osn"
    return ""


def package_visual(name):
    """One full-title decision for the Live category icon, with clear priority.

    Specific branded/category matches precede generic STC -> Saudi fallback.
    An explicit Morocco/Lebanon country name still gets its national flag.
    """
    special = package_special_icon(name)
    if special in ("documentary", "sport", "arab_channel", "africa", "beinsport", "entertainment"):
        return "kind", special
    country = package_country(name)
    if country:
        return "country", country
    if special:
        return "kind", special
    return "kind", package_kind(name)


def package_kind(name):
    """Lightweight fallback icon when no country flag has arrived yet."""
    value = _normalized_name(name)
    if any(word in value for word in ("sport", "football", "soccer", "bein", "espn", "nba", "epl", "fifa", "sky sport", "رياضه", "رياضي", "كره", "مصارعه", "الكاس", "الكأس")):
        return "beinsport" if "bein" in value else "sport"
    if any(word in value for word in ("movie", "cinema", "film", "vod", "افلام", "سينما")):
        return "movies"
    if any(word in value for word in ("series", "show", "drama", "مسلسلات", "مسلسل", "دراما")):
        return "shows"
    if any(word in value for word in ("news", "اخبار", "عاجل")):
        return "news"
    if any(word in value for word in ("entertainment", "entertain", "showbiz", "variety", "ترفيه", "ترفيهي", "منوعات", "تسليه")):
        return "entertainment"
    if any(word in value for word in ("kids", "child", "cartoon", "طفل", "اطفال", "كرتون")):
        return "kids"
    if any(word in value for word in ("music", "radio", "موسيقي", "موسيقا", "اغاني")):
        return "music"
    if any(word in value for word in ("document", "history", "nature", "science", "وثائق", "طبيعه")):
        return "documentary"
    if any(word in value for word in ("religio", "quran", "islam", "دين", "قران", "اسلام")):
        return "religion"
    if any(word in value for word in ("cook", "food", "مطبخ", "طبخ", "طعام")):
        return "food"
    return "general"


def _valid_png(content):
    if not isinstance(content, bytes) or len(content) < 33 or len(content) > 65536:
        return False
    if content[:8] != b"\x89PNG\r\n\x1a\n" or content[12:16] != b"IHDR":
        return False
    width, height = struct.unpack(">II", content[16:24])
    return 12 <= width <= 256 and 9 <= height <= 256


def flag_cached_path(country):
    if country not in _COUNTRIES.values():
        return ""
    try:
        path = os.path.join(get_cache_dir("logos/live_country_flags"), country + ".png")
        return path if _artwork_queue.valid_image_file(path, 32) else ""
    except (OSError, IOError):
        return ""


def fetch_flag(country):
    """Background thread only; no GUI calls and no bulk country downloads."""
    if country not in _COUNTRIES.values():
        return ""
    cached = flag_cached_path(country)
    if cached:
        return cached
    # HTTPS with normal certificate checks. A failed request must never block
    # the UI or disable the local generic icon fallback.
    urls = (
        "https://flagcdn.com/24x18/%s.png" % country,
        "https://flagcdn.io/4x3/24/%s.png" % country,
    )
    for url in urls:
        try:
            response = urlopen(Request(url, headers={"User-Agent": "TiviMateE2/1.0"}), timeout=3)
            try:
                content = response.read(65537)
            finally:
                response.close()
            if not _valid_png(content):
                continue
            directory = get_cache_dir("logos/live_country_flags")
            target = os.path.join(directory, country + ".png")
            temp = target + ".part"
            with open(temp, "wb") as f:
                f.write(content)
            try:
                os.replace(temp, target)
            except AttributeError:
                os.rename(temp, target)
            return target if _artwork_queue.valid_image_file(target, 32) else ""
        except Exception:
            continue
    return ""
