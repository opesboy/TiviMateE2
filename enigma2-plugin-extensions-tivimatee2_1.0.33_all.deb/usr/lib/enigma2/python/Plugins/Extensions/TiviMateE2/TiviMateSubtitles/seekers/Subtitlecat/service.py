# -*- coding: utf-8 -*-
"""Subtitlecat for TiviMate: only the language you asked for, with its flag.

Subtitlecat's search page lists a release with "N languages" only. Each
result page is opened (in parallel, time-limited) to find the ready SRT of
the wanted language; results show that language (Arabic -> UAE flag) and the
download fetches exactly that SRT. Works on Python 2.7 and 3.
"""
from __future__ import absolute_import, print_function
import os
import re
import time
import random
import threading
import requests
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus, urljoin

try:
    import warnings
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    warnings.simplefilter('ignore', InsecureRequestWarning)
except Exception:
    pass

main_url = "https://www.subtitlecat.com"
_UA = random.choice([
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
])
HEADERS = {
    "User-Agent": _UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,ar;q=0.8",
    "Referer": main_url + "/",
}

MAX_PAGES = 30          # result pages opened per search
WORKERS = 6             # pages opened at the same time
TIME_BUDGET = 12.0      # seconds for the whole page check

# Subtitlecat language label -> (display name, ISO 639-1, ISO 639-2, flag country)
_LANGS = {
    "arabic": ("Arabic", "ar", "ara", "AE"),
    "english": ("English", "en", "eng", "GB"),
    "french": ("French", "fr", "fre", "FR"),
    "turkish": ("Turkish", "tr", "tur", "TR"),
    "spanish": ("Spanish", "es", "spa", "ES"),
    "german": ("German", "de", "ger", "DE"),
    "italian": ("Italian", "it", "ita", "IT"),
    "persian": ("Persian", "fa", "per", "IR"),
    "farsi": ("Persian", "fa", "per", "IR"),
    "urdu": ("Urdu", "ur", "urd", "PK"),
    "hindi": ("Hindi", "hi", "hin", "IN"),
    "indonesian": ("Indonesian", "id", "ind", "ID"),
    "portuguese": ("Portuguese", "pt", "por", "PT"),
    "russian": ("Russian", "ru", "rus", "RU"),
}
_ALIASES = {"ar": "arabic", "ara": "arabic", "arab": "arabic", u"العربية": "arabic",
            "en": "english", "eng": "english", "fr": "french", "fra": "french",
            "fre": "french", "tr": "turkish", "tur": "turkish", "es": "spanish",
            "spa": "spanish", "de": "german", "ger": "german", "deu": "german",
            "it": "italian", "ita": "italian", "fa": "persian", "per": "persian"}


def _norm(value):
    try:
        text = (value or "").strip().lower()
    except Exception:
        text = ""
    text = re.sub(r"\s*\(.*?\)\s*", "", text)      # "Arabic (translated)" -> arabic
    return _ALIASES.get(text, text)


def _wanted(languages):
    out = []
    for lang in languages or []:
        key = _norm(lang)
        if key and key not in out:
            out.append(key)
    return out or ["arabic"]


def _get(url, timeout=8):
    return requests.get(url, headers=HEADERS, verify=False, timeout=timeout)


def get_real_srt_links(page_url):
    """Ready SRT files on one result page: [{'language', 'download_link'}]."""
    response = _get(page_url)
    if response.status_code != 200:
        return []
    soup = BeautifulSoup(response.text, "html.parser")
    links = []
    for block in soup.find_all("div", class_="sub-single"):
        anchor = block.find("a", class_="green-link")
        if anchor is None or not anchor.get("href"):
            continue      # "translate" only, no ready file
        spans = block.find_all("span")
        language = ""
        for span in spans:
            text = span.get_text(" ", strip=True)
            if text and _norm(text) in _LANGS:
                language = text
                break
        if not language and len(spans) > 1:
            language = spans[1].get_text(" ", strip=True)
        links.append({"language": language,
                      "download_link": urljoin(main_url + "/", anchor["href"])})
    return links


def _search_rows(title):
    response = _get("%s/index.php?search=%s" % (main_url, quote_plus(title)))
    if response.status_code != 200:
        return []
    soup = BeautifulSoup(response.text, "html.parser")
    rows = []
    for row in soup.find_all("tr"):
        anchor = row.find("a")
        if anchor is None or not anchor.get("href"):
            continue
        name = anchor.get_text(" ", strip=True)
        href = urljoin(main_url + "/", anchor["href"].strip())
        if "/subs/" not in href:
            continue
        rows.append((name, href))
    # Releases that already name the wanted language are opened first.
    return rows


def _resolve(rows, wanted):
    """Open result pages in parallel; keep the ones with a wanted language."""
    results = [None] * len(rows)
    queue = list(enumerate(rows))
    lock = threading.Lock()
    deadline = time.time() + TIME_BUDGET

    def worker():
        while time.time() < deadline:
            with lock:
                if not queue:
                    return
                index, (name, href) = queue.pop(0)
            try:
                links = get_real_srt_links(href)
            except Exception:
                continue
            for want in wanted:
                hit = None
                for item in links:
                    if _norm(item.get("language")) == want:
                        hit = item
                        break
                if hit is not None:
                    results[index] = (name, href, want, hit["download_link"])
                    break

    threads = []
    for _ in range(min(WORKERS, len(rows))):
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
        threads.append(thread)
    for thread in threads:
        thread.join(max(0.1, deadline - time.time()) + 1)
    return [row for row in results if row]


def search_movie(title, year, languages, filename):
    wanted = _wanted(languages)
    rows = _search_rows(title)
    if year:
        rows.sort(key=lambda r: 0 if str(year) in r[0] else 1)
    hint = [w for w in wanted]
    rows.sort(key=lambda r: 0 if any(h in r[0].lower() for h in hint) else 1)
    subtitles = []
    for name, href, want, link in _resolve(rows[:MAX_PAGES], wanted):
        display, two, three, country = _LANGS.get(want, (want.title(), want[:2], want[:3], "UNK"))
        subtitles.append({
            "filename": name,
            "link": href,
            "language_name": display,
            "lang": {"name": display, "2et": two, "3et": three},
            "country": country,
            "sync": True,
            "_tivimate_direct_srt": link,
            "_tivimate_language": display,
        })
    return subtitles


def search_tvshow(tvshow, season, episode, languages, filename):
    try:
        query = "%s S%02dE%02d" % (tvshow, int(season), int(episode))
    except Exception:
        query = tvshow
    return search_movie(query, None, languages, filename)


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    languages = [lang1, lang2, lang3]
    if tvshow:
        return search_tvshow(tvshow, season, episode, languages, file_original_path), "", ""
    if title:
        return search_movie(title, year, languages, file_original_path), "", ""
    return [], "", ""


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """Download exactly the language shown in the list."""
    selected = subtitles_list[pos]
    link = selected.get("_tivimate_direct_srt", "")
    language = selected.get("_tivimate_language") or selected.get("language_name", "")
    if not link:
        want = _norm(language) or "arabic"
        for item in get_real_srt_links(selected.get("link", "")):
            if _norm(item.get("language")) == want:
                link = item["download_link"]
                break
    if not link:
        raise Exception("Subtitlecat: %s subtitle not available" % (language or "requested"))
    response = requests.get(link, headers=dict(HEADERS, Referer=selected.get("link") or main_url + "/"),
                            verify=False, timeout=12)
    if response.status_code != 200 or not response.content or response.content[:200].lstrip().lower().startswith(b"<"):
        raise Exception("Subtitlecat: download failed (HTTP %s)" % response.status_code)
    if not os.path.isdir(tmp_sub_dir):
        os.makedirs(tmp_sub_dir)
    file_name = link.split("/")[-1].split("?")[0] or "subtitle.srt"
    if not file_name.lower().endswith((".srt", ".ass", ".sub", ".vtt")):
        file_name += ".srt"
    file_path = os.path.join(tmp_sub_dir, file_name)
    with open(file_path, "wb") as handle:
        handle.write(response.content)
    return False, language, file_path
