# -*- coding: utf-8 -*-
"""Manual TMDb match (idea from Ultra Stalker manual_match).

When a movie or series shows the wrong poster/plot, the user presses MENU
on its details page, searches TMDb and picks the right title. The choice is
pinned by title + type and used everywhere TiviMate asks TMDb about that
title (details, posters, backdrops, logos), until the user resets it.

Store: <data root>/tmdb_manual_match_v1.json  (title keys -> TMDb row).
Works on Python 2.7 and 3. Nothing here runs unless the user asks.
"""
from __future__ import absolute_import

import json
import os
import threading
import time

from .storage import data_path

_LOCK = threading.RLock()
_STATE = {"path": "", "data": None}
_KEEP = ("id", "title", "name", "original_title", "original_name", "poster_path",
         "backdrop_path", "release_date", "first_air_date", "overview",
         "vote_average", "original_language", "genre_ids", "origin_country")
_MAX = 1000

try:
    _UNICODE = unicode  # noqa: F821  (Python 2.7)
except NameError:
    _UNICODE = None


def _txt(value):
    """Native GUI text: UTF-8 bytes on Python 2.7, str on Python 3."""
    if value is None:
        return ""
    if _UNICODE is not None:
        if isinstance(value, _UNICODE):
            return value.encode("utf-8")
        return str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


def _kind(kind):
    return "vod" if str(kind or "vod").lower() in ("vod", "movie", "movies", "film") else "series"


def _media(kind):
    return "movie" if _kind(kind) == "vod" else "tv"


def _norms(title, kind):
    """Every normalised form TiviMate may search this title under."""
    out = []
    try:
        from . import tmdb_client as T
        values = [title]
        try:
            values.append(T._tmdb_identity_anchor(title, _kind(kind)))
        except Exception:
            pass
        try:
            values.extend((T._tmdb_title_candidates(title) or [])[:1])
        except Exception:
            pass
        for value in values:
            norm = T._tmdb_match_norm(value)
            if norm and norm not in out:
                out.append(norm)
    except Exception:
        pass
    if not out:
        raw = " ".join(str(title or "").lower().split())
        if raw:
            out.append(raw)
    return out


def _path():
    return data_path("tmdb_manual_match_v1.json")


def _load():
    path = _path()
    if _STATE["data"] is not None and _STATE["path"] == path:
        return _STATE["data"]
    data = {}
    try:
        with open(path, "rb") as handle:
            data = json.loads(handle.read().decode("utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}
    _STATE["path"], _STATE["data"] = path, data
    return data


def _save(data):
    path = _path()
    temp = path + ".tmp"
    try:
        with open(temp, "wb") as handle:
            handle.write(json.dumps(data, ensure_ascii=True).encode("utf-8"))
        os.rename(temp, path)
        return True
    except Exception:
        try:
            os.unlink(temp)
        except Exception:
            pass
        return False


def get(title, kind="vod"):
    """Pinned TMDb row for this title, or None."""
    kind = _kind(kind)
    with _LOCK:
        data = _load()
        if not data:
            return None
        for norm in _norms(title, kind):
            row = data.get("%s|%s" % (kind, norm))
            if isinstance(row, dict) and row.get("id"):
                return dict(row)
    return None


def pinned_id(title, kind="vod"):
    row = get(title, kind)
    return str(row.get("id")) if row else ""


def put(title, kind, row):
    kind = _kind(kind)
    clean = dict((k, row.get(k)) for k in _KEEP if row.get(k) not in (None, ""))
    clean["id"] = int(row.get("id"))
    clean["_pinned"] = time.time()
    with _LOCK:
        data = _load()
        for norm in _norms(title, kind):
            data["%s|%s" % (kind, norm)] = clean
        if len(data) > _MAX:
            ordered = sorted(data.items(), key=lambda kv: kv[1].get("_pinned", 0), reverse=True)
            data = dict(ordered[:_MAX])
            _STATE["data"] = data
        return _save(data)


def remove(title, kind="vod"):
    kind = _kind(kind)
    with _LOCK:
        data = _load()
        changed = False
        for norm in _norms(title, kind):
            if data.pop("%s|%s" % (kind, norm), None) is not None:
                changed = True
        return _save(data) if changed else True


def search(client, query, kind="vod"):
    """TMDb candidates for a typed query (movie or tv only)."""
    media = _media(kind)
    rows, seen = [], set()
    languages = []
    for lang in (getattr(client, "language", "") or "en-US", "en-US"):
        if lang not in languages:
            languages.append(lang)
    for lang in languages:
        data = client._get("/search/%s" % media,
                           {"query": query, "page": 1, "language": lang, "include_adult": "false"}) or {}
        for row in (data.get("results") or [])[:20]:
            if not isinstance(row, dict) or not row.get("id") or row["id"] in seen:
                continue
            seen.add(row["id"])
            rows.append(row)
        if len(rows) >= 12:
            break
    return rows[:20]


def verify(client, tmdb_id, kind="vod"):
    """Fetch the chosen identity itself; refuse a different id."""
    data = client._get("/%s/%s" % (_media(kind), tmdb_id), {"language": getattr(client, "language", "en-US")}) or {}
    if str(data.get("id") or "") != str(tmdb_id):
        raise ValueError("TMDb returned a different title")
    return data


def _label(row, kind):
    name = row.get("title") or row.get("name") or row.get("original_title") or row.get("original_name") or "?"
    date = str(row.get("release_date") or row.get("first_air_date") or "")[:4]
    original = row.get("original_title") or row.get("original_name") or ""
    name, original, date = _txt(name), _txt(original), _txt(date)
    text = "%s (%s)" % (name, date) if date else name
    if original and original != name:
        text += "  -  %s" % original
    return text


# ---------------------------------------------------------------------------
# UI flow: MENU -> choose -> keyboard -> results -> pin -> reopen details
# ---------------------------------------------------------------------------
class _Flow(object):
    def __init__(self, screen, title, kind, reopen):
        self.screen = screen
        self.session = screen.session
        self.title = title
        self.kind = _kind(kind)
        self.reopen = reopen
        self.rows = []
        self.result = None
        self.timer = None

    def _tr(self, text):
        try:
            from .i18n import tr
            return tr(text)
        except Exception:
            return text

    def message(self, text, error=False):
        try:
            from Screens.MessageBox import MessageBox
            kind = MessageBox.TYPE_ERROR if error else MessageBox.TYPE_INFO
            self.session.open(MessageBox, _txt(self._tr(text)), kind, timeout=6)
        except Exception:
            pass

    def start(self):
        from Screens.ChoiceBox import ChoiceBox
        options = [(_txt(self._tr("Fix TMDb match (search the correct title)")), "search")]
        current = get(self.title, self.kind)
        if current:
            options.append((_txt(self._tr("Reset TMDb match")) + "  [%s]" % _label(current, self.kind), "reset"))
        self.session.openWithCallback(self.chosen, ChoiceBox,
                                      title=_txt(self._tr("TMDb match")) + ": " + _txt(self.title),
                                      list=options)

    def chosen(self, choice):
        if not choice:
            return
        if choice[1] == "reset":
            remove(self.title, self.kind)
            self.message("TMDb match reset. The automatic match is used again.")
            self.done()
            return
        from Screens.VirtualKeyBoard import VirtualKeyBoard
        self.session.openWithCallback(self.typed, VirtualKeyBoard,
                                      title=_txt(self._tr("Search TMDb")), text=_txt(self.title))

    def typed(self, text):
        text = _txt(text).strip()
        if not text:
            return
        if _UNICODE is not None:
            text = text.decode("utf-8", "replace")
        self._run(lambda client: search(client, text, self.kind), self.found)

    def _run(self, work, finish):
        """Network work off the GUI thread, result back on it."""
        state = {"done": False, "value": None, "error": None}

        def worker():
            try:
                from .tmdb_client import TMDbClient
                client = TMDbClient()
                if not client.configured():
                    raise ValueError("TMDb is not configured")
                state["value"] = work(client)
            except Exception as exc:
                state["error"] = exc
            state["done"] = True

        thread = threading.Thread(target=worker, name="TiviMateManualMatch")
        thread.daemon = True
        thread.start()
        from enigma import eTimer
        self.timer = eTimer()

        def poll():
            if not state["done"]:
                self.timer.start(200, True)
                return
            if state["error"] is not None:
                self.message("TMDb search failed: %s" % _txt(state["error"]), error=True)
                return
            finish(state["value"])
        try:
            self._conn = self.timer.timeout.connect(poll)
        except AttributeError:
            self.timer.callback.append(poll)
        self.timer.start(200, True)

    def found(self, rows):
        self.rows = list(rows or [])
        if not self.rows:
            self.message("No TMDb results. Try another spelling or the English title.")
            return
        from Screens.ChoiceBox import ChoiceBox
        options = [(_label(row, self.kind), row) for row in self.rows]
        self.session.openWithCallback(self.picked, ChoiceBox,
                                      title=_txt(self._tr("Choose the correct title")), list=options)

    def picked(self, choice):
        if not choice or not isinstance(choice[1], dict):
            return
        row = choice[1]
        self._run(lambda client: verify(client, row.get("id"), self.kind), self.verified)

    def verified(self, data):
        if not data or not data.get("id"):
            return
        if put(self.title, self.kind, data):
            self.done()
        else:
            self.message("Could not save the TMDb match.", error=True)

    def done(self):
        try:
            if callable(self.reopen):
                self.reopen()
        except Exception as exc:
            print("[TiviMateE2] manual match reopen failed: %s" % exc)


def open_menu(screen, title, kind, reopen):
    """Entry point used by the Movie and Series details screens (MENU key)."""
    try:
        flow = _Flow(screen, title, kind, reopen)
        screen._tivimate_manual_match_flow = flow
        flow.start()
    except Exception as exc:
        print("[TiviMateE2] manual match failed to open: %s" % exc)


def reopen_later(session, screen, screen_class, *args):
    """Close the current details page and open it again with fresh data."""
    from enigma import eTimer
    holder = {}

    def fire():
        try:
            session.open(screen_class, *args)
        except Exception as exc:
            print("[TiviMateE2] manual match reopen failed: %s" % exc)
        holder.clear()
    timer = eTimer()
    holder["timer"] = timer
    try:
        holder["conn"] = timer.timeout.connect(fire)
    except AttributeError:
        timer.callback.append(fire)
    try:
        screen.close()
    except Exception:
        pass
    timer.start(150, True)
    _REOPEN.append(holder)
    del _REOPEN[:-4]


_REOPEN = []
