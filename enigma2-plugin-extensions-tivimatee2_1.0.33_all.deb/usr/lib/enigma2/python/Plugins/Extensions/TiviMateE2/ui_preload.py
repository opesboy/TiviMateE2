# -*- coding: utf-8 -*-
"""Safely precompile the trusted built-in UI fragments without importing any Enigma widget.

This work runs after session start and only uses Python's compiler; all
Enigma screens/objects continue to be created on the main GUI thread.
"""
import os
import threading

_LOCK = threading.Lock()
_CODE = {}
_STARTED = False
_RELEASED = False


def _signature(path):
    stat = os.stat(path)
    return (stat.st_size, getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1000000000)))


def _python_tag():
    try:
        import importlib.util
        magic = importlib.util.MAGIC_NUMBER
    except Exception:
        try:
            import imp
            magic = imp.get_magic()
        except Exception:
            magic = b""
    try:
        magic = bytearray(magic)
        return "".join("%02x" % c for c in magic)
    except Exception:
        return "py"


def _disk_code_path(path):
    """_ui_parts/__pycache__/<name>.<python magic>.tmcode"""
    folder = os.path.join(os.path.dirname(path), "__pycache__")
    return os.path.join(folder, "%s.%s.tmcode" % (os.path.basename(path), _python_tag()))


def _load_disk_code(path):
    """Bytecode of an unchanged fragment, written by an earlier start.

    The UI fragments are ~2 MB of source. Compiling them on every GUI start
    took many seconds on small receivers (e.g. Vu+ Zero 4K); the cached
    bytecode is only reused when the source size and mtime are identical.
    """
    try:
        import marshal
        size, mtime = _signature(path)
        with open(_disk_code_path(path), "rb") as handle:
            header = handle.readline().strip()
            if header != ("%d:%d" % (size, mtime)).encode("ascii"):
                return None
            return marshal.loads(handle.read())
    except Exception:
        return None


def _save_disk_code(path, code):
    try:
        import marshal
        size, mtime = _signature(path)
        target = _disk_code_path(path)
        folder = os.path.dirname(target)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temp = "%s.%d.tmp" % (target, os.getpid())
        with open(temp, "wb") as handle:
            handle.write(("%d:%d\n" % (size, mtime)).encode("ascii"))
            handle.write(marshal.dumps(code))
        os.rename(temp, target)
    except Exception:
        try:
            os.remove(temp)
        except Exception:
            pass


def get_compiled_part(path):
    """Return a compiled fragment if unchanged, otherwise compile it normally."""
    path = os.path.abspath(path)
    try:
        signature = _signature(path)
        with _LOCK:
            if not _RELEASED:
                entry = _CODE.get(path)
                if entry and entry[0] == signature:
                    return entry[1]
    except Exception:
        pass
    compiled = _load_disk_code(path)
    if compiled is None:
        with open(path, "rb") as handle:
            data = handle.read()
        compiled = compile(data, path, "exec")
        _save_disk_code(path, compiled)
    # Only retain the code if source did not change while reading it.
    try:
        signature = _signature(path)
        with _LOCK:
            if not _RELEASED:
                _CODE[path] = (signature, compiled)
    except Exception:
        pass
    return compiled


def start_prewarm():
    """Start once; don't import UI or create Enigma widgets in this thread."""
    global _STARTED
    with _LOCK:
        if _STARTED:
            return
        _STARTED = True

    def worker():
        folder = os.path.join(os.path.dirname(__file__), "_ui_parts")
        names = (
            "01_common_and_skins.py", "02_editors_and_tmdb.py",
            "03_packages_and_settings.py", "04_server_manager.py",
            "05_search_home_continue.py", "06_series_details.py",
            "07_media_and_favorites.py",
        )
        for name in names:
            with _LOCK:
                if _RELEASED:
                    return
            try:
                get_compiled_part(os.path.join(folder, name))
            except Exception:
                # The UI loader will compile the original source on demand.
                pass
    t = threading.Thread(target=worker, name="TiviMateUICompileWarmup")
    t.daemon = True
    t.start()


def release():
    """Discard warmed code after the UI module has imported successfully."""
    global _RELEASED
    with _LOCK:
        _RELEASED = True
        _CODE.clear()
