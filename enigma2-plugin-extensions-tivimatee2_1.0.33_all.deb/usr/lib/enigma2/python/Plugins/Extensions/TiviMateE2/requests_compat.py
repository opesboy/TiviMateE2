# -*- coding: utf-8 -*-
"""Minimal stdlib stand-in for python3-requests on lean Enigma2 images.

OpenPLi (and other minimal Python 3 images) ship without python3-requests.
The Stalker engine ("EStalker native mode requires requests.Session") and
the subtitle seekers then could not work at all: every Stalker server showed
OFF although the same portals worked on other receivers.

install() registers this module as ``requests`` ONLY when the real package
cannot be imported; receivers that have requests keep using it unchanged.

Covered API: get/post/head/request, Session (headers, cookies, mount,
get/post/head/put/delete, context manager), Response (content/text/json/
status_code/ok/headers/url/raise_for_status/iter_content/iter_lines/raw/
close, lazy body for stream=True), adapters.HTTPAdapter, exceptions, codes,
compat, utils and the packages.urllib3 warning helpers.
"""
import http.cookiejar
import io
import json as _json
import socket
import ssl
import sys
import types
import urllib.error
import urllib.parse
import urllib.request
import zlib

__version__ = "2.0.0-tivimate-compat"
_tivimate_compat = True


# --------------------------------------------------------------- exceptions
class RequestException(IOError):
    def __init__(self, *args, **kwargs):
        self.response = kwargs.pop("response", None)
        self.request = kwargs.pop("request", None)
        IOError.__init__(self, *args)


class HTTPError(RequestException):
    pass


class ConnectionError(RequestException):  # noqa: A001 - requests name
    pass


class SSLError(ConnectionError):
    pass


class Timeout(RequestException):
    pass


class ConnectTimeout(ConnectionError, Timeout):
    pass


class ReadTimeout(Timeout):
    pass


class TooManyRedirects(RequestException):
    pass


class InvalidURL(RequestException, ValueError):
    pass


class ChunkedEncodingError(RequestException):
    pass


class ContentDecodingError(RequestException):
    pass


class InsecureRequestWarning(Warning):
    pass


exceptions = types.ModuleType("requests.exceptions")
for _cls in (RequestException, HTTPError, ConnectionError, SSLError, Timeout,
             ConnectTimeout, ReadTimeout, TooManyRedirects, InvalidURL,
             ChunkedEncodingError, ContentDecodingError):
    setattr(exceptions, _cls.__name__, _cls)
exceptions.InsecureRequestWarning = InsecureRequestWarning

compat = types.ModuleType("requests.compat")
compat.urljoin = urllib.parse.urljoin
compat.urlencode = urllib.parse.urlencode
compat.quote = urllib.parse.quote
compat.unquote = urllib.parse.unquote
compat.urlparse = urllib.parse.urlparse


class _Codes(object):
    ok = 200
    OK = 200
    created = 201
    no_content = 204
    moved = 301
    found = 302
    not_modified = 304
    bad_request = 400
    unauthorized = 401
    forbidden = 403
    not_found = 404
    too_many_requests = 429
    server_error = 500


codes = _Codes()

packages = types.ModuleType("requests.packages")
urllib3 = types.ModuleType("requests.packages.urllib3")
urllib3_exceptions = types.ModuleType("requests.packages.urllib3.exceptions")
urllib3_exceptions.InsecureRequestWarning = InsecureRequestWarning
urllib3.exceptions = urllib3_exceptions
urllib3.disable_warnings = lambda *args, **kwargs: None
packages.urllib3 = urllib3


class HTTPAdapter(object):
    """Accepted and ignored (pooling/retries are handled per request)."""
    def __init__(self, *args, **kwargs):
        self.max_retries = kwargs.get("max_retries", 0)

    def close(self):
        pass


adapters = types.ModuleType("requests.adapters")
adapters.HTTPAdapter = HTTPAdapter


# --------------------------------------------------------------- structures
class CaseInsensitiveDict(dict):
    def __init__(self, data=None, **kwargs):
        dict.__init__(self)
        self.update(data or {}, **kwargs)

    def _real(self, key):
        lowered = str(key).lower()
        for existing in dict.keys(self):
            if existing.lower() == lowered:
                return existing
        return None

    def __setitem__(self, key, value):
        real = self._real(key)
        if real is not None and real != key:
            dict.__delitem__(self, real)
        dict.__setitem__(self, key, value)

    def __getitem__(self, key):
        real = self._real(key)
        if real is None:
            raise KeyError(key)
        return dict.__getitem__(self, real)

    def __delitem__(self, key):
        real = self._real(key)
        if real is None:
            raise KeyError(key)
        dict.__delitem__(self, real)

    def __contains__(self, key):
        return self._real(key) is not None

    def get(self, key, default=None):
        real = self._real(key)
        return default if real is None else dict.__getitem__(self, real)

    def pop(self, key, *default):
        real = self._real(key)
        if real is None:
            if default:
                return default[0]
            raise KeyError(key)
        return dict.pop(self, real)

    def setdefault(self, key, default=None):
        if key not in self:
            self[key] = default
        return self[key]

    def update(self, data=None, **kwargs):
        if data:
            items = data.items() if hasattr(data, "items") else data
            for key, value in items:
                self[key] = value
        for key, value in kwargs.items():
            self[key] = value

    def copy(self):
        return CaseInsensitiveDict(self)


class _CookieView(object):
    """dict-like view over a cookiejar (get/set/update/items/get_dict)."""
    def __init__(self, jar):
        self.jar = jar

    @staticmethod
    def _cookie(name, value, domain=""):
        return http.cookiejar.Cookie(
            0, name, value, None, False, domain, bool(domain),
            domain.startswith("."), "/", True, False, None, False, None, None, {})

    def set(self, name, value, domain="", **kwargs):
        self.jar.set_cookie(self._cookie(str(name), str(value), domain or kwargs.get("domain", "") or ""))

    __setitem__ = set

    def update(self, other):
        for key, value in (other.items() if hasattr(other, "items") else other):
            self.set(key, value)

    def get(self, name, default=None, **kwargs):
        for cookie in self.jar:
            if cookie.name == name:
                return cookie.value
        return default

    def __getitem__(self, name):
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __contains__(self, name):
        return self.get(name) is not None

    def items(self):
        return [(c.name, c.value) for c in self.jar]

    def keys(self):
        return [c.name for c in self.jar]

    def values(self):
        return [c.value for c in self.jar]

    def get_dict(self, *args, **kwargs):
        return dict(self.items())

    def clear(self, *args):
        self.jar.clear(*args)

    def __iter__(self):
        return iter(self.jar)

    def __len__(self):
        return len(list(self.jar))


def _decode_body(data, headers):
    encoding = str(headers.get("content-encoding") or "").lower()
    try:
        if encoding == "gzip":
            return zlib.decompress(data, 16 + zlib.MAX_WBITS)
        if encoding == "deflate":
            try:
                return zlib.decompress(data)
            except zlib.error:
                return zlib.decompress(data, -zlib.MAX_WBITS)
    except zlib.error:
        pass
    return data


class Response(object):
    def __init__(self):
        self._content = None
        self._raw = None
        self.status_code = 0
        self.headers = CaseInsensitiveDict()
        self.url = ""
        self.reason = ""
        self.history = []
        self.encoding = None
        self.cookies = {}
        self.request = None
        self.elapsed = None

    # Body is read lazily: stream=True probes that only need the status
    # code never download a whole page.
    @property
    def content(self):
        if self._content is None:
            data = b""
            raw = self._raw
            if raw is not None:
                try:
                    data = raw.read() or b""
                except socket.timeout as error:
                    raise ReadTimeout(str(error))
                except Exception:
                    data = b""
                finally:
                    self.close()
            self._content = _decode_body(data, self.headers)
        return self._content

    @content.setter
    def content(self, value):
        self._content = value

    @property
    def ok(self):
        return self.status_code < 400

    @property
    def apparent_encoding(self):
        return "utf-8"

    @property
    def text(self):
        encodings = []
        if self.encoding:
            encodings.append(self.encoding)
        ctype = str(self.headers.get("content-type") or "")
        if "charset=" in ctype.lower():
            encodings.append(ctype.lower().split("charset=", 1)[1].split(";")[0].strip(" \"'"))
        encodings.extend(("utf-8", "cp1256", "latin-1"))
        content = self.content
        for encoding in encodings:
            try:
                return content.decode(encoding)
            except (UnicodeError, LookupError):
                continue
        return content.decode("utf-8", "replace")

    def json(self, **kwargs):
        return _json.loads(self.text, **kwargs)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPError("%s Error: %s for url: %s" % (self.status_code, self.reason, self.url),
                            response=self)

    def iter_content(self, chunk_size=8192, decode_unicode=False):
        chunk_size = int(chunk_size or 8192)
        content = self.content
        for pos in range(0, len(content), chunk_size):
            yield content[pos:pos + chunk_size]

    def iter_lines(self, chunk_size=512, decode_unicode=False, delimiter=None):
        raw = self._raw
        encoded = str(self.headers.get("content-encoding") or "").lower() in ("gzip", "deflate")
        if self._content is None and raw is not None and not encoded:
            # Stream line by line (portal launcher probes stop early).
            try:
                while True:
                    line = raw.readline()
                    if not line:
                        break
                    yield line.rstrip(b"\r\n")
            except socket.timeout as error:
                raise ReadTimeout(str(error))
            finally:
                self.close()
            return
        for line in self.content.splitlines():
            yield line

    @property
    def raw(self):
        if self._content is None and self._raw is not None:
            return self._raw
        return io.BytesIO(self.content)

    def close(self):
        raw = self._raw
        self._raw = None
        if raw is not None:
            try:
                raw.close()
            except Exception:
                pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False

    def __bool__(self):
        return self.ok


# --------------------------------------------------------------- transport
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_CONTEXTS = {}


def _context(verify):
    try:
        if verify is False:
            ctx = _CONTEXTS.get("insecure")
            if ctx is None:
                ctx = ssl._create_unverified_context()
                _CONTEXTS["insecure"] = ctx
            return ctx
        if isinstance(verify, str) and verify:
            ctx = ssl.create_default_context(cafile=verify)
            return ctx
        ctx = _CONTEXTS.get("default")
        if ctx is None:
            ctx = ssl.create_default_context()
            _CONTEXTS["default"] = ctx
        return ctx
    except Exception:
        return None


def _text(value):
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return value if isinstance(value, str) else str(value)


def _encode_params(params):
    if not params:
        return ""
    if isinstance(params, (str, bytes)):
        return _text(params)
    items = params.items() if hasattr(params, "items") else params
    pairs = []
    for key, value in items:
        if value is None:
            continue
        if isinstance(value, (list, tuple)):
            for item in value:
                pairs.append((_text(key), _text(item)))
        else:
            pairs.append((_text(key), _text(value)))
    return urllib.parse.urlencode(pairs)


class Session(object):
    def __init__(self):
        self.headers = CaseInsensitiveDict({
            "User-Agent": "Mozilla/5.0 (Linux; Enigma2) python-requests-compat",
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
        })
        self._jar = http.cookiejar.CookieJar()
        self.cookies = _CookieView(self._jar)
        self.verify = True
        self.proxies = {}
        self.auth = None
        self.max_redirects = 30
        self.adapters = {}

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False

    def close(self):
        pass

    def mount(self, prefix, adapter):
        self.adapters[prefix] = adapter

    def request(self, method, url, params=None, data=None, headers=None,
                cookies=None, files=None, auth=None, timeout=None,
                allow_redirects=True, proxies=None, hooks=None, stream=None,
                verify=None, cert=None, json=None):
        method = str(method or "GET").upper()
        url = _text(url)
        if not url.lower().startswith(("http://", "https://")):
            raise InvalidURL("Invalid URL %r" % url)
        query = _encode_params(params)
        if query:
            url = url + ("&" if "?" in url else "?") + query
        merged = CaseInsensitiveDict(self.headers)
        merged.update(headers or {})
        body = None
        if json is not None:
            body = _json.dumps(json).encode("utf-8")
            if "content-type" not in merged:
                merged["Content-Type"] = "application/json"
        elif data is not None:
            if isinstance(data, (dict, list, tuple)):
                body = _encode_params(data).encode("utf-8")
                if "content-type" not in merged:
                    merged["Content-Type"] = "application/x-www-form-urlencoded"
            elif isinstance(data, str):
                body = data.encode("utf-8")
            else:
                body = data
        if cookies:
            self.cookies.update(cookies)
        if isinstance(timeout, (tuple, list)):
            timeout = max(float(x or 0) for x in timeout) or None
        timeout = float(timeout) if timeout else 30.0
        verify = self.verify if verify is None else verify

        handlers = [urllib.request.HTTPCookieProcessor(self._jar)]
        context = _context(verify)
        if context is not None:
            handlers.append(urllib.request.HTTPSHandler(context=context))
        if not allow_redirects:
            handlers.append(_NoRedirect())
        opener = urllib.request.build_opener(*handlers)
        request = urllib.request.Request(url, data=body, method=method)
        for key, value in merged.items():
            if value is not None:
                request.add_header(_text(key), _text(value))

        response = Response()
        response.request = request
        raw = None
        try:
            raw = opener.open(request, timeout=timeout)
            response.status_code = int(raw.getcode() or 200)
            response.reason = getattr(raw, "reason", "") or getattr(raw, "msg", "") or ""
            response.url = raw.geturl()
            info = raw.info()
        except urllib.error.HTTPError as error:
            response.status_code = int(error.code or 0)
            response.reason = str(getattr(error, "reason", "") or "")
            response.url = error.geturl() if hasattr(error, "geturl") else url
            info = error.headers
            raw = error
        except urllib.error.URLError as error:
            reason = getattr(error, "reason", error)
            if isinstance(reason, socket.timeout):
                raise ConnectTimeout(str(reason))
            if isinstance(reason, ssl.SSLError):
                raise SSLError(str(reason))
            raise ConnectionError(str(reason))
        except socket.timeout as error:
            raise ReadTimeout(str(error))
        except ssl.SSLError as error:
            if "timed out" in str(error).lower():
                raise ReadTimeout(str(error))
            raise SSLError(str(error))
        except (OSError, IOError) as error:
            raise ConnectionError(str(error))
        headers_out = CaseInsensitiveDict()
        try:
            for key, value in info.items():
                if key in headers_out:
                    headers_out[key] = headers_out[key] + ", " + value
                else:
                    headers_out[key] = value
        except Exception:
            pass
        response.headers = headers_out
        response._raw = raw
        if not stream:
            response.content  # read now, like requests without stream=True
        response.cookies = dict(self.cookies.items())
        return response

    def get(self, url, **kwargs):
        kwargs.setdefault("allow_redirects", True)
        return self.request("GET", url, **kwargs)

    def post(self, url, data=None, json=None, **kwargs):
        return self.request("POST", url, data=data, json=json, **kwargs)

    def head(self, url, **kwargs):
        kwargs.setdefault("allow_redirects", False)
        return self.request("HEAD", url, **kwargs)

    def put(self, url, data=None, **kwargs):
        return self.request("PUT", url, data=data, **kwargs)

    def delete(self, url, **kwargs):
        return self.request("DELETE", url, **kwargs)


def session():
    return Session()


def request(method, url, **kwargs):
    return Session().request(method, url, **kwargs)


def get(url, params=None, **kwargs):
    return Session().get(url, params=params, **kwargs)


def post(url, data=None, json=None, **kwargs):
    return Session().post(url, data=data, json=json, **kwargs)


def head(url, **kwargs):
    return Session().head(url, **kwargs)


utils = types.ModuleType("requests.utils")
utils.quote = urllib.parse.quote
utils.unquote = urllib.parse.unquote
utils.urlparse = urllib.parse.urlsplit


def install():
    """Register as ``requests`` only when the real package is unavailable."""
    existing = sys.modules.get("requests")
    if existing is not None and not getattr(existing, "_tivimate_compat", False):
        return False
    if existing is None:
        try:
            import requests as _real  # noqa: F401
            if not getattr(_real, "_tivimate_compat", False):
                return False
        except Exception:
            sys.modules.pop("requests", None)
    module = sys.modules.get(__name__)
    if module is None:
        return False
    sys.modules["requests"] = module
    sys.modules["requests.exceptions"] = exceptions
    sys.modules["requests.compat"] = compat
    sys.modules["requests.utils"] = utils
    sys.modules["requests.adapters"] = adapters
    sys.modules["requests.packages"] = packages
    sys.modules["requests.packages.urllib3"] = urllib3
    sys.modules["requests.packages.urllib3.exceptions"] = urllib3_exceptions
    return True
