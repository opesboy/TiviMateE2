# -*- coding: utf-8 -*-
"""Dreambox DM900/DM920 400x240 front LCD artwork (cached images only).

Uses Enigma2's *summary screen* on the front-panel desktop, not /dev/lcd0,
not an LCD4Linux file, and never steals the system InfoBar display.  Each
TiviMate2 summary is disposed by Enigma2 as soon as its page/player closes.
Nothing is downloaded here: all HTTP artwork stays with its original queue.
"""
from __future__ import absolute_import

import os
import time
import re

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ProgressBar import ProgressBar
from enigma import ePicLoad, eTimer


_IMAGES = ('.png', '.jpg', '.jpeg', '.webp', '.bmp')


def dream_lcd_available():
    """Use only the known 400x240 colour Dreambox displays, never Vu+/ATV."""
    machine = ''
    for file_name in ('/proc/stb/info/model', '/proc/stb/info/boxtype',
                      '/proc/stb/info/hwmodel'):
        try:
            with open(file_name, 'r') as stream:
                machine = stream.read(60).strip().lower()
            if machine:
                break
        except (IOError, OSError):
            pass
    if not machine:
        try:
            from Components.SystemInfo import BoxInfo
            machine = str(BoxInfo.getItem('model') or BoxInfo.getItem('machinebuild') or '').lower()
        except Exception:
            pass
    return machine in ('dm900', 'dm920', 'dreambox900', 'dreambox920',
                       'dm900uhd', 'dm920uhd')


def _local_image(path):
    try:
        path = str(path or '').strip()
        return (path if path.startswith('/') and
                path.lower().endswith(_IMAGES) and os.path.isfile(path) and
                os.path.getsize(path) > 128 else '')
    except (IOError, OSError, ValueError):
        return ''


def _cache_only_image(item, category, source=None):
    if not isinstance(item, dict):
        return ''
    if category == 'picons':
        try:
            from .estalker_picon import resolve_picon_url, cached_picon_path
            url = resolve_picon_url(item, source)
            if url:
                for size in ((240, 100), (280, 168), (220, 130)):
                    file_name = _local_image(cached_picon_path(url, size))
                    if file_name:
                        return file_name
        except Exception:
            pass
        for field in ('_picon_path', 'picon_path', 'cached_picon'):
            file_name = _local_image(item.get(field))
            if file_name:
                return file_name
        # Also support DreamOS's ordinary service-reference picon folders.
        # This is a read-only local fallback if TiviMate's picon cache is not
        # present in an older DreamOS branch.  Never trigger a download.
        ref = item.get('service_ref') or item.get('serviceref') or item.get('ref') or ''
        try:
            ref = ref.toString() if hasattr(ref, 'toString') else str(ref)
            ref = '_'.join(ref.split(':')[:10]).rstrip('_')
            if ref:
                for directory in ('/usr/share/enigma2/picon', '/media/hdd/picon',
                                  '/media/usb/picon', '/picon'):
                    hit = _local_image(os.path.join(directory, ref + '.png'))
                    if hit:
                        return hit
        except Exception:
            pass
        return ''

    for field in ('_player_cover_cache', '_player_cover_cache_fallback',
                  '_front_panel_poster_file', '_cached_poster',
                  '_resolved_poster_cache', 'local_poster'):
        file_name = _local_image(item.get(field))
        if file_name:
            return file_name

    urls = []
    for field in ('_resolved_server_poster', '_genre_poster_url',
                  '_player_cover', 'cover', 'poster', 'movie_image',
                  'poster_image', 'stream_icon', 'image_url', '_tmdb_poster',
                  'poster_path', 'thumbnail', 'series_poster'):
        raw = str(item.get(field) or '').strip().replace('\\/', '/')
        if raw and raw not in urls:
            if raw.startswith('/') and not os.path.isfile(raw) and len(raw) < 150:
                # TMDb stores relative paths like /abc123.jpg.
                urls.append('https://image.tmdb.org/t/p/w500' + raw)
            else:
                urls.append(raw)
    try:
        from .poster_manager import provider_poster_url
        if source:
            server = provider_poster_url(source, item)
            if server and server not in urls:
                urls.insert(0, server)
    except Exception:
        pass
    try:
        from .artwork_queue import cached_artwork
        for url in urls:
            hit = _local_image(url)
            if not hit and url.startswith(('http://', 'https://')):
                hit = _local_image(cached_artwork(url, 'posters'))
            if hit:
                return hit
    except Exception:
        pass
    return ''


def _selected(screen):
    """Return active kind, selected catalogue row and provider without I/O."""
    if screen is None:
        return ('', {}, {})
    source = getattr(screen, 'source', {}) or {}
    if not isinstance(source, dict):
        source = {}
    kind = str(getattr(screen, 'kind', '') or '').lower()
    cls = screen.__class__.__name__
    if cls == 'TiviMateLivePlayer':
        try:
            return 'picons', screen._current(), source
        except Exception:
            return 'picons', {}, source
    if cls == 'LiveWindowsScreen':
        if getattr(screen, '_packagesOpen', False):
            return 'picons', {}, source
        rows = getattr(screen, 'grid_items', ()) or ()
        idx = getattr(screen, 'focusIndex', 0)
        parent = getattr(screen, 'parentLive', None)
        return 'picons', (rows[idx] if 0 <= idx < len(rows) else {}), (getattr(parent, 'source', {}) or {})
    if kind == 'live':
        try:
            return 'picons', screen.current() or {}, source
        except Exception:
            return 'picons', {}, source
    if cls == 'TiviMatePlayer':
        return 'posters', (getattr(screen, 'item', None) or {}), source
    if cls == 'SeriesDetailsScreen':
        return 'posters', (getattr(screen, 'seriesItem', None) or {}), source
    if cls == 'MovieDetailsScreen':
        return 'posters', (getattr(screen, 'item', None) or {}), source
    if hasattr(screen, 'genre_items'):
        rows = getattr(screen, 'genre_items', ()) or ()
        idx = getattr(screen, 'index', 0)
        return 'posters', (rows[idx] if 0 <= idx < len(rows) else {}), source
    if callable(getattr(screen, 'current', None)):
        try:
            row = screen.current()
            if isinstance(row, dict):
                return 'posters', row, source
        except Exception:
            pass
    return '', {}, source


def _title(item):
    for field in ('name', 'title', 'stream_name', 'series_name', 'channel_name'):
        if item.get(field):
            return str(item[field]).strip()[:52]
    return ''


def _saved_artwork(item, keys, category):
    """Reuse already-cached imagery; never start work in front-LCD thread."""
    if not isinstance(item, dict):
        return ''
    for field in keys:
        file_name = _local_image(item.get(field))
        if file_name:
            return file_name
    try:
        from .artwork_queue import cached_artwork
        for field in keys:
            raw = str(item.get(field) or '').strip().replace('\\\\/', '/')
            if raw.startswith('/') and len(raw) < 150 and not os.path.isfile(raw):
                raw = 'https://image.tmdb.org/t/p/w500' + raw
            if raw.startswith(('https://', 'http://')):
                hit = _local_image(cached_artwork(raw, category))
                if hit:
                    return hit
    except Exception:
        pass
    return ''


def _movie_artwork(screen, item, source):
    """Prefer a cinematic cached backdrop, then the existing player poster."""
    backdrop_keys = (
        '_front_panel_backdrop_file', '_cached_backdrop', '_backdrop_cache',
        '_resolved_backdrop_cache', 'local_backdrop', '_genre_backdrop_url',
        '_resolved_server_backdrop', '_tmdb_backdrop', 'backdrop',
        'backdrop_path', 'backdrop_url', 'background_image',
    )
    hit = _saved_artwork(item, backdrop_keys, 'backdrops')
    if hit:
        return hit
    hit = _local_image(getattr(screen, '_cover_cached_path', ''))
    if hit:
        return hit
    return _cache_only_image(item, 'posters', source)


def _clean(value, max_chars=44):
    try:
        return str(value or '').strip().replace('\\n', ' ').replace('\\r', ' ')[:max_chars]
    except Exception:
        return ''


def _film_meta(item):
    year = _clean(item.get('year') or item.get('release_date'), 10)[:4]
    quality = _clean(item.get('quality') or item.get('resolution'), 8).upper()
    rating = _clean(item.get('rating') or item.get('vote_average'), 8)
    pieces = [value for value in (year, quality, ('★ ' + rating) if rating else '') if value]
    return '   '.join(pieces)[:45]


def _live_context(screen, item):
    """Use already-resolved Live EPG, not synchronous EPG/network lookup."""
    context = getattr(screen, '_live_epg_context', {}) or {}
    if not isinstance(context, dict):
        context = {}
    now_title = _clean(context.get('title') or item.get('epg_title') or
                       item.get('current_program') or item.get('now_title'), 35)
    next_title = _clean(item.get('next_program') or item.get('next_title'), 38)
    try:
        begin = int(context.get('begin') or 0)
        duration = int(context.get('duration') or 0)
        now = int(time.time())
    except (ValueError, TypeError, OverflowError):
        begin, duration, now = 0, 0, 0
    if begin > 0 and duration > 0 and now:
        progress = min(1000, max(0, int((now-begin)*1000.0/duration)))
        first = time.strftime('%H:%M', time.localtime(begin))
        last = time.strftime('%H:%M', time.localtime(begin+duration))
        times = '%s - %s' % (first, last)
        return now_title, next_title, times, progress
    return now_title, next_title, '', None


def _player_progress(screen):
    # TiviMatePlayer updates these values from the native service seek API.
    # They are in PTS units; never fabricate a film progress percentage.
    try:
        pos = int(getattr(screen, '_last_position', 0) or 0)
        duration = int(getattr(screen, '_last_duration', 0) or 0)
        if duration > 0 and pos >= 0:
            progress = max(0, min(1000, int(1000.0*pos/duration)))
            seconds = max(0, pos // 90000)
            return '%02d:%02d:%02d' % (seconds//3600, (seconds//60)%60, seconds%60), progress
    except (ValueError, TypeError, OverflowError):
        pass
    return '', None


def _format_degrees(raw, unit='C', minimum=-60.0, maximum=70.0):
    """Return real Celsius degrees, or blank for absent/invalid readings."""
    try:
        if raw is None:
            return ''
        value = (raw if isinstance(raw, type(u'')) else str(raw)).strip()
        value = value.replace(',', '.').replace(u'\u2212', '-')
        match = re.search(r'[-+]?[0-9]+(?:\.[0-9]+)?', value)
        if not match:
            return ''
        number = float(match.group())
        if u'\u00b0F' in value or value.upper().endswith(' F') or str(unit).upper() == 'F':
            number = (number - 32.0) * 5.0 / 9.0
        if not minimum <= number <= maximum:
            return ''
        return u'%d\u00b0C' % int(round(number))
    except (TypeError, ValueError, OverflowError, UnicodeError):
        return ''


def _weather_temperature():
    """Reuse weather data already stored by Enigma2; no HTTP request."""
    try:
        from Components.config import config
        weather = getattr(getattr(config, 'plugins', None), 'MetrixWeather', None)
        entry = getattr(weather, 'currentWeatherTemp', None)
        raw = getattr(entry, 'value', None)
        if raw is not None:
            value = _format_degrees(raw)
            if value:
                return value
    except Exception:
        pass
    try:
        from Components.WeatherMSN import weathermsn
        data = getattr(weathermsn, 'weatherData', None)
        items = getattr(data, 'weatherItems', {}) or {}
        current = items.get('-1') or items.get(-1)
        if current is not None:
            return _format_degrees(getattr(current, 'temperature', None),
                                   getattr(data, 'degreetype', 'C'))
    except Exception:
        pass
    return ''


def _system_temperature():
    """A clearly labelled receiver sensor reading if weather isn't configured."""
    for path in ('/proc/stb/sensors/temp0/value',
                 '/proc/stb/sensors/temp/value',
                 '/proc/stb/fp/temp_sensor',
                 '/sys/class/thermal/thermal_zone0/temp'):
        try:
            with open(path, 'r') as stream:
                raw = stream.read(32).strip()
            match = re.search(r'[-+]?[0-9]+(?:\.[0-9]+)?', raw)
            if not match:
                continue
            number = float(match.group())
            # Linux thermal-zone sensors commonly expose millidegrees.
            if number > 1000.0:
                number /= 1000.0
            if 10.0 <= number <= 115.0:
                return u'BOX %d\u00b0C' % int(round(number))
        except (IOError, OSError, ValueError, TypeError):
            continue
    return ''


def _frontpanel_temperature():
    return _weather_temperature() or _system_temperature()


_LCD_DIR = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/frontpanel'


class TiviMateDreamFrontPanelSummary(Screen):
    """400x240 Dreambox DM900/DM920 front display: Live vs TiviMate VOD."""
    skin = '''<screen name="TiviMateDreamFrontPanelSummary" id="3" position="0,0" size="400,240" flags="wfNoBorder" backgroundColor="#030B12">
        <ePixmap pixmap="''' + _LCD_DIR + '''/lcd_background_400x240.png" position="0,0" size="400,240" alphatest="blend" zPosition="0"/>
        <widget name="image" position="185,40" size="211,196" alphatest="blend" scale="1" zPosition="1" />
        <ePixmap pixmap="''' + _LCD_DIR + '''/lcd_overlay_400x240.png" position="0,0" size="400,240" alphatest="blend" zPosition="2"/>
        <ePixmap pixmap="''' + _LCD_DIR + '''/lcd_accent_7x167.png" position="10,54" size="7,167" alphatest="blend" zPosition="3"/>
        <widget name="mode" position="29,6" size="175,29" font="Regular;17" foregroundColor="#EBC35D" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="temperature" position="207,8" size="92,25" font="Regular;15" halign="right" foregroundColor="#EBC35D" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="clock" position="302,5" size="90,30" font="Regular;25" halign="right" foregroundColor="#FFD76B" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="caption" position="28,49" size="196,35" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="headline" position="28,91" size="182,43" font="Regular;17" foregroundColor="#F0F5FF" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="meta" position="28,137" size="187,24" font="Regular;14" foregroundColor="#EFCB78" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="subline" position="28,163" size="183,29" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="4" />
        <widget name="progress" position="28,194" size="169,5" foregroundColor="#E5B340" backgroundColor="#384355" borderWidth="0" zPosition="5" />
        <widget name="foot" position="29,211" size="184,23" font="Regular;13" foregroundColor="#C7D0E0" backgroundColor="#030B12" transparent="1" noWrap="1" zPosition="5" />
    </screen>'''

    def __init__(self, session, parent):
        Screen.__init__(self, session, parent=parent)
        self.parent_screen = parent
        self['image'] = Pixmap()
        for name in ('mode', 'temperature', 'clock', 'caption', 'headline', 'meta', 'subline', 'foot'):
            self[name] = Label('')
        self['progress'] = ProgressBar()
        try:
            self['progress'].setRange((0, 1000))
        except Exception:
            pass
        self._last_temperature_check = 0
        self._temperature_display = ''
        self._last_image = None
        self._decoder = None
        self._decoder_connection = None
        self._decoder_token = 0
        self._closed = False
        self._timer = eTimer()
        self._timer_connection = None
        try:
            self._timer_connection = self._timer.timeout.connect(self._refresh)
        except Exception:
            self._timer.callback.append(self._refresh)
        self.onLayoutFinish.append(self._start)
        self.onShow.append(self._start)
        self.onHide.append(self._stop)
        self.onClose.append(self._close)

    def _start(self):
        if self._closed:
            return
        self._refresh()
        try:
            self._timer.start(1200, False)
        except Exception:
            pass

    def _stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass

    def _close(self):
        self._closed = True
        self._stop()
        self._decoder_token += 1
        self._decoder = None
        self._decoder_connection = None
        self.parent_screen = None

    def _refresh(self):
        if self._closed:
            return
        try:
            screen = self.parent_screen
            category, item, source = _selected(screen)
            item = item if isinstance(item, dict) else {}
            self['clock'].setText(time.strftime('%H:%M'))
            now_temperature = time.time()
            if now_temperature - self._last_temperature_check >= 60:
                self._last_temperature_check = now_temperature
                self._temperature_display = _frontpanel_temperature()
            self['temperature'].setText(self._temperature_display)
            is_live = category == 'picons'
            is_movie = category == 'posters'
            if is_live:
                self['mode'].setText('LIVE  •  TiviMateE2')
                self['caption'].setText(_title(item))
                now, upcoming, times, progress = _live_context(screen, item)
                self['headline'].setText(now)
                self['meta'].setText(times)
                self['subline'].setText(upcoming)
                self['foot'].setText('EPG' if now else '')
                image_path = _cache_only_image(item, 'picons', source)
            elif is_movie:
                self['mode'].setText('VOD  •  TiviMateE2')
                self['caption'].setText(_title(item))
                self['headline'].setText(_clean(item.get('genre') or item.get('genres') or '', 31))
                self['meta'].setText(_film_meta(item))
                self['subline'].setText(_clean(item.get('description') or item.get('plot') or item.get('overview'), 33))
                progress_text, progress = _player_progress(screen) if screen.__class__.__name__ == 'TiviMatePlayer' else ('', None)
                self['foot'].setText(progress_text)
                image_path = _movie_artwork(screen, item, source)
            else:
                self['mode'].setText('TiviMateE2')
                for name in ('caption', 'headline', 'meta', 'subline', 'foot'):
                    self[name].setText('')
                progress = None
                image_path = ''
            if progress is None:
                self['progress'].hide()
            else:
                self['progress'].setValue(progress)
                self['progress'].show()
            self._show_image(image_path)
        except Exception:
            # Failure on the secondary display must never crash the main GUI.
            pass

    def _show_image(self, file_name):
        if file_name == self._last_image:
            return
        self._last_image = file_name
        self._decoder_token += 1
        self._decoder_connection = None
        self._decoder = None
        if not file_name:
            self['image'].hide()
            return
        decoder = ePicLoad()
        self._decoder = decoder
        token = self._decoder_token
        def ready(_=None):
            if self._closed or token != self._decoder_token or decoder is not self._decoder:
                return
            try:
                ptr = decoder.getData()
                if ptr is not None and self['image'].instance:
                    self['image'].instance.setPixmap(ptr)
                    self['image'].show()
            except Exception:
                pass
        try:
            try:
                self._decoder_connection = decoder.PictureData.connect(ready)
            except Exception:
                decoder.PictureData.get().append(ready)
            decoder.setPara((211, 196, 1, 1, False, 1, '#00000000'))
            decoder.startDecode(file_name)
        except Exception:
            self['image'].hide()
def install_frontpanel(ui_module):
    """Patch only TiviMateE2 screen classes; do not modify DreamOS global skin."""
    if not dream_lcd_available():
        return False
    classes = [
        'TiviMateE2Home', 'MediaScreen', 'LiveWindowsScreen',
        'MovieDetailsScreen', 'SeriesDetailsScreen', 'ContentHomeScreen',
        'FastMoviesContentScreen', 'FastSeriesContentScreen',
        'StandaloneGenreScreen', 'MovieGenresScreen', 'FavoritesScreen',
        'FavoritesLibraryScreen',
    ]
    def create_summary(self):
        return TiviMateDreamFrontPanelSummary

    for name in classes:
        cls = getattr(ui_module, name, None)
        if isinstance(cls, type) and issubclass(cls, Screen):
            cls.createSummary = create_summary
    try:
        from .cinematic_catalog import CinematicCatalogScreen
        CinematicCatalogScreen.createSummary = create_summary
    except Exception:
        pass
    try:
        from .tivimate_player import TiviMatePlayer
        TiviMatePlayer.createSummary = create_summary
    except Exception:
        pass
    try:
        from .live_player import TiviMateLivePlayer
        TiviMateLivePlayer.createSummary = create_summary
    except Exception:
        pass
    return True
