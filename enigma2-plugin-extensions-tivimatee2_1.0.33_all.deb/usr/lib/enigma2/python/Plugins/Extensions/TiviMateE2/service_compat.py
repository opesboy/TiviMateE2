# -*- coding: utf-8 -*-
"""Detect optional ServiceApp engines without making Enigma2 depend on them.

ServiceApp registers types 5001/5002.  A binary alone is not enough if the
plugin is missing; a plugin directory alone is not enough if the player binary
is missing.  An existing saved engine can remain configured and is only
normalized at runtime, so installing ServiceApp later restores the preference.
"""
import os

_PLUGIN_BASE = "/usr/lib/enigma2/python/Plugins"


def _serviceapp_installed():
    for section in ("SystemPlugins", "Extensions"):
        directory = os.path.join(_PLUGIN_BASE, section, "ServiceApp")
        if not os.path.isdir(directory):
            continue
        if any(os.path.isfile(os.path.join(directory, name))
               for name in ("plugin.py", "plugin.pyc", "plugin.pyo", "serviceapp.so")):
            return True
        # Python 3.12+ images (OpenBH 6, Python 3.14) may ship only
        # __pycache__/plugin.cpython-3xx.pyc.
        try:
            cache = os.path.join(directory, "__pycache__")
            if any(name.startswith("plugin.") and name.endswith(".pyc")
                   for name in os.listdir(cache)):
                return True
        except OSError:
            pass
    return False


_BINARY_DIRS = ("/usr/bin", "/usr/local/bin", "/usr/sbin", "/bin")


def serviceapp_backend_available(service_type):
    try:
        service_type = int(service_type)
    except (ValueError, TypeError):
        return False
    binary = {5001: "gstplayer", 5002: "exteplayer3"}.get(service_type)
    if binary is None or not _serviceapp_installed():
        return False
    return any(os.path.isfile(os.path.join(folder, binary)) and
               os.access(os.path.join(folder, binary), os.X_OK)
               for folder in _BINARY_DIRS)


_SERVICEAPP_INSTALL = [None]
_SERVICEAPP_PACKAGES = ("enigma2-plugin-systemplugins-serviceapp", "exteplayer3", "gstplayer")


def install_serviceapp(session, done=None):
    """Install ServiceApp + exteplayer3/gstplayer from the image feed in the
    background (never blocks the GUI). Returns False if already running or
    no opkg. The GUI must be restarted afterwards for 5001/5002."""
    if _SERVICEAPP_INSTALL[0] is not None:
        return False
    opkg = None
    for folder in _BINARY_DIRS:
        candidate = os.path.join(folder, "opkg")
        if os.path.isfile(candidate):
            opkg = candidate
            break
    if not opkg:
        return False
    try:
        from enigma import eConsoleAppContainer
    except Exception:
        return False
    pkgs = " ".join(_SERVICEAPP_PACKAGES)
    # Each package separately: a feed without gstplayer must not stop the rest.
    parts = ["%s update >/dev/null 2>&1" % opkg]
    parts += ["%s install %s >/dev/null 2>&1" % (opkg, name) for name in _SERVICEAPP_PACKAGES]
    command = "; ".join(parts) + "; exit 0"
    proc = eConsoleAppContainer()
    _SERVICEAPP_INSTALL[0] = proc

    def _finished(retval=None):
        _SERVICEAPP_INSTALL[0] = None
        ok5002 = serviceapp_backend_available(5002)
        ok5001 = serviceapp_backend_available(5001)
        try:
            from Screens.MessageBox import MessageBox
            if ok5002 or ok5001 or _serviceapp_installed():
                text = ("ServiceApp installed (%s).\nPlease restart the GUI, then choose "
                        "5002 or 5001 in Player Engine." %
                        ", ".join([x for x, ok in (("ExtePlayer3 5002", ok5002), ("GstPlayer 5001", ok5001)) if ok]) or "ServiceApp")
                session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=12)
            else:
                session.open(MessageBox, "ServiceApp (%s) is not available in this image's feed." % pkgs,
                             MessageBox.TYPE_ERROR, timeout=10)
        except Exception:
            pass
        if done:
            try:
                done()
            except Exception:
                pass
    try:
        proc.appClosed.append(_finished)
    except Exception:
        try:
            proc.appClosed.get().append(_finished)
        except Exception:
            pass
    try:
        rc = proc.execute("/bin/sh", "sh", "-c", command)
    except (TypeError, AttributeError):
        rc = proc.execute(command)
    if rc not in (0, None, True):
        _SERVICEAPP_INSTALL[0] = None
        return False
    return True


def compatible_service_type(value):
    """Preserve all existing types except unavailable optional 5001/5002."""
    try:
        value = int(value)
    except (ValueError, TypeError):
        return 4097
    if value in (5001, 5002) and not serviceapp_backend_available(value):
        return 4097
    return value
