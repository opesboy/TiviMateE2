# -*- coding: utf-8 -*-
"""EPG programme reminders for TiviMate Live.

In the Live player, MENU -> "Remind me" saves the NEXT programme of the
channel. One minute before it starts, a message asks whether to switch to
that channel (anywhere in Enigma2, also outside the plugin). Reminders are
kept in <data root>/epg_reminders_v1.json, survive a GUI restart and are
removed after they fired or once the programme is long over.

Works on Python 2.7 and 3. The check runs every 20 s on the GUI thread and
only reads a small JSON list; the stream link is resolved in a worker.
"""
from __future__ import absolute_import

import json
import os
import threading
import time

_LOCK = threading.RLock()
_STATE = {"path": "", "data": None, "session": None, "timer": None, "conn": None, "open": False}
_CHECK_MS = 20000
_EARLY = 60          # ask one minute before the start
_LATE = 15 * 60      # still useful up to 15 minutes after the start
_KEEP_ROW = ("name", "title", "stream_id", "id", "ch_id", "cmd", "url", "stream_url",
             "epg_channel_id", "tvg_id", "stream_icon", "logo", "category_id",
             "use_http_tmp_link", "use_load_balancing", "disable_ad",
             "force_ch_link_check", "number", "num")
_KEEP_SOURCE = ("type", "name", "url", "host", "server", "portal", "username", "password",
                "mac", "service_type", "output", "id", "serial", "device_id",
                "device_id2", "signature", "model")

try:
    _UNICODE = unicode  # noqa: F821  (Python 2.7)
except NameError:
    _UNICODE = None


def _txt(value):
    """Native GUI text: UTF-8 bytes on Python 2.7, str on Python 3."""
    if value is None:
        return ""
    if _UNICODE is not None:
        return value.encode("utf-8") if isinstance(value, _UNICODE) else str(value)
    if isinstance(value, bytes):
        return value.decode("utf-8", "replace")
    return str(value)


def _log(message):
    try:
        print("[TiviMateE2][reminder] %s" % message)
    except Exception:
        pass


def _path():
    try:
        from .storage import data_path
        return data_path("epg_reminders_v1.json")
    except Exception:
        return "/etc/enigma2/tivimatee2/epg_reminders_v1.json"


def _load():
    path = _path()
    if _STATE["data"] is not None and _STATE["path"] == path:
        return _STATE["data"]
    rows = []
    try:
        with open(path, "rb") as handle:
            rows = json.loads(handle.read().decode("utf-8"))
        if not isinstance(rows, list):
            rows = []
    except Exception:
        rows = []
    _STATE["path"], _STATE["data"] = path, [r for r in rows if isinstance(r, dict)]
    return _STATE["data"]


def _save(rows):
    path = _path()
    temp = path + ".tmp"
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(temp, "wb") as handle:
            handle.write(json.dumps(rows, ensure_ascii=True).encode("utf-8"))
        os.rename(temp, path)
        return True
    except Exception as exc:
        _log("save failed: %s" % exc)
        return False


def _ident(begin, channel, title):
    return "%s|%s|%s" % (int(begin or 0), _txt(channel)[:60], _txt(title)[:60])


def _small(row, keys):
    """Copy only plain JSON-safe values (no nested rows, no bytes)."""
    out = {}
    for key in keys:
        value = (row or {}).get(key)
        if value is None or value == "":
            continue
        if isinstance(value, bytes) and _UNICODE is None:
            value = value.decode("utf-8", "replace")
        if isinstance(value, (int, float, bool, str)) or (_UNICODE is not None and isinstance(value, _UNICODE)):
            out[key] = value
    return out


def add(source, item, begin, title, channel="", service_type=4097):
    """Save a reminder. Returns False for a programme already over."""
    try:
        begin = int(begin or 0)
    except Exception:
        return False
    if begin <= 0 or begin + _LATE < time.time():
        return False
    channel = channel or (item or {}).get("name") or (item or {}).get("title") or ""
    entry = {
        "id": _ident(begin, channel, title),
        "begin": begin,
        "title": title or "",
        "channel": channel or "",
        "service_type": int(service_type or 4097),
        "source": _small(source, _KEEP_SOURCE),
        "item": _small(item, _KEEP_ROW),
    }
    with _LOCK:
        rows = [r for r in _load() if r.get("id") != entry["id"]]
        rows.append(entry)
        rows.sort(key=lambda r: r.get("begin", 0))
        _STATE["data"] = rows[-100:]
        return _save(_STATE["data"])


def remove(entry_id):
    with _LOCK:
        rows = [r for r in _load() if r.get("id") != entry_id]
        _STATE["data"] = rows
        return _save(rows)


def has(begin, channel, title):
    ident = _ident(begin, channel, title)
    with _LOCK:
        return any(r.get("id") == ident for r in _load())


def upcoming():
    now = time.time()
    with _LOCK:
        return [dict(r) for r in _load() if r.get("begin", 0) + _LATE >= now]


def label(entry):
    try:
        clock = time.strftime("%H:%M", time.localtime(int(entry.get("begin") or 0)))
        day = time.strftime("%d/%m", time.localtime(int(entry.get("begin") or 0)))
    except Exception:
        clock, day = "--:--", ""
    return "%s %s  %s  -  %s" % (day, clock, _txt(entry.get("title")), _txt(entry.get("channel")))


# ---------------------------------------------------------------------------
# Background check (GUI thread eTimer, started at session start)
# ---------------------------------------------------------------------------
def start(session):
    _STATE["session"] = session
    if _STATE["timer"] is not None:
        return
    try:
        from enigma import eTimer
        timer = eTimer()
        try:
            _STATE["conn"] = timer.timeout.connect(_check)
        except AttributeError:
            timer.callback.append(_check)
        _STATE["timer"] = timer
        timer.start(_CHECK_MS, False)
    except Exception as exc:
        _log("timer failed: %s" % exc)


def _check():
    if _STATE["open"]:
        return
    session = _STATE["session"]
    if session is None:
        return
    now = time.time()
    due = None
    with _LOCK:
        rows = _load()
        keep = []
        changed = False
        for row in rows:
            begin = int(row.get("begin") or 0)
            if begin + _LATE < now:
                changed = True          # long over: drop silently
                continue
            if due is None and begin - _EARLY <= now:
                due = row
                changed = True          # fires once
                continue
            keep.append(row)
        if changed:
            _STATE["data"] = keep
            _save(keep)
    if due is not None:
        _ask(session, due)


def _ask(session, entry):
    try:
        from Screens.MessageBox import MessageBox
        started = int(entry.get("begin") or 0) <= time.time()
        head = "Now on" if started else "Starting in 1 minute on"
        text = "%s %s:\n\n%s\n\nSwitch to this channel now?" % (
            head, _txt(entry.get("channel")), _txt(entry.get("title")))
        _STATE["open"] = True

        def answered(yes):
            _STATE["open"] = False
            if yes:
                switch(session, entry)
        session.openWithCallback(answered, MessageBox, text, MessageBox.TYPE_YESNO, timeout=60, default=True)
    except Exception as exc:
        _STATE["open"] = False
        _log("message failed: %s" % exc)


def switch(session, entry):
    """Resolve the channel link off the GUI thread, then play it."""
    source = dict(entry.get("source") or {})
    item = dict(entry.get("item") or {})
    service_type = int(entry.get("service_type") or source.get("service_type") or 4097)
    state = {"url": "", "done": False}

    def worker():
        try:
            from .core import get_source_client
            state["url"] = get_source_client(source).stream_url(item, "live") or ""
        except Exception as exc:
            _log("link failed: %s" % exc)
        state["done"] = True

    thread = threading.Thread(target=worker, name="TiviMateReminderLink")
    thread.daemon = True
    thread.start()
    from enigma import eTimer
    timer = eTimer()
    holder = {"timer": timer, "polls": 0}

    def poll():
        holder["polls"] += 1
        if not state["done"] and holder["polls"] < 75:
            timer.start(200, True)
            return
        url = state["url"]
        if not url:
            try:
                from Screens.MessageBox import MessageBox
                session.open(MessageBox, "Could not open %s" % _txt(entry.get("channel")),
                             MessageBox.TYPE_ERROR, timeout=6)
            except Exception:
                pass
            return
        try:
            from .live_service import live_reference
            ref = live_reference(source, item, service_type, url, _txt(entry.get("channel")) or "IPTV")
            session.nav.playService(ref)
        except Exception as exc:
            _log("play failed: %s" % exc)
        _STATE.pop("switch_holder", None)
    try:
        holder["conn"] = timer.timeout.connect(poll)
    except AttributeError:
        timer.callback.append(poll)
    _STATE["switch_holder"] = holder
    timer.start(200, True)
