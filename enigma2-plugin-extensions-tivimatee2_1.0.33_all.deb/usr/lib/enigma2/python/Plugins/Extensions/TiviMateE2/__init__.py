# -*- coding: utf-8 -*-

# Compatibility helpers are imported locally by the program modules that need
# them.  No Python builtins or os functions are changed at package import time.

# Lean images (OpenPLi, ...) ship without python3-requests. The Stalker
# engine and the subtitle seekers need it, so register a small stdlib
# stand-in BEFORE any module imports "requests". Images that have the real
# package keep using it unchanged.
try:
    from .requests_compat import install as _install_requests_compat
    _install_requests_compat()
except Exception:
    pass

# Pure-Python libraries the subtitles need (six, bs4 + soupsieve,
# typing_extensions). Some images (OpenBH, OpenPLi...) lack them, and a
# missing "six" made the blue key do nothing at all. The bundled copies are
# appended to the END of sys.path, so a library installed on the image always
# wins; only missing ones are taken from the plugin.
try:
    import os as _os
    import sys as _sys
    _vendor = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "_vendor")
    _missing = False
    for _name in ("six", "bs4", "typing_extensions"):
        try:
            __import__(_name)
        except Exception:
            _missing = True
            break
    if _missing and _os.path.isdir(_vendor) and _vendor not in _sys.path:
        _sys.path.append(_vendor)
except Exception:
    pass
