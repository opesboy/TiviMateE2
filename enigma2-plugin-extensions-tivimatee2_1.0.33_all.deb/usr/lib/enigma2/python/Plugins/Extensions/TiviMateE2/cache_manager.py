from .storage import get_data_root, data_path, hdd_available
from .compat import atomic_replace, ensure_dir, open_text
import os, json, time, shutil, threading, hashlib
try:
    import sqlite3
except Exception:
    sqlite3 = None

BASE = get_data_root()
SETTINGS_FILE = data_path("cache_settings.json")
# Cache policy:
# - Auto prefers an actually mounted HDD, otherwise other removable storage,
#   and finally a bounded receiver-flash cache.
# - HDD is unlimited: no image-count, age or cache-size deletion.
# - Receiver flash keeps the most recently used images within a safe quota.
# - /tmp remains temporary and is naturally cleared by the receiver/system.
DEFAULTS = {"location": "auto", "max_mb": 0, "retention_days": 0, "flash_image_limit": 40, "flash_min_free_mb": 30}
MIN_RETENTION_DAYS = 0
MAX_RETENTION_DAYS = 3650

# Disk/mount probing involves a real write/delete test.  Reusing the selected
# root for a short interval removes that work from every poster/backdrop request
# while still rechecking removable media regularly.
CACHE_ROOT_TTL = 10
AUTO_CACHE_ROOT_TTL = 10
# Check mount changes periodically, not once per artwork widget. External
# storage still gets revalidated promptly if it is unplugged.
EXTERNAL_MOUNT_CHECK_TTL = 2
_CACHE_ROOT = ""
_CACHE_ROOT_LOCATION = ""
_CACHE_ROOT_AT = 0.0
_CACHE_ROOT_MOUNT_CHECK_AT = 0.0
_CACHE_ROOT_LOCK = threading.RLock()

_SETTINGS_MEMORY = None
_INTERNAL_ROOT_STATE = ("", 0.0, False)
_INTERNAL_ROOT_STATE_TTL = 15.0


def _load():
    global _SETTINGS_MEMORY
    if _SETTINGS_MEMORY is not None:
        return dict(_SETTINGS_MEMORY)
    try:
        with open_text(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
    except Exception:
        data = {}
    out = dict(DEFAULTS)
    out.update(data)
    # max_mb is retained only for backward compatibility with old settings.
    # It is deliberately ignored by cleanup_cache().
    out["max_mb"] = 0
    try:
        out["retention_days"] = max(MIN_RETENTION_DAYS, min(int(out.get("retention_days", DEFAULTS["retention_days"])), MAX_RETENTION_DAYS))
    except Exception:
        out["retention_days"] = DEFAULTS["retention_days"]
    try:
        out["flash_image_limit"] = max(0, min(int(out.get("flash_image_limit", DEFAULTS["flash_image_limit"])), 500))
    except Exception:
        out["flash_image_limit"] = DEFAULTS["flash_image_limit"]
    try:
        out["flash_min_free_mb"] = max(0, min(int(out.get("flash_min_free_mb", DEFAULTS["flash_min_free_mb"])), 1024))
    except Exception:
        out["flash_min_free_mb"] = DEFAULTS["flash_min_free_mb"]
    _SETTINGS_MEMORY = dict(out)
    return dict(out)


def _invalidate_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT, _CACHE_ROOT_MOUNT_CHECK_AT, _SETTINGS_MEMORY, _INTERNAL_ROOT_STATE
    with _CACHE_ROOT_LOCK:
        _INTERNAL_ROOT_STATE = ("", 0.0, False)
        _CACHE_ROOT = ""
        _CACHE_ROOT_LOCATION = ""
        _CACHE_ROOT_AT = 0.0
        _CACHE_ROOT_MOUNT_CHECK_AT = 0.0
        _SETTINGS_MEMORY = None


def save_settings(location, max_mb=0, retention_days=0, flash_image_limit=None, flash_min_free_mb=None):
    # max_mb is accepted for compatibility, but size never causes deletion.
    current = _load()
    try:
        safe_retention = max(MIN_RETENTION_DAYS, min(int(retention_days), MAX_RETENTION_DAYS))
    except Exception:
        safe_retention = DEFAULTS["retention_days"]
    if flash_image_limit is None:
        flash_image_limit = current.get("flash_image_limit", DEFAULTS["flash_image_limit"])
    if flash_min_free_mb is None:
        flash_min_free_mb = current.get("flash_min_free_mb", DEFAULTS["flash_min_free_mb"])
    try:
        safe_flash_limit = max(0, min(int(flash_image_limit), 500))
    except Exception:
        safe_flash_limit = DEFAULTS["flash_image_limit"]
    try:
        safe_flash_free = max(0, min(int(flash_min_free_mb), 1024))
    except Exception:
        safe_flash_free = DEFAULTS["flash_min_free_mb"]
    data = {
        "location": str(location or "auto"),
        "max_mb": 0,
        "retention_days": safe_retention,
        "flash_image_limit": safe_flash_limit,
        "flash_min_free_mb": safe_flash_free,
    }
    try:
        ensure_dir(BASE)
        tmp = SETTINGS_FILE + ".tmp"
        payload = json.dumps(data, ensure_ascii=False, indent=2)
        if not isinstance(payload, str):
            payload = str(payload)
        with open_text(tmp, "w", encoding="utf-8") as f: f.write(payload)
        atomic_replace(tmp, SETTINGS_FILE)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def get_settings():
    return _load()


def _usable_mount(path):
    """Fast read-only mount check.

    Do not create/delete a test file during normal UI navigation.  Real writes
    are attempted only when a caller actually saves cache content.
    """
    try:
        if not os.path.isdir(path):
            return False
        real = os.path.realpath(path)
        mounted = os.path.ismount(path) or os.path.ismount(real)
        if path == "/tmp":
            mounted = True
        if not mounted:
            return False
        return os.access(path, os.W_OK | os.X_OK)
    except Exception:
        return False


def _root_mount_valid(root):
    """Reject stale /media paths after a disk has been unmounted.

    A mount point can remain a writable directory on receiver flash even after
    the external device has gone away. Never treat that directory as an HDD.
    """
    root = str(root or "")
    for mount in (
        "/media/hdd", "/media/usb", "/media/usb1", "/media/usb2",
        "/media/usb3", "/media/mmc", "/media/sdcard",
    ):
        if root == mount or root.startswith(mount + os.sep):
            return _usable_mount(mount)
    # Cache location must not be a fabricated disk directory under /media.
    return not root.startswith("/media/")


def _hdd_cache_root(root):
    return bool(str(root or "").startswith("/media/hdd/") and _usable_mount("/media/hdd"))


def _selected_root(location):
    """Resolve the configured cache location without overriding explicit choices."""
    location = str(location or "auto").strip().lower()
    candidates = []
    if location == "hdd":
        # Explicit HDD preference with safe fallback: HDD -> USB -> internal.
        candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/home/root"]
    elif location == "usb":
        # Explicit USB preference with safe fallback: USB -> HDD -> internal.
        candidates = ["/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/media/hdd", "/home/root"]
    elif location in ("mmc", "sd", "sdcard"):
        candidates = ["/media/mmc", "/media/sdcard"]
    elif location == "internal":
        candidates = ["/var/tmp"]
    elif location == "tmp":
        # One visible root for all temporary artwork, rather than creating
        # /tmp/.tivimatee2-cache alongside /tmp/tivimatee2-cache.
        if os.path.isdir("/tmp") and os.access("/tmp", os.W_OK | os.X_OK):
            return "/tmp/tivimatee2-cache"
        candidates = ["/var/tmp"]
    else:
        # AUTO: real HDD first, then removable USB/MMC, then receiver flash.
        # Never fall through to /tmp: the final fallback is the same protected
        # INTERNAL root used by the explicit Internal setting.
        candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/media/mmc", "/media/sdcard", "/var/tmp"]
    for mount in candidates:
        if mount == "/var/tmp":
            if os.path.isdir(mount) and os.access(mount, os.W_OK | os.X_OK):
                return os.path.join(mount, "tivimatee2-cache")
        elif _usable_mount(mount):
            return os.path.join(mount, ".tivimatee2-cache")
    return "/var/tmp/tivimatee2-cache"


# Do this once per Enigma2 process, and only for an explicitly selected TMP.
# Fast directory renames preserve existing cached artwork without redownloading.
_TMP_CACHE_UNIFIED = False
_TMP_NESTED_NAMES = (".tivimatee2-cache", "tivimatee2-cache")


def _merge_legacy_tmp_dir(source, target, root, depth=0):
    """Flatten old TMP artwork paths without overwriting any existing file.

    Duplicate filenames with different contents are retained under a single
    _legacy_conflicts subdirectory, never deleted or silently replaced. Other
    storage locations (HDD, USB, flash) are not read or modified.
    """
    if depth > 24 or os.path.islink(source) or not os.path.isdir(source):
        return
    if os.path.realpath(source) == os.path.realpath(target):
        return
    try:
        names = os.listdir(source)
    except OSError:
        return
    for name in names:
        src = os.path.join(source, name)
        if os.path.islink(src):
            # Do not traverse unknown links from a previous install.
            continue
        # A previous build sometimes put a cache directory inside another
        # cache directory. Merge those entries directly into the one root.
        if name in _TMP_NESTED_NAMES and os.path.isdir(src):
            _merge_legacy_tmp_dir(src, root, root, depth + 1)
            continue
        dst = os.path.join(target, name)
        if os.path.normpath(src) == os.path.normpath(dst):
            continue
        try:
            if not os.path.lexists(dst):
                os.rename(src, dst)
            elif os.path.isdir(src) and os.path.isdir(dst) and not os.path.islink(dst):
                _merge_legacy_tmp_dir(src, dst, root, depth + 1)
            elif os.path.isfile(src):
                # Keep both copies when paths collide; avoid costly full image
                # hashing and do not replace a possibly newer cached file.
                backup = os.path.join(root, "_legacy_conflicts")
                ensure_dir(backup)
                key = hashlib.sha1(src.encode("utf-8")).hexdigest()[:12]
                suffix = 0
                while True:
                    candidate = os.path.join(backup, key + "_" + str(suffix) + "_" + name)
                    if not os.path.lexists(candidate):
                        os.rename(src, candidate)
                        break
                    suffix += 1
        except OSError:
            # An inaccessible file remains untouched in the old directory.
            pass
    try:
        os.rmdir(source)  # Removes only an empty old folder.
    except OSError:
        pass


def _unify_tmp_cache_once(root):
    global _TMP_CACHE_UNIFIED
    if _TMP_CACHE_UNIFIED or root != "/tmp/tivimatee2-cache":
        return
    _TMP_CACHE_UNIFIED = True
    # Both variants appeared on OpenPLi; nested directories have also been
    # observed under the visible root. Merge instead of deleting the cache.
    sources = (
        "/tmp/.tivimatee2-cache",
        os.path.join(root, ".tivimatee2-cache"),
        os.path.join(root, "tivimatee2-cache"),
    )
    for source in sources:
        _merge_legacy_tmp_dir(source, root, root)


def get_cache_root():
    """Return the configured persistent cache root, preferring HDD in Auto."""
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT, _CACHE_ROOT_MOUNT_CHECK_AT
    cfg = _load()
    location = str(cfg.get("location") or "auto").strip().lower()
    now = time.time()
    with _CACHE_ROOT_LOCK:
        # Keep the resolved root in memory between periodic mount checks.
        # Previously even a valid cached result called realpath/ismount on
        # EVERY poster lookup; explicit HDD/USB fallbacks were reselected on
        # EVERY lookup because the cached root did not start with the chosen
        # preference. The location string already handles settings changes.
        if _CACHE_ROOT and _CACHE_ROOT_LOCATION == location:
            elapsed = now - _CACHE_ROOT_AT
            if 0 <= elapsed < CACHE_ROOT_TTL:
                external = _CACHE_ROOT.startswith("/media/")
                # Mount checks are only needed every two seconds for HDD/USB.
                # Valid internal paths can be reused for the full TTL.
                if not external or now - _CACHE_ROOT_MOUNT_CHECK_AT < EXTERNAL_MOUNT_CHECK_TTL:
                    return _CACHE_ROOT
                if os.path.isdir(_CACHE_ROOT) and _root_mount_valid(_CACHE_ROOT):
                    _CACHE_ROOT_MOUNT_CHECK_AT = now
                    return _CACHE_ROOT
        # Re-select only after expiration, missing storage, or a changed
        # setting. This also picks up a newly connected HDD/USB within the
        # regular time window without forcing an FS scan on every card.
        root = _selected_root(location)
        # A disk may disappear between the mount check and path selection.
        if not _root_mount_valid(root):
            root = "/var/tmp/tivimatee2-cache"
        try:
            ensure_dir(root)
        except Exception:
            try:
                # Respect explicit INTERNAL even when HDD is mounted. AUTO/HDD
                # may still prefer HDD according to _selected_root().
                if location == "internal":
                    root = "/var/tmp/tivimatee2-cache"
                elif hdd_available() and location in ("auto", "hdd"):
                    root = os.path.join("/media/hdd", ".tivimatee2-cache")
                else:
                    root = "/var/tmp/tivimatee2-cache"
                ensure_dir(root)
            except Exception:
                pass
        # Do not delete fallback flash artwork when an HDD is plugged in.
        # If the HDD is unplugged later, its last limited poster cache is still
        # available, and its size is controlled separately by the flash LRU.
        _CACHE_ROOT = root
        _CACHE_ROOT_LOCATION = location
        _CACHE_ROOT_AT = now
        _CACHE_ROOT_MOUNT_CHECK_AT = now
        if location == "tmp":
            _unify_tmp_cache_once(root)
        return root




def _filesystem_type(path):
    """Find the filesystem backing the *resolved* cache directory.

    /var/tmp can be a symlink into /tmp on OpenATV/Pure2.  Classifying that
    RAM-backed path as receiver flash causes needless trimming after downloads.
    Unknown mount information is reported as None so we retain flash protection.
    """
    try:
        real = os.path.realpath(path)
        chosen = ""
        result = None
        with open("/proc/mounts", "r") as mounts:
            for line in mounts:
                parts = line.split()
                if len(parts) < 3:
                    continue
                mount = parts[1].replace("\\040", " ").replace("\\011", "\t")
                mount = os.path.realpath(mount)
                if (real == mount or real.startswith(mount.rstrip(os.sep) + os.sep)) and len(mount) > len(chosen):
                    chosen, result = mount, parts[2].lower()
        return result
    except Exception:
        return None


def is_internal_cache_active():
    """True only for receiver-flash-backed INTERNAL/AUTO cache storage.

    If /var/tmp aliases a RAM tmpfs, its artwork uses the TMP retention policy.
    The selected storage path itself remains unchanged.  Unknown filesystem
    types deliberately keep the existing conservative flash guard.
    """
    global _INTERNAL_ROOT_STATE
    try:
        selected = get_cache_root()
        now = time.time()
        with _CACHE_ROOT_LOCK:
            cached_path, checked_at, cached_result = _INTERNAL_ROOT_STATE
            if selected == cached_path and 0 <= now - checked_at < _INTERNAL_ROOT_STATE_TTL:
                return cached_result
            root = os.path.realpath(selected)
            internal = os.path.realpath("/var/tmp/tivimatee2-cache")
            candidate = root == internal or root.startswith(internal + os.sep)
            if not candidate:
                result = False
            elif root.startswith("/media/"):
                result = False
            else:
                fs_type = _filesystem_type(root)
                result = fs_type not in ("tmpfs", "ramfs", "devtmpfs")
            _INTERNAL_ROOT_STATE = (selected, now, result)
            return result
    except Exception:
        # Preserve the flash reserve if mount probing fails unexpectedly.
        try:
            selected = os.path.realpath(get_cache_root())
            internal = os.path.realpath("/var/tmp/tivimatee2-cache")
            return selected == internal or selected.startswith(internal + os.sep)
        except Exception:
            return False

def get_cache_dir(kind="misc"):
    path = os.path.join(get_cache_root(), str(kind or "misc"))
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def cleanup_stale_temp_files():
    """No-op: TiviMateE2 no longer creates upgrade backup archives."""
    return

def cache_status():
    root = get_cache_root()
    total = 0
    files = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    total += os.path.getsize(p)
                    files += 1
                except Exception:
                    pass
    except Exception:
        pass
    return root, total, files


def _artwork_dirs(root):
    """Image-cache folders only. Metadata and list/database caches are preserved.

    Includes channel picons so the same retention/LRU/free-space protection
    applies to every *transient* image family on the selected cache storage.
    IMPORTANT: images/genre contains permanent, per-server package JPG files.
    It must NOT be added to this list or deleted by Clear Cache / exit cleanup.
    """
    return (
        os.path.join(root, "posters"),
        os.path.join(root, "backdrops"),
        # Derived GENRE dimmed backdrops need the same flash-space protection.
        os.path.join(root, "backdrops", "genre_dim"),
        # Full-screen TMDb episode stills use their own HD quality cache.
        os.path.join(root, "episode_hd"),
        os.path.join(root, "picons"),
        os.path.join(root, "logos"),
    )


def _remove_file(path):
    try:
        if path and os.path.isfile(path):
            os.remove(path)
            return True
    except Exception:
        pass
    return False


def _artwork_files(folder):
    rows = []
    try:
        for name in os.listdir(folder):
            path = os.path.join(folder, name)
            try:
                if not os.path.isfile(path):
                    continue
                st = os.stat(path)
                rows.append((float(st.st_mtime), int(st.st_size), path))
            except Exception:
                pass
    except Exception:
        pass
    rows.sort(key=lambda row: row[0])  # oldest / least recently used first
    return rows


def clear_cache():
    """Clear artwork only; never erase metadata, SQLite/list caches, Recent or TMDb data."""
    root = get_cache_root()
    try:
        for path in _artwork_dirs(root):
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception:
                pass
        ensure_dir(root)
        _invalidate_cache_root()
        return True
    except Exception:
        return False



def clear_internal_artwork_on_exit():
    """Remove all TiviMateE2 artwork when leaving the app on INTERNAL storage.

    Only posters/backdrops/picons/logos are removed. Metadata, SQLite, Recent,
    TMDb data, packages, logs and other persistent caches are preserved.
    HDD/USB/MMC/TMP selections are intentionally left untouched.
    """
    try:
        cfg = _load()
        location = str(cfg.get("location") or "auto").strip().lower()
        if location not in ("internal", "auto") or not is_internal_cache_active():
            return False
        root = get_cache_root()
        for path in _artwork_dirs(root):
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception:
                pass
        try:
            ensure_dir(root)
        except Exception:
            pass
        return True
    except Exception:
        return False

def cleanup_cache():
    """Trim transient artwork only; never touch metadata, favourites or lists.

    The cleanup caller batches successful downloads.  One directory snapshot
    per pass replaces the old repeated scans for count, free space and totals.
    Flash image limits and the configured free-space reserve are still enforced.
    """
    cfg = _load()
    root = get_cache_root()
    retention_days = int(cfg.get("retention_days", DEFAULTS["retention_days"]) or 0)
    flash_limit = int(cfg.get("flash_image_limit", DEFAULTS["flash_image_limit"]) or DEFAULTS["flash_image_limit"])
    flash_min_free_mb = int(cfg.get("flash_min_free_mb", DEFAULTS["flash_min_free_mb"]) or 0)
    internal = is_internal_cache_active()
    now = time.time()
    folder_rows = [(folder, _artwork_files(folder)) for folder in _artwork_dirs(root)]
    total = sum(size for _folder, rows in folder_rows for _mtime, size, _path in rows)

    if not internal and not _hdd_cache_root(root) and retention_days > 0:
        retention = retention_days * 86400
        for _folder, rows in folder_rows:
            for mtime, size, path in rows:
                if now - mtime > retention and _remove_file(path):
                    total -= size

    if internal:
        if flash_limit > 0:
            for _folder, rows in folder_rows:
                excess = max(0, len(rows) - flash_limit)
                for _mtime, size, path in rows[:excess]:
                    if _remove_file(path):
                        total -= size

        # A fresh statvfs read is authoritative for free space.  Never trust
        # only the accumulated file lengths after concurrent image downloads.
        if flash_min_free_mb > 0:
            reserve = flash_min_free_mb * 1024 * 1024
            try:
                st = os.statvfs(root)
                free_bytes = int(st.f_bavail * st.f_frsize)
            except Exception:
                free_bytes = reserve
            if free_bytes < reserve:
                candidates = []
                for _folder, rows in folder_rows:
                    candidates.extend(rows)
                candidates.sort(key=lambda row: row[0])
                for _mtime, size, path in candidates:
                    if free_bytes >= reserve:
                        break
                    if _remove_file(path):
                        total -= size
                        free_bytes += int(size or 0)
    return max(0, total)

def migrate_legacy_tmp_cache():
    """Move persistent TiviMateE2 cache out of /tmp to the selected storage.

    True runtime scratch files (QR image, subtitle temp files, sockets) are not
    moved.  This runs only when the resolved cache root is persistent.
    """
    src_root = "/tmp/tivimatee2"
    try:
        dst_root = get_cache_root()
    except Exception:
        return
    if not dst_root or dst_root.startswith("/tmp/") or dst_root == src_root:
        return
    if not os.path.isdir(src_root):
        return
    try:
        ensure_dir(dst_root)
    except Exception:
        return
    # Known persistent cache folders.  Leave web_access_qr.png and any unknown
    # runtime scratch content in /tmp.
    persistent_names = (
        "posters", "backdrops", "logos", "picons", "epg",
        "tmdb_search", "tmdb_trending", "details_json",
        "vod", "series", "live", "metadata", "json", "info"
    )
    for name in persistent_names:
        src = os.path.join(src_root, name)
        dst = os.path.join(dst_root, name)
        if not os.path.exists(src):
            continue
        try:
            if os.path.isdir(src):
                ensure_dir(dst)
                for base, dirs, files in os.walk(src):
                    rel = os.path.relpath(base, src)
                    target_base = dst if rel == "." else os.path.join(dst, rel)
                    ensure_dir(target_base)
                    for fn in files:
                        sp = os.path.join(base, fn)
                        dp = os.path.join(target_base, fn)
                        try:
                            if not os.path.exists(dp):
                                shutil.move(sp, dp)
                            else:
                                os.remove(sp)
                        except Exception:
                            pass
                try:
                    shutil.rmtree(src)
                except Exception:
                    pass
            elif os.path.isfile(src):
                dp = os.path.join(dst_root, name)
                if not os.path.exists(dp):
                    shutil.move(src, dp)
                else:
                    os.remove(src)
        except Exception:
            pass
    # Remove empty legacy log/cache directories, but keep /tmp/tivimatee2 itself
    # if runtime scratch files are still present.
    for sub in ("logs",):
        try:
            path = os.path.join(src_root, sub)
            if os.path.isdir(path) and not os.listdir(path):
                os.rmdir(path)
        except Exception:
            pass
    try:
        if os.path.isdir(src_root) and not os.listdir(src_root):
            os.rmdir(src_root)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Persistent key/value cache for Stalker and other network catalogs.
# SQLite/WAL is preferred when python3-sqlite3 is available.  Images that do
# not ship sqlite3 transparently fall back to atomic JSON files on HDD/USB.
# ---------------------------------------------------------------------------
_SQLITE_LOCK = threading.RLock()
_SQLITE_CONN = None
_SQLITE_PATH = ""


def stable_cache_key(namespace, *parts):
    raw = "|".join([str(namespace or "")] + [str(x or "") for x in parts])
    try:
        return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()
    except Exception:
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _json_kv_dir():
    path = os.path.join(get_cache_dir("stalker"), "json_kv")
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def _json_kv_path(cache_key):
    safe = str(cache_key or "")
    if not safe or any(c not in "0123456789abcdefABCDEF" for c in safe):
        safe = stable_cache_key("fallback", safe)
    return os.path.join(_json_kv_dir(), safe + ".json")


def _json_cache_get(cache_key, default=None):
    path = _json_kv_path(cache_key)
    try:
        with open_text(path, "r", encoding="utf-8") as f:
            row = json.load(f) or {}
        if float(row.get("expires") or 0) <= time.time():
            try: os.remove(path)
            except Exception: pass
            return default
        return row.get("value", default)
    except Exception:
        return default


def _json_cache_set(cache_key, namespace, value, ttl):
    path = _json_kv_path(cache_key)
    tmp = path + ".tmp"
    now = time.time()
    try:
        ttl = max(1, int(ttl or 1))
        row = {
            "namespace": str(namespace or "misc"),
            "created": now,
            "expires": now + ttl,
            "value": value,
        }
        payload = json.dumps(row, ensure_ascii=False, separators=(",", ":"))
        with open_text(tmp, "w", encoding="utf-8") as f:
            f.write(payload)
        atomic_replace(tmp, path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except Exception:
            pass
        return False


def _sqlite_connection():
    global _SQLITE_CONN, _SQLITE_PATH
    if sqlite3 is None:
        return None
    path = os.path.join(get_cache_dir("stalker"), "persistent_cache.sqlite3")
    with _SQLITE_LOCK:
        if _SQLITE_CONN is not None and _SQLITE_PATH == path:
            return _SQLITE_CONN
        try:
            if _SQLITE_CONN is not None:
                _SQLITE_CONN.close()
        except Exception:
            pass
        try:
            conn = sqlite3.connect(path, timeout=8.0, check_same_thread=False)
            _SQLITE_CONN = conn
            _SQLITE_PATH = path
            cur = conn.cursor()
            try: cur.execute("PRAGMA journal_mode=WAL")
            except Exception: pass
            try: cur.execute("PRAGMA synchronous=NORMAL")
            except Exception: pass
            try: cur.execute("PRAGMA busy_timeout=8000")
            except Exception: pass
            cur.execute("CREATE TABLE IF NOT EXISTS kv_cache (cache_key TEXT PRIMARY KEY, namespace TEXT NOT NULL, created REAL NOT NULL, expires REAL NOT NULL, payload TEXT NOT NULL)")
            cur.execute("CREATE INDEX IF NOT EXISTS kv_cache_expiry ON kv_cache(expires)")
            conn.commit()
            return conn
        except Exception:
            _SQLITE_CONN = None
            _SQLITE_PATH = ""
            return None


def persistent_cache_get(cache_key, default=None):
    now = time.time()
    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    cur = conn.cursor()
                    cur.execute("SELECT expires,payload FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                    row = cur.fetchone()
                    if row:
                        if float(row[0] or 0) <= now:
                            try:
                                cur.execute("DELETE FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                                conn.commit()
                            except Exception:
                                pass
                        else:
                            return json.loads(row[1])
        except Exception:
            pass
    return _json_cache_get(cache_key, default)



def persistent_cache_peek(cache_key, default=None, max_stale=86400):
    """Return (value, fresh) without deleting a recently expired row.

    Used by Stalker stale-while-revalidate so the UI can render cached data
    immediately while a background refresh updates the persistent copy.
    """
    now = time.time()
    try:
        max_stale = max(0, int(max_stale or 0))
    except Exception:
        max_stale = 0

    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    cur = conn.cursor()
                    cur.execute("SELECT expires,payload FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                    row = cur.fetchone()
                    if row:
                        expires = float(row[0] or 0)
                        if expires > now or (max_stale and now - expires <= max_stale):
                            try:
                                return json.loads(row[1]), bool(expires > now)
                            except Exception:
                                pass
        except Exception:
            pass

    path = _json_kv_path(cache_key)
    try:
        with open_text(path, "r", encoding="utf-8") as f:
            row = json.load(f) or {}
        expires = float(row.get("expires") or 0)
        if expires > now or (max_stale and now - expires <= max_stale):
            return row.get("value", default), bool(expires > now)
    except Exception:
        pass
    return default, False

def persistent_cache_set(cache_key, namespace, value, ttl):
    now = time.time()
    try:
        ttl = max(1, int(ttl or 1))
    except Exception:
        ttl = 1
    if sqlite3 is not None:
        try:
            payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    conn.execute("INSERT OR REPLACE INTO kv_cache(cache_key,namespace,created,expires,payload) VALUES(?,?,?,?,?)",
                                 (str(cache_key), str(namespace or "misc"), now, now + ttl, payload))
                    conn.commit()
                    # A JSON row may be left by an older no-sqlite receiver.
                    # Remove it only after the SQLite transaction commits so a
                    # failed DB write never destroys the compatible fallback.
                    try:
                        legacy_path = _json_kv_path(cache_key)
                        if os.path.exists(legacy_path):
                            os.remove(legacy_path)
                    except Exception:
                        pass
                    return True
        except Exception:
            pass
    return _json_cache_set(cache_key, namespace, value, ttl)


def persistent_cache_delete(cache_key):
    ok = False
    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    conn.execute("DELETE FROM kv_cache WHERE cache_key=?", (str(cache_key),))
                    conn.commit()
                    ok = True
        except Exception:
            pass
    try:
        path = _json_kv_path(cache_key)
        if os.path.exists(path):
            os.remove(path)
            ok = True
    except Exception:
        pass
    return ok


def persistent_cache_purge_expired(limit=500):
    now = time.time()
    try:
        max_rows = max(1, int(limit or 500))
    except Exception:
        max_rows = 500
    ok = False
    if sqlite3 is not None:
        try:
            with _SQLITE_LOCK:
                conn = _sqlite_connection()
                if conn is not None:
                    conn.execute("DELETE FROM kv_cache WHERE cache_key IN (SELECT cache_key FROM kv_cache WHERE expires<=? LIMIT ?)",
                                 (now, max_rows))
                    conn.commit()
                    ok = True
        except Exception:
            pass
    # Also clean fallback JSON rows, including rows left from a receiver that
    # previously had no sqlite module.
    try:
        folder = _json_kv_dir()
        count = 0
        for name in os.listdir(folder):
            if count >= max_rows:
                break
            if not name.endswith(".json"):
                continue
            path = os.path.join(folder, name)
            try:
                with open_text(path, "r", encoding="utf-8") as f:
                    row = json.load(f) or {}
                if float(row.get("expires") or 0) <= now:
                    os.remove(path)
                count += 1
            except Exception:
                try: os.remove(path)
                except Exception: pass
                count += 1
        ok = True
    except Exception:
        pass
    return ok
