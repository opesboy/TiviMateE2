
from .title_cleaning import clean_series_label, compact_series_label, fit_series_text
from urllib.parse import urlsplit

# r427 diagnostic only: persistent checkpoints for Series restart tracing.
# No timer/hook/thread is added by this logger.
def _series_restart_log(stage, item=None, extra=""):
    return None

class SeriesDetailsScreen(Screen):
    skin = SERIES_DETAILS
    EPISODE_X = [80, 440, 800, 1160, 1520]

    def _seriesTmdbSearchTitles(self, title):
        """Use the provider-visible series title as-is for TMDb lookup.

        Series names are already normalized upstream. Keep this path generic:
        no Arabic/genre/provider word rules and no title-specific exceptions.
        """
        raw = re.sub(r"\s+", " ", clean_series_label(title)).strip()
        return [raw] if raw else []

    def _seriesTmdbNorm(self, value):
        text = str(value or "").lower()
        try:
            text = re.sub(r"[\u064b-\u065f\u0670\u06d6-\u06ed]", "", text)
        except Exception:
            pass
        text = re.sub(r"[^0-9a-z\u0600-\u06ff]+", " ", text, flags=re.UNICODE)
        return re.sub(r"\s+", " ", text).strip()

    def _openManualTmdbMatch(self):
        """MENU: search TMDb and pin the correct series (Ultra manual match)."""
        title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
        if not title:
            return
        from .manual_match import open_menu, reopen_later

        def reopen():
            source, item = getattr(self, "_manualMatchArgs", None) or (self.source, dict(self.seriesItem))
            item = dict(item)
            reopen_later(self.session, self, SeriesDetailsScreen, source, item)
        open_menu(self, title, "series", reopen)

    def _searchSeriesTmdbSafe(self, client, title, year=None):
        """Resolve the series by its already-normalized visible title."""
        raw = re.sub(r"\s+", " ", clean_series_label(title)).strip()
        if not raw:
            return {}
        try:
            found = client.search_title(raw, "series", year) or {}
            if not found and year:
                found = client.search_title(raw, "series", None) or {}
            return found
        except Exception:
            return {}



    def __init__(self, session, source, seriesItem):
        _series_restart_log("DETAILS_INIT_ENTER", seriesItem, "source_type=%s" % str((source or {}).get("type") if isinstance(source, dict) else ""))
        Screen.__init__(self, session)
        _series_restart_log("DETAILS_SCREEN_INIT_OK", seriesItem)
        self.source = source
        self._vodSelectedSource = dict(self.source or {})
        self.seriesItem = seriesItem or {}
        self._manualMatchArgs = (source, dict(self.seriesItem))
        self._serverPackageProvider = str(self.seriesItem.get("_server_package_provider") or self.seriesItem.get("_tmdb_provider") or "")
        self.seriesData = {}
        self.episodesBySeason = {}
        self.seasonItems = []
        self.episodeItems = []
        self.seasonIndex = 0
        self.episodePage = 0
        self.episodeIndex = 0
        self.downloads = []
        self.picloads = []
        self.backdropLoader = None
        # Keep every active ePicLoad alive until its native decode callback finishes.
        # backdropLoader still points to the newest request so visual behaviour is unchanged.
        self.backdropLoaders = []
        self.backdropDownloader = None
        self.seriesFallbackPoster = ""
        self.seriesBackdrop = ""
        self._seriesOriginalBackdropShown = False
        self._seriesBackdropFailed = False
        self._seriesBadBackdropUrls = set()
        self["backdrop"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["seriesTitleLogo"] = Pixmap()
        self._seriesTitleLogoLoader = None
        self._seriesTitleLogoToken = ""
        # Invalidate all late artwork/episode replies when this screen closes.
        self._seriesClosed = False
        self._seriesGeneration = 0
        self["title"] = DirectionalLabel(compact_series_label(self.seriesItem.get("name") or self.seriesItem.get("title") or (tr("TV Show") if get_language() != "ar" else "مسلسل"), 44))
        self["rating"] = Label("")
        self["ratingStars"] = Label("")
        self["ratingText"] = Label("")
        self["ratingText"].setText("")
        self["countryFlag"] = Pixmap()
        self["countryFlag"].hide()
        self["meta"] = CenteredArabicMetadataLabel("")
        self["cast"] = Label("")
        self._seriesActorToken = 0
        self._seriesActorPeople = []
        self._seriesActorFocus = False
        self._seriesActorIndex = 0
        self._seriesActorSearchBusy = False
        self._seriesActorLoaders = []
        for i in range(5):
            self["actor%d" % i] = Pixmap()
            self["actorLabel%d" % i] = Label("")
        self["actorSelector"] = Pixmap()
        self["desc"] = RisingOverviewLabel(tr(""))
        self["seasonInfo"] = Label("")
        # Five compact S01/S02 chips. UP/DOWN still select seasons; LEFT/RIGHT
        # still select episodes. No season picture fetching whatsoever.
        self._seasonChipX = (80, 275, 470, 665, 860)
        for i in range(5):
            self["seasonChipBg%d" % i] = Pixmap()
            self["seasonChipLabel%d" % i] = Label("")
        self["seasonChipFocus"] = Pixmap()
        self["episodeInfo"] = Label("")
        from .resolution_badge import install_information_badge
        install_information_badge(self, "meta", observe=("meta", "episodeInfo"), position=(427, 148), badges_only=True)
        for i in range(5):
            self["episode%d" % i] = Pixmap()
            self["episodeBadgeBg%d" % i] = Pixmap()
            self["episodeLabel%d" % i] = Label("")
        self["episodeSelector"] = Pixmap()
        self["keys"] = Label(tr("LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back"))
        self["guideBar"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite,
            "yellowlong": self.addSeriesFavourite, "blue": self._chooseSeriesActor,
            "menu": self._openManualTmdbMatch
        }, -1)
        self.onClose.append(self._stopSeriesWork)
        self.onLayoutFinish.append(self._updateSeriesActorFocus)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self._startSeriesArtworkFirst)
        _series_restart_log("DETAILS_INIT_DONE", self.seriesItem)


    def _stopSeriesWork(self):
        """Invalidate late worker callbacks without trying to cancel native IO."""
        self._seriesClosed = True
        self._seriesGeneration += 1
        self._seriesArtworkFallbackPending = False
        try:
            self._episodeStillPending.clear()
        except Exception:
            pass

    def _showSeriesActors(self, tmdb_data):
        """Show TMDb series cast without blocking episode or backdrop loading."""
        self._seriesActorToken += 1
        token = self._seriesActorToken
        cast = ((tmdb_data or {}).get("credits") or {}).get("cast") or []
        people = [p for p in cast if isinstance(p, dict) and p.get("id")][:5]
        self._seriesActorPeople = [dict(p) for p in people]
        self._seriesActorIndex = min(self._seriesActorIndex, max(0, len(self._seriesActorPeople) - 1))
        self._updateSeriesActorFocus()
        for i in range(5):
            try:
                self["actor%d" % i].hide()
                self["actorLabel%d" % i].setText("")
            except Exception:
                pass
        if not people:
            self._seriesActorFocus = False
            self._updateSeriesActorFocus()
            return False
        self["cast"].setText("")
        for i, person in enumerate(people):
            name = str(person.get("name") or "")
            role = str(person.get("character") or "")
            self["actorLabel%d" % i].setText((name + ("\n" + role if role else ""))[:70])
            path = str(person.get("profile_path") or "")
            if not path.startswith("/"):
                continue
            url = "https://image.tmdb.org/t/p/w185" + path
            def done(local_path, slot=i, expected=token):
                if expected != self._seriesActorToken:
                    return
                loader = ePicLoad()
                self._seriesActorLoaders.append(loader)
                def ready(_info=None, l=loader, index=slot, t=expected):
                    try:
                        if t == self._seriesActorToken and self["actor%d" % index].instance:
                            ptr = l.getData()
                            if ptr:
                                self["actor%d" % index].instance.setPixmap(ptr)
                                self["actor%d" % index].show()
                    except Exception:
                        pass
                    try:
                        self._seriesActorLoaders.remove(l)
                    except Exception:
                        pass
                connect_picture_data(loader, ready, self)
                w, h = scale_size(90, 90)
                loader.setPara((w, h, 0, 0, False, 1, "#00000000"))
                loader.startDecode(local_path)
            request_artwork(url, "actors", done, priority=30)
        return True

    def _updateSeriesActorFocus(self):
        """Show the same visible remote focus frame used by actor selection."""
        try:
            visible = bool(self._seriesActorFocus and self._seriesActorPeople)
            if visible:
                self._seriesActorIndex = max(0, min(self._seriesActorIndex, len(self._seriesActorPeople) - 1))
                self["actorSelector"].instance.move(ePoint(sx(78 + 265 * self._seriesActorIndex), sy(242)))
                self["actorSelector"].show()
                self["episodeSelector"].hide()
            else:
                self["actorSelector"].hide()
                self["episodeSelector"].show()
        except Exception:
            pass

    def _openFocusedSeriesActor(self):
        if not self._seriesActorPeople:
            return
        actor = self._seriesActorPeople[max(0, min(self._seriesActorIndex, len(self._seriesActorPeople) - 1))]
        self._seriesActorChosen((str(actor.get("name") or "Actor"), actor))

    def _chooseSeriesActor(self):
        """Blue: choose a visible actor and search series (cache first)."""
        if not self._seriesActorPeople:
            self.session.open(MessageBox, "No actor information available.", MessageBox.TYPE_INFO)
            return
        options = [(str(p.get("name") or "Actor"), p) for p in self._seriesActorPeople]
        self.session.openWithCallback(self._seriesActorChosen, ChoiceBox, title="ACTORS - TV SHOWS", list=options)

    def _seriesActorChosen(self, choice):
        if not choice or self._seriesActorSearchBusy:
            return
        actor = choice[1] if isinstance(choice, (list, tuple)) and len(choice) > 1 else None
        if not isinstance(actor, dict) or not actor.get("id"):
            return
        self._searchSeriesActor(actor)

    def _searchSeriesActor(self, actor):
        self._seriesActorSearchBusy = True
        actor_name = str(actor.get("name") or "Actor")
        actor_id = str(actor.get("id") or "")
        source = dict(self.source or {})
        current = dict(self.seriesItem or {})
        self["keys"].setText("Searching %s TV shows..." % actor_name)

        def worker():
            matches = []
            failure = None
            try:
                credits = TMDbClient().person_tv_credits(actor_id) or {}
                if not credits or not isinstance(credits, dict):
                    raise RuntimeError("TMDb TV credits unavailable; check network/API")
                credit_rows = [r for r in (credits.get("cast") or []) if isinstance(r, dict)]
                wanted = set()
                for credit in credit_rows:
                    for field in ("name", "original_name", "title", "original_title"):
                        key = self._seriesTmdbNorm(credit.get(field))
                        if key:
                            wanted.add(key)
                if wanted:
                    categories, _ = get_cached_categories(source, "series", wait_for_server=False)
                    allowed = get_allowed_category_ids(source, "series")
                    allowed = None if allowed is None else set(str(x) for x in allowed)
                    current_cid = str(current.get("_source_category_id") or current.get("category_id") or "").strip()
                    package_ids = [current_cid] if current_cid and (allowed is None or current_cid in allowed) else []
                    for cat in categories or []:
                        cid = str((cat or {}).get("category_id") or "").strip()
                        if cid and cid != "__recent_added__" and cid not in package_ids and (allowed is None or cid in allowed):
                            package_ids.append(cid)
                    if allowed is not None:
                        for cid in sorted(allowed):
                            if cid and cid != "__recent_added__" and cid not in package_ids:
                                package_ids.append(cid)
                    seen = set()
                    def matches_credit(row):
                        titles = [self._seriesTmdbNorm(row.get(k)) for k in ("name", "title", "original_name", "original_title")]
                        for title in titles:
                            if not title:
                                continue
                            if title in wanted:
                                return True
                            # Providers commonly append a year, season, or quality marker.
                            clean = re.sub(r"\s+(?:19|20)\d{2}(?:\s+.*)?$", "", title).strip()
                            clean = re.sub(r"\s+(?:s\d{1,2}|season\s+\d+|4k|uhd|fhd|hd)$", "", clean).strip()
                            if clean in wanted:
                                return True
                        return False
                    def collect(rows, cid):
                        for row in rows or []:
                            if not isinstance(row, dict) or not matches_credit(row):
                                continue
                            sid = str(row.get("series_id") or row.get("stream_id") or row.get("id") or "")
                            marker = (cid, sid or self._seriesTmdbNorm(row.get("name") or row.get("title")))
                            if marker in seen:
                                continue
                            seen.add(marker)
                            result = dict(row)
                            result["_source_category_id"] = cid
                            matches.append(result)
                    # First search the full cached series catalog and every cached package.
                    catalog, _ = peek_filtered_streams_cache(source, "series")
                    collect(catalog, current_cid)
                    misses = []
                    for cid in package_ids:
                        rows, origin = peek_category_streams_cache(source, "series", cid)
                        if origin == "miss":
                            misses.append(cid)
                        else:
                            collect(rows, cid)
                    # Cached catalogs can be stale or incomplete. On zero matches,
                    # query ALL active series packages, not only uncached ones.
                    if not matches:
                        client = get_source_client(source)
                        for cid in package_ids:
                            try:
                                rows, _ = get_category_streams(source, "series", client, cid,
                                    use_cache=False, wait_for_server=True)
                                collect(rows, cid)
                            except Exception:
                                continue
                            if len(matches) >= 100:
                                break
                elif not credit_rows:
                    failure = "TMDb returned no TV acting credits for %s." % actor_name
            except Exception as exc:
                failure = str(exc)
            def finish():
                self._seriesActorSearchBusy = False
                self["keys"].setText(tr("LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back"))
                if matches:
                    from .actor_results_layout import open_actor_results
                    open_actor_results(self.session, source, "series", actor_name, matches)
                else:
                    message = ("Actor search failed: %s" % failure) if failure else ("No matching TV shows for %s in active series packages." % actor_name)
                    self.session.open(MessageBox, message, MessageBox.TYPE_INFO)
            if reactor:
                reactor.callFromThread(finish)
            else:
                # Enigma2 uses Twisted; do not manipulate widgets from a worker.
                self._seriesActorSearchBusy = False
        thread = threading.Thread(target=worker, name="TiviMateActorCacheSeries")
        thread.daemon = True
        thread.start()

    def _applySeriesTitleLogo(self, bundle, tmdb_id):
        """Select a TV logo using TMDb Settings, from the metadata worker."""
        try:
            from .logo_manager import localized_logo_url
            client = TMDbClient()
            return localized_logo_url(client, "tv", tmdb_id,
                                      (bundle or {}).get("images") or {}, details=bundle)
        except Exception:
            return ""

    def _showSeriesTitleLogo(self, path, token):
        if token != self._seriesTitleLogoToken:
            return
        loader = ePicLoad()
        self._seriesTitleLogoLoader = loader
        def ready(_info=None, ref=loader, expected=token):
            if expected != self._seriesTitleLogoToken or self._seriesTitleLogoLoader is not ref:
                return
            try:
                pix = ref.getData()
                if pix and self["seriesTitleLogo"].instance:
                    self["seriesTitleLogo"].instance.setPixmap(pix)
                    self["seriesTitleLogo"].show()
                    self["title"].hide()
            except Exception:
                pass
        connect_picture_data(loader, ready, self)
        w, h = scale_size(660, 142)
        loader.setPara((w, h, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def _loadSeriesTitleLogoUltra(self, bundle, title, verified_id, fallback_url):
        token = "%s:%s" % (verified_id, title)
        self._seriesTitleLogoToken = token
        def worker():
            try:
                from .title_logo_ultra_bridge import resolve_title_logo
                client = TMDbClient()
                path = resolve_title_logo(client, "series", verified_id, title=title,
                         details=bundle, item=self.seriesItem, canvas=(660, 142),
                         cancelled=lambda: self._seriesTitleLogoToken != token)
                if path and self._seriesTitleLogoToken == token and reactor:
                    reactor.callFromThread(self._showSeriesTitleLogo, path, token)
                elif not path and fallback_url and self._seriesTitleLogoToken == token and reactor:
                    reactor.callFromThread(self._loadSeriesTitleLogo, fallback_url)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateSeriesUltraLogo", daemon=True).start()

    def _loadSeriesTitleLogo(self, url):
        if not url:
            return
        token = str(self.seriesItem.get("tmdb_id") or "") + ":" + url
        self._seriesTitleLogoToken = token
        def done(path, expected=token):
            if expected == self._seriesTitleLogoToken and path:
                self._showSeriesTitleLogo(path, expected)
        try:
            from .genre_ultra_artwork import request_transparent_logo
            request_transparent_logo(url, dict(self.source or {}), done,
                                     lambda _p: self._genreSeriesMissing('logo', url),
                                     lambda fn,*args: reactor.callFromThread(fn,*args) if reactor else None)
        except Exception:
            request_artwork(url, "logos", done, priority=80)

    def _updateProviderLogo(self):
        try:
            from .details_branding import detail_brand_logo
            path = detail_brand_logo(self.seriesItem)
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _normImage(self, value):
        if isinstance(value, list):
            value = value[0] if value else ""
        if isinstance(value, str):
            v = value.strip().replace("\\/", "/")
            if v.startswith("["):
                try:
                    arr = json.loads(v)
                    v = arr[0] if arr else ""
                except Exception:
                    pass
            if v.startswith("/") and not v.startswith("//"):
                v = "https://image.tmdb.org/t/p/w780" + v
            return v
        return ""

    def _normSeriesTitle(self, value):
        text = clean_series_label(value).lower()
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"\b(?:4k|uhd|fhd|hd|sd|1080p|720p|2160p|ar|en|eng|arabic|english|netflix|amz|amzn|web[- ]?dl|webrip)\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())

    def _seriesServerBackdrop(self, *mappings):
        """Resolve provider backdrop fields against the active server.

        A leading slash from Xtream/Stalker is a server-relative path, not a
        TMDb path. TMDb paths are handled separately before this helper.
        """
        for mapping in mappings:
            if not isinstance(mapping, dict):
                continue
            for key in ("backdrop_path", "backdrop", "backdrop_url", "movie_backdrop", "screenshot_uri"):
                value = mapping.get(key)
                if value not in (None, "", [], {}):
                    try:
                        url = _server_asset_url(self._vodSelectedSource or {}, value)
                    except Exception:
                        url = ""
                    if url:
                        return url
        return ""

    def _startSeriesArtworkFirst(self):
        _series_restart_log("LAYOUT_ARTWORK_ENTER", self.seriesItem)
        try:
            # Use the same provider-poster resolver as Movies/player. It checks
            # all common poster fields and resolves relative server URLs correctly.
            poster = _server_poster_url(self._vodSelectedSource or {}, self.seriesItem)
            if not poster:
                poster = self._normImage(self.seriesItem.get("poster_path") or "")
            tmdb_backdrop = self._normImage(self.seriesItem.get("_tmdb_backdrop") or "")
            server_backdrop = self._seriesServerBackdrop(self.seriesItem)
            backdrop = server_backdrop or tmdb_backdrop
            self.seriesFallbackPoster = poster
            # Backdrop stays a backdrop. Never stretch a poster into the large
            # background, and do not replace an already-visible backdrop later.
            self.seriesBackdrop = backdrop
            self._seriesBackdropLocked = bool(backdrop)
            self._seriesBackdropSource = "provider" if server_backdrop else ("tmdb" if backdrop else "")
            if self.seriesBackdrop:
                _series_restart_log("BACKDROP_LOAD_CALL", self.seriesItem, self.seriesBackdrop)
                self.loadBackdrop(self.seriesBackdrop)
            else:
                self._genreSeriesMissing('backdrop')
            self._genreSeriesMissing('logo')
            _series_restart_log("LAYOUT_ARTWORK_RESOLVED", self.seriesItem, "poster=%s backdrop=%s" % (bool(self.seriesFallbackPoster), bool(self.seriesBackdrop)))
        except Exception as exc:
            _series_restart_log("LAYOUT_ARTWORK_ERROR", self.seriesItem, str(exc))
        try:
            timer = eTimer()
            self._seriesDeferredLoadTimer = timer
            def go():
                try: timer.stop()
                except Exception: pass
                self.loadSeries()
            try:
                self._seriesDeferredLoadConn = timer.timeout.connect(go)
            except Exception:
                timer.callback.append(go)
            timer.start(120, True)
            _series_restart_log("DEFER_TIMER_STARTED", self.seriesItem, "120ms")
        except Exception as exc:
            _series_restart_log("DEFER_TIMER_ERROR", self.seriesItem, str(exc))
            self.loadSeries()


    def loadSeries(self):
        sid = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id")
        _series_restart_log("LOAD_SERIES_ENTER", self.seriesItem, "sid=%s" % str(sid))
        self["desc"].setText(tr(""))

        def worker():
            _series_restart_log("WORKER_ENTER", self.seriesItem, "sid=%s" % str(sid))
            try:
                source = dict(self._vodSelectedSource or {})
                chosen = dict(self.seriesItem or {})
                resolved_sid = sid

                # Popular/Trending never checks availability in the list.
                # Search the provider only after this details screen has opened.
                if not resolved_sid and chosen.get("_home_tmdb_feed"):
                    wanted_id = str(chosen.get("tmdb_id") or chosen.get("id") or "").strip()
                    wanted = self._normSeriesTitle(chosen.get("name") or chosen.get("title") or "")
                    wanted_year_match = re.search(r"\b(19|20)\d{2}\b", str(chosen.get("year") or chosen.get("first_air_date") or ""))
                    wanted_year = wanted_year_match.group(0) if wanted_year_match else ""
                    best = None

                    def row_tmdb_id(row):
                        row = row or {}
                        for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                            for key in ("tmdb_id", "tmdb", "tmdbid"):
                                value = mapping.get(key)
                                if value not in (None, ""):
                                    try:
                                        return str(int(value))
                                    except Exception:
                                        value = str(value).strip()
                                        if value:
                                            return value
                        return ""

                    def match_rows(rows):
                        if wanted_id:
                            for candidate in rows or []:
                                if row_tmdb_id(candidate) == wanted_id:
                                    return dict(candidate)
                        selected = None
                        selected_score = 0.0
                        for candidate in rows or []:
                            cand = self._normSeriesTitle(candidate.get("name") or candidate.get("title") or "")
                            if not cand or not wanted:
                                continue
                            raw_year = candidate.get("year") or candidate.get("releaseDate") or candidate.get("first_air_date") or ""
                            ym = re.search(r"\b(19|20)\d{2}\b", str(raw_year))
                            row_year = ym.group(0) if ym else ""
                            if wanted_year and row_year and wanted_year != row_year:
                                continue
                            a=set(wanted.split()); b=set(cand.split())
                            overlap=a & b
                            coverage=float(len(overlap))/float(min(len(a),len(b))) if a and b else 0.0
                            union=float(len(a | b)) if a or b else 0.0
                            jaccard=float(len(overlap))/union if union else 0.0
                            from difflib import SequenceMatcher
                            ratio=SequenceMatcher(None,wanted,cand).ratio()
                            score=1.0 if wanted == cand else 0.0
                            if not score and coverage == 1.0 and min(len(a),len(b)) >= 2 and abs(len(a)-len(b)) <= 1:
                                score=0.98
                            elif not score and min(len(a),len(b)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
                                score=ratio
                            threshold=0.94 if wanted_year and row_year else 0.98
                            if score >= threshold and score > selected_score:
                                selected=dict(candidate); selected_score=score
                        return selected

                    try:
                        client = get_source_client(source)
                        if source.get("type") == "xtream":
                            best = match_rows(list(get_filtered_streams(source, "series", client) or []))
                        elif source.get("type") == "stalker":
                            cats,_ = get_cached_categories(source, "series", client=client, wait_for_server=True)
                            cats = filter_categories(source, "series", cats or [])
                            for cat in cats:
                                cid = str((cat or {}).get("category_id") or "")
                                if not cid:
                                    continue
                                rows,_origin = get_category_streams(source, "series", client, cid, use_cache=True, wait_for_server=True)
                                best = match_rows(rows or [])
                                if best:
                                    break
                        if best is not None:
                            chosen.update(best)
                            resolved_sid = best.get("series_id") or best.get("stream_id") or best.get("id")
                            self.seriesItem.update(best)
                            if self._serverPackageProvider:
                                self.seriesItem["_server_package_provider"] = self._serverPackageProvider
                                self.seriesItem["_tmdb_provider"] = self._serverPackageProvider
                    except Exception:
                        pass

                _series_restart_log("SERIES_INFO_BEFORE", chosen, "resolved_sid=%s" % str(resolved_sid))
                data = (get_source_client(source).series_info(resolved_sid) or {}) if resolved_sid else {}
                _series_restart_log("SERIES_INFO_AFTER", chosen, "keys=%s" % (list(data.keys())[:20] if isinstance(data, dict) else type(data).__name__))

                # r141: first-open fast path.  series_info already contains the
                # seasons/episodes needed by this screen, so do not hold the UI
                # behind TMDb metadata/artwork network calls.  Render once now;
                # the worker continues below and applies metadata only.
                self._seriesMetadataWorkerPending = True
                if reactor:
                    reactor.callFromThread(self._seriesReady, data)
                else:
                    self._seriesReady(data)

                try:
                    info = data.get("info") or {}
                    raw_title = chosen.get("name") or chosen.get("title") or info.get("name") or ""
                    raw_year = info.get("releaseDate") or info.get("releasedate") or info.get("year") or chosen.get("year") or ""
                    year_match = re.search(r"\b(19|20)\d{2}\b", str(raw_year))
                    _series_restart_log("TMDB_METADATA_BEFORE", chosen, "title=%s" % str(raw_title)[:120])
                    tmdb = TMDbClient()
                    search_year = year_match.group(0) if year_match else None
                    # r435: this TMDb id drives episode stills. Resolve noisy
                    # provider titles here, on the actual SeriesDetails path,
                    # rather than only in the package-poster grid.
                    # An existing provider TMDb id identifies the series more
                    # reliably than a subtitle/noisy name search. Never replace
                    # that id with the result for a different show.
                    provider_id = (chosen.get("tmdb_id") or chosen.get("tmdb") or
                                   info.get("tmdb_id") or info.get("tmdb"))
                    # A TMDb match pinned by the user (MENU) beats provider ids.
                    try:
                        from .manual_match import pinned_id as _pinned_tmdb_id
                        provider_id = (_pinned_tmdb_id(self.seriesItem.get("name") or self.seriesItem.get("title") or raw_title, "series")
                                       or _pinned_tmdb_id(raw_title, "series") or provider_id)
                    except Exception:
                        pass
                    bundle = tmdb.details_bundle(provider_id, "series") if provider_id else {}
                    trusted_id = provider_id if bundle else None
                    found = (self._searchSeriesTmdbSafe(tmdb, raw_title, search_year)
                             if raw_title and not trusted_id else None)
                    tid = trusted_id or (found or {}).get("id")
                    if tid and not bundle:
                        bundle = tmdb.details_bundle(tid, "series") or {}
                    if found:
                        seed = dict(found); seed.update(bundle or {}); bundle = seed
                    # Match the player poster fallback when series details/TMDb
                    # metadata has no poster. Search artwork only in that case.
                    if raw_title and not (bundle or {}).get("poster_path"):
                        try:
                            artwork = tmdb.search_artwork(raw_title, kind="series", year=search_year, required_key="poster_path") or {}
                            if artwork.get("poster_path") and (not tid or str(artwork.get("id")) == str(tid)):
                                seed = dict(artwork); seed.update(bundle or {})
                                seed["poster_path"] = artwork.get("poster_path")
                                bundle = seed
                        except Exception:
                            pass
                    # Series backdrop is independent from the poster. A valid
                    # TMDb match can have a poster while its current details/search
                    # bundle has no backdrop, so resolve the backdrop explicitly.
                    if not (bundle or {}).get("backdrop_path"):
                        images = (bundle or {}).get("images") or {}
                        if isinstance(images, dict):
                            other = next((r.get("file_path") for r in (images.get("backdrops") or [])
                                          if isinstance(r, dict) and r.get("file_path")), "")
                            if other:
                                bundle = dict(bundle or {})
                                bundle["backdrop_path"] = other
                    if raw_title and not (bundle or {}).get("backdrop_path"):
                        try:
                            artwork = tmdb.search_artwork(raw_title, kind="series", year=search_year, required_key="backdrop_path") or {}
                            if artwork.get("backdrop_path") and (not tid or str(artwork.get("id")) == str(tid)):
                                seed = dict(artwork); seed.update(bundle or {})
                                seed["backdrop_path"] = artwork.get("backdrop_path")
                                bundle = seed
                        except Exception:
                            pass
                    if tid:
                        self.seriesItem["tmdb_id"] = str(tid)
                        data["_tmdb_id"] = str(tid)
                    data["_tmdb_bundle"] = bundle or {}
                    data["_series_title_logo_url"] = self._applySeriesTitleLogo(bundle, tid)
                    _series_restart_log("TMDB_METADATA_AFTER", chosen, "tmdb_id=%s poster=%s backdrop=%s" % (str(tid or ""), bool((bundle or {}).get("poster_path")), bool((bundle or {}).get("backdrop_path"))))
                except Exception as exc:
                    _series_restart_log("TMDB_METADATA_ERROR", chosen, str(exc))

                _series_restart_log("WORKER_METADATA_DISPATCH", self.seriesItem, "episodes_type=%s" % type((data or {}).get("episodes") if isinstance(data, dict) else None).__name__)
                if reactor:
                    reactor.callFromThread(self._seriesMetadataReady, data)
                else:
                    self._seriesMetadataReady(data)
            except Exception as exc:
                _series_restart_log("WORKER_ERROR", self.seriesItem, str(exc))
                if reactor:
                    reactor.callFromThread(self._seriesFailed, str(exc))
                else:
                    self._seriesFailed(str(exc))

        _series_restart_log("THREAD_CREATE", self.seriesItem)
        thread = threading.Thread(target=worker, name="TiviMateSeriesDetails")
        thread.daemon = True
        thread.start()
        _series_restart_log("THREAD_STARTED", self.seriesItem)


    def _seriesReady(self, data):
        _series_restart_log("SERIES_READY_ENTER", self.seriesItem, "data_type=%s" % type(data).__name__)
        try:
            self.seriesData = data or {}
            info = self.seriesData.get("info") or {}
            tmdb_data = self.seriesData.get("_tmdb_bundle") or {}
            # Keep an existing Arabic server title Arabic. TMDb must not replace
            # it with an English/localized name; it remains metadata fallback only.
            server_title = info.get("name") or self.seriesItem.get("name") or self.seriesItem.get("title") or ""
            # Honor explicit French/Turkish TMDb metadata selection even when
            # the IPTV provider originally supplied an Arabic series title.
            display = merge_metadata(self.seriesItem, provider=info, tmdb=tmdb_data,
                                     language=TMDbClient().language, kind="series")
            title = display["title"] or (tr("TV Show") if get_language() != "ar" else "مسلسل")
            year = display["year"]
            rating = display["rating"]
            genre = display["genre"]
            # Cast/director text follows server-first metadata. TMDb cast
            # portraits remain on their separate artwork path below.
            cast = (info.get("cast") or info.get("actors") or
                    ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("cast") or [])[:8] if x.get("name")))
            director = (info.get("director") or
                        ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("crew") or []) if x.get("job") in ("Director", "Creator")))
            self["title"].setText(compact_series_label(title, 44))
            rating_text = "--"
            stars_text = "☆☆☆☆☆"
            try:
                rating_value = float(str(rating).replace(",", "."))
                if rating_value > 10.0:
                    rating_value = rating_value / 10.0
                rating_value = max(0.0, min(10.0, rating_value))
                rating_text = "%.1f" % rating_value
                star_value = rating_value / 2.0
                full = int(star_value)
                if (star_value - full) >= 0.5 and full < 5:
                    full += 1
                full = max(0, min(5, full))
                stars_text = ("★" * full) + ("☆" * (5 - full))
            except Exception:
                if rating:
                    rating_text = str(rating)[:4]
            self["rating"].setText("")
            self["ratingStars"].setText("")
            self["ratingText"].setText("")
            show_country_flag(self["countryFlag"], tmdb_data, "series", self.seriesItem.get("tmdb_id") or self.seriesData.get("_tmdb_id"))
            self["meta"].setText("  •  ".join(x for x in [str(year), str(genre)] if x))
            cast_text = []
            if cast:
                cast_text.append("طاقم الممثلين: %s" % str(cast)[:150])
            if director:
                cast_text.append("المخرج: %s" % str(director)[:90])
            self["cast"].setText(fit_series_text("\n".join(cast_text), 75, 2))
            self._showSeriesActors(tmdb_data)
            description = display["description"] or "لا توجد معلومات"
            self["desc"].setText(description if contains_arabic_text(description)
                                 else fit_series_text(description, 70, 5))
            # Poster policy: provider/server first using the same resolver as
            # Movies/player (including nested info + relative server URLs), then TMDb.
            server_poster = _server_poster_url(self._vodSelectedSource or {}, self.seriesItem, extra=info)
            self.seriesFallbackPoster = server_poster or self._normImage(tmdb_data.get("poster_path") or "")
            # A later TMDb metadata callback must not replace a working
            # server backdrop.  TMDb is used only when there is no usable
            # provider URL (including a provider URL already marked bad).
            serverBackdrop = self._seriesServerBackdrop(info, self.seriesItem)
            verifiedBackdrop = self._normImage(tmdb_data.get("backdrop_path") or "")
            if serverBackdrop in self._seriesBadBackdropUrls:
                serverBackdrop = ""
            if verifiedBackdrop in self._seriesBadBackdropUrls:
                verifiedBackdrop = ""
            resolvedBackdrop = serverBackdrop or verifiedBackdrop
            if resolvedBackdrop and (self.seriesBackdrop != resolvedBackdrop or
                                     getattr(self, "_seriesBackdropSource", "") == "episode"):
                self.seriesBackdrop = resolvedBackdrop
                self._seriesBackdropLocked = True
                self._seriesBackdropSource = "provider" if serverBackdrop else "tmdb"
                self.loadBackdrop(resolvedBackdrop)
            if (not self.seriesFallbackPoster or not self.seriesBackdrop) and not getattr(self, "_seriesMetadataWorkerPending", False):
                self._ensureSeriesArtworkFallback()

            raw = self.seriesData.get("episodes") or {}
            _series_restart_log("EPISODES_RAW", self.seriesItem, "type=%s seasons=%s" % (type(raw).__name__, len(raw) if hasattr(raw, "__len__") else "?"))
            self.episodesBySeason = {str(key): (value or []) for key, value in raw.items() if value}
            seasons = self.seriesData.get("seasons") or []
            self.seasonItems = []
            if seasons:
                for season in seasons:
                    number = str(season.get("season_number") if season.get("season_number") is not None else season.get("season") or "")
                    if self.episodesBySeason.get(number):
                        row = dict(season)
                        row["_num"] = number
                        self.seasonItems.append(row)
            if not self.seasonItems:
                for number in sorted(self.episodesBySeason.keys(), key=lambda value: int(value) if str(value).isdigit() else 999):
                    self.seasonItems.append({"_num": number, "name": (("Season %s" % number) if get_language() == "en" else (("Saison %s" % number) if get_language() == "fr" else ("الموسم %s" % number)))})
            self.seasonIndex = 0
            _series_restart_log("SEASONS_BUILT", self.seriesItem, "seasonItems=%d episodeSeasons=%d" % (len(self.seasonItems), len(self.episodesBySeason)))
            if not self.seriesBackdrop:
                self._inheritBackdropFromEpisodes()
            self.selectSeason()
            _series_restart_log("SERIES_READY_DONE", self.seriesItem)
        except Exception as exc:
            _series_restart_log("SERIES_READY_ERROR", self.seriesItem, str(exc))
            self._seriesFailed(str(exc))

    def _seriesMetadataReady(self, data):
        """Apply late TMDb metadata/artwork without rebuilding seasons/episodes."""
        try:
            self._seriesMetadataWorkerPending = False
            if not isinstance(data, dict):
                return
            # Keep the already-rendered episode/seasons structures untouched.
            self.seriesData.update({k: v for k, v in data.items() if k in ("_tmdb_id", "_tmdb_bundle")})
            if data.get("_tmdb_id"):
                self.seriesItem["tmdb_id"] = str(data.get("_tmdb_id"))
            info = self.seriesData.get("info") or {}
            tmdb_data = data.get("_tmdb_bundle") or {}
            server_title = info.get("name") or self.seriesItem.get("name") or self.seriesItem.get("title") or ""
            display = merge_metadata(self.seriesItem, provider=info, tmdb=tmdb_data,
                                     language=TMDbClient().language, kind="series")
            title = display["title"] or (tr("TV Show") if get_language() != "ar" else "مسلسل")
            year = display["year"]
            rating = display["rating"]
            genre = display["genre"]
            cast = (info.get("cast") or info.get("actors") or
                    ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("cast") or [])[:8] if x.get("name")))
            director = (info.get("director") or
                        ", ".join(x.get("name", "") for x in ((tmdb_data.get("credits") or {}).get("crew") or []) if x.get("job") in ("Director", "Creator")))
            self["title"].setText(compact_series_label(title, 44))
            self._loadSeriesTitleLogoUltra(tmdb_data, server_title,
                                           data.get("_tmdb_id") or "",
                                           data.get("_series_title_logo_url") or "")
            self["meta"].setText("  •  ".join(x for x in [str(year), str(genre)] if x))
            self["cast"].setText(fit_series_text("\n".join((["طاقم الممثلين: %s" % str(cast)[:150]] if cast else []) + (["المخرج: %s" % str(director)[:90]] if director else [])), 75, 2))
            self._showSeriesActors(tmdb_data)
            description = display["description"] or "لا توجد معلومات"
            self["desc"].setText(description if contains_arabic_text(description)
                                 else fit_series_text(description, 70, 5))
            try:
                rv = float(str(rating).replace(",", ".")); rv = rv / 10.0 if rv > 10.0 else rv; rv = max(0.0, min(10.0, rv))
                self["rating"].setText("")
                self["ratingStars"].setText("")
            except Exception:
                pass
            self["ratingText"].setText("")
            show_country_flag(self["countryFlag"], tmdb_data, "series", self.seriesItem.get("tmdb_id") or self.seriesData.get("_tmdb_id"))
            poster = _server_poster_url(self._vodSelectedSource or {}, self.seriesItem, extra=info) or self._normImage(tmdb_data.get("poster_path") or "")
            serverBackdrop = self._seriesServerBackdrop(info, self.seriesItem)
            verifiedBackdrop = self._normImage(tmdb_data.get("backdrop_path") or "")
            if serverBackdrop in self._seriesBadBackdropUrls:
                serverBackdrop = ""
            if verifiedBackdrop in self._seriesBadBackdropUrls:
                verifiedBackdrop = ""
            backdrop = serverBackdrop or verifiedBackdrop
            if poster:
                self.seriesFallbackPoster = poster
            # Preserve the provider's working backdrop after late TMDb
            # enrichment.  A bad provider image is excluded above, allowing
            # TMDb to take over on genuine artwork failure.
            if backdrop and (self.seriesBackdrop != backdrop or
                             getattr(self, "_seriesBackdropSource", "") == "episode"):
                self.seriesBackdrop = backdrop
                self._seriesBackdropLocked = True
                self._seriesBackdropSource = "provider" if serverBackdrop else "tmdb"
                self.loadBackdrop(backdrop)
            if not self.seriesBackdrop:
                self._inheritBackdropFromEpisodes(self.episodeItems)
            if not self.seriesFallbackPoster or not self.seriesBackdrop:
                self._ensureSeriesArtworkFallback()
            # The first episode render happens before this late TMDb result.
            # Resolve visible real SxxExx stills now without rebuilding the
            # seasons list or losing the selected episode/focus.
            if self.seriesData.get("_tmdb_id") and self.episodeItems:
                for visible_slot in range(min(5, len(self.episodeItems) - self.episodePage)):
                    absolute_index = self.episodePage + visible_slot
                    record = self.episodeItems[absolute_index]
                    if not record.get("_tmdb_episode_still"):
                        self._queueEpisodeStill(visible_slot, record, absolute_index)
            _series_restart_log("SERIES_METADATA_READY", self.seriesItem)
        except Exception as exc:
            self._seriesMetadataWorkerPending = False
            _series_restart_log("SERIES_METADATA_ERROR", self.seriesItem, str(exc))

    def _seriesFailed(self, error):
        self["desc"].setText("تعذر تحميل المسلسل\n%s" % error)

    def _setVisible(self, name, visible):
        try:
            self[name].setVisible(visible)
            return
        except Exception:
            pass
        try:
            if self[name].instance:
                self[name].instance.setVisible(visible)
        except Exception:
            pass

    def _renderSeasonChips(self):
        """Display numeric season buttons like the approved Latest-style mock-up.

        Paged by five for long series. Widget visibility and focus are purely
        local; changing season still uses the original episode loader/cache.
        """
        total = len(self.seasonItems)
        start = (self.seasonIndex // 5) * 5 if total else 0
        for slot in range(5):
            index = start + slot
            label = self["seasonChipLabel%d" % slot]
            bg = self["seasonChipBg%d" % slot]
            if index >= total:
                label.setText("")
                label.hide()
                bg.hide()
                continue
            raw = str(self.seasonItems[index].get("_num") or "0").strip()
            try:
                caption = "S%02d" % int(raw)
            except (ValueError, TypeError):
                caption = ("S" + raw)[:6]
            label.setText(caption)
            label.show()
            bg.show()
        try:
            if total:
                slot = self.seasonIndex - start
                self["seasonChipFocus"].instance.move(ePoint(sx(self._seasonChipX[slot]), sy(632)))
                self["seasonChipFocus"].show()
            else:
                self["seasonChipFocus"].hide()
        except Exception:
            pass

    def selectSeason(self):
        _series_restart_log("SELECT_SEASON_ENTER", self.seriesItem, "index=%s seasons=%s" % (str(self.seasonIndex), len(self.seasonItems)))
        if not self.seasonItems:
            self.episodeItems = []
            self._renderSeasonChips()
            self["seasonInfo"].setText("")
            self.renderEpisodes()
            return
        self.seasonIndex = max(0, min(self.seasonIndex, len(self.seasonItems) - 1))
        self._renderSeasonChips()
        season = self.seasonItems[self.seasonIndex]
        num = str(season.get("_num", ""))
        self.episodeItems = self.episodesBySeason.get(num, []) or []
        self["seasonInfo"].setText("")
        self.episodePage = 0
        self.episodeIndex = 0
        _series_restart_log("SELECT_SEASON_RENDER", self.seriesItem, "season=%s episodes=%d" % (num, len(self.episodeItems)))
        self.renderEpisodes()

    def _episodeArtworkUrl(self, item, info=None):
        """Return a real episode/still image from provider data, if present."""
        item = item if isinstance(item, dict) else {}
        info = info if isinstance(info, dict) else {}
        # Episode APIs commonly expose landscape artwork in these fields.
        # Keep this separate from the generic series-poster resolver so a
        # portrait poster does not win over a real episode still.
        keys = (
            "screenshot_uri", "still_path", "backdrop_path", "backdrop", "backdrop_url",
            "movie_image", "image", "cover_big", "cover", "stream_icon"
        )
        for mapping in (item, item.get("info") if isinstance(item.get("info"), dict) else {}, info):
            for key in keys:
                value = mapping.get(key) if isinstance(mapping, dict) else None
                if value not in (None, "", [], {}):
                    try:
                        # Episodes have real landscape keys which the poster-only
                        # resolver intentionally ignores. Resolve the *episode*
                        # asset directly against the active provider instead.
                        url = _server_asset_url(self._vodSelectedSource or {}, value)
                        if key == "still_path" and isinstance(value, str) and value.startswith("/") and not str(url or "").startswith(("http://", "https://")):
                            url = self._normImage(value)
                    except Exception:
                        url = ""
                    if url and not self._unavailableEpisodeHost(url):
                        return url
        return ""

    @staticmethod
    def _unavailableEpisodeHost(url):
        """Ignore hosts known to return an image of an unavailable thumbnail.

        A binary JPEG on these hosts can be their error graphic; checking image
        headers alone would incorrectly mark the download as a successful still.
        """
        try:
            host = (urlsplit(str(url or "")).hostname or "").lower()
            return host == "imgbox.com" or host.endswith(".imgbox.com") or host == "imgbox.io" or host.endswith(".imgbox.io")
        except Exception:
            return False

    @staticmethod
    def _episodeHdBackdropUrl(url):
        """Use a separate high-resolution TMDb still for the full-screen background.

        Episode cards continue to use the shared w780 cache; no global artwork
        cache or other screen is changed.  TMDb w1280 is native 720p detail
        instead of enlarging a 780px image to 1920 display pixels.
        """
        url = str(url or "").strip()
        marker = "image.tmdb.org/t/p/"
        if marker not in url.lower():
            return ""
        prefix, remainder = url.split(marker, 1)
        if "/" not in remainder:
            return ""
        _, filename = remainder.split("/", 1)
        if not filename:
            return ""
        return prefix + marker + "w1280/" + filename

    def _showEpisodeBackdropHd(self, url):
        """Show the original cached still first, then upgrade to HD when ready.

        An HD cache miss must never leave the existing episode backdrop blank:
        the old implementation replaced the original w780 request immediately,
        so failed/slow w1280 downloads hid an otherwise valid episode image.
        """
        hd = self._episodeHdBackdropUrl(url)
        if not hd:
            return False
        selected = self.episodePage + self.episodeIndex
        token = (hd, selected)
        self._episodeHdWanted = token
        cached_hd = cached_artwork(hd, "episode_hd")
        if cached_hd:
            self.loadBackdrop(hd)
            return True

        # Keep the already available thumbnail on screen during the HD fetch.
        self.loadBackdrop(url)

        def ready(path):
            if (getattr(self, "_seriesClosed", False) or
                    getattr(self, "_episodeHdWanted", None) != token or
                    self.episodePage + self.episodeIndex != selected or
                    not path or not os.path.isfile(path)):
                return
            self.loadBackdrop(hd)

        def failed(_path):
            # The fallback is intentionally retained on network/cache failure.
            return

        try:
            from .genre_ultra_artwork import request as genre_ultra_request
            genre_ultra_request(hd, "episode_hd", dict(self.source or {}),
                                ready, failed,
                                lambda fn, *args: reactor.callFromThread(fn, *args) if reactor else fn(*args))
        except Exception:
            # Backdrop remains visible even when HD transport is unavailable.
            pass
        return True

    def _promoteEpisodeBackdrop(self, candidate, confirmed_path=""):
        """Promote an already successful episode still after series art failure.

        No extra network lookup: the episode thumbnail downloader owns the
        download, while cached_artwork() proves disk-backed candidates exist.
        """
        candidate = str(candidate or "").strip()
        if not candidate or self._unavailableEpisodeHost(candidate):
            return False
        if getattr(self, "_seriesOriginalBackdropShown", False):
            return False
        if (self.seriesBackdrop and not getattr(self, "_seriesBackdropFailed", False)
                and getattr(self, "_seriesBackdropSource", "") != "episode"):
            # An original image is still being decoded; do not cancel it.
            return False
        if not confirmed_path:
            confirmed_path = cached_artwork(candidate, "backdrops")
        if not confirmed_path or not os.path.isfile(confirmed_path):
            return False
        if self.seriesBackdrop == candidate and getattr(self, "_seriesBackdropSource", "") == "episode":
            return True
        self.seriesBackdrop = candidate
        self._seriesBackdropSource = "episode"
        self._seriesBackdropLocked = False  # An original TMDb/provider image may supersede the still.
        self._seriesBackdropFailed = False
        if not self._showEpisodeBackdropHd(candidate):
            self.loadBackdrop(candidate)
        return True

    def _inheritBackdropFromEpisodes(self, rows=None):
        """Use only cached, valid episode stills; never treat a URL as success."""
        if getattr(self, "_seriesOriginalBackdropShown", False):
            return False
        if rows is None:
            rows = []
            if isinstance(getattr(self, "episodesBySeason", None), dict):
                for season_rows in (self.episodesBySeason or {}).values():
                    if season_rows:
                        rows.extend(list(season_rows or []))
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            info = row.get("info") if isinstance(row.get("info"), dict) else {}
            candidate = str(row.get("_tmdb_episode_still") or "").strip() or self._episodeArtworkUrl(row, info)
            if candidate and self._promoteEpisodeBackdrop(candidate):
                return True
        return False

    def _ensureSeriesArtworkFallback(self, force_poster=False, force_backdrop=False):
        """Mirror the player TMDb fallback, including failed provider artwork.

        A provider URL can be present but dead.  In that case the player falls
        back to TMDb after the download fails; SeriesDetails must do the same.
        """
        if getattr(self, "_seriesArtworkFallbackPending", False):
            return
        title = str(
            self.seriesItem.get("name") or self.seriesItem.get("title") or
            (self.seriesData.get("info") or {}).get("name") or ""
        ).strip()
        tid = str(
            (self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or
            self.seriesItem.get("tmdb") or ""
        ).strip()
        if not title and not tid:
            return
        self._seriesArtworkFallbackPending = True
        token = "%s|%s" % (tid, title)
        self._seriesArtworkFallbackToken = token

        def worker():
            resolved_tid = tid
            poster = ""
            backdrop = ""
            try:
                client = TMDbClient()
                data = client.details_bundle(resolved_tid, "series") if resolved_tid else {}
                poster = (data or {}).get("poster_path") or ""
                backdrop = (data or {}).get("backdrop_path") or ""
                if (not poster or not backdrop) and not (resolved_tid and data):
                    raw_year = (
                        self.seriesItem.get("year") or self.seriesItem.get("releaseDate") or
                        self.seriesItem.get("releasedate") or (self.seriesData.get("info") or {}).get("year") or ""
                    )
                    match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                    found = self._searchSeriesTmdbSafe(
                        client, title, match.group(0) if match else None
                    ) if title else None
                    new_tid = (found or {}).get("id")
                    if new_tid and (not tid or str(new_tid) == str(tid)):
                        resolved_tid = str(new_tid)
                        detail = client.details_bundle(resolved_tid, "series") or {}
                        data = dict(found or {})
                        data.update(detail)
                    elif found:
                        data = found
                    poster = poster or (data or {}).get("poster_path") or ""
                    backdrop = backdrop or (data or {}).get("backdrop_path") or ""
                if not backdrop and title and not (resolved_tid and data):
                    try:
                        raw_year = (
                            self.seriesItem.get("year") or self.seriesItem.get("releaseDate") or
                            self.seriesItem.get("releasedate") or (self.seriesData.get("info") or {}).get("year") or ""
                        )
                        match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                        artwork = client.search_artwork(
                            title, kind="series", year=match.group(0) if match else None,
                            required_key="backdrop_path"
                        ) or {}
                        if not resolved_tid or str(artwork.get("id")) == str(resolved_tid):
                            backdrop = artwork.get("backdrop_path") or ""
                    except Exception:
                        pass
                poster = self._normImage(poster)
                backdrop = self._normImage(backdrop)
            except Exception:
                poster = ""
                backdrop = ""

            def apply():
                if (getattr(self, "_seriesClosed", False) or
                        getattr(self, "_seriesArtworkFallbackToken", "") != token):
                    return
                self._seriesArtworkFallbackPending = False
                previous_tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
                if resolved_tid:
                    self.seriesItem["tmdb_id"] = str(resolved_tid)
                    self.seriesData["_tmdb_id"] = str(resolved_tid)
                changed = bool(resolved_tid and str(resolved_tid) != previous_tid)
                if poster and ((force_poster and poster != self.seriesFallbackPoster) or not self.seriesFallbackPoster):
                    self.seriesFallbackPoster = poster
                    changed = True
                if backdrop and backdrop not in getattr(self, "_seriesBadBackdropUrls", set()) and ((force_backdrop and backdrop != self.seriesBackdrop) or not self.seriesBackdrop):
                    self.seriesBackdrop = backdrop
                    self._seriesBackdropLocked = True
                    self._seriesBackdropSource = ("tmdb" if "image.tmdb.org/t/p/" in str(backdrop) else "provider")
                    self.loadBackdrop(backdrop)
                    changed = True
                # A newly resolved TMDb id is itself enough reason to repaint:
                # missing episode cards can now request their real TMDb stills.
                if changed and self.episodeItems:
                    self.renderEpisodes()

            if reactor:
                reactor.callFromThread(apply)
            else:
                apply()

        thread = threading.Thread(target=worker, name="TiviMateSeriesArtworkFallback")
        thread.daemon = True
        thread.start()

    def _episodeNumbers(self, item, absolute_index):
        try:
            season = str(self.seasonItems[self.seasonIndex].get("_num", "") or "") if self.seasonItems else ""
        except Exception:
            season = ""
        info = (item or {}).get("info") or {}
        if not season:
            season = str((item or {}).get("season") or (item or {}).get("season_number") or info.get("season") or info.get("season_number") or "")
        episode = ((item or {}).get("episode_num") or (item or {}).get("episode_number") or
                   info.get("episode_num") or info.get("episode_number") or (absolute_index + 1))
        try:
            return str(int(str(season).strip())), str(int(str(episode).strip()))
        except Exception:
            return "", ""

    def _queueEpisodeStill(self, slot, item, absolute_index):
        """Resolve a missing episode thumbnail from TMDb, then repaint that card."""
        tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
        if not tid:
            self._ensureSeriesArtworkFallback()
            return
        season, episode = self._episodeNumbers(item, absolute_index)
        if not season or not episode:
            return
        key = "%s:%s:%s" % (tid, season, episode)
        # Persistent cache-first lookup: a resolved SxxExx still survives
        # leaving this screen and restarting Enigma2.
        remembered = episode_still_index_lookup(tid, season, episode)
        if remembered:
            item["_tmdb_episode_still"] = remembered
            current = self.episodePage + slot
            if (0 <= current < len(self.episodeItems) and
                    self.episodeItems[current] is item):
                fallback = self.seriesFallbackPoster or self.seriesBackdrop
                self._loadThumb(slot, remembered, (310, 174), fallback_url=fallback,
                                kind="backdrops",
                                fallback_kind=("posters" if self.seriesFallbackPoster else "backdrops"))
            selected = self.episodePage + self.episodeIndex
            if selected == absolute_index and 0 <= selected < len(self.episodeItems) and self.episodeItems[selected] is item:
                self._showEpisodeBackdropHd(remembered)
            return
        missed = getattr(self, "_episodeStillMissing", None)
        if isinstance(missed, dict) and missed.get(key, 0) > time.time():
            return
        pending = getattr(self, "_episodeStillPending", None)
        if pending is None:
            pending = set()
            self._episodeStillPending = pending
        if key in pending or str((item or {}).get("_tmdb_episode_still") or "").strip():
            return
        pending.add(key)

        def worker():
            still = ""
            try:
                row = TMDbClient()._get("/tv/%s/season/%s/episode/%s" % (tid, season, episode), {}) or {}
                try:
                    from .episode_labels import meta_put
                    meta_put(tid, season, episode, row.get("name") or "", row.get("runtime") or 0)
                    if row.get("name"):
                        item["_ep_tmdb_name"] = row.get("name")
                    if row.get("runtime"):
                        item["_ep_runtime"] = row.get("runtime")
                except Exception:
                    pass
                still = self._normImage(row.get("still_path") or "")
                if still:
                    episode_still_index_save(tid, season, episode, still)
            except Exception:
                still = ""

            def apply():
                try:
                    self._episodeStillPending.discard(key)
                except Exception:
                    pass
                if getattr(self, "_seriesClosed", False):
                    return
                try:
                    selected_now = self.episodePage + self.episodeIndex
                    if (selected_now == absolute_index and 0 <= selected_now < len(self.episodeItems)
                            and self.episodeItems[selected_now] is item):
                        from .episode_labels import preview_line
                        parent_title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
                        number = item.get("episode_num") or item.get("episode_number") or (absolute_index + 1)
                        text = preview_line(item, number, parent_title, get_language())
                        self["episodeInfo"].setText(text)
                except Exception:
                    pass
                if not still:
                    misses = getattr(self, "_episodeStillMissing", None)
                    if misses is None:
                        misses = {}
                        self._episodeStillMissing = misses
                    misses[key] = time.time() + 1800
                    return
                try:
                    item["_tmdb_episode_still"] = still
                except Exception:
                    return
                current = self.episodePage + slot
                if 0 <= current < len(self.episodeItems) and self.episodeItems[current] is item:
                    fallback = self.seriesFallbackPoster or self.seriesBackdrop
                    self._loadThumb(
                        slot, still, (310, 174), fallback_url=fallback,
                        kind="backdrops",
                        fallback_kind=("posters" if self.seriesFallbackPoster else "backdrops")
                    )
                selected = self.episodePage + self.episodeIndex
                if (selected == absolute_index and
                        0 <= selected < len(self.episodeItems) and
                        self.episodeItems[selected] is item):
                    self._showEpisodeBackdropHd(still)

            if reactor:
                reactor.callFromThread(apply)
            else:
                apply()

        try:
            from concurrent.futures import ThreadPoolExecutor
            pool = getattr(SeriesDetailsScreen, "_episodeStillPool", None)
            if pool is None:
                pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviEpisodeStill")
                SeriesDetailsScreen._episodeStillPool = pool
            pool.submit(worker)
        except Exception:
            pending.discard(key)

    def renderEpisodes(self):
        _series_restart_log("RENDER_EPISODES_ENTER", self.seriesItem, "page=%s index=%s count=%s active_picloads=%s" % (str(self.episodePage), str(self.episodeIndex), len(self.episodeItems), len(getattr(self, "picloads", []) or [])))
        self.downloads = []
        # r428: NEVER drop active ePicLoad objects while their async decode
        # callback is still pending.  Enigma2's native decoder keeps using the
        # Python-owned loader; replacing this list can release the loader and
        # produce a native restart with no Python crash screen.  Each completed
        # loader already removes itself in _decodeThumb.ready(), so preserving
        # the list is both bounded and safe across episode-page redraws.
        if not isinstance(getattr(self, "picloads", None), list):
            self.picloads = []
        for slot in range(5):
            idx = self.episodePage + slot
            item = self.episodeItems[idx] if idx < len(self.episodeItems) else None
            self._setVisible("episode%d" % slot, bool(item))
            self._setVisible("episodeBadgeBg%d" % slot, bool(item))
            self._setVisible("episodeLabel%d" % slot, bool(item))
            if not item:
                self["episodeLabel%d" % slot].setText(tr(""))
                continue
            ep = item.get("episode_num") or item.get("episode_number") or (idx + 1)
            lang = get_language()
            prefix = ("EPISODE %s" % ep) if lang == "en" else (("ÉPISODE %s" % ep) if lang == "fr" else ("الحلقة %s" % ep))
            self["episodeLabel%d" % slot].setText(prefix)
            self._placeholder(slot)
            inf = item.get("info") or {}
            episode_url = self._episodeArtworkUrl(item, inf)
            tmdb_still = str(item.get("_tmdb_episode_still") or "").strip()
            if not tmdb_still:
                tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
                season_num, episode_num = self._episodeNumbers(item, idx)
                if tid and season_num and episode_num:
                    tmdb_still = episode_still_index_lookup(tid, season_num, episode_num)
                    if tmdb_still:
                        item["_tmdb_episode_still"] = tmdb_still
            if tmdb_still and self._unavailableEpisodeHost(tmdb_still):
                tmdb_still = ""
                item.pop("_tmdb_episode_still", None)
            fallback_url = self.seriesBackdrop or self.seriesFallbackPoster
            # r127: every SeriesDetails episode card follows the same artwork
            # pipeline.  Show cached/resolved TMDb episode still first; while it
            # is not available, keep the provider image/fallback visible and
            # resolve the real SxxExx still asynchronously.
            url = tmdb_still or episode_url or fallback_url
            if url:
                landscape = bool(tmdb_still or episode_url)
                primary_kind = "backdrops" if landscape else ("posters" if self.seriesFallbackPoster else "backdrops")
                fallback_kind = "backdrops" if self.seriesBackdrop and fallback_url == self.seriesBackdrop else "posters"
                self._loadThumb(slot, url, (328, 184),
                                fallback_url=(fallback_url if landscape and fallback_url and fallback_url != url else ""),
                                kind=primary_kind, fallback_kind=fallback_kind)
            if not tmdb_still and (self.seriesData.get("_tmdb_id") or self.seriesItem.get("tmdb_id")):
                # Provider HTTP 200 can be an error slate instead of an episode
                # image. Resolve the exact TMDb SxxExx still off the UI thread.
                self._queueEpisodeStill(slot, item, idx)
        episode_prefetch = []
        for row in list(self.episodeItems[self.episodePage:self.episodePage + 10] or []):
            try:
                inf = (row or {}).get("info") or {}
                u = self._episodeArtworkUrl(row or {}, inf)
                if u:
                    episode_prefetch.append(u)
            except Exception:
                pass
        if episode_prefetch:
            prefetch_artwork(episode_prefetch, "backdrops", priority=2)
        if self.seriesFallbackPoster:
            prefetch_artwork([self.seriesFallbackPoster], "posters", priority=3)
        elif self.seriesBackdrop:
            prefetch_artwork([self.seriesBackdrop], "backdrops", priority=2)
        self._setVisible("episodeSelector", bool(self.episodeItems))
        self._moveSelector()
        self.previewEpisode()
        _series_restart_log("RENDER_EPISODES_DONE", self.seriesItem, "page=%s active_picloads=%s" % (str(self.episodePage), len(getattr(self, "picloads", []) or [])))

    def _placeholder(self, slot):
        try:
            self["episode%d" % slot].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "series/episode_placeholder.png"))
        except Exception:
            pass

    def _loadThumb(self, slot, url, size, fallback_url="", retry=1, kind="backdrops", fallback_kind="posters"):
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        kind = kind if kind in ("posters", "backdrops") else "backdrops"
        fallback_kind = fallback_kind if fallback_kind in ("posters", "backdrops") else "posters"
        if not url:
            if fallback_url:
                return self._loadThumb(slot, fallback_url, size, fallback_url="", retry=0, kind=fallback_kind, fallback_kind=fallback_kind)
            return
        requests = getattr(self, "_episode_artwork_requests", None)
        if requests is None:
            requests = {}
            self._episode_artwork_requests = requests
        token = "%s|%s" % (slot, url)
        requests[slot] = token

        def done(path, s=slot, sz=size, expected=token):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != expected:
                return
            self._decodeThumb(s, path, sz, expected=expected, source_url=url,
                              episode_still=(kind == "backdrops" and url not in
                                             (self.seriesFallbackPoster, self.seriesBackdrop)))

        def failed(_path, s=slot, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_episode_artwork_requests", {}).get(s) != token:
                return
            try:
                # Do not let the generic series poster prevent requesting the
                # matching SxxExx still. A provider URL may return a valid JPEG
                # containing an error graphic, or a dead URL may fail entirely.
                absolute_index = self.episodePage + s
                if 0 <= absolute_index < len(self.episodeItems):
                    record = self.episodeItems[absolute_index]
                    saved_still = str(record.get("_tmdb_episode_still") or "").strip()
                    if saved_still and saved_still == primary:
                        record.pop("_tmdb_episode_still", None)
                        season, episode = self._episodeNumbers(record, absolute_index)
                        tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
                        if tid and season and episode:
                            if not isinstance(getattr(self, "_episodeStillMissing", None), dict):
                                self._episodeStillMissing = {}
                            self._episodeStillMissing["%s:%s:%s" % (tid, season, episode)] = time.time() + 1800
                    elif primary not in (self.seriesFallbackPoster, self.seriesBackdrop):
                        self._queueEpisodeStill(s, record, absolute_index)
            except Exception:
                pass
            if retries > 0 and not (primary.startswith("https://image.tmdb.org/") and primary.endswith((".jpg", ".png", ".webp"))):
                self._loadThumb(s, primary, size, fallback_url=fb, retry=retries - 1, kind=kind, fallback_kind=fallback_kind)
            elif fb and fb != primary:
                self._loadThumb(s, fb, size, fallback_url="", retry=0, kind=fallback_kind, fallback_kind=fallback_kind)
            else:
                # A missing series poster/backdrop needs a verified TMDb art
                # fallback too, independent from episode-specific stills.
                try:
                    self._ensureSeriesArtworkFallback(force_poster=(primary == self.seriesFallbackPoster))
                except Exception:
                    pass

        request_artwork(url, kind, done, priority=45, errback=failed,
                        source=dict(self.source or {}))

    def _decodeThumb(self, slot, path, size, expected=None, source_url="", episode_still=False):
        loader = ePicLoad()
        self.picloads.append(loader)
        def ready(_info=None, s=slot, l=loader, token=expected):
            try:
                if token is None or getattr(self, "_episode_artwork_requests", {}).get(s) == token:
                    ptr = l.getData()
                    if ptr and self["episode%d" % s].instance:
                        # Do not let a freshly decoded still render smaller than
                        # its placeholder.  The image widget remains 328x184 in
                        # all five slots; this only scales the loaded pixmap to
                        # that existing rectangle (never resizes the card).
                        widget = self["episode%d" % s].instance
                        try:
                            widget.setScale(1)
                        except (AttributeError, TypeError):
                            pass
                        widget.setPixmap(ptr)
                        if episode_still and source_url:
                            self._promoteEpisodeBackdrop(source_url, confirmed_path=path)
            except Exception:
                pass
            finally:
                try:
                    if l in self.picloads:
                        self.picloads.remove(l)
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(size[0], size[1])
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)

    def _moveSelector(self):
        try:
            self["episodeSelector"].instance.move(ePoint(sx(self.EPISODE_X[self.episodeIndex] - 3), sy(690)))
        except Exception:
            pass

    def left(self):
        if self._seriesActorFocus:
            self._seriesActorIndex = max(0, self._seriesActorIndex - 1)
            self._updateSeriesActorFocus()
            return
        idx = self.episodePage + self.episodeIndex
        if idx <= 0:
            return
        if self.episodeIndex > 0:
            self.episodeIndex -= 1
        else:
            self.episodePage = max(0, self.episodePage - 5)
            self.episodeIndex = min(4, len(self.episodeItems) - self.episodePage - 1)
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def right(self):
        if self._seriesActorFocus:
            self._seriesActorIndex = min(len(self._seriesActorPeople) - 1, self._seriesActorIndex + 1)
            self._updateSeriesActorFocus()
            return
        idx = self.episodePage + self.episodeIndex
        if idx + 1 >= len(self.episodeItems):
            return
        if self.episodeIndex < 4 and self.episodeIndex + 1 < len(self.episodeItems) - self.episodePage:
            self.episodeIndex += 1
        else:
            self.episodePage += 5
            self.episodeIndex = 0
            self.renderEpisodes()
        self._moveSelector()
        self.previewEpisode()

    def up(self):
        # Keep UP/DOWN on the season rail while a previous season exists.
        # The old actor-first test stole UP at S02, skipping S01 altogether.
        if self._seriesActorFocus:
            return
        if self.seasonIndex > 0:
            self.seasonIndex -= 1
            self.selectSeason()
            return
        # Actors are a separate row above the very first season only.
        if self._seriesActorPeople:
            self._seriesActorFocus = True
            self._updateSeriesActorFocus()

    def down(self):
        if self._seriesActorFocus:
            self._seriesActorFocus = False
            self._updateSeriesActorFocus()
            return
        if self.seasonIndex + 1 < len(self.seasonItems):
            self.seasonIndex += 1
            self.selectSeason()

    def previewEpisode(self):
        idx = self.episodePage + self.episodeIndex
        ep = self.episodeItems[idx] if 0 <= idx < len(self.episodeItems) else None
        if not ep:
            self["episodeInfo"].setText(tr(""))
            return
        inf = ep.get("info") or {}
        num = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        lang = get_language()
        title = str(ep.get("title") or ep.get("name") or "").strip()
        parent = str(self.seriesItem.get("name") or self.seriesItem.get("title") or "").strip()
        duration = inf.get("duration") or ep.get("duration") or ""
        prefix = ("Episode %s" % num) if lang == "en" else (("Épisode %s" % num) if lang == "fr" else ("الحلقة %s" % num))
        info = prefix
        # Show a genuinely different episode title once, never the repeated series name.
        if title and title.lower() != parent.lower() and title.lower() != prefix.lower() and not title.lower().startswith(parent.lower() + " - "):
            info += "  •  %s" % title[:60]
        if duration:
            info += "  •  %s" % str(duration)[:24]
        # Unified label (Ultra): "Episode N  •  real name  •  45 min".
        try:
            from .episode_labels import apply_meta, preview_line
            tid = str((self.seriesData or {}).get("_tmdb_id") or self.seriesItem.get("tmdb_id") or "").strip()
            if tid:
                s_num, e_num = self._episodeNumbers(ep, idx)
                if s_num and e_num:
                    apply_meta(ep, tid, s_num, e_num)
            info = preview_line(ep, num, parent, lang)
        except Exception:
            pass
        self["episodeInfo"].setText(info)
        # Invalidate HD callbacks from the previously highlighted episode.
        self._episodeHdWanted = None
        tmdb_still = str(ep.get("_tmdb_episode_still") or "").strip()
        episode_art = tmdb_still or self._episodeArtworkUrl(ep, inf)
        if episode_art:
            # The episode image must not cancel an original series backdrop
            # still downloading.  After the original has displayed (or failed),
            # keep normal episode-selection previews from already cached stills.
            can_preview = (not self.seriesBackdrop or
                           getattr(self, "_seriesOriginalBackdropShown", False) or
                           getattr(self, "_seriesBackdropFailed", False) or
                           getattr(self, "_seriesBackdropSource", "") == "episode")
            episode_cached = cached_artwork(episode_art, "backdrops")
            hd_cached = bool(tmdb_still and cached_artwork(self._episodeHdBackdropUrl(tmdb_still), "episode_hd"))
            if can_preview and (episode_cached or hd_cached):
                if not (tmdb_still and self._showEpisodeBackdropHd(tmdb_still)):
                    self.loadBackdrop(episode_art)
            elif not episode_cached and self.seriesBackdrop:
                # No selected episode still is cached yet: retain the series
                # background rather than leaving a black/empty backdrop.
                self.loadBackdrop(self.seriesBackdrop)
        elif self.seriesBackdrop:
            self.loadBackdrop(self.seriesBackdrop)
        else:
            self._queueEpisodeStill(self.episodeIndex, ep, idx)
            self._ensureSeriesArtworkFallback()

    def toggleFavourite(self):
        added, saved = toggle_favourite(self.source, "series", self.seriesItem)
        title = self.seriesItem.get("name") or self.seriesItem.get("title") or "المسلسل"
        if not saved:
            self["keys"].setText(tr("Unable to save favorite"))
        elif added:
            self["keys"].setText("★ تمت إضافة %s إلى المفضلات" % title)
        else:
            self["keys"].setText("☆ تمت إزالة %s من المفضلات" % title)

    def addSeriesFavourite(self):
        if is_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series is already in favorites"))
        elif add_favourite(self.source, "series", self.seriesItem):
            self["keys"].setText(tr("Series added to favorites"))
        else:
            self["keys"].setText(tr("Unable to save favorite"))

    def ok(self):
        if self._seriesActorFocus:
            self._openFocusedSeriesActor()
            return
        idx = self.episodePage + self.episodeIndex
        if not (0 <= idx < len(self.episodeItems)):
            return
        ep = dict(self.episodeItems[idx] or {})
        series_title = self.seriesItem.get("name") or self.seriesItem.get("title") or ""
        episode_info = ep.get("info") or {}
        if not isinstance(episode_info, dict):
            episode_info = {}
        # r425: keep the player poster independent from episode thumbnails.
        # The episode rail keeps its original artwork path; the player receives
        # only the parent-series poster that this details screen already caches.
        player_cover = self._normImage(self.seriesFallbackPoster or "")
        if player_cover:
            ep["_player_cover"] = player_cover
            try:
                # r428: pass the real completed cache file when available.
                # The player can still fetch _player_cover through the existing
                # artwork queue if this page has not finished caching it yet.
                cover_cache = cached_artwork(player_cover, "posters")
                if cover_cache and os.path.exists(cover_cache):
                    ep["_player_cover_cache"] = cover_cache
            except Exception:
                pass
        if self.seriesItem.get("tmdb_id"):
            ep["tmdb_id"] = self.seriesItem.get("tmdb_id")
        if self.seriesFallbackPoster and not ep.get("_player_cover"):
            ep["_player_cover"] = self.seriesFallbackPoster
        ep["_tmdb_title"] = series_title
        ep["_tmdb_kind"] = "series"
        ep["series_name"] = series_title
        ep["series_id"] = self.seriesItem.get("series_id") or self.seriesItem.get("stream_id") or ep.get("series_id") or ""
        try:
            ep["_source_key"] = _source_identity(self.source)
        except Exception:
            ep["_source_key"] = ""
        ep["_source_type"] = self.source.get("type") or ""
        ep["_subdl_type"] = "tv"
        ep["_subdl_title"] = series_title
        ep["_subdl_season"] = self.seasonItems[self.seasonIndex].get("_num", "") if self.seasonItems else ""
        ep["_subdl_episode"] = ep.get("episode_num") or ep.get("episode_number") or (idx + 1)
        # Give every subtitle provider the same explicit TV identity.  Several
        # provider seekers read the standard season/episode fields rather than
        # TiviMate's _subdl_* aliases.
        if ep.get("_subdl_season") not in (None, ""):
            ep["season"] = ep.get("_subdl_season")
            ep["season_number"] = ep.get("_subdl_season")
        if ep.get("_subdl_episode") not in (None, ""):
            ep["episode_num"] = ep.get("_subdl_episode")
            ep["episode_number"] = ep.get("_subdl_episode")
        ep["_episode_items"] = list(self.episodeItems or [])
        ep["_episode_index"] = int(idx)
        ep["_episode_source"] = dict(self.source or {})
        if (self.seriesItem or {}).get("_favorite_exit_stop"):
            ep["_favorite_exit_stop"] = True
        if self.source.get("type") == "stalker":
            # Stalker login + create_link can take seconds: never on the GUI
            # thread (the whole receiver used to freeze on OK).
            if getattr(self, "_episodeResolving", False):
                return
            self._episodeResolving = True
            source = dict(self.source or {})
            try:
                self["keys"].setText(tr("Loading..."))
            except Exception:
                pass

            def done(url, ep=ep):
                self._episodeResolving = False
                self._playEpisodeUrl(ep, url)

            def failed(exc):
                self._episodeResolving = False
                self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)
            from .bg_resolve import resolve_async
            resolve_async(lambda: StalkerClient(source).stream_url(ep, "series"), done, failed)
            return
        try:
            url = XtreamClient(self.source).episode_url(ep)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)
            return
        self._playEpisodeUrl(ep, url)

    def _playEpisodeUrl(self, ep, url):
        try:
            self["keys"].setText(tr("LEFT/RIGHT Episodes    UP/DOWN Change Season    OK Play    RED Favorite    EXIT Back"))
        except Exception:
            pass
        try:
            if not url:
                raise ValueError("Episode URL unavailable")
            service_type = int(_media_service_type(self.source, "series"))
            service = eServiceReference(service_type, 0, url)
            service.setName(ep.get("title") or ep.get("name") or "حلقة")
            ep["_kind"] = "episode"
            self.session.open(TiviMatePlayer, service, ep)
        except Exception as exc:
            self.session.open(MessageBox, "تعذر تشغيل الحلقة\n%s" % exc, MessageBox.TYPE_ERROR)

    def _genreSeriesMissing(self, media, failed_url=''):
        if media not in ('backdrop', 'logo'):
            return
        attempts = getattr(self, '_genreSeriesAttempts', None)
        if attempts is None:
            attempts = set()
            self._genreSeriesAttempts = attempts
        key = (media, str(failed_url or ''))
        if key in attempts:
            return
        attempts.add(key)
        # Live details are a fixed series identity; callbacks can be dismissed
        # by the screen's Enigma2 lifecycle, never moved to another title.
        expected = self._series_backdrop_request if media == 'backdrop' else self._seriesTitleLogoToken
        def valid():
            if media == 'backdrop':
                return (not getattr(self, '_seriesOriginalBackdropShown', False)
                        and getattr(self, '_series_backdrop_request', '') == expected)
            return getattr(self, '_seriesTitleLogoToken', '') == expected
        def ready(path):
            if not valid() or not path or not os.path.isfile(path):
                return
            if media == 'backdrop':
                from .content_home import _cinematic_is_landscape_image
                if not _cinematic_is_landscape_image(path):
                    return
                self._seriesBackdropSource = 'genre'
                self.seriesBackdrop = 'genre-hero|' + path
                self._series_backdrop_request = self.seriesBackdrop
                self.decodeBackdrop(path)
            else:
                self._showSeriesTitleLogo(path, expected)
        def failed(_path):
            return
        try:
            from .hero_shared import recover
            def dispatch(fn, *args):
                if reactor:
                    reactor.callFromThread(fn, *args)
            recover(dict(self.source or {}), dict(self.seriesItem or {}), 'series',
                    media, ready, failed, dispatch,
                    excluded=(failed_url,) if failed_url else (),
                    canvas=(690,110), cancelled=lambda: not valid())
        except Exception:
            attempts.discard(key)

    def loadBackdrop(self, url):
        url = self._normImage(url)
        if not url:
            return
        self._series_backdrop_request = url

        def done(path, expected=url):
            if (getattr(self, "_seriesClosed", False) or
                    getattr(self, "_series_backdrop_request", "") != expected):
                return
            self.decodeBackdrop(path)

        def failed(_path, expected=url):
            if (getattr(self, "_seriesClosed", False) or
                    getattr(self, "_series_backdrop_request", "") != expected):
                return
            retries = getattr(self, "_series_backdrop_retries", {})
            count = retries.get(expected, 0)
            if count < 1:
                retries[expected] = count + 1
                self._series_backdrop_retries = retries
                def retry_failed(_p, exp=expected):
                    if getattr(self, "_series_backdrop_request", "") != exp:
                        return
                    if getattr(self, "_seriesBackdropSource", "") != "episode":
                        self._seriesBackdropFailed = True
                        self._seriesBadBackdropUrls.add(exp)
                        self._genreSeriesMissing('backdrop', expected)
                        self._inheritBackdropFromEpisodes()
                    try:
                        self._ensureSeriesArtworkFallback(force_backdrop=True)
                    except Exception:
                        pass
                request_artwork(expected, "episode_hd" if "image.tmdb.org/t/p/w1280/" in expected else "backdrops", done, priority=115, errback=retry_failed,
                                source=dict(self.source or {}))
            else:
                if getattr(self, "_seriesBackdropSource", "") != "episode":
                    self._seriesBackdropFailed = True
                    self._seriesBadBackdropUrls.add(expected)
                    self._genreSeriesMissing('backdrop', expected)
                    self._inheritBackdropFromEpisodes()
                try:
                    self._ensureSeriesArtworkFallback(force_backdrop=True)
                except Exception:
                    pass

        # The full-screen episode still must not reuse the canonical w780
        # backdrop cache.  Keep its w1280 download isolated to this screen.
        artwork_kind = "episode_hd" if "image.tmdb.org/t/p/w1280/" in url else "backdrops"
        try:
            from .genre_ultra_artwork import request as genre_ultra_request
            genre_ultra_request(url, artwork_kind, dict(self.source or {}),
                                done, failed, lambda fn,*args: reactor.callFromThread(fn,*args) if reactor else None)
        except Exception:
            request_artwork(url, artwork_kind, done, priority=115, errback=failed,
                            source=dict(self.source or {}))

    def decodeBackdrop(self, path):
        source_url = str(getattr(self, "_series_backdrop_request", "") or "")
        loader = ePicLoad()
        if not isinstance(getattr(self, "backdropLoaders", None), list):
            self.backdropLoaders = []
        self.backdropLoaders.append(loader)
        self.backdropLoader = loader
        def ready(_info=None, l=loader):
            try:
                ptr = l.getData()
                # Only the newest completed request may replace the visible backdrop.
                # Older decodes are retained safely until completion, then discarded.
                if (self.backdropLoader is l and ptr and self["backdrop"].instance
                        and self._series_backdrop_request == source_url):
                    self["backdrop"].instance.setPixmap(ptr)
                    if getattr(self, "_seriesBackdropSource", "") != "episode" and source_url == self.seriesBackdrop:
                        self._seriesOriginalBackdropShown = True
                        self._seriesBackdropFailed = False
                elif (self.backdropLoader is l and not ptr and
                      self._series_backdrop_request == source_url and
                      self.seriesBackdrop == source_url and
                      getattr(self, "_seriesBackdropSource", "") != "episode"):
                    # HTTP succeeded but decoder rejected the image; treat this
                    # as a real backdrop failure so episode stills can fill it.
                    self._seriesBackdropFailed = True
                    self._seriesBadBackdropUrls.add(source_url)
                    self._inheritBackdropFromEpisodes()
            except Exception:
                pass
            finally:
                try:
                    if l in self.backdropLoaders:
                        self.backdropLoaders.remove(l)
                    if self.backdropLoader is l:
                        self.backdropLoader = None
                except Exception:
                    pass
        connect_picture_data(loader, ready, self)
        render_width, render_height = scale_size(1920, 1080)
        loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000"))
        loader.startDecode(path)


def _is_bein_sports_channel(item):
    """Return True for channels that clearly identify as beIN SPORTS.

    This is a local filter only. It never creates or resolves stream URLs.
    """
    item = item or {}
    parts = []
    for key in ("name", "title", "stream_display_name", "channel_name", "tvg_name", "epg_channel_name"):
        value = item.get(key)
        if value not in (None, ""):
            try:
                parts.append(str(value))
            except Exception:
                pass
    text = " ".join(parts).lower().replace("_", " ").replace("-", " ")
    compact = " ".join(text.split())
    return (
        "bein sports" in compact or "bein sport" in compact or
        "be in sports" in compact or "be in sport" in compact or
        u"بي ان سبورت" in compact or u"بي إن سبورت" in compact or u"بين سبورت" in compact
    )



RECENT_MEDIA_CACHE_FILE = data_path("recent_media_cache.json")
# Recent is a moving feed. Keep the last good snapshot on screen for as long
# as necessary, but schedule a refresh after ten minutes when the browser is
# visited again. This TTL never deletes the saved posters.
RECENT_MEDIA_CACHE_TTL = 600
_RECENT_MEDIA_FILE_LOCK = threading.RLock()
_RECENT_MEDIA_WARM_LOCK = threading.Lock()
_RECENT_MEDIA_WARMING = set()
_RECENT_MEDIA_WARM_ATTEMPTS = {}

def _recent_media_cache_key(source, kind):
    # v3 invalidates the former first-12-packages snapshot, which did not
    # actually represent the most recently added titles.  Package selections
    # belong in the key so changing the filter never reuses an old feed.
    try:
        selected = get_allowed_category_ids(source, kind)
        scope = "ALL" if selected is None else ",".join(sorted(str(x) for x in selected))
        # A changed Xtream password or M3U file must not inherit the old
        # account's recent feed. The complete string is SHA1-hashed below.
        account = str((source or {}).get("password") or "")
        playlist = str((source or {}).get("path") or "")
        raw = ("recent-feed-v3|" + _source_identity(source) + "|" +
               account + "|" + playlist + "|" + str(kind or "") +
               "|" + scope).encode("utf-8", "ignore")
    except Exception:
        raw = ("recent-feed-v3|" + str(source) + "|" +
               str(kind or "")).encode("utf-8", "ignore")
    return hashlib.sha1(raw).hexdigest()

def _recent_media_cache_state(source, kind):
    """Previously verified result can be displayed stale while refresh runs.

    TTL controls background refresh, not whether a user sees a blank screen.
    Source, account, kind and enabled-package filters remain in the v3 key.
    """
    try:
        with _RECENT_MEDIA_FILE_LOCK:
            data = load_json(RECENT_MEDIA_CACHE_FILE, {}) or {}
        row = data.get(_recent_media_cache_key(source, kind)) or {}
        saved = int(row.get("saved") or 0)
        if not saved:
            return [], False
        items = [dict(x) for x in (row.get("items") or []) if isinstance(x, dict)]
        age = max(0, int(time.time()) - saved)
        return items, age <= RECENT_MEDIA_CACHE_TTL
    except Exception:
        return [], False


def _load_recent_media_cache(source, kind):
    return _recent_media_cache_state(source, kind)[0]

def _save_recent_media_cache(source, kind, items):
    # Do not overwrite a verified snapshot with an empty/error response. In
    # particular, parallel Movies and Series refreshes must not clobber one
    # another's read-modify-write of the shared JSON file.
    rows = [dict(x) for x in (items or [])[:200] if isinstance(x, dict)]
    if not rows:
        return
    try:
        with _RECENT_MEDIA_FILE_LOCK:
            data = load_json(RECENT_MEDIA_CACHE_FILE, {}) or {}
            if not isinstance(data, dict):
                data = {}
            data[_recent_media_cache_key(source, kind)] = {
                "saved": int(time.time()), "items": rows,
            }
            save_json(RECENT_MEDIA_CACHE_FILE, data)
    except Exception:
        pass


def _warm_recent_media_cache(source, kind, category_ids=None):
    """Warm *one* Recent feed in a daemon while the package browser is open.

    A cache miss on first Recent entry used to show 0 until the entire portal
    catalogue completed. Begin that same shared fetch opportunistically after
    package text is painted. No GUI calls, no extra image download workers,
    no per-package prefetch queue changes, and no second scan while in flight.
    Last-good rows remain visible even if this attempt fails.
    """
    if kind not in ("vod", "series") or not isinstance(source, dict):
        return False
    rows, fresh = _recent_media_cache_state(source, kind)
    if rows and fresh:
        return False
    key = _recent_media_cache_key(source, kind)
    now = time.monotonic()
    with _RECENT_MEDIA_WARM_LOCK:
        if (key in _RECENT_MEDIA_WARMING or
                now - _RECENT_MEDIA_WARM_ATTEMPTS.get(key, -1e10) < 90):
            return False
        _RECENT_MEDIA_WARMING.add(key)
        _RECENT_MEDIA_WARM_ATTEMPTS[key] = now
    saved_source = dict(source)
    known_ids = list(dict.fromkeys(str(cid) for cid in (category_ids or [])
                                   if str(cid) and not str(cid).startswith("__")))

    def worker():
        try:
            from .filters import get_allowed_category_ids, get_cached_categories
            from .core import get_source_client
            from .recent_feed import recent_added_items
            client = get_source_client(saved_source)
            allowed = get_allowed_category_ids(saved_source, kind)
            if known_ids:
                categories = [{"category_id": cid} for cid in known_ids]
            else:
                categories, _origin = get_cached_categories(
                    saved_source, kind, client=client, wait_for_server=True)
            categories = [row for row in (categories or [])
                          if isinstance(row, dict) and
                          str(row.get("category_id") or "").strip() and
                          not str(row.get("category_id")).startswith("__") and
                          (allowed is None or str(row.get("category_id")) in allowed)]
            if not categories:
                return
            items = recent_added_items(saved_source, kind, client, categories, 200)
            if items:
                _save_recent_media_cache(saved_source, kind, items)
        except Exception:
            # Provider may be offline or return a temporarily incomplete list.
            # Never replace verified cache on any failed background refresh.
            pass
        finally:
            with _RECENT_MEDIA_WARM_LOCK:
                _RECENT_MEDIA_WARMING.discard(key)
    thread = threading.Thread(target=worker, name="TiviMateRecentWarm")
    thread.daemon = True
    thread.start()
    return True
