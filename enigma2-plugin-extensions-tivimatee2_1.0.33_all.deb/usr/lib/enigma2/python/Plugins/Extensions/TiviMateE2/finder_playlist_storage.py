# -*- coding: utf-8 -*-
"""Finder-generated M3U catalog storage; do not pollute Enigma2's config root.

Only internal Finder filenames are eligible for legacy migration. Never touch an
arbitrary user-selected M3U path or an Enigma2 bouquet. The originals are kept
until migration is confirmed and the receiver owner explicitly cleans them.
"""
from __future__ import absolute_import

import os
import re
import shutil

from .storage import data_path

_LEGACY_FOLDER = "/etc/enigma2"
_INTERNAL_M3U = re.compile(
    r"^tivimatee2_(?:(?:xumo|freetv|localnow|lgchannels|roku|tubitv|"
    r"vizio|tclplus|freelivesports)_[a-z0-9_-]+|"
    r"(?:samsung|xiaomi)_[a-z0-9_-]+|"
    r"iptvorg_arabic_[a-z0-9_-]+)\.m3u$"
)


def _is_finder_name(filename):
    return bool(_INTERNAL_M3U.match(str(filename or "")))


def _valid_file(path):
    try:
        if not os.path.isfile(path) or os.path.getsize(path) <= 64:
            return False
        with open(path, "rb") as handle:
            head = handle.read(4096)
        return head.lstrip().startswith(b"#EXTM3U") and b"#EXTINF" in head
    except Exception:
        return False


def _verified_copy(source, dest):
    """Do not clobber a newer/valid playlist; copy atomically and check size."""
    if not _valid_file(source):
        return False
    try:
        if _valid_file(dest):
            return True
        parent = os.path.dirname(dest)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        tmp = dest + ".migrating"
        try:
            shutil.copy2(source, tmp)
            if (os.path.getsize(source) != os.path.getsize(tmp) or
                    not _valid_file(tmp)):
                return False
            os.rename(tmp, dest)
        finally:
            if os.path.isfile(tmp):
                os.unlink(tmp)
        return _valid_file(dest)
    except Exception:
        return False


def finder_playlist_path(filename):
    """Location for internal FAST/Samsung/Xiaomi/IPTV-ORG playlists.

    Uses the existing HDD-first storage policy with the plugin's /var/tmp
    fallback when no real mounted storage is available. The return value is
    always the same local file path consumed by the existing M3U player.
    """
    filename = str(filename or "")
    if not _is_finder_name(filename):
        raise ValueError("Not an internal Server Finder playlist filename")
    new_path = data_path("server_finder", filename)
    old_path = os.path.join(_LEGACY_FOLDER, filename)
    if not _valid_file(new_path):
        if _verified_copy(old_path, new_path):
            # LG aggregation refresh marker travels with its playlist.
            if os.path.isfile(old_path + ".regions-v2"):
                try:
                    shutil.copy2(old_path + ".regions-v2", new_path + ".regions-v2")
                except Exception:
                    pass
    return new_path


def migrate_finder_sources(sources):
    """Move references only after a usable copy exists at the new location.

    Originals are intentionally not removed: third-party bouquets/scripts
    might refer to their old absolute paths. No blind /etc cleanup on launch.
    """
    updated = []
    for item in sources or []:
        if not isinstance(item, dict) or str(item.get("type") or "").lower() != "m3u":
            updated.append(item)
            continue
        source = dict(item)
        paths = (str(source.get("url") or ""), str(source.get("path") or ""))
        # Handle the historical /etc location and older Finder cache roots if
        # a HDD/USB is inserted or removed between sessions. Only known Finder
        # filenames under these two directory structures are eligible.
        old = next((p for p in paths if _is_finder_name(os.path.basename(p)) and
                    (os.path.dirname(p) == _LEGACY_FOLDER or
                     "/server_finder/" in p and p.endswith(
                         "/server_finder/" + os.path.basename(p)))), "")
        if old:
            try:
                new = finder_playlist_path(os.path.basename(old))
                if old != new and not _valid_file(new):
                    _verified_copy(old, new)
                if _valid_file(new):
                    for key in ("url", "path"):
                        if str(source.get(key) or "") == old:
                            source[key] = new
            except Exception:
                pass
        updated.append(source)
    return updated


def finder_identity_url(url):
    """Keep existing favourites, source selection, filters and cache IDs stable.

    A Finder playlist was historically stored at /etc/enigma2/<name>.
    Its physical location moved, but its persistent source identity must not.
    Do not rewrite other M3U endpoints or user-managed files.
    """
    url = str(url or "")
    name = os.path.basename(url)
    if _is_finder_name(name) and (
            url == os.path.join(_LEGACY_FOLDER, name) or
            url.endswith("/server_finder/" + name)):
        return os.path.join(_LEGACY_FOLDER, name)
    return url
