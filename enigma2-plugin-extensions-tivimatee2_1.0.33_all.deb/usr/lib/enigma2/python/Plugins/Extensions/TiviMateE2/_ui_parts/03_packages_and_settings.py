from .movies_layout_choice import configured_movies_screen
# Latest is ORDER METADATA, not artwork. Keep its very small per-server index
# on receiver's persistent /etc storage regardless of the TMP/HDD image setting.
# Other GENRE files (package images, metadata, etc.) still follow get_cache_root().
_GENRE_LATEST_INDEX_FILE = "/etc/enigma2/tivimatee2_genre_latest_order.json"
_GENRE_LATEST_INDEX_LOCK = threading.RLock()
_GENRE_LATEST_INDEX_CHECKED = False


def _genre_cache_file(filename):
    """Return GENRE file path; Latest ordering survives TMP resets and mode changes."""
    global _GENRE_LATEST_INDEX_CHECKED
    name = str(filename or "").strip()
    if name == "latest_order.json":
        target = _GENRE_LATEST_INDEX_FILE
        if not _GENRE_LATEST_INDEX_CHECKED:
            with _GENRE_LATEST_INDEX_LOCK:
                if not _GENRE_LATEST_INDEX_CHECKED:
                    # Migrate existing per-server timestamps from previous
                    # HDD/USB/TMP/flash cache roots. Never copy image content.
                    # On subsequent starts, old roots have older mtimes than
                    # the canonical index and will not replace its values.
                    old_files = [
                        "/media/hdd/.tivimatee2-cache/genre/latest_order.json",
                        "/media/usb/.tivimatee2-cache/genre/latest_order.json",
                        "/media/usb1/.tivimatee2-cache/genre/latest_order.json",
                        "/media/usb2/.tivimatee2-cache/genre/latest_order.json",
                        "/media/mmc/.tivimatee2-cache/genre/latest_order.json",
                        "/var/tmp/tivimatee2-cache/genre/latest_order.json",
                        "/tmp/tivimatee2-cache/genre/latest_order.json",
                        "/tmp/.tivimatee2-cache/genre/latest_order.json",
                    ]
                    try:
                        current_mtime = os.path.getmtime(target) if os.path.isfile(target) else -1
                        merged = {}
                        if os.path.isfile(target):
                            with open(target, "r") as handle:
                                data = json.load(handle) or {}
                            if isinstance(data, dict):
                                merged = data
                        changed = False
                        for source_file in old_files:
                            try:
                                if not os.path.isfile(source_file) or os.path.getmtime(source_file) <= current_mtime:
                                    continue
                                with open(source_file, "r") as handle:
                                    source_data = json.load(handle) or {}
                                if not isinstance(source_data, dict):
                                    continue
                                for scope, values in source_data.items():
                                    if not isinstance(values, dict):
                                        continue
                                    latest = merged.get(scope)
                                    if not isinstance(latest, dict):
                                        latest = {}
                                        merged[scope] = latest
                                    for category_id, timestamp in values.items():
                                        try:
                                            timestamp = max(0, int(timestamp or 0))
                                            previous = max(0, int(latest.get(category_id) or 0))
                                        except (TypeError, ValueError, OverflowError):
                                            continue
                                        if category_id not in latest or timestamp > previous:
                                            latest[category_id] = timestamp
                                            changed = True
                            except Exception:
                                continue
                        if changed and merged:
                            folder = os.path.dirname(target)
                            if not os.path.isdir(folder):
                                os.makedirs(folder)
                            temp = target + ".tmp"
                            with open_text(temp, "w", encoding="utf-8") as handle:
                                json.dump(merged, handle, ensure_ascii=False, separators=(",", ":"))
                            atomic_replace(temp, target)
                    except Exception:
                        pass  # A failing migration must never prevent GENRE opening.
                    _GENRE_LATEST_INDEX_CHECKED = True
        return target
    root = get_cache_root()
    folder = os.path.join(root, "genre")
    try:
        if not os.path.isdir(folder):
            os.makedirs(folder)
    except Exception:
        pass
    target = os.path.join(folder, name)
    legacy = os.path.join("/etc/enigma2", "tivimatee2_genre_" + name)
    try:
        if name and os.path.isfile(legacy) and not os.path.exists(target):
            import shutil
            shutil.copy2(legacy, target)
    except Exception:
        pass
    return target

def _content_package_control_key(source, kind):
    return "%s|%s" % (_source_identity(source or {}), str(kind or "vod"))

def _load_content_package_controls(source, kind):
    data = load_json(CONTENT_PACKAGE_CONTROLS_FILE, {}) or {}
    row = data.get(_content_package_control_key(source, kind)) or {}
    return {
        "pin": str(row.get("pin") or "0000"),
        "locked": set(str(x) for x in (row.get("locked") or [])),
        "order": [str(x) for x in (row.get("order") or []) if str(x)],
        "sort": str(row.get("sort") or "latest"),
    }

def _save_content_package_controls(source, kind, state):
    data = load_json(CONTENT_PACKAGE_CONTROLS_FILE, {}) or {}
    data[_content_package_control_key(source, kind)] = {
        "pin": str((state or {}).get("pin") or "0000"),
        "locked": sorted(set(str(x) for x in ((state or {}).get("locked") or []))),
        "order": [str(x) for x in ((state or {}).get("order") or []) if str(x)],
        "sort": str((state or {}).get("sort") or "latest"),
    }
    return save_json(CONTENT_PACKAGE_CONTROLS_FILE, data)



PACKAGE_ORDER_SKIN = r"""<screen name="PackageOrderScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#02060B">
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_cinematic_bg_r209.jpg" alphatest="blend" zPosition="0"/>
<eLabel position="0,0" size="1920,128" backgroundColor="#050A10" zPosition="1"/>
<eLabel position="48,126" size="1824,2" backgroundColor="#153653" zPosition="2"/>
<ePixmap position="64,26" size="306,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="4"/>
<widget name="title" position="430,25" size="1000,52" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" zPosition="4"/>
<eLabel position="432,78" size="900,30" text="Choose package order" font="Regular;22" foregroundColor="#8EA7BA" transparent="1" zPosition="4"/>
<widget name="card0" position="260,250" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name0" position="330,300" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="card1" position="1010,250" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name1" position="1080,300" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="card2" position="260,510" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name2" position="330,560" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="card3" position="1010,510" size="650,180" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_card_r208.png" alphatest="blend" zPosition="2"/>
<widget name="name3" position="1080,560" size="500,70" font="Regular;34" foregroundColor="#F7FAFD" transparent="1" valign="center" zPosition="4"/>
<widget name="focus" position="254,244" size="662,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_filter_focus_r208.png" alphatest="blend" zPosition="7"/>
<widget name="hint" position="250,800" size="1420,45" font="Regular;24" foregroundColor="#B9D7EA" transparent="1" halign="center" zPosition="4"/>
<eLabel position="58,930" size="1804,2" backgroundColor="#17324B" zPosition="2"/>
<eLabel position="650,970" size="18,18" backgroundColor="#15964C" zPosition="4"/><eLabel position="680,958" size="250,42" text="OK  Apply" font="Regular;22" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
<eLabel position="1010,970" size="18,18" backgroundColor="#B83232" zPosition="4"/><eLabel position="1040,958" size="300,42" text="EXIT  Back" font="Regular;22" foregroundColor="#D5DEE5" transparent="1" zPosition="4"/>
</screen>"""

class PackageOrderScreen(Screen):
    MODES = (("original","Original"),("latest","Latest"),("az","A to Z"),("za","Z to A"))
    POS = ((254,244),(1004,244),(254,504),(1004,504))
    def __init__(self, session, current="original", kind="vod"):
        self.skin=PACKAGE_ORDER_SKIN
        from .font_preferences import read_preferences, scale_skin_text
        self.skin = scale_skin_text(self.skin, read_preferences()["font_scale"])
        Screen.__init__(self,session)
        self.current=current if current in dict(self.MODES) else "original"
        self.index=next((i for i,x in enumerate(self.MODES) if x[0]==self.current),0)
        self["title"]=Label("PACKAGE ORDER  •  %s" % ("TV SHOWS" if kind=="series" else "MOVIES"))
        self["hint"]=Label("Select how the packages themselves are ordered")
        self["focus"]=Pixmap()
        for i,(mode,label) in enumerate(self.MODES):
            self["card%d"%i]=Pixmap(); self["name%d"%i]=Label(("●  " if mode==self.current else "○  ")+label)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.apply,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down},-1)
        self.onLayoutFinish.append(self.render)
    def render(self):
        for i,(mode,label) in enumerate(self.MODES): self["name%d"%i].setText(("●  " if mode==self.current else "○  ")+label)
        try:
            x,y=self.POS[self.index]; self["focus"].instance.move(ePoint(sx(x),sy(y)))
        except Exception: pass
    def left(self): self.index=max(0,self.index-1); self.render()
    def right(self): self.index=min(3,self.index+1); self.render()
    def up(self): self.index=max(0,self.index-2); self.render()
    def down(self): self.index=min(3,self.index+2); self.render()
    def apply(self):
        self.current=self.MODES[self.index][0]; self.close(self.current)

# ---------------------------------------------------------------------------
# Movie Genres - standalone page (not part of Movies Packages)
# ---------------------------------------------------------------------------

MOVIE_GENRES_SKIN = r"""<screen name="MovieGenresScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050608">
<ePixmap position="0,-8" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_background.jpg" alphatest="blend" scale="1" zPosition="0"/>
<widget name="title" position="65,25" size="1200,50" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
<widget name="page" position="1525,30" size="330,40" font="Regular;22" foregroundColor="#CFCFCF" transparent="1" halign="right" zPosition="5"/>
<widget name="card0" position="250,181" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label0" position="247,338" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell0" position="247,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge0" position="259,338" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge0" position="472,338" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card1" position="615,181" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label1" position="612,338" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell1" position="612,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge1" position="624,338" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge1" position="837,338" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card2" position="980,181" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label2" position="977,338" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell2" position="977,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge2" position="989,338" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge2" position="1202,338" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card3" position="1345,181" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label3" position="1342,338" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell3" position="1342,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge3" position="1354,338" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge3" position="1567,338" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card4" position="250,451" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label4" position="247,608" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell4" position="247,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge4" position="259,608" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge4" position="472,608" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card5" position="615,451" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label5" position="612,608" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell5" position="612,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge5" position="624,608" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge5" position="837,608" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card6" position="980,451" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label6" position="977,608" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell6" position="977,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge6" position="989,608" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge6" position="1202,608" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card7" position="1345,451" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label7" position="1342,608" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell7" position="1342,448" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge7" position="1354,608" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge7" position="1567,608" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card8" position="250,721" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label8" position="247,878" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell8" position="247,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge8" position="259,878" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge8" position="472,878" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card9" position="615,721" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label9" position="612,878" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell9" position="612,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge9" position="624,878" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge9" position="837,878" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card10" position="980,721" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label10" position="977,878" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell10" position="977,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge10" position="989,878" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge10" position="1202,878" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="card11" position="1345,721" size="324,161" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg" alphatest="blend" scale="1" zPosition="3"/>
<widget name="label11" position="1342,878" size="330,34" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" transparent="1" zPosition="7"/>
<widget name="shell11" position="1342,718" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_shell_silver_330x198.png" alphatest="blend" zPosition="5"/>
<widget name="badge11" position="1354,878" size="306,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="yearBadge11" position="1567,878" size="94,34" alphatest="blend" scale="1" zPosition="7"/>
<widget name="selector" position="247,178" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_package_focus_silver.png" alphatest="blend" zPosition="8" scale="1"/>
<eLabel position="540,1010" size="18,18" backgroundColor="#C62828" zPosition="12"/><widget name="redHint" position="568,998" size="160,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
<eLabel position="750,1010" size="18,18" backgroundColor="#15964C" zPosition="12"/><widget name="greenHint" position="778,998" size="180,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
<eLabel position="980,1010" size="18,18" backgroundColor="#D8B323" zPosition="12"/><widget name="yellowHint" position="1008,986" size="315,60" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
<eLabel position="1360,1010" size="18,18" backgroundColor="#2878D8" zPosition="12"/><widget name="blueHint" position="1388,998" size="170,38" font="Regular;21" foregroundColor="#FFFFFF" transparent="1" zPosition="12"/>
</screen>"""

# A single, bounded pool for GENRE package art. The old implementation spawned
# 12 unbounded network/TMDb threads per visible page; rapid page changes kept
# spawning more workers against the same receiver/flash.
from concurrent.futures import ThreadPoolExecutor
from itertools import islice
_GENRE_BACKDROP_POOL = ThreadPoolExecutor(max_workers=2, thread_name_prefix="TiviGenreBackdrop")
_GENRE_BACKDROP_INDEX_LOCK = threading.RLock()

class MovieGenresScreen(Screen):
    PAGE_SIZE = 12
    EXCLUDE_WORDS = (
        "sport","sports","football","soccer","wwe","wrestling","ufc","mma","boxing","basketball","tennis",
        "formula 1","formula1","f1","racing","race","music","musical","songs","song","radio","concert",
        "theatre","theater","stage play","plays","مسرح","مسرحيات","اغاني","أغاني","موسيقى","رياضة","رياضي",
        "كرة قدم","مصارعة","ملاكمة"
    )
    def __init__(self, session, source, initial_kind="vod", initial_index=None, auto_choose=False):
        self.skin=MOVIE_GENRES_SKIN
        from .font_preferences import read_preferences, scale_skin_text
        self.skin = scale_skin_text(self.skin, read_preferences()["font_scale"])
        Screen.__init__(self,session)
        self.source=dict(source or {})
        self.kind="series" if str(initial_kind)=="series" else "vod"
        # Restore the last Genre server for this media kind before the first render.
        # This prevents opening on one server and jumping to the saved server later.
        try:
            _genre_server_file="/etc/enigma2/tivimatee2_genre_server.json"
            _genre_server_data=load_json(_genre_server_file,{}) or {}
            _saved_server_key=str(_genre_server_data.get(self.kind) or "")
            if _saved_server_key:
                for _candidate in list(get_sources() or []):
                    if isinstance(_candidate,dict) and _source_identity(_candidate)==_saved_server_key:
                        _stype=str(_candidate.get("type") or "").lower()
                        if _stype in ("xtream","stalker","m3u") and not (_stype=="m3u" and not _m3u_source_has_kind(_candidate,self.kind)):
                            self.source=dict(_candidate); break
        except Exception:
            pass
        self.rows=[]; self.index=0; self.pageStart=0; self._token=0
        self._genreImageSavePending=set()
        self._genreBackdropJobs=[]
        self._genreClosed=False
        self._genreBackdropMisses={}
        self._genreBackdropRecoveryCount={}
        self._genreBackdropResolver=None
        self._renderedGenrePage=None
        self.onClose.append(self._stopGenreBackdropJobs)
        # Persistent package -> backdrop mapping.  This is separate from the
        # downloaded image cache: reopening GENRE can resolve the package art
        # immediately without scanning package contents again.
        self._packageBackdropFile=_genre_cache_file("package_backdrops.json")
        self._packageBackdropCache={}
        try:
            _all_backdrops=load_json(self._packageBackdropFile,{}) or {}
            _backdrop_scope=_content_package_control_key(self.source,self.kind)
            _scope_cache=_all_backdrops.get(_backdrop_scope,{})
            if isinstance(_scope_cache,dict): self._packageBackdropCache=_scope_cache
        except Exception:
            self._packageBackdropCache={}
        # Persist Genre package ordering per server and media kind.
        # Movies and TV Shows intentionally keep independent selections.
        self.sortMode="original"
        self._latestOrderCache={}
        try:
            _genre_order_file="/etc/enigma2/tivimatee2_genre_package_order.json"
            _genre_order_data=load_json(_genre_order_file,{}) or {}
            _genre_order_key=_content_package_control_key(self.source,self.kind)
            _saved_mode=str(_genre_order_data.get(_genre_order_key) or "latest")
            if _saved_mode in ("original","latest","az","za"):
                self.sortMode=_saved_mode
            # Keep the last resolved Latest timestamps so reopening Genre never
            # flashes provider/Original order while background refresh runs.
            _latest_file=_genre_cache_file("latest_order.json")
            _latest_data=load_json(_latest_file,{}) or {}
            _cached=_latest_data.get(_genre_order_key,{})
            if isinstance(_cached,dict): self._latestOrderCache=_cached
        except Exception:
            pass
        self["title"]=Label("TV SHOWS PACKAGES" if self.kind=="series" else "MOVIES PACKAGES")
        self["page"]=Label("")
        self["redHint"]=Label("Delete Package")
        self["greenHint"]=Label("Package Filter")
        self["yellowHint"]=Label("SORT\nLATEST  •  HOLD FAV")
        self["blueHint"]=Label("Switch Server")
        self["selector"]=Pixmap()
        for i in range(self.PAGE_SIZE):
            self["card%d"%i]=Pixmap(); self["label%d"%i]=Label(""); self["shell%d"%i]=Pixmap(); self["badge%d"%i]=Pixmap(); self["yearBadge%d"%i]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "ok":self.choose,"cancel":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,
            "pageUp":self.pageUp,"pageDown":self.pageDown,
            "red":self.deleteSelectedPackage,"green":self.openPackageFilter,"yellow":self.openPackageOrder,"yellowlong":self.addSelectedPackageFavourite,"blue":self.serverSwitch},-1)
        self.onLayoutFinish.append(self.start)
    def _stopGenreBackdropJobs(self):
        self._genreClosed=True
        self._cancelGenreBackdropJobs()
        self._genreBackdropResolver=None

    def _cancelGenreBackdropJobs(self):
        # Cancel queued futures; running requests cannot safely be interrupted,
        # so each running worker also checks page/selection before further I/O.
        for future in self._genreBackdropJobs:
            try: future.cancel()
            except Exception: pass
        self._genreBackdropJobs=[]

    def _isRealPackageBackdrop(self, value):
        # The GENRE default/GENERAL artwork is only a visual placeholder.
        # Never treat it as a resolved package backdrop or persist it as one.
        value=str(value or "").strip()
        if not value:
            return False
        low=value.lower().replace("\\", "/")
        base=low.rsplit("/",1)[-1].split("?",1)[0]
        if base in ("genre_default.jpg","genre_default.png","general.jpg","general.png"):
            return False
        return True

    def _recordSavedGenreBackdrop(self, source, kind, cid, url):
        """Index only verified, permanently saved GENRE package artwork."""
        if not url or not self._isRealPackageBackdrop(url):
            return
        try:
            scope=_content_package_control_key(source,kind)
            with _GENRE_BACKDROP_INDEX_LOCK:
                all_backdrops=load_json(self._packageBackdropFile,{}) or {}
                if not isinstance(all_backdrops,dict): all_backdrops={}
                scope_cache=all_backdrops.get(scope,{})
                if not isinstance(scope_cache,dict): scope_cache={}
                if str(scope_cache.get(str(cid)) or "")==str(url): return
                scope_cache[str(cid)]=str(url)
                all_backdrops[scope]=scope_cache
                save_json(self._packageBackdropFile,all_backdrops)
        except Exception:
            pass

    def _saveGenreImageLater(self, source, kind, category_id, path, token, backdrop_url=""):
        """Save an actual picture without blocking the Enigma GUI thread."""
        cid=str(category_id or "").strip()
        if not cid or not path:
            return
        try:
            if saved_genre_image(source, kind, cid):
                return
            key=(_source_identity(source), str(kind), cid)
            if key in self._genreImageSavePending:
                return
            self._genreImageSavePending.add(key)
        except Exception:
            return
        def worker():
            try:
                saved=save_genre_image(source, kind, cid, path)
                # An image may finish after the user changes page. Persist its
                # successful download anyway; token only gates the UI repaint.
                if saved and backdrop_url:
                    self._recordSavedGenreBackdrop(source,kind,cid,backdrop_url)
            except Exception:
                saved=""
            def completed():
                try:
                    self._genreImageSavePending.discard(key)
                    if (not saved or token!=self._token or self.kind!=kind or
                            _source_identity(self.source)!=_source_identity(source)):
                        return
                    for r in self.rows:
                        if str(r.get("id") or "")==cid:
                            r["_genre_image"]=saved
                    # Only repaint the newly completed card. Repainting all 12
                    # pixmaps on every image completion briefly freezes Enigma.
                    for pos in range(self.pageStart, min(len(self.rows), self.pageStart+self.PAGE_SIZE)):
                        if str(self.rows[pos].get("id") or "") != cid:
                            continue
                        slot=pos-self.pageStart
                        try: self["card%d"%slot].instance.setPixmapFromFile(saved)
                        except Exception: pass
                        break
                except Exception:
                    pass
            if reactor:
                try: reactor.callFromThread(completed)
                except Exception: pass
            else:
                # No reactor means do not touch Enigma widgets from worker.
                try: self._genreImageSavePending.discard(key)
                except Exception: pass
        t=threading.Thread(target=worker,name="TiviMateSaveGenreImage")
        t.daemon=True; t.start()

    def _applyPackageOrder(self):
        if self.sortMode=="latest":
            # _latest_key is the newest real title timestamp in the package.
            # Unknown packages stay behind dated packages in original provider order.
            self.rows.sort(key=lambda r:(int(r.get("_latest_key") or 0), -int(r.get("_provider_order") or 0)), reverse=True)
        elif self.sortMode=="az":
            self.rows.sort(key=lambda r:str(r.get("name") or "").casefold())
        elif self.sortMode=="za":
            self.rows.sort(key=lambda r:str(r.get("name") or "").casefold(), reverse=True)
        else:
            self.rows.sort(key=lambda r:r.get("_provider_order",0))
        self._refreshPackageSortHint()

    def _mediaLatestStamp(self, item):
        if not isinstance(item,dict): return 0
        import datetime
        def _stamp(value):
            if value in (None,""): return 0
            try:
                n=int(float(value))
                if n>100000000000: n//=1000
                if n>100000000: return n
            except Exception: pass
            txt=str(value).strip().replace("Z","").replace("T"," ")
            for fmt,size in (("%Y-%m-%d %H:%M:%S",19),("%Y-%m-%d",10),("%Y/%m/%d %H:%M:%S",19),("%Y/%m/%d",10)):
                try: return int(time.mktime(datetime.datetime.strptime(txt[:size],fmt).timetuple()))
                except Exception: pass
            return 0
        for key in ("added","added_timestamp","added_at","date_added","created_at","timestamp"):
            ts=_stamp(item.get(key))
            if ts: return ts
        for key in ("release_date","releaseDate","releasedate","release_date_utc","first_air_date"):
            ts=_stamp(item.get(key))
            if ts: return ts
        try:
            year=int(str(item.get("year") or "")[:4])
            if 1800<=year<=2200: return int(time.mktime(datetime.datetime(year,1,1).timetuple()))
        except Exception: pass
        return 0

    def _refreshLatestPackageOrder(self, token):
        # Resolve the newest actual title in every package. Cache first; only a
        # package with no cached catalogue contacts the server. Never infer age
        # from category_id because providers do not guarantee chronological IDs.
        if self.sortMode!="latest": return
        source=dict(self.source); rows=list(self.rows)
        def worker():
            changed=False
            for idx, row in enumerate(rows):
                if token!=self._token or self.sortMode!="latest": return
                # Large cached catalogues should not monopolise receiver CPU.
                if idx and idx % 8 == 0: time.sleep(0.005)
                try:
                    from .filters import peek_category_streams_cache
                    items,_=peek_category_streams_cache(source,row.get("kind"),row.get("id"))
                    if not items: continue  # Keep persisted Latest while uncached.
                    latest=max([self._mediaLatestStamp(x) for x in list(items)] or [0])
                except Exception: continue
                row["_latest_key"]=latest
                changed=True
            if not changed or token!=self._token or self.sortMode!="latest": return
            # Persist the resolved timestamps before repainting. Next entry can
            # apply Latest immediately, then refresh silently in background.
            try:
                _latest_file=_genre_cache_file("latest_order.json")
                _latest_data=load_json(_latest_file,{}) or {}
                _key=_content_package_control_key(source,self.kind)
                _old_scope=_latest_data.get(_key,{}) or {}
                if not isinstance(_old_scope,dict): _old_scope={}
                _old_scope.update({str(x.get("id")):int(x.get("_latest_key") or 0) for x in rows if x.get("_latest_key") is not None})
                _latest_data[_key]=_old_scope
                save_json(_latest_file,_latest_data)
                self._latestOrderCache=dict(_latest_data[_key])
            except Exception:
                pass
            def done():
                if token!=self._token or self.sortMode!="latest": return
                byid={str(x.get("id")):x for x in rows}
                for current in self.rows:
                    resolved=byid.get(str(current.get("id")))
                    if resolved is not None: current["_latest_key"]=resolved.get("_latest_key",0)
                # Background Latest refresh must not kick the user back to page 1.
                # Keep the currently selected package (or at least its index)
                # while applying the refreshed ordering.
                _old_index=int(self.index or 0)
                _selected_id=""
                try:
                    if self.rows and 0 <= _old_index < len(self.rows):
                        _selected_id=str(self.rows[_old_index].get("id") or "")
                except Exception:
                    _selected_id=""
                self._applyPackageOrder()
                _new_index=min(_old_index,max(0,len(self.rows)-1)) if self.rows else 0
                if _selected_id:
                    try:
                        _new_index=next(i for i,x in enumerate(self.rows) if str(x.get("id") or "")==_selected_id)
                    except Exception:
                        pass
                self.index=_new_index
                self.pageStart=(self.index//self.PAGE_SIZE)*self.PAGE_SIZE if self.rows else 0
                # Latest can reorder page 1 after its first artwork pass. Force the
                # visible page to re-bind its cache immediately after that reorder.
                self._artworkPageKey=None
                self.render()
            try: reactor.callFromThread(done)
            except Exception: done()
        t=threading.Thread(target=worker,name="TiviMateGenreLatestPackages"); t.daemon=True; t.start()

    def addSelectedPackageFavourite(self):
        # Long YELLOW saves the selected Movies/TV Shows package as one
        # Favorites folder. It does not expand the package into title rows.
        if not self.rows or self.index < 0 or self.index >= len(self.rows):
            return
        row = self.rows[self.index] if isinstance(self.rows[self.index], dict) else {}
        cid = str(row.get("id") or "").strip()
        title = str(row.get("name") or "").strip()
        if not cid or not title:
            return
        marker_file = favorites_path("media_package_favorites.json")
        marker_key = "%s|%s|%s" % (favourite_source_id(self.source), self.kind, cid)
        try:
            try:
                with open(marker_file, "r") as h:
                    markers = json.load(h) or {}
            except Exception:
                markers = {}
            if marker_key in markers:
                self.session.open(MessageBox, "Package is already in Favorites", MessageBox.TYPE_INFO, timeout=3)
                return
            back = row.get("backdrop") or ""
            markers[marker_key] = {
                "source_id": favourite_source_id(self.source),
                "kind": self.kind,
                "category_id": cid,
                "title": title,
                "backdrop": str(back or "")
            }
            folder = os.path.dirname(marker_file)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)
            tmp = marker_file + ".tmp"
            with open(tmp, "w") as h:
                json.dump(markers, h, sort_keys=True)
            os.rename(tmp, marker_file)
            self.session.open(MessageBox, "Added package folder to Favorites", MessageBox.TYPE_INFO, timeout=3)
        except Exception as exc:
            self.session.open(MessageBox, "Favorite package error: %s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def deleteSelectedPackage(self):
        if not self.rows or self.index < 0 or self.index >= len(self.rows): return
        row=self.rows[self.index] if isinstance(self.rows[self.index],dict) else {}
        cid=str(row.get("id") or "").strip(); name=str(row.get("name") or "").strip()
        if not cid:return
        self._pendingDeletePackage=(cid,name)
        self.session.openWithCallback(self._confirmDeletePackage,MessageBox,"Delete this package?\n"+name,MessageBox.TYPE_YESNO)

    def _confirmDeletePackage(self,answer=False):
        pending=getattr(self,"_pendingDeletePackage",None); self._pendingDeletePackage=None
        if not answer or not pending:return
        cid,name=pending
        try:
            data=_load_all_filters(); key=_source_filter_key(self.source); entry=data.setdefault(key,{})
            allowed=entry.get(self.kind)
            if allowed is None:
                allowed=[str(row.get("id") or "") for row in self.rows if str(row.get("id") or "")]
            allowed=[str(x) for x in (allowed or []) if str(x)!=cid]
            entry[self.kind]=allowed; data[key]=entry
            if not _save_all_filters(data):
                self.session.open(MessageBox,"Unable to delete package.",MessageBox.TYPE_ERROR,timeout=3); return
            self.rows=[row for row in self.rows if str(row.get("id") or "")!=cid]
            if self.index>=len(self.rows):self.index=max(0,len(self.rows)-1)
            try:clear_catalog_memory()
            except Exception:pass
            self.render()
        except Exception as exc:
            self.session.open(MessageBox,"Delete package error: %s" % exc,MessageBox.TYPE_ERROR,timeout=4)

    def _refreshPackageSortHint(self):
        # The yellow key is already wired to the sort picker. Show its current
        # value without changing its action or the number of visible packages.
        labels = {"original": "ORIGINAL", "latest": "LATEST", "az": "A-Z", "za": "Z-A"}
        try:
            self["yellowHint"].setText("SORT\n%s  •  HOLD FAV" % labels.get(self.sortMode, "LATEST"))
        except Exception:
            pass

    def openPackageOrder(self):
        self.session.openWithCallback(self._packageOrderSelected,PackageOrderScreen,self.sortMode,self.kind)

    def _packageOrderSelected(self,mode=None):
        mode=str(mode or "")
        if mode not in ("original","latest","az","za"):return
        self.sortMode=mode
        try:
            _genre_order_file="/etc/enigma2/tivimatee2_genre_package_order.json"
            _genre_order_data=load_json(_genre_order_file,{}) or {}
            _genre_order_data[_content_package_control_key(self.source,self.kind)]=mode
            save_json(_genre_order_file,_genre_order_data)
        except Exception:
            pass
        self._applyPackageOrder(); self.index=0; self.pageStart=0; self._refreshPackageSortHint(); self.render()
        if self.sortMode=="latest": self._refreshLatestPackageOrder(self._token)

    def openPackageFilter(self):
        stype=str((self.source or {}).get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self.session.open(MessageBox,"Package filtering is available for Xtream Codes and Stalker Portal.",MessageBox.TYPE_INFO,timeout=4); return
        self.session.openWithCallback(self._packageFilterClosed,ServerCategoryFilter,dict(self.source),self.kind,True)

    def _packageFilterClosed(self,changed=None):
        try:clear_catalog_memory()
        except Exception:pass
        self.rows=[]; self.index=0; self.pageStart=0; self.start()

    def _serverChoices(self):
        rows=[]; current_key=_source_identity(self.source)
        for source in list(get_sources() or []):
            if not isinstance(source,dict):continue
            stype=str(source.get("type") or "").lower()
            if stype not in ("xtream","stalker","m3u"):continue
            if stype=="m3u" and not _m3u_source_has_kind(source,self.kind):continue
            name=str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            kind="Xtream" if stype=="xtream" else "Stalker" if stype=="stalker" else "M3U"
            prefix="✓ " if _source_identity(source)==current_key else ""
            rows.append(("%s%s  [%s]"%(prefix,name,kind),dict(source)))
        return rows

    def serverSwitch(self):
        choices=self._serverChoices()
        if not choices:
            self.session.open(MessageBox,"No compatible IPTV servers found.",MessageBox.TYPE_INFO,timeout=3); return
        self.session.openWithCallback(self._serverSwitchSelected,ChoiceBox,title="SERVER SWITCH",list=choices)

    def _serverSwitchSelected(self,choice=None):
        if not choice:return
        try:source=choice[1]
        except Exception:return
        if not isinstance(source,dict):return
        self.source=dict(source); self.rows=[]; self.index=0; self.pageStart=0
        self._genreImageSavePending=set()
        try:
            _all_backdrops=load_json(self._packageBackdropFile,{}) or {}
            _scope_cache=_all_backdrops.get(_content_package_control_key(self.source,self.kind),{})
            self._packageBackdropCache=dict(_scope_cache) if isinstance(_scope_cache,dict) else {}
        except Exception:
            self._packageBackdropCache={}
        try:
            # Persist the Genre server independently for Movies and TV Shows.
            _genre_server_file="/etc/enigma2/tivimatee2_genre_server.json"
            _genre_server_data=load_json(_genre_server_file,{}) or {}
            _genre_server_data[self.kind]=_source_identity(self.source)
            save_json(_genre_server_file,_genre_server_data)
            save_json(MAIN_SOURCE_FILE,{"key":_source_identity(self.source)})
        except Exception:pass
        # Load ORDER + cached Latest for the newly selected server before rendering it.
        self.sortMode="latest"; self._latestOrderCache={}
        try:
            _key=_content_package_control_key(self.source,self.kind)
            _orders=load_json("/etc/enigma2/tivimatee2_genre_package_order.json",{}) or {}
            _mode=str(_orders.get(_key) or "latest")
            if _mode in ("original","latest","az","za"): self.sortMode=_mode
            _latest=load_json(_genre_cache_file("latest_order.json"),{}) or {}
            _cached=_latest.get(_key,{})
            if isinstance(_cached,dict): self._latestOrderCache=_cached
        except Exception:pass
        self.start()

    def _excluded(self,name):
        t=str(name or "").casefold()
        return any(w.casefold() in t for w in self.EXCLUDE_WORDS)
    def start(self):
        self._cancelGenreBackdropJobs()
        self._genreBackdropRecoveryCount={}
        self._renderedGenrePage=None
        self._artworkPageKey=None
        self._token+=1; token=self._token; source=dict(self.source)
        def make_rows(cats):
            rows=[]; seen=set(); kind=self.kind
            try: cats=filter_categories(source,kind,cats or [])
            except Exception: cats=cats or []
            for entry in cats or []:
                if isinstance(entry,dict):
                    name=str(entry.get("category_name") or entry.get("name") or entry.get("title") or "").strip()
                    cid=str(entry.get("category_id") or entry.get("id") or "").strip()
                elif isinstance(entry,(list,tuple)) and len(entry)>=2:
                    name=str(entry[0] or "").strip(); cid=str(entry[1] or "").strip()
                else: continue
                if not name or not cid or self._excluded(name): continue
                key=(kind,cid)
                if key in seen: continue
                cached_latest=0
                try: cached_latest=int(self._latestOrderCache.get(str(cid),0) or 0)
                except Exception: cached_latest=0
                cached_backdrop=str(self._packageBackdropCache.get(str(cid)) or "").strip()
                if not self._isRealPackageBackdrop(cached_backdrop):
                    cached_backdrop=""
                # The saved image is authoritative; URL mapping is fallback only.
                local_image=saved_genre_image(source,kind,cid)
                seen.add(key); rows.append({"name":name,"id":cid,"kind":kind,
                    "backdrop":cached_backdrop,"_genre_image":local_image,
                    "_provider_order":len(rows),"_latest_key":cached_latest})
            return rows
        def paint(rows, reset=True):
            if token!=self._token:return
            self.rows=rows
            self._applyPackageOrder()
            if reset:self.index=0; self.pageStart=0
            elif self.rows:self.index=min(self.index,len(self.rows)-1)
            # Never defer the first paint for the Latest cache scan. On a
            # first install or an undated provider, no cached timestamp may
            # exist at all: the old branch returned without ever painting the
            # screen. Display provider order temporarily and refine cached
            # Latest timestamps off the GUI thread when they are available.
            # A fresh/cached category list may replace rows while staying on page 1.
            # Do not keep the old page artwork key or the first page can wait until
            # the user visits page 2 before its backdrop jobs are scheduled again.
            self._artworkPageKey=None
            self.render()
            if self.sortMode=="latest": self._refreshLatestPackageOrder(token)
            # Backdrops are loaded page-by-page from render(): only the visible 12.
        def worker():
            client=None; cached=[]
            try:
                client=get_source_client(source)
                cached,_=get_cached_categories(source,self.kind,client=client,wait_for_server=False)
            except Exception: cached=[]
            rows=make_rows(cached)
            if rows:
                try: reactor.callFromThread(paint,rows,True)
                except Exception: paint(rows,True)
            # Refresh categories after the cached list is already on screen.
            try:
                fresh,_=get_cached_categories(source,self.kind,client=client,wait_for_server=True)
                fresh_rows=make_rows(fresh)
            except Exception: fresh_rows=[]
            if fresh_rows and [(x["id"],x["name"]) for x in fresh_rows] != [(x["id"],x["name"]) for x in rows]:
                try: reactor.callFromThread(paint,fresh_rows,not bool(rows))
                except Exception: paint(fresh_rows,not bool(rows))
            elif not rows and fresh_rows:
                try: reactor.callFromThread(paint,fresh_rows,True)
                except Exception: paint(fresh_rows,True)
        t=threading.Thread(target=worker,name="TiviMateGenrePackages"); t.daemon=True; t.start()

    def _loadPackageBackdrops(self, token):
        # GENRE artwork follows the Movies backdrop behaviour: the package grid
        # paints immediately, while only the 12 visible backdrops resolve in
        # parallel and use the shared persistent artwork cache.
        source=dict(self.source); rows=self.rows
        page_start=max(0,int(self.pageStart or 0))
        page_end=min(len(rows),page_start+self.PAGE_SIZE)
        self._cancelGenreBackdropJobs()

        def active():
            return (not self._genreClosed and token==self._token and
                    self.pageStart==page_start and
                    _source_identity(self.source)==_source_identity(source))

        def resolve_one(idx, row):
            if not active() or saved_genre_image(source,row["kind"],row["id"]):
                return
            # Missing/backdrop-less packages have a short in-memory retry
            # cooldown; cursor movement must not trigger endless new requests.
            miss_key=(_source_identity(source),row["kind"],str(row["id"]))
            if self._genreBackdropMisses.get(miss_key,0)>time.monotonic():
                return
            if (self._isRealPackageBackdrop(row.get("backdrop")) and
                    str(row.get("backdrop")) != str(row.get("_broken_backdrop") or "")):
                # render() will download an untried URL and save its image.
                return
            row["backdrop"]=""
            try:
                try: client=get_source_client(source)
                except Exception: client=None
                # Peek without queuing a refresh: the prior nonblocking call
                # started a download and the following blocking call could
                # start/wait for the same uncached category twice.
                from .filters import peek_category_streams_cache
                items,_=peek_category_streams_cache(source,row["kind"],row["id"])
                tmdb=TMDbClient(); tmdb_kind="series" if row["kind"]=="series" else "vod"

                def resolve_backdrop(candidates):
                    # A category may start with items without usable artwork.
                    # Scan up to 24 provider records for *existing* backdrop
                    # fields first (no network). This avoids the old first-5
                    # cutoff without increasing the two GENRE resolver workers.
                    sample=list(islice(candidates or [],24))
                    broken=str(row.get("_broken_backdrop") or "")
                    def good_url(value):
                        if isinstance(value,(list,tuple)):
                            value=value[0] if value else ""
                        if not value: return ""
                        value=str(value).strip().replace(chr(92)+"/", "/")
                        if value.startswith("["):
                            try:
                                parsed=json.loads(value)
                                value=parsed[0] if isinstance(parsed,list) and parsed else ""
                            except Exception: return ""
                        if not value: return ""
                        value=_server_asset_url(source,value)
                        return value if value and str(value)!=broken else ""
                    for candidate in sample:
                        if not active(): return ""
                        if not isinstance(candidate,dict): continue
                        info=candidate.get("info")
                        for item in (candidate,info if isinstance(info,dict) else {}):
                            back=good_url(item.get("backdrop_path") or item.get("backdrop") or
                                          item.get("backdrop_url") or item.get("fanart") or
                                          item.get("background"))
                            if back: return back
                    # Provider metadata absent: bounded lookups only. A title
                    # found later in the list gets its chance without making
                    # unbounded serial TMDb requests on the receiver.
                    remote_checks=0
                    max_remote_checks=8
                    for candidate in sample:
                        if not active(): return ""
                        if not isinstance(candidate,dict): continue
                        if row["kind"]=="series" and client is not None and remote_checks<max_remote_checks:
                            series_id=str(candidate.get("series_id") or candidate.get("id") or candidate.get("stream_id") or "").strip()
                            if series_id and hasattr(client,"series_info"):
                                remote_checks+=1
                                try:
                                    series_data=client.series_info(series_id) or {}
                                    info=series_data.get("info") if isinstance(series_data,dict) else {}
                                    if not isinstance(info,dict): info={}
                                    back=good_url(info.get("backdrop_path") or info.get("backdrop") or
                                                  info.get("backdrop_url") or info.get("fanart") or
                                                  series_data.get("backdrop_path") or series_data.get("backdrop"))
                                    if back: return back
                                except Exception: pass
                        if remote_checks<max_remote_checks:
                            tid=str(candidate.get("tmdb_id") or candidate.get("tmdb") or candidate.get("tmdbid") or "").strip()
                            if tid:
                                remote_checks+=1
                                try:
                                    back=(tmdb.details_bundle(tid,tmdb_kind) or {}).get("backdrop_path") or ""
                                    if back:
                                        back=backdrop_url(back)
                                        if back and str(back)!=broken: return back
                                except Exception: pass
                        if remote_checks<max_remote_checks:
                            title=str(candidate.get("name") or candidate.get("title") or "").strip()
                            if title:
                                remote_checks+=1
                                try:
                                    back=(tmdb.search_artwork(title,kind=tmdb_kind,
                                        year=candidate.get("year"),required_key="backdrop_path") or {}).get("backdrop_path") or ""
                                    if back:
                                        back=backdrop_url(back)
                                        if back and str(back)!=broken: return back
                                except Exception: pass
                        if remote_checks>=max_remote_checks: break
                    return ""

                back=resolve_backdrop(items)
                if not back and active():
                    # Request the same category once through the cache-aware
                    # path; use_cache=False previously forced a second network
                    # fetch even if a background update was already underway.
                    try: full_items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=True,wait_for_server=True)
                    except Exception: full_items=[]
                    if active(): back=resolve_backdrop(full_items)
                if not active(): return
                if not back:
                    self._genreBackdropMisses[miss_key]=time.monotonic()+90.0
                    return
                if isinstance(back,str):
                    back=back.strip().replace(chr(92)+"/","/")
                    if back.startswith("["):
                        try:
                            arr=json.loads(back); back=arr[0] if arr else ""
                        except Exception: pass
                    if back.startswith("/") and not back.startswith("//"):
                        back = _server_asset_url(source, back)
                if not self._isRealPackageBackdrop(back): return
                row["backdrop"]=str(back)
                # Download from provider/TMDb exactly once, then persist the
                # *actual* picture under images/genre/<server>/<kind>/<package>.
                try:
                    request_artwork(str(back),"backdrops",
                        lambda path, source=source, kind=row["kind"], cid=row["id"], token=token, url=str(back):
                            self._saveGenreImageLater(source,kind,cid,path,token,url),
                        priority=115,source=source)
                except Exception: pass
                def repaint(i=idx):
                    if active() and self.pageStart <= i < self.pageStart+self.PAGE_SIZE: self.render()
                try: reactor.callFromThread(repaint)
                except Exception: pass
            except Exception: pass

        self._genreBackdropResolver=resolve_one
        # Only the visible page is queued. At most two background workers run
        # concurrently; switching pages cancels all still-queued old-page jobs.
        for idx in range(page_start,page_end):
            local=rows[idx].get("_genre_image") or ""
            if (local and os.path.isfile(local)) or saved_genre_image(source,rows[idx]["kind"],rows[idx]["id"]):
                continue
            miss_key=(_source_identity(source),rows[idx]["kind"],str(rows[idx]["id"]))
            if self._genreBackdropMisses.get(miss_key,0)>time.monotonic():
                continue
            future=_GENRE_BACKDROP_POOL.submit(resolve_one,idx,rows[idx])
            self._genreBackdropJobs.append(future)
    def _drawGenreFocus(self):
        total=len(self.rows)
        if total:
            slot=self.index-self.pageStart
            x=[247,612,977,1342][slot%4]
            y=[178,448,718][slot//4]
            try:
                focus_colors=("cyan","silver","red","green","orange","purple")
                focus_name="genre_package_focus_%s.png" % focus_colors[self.index % len(focus_colors)]
                focus_path=os.path.join(PLUGIN_PATH,"skins","genre",focus_name)
                self["selector"].instance.setPixmapFromFile(focus_path)
            except Exception: pass
            try: self["selector"].instance.move(ePoint(sx(x),sy(y))); self["selector"].show()
            except Exception: pass
        else:
            try: self["selector"].hide()
            except Exception: pass

    def _genreSelectionChanged(self):
        # Arrow-key repeats should move only the focus, not re-decode 12 JPEGs,
        # restat cache files, resolve badges and touch flash on every press.
        if not self.rows:
            return
        start=(self.index//self.PAGE_SIZE)*self.PAGE_SIZE
        if self._renderedGenrePage==(self._token,start):
            self._drawGenreFocus()
        else:
            self.render()

    def render(self):
        total=len(self.rows)
        if total:
            self.pageStart=(self.index//self.PAGE_SIZE)*self.PAGE_SIZE
        page=(self.pageStart//self.PAGE_SIZE)+1 if total else 1
        pages=max(1,(total+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["page"].setText("%d / %d"%(page,pages))
        # Resolve/download artwork only for the 12 packages on the visible page.
        # Moving to another page schedules that page's 12; hidden pages stay untouched.
        _art_key=(self._token,self.pageStart)
        if total and getattr(self,"_artworkPageKey",None)!=_art_key:
            self._artworkPageKey=_art_key
            self._loadPackageBackdrops(self._token)
        for slot in range(self.PAGE_SIZE):
            pos=self.pageStart+slot; row=self.rows[pos] if pos<total else None
            label=self["label%d"%slot]
            badge=self["badge%d"%slot]
            year_badge=self["yearBadge%d"%slot]
            if not row:
                label.setText(""); label.hide(); badge.hide(); year_badge.hide()
                self["card%d"%slot].hide(); self["shell%d"%slot].hide(); continue
            # Logos are local assets. Match Arabic/English package names without
            # changing their real provider title, ID, order, caches or artwork.
            logo_path, year_path=resolve_package_badge(row.get("name") or "", row.get("kind") or self.kind)
            if logo_path:
                label.setText(""); label.hide()
                try:
                    badge.instance.resize(eSize(sx(204 if year_path else 306),sy(34)))
                    badge.instance.setPixmapFromFile(logo_path)
                    badge.show()
                except Exception:
                    badge.hide()
                    label.setText(row.get("name") or ""); label.show()
                if year_path:
                    try:
                        year_badge.instance.setPixmapFromFile(year_path)
                        year_badge.show()
                    except Exception: year_badge.hide()
                else:
                    year_badge.hide()
            else:
                badge.hide(); year_badge.hide()
                label.setText(row.get("name") or ""); label.show()
            self["card%d"%slot].show(); self["shell%d"%slot].show()
            # Saved per-server file takes precedence over all URL/cache results.
            local=row.get("_genre_image") or ""
            if not local or not os.path.isfile(local):
                local=saved_genre_image(self.source,row["kind"],row["id"])
                if local:
                    row["_genre_image"]=local
            if local:
                try:self["card%d"%slot].instance.setPixmapFromFile(local)
                except Exception:pass
                continue
            url=row.get("backdrop") or ""
            cached=cached_artwork(url,"backdrops") if url else ""
            if cached and os.path.exists(cached):
                try:self["card%d"%slot].instance.setPixmapFromFile(cached)
                except Exception:pass
                self._saveGenreImageLater(dict(self.source),row["kind"],row["id"],cached,self._token,url)
            else:
                try:self["card%d"%slot].instance.setPixmapFromFile("/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/genre/genre_default.jpg")
                except Exception:pass
                if url:
                    expected=(pos,url)
                    source=dict(self.source); kind=row["kind"]; cid=row["id"]; token=self._token
                    def ready(path, s=slot, exp=expected, source=source, kind=kind, cid=cid, token=token):
                        if not path: return
                        self._saveGenreImageLater(source,kind,cid,path,token,exp[1])
                        try:
                            p=self.pageStart+s
                            if p!=exp[0] or p>=len(self.rows) or self.rows[p].get("backdrop")!=exp[1]:return
                            self["card%d"%s].instance.setPixmapFromFile(path)
                        except Exception:pass
                    # Visible GENRE cards outrank background artwork downloads.
                    def failed(_path, p=pos, missing_url=url, token=token):
                        if token!=self._token or p>=len(self.rows): return
                        current=self.rows[p]
                        if str(current.get("backdrop") or "")!=missing_url: return
                        current["_broken_backdrop"]=missing_url
                        current["backdrop"]=""
                        # Re-resolve this package from its existing provider
                        # items and then TMDb, off the UI thread. Do not delete
                        # any saved genre image or affect another server.
                        # Retry only the failed card, not all 12. Try a
                        # different real backdrop from the same package once;
                        # repeated broken URLs get a short negative cooldown.
                        miss_key=(_source_identity(self.source),current["kind"],str(current["id"]))
                        attempt_key=(token,miss_key)
                        attempts=self._genreBackdropRecoveryCount.get(attempt_key,0)
                        if (attempts<1 and self.pageStart<=p<self.pageStart+self.PAGE_SIZE
                                and self._genreBackdropResolver is not None and not self._genreClosed):
                            self._genreBackdropRecoveryCount[attempt_key]=attempts+1
                            future=_GENRE_BACKDROP_POOL.submit(self._genreBackdropResolver,p,current)
                            self._genreBackdropJobs.append(future)
                        else:
                            self._genreBackdropMisses[miss_key]=time.monotonic()+90.0
                    try:request_artwork(url,"backdrops",ready,priority=150,errback=failed,source=source)
                    except Exception:pass
        self._renderedGenrePage=(self._token,self.pageStart)
        self._drawGenreFocus()
    def left(self):
        if self.rows:self.index=max(0,self.index-1); self._genreSelectionChanged()
    def right(self):
        if self.rows:self.index=min(len(self.rows)-1,self.index+1); self._genreSelectionChanged()
    def up(self):
        if self.rows:
            if self.index == 0:
                self.index = ((len(self.rows) - 1) // self.PAGE_SIZE) * self.PAGE_SIZE
            else:
                self.index = max(0, self.index - 4)
            self._genreSelectionChanged()
    def down(self):
        if self.rows:self.index=min(len(self.rows)-1,self.index+4); self._genreSelectionChanged()
    def pageUp(self):
        if self.rows:self.index=max(0,self.index-self.PAGE_SIZE); self._genreSelectionChanged()
    def pageDown(self):
        if self.rows:self.index=min(len(self.rows)-1,self.index+self.PAGE_SIZE); self._genreSelectionChanged()
    def choose(self):
        if not self.rows:return
        row=dict(self.rows[self.index]); source=dict(self.source)
        def worker():
            items=[]
            try:
                client=get_source_client(source)
                # Genre package opening is cache-first.  Only contact the server
                # when this package has no cached content, so sorting never adds
                # a server request on every visit.
                items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=True,wait_for_server=False)
                if not items:
                    items,_=get_category_streams(source,row["kind"],client,row["id"],use_cache=True,wait_for_server=True)
            except Exception:pass
            # Newest -> oldest, locally. Prefer provider added timestamps; when
            # unavailable, fall back to release date/year. Python's stable sort
            # preserves provider order when no useful date exists.
            def newest_key(item):
                # Real newest-first ordering for Genre package contents.
                # Provider `added` is authoritative when present; release date/year
                # is the fallback. Do not use last_modified because many providers
                # update old records and that makes them look falsely new.
                if not isinstance(item, dict):
                    return (0, 0)
                import datetime
                def _stamp(value):
                    if value in (None, ""):
                        return 0
                    try:
                        n = int(float(value))
                        # Accept seconds or milliseconds since epoch.
                        if n > 100000000000:
                            n //= 1000
                        if n > 100000000:
                            return n
                    except Exception:
                        pass
                    txt = str(value).strip().replace("Z", "").replace("T", " ")
                    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d"):
                        try:
                            return int(time.mktime(datetime.datetime.strptime(txt[:19] if "%H" in fmt else txt[:10], fmt).timetuple()))
                        except Exception:
                            pass
                    return 0
                for key in ("added", "added_timestamp", "added_at", "date_added", "created_at", "timestamp"):
                    ts = _stamp(item.get(key))
                    if ts:
                        return (3, ts)
                for key in ("release_date", "releaseDate", "releasedate", "release_date_utc", "first_air_date"):
                    ts = _stamp(item.get(key))
                    if ts:
                        return (2, ts)
                try:
                    year = int(str(item.get("year") or "")[:4])
                    if 1800 <= year <= 2200:
                        return (1, year)
                except Exception:
                    pass
                return (0, 0)
            try: items=sorted(list(items or []),key=newest_key,reverse=True)
            except Exception: items=list(items or [])

            # GENRE package artwork: as soon as the package content is loaded,
            # persist the first *real backdrop* already present in its items.
            # This runs only for the package the user opened and never uses a poster/cover.
            try:
                package_id=str(row.get("id") or "").strip()
                scope=_content_package_control_key(source,row.get("kind") or self.kind)
                all_backdrops=load_json(self._packageBackdropFile,{}) or {}
                scope_cache=all_backdrops.get(scope,{})
                if not isinstance(scope_cache,dict): scope_cache={}
                current=str(scope_cache.get(package_id) or "").strip()
                if package_id and not self._isRealPackageBackdrop(current):
                    found_backdrop=""
                    for candidate in (items or []):
                        if not isinstance(candidate,dict):
                            continue
                        back=(candidate.get("backdrop_path") or candidate.get("backdrop") or candidate.get("backdrop_url") or candidate.get("fanart") or candidate.get("background") or "")
                        if isinstance(back,list):
                            back=back[0] if back else ""
                        back=str(back or "").strip().replace("\\/","/")
                        # Some providers return a JSON encoded backdrop list.
                        if back.startswith("["):
                            try:
                                parsed=json.loads(back)
                                if isinstance(parsed,list) and parsed:
                                    back=str(parsed[0] or "").strip()
                            except Exception:
                                pass
                        if back.startswith("/"):
                            try: back=backdrop_url(back) or back
                            except Exception: pass
                        if self._isRealPackageBackdrop(back):
                            found_backdrop=back
                            break
                    if found_backdrop:
                        scope_cache[package_id]=found_backdrop
                        all_backdrops[scope]=scope_cache
                        save_json(self._packageBackdropFile,all_backdrops)
                        self._packageBackdropCache=dict(scope_cache)
            except Exception:
                pass

            def done():
                if not items:
                    self.session.open(MessageBox,"No content in this package.",MessageBox.TYPE_INFO,timeout=3); return
                media_source=dict(source)
                media_source["_genre_package_id"]=str(row.get("id") or "")
                media_source["_genre_package_kind"]=str(row.get("kind") or "")
                media_source["_genre_badge_context"]="selected_item"
                def package_closed(*args):
                    # MediaScreen stores the first real backdrop it actually
                    # displays for this package. Reload that mapping on return
                    # so GENERAL is replaced immediately without another scan.
                    try:
                        all_backdrops=load_json(self._packageBackdropFile,{}) or {}
                        scope=_content_package_control_key(self.source,self.kind)
                        scope_cache=all_backdrops.get(scope,{})
                        if isinstance(scope_cache,dict):
                            self._packageBackdropCache=dict(scope_cache)
                            saved=str(self._packageBackdropCache.get(str(row.get("id") or "")) or "").strip()
                            if self._isRealPackageBackdrop(saved):
                                for current in self.rows:
                                    if str(current.get("id") or "")==str(row.get("id") or ""):
                                        current["backdrop"]=saved
                                        break
                    except Exception:
                        pass
                    # MediaScreen already saved the first successfully loaded
                    # package backdrop image, so bind that file immediately.
                    try:
                        local=saved_genre_image(self.source,row["kind"],row["id"])
                        if local:
                            for current in self.rows:
                                if str(current.get("id") or "")==str(row["id"]):
                                    current["_genre_image"]=local
                    except Exception:pass
                    self.render()
                self.session.openWithCallback(package_closed,MediaScreen,media_source,row["kind"],None,row["name"],list(items))
            try:reactor.callFromThread(done)
            except Exception:done()
        t=threading.Thread(target=worker,name="TiviMateOpenGenrePackage"); t.daemon=True; t.start()

# ---------------------------------------------------------------------------
# Package browser screens
# ---------------------------------------------------------------------------

# Actual, precomputed RGBA content bounds for the ORIGINAL GENRE badges.
# Metadata only: no Pillow, recompression, runtime image processing or new images.
_PACKAGE_BADGE_VISIBLE_BOUNDS = {
    'badge_4k_compact.png': (63, 6, 141, 27),
    'badge_4k_full.png': (114, 6, 192, 27),
    'badge_action_ar_compact.png': (67, 5, 137, 29),
    'badge_action_ar_full.png': (117, 5, 188, 29),
    'badge_action_compact.png': (57, 5, 147, 29),
    'badge_action_full.png': (108, 5, 198, 29),
    'badge_adventure_ar_compact.png': (38, 7, 165, 30),
    'badge_adventure_ar_full.png': (85, 6, 219, 30),
    'badge_adventure_compact.png': (35, 5, 169, 29),
    'badge_adventure_full.png': (86, 5, 220, 29),
    'badge_animation_ar_compact.png': (30, 5, 173, 29),
    'badge_animation_ar_full.png': (84, 5, 222, 29),
    'badge_animation_compact.png': (48, 5, 156, 29),
    'badge_animation_full.png': (99, 5, 207, 29),
    'badge_anime_ar_compact.png': (71, 5, 132, 29),
    'badge_anime_ar_full.png': (122, 5, 184, 29),
    'badge_anime_compact.png': (56, 5, 148, 29),
    'badge_anime_full.png': (107, 5, 199, 29),
    'badge_apple_compact.png': (30, 5, 174, 29),
    'badge_apple_full.png': (81, 5, 225, 29),
    'badge_arabic_ar_compact.png': (49, 5, 155, 29),
    'badge_arabic_ar_full.png': (98, 5, 207, 29),
    'badge_arabic_series_ar_compact.png': (28, 5, 176, 29),
    'badge_arabic_series_ar_full.png': (64, 5, 241, 29),
    'badge_asian_ar_compact.png': (42, 5, 161, 29),
    'badge_asian_ar_full.png': (91, 5, 214, 29),
    'badge_asian_compact.png': (57, 5, 146, 29),
    'badge_asian_full.png': (108, 5, 197, 29),
    'badge_asian_series_ar_compact.png': (9, 6, 194, 28),
    'badge_asian_series_ar_full.png': (50, 5, 256, 29),
    'badge_comedy_ar_compact.png': (56, 5, 147, 29),
    'badge_comedy_ar_full.png': (105, 5, 201, 29),
    'badge_comedy_compact.png': (44, 5, 159, 29),
    'badge_comedy_full.png': (95, 5, 210, 29),
    'badge_crime_ar_compact.png': (63, 5, 141, 29),
    'badge_crime_ar_full.png': (112, 5, 194, 29),
    'badge_crime_compact.png': (58, 5, 146, 29),
    'badge_crime_full.png': (109, 5, 197, 29),
    'badge_dc_compact.png': (86, 7, 119, 24),
    'badge_dc_full.png': (135, 6, 173, 25),
    'badge_disney_compact.png': (46, 5, 157, 29),
    'badge_disney_full.png': (97, 5, 208, 29),
    'badge_documentary_ar_compact.png': (41, 5, 163, 29),
    'badge_documentary_ar_full.png': (93, 5, 213, 29),
    'badge_documentary_compact.png': (35, 5, 169, 29),
    'badge_documentary_full.png': (86, 5, 220, 29),
    'badge_drama_ar_compact.png': (63, 5, 141, 29),
    'badge_drama_ar_full.png': (112, 5, 194, 29),
    'badge_drama_compact.png': (40, 5, 164, 29),
    'badge_drama_full.png': (91, 5, 215, 29),
    'badge_dreamworks_compact.png': (13, 8, 192, 24),
    'badge_dreamworks_full.png': (47, 6, 258, 25),
    'badge_family_ar_compact.png': (57, 5, 147, 29),
    'badge_family_ar_full.png': (109, 5, 197, 29),
    'badge_family_compact.png': (48, 5, 155, 29),
    'badge_family_full.png': (99, 5, 206, 29),
    'badge_fantasy_ar_compact.png': (55, 5, 148, 29),
    'badge_fantasy_ar_full.png': (104, 5, 202, 29),
    'badge_fantasy_compact.png': (57, 5, 147, 29),
    'badge_fantasy_full.png': (108, 5, 198, 29),
    'badge_foreign_ar_compact.png': (46, 5, 157, 29),
    'badge_foreign_ar_full.png': (95, 5, 210, 29),
    'badge_foreign_compact.png': (50, 5, 153, 29),
    'badge_foreign_full.png': (101, 5, 204, 29),
    'badge_foreign_series_ar_compact.png': (25, 5, 178, 29),
    'badge_foreign_series_ar_full.png': (64, 5, 241, 29),
    'badge_hbo_compact.png': (76, 7, 130, 24),
    'badge_hbo_full.png': (123, 6, 184, 25),
    'badge_horror_ar_compact.png': (72, 5, 131, 29),
    'badge_horror_ar_full.png': (122, 5, 184, 29),
    'badge_horror_compact.png': (55, 5, 149, 29),
    'badge_horror_full.png': (106, 5, 200, 29),
    'badge_hulu_compact.png': (74, 7, 129, 24),
    'badge_hulu_full.png': (123, 5, 184, 25),
    'badge_illumination_compact.png': (11, 7, 193, 24),
    'badge_illumination_full.png': (50, 6, 256, 25),
    'badge_indian_ar_compact.png': (49, 5, 155, 29),
    'badge_indian_ar_full.png': (98, 5, 207, 29),
    'badge_indian_compact.png': (60, 5, 144, 29),
    'badge_indian_full.png': (111, 5, 195, 29),
    'badge_indian_series_ar_compact.png': (28, 5, 175, 29),
    'badge_indian_series_ar_full.png': (64, 5, 241, 29),
    'badge_kids_ar_compact.png': (67, 5, 137, 29),
    'badge_kids_ar_full.png': (117, 5, 188, 29),
    'badge_kids_compact.png': (70, 5, 134, 29),
    'badge_kids_full.png': (121, 5, 185, 29),
    'badge_marvel_compact.png': (51, 7, 156, 24),
    'badge_marvel_full.png': (95, 6, 213, 25),
    'badge_max_compact.png': (54, 5, 149, 29),
    'badge_max_full.png': (105, 5, 200, 29),
    'badge_mbc_compact.png': (75, 7, 129, 24),
    'badge_mbc_full.png': (123, 6, 185, 25),
    'badge_movies_ar_compact.png': (70, 5, 133, 29),
    'badge_movies_ar_full.png': (121, 5, 185, 29),
    'badge_movies_compact.png': (57, 5, 146, 29),
    'badge_movies_full.png': (108, 5, 197, 29),
    'badge_music_ar_compact.png': (53, 5, 150, 29),
    'badge_music_ar_full.png': (102, 5, 204, 29),
    'badge_music_compact.png': (64, 5, 140, 29),
    'badge_music_full.png': (115, 5, 191, 29),
    'badge_mystery_ar_compact.png': (45, 6, 157, 29),
    'badge_mystery_ar_full.png': (98, 5, 207, 29),
    'badge_mystery_compact.png': (23, 5, 181, 29),
    'badge_mystery_full.png': (74, 5, 232, 29),
    'badge_netflix_compact.png': (47, 8, 157, 25),
    'badge_netflix_full.png': (98, 8, 208, 25),
    'badge_osn_compact.png': (75, 7, 128, 24),
    'badge_osn_full.png': (123, 6, 183, 25),
    'badge_paramount_compact.png': (16, 8, 187, 26),
    'badge_paramount_full.png': (67, 8, 238, 26),
    'badge_pixar_compact.png': (65, 7, 142, 24),
    'badge_pixar_full.png': (111, 6, 198, 25),
    'badge_prime_compact.png': (77, 5, 127, 29),
    'badge_prime_full.png': (128, 5, 178, 29),
    'badge_ramadan_ar_compact.png': (47, 7, 157, 30),
    'badge_ramadan_ar_full.png': (95, 6, 210, 30),
    'badge_ramadan_compact.png': (49, 5, 154, 29),
    'badge_ramadan_full.png': (100, 5, 205, 29),
    'badge_recent_movies_ar_compact.png': (42, 5, 161, 29),
    'badge_recent_movies_ar_full.png': (92, 5, 214, 29),
    'badge_recent_movies_compact.png': (64, 5, 139, 29),
    'badge_recent_movies_full.png': (115, 5, 190, 29),
    'badge_recent_series_ar_compact.png': (29, 5, 174, 29),
    'badge_recent_series_ar_full.png': (64, 5, 242, 29),
    'badge_recent_series_compact.png': (65, 5, 139, 29),
    'badge_recent_series_full.png': (116, 5, 190, 29),
    'badge_romance_ar_compact.png': (54, 5, 149, 29),
    'badge_romance_ar_full.png': (103, 5, 203, 29),
    'badge_romance_compact.png': (42, 5, 161, 29),
    'badge_romance_full.png': (93, 5, 212, 29),
    'badge_rotana_compact.png': (51, 7, 155, 24),
    'badge_rotana_full.png': (95, 6, 213, 25),
    'badge_scifi_ar_compact.png': (51, 5, 152, 29),
    'badge_scifi_ar_full.png': (98, 5, 207, 29),
    'badge_scifi_compact.png': (69, 5, 135, 29),
    'badge_scifi_full.png': (120, 5, 186, 29),
    'badge_series_ar_compact.png': (28, 6, 176, 28),
    'badge_series_ar_full.png': (74, 6, 231, 28),
    'badge_series_compact.png': (54, 5, 150, 29),
    'badge_series_full.png': (105, 5, 201, 29),
    'badge_shahid_compact.png': (56, 5, 147, 29),
    'badge_shahid_full.png': (107, 5, 198, 29),
    'badge_starz_compact.png': (62, 7, 143, 24),
    'badge_starz_full.png': (107, 6, 199, 25),
    'badge_stc_compact.png': (84, 8, 121, 24),
    'badge_stc_full.png': (132, 7, 173, 25),
    'badge_theatre_ar_compact.png': (50, 11, 154, 33),
    'badge_theatre_ar_full.png': (98, 11, 207, 34),
    'badge_theatre_compact.png': (10, 5, 194, 28),
    'badge_theatre_full.png': (61, 5, 245, 28),
    'badge_thriller_ar_compact.png': (65, 5, 139, 29),
    'badge_thriller_ar_full.png': (117, 5, 188, 29),
    'badge_thriller_compact.png': (53, 5, 151, 29),
    'badge_thriller_full.png': (104, 5, 202, 29),
    'badge_tod_compact.png': (73, 5, 130, 29),
    'badge_tod_full.png': (124, 5, 181, 29),
    'badge_top_ar_compact.png': (35, 5, 169, 29),
    'badge_top_ar_full.png': (81, 5, 224, 29),
    'badge_top_compact.png': (26, 6, 178, 27),
    'badge_top_full.png': (77, 6, 229, 27),
    'badge_ufc_compact.png': (68, 5, 136, 29),
    'badge_ufc_full.png': (119, 5, 187, 29),
    'badge_universal_compact.png': (31, 7, 176, 24),
    'badge_universal_full.png': (72, 6, 235, 25),
    'badge_viu_compact.png': (70, 5, 134, 29),
    'badge_viu_full.png': (121, 5, 185, 29),
    'badge_war_ar_compact.png': (66, 5, 137, 29),
    'badge_war_ar_full.png': (115, 5, 190, 29),
    'badge_war_compact.png': (65, 5, 139, 29),
    'badge_war_full.png': (116, 5, 190, 29),
    'badge_warner_compact.png': (10, 8, 193, 24),
    'badge_warner_full.png': (45, 6, 260, 25),
    'badge_watchit_compact.png': (80, 5, 123, 29),
    'badge_watchit_full.png': (131, 5, 174, 29),
    'badge_western_ar_compact.png': (46, 9, 157, 30),
    'badge_western_ar_full.png': (94, 9, 211, 30),
    'badge_western_compact.png': (23, 5, 181, 29),
    'badge_western_full.png': (74, 5, 232, 29),
    'badge_wrestling_ar_compact.png': (48, 4, 151, 30),
    'badge_wrestling_ar_full.png': (99, 4, 202, 30),
    'badge_wrestling_compact.png': (29, 8, 171, 30),
    'badge_wrestling_full.png': (80, 8, 222, 30),
    'badge_wwe_compact.png': (70, 3, 140, 34),
    'badge_wwe_full.png': (121, 3, 191, 34),
    'badge_youtube_compact.png': (47, 7, 156, 24),
    'badge_youtube_full.png': (91, 5, 214, 25),
    'package_anime.png': (33, 22, 186, 62),
    'package_apple.png': (29, 28, 191, 55),
    'package_asia.png': (47, 25, 173, 59),
    'package_disney.png': (34, 25, 186, 58),
    'package_foreign.png': (18, 20, 202, 63),
    'package_genre_action.png': (29, 20, 190, 63),
    'package_genre_adventure.png': (18, 25, 202, 58),
    'package_genre_animation.png': (18, 21, 202, 62),
    'package_genre_comedy.png': (21, 23, 198, 60),
    'package_genre_crime.png': (38, 22, 181, 61),
    'package_genre_documentary.png': (18, 25, 202, 58),
    'package_genre_drama.png': (30, 26, 190, 57),
    'package_genre_family.png': (32, 24, 188, 59),
    'package_genre_fantasy.png': (20, 18, 200, 66),
    'package_genre_horror.png': (19, 19, 200, 65),
    'package_genre_mystery.png': (18, 28, 202, 56),
    'package_genre_romance.png': (18, 23, 202, 60),
    'package_genre_scifi.png': (44, 18, 176, 66),
    'package_genre_thriller.png': (18, 19, 202, 64),
    'package_genre_war.png': (51, 23, 169, 61),
    'package_genre_western.png': (18, 28, 202, 56),
    'package_imdb_top.png': (34, 31, 186, 52),
    'package_indian.png': (29, 19, 190, 65),
    'package_kids.png': (45, 18, 174, 66),
    'package_max.png': (58, 29, 161, 55),
    'package_movies_r284.png': (10, 17, 207, 70),
    'package_music.png': (35, 18, 184, 65),
    'package_netflix.png': (39, 30, 181, 53),
    'package_paramount.png': (24, 33, 195, 51),
    'package_prime.png': (60, 18, 159, 66),
    'package_ramadan.png': (18, 21, 202, 63),
    'package_recent_movies_r284.png': (8, 8, 206, 71),
    'package_recent_series_r284.png': (7, 6, 208, 71),
    'package_series_r284.png': (10, 21, 210, 71),
    'package_shahid.png': (19, 18, 201, 66),
    'package_theatre.png': (18, 30, 202, 53),
    'package_tod.png': (52, 18, 167, 66),
    'package_ufc.png': (74, 29, 145, 54),
    'package_viu.png': (46, 18, 174, 66),
    'package_watchit.png': (66, 18, 153, 66),
    'package_wwe.png': (48, 13, 180, 83),
    'year_1900.png': (4, 6, 75, 27),
    'year_1901.png': (4, 6, 75, 27),
    'year_1902.png': (4, 6, 75, 27),
    'year_1903.png': (4, 6, 75, 27),
    'year_1904.png': (4, 6, 76, 27),
    'year_1905.png': (4, 6, 75, 27),
    'year_1906.png': (4, 6, 75, 27),
    'year_1907.png': (4, 6, 75, 27),
    'year_1908.png': (4, 6, 75, 27),
    'year_1909.png': (4, 6, 75, 27),
    'year_1910.png': (4, 6, 75, 27),
    'year_1911.png': (4, 6, 75, 27),
    'year_1912.png': (4, 6, 75, 27),
    'year_1913.png': (4, 6, 75, 27),
    'year_1914.png': (4, 6, 76, 27),
    'year_1915.png': (4, 6, 75, 27),
    'year_1916.png': (4, 6, 75, 27),
    'year_1917.png': (4, 6, 75, 27),
    'year_1918.png': (4, 6, 75, 27),
    'year_1919.png': (4, 6, 75, 27),
    'year_1920.png': (4, 6, 75, 27),
    'year_1921.png': (4, 6, 75, 27),
    'year_1922.png': (4, 6, 75, 27),
    'year_1923.png': (4, 6, 75, 27),
    'year_1924.png': (4, 6, 76, 27),
    'year_1925.png': (4, 6, 75, 27),
    'year_1926.png': (4, 6, 75, 27),
    'year_1927.png': (4, 6, 75, 27),
    'year_1928.png': (4, 6, 75, 27),
    'year_1929.png': (4, 6, 75, 27),
    'year_1930.png': (4, 6, 75, 27),
    'year_1931.png': (4, 6, 75, 27),
    'year_1932.png': (4, 6, 75, 27),
    'year_1933.png': (4, 6, 75, 27),
    'year_1934.png': (4, 6, 76, 27),
    'year_1935.png': (4, 6, 75, 27),
    'year_1936.png': (4, 6, 75, 27),
    'year_1937.png': (4, 6, 75, 27),
    'year_1938.png': (4, 6, 75, 27),
    'year_1939.png': (4, 6, 75, 27),
    'year_1940.png': (4, 6, 75, 27),
    'year_1941.png': (4, 6, 75, 27),
    'year_1942.png': (4, 6, 75, 27),
    'year_1943.png': (4, 6, 75, 27),
    'year_1944.png': (4, 6, 76, 27),
    'year_1945.png': (4, 6, 75, 27),
    'year_1946.png': (4, 6, 75, 27),
    'year_1947.png': (4, 6, 75, 27),
    'year_1948.png': (4, 6, 75, 27),
    'year_1949.png': (4, 6, 75, 27),
    'year_1950.png': (4, 6, 75, 27),
    'year_1951.png': (4, 6, 75, 27),
    'year_1952.png': (4, 6, 75, 27),
    'year_1953.png': (4, 6, 75, 27),
    'year_1954.png': (4, 6, 76, 27),
    'year_1955.png': (4, 6, 75, 27),
    'year_1956.png': (4, 6, 75, 27),
    'year_1957.png': (4, 6, 75, 27),
    'year_1958.png': (4, 6, 75, 27),
    'year_1959.png': (4, 6, 75, 27),
    'year_1960.png': (4, 6, 75, 27),
    'year_1961.png': (4, 6, 75, 27),
    'year_1962.png': (4, 6, 75, 27),
    'year_1963.png': (4, 6, 75, 27),
    'year_1964.png': (4, 6, 76, 27),
    'year_1965.png': (4, 6, 75, 27),
    'year_1966.png': (4, 6, 75, 27),
    'year_1967.png': (4, 6, 75, 27),
    'year_1968.png': (4, 6, 75, 27),
    'year_1969.png': (4, 6, 75, 27),
    'year_1970.png': (4, 6, 75, 27),
    'year_1971.png': (4, 6, 75, 27),
    'year_1972.png': (4, 6, 75, 27),
    'year_1973.png': (4, 6, 75, 27),
    'year_1974.png': (4, 6, 76, 27),
    'year_1975.png': (4, 6, 75, 27),
    'year_1976.png': (4, 6, 75, 27),
    'year_1977.png': (4, 6, 75, 27),
    'year_1978.png': (4, 6, 75, 27),
    'year_1979.png': (4, 6, 75, 27),
    'year_1980.png': (4, 6, 75, 27),
    'year_1981.png': (4, 6, 75, 27),
    'year_1982.png': (4, 6, 75, 27),
    'year_1983.png': (4, 6, 75, 27),
    'year_1984.png': (4, 6, 76, 27),
    'year_1985.png': (4, 6, 75, 27),
    'year_1986.png': (4, 6, 75, 27),
    'year_1987.png': (4, 6, 75, 27),
    'year_1988.png': (4, 6, 75, 27),
    'year_1989.png': (4, 6, 75, 27),
    'year_1990.png': (4, 6, 75, 27),
    'year_1991.png': (4, 6, 75, 27),
    'year_1992.png': (4, 6, 75, 27),
    'year_1993.png': (4, 6, 75, 27),
    'year_1994.png': (4, 6, 76, 27),
    'year_1995.png': (4, 6, 75, 27),
    'year_1996.png': (4, 6, 75, 27),
    'year_1997.png': (4, 6, 75, 27),
    'year_1998.png': (4, 6, 75, 27),
    'year_1999.png': (4, 6, 75, 27),
    'year_2000.png': (4, 6, 75, 27),
    'year_2001.png': (4, 6, 75, 27),
    'year_2002.png': (4, 6, 75, 27),
    'year_2003.png': (4, 6, 75, 27),
    'year_2004.png': (4, 6, 76, 27),
    'year_2005.png': (4, 6, 75, 27),
    'year_2006.png': (4, 6, 75, 27),
    'year_2007.png': (4, 6, 75, 27),
    'year_2008.png': (4, 6, 75, 27),
    'year_2009.png': (4, 6, 75, 27),
    'year_2010.png': (4, 6, 75, 27),
    'year_2011.png': (4, 6, 75, 27),
    'year_2012.png': (4, 6, 75, 27),
    'year_2013.png': (4, 6, 75, 27),
    'year_2014.png': (4, 6, 76, 27),
    'year_2015.png': (4, 6, 75, 27),
    'year_2016.png': (4, 6, 75, 27),
    'year_2017.png': (4, 6, 75, 27),
    'year_2018.png': (4, 6, 75, 27),
    'year_2019.png': (4, 6, 75, 27),
    'year_2020.png': (4, 6, 75, 27),
    'year_2021.png': (4, 6, 75, 27),
    'year_2022.png': (4, 6, 75, 27),
    'year_2023.png': (4, 6, 75, 27),
    'year_2024.png': (4, 6, 76, 27),
    'year_2025.png': (4, 6, 75, 27),
    'year_2026.png': (4, 6, 75, 27),
    'year_2027.png': (4, 6, 75, 27),
    'year_2028.png': (4, 6, 75, 27),
    'year_2029.png': (4, 6, 75, 27),
    'year_2030.png': (4, 6, 75, 27),
    'year_2031.png': (4, 6, 75, 27),
    'year_2032.png': (4, 6, 75, 27),
    'year_2033.png': (4, 6, 75, 27),
    'year_2034.png': (4, 6, 76, 27),
    'year_2035.png': (4, 6, 75, 27),
    'year_2036.png': (4, 6, 75, 27),
    'year_2037.png': (4, 6, 75, 27),
    'year_2038.png': (4, 6, 75, 27),
    'year_2039.png': (4, 6, 75, 27),
    'year_2040.png': (4, 6, 75, 27),
    'year_2041.png': (4, 6, 75, 27),
    'year_2042.png': (4, 6, 75, 27),
    'year_2043.png': (4, 6, 75, 27),
    'year_2044.png': (4, 6, 76, 27),
    'year_2045.png': (4, 6, 75, 27),
    'year_2046.png': (4, 6, 75, 27),
    'year_2047.png': (4, 6, 75, 27),
    'year_2048.png': (4, 6, 75, 27),
    'year_2049.png': (4, 6, 75, 27),
    'year_2050.png': (4, 6, 75, 27),
    'year_2051.png': (4, 6, 75, 27),
    'year_2052.png': (4, 6, 75, 27),
    'year_2053.png': (4, 6, 75, 27),
    'year_2054.png': (4, 6, 76, 27),
    'year_2055.png': (4, 6, 75, 27),
    'year_2056.png': (4, 6, 75, 27),
    'year_2057.png': (4, 6, 75, 27),
    'year_2058.png': (4, 6, 75, 27),
    'year_2059.png': (4, 6, 75, 27),
    'year_2060.png': (4, 6, 75, 27),
    'year_2061.png': (4, 6, 75, 27),
    'year_2062.png': (4, 6, 75, 27),
    'year_2063.png': (4, 6, 75, 27),
    'year_2064.png': (4, 6, 76, 27),
    'year_2065.png': (4, 6, 75, 27),
    'year_2066.png': (4, 6, 75, 27),
    'year_2067.png': (4, 6, 75, 27),
    'year_2068.png': (4, 6, 75, 27),
    'year_2069.png': (4, 6, 75, 27),
    'year_2070.png': (4, 6, 75, 27),
    'year_2071.png': (4, 6, 75, 27),
    'year_2072.png': (4, 6, 75, 27),
    'year_2073.png': (4, 6, 75, 27),
    'year_2074.png': (4, 6, 76, 27),
    'year_2075.png': (4, 6, 75, 27),
    'year_2076.png': (4, 6, 75, 27),
    'year_2077.png': (4, 6, 75, 27),
    'year_2078.png': (4, 6, 75, 27),
    'year_2079.png': (4, 6, 75, 27),
    'year_2080.png': (4, 6, 75, 27),
    'year_2081.png': (4, 6, 75, 27),
    'year_2082.png': (4, 6, 75, 27),
    'year_2083.png': (4, 6, 75, 27),
    'year_2084.png': (4, 6, 76, 27),
    'year_2085.png': (4, 6, 75, 27),
    'year_2086.png': (4, 6, 75, 27),
    'year_2087.png': (4, 6, 75, 27),
    'year_2088.png': (4, 6, 75, 27),
    'year_2089.png': (4, 6, 75, 27),
    'year_2090.png': (4, 6, 75, 27),
    'year_2091.png': (4, 6, 75, 27),
    'year_2092.png': (4, 6, 75, 27),
    'year_2093.png': (4, 6, 75, 27),
    'year_2094.png': (4, 6, 76, 27),
    'year_2095.png': (4, 6, 75, 27),
    'year_2096.png': (4, 6, 75, 27),
    'year_2097.png': (4, 6, 75, 27),
    'year_2098.png': (4, 6, 75, 27),
    'year_2099.png': (4, 6, 75, 27),
}

# Sliding sidebar on the package browser.  The native Enigma2 focus is
# controlled by LEFT/RIGHT (there is no universal mouse-hover event on STBs).
# Convert only the fixed sidebar decorations and the eight glass backgrounds to
# named widgets so visibility and available table width can be changed without
# reopening a screen or reloading its cached categories/posters.
def _autohide_package_browser_skin(base):
    import re
    side_labels=[]
    side_images=[]
    def replace_static(match):
        tag=match.group(0)
        xmatch=re.search(r'\bposition="(\d+),(\d+)"',tag)
        if not xmatch:
            return tag
        x,y=map(int,xmatch.groups())
        smatch=re.search(r'\bsize="(\d+),(\d+)"',tag)
        width=int(smatch.group(1)) if smatch else 0
        kind=tag[1:tag.index(' ')]
        if kind=='ePixmap' and x==475 and y in (215,303,391,479,567,655,743,831) and width==1340:
            slot=(y-215)//88
            return tag.replace('<ePixmap ', '<widget name="packageRowBg%d" ' % slot,1).replace(' zPosition="4"', ' scale="1" zPosition="4"',1)
        # Only elements belonging to the left sidebar; never touch content rows.
        if x+width>392 or kind not in ('eLabel','ePixmap'):
            return tag
        if kind=='eLabel':
            name='sideDecorLabel%d'%len(side_labels)
            side_labels.append(name)
            converted=tag.replace('<eLabel ', '<widget name="%s" ' % name,1)
        else:
            name='sideDecorImage%d'%len(side_images)
            side_images.append(name)
            converted=tag.replace('<ePixmap ', '<widget name="%s" ' % name,1)
        # Sidebar is above expanded package rows only while it is visible.
        converted=re.sub(r'zPosition="\d+"', 'zPosition="18"',converted)
        return converted
    new=re.sub(r'<e(?:Label|Pixmap)\b[^>]*/>', replace_static, base)
    # Existing labels and the sidebar focus also participate in reveal/hide.
    for name in ['sideSelector','serverHeading','serverName','serverNameBold',
                 'packageCaption','newMovieCaption','newSeriesCaption',
                 'count','newMovieCount','newSeriesCount'] + ['nav%d'%i for i in range(7)]:
        pattern=r'(<widget name="%s"[^>]*?zPosition=")\d+("[^>]*/>)'%name
        new,n=re.subn(pattern,r'\g<1>19\2',new)
        assert n==1, (name,n)
    new=new.replace('name="packageSelector" position="475,215" size="1340,84" alphatest="blend"',
                    'name="packageSelector" position="475,215" size="1340,84" scale="1" alphatest="blend"')
    new=new.replace('name="packageTextFocusBg" position="655,222" size="1080,66" pixmap=',
                    'name="packageTextFocusBg" position="655,222" size="1080,66" scale="1" pixmap=')
    assert len(side_labels)==6,side_labels
    assert len(side_images)==9,side_images
    assert new.count('name="packageRowBg')==8
    # Use the exact visual language of the poster pages' full-width toolbar.
    # Keep the same real actions: RED Back / GREEN Filter / YELLOW Sort /
    # BLUE Switch Server / MENU Parental, plus LEFT/RIGHT sidebar navigation.
    # Remove the obsolete four-key footer background and icons (not controls).
    new=re.sub(r'<eLabel position="475,820"[^>]*/>', '', new)
    new=re.sub(r'<ePixmap position="(?:510|760|1140|1430),832"[^>]*/>', '', new)
    # The old menu-hint backing plate is no longer needed.  The mode hint can
    # still appear at Y=912 when rearranging a package.
    new=re.sub(r'<eLabel position="710,908"[^>]*/>', '', new)
    for name in ('back','info'):
        new=re.sub(r'(<widget name="%s" )[^>]*(/>)' % name,
                   r'\g<1>position="1,1078" size="1,1" font="Regular;1" transparent="1" \g<2>', new, count=1)
    # Existing Label widgets continue to reflect the real active sort/server.
    new=re.sub(r'(<widget name="sort" )[^>]*(/>)',
               r'\g<1>position="691,1054" size="230,19" font="Regular;15" foregroundColor="#B9C6CF" transparent="1" halign="left" valign="center" noWrap="1" zPosition="39" \g<2>', new, count=1)
    new=re.sub(r'(<widget name="open" )[^>]*(/>)',
               r'\g<1>position="997,1054" size="225,19" font="Regular;15" foregroundColor="#B9C6CF" transparent="1" halign="left" valign="center" noWrap="1" zPosition="39" \g<2>', new, count=1)
    footer = ('<ePixmap position="20,1027" size="1880,52" pixmap="'
              '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/'
              'poster_actions_toolbar_packages.png" alphatest="blend" zPosition="35" />')
    new=new.replace('</screen>',footer+'\n</screen>',1)
    assert new.count('poster_actions_toolbar_packages.png')==1
    return new,side_labels,side_images

class HomePackageBrowserScreen(Screen):
    skin = PROFESSIONAL_PACKAGE_BROWSER_SKIN
    CARD_ROW_Y = [215,303,391,479,567,655,743,831]
    VISIBLE_ROWS = 8
    NAV_Y = [119,191,263,335,407,479,551]

    def __init__(self, session, source, kind):
        self.kind="series" if str(kind)=="series" else "vod"
        # Glass package bars are an MOVIES-only experiment; Series remains exactly as r66.
        _base_skin = PROFESSIONAL_PACKAGE_BROWSER_MOVIES_GLASS_SKIN if self.kind=="vod" else PROFESSIONAL_PACKAGE_BROWSER_SERIES_GLASS_SKIN
        self.skin, self._sidebarDecorationLabels, self._sidebarDecorationImages = _autohide_package_browser_skin(_base_skin)
        from .font_preferences import read_preferences, scale_skin_text
        self.skin = scale_skin_text(self.skin, read_preferences()["font_scale"])
        Screen.__init__(self, session)
        self.source=dict(source or {})
        self.rows=[]
        self.index=0
        self.pageStart=0
        # Restore the last package order selected with YELLOW.
        # Keep Movies and TV Shows independently per server.
        _package_state = _load_content_package_controls(self.source, self.kind)
        _saved_sort = str(_package_state.get("sort") or "latest")
        self.sortMode = _saved_sort if _saved_sort in ("original", "latest", "az", "za", "custom") else "latest"
        self.focusMode="packages"
        self.navIndex=3
        self["background"]=Pixmap()
        for name in self._sidebarDecorationLabels:
            self[name]=Label("")
        for name in self._sidebarDecorationImages:
            self[name]=Pixmap()
        for row_index in range(self.VISIBLE_ROWS):
            self["packageRowBg%d" % row_index]=Pixmap()
        self._sidebarVisible=True
        self["sideSelector"]=Pixmap()
        self["packageSelector"]=Pixmap()
        self["packageTextFocusBg"]=Pixmap()
        self["clock"]=Label("")
        self["date"]=Label("")
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["count"]=Label("0")
        self["packageCaption"]=Label("PACKAGES")
        self["serverHeading"]=Label("ACTIVE SERVER")
        self["newMovieCaption"]=Label("NEW MOVIES")
        self["newSeriesCaption"]=Label("NEW SERIES")
        self["newMovieCount"]=Label("—")
        self["newSeriesCount"]=Label("—")
        self["serverName"]=Label("")
        self["serverNameBold"]=Label("")
        self["back"]=Label("BACK")
        self["open"]=Label("Change Server")
        self["info"]=Label("PACKAGE FILTER")
        self["sort"]=Label("SORT: LATEST")
        self["packageFocusBold"]=Label("")
        self["packageMenuHint"]=Label("")
        self.moveMode=False
        self._pendingPackageOpen=None
        for i,name in enumerate(["LIVE TV","MOVIES","TV SHOWS","PACKAGES","GENRE","FAVORITES","SETTINGS"]):
            self["nav%d"%i]=Label(name)
        for i in range(self.VISIBLE_ROWS):
            self["row%d"%i]=Label("")
            self["meta%d"%i]=Label("")
            self["logo%d"%i]=Pixmap()
            self["desc%d"%i]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions","MenuActions"],{
            "ok":self.choose,"cancel":self.close,"red":self.close,
            "up":self.up,"down":self.down,"left":self.left,"right":self.right,
            "pageUp":self.pageUp,"pageDown":self.pageDown,
            "green":self.openPackageFilter,
            "yellow":self.togglePackageSort,"blue":self.serverSwitch,"menu":self.openPackageMenu
        },-1)
        self._loadToken=0
        self._warmGeneration=0
        self._warmDone=set()
        self._warmFailures={}
        self._warmPageKey=None
        self._warmTimer=eTimer()
        _connect_timer(self._warmTimer,self._startVisiblePackageWarm)
        self.onClose.append(self._stopPackageWarm)
        # Recent Added prewarm only after the package-list first paint. This
        # does not alter the existing visible-package image/content queues.
        self._recentWarmTimer=eTimer()
        _connect_timer(self._recentWarmTimer,self._warmRecentAfterPaint)
        self.onClose.append(self._recentWarmTimer.stop)
        self._loadResult=None
        self._loadTimer=eTimer()
        _connect_timer(self._loadTimer,self._finishLoad)
        # r284: package list paints text first. Logos are decoded only after the
        # page is already visible, one slot at a time, and then kept in a tiny
        # in-memory slot/path cache so navigation does not decode the same PNG
        # repeatedly. This keeps package opening independent from logo work.
        self._logoTimer=eTimer()
        _connect_timer(self._logoTimer,self._loadNextVisibleLogo)
        self._logoPathCache={}
        self._slotLogoState={}
        self._logoQueue=[]
        self._logoRequests={}
        self.clockTimer=eTimer()
        _connect_timer(self.clockTimer,self.updateClock)
        # Statistics are computed from existing provider caches off the UI thread.
        self._todayStatsTimer=eTimer()
        _connect_timer(self._todayStatsTimer,self._refreshTodayStats)
        self._todayStatsResult=None
        self._todayStatsBusy=False
        self._todayStatsTries=0
        self.onLayoutFinish.append(self.start)

    def start(self):
        bg=os.path.join(PLUGIN_PATH,"skins","home","home_packages_luxury_movies.jpg" if self.kind=="vod" else "home_packages_luxury_series.jpg")
        focus=os.path.join(PLUGIN_PATH,"skins","packages","movie_package_card_focus_r60.png" if self.kind=="vod" else "series_package_card_focus_r60.png")
        try:self["background"].instance.setPixmapFromFile(bg)
        except Exception:pass
        try:self["packageSelector"].instance.setPixmapFromFile(focus)
        except Exception:pass
        try:self["packageTextFocusBg"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages","package_text_focus_bg_r180.png"))
        except Exception:pass
        if self.kind=="series":
            try:self["title"].instance.setForegroundColor(parseColor("#B48CFF"))
            except Exception:pass
            try:self["count"].instance.setForegroundColor(parseColor("#F3D7A5"))
            except Exception:pass
        else:
            try:self["title"].instance.setForegroundColor(parseColor("#E5B243"))
            except Exception:pass
            try:self["count"].instance.setForegroundColor(parseColor("#F3D7A5"))
            except Exception:pass
        # Show only the currently active server name on both Movies and TV Shows package pages.
        try:
            active_name = str(self.source.get("name") or self.source.get("title") or "").strip()
            self["serverName"].setText(active_name[:32])
            self["serverNameBold"].setText(active_name[:32])
            self["open"].setText(active_name[:23] or "Change Server")
        except Exception:
            pass
        self.updateClock()
        try:self.clockTimer.start(30000)
        except Exception:pass
        # Packages get the full-width table by default.  LEFT reveals the
        # sidebar, RIGHT returns to the wide list without touching data caches.
        self._setPackageSidebarVisible(False, force=True)
        self._renderNavFocus()
        try:self["packageFocusBold"].hide()
        except Exception:pass
        self.load()
        # Packages opens with its sidebar hidden.  Do not scan every movie and
        # series cache to compute invisible sidebar statistics on every entry.
        # The first LEFT reveal requests the statistics only when needed.

    def _refreshTodayStats(self):
        # Persistent local observation of new IDs; no provider-wide network scan.
        if self._todayStatsResult is not None:
            result=self._todayStatsResult
            self._todayStatsResult=None
            for kind,widget in (("vod","newMovieCount"),("series","newSeriesCount")):
                try:self[widget].setText(result.get(kind) or "—")
                except Exception:pass
        if self._todayStatsBusy:
            try:self._todayStatsTimer.start(1000,True)
            except Exception:pass
            return
        if self._todayStatsTries >= 12:return
        self._todayStatsTries+=1
        self._todayStatsBusy=True
        source=dict(self.source or {})
        def worker():
            results={"vod":"—","series":"—"}
            try:
                import hashlib, json
                from datetime import datetime
                from Plugins.Extensions.TiviMateE2 import filters as f
                today=datetime.now().strftime("%Y-%m-%d")
                identity=hashlib.sha256(str(_source_identity(source)).encode("utf-8")).hexdigest()[:24]
                folder=os.path.join(get_cache_root(),"today_observations")
                if not os.path.isdir(folder):os.makedirs(folder)
                for kind in ("vod","series"):
                    try:
                        # Prefer a full cached catalog. Fall back to available
                        # category caches, never triggering network requests.
                        key=f._catalog_key(source,kind)
                        mem=f._RAM_CATALOG_CACHE.get(key)
                        if mem is not None:items=list(mem[0] or []);complete=True
                        else:
                            items,_=f._load_cache_state(f._catalog_cache_path(source,kind))
                            complete=items is not None
                            items=list(items or [])
                        allowed=f.get_allowed_category_ids(source,kind)
                        if allowed is not None or not complete:
                            cats=[]
                            if allowed is not None:cats=[str(x) for x in allowed]
                            else:
                                ck="%s|categories|%s"%(f.source_filter_key(source),kind)
                                cached=f._RAM_CATEGORY_CACHE.get(ck)
                                if cached is not None:categories=list(cached[0] or [])
                                else:categories,_=f._load_cache_state(f._categories_cache_path(source,kind))
                                cats=[str(c.get("category_id") or "") for c in (categories or []) if isinstance(c,dict)]
                            complete=bool(cats)
                            items=[]
                            for cid in set(cats):
                                if not cid:continue
                                rows,origin=f.peek_category_streams_cache(source,kind,cid)
                                if origin=="miss":complete=False
                                items.extend(rows or [])
                        ids=set()
                        for row in items:
                            if not isinstance(row,dict):continue
                            ident=row.get("series_id") if kind=="series" else row.get("stream_id")
                            if ident is None:ident=row.get("id")
                            if ident is None:continue
                            ids.add(str(ident))
                        if not ids:continue
                        path=os.path.join(folder,identity+"_"+kind+".json")
                        state={}
                        try:
                            with open(path,"r") as fh:state=json.load(fh)
                            if not isinstance(state,dict):state={}
                        except Exception:pass
                        previous=set(str(x) for x in state.get("seen",[]))
                        counts=state.get("counts",{})
                        if not isinstance(counts,dict):counts={}
                        if not previous:
                            # First scan establishes baseline; it cannot reconstruct
                            # additions earlier today without provider timestamps.
                            counts[today]=0
                        else:
                            counts[today]=int(counts.get(today,0))+len(ids-previous)
                        previous.update(ids)
                        counts={k:v for k,v in counts.items() if k>=today}
                        payload={"seen":sorted(previous),"counts":counts,"complete":bool(complete)}
                        tmp=path+".tmp"
                        with open(tmp,"w") as fh:json.dump(payload,fh,separators=(",",":"))
                        os.rename(tmp,path)
                        value=str(counts[today])
                        results[kind]=value if complete else value+"+"
                    except Exception:
                        continue
            except Exception:pass
            self._todayStatsResult=results
            self._todayStatsBusy=False
        t=threading.Thread(target=worker,name="TiviMateTodayObservations")
        t.daemon=True
        t.start()
        try:self._todayStatsTimer.start(3000,True)
        except Exception:pass

    def _setPackageSidebarVisible(self, visible, force=False):
        """Show the sidebar only when it has focus; enlarge the list otherwise.

        Only native widget geometry changes here.  No category refresh, artwork
        lookup, PNG downloads, or disk cache operations are triggered.
        """
        visible=bool(visible)
        if not force and visible==getattr(self,"_sidebarVisible",True):
            return
        self._sidebarVisible=visible
        if visible and not self._todayStatsTries and not self._todayStatsBusy:
            try:self._todayStatsTimer.start(750,True)
            except Exception:pass
        names=(list(self._sidebarDecorationLabels)+list(self._sidebarDecorationImages)+
               ["sideSelector","serverHeading","serverName","serverNameBold",
                "packageCaption","newMovieCaption","newSeriesCaption",
                "count","newMovieCount","newSeriesCount"]+
               ["nav%d"%i for i in range(7)])
        for name in names:
            try:
                if visible:self[name].show()
                else:self[name].hide()
            except Exception:pass
        shift=0 if visible else -360
        extra=0 if visible else 360
        try:
            self["title"].instance.move(ePoint(sx(500+shift),sy(80)))
            self["title"].instance.resize(eSize(sx(930+extra),sy(70)))
            self["subtitle"].instance.move(ePoint(sx(505+shift),sy(160)))
            self["subtitle"].instance.resize(eSize(sx(1000+extra),sy(34)))
        except Exception:pass
        for slot,y in enumerate(self.CARD_ROW_Y):
            positions=[("packageRowBg%d"%slot,475+shift,y,1340+extra,84),
                       ("row%d"%slot,740+shift,y+7,680+extra,42),
                       ("desc%d"%slot,792+shift,y+44,615+extra,27)]
            for name,x,py,w,h in positions:
                try:
                    self[name].instance.move(ePoint(sx(x),sy(py)))
                    self[name].instance.resize(eSize(sx(w),sy(h)))
                except Exception:pass
        for name,x,y,w,h in (("packageSelector",475+shift,self.CARD_ROW_Y[0],1340+extra,84),
                             ("packageTextFocusBg",655+shift,self.CARD_ROW_Y[0]+7,1080+extra,66),
                             ("packageFocusBold",740+shift,self.CARD_ROW_Y[0]+7,680+extra,42)):
            try:
                self[name].instance.move(ePoint(sx(x),sy(y)))
                self[name].instance.resize(eSize(sx(w),sy(h)))
            except Exception:pass
        # Existing decoded local logos are simply repositioned on focus change.
        for slot in range(self.VISIBLE_ROWS):
            state=self._slotLogoState.get(slot)
            if state and len(state)>1 and state[1]:
                self._renderPackageLogo(slot,state[1])
        # Keep the active row highlighted, with no data or logo queue restart.
        if self.rows:
            selected=max(0,min(self.VISIBLE_ROWS-1,int(self.index-self.pageStart)))
            try:self["packageSelector"].instance.move(ePoint(sx(475+shift),sy(self.CARD_ROW_Y[selected])))
            except Exception:pass
            try:self["packageTextFocusBg"].instance.move(ePoint(sx(655+shift),sy(self.CARD_ROW_Y[selected]+7)))
            except Exception:pass
            try:self["packageFocusBold"].instance.move(ePoint(sx(740+shift),sy(self.CARD_ROW_Y[selected]+7)))
            except Exception:pass

    def _renderNavFocus(self):
        try:
            y=self.NAV_Y[self.navIndex]
            self["sideSelector"].instance.move(ePoint(sx(15),sy(y)))
            if self.focusMode=="nav":self["sideSelector"].show()
            else:self["sideSelector"].hide()
        except Exception:
            pass
        # Same text color everywhere; the moving gold glass bar is the only focus.
        for i in range(7):
            try:
                self["nav%d"%i].instance.setForegroundColor(parseColor("#FFFFFF" if i==self.navIndex and self.focusMode=="nav" else "#E8E8E8"))
            except Exception:
                pass

    def _packageGenreSelected(self, selected=None):
        if not selected:
            return
        try:
            kind = selected[1] if isinstance(selected, (tuple, list)) else str(selected)
            self.session.open(MovieGenresScreen, dict(self.source), kind)
        except Exception as exc:
            self.session.open(MessageBox, tr("Unable to open Genres")+":\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def _openNavItem(self):
        if self.navIndex==0:
            self.session.open(MediaScreen,self.source,"live"); return
        if self.navIndex==1:
            self.session.open(configured_movies_screen(FastMoviesContentScreen, "vod"),self.source,"vod"); return
        if self.navIndex==2:
            self.session.open(configured_movies_screen(FastMoviesContentScreen, "series"),self.source,"series"); return
        if self.navIndex==3:
            self.focusMode="packages"
            self._setPackageSidebarVisible(False)
            self._renderNavFocus()
            self.render()
            return
        if self.navIndex==4:
            self.session.openWithCallback(self._packageGenreSelected,TiviMateGenreSelectScreen); return
        if self.navIndex==5:
            self.session.open(FavoritesScreen); return
        if self.navIndex==6:
            self.session.open(SettingsDashboard); return

    def left(self):
        if self.focusMode!="nav":
            self.focusMode="nav"
            self._setPackageSidebarVisible(True)
            self._renderNavFocus()

    def right(self):
        if self.focusMode!="packages":
            self.focusMode="packages"
            self._setPackageSidebarVisible(False)
            self._renderNavFocus()
            self.render()

    def updateClock(self):
        now=datetime.now()
        try:self["clock"].setText(now.strftime("%I:%M %p").lstrip("0"))
        except Exception:pass
        try:self["date"].setText(now.strftime("%A, %d %b %Y"))
        except Exception:pass

    def _brandLogo(self,name):
        # r284: only resolve lightweight package assets. Do not fall back to the
        # old server/filter television icons; unknown collections use the new
        # Movies / TV Shows collection mark instead. Resolution is cached.
        cache_key=(self.kind,str(name or ""))
        if cache_key in self._logoPathCache:
            return self._logoPathCache.get(cache_key) or None
        # Package logos ship with the plugin: resolve a local badge only.
        # No per-server copies, hashes, background logo jobs or image downloads.
        from .package_logos import package_popup_logo_path
        branded = package_popup_logo_path(name, self.kind)
        if not branded:
            branded = package_browser_logo_for_key("movies" if self.kind == "vod" else "series")
        if branded and not os.path.exists(branded):
            branded=None
        self._logoPathCache[cache_key]=branded or ""
        return branded

    def _rowLogo(self,row):
        try:
            name,cid=row[0],str(row[1] or "")
        except Exception:
            return None
        if cid == "__recent_added__":
            return package_browser_logo_for_key("recent_movies" if self.kind == "vod" else "recent_series")
        if cid == "__netflix__":
            return package_browser_logo_for_key("netflix")
        if cid == "__prime_video__":
            return package_browser_logo_for_key("prime")
        # Directly show the bundled image. Keep the slot-level pixmap cache.
        return self._brandLogo(name)

    def _queueVisibleLogos(self,delay=180):
        # Text/cards are already visible when this starts. Only visible slots are
        # decoded, then further slots are handled after navigation.
        q=[]
        for slot in range(self.VISIBLE_ROWS):
            pos=self.pageStart+slot
            if 0 <= pos < len(self.rows):
                q.append((slot,pos))
        self._logoQueue=q
        try:
            self._logoTimer.stop()
        except Exception:
            pass
        if q:
            try:self._logoTimer.start(int(delay),True)
            except Exception:pass

    def _renderPackageLogo(self, slot, path):
        # Render the bundled PNG directly, scaled to a smaller consistent
        # 118x26 visible-artwork footprint without distorting its aspect ratio.
        widget_name = "logo%d" % int(slot)
        widget = self[widget_name]
        self._logoRequests[widget_name] = path
        if path and os.path.isfile(path):
            try:
                with open(path, "rb") as image_file:
                    header = image_file.read(24)
                if header[:8] != b"\x89PNG\r\n\x1a\n":
                    raise ValueError("not a PNG")
                import struct
                iw, ih = struct.unpack(">II", header[16:24])
                if iw <= 0 or ih <= 0:
                    raise ValueError("invalid logo dimensions")
                bb = _PACKAGE_BADGE_VISIBLE_BOUNDS.get(os.path.basename(path),
                                                       (0, 0, iw, ih))
                left, top, right, bottom = bb
                if right <= left or bottom <= top:
                    raise ValueError("invalid visible bounds")
                # One factor for both axes: NEVER deform Netflix, Disney, etc.
                factor = min(118.0 / (right - left),
                             26.0 / (bottom - top), 1.10, 500.0 / iw)
                width = max(1, int(round(iw * factor)))
                height = max(1, int(round(ih * factor)))
                # Keep its visible centre aligned with the original slot.
                visible_mid_x = (left + right) * 0.5 * factor
                visible_mid_y = (top + bottom) * 0.5 * factor
                x = int(round(610 - (0 if self._sidebarVisible else 360) - visible_mid_x))
                y = int(round(self.CARD_ROW_Y[int(slot)] + 42 - visible_mid_y))
                if widget.instance:
                    widget.instance.resize(eSize(sx(width), sy(height)))
                    widget.instance.move(ePoint(sx(x), sy(y)))
                    widget.instance.setPixmapFromFile(path)
                    widget.show()
                    return
            except Exception:
                pass
        try: widget.hide()
        except Exception: pass

    def _loadNextVisibleLogo(self):
        if not self._logoQueue:
            return
        slot,pos=self._logoQueue.pop(0)
        try:
            if pos < 0 or pos >= len(self.rows) or pos != self.pageStart+slot:
                raise ValueError("stale logo slot")
            row=self.rows[pos]
            path=self._rowLogo(row)
            state=(str(row[1] or ""),path or "")
            if self._slotLogoState.get(slot) != state:
                if path:
                    self._renderPackageLogo(slot, path)
                else:
                    self._logoRequests.pop("logo%d" % slot, None)
                    self["logo%d"%slot].hide()
                self._slotLogoState[slot]=state
        except Exception:
            try:
                self._logoRequests.pop("logo%d" % slot, None)
                self["logo%d"%slot].hide()
            except Exception:pass
        if self._logoQueue:
            try:self._logoTimer.start(85,True)
            except Exception:pass

    def load(self):
        self._stopPackageWarm()
        try:
            self._recentWarmTimer.stop()
        except Exception:
            pass
        self._warmDone=set()
        self._warmFailures={}
        self._warmPageKey=None
        self._loadToken+=1
        token=self._loadToken
        source=dict(self.source)
        kind=self.kind
        self._loadResult=None
        def worker():
            try:
                cats,origin=get_cached_categories(source,kind,get_source_client(source),wait_for_server=True)
                cats=filter_categories(source,kind,cats or [])
                rows=[(
                    "RECENT ADDED",
                    "__recent_added__",
                    "",
                    "LATEST " + ("MOVIES" if kind=="vod" else "SERIES"),
                    10**18,
                    -1
                )]
                # Load Latest timestamps once per catalogue instead of one disk
                # read + JSON decode for each of potentially hundreds of packages.
                try:
                    _latest_saved=load_json(_genre_cache_file("latest_order.json"),{}) or {}
                    _latest_scope=_content_package_control_key(source,kind)
                    _latest_scope_data=_latest_saved.get(_latest_scope,{}) or {}
                    if not isinstance(_latest_scope_data,dict): _latest_scope_data={}
                except Exception:
                    _latest_scope_data={}
                for order,x in enumerate(cats):
                    name=x.get("category_name") or "Other"
                    cid=str(x.get("category_id") or "")
                    raw=x.get("count") or x.get("num") or x.get("total") or x.get("items_count") or ""
                    meta=(str(raw)+" "+("MOVIES" if kind=="vod" else "SHOWS")) if raw not in ("",None) else ""
                    # PACKAGES Latest uses the exact same persisted real-content
                    # timestamp cache as GENRE. Never infer age from category_id.
                    try: newest_key=int(_latest_scope_data.get(cid,0) or 0)
                    except Exception: newest_key=0
                    # r284: do not decode or even resolve row logos while the
                    # package catalogue is being built. Text opens first.
                    rows.append((name,cid,"",meta,newest_key,order))
                self._loadResult=(token,rows,"")
            except Exception as exc:
                self._loadResult=(token,[],str(exc))
        t=threading.Thread(target=worker,name="TiviMatePackagesCards")
        t.daemon=True
        t.start()
        try:self._loadTimer.start(100,False)
        except Exception:pass

    def _finishLoad(self):
        result=self._loadResult
        if not result:
            try:self._loadTimer.start(100,False)
            except Exception:pass
            return
        self._loadResult=None
        token,rows,error=result
        if token!=self._loadToken:return
        if error:
            self.rows=[]
            self["count"].setText("0")
            self["row0"].setText("Unable to load packages")
            return
        self.rows=rows or []
        _state=_load_content_package_controls(self.source,self.kind)
        _saved_sort=str(_state.get("sort") or self.sortMode or "latest")
        if _saved_sort in ("original","latest","az","za","custom"):
            self.sortMode=_saved_sort
        self._applyPackageSort(reset=True)
        self["count"].setText(str(len([r for r in self.rows if not str(r[1]).startswith("__")])))
        self.render()
        # Do not start the Recent Add provider-wide refresh just because the
        # user opened Packages.  Recent itself reads last-good caches and owns
        # its refresh policy; this list must not trigger an unrelated scan.

    def _warmRecentAfterPaint(self):
        # The Recent snapshot is refreshed in its own bounded background
        # thread. Merely reading the clock and starting the worker is done here;
        # never enumerate the provider's catalogue from the GUI thread.
        try:
            category_ids = [str(row[1]) for row in self.rows
                            if len(row) > 1 and str(row[1]) and
                            not str(row[1]).startswith("__")]
            _warm_recent_media_cache(dict(self.source), self.kind, category_ids)
        except Exception:
            pass

    def _prefetchPackageContents(self):
        # Debounced: only visible packages and two neighbours, never all packages.
        # Old worker generations stop when the page or source changes.
        if self.source.get("type") not in ("xtream", "stalker"):
            return
        if not self.rows:
            return
        self._warmGeneration = getattr(self, "_warmGeneration", 0) + 1
        try: self._warmTimer.stop()
        except Exception: pass
        try: self._warmTimer.start(280, True)
        except Exception: self._startVisiblePackageWarm()

    def _startVisiblePackageWarm(self):
        gen=getattr(self, "_warmGeneration", 0)
        token=self._loadToken
        source=dict(self.source or {})
        kind=self.kind
        start=max(0,int(self.pageStart or 0))
        limit=min(len(self.rows),start+8)
        ids=[]
        for pos in range(start,limit):
            try: cid=str(self.rows[pos][1] or "").strip()
            except Exception: cid=""
            if cid and not cid.startswith("__") and cid not in ids:
                ids.append(cid)
        done_ids=getattr(self,"_warmDone",set())
        failures=getattr(self,"_warmFailures",{})
        now=time.time()
        ids=[cid for cid in ids if cid not in done_ids and now-failures.get(cid,0)>90]
        if not ids: return
        def worker():
            try: client=get_source_client(source)
            except Exception: return
            changed=False
            for cid in ids:
                if gen!=getattr(self,"_warmGeneration",None) or token!=self._loadToken:
                    return
                try:
                    items,origin=get_category_streams(source,kind,client,cid,use_cache=True,wait_for_server=True)
                    if items:
                        # Do not ever treat an empty error reply as warm/success.
                        done_ids.add(cid)
                        failures.pop(cid,None)
                        changed=True
                    else:
                        failures[cid]=time.time()
                except Exception:
                    failures[cid]=time.time()
                time.sleep(0.03)
            if changed and self.sortMode=="latest" and token==self._loadToken:
                try:
                    if reactor: reactor.callFromThread(self._refreshLatestPackageOrder)
                except Exception: pass
        t=threading.Thread(target=worker,name="TiviMateVisiblePackageWarm")
        t.daemon=True
        t.start()

    def _stopPackageWarm(self):
        self._warmGeneration=getattr(self,"_warmGeneration",0)+1
        try:self._warmTimer.stop()
        except Exception:pass

    def _mediaLatestStamp(self, item):
        # Same Latest timestamp resolver used by GENRE.
        if not isinstance(item,dict): return 0
        import datetime
        def _stamp(value):
            if value in (None,""): return 0
            try:
                n=int(float(value))
                if n>100000000000: n//=1000
                if n>100000000: return n
            except Exception: pass
            txt=str(value).strip().replace("Z","").replace("T"," ")
            for fmt,size in (("%Y-%m-%d %H:%M:%S",19),("%Y-%m-%d",10),("%Y/%m/%d %H:%M:%S",19),("%Y/%m/%d",10)):
                try: return int(time.mktime(datetime.datetime.strptime(txt[:size],fmt).timetuple()))
                except Exception: pass
            return 0
        for key in ("added","added_timestamp","added_at","date_added","created_at","timestamp"):
            ts=_stamp(item.get(key))
            if ts: return ts
        for key in ("release_date","releaseDate","releasedate","release_date_utc","first_air_date"):
            ts=_stamp(item.get(key))
            if ts: return ts
        try:
            year=int(str(item.get("year") or "")[:4])
            if 1800<=year<=2200: return int(time.mktime(datetime.datetime(year,1,1).timetuple()))
        except Exception: pass
        return 0

    def _refreshLatestPackageOrder(self):
        # Same rule as GENRE: newest real title inside each package wins.
        # Cache first; server is contacted only when that package has no cached catalogue.
        if self.sortMode!="latest": return
        token=self._loadToken
        source=dict(self.source or {})
        kind=self.kind
        rows=list(self.rows or [])
        def worker():
            try: client=get_source_client(source)
            except Exception: client=None
            resolved={}
            for row in rows:
                if token!=self._loadToken or self.sortMode!="latest": return
                try: cid=str(row[1] or "")
                except Exception: cid=""
                if not cid or cid.startswith("__"):
                    continue
                try:
                    from .filters import peek_category_streams_cache
                    items,_=peek_category_streams_cache(source,kind,cid)
                    if not items: continue  # Retain saved Latest for unknown packages.
                    latest=max([self._mediaLatestStamp(x) for x in list(items)] or [0])
                except Exception:
                    continue
                resolved[cid]=int(latest or 0)
            if not resolved or token!=self._loadToken or self.sortMode!="latest": return
            try:
                latest_file=_genre_cache_file("latest_order.json")
                latest_data=load_json(latest_file,{}) or {}
                scope=_content_package_control_key(source,kind)
                scope_data=latest_data.get(scope,{}) or {}
                if not isinstance(scope_data,dict): scope_data={}
                scope_data.update(resolved)
                latest_data[scope]=scope_data
                save_json(latest_file,latest_data)
            except Exception:
                pass
            def done():
                if token!=self._loadToken or self.sortMode!="latest": return
                old_index=int(self.index or 0)
                selected_id=""
                try:
                    if self.rows and 0<=old_index<len(self.rows): selected_id=str(self.rows[old_index][1] or "")
                except Exception: pass
                updated=[]
                for row in self.rows:
                    vals=list(row)
                    cid=str(vals[1] or "") if len(vals)>1 else ""
                    if cid in resolved and len(vals)>4: vals[4]=resolved[cid]
                    updated.append(tuple(vals))
                self.rows=updated
                self._applyPackageSort(reset=False)
                if selected_id:
                    try:self.index=next(i for i,x in enumerate(self.rows) if str(x[1] or "")==selected_id)
                    except Exception:self.index=min(old_index,max(0,len(self.rows)-1))
                else:self.index=min(old_index,max(0,len(self.rows)-1))
                if self.index<self.pageStart:self.pageStart=self.index
                elif self.index>=self.pageStart+self.VISIBLE_ROWS:self.pageStart=max(0,self.index-(self.VISIBLE_ROWS-1))
                self.render()
            try: reactor.callFromThread(done)
            except Exception: done()
        t=threading.Thread(target=worker,name="TiviMatePackagesLatestRealContent")
        t.daemon=True
        t.start()

    def _applyPackageSort(self, reset=False):
        state=_load_content_package_controls(self.source,self.kind)
        custom_order=list(state.get("order") or [])
        if self.sortMode=="custom" and custom_order:
            rank=dict((cid,i) for i,cid in enumerate(custom_order))
            self.rows.sort(key=lambda row:(rank.get(str(row[1]),10**6), str(row[0] or "").casefold()))
            self["sort"].setText("MOVE")
            if reset:
                self.index=0; self.pageStart=0
            return
        pin_order={"__recent_added__":0, "__netflix__":1, "__prime_video__":2}
        pinned = [row for row in self.rows if str(row[1]) in pin_order]
        pinned.sort(key=lambda row: pin_order.get(str(row[1]), 99))
        normal = [row for row in self.rows if str(row[1]) not in pin_order]
        if self.sortMode=="az":
            normal.sort(key=lambda row: str(row[0] or "").casefold())
            self["sort"].setText("SORT: A-Z")
        elif self.sortMode=="za":
            normal.sort(key=lambda row: str(row[0] or "").casefold(), reverse=True)
            self["sort"].setText("SORT: Z-A")
        elif self.sortMode=="original":
            # Preserve the provider/server category order exactly as received.
            normal.sort(key=lambda row: row[5])
            self["sort"].setText("SORT: ORIGINAL")
        else:
            # Same Latest rule as GENRE: newest real content timestamp first.
            # Unknown/undated packages remain behind dated packages in provider order.
            normal.sort(key=lambda row:(int(row[4] or 0), -int(row[5] or 0)), reverse=True)
            self["sort"].setText("SORT: LATEST")
        self.rows = pinned + normal
        if reset:
            self.index=0
            self.pageStart=0

    def togglePackageSort(self):
        # Keep the original PACKAGES interaction: YELLOW cycles the order
        # directly on the same screen; never open a PACKAGE ORDER popup.
        modes=("original","latest","az","za")
        try:
            pos=modes.index(self.sortMode)
        except Exception:
            pos=0
        self.sortMode=modes[(pos+1)%len(modes)]
        state=_load_content_package_controls(self.source,self.kind)
        state["sort"]=self.sortMode
        _save_content_package_controls(self.source,self.kind,state)
        self._applyPackageSort(reset=True)
        self.render()
        if self.sortMode=="latest":
            self._refreshLatestPackageOrder()

    def render(self):
        if self.rows:
            if self.index<self.pageStart:self.pageStart=self.index
            if self.index>=self.pageStart+self.VISIBLE_ROWS:self.pageStart=self.index-(self.VISIBLE_ROWS-1)
        for slot in range(self.VISIBLE_ROWS):
            pos=self.pageStart+slot
            row=self.rows[pos] if 0<=pos<len(self.rows) else None
            if row:
                name,cid,logo,meta=row[:4]
                self["row%d"%slot].setText(name)
                self["meta%d"%slot].setText(meta or ("MOVIES" if self.kind=="vod" else "SERIES"))
                if cid=="__netflix__":
                    self["desc%d"%slot].setText("Netflix Collection")
                elif cid=="__prime_video__":
                    self["desc%d"%slot].setText("Prime Video Collection")
                else:
                    self["desc%d"%slot].setText("Movies Collection" if self.kind=="vod" else "Series Collection")
                # r284: never make the initial card paint wait on PNG decode.
                # Keep an already-cached logo only if this exact row still owns
                # the slot; otherwise paint text first and defer the logo.
                expected=(str(cid or ""),)
                state=self._slotLogoState.get(slot)
                if not state or state[:1] != expected:
                    self["logo%d"%slot].hide()
            else:
                self["row%d"%slot].setText("")
                self["meta%d"%slot].setText("")
                self["desc%d"%slot].setText("")
                self["logo%d"%slot].hide()
        # Keep every non-selected package quiet and readable.  The focused row
        # gets a local dark glass strip, slightly larger title and brighter meta.
        for slot in range(self.VISIBLE_ROWS):
            try:
                self["row%d"%slot].show()
                self["row%d"%slot].instance.setFont(gFont("Regular",27))
                self["row%d"%slot].instance.setForegroundColor(parseColor("#F0F0F0"))
                self["desc%d"%slot].instance.setForegroundColor(parseColor("#C8BFD2"))
                self["meta%d"%slot].instance.setForegroundColor(parseColor("#D7D0E1"))
            except Exception:
                pass
        if self.rows and self.focusMode=="packages":
            slot=self.index-self.pageStart
            try:
                self["packageSelector"].instance.move(ePoint(sx(475 - (0 if self._sidebarVisible else 360)),sy(self.CARD_ROW_Y[slot])))
            except Exception:pass
            try:
                self["packageTextFocusBg"].instance.move(ePoint(sx(655 - (0 if self._sidebarVisible else 360)),sy(self.CARD_ROW_Y[slot]+7)))
                self["packageTextFocusBg"].show()
            except Exception:pass
            try:
                self["row%d"%slot].instance.setFont(gFont("Regular",31))
                self["row%d"%slot].instance.setForegroundColor(parseColor("#FFD34E"))
                self["desc%d"%slot].instance.setForegroundColor(parseColor("#FFF1BF"))
                self["meta%d"%slot].instance.setForegroundColor(parseColor("#FFD34E"))
                focused_name=str(self.rows[self.index][0] or "")
                self["packageFocusBold"].setText(focused_name)
                self["row%d"%slot].hide()
                self["packageFocusBold"].instance.move(ePoint(sx(740 - (0 if self._sidebarVisible else 360)),sy(self.CARD_ROW_Y[slot]+7)))
                self["packageFocusBold"].show()
            except Exception:
                pass
            self["packageSelector"].show()
        else:
            self["packageSelector"].hide()
            try:self["packageTextFocusBg"].hide()
            except Exception:pass
            try:self["packageFocusBold"].hide()
            except Exception:pass
        # Do not fetch up to eight package catalogues while merely scrolling
        # package names.  On-demand Media/GENRE/Cinematic screens retain their
        # own RAM -> disk -> server fallback, and existing image queues stay
        # untouched.  This prevents unseen catalogue requests from competing
        # with the user's selected package and poster downloads.
        # Paint package names/cards first. Logo decoding starts only after the
        # first visible frame, then proceeds one logo at a time.
        self._queueVisibleLogos(420)

    def up(self):
        if self.focusMode=="nav":
            self.navIndex=(self.navIndex-1)%7
            self._renderNavFocus()
            return
        if not self.rows:return
        if self.moveMode and self.index>0:
            self.rows[self.index-1],self.rows[self.index]=self.rows[self.index],self.rows[self.index-1]
            self.index-=1
            self._savePackageOrder()
        else:
            self.index=(self.index-1)%len(self.rows)
        self.render()

    def down(self):
        if self.focusMode=="nav":
            self.navIndex=(self.navIndex+1)%7
            self._renderNavFocus()
            return
        if not self.rows:return
        if self.moveMode and self.index<len(self.rows)-1:
            self.rows[self.index+1],self.rows[self.index]=self.rows[self.index],self.rows[self.index+1]
            self.index+=1
            self._savePackageOrder()
        else:
            self.index=(self.index+1)%len(self.rows)
        self.render()

    def pageUp(self):
        if self.focusMode=="nav":return
        if not self.rows:return
        self.index=max(0,self.index-self.VISIBLE_ROWS)
        self.render()

    def pageDown(self):
        if self.focusMode=="nav":return
        if not self.rows:return
        self.index=min(len(self.rows)-1,self.index+self.VISIBLE_ROWS)
        self.render()

    def choose(self):
        if self.focusMode=="nav":
            self._openNavItem()
            return
        if not self.rows:return
        row=self.rows[self.index]
        cid=str(row[1] or "")
        state=_load_content_package_controls(self.source,self.kind)
        if cid and cid in state.get("locked",set()):
            self._pendingPackageOpen=row
            self.session.openWithCallback(self._packagePinForOpen,VirtualKeyBoard,title=tr("Enter parental PIN"),text="")
            return
        self._openPackageRow(row)

    def _packagePinForOpen(self,value=None):
        row=self._pendingPackageOpen; self._pendingPackageOpen=None
        if not row:return
        state=_load_content_package_controls(self.source,self.kind)
        if str(value or "").strip()!=str(state.get("pin") or "0000"):
            self.session.open(MessageBox,tr("Incorrect PIN"),MessageBox.TYPE_ERROR,timeout=3); return
        self._openPackageRow(row)

    def _openPackageRow(self,row):
        name,cid,logo,meta=row[:4]
        result={"name":name,"id":cid,"_source":dict(self.source)}
        if cid in ("__netflix__","__prime_video__"):
            result["target_id"]=str(row[6] or "") if len(row)>6 else ""
            result["target_name"]=str(row[7] or name) if len(row)>7 else name
        if cid:
            try:
                target_id = str(result.get("target_id") or cid)
                target_name = result.get("target_name") or name
                from .view_style_picker import get_style
                style = get_style('package', self.kind)
                view_source = dict(self.source)
                view_source['_view_picker_context'] = 'package'
                if style == 'cinematic':
                    from .cinematic_catalog import CinematicCatalogScreen
                    self.session.open(CinematicCatalogScreen, view_source, self.kind, target_id)
                elif style == 'genre':
                    from .genre_page import StandaloneGenreScreen
                    self.session.open(StandaloneGenreScreen, view_source, self.kind, target_id)
                else:
                    view_source['_view_style_override'] = 'circle' if style == 'circle' else 'original'
                    self.session.open(MediaScreen, view_source, self.kind, target_id, target_name)
            except Exception:
                self.close(result)

    def _savePackageOrder(self):
        state=_load_content_package_controls(self.source,self.kind)
        state["order"]=[str(row[1]) for row in self.rows if str(row[1] or "")]
        state["sort"]="custom"
        _save_content_package_controls(self.source,self.kind,state)
        self.sortMode="custom"
        try:self["sort"].setText("MOVE")
        except Exception:pass

    def openPackageMenu(self):
        if self.focusMode!="packages" or not self.rows:return
        row=self.rows[self.index]; name=str(row[0] or ""); cid=str(row[1] or "")
        if not cid:return
        state=_load_content_package_controls(self.source,self.kind)
        locked=cid in state.get("locked",set())
        choices=[
            ("Choose View Style (4 previews)","view_style"),
            (tr("GENRE"),"genre"),
            ((tr("Remove from parental protection") if locked else tr("Add to parental protection")),"parental"),
            (tr("Hide this package"),"hide"),
            ((tr("Disable move") if self.moveMode else tr("Enable move")),"move"),
            (tr("Change parental PIN"),"change_pin"),
        ]
        self.session.openWithCallback(self._packageMenuSelected,ChoiceBox,title=name,list=choices)

    def _packageViewStyleSelected(self, choice=None):
        if choice in ('circle','poster','genre','cinematic') and self.rows and self.focusMode == 'packages':
            self._openPackageRow(self.rows[self.index])

    def _packageMenuSelected(self,choice=None):
        if not choice or not self.rows:return
        action=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
        row=self.rows[self.index]; cid=str(row[1] or ""); name=str(row[0] or "")
        if action=="view_style":
            from .view_style_picker import PosterViewPicker
            self.session.openWithCallback(self._packageViewStyleSelected, PosterViewPicker, 'package', self.kind)
            return
        if action=="genre":
            try:
                self.session.open(MovieGenresScreen, dict(self.source), self.kind)
            except Exception as exc:
                self.session.open(MessageBox, tr("Unable to open Genres")+":\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)
            return
        if action=="parental":
            state=_load_content_package_controls(self.source,self.kind)
            locked=set(state.get("locked") or [])
            if cid in locked:locked.discard(cid)
            else:locked.add(cid)
            state["locked"]=locked; _save_content_package_controls(self.source,self.kind,state)
            self.render(); return
        if action=="hide":
            if cid.startswith("__"):
                self.session.open(MessageBox,tr("This package cannot be hidden."),MessageBox.TYPE_INFO,timeout=3); return
            self._pendingHidePackage=(cid,name)
            self.session.openWithCallback(self._confirmHidePackage,MessageBox,tr("Hide this package?")+"\n"+name,MessageBox.TYPE_YESNO)
            return
        if action=="move":
            self.moveMode=not self.moveMode
            if self.moveMode:
                self.sortMode="custom"; self._savePackageOrder()
                self["packageMenuHint"].setText("MOVE MODE  •  UP/DOWN move package  •  MENU disable move")
            else:
                self["packageMenuHint"].setText("")
            self.render(); return
        if action=="change_pin":
            self.session.openWithCallback(self._packageNewPinEntered,VirtualKeyBoard,title=tr("Enter new 4-digit PIN"),text="")

    def _confirmHidePackage(self,answer=False):
        pending=getattr(self,"_pendingHidePackage",None); self._pendingHidePackage=None
        if not answer or not pending:return
        cid,name=pending
        data=_load_all_filters(); key=_source_filter_key(self.source); entry=data.setdefault(key,{})
        allowed=entry.get(self.kind)
        if allowed is None:
            allowed=[str(row[1]) for row in self.rows if str(row[1] or "") and not str(row[1]).startswith("__")]
        allowed=[str(x) for x in (allowed or []) if str(x)!=cid]
        entry[self.kind]=allowed; data[key]=entry
        if _save_all_filters(data):
            self.rows=[row for row in self.rows if str(row[1])!=cid]
            if self.index>=len(self.rows):self.index=max(0,len(self.rows)-1)
            try:clear_catalog_memory()
            except Exception:pass
            self["count"].setText(str(len([r for r in self.rows if not str(r[1]).startswith("__")])))
            self.render()

    def _packageNewPinEntered(self,value=None):
        value=str(value or "").strip()
        if not(len(value)==4 and value.isdigit()):
            self.session.open(MessageBox,tr("PIN must contain exactly 4 digits."),MessageBox.TYPE_ERROR,timeout=3); return
        state=_load_content_package_controls(self.source,self.kind); state["pin"]=value
        _save_content_package_controls(self.source,self.kind,state)
        self.session.open(MessageBox,tr("Parental PIN changed."),MessageBox.TYPE_INFO,timeout=3)

    def openPackageFilter(self):
        # GREEN filters the currently open package kind for THIS server.
        # Movies -> VOD categories, TV Shows -> Series categories.
        stype = str((self.source or {}).get("type") or "").lower()
        if stype not in ("xtream", "stalker"):
            label = "Movie" if self.kind == "vod" else "TV Shows"
            self.session.open(MessageBox, "%s package filtering is available for Xtream Codes and Stalker Portal." % label, MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(
            self._packageFilterClosed,
            ServerCategoryFilter,
            dict(self.source),
            self.kind,
            True
        )

    # Compatibility alias for older callers.
    def openMoviePackageFilter(self):
        return self.openPackageFilter()

    def _packageFilterClosed(self, changed=None):
        # Reload the visible package list after saving; filter data itself is
        # persisted per-server by ServerCategoryFilter / filters.py.
        try:
            clear_catalog_memory()
        except Exception:
            pass
        self.rows=[]
        self.index=0
        self.pageStart=0
        try:self["count"].setText("")
        except Exception:pass
        self.load()

    def _moviePackageFilterClosed(self, changed=None):
        return self._packageFilterClosed(changed)

    def _serverChoices(self):
        rows=[]
        current_key=_source_identity(self.source)
        for source in list(get_sources() or []):
            if not isinstance(source,dict):
                continue
            # Movies/TV Shows: M3U is shown only when its cached playlist proves
            # that this section exists. Live-only M3U never leaks into VOD/Series.
            stype=str(source.get("type") or "").lower()
            if stype not in ("xtream","stalker","m3u"):
                continue
            if stype == "m3u" and not _m3u_source_has_kind(source, self.kind):
                continue
            name=str(source.get("name") or source.get("server") or source.get("portal") or "IPTV Server")
            kind="Xtream" if stype=="xtream" else "Stalker" if stype=="stalker" else "M3U"
            prefix="✓ " if _source_identity(source)==current_key else ""
            rows.append(("%s%s  [%s]"%(prefix,name,kind),dict(source)))
        return rows

    def serverSwitch(self):
        choices=self._serverChoices()
        if not choices:
            self.session.open(MessageBox,"No compatible IPTV servers found.",MessageBox.TYPE_INFO,timeout=3)
            return
        self.session.openWithCallback(
            self._serverSwitchSelected,
            ChoiceBox,
            title="SERVER SWITCH",
            list=choices
        )

    def _serverSwitchSelected(self,choice=None):
        if not choice:
            return
        try:
            source=choice[1]
        except Exception:
            return
        if not isinstance(source,dict):
            return
        self.source=dict(source)
        try:
            save_json(MAIN_SOURCE_FILE,{"key":_source_identity(self.source)})
        except Exception:
            pass
        self.rows=[]
        self.index=0
        self.pageStart=0
        self["count"].setText("")
        for slot in range(self.VISIBLE_ROWS):
            self["row%d"%slot].setText("")
            self["meta%d"%slot].setText("")
            self["desc%d"%slot].setText("")
            try:self["logo%d"%slot].hide()
            except Exception:pass
        self.load()

    def showInfo(self):
        if not self.rows:return
        name,cid,logo,meta=self.rows[self.index][:4]
        self.session.open(MessageBox,name,MessageBox.TYPE_INFO,timeout=3)


PACKAGE_SELECTOR_SKIN = r"""<screen name="ContentPackagesScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
<widget name="pageBackground" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/packages_selector_main_no_sidebar.jpg" alphatest="blend" scale="1" zPosition="0"/>
<!-- Selection outline is a separate focus-controlled pixmap, NEVER baked into the image. -->
<widget name="cardFocus" position="435,320" size="508,539" alphatest="blend" scale="1" zPosition="12"/>
<!-- Reuse the same complete sidebar layout as HomePackageBrowserScreen. -->
<widget name="navPanel" position="0,0" size="390,1080" alphatest="blend" zPosition="14"/>
<widget name="navLogo" position="28,24" size="325,96" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_e2_gold_logo.png" alphatest="blend" scale="1" zPosition="15"/>
<widget name="navFocus" position="15,389" size="360,72" alphatest="blend" zPosition="16"/>
<widget name="navIcon0" position="42,142" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/live.png" alphatest="blend" zPosition="17"/><widget name="nav0" position="78,130" size="260,48" font="Bold;22" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navIcon1" position="42,214" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/movies.png" alphatest="blend" zPosition="17"/><widget name="nav1" position="78,202" size="260,48" font="Bold;22" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navIcon2" position="42,286" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/shows.png" alphatest="blend" zPosition="17"/><widget name="nav2" position="78,274" size="260,48" font="Bold;22" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navIcon3" position="42,358" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/packages.png" alphatest="blend" zPosition="17"/><widget name="nav3" position="78,346" size="260,48" font="Bold;22" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navIcon4" position="42,430" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/genre.png" alphatest="blend" zPosition="17"/><widget name="nav4" position="78,418" size="260,48" font="Bold;22" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navIcon5" position="42,502" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/continue.png" alphatest="blend" zPosition="17"/><widget name="nav5" position="78,490" size="260,48" font="Bold;22" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navIcon6" position="42,574" size="24,24" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/navicons/settings.png" alphatest="blend" zPosition="17"/><widget name="nav6" position="78,562" size="260,48" font="Bold;19" foregroundColor="#E8E8E8" transparent="1" valign="center" zPosition="17"/>
<widget name="navSignature" position="35,928" size="320,90" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/developed_by_opesboy_signature_r212.png" alphatest="blend" scale="1" zPosition="17"/>
<widget name="serverHeading" position="88,694" size="215,26" font="Regular;17" foregroundColor="#C7A36C" transparent="1" halign="center" zPosition="17"/>
<widget name="serverName" position="38,726" size="318,42" font="Regular;26" foregroundColor="#F3E8D6" transparent="1" halign="center" valign="center" zPosition="17"/>
<widget name="packageCaption" position="42,793" size="108,22" font="Regular;15" foregroundColor="#C7A36C" transparent="1" halign="center" zPosition="17"/>
<widget name="newMovieCaption" position="151,793" size="102,22" font="Regular;14" foregroundColor="#C7A36C" transparent="1" halign="center" zPosition="17"/>
<widget name="newSeriesCaption" position="253,793" size="108,22" font="Regular;14" foregroundColor="#C7A36C" transparent="1" halign="center" zPosition="17"/>
<widget name="count" position="42,825" size="108,50" font="Regular;33" foregroundColor="#F3D7A5" transparent="1" halign="center" zPosition="17"/>
<widget name="newMovieCount" position="151,825" size="102,50" font="Regular;33" foregroundColor="#F3D7A5" transparent="1" halign="center" zPosition="17"/>
<widget name="newSeriesCount" position="253,825" size="108,50" font="Regular;33" foregroundColor="#F3D7A5" transparent="1" halign="center" zPosition="17"/>
<!-- Preserve the existing active receiver clock/date at the upper-right. -->
<widget name="packageClockFace" position="1578,18" size="116,116" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/packages/package_clock_r108/face.png" alphatest="blend" zPosition="8"/>
<widget name="packageClockHour" position="1578,18" size="116,116" alphatest="blend" zPosition="9"/>
<widget name="packageClockMinute" position="1578,18" size="116,116" alphatest="blend" zPosition="10"/>
<widget name="packageDate" position="1712,42" size="190,64" font="Regular;20" foregroundColor="#F4F4F0" transparent="1" halign="left" valign="center" zPosition="10"/>
</screen>"""
class ContentPackagesScreen(Screen):
    skin = PACKAGE_SELECTOR_SKIN
    NAV_Y = [119,191,263,335,407,479,551]
    CARD_FOCUS = [(435,320,508,539), (975,320,497,539)]

    def __init__(self, session, source):
        Screen.__init__(self, session)
        self.source=dict(source or {})
        self.choice=0
        self.navIndex=3
        self.mode="cards"
        self._sidebarVisible=False
        self["pageBackground"]=Pixmap()
        self["navFocus"]=Pixmap(); self["cardFocus"]=Pixmap()
        self["navPanel"]=Pixmap()
        self["navLogo"]=Pixmap()
        self["navSignature"]=Pixmap()
        self["serverHeading"]=Label("ACTIVE SERVER")
        self["serverName"]=Label("")
        self["packageCaption"]=Label("PACKAGES")
        self["newMovieCaption"]=Label("NEW MOVIES")
        self["newSeriesCaption"]=Label("NEW SERIES")
        self["count"]=Label("—")
        self["newMovieCount"]=Label("—")
        self["newSeriesCount"]=Label("—")
        for i in range(7):self["navIcon%d"%i]=Pixmap()
        self["packageClockFace"]=Pixmap()
        self["packageClockHour"]=Pixmap()
        self["packageClockMinute"]=Pixmap()
        self["packageDate"]=Label("")
        for i,name in enumerate(["LIVE TV","MOVIES","TV SHOWS","PACKAGES","GENRE","FAVORITES","SETTINGS"]): self["nav%d"%i]=Label(name)
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{
            "left":self.left,"right":self.right,"up":self.up,"down":self.down,"ok":self.ok,"cancel":self.close,"red":self.close
        },-1)
        self._packageClockTimer=eTimer()
        _connect_timer(self._packageClockTimer,self._updatePackageClock)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._stopPackageClock)

    def _ready(self):
        try:self["navFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages","packages_nav_focus_r52.png"))
        except Exception:pass
        try:self["navPanel"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages","packages_full_sidebar_backplate_r136.png"))
        except Exception:pass
        try:self["navLogo"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","common","tivimate_e2_gold_logo.png"))
        except Exception:pass
        try:self["navSignature"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","common","developed_by_opesboy_signature_r212.png"))
        except Exception:pass
        for i,icon in enumerate(("live","movies","shows","packages","genre","continue","settings")):
            try:self["navIcon%d"%i].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","navicons",icon+".png"))
            except Exception:pass
        self._updatePackageClock()
        try:self._packageClockTimer.start(30000, False)
        except Exception:pass
        # Start with the complete menu hidden, as on the movie/series package list.
        # No artwork or data fetch runs when the focus changes.
        self._setSidebarVisible(False,force=True)
        self._renderFocus()

    def _stopPackageClock(self):
        try:self._packageClockTimer.stop()
        except Exception:pass

    def _updatePackageClock(self):
        now=datetime.now()
        minute=int(now.minute)
        hour=int(now.hour)%12
        # Hour hand advances every five minutes, not only once per hour.
        hour_slot=(hour*12 + int(minute/5)) % 144
        clock_root=os.path.join(PLUGIN_PATH,"skins","packages","package_clock_r108")
        try:
            self["packageClockHour"].instance.setPixmapFromFile(
                os.path.join(clock_root,"h%03d.png"%hour_slot)
            )
        except Exception:pass
        try:
            self["packageClockMinute"].instance.setPixmapFromFile(
                os.path.join(clock_root,"m%02d.png"%minute)
            )
        except Exception:pass
        try:
            self["packageDate"].setText(now.strftime("%A\n%d %b %Y"))
        except Exception:pass

    def _refreshSelectorSidebarStats(self):
        """Use existing small category/index caches; never initiate network work."""
        try:
            from Plugins.Extensions.TiviMateE2 import filters as f
            source=self.source
            counts=[]
            for kind in ("vod","series"):
                try:
                    key="%s|categories|%s" % (f.source_filter_key(source),kind)
                    cached=f._RAM_CATEGORY_CACHE.get(key)
                    if cached is not None:
                        categories=cached[0]
                    else:
                        categories,_=f._load_cache_state(f._categories_cache_path(source,kind))
                    counts.append(len([r for r in (categories or []) if isinstance(r,dict) and (r.get("category_id") is not None)]))
                except Exception:
                    counts.append(0)
            if any(counts):
                self["count"].setText(str(sum(counts)))
            self["serverName"].setText(str(source.get("name") or source.get("title") or source.get("server_name") or "—")[:32])
            # The movie-browser also records recent observations on disk. Read
            # only the small index if present; do not scan entire VOD catalogs.
            try:
                import hashlib
                identity=hashlib.sha256(str(_source_identity(source)).encode("utf-8")).hexdigest()[:24]
                folder=os.path.join(get_cache_root(),"today_observations")
                day=datetime.now().strftime("%Y-%m-%d")
                for kind,label in (("vod","newMovieCount"),("series","newSeriesCount")):
                    try:
                        with open(os.path.join(folder,identity+"_"+kind+".json"),"r") as inp:
                            data=json.load(inp)
                        amount=data.get("counts",{}).get(day)
                        if amount is not None:
                            self[label].setText(str(amount)+( "" if data.get("complete",True) else "+"))
                    except Exception:pass
            except Exception:pass
        except Exception:
            try:self["serverName"].setText(str(self.source.get("name") or "—")[:32])
            except Exception:pass

    def _setSidebarVisible(self,visible,force=False):
        """Same focus-driven hide/reveal as HomePackageBrowserScreen."""
        visible=bool(visible)
        if not force and self._sidebarVisible==visible:
            return
        self._sidebarVisible=visible
        if visible:
            self._refreshSelectorSidebarStats()
        for name in ("navPanel","navLogo","navSignature","serverHeading","serverName",
                     "packageCaption","newMovieCaption","newSeriesCaption","count",
                     "newMovieCount","newSeriesCount"):
            try:
                if visible:self[name].show()
                else:self[name].hide()
            except Exception:pass
        for i in range(7):
            for name in ("nav%d"%i,"navIcon%d"%i):
                try:
                    if visible:self[name].show()
                    else:self[name].hide()
                except Exception:pass
        try:
            if visible and self.mode=="nav":self["navFocus"].show()
            else:self["navFocus"].hide()
        except Exception:pass

    def _renderFocus(self):
        if self.mode=="nav":
            self._setSidebarVisible(True)
            try:
                self["navFocus"].instance.move(ePoint(sx(15),sy(self.NAV_Y[self.navIndex])))
                self["navFocus"].show()
            except Exception:pass
            try:self["cardFocus"].hide()
            except Exception:pass
        else:
            self._setSidebarVisible(False)
            try:self["navFocus"].hide()
            except Exception:pass
            try:
                # Native focus pixmap tracks the focused card. Static artwork
                # is unchanged and there is NO permanently drawn focus frame.
                x,y,w,h=self.CARD_FOCUS[self.choice]
                self["cardFocus"].instance.move(ePoint(sx(x),sy(y)))
                self["cardFocus"].instance.resize(eSize(sx(w),sy(h)))
                asset="packages_active_movies_r136.png" if self.choice==0 else "packages_active_series_r136.png"
                self["cardFocus"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","packages",asset))
                self["cardFocus"].show()
            except Exception:pass
        for i in range(7):
            try:
                self["nav%d"%i].instance.setForegroundColor(parseColor("#FFFFFF" if self.mode=="nav" and i==self.navIndex else "#E8E8E8"))
            except Exception:pass

    def up(self):
        if self.mode!="nav":self.mode="nav"
        else:self.navIndex=(self.navIndex-1)%7
        self._renderFocus()
    def down(self):
        if self.mode!="nav":self.mode="nav"
        else:self.navIndex=(self.navIndex+1)%7
        self._renderFocus()
    def left(self):
        if self.mode=="cards":
            if self.choice==1:self.choice=0
            else:
                self.mode="nav"
                self.navIndex=3
        self._renderFocus()
    def right(self):
        if self.mode=="nav":
            self.mode="cards"
            self.choice=0
        else:self.choice=1
        self._renderFocus()

    def ok(self):
        if self.mode=="nav":
            if self.navIndex==0:self.session.open(MediaScreen,self.source,"live"); return
            if self.navIndex==1:self.session.open(configured_movies_screen(FastMoviesContentScreen, "vod"),self.source,"vod"); return
            if self.navIndex==2:self.session.open(configured_movies_screen(FastMoviesContentScreen, "series"),self.source,"series"); return
            if self.navIndex==3:
                self.mode="cards"
                self._renderFocus()
                return
            if self.navIndex==4:
                self.session.openWithCallback(self._packageGenreSelected,TiviMateGenreSelectScreen); return
            if self.navIndex==5:self.session.open(FavoritesScreen); return
            if self.navIndex==6:self.session.open(SettingsDashboard); return
        kind="vod" if self.choice==0 else "series"
        self._homePackageKind=kind
        try:
            self.source=dict(_load_main_source(self.source) or self.source)
        except Exception:
            pass
        self.session.openWithCallback(self._homePackageBrowserClosed,HomePackageBrowserScreen,self.source,kind)

    def _packageGenreSelected(self, selected=None):
        if not selected:
            return
        try:
            kind = selected[1] if isinstance(selected, (tuple, list)) else str(selected)
            self.session.openWithCallback(self._returnToPackageGenreSelector, MovieGenresScreen, dict(self.source), kind)
        except Exception as exc:
            self.session.open(MessageBox, tr("Unable to open Genres")+":\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)

    def _returnToPackageGenreSelector(self, *args):
        self.session.openWithCallback(self._packageGenreSelected, TiviMateGenreSelectScreen)

    def _homePackageBrowserClosed(self, selected=None, *args):
        self._packageSelected(getattr(self,"_homePackageKind","vod"),selected)
    def _packageSelected(self,kind,selected=None):
        if not selected or not isinstance(selected,dict):return
        selected_source=selected.get("_source")
        if isinstance(selected_source,dict):
            self.source=dict(selected_source)
        cid=str(selected.get("id") or ""); name=selected.get("name") or ""
        if cid in ("__netflix__","__prime_video__"):
            target_id=str(selected.get("target_id") or "")
            target_name=str(selected.get("target_name") or name)
            if not target_id:
                self.session.open(
                    MessageBox,
                    "%s package with content was not found on this server." % name,
                    MessageBox.TYPE_INFO,
                    timeout=5
                )
                return
            provider="netflix" if cid=="__netflix__" else "prime"
            routed_source=dict(self.source or {})
            routed_source["_package_provider_override"]=provider
            routed_source["_package_provider_category_id"]=target_id
            self.session.open(MediaScreen,routed_source,kind,target_id,target_name)
            return
        if cid=="__recent_added__":
            self.session.open(MediaScreen,self.source,kind,cid,name)
            return
        if cid:self.session.open(MediaScreen,self.source,kind,cid,name)



IMAGE_CACHE_CLEAN_BLUE_SKIN = r"""<screen name="ImageCacheSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#070A0E">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#070A0E" zPosition="0"/>
    <eLabel position="0,0" size="1920,96" backgroundColor="#0A0E13" zPosition="1"/>
    <widget name="cacheBrand" position="42,13" size="300,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" scale="1" zPosition="4"/>

    <eLabel position="520,0" size="150,96" text="Search" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="670,0" size="130,96" text="Home" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="800,0" size="120,96" text="Live" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="920,0" size="140,96" text="Movies" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1060,0" size="170,96" text="TV Shows" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1230,0" size="160,96" text="Settings" font="Regular;22" foregroundColor="#8B6CFF" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1260,82" size="100,3" backgroundColor="#8B6CFF" zPosition="4"/>

    <widget name="title" position="95,155" size="1200,52" font="Regular;38" foregroundColor="#F4F7FA" transparent="1" zPosition="4"/>
    <eLabel position="95,225" size="1730,2" backgroundColor="#6F5AA8" zPosition="2"/>

    <eLabel position="95,270" size="1730,510" backgroundColor="#161B27" borderColor="#6F5AA8" borderWidth="2" cornerRadius="12" zPosition="1"/>
    <widget name="config" position="125,300" size="1670,430" font="Regular;25" itemHeight="92" scrollbarMode="showOnDemand"
        foregroundColor="#E8EDF2" backgroundColor="#161B27"
        selectionForegroundColor="#FFFFFF" selectionBackgroundColor="#26A7E8"
        transparent="0" zPosition="4"/>

    <widget name="hint" position="180,800" size="1560,48" font="Regular;20" foregroundColor="#AEB9C4" transparent="1" halign="center" valign="center" zPosition="4"/>
    <eLabel position="95,862" size="1730,2" backgroundColor="#6F5AA8" zPosition="2"/>

    <eLabel position="120,900" size="390,76" text="GREEN\nSAVE" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#21C7D9" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="540,900" size="390,76" text="YELLOW\nCLEAN UP" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#8F55D9" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="960,900" size="390,76" text="BLUE\nCLEAR CACHE" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#9A56D8" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="1380,900" size="390,76" text="EXIT\nBACK" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#34485D" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <widget name="keys" position="0,1035" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


# ---------------------------------------------------------------------------
# Settings screens
# ---------------------------------------------------------------------------

class ImageCacheSettings(Screen, ConfigListScreen):
    skin = IMAGE_CACHE_CLEAN_BLUE_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["cacheBrand"] = Pixmap()
        cfg = get_cache_settings()
        self["title"] = Label(tr("IMAGE CACHE"))
        self["hint"] = Label("")
        self["keys"] = Label(tr("GREEN  SAVE    BLUE  CLEAR CACHE    YELLOW  CLEAN UP    EXIT  BACK"))
        self.location = ConfigSelection(default=str(cfg.get("location", "auto")), choices=[
            ("auto", "Auto: HDD → USB → MMC → Internal Flash"),
            ("hdd", "HDD /media/hdd"),
            ("usb", "USB /media/usb"),
            ("mmc", "MMC /media/mmc"),
            ("internal", "Internal Flash"),
            ("tmp", "Temporary /tmp"),
        ])
        self.retention = ConfigSelection(default=str(cfg.get("retention_days", 0)), choices=[
            ("0", "Unlimited — Keep images"),
            ("7", "1 Week"), ("14", "2 Weeks"), ("21", "3 Weeks"), ("30", "30 Days")
        ])
        self.flashLimit = ConfigSelection(default=str(cfg.get("flash_image_limit", 20)), choices=[
            ("20", "20 Posters + 20 Backdrops"),
            ("40", "40 Posters + 40 Backdrops"),
            ("60", "60 Posters + 60 Backdrops"),
            ("100", "100 Posters + 100 Backdrops")
        ])
        self.flashReserve = ConfigSelection(default=str(cfg.get("flash_min_free_mb", 30)), choices=[
            ("0", "Disabled"), ("20", "20 MB"), ("30", "30 MB — Recommended"), ("50", "50 MB")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Cache Location"), self.location),
            getConfigListEntry(tr("Image Cache Retention"), self.retention),
            getConfigListEntry(tr("Internal Flash Image Limit"), self.flashLimit),
            getConfigListEntry(tr("Internal Flash Free Space"), self.flashReserve),
        ], session=session)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "blue": self.clearNow, "yellow": self.cleanNow,
            "red": self.close, "cancel": self.close
        }, -1)
        self["sectionNav"] = ActionMap(["DirectionActions"], {
            "up": self._sectionUp, "down": self._sectionDown,
        }, -2)
        self.onLayoutFinish.append(self.updateHint)

    def _sectionUp(self):
        try:
            if self["config"].getCurrentIndex() > 0:
                return ConfigListScreen.keyUp(self)
        except Exception:
            return ConfigListScreen.keyUp(self)
        return ConfigListScreen.keyUp(self)

    def _sectionDown(self):
        try:
            idx = self["config"].getCurrentIndex()
            total = len(self["config"].list or [])
            if idx < max(0, total - 1):
                return ConfigListScreen.keyDown(self)
        except Exception:
            return ConfigListScreen.keyDown(self)
        self.session.open(SubDLSubtitleLanguageSettings)

    def updateHint(self):
        root, size, files = cache_status()
        self["hint"].setText("Current location: %s  •  %.1f MB  •  %d files" % (root, size / 1048576.0, files))

    def save(self):
        if save_cache_settings(
                self.location.value, 0, int(self.retention.value),
                int(self.flashLimit.value), int(self.flashReserve.value)):
            cleanup_cache()
            self.updateHint()
            self.session.open(MessageBox, "Cache settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save cache settings.", MessageBox.TYPE_ERROR)

    def clearNow(self):
        if clear_cache():
            try:
                clear_catalog_memory()
            except Exception:
                pass
            self.updateHint()
            self.session.open(MessageBox, "Poster and backdrop cache cleared. Data caches were kept.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to clear image cache.", MessageBox.TYPE_ERROR)

    def cleanNow(self):
        cleanup_cache()
        self.updateHint()
        self.session.open(MessageBox, "Poster/backdrop cache cleaned. Metadata, Recent, TMDb and database caches were kept.", MessageBox.TYPE_INFO)


from .display_scale import load_profile_preference, save_profile_preference

POSTER_SETTINGS_R199_SKIN = r'''<screen name="HomeAppearanceSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#030811">
 <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_settings_cards_r199.jpg" alphatest="blend" zPosition="0"/>
 <widget name="focus" position="310,300" size="410,550" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster/poster_card_focus_r199.png" alphatest="blend" zPosition="8"/>
 <widget name="title0" position="340,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="desc0" position="347,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="value0" position="343,765" size="344,44" font="Regular;25" foregroundColor="#1FA8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title3" position="785,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="desc3" position="792,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="value3" position="788,765" size="344,44" font="Regular;25" foregroundColor="#FF9F1C" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title2" position="1230,555" size="350,42" font="Regular;30" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
 <widget name="desc2" position="1237,625" size="336,70" font="Regular;22" foregroundColor="#C8D2DC" transparent="1" halign="center" valign="center" zPosition="5"/>
 <widget name="value2" position="1233,765" size="344,44" font="Regular;25" foregroundColor="#00D2CC" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title1" position="0,0" size="1,1" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6"/>
 <widget name="desc1" position="0,0" size="1,1" font="Regular;19" foregroundColor="#C8D2DC" transparent="1" halign="center" zPosition="6"/>
 <widget name="value1" position="0,0" size="1,1" font="Regular;24" foregroundColor="#56C8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title4" position="0,0" size="1,1" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6"/>
 <widget name="desc4" position="0,0" size="1,1" font="Regular;19" foregroundColor="#C8D2DC" transparent="1" halign="center" zPosition="6"/>
 <widget name="value4" position="0,0" size="1,1" font="Regular;24" foregroundColor="#56C8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="title5" position="0,0" size="1,1" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="6"/>
 <widget name="desc5" position="0,0" size="1,1" font="Regular;19" foregroundColor="#C8D2DC" transparent="1" halign="center" zPosition="6"/>
 <widget name="value5" position="0,0" size="1,1" font="Regular;24" foregroundColor="#56C8FF" transparent="1" halign="center" valign="center" zPosition="6"/>
 <widget name="hint" position="510,1012" size="900,30" font="Regular;19" foregroundColor="#8795A3" transparent="1" halign="center" zPosition="5"/>
</screen>'''

class HomeAppearanceSettings(Screen):
    skin = POSTER_SETTINGS_R199_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        current = _load_home_appearance()
        tmdb = load_tmdb_settings()
        self.index = 0
        self.skinChoices = [("cinema_blue", "Cinema Blue — Default"), ("skin2_dark", "Classic")]
        self.contentChoices = [("popular_movies", "Popular Show"),("popular_series", "Popular TV Shows"),("trending_movies", "Movies You Might Like"),("trending_series", "TV Shows You Might Like")]
        self.backdropChoices = [("w780", "780px (Default)"),("w1920", "1920px"),("original", "Original")]
        self.posterStyleChoices = [("original", "Original"),("circle", "Circle Poster")]
        self.resolutionChoices = [("fhd", "FHD — 1920×1080 (Default)"),("wqhd", "High Resolution — WQHD 2560×1440")]
        self.homeSkin = current.get("skin", "skin2_dark")
        self.homeContent = current.get("content", "popular_movies")
        self.backdropQuality = tmdb.get("backdrop_quality", "w780")
        self.posterStyle = current.get("poster_style", "original")
        self.displayProfile = load_profile_preference()
        from .app_font_setting import font_choices, current_font
        self.appFontChoices = font_choices()
        self.appFont = current_font()
        self["focus"] = Pixmap()
        self["title3"] = Label("APP FONT")
        self["desc3"] = Label("Font of TiviMate\nand its subtitles")
        self["value3"] = Label("")
        self["title0"] = Label("SKIN STYLE"); self["title1"] = Label(""); self["title2"] = Label("POSTER VIEW")
        self["title4"] = Label("")
        self["title5"] = Label("")
        self["desc0"] = Label("Choose your preferred\nskin style")
        self["desc1"] = Label("")
        self["desc2"] = Label("Choose poster style\nand size")
        self["desc4"] = Label("")
        self["desc5"] = Label("")
        for i in (0, 1, 2, 4, 5): self["value%d"%i] = Label("")
        self["hint"] = Label("YELLOW  MOVIES DESIGN     BLUE  FONT SIZE     GREEN  SAVE     RED  BACK")
        self["actions"] = ActionMap(["OkCancelActions","DirectionActions","ColorActions"], {"up": self.prevCard, "down": self.nextCard, "left": self.prevValue, "right": self.nextValue, "ok": self.save, "green": self.save, "blue": self.openFontSettings, "yellow": self.openMoviesPageDesign, "cancel": self.close, "red": self.close}, -1)
        self.onLayoutFinish.append(self._refresh)

    def openFontSettings(self):
        self.session.open(FontAppearanceSettings)

    def openMoviesPageDesign(self):
        """Shared design chooser for Movies/TV Shows, reachable in settings."""
        from .movies_layout_choice import get_content_layout
        movies = get_content_layout("vod")
        shows = get_content_layout("series")
        choices = [
            (("✓  " if movies == "current" else "   ") + "Movies  •  Current", "vod:current"),
            (("✓  " if movies == "new" else "   ") + "Movies  •  Cinematic", "vod:new"),
            (("✓  " if movies == "grid24" else "   ") + "Movies  •  24 Grid", "vod:grid24"),
            (("✓  " if shows == "current" else "   ") + "TV Shows  •  Current", "series:current"),
            (("✓  " if shows == "new" else "   ") + "TV Shows  •  Cinematic", "series:new"),
            (("✓  " if shows == "grid24" else "   ") + "TV Shows  •  24 Grid", "series:grid24"),
        ]
        self.session.openWithCallback(self._moviesPageDesignChosen, ChoiceBox,
                                      title="MOVIES / TV SHOWS  •  PAGE DESIGN", list=choices)

    def _moviesPageDesignChosen(self, selection=None):
        if not selection:
            return
        value = selection[1] if isinstance(selection, (tuple, list)) and len(selection)>1 else selection
        if not isinstance(value, str) or ':' not in value:
            return
        kind, design = value.split(':', 1)
        if design not in ('current', 'new', 'grid24') or kind not in ('vod', 'series'):
            return
        from .movies_layout_choice import save_content_layout
        saved = save_content_layout(kind, design)
        if saved:
            self.session.open(MessageBox, "Page design saved. Reopen Movies/TV Shows to apply.",
                              MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to save page design.",
                              MessageBox.TYPE_ERROR, timeout=4)


    def _pairs(self):
        # Home Content is a single Popular Show choice on Classic. The other
        # three feeds remain configurable on Cinema, not loaded on Classic.
        feeds = [("popular_movies", "Popular Show")] if self.homeSkin == "skin2_dark" else self.contentChoices
        return [(self.skinChoices,"homeSkin"),(feeds,"homeContent"),(self.posterStyleChoices,"posterStyle")]
    def _label(self, choices, value):
        for k,v in choices:
            if k == value: return v
        return choices[0][1]
    def _refresh(self):
        if self.homeSkin == "skin2_dark":
            self.homeContent = "popular_movies"
        xs={0: 310, 3: 755, 2: 1200}
        try:
            if self.index in xs:
                self["focus"].show()
                self["focus"].instance.move(ePoint(sx(xs[self.index]),sy(300)))
            else:
                self["focus"].hide()
        except Exception:pass
        self["title4"].setText("")
        self["title5"].setText("")
        self["value0"].setText("‹  %s  ›" % self._label(self.skinChoices,self.homeSkin))
        self["value1"].setText("")
        self["value2"].setText("‹  %s  ›" % self._label(self.posterStyleChoices,self.posterStyle))
        from .app_font_setting import label as _font_label
        self["value3"].setText("‹  %s  ›" % _font_label(self.appFont, self.appFontChoices))
        self["value4"].setText("")
        self["value5"].setText("")
    # Cards: SKIN STYLE, APP FONT (under the skin choice), POSTER VIEW.
    # HOME CONTENT is not used by the app any more and is not shown.
    _CARD_ORDER = (0, 3, 2)
    def _moveCard(self, delta):
        order = self._CARD_ORDER
        i = order.index(self.index) if self.index in order else 0
        self.index = order[(i + delta) % len(order)]; self._refresh()
    def prevCard(self): self._moveCard(-1)
    def nextCard(self): self._moveCard(1)
    def _step(self, delta):
        if self.index == 3:
            from .app_font_setting import step as _font_step
            self.appFont = _font_step(self.appFont, delta, self.appFontChoices); self._refresh(); return
        choices, attr = self._pairs()[self.index]; cur=getattr(self,attr); keys=[x[0] for x in choices]
        try:i=keys.index(cur)
        except Exception:i=0
        setattr(self,attr,keys[(i+delta)%len(keys)]); self._refresh()
    def prevValue(self): self._step(-1)
    def nextValue(self): self._step(1)
    def save(self):
        content = "popular_movies" if self.homeSkin == "skin2_dark" else self.homeContent
        ok1=_save_home_appearance(self.homeSkin,content,"none","none",False,False,poster_style=self.posterStyle)
        from .app_font_setting import save as _font_save
        _font_save(self.appFont)
        if ok1: self.session.open(MessageBox,"Skin and poster settings saved.",MessageBox.TYPE_INFO)
        else: self.session.open(MessageBox,"Unable to save appearance settings.\n%s" % _home_appearance_save_error(),MessageBox.TYPE_ERROR)


class TiviMateUpdatePreviewCode(Screen):
    """Local visual preview of the Online Update design. No network/update actions."""
    skin = """
    <screen name="TiviMateUpdatePreviewCode" position="center,center" size="1200,800" flags="wfNoBorder" backgroundColor="transparent">
        <ePixmap position="0,0" size="1200,800" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/update_online_r470.jpg" alphatest="blend" zPosition="0" />
        <eLabel position="355,202" size="500,54" backgroundColor="#121b24" cornerRadius="10" zPosition="1" />
        <widget name="heading" position="355,205" size="500,48" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" halign="center" valign="center" zPosition="2" />
        <eLabel position="158,292" size="265,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="currentLabel" position="165,298" size="250,34" font="Regular;25" foregroundColor="#D7E8FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="425,292" size="330,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="currentValue" position="435,298" size="315,34" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="158,343" size="265,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="latestLabel" position="165,349" size="250,34" font="Regular;25" foregroundColor="#D7E8FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="425,343" size="330,46" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="latestValue" position="435,349" size="315,34" font="Regular;25" foregroundColor="#31B9FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="158,403" size="265,48" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="notesLabel" position="165,409" size="250,34" font="Regular;25" foregroundColor="#D7E8FF" backgroundColor="transparent" transparent="1" valign="center" zPosition="2" />
        <eLabel position="425,403" size="700,125" backgroundColor="#121b24" cornerRadius="8" zPosition="1" />
        <widget name="notes" position="435,412" size="680,105" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" valign="top" zPosition="2" />
        <eLabel position="895,258" size="230,140" backgroundColor="#121b24" zPosition="5" />
        <eLabel position="895,398" size="230,135" backgroundColor="#121b24" zPosition="1" />
        <eLabel position="89,608" size="515,86" backgroundColor="#17324A" cornerRadius="18" zPosition="1" />
        <widget name="previewText" position="105,620" size="485,60" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" halign="center" valign="center" zPosition="2" />
        <eLabel position="640,608" size="495,86" backgroundColor="#1D252E" cornerRadius="18" zPosition="1" />
        <widget name="closeText" position="655,620" size="465,60" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="transparent" transparent="1" halign="center" valign="center" zPosition="2" />
        <widget name="updateFocus" position="89,608" size="515,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
        <widget name="cancelFocus" position="640,608" size="495,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
    </screen>
    """

    def __init__(self, session):
        Screen.__init__(self, session)
        self["heading"] = Label("")
        self["currentLabel"] = Label("")
        self["currentValue"] = Label("")
        self["latestLabel"] = Label("")
        self["latestValue"] = Label("")
        self["notesLabel"] = Label("")
        self["notes"] = Label("")
        self["previewText"] = Label("")
        self["closeText"] = Label("")
        self["updateFocus"] = Pixmap()
        self["cancelFocus"] = Pixmap()
        self._focusIndex = 0
        self.onLayoutFinish.append(self._refreshFocus)
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "left": self._focusUpdate,
            "right": self._focusCancel,
            "ok": self.close,
            "green": self.close,
            "red": self.close,
            "cancel": self.close,
        }, -1)

    def _refreshFocus(self):
        if self._focusIndex == 0:
            self["updateFocus"].show()
            self["cancelFocus"].hide()
        else:
            self["updateFocus"].hide()
            self["cancelFocus"].show()

    def _focusUpdate(self):
        self._focusIndex = 0
        self._refreshFocus()

    def _focusCancel(self):
        self._focusIndex = 1
        self._refreshFocus()


class TiviMateUpdatePrompt(Screen):
    """Branded update confirmation: image + movable focus + OK only."""
    skin = """
    <screen name="TiviMateUpdatePrompt" position="center,center" size="1200,800" flags="wfNoBorder" backgroundColor="transparent">
        <ePixmap position="0,0" size="1200,800" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/update_online_r470.jpg" alphatest="blend" zPosition="0" />
        <widget name="updateFocus" position="89,608" size="515,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
        <widget name="cancelFocus" position="640,608" size="495,86" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" scale="1" zPosition="6" />
    </screen>
    """

    def __init__(self, session, candidate=None, timeout=None):
        Screen.__init__(self, session)
        self.candidate = candidate or {}
        self["updateFocus"] = Pixmap()
        self["cancelFocus"] = Pixmap()
        self._focusIndex = 0
        self.onLayoutFinish.append(self._refreshFocus)
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "left": self._focusUpdate,
            "right": self._focusCancel,
            "ok": self._focusedOk,
            "cancel": self._cancel,
        }, -1)

    def _refreshFocus(self):
        if self._focusIndex == 0:
            self["updateFocus"].show()
            self["cancelFocus"].hide()
        else:
            self["updateFocus"].hide()
            self["cancelFocus"].show()

    def _focusUpdate(self):
        self._focusIndex = 0
        self._refreshFocus()

    def _focusCancel(self):
        self._focusIndex = 1
        self._refreshFocus()

    def _focusedOk(self):
        if self._focusIndex == 0:
            self._accept()
        else:
            self._cancel()

    def _accept(self):
        self.close(True)

    def _cancel(self):
        self.close(False)


class UpdateSettingsScreen(Screen, ConfigListScreen):
    """Settings and user-confirmed manual update flow for verified packages."""
    skin = EDITOR.replace('name="TiviMateE2PlaylistEditor"', 'name="UpdateSettingsScreen"').replace('settings_guide_keyboard_save_r69.png', 'settings_guide_save_back_r69.png')

    def __init__(self, session):
        Screen.__init__(self, session)
        _setup_settings_chrome(self)
        _show_settings_guide(self)
        cfg = _load_update_settings()
        self.autoCheck = ConfigSelection(default="on" if cfg.get("auto_check", True) else "off", choices=[
            ("on", "On"), ("off", "Off")
        ])
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Automatic update check"), self.autoCheck)
        ], session=session)
        self["title"] = Label(tr("SOFTWARE UPDATES"))
        self["hint"] = Label(tr("Automatic checks only read a small verified update manifest. Press YELLOW to check now."))
        self["keys"] = Label(tr("GREEN  SAVE    YELLOW  CHECK NOW    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "yellow": self.manualCheck, "ok": self.save,
            "red": self.close, "cancel": self.close
        }, -1)
        self._checkPending = None
        self._downloadPending = None
        self._candidate = None
        self._installProcess = None
        self._checkInProgress = False
        self._downloadInProgress = False
        self._checkTimer = eTimer()
        self._downloadTimer = eTimer()
        _connect_timer(self._checkTimer, self._pollCheck)
        _connect_timer(self._downloadTimer, self._pollDownload)
        self.onClose.append(self._stopTimers)

    def _stopTimers(self):
        for timer in (getattr(self, "_checkTimer", None), getattr(self, "_downloadTimer", None)):
            try:
                timer.stop()
            except Exception:
                pass

    def save(self):
        enabled = self.autoCheck.value == "on"
        if _save_update_settings(enabled):
            state = "enabled" if enabled else "disabled"
            self["hint"].setText("Automatic update checks are %s. Press YELLOW to check now." % state)
            self.session.open(MessageBox, "Update settings saved.", MessageBox.TYPE_INFO)
        else:
            self.session.open(MessageBox, "Unable to save update settings.", MessageBox.TYPE_ERROR)

    def manualCheck(self):
        if self._checkInProgress or self._downloadInProgress or self._installProcess:
            return
        self._checkInProgress = True
        self._checkPending = None
        self["hint"].setText(tr("Checking for a verified update..."))

        def worker():
            try:
                self._checkPending = check_for_update()
            except Exception:
                self._checkPending = {}

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateCheck")
            thread.daemon = True
            thread.start()
            self._checkTimer.start(200, True)
        except Exception:
            self._checkPending = {}
            self._pollCheck()

    def _pollCheck(self):
        if self._checkPending is None:
            try:
                self._checkTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._checkPending or {}
        self._checkPending = None
        self._checkInProgress = False
        if not result.get("available"):
            if result.get("reason") == "current":
                self["hint"].setText(tr("TiViMate E2 is already up to date."))
                self.session.open(MessageBox, "No update is available. TiViMate E2 is already up to date.", MessageBox.TYPE_INFO)
            else:
                self["hint"].setText(tr("Unable to verify updates right now. You can try again later."))
                self.session.open(MessageBox, "Unable to check for updates. Please try again later.", MessageBox.TYPE_ERROR)
            return
        self._candidate = result
        self.session.openWithCallback(self._confirmUpdate, TiviMateUpdatePrompt, result)

    def _confirmUpdate(self, answer):
        if not answer or not self._candidate:
            return
        package = self._candidate.get("package")
        if not package:
            return
        self._downloadInProgress = True
        self._downloadPending = None
        self["hint"].setText("")

        def worker():
            self._downloadPending = download_package(package)

        try:
            thread = threading.Thread(target=worker, name="TiviMateManualUpdateDownload")
            thread.daemon = True
            thread.start()
            self._downloadTimer.start(200, True)
        except Exception:
            self._downloadPending = {"ok": False, "message": "Unable to start download"}
            self._pollDownload()

    def _pollDownload(self):
        if self._downloadPending is None:
            try:
                self._downloadTimer.start(200, True)
            except Exception:
                pass
            return
        result = self._downloadPending or {}
        self._downloadPending = None
        self._downloadInProgress = False
        if not result.get("ok"):
            self["hint"].setText(tr("Update download failed."))
            self.session.open(MessageBox, "Update download failed.\n\n%s" % (result.get("message") or "Please try again later."), MessageBox.TYPE_ERROR); return
        command = install_command(result)
        if not command:
            cleanup_update_package(result)
            self["hint"].setText(tr("The verified package could not be installed."))
            self.session.open(MessageBox, "The verified update package could not be installed.", MessageBox.TYPE_ERROR); return
        self["hint"].setText(tr("Installing TiViMate E2 update..."))
        try:
            process = eConsoleAppContainer()
            self._installProcess = process
            try:
                process.appClosed.append(self._installFinished)
            except Exception:
                process.appClosed.get().append(self._installFinished)
            process.execute("/bin/sh", "sh", "-c", command)
        except Exception:
            cleanup_update_package(result)
            self["hint"].setText(tr("Unable to start the update installer."))
            self.session.open(MessageBox, "Unable to start the update installer.", MessageBox.TYPE_ERROR)

    def _installFinished(self, status):
        self._installProcess = None
        if status == 0:
            self["hint"].setText(tr("Update completed. Restarting Enigma2 GUI..."))
            try:
                from enigma import quitMainloop
                quitMainloop(3)
            except Exception:
                self.session.open(MessageBox, "TiViMate E2 was updated successfully.\n\nPlease restart the Enigma2 GUI to use the new version.", MessageBox.TYPE_INFO)
        else:
            self["hint"].setText(tr("The update installer returned an error."))
            self.session.open(MessageBox, "The update installer returned an error. Your current installation has not been changed.", MessageBox.TYPE_ERROR)


SUBTITLE_LANGUAGE_CLEAN_BLUE_SKIN = r"""<screen name="SubDLSubtitleLanguageSettings" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#070A0E">
    <eLabel position="0,0" size="1920,1080" backgroundColor="#070A0E" zPosition="0"/>
    <eLabel position="0,0" size="1920,96" backgroundColor="#0A0E13" zPosition="1"/>
    <widget name="cacheBrand" position="42,13" size="300,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" scale="1" zPosition="4"/>

    <eLabel position="520,0" size="150,96" text="Search" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="670,0" size="130,96" text="Home" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="800,0" size="120,96" text="Live" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="920,0" size="140,96" text="Movies" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1060,0" size="170,96" text="TV Shows" font="Regular;22" foregroundColor="#DCE4EC" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1230,0" size="160,96" text="Settings" font="Regular;22" foregroundColor="#8B6CFF" backgroundColor="#0A0E13" halign="center" valign="center" zPosition="3"/>
    <eLabel position="1260,82" size="100,3" backgroundColor="#8B6CFF" zPosition="4"/>

    <eLabel position="80,158" size="330,42" text="CONTROL CENTER" font="Regular;30" foregroundColor="#F4F7FA" backgroundColor="#070A0E" zPosition="3"/>
    <eLabel position="80,220" size="330,2" backgroundColor="#312B46" zPosition="2"/>
    <eLabel position="70,250" size="350,118" backgroundColor="#0D1218" borderColor="#403754" borderWidth="1" cornerRadius="12" zPosition="2"/>
    <eLabel position="92,270" size="300,34" text="IMAGE CACHE" font="Regular;27" foregroundColor="#E6E1F8" backgroundColor="#0D1218" zPosition="3"/>
    <eLabel position="92,312" size="300,42" text="Manage image cache and location" font="Regular;18" foregroundColor="#9EA8B4" backgroundColor="#0D1218" zPosition="3"/>
    <eLabel position="70,382" size="350,118" backgroundColor="#171427" borderColor="#6F5AA8" borderWidth="2" cornerRadius="12" zPosition="2"/>
    <eLabel position="92,402" size="300,34" text="SUBTITLE LANGUAGE" font="Regular;25" foregroundColor="#B9A9FF" backgroundColor="#171427" zPosition="3"/>
    <eLabel position="92,444" size="300,42" text="Language and subtitle font size" font="Regular;18" foregroundColor="#B9C1CC" backgroundColor="#171427" zPosition="3"/>

    <widget name="title" position="480,165" size="1080,50" font="Regular;36" foregroundColor="#F4F7FA" transparent="1" zPosition="4"/>
    <eLabel position="480,230" size="1240,2" backgroundColor="#312B46" zPosition="2"/>

    <eLabel position="480,270" size="1240,500" backgroundColor="#0D1218" borderColor="#6F5AA8" borderWidth="2" cornerRadius="12" zPosition="1"/>
    <widget name="config" position="505,292" size="1190,450" font="Regular;25" itemHeight="82" scrollbarMode="showOnDemand"
        foregroundColor="#E8EDF2" backgroundColor="#0D1218"
        selectionForegroundColor="#FFFFFF" selectionBackgroundColor="#51409B"
        transparent="0" zPosition="4"/>

    <widget name="hint" position="500,800" size="1180,58" font="Regular;20" foregroundColor="#AEB9C4" transparent="1" halign="center" valign="center" zPosition="4"/>
    <eLabel position="480,862" size="1240,2" backgroundColor="#312B46" zPosition="2"/>

    <eLabel position="630,900" size="420,76" text="GREEN  SAVE &amp; APPLY" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#5C45C9" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <eLabel position="1080,900" size="420,76" text="RED  BACK" font="Regular;22" foregroundColor="#FFFFFF" backgroundColor="#563C6B" halign="center" valign="center" cornerRadius="8" zPosition="3"/>
    <widget name="keys" position="0,1035" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


class FontAppearanceSettings(Screen, ConfigListScreen):
    """Ultra-style global and film/series text size, not subtitle pixel size."""
    skin = (SUBTITLE_LANGUAGE_CLEAN_BLUE_SKIN
            .replace('name="SubDLSubtitleLanguageSettings"', 'name="FontAppearanceSettings"')
            .replace('text="SUBTITLE LANGUAGE"', 'text="FONT APPEARANCE"')
            .replace('text="Language and subtitle font size"', 'text="Interface and movie font size"'))

    def __init__(self, session):
        Screen.__init__(self, session)
        from .font_preferences import read_preferences
        saved = read_preferences()
        self["cacheBrand"] = Pixmap()
        levels = [
            ("normal", "Normal"),
            ("large", "Large"),
            ("larger", "Larger"),
            ("xlarge", "Extra Large"),
        ]
        self.interfaceFont = ConfigSelection(default=saved["font_scale"], choices=levels)
        self.overviewFont = ConfigSelection(default=saved["overview_font_scale"], choices=levels)
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Font Size", self.interfaceFont),
            getConfigListEntry("Movies/Series  •  Font Size", self.overviewFont),
        ], session=session)
        self["title"] = Label("APPEARANCE  •  FONT SIZE")
        self["hint"] = Label("Application text and Movies/Series descriptions. Restart Enigma2 to apply.")
        self["keys"] = Label("GREEN  SAVE     RED  BACK")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "cancel": self.close, "red": self.close,
        }, -1)

    def save(self):
        from .font_preferences import save_preferences
        ok = save_preferences(self.interfaceFont.value, self.overviewFont.value)
        if ok:
            # Previous implementation only changed skins during the next
            # plugin import, leaving an already running Enigma2 unaffected.
            # Update the class skins in memory so the NEXT opened page shows
            # the new size immediately, without restarting the whole receiver.
            try:
                from .font_preferences import refresh_loaded_screens
                refresh_loaded_screens()
            except Exception as exc:
                print("[TiviMateE2] Could not refresh font skins: %s" % exc)
            self.session.open(MessageBox, "Saved. Reopen a TiviMate page to see the new font size.", MessageBox.TYPE_INFO, timeout=5)
        else:
            self.session.open(MessageBox, "Unable to save font sizes.", MessageBox.TYPE_ERROR, timeout=4)


class SubDLSubtitleLanguageSettings(Screen, ConfigListScreen):
    """Preferred subtitle language for server tracks, SubsSupport fallback and SubDL."""
    skin = SUBTITLE_LANGUAGE_CLEAN_BLUE_SKIN

    def __init__(self, session, focus_font=False):
        Screen.__init__(self, session)
        self.session = session
        self._focus_font = bool(focus_font)
        self["cacheBrand"] = Pixmap()
        current = load_subdl_settings()
        # LANGUAGE_CHOICES is stored as (display name, ISO code), while
        # ConfigSelection expects (value, display label). Keep the ISO code as
        # the single persisted value used by server + all external providers.
        self.targetLanguage = ConfigSelection(
            default=current.get("language", "ar"),
            choices=[(code, name) for name, code in SUBDL_LANGUAGE_CHOICES],
        )
        try:
            native_font = getattr(getattr(config, "subtitles", None), "subtitle_fontsize", None)
            subtitle_font_default = str(getattr(native_font, "value", "55") or "55")
        except Exception:
            subtitle_font_default = "55"
        # TiviMateE2 unified subtitle size: 14..100 px, default 55 px.
        # Migrate the old screen default (48 px) to the new 55 px default once.
        common_font_sizes = [str(x) for x in range(14, 101)]
        if subtitle_font_default == "48" or subtitle_font_default not in common_font_sizes:
            subtitle_font_default = "55"
        self.subtitleFont = ConfigSelection(
            default=subtitle_font_default,
            choices=[(v, "%s px" % v) for v in common_font_sizes],
        )
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("Preferred Subtitle Language"), self.targetLanguage),
            getConfigListEntry(tr("Subtitle Font Size"), self.subtitleFont),
        ], session=session)
        if self._focus_font:
            try:
                self["config"].setCurrentIndex(1)
            except Exception:
                pass
        self["title"] = Label(tr("SUBTITLE LANGUAGE"))
        self["hint"] = Label(tr(
            "Choose the subtitle search language and the native/external subtitle font size. Audio and server subtitle tracks remain manually selectable."
        ))
        self["keys"] = Label(tr("GREEN  SAVE    RED  BACK"))
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "green": self.save, "ok": self.save, "red": self.close, "cancel": self.close,
        }, -1)
        self["sectionNav"] = ActionMap(["DirectionActions"], {
            "up": self._sectionUp, "down": self._sectionDown,
        }, -2)

    def _sectionUp(self):
        try:
            if self["config"].getCurrentIndex() > 0:
                return ConfigListScreen.keyUp(self)
        except Exception:
            return ConfigListScreen.keyUp(self)
        self.session.open(ImageCacheSettings)

    def _sectionDown(self):
        return ConfigListScreen.keyDown(self)

    def _saveUnifiedSubtitleFont(self):
        value = str(self.subtitleFont.value)
        applied = False
        try:
            native = config.subtitles.subtitle_fontsize
            try:
                native.setValue(value)
            except Exception:
                native.value = value
            try:
                native.save()
            except Exception:
                pass
            applied = True
        except Exception:
            pass
        try:
            from Plugins.Extensions.SubsSupport.subtitles import initSubsSettings
            subs = initSubsSettings()
            for section_name in ("external", "embedded"):
                try:
                    section = getattr(subs, section_name, None)
                    font = getattr(section, "font", None) if section is not None else None
                    setting = getattr(font, "size", None) if font is not None else None
                    if setting is None:
                        continue
                    try:
                        setting.setValue(value)
                    except Exception:
                        setting.value = value
                    try:
                        setting.save()
                    except Exception:
                        pass
                    applied = True
                except Exception:
                    pass
        except Exception:
            pass
        try:
            configfile.save()
        except Exception:
            pass
        return applied

    def save(self):
        try:
            current = load_subdl_settings()
            save_subdl_settings(
                current.get("api_key", ""),
                self.targetLanguage.value,
                current.get("kind", "standard"),
            )
            try:
                from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.subtitles import initSubsProSettings
                pro_settings = initSubsProSettings()
                for name in ("lang1", "lang2", "lang3"):
                    entry = getattr(pro_settings.search, name)
                    try:
                        entry.setValue(self.targetLanguage.value)
                    except Exception:
                        entry.value = self.targetLanguage.value
                    try:
                        entry.save()
                    except Exception:
                        pass
            except Exception:
                pass
            self._saveUnifiedSubtitleFont()
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save the SubDL subtitle language.", MessageBox.TYPE_ERROR, timeout=5)


WEB_ACCESS_SKIN = scale_skin(r'''<screen name="TiviMateE2WebAccess" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101D">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_web_blue.png" alphatest="blend" zPosition="0" />
    <ePixmap position="72,14" size="330,94" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/common/tivimate_wordmark.png" alphatest="blend" zPosition="5" />
    <widget name="title" position="500,126" size="1320,58" font="Regular;44" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="subtitle" position="500,188" size="1320,34" font="Regular;22" foregroundColor="#56E5FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <ePixmap position="84,284" size="430,500" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/web_mobile_device.png" alphatest="blend" zPosition="3" />
    <widget name="leftTitle" position="92,794" size="414,42" font="Regular;30" foregroundColor="#48E4FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <widget name="leftHint" position="82,838" size="434,62" font="Regular;20" foregroundColor="#E5F2FF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <widget name="qrTitle" position="610,264" size="420,42" font="Regular;30" foregroundColor="#53E7FF" backgroundColor="#00000000" transparent="1" halign="center" zPosition="5" />
    <eLabel position="626,326" size="388,388" backgroundColor="#0A1622" zPosition="3" />
    <widget name="qr" position="654,354" size="332,332" alphatest="blend" zPosition="5" />
    <widget name="qrHint" position="620,742" size="400,68" font="Regular;20" foregroundColor="#DCEBFA" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
    <eLabel position="1160,305" size="22,22" backgroundColor="#24E882" zPosition="4" />
    <widget name="status" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="addressLabel" position="1195,358" size="560,32" font="Regular;22" foregroundColor="#57E1FF" backgroundColor="#00000000" transparent="1" zPosition="5" />
    <widget name="url" position="1195,416" size="560,54" font="Regular;29" foregroundColor="#71E4FF" backgroundColor="#00000000" transparent="1" zPosition="5" valign="center" />
    <widget name="help" position="1195,522" size="560,230" font="Regular;24" foregroundColor="#E5F2FF" backgroundColor="#00000000" transparent="1" valign="top" zPosition="5" />
    <widget name="hint" position="1195,788" size="560,60" font="Regular;21" foregroundColor="#82DFFF" backgroundColor="#00000000" transparent="1" zPosition="5" halign="left" valign="center" />
    <widget name="footer" position="560,932" size="1270,48" font="Regular;22" foregroundColor="#C9D8E8" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="5" />
</screen>''')

class WebAccessScreen(Screen):
    skin = WEB_ACCESS_SKIN

    def __init__(self, session):
        Screen.__init__(self, session)
        self["title"] = Label("")
        self["subtitle"] = Label("")
        self["leftTitle"] = Label("Control your IPTV")
        self["leftHint"] = Label("Manage servers and playlists from your mobile phone or computer.")
        self["qrTitle"] = Label("SCAN QR CODE")
        self["qrHint"] = Label("Point your phone camera at the QR code")
        self["addressLabel"] = Label("Web Address")
        self["qr"] = Pixmap()
        self["status"] = Label("")
        self["url"] = Label("")
        self["help"] = Label("Manage servers from your phone:\n• Add / edit Xtream\n• Add / edit Stalker + MAC\n• M3U playlists\n• IPTV Finder and maintenance")
        self["hint"] = Label("")
        self["footer"] = Label("")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.close, "ok": self.close, "red": self.close,
            "green": self.refreshAccess
        }, -1)

        try:
            from .storage import data_path
            self._qrPath = data_path("runtime", "web_access_qr.png")
        except Exception:
            self._qrPath = "/media/hdd/.tivimatee2-cache/runtime/web_access_qr.png" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/runtime/web_access_qr.png"
        self.onLayoutFinish.append(self.refreshAccess)

    def refreshAccess(self):
        try:
            from .web_manager import start_web_manager, web_manager_status, web_manager_url, web_manager_qr_url, web_access_pin
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get('ip') or '127.0.0.1')
            port = int(status.get('port') or 80)
            running = bool(status.get('running'))
            url = web_manager_url(ip, port)
            self['status'].setText('Web Server: %s' % ('ON' if running else 'OFF'))
            self['url'].setText(url if running else '')
            if running:
                self['hint'].setText('WEB ACCESS CODE: %s' % web_access_pin())
            if running and not ip.startswith('127.') and ip != '0.0.0.0':
                from .web_qr import make_qr_png, qr_file_for_url
                qr_path = qr_file_for_url(self._qrPath, web_manager_qr_url(ip, port))
                make_qr_png(web_manager_qr_url(ip, port), qr_path, scale=8, border=4)
                picture = LoadPixmap(qr_path)
                if picture is None:
                    raise RuntimeError('QR image decoder unavailable')
                self['qr'].instance.setPixmap(picture)
                self['qr'].show()
                self['hint'].setText('ACCESS CODE: %s  |  %s' % (web_access_pin(), str(status.get('notice') or 'Scan QR to pair.')))
            else:
                self['qr'].hide()
                self['hint'].setText(str(status.get('error') or
                    'Web access unavailable. Check receiver LAN IP and press GREEN.'))
        except Exception as error:
            self['qr'].hide()
            self['status'].setText('Web Server: ERROR')
            self['url'].setText('')
            self['hint'].setText('Could not display QR: %s' % str(error)[:70])



def _extract_xtream_expiry(reply):
    """Return Xtream expiry from common panel fields.

    Standard Xtream panels expose ``user_info.exp_date``.  Some compatible
    panels rename the field.  A present-but-empty/zero exp_date is treated as
    Unlimited, while a completely missing field stays unknown.
    """
    if not isinstance(reply, dict):
        return ""
    user = reply.get("user_info") if isinstance(reply.get("user_info"), dict) else {}
    keys = ("exp_date", "expiry", "expire", "expire_date", "expiration_date", "expiration", "end_date")
    for container in (user, reply):
        if not isinstance(container, dict):
            continue
        for key in keys:
            if key not in container:
                continue
            value = container.get(key)
            raw = str(value or "").strip()
            if raw and raw.lower() not in ("0", "none", "null", "false", "n/a", "-"):
                return raw
            # Standard panels use a null/0 exp_date for unlimited accounts.
            if key == "exp_date":
                return "Unlimited"
    return ""


def _xtream_expiry_is_past(value):
    raw = str(value or "").strip()
    if not raw or raw.lower() in ("unlimited", "never", "lifetime"):
        return False
    try:
        number = float(raw)
        if number > 100000000000:
            number /= 1000.0
        if number > 946684800:
            return number < time.time()
    except Exception:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            return datetime.strptime(raw, fmt) < datetime.now()
        except Exception:
            pass
    return False


def _xtream_state_from_reply(reply):
    report = evaluate_reply("xtream", reply)
    user = reply.get("user_info") if isinstance(reply, dict) and isinstance(reply.get("user_info"), dict) else {}
    status = str(user.get("status") or "").strip().lower()
    auth = str(user.get("auth") if "auth" in user else "").strip().lower()
    expiry = _extract_xtream_expiry(reply)
    if status in ("expired", "disabled", "banned", "blocked", "inactive") or _xtream_expiry_is_past(expiry):
        state = "expired"
    elif auth in ("0", "false", "no"):
        state = "offline"
    else:
        state = report.get("state", "offline")
    return state, expiry


def _format_server_expiry(value):
    """Return a compact human-readable subscription expiry or em dash."""
    raw = str(value or "").strip()
    if not raw or raw.lower() in ("0", "none", "null", "false", "unknown", "n/a", "-"):
        return "—"
    if raw.lower() in ("unlimited", "never", "lifetime"):
        return "Unlimited"
    # Xtream normally returns Unix seconds.
    try:
        number = int(float(raw))
        if 946684800 <= number <= 4102444800:
            return datetime.fromtimestamp(number).strftime("%d/%m/%Y")
    except Exception:
        pass
    # Common Stalker / panel date formats.
    match = re.search(r"((?:19|20)\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", raw)
    if match:
        return "%02d/%02d/%04d" % (int(match.group(3)), int(match.group(2)), int(match.group(1)))
    match = re.search(r"(\d{1,2})[-/.](\d{1,2})[-/.]((?:19|20)\d{2})", raw)
    if match:
        return "%02d/%02d/%04d" % (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    return "—"

class ServerStatusList(MenuList):
    """MenuList that preserves source rows while drawing a local health dot.

    The source dictionary remains the first element of every row, so ServerManager
    keeps the same selection, scrolling, action-key and source-editing behaviour.
    """
    STATUS_PIXMAPS = {
        "online": os.path.join(PLUGIN_PATH, "skins/server/server_status_online_r123.png"),
        "busy": os.path.join(PLUGIN_PATH, "skins/server/server_status_busy_r123.png"),
        "checking": os.path.join(PLUGIN_PATH, "skins/server/server_status_checking_r123.png"),
        "offline": os.path.join(PLUGIN_PATH, "skins/server/server_status_offline_r123.png"),
        "expired": os.path.join(PLUGIN_PATH, "skins/server/server_status_offline_r123.png"),
    }
    TYPE_PIXMAPS = {
        "xtream": os.path.join(PLUGIN_PATH, "skins/server/web_xtream_icon.png"),
        "stalker": os.path.join(PLUGIN_PATH, "skins/server/web_stalker_icon.png"),
    }

    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 36))
            self.l.setItemHeight(88)
        except Exception:
            pass
        self._pixmaps = {}
        for name, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._pixmaps[name] = None
        self._type_pixmaps = {}
        for name, path in self.TYPE_PIXMAPS.items():
            try:
                self._type_pixmaps[name] = LoadPixmap(path)
            except Exception:
                self._type_pixmaps[name] = None

    def setSources(self, sources, states, expiries=None):
        expiries = expiries or {}
        rows = [self._makeRow(
            source,
            states.get(self._key(source), "checking"),
            expiries.get(self._key(source), "")
        ) for source in sources]
        self.setList(rows)

    @staticmethod
    def _display_name(source):
        source = source or {}
        name = str(source.get("name") or "").strip()
        url = str(source.get("url") or source.get("portal") or "").strip()
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    @staticmethod
    def _key(source):
        endpoint = source.get("url") or source.get("host") or source.get("server") or source.get("portal") or ""
        return "%s|%s|%s|%s" % (source.get("type", ""), source.get("name", ""), endpoint, source.get("username", ""))

    def _makeRow(self, source, state, expiry=""):
        source = source or {}
        source_type = str(source.get("type") or "").lower()
        name = self._display_name(source)
        alias = str(source.get("mac_alias") or "").strip()
        if alias and alias.lower() not in name.lower():
            name = "%s • %s" % (name, alias)

        title = "%s  •  %s" % (name, source_type.upper() if source_type else "SERVER")
        expiry_text = "Expire: %s" % _format_server_expiry(expiry)
        status_pixmap = self._pixmaps.get(state) or self._pixmaps.get("checking")
        type_pixmap = self._type_pixmaps.get(source_type)

        row = [
            source,
            MultiContentEntryPixmapAlphaBlend(
                pos=(0, 8), size=(1000, 78),
                png=LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server/server_row_r67.png"))
            ),
        ]
        if type_pixmap is not None:
            row.append(MultiContentEntryPixmapAlphaBlend(
                pos=(22, 16), size=(56, 56), png=type_pixmap
            ))

        row.extend([
            MultiContentEntryText(
                pos=(100, 0), size=(590, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=title,
                color=0x00F5F8FC, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(690, 0), size=(155, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=expiry_text,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ),
            MultiContentEntryText(
                pos=(850, 0), size=(115, 88), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text={"online": "ONLINE", "busy": "IN USE", "checking": "CHECK", "offline": "OFFLINE", "expired": "EXPIRED", "unknown": "—"}.get(state, "—"),
                color={"online": 0x0067E89A, "busy": 0x00FFD669, "checking": 0x00FFD669, "offline": 0x00FF8C95, "expired": 0x00FF8C95, "unknown": 0x008C95A4}.get(state, 0x008C95A4),
                color_sel=0x00FFFFFF
            ),
            MultiContentEntryPixmapAlphaBlend(
                pos=(965, 28), size=(32, 32), png=status_pixmap
            ),
        ])
        return row



from .live_server_health import check_live_source


def _stalker_session_headers(client):
    """Headers the portal session really uses (UA/X-UA/cookie/token)."""
    for engine in (getattr(client, "_ultra_client", None), client):
        getter = getattr(engine, "_headers", None)
        if callable(getter):
            try:
                headers = dict(getter() or {})
                for key in ("Host", "Accept-Encoding", "Connection", "Pragma"):
                    headers.pop(key, None)
                return headers
            except Exception:
                pass
    return {}


_LAST_STALKER_PROBE = {"report": ""}


def _stalker_slot_probe(source, limit=20.0):
    """BUSY / FREE for a Stalker MAC (+ a report of WHY a stream fails).

    Takes the first channel, asks the portal for its link and opens the
    stream for a moment (a few KB, then closed) in several ways:
      1. like the Enigma2 player (GStreamer user agent, no cookies)
      2. like a MAG box player (MAG user agent)
      3. with the full portal session (same UA, X-User-Agent, cookie, token)
    The first that plays = FREE. 458/429/453... = BUSY. The report is kept
    in /tmp/tivimate_stalker_probe.txt and shown when nothing plays.
    """
    box = {}
    lines = []

    def note(text):
        try:
            lines.append(u"%s" % (text,))
        except Exception:
            lines.append(repr(text))

    def run():
        try:
            client = StalkerClient(dict(source or {}))
            note("Portal: %s" % (source or {}).get("url"))
            note("MAC: %s" % (source or {}).get("mac"))
            cats = client.live_categories() or []
            note("Packages: %d" % len(cats))
            candidates = []
            for cat in cats[:6]:
                cid = cat.get("category_id") if isinstance(cat, dict) else None
                if cid in (None, ""):
                    continue
                page = client.live_page(cid, 1) or {}
                rows = page.get("items") if isinstance(page, dict) else page
                rows = [r for r in (rows or []) if isinstance(r, dict)]
                candidates.extend(rows[:1])
                if len(candidates) >= 2:
                    break
            if not candidates:
                box["state"] = "NO CHANNEL"
                note("No channel found in the first packages")
                return
            try:
                from urllib.request import Request, urlopen
                from urllib.error import HTTPError
            except ImportError:
                from urllib2 import Request, urlopen, HTTPError
            mag = ("Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 "
                   "(KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3")
            session = _stalker_session_headers(client)
            variants = [
                ("ENIGMA PLAYER", {"User-Agent": "GStreamer souphttpsrc libsoup/2.72"}),
                ("MAG UA", {"User-Agent": mag}),
                ("PORTAL SESSION", session),
            ]
            limit_words = ("connection", "limit", "in use", "another device", "busy", "max")
            outcome = {}
            for item in candidates:
                name = item.get("name") or item.get("title") or "?"
                note("")
                note("Channel: %s" % name)
                note("cmd: %s" % str(item.get("cmd") or "")[:160])
                try:
                    url = client.stream_url(item, "live") or ""
                except Exception as exc:
                    note("create_link FAILED: %s" % exc)
                    continue
                note("link: %s" % url[:200])
                if not url.startswith(("http://", "https://")):
                    outcome.setdefault("nolink", True)
                    continue
                url = url.split("#", 1)[0]
                for label, headers in variants:
                    if not headers:
                        continue
                    try:
                        # A single-use play_token: ask for a fresh link per try.
                        if label != variants[0][0] and "play_token=" in url.lower():
                            fresh = client.stream_url(item, "live") or url
                            url = fresh.split("#", 1)[0]
                        response = urlopen(Request(url, headers=headers), timeout=6)
                        try:
                            data = response.read(4096)
                            code = response.getcode()
                        finally:
                            try:
                                response.close()
                            except Exception:
                                pass
                        note("  %-15s -> HTTP %s, %d bytes" % (label, code, len(data or b"")))
                        if data:
                            outcome.setdefault("free", label)
                    except HTTPError as exc:
                        code = int(getattr(exc, "code", 0) or 0)
                        body = ""
                        try:
                            body = exc.read(300).decode("utf-8", "ignore")
                        except Exception:
                            pass
                        note("  %-15s -> HTTP %d %s" % (label, code, body.strip().replace("\n", " ")[:80]))
                        if code in (429, 453, 456, 458, 509) or any(w in body.lower() for w in limit_words):
                            outcome.setdefault("busy", label)
                        else:
                            outcome.setdefault("codes", []).append(code)
                    except Exception as exc:
                        note("  %-15s -> %s" % (label, str(exc)[:80]))
                        outcome.setdefault("errors", []).append(str(exc)[:40])
                if outcome.get("free") or outcome.get("busy"):
                    break
            if outcome.get("free"):
                box["state"] = "FREE"
                note("")
                note("RESULT: plays with %s" % outcome["free"])
                if outcome["free"] != "ENIGMA PLAYER":
                    note("=> The Enigma2 player alone is refused; it needs %s headers." % outcome["free"])
            elif outcome.get("busy"):
                box["state"] = "BUSY"
                note("")
                note("RESULT: MAC in use on another device")
            elif outcome.get("codes"):
                box["state"] = "NO PLAY %d" % outcome["codes"][-1]
            elif outcome.get("nolink"):
                box["state"] = "NO LINK"
            else:
                box["state"] = "NO PLAY"
        except Exception as exc:
            note("ERROR: %s" % exc)
            box["state"] = "TIMEOUT" if "timed out" in str(exc).lower() else "NO PLAY"

    thread = threading.Thread(target=run)
    thread.daemon = True
    thread.start()
    thread.join(limit)
    state = box.get("state") or "TIMEOUT"
    report = u"\n".join(lines + [u"", u"STATE: %s" % state])
    _LAST_STALKER_PROBE["report"] = report
    try:
        with open("/tmp/tivimate_stalker_probe.txt", "wb") as handle:
            handle.write((report + u"\n").encode("utf-8", "replace"))
    except Exception:
        pass
    return state


class LiveServerChoiceList(MenuList):
    STATUS_PIXMAPS = {
        "active": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_green.png"),
        "unknown": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_yellow.png"),
        "inactive": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "blocked": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "expired": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_red.png"),
        "unchecked": os.path.join(PLUGIN_PATH, "skins/live/estalker_led_grey.png"),
    }

    def __init__(self, rows=None):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 24))
            self.l.setItemHeight(78)
        except Exception:
            pass
        self._pixmaps = {}
        for state, path in self.STATUS_PIXMAPS.items():
            try:
                self._pixmaps[state] = LoadPixmap(path)
            except Exception:
                self._pixmaps[state] = None
        try:
            self._type_pixmap_xtream = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server/live_switch_xtream.png"))
        except Exception:
            self._type_pixmap_xtream = None
        try:
            self._type_pixmap_stalker = LoadPixmap(os.path.join(PLUGIN_PATH, "skins/server/live_switch_stalker.png"))
        except Exception:
            self._type_pixmap_stalker = None
        self.setRows(rows or [])

    @staticmethod
    def _display_name(source):
        source = source or {}
        name = str(source.get("name") or "").strip()
        url = str(source.get("url") or source.get("portal") or "").strip()
        noisy = (
            not name or len(name) > 32 or
            "stalker portal mac" in name.lower() or
            "stbemu codes" in name.lower()
        )
        if noisy and url:
            try:
                parsed = urlparse(url if "://" in url else "http://" + url)
                host = parsed.hostname or ""
                port = parsed.port
                if host:
                    return ("%s:%d" % (host, port)) if port else host
            except Exception:
                pass
        return name or url or "SERVER"

    @staticmethod
    def _format_estalker_expiry(value):
        raw = str(value or "").strip()
        if not raw:
            return ""
        if raw.lower() in ("unknown", "none", "null", "0", "-"):
            return "Unknown"
        if raw.lower() in ("unlimited", "never", "lifetime"):
            return "Unlimited"
        try:
            number = int(float(raw))
            # EStalker treats bare numeric expiry as unknown in its list.
            if number > 0:
                return "Unknown"
        except Exception:
            pass
        return raw

    @staticmethod
    def _parse_estalker_expiry(value):
        raw = str(value or "").strip()
        if not raw:
            return None
        for fmt in (
            "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y/%m/%d",
            "%d/%m/%Y", "%m/%d/%Y",
            "%B %d, %Y, %I:%M %p", "%B %d, %Y"
        ):
            try:
                return datetime.strptime(raw, fmt)
            except Exception:
                pass
        return None

    def _estalker_row_info(self, source):
        """A passive status row. Never treat last-known health as a live test."""
        source = source or {}
        stype = str(source.get("type") or "").strip().lower()
        account = str(source.get("_live_probe_account") or "na").lower()
        connection = str(source.get("_live_probe_connection") or "unchecked").lower()
        expiry = source.get("_live_probe_expiry")
        if expiry is None:
            expiry = source.get("_last_expiry") or source.get("expiry") or ""
        expiry_text = _format_server_expiry(expiry)
        if expiry_text == u"—":
            expiry_text = u"—"
        account_names = {
            "active": "ACTIVE", "expired": "EXPIRED", "blocked": "BLOCKED",
            "inactive": "INACTIVE", "unknown": u"—", "na": u"—"
        }
        connection_names = {
            "online": "REACHABLE", "valid": "VALID", "failed": "NO REPLY",
            "checking": "TESTING", "unchecked": "NOT TESTED",
            "cached_online": "LAST OK", "cached_failed": "LAST FAIL",
            "cached_expired": "EXPIRED"
        }
        led = {
            "online": "active", "valid": "active", "failed": "inactive",
            "checking": "unknown", "unchecked": "unchecked",
            "cached_online": "unchecked", "cached_failed": "unchecked",
            "cached_expired": "unchecked"
        }.get(connection, "unchecked")
        return {
            "type": stype, "name": self._display_name(source),
            "mac": str(source.get("mac") or "").strip().upper() if stype == "stalker" else "",
            "expiry": expiry_text,
            "account": account_names.get(account, u"—"),
            "connection": connection_names.get(connection, "NOT TESTED"),
            "account_state": account, "connection_state": connection, "led": led,
            "cons": str(source.get("_live_probe_cons") or "")
        }

    def _row(self, source, selected_here=False):
        info = self._estalker_row_info(source)
        pixmap = self._pixmaps.get(info["led"]) or self._pixmaps.get("unchecked")
        selected_text = u"✓" if selected_here else ""
        account_color = {
            "active": 0x0067E89A, "expired": 0x00FF6B78,
            "blocked": 0x00FF6B78, "inactive": 0x00FF6B78,
            "unknown": 0x009FB5C9, "na": 0x009FB5C9
        }.get(info["account_state"], 0x009FB5C9)
        connection_color = {
            "online": 0x0067E89A, "valid": 0x0067E89A,
            "failed": 0x00FF8896, "checking": 0x00A8CEDA,
            "unchecked": 0x008A9AAA, "cached_online": 0x0095B8AA,
            "cached_failed": 0x008A9AAA, "cached_expired": 0x008A9AAA
        }.get(info["connection_state"], 0x008A9AAA)
        row = [
            source,
            MultiContentEntryText(
                pos=(8, 0), size=(28, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=selected_text, color=0x00FFD34A, color_sel=0x00FFD34A
            ),
        ]
        icon = (self._type_pixmap_xtream if info["type"] == "xtream" else
                self._type_pixmap_stalker if info["type"] == "stalker" else None)
        if icon is not None:
            row.append(MultiContentEntryPixmapAlphaBlend(pos=(42, 18), size=(40, 40), png=icon))
        if info["mac"]:
            row.extend([
                MultiContentEntryText(pos=(94, 5), size=(300, 32), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["name"],
                    color=0x00F5F8FC, color_sel=0x00FFFFFF),
                MultiContentEntryText(pos=(94, 38), size=(300, 29), font=0,
                    flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["mac"],
                    color=0x008FA8C0, color_sel=0x00BFD7EA),
            ])
        else:
            row.append(MultiContentEntryText(pos=(94, 0), size=(300, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["name"],
                color=0x00F5F8FC, color_sel=0x00FFFFFF))
        row.extend([
            MultiContentEntryText(pos=(405, 0), size=(185, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["expiry"],
                color=0x00D5DDE8, color_sel=0x00FFFFFF),
            MultiContentEntryText(pos=(600, 0), size=(125, 76), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["account"],
                color=account_color, color_sel=account_color),
        ])
        if pixmap is not None:
            row.append(MultiContentEntryPixmapAlphaBlend(pos=(730, 27), size=(23, 24), png=pixmap))
        cons = info.get("cons") or ""
        busy = None
        if cons in ("BUSY", "FREE"):
            busy = (cons == "BUSY")
        elif cons and "/" in cons:
            try:
                used, limit = [int(x) for x in cons.split("/", 1)]
                busy = bool(limit > 0 and used >= limit)
            except Exception:
                busy = None
        if busy is None and cons and info.get("type") == "stalker":
            row.append(MultiContentEntryText(pos=(770, 4), size=(185, 34), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["connection"],
                color=connection_color, color_sel=connection_color))
            row.append(MultiContentEntryText(pos=(770, 38), size=(185, 34), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text="ERROR",
                color=0x00FF6B78, color_sel=0x00FF6B78))
        elif busy is None:
            row.append(MultiContentEntryText(pos=(770, 12), size=(185, 52), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["connection"],
                color=connection_color, color_sel=connection_color))
        else:
            # Line 1: reachability, line 2: BUSY (all connections used) / FREE.
            row.append(MultiContentEntryText(pos=(770, 4), size=(185, 34), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER, text=info["connection"],
                color=connection_color, color_sel=connection_color))
            cons_color = 0x00FF9F43 if busy else 0x0067E89A
            row.append(MultiContentEntryText(pos=(770, 38), size=(185, 34), font=0,
                flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
                text=cons if cons in ("BUSY", "FREE") else (("BUSY  %s" if busy else "FREE  %s") % cons),
                color=cons_color, color_sel=cons_color))
        return row

    def setRows(self, rows):
        self.setList([self._row(source, selected) for source, selected in rows])


class LiveServerChoiceScreen(Screen):
    skin = """
    <screen name="LiveServerChoiceScreen" position="center,center" size="1540,820"
            title="Switch Live server" backgroundColor="#050D18">

        <!-- outer glow / frame -->
        <eLabel position="0,0" size="1540,820" backgroundColor="#07111F" zPosition="0" />
        <eLabel position="2,2" size="1536,816" backgroundColor="#0A1A2D" zPosition="1" />

        <!-- header -->
        <eLabel position="26,24" size="1018,112" backgroundColor="#081522" zPosition="2" />
        <widget name="title" position="62,42" size="720,48" font="Regular;36"
                foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="subtitle" position="62,92" size="920,28" font="Regular;20"
                foregroundColor="#9FB5C9" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <eLabel position="28,134" size="1014,2" backgroundColor="#148CFF" zPosition="4" />

        <!-- left server card -->
        <eLabel position="26,150" size="1018,592" backgroundColor="#071522" zPosition="2" />
        <eLabel position="42,162" size="986,52" backgroundColor="#0A1D31" zPosition="3" />
        <widget name="columns" position="66,172" size="930,32" font="Regular;19"
                foregroundColor="#A9BDD0" backgroundColor="#00000000" transparent="1" zPosition="5" />
        <widget name="servers" position="48,220" size="978,468"
                backgroundColor="#071522" backgroundColorSelected="#12345A"
                foregroundColor="#FFFFFF" foregroundColorSelected="#FFFFFF"
                itemHeight="78" scrollbarMode="showOnDemand"
                itemCornerRadius="10" itemCornerRadiusSelected="10" zPosition="5" />

        <!-- footer controls -->
        <eLabel position="42,700" size="986,1" backgroundColor="#173451" zPosition="4" />
        <widget name="hint" position="62,710" size="940,28" font="Regular;18"
                foregroundColor="#D8E6F2" backgroundColor="#00000000" transparent="1" zPosition="5" />

        <!-- Slim on-demand status card; web QR remains available below -->
        <eLabel position="1064,24" size="450,718" backgroundColor="#071522" zPosition="2" />
        <eLabel position="1066,26" size="446,714" backgroundColor="#0A1622" zPosition="3" />
        <widget name="qrTitle" position="1098,65" size="382,36" font="Regular;27"
                foregroundColor="#E2EDF6" transparent="1" zPosition="5" />
        <widget name="qrSubtitle" position="1098,110" size="382,28" font="Regular;18"
                foregroundColor="#8EAABD" transparent="1" zPosition="5" />
        <eLabel position="1096,158" size="384,1" backgroundColor="#284054" zPosition="4" />
        <widget name="probeName" position="1100,179" size="375,42" font="Regular;25"
                foregroundColor="#FFFFFF" transparent="1" zPosition="5" />
        <widget name="probeState" position="1100,222" size="375,38" font="Regular;22"
                foregroundColor="#A2BDCC" transparent="1" zPosition="5" />
        <eLabel position="1098,273" size="380,27" text="BLUE  Test this server only"
                font="Regular;18" foregroundColor="#91D6E3" transparent="1" zPosition="5" />
        <eLabel position="1096,324" size="384,1" backgroundColor="#284054" zPosition="4" />
        <eLabel position="1098,341" size="384,26" text="WEB ACCESS"
                font="Regular;18" foregroundColor="#829EAF" transparent="1" zPosition="5" />
        <eLabel position="1188,375" size="203,203" backgroundColor="#0A1622" zPosition="4" />
        <widget name="qr" position="1197,384" size="185,185" alphatest="blend" zPosition="6" />
        <widget name="webStatus" position="1120,594" size="350,32" font="Regular;20"
                foregroundColor="#7CCFA4" transparent="1" zPosition="5" />
        <widget name="webUrl" position="1094,626" size="390,43" font="Regular;17"
                foregroundColor="#93B9CD" transparent="1"
                halign="center" valign="center" zPosition="5" />
        <widget name="webHint" position="1098,676" size="386,49" font="Regular;16"
                foregroundColor="#839BA9" transparent="1"
                halign="center" valign="center" zPosition="5" />

        <!-- clock -->
        <widget name="clock" position="1198,758" size="286,34" font="Regular;27"
                foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1"
                halign="right" zPosition="5" />
        <widget name="date" position="1120,792" size="364,22" font="Regular;17"
                foregroundColor="#91A8BB" backgroundColor="#00000000" transparent="1"
                halign="right" zPosition="5" />
    </screen>
    """

    def __init__(self, session, rows):
        Screen.__init__(self, session)
        self["title"] = Label("")
        self["subtitle"] = Label("Only the selected server is tested when you press BLUE")
        self["columns"] = Label("SERVER NAME                         EXPIRY                 ACCOUNT               STATUS")
        self._serverRows = []
        for source, selected in (rows or []):
            entry = dict(source)
            # Historical status is shown as LAST OK/LAST FAIL, never CONNECTED.
            # Opening the selector does not start any network requests.
            entry["_live_probe_account"] = "na"
            last_state = str(entry.get("_last_status") or "").strip().lower()
            entry["_live_probe_connection"] = {
                "online": "cached_online", "busy": "cached_online",
                "offline": "cached_failed", "expired": "cached_expired"
            }.get(last_state, "unchecked")
            self._serverRows.append((entry, bool(selected)))
        self["servers"] = LiveServerChoiceList(self._serverRows)
        self["servers"].onSelectionChanged.append(self._refreshQuickProbeCard)
        self["hint"] = Label("")

        self["qrTitle"] = Label("SERVER STATUS")
        self["qrSubtitle"] = Label("No background checks")
        self["probeName"] = Label("")
        self["probeState"] = Label("")
        self["qr"] = Pixmap()
        self["webStatus"] = Label("Web server: STARTING")
        self["webUrl"] = Label("")
        self["webHint"] = Label("Phone and receiver must be on the same local network.")
        self["clock"] = Label("")
        self["date"] = Label("")


        try:
            from .storage import data_path
            self._qrPath = data_path("runtime", "tivimatee2_live_server_qr.png")
        except Exception:
            self._qrPath = "/media/hdd/.tivimatee2-cache/runtime/tivimatee2_live_server_qr.png" if os.path.ismount("/media/hdd") else "/var/tmp/tivimatee2-cache/runtime/tivimatee2_live_server_qr.png"
        self._clockTimer = eTimer()
        _connect_timer(self._clockTimer, self._refreshClock)
        self._statusProbeTimer = eTimer()
        _connect_timer(self._statusProbeTimer, self._finishServerProbe)
        self._statusProbeResult = None
        self._statusProbeBusy = False
        self._statusProbeToken = 0
        self._statusProbeClosed = False

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.ok,
                "cancel": self.close,
                "up": self["servers"].up,
                "down": self["servers"].down,
                "pageUp": self["servers"].pageUp,
                "pageDown": self["servers"].pageDown,
                "red": self.deleteCurrent,
                "yellow": self.ok,
                "blue": self.testCurrent,
            }, -1
        )

        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._cleanupProfessionalUI)

    def _layoutReady(self):
        self._refreshClock()
        try:
            self._clockTimer.start(30000, False)
        except Exception:
            pass
        self._refreshWebCard()
        self["hint"].setText("OK  Select       RED  Delete       BLUE  Test selected only       EXIT  Close")
        self._refreshQuickProbeCard()

    def _refreshQuickProbeCard(self):
        """Selection-only UI update, without network or disk activity."""
        try:
            source = self._currentSource() or {}
            info = self["servers"]._estalker_row_info(source)
            self["probeName"].setText(info.get("name") or "SERVER")
            self["probeState"].setText(info.get("connection") or "NOT TESTED")
            color = {
                "online": "#76D7A1", "valid": "#76D7A1",
                "failed": "#EF9B9B", "checking": "#96CDDA"
            }.get(info.get("connection_state"), "#9BB0C0")
            try:
                self["probeState"].instance.setForegroundColor(parseColor(color))
            except Exception:
                pass
        except Exception:
            pass

    def _refreshClock(self):
        try:
            now = datetime.now()
            self["clock"].setText(now.strftime("%I:%M %p").lstrip("0"))
            self["date"].setText(now.strftime("%d %B %Y"))
        except Exception:
            pass

    def _refreshWebCard(self):
        try:
            from .web_manager import start_web_manager, web_manager_status, web_manager_url, web_manager_qr_url, web_access_pin
            start_web_manager()
            status = web_manager_status() or {}
            ip = str(status.get('ip') or '127.0.0.1')
            port = int(status.get('port') or 80)
            running = bool(status.get('running'))
            url = web_manager_url(ip, port)
            self['webStatus'].setText('Web server %s' % ('ON' if running else 'OFF'))
            self['webUrl'].setText(url if running else '')
            if running and not ip.startswith('127.') and ip != '0.0.0.0':
                from .web_qr import make_qr_png, qr_file_for_url
                qr_path = qr_file_for_url(self._qrPath, web_manager_qr_url(ip, port))
                if not os.path.isfile(qr_path) or os.path.getsize(qr_path) < 400:
                    make_qr_png(web_manager_qr_url(ip, port), qr_path, scale=4, border=4)
                picture = LoadPixmap(qr_path)
                if picture is None:
                    # Retry once if Enigma2 rejected an older partial/cached PNG.
                    make_qr_png(web_manager_qr_url(ip, port), qr_path, scale=4, border=4)
                    picture = LoadPixmap(qr_path)
                if picture is None:
                    raise RuntimeError('QR image could not be decoded')
                if self['qr'].instance:
                    self['qr'].instance.setPixmap(picture)
                self['qr'].show()
                self['webHint'].setText('Access Code: %s  |  Same local Wi-Fi required.' % web_access_pin())
            else:
                self['qr'].hide()
                self['webHint'].setText(str(status.get('error') or
                    'Web access unavailable. Check LAN and press GREEN.'))
        except Exception as exc:
            self['qr'].hide()
            self['webStatus'].setText('Web server OFF')
            self['webUrl'].setText('')
            self['webHint'].setText('Web QR unavailable: %s' % str(exc)[:55])

    @staticmethod
    def _quickM3ULiveProbe(source):
        """Read only the M3U header; never download a huge playlist to test it."""
        candidate = str(source.get("path") or source.get("url") or "").strip()
        mode = str(source.get("m3u_mode") or "").strip().lower()
        if mode == "file" or not candidate.lower().startswith(("http://", "https://")):
            with open(os.path.expanduser(candidate), "rb") as handle:
                chunk = handle.read(256)
        else:
            from urllib.request import Request, urlopen
            req = Request(candidate, headers={"Range": "bytes=0-255", "User-Agent": "TiviMateE2"})
            response = urlopen(req, timeout=5)
            try:
                chunk = response.read(256)
            finally:
                response.close()
        return {"ok": chunk.lstrip(b"\xef\xbb\xbf\r\n ").startswith(b"#EXTM3U")}

    def _startServerProbe(self):
        """An explicit, single-server probe; no implicit multi-server scan."""
        if self._statusProbeClosed or self._statusProbeBusy or not self._serverRows:
            return
        try:
            index = int(self["servers"].getSelectedIndex())
        except Exception:
            index = 0
        if not 0 <= index < len(self._serverRows):
            return
        source, selected = self._serverRows[index]
        source = dict(source)
        identity = _source_identity(source)
        self._statusProbeBusy = True
        self._statusProbeToken += 1
        token = self._statusProbeToken
        self._statusProbeResult = None
        source["_live_probe_connection"] = "checking"
        source["_live_probe_account"] = "na"
        self._serverRows[index] = (source, selected)
        self._refreshProbeRows(index)
        self["hint"].setText("Testing selected server only...   You can still navigate")

        def worker():
            stype = str(source.get("type") or "").strip().lower()
            reply = None
            expiry = ""
            failure = None
            try:
                if stype == "xtream":
                    reply = XtreamClient(source).test()
                    expiry = _extract_xtream_expiry(reply)
                elif stype == "stalker":
                    reply = StalkerClient(source).test()
                    expiry = str(reply.get("expiry") or "") if isinstance(reply, dict) else ""
                elif stype == "m3u":
                    reply = self._quickM3ULiveProbe(source)
                else:
                    reply = get_source_client(source).test()
            except Exception as exc:
                failure = exc
            status = check_live_source(stype, reply, expiry=expiry, error=failure)
            # Xtream reports how many connections are in use: show BUSY/FREE.
            try:
                user = reply.get("user_info") if isinstance(reply, dict) and isinstance(reply.get("user_info"), dict) else {}
                if stype == "xtream" and str(user.get("max_connections") or "").strip() not in ("", "None"):
                    status = dict(status)
                    status["connections"] = "%d/%d" % (int(float(user.get("active_cons") or 0)), int(float(user.get("max_connections") or 0)))
            except Exception:
                pass
            # Stalker has no connection counter: open one real channel stream
            # for a moment. 458/429/453 = the MAC is used by another device.
            if stype == "stalker" and failure is None and isinstance(reply, dict) and reply.get("ok"):
                slot = _stalker_slot_probe(source, 35.0)
                if slot:
                    status = dict(status)
                    status["connections"] = slot
            # Only the UI timer applies the result. No Enigma calls from workers.
            self._statusProbeResult = (token, index, identity, status)

        thread = threading.Thread(target=worker, name="TiviMateSelectedLiveServerTest")
        thread.daemon = True
        try:
            thread.start()
            self._statusProbeTimer.start(120, False)
        except Exception:
            self._statusProbeBusy = False
            source["_live_probe_connection"] = "failed"
            self._serverRows[index] = (source, selected)
            self._refreshProbeRows(index)
            self["hint"].setText("Server test could not start")

    def _refreshProbeRows(self, index):
        """Update a short list without changing focus or launching probes."""
        try:
            self["servers"].setRows(self._serverRows)
            self["servers"].moveToIndex(max(0, min(index, len(self._serverRows) - 1)))
        except Exception:
            pass
        self._refreshQuickProbeCard()

    def _finishServerProbe(self):
        if self._statusProbeClosed:
            return
        result = self._statusProbeResult
        if result is None:
            if self._statusProbeBusy:
                try:
                    self._statusProbeTimer.start(120, False)
                except Exception:
                    pass
            return
        self._statusProbeResult = None
        token, index, identity, status = result
        if token != self._statusProbeToken:
            return
        self._statusProbeBusy = False
        if not 0 <= index < len(self._serverRows):
            return
        original, selected = self._serverRows[index]
        if _source_identity(original) != identity:
            return
        updated = dict(original)
        updated["_live_probe_account"] = status.get("account", "unknown")
        updated["_live_probe_connection"] = status.get("connection", "failed")
        updated["_live_probe_expiry"] = status.get("expiry") or None
        updated["_live_probe_cons"] = status.get("connections") or ""
        updated["_last_status"] = status.get("legacy_status", "unknown")
        updated["_last_status_at"] = int(time.time())
        if status.get("expiry"):
            updated["_last_expiry"] = str(status["expiry"])
        self._serverRows[index] = (updated, selected)
        try:
            focus_index = int(self["servers"].getSelectedIndex())
        except Exception:
            focus_index = index
        self._refreshProbeRows(focus_index)
        self["hint"].setText("Test finished   •   BLUE  Test selected       OK  Select       EXIT  Close")
        # Save just the explicitly checked source. Keep other servers untouched.
        try:
            saved = list(get_sources() or [])
            for old_source in saved:
                if _source_identity(old_source) != identity:
                    continue
                old_source["_last_status"] = updated["_last_status"]
                old_source["_last_status_at"] = updated["_last_status_at"]
                if updated.get("_last_expiry"):
                    old_source["_last_expiry"] = updated["_last_expiry"]
                set_sources(saved)
                break
        except Exception:
            pass

    def _cleanupProfessionalUI(self):
        self._statusProbeClosed = True
        self._statusProbeToken += 1
        try:
            self._statusProbeTimer.stop()
        except Exception:
            pass
        try:
            self._clockTimer.stop()
        except Exception:
            pass
        # Keep the tiny LAN QR cached. Regenerating it on every popup open
        # caused avoidable flash writes even though the address had not changed.

    def _currentSource(self):
        row = self["servers"].getCurrent()
        return row[0] if row and isinstance(row[0], dict) else None

    @staticmethod
    def _cleanSelectionSource(source):
        # Probe-specific fields belong to this screen, not the persistent
        # source configuration or favourite/playback identities.
        return {key: value for key, value in dict(source).items()
                if not str(key).startswith("_live_probe_")}

    def deleteCurrent(self):
        source = self._currentSource()
        if not source:
            return
        self.close(("delete", self._cleanSelectionSource(source)))

    def testCurrent(self):
        # Test only this row, asynchronously and inline; never close the screen.
        self._startServerProbe()

    def ok(self):
        row = self["servers"].getCurrent()
        source = row[0] if row else None
        self.close(self._cleanSelectionSource(source) if isinstance(source, dict) else None)


BACKUP_SCHEMA_VERSION = 1
BACKUP_FOLDER = data_path("backups")

_BACKUP_FILE_GROUPS = {
    "filters": [
        data_path("category_filters.json"),
        data_path("stalker_hidden.json"),
        data_path("xtream_hidden.json"),
        data_path("stalker_pin.json"),
        data_path("xtream_pin.json"),
    ],
    "favorites": [favorites_path("favorites.json"),
                  favorites_path("live_package_favorites.json"),
                  favorites_path("media_package_favorites.json"),
                  "/etc/enigma2/tivimatee2_live_favorite_exclusions.json"],
    "app_settings": [
        data_path("channel_settings.json"), data_path("live_source.json"),
        HOME_APPEARANCE_FILE, data_path("update_settings.json"),
        data_path("active_source.json"), data_path("language.json"),
        data_path("tmdb.json"), data_path("cache_settings.json"),
        data_path("recording.json"), data_path("subdl.json"),
        data_path("backup_auto_settings.json"),
    ],
    "continue": [data_path("resume.json")],
    "player": [
        data_path("player.json"), data_path("player_preferences.json"),
        data_path("xtream_service_types.json"), data_path("stalker_service_types.json"),
    ],
}


def _backup_read_file(path):
    try:
        if not os.path.exists(path):
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            raw = handle.read()
        try:
            return {"format": "json", "value": json.loads(raw)}
        except Exception:
            return {"format": "text", "value": raw}
    except Exception:
        return None


def _backup_write_file(path, record):
    if not isinstance(record, dict):
        return False
    try:
        ensure_dir(os.path.dirname(path))
        tmp = path + ".restore.tmp"
        if record.get("format") == "json":
            raw = json.dumps(record.get("value"), ensure_ascii=False, indent=2, sort_keys=True)
        else:
            raw = str(record.get("value") or "")
        with open_text(tmp, "w", encoding="utf-8") as handle:
            handle.write(raw)
        atomic_replace(tmp, path)
        return True
    except Exception:
        return False


def _backup_group_count(group):
    try:
        if group == "servers":
            return len(get_sources() or [])
        if group == "filters":
            total = 0
            for path in _BACKUP_FILE_GROUPS["filters"]:
                data = load_json(path, {}) or {}
                if isinstance(data, dict):
                    for value in data.values():
                        if isinstance(value, dict):
                            for key in ("live", "vod", "series", "categories", "channels"):
                                rows = value.get(key)
                                if isinstance(rows, (list, tuple, set)):
                                    total += len(rows)
                        elif isinstance(value, list):
                            total += len(value)
            return total
        if group == "favorites":
            try:
                return int(favourites_count() or 0)
            except Exception:
                data = load_json(favorites_path("favorites.json"), {}) or {}
                return len(data.get("items") or []) if isinstance(data, dict) else 0
        if group == "continue":
            data = load_json(data_path("resume.json"), {}) or {}
            return len(data) if isinstance(data, dict) else 0
        if group in ("app_settings", "player"):
            return sum(1 for path in _BACKUP_FILE_GROUPS.get(group, []) if os.path.exists(path))
    except Exception:
        pass
    return 0


def _create_selected_backup(selected):
    ensure_dir(BACKUP_FOLDER)
    payload = {
        "schema": BACKUP_SCHEMA_VERSION,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "groups": {},
    }
    for group in selected:
        if group == "servers":
            payload["groups"][group] = {"servers": get_sources() or []}
            continue
        files = {}
        for path in _BACKUP_FILE_GROUPS.get(group, []):
            record = _backup_read_file(path)
            if record is not None:
                files[os.path.basename(path)] = record
        payload["groups"][group] = {"files": files}
    stamp = time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join(BACKUP_FOLDER, "tivimatee2-backup-%s.json" % stamp)
    tmp = path + ".tmp"
    with open_text(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    atomic_replace(tmp, path)
    return path


def _latest_backup_file():
    try:
        rows = [os.path.join(BACKUP_FOLDER, name) for name in os.listdir(BACKUP_FOLDER)
                if name.startswith("tivimatee2-backup-") and name.endswith(".json")]
        rows = [path for path in rows if os.path.isfile(path)]
        return max(rows, key=os.path.getmtime) if rows else ""
    except Exception:
        return ""


def _restore_selected_backup(path, selected):
    with open_text(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle) or {}
    groups = payload.get("groups") or {}
    restored = []
    for group in selected:
        record = groups.get(group)
        if not isinstance(record, dict):
            continue
        if group == "servers":
            servers = record.get("servers") or []
            set_sources(servers)
            write_playlists(servers)
            restored.append(group)
            continue
        by_name = record.get("files") or {}
        for target in _BACKUP_FILE_GROUPS.get(group, []):
            saved = by_name.get(os.path.basename(target))
            if saved is not None:
                _backup_write_file(target, saved)
        restored.append(group)
    return restored




BACKUP_AUTO_SETTINGS_FILE = data_path("backup_auto_settings.json")

def _backup_files():
    try:
        ensure_dir(BACKUP_FOLDER)
        rows = [os.path.join(BACKUP_FOLDER, name) for name in os.listdir(BACKUP_FOLDER)
                if name.startswith("tivimatee2-backup-") and name.endswith(".json")]
        rows = [path for path in rows if os.path.isfile(path)]
        return sorted(rows, key=os.path.getmtime, reverse=True)
    except Exception:
        return []

def _backup_all_groups():
    return set(["servers", "filters", "favorites", "app_settings", "continue", "player"])

def _backup_auto_settings():
    data = load_json(BACKUP_AUTO_SETTINGS_FILE, {}) or {}
    return {
        "enabled": bool(data.get("enabled", False)),
        "last_run": int(data.get("last_run", 0) or 0),
    }

def _save_backup_auto_settings(settings):
    try:
        save_json(BACKUP_AUTO_SETTINGS_FILE, settings)
        return True
    except Exception:
        return False


def run_auto_backup_if_due(force=False):
    """Create the configured daily backup without requiring the Backup screen."""
    settings = _backup_auto_settings()
    if not settings.get("enabled"):
        return False
    now = int(time.time())
    last_run = int(settings.get("last_run", 0) or 0)
    if not force and last_run and (now - last_run) < 86400:
        return False
    try:
        _create_selected_backup(_backup_all_groups())
        settings["last_run"] = now
        _save_backup_auto_settings(settings)
        return True
    except Exception:
        return False

def _backup_validate_file(path):
    try:
        with open_text(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle) or {}
        return isinstance(payload, dict) and isinstance(payload.get("groups"), dict)
    except Exception:
        return False

def _backup_import_candidates():
    roots = ["/media/hdd", "/media/usb", "/media/mmc", "/media/net", "/tmp"]
    rows = []
    seen = set()
    for root in roots:
        if not os.path.isdir(root):
            continue
        try:
            for name in os.listdir(root):
                path = os.path.join(root, name)
                if os.path.isfile(path) and name.endswith(".json") and ("backup" in name.lower()):
                    if path not in seen and _backup_validate_file(path):
                        seen.add(path); rows.append(path)
        except Exception:
            pass
    return rows

BACKUP_DASHBOARD_R135_SKIN = r"""<screen name="TiviMateBackupRestore" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#01060B">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/backup_dashboard_r198.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus" position="234,292" size="476,344" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/backup_focus_r198.png" alphatest="blend" zPosition="10"/>
    <widget name="status0" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status1" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status2" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status3" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status4" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
    <widget name="status5" position="-20,-20" size="1,1" font="Regular;1" transparent="1" zPosition="1"/>
</screen>"""


class BackupRestoreScreen(Screen):
    skin = scale_skin(BACKUP_DASHBOARD_R135_SKIN)

    POSITIONS = [(234,292), (729,292), (1225,292), (234,634), (729,634), (1225,634)]

    def __init__(self, session):
        Screen.__init__(self, session)
        self.index = 0
        self["focus"] = Pixmap()
        for i in range(6):
            self["status%d" % i] = Label("")
        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.openCurrent, "cancel": self.close,
                "left": self.left, "right": self.right,
                "up": self.up, "down": self.down,
                "green": self.openCurrent,
                "yellow": self.showInfo,
                "blue": self.manageBackups,
                "red": self.close,
            }, -1
        )
        self.onLayoutFinish.append(self._layoutReady)

    def _layoutReady(self):
        self._maybeAutoBackup()
        self.refresh()
        self._focus()

    def _focus(self):
        try:
            x, y = self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x), sy(y)))
            self["focus"].show()
        except Exception:
            pass

    def left(self):
        row = self.index // 3
        col = self.index % 3
        self.index = row * 3 + ((col - 1) % 3)
        self._focus()

    def right(self):
        row = self.index // 3
        col = self.index % 3
        self.index = row * 3 + ((col + 1) % 3)
        self._focus()

    def up(self):
        self.index = (self.index - 3) % 6
        self._focus()

    def down(self):
        self.index = (self.index + 3) % 6
        self._focus()

    def _backupCount(self):
        return len(_backup_files())

    def _latestText(self):
        path = _latest_backup_file()
        if not path:
            return "No backup yet"
        try:
            return "Last: " + time.strftime("%d %b %Y", time.localtime(os.path.getmtime(path)))
        except Exception:
            return "Backup available"

    def _externalStorageText(self):
        for path, label in (
            ("/media/usb", "USB Ready"),
            ("/media/hdd", "HDD Ready"),
            ("/media/mmc", "MMC Ready"),
            ("/media/net", "Network Ready"),
        ):
            try:
                if os.path.ismount(path) or os.path.isdir(path):
                    return label
            except Exception:
                pass
        return "No External Storage"

    def refresh(self):
        count = self._backupCount()
        auto = _backup_auto_settings()
        self["status0"].setText("%d Backup%s" % (count, "" if count == 1 else "s"))
        self["status1"].setText(self._latestText())
        self["status2"].setText("AUTO  %s" % ("ON" if auto.get("enabled") else "OFF"))
        self["status3"].setText("%d Backup%s" % (count, "" if count == 1 else "s"))
        self["status4"].setText(self._externalStorageText())
        self["status5"].setText("%d Available" % count)

    def openCurrent(self):
        actions = (
            self.createBackup,
            self.restoreBackup,
            self.toggleAutoBackup,
            self.manageBackups,
            self.importBackup,
            self.deleteBackup,
        )
        if 0 <= self.index < len(actions):
            actions[self.index]()

    def createBackup(self):
        try:
            path = _create_selected_backup(_backup_all_groups())
            auto = _backup_auto_settings()
            if auto.get("enabled"):
                auto["last_run"] = int(time.time())
                _save_backup_auto_settings(auto)
            self.refresh()
            self.session.open(MessageBox, "Backup created successfully.\n\n%s" % path, MessageBox.TYPE_INFO, timeout=7)
        except Exception as exc:
            self.session.open(MessageBox, "Backup failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def _backupChoices(self):
        choices = []
        for path in _backup_files():
            try:
                stamp = time.strftime("%d %b %Y  %H:%M", time.localtime(os.path.getmtime(path)))
            except Exception:
                stamp = os.path.basename(path)
            choices.append(("%s   •   %s" % (stamp, os.path.basename(path)), path))
        return choices

    def restoreBackup(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backup file is available yet.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._restoreSelected, ChoiceBox, title="RESTORE BACKUP", list=choices)

    def _restoreSelected(self, selected=None):
        if not selected:
            return
        path = selected[1]
        self.session.openWithCallback(
            lambda answer, p=path: self._restoreConfirmed(p) if answer else None,
            MessageBox,
            "Restore all available settings from:\n%s ?" % os.path.basename(path),
            MessageBox.TYPE_YESNO
        )

    def _restoreConfirmed(self, path):
        try:
            restored = _restore_selected_backup(path, _backup_all_groups())
            self.refresh()
            self.session.open(
                MessageBox,
                "Restore completed: %s\n\nRestart TiviMateE2 / Enigma2 to reload restored settings." %
                (", ".join(restored) if restored else "no matching sections"),
                MessageBox.TYPE_INFO, timeout=8
            )
        except Exception as exc:
            self.session.open(MessageBox, "Restore failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def toggleAutoBackup(self):
        settings = _backup_auto_settings()
        settings["enabled"] = not bool(settings.get("enabled"))
        if settings["enabled"] and not settings.get("last_run"):
            settings["last_run"] = 0
        _save_backup_auto_settings(settings)
        self._maybeAutoBackup(force=False)
        self.refresh()
        self.session.open(
            MessageBox,
            "Automatic daily backup is %s." % ("ON" if settings["enabled"] else "OFF"),
            MessageBox.TYPE_INFO, timeout=4
        )

    def _maybeAutoBackup(self, force=False):
        run_auto_backup_if_due(force=force)

    def manageBackups(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backups to manage.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._manageSelected, ChoiceBox, title="MANAGE BACKUPS", list=choices)

    def _manageSelected(self, selected=None):
        if not selected:
            return
        path = selected[1]
        choices = [
            ("RESTORE", ("restore", path)),
            ("INFO", ("info", path)),
            ("DELETE", ("delete", path)),
        ]
        self.session.openWithCallback(self._manageAction, ChoiceBox, title=os.path.basename(path), list=choices)

    def _manageAction(self, selected=None):
        if not selected:
            return
        action, path = selected[1]
        if action == "restore":
            self._restoreSelected(("restore", path))
        elif action == "delete":
            self._deletePathAsk(path)
        else:
            self._showBackupInfo(path)

    def _showBackupInfo(self, path):
        try:
            with open_text(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle) or {}
            groups = sorted((payload.get("groups") or {}).keys())
            created = payload.get("created_at") or "Unknown"
            text = "File: %s\nCreated: %s\nSections: %s" % (
                os.path.basename(path), created, ", ".join(groups) if groups else "None"
            )
        except Exception:
            text = "Unable to read backup information."
        self.session.open(MessageBox, text, MessageBox.TYPE_INFO, timeout=8)

    def importBackup(self):
        candidates = _backup_import_candidates()
        if not candidates:
            self.session.open(
                MessageBox,
                "No compatible backup JSON was found on HDD, USB, MMC, network storage or /tmp.",
                MessageBox.TYPE_INFO, timeout=6
            )
            return
        choices = [(os.path.basename(path) + "   •   " + os.path.dirname(path), path) for path in candidates]
        self.session.openWithCallback(self._importSelected, ChoiceBox, title="IMPORT BACKUP", list=choices)

    def _importSelected(self, selected=None):
        if not selected:
            return
        src = selected[1]
        if not _backup_validate_file(src):
            self.session.open(MessageBox, "Invalid backup file.", MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            ensure_dir(BACKUP_FOLDER)
            name = os.path.basename(src)
            if not name.startswith("tivimatee2-backup-"):
                name = "tivimatee2-backup-import-%s.json" % time.strftime("%Y%m%d-%H%M%S")
            dst = os.path.join(BACKUP_FOLDER, name)
            if os.path.exists(dst):
                dst = os.path.join(BACKUP_FOLDER, "tivimatee2-backup-import-%s.json" % time.strftime("%Y%m%d-%H%M%S"))
            with open(src, "rb") as rf:
                data = rf.read()
            tmp = dst + ".tmp"
            with open(tmp, "wb") as wf:
                wf.write(data)
            atomic_replace(tmp, dst)
            self.refresh()
            self.session.open(MessageBox, "Backup imported successfully.", MessageBox.TYPE_INFO, timeout=5)
        except Exception as exc:
            self.session.open(MessageBox, "Import failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=6)

    def deleteBackup(self):
        choices = self._backupChoices()
        if not choices:
            self.session.open(MessageBox, "No backups to delete.", MessageBox.TYPE_INFO, timeout=4)
            return
        self.session.openWithCallback(self._deleteSelected, ChoiceBox, title="DELETE BACKUP", list=choices)

    def _deleteSelected(self, selected=None):
        if selected:
            self._deletePathAsk(selected[1])

    def _deletePathAsk(self, path):
        self.session.openWithCallback(
            lambda answer, p=path: self._deletePath(p) if answer else None,
            MessageBox,
            "Delete backup?\n%s" % os.path.basename(path),
            MessageBox.TYPE_YESNO
        )

    def _deletePath(self, path):
        try:
            os.remove(path)
            self.refresh()
            self.session.open(MessageBox, "Backup deleted.", MessageBox.TYPE_INFO, timeout=4)
        except Exception as exc:
            self.session.open(MessageBox, "Delete failed:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def showInfo(self):
        descriptions = [
            "Create a full backup of servers, filters, favourites, application settings, history and player preferences.",
            "Restore all matching settings from a selected backup file.",
            "Toggle automatic backup. When enabled, one backup is created per day when TiviMateE2 starts.",
            "Browse existing backups and restore, inspect or delete them.",
            "Import a compatible backup JSON from external storage.",
            "Choose and permanently delete an existing backup file.",
        ]
        self.session.open(MessageBox, descriptions[self.index], MessageBox.TYPE_INFO, timeout=7)



SUBTITLE_DASHBOARD_SKIN = r"""<screen name="SubtitleDashboard" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/subtitle_dashboard_r119.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus" position="53,278" size="895,310" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/subtitle_focus_r177.png" alphatest="blend" zPosition="8"/>
</screen>"""

class SubtitleDashboard(Screen):
    skin = SUBTITLE_DASHBOARD_SKIN
    POSITIONS=[(53,278),(972,278),(53,610),(972,610)]

    def __init__(self,session):
        Screen.__init__(self,session)
        self.index=0
        self["focus"]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{
            "ok":self.openCurrent,"cancel":self.close,
            "left":self.left,"right":self.right,"up":self.up,"down":self.down,
        },-1)
        self.onLayoutFinish.append(self._focus)

    def _focus(self):
        try:
            x,y=self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:pass

    def left(self):
        self.index=self.index-1 if self.index%2 else self.index+1
        self._focus()
    def right(self):
        self.left()
    def up(self):
        self.index=(self.index-2)%4; self._focus()
    def down(self):
        self.index=(self.index+2)%4; self._focus()

    def openCurrent(self):
        if self.index==0:
            # IMPORT SUBTITLE tile now opens the existing Add API dashboard.
            self.openSubtitleApiManager(); return
        if self.index==1:
            self.session.open(SubDLSubtitleLanguageSettings); return
        if self.index==2:
            # IMAGE CACHE tile: open the actual image-cache settings screen.
            self.session.open(ImageCacheSettings); return
        if self.index==3:
            # EXTERNAL SUBTITLE tile opens the existing advanced font/style editor.
            self.openExternalSubtitleFont(); return

    def openSubtitleApiManager(self):
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import (
                TiviMateSubtitleApiManager, E2SubsSeeker, initTiviMateSettings
            )
            settings = initTiviMateSettings()
            seeker = E2SubsSeeker(self.session, settings.search, debug=False)
            self.session.open(TiviMateSubtitleApiManager, seeker)
        except Exception as exc:
            self.session.open(
                MessageBox,
                "Could not open Subtitle API settings.\n\n%s" % exc,
                MessageBox.TYPE_ERROR,
                timeout=7,
            )

    def importSubDLKey(self):
        try:
            value=_read_subdl_import_key()
            current=load_subdl_settings()
            save_subdl_settings(value,current.get("language","ar"),current.get("kind","standard"))
            removed=_remove_subdl_import_file()
            msg=("SubDL key imported and saved. Temporary key file removed." if removed else
                 "SubDL key imported and saved. Remove the imported key file manually to protect your key.")
            self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=6)
        except IOError:
            self.session.open(MessageBox,
                "Put one SubDL API key in key.txt on HDD, USB, MMC or /etc/enigma2, then select Import Subtitle.",
                MessageBox.TYPE_INFO,timeout=7)
        except ValueError:
            self.session.open(MessageBox,"Invalid SubDL key file. It must contain exactly one API key.",MessageBox.TYPE_ERROR,timeout=7)
        except Exception:
            self.session.open(MessageBox,"Could not import the SubDL key.",MessageBox.TYPE_ERROR,timeout=7)

    def openServerSubtitleFont(self):
        try:
            subtitles=getattr(config,"subtitles",None)
            setting=getattr(subtitles,"subtitle_fontsize",None) if subtitles is not None else None
            if setting is None: raise RuntimeError("native subtitle font setting unavailable")
            current=str(getattr(setting,"value","") or "")
            sizes=[]
            try:
                for entry in (getattr(setting,"choices",None) or []):
                    value=entry[0] if isinstance(entry,(tuple,list)) else entry
                    value=str(value)
                    if value.isdigit() and value not in sizes:sizes.append(value)
            except Exception:sizes=[]
            if not sizes:sizes=[str(x) for x in range(16,50,2)]
            choices=[("%s px%s"%(v,"  •  Current" if v==current else ""),v) for v in sizes]
            self.session.openWithCallback(self._serverFontSelected,ChoiceBox,title="SERVER SUBTITLE FONT",list=choices)
        except Exception:
            self.session.open(MessageBox,"Native Enigma2 subtitle font settings are not available on this image.",MessageBox.TYPE_ERROR,timeout=6)

    def _serverFontSelected(self,choice=None):
        if not choice:return
        try:
            value=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
            setting=config.subtitles.subtitle_fontsize
            setting.value=str(value)
            try:setting.save()
            except Exception:pass
            try:configfile.save()
            except Exception:pass
            self.session.open(MessageBox,"Server subtitle font size saved: %s"%value,MessageBox.TYPE_INFO,timeout=3)
        except Exception:
            self.session.open(MessageBox,"Could not save the native subtitle font size.",MessageBox.TYPE_ERROR,timeout=5)

    def openExternalSubtitleFont(self):
        try:
            from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import (
                initTiviMateSettings, TiviMateSetupExternal
            )
            settings = initTiviMateSettings()
            external = getattr(settings, "external", None)
            if external is None:
                raise RuntimeError("missing external subtitle settings")
            def _applied(*args):
                try:
                    from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import applySubtitleFontAsReplacement
                    applySubtitleFontAsReplacement(settings)
                except Exception:
                    pass
            self.session.openWithCallback(_applied, TiviMateSetupExternal, external)
        except Exception as exc:
            self.session.open(
                MessageBox,
                "Could not open External Subtitle font settings.\n\n%s" % exc,
                MessageBox.TYPE_ERROR,
                timeout=7,
            )



E2_IPTV_FINDER_SKIN = scale_skin(r"""<screen name="TiviMateE2IPTVFinder" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/finder/finder_final_approved.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="title" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="subtitle" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="brand" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterAll" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterStalker" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterXtream" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="filterM3U" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="daysBox" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="searchBox" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="summary" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="status" position="1190,154" size="520,60" font="Regular;22" foregroundColor="#DDE7F0" transparent="1" halign="right" valign="center" zPosition="18"/>
    <widget name="quickAnim" position="1725,154" size="65,60" font="Regular;28" foregroundColor="#67E89A" transparent="1" halign="center" valign="center" zPosition="19"/>
    <widget name="typeLogoTop" position="980,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="typeLogoXtream" position="910,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="typeLogoStalker" position="980,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="typeLogoM3U" position="1050,155" size="58,58" alphatest="blend" scale="1" zPosition="20"/>
    <widget name="sourceLogoTop" position="1120,160" size="48,48" alphatest="blend" scale="1" zPosition="21"/>
    <widget name="pageNumbers" position="330,154" size="555,60" font="Regular;29" foregroundColor="#FFFFFF" transparent="1" halign="left" valign="center" zPosition="18"/>
    <widget name="tableHead" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailIcon" position="0,0" size="1,1" alphatest="blend"/>
    <widget name="detailType" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailOnline" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailUrl" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailInfo" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="detailAction" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="hint" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="list" position="286,225" size="1580,660" backgroundColor="#00101A" foregroundColor="#F4FAFF" transparent="1" scrollbarMode="showOnDemand" zPosition="10" selectionPixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/finder/finder_row_focus_cyan.png" selectionBackgroundColor="#00101A" selectionForegroundColor="#FFFFFF"/>
    <widget name="fieldUrl" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="fieldUser" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="fieldPass" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
    <widget name="fieldMac" position="0,0" size="1,1" font="Regular;1" transparent="1"/>
</screen>""")

class IPTVFinderResultList(MenuList):
    def __init__(self):
        MenuList.__init__(self, [], False, eListboxPythonMultiContent)
        try:
            self.l.setFont(0, gFont("Regular", 23))
            self.l.setFont(1, gFont("Regular", 21))
            self.l.setFont(2, gFont("Regular", 20))
            self.l.setItemHeight(66)
        except Exception:
            pass

        self._finder_type_pixmaps = {}
        for _kind, _rel in {
            "xtream": "skins/server/finder_xtream_round_small.png",
            "stalker": "skins/server/finder_stalker_round_small.png",
            "m3u": "skins/server/finder_m3u_round_small.png",
        }.items():
            try:
                self._finder_type_pixmaps[_kind] = LoadPixmap(os.path.join(PLUGIN_PATH, _rel))
            except Exception:
                self._finder_type_pixmaps[_kind] = None

        # Reuse the exact Live Server LED assets.
        self._finder_leds = {}
        for _state, _rel in {
            "online": "skins/live/estalker_led_green.png",
            "reachable": "skins/live/estalker_led_yellow.png",
            "offline": "skins/live/estalker_led_red.png",
            "unknown": "skins/live/estalker_led_grey.png",
        }.items():
            try:
                self._finder_leds[_state] = LoadPixmap(os.path.join(PLUGIN_PATH, _rel))
            except Exception:
                self._finder_leds[_state] = None

    def _rowMac(self, row):
        try:
            direct = str((row or {}).get("mac") or "").strip().upper().replace("-", ":")
            if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$", direct):
                return direct
            post = (row or {}).get("post") if isinstance((row or {}).get("post"), dict) else {}
            macs = post.get("macs") or []
            if not isinstance(macs, (list, tuple)):
                macs = [macs]
            for entry in macs:
                if isinstance(entry, dict):
                    value = str(entry.get("mac") or entry.get("value") or "")
                else:
                    value = str(entry or "")
                value = value.strip().upper().replace("-", ":")
                if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$", value):
                    return value
        except Exception:
            pass
        return ""

    def setResults(self, rows):
        self.setList([self._row(row) for row in (rows or [])])

    def _row(self, row):
        row = row or {}
        url = str(row.get("url") or "")
        kind = str(row.get("kind") or "").lower()
        raw_expiry = str(row.get("expiry") or row.get("_last_expiry") or "").strip()
        scan = str(row.get("_scan") or row.get("status") or "FOUND").strip().upper()

        try:
            expiry_txt = _format_server_expiry(raw_expiry)
        except Exception:
            expiry_txt = "—"
        if expiry_txt == "—":
            expiry_txt = "--"

        online = scan in ("VALID", "ONLINE", "OK", "WORKING")
        reachable = scan in ("REACHABLE", "PORTAL", "PORTAL ONLY")
        offline = scan in ("DEAD", "INVALID", "OFFLINE")
        if online:
            led = self._finder_leds.get("online")
            status_text = "ONLINE"
            status_color = 0x0067E89A
        elif reachable:
            led = self._finder_leds.get("reachable") or self._finder_leds.get("unknown")
            status_text = "PORTAL"
            status_color = 0x00F6B717
        elif offline:
            led = self._finder_leds.get("offline")
            status_text = "OFFLINE"
            status_color = 0x00FF6B78
        else:
            led = self._finder_leds.get("unknown")
            status_text = "--"
            status_color = 0x0098A6B8

        entries = [row]

        type_pix = self._finder_type_pixmaps.get(kind)
        if type_pix is not None:
            entries.append(MultiContentEntryPixmapAlphaBlend(
                pos=(16,19), size=(28,28), png=type_pix
            ))

        # Keep Stalker portal + MAC on the same row in separate clean columns.
        if kind == "stalker":
            mac_txt = self._rowMac(row)
            entries.append(MultiContentEntryText(
                pos=(54,0), size=(700,66), font=0,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=url[:72],
                color=0x00F4FAFF, color_sel=0x00FFFFFF
            ))
            entries.append(MultiContentEntryText(
                pos=(770,0), size=(330,66), font=1,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=("MAC  " + mac_txt) if mac_txt else "MAC  --",
                color=0x00D7F4FF, color_sel=0x00FFFFFF
            ))
            entries.append(MultiContentEntryText(
                pos=(1120,0), size=(225,66), font=1,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=expiry_txt,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ))
        else:
            entries.append(MultiContentEntryText(
                pos=(54,0), size=(790,66), font=0,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=((str(row.get("display_name") or "") + "  •  " + url) if row.get("display_name") else url)[:84],
                color=0x00F4FAFF, color_sel=0x00FFFFFF
            ))
            entries.append(MultiContentEntryText(
                pos=(875,0), size=(230,66), font=1,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=expiry_txt,
                color=0x00D5DDE8, color_sel=0x00FFFFFF
            ))

        # FAST catalogue rows are not server probes.  Do not show the generic
        # ONLINE/OFFLINE indicator for them; it is meaningful only for real
        # Stalker/Xtream/traditional M3U checks.
        _post = row.get("post") if isinstance(row.get("post"), dict) else {}
        _finder_source = str(_post.get("finder_source") or row.get("finder_source") or "").strip().lower()
        _fast_service = str(row.get("fast_service") or "").strip().lower()
        _fast_sources = ("samsungtv", "xiaomitv", "xumotv", "xumo", "freetv", "localnow", "lgchannels", "roku", "tubitv", "vizio", "tclplus", "freelivesports")
        _is_fast_row = bool(
            _fast_service in _fast_sources or
            _finder_source in _fast_sources or
            row.get("samsung_group") or row.get("xiaomi_group") or
            url.lower().startswith("fastm3u://")
        )
        if not _is_fast_row:
            if led is not None:
                entries.append(MultiContentEntryPixmapAlphaBlend(
                    pos=(1370,21), size=(23,24), png=led
                ))
            entries.append(MultiContentEntryText(
                pos=(1404,0), size=(150,66), font=2,
                flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER,
                text=status_text,
                color=status_color, color_sel=status_color
            ))
        return entries

class TiviMateE2IPTVFinder(Screen):
    skin = E2_IPTV_FINDER_SKIN
    def __init__(self,session):
        Screen.__init__(self,session)
        self._generation=0; self._running=False; self._scan_running=False; self._results=[]; self._all_results=[]; self._page=0; self._page_size=100; self._mode="all"; self._source="all"; self._days=0
        self._quick_anim_step=0
        # Independent one-shot UI guards for slow public playlist providers.
        # Download threads and their built-in network timeouts are untouched.
        self._fastPlaylistTimer=eTimer()
        self._iptvorgPlaylistTimer=eTimer()
        _connect_timer(self._fastPlaylistTimer, self._fastPlaylistStalled)
        _connect_timer(self._iptvorgPlaylistTimer, self._iptvorgPlaylistStalled)
        self._fastPlaylistRequest=None
        self._iptvorgPlaylistRequest=None
        self._fastPlaylistSerial=0
        self._iptvorgPlaylistSerial=0
        self._quick_anim_timer=eTimer()
        try:self._quick_anim_timer.callback.append(self._quickAnimTick)
        except Exception:
            try:self._quick_anim_timer.timeout.connect(self._quickAnimTick)
            except Exception:pass
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["brand"]=Label("TiviMateE2  •  SEARCH  •  CHECK")
        self["filterAll"]=Label("▦  ALL"); self["filterStalker"]=Label("STALKER")
        self["filterXtream"]=Label("XTREAM"); self["filterM3U"]=Label("M3U")
        self["daysBox"]=Label("ALL DATES"); self["searchBox"]=Label("⌕  SEARCH")
        self["summary"]=Label("Press GREEN to search")
        self["status"]=Label("")
        self["quickAnim"]=Label("")
        self["typeLogoTop"]=Pixmap()
        self["typeLogoXtream"]=Pixmap()
        self["typeLogoStalker"]=Pixmap()
        self["typeLogoM3U"]=Pixmap()
        self["sourceLogoTop"]=Pixmap()
        self["pageNumbers"]=Label("0 RESULTS")
        self["tableHead"]=Label("TYPE   SERVER / URL                         EXPIRY            ONLINE")
        self["list"]=IPTVFinderResultList()
        self["detailIcon"]=Pixmap(); self["detailType"]=Label("SELECT SERVER")
        self["detailOnline"]=Label(""); self["detailUrl"]=Label("")
        self["detailInfo"]=Label("Choose a working result to view its information.")
        self["detailAction"]=Label("OK  •  ADD SERVER")
        self["hint"]=Label("")
        self["fieldUrl"]=Label("")
        self["fieldUser"]=Label("")
        self["fieldPass"]=Label("")
        self["fieldMac"]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","ColorActions","DirectionActions","MenuActions"],{
            "cancel":self.close,"red":self.quickCheckPage,"ok":self.openCurrent,"green":self.startSearch,
            "menu":self.chooseCheckMode,
            "yellow":self.cycleSource,"blue":self.cycleType,
            "up":self._up,"down":self._down,"left":self._pageUp,"right":self._pageDown},-1)
        self.onLayoutFinish.append(self._finderReady); self.onClose.append(self._closed)
        # Create the Finder log immediately, before layout callbacks run.
        self._finder_log_path = self._finderLog("FINDER_INIT", source=self._source, mode=self._mode)

    def _fastPlaylistStalled(self):
        request = self._fastPlaylistRequest
        if request is None:
            return
        token, request_id, generation, url = request
        if getattr(self, "_fast_open_loading", None) != token:
            return
        self._fast_open_loading = None
        self._fastPlaylistRequest = None
        self._finishPlaylistStatus(generation, url, "PLAYLIST REQUEST EXPIRED — PRESS OK TO RETRY")

    def _iptvorgPlaylistStalled(self):
        request = self._iptvorgPlaylistRequest
        if request is None:
            return
        token, request_id, generation, url = request
        if getattr(self, "_iptvorg_build_loading", None) != token:
            return
        self._iptvorg_build_loading = None
        self._iptvorgPlaylistRequest = None
        self._finishPlaylistStatus(generation, url, "IPTV-ORG REQUEST EXPIRED — PRESS OK TO RETRY")

    def _finishPlaylistStatus(self, selected_generation, selected_url, message):
        """Remove only the Finder playlist's visible LOADING state.

        A finished background request may refer to a row/source the user has
        already left.  Never overwrite the active Finder status in that case.
        """
        try:
            if self._generation != selected_generation:
                return False
            if str((self._selectedRow() or {}).get("url") or "") != selected_url:
                return False
            self["status"].setText(message)
            return True
        except Exception:
            return False

    def _finderLog(self, event, **fields):
        # Persistent Finder diagnostics on HDD. Secrets are never written.
        try:
            import datetime
            # Pick a writable persistent mount automatically. Some images do not mount storage as /media/hdd.
            candidates = ["/media/hdd", "/media/usb", "/media/usb1", "/media/usb2", "/media/usb3", "/media/mmc", "/media/sdcard"]
            try:
                for name in os.listdir("/media"):
                    path = os.path.join("/media", name)
                    if path not in candidates:
                        candidates.append(path)
            except Exception:
                pass
            root = None
            for path in candidates:
                try:
                    if os.path.isdir(path) and os.access(path, os.W_OK):
                        root = path
                        break
                except Exception:
                    pass
            if root is None:
                # Never write Finder diagnostics to /tmp or internal flash.
                return None
            base = os.path.join(root, "tivimatee2")
            if not os.path.isdir(base):
                os.makedirs(base)
            def safe(k, v):
                k=str(k or "").lower()
                if any(x in k for x in ("pass","password","user","username","mac","token","cookie","auth")):
                    return "<redacted>"
                v=str(v if v is not None else "")
                # Strip credentials from common Xtream-style query strings.
                v=re.sub(r'([?&](?:username|password|token)=)[^&\s]+', r'\1<redacted>', v, flags=re.I)
                return v[:800]
            parts=["%s=%s"%(k,safe(k,v)) for k,v in sorted(fields.items())]
            line="[%s] %s%s\n"%(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),str(event),(" | "+" | ".join(parts)) if parts else "")
            log_path=os.path.join(base,"finder_debug.log")
            with open(log_path,"a") as fh:
                fh.write(line); fh.flush()
                try: os.fsync(fh.fileno())
                except Exception: pass
            return log_path
        except Exception:
            return None

    def _finderReady(self):
        self._finderLog("FINDER_OPEN", source=self._source, mode=self._mode)
        self._setFilters()
        self["status"].setText("READY — PRESS GREEN   •   CHECK: %s" % ("AUTO" if self._autoCheckEnabled() else "MANUAL"))
        _lp = self._finder_log_path or self._finderLog("FINDER_READY", source=self._source, mode=self._mode)
        self._finder_log_path = _lp
        if _lp:
            self["summary"].setText("DEBUG LOG: %s" % _lp)
        else:
            self["summary"].setText("")
        self["searchBox"].setText("GREEN = SEARCH")

    def _closed(self):
        self._finderLog("FINDER_CLOSE", results=len(self._results or []), running=self._running, scan_running=self._scan_running)
        for timer in (self._fastPlaylistTimer, self._iptvorgPlaylistTimer):
            try: timer.stop()
            except Exception: pass
        self._fastPlaylistRequest=None
        self._iptvorgPlaylistRequest=None
        self._fast_open_loading=None
        self._iptvorg_build_loading=None
        self._generation+=1; self._running=False; self._scan_running=False
        try:self._checkRefreshTimer.stop()
        except Exception:pass
    def _up(self):
        try:self["list"].up()
        except Exception:pass
        self._updateDetail()
        self._autoCheckOnMove()
    def _down(self):
        try:self["list"].down()
        except Exception:pass
        self._updateDetail()
        self._autoCheckOnMove()
    def _autoCheckOnMove(self):
        """AUTOMATIC mode: entering the next 10 servers checks them."""
        if not self._autoCheckEnabled():
            return
        try:
            block=(int(self["list"].getSelectedIndex() or 0)//10)*10
        except Exception:
            return
        if block!=getattr(self,"_checkBlock",None):
            self._autoCheckPage()
    def _pageUp(self):
        self._changePage(self._page-1)
    def _pageDown(self):
        self._changePage(self._page+1)
    def _changePage(self,page):
        old=self._page
        total=len(self._all_results or [])
        pages=max(1,(total+self._page_size-1)//self._page_size)
        if total<=0 or page<0 or page>=pages:
            return
        # Leaving a page stops its check; nothing keeps running behind.
        if self._scan_running:
            self._stopQuickCheck()
        self._showResultPage(page)
        if self._page!=old:self._autoCheckPage()

    # ---- Check mode: MANUAL (RED) or AUTOMATIC (after search / page change)
    def _checkModePath(self):
        try:
            return data_path("finder_check_mode.json")
        except Exception:
            return "/etc/enigma2/tivimatee2/finder_check_mode.json"

    def _autoCheckEnabled(self):
        cached=getattr(self,"_autoCheckCached",None)
        if cached is not None:return cached
        value=False
        try:
            with open(self._checkModePath(),"r") as handle:
                value=bool(json.load(handle).get("auto",False))
        except Exception:
            value=False
        self._autoCheckCached=value
        return value

    def _setAutoCheck(self,value):
        self._autoCheckCached=bool(value)
        try:
            path=self._checkModePath()
            with open(path+".tmp","w") as handle:
                json.dump({"auto":bool(value)},handle)
            os.rename(path+".tmp",path)
        except Exception:
            pass

    def chooseCheckMode(self):
        auto=self._autoCheckEnabled()
        choices=[
            (("✓ " if not auto else "")+"MANUAL  -  check only when I press RED","manual"),
            (("✓ " if auto else "")+"AUTOMATIC  -  check after search and on every page","auto"),
            ("Check this page now","now"),
        ]
        self.session.openWithCallback(self._checkModeChosen,ChoiceBox,title="Server check mode",list=choices)

    def _checkModeChosen(self,choice):
        if not choice:return
        if choice[1]=="now":
            self.quickCheckPage();return
        self._setAutoCheck(choice[1]=="auto")
        try:
            self["status"].setText("CHECK: %s"%("AUTO" if choice[1]=="auto" else "MANUAL"))
        except Exception:
            pass
        if choice[1]=="auto":self._autoCheckPage()

    def _autoCheckPage(self):
        """AUTOMATIC mode: check the visible page; queue it if a check is busy."""
        if not self._autoCheckEnabled() or self._running or not self._results:
            return
        if self._scan_running:
            self._autoCheckQueued=True
            return
        self._autoCheckQueued=False
        self.quickCheckPage()

    def _showResultPage(self,page=0):
        total=len(self._all_results or [])
        if total<=0:
            self._page=0; self._results=[]
            self["list"].setResults([])
            self._updateTopTypeAndNumbers()
            return
        pages=max(1,(total+self._page_size-1)//self._page_size)
        page=max(0,min(int(page or 0),pages-1))
        self._page=page
        start=page*self._page_size
        end=min(total,start+self._page_size)
        self._results=list(self._all_results[start:end])
        self["list"].setResults(self._results)
        self["status"].setText("PAGE %d/%d  •  %d-%d / %d"%(page+1,pages,start+1,end,total))
        self._updateTopTypeAndNumbers()
        self["summary"].setText("100 PER PAGE  •  LEFT/RIGHT = PAGE  •  RED = CHECK  •  MENU = CHECK MODE  •  OK = ADD")
        if self._results:self._updateDetail()
        else:self._clearDetail()

    def _updateTopTypeAndNumbers(self):
        # YELLOW Source: show a compact visual badge beside the existing
        # XT/STB/M3U type icons. This is display-only and does not change
        # Finder search/source logic.
        try:
            source_files={
                "iptvlinks":"finder_source_links.png",
                "stbstalker":"finder_source_stb.png",
                "stalker429":"finder_source_stb.png",
                "stbtelegram":"finder_source_telegram.png",
                "sattivimate":"finder_source_telegram.png",
                "iptvorg":"finder_source_iptvorg.png",
                "samsungtv":"finder_source_samsung.png",
                "xiaomitv":"finder_source_xiaomi.png",
                "freetv":"finder_source_freetv.png",
                "xumotv":"finder_source_xumo.png",
                "localnow":"finder_source_localnow.png",
                "lgchannels":"finder_source_lg.png",
                "roku":"finder_source_roku.png",
                "tubitv":"finder_source_tubi.png",
                "vizio":"finder_source_vizio.png",
                "tclplus":"finder_source_tcl.png","freelivesports":"finder_source_freelivesports.png",
            }
            sw=self["sourceLogoTop"]
            sf=source_files.get(self._source)
            if sf:
                sw.instance.setPixmapFromFile(os.path.join(PLUGIN_PATH,"skins","server",sf))
                sw.show()
            else:
                sw.hide()
        except Exception:
            pass

        # One clean circular logo only. BLUE changes TYPE; YELLOW can force
        # the natural family for fixed sources such as STB Stalker/IPTV-Org.
        try:
            logo_files={
                "xtream":"finder_xtream_top_clean.png",
                "stalker":"finder_stalker_top_clean.png",
                "m3u":"finder_m3u_top_clean.png",
            }
            source_kind={"stbstalker":"stalker", "stalker429":"stalker", "iptvorg":"m3u", "samsungtv":"m3u", "xiaomitv":"m3u", "freetv":"m3u", "xumotv":"m3u", "localnow":"m3u", "lgchannels":"m3u", "roku":"m3u", "tubitv":"m3u", "vizio":"m3u", "tclplus":"m3u", "freelivesports":"m3u"}.get(self._source)
            active=source_kind or self._mode
            w=self["typeLogoTop"]
            trio=(
                ("typeLogoXtream","xtream"),
                ("typeLogoStalker","stalker"),
                ("typeLogoM3U","m3u"),
            )
            if active == "all":
                try:w.hide()
                except Exception:pass
                for name,kind in trio:
                    path=os.path.join(PLUGIN_PATH,"skins","server",logo_files[kind])
                    try:self[name].instance.setPixmapFromFile(path)
                    except Exception:pass
                    try:self[name].show()
                    except Exception:pass
            elif active in logo_files:
                for name,kind in trio:
                    try:self[name].hide()
                    except Exception:pass
                path=os.path.join(PLUGIN_PATH,"skins","server",logo_files[active])
                try:w.instance.setPixmapFromFile(path)
                except Exception:pass
                try:w.show()
                except Exception:pass
            else:
                try:w.hide()
                except Exception:pass
                for name,kind in trio:
                    try:self[name].hide()
                    except Exception:pass
        except Exception:
            pass

        try:
            total=len(self._all_results or [])
            if total<=0:
                self["pageNumbers"].setText("0 RESULTS")
                return
            pages=max(1,(total+self._page_size-1)//self._page_size)
            page=max(0,min(int(self._page or 0),pages-1))
            start=page*self._page_size
            end=min(total,start+self._page_size)
            self["pageNumbers"].setText("PAGE %d / %d     %d - %d / %d"%(page+1,pages,start+1,end,total))
        except Exception:
            try:self["pageNumbers"].setText("0 RESULTS")
            except Exception:pass

    def _setFilters(self):
        names={"all":"▦  ALL","stalker":"STALKER","m3u":"M3U"}
        self["filterAll"].setText(("▶  " if self._mode=="all" else "")+"ALL")
        self["filterStalker"].setText(("▶  " if self._mode=="stalker" else "")+"STALKER")
        self["filterXtream"].setText(("▶  " if self._mode=="xtream" else "")+"XTREAM")
        self["filterM3U"].setText(("▶  " if self._mode=="m3u" else "")+"M3U")
        self["daysBox"].setText("ALL DATES")
        self._updateTopTypeAndNumbers()

    def cycleSource(self):
        sources=("all","iptvlinks","stbstalker","stalker429","stbtelegram","sattivimate","iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports")
        try:self._source=sources[(sources.index(self._source)+1)%len(sources)]
        except Exception:self._source="all"
        labels={"all":"ALL SOURCES","iptvlinks":"IPTV LINKS","stbstalker":"STB STALKER","stalker429":"STALKER429","stbtelegram":"TELEGRAM","sattivimate":"Sat tivimate","iptvorg":"IPTV-ORG","samsungtv":"SAMSUNG TV PLUS","xiaomitv":"XIAOMI TV+","xumotv":"XUMO PLAY","freetv":"FREE TV","localnow":"LOCAL NOW","lgchannels":"LG CHANNELS","roku":"ROKU CHANNEL","tubitv":"TUBI LIVE TV","vizio":"VIZIO WATCHFREE+","tclplus":"TCL TV+","freelivesports":"FREE LIVE SPORTS"}
        self["status"].setText("SOURCE: %s  •  TYPE: %s"%(labels.get(self._source,self._source.upper()),str(self._mode or "all").upper()))
        self["summary"].setText("GREEN = SEARCH  •  YELLOW = SOURCE  •  BLUE = TYPE")
        self._updateTopTypeAndNumbers()
    def cycleType(self):
        vals=("all","stalker","xtream","m3u")
        try:self._mode=vals[(vals.index(self._mode)+1)%len(vals)]
        except Exception:self._mode="xtream"
        labels={"all":"ALL","stalker":"STALKER","xtream":"XTREAM","m3u":"M3U"}
        self["status"].setText("TYPE: %s"%labels.get(self._mode,"ALL"))
        self._setFilters()

    def cycleDays(self):
        self._days=0
        self["daysBox"].setText("ALL DATES")


    def _finderTxtPath(self, scanned=False):
        try:
            from Plugins.Extensions.TiviMateE2.storage import data_path
            name="finder_valid.txt" if scanned else "finder_results.txt"
            return data_path("finder",name)
        except Exception:
            return "/tmp/tivimatee2_finder_valid.txt" if scanned else "/tmp/tivimatee2_finder_results.txt"

    def _rowMac(self,row):
        try:
            direct=str((row or {}).get("mac") or "").strip().upper().replace("-",":")
            if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$",direct):
                return direct
            post=(row or {}).get("post") if isinstance((row or {}).get("post"),dict) else {}
            macs=post.get("macs") or []
            if not isinstance(macs,(list,tuple)):
                macs=[macs]
            for entry in macs:
                if isinstance(entry,dict):
                    value=str(entry.get("mac") or entry.get("value") or "")
                else:
                    value=str(entry or "")
                value=value.strip().upper().replace("-",":")
                if re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$",value):
                    return value
        except Exception:
            pass
        return ""

    def _writeFinderTxt(self,rows,scanned=False):
        path=self._finderTxtPath(scanned)
        try:
            parent=os.path.dirname(path)
            if parent and not os.path.isdir(parent):
                os.makedirs(parent)
        except Exception:
            pass
        with open(path,"w") as fh:
            fh.write("# TiviMateE2 IPTV Finder\n")
            fh.write("# TYPE\tSTATUS\tHTTP\tMS\tURL\tMAC\tEXPIRY\n")
            for row in (rows or []):
                kind=str((row or {}).get("kind") or "").lower()
                status=str((row or {}).get("_scan") or "FOUND")
                code=str(int((row or {}).get("_code") or 0) or "")
                ms=str(int((row or {}).get("_ms") or 0) or "")
                url=str((row or {}).get("url") or "").replace("\r","").replace("\n","")
                mac=self._rowMac(row)
                try:
                    expiry=str(
                        (row or {}).get("expiry")
                        or (row or {}).get("_last_expiry")
                        or (((row or {}).get("post") or {}).get("expiry"))
                        or (((row or {}).get("source_post") or {}).get("expiry"))
                        or ""
                    ).strip()
                except Exception:
                    expiry=""
                # Source selector metadata is essential when scanAll reloads TXT.
                # Persist only these allowlisted noncredential fields.
                _extra={k:str((row or {}).get(k) or "") for k in ("fast_service","fast_region","iptvorg_group","display_name","samsung_group","xiaomi_group") if (row or {}).get(k)}
                _payload=json.dumps(_extra,ensure_ascii=False,separators=(",",":")) if _extra else ""
                fh.write("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n"%(kind,status,code,ms,url,mac,expiry,_payload))
        return path

    def _readFinderTxt(self,scanned=False):
        path=self._finderTxtPath(scanned)
        rows=[]
        try:
            with open(path,"r") as fh:
                for raw in fh:
                    raw=raw.rstrip("\r\n")
                    if not raw or raw.startswith("#"):
                        continue
                    parts=raw.split("\t",7)
                    while len(parts)<8:
                        parts.append("")
                    kind,status,code,ms,url,mac,expiry,_extra=parts
                    if not url:
                        continue
                    row={"kind":kind,"url":url,"_scan":status}
                    if _extra:
                        try:
                            _fields=json.loads(_extra)
                            if isinstance(_fields,dict):
                                for _key in ("fast_service","fast_region","iptvorg_group","display_name","samsung_group","xiaomi_group"):
                                    if _key in _fields: row[_key]=str(_fields[_key])
                        except Exception:
                            pass
                    if mac:
                        row["mac"]=mac
                    if expiry:
                        row["expiry"]=expiry
                    try: row["_code"]=int(code or 0)
                    except Exception: row["_code"]=0
                    try: row["_ms"]=int(ms or 0)
                    except Exception: row["_ms"]=0
                    rows.append(row)
        except Exception:
            pass
        return rows

    def _finderPublicPlaylistURL(self, row):
        """Turn internal LG/Arabic selectors into an actual published playlist URL."""
        row=row or {}
        _u=str(row.get("url") or "").strip()
        _fs=str(row.get("fast_service") or "").strip().lower()
        _fr=str(row.get("fast_region") or "all").strip().lower()
        if _fs == "lgchannels" or _u.startswith("fastm3u://lgchannels/"):
            if _u.startswith("fastm3u://lgchannels/"):
                _fr=_u.split("/",3)[-1].strip().lower() or "all"
            if _fr == "all": return "https://www.apsattv.com/aelg.m3u"  # representative live regional list
            if _fr == "us": return "https://raw.githubusercontent.com/JulioCesarXY/EPG-LG-Channels/main/lg_channels_us.m3u"
            return "https://www.apsattv.com/%slg.m3u"%_fr
        if row.get("iptvorg_group") or "#tivimatee2-" in _u:
            return _u.split("#",1)[0]
        return _u

    def _scanTarget(self,row):
        """Return a public endpoint to probe without performing a login/handshake."""
        url=self._finderPublicPlaylistURL(row)
        if not url:
            return ""
        try:
            p=urlparse(url if "://" in url else "http://"+url)
            if p.scheme not in ("http","https") or not p.netloc:
                return ""
            kind=str((row or {}).get("kind") or "").lower()
            # For credential-bearing playlist/Xtream URLs, probe only the public host.
            if kind in ("xtream","m3u") and (p.query or "get.php" in (p.path or "").lower()):
                return "%s://%s/"%(p.scheme,p.netloc)
            return url
        except Exception:
            return ""

    def _quickReachabilityTarget(self,row):
        """Return a lightweight public URL target appropriate for this Finder type."""
        row=row or {}
        kind=str(row.get("kind") or "").lower()
        raw=self._finderPublicPlaylistURL(row)
        if not raw:
            return ""

        # M3U: check the exact public playlist URL.
        if kind=="m3u":
            return raw

        # Xtream: only check scheme + host + port. Do not submit credentials.
        if kind=="xtream":
            try:
                from urllib.parse import urlsplit
            except Exception:
                from urlparse import urlsplit
            try:
                p=urlsplit(raw if "://" in raw else "http://"+raw)
                if p.scheme and p.netloc:
                    return "%s://%s/"%(p.scheme,p.netloc)
            except Exception:
                pass
            return raw

        # Stalker: keep the public portal path when present. /c and
        # /stalker_portal/c are legitimate portal forms; do not strip them.
        if kind=="stalker":
            clean=raw.rstrip("/")
            low=clean.lower()
            if low.endswith("/c") or "/stalker_portal/c" in low:
                return clean+"/"
            return raw

        return raw

    def _quickAnimTick(self):
        if not self._scan_running:
            self._stopQuickAnim()
            return
        frames=("●","◉","○","◉")
        self._quick_anim_step=(self._quick_anim_step+1)%len(frames)
        try:self["quickAnim"].setText(frames[self._quick_anim_step])
        except Exception:pass

    def _startQuickAnim(self):
        self._quick_anim_step=0
        try:self["quickAnim"].setText("●")
        except Exception:pass
        try:self._quick_anim_timer.start(220,False)
        except Exception:pass

    def _stopQuickAnim(self):
        try:self._quick_anim_timer.stop()
        except Exception:pass
        try:self["quickAnim"].setText("")
        except Exception:pass

    def quickCheckPage(self):
        """Fast public reachability check for the currently visible Finder page only."""
        self._finderLog("QUICK_CHECK_REQUEST", page=self._page, rows=len(self._results or []), source=self._source, mode=self._mode)
        # Do not fail silently when another operation is really still active.
        if self._running:
            try:
                self["status"].setText("SEARCH STILL RUNNING")
                self["summary"].setText("Wait for SEARCH to finish, then press RED to check")
            except Exception:
                pass
            return
        if self._scan_running:
            # RED again = STOP the running check (no more waiting/freezing).
            self._stopQuickCheck()
            return

        rows=list(self._results or [])
        if not rows:
            self.session.open(MessageBox,"Run SEARCH first.",MessageBox.TYPE_INFO,timeout=3)
            return

        # Check only the 10 rows on screen (the block holding the cursor),
        # and never re-check a row that already has a result.
        try:
            sel=int(self["list"].getSelectedIndex() or 0)
        except Exception:
            sel=0
        block=10
        first=(sel//block)*block
        last=min(len(rows),first+block)
        checked=("VALID","REACHABLE","DEAD","INVALID","ONLINE","OFFLINE","PORTAL")
        indices=[i for i in range(first,last) if str(rows[i].get("_scan") or "").upper() not in checked]
        if not indices:
            try:
                self["status"].setText("ROWS %d-%d ALREADY CHECKED"%(first+1,last))
                self["summary"].setText("Move down to the next servers and press RED")
            except Exception:
                pass
            return

        self._scan_running=True
        self._checkToken=int(getattr(self,"_checkToken",0) or 0)+1
        token=self._checkToken
        self._checkDirty=False
        self._checkBlock=first
        self._startQuickAnim()
        self._startCheckRefresh()
        generation=self._generation
        page=self._page
        total=len(indices)
        self._results=[dict(x) for x in rows]
        try:
            self["status"].setText("CHECK 0/%d  •  ROWS %d-%d   •   RED = STOP"%(total,first+1,last))
            self["summary"].setText("Checking the servers on screen  •  RED = STOP")
        except Exception:
            pass

        worker=threading.Thread(target=self._quickCheckWorker,args=(generation,page,list(self._results),token,indices))
        worker.daemon=True
        worker.start()

    # ---- live list refresh: at most every 0.5 s, cursor never jumps ----
    def _startCheckRefresh(self):
        timer=getattr(self,"_checkRefreshTimer",None)
        if timer is None:
            timer=eTimer()
            try:
                self._checkRefreshConn=timer.timeout.connect(self._checkRefreshTick)
            except AttributeError:
                timer.callback.append(self._checkRefreshTick)
            self._checkRefreshTimer=timer
        timer.start(500,False)

    def _refreshCheckedList(self):
        try:
            index=self["list"].getSelectedIndex() or 0
        except Exception:
            index=0
        try:
            self["list"].setResults(self._results)
            if self._results:
                self["list"].moveToIndex(min(int(index),len(self._results)-1))
            self._updateDetail()
        except Exception:
            pass

    def _checkRefreshTick(self):
        if getattr(self,"_checkDirty",False):
            self._checkDirty=False
            self._refreshCheckedList()
        if not self._scan_running:
            try:self._checkRefreshTimer.stop()
            except Exception:pass

    def _finderStalkerTest(self,url,mac,limit):
        """Portal+MAC login test, but never longer than `limit` seconds."""
        box={}
        def run():
            try:
                box["reply"]=StalkerClient({"type":"stalker","url":url,"mac":mac,"service_type":4097,"_finder_check":True}).test()
            except Exception:
                box["reply"]=None
        t=threading.Thread(target=run)
        t.daemon=True
        t.start()
        t.join(limit)
        return box.get("reply")

    def _stopQuickCheck(self):
        self._checkToken=int(getattr(self,"_checkToken",0) or 0)+1
        self._scan_running=False
        self._autoCheckQueued=False
        self._stopQuickAnim()
        self._refreshCheckedList()
        try:
            self["status"].setText("CHECK STOPPED   •   RED = CHECK AGAIN")
            self["summary"].setText("Check stopped. Rows already checked keep their result.")
        except Exception:
            pass
        self._finderLog("QUICK_CHECK_STOP", page=self._page)

    def _quickCheckWorker(self,generation,page,rows,token=None,indices=None):
        # Small fixed pool using the existing threading module: no timer/hook/module added.
        if indices is None:
            indices=list(range(len(rows)))
        total=len(indices)
        results=[dict(x) for x in rows]
        cursor=[0]
        done=[0]
        online=[0]
        reachable=[0]
        lock=threading.Lock()

        try:
            from .web_manager import _public_reachability
        except Exception:
            _public_reachability=None

        def _alive():
            return generation==self._generation and (token is None or token==getattr(self,"_checkToken",None))

        def _push_one(idx,item,done_count,online_count,reachable_count):
            def _apply():
                if not _alive():
                    return
                start=page*self._page_size
                pos=start+idx
                if pos < len(self._all_results):
                    self._all_results[pos]=item
                if self._page==page and idx < len(self._results):
                    self._results[idx]=item
                    self._checkDirty=True
                try:
                    self["status"].setText("CHECK %d/%d  •  ONLINE %d  •  PORTAL %d   •   RED = STOP"%(done_count,total,online_count,reachable_count))
                except Exception:
                    pass
            try:
                if reactor is not None:
                    reactor.callFromThread(_apply)
                else:
                    _apply()
            except Exception:
                try:_apply()
                except Exception:pass

        def _finish_all():
            def _finish():
                if not _alive():
                    # Stopped by the user or screen closed: _stopQuickCheck
                    # already updated the screen.
                    return
                self._scan_running=False
                self._stopQuickAnim()
                if self._page==page:
                    self._results=list(results)
                    self._refreshCheckedList()
                try:
                    self["status"].setText("QUICK: %d ONLINE • %d PORTAL / %d"%(online[0],reachable[0],total))
                    self["summary"].setText("GREEN = MAC VERIFIED  •  YELLOW = PORTAL ONLY  •  RED = OFFLINE")
                except Exception:
                    pass
                if getattr(self,"_autoCheckQueued",False):
                    self._autoCheckPage()
            try:
                if reactor is not None:
                    reactor.callFromThread(_finish)
                else:
                    _finish()
            except Exception:
                try:_finish()
                except Exception:pass

        def _worker():
            while True:
                if not _alive():
                    return
                with lock:
                    if cursor[0] >= total:
                        return
                    idx=indices[cursor[0]]
                    cursor[0]+=1

                item=dict(rows[idx])
                target=self._quickReachabilityTarget(item)
                kind=str(item.get("kind") or "").lower()
                if not target:
                    item["_scan"]="INVALID"
                    item["_code"]=0
                    item["_ms"]=0
                elif kind=="stalker":
                    # A green Stalker row must prove that this exact MAC can
                    # authenticate. Public HTTP reachability alone is yellow.
                    # Show CHECKING immediately so RED never appears frozen.
                    mac=self._rowMac(item)
                    verified=False
                    started=time.time()
                    checking=dict(item)
                    checking["_scan"]="CHECKING"
                    _push_one(idx,checking,done[0],online[0],reachable[0])
                    if mac:
                        try:
                            reply=self._finderStalkerTest(str(item.get("url") or target),mac,8.0) or {}
                            item["_handshake"]=bool(reply.get("handshake"))
                            item["_profile"]=bool(reply.get("profile"))
                            item["_categories"]=int(reply.get("categories") or 0)
                            if reply.get("expiry"):
                                item["expiry"]=str(reply.get("expiry"))
                            verified=bool(reply.get("ok"))
                        except Exception:
                            verified=False
                    item["_ms"]=int((time.time()-started)*1000)
                    if verified:
                        item["_scan"]="VALID"
                        item["_code"]=200
                    else:
                        if _public_reachability is not None:
                            try:
                                state,code,ms,final=_public_reachability(target)
                                item["_code"]=int(code or 0)
                                item["_ms"]=max(int(item.get("_ms") or 0),int(ms or 0))
                                item["_scan"]="REACHABLE" if state=="reachable" else "DEAD"
                            except Exception:
                                item["_scan"]="DEAD"
                                item["_code"]=0
                        else:
                            item["_scan"]="DEAD"
                            item["_code"]=0
                else:
                    try:
                        state,code,ms,final=_public_reachability(target)
                        item["_code"]=int(code or 0)
                        item["_ms"]=int(ms or 0)
                        item["_scan"]="VALID" if state=="reachable" else "DEAD"
                    except Exception:
                        item["_scan"]="DEAD"
                        item["_code"]=0
                        item["_ms"]=0

                with lock:
                    results[idx]=item
                    done[0]+=1
                    scan_state=str(item.get("_scan") or "").upper()
                    if scan_state=="VALID":
                        online[0]+=1
                    elif scan_state=="REACHABLE":
                        reachable[0]+=1
                    d=done[0]
                    o=online[0]
                    y=reachable[0]

                # Update this exact row immediately instead of waiting for all 100.
                _push_one(idx,item,d,o,y)

        # One worker per row on screen (max 10): the whole block runs at once.
        workers=[]
        count=min(10,total)
        for _n in range(count):
            t=threading.Thread(target=_worker)
            t.daemon=True
            workers.append(t)
            t.start()
        # Never let one dead provider keep the Finder worker alive forever.
        # This worker is already off the Enigma2 UI thread; use one short
        # shared deadline and return whatever checks completed.
        # Wait for the workers; STOP ends them at the next row, so the screen
        # is free at once and late answers are ignored.
        for t in workers:
            while t.is_alive() and _alive():
                t.join(0.5)

        _finish_all()

    def scanAll(self):
        if self._running or self._scan_running:
            return
        # Always scan exactly what SEARCH wrote to the TXT file.
        rows=self._readFinderTxt(False)
        if not rows:
            self.session.open(MessageBox,"Run SEARCH first. No Finder TXT results are available.",MessageBox.TYPE_INFO,timeout=4)
            return
        self._scan_running=True
        self["status"].setText("SCANNING ALL...")
        self["summary"].setText("Checking %d saved TXT results..."%len(rows))
        generation=self._generation
        worker=threading.Thread(target=self._scanWorker,args=(generation,rows))
        worker.daemon=True
        worker.start()

    def _scanWorker(self,generation,rows):
        checked=[]
        valid=[]
        try:
            from .web_manager import _public_reachability, _urlopen_text
            for row in rows:
                item=dict(row)
                kind=str(item.get("kind") or "").lower()
                target=self._scanTarget(item)
                if not target:
                    item["_scan"]="INVALID"; item["_code"]=0; item["_ms"]=0
                    checked.append(item)
                    continue

                if kind=="m3u":
                    # Validate the exact saved URL, not a shortened host URL.
                    try:
                        started=time.time()
                        code,final,body=_urlopen_text(target,timeout=6,max_bytes=524288)
                        item["_code"]=int(code or 0)
                        item["_ms"]=int((time.time()-started)*1000)
                        text=str(body or "")
                        head=text[:524288].lstrip("\ufeff\r\n\t ")
                        upper=head.upper()

                        # Detect HLS first: media manifests also contain
                        # #EXTINF, so checking #EXTINF first wrongly marked
                        # direct streams as full IPTV playlists.
                        if 200 <= int(code or 0) < 400 and "#EXTM3U" in upper and (
                            "#EXT-X-STREAM-INF" in upper or "#EXT-X-TARGETDURATION" in upper or "#EXT-X-MEDIA-SEQUENCE" in upper
                        ):
                            item["_scan"]="HLS STREAM"
                        # A downloadable IPTV channel list is VALID even when
                        # the public URL itself has no .m3u suffix.
                        elif 200 <= int(code or 0) < 400 and "#EXTM3U" in upper and "#EXTINF" in upper:
                            item["_scan"]="VALID"
                            valid.append(item)
                        else:
                            item["_scan"]="DEAD"
                    except Exception:
                        item["_scan"]="DEAD"; item["_code"]=0; item["_ms"]=0
                    checked.append(item)
                    continue

                # Stalker is VALID only when this exact MAC authenticates.
                # A portal that merely answers HTTP is kept as REACHABLE/yellow.
                if kind=="stalker":
                    mac=self._rowMac(item)
                    verified=False
                    started=time.time()
                    if mac:
                        try:
                            reply=self._finderStalkerTest(str(item.get("url") or target),mac,8.0) or {}
                            item["_handshake"]=bool(reply.get("handshake"))
                            item["_profile"]=bool(reply.get("profile"))
                            item["_categories"]=int(reply.get("categories") or 0)
                            if reply.get("expiry"):
                                item["expiry"]=str(reply.get("expiry"))
                            verified=bool(reply.get("ok"))
                        except Exception:
                            verified=False
                    item["_ms"]=int((time.time()-started)*1000)
                    if verified:
                        item["_scan"]="VALID"; item["_code"]=200
                        valid.append(item)
                    else:
                        try:
                            state,code,ms,final=_public_reachability(target)
                            item["_code"]=int(code or 0); item["_ms"]=max(int(item.get("_ms") or 0),int(ms or 0))
                            item["_scan"]="REACHABLE" if state=="reachable" else "DEAD"
                        except Exception:
                            item["_scan"]="DEAD"; item["_code"]=0
                else:
                    try:
                        state,code,ms,final=_public_reachability(target)
                        item["_code"]=int(code or 0); item["_ms"]=int(ms or 0)
                        if state=="reachable":
                            item["_scan"]="VALID"
                            valid.append(item)
                        else:
                            item["_scan"]="DEAD"
                    except Exception:
                        item["_scan"]="DEAD"; item["_code"]=0; item["_ms"]=0
                checked.append(item)
        except Exception:
            checked=[dict(x,**{"_scan":"INVALID"}) for x in rows]
            valid=[]

        try:
            self._writeFinderTxt(checked,False)
            self._writeFinderTxt(valid,True)
        except Exception:
            pass

        def _finish():
            if generation!=self._generation:
                self._scan_running=False
                return
            self._scan_running=False
            # Preserve complete original discovery rows after SCAN.  The TXT
            # diagnostic export intentionally contains only seven safe fields,
            # and loading it back silently strips source selectors such as
            # fast_service/fast_region, samsung_group, xiaomi_group, and custom
            # IPTV-Org grouping details.  Those fields are required by
            # openCurrent() to build working local M3U sources.  Keep the full
            # scanned rows in memory; TXT files remain diagnostic exports only.
            self._all_results=[dict(row) for row in checked]
            self._page=0
            valid_count=sum(1 for _r in self._all_results if str((_r or {}).get("_scan") or "").upper()=="VALID")
            if self._all_results:
                self._showResultPage(0)
                self["status"].setText("VALID: %d / %d"%(valid_count,len(self._all_results)))
                reachable_count=sum(1 for _r in self._all_results if str((_r or {}).get("_scan") or "").upper()=="REACHABLE")
                self["summary"].setText("SCAN complete • GREEN = MAC LOGIN ONLY • OPEN = LIVE CHECK • YELLOW = PORTAL ONLY")
                self["status"].setText("VALID: %d • PORTAL: %d / %d"%(valid_count,reachable_count,len(self._all_results)))
            else:
                self._results=[]
                self["list"].setResults([])
                self["status"].setText("VALID: 0 / %d"%len(rows))
                self["summary"].setText("SCAN complete • no results")
                self._clearDetail()
        try:
            if reactor is not None:reactor.callFromThread(_finish)
            else:_finish()
        except Exception:
            try:_finish()
            except Exception:pass


    def startSearch(self):
        self._finderLog("SEARCH_REQUEST", source=self._source, mode=self._mode, days=self._days)
        if self._running:return
        self._setFilters(); self._running=True; self._generation+=1; generation=self._generation
        self["status"].setText("SEARCHING..."); self["searchBox"].setText("⌕  CHECKING...")
        self["summary"].setText("Searching selected source... please wait")
        self._results=[]; self._all_results=[]; self._page=0; self["list"].setResults([]); self._clearDetail()
        worker=threading.Thread(target=self._worker,args=(generation,)); worker.daemon=True; worker.start()

    def _worker(self,generation):
        rows=[]; error=""
        self._finderLog("SEARCH_WORKER_START", generation=generation, source=self._source, mode=self._mode)
        try:
            from .web_manager import _fetch_discovery,_discovery_items
            posts=[]; source_errors=[]
            samsung_region_keys=[]
            source_ids=("iptvlinks","stbstalker","stalker429","stbtelegram","sattivimate","iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports") if self._source=="all" else (self._source,)
            for source_id in source_ids:
                if source_id in ("xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports"):
                    # FAST sources are exposed as compact rows below; do not download
                    # their playlists during SEARCH. Download only when OPEN is pressed.
                    continue
                if source_id == "samsungtv":
                    # Samsung TV Plus is an isolated public FAST source.
                    # Channel metadata is refreshed at search time; no timer/hook is added.
                    try:
                        req=Request("https://i.mjh.nz/SamsungTVPlus/.channels.json.gz",headers={"User-Agent":"Mozilla/5.0"})
                        raw=urlopen(req,timeout=12).read(4*1024*1024)
                        data=json.loads(gzip.decompress(raw).decode("utf-8","ignore"))
                        regions=(data or {}).get("regions") or {}
                        samsung_region_keys=[str(x).lower() for x in regions.keys()]
                        # Load every region exposed by the Samsung TV Plus catalog.
                        # Keep region-specific channel IDs/feeds; only identical stream URLs
                        # are de-duplicated so alternate regional feeds remain available.
                        region_channels=[]
                        for rk in sorted(regions.keys(),key=lambda x:str(x).lower()):
                            rchannels=((regions.get(rk) or {}).get("channels") or {})
                            for cid,ch in rchannels.items():
                                if not isinstance(ch,dict) or ch.get("license_url"):
                                    continue
                                region_channels.append((str(rk).upper(),str(cid),ch))
                        m3us=[]; seen_streams=set()
                        slug_fmt=str((data or {}).get("slug") or "sam-{id}.m3u8")
                        for rk,cid,ch in sorted(region_channels,key=lambda x:(x[0],int((x[2] or {}).get("chno") or 999999),str((x[2] or {}).get("name") or ""))):
                            slug=slug_fmt.format(id=cid)
                            u="https://jmp2.uk/%s"%slug.lstrip("/")
                            if u in seen_streams:
                                continue
                            seen_streams.add(u)
                            m3us.append(u)
                        if m3us:
                            posts.append({"title":"Samsung TV Plus","date":"","expiry":"","urls":[],"macs":[],"xtreams":[],"m3us":m3us,"finder_source":"samsungtv"})
                        else:
                            source_errors.append("samsungtv: no public channels")
                    except Exception as e:
                        source_errors.append("samsungtv: %s"%str(e)[:60])
                    continue
                if source_id == "xiaomitv":
                    # Xiaomi TV+ public FAST source. Apsattv publishes a legal
                    # Xiaomi playlist; Finder exposes compact category packages.
                    # No timer/hook is added: the playlist is refreshed only on SEARCH/OPEN.
                    try:
                        _xiaomi_url="https://www.apsattv.com/xiaomi.m3u"
                        req=Request(_xiaomi_url,headers={"User-Agent":"Mozilla/5.0"})
                        raw=urlopen(req,timeout=12).read(8*1024*1024)
                        txt=raw.decode("utf-8","replace") if isinstance(raw,bytes) else str(raw)
                        _count=txt.count("#EXTINF")
                        if _count>0:
                            posts.append({"title":"Xiaomi TV+","date":"","expiry":"","urls":[],"macs":[],"xtreams":[],"m3us":[_xiaomi_url],"finder_source":"xiaomitv","channel_count":_count})
                        else:
                            source_errors.append("xiaomitv: empty playlist")
                    except Exception as e:
                        source_errors.append("xiaomitv: %s"%str(e)[:60])
                    continue
                if source_id == "iptvorg":
                    # Isolated IPTV-Org source. Existing Telegram/STB/IPTVLinks code is untouched.
                    # Start from a bundled public catalog so this source never depends on GitHub Raw.
                    catalog=[]
                    try:
                        catalog_path=os.path.join(PLUGIN_PATH,"data","iptvorg_catalog.txt")
                        with open(catalog_path,"r") as fh:
                            for line in fh:
                                u=str(line or "").strip()
                                if u.startswith("https://iptv-org.github.io/iptv/") and u.endswith(".m3u") and u not in catalog:
                                    catalog.append(u)
                    except Exception:
                        pass
                    # If GitHub Raw is reachable on the receiver, merge the current official catalog.
                    try:
                        from .web_manager import _urlopen_text
                        code,final,body=_urlopen_text("https://raw.githubusercontent.com/iptv-org/iptv/master/PLAYLISTS.md",timeout=10,max_bytes=262144)
                        if 200 <= int(code or 0) < 400 and body:
                            found=re.findall(r'https://iptv-org\.github\.io/iptv/[^\s`<>"\\\']+?\.m3u',str(body),re.I)
                            for u in found:
                                u=str(u or "").strip()
                                if u and u not in catalog:
                                    catalog.append(u)
                    except Exception:
                        pass
                    if catalog:
                        # Pin the large official aggregate playlists first.
                        pinned = [
                            "https://iptv-org.github.io/iptv/index.m3u",
                            "https://iptv-org.github.io/iptv/index.country.m3u",
                            "https://iptv-org.github.io/iptv/index.language.m3u",
                            "https://iptv-org.github.io/iptv/index.category.m3u",
                            "https://iptv-org.github.io/iptv/index.region.m3u",
                            "https://iptv-org.github.io/iptv/languages/ara.m3u",
                        ]
                        ordered=[]
                        for u in pinned + catalog:
                            if u and u not in ordered:
                                ordered.append(u)
                        catalog=ordered
                        posts.append({"title":"IPTV-Org Public Playlists","date":"","expiry":"","urls":[],"macs":[],"xtreams":[],"m3us":catalog,"finder_source":"iptvorg"})
                    else:
                        source_errors.append("iptvorg: catalog unavailable")
                    continue
                _src,_posts,_err=_fetch_discovery(source_id,limit=1000,days=(60 if source_id=="sattivimate" else (30 if source_id=="stbtelegram" else 0)))
                if _posts: posts.extend(_posts)
                if _err: source_errors.append("%s: %s"%(source_id,str(_err)[:60]))
            error=" | ".join(source_errors)

            # STALKER429 is a fixed portal preset only. No MAC/credential is bundled.
            # It appears immediately after STB STALKER in Source and uses the existing
            # Stalker 429-aware checker when the user supplies an authorized MAC.
            _stalker429_fixed = (self._source == "stalker429")

            # Use the requested type directly. Keep the discovery URL exactly as returned
            # by _discovery_items; do not truncate it before writing the TXT file.
            items=_discovery_items(posts,mode=("m3u" if self._source in ("iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports") and self._mode in ("all","m3u") else self._mode),max_candidates=1000000)
            if _stalker429_fixed and self._mode in ("all","stalker"):
                items.insert(0,{"kind":"stalker","url":"https://stbstalker.alaaeldinee.com/","display_name":"STALKER429","finder_source":"stalker429","post":{"title":"STALKER429","finder_source":"stalker429","macs":[]}})
            elif _stalker429_fixed:
                items=[]

            # IPTV-Org is M3U only: never leak its pinned playlists into STALKER/XTREAM.
            if self._source in ("iptvorg","samsungtv","xiaomitv","xumotv","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports") and self._mode not in ("all","m3u"):
                items=[]
            rows=[]
            for x in items:
                if not isinstance(x,dict) or not str(x.get("url") or "").strip():
                    continue
                row=dict(x)
                try:
                    row["expiry"]=str(row.get("expiry") or ((row.get("post") or {}).get("expiry")) or ((row.get("source_post") or {}).get("expiry")) or "").strip()
                except Exception:
                    row["expiry"]=""
                # Friendly names for the six large IPTV-Org bundles pinned at the top.
                if str(((row.get("post") or {}).get("finder_source") or "")) == "iptvorg":
                    _u=str(row.get("url") or "").strip()
                    _names={
                        "https://iptv-org.github.io/iptv/index.m3u":"ALL",
                        "https://iptv-org.github.io/iptv/index.country.m3u":"ALL BY COUNTRY",
                        "https://iptv-org.github.io/iptv/index.language.m3u":"ALL BY LANGUAGE",
                        "https://iptv-org.github.io/iptv/index.category.m3u":"ALL BY CATEGORY",
                        "https://iptv-org.github.io/iptv/index.region.m3u":"ALL BY REGION",
                        "https://iptv-org.github.io/iptv/languages/ara.m3u":"ARABIC",
                    }
                    row["display_name"]=_names.get(_u,"")
                    row["_iptvorg_priority"]={u:i for i,u in enumerate(_names.keys())}.get(_u,1000)
                rows.append(row)
            if self._source == "iptvorg":
                rows.sort(key=lambda x:(int(x.get("_iptvorg_priority",1000)),str(x.get("url") or "")))
            elif self._source in ("iptvlinks", "stbstalker", "stbtelegram", "sattivimate"):
                # These sources are chronological. Preserve Blogger/message order so
                # page 1 starts with the newest published post.  Do not re-sort IPTV
                # Links by URL text, because that hides the newest M3U post.
                pass
            else:
                rows.sort(key=lambda x:(str(x.get("kind") or ""),str(x.get("url") or "")))

            # Finder uses public sources; no private account file access.
            self._writeFinderTxt(rows,False)
            rows=self._readFinderTxt(False)

            # Samsung TV Plus: show one selectable playlist per region instead of
            # hundreds of raw channel URLs. MIDDLE EAST combines UAE + Saudi + Egypt.
            # The actual local M3U is built only when the user opens/adds the row.
            if self._source == "samsungtv" and self._mode in ("all","m3u"):
                _region_names={
                    "ae":"UAE", "sa":"SAUDI ARABIA", "eg":"EGYPT", "us":"USA", "gb":"UNITED KINGDOM",
                    "ca":"CANADA", "au":"AUSTRALIA", "nz":"NEW ZEALAND", "de":"GERMANY", "fr":"FRANCE",
                    "es":"SPAIN", "it":"ITALY", "at":"AUSTRIA", "ch":"SWITZERLAND", "nl":"NETHERLANDS",
                    "be":"BELGIUM", "pt":"PORTUGAL", "ie":"IRELAND", "se":"SWEDEN", "no":"NORWAY",
                    "fi":"FINLAND", "dk":"DENMARK", "kr":"SOUTH KOREA", "in":"INDIA", "br":"BRAZIL",
                    "mx":"MEXICO"}
                _keys=[]
                for _rk in samsung_region_keys:
                    if _rk and _rk not in _keys: _keys.append(_rk)
                _groups=[("ALL REGIONS","all"),("ARABIC - ALL REGIONS","arabic-all")]
                for _rk in sorted(_keys,key=lambda x:(_region_names.get(x,x.upper()),x)):
                    _groups.append((_region_names.get(_rk,_rk.upper()),_rk))
                rows=[]
                for _name,_gid in _groups:
                    rows.append({"kind":"m3u",
                                 "url":"https://i.mjh.nz/SamsungTVPlus/.channels.json.gz#tivimatee2-region-"+_gid,
                                 "display_name":_name, "samsung_group":_gid,
                                 "_scan":"FOUND","_code":0,"_ms":0})

            # Xiaomi TV+: compact category packages, with ALL always first.
            # Each row builds a local filtered M3U when opened.
            if self._source == "xiaomitv" and self._mode in ("all","m3u"):
                _xiaomi_groups=[
                    ("ALL","all"),
                    ("EUROPE","europe"),
                    ("MIDDLE EAST","middle_east"),
                    ("ASIA","asia"),
                    ("NORTH AMERICA","north_america"),
                    ("LATIN AMERICA","latin_america"),
                    ("AFRICA","africa"),
                    ("OTHER","other"),
                ]
                rows=[]
                for _name,_gid in _xiaomi_groups:
                    rows.append({"kind":"m3u",
                                 "url":"https://www.apsattv.com/xiaomi.m3u#tivimatee2-"+_gid,
                                 "display_name":_name,"xiaomi_group":_gid,
                                 "_scan":"READY","_code":0,"_ms":0})

            # Xumo Play and Free TV: compact public source rows.
            # Playlists are downloaded only when opened, keeping Finder search fast.
            if self._source in ("all","xumotv") and self._mode in ("all","m3u"):
                if self._source == "xumotv":
                    rows=[]
                rows.append({"kind":"m3u","url":"fastm3u://xumo/all",
                             "display_name":"XUMO PLAY - LIVE",
                             "fast_service":"xumo","fast_region":"all","_scan":"READY","_code":0,"_ms":0})

            if self._source in ("all","freetv") and self._mode in ("all","m3u"):
                if self._source == "freetv":
                    rows=[]
                rows.append({"kind":"m3u","url":"fastm3u://freetv/world",
                             "display_name":"FREE TV - WORLD",
                             "fast_service":"freetv","fast_region":"world","_scan":"READY","_code":0,"_ms":0})

            # Additional public FAST sources for compatibility testing on Enigma2.
            # Keep SEARCH instant: playlists are fetched only when the row is opened.
            _extra_fast=(
                ("localnow","LOCAL NOW - LIVE","us"),
                ("roku","ROKU CHANNEL - LIVE","all"),
                ("tubitv","TUBI LIVE TV","all"),
            )
            for _sid,_label,_region in _extra_fast:
                if self._source in ("all",_sid) and self._mode in ("all","m3u"):
                    if self._source == _sid:
                        rows=[]
                    rows.append({"kind":"m3u","url":"fastm3u://%s/%s"%(_sid,_region),
                                 "display_name":_label,"fast_service":_sid,"fast_region":_region,
                                 "_scan":"FOUND","_code":0,"_ms":0})

            # Additional independent FAST playlists. Each source has its own upstream URL;
            # do not alias these names to any existing TiviMateE2 source.
            _independent_fast=(
                ("vizio","VIZIO WATCHFREE+ - LIVE","all"),
                ("tclplus","TCL TV+ - LIVE","all"),
                ("freelivesports","FREE LIVE SPORTS","all"),
            )
            for _sid,_label,_region in _independent_fast:
                if self._source in ("all",_sid) and self._mode in ("all","m3u"):
                    if self._source == _sid:
                        rows=[]
                    rows.append({"kind":"m3u","url":"fastm3u://%s/%s"%(_sid,_region),
                                 "display_name":_label,"fast_service":_sid,"fast_region":_region,
                                 "_scan":"READY","_code":0,"_ms":0})

            # LG Channels: expose every currently published APSATTV region as its own
            # lightweight row. Only the selected country's playlist is downloaded on OPEN.
            _lg_regions=(
                ("UAE","ae"),("USA","us"),("UK","gb"),("CANADA","ca"),("AUSTRALIA","au"),
                ("GERMANY","de"),("FRANCE","fr"),("ITALY","it"),("SPAIN","es"),("PORTUGAL","pt"),
                ("AUSTRIA","at"),("BELGIUM","be"),("SWITZERLAND","ch"),("DENMARK","dk"),("FINLAND","fi"),
                ("IRELAND","ie"),("LUXEMBOURG","lu"),("NETHERLANDS","nl"),("NORWAY","no"),("SWEDEN","se"),
                ("POLAND","pl"),("ARGENTINA","ar"),("BRAZIL","br"),("CHILE","cl"),("COLOMBIA","co"),
                ("MEXICO","mx"),("PERU","pe"),("INDIA","in"),("JAPAN","jp"),("KOREA","kr"),
                ("SINGAPORE","sg"),("NEW ZEALAND","nz"),
            )
            if self._source in ("all","lgchannels") and self._mode in ("all","m3u"):
                if self._source == "lgchannels":
                    rows=[]
                # ALL first: aggregate current published regional M3U lists.
                # Keep each individual region selectable below.
                rows.append({"kind":"m3u","url":"fastm3u://lgchannels/all",
                             "display_name":"LG CHANNELS - ALL",
                             "fast_service":"lgchannels","fast_region":"all",
                             "_scan":"FOUND","_code":0,"_ms":0})
                for _country,_region in _lg_regions:
                    rows.append({"kind":"m3u","url":"fastm3u://lgchannels/%s"%_region,
                                 "display_name":"LG CHANNELS - %s"%_country,
                                 "fast_service":"lgchannels","fast_region":_region,
                                 "_scan":"READY","_code":0,"_ms":0})

            # IPTV-Org: guarantee the six aggregate playlists are real rows at the
            # very beginning of page 1, even if discovery parsing filtered them.
            # When searching ALL sources, keep IPTV-Org ALL as the first result too.
            if self._source == "all" and self._mode in ("all","m3u"):
                _all_url="https://iptv-org.github.io/iptv/index.m3u"
                rows=[{"kind":"m3u","url":_all_url,"display_name":"ALL","_scan":"FOUND","_code":0,"_ms":0}] + [r for r in rows if str((r or {}).get("url") or "").strip()!=_all_url]

            if self._source == "iptvorg" and self._mode in ("all","m3u"):
                _pinned = [
                    ("ALL", "https://iptv-org.github.io/iptv/index.m3u"),
                    ("ALL BY COUNTRY", "https://iptv-org.github.io/iptv/index.country.m3u"),
                    ("ALL BY LANGUAGE", "https://iptv-org.github.io/iptv/index.language.m3u"),
                    ("ALL BY CATEGORY", "https://iptv-org.github.io/iptv/index.category.m3u"),
                    ("ALL BY REGION", "https://iptv-org.github.io/iptv/index.region.m3u"),
                    # Arabic block: keep overlapping playlists on purpose. A channel may
                    # exist in more than one list with a different stream, so do not
                    # collapse the Arabic sources into one deduplicated result.
                    ("ARABIC - LANGUAGE", "https://iptv-org.github.io/iptv/languages/ara.m3u"),
                    ("ARABIC - ARAB WORLD", "https://iptv-org.github.io/iptv/regions/arab.m3u"),
                    ("ARABIC - GCC", "https://iptv-org.github.io/iptv/regions/gcc.m3u"),
                    ("ARABIC - MENA", "https://iptv-org.github.io/iptv/regions/mena.m3u"),
                    ("ARABIC - MIDDLE EAST", "https://iptv-org.github.io/iptv/regions/mideast.m3u"),
                    ("ARABIC - MAGHREB", "https://iptv-org.github.io/iptv/regions/maghreb.m3u"),
                    ("ARABIC - SPORTS / BEIN / SKY", "https://iptv-org.github.io/iptv/categories/sports.m3u"),
                    ("ARABIC - UAE", "https://iptv-org.github.io/iptv/countries/ae.m3u"),
                    ("ARABIC - SAUDI ARABIA", "https://iptv-org.github.io/iptv/countries/sa.m3u"),
                    ("ARABIC - QATAR / BEIN", "https://iptv-org.github.io/iptv/countries/qa.m3u"),
                    ("ARABIC - KUWAIT", "https://iptv-org.github.io/iptv/countries/kw.m3u"),
                    ("ARABIC - BAHRAIN", "https://iptv-org.github.io/iptv/countries/bh.m3u"),
                    ("ARABIC - OMAN", "https://iptv-org.github.io/iptv/countries/om.m3u"),
                    ("ARABIC - EGYPT", "https://iptv-org.github.io/iptv/countries/eg.m3u"),
                    ("ARABIC - IRAQ", "https://iptv-org.github.io/iptv/countries/iq.m3u"),
                    ("ARABIC - JORDAN", "https://iptv-org.github.io/iptv/countries/jo.m3u"),
                    ("ARABIC - LEBANON", "https://iptv-org.github.io/iptv/countries/lb.m3u"),
                    ("ARABIC - SYRIA", "https://iptv-org.github.io/iptv/countries/sy.m3u"),
                    ("ARABIC - PALESTINE", "https://iptv-org.github.io/iptv/countries/ps.m3u"),
                    ("ARABIC - YEMEN", "https://iptv-org.github.io/iptv/countries/ye.m3u"),
                    ("ARABIC - LIBYA", "https://iptv-org.github.io/iptv/countries/ly.m3u"),
                    ("ARABIC - TUNISIA", "https://iptv-org.github.io/iptv/countries/tn.m3u"),
                    ("ARABIC - ALGERIA", "https://iptv-org.github.io/iptv/countries/dz.m3u"),
                    ("ARABIC - MOROCCO", "https://iptv-org.github.io/iptv/countries/ma.m3u"),
                    ("SPORTS - UK / SKY", "https://iptv-org.github.io/iptv/countries/uk.m3u"),
                ]
                _pin_urls=set(u for _n,u in _pinned)
                _arabic_hidden_urls=set(u for n,u in _pinned if n.startswith("ARABIC -") or n.startswith("SPORTS - UK"))
                _rest=[r for r in rows if str((r or {}).get("url") or "").strip() not in _pin_urls and str((r or {}).get("url") or "").strip() not in _arabic_hidden_urls]
                _groups = [
                    ("ARABIC ALL", "all"),
                    ("GENERAL", "general"),
                    ("MBC • SHAHID", "mbcshahid"),
                    ("MOVIES", "movies"),
                    ("SERIES & ENTERTAINMENT", "entertainment"),
                    ("SPORTS", "sports"),
                    ("KIDS", "kids"),
                    ("CULTURE", "culture"),
                    ("RELIGION", "religion"),
                ]
                _group_rows=[]
                for _name,_gid in _groups:
                    _group_rows.append({"kind":"m3u","url":"https://iptv-org.github.io/iptv/languages/ara.m3u#tivimatee2-"+_gid,
                                        "display_name":_name,"iptvorg_group":_gid,"_scan":"FOUND","_code":0,"_ms":0})
                # Keep the Arabic section compact: the aggregate packages above are
                # the only Arabic package rows. Do not expose the old per-country /
                # per-region Arabic rows again underneath them.
                _global_pinned = [(n,u) for n,u in _pinned if not (n.startswith("ARABIC -") or n.startswith("SPORTS - UK"))]
                rows=_group_rows + [{"kind":"m3u","url":u,"display_name":n,"_scan":"FOUND","_code":0,"_ms":0} for n,u in _global_pinned] + _rest

                # IPTV-Org cleanup: remove XXX/XXXXX entries and collapse only exact
                # duplicate URLs. Keep same channel name when its stream URL differs.
                _clean_rows=[]
                _seen_urls=set()
                for _r in rows:
                    _u=str((_r or {}).get("url") or "").strip()
                    _n=str((_r or {}).get("display_name") or "").strip()
                    _hay=("%s %s"%(_n,_u)).lower()
                    if re.search(r"x{3,}",_hay):
                        continue
                    _key=_u
                    if _key and _key in _seen_urls:
                        continue
                    if _key:
                        _seen_urls.add(_key)
                    _clean_rows.append(_r)
                rows=_clean_rows
            # Persist the *final* result rows including provider selector fields.
            # Previously scanAll examined the pre-LG/pre-group list instead.
            self._writeFinderTxt(rows,False)
        except Exception as exc:
            error=str(exc)

        def _finish():
            if generation!=self._generation:return
            self._running=False
            self._all_results=list(rows)
            self._page=0
            self["searchBox"].setText("⌕  SEARCH")
            if rows:
                self._showResultPage(0)
                try:
                    self["summary"].setText("SOURCE: %s  •  TYPE: %s  •  %d RESULTS"%(str(self._source or "all").upper(),str(self._mode or "all").upper(),len(rows)))
                except Exception:
                    pass
                self._autoCheckPage()
            else:
                self["status"].setText("FOUND: 0")
                self["summary"].setText(("No results found")+(("   •   "+error[:80]) if error else ""))
                self._clearDetail()
        try:
            if reactor is not None:reactor.callFromThread(_finish)
            else:_finish()
        except Exception:
            try:_finish()
            except Exception:pass

    def _clearDetail(self):
        try:self["detailIcon"].hide()
        except Exception:pass
        self["detailType"].setText("SELECT SERVER"); self["detailOnline"].setText(""); self["detailUrl"].setText("")
        self["detailInfo"].setText("Choose a working result to view its information.")
        try:
            self["fieldUrl"].setText("")
            self["fieldUser"].setText("")
            self["fieldPass"].setText("")
            self["fieldMac"].setText("")
        except Exception:
            pass

    def _selectedRow(self):
        if not self._results:return None
        try:index=int(self["list"].getSelectedIndex())
        except Exception:index=0
        return self._results[index] if 0<=index<len(self._results) else None

    def _updateDetail(self):
        row=self._selectedRow()
        if not row:self._clearDetail(); return
        kind=str(row.get("kind") or "iptv").lower(); url=str(row.get("url") or "")
        host=url.replace("http://","").replace("https://","").split("/")[0]
        port="—"
        try:
            parsed=urlparse(url if "://" in url else "http://"+url); port=str(parsed.port or (443 if parsed.scheme=="https" else 80))
        except Exception:pass
        self["detailType"].setText({"stalker":"STALKER","xtream":"XTREAM","m3u":"M3U"}.get(kind,kind.upper()))
        scan=str(row.get("_scan") or "FOUND").upper()
        self["detailOnline"].setText("●  "+scan); self["detailUrl"].setText(host[:38])
        self["detailInfo"].setText("Response Time     %d ms\n\nServer                 %s\n\nPort                     %s\n\nHTTP                    %s"%(int(row.get("_ms") or 0),host[:30],port,int(row.get("_code") or 0) or "—"))
        icon_path={"stalker":"skins/server/web_stalker_icon.png","xtream":"skins/server/web_xtream_icon.png","m3u":"skins/server/icon_m3u_r123.png"}.get(kind)
        try:
            if icon_path:
                pix=LoadPixmap(os.path.join(PLUGIN_PATH,icon_path)); self["detailIcon"].instance.setPixmap(pix); self["detailIcon"].show()
            else:self["detailIcon"].hide()
        except Exception:pass
        try:
            show_url=str(url or "")
            show_user=""
            show_pass=""
            show_mac=""

            if kind=="xtream" and row.get("_local_xtream"):
                show_url=url
                show_user=str(row.get("_local_user") or "")
                show_pass="••••••••"
            elif kind=="xtream":
                try:
                    from .web_manager import _xtream_from_m3u_url
                    xt=_xtream_from_m3u_url(url) or {}
                    show_url=str(xt.get("url") or url).rstrip("/")
                    show_user=str(xt.get("username") or "")
                    show_pass=str(xt.get("password") or "")
                except Exception:
                    pass
            elif kind=="stalker":
                show_mac=self._rowMac(row)
            # M3U intentionally uses URL only.

            self["fieldUrl"].setText(show_url[:72])
            self["fieldUser"].setText(show_user[:40])
            self["fieldPass"].setText(show_pass[:40])
            self["fieldMac"].setText(show_mac[:24])
        except Exception:
            pass

    def openCurrent(self):
        row=self._selectedRow()
        if not row:return
        kind=str(row.get("kind") or "").lower()
        url=str(row.get("url") or "").strip()
        if not url:return
        self._finderLog("OPEN_RESULT", kind=kind, source=self._source, url=url, fast_service=row.get("fast_service") or "")
        source=None

        # Xumo Play / Free TV. Download only on OPEN and keep a local cache.
        _fast_service=str(row.get("fast_service") or "").strip().lower()
        _fast_region=str(row.get("fast_region") or "all").strip().lower()
        if kind=="m3u" and _fast_service in ("xumo","freetv","localnow","lgchannels","roku","tubitv","vizio","tclplus","freelivesports"):
            source=None
            _cache_ttl=(60 if (_fast_service == "lgchannels" and _fast_region == "ae") else 6*60*60)
            _path=finder_playlist_path("tivimatee2_%s_%s.m3u"%(_fast_service,_fast_region))
            _fast_map={
                "xumo":("https://www.apsattv.com/xumo.m3u","XUMO PLAY - LIVE"),
                "freetv":("https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8","FREE TV - WORLD"),
                "localnow":("https://www.apsattv.com/localnow.m3u?","LOCAL NOW - LIVE"),
                "lgchannels":(("https://www.apsattv.com/aelg.m3u" if _fast_region == "all" else "https://www.apsattv.com/%slg.m3u"%_fast_region),"LG CHANNELS - %s"%_fast_region.upper()),
                "roku":("https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/roku_all.m3u","ROKU CHANNEL - LIVE"),
                "tubitv":("https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/tubi_all.m3u","TUBI LIVE TV"),
                "vizio":("https://www.apsattv.com/vizio.m3u","VIZIO WATCHFREE+ - LIVE"),
                "tclplus":("https://www.apsattv.com/tclplus.m3u","TCL TV+ - LIVE"),
                "freelivesports":("https://www.apsattv.com/freelivesports.m3u","FREE LIVE SPORTS"),
            }
            _remote,_name=_fast_map[_fast_service]
            _need=True
            try:
                if os.path.exists(_path) and os.path.getsize(_path)>64:
                    _age=time.time()-os.path.getmtime(_path)
                    _need=not (0 <= _age < _cache_ttl)
            except Exception:
                _need=True
            # A failed refresh may still leave a previously valid playlist.
            # Use it once without entering a refresh/open/refresh recursion.
            _cache_token=(str(_fast_service),str(_fast_region))
            _skip_upgrade_retry=(getattr(self,"_fast_open_stale_once",None)==_cache_token)
            if _skip_upgrade_retry:
                _need=False
                self._fast_open_stale_once=None
            # Force one rebuild after upgrading from the discontinued LG ALL URL.
            # Don't retry forever if refresh failed but the old file is usable.
            if (_fast_service == "lgchannels" and _fast_region == "all" and
                    not os.path.isfile(_path + ".regions-v2") and
                    not _skip_upgrade_retry):
                _need=True
            if _need:
                # Network download must never run on the Enigma2 main/UI thread.
                # Start one lightweight background fetch and reopen the row only
                # after the local cache is ready.
                _token=(str(_fast_service),str(_fast_region))
                if getattr(self,"_fast_open_loading",None)==_token:
                    return
                self._fast_open_loading=_token
                self._fastPlaylistSerial += 1
                _request_id = self._fastPlaylistSerial
                _selected_generation = self._generation
                _selected_url = url
                self._fastPlaylistRequest=(_token,_request_id,_selected_generation,_selected_url)
                try: self._fastPlaylistTimer.start(90000,True)
                except Exception: pass
                try:
                    self["status"].setText("LOADING %s..."%_name)
                except Exception:
                    pass
                def _fetch_fast():
                    _err=None
                    try:
                        _req=Request(_remote,headers={"User-Agent":"Mozilla/5.0 (Enigma2; TiviMateE2)","Accept":"application/x-mpegURL,text/plain,*/*"})
                        # The old apsattv.com/lg.m3u combined list is no longer
                        # maintained. Build LG ALL from the current regional lists.
                        if _fast_service == "lgchannels" and _fast_region == "all":
                            from concurrent.futures import ThreadPoolExecutor, as_completed
                            _lg_codes=("ae","us","gb","ca","au","de","fr","it","es","pt",
                                "at","be","ch","dk","fi","ie","lu","nl","no","se",
                                "pl","ar","br","cl","co","mx","pe","in","jp","kr","sg","nz")
                            def _fetch_lg_region(_code):
                                _u="https://www.apsattv.com/%slg.m3u"%_code
                                _q=Request(_u,headers={"User-Agent":"Mozilla/5.0 (Enigma2; TiviMateE2)",
                                                       "Accept":"application/x-mpegURL,text/plain,*/*"})
                                _body=urlopen(_q,timeout=8).read(4*1024*1024)
                                _text=_body.decode("utf-8","replace") if isinstance(_body,bytes) else str(_body or "")
                                if not _text.lstrip().startswith("#EXTM3U") or "#EXTINF" not in _text:
                                    raise ValueError("Not a valid M3U list")
                                return _code,_text
                            _regions_ok=0
                            _sections=["#EXTM3U"]
                            _region_errors=[]
                            _regional_text={}
                            with ThreadPoolExecutor(max_workers=6) as _executor:
                                _futures={_executor.submit(_fetch_lg_region,_code):_code for _code in _lg_codes}
                                for _future in as_completed(_futures):
                                    try:
                                        _code,_region_text=_future.result()
                                        _regional_text[_code]=_region_text
                                        _regions_ok+=1
                                    except Exception as _region_exc:
                                        _region_errors.append("%s:%s"%(_futures[_future],str(_region_exc)[:45]))
                            # Display UAE/USA first regardless of network completion order.
                            for _code in _lg_codes:
                                if _code in _regional_text:
                                    _sections.append("\n".join(_line for _line in _regional_text[_code].splitlines()
                                        if not _line.strip().startswith("#EXTM3U")))
                            if _regions_ok < 1:
                                raise ValueError("LG ALL: no regional M3U was available ("+
                                                 ", ".join(_region_errors[:3])+")")
                            self._finderLog("LG_ALL_FETCHED", regions=_regions_ok,
                                            failures=len(_region_errors))
                            _raw="\n".join(_sections).encode("utf-8")
                        # LG AE/US can respond slowly; keep both fallbacks off the UI thread.
                        elif _fast_service == "lgchannels" and _fast_region in ("ae", "us"):

                            # APSATTV has had host/TLS reachability issues where the
                            # plain HTTP playlist remained reachable. For UAE only,
                            # validate HTTPS first then transparently fall back to HTTP.
                            _raw=None
                            _last_exc=None
                            _ae_urls=(
                                "https://www.apsattv.com/uslg.m3u",
                                "https://raw.githubusercontent.com/JulioCesarXY/EPG-LG-Channels/main/lg_channels_us.m3u",
                            ) if _fast_region == "us" else (
                                "https://www.apsattv.com/aelg.m3u",
                                "http://www.apsattv.com/aelg.m3u",
                            )
                            for _ae_url in _ae_urls:
                                for _attempt in range(1):
                                    try:
                                        _ae_req=Request(_ae_url,headers={"User-Agent":"Mozilla/5.0 (Enigma2; TiviMateE2)","Accept":"application/x-mpegURL,text/plain,*/*"})
                                        _candidate=urlopen(_ae_req,timeout=10).read(12*1024*1024)
                                        _probe=_candidate.decode("utf-8","replace") if isinstance(_candidate,bytes) else str(_candidate or "")
                                        if _probe.lstrip().startswith("#EXTM3U") and "#EXTINF" in _probe and "http" in _probe:
                                            _raw=_candidate
                                            break
                                        _last_exc=Exception("LG AE playlist is invalid")
                                    except Exception as _retry_exc:
                                        _last_exc=_retry_exc
                                    if _attempt < 1:
                                        time.sleep(1)
                                if _raw is not None:
                                    break
                            if _raw is None:
                                raise _last_exc or Exception("LG AE download failed")
                        else:
                            _raw=urlopen(_req,timeout=5).read(12*1024*1024)
                        _txt=_raw.decode("utf-8","replace") if isinstance(_raw,bytes) else str(_raw or "")
                        if not _txt.lstrip().startswith("#EXTM3U") or "#EXTINF" not in _txt or "http" not in _txt:
                            raise Exception("Downloaded playlist is invalid")
                        # LG playlists can occasionally be published with the stream URL
                        # appended to the EXTINF line. Normalize that form before M3UClient
                        # parses it. Local Live always re-parses the converted file;
                        # a stale empty catalog cannot override working M3U data.
                        if _fast_service == "lgchannels":
                            _txt=re.sub(r"[ \t]+(?=#EXTINF:)", "\n", _txt)
                            _fixed=[]
                            for _line in _txt.splitlines():
                                if _line.startswith("#EXTINF") and "," in _line:
                                    _comma=_line.find(",")
                                    _m=re.search(r"[ \t]+(https?://\S+)\s*$", _line[_comma+1:])
                                    if _m:
                                        _abs=_comma+1+_m.start()
                                        _fixed.append(_line[:_abs].rstrip())
                                        _fixed.append(_m.group(1).strip())
                                        continue
                                _fixed.append(_line)
                            _txt="\n".join(_fixed)+"\n"

                        # Tubi's generated public playlist can arrive flattened, with
                        # #EXTINF records and their stream URLs on the same physical
                        # line. M3UClient expects the URL on the following line.
                        # Normalize Tubi only; keep every other FAST source untouched.
                        if _fast_service == "tubitv":
                            _txt=re.sub(r"[ \t]+(?=#EXTINF:)", "\n", _txt)
                            _fixed=[]
                            for _line in _txt.splitlines():
                                if _line.startswith("#EXTINF") and "," in _line:
                                    _comma=_line.find(",")
                                    _m=re.search(r"[ \t]+(https?://\S+)\s*$", _line[_comma+1:])
                                    if _m:
                                        _abs=_comma+1+_m.start()
                                        _fixed.append(_line[:_abs].rstrip())
                                        _fixed.append(_m.group(1).strip())
                                        continue
                                _fixed.append(_line)
                            _txt="\n".join(_fixed)+"\n"
                        # Verify the *converted* playlist before atomically replacing
                        # an existing working LG M3U. A valid header is insufficient.
                        if _fast_service == "lgchannels":
                            _check_lines=_txt.replace("\r\n","\n").split("\n")
                            _valid_channels=0
                            _pending=False
                            for _line in _check_lines:
                                _line=_line.strip()
                                if _line.startswith("#EXTINF:"):
                                    _pending=True
                                elif _line.startswith("#") or not _line:
                                    continue
                                elif _pending:
                                    if _line.lower().startswith(("http://","https://")):
                                        _valid_channels+=1
                                    _pending=False
                            if _valid_channels < 1:
                                raise ValueError("LG M3U has no readable EXTINF/URL channel pairs")
                            self._finderLog("LG_PLAYLIST_PARSED", region=_fast_region, channels=_valid_channels)
                        _tmp=_path+".tmp.%d"%_request_id
                        with open(_tmp,"w") as _fh:
                            _fh.write(_txt)
                            if not _txt.endswith("\n"):_fh.write("\n")
                        if self._fastPlaylistRequest != (_token,_request_id,_selected_generation,_selected_url):
                            try: os.remove(_tmp)
                            except Exception: pass
                            return
                        os.rename(_tmp,_path)
                        if _fast_service == "lgchannels" and _fast_region == "all":
                            try:
                                with open(_path+".regions-v2","w") as _marker:
                                    _marker.write("region-aggregation\n")
                            except Exception:
                                pass
                    except Exception as _exc:
                        _err=_exc
                        self._finderLog("FAST_DOWNLOAD_FAILED", source=_fast_service, region=_fast_region, error=str(_exc)[:180])
                    def _done():
                        if (getattr(self, "_fast_open_loading", None) != _token or
                                self._fastPlaylistRequest != (_token,_request_id,_selected_generation,_selected_url)):
                            return
                        self._fast_open_loading=None
                        self._fastPlaylistRequest=None
                        try: self._fastPlaylistTimer.stop()
                        except Exception: pass
                        # A callback from an old row must not reopen a new row,
                        # change its status, or display an unrelated error.
                        if not self._finishPlaylistStatus(_selected_generation, _selected_url, "READY"):
                            return
                        _cache_valid=False
                        try:
                            if os.path.isfile(_path) and os.path.getsize(_path)>64:
                                with open(_path,"rb") as _fh:
                                    _h=_fh.read(12*1024*1024)
                                _cache_valid=(_h.lstrip().startswith(b"#EXTM3U") and
                                              b"#EXTINF:" in _h and
                                              any(_ln.strip().startswith((b"http://",b"https://"))
                                                  for _ln in _h.splitlines()))
                        except Exception:
                            pass
                        if _err is not None:
                            if not _cache_valid:
                                self._finishPlaylistStatus(_selected_generation, _selected_url,
                                    "FAILED %s — PRESS OK TO RETRY" % _name)
                                self.session.open(MessageBox,"Could not load %s.\n\n%s"%(_name,_err),MessageBox.TYPE_ERROR,timeout=6)
                                return
                            self._fast_open_stale_once=_token
                            try:self["status"].setText("USING CACHED %s (refresh failed)"%_name)
                            except Exception:pass
                        self.openCurrent()
                    try:
                        if reactor is not None: reactor.callFromThread(_done)
                        else: _done()
                    except Exception:
                        pass
                _t=threading.Thread(target=_fetch_fast)
                _t.daemon=True
                _t.start()
                return
            source={"type":"m3u","name":_name,"url":_path,"path":_path,"m3u_mode":"file","service_type":4097,
                    "fast_service":_fast_service,"fast_region":_fast_region}
        # Samsung TV Plus grouped playlists: one row per region. Build a local M3U
        # from the current public catalog only when the row is opened/added.
        _samsung_group=str(row.get("samsung_group") or "").strip().lower()
        if source is None and kind=="m3u" and _samsung_group:
            try:
                req=Request("https://i.mjh.nz/SamsungTVPlus/.channels.json.gz",headers={"User-Agent":"Mozilla/5.0"})
                raw=urlopen(req,timeout=4).read(4*1024*1024)
                data=json.loads(gzip.decompress(raw).decode("utf-8","ignore"))
                regions=(data or {}).get("regions") or {}
                _region_map={str(k).lower():v for k,v in regions.items()}
                if _samsung_group in ("all","arabic-all"):
                    _wanted=sorted(_region_map.keys())
                elif _samsung_group=="middleeast":
                    # Samsung MENA catalogs have used both country keys and
                    # aggregate Middle-East keys across catalog revisions.
                    # Accept all known aliases instead of assuming ae/sa/eg only.
                    _me_aliases=("ae","sa","eg","mena","me","middleeast","middle-east","mideast","gcc")
                    _wanted=[x for x in _me_aliases if x in _region_map]
                    # Some catalogs expose a descriptive region key rather than a code.
                    for _rk in sorted(_region_map.keys()):
                        _norm=re.sub(r"[^a-z]","",str(_rk).lower())
                        if _norm in ("middleeast","middleeastnorthafrica","mena","gcc") and _rk not in _wanted:
                            _wanted.append(_rk)
                else:
                    _wanted=[_samsung_group] if _samsung_group in _region_map else []
                _slug_fmt=str((data or {}).get("slug") or "sam-{id}.m3u8")
                _entries=[]; _seen=set()
                for _rk in _wanted:
                    _chs=((_region_map.get(_rk) or {}).get("channels") or {})
                    for _cid,_ch in sorted(_chs.items(),key=lambda kv:(int((kv[1] or {}).get("chno") or 999999),str((kv[1] or {}).get("name") or ""))):
                        if not isinstance(_ch,dict) or _ch.get("license_url"): continue
                        if _samsung_group=="arabic-all":
                            # Arabic channels across every Samsung region. Prefer explicit
                            # language metadata; Arabic script in title is a safe fallback.
                            _nm=str(_ch.get("name") or "")
                            _lang_parts=[]
                            for _lk in ("language","lang","languages","audio_language","audio_languages"):
                                _lv=_ch.get(_lk)
                                if isinstance(_lv,(list,tuple)):
                                    _lang_parts.extend([str(x).lower() for x in _lv])
                                elif _lv:
                                    _lang_parts.append(str(_lv).lower())
                            _lang_text=" ".join(_lang_parts)
                            _is_ar_lang=bool(re.search(r"(^|[^a-z])(ar|ara|arabic)([^a-z]|$)",_lang_text))
                            _is_ar_name=bool(re.search(u"[\u0600-\u06ff]",_nm))
                            # Known Arabic FAST brands/titles that may use Latin names.
                            _latin=_nm.lower()
                            _ar_brands=("shahid","khaleej","khaleeji","bab al hara","shamiyat","shami","aflam z","rotana","al arabiya","al jazeera arabic")
                            _is_ar_brand=any(x in _latin for x in _ar_brands)
                            if not (_is_ar_lang or _is_ar_name or _is_ar_brand):
                                continue
                        _slug=_slug_fmt.format(id=str(_cid))
                        _stream="https://jmp2.uk/%s"%_slug.lstrip("/")
                        if _stream in _seen: continue
                        _seen.add(_stream)
                        _name=str(_ch.get("name") or _cid).strip()
                        _logo=str(_ch.get("logo") or _ch.get("image") or "").strip()
                        _meta='#EXTINF:-1 tvg-id="%s" group-title="Samsung TV Plus - %s"%s,%s'%(str(_cid),_rk.upper(),(' tvg-logo="%s"'%_logo if _logo else ''),_name)
                        _entries.append((_meta,_stream))
                if not _entries:
                    self.session.open(MessageBox,"No Samsung TV Plus channels were returned for this region.",MessageBox.TYPE_INFO,timeout=5)
                    return
                _safe=re.sub(r"[^a-z0-9_-]+","_",_samsung_group)
                _path=finder_playlist_path("tivimatee2_samsung_%s.m3u"%_safe)
                _samsung_epg_region=_samsung_group if _samsung_group not in ("all","arabic-all","middleeast") else "all"
                _samsung_epg="https://i.mjh.nz/SamsungTVPlus/%s.xml.gz"%_samsung_epg_region
                with open(_path,"w") as _fh:
                    _fh.write('#EXTM3U url-tvg="%s"\n'%_samsung_epg)
                    for _meta,_stream in _entries:
                        _fh.write(_meta+"\n"+_stream+"\n")
                source={"type":"m3u","name":str(row.get("display_name") or "SAMSUNG TV PLUS"),"url":_path,"path":_path,"m3u_mode":"file","service_type":4097,"epg_url":_samsung_epg,"fast_service":"samsung","fast_region":_samsung_group}
            except Exception as exc:
                self.session.open(MessageBox,"Could not build Samsung TV Plus region package.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=7)
                return
        elif source is None:
            source=None

        # Xiaomi TV+ grouped packages. Fetch the current public Xiaomi M3U only
        # when the user opens the selected category, then filter locally.
        _xiaomi_group=str(row.get("xiaomi_group") or "").strip().lower()
        if source is None and kind=="m3u" and _xiaomi_group:
            try:
                _srcurl="https://www.apsattv.com/xiaomi.m3u"
                req=Request(_srcurl,headers={"User-Agent":"Mozilla/5.0"})
                raw=urlopen(req,timeout=4).read(8*1024*1024)
                _txt=raw.decode("utf-8","replace") if isinstance(raw,bytes) else str(raw)
                _lines=_txt.replace("\r\n","\n").replace("\r","\n").split("\n")
                _xiaomi_header=next((x.strip() for x in _lines if x.strip().startswith("#EXTM3U")),"#EXTM3U")
                _xiaomi_epg=""
                try:
                    _hm=dict(re.findall(r'([\w-]+)="([^"]*)"',_xiaomi_header)); _hm.update(dict(re.findall(r"([\w-]+)='([^']*)'",_xiaomi_header)))
                    _xiaomi_epg=str(_hm.get("url-tvg") or _hm.get("x-tvg-url") or "").strip()
                except Exception:
                    _xiaomi_epg=""
                # Region classifier. Prefer country/region metadata when the
                # playlist provides it; fall back to channel-name/location hints.
                _regions={
                    "middle_east":("uae","united arab emirates","saudi","saudi arabia","ksa","qatar","kuwait","bahrain","oman","iraq","jordan","lebanon","egypt","israel","turkey","turkiye","arab","mena","middle east"),
                    "latin_america":("mexico","mexican","brazil","brasil","argentina","colombia","peru","chile","bolivia","uruguay","paraguay","ecuador","panama","guatemala","costa rica","el salvador","latam","latin america"),
                    "north_america":("usa","u.s.","united states","american","canada","canadian","north america"),
                    "africa":("south africa","morocco","maroc","tunisia","nigeria","kenya","algeria","africa","african"),
                    "asia":("india","indian","malaysia","vietnam","cambodia","laos","myanmar","indonesia","singapore","philippines","thailand","korea","korean","japan","japanese","hong kong","macau","taiwan","asia","asian"),
                    "europe":("uk","united kingdom","britain","british","england","spain","spanish","france","french","italy","italian","germany","german","portugal","poland","greece","ukraine","romania","czech","hungary","croatia","lithuania","slovakia","slovenia","sweden","norway","denmark","finland","bulgaria","latvia","cyprus","malta","estonia","iceland","netherlands","belgium","switzerland","austria","ireland","europe","european"),
                }
                def _region(_meta):
                    _low=(" "+str(_meta or "").lower()+" ").replace("_"," ").replace("-"," ")
                    for _gid in ("middle_east","latin_america","north_america","africa","asia","europe"):
                        if any((" "+_x+" ") in _low for _x in _regions.get(_gid,())):
                            return _gid
                    return "other"
                _entries=[]; _i=0
                while _i<len(_lines):
                    _meta=_lines[_i].strip()
                    if _meta.startswith("#EXTINF"):
                        _j=_i+1
                        while _j<len(_lines) and (not _lines[_j].strip() or _lines[_j].lstrip().startswith("#")):
                            _j+=1
                        if _j<len(_lines):
                            _stream=_lines[_j].strip()
                            if _stream and not _stream.startswith("#"):
                                _c=_region(_meta)
                                if _xiaomi_group=="all" or _c==_xiaomi_group:
                                    _entries.append((_meta,_stream))
                            _i=_j
                    _i+=1
                if not _entries:
                    self.session.open(MessageBox,"No Xiaomi TV+ channels were returned for this category.",MessageBox.TYPE_INFO,timeout=5)
                    return
                _safe=re.sub(r"[^a-z0-9_-]+","_",_xiaomi_group)
                _path=finder_playlist_path("tivimatee2_xiaomi_%s.m3u"%_safe)
                with open(_path,"w") as _fh:
                    _fh.write((_xiaomi_header or "#EXTM3U")+"\n")
                    _seen=set()
                    for _meta,_stream in _entries:
                        _key=str(_stream or "").strip()
                        if _key in _seen: continue
                        _seen.add(_key)
                        _fh.write(_meta+"\n"+_stream+"\n")
                source={"type":"m3u","name":str(row.get("display_name") or "XIAOMI TV+"),"url":_path,"path":_path,"m3u_mode":"file","service_type":4097,"fast_service":"xiaomi","fast_region":_xiaomi_group}
                if _xiaomi_epg:
                    source["epg_url"]=_xiaomi_epg
            except Exception as exc:
                self.session.open(MessageBox,"Could not build Xiaomi TV+ package.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=7)
                return
        elif source is None and not _samsung_group:
            source=None

        # IPTV-Org grouped Arabic playlists: build one local M3U from all relevant
        # official public playlists. Exact duplicate stream URLs are collapsed when
        # the local group is written; different URLs for the same channel are kept.
        _iptvorg_group=str(row.get("iptvorg_group") or "").strip().lower()
        if source is None and kind=="m3u" and _iptvorg_group:
            _safe=re.sub(r"[^a-z0-9_-]+","_",_iptvorg_group)
            _path=finder_playlist_path("tivimatee2_iptvorg_arabic_%s.m3u"%_safe)
            # 5002 must not be forced on images without ServiceApp/exteplayer3.
            # Keep the existing MBC preference when it is genuinely available.
            try:
                from .live_player import _available_service_types
                _available_players = [int(v) for v, _ in _available_service_types()]
            except Exception:
                _available_players = [4097]
            _svc_type=(5002 if _iptvorg_group in ("mbc","shahid","mbcshahid") and
                       5002 in _available_players else 4097)
            _cache_ok=False
            try:
                if os.path.getsize(_path)>64 and 0<=time.time()-os.path.getmtime(_path)<7200:
                    with open(_path,"rb") as _fh:
                        _header=_fh.read(4096)
                    _cache_ok=_header.startswith(b"#EXTM3U") and b"#EXTINF" in _header
            except Exception:
                pass
            if _cache_ok:
                source={"type":"m3u","name":str(row.get("display_name") or "ARABIC IPTV-ORG"),"url":_path,"path":_path,"m3u_mode":"file","service_type":_svc_type,"finder_source":"iptvorg"}
            else:
                _token="iptvorg:"+_iptvorg_group
                _selected_url=url
                _selected_generation=self._generation
                if getattr(self,"_iptvorg_build_loading",None)==_token:
                    return
                self._iptvorg_build_loading=_token
                self._iptvorgPlaylistSerial += 1
                _request_id = self._iptvorgPlaylistSerial
                self._iptvorgPlaylistRequest=(_token,_request_id,_selected_generation,_selected_url)
                try: self._iptvorgPlaylistTimer.start(90000,True)
                except Exception: pass
                try:self["status"].setText("LOADING IPTV-ORG %s..."%_iptvorg_group.upper())
                except Exception:pass
                def _build_iptvorg():
                    _err=None
                    try:
                        from .web_manager import _urlopen_text
                        _base="https://iptv-org.github.io/iptv/"
                        _arab_codes=set(("ae","sa","qa","kw","bh","om","eg","iq","jo","lb","sy","ps","ye","ly","tn","dz","ma","sd","so","mr","dj","km"))
                        # All nine groups share verified official Arabic sources.
                        # Prefer the Arabic language/world feeds; do not wait on
                        # every older region alias that can return transport errors.
                        _urls=[_base+"languages/ara.m3u", _base+"regions/arab.m3u", _base+"regions/gcc.m3u"]
                        # Official country playlists are a fallback, not fake channels.
                        # This works when a regional generated playlist is empty.
                        # If the smaller Arabic playlists are unreachable, the
                        # official language-grouped master is another valid source.
                        # Two country lists are last-resort, not fabricated data.
                        _language_fallback=_base+"index.language.m3u"
                        _country_fallback=[_base+"countries/%s.m3u"%_cc for _cc in ("ae","sa")]
                        _fetch_failures=[]
                        _fetched_ok=0
                        if _iptvorg_group=="sports":
                            _urls += [_base+"categories/sports.m3u", _base+"countries/uk.m3u"]
                        _keywords={
                            "general":("group-title=\"general\"","group-title='general'","group-title=general"," general","public"),
                            "sports":("sport","bein","be in","sky sport","ssc","alkass","ad sports","dubai sports","riyadi"),
                            "mbc":("mbc",),
                            "shahid":("shahid",),
                            "mbcshahid":("mbc","shahid","al arabiya","alarabiya","al hadath","alhadath","العربية","الحدث"),
                            "movies":("movie","movies","film","cinema","aflam","افلام","أفلام"),
                            "entertainment":("entertainment","series","drama","comedy","lifestyle","music","مسلسل","دراما","ترفيه"),
                            "news":("news","اخبار","أخبار"),
                            "kids":("kids","children","cartoon","animation","family","طفل","اطفال","أطفال","كرتون"),
                            "culture":("culture","documentary","education","science","travel","ثقاف","وثائق","تعليم","علوم"),
                            "religion":("religious","religion","quran","islam","دين","قرآن","اسلام"),
                        }
                        _entries=[]
                        # The general ALL row stays untouched. Grouped rows
                        # fetch valid M3U with a shared 2-hour cache and a
                        # separate HTTPS client on transport failure.
                        from .iptvorg_fetch import fetch_iptvorg_m3u
                        _candidate_urls=_urls+[_language_fallback]+_country_fallback
                        for _srcurl in _candidate_urls:
                            if _srcurl in ([_language_fallback]+_country_fallback) and _entries:
                                break
                            try:
                                _txt,_cache_used=fetch_iptvorg_m3u(_srcurl,timeout=7,max_bytes=24*1024*1024)
                                _fetched_ok+=1
                                _lines=_txt.replace("\r\n","\n").replace("\r","\n").split("\n")
                                _i=0
                                while _i < len(_lines):
                                    _meta=_lines[_i].strip()
                                    if _meta.startswith("#EXTINF"):
                                        _j=_i+1
                                        _stream_options=[]
                                        while _j<len(_lines) and (not _lines[_j].strip() or _lines[_j].lstrip().startswith("#")):
                                            _directive=_lines[_j].strip()
                                            # Preserve only recognized IPTV-Org header
                                            # directives; no unrelated VLC options leak.
                                            if _directive.lower().startswith("#extvlcopt:"):
                                                _opt=_directive.split(":",1)[1]
                                                if _opt.lower().startswith(("http-user-agent=", "http-referrer=", "http-referer=")):
                                                    _stream_options.append(_directive)
                                            _j+=1
                                        if _j<len(_lines):
                                            _stream=_lines[_j].strip()
                                            if _stream and not _stream.startswith("#"):
                                                _low=_meta.lower()
                                                # index.language.m3u is worldwide:
                                                # include its Arabic group only.
                                                if _srcurl==_language_fallback:
                                                    if not ('group-title="arabic"' in _low or "group-title='arabic'" in _low or 'group-title=arabic' in _low):
                                                        _i=_j+1
                                                        continue
                                                _keep=(_iptvorg_group=="all")
                                                if not _keep:
                                                    _keep=any(k in _low for k in _keywords.get(_iptvorg_group,()))
                                                if _iptvorg_group=="sports" and ("bein" in _low or "be in" in _low or "sky sport" in _low):
                                                    _keep=True
                                                if _keep: _entries.append((_meta,_stream,tuple(_stream_options)))
                                            _i=_j
                                    _i+=1
                            except Exception as _src_exc:
                                _fetch_failures.append("%s: %s"%(_srcurl,str(_src_exc)[:80]))
                                continue
                        if not _entries:
                            _reason=("No valid IPTV-Org M3U could be fetched" if not _fetched_ok else
                                     "No channel matched this IPTV-Org category")
                            self._finderLog("IPTVORG_EMPTY_GROUP", group=_iptvorg_group,
                                valid_playlists=_fetched_ok, failures="; ".join(_fetch_failures[-4:])[:450])
                            raise ValueError(_reason + ("; " + "; ".join(_fetch_failures[:2]) if _fetch_failures else ""))
                        # Stable Arabic channel order inside every generated package:
                        # MBC first, then Gulf networks by country, then Egypt/Levant/Iraq/Maghreb,
                        # and finally the remaining Arabic channels. This changes presentation only.
                        _country_markers=(
                            (0,("mbc",)),
                            (10,("uae","emirates","dubai","abu dhabi","abudhabi","sharjah","الإمارات","دبي","أبوظبي","الشارقة")),
                            (11,("saudi","ksa","saudi arabia","السعودية","السعوديه")),
                            (12,("kuwait","الكويت")),
                            (13,("qatar","doha","قطر","الدوحة")),
                            (14,("bahrain","البحرين")),
                            (15,("oman","muscat","عمان","مسقط")),
                            (20,("egypt","masr","cairo","مصر","القاهرة")),
                            (30,("lebanon","beirut","لبنان","بيروت","syria","sham","سوريا","الشام","jordan","الأردن","palestine","فلسطين")),
                            (40,("iraq","baghdad","العراق","بغداد")),
                            (50,("morocco","المغرب","algeria","الجزائر","tunisia","تونس","libya","ليبيا","mauritania","موريتانيا")),
                        )
                        def _arabic_channel_rank(_item):
                            _m=str(_item[0] or "").lower().replace("_"," ").replace("-"," ")
                            _name=_m.rsplit(",",1)[-1].strip()
                            _rank=80
                            for _r,_marks in _country_markers:
                                if any(_x in _m for _x in _marks):
                                    _rank=_r; break
                            _num=re.search(r"(?:^|\s)(\d{1,3})(?:\s|$)",_name)
                            _n=int(_num.group(1)) if _num else 999
                            return (_rank,_name.split()[0] if _name else "",_n,_name)
                        _entries.sort(key=_arabic_channel_rank)

                        # Combined MBC/Shahid/news package. Keep MBC first, Shahid second,
                        # and MBC-group news (Al Arabiya/Al Hadath) last.
                        if _iptvorg_group in ("mbc","mbcshahid"):
                            _mbc_order=("mbc 1","mbc1","mbc 2","mbc2","mbc 3","mbc3","mbc 4","mbc4","mbc 5","mbc5",
                                        "mbc action","mbc max","mbc drama","mbc bollywood","mbc masr 2","mbc masr","mbc iraq")
                            def _mbc_rank(_item):
                                _m=str(_item[0] or "").lower().replace("_"," ").replace("-"," ")
                                for _ix,_key in enumerate(_mbc_order):
                                    if _key in _m:
                                        return (0,_ix,_m)
                                if "mbc" in _m:
                                    return (0,900,_m)
                                if "shahid" in _m:
                                    return (1,0,_m)
                                if any(_k in _m for _k in ("al arabiya","alarabiya","al hadath","alhadath","العربية","الحدث")):
                                    return (2,0,_m)
                                return (3,0,_m)
                            _entries.sort(key=_mbc_rank)
                        _safe=re.sub(r"[^a-z0-9_-]+","_",_iptvorg_group)
                        _path=finder_playlist_path("tivimatee2_iptvorg_arabic_%s.m3u"%_safe)
                        _tmp_path=_path+".tmp.%d"%_request_id
                        with open(_tmp_path,"w") as _fh:
                            _fh.write("#EXTM3U\n")
                            _seen_streams=set()
                            for _meta,_stream,_stream_options in _entries:
                                # De-duplicate the actual stream link across all overlapping
                                # Arabic IPTV-Org source playlists. Normalize harmless textual
                                # differences only; keep query strings because they may identify
                                # genuinely different feeds.
                                _stream_key=str(_stream or "").strip().replace("&amp;","&")
                                _hash=_stream_key.find("#")
                                if _hash>0:
                                    _stream_key=_stream_key[:_hash]
                                _stream_key=_stream_key.rstrip("/")
                                if _stream_key in _seen_streams:
                                    continue
                                _seen_streams.add(_stream_key)
                                _fh.write(_meta+"\n")
                                for _option in _stream_options:
                                    _fh.write(_option+"\n")
                                _fh.write(_stream+"\n")
                        if len(_seen_streams)<1:
                            raise ValueError("IPTV-Org converted M3U contains zero streams")
                        if self._iptvorgPlaylistRequest != (_token,_request_id,_selected_generation,_selected_url):
                            try: os.remove(_tmp_path)
                            except Exception: pass
                            return
                        os.rename(_tmp_path,_path)
                        self._finderLog("IPTVORG_PLAYLIST_PARSED", group=_iptvorg_group, channels=len(_seen_streams))
                        # MBC & SHAHID only: prefer service type 5002 for its HLS/audio handling.
                        # Other IPTV-Org groups keep the normal 4097 player path.
                        _svc_type=(5002 if _iptvorg_group in ("mbc","shahid","mbcshahid") and
                                   5002 in _available_players else 4097)
                    except Exception as exc:
                        _err=exc
                        self._finderLog("IPTVORG_DOWNLOAD_FAILED", group=_iptvorg_group, error=str(exc)[:180])
                    def _done():
                        if (getattr(self, "_iptvorg_build_loading", None) != _token or
                                self._iptvorgPlaylistRequest != (_token,_request_id,_selected_generation,_selected_url)):
                            return
                        self._iptvorg_build_loading=None
                        self._iptvorgPlaylistRequest=None
                        try: self._iptvorgPlaylistTimer.stop()
                        except Exception: pass
                        if not self._finishPlaylistStatus(_selected_generation, _selected_url, "READY"):
                            return
                        if _err is not None:
                            self._finishPlaylistStatus(_selected_generation, _selected_url,
                                "IPTV-ORG FAILED — PRESS OK TO RETRY")
                            self.session.open(MessageBox,"Could not build IPTV-Org group.\n\n%s"%_err,MessageBox.TYPE_ERROR,timeout=7)
                        else:
                            self.openCurrent()
                    if reactor is not None:
                        reactor.callFromThread(_done)
                    else:
                        _done()
                _thread=threading.Thread(target=_build_iptvorg)
                _thread.daemon=True
                _thread.start()
                return
        elif source is None and not _samsung_group and not _xiaomi_group:
            source=None
        try:
            if source is not None:
                pass
            elif kind=="xtream":
                if row.get("_local_xtream"):
                    user=str(row.get("_local_user") or "")
                    password=str(row.get("_local_password") or "")
                    if not user or not password:
                        self.session.open(MessageBox,"Missing local Xtream credentials.",MessageBox.TYPE_ERROR,timeout=5)
                        return
                    source={"type":"xtream","name":url.split("://")[-1],
                            "url":url.rstrip("/"),"username":user,
                            "password":password,
                            "output":str(row.get("_local_output") or "ts"),
                            "service_type":4097}
                else:
                    from .web_manager import _xtream_from_m3u_url
                    xt=_xtream_from_m3u_url(url)
                    if not xt:
                        self.session.open(MessageBox,"Xtream credentials were not found in this result.",MessageBox.TYPE_ERROR,timeout=5)
                        return
                    host=str(xt.get("url") or "").rstrip("/")
                    name=host.replace("http://","").replace("https://","").split("/")[0] or "Xtream Server"
                    source={
                        "type":"xtream","name":name,"url":host,
                        "username":str(xt.get("username") or ""),
                        "password":str(xt.get("password") or ""),
                        "output":str(xt.get("output") or "ts"),
                        "service_type":4097
                    }
            elif kind=="m3u":
                # Telegram often publishes an Xtream get.php playlist URL in
                # an M3U-labelled post.  Preserve its username/password by
                # adding it as Xtream instead of stripping it down to a fake
                # /playlist.m3u8 style source.
                try:
                    from .web_manager import _xtream_from_m3u_url
                    xt=_xtream_from_m3u_url(url)
                except Exception:
                    xt=None
                if xt:
                    host=str(xt.get("url") or "").rstrip("/")
                    name=host.replace("http://","").replace("https://","").split("/")[0] or "Xtream Server"
                    source={
                        "type":"xtream","name":name,"url":host,
                        "username":str(xt.get("username") or ""),
                        "password":str(xt.get("password") or ""),
                        "output":str(xt.get("output") or "ts"),
                        "service_type":4097
                    }
                else:
                    try:
                        parsed=urlparse(url)
                        if str(parsed.path or "").lower().endswith(".m3u8"):
                            self.session.open(MessageBox,"This result is a direct HLS stream, not a full M3U playlist. It was not added.",MessageBox.TYPE_INFO,timeout=5)
                            return
                    except Exception:
                        pass
                    host=url.replace("http://","").replace("https://","").split("/")[0]
                    source={"type":"m3u","name":str(row.get("display_name") or host or "M3U Server"),"url":url,"m3u_mode":"url","service_type":4097}
            elif kind=="stalker":
                host=url.replace("http://","").replace("https://","").split("/")[0]
                mac=self._rowMac(row)
                if not mac:
                    # Reuse only a MAC already saved for this same portal.
                    try:
                        target_host=host.lower()
                        for saved in (get_sources() or []):
                            if str(saved.get("type") or "").lower()!="stalker":
                                continue
                            saved_url=str(saved.get("url") or "").strip()
                            saved_host=saved_url.replace("http://","").replace("https://","").split("/")[0].lower()
                            candidate=str(saved.get("mac") or "").strip().upper().replace("-",":")
                            if saved_host==target_host and re.match(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$",candidate):
                                mac=candidate
                                break
                    except Exception:
                        mac=""
                # Portal discovery may not provide a MAC.  Save the portal
                # explicitly as pending so it is visible in server selection,
                # but never pretend the account can play without credentials.
                source={"type":"stalker","name":host or "Stalker Portal","url":url,"mac":mac,"service_type":4097}
                if not mac:
                    source["discovery_pending"]=True
                    source["finder_live_status"]="mac_required"
            else:
                return
        except Exception as exc:
            self.session.open(MessageBox,"Could not prepare this server.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=6)
            return

        # Persist origin so Home -> Switch Server can distinguish manually
        # configured IPTV servers from anything added through Server Finder.
        source["_from_server_finder"] = True
        _post = row.get("post") if isinstance(row.get("post"), dict) else {}
        _origin = str(_post.get("finder_source") or row.get("finder_source") or row.get("fast_service") or "server_finder").strip().lower()
        if row.get("iptvorg_group") or "iptv-org.github.io/iptv/" in url:
            _origin="iptvorg"
        source["finder_source"] = _origin or "server_finder"

        self._pendingAddSource=source
        label={"xtream":"Xtream","stalker":"Stalker","m3u":"M3U"}.get(kind,kind.upper())
        self.session.openWithCallback(
            self._confirmAddServer,
            MessageBox,
            "Add this %s server to Server & Playlists?\n\n%s"%(label,str(source.get("name") or url)),
            type=MessageBox.TYPE_YESNO,
            default=True
        )

    def _confirmAddServer(self,answer=False):
        source=getattr(self,"_pendingAddSource",None)
        self._pendingAddSource=None
        if not answer or not isinstance(source,dict):
            return
        # A user-confirmed Add must persist immediately.  The former live
        # validation blocked saving when the portal was slow/rate-limited,
        # leaving the result absent from the server picker.  The separate
        # BLUE/Test command remains responsible for checking actual playback.
        # Never report an untested Stalker server as verified or playable.
        if str(source.get("type") or "").lower()=="stalker":
            if not str(source.get("mac") or "").strip():
                source["discovery_pending"]=True
                source["finder_live_status"]="mac_required"
            elif source.get("finder_live_status") != "verified":
                source["finder_live_status"]="unverified"
        try:
            srcs=list(get_sources() or [])
            stype=str(source.get("type") or "").lower()
            duplicate=False
            for item in srcs:
                if str(item.get("type") or "").lower()!=stype:
                    continue
                if stype=="xtream":
                    if ((str(item.get("url") or "").rstrip("/")==str(source.get("url") or "").rstrip("/")) and
                        str(item.get("username") or "")==str(source.get("username") or "")):
                        duplicate=True; break
                elif stype=="stalker":
                    if ((str(item.get("url") or "").rstrip("/")==str(source.get("url") or "").rstrip("/")) and
                        str(item.get("mac") or "").upper()==str(source.get("mac") or "").upper()):
                        duplicate=True; break
                elif stype=="m3u":
                    if str(item.get("url") or "").strip()==str(source.get("url") or "").strip():
                        duplicate=True; break
            if duplicate:
                self.session.open(MessageBox,"This server is already saved. Exit Finder and open Switch Server (or Server & Playlists).",MessageBox.TYPE_INFO,timeout=6)
                return

            srcs.append(source)
            set_sources(srcs)
            write_playlists(srcs)
            try:
                from .web_manager import _save_service_types
                _save_service_types(source,4097)
            except Exception:
                pass

            # Verify persistence before reporting success.  A discovered Stalker
            # portal without a MAC is intentionally stored as discovery_pending
            # so it appears in Server & Playlists and can be completed later.
            saved_ok = False
            for item in (get_sources() or []):
                if str(item.get("type") or "").lower() != stype:
                    continue
                if stype == "stalker":
                    same_url = str(item.get("url") or "").rstrip("/") == str(source.get("url") or "").rstrip("/")
                    same_mac = str(item.get("mac") or "").strip().upper() == str(source.get("mac") or "").strip().upper()
                    if same_url and same_mac:
                        saved_ok = True; break
                elif stype == "xtream":
                    if (str(item.get("url") or "").rstrip("/") == str(source.get("url") or "").rstrip("/") and
                        str(item.get("username") or "") == str(source.get("username") or "")):
                        saved_ok = True; break
                elif stype == "m3u" and str(item.get("url") or "").strip() == str(source.get("url") or "").strip():
                    saved_ok = True; break
            if not saved_ok:
                raise RuntimeError("Server was not persisted")

            self["detailAction"].setText("✓  SERVER ADDED")
            # Stalker Finder: show status inline, not a blocking full-screen
            # MessageBox.  The portal was already persisted and verified above.
            if stype == "stalker":
                return
            msg = "%s saved. It is available in Server & Playlists and Home > Switch Server." % {"xtream":"Xtream server","stalker":"Stalker portal","m3u":"M3U playlist"}.get(stype,"Server")
            if stype == "stalker" and source.get("finder_live_status") == "unverified":
                msg += "\n\nLive has not been tested. Use BLUE Test in Switch Server."
            if stype=="m3u":
                msg += "\n\nSaved exact URL (%d chars)." % len(str(source.get("url") or ""))
            if stype == "stalker" and not str(source.get("mac") or "").strip():
                msg += "\n\nPortal saved. Add your authorised MAC in Server & Playlists before playback."
            self.session.open(MessageBox,msg,MessageBox.TYPE_INFO,timeout=5)
        except Exception as exc:
            self.session.open(MessageBox,"Could not add server.\n\n%s"%exc,MessageBox.TYPE_ERROR,timeout=6)



SERVER_HUB_SKIN = r"""<screen name="ServerHub" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_cards_bg_r123.jpg" alphatest="blend" scale="1" zPosition="0"/>

    <widget name="brand" position="72,42" size="390,52" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="title" position="600,38" size="720,46" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
    <widget name="subtitle" position="550,86" size="820,30" font="Regular;19" foregroundColor="#B8C2CB" transparent="1" halign="center" zPosition="5"/>
    <widget name="clock" position="1580,38" size="220,42" font="Regular;33" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="5"/>
    <widget name="date" position="1550,80" size="280,28" font="Regular;17" foregroundColor="#C8D0D8" transparent="1" halign="center" zPosition="5"/>

    <widget name="focus" position="60,185" size="560,320" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_focus_r123.png" alphatest="blend" zPosition="20"/>

    <widget name="bg0" position="60,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon0" position="92,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name0" position="265,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type0" position="265,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state0" position="265,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry0" position="265,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host0" position="265,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions0" position="90,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg1" position="680,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon1" position="712,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name1" position="885,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type1" position="885,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state1" position="885,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry1" position="885,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host1" position="885,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions1" position="710,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg2" position="1300,185" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon2" position="1332,238" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name2" position="1505,215" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type2" position="1505,256" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state2" position="1505,302" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry2" position="1505,344" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host2" position="1505,386" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions2" position="1330,454" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg3" position="60,545" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon3" position="92,598" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name3" position="265,575" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type3" position="265,616" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state3" position="265,662" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry3" position="265,704" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host3" position="265,746" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions3" position="90,814" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg4" position="680,545" size="560,320" alphatest="blend" zPosition="2"/>
    <widget name="icon4" position="712,598" size="150,150" alphatest="blend" zPosition="4"/>
    <widget name="name4" position="885,575" size="320,36" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="type4" position="885,616" size="300,28" font="Regular;18" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>
    <widget name="state4" position="885,662" size="290,28" font="Regular;18" foregroundColor="#67E26E" transparent="1" zPosition="5"/>
    <widget name="expiry4" position="885,704" size="290,28" font="Regular;20" foregroundColor="#FFFFFF" transparent="1" zPosition="5"/>
    <widget name="host4" position="885,746" size="290,48" font="Regular;16" foregroundColor="#BCC8D2" transparent="1" zPosition="5"/>
    <widget name="actions4" position="710,814" size="500,30" font="Regular;16" foregroundColor="#AFC0CD" transparent="1" halign="center" zPosition="5"/>

    <widget name="bg5" position="1300,545" size="560,320" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_add_r123.png" alphatest="blend" zPosition="2"/>
    <widget name="icon5" position="1332,598" size="150,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_add_r123.png" alphatest="blend" zPosition="4"/>
    <widget name="name5" position="1505,590" size="320,38" font="Regular;27" foregroundColor="#F1C84C" transparent="1" zPosition="5"/>
    <widget name="type5" position="1505,648" size="300,78" font="Regular;18" foregroundColor="#D5DEE6" transparent="1" valign="top" zPosition="5"/>
    <widget name="state5" position="1505,744" size="290,30" font="Regular;17" foregroundColor="#43B6F5" transparent="1" zPosition="5"/>

    <widget name="pageText" position="780,896" size="360,32" font="Regular;18" foregroundColor="#D9E1E8" transparent="1" halign="center" zPosition="5"/>
    <widget name="footer" position="85,985" size="1750,42" font="Regular;19" foregroundColor="#E8EDF2" transparent="1" halign="center" valign="center" zPosition="5"/>
    <widget name="keyRed" position="260,975" size="300,48" font="Regular;26" foregroundColor="#F25D5D" transparent="1" halign="center" valign="center" zPosition="8"/>
    <widget name="keyGreen" position="620,975" size="300,48" font="Regular;26" foregroundColor="#63DE83" transparent="1" halign="center" valign="center" zPosition="8"/>
    <widget name="keyYellow" position="980,975" size="300,48" font="Regular;26" foregroundColor="#F4D457" transparent="1" halign="center" valign="center" zPosition="8"/>
    <widget name="keyBlue" position="1340,975" size="320,48" font="Regular;26" foregroundColor="#56B8FF" transparent="1" halign="center" valign="center" zPosition="8"/>
</screen>"""

class ServerHub(Screen):
    skin = SERVER_HUB_SKIN
    POSITIONS=[(60,185),(680,185),(1300,185),(60,545),(680,545),(1300,545)]
    PAGE_SIZE=5

    CARD_BG={
        "xtream":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_xtream_r123.png",
        "stalker":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_stalker_r123.png",
        "m3u":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_m3u_r123.png",
        "generic":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/server_card_generic_r123.png"
    }
    CARD_ICON={
        "xtream":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_xtream_r123.png",
        "stalker":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_stalker_r123.png",
        "m3u":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_m3u_r123.png",
        "generic":"/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/server/icon_generic_r123.png"
    }

    def __init__(self,session):
        Screen.__init__(self,session)
        self.index=0
        self.page=0
        self.sources=[]
        self["brand"]=Label("TiviMate")
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["clock"]=Label("")
        self["date"]=Label("")
        self["focus"]=Pixmap()
        for i in range(5):
            self["bg%d"%i]=Pixmap()
            self["icon%d"%i]=Pixmap()
            self["name%d"%i]=Label("")
            self["type%d"%i]=Label("")
            self["state%d"%i]=Label("")
            self["expiry%d"%i]=Label("")
            self["host%d"%i]=Label("")
            self["actions%d"%i]=Label("")
        self["bg5"]=Pixmap()
        self["icon5"]=Pixmap()
        self["name5"]=Label("ADD NEW SERVER")
        self["type5"]=Label("Xtream Codes\nStalker Portal\nM3U Playlist")
        self["state5"]=Label("OK  •  Select")
        self["pageText"]=Label("")
        self["footer"]=Label("")
        self["keyRed"]=Label("●  Delete")
        self["keyGreen"]=Label("●  Add Server")
        self["keyYellow"]=Label("●  Edit")
        self["keyBlue"]=Label("●  Filter")

        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions","NumberActions"],{
            "ok":self.openCurrent,
            "cancel":self.close,
            "left":self.left,
            "right":self.right,
            "up":self.up,
            "down":self.down,
            "green":self.openAdd,
            "yellow":self.editSelected,
            "red":self.deleteSelected,
            "blue":self.openSelectedServerFilter,
            "0":self.openIPTVFinder
        },-1)

        self._clockTimer=eTimer()
        _connect_timer(self._clockTimer,self.updateClock)
        self.onLayoutFinish.append(self._ready)
        self.onClose.append(self._cleanup)

    def _ready(self):
        self.refresh()
        self.updateClock()
        try:self._clockTimer.start(30000,False)
        except Exception:pass

    def _cleanup(self):
        try:self._clockTimer.stop()
        except Exception:pass

    def updateClock(self):
        try:
            import time
            now=time.localtime()
            self["clock"].setText(time.strftime("%H:%M",now))
            self["date"].setText(time.strftime("%a, %d %b %Y",now))
        except Exception:pass

    @staticmethod
    def _sourceKey(source):
        source=source or {}
        return "%s|%s|%s|%s"%(
            source.get("type",""),
            (source.get("url") or source.get("path") or source.get("host") or source.get("server") or source.get("portal") or "").rstrip("/"),
            source.get("username",""),
            source.get("mac","")
        )

    def _setPixmap(self,widget,path):
        try:
            pix=LoadPixmap(path)
            if pix is not None:
                widget.instance.setPixmap(pix)
        except Exception:pass

    def _hideServerCard(self,i):
        for key in ("bg","icon","name","type","state","expiry","host","actions"):
            try:self["%s%d"%(key,i)].hide()
            except Exception:pass

    def _showServerCard(self,i):
        for key in ("bg","icon","name","type","state","expiry","host","actions"):
            try:self["%s%d"%(key,i)].show()
            except Exception:pass

    def refresh(self):
        self.sources=list(get_sources() or [])
        max_page=max(0,(len(self.sources)-1)//self.PAGE_SIZE)
        if self.page>max_page:self.page=max_page
        self._render()

    @staticmethod
    def _formatExpiry(value):
        raw=str(value or "").strip()
        if not raw or raw in ("0", "—", "None"):
            return "—"
        try:
            import time
            num=float(raw)
            if num > 100000000000:
                num /= 1000.0
            if num > 1000000000:
                return time.strftime("%d %b %Y", time.localtime(num))
        except Exception:
            pass
        return raw[:22]

    def _render(self):
        start=self.page*self.PAGE_SIZE
        visible=self.sources[start:start+self.PAGE_SIZE]

        for i in range(5):
            if i>=len(visible):
                self._hideServerCard(i)
                continue

            self._showServerCard(i)
            src=visible[i]
            stype=str(src.get("type") or "generic").strip().lower()
            if stype not in ("xtream","stalker","m3u"):
                stype="generic"

            self._setPixmap(self["bg%d"%i],self.CARD_BG[stype])
            self._setPixmap(self["icon%d"%i],self.CARD_ICON[stype])

            name=str(src.get("name") or ("Server %d"%(start+i+1)))
            pretty={"xtream":"Xtream Codes","stalker":"Stalker Portal","m3u":"M3U Playlist","generic":"IPTV Source"}[stype]
            expiry=str(src.get("_last_expiry") or src.get("expiry") or src.get("exp_date") or "—")
            host=str(src.get("url") or src.get("host") or src.get("server") or src.get("portal") or "")
            host=host.replace("http://","").replace("https://","").split("/")[0]

            self["name%d"%i].setText(name[:25])
            self["type%d"%i].setText(pretty)
            self["state%d"%i].setText("●  Configured")
            self["expiry%d"%i].setText("Expires: %s"%self._formatExpiry(expiry))
            self["host%d"%i].setText(host[:34] if host else "Local / configured source")
            self["actions%d"%i].setText("YELLOW Edit   •   RED Delete   •   OK Open")

        pages=max(1,(len(self.sources)+self.PAGE_SIZE-1)//self.PAGE_SIZE)
        self["pageText"].setText("Page %d / %d"%(self.page+1,pages))
        self._focus()

    def _focus(self):
        try:
            x,y=self.POSITIONS[self.index]
            self["focus"].instance.move(ePoint(sx(x),sy(y)))
            self["focus"].show()
        except Exception:pass

    def left(self):
        row=self.index//3
        col=(self.index%3-1)%3
        self.index=row*3+col
        self._focus()

    def right(self):
        row=self.index//3
        col=(self.index%3+1)%3
        self.index=row*3+col
        self._focus()

    def up(self):
        if self.index>=3:
            self.index-=3
            self._focus()
            return
        if self.page>0:
            self.page-=1
            self.index=min(self.index+3,5)
            self._render()
            return
        self.index=min(self.index+3,5)
        self._focus()

    def down(self):
        if self.index<3:
            self.index+=3
            self._focus()
            return
        max_page=max(0,(len(self.sources)-1)//self.PAGE_SIZE)
        if self.page<max_page:
            self.page+=1
            self.index=max(0,self.index-3)
            self._render()
            return
        self.index=max(0,self.index-3)
        self._focus()

    def _selectedIndex(self):
        if self.index==5:return -1
        pos=self.page*self.PAGE_SIZE+self.index
        return pos if 0<=pos<len(self.sources) else -1

    def _selected(self):
        pos=self._selectedIndex()
        return self.sources[pos] if pos>=0 else None

    def openCurrent(self):
        if self.index==5:
            self.openAdd()
            return
        if self._selected() is not None:
            self.editSelected()

    def openIPTVFinder(self):
        # The hub stays open underneath Finder: refresh its saved server cards
        # as soon as Finder closes, rather than retaining the old list.
        self.session.openWithCallback(self._finderClosedRefresh, TiviMateE2IPTVFinder)

    def _finderClosedRefresh(self, *args):
        self.refresh()


    def openAdd(self):
        self.session.openWithCallback(self._chooseSourceType,SourceTypePicker)

    def _chooseSourceType(self,source_type=None):
        if source_type=="xtream":
            self.session.openWithCallback(self._saveNew,PlaylistEditor,None)
        elif source_type=="stalker":
            self.session.openWithCallback(self._saveNew,StalkerPortalEditor,None)
        elif source_type=="m3u":
            self.session.openWithCallback(self._saveNew,M3UPlaylistEditor,None)

    def _saveNew(self,source=None):
        if not isinstance(source,dict):return
        srcs=list(get_sources() or [])
        srcs.append(source)
        set_sources(srcs)
        write_playlists(srcs)
        self.refresh()
        try:self.session.open(MessageBox,"Server saved.",MessageBox.TYPE_INFO,timeout=3)
        except Exception:pass

    def editSelected(self):
        source=self._selected()
        if not source:return
        pos=self._selectedIndex()
        callback=lambda edited=None:self._replaceAt(pos,source,edited)
        stype=str(source.get("type") or "").lower()
        if stype=="xtream":
            self.session.openWithCallback(callback,PlaylistEditor,source)
        elif stype=="stalker":
            self.session.openWithCallback(callback,StalkerPortalEditor,source)
        elif stype=="m3u":
            self.session.openWithCallback(callback,M3UPlaylistEditor,source)

    def _replaceAt(self,pos,old,new=None):
        if not isinstance(new,dict):return
        srcs=list(get_sources() or [])
        replaced=False
        if 0<=pos<len(srcs) and (srcs[pos]==old or self._sourceKey(srcs[pos])==self._sourceKey(old)):
            srcs[pos]=new
            replaced=True
        if not replaced:
            old_key=self._sourceKey(old)
            for i,item in enumerate(srcs):
                if item==old or self._sourceKey(item)==old_key:
                    srcs[i]=new
                    replaced=True
                    break
        if not replaced:srcs.append(new)
        set_sources(srcs)
        write_playlists(srcs)
        self.refresh()

    def openSelectedServerFilter(self):
        source=self._selected()
        if not isinstance(source,dict):
            self.session.open(
                MessageBox,
                "Select a server card first.",
                MessageBox.TYPE_INFO,
                timeout=3
            )
            return
        stype=str(source.get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self.session.open(
                MessageBox,
                "Packages/channel filtering is available for Xtream Codes and Stalker Portal.",
                MessageBox.TYPE_INFO,
                timeout=5
            )
            return
        self.session.openWithCallback(
            self._serverFilterClosed,
            ServerCategoryFilter,
            dict(source)
        )

    def _serverFilterClosed(self, changed=None):
        if changed:
            try:
                clear_catalog_memory()
            except Exception:
                pass
        self.refresh()

    def deleteSelected(self):
        source=self._selected()
        if not source:return
        name=str(source.get("name") or "server")
        self.session.openWithCallback(
            lambda answer:self._deleteConfirmed(answer,source),
            MessageBox,
            "Delete %s?"%name,
            MessageBox.TYPE_YESNO
        )

    def _deleteConfirmed(self,answer,source):
        if not answer:return
        key=self._sourceKey(source)
        srcs=[item for item in list(get_sources() or []) if not (item==source or self._sourceKey(item)==key)]
        set_sources(srcs)
        write_playlists(srcs)
        self.index=0
        self.refresh()



CACHE_STORAGE_PICKER_SKIN = r"""<screen name="CacheStoragePicker" position="600,280" size="720,470" flags="wfNoBorder" backgroundColor="#07101A">
    <eLabel position="0,0" size="720,470" backgroundColor="#07101A" zPosition="0"/>
    <eLabel position="0,0" size="720,5" backgroundColor="#31B4FF" zPosition="2"/>
    <widget name="title" position="45,35" size="630,46" font="Regular;31" foregroundColor="#FFFFFF" transparent="1" halign="center" zPosition="4"/>
    <widget name="subtitle" position="45,85" size="630,30" font="Regular;18" foregroundColor="#8FA2B1" transparent="1" halign="center" zPosition="4"/>
    <widget name="focus" position="70,145" size="580,70" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/cache_picker_focus_r223.png" alphatest="blend" zPosition="5"/>
    <widget name="row0" position="92,158" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="row1" position="92,238" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="row2" position="92,318" size="536,44" font="Regular;25" foregroundColor="#FFFFFF" transparent="1" halign="center" valign="center" zPosition="6"/>
    <widget name="hint" position="45,410" size="630,28" font="Regular;17" foregroundColor="#7E909F" transparent="1" halign="center" zPosition="4"/>
</screen>"""

class CacheStoragePicker(Screen):
    skin = CACHE_STORAGE_PICKER_SKIN
    CHOICES = [("auto", "AUTO  •  HDD → USB → INTERNAL"), ("usb", "USB  •  removable storage"), ("internal", "INTERNAL  •  receiver flash")]
    def __init__(self, session, current="auto"):
        Screen.__init__(self, session)
        keys=[x[0] for x in self.CHOICES]
        try:self.index=keys.index(str(current or "auto"))
        except Exception:self.index=0
        self["title"]=Label("")
        self["subtitle"]=Label("")
        self["focus"]=Pixmap()
        for i,(_k,label) in enumerate(self.CHOICES): self["row%d"%i]=Label(label)
        self["hint"]=Label("")
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"], {"up":self.up,"down":self.down,"ok":self.ok,"cancel":self.close}, -1)
        self.onLayoutFinish.append(self._focus)
    def _focus(self):
        try:self["focus"].instance.move(ePoint(sx(70),sy(145 + self.index*80)))
        except Exception:pass
    def up(self): self.index=(self.index-1)%len(self.CHOICES); self._focus()
    def down(self): self.index=(self.index+1)%len(self.CHOICES); self._focus()
    def ok(self): self.close(self.CHOICES[self.index][0])

SETTINGS_DASHBOARD_SKIN = r"""<screen name="SettingsDashboard" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#000000">
    <ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_default.jpg" alphatest="blend" scale="1" zPosition="0"/>
    <widget name="focus0" position="64,340" size="667,212" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_0.png" alphatest="blend" zPosition="8"/>
    <widget name="focus1" position="752,340" size="658,215" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_1.png" alphatest="blend" zPosition="8"/>
    <widget name="focus2" position="64,569" size="667,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_2.png" alphatest="blend" zPosition="8"/>
    <widget name="focus3" position="752,570" size="658,192" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_3.png" alphatest="blend" zPosition="8"/>
    <widget name="focus4" position="65,772" size="1345,155" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_dashboard_focus_4.png" alphatest="blend" zPosition="8"/>
    <widget name="langFocus0" position="208,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus1" position="506,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus2" position="823,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="langFocus3" position="1121,191" size="104,104" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/language_flag_focus_r273.png" alphatest="blend" zPosition="10"/>
    <widget name="statusTitle" position="1500,88" size="330,34" font="Regular;24" foregroundColor="#F1C84C" transparent="1" zPosition="9"/>
    <eLabel position="1500,128" size="72,3" backgroundColor="#E2B84B" zPosition="9"/>
    <widget name="serverName" position="1500,150" size="220,32" font="Regular;22" foregroundColor="#FFFFFF" transparent="1" zPosition="9"/>
    <widget name="serverTypeIcon" position="1500,181" size="40,40" transparent="1" alphatest="blend" scale="1" zPosition="10"/>
    <widget name="serverType" position="1548,190" size="172,26" font="Regular;16" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <widget name="serverState" position="1725,153" size="105,30" font="Regular;16" foregroundColor="#71E65A" transparent="1" halign="right" zPosition="9"/>
    <widget name="expiryText" position="1500,224" size="330,30" font="Regular;17" foregroundColor="#74E95C" transparent="1" zPosition="9"/>
    <eLabel position="1500,266" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="serverCount" position="1500,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <widget name="favoriteCount" position="1612,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <widget name="bouquetCount" position="1725,282" size="105,54" font="Regular;17" foregroundColor="#F1C84C" transparent="1" halign="center" valign="center" zPosition="9"/>
    <eLabel position="1500,348" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="ramText" position="1500,368" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,402" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="ramBar" position="1500,402" size="330,10" borderWidth="0" foregroundColor="#57D55A" backgroundColor="#202932" zPosition="9"/>
    <widget name="cpuText" position="1500,436" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,470" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="cpuBar" position="1500,470" size="330,10" borderWidth="0" foregroundColor="#35A9E7" backgroundColor="#202932" zPosition="9"/>
    <widget name="storageText" position="1500,504" size="330,28" font="Regular;17" foregroundColor="#E7ECF1" transparent="1" zPosition="9"/>
    <eLabel position="1500,538" size="330,10" backgroundColor="#202932" cornerRadius="5" zPosition="8"/>
    <widget name="storageBar" position="1500,538" size="330,10" borderWidth="0" foregroundColor="#F0B63D" backgroundColor="#202932" zPosition="9"/>
    <widget name="cacheFocus" position="1492,586" size="346,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/settings/settings_cache_focus_r223.png" alphatest="blend" zPosition="10"/>
    <widget name="cacheTitle" position="1500,558" size="330,24" font="Regular;16" foregroundColor="#90A0AE" transparent="1" zPosition="9"/>
    <widget name="cacheStorage" position="1503,591" size="324,34" font="Regular;18" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="cacheInfo" position="1500,626" size="330,22" font="Regular;14" foregroundColor="#A9B5BF" transparent="1" zPosition="9"/>
    <widget name="flashLimitText" position="1503,653" size="324,30" font="Regular;16" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="flashReserveText" position="1503,687" size="324,30" font="Regular;16" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="11"/>
    <widget name="cacheClear" position="1503,721" size="324,30" font="Regular;16" foregroundColor="#FF7676" transparent="1" valign="center" zPosition="11"/>
    <widget name="connectionsText" position="1500,765" size="330,24" font="Regular;16" foregroundColor="#4EB8FF" transparent="1" zPosition="9"/>
    <widget name="ipText" position="1500,794" size="330,24" font="Regular;15" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <widget name="uptimeText" position="1500,823" size="330,24" font="Regular;15" foregroundColor="#C8D0D8" transparent="1" zPosition="9"/>
    <eLabel position="1500,854" size="330,2" backgroundColor="#263039" zPosition="8"/>
    <widget name="serverDetail" position="1500,867" size="330,76" font="Regular;16" foregroundColor="#D9E1E8" transparent="1" valign="top" zPosition="9"/>
    <eLabel position="1500,955" size="330,30" text="BLUE  FONT SIZE" font="Regular;20" foregroundColor="#56C8FF" transparent="1" halign="center" zPosition="9"/>
</screen>"""

class SettingsDashboard(Screen):
    skin = SETTINGS_DASHBOARD_SKIN
    ITEMS=[("servers","Server & Playlists"),("skin","Skin & Poster View"),("subtitle","Subtitle"),("backup","Backup & System"),("tmdb","TMDb Settings")]
    def __init__(self,session):
        Screen.__init__(self,session); self.index=0; self.focusZone="cards"
        self.languageIndex={"en":0,"ar":1,"fr":2,"tr":3}.get(get_language(),0)
        for i in range(5): self["focus%d"%i]=Pixmap()
        for i in range(4): self["langFocus%d"%i]=Pixmap()
        self["statusTitle"]=Label("SERVER STATUS")
        for n in ("serverName","serverType","serverState","expiryText","serverCount","favoriteCount","bouquetCount","ramText","cpuText","storageText","connectionsText","ipText","uptimeText","serverDetail","cacheTitle","cacheStorage","cacheInfo","flashLimitText","flashReserveText","cacheClear"): self[n]=Label("")
        self["serverTypeIcon"]=Pixmap()
        self["cacheFocus"]=Pixmap()
        self["ramBar"]=ProgressBar(); self["cpuBar"]=ProgressBar(); self["storageBar"]=ProgressBar()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions","ColorActions"],{"ok":self.openCurrent,"cancel":self.close,"red":self.close,"left":self.left,"right":self.right,"up":self.up,"down":self.down,"green":self.openAddServer,"yellow":self.openServerHub,"blue":self.openFontSettings},-1)
        self._timer=eTimer(); _connect_timer(self._timer,self.refreshStatus); self._lastCpu=None
        self._expiryProbeRunning=False; self._expiryProbeDoneKey=None; self._expiryProbeResult=None
        self._expiryTimer=eTimer(); _connect_timer(self._expiryTimer,self._finishExpiryProbe)
        self.cacheIndex=0; self._cacheStatusAt=0.0; self._cacheSize=0; self._cacheFiles=0
        self._cacheScanRunning=False; self._cacheScanResult=None; self._cacheScanClosed=False
        self._cacheScanTimer=eTimer(); _connect_timer(self._cacheScanTimer,self._finishCacheScan)
        self._summaryAt=0.0; self._summaryRunning=False; self._summaryResult=None
        self._summaryTimer=eTimer(); _connect_timer(self._summaryTimer,self._finishSummary)
        self.onLayoutFinish.append(self._ready); self.onClose.append(self._cleanup)
    def _ready(self):
        self._focus(); self.refreshStatus()
        try:self._timer.start(3000,False)
        except Exception:pass
    def _cleanup(self):
        try:self._timer.stop()
        except Exception:pass
        try:self._expiryTimer.stop()
        except Exception:pass
        self._expiryProbeRunning=False
        self._expiryProbeResult=None
        self._cacheScanClosed=True
        try:self._summaryTimer.stop()
        except Exception:pass
        try:self._cacheScanTimer.stop()
        except Exception:pass
    def _focus(self):
        for i in range(5):
            try:self["focus%d"%i].hide()
            except Exception:pass
            try:self["langFocus%d"%i].hide()
            except Exception:pass
        try:self["cacheFocus"].hide()
        except Exception:pass
        if self.focusZone == "language":
            try:self["langFocus%d"%self.languageIndex].show()
            except Exception:pass
        elif self.focusZone == "cache":
            try:
                y=(586,648,682,716)[max(0,min(3,self.cacheIndex))]
                self["cacheFocus"].instance.move(ePoint(sx(1492),sy(y)))
                self["cacheFocus"].show()
            except Exception:pass
        else:
            try:self["focus%d"%self.index].show()
            except Exception:pass
    def left(self):
        if self.focusZone == "language": self.languageIndex=(self.languageIndex-1)%4
        elif self.focusZone == "cache":
            self.focusZone="cards"; self.index=1 if self.cacheIndex==0 else 3
        else:
            if self.index == 4: return
            self.index=self.index-1 if self.index%2 else self.index+1
        self._focus()
    def right(self):
        if self.focusZone == "language": self.languageIndex=(self.languageIndex+1)%4
        elif self.focusZone == "cache": return
        elif self.index in (1,3):
            self.focusZone="cache"; self.cacheIndex=0 if self.index==1 else (3 if not is_internal_cache_active() else 1)
        elif self.index == 4: return
        else: self.index=self.index+1
        self._focus()
    def up(self):
        if self.focusZone == "language": return
        if self.focusZone == "cache":
            internal=is_internal_cache_active()
            if internal: self.cacheIndex=max(0,self.cacheIndex-1)
            else: self.cacheIndex=0
            self._focus(); return
        if self.index < 2: self.focusZone="language"
        elif self.index == 4: self.index=2
        else: self.index-=2
        self._focus()
    def down(self):
        if self.focusZone == "language":
            self.focusZone="cards"; self.index=0
        elif self.focusZone == "cache":
            internal=is_internal_cache_active()
            if internal: self.cacheIndex=min(3,self.cacheIndex+1)
            else: self.cacheIndex=3
        elif self.index < 2: self.index+=2
        elif self.index in (2,3): self.index=4
        self._focus()
    @staticmethod
    def _read(path,default=""):
        try:
            with open(path,"r") as h:return h.read().strip()
        except Exception:return default
    def _memory(self):
        vals={}
        try:
            with open("/proc/meminfo","r") as h:
                for line in h:
                    if ":" in line:
                        k,v=line.split(":",1); vals[k]=int(v.strip().split()[0])
        except Exception:pass
        total=int(vals.get("MemTotal",0)); avail=int(vals.get("MemAvailable",vals.get("MemFree",0))); used=max(0,total-avail); pct=int(round(100.0*used/total)) if total else 0
        return total,avail,pct
    def _cpu_usage(self):
        try:
            vals=[int(x) for x in self._read("/proc/stat","").splitlines()[0].split()[1:]]; idle=vals[3]+(vals[4] if len(vals)>4 else 0); total=sum(vals); now=(idle,total)
            if self._lastCpu is None:self._lastCpu=now; return 0
            idle_d=idle-self._lastCpu[0]; total_d=total-self._lastCpu[1]; self._lastCpu=now
            return max(0,min(100,int(round(100.0*(1.0-idle_d/float(total_d)))))) if total_d>0 else 0
        except Exception:return 0
    def _storage(self):
        try:
            target="/media/hdd" if os.path.ismount("/media/hdd") else "/"; st=os.statvfs(target); total=float(st.f_blocks*st.f_frsize); free=float(st.f_bavail*st.f_frsize); used=max(0.0,total-free); pct=int(round(100.0*used/total)) if total else 0; return total,free,pct
        except Exception:return 0.0,0.0,0
    def _ip(self):
        try:
            import socket; sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            try:sock.connect(("8.8.8.8",80)); return sock.getsockname()[0]
            finally:sock.close()
        except Exception:return "n/a"
    def _uptime(self):
        try:
            sec=int(float(self._read("/proc/uptime","0").split()[0])); d,r=divmod(sec,86400); h,r=divmod(r,3600); m=r//60; return ("%dd %dh %dm"%(d,h,m)) if d else ("%dh %dm"%(h,m))
        except Exception:return "n/a"
    def _connections(self):
        c=0
        for p in ("/proc/net/tcp","/proc/net/tcp6"):
            try:
                for line in self._read(p,"").splitlines()[1:]:
                    cols=line.split(); c += 1 if len(cols)>3 and cols[3]=="01" else 0
            except Exception:pass
        return c
    def _cacheDisplay(self):
        cfg=get_cache_settings() or {}; loc=str(cfg.get("location") or "auto").lower()
        labels={"hdd":"HDD","usb":"USB","internal":"INTERNAL","auto":"AUTO","mmc":"MMC","tmp":"TMP"}
        self["cacheTitle"].setText("CACHE STORAGE")
        self["cacheStorage"].setText("%s   •   OK to change" % labels.get(loc,loc.upper()))
        internal = is_internal_cache_active()
        if internal:
            lim=int(cfg.get("flash_image_limit",20) or 0); reserve=int(cfg.get("flash_min_free_mb",30) or 0)
            self["flashLimitText"].setText("FLASH IMAGES   •   %s   •   OK" % (str(lim) if lim else "Unlimited"))
            self["flashReserveText"].setText("FLASH RESERVE  •   %s   •   OK" % ((str(reserve)+" MB") if reserve else "Disabled"))
        else:
            self["flashLimitText"].setText(""); self["flashReserveText"].setText("")
        self["cacheClear"].setText("CLEAR CACHE   •   OK")
        try:
            root=get_cache_root(); st=os.statvfs(root); free=float(st.f_bavail*st.f_frsize)/(1024.0**3)
        except Exception:
            root=""; free=0.0
        now=time.time()
        if (not self._cacheStatusAt or now-self._cacheStatusAt>60) and not self._cacheScanRunning:
            self._cacheScanRunning=True
            self._cacheScanResult=None
            def scan_worker():
                try:
                    _r,size,files=cache_status()
                    self._cacheScanResult=(size,files)
                except Exception:
                    self._cacheScanResult=(-1,-1)
            worker=threading.Thread(target=scan_worker,name="TiviMateSettingsCacheScan")
            worker.daemon=True
            worker.start()
            try:self._cacheScanTimer.start(250,False)
            except Exception:pass
        info=("Cache %.1f MB" % (float(self._cacheSize)/1048576.0)) if self._cacheStatusAt else "Cache calculating..."
        self["cacheInfo"].setText("%s   •   Free %.1f GB" % (info,free))
    def _finishCacheScan(self):
        if self._cacheScanClosed:return
        result=self._cacheScanResult
        if result is None:
            try:self._cacheScanTimer.start(350,False)
            except Exception:pass
            return
        self._cacheScanResult=None
        self._cacheScanRunning=False
        if result[0]>=0:
            self._cacheSize,self._cacheFiles=result
            self._cacheStatusAt=time.time()
            try:self._cacheDisplay()
            except Exception:pass
        else:
            self._cacheStatusAt=time.time()

    def _openCacheStorage(self):
        cfg=get_cache_settings() or {}; current=str(cfg.get("location") or "auto").lower()
        choices=[
            ("AUTO  •  HDD → USB → MMC → INTERNAL", "auto"),
            ("HDD  •  /media/hdd", "hdd"),
            ("USB  •  /media/usb", "usb"),
            ("MMC  •  /media/mmc", "mmc"),
            ("INTERNAL  •  receiver flash", "internal"),
            ("TMP  •  temporary /tmp", "tmp"),
        ]
        self.session.openWithCallback(self._cacheStorageSelected, ChoiceBox, title="CACHE STORAGE  •  Current: %s" % current.upper(), list=choices)
    def _cacheStorageSelected(self, choice=None):
        if not choice:return
        value=choice[1] if isinstance(choice,(tuple,list)) and len(choice)>1 else choice
        if value not in ("auto","hdd","usb","mmc","internal","tmp"): return
        cfg=get_cache_settings() or {}
        if save_cache_settings(value,0,int(cfg.get("retention_days",0) or 0),int(cfg.get("flash_image_limit",20) or 20),int(cfg.get("flash_min_free_mb",30) or 0)):
            self._cacheStatusAt=0.0; self._cacheDisplay()
            self.session.open(MessageBox, "Cache storage saved. New cached files will use %s." % value.upper(), MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to save cache storage.", MessageBox.TYPE_ERROR)
    def _cycleFlashLimit(self):
        cfg=get_cache_settings() or {}
        if not is_internal_cache_active(): return
        loc=str(cfg.get("location") or "auto").lower()
        vals=[20,40,60,100]; cur=int(cfg.get("flash_image_limit",20) or 20)
        try: new=vals[(vals.index(cur)+1)%len(vals)]
        except Exception: new=20
        if save_cache_settings(loc,0,int(cfg.get("retention_days",0) or 0),new,int(cfg.get("flash_min_free_mb",30) or 0)):
            self._cacheDisplay()

    def _cycleFlashReserve(self):
        cfg=get_cache_settings() or {}
        if not is_internal_cache_active(): return
        loc=str(cfg.get("location") or "auto").lower()
        vals=[0,20,30,50]; cur=int(cfg.get("flash_min_free_mb",30) or 0)
        try: new=vals[(vals.index(cur)+1)%len(vals)]
        except Exception: new=30
        if save_cache_settings(loc,0,int(cfg.get("retention_days",0) or 0),int(cfg.get("flash_image_limit",20) or 20),new):
            self._cacheDisplay()

    def _askClearCache(self):
        self.session.openWithCallback(self._clearCacheConfirmed, MessageBox, "Are you sure you want to clear the cache?", type=MessageBox.TYPE_YESNO, default=False)
    def _clearCacheConfirmed(self, answer=False):
        if not answer:return
        ok=clear_cache()
        if ok:
            try:clear_catalog_memory()
            except Exception:pass
            self._cacheStatusAt=0.0; self._cacheSize=0; self._cacheFiles=0; self._cacheDisplay()
            self.session.open(MessageBox, "Cache cleared successfully.", MessageBox.TYPE_INFO, timeout=4)
        else:
            self.session.open(MessageBox, "Unable to clear cache.", MessageBox.TYPE_ERROR)

    @staticmethod
    def _formatDashboardExpiry(value):
        raw = str(value or "").strip()
        low = raw.lower()
        if not raw or low in ("0", "none", "null", "—"):
            return "—"
        if low in ("unlimited", "never", "lifetime"):
            return "Unlimited"
        try:
            num = float(raw)
            if num > 100000000000:
                num /= 1000.0
            if num > 1000000000:
                return time.strftime("%d %b %Y", time.localtime(num))
        except Exception:
            pass
        for fmt, size in (("%Y-%m-%d %H:%M:%S",19),("%Y-%m-%d",10),("%d/%m/%Y",10),("%d-%m-%Y",10)):
            try:
                dt = datetime.strptime(raw[:size], fmt)
                return dt.strftime("%d %b %Y")
            except Exception:
                pass
        return raw[:22]

    def _setDashboardType(self, active):
        stype = str((active or {}).get("type") or "").strip().lower()
        labels = {"xtream":"Xtream", "stalker":"Stalker", "m3u":"M3U", "fg":"M3U"}
        icons = {
            "xtream": os.path.join(PLUGIN_PATH,"skins","icon_xtream_r123.png"),
            "stalker": os.path.join(PLUGIN_PATH,"skins","icon_stalker_r123.png"),
            "m3u": os.path.join(PLUGIN_PATH,"skins","icon_m3u_r123.png"),
            "fg": os.path.join(PLUGIN_PATH,"skins","icon_m3u_r123.png"),
        }
        self["serverType"].setText(labels.get(stype, "IPTV" if stype else "NOT CONFIGURED"))
        try:
            path = icons.get(stype)
            if path and os.path.exists(path):
                self["serverTypeIcon"].instance.setPixmapFromFile(path)
                self["serverTypeIcon"].show()
            else:
                self["serverTypeIcon"].hide()
        except Exception:
            try:self["serverTypeIcon"].hide()
            except Exception:pass

    @staticmethod
    def _dashboardSourceKey(source):
        source=source or {}
        return "|".join((str(source.get("type") or ""), str(source.get("url") or source.get("portal") or ""), str(source.get("username") or source.get("mac") or "")))

    def _startExpiryProbe(self, active):
        if not active or self._expiryProbeRunning:
            return
        key=self._dashboardSourceKey(active)
        if key == self._expiryProbeDoneKey:
            return
        stype=str(active.get("type") or "").lower()
        if stype not in ("xtream","stalker"):
            self._expiryProbeDoneKey=key
            return
        self._expiryProbeRunning=True
        source=dict(active)
        def worker():
            expiry=""; ok=False
            try:
                if stype == "xtream":
                    reply=XtreamClient(source).test() or {}
                    if isinstance(reply,dict):
                        user=reply.get("user_info") if isinstance(reply.get("user_info"),dict) else {}
                        expiry=user.get("exp_date") or reply.get("exp_date") or ""
                        ok=bool(user or reply.get("server_info"))
                else:
                    reply=StalkerClient(source).test() or {}
                    if isinstance(reply,dict):
                        expiry=reply.get("expiry") or ""
                        ok=bool(reply.get("ok") or reply.get("profile") or reply.get("handshake"))
            except Exception:
                pass
            self._expiryProbeResult=(key,str(expiry or ""),ok)
        t=threading.Thread(target=worker,name="TiviMateDashboardExpiry")
        t.daemon=True; t.start()
        try:self._expiryTimer.start(150,False)
        except Exception:pass

    def _finishExpiryProbe(self):
        result=self._expiryProbeResult
        if result is None:
            try:self._expiryTimer.start(150,False)
            except Exception:pass
            return
        self._expiryProbeResult=None; self._expiryProbeRunning=False
        key,expiry,ok=result; self._expiryProbeDoneKey=key
        if expiry:
            try:
                sources=list(get_sources() or []); changed=False
                for src in sources:
                    if self._dashboardSourceKey(src)==key:
                        src["_last_expiry"]=expiry; changed=True; break
                if changed:set_sources(sources)
            except Exception:pass
            try:self["expiryText"].setText("Expires: %s" % self._formatDashboardExpiry(expiry))
            except Exception:pass

    def refreshStatus(self):
        # Source importing and favourites counting may touch HDD/network mounts.
        # Keep them off the Enigma2 UI thread and refresh no more than once a minute.
        now=time.time()
        if not self._summaryRunning and (not self._summaryAt or now-self._summaryAt>=60):
            self._summaryRunning=True
            def summary_worker():
                try:
                    sources=list(get_sources() or [])
                except Exception:
                    sources=[]
                try:fav=int(favourites_count() or 0)
                except Exception:fav=0
                try:bq=sum(1 for x in os.listdir("/etc/enigma2") if x.startswith("userbouquet.") and x.endswith(".tv"))
                except Exception:bq=0
                self._summaryResult=(sources,fav,bq)
            t=threading.Thread(target=summary_worker,name="TiviMateSettingsSummary")
            t.daemon=True; t.start()
            try:self._summaryTimer.start(250,False)
            except Exception:pass
        total,free,ram=self._memory(); self["ramText"].setText("RAM Usage  %d%%   •   Free %d MB"%(ram,free//1024 if free else 0)); self["ramBar"].setValue(ram)
        cpu=self._cpu_usage(); self["cpuText"].setText("CPU Usage  %d%%"%cpu); self["cpuBar"].setValue(cpu)
        tb,fb,sp=self._storage(); self["storageText"].setText("Storage  %d%%   •   Free %.1f GB"%(sp,fb/(1024**3) if fb else 0)); self["storageBar"].setValue(sp)
        self._cacheDisplay()
        self["connectionsText"].setText("Connections  %d Active"%self._connections())
        self["uptimeText"].setText("Uptime  %s"%self._uptime())

    def _finishSummary(self):
        if self._cacheScanClosed:return
        result=self._summaryResult
        if result is None:
            try:self._summaryTimer.start(350,False)
            except Exception:pass
            return
        self._summaryResult=None; self._summaryRunning=False; self._summaryAt=time.time()
        sources,fav,bq=result
        active=sources[0] if sources else {}
        if active:
            self["serverName"].setText(str(active.get("name") or "Server")[:22])
            self._setDashboardType(active)
            self["serverState"].setText("CONNECTED")
            expiry=str(active.get("_last_expiry") or active.get("expiry") or active.get("exp_date") or "").strip()
            self["expiryText"].setText("Expires: %s" % self._formatDashboardExpiry(expiry))
            self._startExpiryProbe(active)
        else:
            self["serverName"].setText("No server")
            self._setDashboardType({})
            self["serverState"].setText("")
            self["expiryText"].setText("Expires: —")
        self["serverCount"].setText("%d\nSERVERS"%len(sources))
        self["favoriteCount"].setText("%d\nFAVORITES"%fav)
        self["bouquetCount"].setText("%d\nBOUQUETS"%bq)
        try:self["ipText"].setText("IP Address  %s"%self._ip())
        except Exception:pass
        if active:
            host=str(active.get("url") or active.get("host") or active.get("server") or active.get("portal") or ""); details=[]
            local_path=str(active.get("path") or "")
            if host: details.append("Host: %s"%host.replace("http://","").replace("https://","").split("/")[0][:34])
            elif local_path: details.append("Source: Imported M3U")
            details.append("Type: %s"%str(active.get("type") or "").upper())
            self["serverDetail"].setText("\n".join(details))
        else:self["serverDetail"].setText("Press GREEN to add a server.")
    def openAddServer(self): self.session.openWithCallback(self._sourceType,SourceTypePicker)
    def _sourceType(self,t=None):
        if t=="xtream":self.session.open(PlaylistEditor,None)
        elif t=="stalker":self.session.open(StalkerPortalEditor,None)
        elif t=="m3u":self.session.open(M3UPlaylistEditor,None)
    def openServerHub(self): self.session.open(ServerHub)
    def openFontSettings(self):
        self.session.open(FontAppearanceSettings)

    def openCurrent(self):
        if self.focusZone == "cache":
            if self.cacheIndex==0:self._openCacheStorage()
            elif self.cacheIndex==1:self._cycleFlashLimit()
            elif self.cacheIndex==2:self._cycleFlashReserve()
            else:self._askClearCache()
            return
        if self.focusZone == "language":
            code=("en","ar","fr","tr")[self.languageIndex]
            if save_language(code):
                try:self.session.open(MessageBox, "Language saved. Reopen the app to apply it.", MessageBox.TYPE_INFO, timeout=3)
                except Exception:pass
            return
        a=self.ITEMS[self.index][0]
        if a=="servers": self.session.open(ServerHub); return
        if a=="skin": self.session.open(HomeAppearanceSettings); return
        if a=="subtitle": self.session.open(SubtitleDashboard); return
        if a=="backup": self.session.open(BackupRestoreScreen); return
        if a=="tmdb": self.session.open(TMDbSettings); return
