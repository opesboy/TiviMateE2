import re
# -*- coding: utf-8 -*-
import os
from .storage import data_path
import traceback


def _preferred_language():
    try:
        from .subdl_client import load_settings
        code = str((load_settings() or {}).get("language") or "ar").strip().lower()
    except Exception:
        code = "ar"
    aliases = {"ara":"ar","arabic":"ar","eng":"en","english":"en","fra":"fr","fre":"fr","tur":"tr"}
    return aliases.get(code, code[:2] if len(code) > 2 else code) or "ar"


def _set_language(settings, language_code=None):
    # Subtitle Settings are authoritative. Live and VOD/Series normally arrive
    # here without an explicit language, so preserve the user's saved
    # lang1/lang2/lang3 choices instead of overwriting them.
    explicit = str(language_code or "").strip().lower()
    if explicit:
        code = explicit
        for name in ("lang1","lang2","lang3"):
            try:
                entry=getattr(settings,name); entry.value=code
                try: entry.save()
                except Exception: pass
            except Exception: pass
    else:
        # The plugin Subtitle Language setting is authoritative for every new
        # automatic/manual title search. Do not inherit an old SubsSupport
        # lang1 value (commonly English) from a previous session.
        code = _preferred_language()
        for name in ("lang1","lang2","lang3"):
            try:
                entry=getattr(settings,name); entry.value=code
                try: entry.save()
                except Exception: pass
            except Exception: pass

    for name,value in (("manualSearch",False),("openParamsDialogOnSearch",False),("useFilePath",False)):
        try:
            entry=getattr(settings,name); entry.value=value
            try: entry.save()
            except Exception: pass
        except Exception: pass
    return code


def _controller(owner):
    obj=getattr(owner,"_tivimate_subtitles",None)
    if obj is not None: return obj
    from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSupport
    obj=TiviMateSubtitleSupport(getattr(owner,"session"),defaultPath=data_path("subtitles"),forceDefaultPath=False,autoLoad=False,showGUIInfoMessages=True,embeddedSupport=False,preferEmbedded=False,searchSupport=True)
    owner._tivimate_subtitles=obj
    owner._tivimate_subtitle_controller=obj
    return obj


def _cached_poster(owner):
    # Keep the hand-off file scoped to the Enigma2 session.  A single global
    # pointer allowed a late callback from another player/session to replace
    # the current poster while the picker was opening.
    session = getattr(owner, "session", None)
    pointer="/tmp/tivimate_subtitles_poster_%s.path" % id(session); path=""
    item=getattr(owner,"item",{}) or {}

    # r478: Subtitle Search must never inherit the VOD player's circular HUD
    # derivative. Reuse only the original rectangular artwork already on disk.
    # No network request, timer, hook, or playback-path change is introduced.
    def _rect_source(candidate):
        try:
            p=str(candidate or "").strip()
            if not p:
                return ""
            if os.path.exists(p) and ".tivimate-circle-" not in os.path.basename(p):
                return p
            # Player circle files are generated as:
            #   <original-root>.tivimate-circle-rXXX.png
            # Recover the already-cached original poster beside that derivative.
            marker=".tivimate-circle-"
            base=os.path.basename(p)
            if marker in base:
                prefix=p[:p.rfind(marker)]
                for ext in (".jpg", ".jpeg", ".png", ".webp"):
                    original=prefix+ext
                    if os.path.exists(original):
                        return original
        except Exception:
            pass
        return ""

    # Prefer the raw player cache fields; these are rectangular server/TMDb art.
    for key in ("_player_cover_cache", "_player_cover_cache_fallback"):
        try:
            path=_rect_source(item.get(key))
            if path:
                break
        except Exception:
            pass

    # Resolve the original URL through the existing artwork cache only.
    if not path:
        try:
            from .artwork_queue import cached_artwork
            for key in ("_player_cover","stream_icon","cover_big","cover","movie_image","poster_url","poster_path"):
                url=item.get(key)
                if not url:
                    continue
                p=cached_artwork(url,"posters")
                path=_rect_source(p)
                if path:
                    break
        except Exception:
            pass

    # Last local-only fallback: recover the original beside any player circle.
    if not path:
        try:
            for attr in ("_cover_cached_path", "_infobarPosterPath"):
                path=_rect_source(getattr(owner,attr,""))
                if path:
                    break
        except Exception:
            pass

    try:
        if path:
            with open(pointer,"w") as f:
                f.write(path)
        elif os.path.exists(pointer):
            os.remove(pointer)
    except Exception:
        pass


def _content_kind(owner):
    item=getattr(owner,"item",{}) or {}
    text=" ".join(str(item.get(k,"") or "").lower() for k in ("content_type","type","stream_type","media_type"))
    if any(x in text for x in ("series","episode","tvshow","tv show")): return "episode"
    for k in ("season","season_number","episode","episode_num","episode_number","series_name","series_id"):
        if item.get(k) not in (None,"",0,"0"): return "episode"
    return "movie"


def _search_title(owner,fallback):
    if _content_kind(owner)!="episode": return fallback
    item=getattr(owner,"item",{}) or {}
    series=next((str(item.get(k)) for k in ("series_name","show_name","tvshow","name","title") if item.get(k)),fallback)
    season=item.get("season_number",item.get("season","")); episode=item.get("episode_number",item.get("episode_num",item.get("episode","")))
    try:
        if str(season).isdigit() and str(episode).isdigit(): return "%s S%02dE%02d" % (series,int(season),int(episode))
    except Exception: pass
    return series



def _subtitle_latin_title(value):
    """Accept a real Latin-script metadata title, never transliterate guesses."""
    try:
        from .subtitle_title import clean_subtitle_title
        text = clean_subtitle_title(value)
    except Exception:
        text = str(value or "").strip()
    # A year or quality tag alone must not be treated as an English title.
    return text if re.search(r"[A-Za-z]{2}", text) else ""


def _existing_english_subtitle_title(owner):
    """Read already-known English names without changing the TMDb UI locale."""
    item = getattr(owner, "item", {}) or {}
    if (getattr(owner, "_subtitle_english_item_key", None) == id(item)):
        name = _subtitle_latin_title(getattr(owner, "_subtitle_english_title", ""))
        if name:
            return name
    # These fields are metadata titles, not the active localized display title.
    if _content_kind(owner) == "episode":
        # Episode original_title can mean the *episode* title. Prefer the
        # English show name for SxxExx subtitle searches.
        keys = ("series_name_en", "english_series_name", "series_original_name",
                "_tmdb_en_title", "_tmdb_english_title", "_subtitle_english_title",
                "english_title", "title_en", "original_name", "series_name")
    else:
        keys = ("_tmdb_en_title", "_tmdb_english_title", "_subtitle_english_title",
                "english_title", "title_en", "original_title", "original_name",
                "movie_name", "title")
    for key in keys:
        name = _subtitle_latin_title(item.get(key))
        if name:
            return name
    return ""


def _english_subtitle_tmdb_lookup(item, is_episode):
    """Background-only English TMDb lookup; reuse the established disk cache."""
    try:
        raw_id = (item.get("series_tmdb_id") or item.get("_series_tmdb_id") or
                  item.get("tmdb_id") or item.get("_tmdb_id") or item.get("tmdb"))
        tmdb_id = int(str(raw_id or "0"))
        if tmdb_id <= 0:
            return ""
        from .tmdb_client import TMDbClient
        tmdb = TMDbClient(language="en-US")
        if not tmdb.configured():
            return ""
        data = tmdb.details_bundle(tmdb_id, "series" if is_episode else "vod") or {}
        # en-US 'title'/'name' is the translated title where available.
        for key in (("name", "original_name") if is_episode else ("title", "original_title")):
            title = _subtitle_latin_title(data.get(key))
            if title:
                return title
    except Exception:
        pass
    return ""


def _tivimate_best_title(owner, fallback=""):
    """Return the real current TiviMate movie/series title."""
    item = getattr(owner, "item", {}) or {}
    # Subtitle search has its own English name. Do NOT alter the player label.
    english = _existing_english_subtitle_title(owner)
    if english:
        return english
    candidates = []

    # Player/runtime attributes first: these are often cleaner than provider labels.
    for attr in (
        "movie_title", "series_title", "content_title", "current_title",
        "service_title", "title", "name"
    ):
        try:
            value = getattr(owner, attr, None)
            if value:
                candidates.append(value)
        except Exception:
            pass

    # Xtream/Stalker/TiviMate item fields.
    for key in (
        "_tmdb_title", "series_name", "series_title", "show_name",
        "movie_name", "vod_name", "stream_name", "channel_name",
        "original_title", "name", "title"
    ):
        try:
            value = item.get(key)
            if value:
                candidates.append(value)
        except Exception:
            pass

    if fallback:
        candidates.append(fallback)

    for value in candidates:
        try:
            text = str(value).strip()
        except Exception:
            continue
        if not text:
            continue

        # Remove only obvious provider/quality decorations; preserve the real title.
        text = re.sub(r"^\s*(?:MOVIES?|VOD|TV\s*SHOWS?|SERIES)\s*[:\-|]\s*", "", text, flags=re.I)
        text = re.sub(r"\s*[\[\(\{](?:4K|UHD|FHD|FULL\s*HD|1080P|720P|2160P|HEVC|H\.?265|H\.?264|AR|EN|MULTI)[^\]\)\}]*[\]\)\}]\s*", " ", text, flags=re.I)
        text = re.sub(r"\s+(?:4K|UHD|FHD|FULL\s*HD|1080P|720P|2160P|HEVC)\s*$", "", text, flags=re.I)
        text = re.sub(r"\s+", " ", text).strip(" -|:_")
        if text:
            return text
    return ""

def _tivimate_player_movie_title_year(owner, fallback_title=""):
    """Use only data already present in the current TiviMate player.

    Returns (clean_title, year).  No TMDb/API/network lookup is performed.
    """
    item = getattr(owner, "item", {}) or {}
    title = _tivimate_best_title(owner, fallback_title) or str(fallback_title or "").strip()

    year = 0
    # Prefer values already attached to the playing item/player.
    for key in ("year", "release_year", "_tmdb_year"):
        try:
            value = item.get(key)
        except Exception:
            value = None
        text = str(value or "").strip()
        m = re.search(r"\b((?:19|20)\d{2})\b", text)
        if m:
            year = int(m.group(1))
            break

    if not year:
        for attr in ("year", "release_year", "movie_year", "content_year"):
            try:
                value = getattr(owner, attr, None)
            except Exception:
                value = None
            text = str(value or "").strip()
            m = re.search(r"\b((?:19|20)\d{2})\b", text)
            if m:
                year = int(m.group(1))
                break

    # Last fallback: the year already visible in the player title, e.g.
    # "The Odyssey (2026)".  Strip only a trailing year from the search title.
    title_text = str(title or "").strip()
    m = re.search(r"(?:[\s\-_.]*[\(\[]?((?:19|20)\d{2})[\)\]]?)\s*$", title_text)
    if m:
        if not year:
            year = int(m.group(1))
        title_text = title_text[:m.start()].strip(" -|:_.")

    return title_text or str(title or "").strip(), year


def _tivimate_search_title(owner, fallback_title=""):
    item = getattr(owner, "item", {}) or {}
    base_title = _tivimate_best_title(owner, fallback_title)
    if not base_title:
        return ""

    kind = _content_kind(owner)
    if kind == "episode":
        # Prefer explicit series/show title over an episode-only title.
        series = ""
        english_series = _existing_english_subtitle_title(owner)
        if english_series:
            series = english_series
        for key in (() if series else ("series_name", "series_title", "show_name", "_tmdb_title")):
            try:
                val = item.get(key)
            except Exception:
                val = None
            if val:
                series = str(val).strip()
                break
        if not series:
            series = base_title

        season = item.get("season_number", item.get("season", ""))
        episode = item.get("episode_number", item.get("episode_num", item.get("episode", "")))

        try:
            if str(season).strip().isdigit() and str(episode).strip().isdigit():
                # Avoid duplicating SxxExx when it is already present.
                if not re.search(r"\bS\d{1,2}E\d{1,3}\b", series, re.I):
                    return "%s S%02dE%02d" % (series, int(season), int(episode))
        except Exception:
            pass
        return series

    return base_title

def _tivimate_content_key(owner):
    """Stable key for the currently playing movie/episode within this player.

    Used only to decide whether BLUE should auto-search on first open.
    A new movie/episode gets one auto search; later opens are manual.
    """
    item = getattr(owner, "item", {}) or {}
    parts = []
    for attr in ("stream_url", "url", "play_url", "service_url", "current_url"):
        try:
            value = getattr(owner, attr, None)
        except Exception:
            value = None
        if value:
            parts.append(str(value))
            break
    for key in ("stream_id", "episode_id", "movie_id", "series_id", "id"):
        try:
            value = item.get(key)
        except Exception:
            value = None
        if value not in (None, ""):
            parts.append(str(value))
    title = _tivimate_search_title(owner, _tivimate_best_title(owner, ""))
    if title:
        parts.append(str(title))
    return "|".join(parts) or str(id(owner))


def _bridge_debug_log(stage, exc=None):
    # Persistent diagnostic for RED / More Info subtitle selection.
    try:
        from datetime import datetime
        path = data_path("subtitle_selection_debug.log")
        with open(path, "a") as fp:
            fp.write("%s %s %s\n" % (datetime.now().isoformat(), str(stage), str(exc or "")))
    except Exception:
        pass


def _subtitle_file_diagnostic(path):
    try:
        if not path or not os.path.isfile(path):
            return "missing subtitle file: %r" % (path,)
        with open(path, "rb") as f:
            sample = f.read(65536)
        decoded = sample.decode("utf-8-sig", "replace")
        arabic = sum(1 for c in decoded if "\u0600" <= c <= "\u06ff")
        latin = sum(1 for c in decoded if ("a" <= c.lower() <= "z"))
        return "subtitle path=%r bytes=%d arabic_chars=%d latin_chars=%d" % (path, os.path.getsize(path), arabic, latin)
    except Exception as exc:
        return "subtitle diagnostic error=%r" % (exc,)


def open_tivimate_subtitle_search(owner, title=None, language_code=None, context=None,
                                  _english_lookup_done=False):
    """Search English metadata title; preserve the selected subtitle language."""
    session = getattr(owner, "session", None)
    # Expose only the failed initialization phase to the UI. Detailed exception
    # information remains in the existing local diagnostic log.
    owner._tivimate_subtitle_search_error = ""
    if session is None:
        owner._tivimate_subtitle_search_error = "session"
        return False

    live_context = dict(context or {}) if isinstance(context, dict) else {}
    is_live = str(live_context.get("media_type") or "").lower() == "live"

    if not is_live and not _english_lookup_done:
        item = getattr(owner, "item", {}) or {}
        english = _existing_english_subtitle_title(owner)
        if not english:
            # Do not make TMDb network calls from the Enigma2 GUI thread.
            # Only resolve when the current player title is not English and
            # a real TMDb ID is already known. Never mistake provider IDs for TMDb.
            current = _tivimate_best_title(owner, title)
            raw_id = (item.get("series_tmdb_id") or item.get("_series_tmdb_id") or
                      item.get("tmdb_id") or item.get("_tmdb_id") or item.get("tmdb"))
            try:
                valid_id = int(str(raw_id or "0")) > 0
            except Exception:
                valid_id = False
            if valid_id and not _subtitle_latin_title(current):
                pending_key = id(item)
                if getattr(owner, "_subtitle_english_pending_key", None) == pending_key:
                    return True
                try:
                    from twisted.internet import threads
                    owner._subtitle_english_pending_key = pending_key
                    item_snapshot = dict(item)
                    is_episode = _content_kind(owner) == "episode"
                    deferred = threads.deferToThread(_english_subtitle_tmdb_lookup,
                                                     item_snapshot, is_episode)

                    def done(result):
                        if getattr(owner, "_subtitle_english_pending_key", None) == pending_key:
                            owner._subtitle_english_pending_key = None
                        if getattr(owner, "_closing", False) or id(getattr(owner, "item", None)) != pending_key:
                            return result
                        name = _subtitle_latin_title(result) if isinstance(result, str) else ""
                        if name:
                            owner._subtitle_english_item_key = pending_key
                            owner._subtitle_english_title = name
                        open_tivimate_subtitle_search(
                            owner, title, language_code, context, _english_lookup_done=True)
                        return result

                    deferred.addBoth(done)
                    return True
                except Exception:
                    owner._subtitle_english_pending_key = None
                    # If TMDb is unavailable, continue with the existing title.
                    pass

    if is_live:
        # Live has no VOD item metadata.  Use only the programme/channel
        # context supplied by LivePlayer and never classify owner.item as a movie.
        clean_title = str(live_context.get("program_title") or title or live_context.get("channel_name") or "").strip()
        player_movie_title, player_movie_year = clean_title, 0
        content_key = "live:%s:%s:%s" % (
            live_context.get("channel_id") or "",
            live_context.get("begin") or 0,
            clean_title.lower(),
        )
    else:
        clean_title = _tivimate_best_title(owner, title)
        if not clean_title:
            return False

        # Movie title/year come only from information already available in the
        # current player.  This deliberately performs no TMDb/API/network lookup.
        player_movie_title, player_movie_year = _tivimate_player_movie_title_year(owner, clean_title)
        if _content_kind(owner) == "movie" and player_movie_title:
            clean_title = player_movie_title
        content_key = _tivimate_content_key(owner)

    if not clean_title:
        return False

    # Auto-search exactly once for each currently playing movie/episode or
    # Live programme. Opening BLUE again shows the normal manual search screen.
    previous_key = getattr(owner, "_tivimate_subtitle_auto_search_key", None)
    auto_search_on_open = previous_key != content_key
    if auto_search_on_open:
        owner._tivimate_subtitle_auto_search_key = content_key

    stage = "import"
    try:
        from Plugins.Extensions.TiviMateE2.TiviMateSubtitles.tivimate_subtitles import TiviMateSubtitleSearch, E2SubsSeeker
        _bridge_debug_log("import ok")

        stage = "controller"
        controller = _controller(owner)
        _bridge_debug_log("controller ok: %s" % controller.__class__.__name__)

        stage = "settings"
        settings = controller.subsProSettings.search
        _bridge_debug_log("settings ok")
        item = {} if is_live else (getattr(owner, "item", {}) or {})
        kind = "live" if is_live else _content_kind(owner)

        # Live title is already normalized by LivePlayer's EPG context.
        # VOD/Series keep their existing metadata-aware title builder.
        search_title = clean_title if is_live else (_tivimate_search_title(owner, clean_title) or clean_title)

        # The VOD player may expose a provider-decorated name even when the
        # movie/year are correctly identified (e.g. "TGP - It Ends (2026)").
        # Normalize the provider prefix BEFORE sending requests, and send the
        # year through the provider's dedicated field, not twice in the query.
        # Never apply this to Live EPG titles or season/episode search labels.
        if kind == "movie" and not is_live:
            try:
                from .subtitle_title import clean_subtitle_title
                normalized = clean_subtitle_title(search_title).strip()
                year_match = re.search(r"\s*[\(\[]?((?:19|20)\d{2})[\)\]]?\s*$", normalized)
                if year_match:
                    without_year = normalized[:year_match.start()].strip(" ._:-|")
                    if without_year:
                        if not player_movie_year:
                            player_movie_year = int(year_match.group(1))
                        normalized = without_year
                if normalized:
                    search_title = normalized
            except Exception as exc:
                _bridge_debug_log("subtitle title normalization failed", exc)

        # Language + manual behaviour.
        _set_language(settings, language_code)
        try:
            settings.manualSearch.value = False
        except Exception:
            pass

        # BLUE search is a real multi-source search.
        # Never keep a previously selected single provider.
        for attr in ("provider", "movieProvider", "tvshowProvider"):
            try:
                getattr(settings, attr).value = "all"
            except Exception:
                pass
        try:
            settings.openParamsDialogOnSearch.value = False
        except Exception:
            pass
        try:
            settings.useFilePath.value = False
        except Exception:
            pass

        # IMPORTANT:
        # Populate search parameters directly.  We open the screen with
        # resetSearchParams=False so its parser cannot erase TiviMate's title.
        try:
            settings.title.value = search_title
        except Exception:
            pass

        if kind == "episode":
            try:
                settings.type.value = "tv_show"
            except Exception:
                pass

            season = item.get("season_number", item.get("season", item.get("_subdl_season", 0)))
            episode = item.get("episode_number", item.get("episode_num",
                      item.get("episode", item.get("_subdl_episode", 0))))

            try:
                settings.season.value = int(season or 0)
            except Exception:
                pass
            try:
                settings.episode.value = int(episode or 0)
            except Exception:
                pass
            try:
                settings.year.value = 0
            except Exception:
                pass
        elif kind == "live":
            # The provider engine requires a movie/tv_show search type, but
            # Live itself remains a separate context: no VOD year/season/item
            # metadata is injected.  Search only the current EPG/channel title.
            try:
                settings.type.value = "movie"
            except Exception:
                pass
            try:
                settings.season.value = 0
                settings.episode.value = 0
                settings.year.value = 0
            except Exception:
                pass
        else:
            try:
                settings.type.value = "movie"
            except Exception:
                pass
            try:
                settings.season.value = 0
                settings.episode.value = 0
            except Exception:
                pass

            # Use only the year already known by the current player.  If the
            # item fields do not expose it, _tivimate_player_movie_title_year()
            # has already extracted a trailing year from the displayed title.
            try:
                settings.year.value = int(player_movie_year or 0)
            except Exception:
                pass

        stage = "seeker"
        seeker = E2SubsSeeker(session, settings, debug=True)
        _bridge_debug_log("seeker ok: %d providers" % len(getattr(seeker, "seekers", []) or []))

        # Keep multiple public providers active even if an older saved config
        # had previously disabled them. API-key providers are left to their
        # own saved credential/enable state.
        # Activate the complete provider engine imported from the second
        # SubsSupport package. Providers that failed to import keep error!=None
        # and are skipped by the seeker engine.
        try:
            for p in seeker.seekers:
                if getattr(p, "error", None) is None:
                    try:
                        p.settings_provider.setSetting("enabled", True)
                    except Exception:
                        pass
        except Exception:
            pass

        # BLUE is always a real multi-source search.
        try:
            settings.provider.value = "all"
            settings.movieProvider.value = "all"
            settings.tvshowProvider.value = "all"
        except Exception:
            pass

        def selected(subfile=None):
            if not subfile:
                return
            # A subtitle download/search callback can arrive after Back has
            # closed LivePlayer. Never reactivate a controller/dialog on a
            # player whose onClose cleanup has already run.
            if getattr(owner, "_epgClosed", False) or getattr(owner, "_closing", False):
                _bridge_debug_log("ignored subtitle result for closed player")
                return
            _bridge_debug_log("selected language=%s %s" % (_preferred_language(), _subtitle_file_diagnostic(subfile)))
            # A provider can label an English file as Arabic. Validate the
            # downloaded text before replacing the currently active subtitle.
            # This is deliberately limited to Arabic; other languages retain
            # their original provider selection behavior.
            if _preferred_language() == "ar":
                try:
                    from .srt_overlay import parse_srt_file
                    cues = list(parse_srt_file(str(subfile)) or [])
                    sample = " ".join(str(cue[2]) for cue in cues[:120] if len(cue) >= 3)
                    arabic_count = sum(1 for c in sample if "\u0600" <= c <= "\u06ff")
                    latin_count = sum(1 for c in sample if ("a" <= c.lower() <= "z"))
                    if arabic_count < 3 or (latin_count > 30 and arabic_count * 3 < latin_count):
                        _bridge_debug_log("REJECTED non-Arabic subtitle: arabic=%d latin=%d" % (arabic_count, latin_count))
                        try:
                            owner._showNotification("Selected subtitle is not Arabic. Choose another result.", 1, 6)
                        except Exception:
                            pass
                        return
                except Exception as exc:
                    _bridge_debug_log("Arabic subtitle content validation failed", exc)
                    return
            # Do not rewrite subtitle cue blocks. The previous Arabic-only
            # filter dropped valid French/Turkish subtitle files and could
            # corrupt cue timing. Keep the provider's original file intact.
            try:
                try:
                    owner.enableSubtitle(None)
                except Exception as exc:
                    _bridge_debug_log("native subtitle disable failed before external load", exc)
                # r333: use the same new-file activation sequence as the
                # original SubsSupport callback: pause -> reset engine -> load on
                # the same service -> refresh if replacing an already-loaded file,
                # otherwise resume the engine on the first external subtitle.
                if is_live:
                    # Set the clock before loading: loadSubs()/resume() consult
                    # getVideoTime() and otherwise start at the first cue.
                    try:
                        engine = getattr(controller, "_TiviMateSubtitleSupport__subsEngine", None)
                        begin = int(live_context.get("begin") or 0)
                        duration = int(live_context.get("duration") or 0)
                        # Providers are inconsistent here: accept epoch ms as
                        # well as the documented epoch-second form.
                        if begin > 100000000000:
                            begin //= 1000
                        import time as _time
                        if begin > 0 and begin <= _time.time() and (not duration or _time.time() <= begin + duration + 120):
                            engine._tivimate_live_program_begin = begin
                            engine._tivimate_live_program_duration = max(0, duration)
                        elif engine is not None:
                            engine._tivimate_live_program_begin = 0
                            engine._tivimate_live_program_duration = 0
                    except Exception as exc:
                        _bridge_debug_log("live subtitle clock setup failed", exc)
                if controller.activateSelectedSubs(subfile):
                    _bridge_debug_log("external subtitle activation success")
                    if is_live:
                        # First-file resume alone can leave the subtitle dialog
                        # invisible on some Enigma2 images; explicitly sync/show.
                        try:
                            controller.playAfterSeek()
                        except Exception as exc:
                            _bridge_debug_log("live subtitle initial sync failed", exc)
                    # r295: keep the exact controller that successfully loaded
                    # the subtitle as the single active controller for RED/sync.
                    owner._external_subs = controller
                    owner._subssupport = controller
                    owner._tivimate_subtitles = controller
                    owner._tivimate_subtitle_controller = controller
                    previous_file = str(getattr(owner, "_external_subtitle_path", "") or "")
                    if previous_file != str(subfile):
                        # A different subtitle file has its own timing: never
                        # carry the old file's delay over (it made the new
                        # subtitle run ahead/behind).
                        owner._subtitle_session_delay_ms = 0
                    owner._external_subtitle_path = str(subfile)
                    owner._external_subtitle_owner = "subssupport"
                    # User-selected external subtitle wins over delayed saved-track restore.
                    owner._subtitle_restore_attempted = True
                    # A SubsSupport-loaded file must be rendered only by
                    # SubsSupport. Clear a stale TiviMate overlay without
                    # touching search/providers or the active controller.
                    try:
                        clear_overlay = getattr(owner, "_clearSRTOverlay", None)
                        if callable(clear_overlay):
                            clear_overlay()
                    except Exception:
                        pass
                    try:
                        controller._tivimateDelayChangedCB = getattr(owner, "_tivimateSubtitleDelayChanged", None)
                    except Exception:
                        pass
                    # Restore only the already-known per-movie delay.
                    try:
                        delay_ms = int(getattr(owner, "_subtitle_session_delay_ms", 0) or 0)
                        setter = getattr(controller, "setTiviMateDelay", None) or getattr(controller, "setSubsDelay", None)
                        if callable(setter) and delay_ms:
                            setter(delay_ms)
                        save = getattr(owner, "_savePreferences", None)
                        if callable(save):
                            save()
                    except Exception:
                        pass
                    # Do not force playAfterSeek() after activation. SubsSupport
                    # either resumes the engine for the first file or refreshes the
                    # renderer when replacing an already-loaded external subtitle.
            except Exception as exc:
                _bridge_debug_log("selected subtitle activation failed: %r" % (subfile,), exc)

        _cached_poster(owner)

        # resetSearchParams=False is intentional:
        # the search screen must use the title/type/season/episode from TiviMate.
        stage = "openWithCallback"
        _bridge_debug_log("opening search screen: title=%r kind=%r auto=%r" % (search_title, kind, auto_search_on_open))
        session.openWithCallback(
            selected,
            TiviMateSubtitleSearch,
            seeker,
            settings,
            None,
            [search_title],
            False,
            False,
            auto_search_on_open
        )
        _bridge_debug_log("openWithCallback ok")
        return True
    except Exception as exc:
        owner._tivimate_subtitle_search_error = stage
        _bridge_debug_log("FAILED at %s" % stage, exc)
        return False

def open_active_subtitle_picker(owner, supports=None):
    """RED: use the active subtitle controller's native status/sync screen.

    r294 restores the proven single-controller path: no separate subtitle-file
    viewer, no re-parsing, and no parallel subtitle state.
    """
    candidates = list(supports or [])
    candidates.extend([
        getattr(owner, "_external_subs", None),
        getattr(owner, "_subssupport", None),
        getattr(owner, "_tivimate_subtitles", None),
        getattr(owner, "_tivimate_subtitle_controller", None),
    ])
    seen = set()
    for controller in candidates:
        if controller is None or id(controller) in seen:
            continue
        seen.add(id(controller))
        try:
            fn = getattr(controller, "subsStatus", None)
            if callable(fn):
                fn()
                return True
        except Exception:
            pass
    return False
