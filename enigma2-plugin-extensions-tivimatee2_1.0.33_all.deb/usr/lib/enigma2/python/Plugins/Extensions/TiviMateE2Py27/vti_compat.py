# -*- coding: utf-8 -*-
"""VTi legacy-skin bridge, strictly scoped to this Python 2.7 plugin.

The original OpenATV test package and system Enigma2 skin remain untouched.
"""
import re
import sys

_OWN_PREFIX = 'Plugins.Extensions.TiviMateE2Py27.'
_UNSUPPORTED = re.compile(
    r'''\s+(?:cornerRadius|cornerRadiusValue|itemCornerRadius|itemCornerRadiusSelected|itemCornerRadiusMarked|itemGradientSelected|selectionForegroundColor|selectionForegroundColorValue|selectionBackgroundColor|scrollbarWidth|secondfont|borderWidth|borderColor)\s*=\s*(?:"[^"]*"|'[^']*')''',
    re.I)
_SCREEN_TAG = re.compile(r'<screen\b[^>]*>', re.I)
_RESOLUTION = re.compile(r'''\s+resolution\s*=\s*(?:"[^"]*"|'[^']*')''', re.I)
_HD_RESOLUTION = re.compile(r'''\bresolution\s*=\s*["']1280\s*,\s*720["']''', re.I)


def sanitize_vti_skin(xml, desktop=None):
    """Remove VTi-incompatible screen/widget attributes before parsing.

    For 720p GUI desktops, retain the plugin's established coordinate scaling.
    Already native-scaled screens are not scaled again. This never changes
    current image downloads, poster queues or runtime decoder preferences.
    """
    if not xml or '<screen' not in xml:
        return xml
    try:
        size = desktop.size() if desktop is not None else None
        width, height = int(size.width()), int(size.height())
    except Exception:
        width, height = 0, 0
    if width == 1280 and height == 720:
        head = _SCREEN_TAG.search(xml)
        # Some plugin screens already run through scale_skin() when they are
        # defined. The older check looked only for resolution="1280,720" and
        # scaled these AGAIN after we removed that unsupported attribute.
        # Only scale a raw 1920x1080 screen exactly once.
        if head and re.search(r'\bsize\s*=\s*["\']1920\s*,\s*1080["\']',
                              head.group(0), re.I):
            try:
                from .display_scale import scale_skin
                xml = scale_skin(xml)
            except Exception:
                pass
    xml = _UNSUPPORTED.sub('', xml)
    return _SCREEN_TAG.sub(lambda match: _RESOLUTION.sub('', match.group(0)), xml)


def _is_plugin_screen(screen):
    try:
        return screen.__class__.__module__.startswith(_OWN_PREFIX)
    except Exception:
        return False


def _clean_skin_value(value, desktop):
    """Sanitize a skin argument (string, or list/tuple of strings)."""
    if isinstance(value, basestring):
        return sanitize_vti_skin(value, desktop) if '<screen' in value else value
    if isinstance(value, (list, tuple)):
        cleaned = [_clean_skin_value(item, desktop) for item in value]
        return type(value)(cleaned)
    return value


def _make_reader(original):
    def reader(*args, **kwargs):
        screen = args[0] if args else kwargs.get('screen')
        if screen is not None and _is_plugin_screen(screen):
            try:
                desktop = (args[-1] if args and hasattr(args[-1], 'size')
                           else kwargs.get('desktop'))
                source = getattr(screen, 'skin', None)
                clean = _clean_skin_value(source, desktop)
                if clean != source:
                    screen.skin = clean
                # VTi's Screen.applySkin reads self.skin BEFORE calling
                # readSkin(screen, skin, names, desktop) and passes the raw
                # string as an argument. Cleaning only screen.skin left
                # itemCornerRadius etc. in the XML actually parsed.
                if len(args) > 1:
                    args = (args[0],) + tuple(
                        _clean_skin_value(arg, desktop) for arg in args[1:])
                if 'skin' in kwargs:
                    kwargs['skin'] = _clean_skin_value(kwargs['skin'], desktop)
            except Exception:
                # A skin parse failure still yields the original E2 error;
                # the plugin must not interfere with unrelated screens.
                pass
        return original(*args, **kwargs)
    reader._tivimate_vti_compat = True
    reader._tivimate_vti_original = original
    return reader


# Attributes that newer images understand but VTi's skin.py rejects with
# "[Skin ERROR] Attribute not implemented". They are purely cosmetic.
_TOLERATED_ATTRIBUTES = frozenset((
    'cornerRadius', 'cornerRadiusValue', 'itemCornerRadius',
    'itemCornerRadiusSelected', 'itemCornerRadiusMarked',
    'itemGradientSelected', 'itemGradient', 'selectionForegroundColor',
    'selectionForegroundColorValue', 'selectionBackgroundColor',
    'scrollbarWidth', 'scrollbarRadius', 'scrollbarBorderWidth',
    'scrollbarBorderColor', 'scrollbarForegroundColor',
    'scrollbarBackgroundColor', 'scrollbarSliderBorderWidth',
    'scrollbarSliderForegroundColor', 'scrollbarSliderBorderColor',
    'textBorderColor', 'textBorderWidth', 'padding', 'textPadding',
    'resolution', 'secondfont', 'backgroundGradient', 'foregroundGradient',
))


def _wrap_attribute_applier(original):
    def apply_single(guiObject, desktop, attrib, value, *args, **kwargs):
        try:
            return original(guiObject, desktop, attrib, value, *args, **kwargs)
        except Exception:
            if attrib in _TOLERATED_ATTRIBUTES:
                return None
            raise
    apply_single._tivimate_vti_compat = True
    return apply_single


def _install_attribute_guard(skin_module):
    """Ignore (instead of failing on) known cosmetic attributes VTi lacks.

    Only attributes in _TOLERATED_ATTRIBUTES are affected; every other skin
    error is raised exactly as before, for all screens.
    """
    original = getattr(skin_module, 'applySingleAttribute', None)
    if callable(original) and not getattr(original, '_tivimate_vti_compat', False):
        setattr(skin_module, 'applySingleAttribute', _wrap_attribute_applier(original))
    parser = getattr(skin_module, 'AttributeParser', None)
    apply_one = getattr(parser, 'applyOne', None) if parser is not None else None
    if callable(apply_one) and not getattr(apply_one, '_tivimate_vti_compat', False):
        def guarded_apply_one(self, attrib, value):
            try:
                return apply_one(self, attrib, value)
            except Exception:
                if attrib in _TOLERATED_ATTRIBUTES:
                    return None
                raise
        guarded_apply_one._tivimate_vti_compat = True
        try:
            parser.applyOne = guarded_apply_one
        except Exception:
            pass


def _install_messagebox_text_guard():
    """MessageBox(text=unicode) fails inside VTi's eLabel_setText(std::string).

    The failure happens while Session.open() builds the box, which left the
    calling page suspended over the TV picture with a dead remote. Converting
    a unicode message to UTF-8 bytes is what every Python 2.7 image expects,
    so the guard is harmless for other callers.
    """
    try:
        from Screens.MessageBox import MessageBox
    except Exception:
        return
    original = MessageBox.__init__
    if getattr(original, '_tivimate_vti_compat', False):
        return

    def __init__(self, session, text, *args, **kwargs):
        try:
            if isinstance(text, unicode):
                text = text.encode('utf-8')
        except Exception:
            pass
        return original(self, session, text, *args, **kwargs)
    __init__._tivimate_vti_compat = True
    try:
        MessageBox.__init__ = __init__
    except Exception:
        pass


def install_vti_skin_compat():
    """Guard both legacy readSkin aliases, scoped to TiviMate Python2 UI."""
    try:
        import skin as skin_module
        import Screens.Screen
        screen_module = sys.modules.get('Screens.Screen')
    except ImportError:
        return False
    try:
        _install_attribute_guard(skin_module)
    except Exception:
        pass
    try:
        _install_messagebox_text_guard()
    except Exception:
        pass
    installed = False
    for module in (skin_module, screen_module):
        if module is None:
            continue
        original = getattr(module, 'readSkin', None)
        if not callable(original):
            continue
        if not getattr(original, '_tivimate_vti_compat', False):
            setattr(module, 'readSkin', _make_reader(original))
        installed = True
    return installed


def _record_vti_screen_open_error(screen, message, traceback_text=''):
    """Keep the ORIGINAL failed Screen exception; avoid masking it with a second open.

    Only private local diagnostics. This does not involve the IPTV server,
    artwork queues, system skins, or the package updater.
    """
    try:
        import os
        import time
        import sys
        screen_name = getattr(screen, '__name__', str(type(screen).__name__))
        line = "[VTi navigation] %s screen=%s %s\n%s\n" % (
            time.strftime('%Y-%m-%d %H:%M:%S'), screen_name,
            str(message)[:500], traceback_text[:5000])
        sys.stderr.write(line)
        path = '/home/root/tivimatee2_vti_screen_errors.log'
        if os.path.isfile(path) and os.path.getsize(path) > 131072:
            with open(path, 'wb') as fd:
                fd.write(b'')
        with open(path, 'a') as fd:
            fd.write(line)
    except Exception:
        pass


def open_vti_page_once(owner, screen, *args):
    """VTi-safe modal page transition (called from an active Screen ActionMap).

    Do not retry Session.open() after openWithCallback() fails: Enigma2 may
    already have pushed the previous Screen and set in_exec=False. Such a retry
    masked the real first exception and caused the reported modal RuntimeError.
    """
    if getattr(owner, '_pageOpenBusy', False):
        return False
    session = owner.session
    if getattr(session, 'current_dialog', None) is not owner or not getattr(session, 'in_exec', True):
        _record_vti_screen_open_error(screen, 'Open ignored: parent is not the active modal screen')
        return False
    owner._pageOpenBusy = True
    try:
        session.openWithCallback(owner._pageClosed, screen, *args)
        return True
    except Exception as exc:
        import traceback
        _record_vti_screen_open_error(screen, '%s: %s' % (type(exc).__name__, exc), traceback.format_exc())
        owner._pageOpenBusy = False
        # Older VTi Session.open() may have pushed the parent then failed while
        # constructing the child. Restore the parent only when this is exactly
        # the pending top of stack; never pop some unrelated/active dialog.
        try:
            stack = getattr(session, 'dialog_stack', ())
            if (stack and not getattr(session, 'in_exec', True)
                    and stack[-1][0] is owner):
                session.popCurrent()
        except Exception as restore_exc:
            _record_vti_screen_open_error(screen, 'Unable to restore parent modal screen: %s' % restore_exc, traceback.format_exc())
        return False


def open_vti_player_once(session, screen, *args, **kwargs):
    """Open a VOD player once, and recover a half-pushed VTi modal stack.

    The original exception is re-raised to the screen's existing error handler.
    Never retry the player on the same OK press: a failed execBegin can already
    have suspended the calling screen on VTi 15 / Python 2.7.
    """
    callback = kwargs.pop('callback', None)
    if kwargs:
        raise TypeError('Unexpected VOD player open options')
    parent = getattr(session, 'current_dialog', None)
    try:
        if callback is None:
            return session.open(screen, *args)
        return session.openWithCallback(callback, screen, *args)
    except Exception as exc:
        # Only record the original failure's class and traceback location.
        # Do not log stream URLs or provider credentials from exception text.
        try:
            import traceback
            frames = traceback.extract_tb(sys.exc_info()[2])
            safe_trace = '\n'.join('%s:%d:%s' % (
                __import__('os').path.basename(f[0]), f[1], f[2]
            ) for f in frames[-12:])
            _record_vti_screen_open_error(screen,
                'VOD player open failed: %s' % type(exc).__name__, safe_trace)
        except Exception:
            pass
        # Session.open() may push the parent then fail while initializing the
        # player. Pop only this known pending parent, not a different dialog.
        try:
            stack = getattr(session, 'dialog_stack', ())
            if (parent is not None and stack and
                    not getattr(session, 'in_exec', True) and
                    stack[-1][0] is parent):
                session.popCurrent()
        except Exception:
            pass
        raise


# VTi 15.0.04 (Python 2.7) has eLabel_setText(std::string) SWIG binding:
# passing a unicode source title may restart Enigma2. Use the safe label
# exclusively in this plugin's own screen modules; never patch system labels.
from Components.Label import Label as _NativeLabel
from .py27_compat import gui_text as _vti_gui_text


class VTiTextLabel(_NativeLabel):
    """Plugin-scoped Label that accepts Arabic/unicode and legacy byte strings."""
    def __init__(self, text=''):
        _NativeLabel.__init__(self, '')
        self.setText(text)

    def setText(self, value):
        return _NativeLabel.setText(self, _vti_gui_text(value))

    # VariableText.text would otherwise bind the base class's setter.
    text = property(_NativeLabel.getText, setText)


# StaticText is a Source (not a Label). Its native Label renderer still feeds
# eLabel_setText and therefore also requires UTF-8 *bytes* on VTi Python2.
# Keep the change scoped to this plugin: no global monkey-patching.
from Components.Sources.StaticText import StaticText as _NativeStaticText


class VTiTextStaticText(_NativeStaticText):
    """Convert portal titles to native UTF-8 bytes before Label rendering."""
    def __init__(self, value=''):
        _NativeStaticText.__init__(self, _vti_gui_text(value))

    def setText(self, value):
        return _NativeStaticText.setText(self, _vti_gui_text(value))


def safe_open_screen(session, callback, screen, *args, **kwargs):
    """Open a Screen without ever leaving Enigma2's modal stack locked.

    On VTi (and other older images) Session.open() pushes the current screen
    BEFORE constructing the new one. If the constructor or execBegin raises,
    the parent stays suspended with no active dialog: the remote does
    nothing and only a GUI restart helps. This restores the parent, records
    the real traceback in /home/root/tivimatee2_vti_screen_errors.log and
    returns None instead of raising. On success the dialog is returned.
    """
    parent = getattr(session, 'current_dialog', None)
    try:
        if callback is None:
            return session.open(screen, *args, **kwargs)
        return session.openWithCallback(callback, screen, *args, **kwargs)
    except Exception as exc:
        import traceback
        _record_vti_screen_open_error(screen, '%s: %s' % (type(exc).__name__, exc),
                                      traceback.format_exc())
        try:
            stack = getattr(session, 'dialog_stack', None) or []
            current = getattr(session, 'current_dialog', None)
            if current is not None and current is not parent:
                # The new screen was created but execBegin failed: close it.
                try:
                    current.callback = None
                except Exception:
                    pass
                try:
                    session.close(current)
                except Exception:
                    try:
                        session.current_dialog = None
                        session.popCurrent()
                    except Exception:
                        pass
            elif (stack and not getattr(session, 'in_exec', True)
                  and stack[-1][0] is parent):
                session.popCurrent()
        except Exception as restore_exc:
            _record_vti_screen_open_error(screen, 'restore failed: %s' % restore_exc,
                                          traceback.format_exc())
        return None
