# -*- coding: utf-8 -*-
"""Footer identity from the active IPTV source. No network and no side effects."""
import sys
from .py27_compat import text_type

def compact_server_name(source, limit=17):
    source = source if isinstance(source, dict) else {}
    raw = (source.get("name") or source.get("display_name") or
           source.get("server_name") or source.get("title") or u"Server")
    if isinstance(raw, bytes):
        try:
            raw = raw.decode("utf-8", "replace")
        except Exception:
            raw = u"Server"
    try:
        text = u" ".join(text_type(raw).split())
    except Exception:
        text = u"Server"
    text = u"".join(ch for ch in text if ord(ch) >= 32)
    # Treat URLs as a display-name omission, not as the server name.
    if not text or "://" in text or text.startswith("/"):
        text = u"Server"
    limit = max(5, int(limit))
    result = text if len(text) <= limit else text[:limit - 1].rstrip() + u"…"
    # DreamOS eLabel in Python 2 expects a UTF-8 char* rather than PyUnicode.
    return result.encode("utf-8") if sys.version_info[0] < 3 else result

def refresh_footer_label(screen):
    try:
        screen["footerServerName"].setText(compact_server_name(getattr(screen, "source", {})))
    except Exception:
        pass
