# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.TiviMateSubtitles.tivimate_plugin import *
