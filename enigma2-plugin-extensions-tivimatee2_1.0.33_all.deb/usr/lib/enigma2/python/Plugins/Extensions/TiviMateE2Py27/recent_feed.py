# -*- coding: utf-8 -*-
"""Shared Recent Added source for Movies/Series pages and new-content notices.

Visible Recent Add keeps its 25 items; the watcher may scan up to 250
without changing the UI. The caller runs provider requests in a worker.
"""
import re
import time
import hashlib
import threading
from .py27_compat import text_type

_FEED_CACHE = {}
_FEED_GATES = {}
_FEED_LOCK = threading.Lock()
_FEED_TTL = 120


def _sort_time(row):
    row = row or {}
    for field in ("added", "date_added", "added_at", "created_at", "timestamp", "last_modified"):
        raw = row.get(field)
        if raw is None or raw == "":
            continue
        try:
            value = int(float(str(raw).strip()))
            if value > 100000000000:
                value //= 1000
            if value > 0:
                return value
        except (ValueError, TypeError, OverflowError):
            pass
        for fmt, n in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%dT%H:%M:%S", 19), ("%Y-%m-%d", 10)):
            try:
                return int(time.mktime(time.strptime(str(raw)[:n], fmt)))
            except (ValueError, TypeError, OverflowError):
                pass
    return 0


def _category_id(row):
    """Normalize category identifiers exactly like the visible Recent page."""
    for field in ("category_id", "id", "genre_id", "group_id"):
        value = row.get(field)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _cache_key(source, kind, ids):
    src = source or {}
    # Never retain raw usernames, passwords or stream URLs in the RAM key.
    secret = u"|".join(text_type(src.get(key) or u"") for key in
                      ("type", "url", "path", "username", "password", "mac"))
    raw = "%s|%s|%s" % (secret, kind, "\x00".join(sorted(ids)))
    return hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest()


def _load_provider_items(source, kind, client, ids, limit):
    media_type = str((source or {}).get("type") or "").lower()
    merged = []
    if kind in ("vod", "series") and media_type in ("xtream", "m3u"):
        # Single provider-wide call; M3U must not reload its playlist per
        # category.  Filter the result locally by the enabled package IDs.
        all_rows = client.streams(kind, "") or []
        allowed = set(ids)
        for item in all_rows:
            if not isinstance(item, dict):
                continue
            cid = str(item.get("category_id") or item.get("categoryId") or
                      item.get("genre_id") or item.get("group_id") or
                      item.get("group") or "").strip()
            if cid in allowed:
                merged.append(item)
    elif kind in ("vod", "series") and media_type == "stalker" and hasattr(client, "recent_media_filtered"):
        merged = list(client.recent_media_filtered(kind, ids, limit) or [])
    else:
        for cid in ids:
            rows = client.streams(kind, cid) or []
            merged.extend(row for row in rows if isinstance(row, dict))

    # Some Xtream portals return a provider-wide list with category keys that
    # cannot be matched to the actual package IDs. A nonempty list is not a
    # successful scan if none of its rows belongs to an enabled package.
    allowed_categories = set(ids)
    provider_has_allowed = any(
        isinstance(item, dict) and str(
            item.get("category_id") or item.get("categoryId") or
            item.get("genre_id") or item.get("group_id") or
            item.get("group") or "").strip() in allowed_categories
        for item in merged
    ) if media_type == "xtream" else bool(merged)
    if (not merged or not provider_has_allowed) and media_type in ("xtream", "stalker") and kind in ("vod", "series"):
        # Some portals expose the category only through per-package endpoints.
        # An eight-package fallback is NOT a correct all-packages Recent feed:
        # it silently labels an arbitrary subset as the newest content.
        # Recover every enabled package, or report an incomplete scan instead.
        try:
            from .filters import peek_category_streams_cache, get_category_streams_batch
            recovered = []
            missing = []
            for cid in ids:
                rows, _origin = peek_category_streams_cache(source, kind, cid)
                if rows:
                    for item in rows:
                        if isinstance(item, dict):
                            entry = dict(item)
                            entry["category_id"] = cid
                            recovered.append(entry)
                else:
                    missing.append(cid)
            if missing:
                fetched = get_category_streams_batch(
                    source, kind, client, missing,
                    use_cache=True, wait_for_server=True, max_workers=3)
                completed = {str(cid): (rows, origin) for cid, rows, origin in fetched}
                if any(cid not in completed or
                       completed[cid][1] in ("loading", "error", "empty_cooldown")
                       for cid in missing):
                    raise RuntimeError("Recent Added catalogue is incomplete")
                for cid in missing:
                    for item in completed[cid][0] or []:
                        if isinstance(item, dict):
                            entry = dict(item)
                            entry["category_id"] = cid
                            recovered.append(entry)
            merged = recovered
        except Exception:
            # Never label a partial or arbitrary package subset as the
            # most recently added across *all* permitted packages.
            raise

    ordered = []
    dedup = set()
    for pos, item in enumerate(merged):
        if not isinstance(item, dict):
            continue
        key = text_type(item.get("stream_id") or item.get("series_id") or
                        item.get("vod_id") or item.get("id") or u"")
        if not key:
            key = text_type(item.get("name") or item.get("title") or u"")
        if not key or key in dedup:
            continue
        dedup.add(key)
        ordered.append((pos, dict(item)))
    # Keep server order for undated rows (same behavior as Recent Add).
    dated, undated = [], []
    for pos, item in ordered:
        stamp = _sort_time(item)
        if stamp:
            dated.append((stamp, pos, item))
        else:
            undated.append((pos, item))
    dated.sort(key=lambda row: (-row[0], row[1]))
    return ([item for _, _, item in dated] + [item for _, item in undated])[:limit]


def recent_added_items(source, kind, client, categories, limit=25):
    """Return a common Recent feed for the UI and new-content watcher.

    The visible page continues to request 25; notifications request a wider
    window. The short in-memory cache also shares a provider-wide Xtream
    response between calls, without freezing the feed for the 15-min interval.
    Errors propagate, and empty/error responses do not poison the cache.
    """
    limit = max(1, min(250, int(limit or 25)))
    categories = [row for row in (categories or []) if isinstance(row, dict)]
    ids = list(dict.fromkeys(_category_id(row) for row in categories))
    ids = [cid for cid in ids if cid]
    if not ids:
        return []
    cache_key = _cache_key(source, kind, ids)
    with _FEED_LOCK:
        gate = _FEED_GATES.setdefault(cache_key, threading.Lock())
    with gate:
        with _FEED_LOCK:
            cached = _FEED_CACHE.get(cache_key)
            if cached and time.time() - cached[0] < _FEED_TTL and cached[2] >= limit:
                return [dict(x) for x in cached[1][:limit]]
        # The capped provider may contain fewer rows than requested, so cache
        # the actual request limit to avoid pointlessly repeating the fetch.
        rows = _load_provider_items(source, kind, client, ids, limit)
        if rows:
            with _FEED_LOCK:
                _FEED_CACHE[cache_key] = (time.time(), rows, limit)
                for old_key, value in list(_FEED_CACHE.items()):
                    if time.time() - value[0] >= _FEED_TTL:
                        _FEED_CACHE.pop(old_key, None)
                if len(_FEED_CACHE) > 20:
                    for old_key, _ in sorted(_FEED_CACHE.items(), key=lambda kv: kv[1][0])[:-20]:
                        _FEED_CACHE.pop(old_key, None)
        return [dict(x) for x in rows[:limit]]
