# -*- coding: utf-8 -*-
"""Python 2.7 urllib.parse equivalents; standard library only."""
from urllib import (urlencode, quote, quote_plus, unquote, unquote_plus,
                    urlretrieve, pathname2url, url2pathname)
from urlparse import (urlparse, urlsplit, urlunsplit, urlunparse, urljoin,
                      parse_qs, parse_qsl, urldefrag)
