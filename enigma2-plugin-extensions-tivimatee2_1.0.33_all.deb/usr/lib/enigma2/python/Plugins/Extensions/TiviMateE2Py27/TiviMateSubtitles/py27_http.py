# -*- coding: utf-8 -*-
"""Restricted stdlib GET fallback when python-requests is not on DreamOS."""
from __future__ import absolute_import
import json
try:
    from urllib2 import Request, urlopen, HTTPError, URLError
    from urllib import urlencode
except ImportError:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    from urllib.parse import urlencode

class RequestException(Exception):
    pass

class Response(object):
    def __init__(self, data, url, headers=None, status=200):
        self.content = data
        self.url = url
        self.headers = headers or {}
        self.status_code = status
        self.ok = status < 400
    @property
    def text(self):
        for enc in ('utf-8-sig', 'utf-8'):
            try: return self.content.decode(enc)
            except Exception: pass
        return self.content.decode('latin-1', 'replace')
    def json(self):
        return json.loads(self.text)
    def raise_for_status(self):
        if not self.ok:
            raise RequestException('HTTP %d' % self.status_code)
    def iter_content(self, chunk_size=8192):
        for pos in range(0, len(self.content), chunk_size):
            yield self.content[pos:pos+chunk_size]

def request(method, url, params=None, data=None, headers=None, timeout=10, **kwargs):
    if kwargs.get('verify') is False:
        # Do not weaken TLS for a fallback transport.
        raise RequestException('secure requests library required for verify=False')
    if params:
        sep = '&' if '?' in url else '?'
        url = url + sep + urlencode(params)
    try:
        req = Request(url, data=data, headers=headers or {})
        resp = urlopen(req, timeout=timeout if isinstance(timeout, (float, int)) else timeout[-1])
        try:
            payload = resp.read()
            return Response(payload, resp.geturl(), dict(resp.info()), resp.getcode() or 200)
        finally:
            resp.close()
    except (HTTPError, URLError) as exc:
        raise RequestException(str(exc))

def get(url, **kwargs):
    return request('GET', url, **kwargs)

def post(url, **kwargs):
    return request('POST', url, **kwargs)
