# -*- coding: utf-8 -*-
"""One-shot local recovery when DreamOS ePicLoad rejects valid cached artwork.

Keeps the original on HDD/USB/flash, performs no network calls, and never
runs image conversion on Enigma2's GUI thread.  Unrelated poster queues,
workers, priorities and cache path selection are left untouched.
"""
from __future__ import absolute_import
import os
import tempfile
import threading
from .py27_futures import ThreadPoolExecutor
from .py27_compat import which, subprocess_run
import subprocess

_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='TiviNativeArtwork')
_LOCK = threading.RLock()
_PENDING = {}
_MAX_PENDING = 12


def is_normalized(path):
    return '.tivi-native-v1.' in os.path.basename(path or '')


def _destination(path, kind):
    suffix = '.png' if kind == 'logo' else '.jpg'
    return os.path.splitext(path)[0] + '.tivi-native-v1.' + suffix.lstrip('.')


def cached(path, kind):
    try:
        dest = _destination(path, kind)
        if (os.path.isfile(dest) and os.path.getsize(dest) > 256 and
                os.path.getmtime(dest) >= os.path.getmtime(path)):
            return dest
    except (OSError, TypeError, ValueError, IOError):
        pass
    return ''


def normalize(path, kind):
    if is_normalized(path) or not path or not os.path.isfile(path):
        return ''
    kind = 'logo' if kind == 'logo' else 'image'
    hit = cached(path, kind)
    if hit:
        return hit
    directory = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(prefix='.tivi-native-', suffix='.png' if kind == 'logo' else '.jpg', dir=directory)
    os.close(fd)
    try:
        try:
            from PIL import Image
            img = Image.open(path)
            try:
                if kind == 'logo':
                    rgba = img.convert('RGBA')
                    alpha = rgba.getchannel('A') if hasattr(rgba, 'getchannel') else rgba.split()[-1]
                    low, high = alpha.getextrema()
                    # An opaque JPG pretending to be a clearlogo is not fixable.
                    if low >= 255 or high <= 0:
                        return ''
                    rgba.save(tmp, 'PNG')
                else:
                    img.convert('RGB').save(tmp, 'JPEG', quality=94)
            finally:
                try: img.close()
                except Exception: pass
        except (ImportError, AttributeError, IOError, OSError, ValueError):
            ffmpeg = which('ffmpeg')
            if not ffmpeg:
                return ''
            if kind == 'logo':
                subprocess_run([ffmpeg, '-nostdin', '-loglevel','error', '-y', '-i', path,
                                '-frames:v','1', '-pix_fmt','rgba', '-vcodec','png', tmp],
                               check=True, timeout=8, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            else:
                subprocess_run([ffmpeg, '-nostdin','-loglevel','error', '-y', '-i', path,
                                '-frames:v','1', '-pix_fmt','yuvj420p', '-q:v','2', tmp],
                               check=True, timeout=8, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if kind == 'logo':
                from .genre_ultra_artwork import _logo_cache_usable
                if not _logo_cache_usable(tmp, ''):
                    return ''
        if os.path.getsize(tmp) < 256:
            return ''
        dest = _destination(path, kind)
        try: os.rename(tmp, dest)
        except (OSError, IOError):
            if os.path.exists(dest): os.unlink(dest)
            os.rename(tmp, dest)
        return dest
    except Exception:
        return ''
    finally:
        try:
            if os.path.exists(tmp): os.unlink(tmp)
        except (OSError, IOError):
            pass


def request(path, kind, callback):
    """Queue at most one conversion per cached image; callback runs on GUI.

    Return True when a recovery has been scheduled.  No recursive attempts
    are allowed on already converted files.
    """
    if not path or is_normalized(path) or not os.path.isfile(path):
        return False
    try:
        from twisted.internet import reactor
        if not reactor or not hasattr(reactor, 'callFromThread'):
            return False
    except (ImportError, AttributeError):
        return False
    key = (path, 'logo' if kind == 'logo' else 'image')
    with _LOCK:
        callbacks = _PENDING.get(key)
        if callbacks is not None:
            if len(callbacks) < 8:
                callbacks.append(callback)
            return True
        if len(_PENDING) >= _MAX_PENDING:
            return False
        _PENDING[key] = [callback]
    def task():
        output = normalize(path, kind)
        with _LOCK:
            handlers = _PENDING.pop(key, [])
        # Notify even when no safe normalized image exists: the caller must
        # continue its existing TMDb/placeholder fallback, never get stuck.
        for handler in handlers:
            try: reactor.callFromThread(handler, output or '')
            except Exception: pass
    try:
        _POOL.submit(task)
        return True
    except RuntimeError:
        with _LOCK: _PENDING.pop(key, None)
        return False
