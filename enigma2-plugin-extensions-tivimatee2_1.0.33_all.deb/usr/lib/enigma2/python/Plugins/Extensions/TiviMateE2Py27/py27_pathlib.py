# -*- coding: utf-8 -*-
"""Minimal Path fallback for optional rarfile handling."""
import os
class Path(object):
    def __init__(self, path): self.path = os.path.expanduser(str(path))
    def __str__(self): return self.path
    def __unicode__(self): return unicode(self.path)
    def __repr__(self): return 'Path(%r)' % self.path
    def __fspath__(self): return self.path
    def open(self, mode='r'): return open(self.path, mode)
    def is_file(self): return os.path.isfile(self.path)
    def exists(self): return os.path.exists(self.path)
    def resolve(self): return Path(os.path.realpath(self.path))
