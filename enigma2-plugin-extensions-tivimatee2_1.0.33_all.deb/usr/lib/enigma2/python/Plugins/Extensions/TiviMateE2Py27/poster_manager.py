# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch, text_type
"""Shared VOD/series poster policy for every TiviMateE2 page.

Keep GENRE, Movies, TV Shows, Details, Search, Favorites and Package layouts
independent. Visible poster requests use the same validated, bounded Ultra
provider downloader as GENRE, with the original artwork queue as a fallback.
"""
from . import artwork_queue as _queue
import re
import threading
from collections import OrderedDict
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit

KIND = "posters"
PROVIDER_KEYS = (
    "stream_icon", "movie_image", "cover", "cover_big", "poster",
    "poster_url", "poster_path", "poster_image", "cover_url",
    "image_url", "pic", "img", "thumbnail", "screenshot_uri", "image",
)

# Context is exact-URL scoped, not a single mutable 'current server' value:
# combined Movies/Series searches can load posters from different Stalker
# portals simultaneously. Retain just a bounded window of sources in RAM.
_PROVIDER_CONTEXTS = OrderedDict()
_CONTEXT_LOCK = threading.RLock()
_MAX_CONTEXTS = 384


def _remember_provider(url, source):
    if not url or not isinstance(source, dict):
        return
    if not text_type(url).startswith(("http://", "https://")):
        return
    key = _queue.normalise_url(url)
    if not key:
        return
    with _CONTEXT_LOCK:
        _PROVIDER_CONTEXTS.pop(key, None)
        _PROVIDER_CONTEXTS[key] = dict(source)
        while len(_PROVIDER_CONTEXTS) > _MAX_CONTEXTS:
            _PROVIDER_CONTEXTS.popitem(last=False)


def _provider_for(url):
    with _CONTEXT_LOCK:
        return _PROVIDER_CONTEXTS.get(_queue.normalise_url(url))


def provider_poster_url(source, item, extra=None):
    url = _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)
    try:
        filename = (urlsplit(text_type(url or u"")).path.rsplit("/", 1)[-1]).lower()
        if py27_fullmatch(r"(?:no[_-]?(?:title|poster|image)|nopic|placeholder|default[_-]?poster)(?:[_-][a-z0-9]+)?\.(?:jpe?g|png|webp)", filename):
            return ""
    except Exception:
        pass
    _remember_provider(url, source)
    return url


def tmdb_poster_url(value):
    """Accept an absolute image URL or TMDb poster_path, never a backdrop."""
    value = text_type(value or u"").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        return "https://image.tmdb.org/t/p/w500" + value
    return value if value.startswith(("https://", "http://")) else ""


def cached(url):
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None, source=None):
    from .unified_genre_artwork import request as genre_request
    return genre_request(url, KIND, callback=callback, priority=priority,
                         errback=errback, source=source)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)


def usable_poster_file(path, minimum_bytes=128):
    """Reject HTML/error pages in cached posters, keep current fallback logic."""
    return _queue.valid_image_file(path, minimum_bytes)
