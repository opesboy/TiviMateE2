# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import json_dump_text

import io
import json
import ssl
import sys

from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen


def _open_url(request, timeout):
    # Default HTTPS validation: never silently trust an invalid certificate.
    return urlopen(request, timeout=timeout)


def main():
    if len(sys.argv) < 3:
        return 2
    url, out = sys.argv[1], sys.argv[2]
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/0.6.3",
        "Accept": "application/json,*/*",
    })
    response = _open_url(request, 10)
    try:
        data = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    parsed = json.loads(data.decode("utf-8", "replace"))
    with io.open(out, "w", encoding="utf-8") as handle:
        json_dump_text(parsed, handle, ensure_ascii=False)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception:
        raise SystemExit(1)
