# -*- coding: utf-8 -*-
"""Cached, transparent circular Live-favourites picons for Python 2 DreamOS.

Picon downloads remain in the existing artwork queue. This *bounded* worker
only converts files already saved locally, never touches the source image and
never decodes/re-encodes on the Enigma2 GUI thread. Native PNG fallback avoids
relying on Pillow on DreamOS for common PNG provider logos.
"""
from __future__ import absolute_import

import hashlib
import os
import struct
import subprocess
import threading
import zlib

from .storage import data_path
from .py27_compat import which, subprocess_run
from .py27_futures import ThreadPoolExecutor

_SIZE = 130
_VERSION = 'fav-live-circle-r3'
_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='TiviFavLiveCircle')
_LOCK = threading.RLock()
_PENDING = {}
_MAX_PENDING = 12

# DreamOS frequently has neither Pillow nor fast image conversion utilities.
# Never run the legacy pure-Python full-resolution PNG decoder in background
# just to decorate favourite picons: it contends with the Enigma UI thread.
_FAST_CONVERTER = None


def fast_converter_available():
    global _FAST_CONVERTER
    if _FAST_CONVERTER is not None:
        return _FAST_CONVERTER
    try:
        from PIL import Image
        _FAST_CONVERTER = True
    except ImportError:
        _FAST_CONVERTER = bool(which('ffmpeg') or which('convert'))
    return _FAST_CONVERTER


def _bytes(value):
    """Encode a bytearray on Python 2 or 3 without assuming str(bytearray)."""
    return struct.pack('%dB' % len(value), *value)


def _png_chunk(tag, body):
    content = tag + body
    return struct.pack('!I', len(body)) + content + struct.pack('!I', zlib.crc32(content) & 0xffffffff)


def _write_png(path, width, height, rgba):
    rows = []
    stride = width * 4
    for y in range(height):
        rows.append(b'\x00' + _bytes(rgba[y * stride:(y + 1) * stride]))
    data = (b'\x89PNG\r\n\x1a\n' +
            _png_chunk(b'IHDR', struct.pack('!2I5B', width, height, 8, 6, 0, 0, 0)) +
            _png_chunk(b'IDAT', zlib.compress(b''.join(rows), 5)) +
            _png_chunk(b'IEND', b''))
    with open(path, 'wb') as handle:
        handle.write(data)


def _read_png(path):
    """Read non-interlaced 8/4/2/1-bit PNG via stdlib (RGB/RGBA/gray/indexed)."""
    with open(path, 'rb') as handle:
        blob = handle.read(16 * 1024 * 1024 + 1)
    if len(blob) > 16 * 1024 * 1024 or not blob.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('Not a supported PNG')
    at = 8
    width = height = depth = typ = None
    pal = b''
    trans = b''
    chunks = []
    while at + 12 <= len(blob):
        n = struct.unpack('!I', blob[at:at+4])[0]
        tag = blob[at+4:at+8]
        if n > 16 * 1024 * 1024 or at+12+n > len(blob):
            raise ValueError('Broken PNG chunk')
        body = blob[at+8:at+8+n]
        if tag == b'IHDR':
            width, height, depth, typ, comp, filt, interlace = struct.unpack('!2I5B', body)
            if comp or filt or interlace or width < 1 or height < 1 or width*height > 5000000:
                raise ValueError('Unsupported PNG dimensions/interlace')
        elif tag == b'PLTE': pal = body
        elif tag == b'tRNS': trans = body
        elif tag == b'IDAT': chunks.append(body)
        elif tag == b'IEND': break
        at += 12+n
    channels = {0:1, 2:3, 3:1, 4:2, 6:4}.get(typ)
    if not channels or depth not in (1,2,4,8,16) or (typ in (2,4,6) and depth not in (8,16)):
        raise ValueError('Unsupported PNG color format')
    rowlen = (width * channels * depth + 7) // 8
    step = max(1, (channels*depth+7)//8)
    try:
        dec = zlib.decompress(b''.join(chunks))
    except Exception:
        raise ValueError('Corrupt PNG pixels')
    if len(dec) != height * (rowlen + 1):
        raise ValueError('PNG pixel size mismatch')
    dst = bytearray(width * height * 4)
    prior = bytearray(rowlen)
    at = 0
    transparent_gray = (struct.unpack('!H', trans[:2])[0] if typ == 0 and len(trans) >= 2 else None)
    transparent_rgb = (struct.unpack('!3H', trans[:6]) if typ == 2 and len(trans) >= 6 else None)
    for y in range(height):
        f = dec[at] if isinstance(dec[at], int) else ord(dec[at])
        row = bytearray(dec[at+1:at+1+rowlen]); at += 1 + rowlen
        if f not in (0,1,2,3,4): raise ValueError('Bad PNG scanline filter')
        for i in range(rowlen):
            a = row[i-step] if i>=step else 0
            b = prior[i]
            c = prior[i-step] if i>=step else 0
            if f == 1: predictor = a
            elif f == 2: predictor = b
            elif f == 3: predictor = (a+b)//2
            elif f == 4:
                p = a+b-c; da=abs(p-a); db=abs(p-b); dc=abs(p-c)
                predictor = a if da<=db and da<=dc else (b if db<=dc else c)
            else: predictor = 0
            row[i] = (row[i]+predictor)&255
        prior = row
        for x in range(width):
            if depth == 8:
                base = x*channels
                px = tuple(row[base:base+channels])
            elif depth == 16:
                base = x*channels*2
                px = tuple(row[base+i*2] for i in range(channels))
            else:
                shift = 8-depth-((x*depth)%8)
                px = ((row[(x*depth)//8] >> shift) & ((1<<depth)-1),)
            if typ == 6: r,g,b,a = px
            elif typ == 4: r=g=b=px[0]; a=px[1]
            elif typ == 2:
                r,g,b = px
                a = 0 if transparent_rgb is not None and tuple(int(v>>8) if depth==16 else int(v) for v in transparent_rgb) == (r,g,b) else 255
            elif typ == 3:
                off = px[0]*3
                if off+3>len(pal): raise ValueError('Palette index out of bounds')
                r,g,b = pal[off:off+3]
                if not isinstance(r, int): r,g,b=ord(r),ord(g),ord(b)
                a = trans[px[0]] if px[0]<len(trans) else 255
                if not isinstance(a,int): a=ord(a)
            else:
                v = px[0]
                if depth < 8: v = v*255//((1<<depth)-1)
                r=g=b=v
                a=0 if transparent_gray is not None and px[0] == transparent_gray else 255
            o = (y*width+x)*4
            dst[o:o+4] = bytearray((r,g,b,a))
    return width, height, dst


def _compose(width, height, rgba, target):
    """Letterbox whole logo; clip outer image to a real transparent circle."""
    if width <= 0 or height <= 0: raise ValueError('Empty picon')
    limit = int(_SIZE*0.87)
    ratio = min(float(limit)/width, float(limit)/height)
    neww = max(1, min(limit, int(round(width*ratio))))
    newh = max(1, min(limit, int(round(height*ratio))))
    ox = (_SIZE-neww)//2
    oy = (_SIZE-newh)//2
    out = bytearray(_SIZE*_SIZE*4)
    for y in range(newh):
        sy = min(height-1, int((y+.5)*height/newh))
        for x in range(neww):
            sx = min(width-1, int((x+.5)*width/neww))
            i = (sy*width+sx)*4
            j = ((y+oy)*_SIZE+x+ox)*4
            out[j:j+4] = rgba[i:i+4]
    # A soft 1.5-pixel outer edge prevents jagged circular edges.
    radius = (_SIZE-2)/2.0
    cx = cy = (_SIZE-1)/2.0
    for y in range(_SIZE):
        for x in range(_SIZE):
            j = (y*_SIZE+x)*4+3
            if not out[j]: continue
            distance = ((x-cx)**2+(y-cy)**2)**0.5
            fade = max(0., min(1., radius-distance))
            out[j] = int(out[j]*fade)
    _write_png(target, _SIZE, _SIZE, out)


def _create(path, target):
    try:
        from PIL import Image, ImageDraw
        im = Image.open(path)
        try:
            im = im.convert('RGBA')
            limit = int(_SIZE*0.87)
            method = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
            im.thumbnail((limit,limit), method)
            canvas = Image.new('RGBA', (_SIZE,_SIZE), (0,0,0,0))
            canvas.paste(im, ((_SIZE-im.width)//2, (_SIZE-im.height)//2))
            mask = Image.new('L', (_SIZE,_SIZE), 0)
            ImageDraw.Draw(mask).ellipse((1,1,_SIZE-2,_SIZE-2), fill=255)
            from PIL import ImageChops
            canvas.putalpha(ImageChops.multiply(canvas.getchannel('A'), mask))
            canvas.save(target, 'PNG')
            return
        finally:
            try: im.close()
            except Exception: pass
    except (ImportError, OSError, IOError, ValueError, AttributeError):
        pass
    # Do not fully decode large PNGs pixel-by-pixel in Python 2.7.
    # Receiver CPU time matters more than creating a decorative mask.
    # JPEG/WebP/unsupported PNG: use existing system tools if available.
    temp = target+'.source.png'
    try:
        ffmpeg = which('ffmpeg')
        convert = which('convert')
        if ffmpeg:
            subprocess_run([ffmpeg, '-nostdin','-loglevel','error','-y','-i',path,
                            '-vf','scale=112:112:force_original_aspect_ratio=decrease',
                            '-frames:v','1',temp], timeout=9, check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif convert:
            subprocess_run([convert,path,'-resize','112x112',temp],timeout=9,check=True,
                           stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        else:
            raise ValueError('No available JPEG converter')
        w,h,rgba = _read_png(temp)
        _compose(w,h,rgba,target)
    finally:
        try:
            if os.path.exists(temp): os.unlink(temp)
        except Exception: pass


def _target(path):
    st = os.stat(path)
    identity = ('%s|%s|%s|%s' % (os.path.realpath(path),st.st_size,int(st.st_mtime),_VERSION))
    digest = hashlib.sha1(identity.encode('utf-8')).hexdigest()[:24]
    return data_path('favorites_live_circles','picon_%s.png' % digest)


def cached(path):
    try:
        if not path or not os.path.isfile(path): return ''
        result = _target(path)
        if os.path.isfile(result) and os.path.getsize(result)>100: return result
    except Exception:
        pass
    return ''


def request(path, callback):
    """Return a cached pathname, True when queued, or False on queue failure."""
    hit = cached(path)
    if hit: return hit
    if not fast_converter_available(): return False
    try:
        from twisted.internet import reactor
        if not hasattr(reactor,'callFromThread') or not os.path.isfile(path): return False
        target = _target(path)
    except Exception:
        return False
    with _LOCK:
        if target in _PENDING:
            if len(_PENDING[target]) < 16: _PENDING[target].append(callback)
            return True
        if len(_PENDING) >= _MAX_PENDING: return False
        _PENDING[target] = [callback]
    def work():
        result = ''
        temp = target+'.%d.%d.png' % (os.getpid(),threading.current_thread().ident or 0)
        try:
            if not cached(path):
                _create(path,temp)
                if os.path.isfile(temp) and os.path.getsize(temp)>100:
                    os.rename(temp,target)
            if os.path.isfile(target): result=target
        except Exception as exc:
            print('[TiviMateE2Py27] favorite circle conversion: %s' % exc)
        finally:
            try:
                if os.path.exists(temp): os.unlink(temp)
            except Exception: pass
            with _LOCK:
                callbacks=_PENDING.pop(target,[])
            for cb in callbacks:
                try: reactor.callFromThread(cb,result)
                except Exception: pass
    try:
        _POOL.submit(work)
        return True
    except Exception:
        with _LOCK: _PENDING.pop(target,None)
        return False
