# -*- coding: utf-8 -*-
"""Local package-footer logos for the 12-card GENRE packages screen.

Recognize platform and genre names in Arabic or English, without modifying
category titles, IDs, sorting, artwork caches or underlying provider data.
All images ship with the IPK: no runtime downloads, fonts, Pillow or API calls.
Unknown names retain their original text.
"""
from __future__ import absolute_import
import os
import re
import unicodedata
from Plugins.Extensions.TiviMateE2Py27.py27_compat import lru_cache, digits_translation_table, text_type

_BADGES = os.path.join(os.path.dirname(__file__), 'skins', 'genre', 'package_badges')
_DIGITS = digits_translation_table()
_MARKS = re.compile(u'[ً-ٰٟـ]')
_ARABIC = re.compile(u'[\u0600-ۿ]')
_YEAR = re.compile(r'(?<!\d)(19\d{2}|20\d{2})(?!\d)')
# Real 4K/UHD package names have their own logo in GENRE; avoid labelling
# a full provider package as 4K unless the package name itself says so.
_QUALITY_4K = re.compile(r'(?:^|\s)(?:4k|uhd|2160p|ultra hd|فوركي|فور كيه|فور كاي)(?:\s|$)', re.I)

# Names alone are ambiguous (e.g. ARABIC SERIES); package kind is authoritative.
_REGIONAL_GENRES = frozenset(('arabic', 'foreign', 'indian', 'asian'))
_SERIES_HINTS = frozenset(('series', 'serial', 'serials', 'show', 'shows', 'tvshows',
                           'مسلسل', 'مسلسلات', 'مسلسله', 'مسلسلاتي', 'دراما تلفزيونيه'))
_MOVIE_HINTS = frozenset(('movie', 'movies', 'film', 'films', 'vod', 'cinema',
                           'فيلم', 'افلام', 'سينما'))

# Longer/more specific brands first; platform identification overrides genres.
_BRANDS = (
    ('apple', ('apple', 'apple tv', 'ابل', 'آبل', 'ابل تي في', 'ابل+', 'apple+')),
    ('netflix', ('netflix', 'netflex', 'نتفليكس', 'نتفلكس', 'نيتفليكس')),
    ('disney', ('disney', 'ديزني', 'دزني')),
    ('prime', ('amazon prime', 'prime video', 'prime', 'amazon', 'amzn', 'امازون', 'أمازون', 'امازون برايم', 'برايم')),
    ('paramount', ('paramount', 'باراماونت', 'بارامونت')),
    ('marvel', ('marvel', 'مارفل', 'مارفيل')),
    ('universal', ('universal', 'يونيفرسال')),
    ('illumination', ('illumination', 'إلومينيشن', 'الومينيشن')),
    ('dreamworks', ('dreamworks', 'دريم ووركس', 'دريموركس')),
    ('warner', ('warner bros', 'warner', 'وارنر')),
    ('pixar', ('pixar', 'بيكسار', 'بكسار')),
    ('shahid', ('shahid', 'شاهد', 'شاهد vip')),
    ('watchit', ('watch it', 'watchit', 'واتش ات', 'واتشيت')),
    ('max', ('hbo max', 'max', 'ماكس')),
    ('hbo', ('hbo', 'اتش بي او', 'إتش بي أو')),
    ('starz', ('starz', 'starzplay', 'ستارز')),
    ('osn', ('osn', 'او اس ان', 'اوس ان', 'اوسن')),
    ('mbc', ('mbc', 'ام بي سي', 'امبيسي')),
    ('hulu', ('hulu', 'هولو')),
    ('dc', ('dc comics', 'dc', 'دي سي')),
    ('viu', ('viu', 'فيو')),
    ('tod', ('tod', 'تود')),
    ('rotana', ('rotana', 'روتانا')),
    ('stc', ('stc', 'اس تي سي')),
    ('ufc', ('ufc', 'يو اف سي')),
    ('wwe', ('wwe', 'دبليو دبليو اي', 'دبليو دبليو ايه', 'دبليو دبليو إي', 'دبليو دبليو إيه')),
    ('youtube', ('youtube', 'يوتيوب')),
)

_GENRES = (
    ('wrestling', ('wrestling', 'pro wrestling', 'مصارعة', 'مصارعه', 'المصارعة', 'المصارعه')),
    # Prefer Ramadan branding to generic latest/series/drama genre matches.
    # Brand-specific platforms retain their existing priority above genres.
    ('ramadan', ('ramadan', 'ramadhan', 'ramazan',
                 'رمضان', 'رمضاني', 'رمضانية', 'رمضانيات', 'رمضان كريم')),
    ('recent_series', ('recent series', 'recent added series', 'recent added tv shows', 'latest series', 'new series', 'احدث مسلسلات', 'مسلسلات جديده', 'مسلسلات مضافه حديثا', 'المضافه حديثا مسلسلات')),
    ('recent_movies', ('recent movies', 'recent added movies', 'latest movies', 'new movies', 'احدث افلام', 'افلام جديده', 'افلام حديثه', 'افلام مضافه حديثا', 'المضافه حديثا افلام')),
    ('scifi', ('science fiction', 'sci fi', 'sci-fi', 'scifi', 'خيال علمي', 'خيال العلمي')),
    ('romance', ('romance', 'romantic', 'love stories', 'رومانس', 'رومانسي', 'رومانسيه', 'حب وعشق')),
    ('horror', ('horror', 'scary', 'رعب', 'الرعب', 'افلام مخيفه')),
    ('war', ('war', 'wars', 'warfare', 'military', 'حرب', 'حربي', 'حربيه', 'حروب', 'عسكريه')),
    ('crime', ('crime', 'criminal', 'gangster', 'جريمه', 'الجريمه', 'جرائم', 'جنايات', 'بوليسي')),
    ('comedy', ('comedy', 'comedies', 'كوميدي', 'كوميديا', 'كوميديه')),
    ('thriller', ('thriller', 'thrillers', 'suspense', 'اثاره', 'تشويق', 'مشوقه')),
    ('action', ('action', 'اكشن', 'اكشنات', 'حركه')),
    ('adventure', ('adventure', 'adventures', 'مغامره', 'مغامرات')),
    ('documentary', ('documentary', 'documentaries', 'وثائقي', 'وثائقيات')),
    ('animation', ('animation', 'cartoon', 'cartoons', 'انيميشن', 'كرتون', 'رسوم متحركه')),
    ('anime', ('anime', 'انمي', 'انيمي')),
    ('fantasy', ('fantasy', 'فانتازيا', 'فانتازي', 'خياليه')),
    ('mystery', ('mystery', 'mysteries', 'غموض', 'غامضه')),
    ('family', ('family', 'families', 'عائليه', 'عائلي', 'اسريه')),
    ('western', ('western', 'westerns', 'وسترن', 'كاوبوي')),
    ('theatre', ('theatre', 'theater', 'plays', 'مسرح', 'مسرحيات')),
    ('music', ('music', 'musical', 'موسيقي', 'موسيقيه', 'اغاني')),
    ('kids', ('kids', 'children', 'اطفال', 'للأطفال', 'للأولاد')),
    ('foreign', ('foreign', 'english movies', 'افلام اجنبيه', 'اجنبيه', 'اجنبي', 'اجانب')),
    ('indian', ('indian', 'bollywood', 'هندي', 'هنديه', 'هنديه')),
    ('asian', ('asian', 'korean', 'chinese', 'اسيوي', 'اسيويه', 'كوري', 'كوريه', 'صيني', 'صينيه')),
    ('arabic', ('arabic', 'arab movies', 'arabian', 'عربي', 'عربيه', 'عربى')),
    ('drama', ('drama', 'دراما', 'درامي', 'دراميه')),
    ('top', ('imdb top', 'top rated', 'top 250', 'الاعلي تقييما', 'الافضل تقييما')),
    ('series', ('series', 'tv shows', 'shows', 'مسلسل', 'مسلسلات')),
    ('movies', ('movies', 'films', 'movie', 'film', 'افلام', 'فيلم')),
)

def _norm(s):
    s = unicodedata.normalize('NFKC', text_type(s or '')).translate(_DIGITS).lower()
    s = _MARKS.sub('', s)
    for a,b in (('أ','ا'),('إ','ا'),('آ','ا'),('ى','ي'),('ة','ه'),('ؤ','و')):
        s=s.replace(a,b)
    return re.sub(u'[^a-z0-9ء-ي]+', ' ', s).strip()


def _strip_arabic_articles(value):
    """Compare Arabic names with/without ال without changing stored titles.

    Only add article-free match variants; preserve the original spelling so
    existing English/Arabic brand aliases and exact matches keep working.
    """
    words = []
    for word in value.split():
        if word.startswith('ال') and len(word) > 4:
            words.append(word[2:])
        elif word.startswith('لل') and len(word) > 4:
            words.append(word[2:])
        else:
            words.append(word)
    return ' '.join(words)


def _match(tokens, compact, phrase):
    phrase = _norm(phrase)
    if not phrase:
        return False
    candidates = (compact, _strip_arabic_articles(compact))
    variants = (phrase, _strip_arabic_articles(phrase))
    # Keep word/phrase boundaries: "war" must not match "warner" and
    # "max" must not match arbitrary words containing those letters.
    for part in variants:
        if not part:
            continue
        for candidate in candidates:
            if ' ' + part + ' ' in ' ' + candidate + ' ':
                return True
    return False


def _file(key, arabic, compact):
    # Keep all logo files in GENRE's single canonical folder.  Do not silently
    # reinterpret unknown region labels as MOVIES: a series row can legitimately
    # contain an English-only region name.
    suffix = 'compact' if compact else 'full'
    if key == 'arabic' and not arabic:
        key = 'movies'
    name = 'badge_%s_%s%s.png' % (key, 'ar_' if arabic else '', suffix)
    path = os.path.join(_BADGES, name)
    return path if os.path.isfile(path) else ''


def _media_kind(kind, tokens):
    k = str(kind or '').strip().lower()
    if k in ('series', 'tv', 'tvshows', 'shows', 'tv_shows'):
        return 'series'
    if k in ('vod', 'movie', 'movies', 'film', 'films'):
        return 'vod'
    # Standalone badge calls (outside a Movies/TV Shows page) must still
    # recognize 'Arabic Series' and similar multilingual package names.
    if tokens.intersection(_SERIES_HINTS):
        return 'series'
    if tokens.intersection(_MOVIE_HINTS):
        return 'vod'
    return ''

@lru_cache(maxsize=512)
def resolve_package_badge(name, kind=None):
    """Return (badge PNG, year PNG), or ('','') for unchanged text fallback."""
    if not name:
        return '', ''
    n = _norm(name)
    words = set(n.split()) | set(_strip_arabic_articles(n).split())
    year_match = _YEAR.search(n)
    year = int(year_match.group(1)) if year_match else 0
    year_path = os.path.join(_BADGES, 'year_%d.png' % year) if year else ''
    if year_path and not os.path.isfile(year_path):
        year_path = ''
    has_arabic = bool(_ARABIC.search(text_type(name)))
    media_kind = _media_kind(kind, words)
    # 4K is an explicit package label (not guessed from posters/TMDb).
    # Give it a dedicated badge even in labels like '4K Movies' or
    # 'NETFLIX UHD', while keeping the year and every other badge intact.
    quality_badge = bool(_QUALITY_4K.search(n))
    match = None
    genre = False
    for key,aliases in _BRANDS:
        if any(_match(words,n,alias) for alias in aliases):
            match = key
            break
    if not match:
        for key,aliases in _GENRES:
            if any(_match(words,n,alias) for alias in aliases):
                match = key
                genre = True
                break
    if not match:
        if quality_badge:
            return _file('4k', False, bool(year_path)), year_path
        return '', ''
    # Provider/platform brands are shared across Movies and TV Shows.
    # Non-brand region badges, however, often literally say 'MOVIES' or
    # 'أفلام'.  Never display those inside a TV Shows category.
    variant = match
    if genre:
        if match in _REGIONAL_GENRES and media_kind == 'series':
            # Country-specific TV-series badges exist for Arabic-language
            # names. English-only names use the generic SERIES logo instead
            # of an incorrectly labelled MOVIES badge.
            variant = match + '_series' if has_arabic else 'series'
        elif match in _REGIONAL_GENRES and media_kind == 'vod':
            variant = match
        elif match in ('movies', 'series') and media_kind:
            variant = 'series' if media_kind == 'series' else 'movies'
        elif match in ('recent_movies', 'recent_series') and media_kind:
            variant = 'recent_series' if media_kind == 'series' else 'recent_movies'
    badge = _file(variant, has_arabic and genre, bool(year_path))
    # Prefer the English variant of the SAME badge when Arabic assets are absent.
    # Do not replace platform logos with an unrelated generic quality label.
    if not badge and has_arabic and genre:
        badge = _file(variant, False, bool(year_path))
    # Prefer full/compact counterpart when a year-specific variant is absent.
    if not badge:
        badge = _file(variant, has_arabic and genre, not bool(year_path))
    if not badge:
        badge = _file(variant, False, not bool(year_path))
    # If a specific localized file does not exist, use the matching media
    # fallback, not an unrelated movie icon or missing/blank badge.
    if not badge and media_kind and genre:
        badge = _file('series' if media_kind == 'series' else 'movies', has_arabic, bool(year_path))
    return (badge, year_path) if badge else ('','')
