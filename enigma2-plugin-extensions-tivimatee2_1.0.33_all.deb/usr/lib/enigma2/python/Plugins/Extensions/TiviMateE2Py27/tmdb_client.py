# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import fullmatch as py27_fullmatch, text_type, which, subprocess_run
from .storage import get_data_root, data_path
from .compat import atomic_replace, ensure_dir, open_text
import os, json, re, ssl, traceback, subprocess, time, hashlib, unicodedata, difflib, threading, copy
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen, HTTPError
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode

CONFIG_DIR = get_data_root()
CONFIG_FILE = data_path("tmdb.json")
API_BASE = "https://api.themoviedb.org/3"
IMAGE_BASE = "https://image.tmdb.org/t/p/"
# Shared defaults stay available to every user, but are not stored as plain text.
# User-provided TMDb credentials always override these values.
_TMDB_MASK = 0x5A

def _decode_builtin(values):
    try:
        return "".join(chr(int(value) ^ _TMDB_MASK) for value in values.split(",") if value)
    except Exception:
        return ""

DEFAULT_API_KEY = _decode_builtin("105,57,105,63,60,57,60,110,109,57,105,111,109,109,111,111,98,98,107,104,56,56,99,62,108,110,106,107,99,62,108,111")
DEFAULT_API_KEY2 = _decode_builtin("106,105,63,109,107,109,98,59,63,59,98,60,56,105,109,98,98,98,99,108,56,99,63,107,98,59,99,110,99,105,63,60")
DEFAULT_ACCESS_TOKEN = _decode_builtin("63,35,16,50,56,29,57,51,21,51,16,19,15,32,19,107,20,51,16,99,116,63,35,16,50,62,13,11,51,21,51,19,45,23,104,15,105,23,14,57,110,3,13,12,50,21,29,0,51,23,32,57,110,21,30,61,111,20,55,19,111,0,14,31,110,3,14,49,106,21,14,20,54,0,51,19,41,19,55,111,51,0,51,19,108,23,14,3,32,20,32,19,104,21,30,3,45,20,25,110,107,23,30,31,41,19,52,20,107,3,51,19,108,19,48,3,34,21,14,0,51,3,32,62,48,3,32,24,50,0,14,23,104,23,30,27,106,20,29,3,35,23,29,8,51,20,35,19,41,19,52,20,48,56,105,24,54,57,35,19,108,13,35,16,50,57,29,54,60,57,55,12,50,0,25,16,62,22,25,16,104,0,2,16,32,59,13,99,47,19,48,53,34,60,11,116,49,60,42,61,104,99,46,19,2,40,13,99,60,42,2,51,45,51,29,16,41,43,5,105,61,108,21,56,27,2,48,45,24,13,35,29,15,21,60,18,32,56,3")



def _tmdb_normalize_unicode_digits(value):
    """Normalize Arabic-Indic and other Unicode decimal digits for TMDb queries."""
    out = []
    for ch in text_type(value or ""):
        try:
            if ch.isdigit():
                out.append(str(unicodedata.digit(ch)))
            else:
                out.append(ch)
        except Exception:
            out.append(ch)
    return u"".join(out)

def _tmdb_extract_year(title, explicit_year=None):
    """Return a safe 4-digit release year from provider metadata or title."""
    value = _tmdb_normalize_unicode_digits(explicit_year)
    m = re.search(r"\b((?:19|20)\d{2})\b", value)
    if m:
        return m.group(1)
    m = re.search(r"(?:^|[^0-9])((?:19|20)\d{2})(?:[^0-9]|$)", _tmdb_normalize_unicode_digits(title))
    return m.group(1) if m else None


def _tmdb_script_group(ch):
    """Broad script group for multilingual IPTV titles.

    Digits/punctuation are neutral and get attached to their neighboring title.
    This is intentionally provider-agnostic: it is only used to create alternate
    TMDb queries and never changes the visible title in the UI.
    """
    try:
        code = ord(ch)
    except Exception:
        return "neutral"
    if ch.isdigit() or ch.isspace() or ch in u"-–—:|/\\+.,'’\"()[]{}&!؟":
        return "neutral"
    if (0x0041 <= code <= 0x024F) or (0x1E00 <= code <= 0x1EFF):
        return "latin"
    if (0x0600 <= code <= 0x06FF) or (0x0750 <= code <= 0x077F) or (0x08A0 <= code <= 0x08FF):
        return "arabic"
    if (0x0400 <= code <= 0x052F):
        return "cyrillic"
    if (0x0370 <= code <= 0x03FF):
        return "greek"
    if (0x0900 <= code <= 0x097F):
        return "devanagari"
    if (0x3040 <= code <= 0x30FF):
        return "japanese"
    if (0xAC00 <= code <= 0xD7AF):
        return "korean"
    if (0x3400 <= code <= 0x9FFF):
        return "cjk"
    if (0x0E00 <= code <= 0x0E7F):
        return "thai"
    if (0x0590 <= code <= 0x05FF):
        return "hebrew"
    return "other"



# Title-language hint for TMDb lookups (Dutch, French, ... catalogues).
# TMDb returns the localized title only in the requested language, so a
# Dutch title ("De Leeuwenkoning") never matched when we searched in the
# device language + en/de/ar: no backdrop, logo or actors appeared.
_TMDB_PREFIX_LANG = {
    "NL": "nl-NL", "DUT": "nl-NL", "BE": "nl-NL", "VL": "nl-NL", "FL": "nl-NL",
    "FR": "fr-FR", "FRE": "fr-FR", "FRA": "fr-FR", "VF": "fr-FR", "VFF": "fr-FR", "VOSTFR": "fr-FR",
    "DE": "de-DE", "GER": "de-DE", "DEU": "de-DE", "AT": "de-DE", "CH": "de-DE",
    "ES": "es-ES", "SPA": "es-ES", "LAT": "es-MX", "MX": "es-MX",
    "IT": "it-IT", "ITA": "it-IT", "TR": "tr-TR", "TUR": "tr-TR",
    "PT": "pt-PT", "POR": "pt-PT", "BR": "pt-BR", "PL": "pl-PL", "POL": "pl-PL",
    "SE": "sv-SE", "SV": "sv-SE", "SWE": "sv-SE", "NO": "no-NO", "NOR": "no-NO",
    "DK": "da-DK", "DA": "da-DK", "DAN": "da-DK", "FI": "fi-FI", "FIN": "fi-FI",
    "RU": "ru-RU", "RUS": "ru-RU", "GR": "el-GR", "EL": "el-GR", "GRE": "el-GR",
    "RO": "ro-RO", "HU": "hu-HU", "CZ": "cs-CZ", "CS": "cs-CZ", "AL": "sq-AL",
    "IR": "fa-IR", "FA": "fa-IR", "IN": "hi-IN", "HI": "hi-IN", "KR": "ko-KR", "JP": "ja-JP",
}
_TMDB_LANG_HINT = {"lang": None}


def _tmdb_title_language(title):
    """'NL - Titel', 'NL| Titel', '[NL] Titel', 'Titel (NL)' -> 'nl-NL'."""
    text = str(title or "").strip()
    match = (re.match(r"^\s*[\[(]?\s*([A-Za-z]{2,6})\s*[\])]?\s*[|:\-\u2013\u2022/]+", text) or
             re.match(r"^\s*[\[(]\s*([A-Za-z]{2,6})\s*[\])]", text) or
             re.search(r"[\[(]\s*([A-Za-z]{2,6})\s*[\])]\s*$", text))
    if not match:
        # 'NL Un bon avocat': an upper-case country code and a space.
        match = re.match(r"^\s*([A-Z]{2,3})\s+(?=\S+\s+\S)", text)
    if match:
        lang = _TMDB_PREFIX_LANG.get(match.group(1).upper())
        if lang:
            _TMDB_LANG_HINT["lang"] = lang      # learned for this server's other titles
            return lang
    return None

def _tmdb_bracket_titles(title):
    """'Un bon avocat [The Good Lawyer]' -> ['Un bon avocat', 'The Good Lawyer'].

    IPTV catalogues often show the local title with the original title in
    brackets. Each part is searched on its own; the combined string with
    brackets never matched TMDb.
    """
    text = str(title or "")
    match = re.search(r"^(.*?)[\[(]\s*([^\[\]()]{3,})\s*[\])](.*)$", text)
    if not match:
        return []
    inside = match.group(2).strip()
    if len(inside.split()) < 2:
        return []          # "Alien (Romulus)": one word is a subtitle, not a title
    if re.fullmatch(r"(?i)\s*(?:19|20)\d{2}\s*|[A-Z]{2,4}|\d+p|4k|hd|fhd|uhd|multi.*|sub.*|vost.*", inside):
        return []
    out = []
    for part in (match.group(1) + " " + match.group(3), inside):
        cands = _tmdb_title_candidates(part)
        if cands:
            value = re.sub(r"[\[\]()]", " ", cands[0])
            value = " ".join(value.split()).strip(" -|:_")
            if len(value) >= 3 and value not in out:
                out.append(value)
    return out if len(out) == 2 else []



def _tmdb_title_locales(title):
    """Add one original-script query locale without excluding any other one.

    TMDb search accepts Unicode titles, but results/localized aliases may only
    be returned or verified in their own language. Keep the configured UI
    language; this hint is used only for artwork identity lookup.
    """
    names = {'arabic': 'ar-AE', 'cyrillic': 'ru-RU', 'greek': 'el-GR',
             'devanagari': 'hi-IN', 'japanese': 'ja-JP', 'korean': 'ko-KR',
             'cjk': 'zh-CN', 'thai': 'th-TH', 'hebrew': 'he-IL'}
    counts = {}
    for ch in text_type(title or u''):
        script = _tmdb_script_group(ch)
        if script in names:
            counts[script] = counts.get(script, 0) + 1
    if not counts:
        return ()
    winner = max(counts, key=lambda name: counts[name])
    if winner == 'cjk':
        # Han characters occur in both Chinese and Japanese titles. Try
        # both rather than assuming one language from the glyphs alone.
        return ('zh-CN', 'ja-JP')
    return (names[winner],)


def _tmdb_multiscript_candidates(value):
    """Split a cleaned mixed-language title into usable per-script alternatives."""
    value = re.sub(r"\s+", u" ", text_type(value or "")).strip(" -|:_")
    if not value:
        return []

    runs = []
    current = []
    current_script = None

    def emit(chars):
        part = re.sub(r"\s+", " ", "".join(chars)).strip(" -|:_")
        if part and any(ch.isalpha() for ch in part):
            runs.append(part)

    for ch in value:
        script = _tmdb_script_group(ch)
        if script == "neutral":
            current.append(ch)
            continue

        if current_script is None:
            current_script = script
            current.append(ch)
            continue

        if script == current_script or script == "other" or current_script == "other":
            current.append(ch)
            if current_script == "other" and script != "other":
                current_script = script
            continue

        # Script changed. Remove separator whitespace/punctuation from the prior
        # run before emitting it. Neutral digits are kept with the side they
        # naturally belong to, but are never allowed to truncate words.
        trailing = []
        while current and _tmdb_script_group(current[-1]) == "neutral":
            trailing.insert(0, current.pop())
        emit(current)

        # Carry only leading digits from the neutral bridge to the new title,
        # e.g. "6 أيام". Normal separators stay discarded.
        carry = "".join(trailing).strip()
        current = ([carry + " "] if carry and any(c.isdigit() for c in carry) else [])
        current.append(ch)
        current_script = script

    emit(current)

    out = []
    for part in runs:
        part = re.sub(r"^[\W_]+|[\W_]+$", "", part, flags=re.UNICODE).strip()
        if len(part) >= 2 and part not in out:
            out.append(part)
    return out


def _tmdb_title_candidates(title):
    """Generate aggressive-but-safe TMDb title candidates for IPTV catalogs.

    The provider title shown in the UI is never changed.  Only TMDb search
    queries use these variants.  Instead of one destructive cleanup pass, this
    function returns several ordered candidates from strict to relaxed.
    """
    raw = text_type(_tmdb_normalize_unicode_digits(title)).strip()
    if not raw:
        return []

    # Normalise Unicode presentation forms without transliterating real words.
    try:
        raw_nfkc = unicodedata.normalize("NFKC", raw)
    except Exception:
        raw_nfkc = raw
    raw_nfkc = raw_nfkc.replace("_", " ").replace("\\/", "/")
    raw_nfkc = re.sub(u'[\u200b-\u200f\u202a-\u202e\u2060\ufeff]', "", raw_nfkc)

    out = []
    seen = set()

    def add(value):
        value = text_type(value or "")
        value = value.replace("_", " ")
        value = re.sub(r"\s+", " ", value)
        value = value.strip(" \t\r\n-|:;/._")
        if not value or len(value) < 2 or not any(ch.isalpha() for ch in value):
            return
        key = value.lower() if hasattr(value, "casefold") else value.lower()
        if key in seen:
            return
        seen.add(key)
        out.append(value)

    # Country/language/service/quality/release metadata.  These are removed only
    # when they appear as standalone tags, bracket metadata, or provider chains.
    tags = [
        # Quality / resolution / dynamic range
        r"4K", r"8K", r"UHD", r"FHD", r"FULL\s*HD", r"HD", r"SD",
        r"2160P", r"1440P", r"1080P", r"1080I", r"720P", r"576P", r"480P",
        r"HDR10\+?", r"HDR", r"DV", r"DOLBY\s*VISION", r"HLG",
        r"10BIT", r"8BIT", r"60FPS", r"50FPS", r"30FPS", r"25FPS", r"24FPS",

        # Streaming/provider/source
        r"AMZ", r"AMZN", r"AMAZON", r"AMAZON\s*PRIME", r"PRIME\s*VIDEO",
        r"NF", r"NETFLIX", r"DSNP", r"DISNEY\+?", r"DISNEYPLUS",
        r"APTV", r"ATVP", r"APPLE\s*TV\+?", r"APPLETV\+?",
        r"HMAX", r"HBO\s*MAX", r"HBO", r"MAX", r"HULU", r"SHAHID",
        r"OSN", r"STARZPLAY", r"STARZ", r"PARAMOUNT\+?", r"PMTP",
        r"PEACOCK", r"CRITERION", r"MUBI", r"PLEX",
        r"WEB[- ]?DL", r"WEBDL", r"WEB[- ]?RIP", r"WEBRIP", r"WEB",
        r"BLU[- ]?RAY", r"BLURAY", r"BDRIP", r"BRRIP", r"BDREMUX",
        r"REMUX", r"HDTV", r"PDTV", r"DVDRIP", r"DVD", r"CAM", r"TS",
        r"TELESYNC", r"TC", r"SCR", r"SCREENER",

        # Video codec
        r"HEVC", r"H\.?265", r"H265", r"X265", r"H\.?264", r"H264", r"X264",
        r"AV1", r"VP9", r"MPEG[- ]?2", r"MPEG[- ]?4",

        # Audio
        r"AAC(?:2\.0|5\.1|7\.1)?", r"AC3", r"EAC3", r"E[- ]?AC[- ]?3",
        r"DDP(?:2\.0|5\.1|7\.1)?", r"DD\+?", r"DTS(?:[- ]?HD)?",
        r"DTS[- ]?X", r"TRUEHD", r"ATMOS", r"DOLBY\s*AUDIO",
        r"2\.0CH", r"5\.1CH", r"7\.1CH",

        # Sub/dub/release markers
        r"MULTI", r"MULTI[- ]?AUDIO", r"MULTI[- ]?SUBS?", r"DUAL[- ]?AUDIO",
        r"SUBS?", r"SUBBED", r"HARDSUB", r"HC", r"DUB", r"DUBBED",
        r"ORIGINAL", r"UNCUT", r"EXTENDED", r"THEATRICAL", r"REPACK",
        r"PROPER", r"INTERNAL", r"COMPLETE",

        # Language codes/names
        r"AR", r"ARA", r"ARABIC", r"EN", r"ENG", r"ENGLISH",
        r"FR", r"FRE", r"FRA", r"FRENCH", r"ES", r"SPA", r"SPANISH",
        r"DE", r"GER", r"DEU", r"GERMAN", r"IT", r"ITA", r"ITALIAN",
        r"TR", r"TUR", r"TURKISH", r"PT", r"POR", r"PORTUGUESE",
        r"RU", r"RUS", r"RUSSIAN", r"HI", r"HIN", r"HINDI",
        r"UR", r"URD", r"URDU", r"FA", r"PER", r"FARSI", r"PERSIAN",
        r"KO", r"KOR", r"KOREAN", r"JA", r"JPN", r"JAPANESE",
        r"ZH", r"CHI", r"ZHO", r"CHINESE", r"TH", r"THA", r"THAI",
        r"HE", r"HEB", r"HEBREW", r"NL", r"DUT", r"DUTCH",
        r"PL", r"POL", r"POLISH", r"RO", r"RON", r"ROMANIAN",
        r"SV", r"SWE", r"SWEDISH", r"NO", r"NOR", r"NORWEGIAN",
        r"DA", r"DAN", r"DANISH", r"FI", r"FIN", r"FINNISH",
        r"EL", r"GRE", r"GREEK", r"CS", r"CZE", r"CZECH",
        r"HU", r"HUN", r"HUNGARIAN", r"ID", r"IND", r"INDONESIAN",
        r"MS", r"MAY", r"MALAY", r"BN", r"BEN", r"BENGALI",
        r"PA", r"PAN", r"PUNJABI", r"TA", r"TAM", r"TAMIL",
        r"TE", r"TEL", r"TELUGU", r"ML", r"MAL", r"MALAYALAM",

        # Country/region codes commonly inserted by IPTV servers
        r"US", r"USA", r"UK", r"GB", r"UAE", r"AE", r"KSA", r"SA",
        r"IN", r"INDIA", r"CA", r"CAN", r"AU", r"AUS", r"NZ",
        r"FRANCE", r"GERMANY", r"ITALY", r"SPAIN", r"TURKEY",
        r"RUSSIA", r"JAPAN", r"KOREA", r"CHINA", r"EG", r"EGYPT",
        r"MA", r"MOROCCO", r"DZ", r"ALGERIA", r"TN", r"TUNISIA",
        r"QA", r"QATAR", r"KW", r"KUWAIT", r"BH", r"BAHRAIN", r"OM", r"OMAN",
    ]
    tag = r"(?:" + "|".join(tags) + r")"

    # Preserve useful title material inside brackets before removing metadata.
    # Example: "Alien (Romulus)" remains available as a candidate, while
    # "(2025) (IN) [1080p]" is treated as metadata.
    work0 = raw_nfkc

    # Explicit year is passed separately to TMDb, never kept in cleaned queries.
    yearless = re.sub(
        r"(?<!\d)[\[(]?\s*(?:19|20)\d{2}\s*[\])]?(?!\d)",
        " ", work0
    )

    # Remove season/episode markers only as metadata suffix/prefix.  Keep the
    # base series name as a candidate.
    seasonless = re.sub(
        r"(?i)(?:\bS(?:EASON)?\s*\d{1,2}\b|\bE(?:P(?:ISODE)?)?\s*\d{1,3}\b|"
        r"\bS\d{1,2}E\d{1,3}\b|\b\d{1,2}X\d{1,3}\b)",
        " ", yearless
    )

    # Remove technical metadata in any bracket style.
    bracket_clean = seasonless
    for _ in range(10):
        before = bracket_clean
        bracket_clean = re.sub(
            r"[\[\(\{]\s*(?:" + tag + r")"
            r"(?:\s*[-|+/.,]\s*(?:" + tag + r"))*\s*[\]\)\}]",
            " ", bracket_clean, flags=re.I
        )
        if bracket_clean == before:
            break

    # Compact provider chains: "4K-AMZ-AR-DO - TITLE", "FHD.NF.EN | TITLE".
    # The unknown short token (e.g. DO) is removed only when the same chain also
    # contains at least one known metadata tag.
    chain_clean = bracket_clean
    compact = re.match(
        r"^\s*([A-Z0-9+]{1,8}(?:\s*[-|:/+.]\s*[A-Z0-9+]{1,8}){1,10})"
        r"\s*(?:-\s+|\|\s+|:\s+)(.+)$",
        chain_clean
    )
    if compact:
        chain, tail = compact.group(1), compact.group(2).strip()
        parts = [p for p in re.split(r"\s*[-|:/+.]\s*", chain) if p]
        known = any(py27_fullmatch(tag, p, flags=re.I) for p in parts)
        codeish = all(py27_fullmatch(r"[A-Z0-9+]{1,8}", p) for p in parts)
        if known and codeish and tail:
            chain_clean = tail

    # Repeated standalone metadata at beginning/end.
    edge_clean = chain_clean
    for _ in range(20):
        before = edge_clean
        edge_clean = re.sub(
            r"^\s*[\[\(\{]?\s*" + tag +
            r"(?=$|[\s\]\)\}\-|:/+.,])\s*[\]\)\}]?\s*(?:[-|:/+.,]\s*)?",
            "", edge_clean, count=1, flags=re.I
        )
        if edge_clean == before:
            break
    for _ in range(20):
        before = edge_clean
        edge_clean = re.sub(
            r"(?:\s+|[-|:/+.,]\s*)[\[\(\{]?\s*" + tag +
            r"\s*[\]\)\}]?\s*$",
            "", edge_clean, count=1, flags=re.I
        )
        if edge_clean == before:
            break

    # Remove release group suffixes only when they look strongly technical:
    # "-GROUP", "@GROUP", "[GROUP]" after a recognisable title.
    release_clean = re.sub(
        r"(?i)\s*(?:-|@)\s*(?:RARBG|YIFY|YTS|PSA|NTB|NTG|FLUX|TEPES|"
        r"ION10|ION265|FGT|EVO|CMRG|MZABI|TOMMY|HONE|GGEZ|SuccessfulCrab|"
        r"MeGusta|GalaxyTV|ETHEL|KOGI|SuccessfulCrab)\s*$",
        " ", edge_clean
    )

    # Drop standalone technical tokens that remain in the middle only if they
    # are surrounded by separators/spaces. This catches "Movie 1080p WEB-DL".
    mid_clean = release_clean
    for _ in range(6):
        before = mid_clean
        mid_clean = re.sub(
            r"(?i)(?:(?<=^)|(?<=[\s|:/+\-\[\(\{]))" + tag +
            r"(?=$|[\s|:/+\-\]\)\}])",
            " ", mid_clean
        )
        if mid_clean == before:
            break

    # Normalise common separators and dots used as word separators in releases.
    clean = mid_clean
    # Dots between alphabetic words are usually release separators; don't touch
    # decimal numbers such as "5.1".
    clean = re.sub(u'(?<=[A-Za-z\u0600-ۿ])\\.(?=[A-Za-z\u0600-ۿ])', " ", clean)
    clean = re.sub(r"\s*[-|:/+]\s*[-|:/+]+\s*", " - ", clean)
    clean = re.sub(r"\s+", " ", clean).strip(" -|:/._")

    # Ordered strategy: strongest cleaned complete title first.
    add(clean)

    # If a title still ends with a bracketed non-metadata phrase, keep both full
    # and base-title candidates. This avoids breaking genuine titles while also
    # recovering provider annotations unknown to us.
    m = re.match(r"^(.*?)\s*[\(\[\{]([^)\]\}]{2,40})[\)\]\}]\s*$", clean)
    if m:
        base = m.group(1).strip()
        bracket = m.group(2).strip()
        add(clean)
        if base:
            add(base)
        if bracket and any(ch.isalpha() for ch in bracket):
            add("%s %s" % (base, bracket))

    # Provider prefix before a strong delimiter. Generate right side as a
    # candidate even if the prefix is unknown, but only when the left side is
    # short/code-like. Example "VIP MOVIES | Dune Part Two".
    for sep in (" | ", " - ", " : ", " / ", " — ", " – "):
        if sep not in clean:
            continue
        parts = [p.strip() for p in clean.split(sep) if p.strip()]
        for part in parts:
            add(part)
        if len(parts) >= 2:
            left = parts[0]
            if len(left.split()) <= 4 and (
                left.isupper() or
                py27_fullmatch(r"[A-Za-z0-9+._ -]{2,22}", left)
            ):
                add(sep.join(parts[1:]).strip())

    # Mixed-language title: Arabic/Latin/Cyrillic/etc. become independent
    # candidates, e.g. "6 Days ستة أيام" -> "6 Days" and "ستة أيام".
    for part in _tmdb_multiscript_candidates(clean):
        add(part)

    # Repeat multi-script split for all delimiter candidates generated above.
    for candidate in list(out):
        for part in _tmdb_multiscript_candidates(candidate):
            add(part)

    # Colon subtitle fallback: TMDb sometimes stores only the main title.
    # Keep the full provider title first, then progressively safer alternates.
    # Some Arabic IPTV catalogues append an editorial type before a colon, e.g.
    # "القصة الكاملة دراما: لعبة جهنم" while TMDb stores "القصة الكاملة".
    # Never remove "دراما" globally: only add a base-title candidate when it is
    # the final token immediately before a colon, and only after the full/head
    # candidates have already been tried.
    for candidate in list(out):
        for sep in (":", " - ", " – ", " — "):
            if sep in candidate:
                head = candidate.split(sep, 1)[0].strip()
                tail = candidate.split(sep, 1)[1].strip()
                if head:
                    add(head)
                    if sep == ":":
                        base = re.sub(r"\s+(?:دراما)\s*$", "", head, flags=re.UNICODE).strip()
                        # Avoid turning a one-word title into an unsafe broad query.
                        if base and base != head and len(base.split()) >= 2:
                            add(base)
                if tail and len(tail) >= 3:
                    add(tail)

    # Remove common edition suffixes as an additional candidate, not destructive.
    for candidate in list(out):
        editionless = re.sub(
            r"(?i)\s+(?:DIRECTOR'?S\s+CUT|FINAL\s+CUT|SPECIAL\s+EDITION|"
            r"ANNIVERSARY\s+EDITION|RESTORED|REMASTERED|IMAX|UNRATED)\s*$",
            "", candidate
        ).strip()
        add(editionless)

    # Raw normalized provider title is last-resort compatibility fallback only.
    add(raw_nfkc)
    if raw_nfkc != raw:
        add(raw)

    return out


def _tmdb_match_norm(value):
    """Search-only normalization used to score TMDb candidates safely."""
    text = _tmdb_normalize_unicode_digits(value)
    try:
        text = unicodedata.normalize("NFKC", text_type(text or ""))
    except Exception:
        text = str(text or "")
    # Search-only Arabic spelling variants: never alter titles in the UI.
    text = re.sub(u'[ً-ٰٟـ]', "", text)
    text = re.sub(u'[أإآٱ]', "ا", text)
    text = text.replace("ى", "ي").replace("ئ", "ي").replace("ؤ", "و")
    text = re.sub(u'[^\\w\u0600-ۿ]+', " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip().lower()


def _tmdb_result_score(query, row, kind="vod", wanted_year=None):
    """Score TMDb search rows instead of trusting the first result.

    Based on UltraStalker's safe matching strategy: exact/core Arabic titles are
    strong evidence, while a small editorial suffix (e.g. "دراما") is allowed.
    """
    media_title = row.get("title") if kind == "vod" else row.get("name")
    original = row.get("original_title") if kind == "vod" else row.get("original_name")
    q = _tmdb_match_norm(query)
    t = _tmdb_match_norm(media_title)
    o = _tmdb_match_norm(original)
    if not q:
        return 0.0
    base = max(
        difflib.SequenceMatcher(None, q, t).ratio() if t else 0.0,
        difflib.SequenceMatcher(None, q, o).ratio() if o else 0.0,
    )
    if q == t or q == o:
        base = 1.0
    else:
        q_tokens = q.split()
        for candidate in (t, o):
            if not candidate:
                continue
            if candidate.startswith(q + " ") or q.startswith(candidate + " "):
                base = max(base, 0.96)
                continue
            c_tokens = candidate.split()
            if len(q_tokens) >= 2 and len(c_tokens) >= len(q_tokens):
                qset, cset = set(q_tokens), set(c_tokens)
                if qset and qset.issubset(cset) and len(cset - qset) <= 3:
                    base = max(base, 0.91)
    try:
        if wanted_year:
            date = row.get("release_date") if kind == "vod" else row.get("first_air_date")
            ry = _tmdb_extract_year(date)
            if ry:
                diff = abs(int(wanted_year) - int(ry))
                if diff == 0:
                    base += 0.16
                elif diff == 1:
                    base += 0.05
                elif diff >= 3:
                    base -= 0.18
    except Exception:
        pass
    try:
        base += min(0.02, float(row.get("popularity") or 0) / 15000.0)
    except Exception:
        pass
    return max(0.0, min(1.0, base))



def _tmdb_identity_anchor(title, kind="series"):
    """Catalog-independent lookup identity, for both movies and TV shows.

    Keep the UI title unchanged.  An editorial subtitle after a colon (or a
    short provider suffix after a dash) is not another media identity.  For
    short or ambiguous headings use the cleaned complete title instead.
    """
    candidates = _tmdb_title_candidates(title)
    if not candidates:
        return ""
    primary = candidates[0]
    # IPTV source codes and generic type prefixes are not part of identity.
    primary = re.sub(u'(?<=[\u0600-ۿ])\\s+[A-Za-z]{1,3}$', "", primary).strip()
    primary = re.sub(r"^(?:مسلسل|مسلسلات|فيلم|افلام|أفلام)\s+(?=\S+\s+\S+)", "", primary).strip()
    for delimiter in (":", "："):
        if delimiter in primary:
            head = primary.split(delimiter, 1)[0].strip(" -|:_")
            if len(_tmdb_match_norm(head).split()) >= 2:
                return head
    # Provider shorthand at the end, e.g. "Arabic Show -SH".  Do not
    # truncate legitimate movie sequels/subtitles like "Part Two".
    for delim in (" - ", " – ", " — "):
        if delim in primary:
            head, tail = primary.rsplit(delim, 1)
            tail = tail.strip()
            if (len(_tmdb_match_norm(head).split()) >= 2 and
                    py27_fullmatch(r"[A-Za-z]{1,3}", tail or "")):
                return head.strip()
    return primary


def _tmdb_identity_candidate_allowed(anchor, candidate, title):
    """Exclude unrelated subtitle fragments and release-group abbreviations.

    Full-title matches and independent alternatives in a *different* script
    are allowed (e.g. an Arabic name followed by its English translation).
    """
    a = _tmdb_match_norm(anchor)
    c = _tmdb_match_norm(candidate)
    if not a or not c:
        return False
    if a == c:
        return True
    # Short fragments are particularly collision prone (e.g. "-Sh").
    if len(c) < 4:
        return False
    if c.startswith(a + " ") or a.startswith(c + " "):
        # Do not turn a long show title into an ambiguous first word.
        return len(c) >= 0.65 * len(a)
    if difflib.SequenceMatcher(None, a, c).ratio() >= 0.80:
        return True
    parts = _tmdb_multiscript_candidates(title)
    if len(parts) >= 2 and any(_tmdb_match_norm(part) == c for part in parts):
        return len(c.split()) >= 2
    return False


def _tmdb_identity_row_score(anchor, candidate, row, kind, wanted_year):
    """Return score only when title identity matches before year boosts.

    A same-year but unrelated title must never become a successful match.
    """
    if not isinstance(row, dict):
        return 0.0
    a = _tmdb_match_norm(anchor)
    c = _tmdb_match_norm(candidate)
    reference = candidate if (c != a and
        len(_tmdb_multiscript_candidates(anchor)) >= 2) else anchor
    # Prefer a match to the core identity. A query that contains the same
    # identity with an editorial subtitle is accepted only via that core.
    if _tmdb_result_score(reference, row, kind, None) < 0.77:
        # Mixed-script titles may contain a genuine separately translated name.
        if not (len(_tmdb_multiscript_candidates(anchor)) >= 2 and
                _tmdb_result_score(candidate, row, kind, None) >= 0.84):
            return 0.0
    return _tmdb_result_score(reference, row, kind, wanted_year)


# Compatibility for existing helper tests and any future local callers.
def _tmdb_series_main_title(title):
    anchor = _tmdb_identity_anchor(title, "series")
    return anchor if u":" in text_type(title or u"") else ""


def _tmdb_series_title_score(anchor, row, wanted_year=None):
    return _tmdb_result_score(anchor, row, "series", wanted_year)


def _has_arabic_letters(value):
    """Only claim Arabic metadata when it genuinely contains Arabic writing."""
    return bool(re.search(u'[\u0600-ۿݐ-ݿࢠ-ࣿ]', text_type(value or u"")))


def preferred_metadata_text(tmdb_text, provider_text="", language=None):
    """Prefer real localized TMDb text without overwriting Arabic with English.

    For Arabic, accept the official TMDb Arabic value, then existing Arabic
    provider text, and only then use English/other-language fallbacks. For
    French/Turkish trust the explicitly requested TMDb locale; TMDb may use
    original titles when a localized translation does not exist.
    """
    tmdb_value = text_type(tmdb_text or u"").strip()
    provider_value = text_type(provider_text or u"").strip()
    if language is None:
        try:
            language = load_settings().get("language") or "en-US"
        except Exception:
            language = "en-US"
    if str(language or "").lower().startswith("ar"):
        if _has_arabic_letters(tmdb_value):
            return tmdb_value
        if _has_arabic_letters(provider_value):
            return provider_value
    return tmdb_value or provider_value


def _device_tmdb_language():
    try:
        from Components.Language import language
        code = str(language.getLanguage() or "").lower()
        if code.startswith("ar"):
            return "ar-AE"
        if code.startswith("fr"):
            return "fr-FR"
        if code.startswith("tr"):
            return "tr-TR"
    except Exception:
        pass
    return "en-US"
DETAILS_TTL = 24 * 60 * 60
SEARCH_TTL = 24 * 60 * 60
TRENDING_TTL = 6 * 60 * 60


def _redact_tmdb_log(value):
    """Remove TMDb credentials from diagnostic text, including subprocess errors."""
    text = str(value or "")
    try:
        text = re.sub(r"(?i)(api_key=)[^&\s'\"]+", r"\1***", text)
        text = re.sub(r"(?i)(Authorization:\s*Bearer\s+)[^\s'\"]+", r"\1***", text)
        text = re.sub(r"(?i)(--header=Authorization:\s*Bearer\s+)[^\s'\"]+", r"\1***", text)
    except Exception:
        pass
    return text

def _log(message):
    return None

# Most screens consult TMDb language for every selection and poster; reading
# tmdb.json from HDD/USB each time can stall Enigma2's UI. Cache only the
# settings dict for two seconds; persistent config and API behaviour stay intact.
_SETTINGS_MEMORY_LOCK = threading.RLock()
_SETTINGS_MEMORY = [None, 0.0]

def _invalidate_settings_cache():
    with _SETTINGS_MEMORY_LOCK:
        _SETTINGS_MEMORY[0] = None
        _SETTINGS_MEMORY[1] = 0.0

def load_settings():
    now = time.time()
    with _SETTINGS_MEMORY_LOCK:
        cached, until = _SETTINGS_MEMORY
        if cached is not None and now < until:
            return dict(cached)
    result = _read_settings_uncached()
    with _SETTINGS_MEMORY_LOCK:
        _SETTINGS_MEMORY[0] = result
        _SETTINGS_MEMORY[1] = now + 2.0
    return dict(result)

def _read_settings_uncached():
    try:
        with open_text(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
        selected = str(data.get("language") or "auto")
        mode = str(data.get("mode") or "auto").lower()
        if mode not in ("auto", "v3", "v4", "disabled"):
            mode = "auto"

        # A user's saved values take priority. Empty fields keep using the shared
        # built-in credentials so existing installations continue to work.
        custom_key = str(data.get("api_key") or "").strip()
        custom_key2 = str(data.get("api_key2") or "").strip()
        custom_token = str(data.get("access_token") or "").strip()
        enabled = mode != "disabled"
        key = custom_key or (DEFAULT_API_KEY if enabled else "")
        key2 = custom_key2 or (DEFAULT_API_KEY2 if enabled else "")
        token = custom_token or (DEFAULT_ACCESS_TOKEN if enabled else "")
        return {
            "mode": mode,
            "api_key": key,
            "api_key2": key2,
            "access_token": token,
            "custom_api_key": custom_key,
            "custom_api_key2": custom_key2,
            "custom_access_token": custom_token,
            "language": _device_tmdb_language() if selected == "auto" else selected,
            "language_setting": selected,
            "backdrop_quality": data.get("backdrop_quality", "w780") if data.get("backdrop_quality", "w780") in ("w780", "w1920", "original") else "w780",
        }
    except Exception:
        return {
            "mode": "auto",
            "api_key": DEFAULT_API_KEY,
            "api_key2": DEFAULT_API_KEY2,
            "access_token": DEFAULT_ACCESS_TOKEN,
            "custom_api_key": "",
            "custom_api_key2": "",
            "custom_access_token": "",
            "language": _device_tmdb_language(),
            "language_setting": "auto",
            "backdrop_quality": "w780",
        }


def save_settings(api_key, language="en-US", mode="auto", access_token="", api_key2="", backdrop_quality="w780"):
    try:
        ensure_dir(CONFIG_DIR)
        payload = {
            "mode": (mode or "auto").lower(),
            "api_key": (api_key or "").strip(),
            "api_key2": (api_key2 or "").strip(),
            "access_token": (access_token or "").strip(),
            "language": language or "en-US",
            "backdrop_quality": backdrop_quality if backdrop_quality in ("w780", "w1920", "original") else "w780",
        }
        with open_text(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except Exception:
            pass
        _invalidate_settings_cache()
        return True
    except Exception:
        return False



def save_backdrop_quality(backdrop_quality):
    """Update only artwork quality without materialising built-in TMDb credentials.

    load_settings() intentionally exposes effective credentials (custom or built-in),
    so appearance-only saves must never round-trip those effective values into tmdb.json.
    """
    try:
        ensure_dir(CONFIG_DIR)
        try:
            with open_text(CONFIG_FILE, "r", encoding="utf-8") as f:
                payload = json.load(f) or {}
        except Exception:
            payload = {}
        payload["backdrop_quality"] = backdrop_quality if backdrop_quality in ("w780", "w1920", "original") else "w780"
        # Keep only actual persisted user overrides; never inject DEFAULT_* here.
        payload.setdefault("mode", "auto")
        payload.setdefault("language", "auto")
        payload.setdefault("api_key", "")
        payload.setdefault("api_key2", "")
        payload.setdefault("access_token", "")
        with open_text(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except Exception:
            pass
        _invalidate_settings_cache()
        return True
    except Exception:
        return False



def _search_cache_path(kind, language, title, year):
    try:
        from .cache_manager import get_cache_dir
        directory = get_cache_dir("metadata")
    except Exception:
        # Do not silently spill persistent TMDb cache into /tmp.
        # If cache_manager is unavailable, skip disk cache for this lookup.
        return None
    key = u"%s|%s|%s|%s" % (kind, language or "en-US", text_type(title or u"").strip().lower(), str(year or ""))
    return os.path.join(directory, "search_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")

def _load_search_cache(kind, language, title, year):
    path = _search_cache_path(kind, language, title, year)
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) >= SEARCH_TTL:
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except Exception:
        return None

def _save_search_cache(kind, language, title, year, data):
    path = _search_cache_path(kind, language, title, year)
    try:
        temporary = path + ".tmp"
        with open_text(temporary, "w", encoding="utf-8") as handle:
            json.dump(data or {}, handle, ensure_ascii=False)
        atomic_replace(temporary, path)
    except Exception:
        pass

# Negative title matches live in bounded RAM (not a flood of tiny HDD/flash
# files), and are never written for network errors. Positive search results
# continue to use the existing 24-hour persistent disk cache.
SEARCH_MISS_TTL = 15 * 60
_SEARCH_MISS_LOCK = threading.Lock()
_SEARCH_MISSES = {}
_SEARCH_MISS_MAX = 256


def _tmdb_lookup_report(line):
    """Short rolling report: /tmp/tivimate_tmdb_lookup.txt."""
    try:
        path = "/tmp/tivimate_tmdb_lookup.txt"
        try:
            if os.path.getsize(path) > 60000:
                os.remove(path)
        except OSError:
            pass
        if not isinstance(line, str):
            try:
                line = line.encode("utf-8")
            except Exception:
                line = str(line)
        with open(path, "a") as handle:
            handle.write(time.strftime("%H:%M:%S ") + line + "\n")
    except Exception:
        pass


def _search_miss_key(kind, language, title, year):
    return (str(kind), str(language), text_type(title or u"").strip().lower(), str(year or ""))


def _search_was_missed(kind, language, title, year):
    key = _search_miss_key(kind, language, title, year)
    with _SEARCH_MISS_LOCK:
        expires = _SEARCH_MISSES.get(key, 0)
        if expires > time.time():
            return True
        _SEARCH_MISSES.pop(key, None)
    return False


def _remember_search_miss(kind, language, title, year):
    key = _search_miss_key(kind, language, title, year)
    now = time.time()
    with _SEARCH_MISS_LOCK:
        _SEARCH_MISSES[key] = now + SEARCH_MISS_TTL
        if len(_SEARCH_MISSES) > _SEARCH_MISS_MAX:
            for old_key, expires in list(_SEARCH_MISSES.items()):
                if expires <= now:
                    _SEARCH_MISSES.pop(old_key, None)
            while len(_SEARCH_MISSES) > _SEARCH_MISS_MAX:
                _SEARCH_MISSES.pop(next(iter(_SEARCH_MISSES)))


# Deduplicate identical concurrent TMDb HTTP calls across separate pages and
# TMDbClient instances. Cache only /search responses briefly in bounded RAM;
# details remain authoritative in the existing ID/language-specific disk cache.
_TMDB_INFLIGHT_LOCK = threading.Lock()
_TMDB_INFLIGHT = {}
_TMDB_RECENT_SEARCH = {}
_TMDB_SEARCH_CACHE_MAX = 72
_TMDB_SEARCH_SUCCESS_TTL = 120
_TMDB_SEARCH_EMPTY_TTL = 120


def _tmdb_copy(payload):
    try:
        return copy.deepcopy(payload)
    except Exception:
        return payload


def _trending_cache_path(kind, language):
    try:
        from .cache_manager import get_cache_dir
        directory = get_cache_dir("metadata")
    except Exception:
        return None
    key = "trending-2026|%s|%s" % (kind, language or "en-US")
    return os.path.join(directory, "trending_" + hashlib.md5(key.encode("utf-8")).hexdigest() + ".json")


def _load_trending_cache(kind, language):
    path = _trending_cache_path(kind, language)
    try:
        if not os.path.exists(path) or time.time() - os.path.getmtime(path) >= TRENDING_TTL:
            return None
        with open_text(path, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        return rows if isinstance(rows, list) else None
    except Exception:
        return None


def _save_trending_cache(kind, language, rows):
    path = _trending_cache_path(kind, language)
    try:
        temporary = path + ".tmp"
        with open_text(temporary, "w", encoding="utf-8") as handle:
            json.dump(list(rows or []), handle, ensure_ascii=False)
        atomic_replace(temporary, path)
    except Exception:
        pass




def backdrop_quality():
    try:
        value = str(load_settings().get("backdrop_quality") or "w780")
    except Exception:
        value = "w1920"
    return value if value in ("w780", "w1920", "original") else "w780"


def backdrop_url(path):
    path = str(path or "")
    if not path:
        return ""
    if path.startswith("http://") or path.startswith("https://"):
        return path
    if not path.startswith("/"):
        path = "/" + path
    return IMAGE_BASE + backdrop_quality() + path

def select_movie_certification(payload, regions=("AE", "DE", "US")):
    """Pick an official region's certificate without inferring age from genre.

    UAE ratings take priority. A verified German FSK rating is the next choice
    when available, so the UI can use authentic FSK pictograms. PG-13 is
    intentionally excluded and is never converted to an arbitrary age.
    """
    results = (payload or {}).get("results") if isinstance(payload, dict) else None
    if not isinstance(results, list):
        return {}
    for region in regions:
        for group in results:
            if not isinstance(group, dict) or str(group.get("iso_3166_1") or "").upper() != region:
                continue
            rows = group.get("release_dates") or []
            if not isinstance(rows, list):
                continue
            priorities = {3: 0, 2: 1, 4: 2, 5: 3, 6: 4, 1: 5}
            rows = sorted((r for r in rows if isinstance(r, dict)),
                          key=lambda r: priorities.get(r.get("type"), 9))
            for row in rows:
                cert = str(row.get("certification") or "").strip()
                canonical = re.sub(r"[\s\-]+", "", cert.upper())
                if (cert and canonical not in ("N/A", "UNRATED", "NR", "NOTRATED", "PG13")
                        and len(cert) <= 16):
                    return {"region": region, "certification": cert}
    return {}


_TMDB_HTTP_LOCAL = threading.local()


class _TMDbHTTPError(Exception):
    def __init__(self, code, body):
        Exception.__init__(self, "TMDb HTTP %s" % code)
        self.code = code
        self._body = body

    def read(self):
        return self._body


def _tmdb_python_fetch(mode, url, auth_header=None):
    """TMDb API GET through Python 2.7 httplib with a kept-alive connection.

    Every TMDb page (details, credits, images, ids) issues several API calls.
    Re-using one TLS connection per worker thread avoids a full handshake per
    call, which is the slowest part on Python 2.7 receivers.
    """
    from . import py27_ssl
    import httplib
    from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit
    parts = urlsplit(url)
    host = parts.hostname
    port = parts.port or 443
    target = parts.path + (("?" + parts.query) if parts.query else "")
    headers = {"Accept": "application/json", "Accept-Encoding": "gzip",
               "Connection": "keep-alive",
               "User-Agent": "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/1.0"}
    if auth_header:
        name, _sep, value = auth_header.partition(":")
        headers[name.strip()] = value.strip()
    context = py27_ssl.verified_context() if mode == "verified" else py27_ssl.unverified_context()
    key = (mode, host, port)
    for attempt in (0, 1):
        conn = getattr(_TMDB_HTTP_LOCAL, "conn", None)
        fresh = conn is None or getattr(_TMDB_HTTP_LOCAL, "key", None) != key
        if fresh:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            conn = httplib.HTTPSConnection(host, port, timeout=8, context=context)
            _TMDB_HTTP_LOCAL.conn = conn
            _TMDB_HTTP_LOCAL.key = key
        try:
            conn.request("GET", target, headers=headers)
            response = conn.getresponse()
            raw = response.read(8 * 1024 * 1024 + 1)
            status = int(response.status or 0)
            encoding = str(response.getheader("content-encoding") or "").lower()
            if response.will_close:
                try:
                    conn.close()
                except Exception:
                    pass
                _TMDB_HTTP_LOCAL.conn = None
            break
        except Exception as error:
            try:
                conn.close()
            except Exception:
                pass
            _TMDB_HTTP_LOCAL.conn = None
            if attempt or fresh:
                raise error
            # Only a re-used keep-alive socket may be stale: reconnect once.
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("TMDb response too large")
    if encoding == "gzip":
        import zlib
        raw = zlib.decompress(raw, 16 + zlib.MAX_WBITS)
    if status >= 400:
        raise _TMDbHTTPError(status, raw)
    return raw


def _manual_pin(title, kind):
    """TMDb row pinned by the user for this title (MENU > Fix TMDb match)."""
    try:
        from .manual_match import get as _manual_get
        return _manual_get(title, kind)
    except Exception:
        return None


class TMDbClient(object):
    def __init__(self, api_key=None, language=None, access_token=None, mode=None, api_key2=None):
        cfg = load_settings()
        self.mode = (mode or cfg.get("mode") or "auto").lower()
        self.api_key = (api_key if api_key is not None else cfg.get("api_key") or "").strip()
        self.api_key2 = (api_key2 if api_key2 is not None else cfg.get("api_key2") or "").strip()
        self.access_token = (access_token if access_token is not None else cfg.get("access_token") or "").strip()
        # Respect the user's TMDb metadata language. load_settings() already
        # resolves the "auto" option to the device's effective language.
        selected = str(language if language is not None else cfg.get("language") or "en-US").strip()
        self.language = selected if selected not in ("", "auto") else _device_tmdb_language()

    def configured(self):
        if self.mode == "disabled":
            return False
        if self.mode == "v4":
            return bool(self.access_token)
        if self.mode == "v3":
            return bool(self.api_key or self.api_key2)
        return bool(self.access_token or self.api_key or self.api_key2)

    def _request(self, path, params, use_token=False, api_key=None):
        params = dict(params or {})
        params.setdefault("language", self.language)
        # VTi and older BusyBox images can install wget in /bin instead of
        # /usr/bin. Use options accepted by both BusyBox and GNU wget.
        # curl is only a transport fallback if the available wget cannot
        # perform HTTPS; never change the API request, identity or caches.
        wget = next((path for path in ("/usr/bin/wget", "/bin/wget", which("wget"))
                     if path and os.path.isfile(path) and os.access(path, os.X_OK)), None)
        curl = next((path for path in ("/usr/bin/curl", "/bin/curl", which("curl"))
                     if path and os.path.isfile(path) and os.access(path, os.X_OK)), None)
        if use_token:
            if not self.access_token:
                raise RuntimeError("TMDb Read Access Token is not configured")
            auth_header = "Authorization: Bearer %s" % self.access_token
        else:
            selected_key = (api_key or self.api_key or "").strip()
            if not selected_key:
                raise RuntimeError("TMDb API key is not configured")
            params["api_key"] = selected_key
            auth_header = None
        # Python 2.7 urllib.urlencode uses ASCII for unicode query values.
        # TMDb searches routinely contain Arabic/non-Latin titles: encode
        # values to UTF-8 bytes before percent-escaping, never with str().
        encoded_params = {}
        for key, value in params.items():
            if value is None:
                # language=None: ask TMDb for every language (logo galleries).
                continue
            if isinstance(key, unicode):
                key = key.encode('utf-8')
            if isinstance(value, unicode):
                value = value.encode('utf-8')
            encoded_params[key] = value
        url = API_BASE + path + "?" + urlencode(encoded_params)
        commands = []
        # VTi: BusyBox wget is usually built without HTTPS and curl is often
        # absent, so TMDb (actors, title logos, artwork) never loaded. Try the
        # in-process Python 2.7 urllib2 transport first; it uses the receiver
        # CA bundle or the plugin's bundled Mozilla CA (verified TLS).
        from . import py27_ssl
        if py27_ssl.HAS_CONTEXT:
            commands.append(("python", ("verified", url, auth_header)))
        if wget:
            cmd = [wget, "-q", "-O", "-", "-T", "8"]
            if auth_header:
                cmd.extend(["--header", auth_header])
            commands.append(("wget", cmd + [url]))
        if curl:
            cmd = [curl, "-fsSL", "--connect-timeout", "5", "--max-time", "8"]
            if auth_header:
                cmd.extend(["-H", auth_header])
            commands.append(("curl", cmd + [url]))
        # Last resort for receivers whose OpenSSL cannot validate TMDb's
        # current chain: public metadata only, same request, no new secrets.
        if py27_ssl.HAS_CONTEXT:
            commands.append(("python-compat", ("compat", url, auth_header)))
        if not commands:
            raise RuntimeError("TMDb HTTPS client unavailable (wget/curl missing)")
        failure_kinds = []
        for transport, cmd in commands:
            try:
                if transport.startswith("python"):
                    raw = _tmdb_python_fetch(*cmd)
                else:
                    raw = subprocess_run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         timeout=10, check=True).stdout
                if not isinstance(raw, (str, unicode)):
                    raw = raw.decode("utf-8", "replace")
                data = json.loads(raw or "{}")
            except (HTTPError, _TMDbHTTPError) as exc:
                # A real TMDb answer (401 bad key, 404 missing id): another
                # transport would get the same reply.
                try:
                    body = json.loads(exc.read() or "{}")
                except Exception:
                    body = {}
                if isinstance(body, dict) and body.get("status_message"):
                    raise RuntimeError(body.get("status_message"))
                raise RuntimeError("TMDb HTTP %s" % getattr(exc, "code", "error"))
            except (OSError, IOError, RuntimeError, subprocess.CalledProcessError, ValueError, TypeError) as exc:
                # Never log the process command: it contains the TMDb key
                # in its URL, or the bearer token in a request header.
                failure_kinds.append(transport + ":" + type(exc).__name__)
                continue
            if isinstance(data, dict) and data.get("success") is False:
                raise RuntimeError(data.get("status_message") or "TMDb request failed")
            return data
        raise RuntimeError("TMDb HTTPS fetch failed: %s" % ",".join(failure_kinds))

    def _get(self, path, params=None):
        """One request per identical in-flight endpoint/query/language/credential.

        Neither search scoring nor server-first decisions are changed here.
        Transient network/auth errors are deliberately NEVER negatively cached.
        """
        if self.mode == "disabled":
            raise RuntimeError("TMDb is disabled")
        normalized = dict(params or {})
        normalized.setdefault("language", self.language)
        # Include all credential choices in the digest. Different TMDb settings
        # must never share a pending request or its response.
        identifier = json.dumps([
            self.mode, self.api_key, self.api_key2, self.access_token,
            str(path), normalized], sort_keys=True, ensure_ascii=False, default=str)
        key = hashlib.sha256(identifier.encode("utf-8")).hexdigest()
        search = str(path).startswith("/search/")
        owner = False
        now = time.time()
        with _TMDB_INFLIGHT_LOCK:
            if search:
                cached = _TMDB_RECENT_SEARCH.get(key)
                if cached is not None:
                    expires, result = cached
                    if now < expires:
                        return _tmdb_copy(result)
                    _TMDB_RECENT_SEARCH.pop(key, None)
            pending = _TMDB_INFLIGHT.get(key)
            if pending is None:
                pending = {"event": threading.Event(), "value": None, "error": None}
                _TMDB_INFLIGHT[key] = pending
                owner = True
        if not owner:
            # A bad connection must not lock another page forever. If the
            # leader hangs unexpectedly, let this caller perform its own retry.
            if pending["event"].wait(35):
                if pending["error"] is not None:
                    raise RuntimeError(str(pending["error"]))
                return _tmdb_copy(pending["value"])
            return self._get_uncached(path, params)
        try:
            result = self._get_uncached(path, params)
            pending["value"] = result
            if search and isinstance(result, dict) and isinstance(result.get("results"), list):
                ttl = (_TMDB_SEARCH_SUCCESS_TTL if result["results"]
                       else _TMDB_SEARCH_EMPTY_TTL)
                with _TMDB_INFLIGHT_LOCK:
                    _TMDB_RECENT_SEARCH[key] = (time.time() + ttl, _tmdb_copy(result))
                    # Small, predictable RAM usage, including any expired rows.
                    for old_key, (expires, _) in list(_TMDB_RECENT_SEARCH.items()):
                        if expires <= time.time():
                            _TMDB_RECENT_SEARCH.pop(old_key, None)
                    while len(_TMDB_RECENT_SEARCH) > _TMDB_SEARCH_CACHE_MAX:
                        _TMDB_RECENT_SEARCH.pop(next(iter(_TMDB_RECENT_SEARCH)))
            return _tmdb_copy(result)
        except Exception as exc:
            pending["error"] = exc
            raise
        finally:
            with _TMDB_INFLIGHT_LOCK:
                if _TMDB_INFLIGHT.get(key) is pending:
                    del _TMDB_INFLIGHT[key]
                pending["event"].set()

    def _get_uncached(self, path, params=None):
        if self.mode == "disabled":
            raise RuntimeError("TMDb is disabled")
        methods = []
        if self.mode == "v4":
            methods = [(True, None, "v4")]
        elif self.mode == "v3":
            if self.api_key:
                methods.append((False, self.api_key, "v3-key1"))
            if self.api_key2 and self.api_key2 != self.api_key:
                methods.append((False, self.api_key2, "v3-key2"))
        else:
            # Auto mode follows the preferred EStalker-style fallback order:
            # API Key 1 first, API Key 2 second, then the v4 token only if both fail.
            if self.api_key:
                methods.append((False, self.api_key, "v3-key1"))
            if self.api_key2 and self.api_key2 != self.api_key:
                methods.append((False, self.api_key2, "v3-key2"))
            if self.access_token:
                methods.append((True, None, "v4"))
        if not methods:
            raise RuntimeError("TMDb credentials are not configured")
        last = None
        for use_token, api_key, auth_name in methods:
            try:
                data = self._request(path, params, use_token=use_token, api_key=api_key)
                _log("GET OK %s auth=%s results=%s" % (
                    path, auth_name,
                    len(data.get("results") or []) if isinstance(data, dict) else "?"
                ))
                return data
            except Exception as exc:
                last = exc
                _log("GET FAILED %s auth=%s: %s" % (path, auth_name, exc))
        raise last or RuntimeError("TMDb request failed")

    def movie_age_certification(self, tmdb_id, release_dates=None):
        """Fetch real TMDb movie release certification with a separate disk cache.

        UI calls this from its existing background worker; no network in GUI.
        The older details cache may lack appended release_dates, so it must not
        suppress this endpoint. A missing certification is never labelled 18+.
        """
        if isinstance(release_dates, dict) and isinstance(release_dates.get("results"), list):
            return select_movie_certification(release_dates)
        try:
            movie_id = int(str(tmdb_id or "0"))
            if movie_id <= 0:
                return {}
        except Exception:
            return {}
        try:
            from .cache_manager import get_cache_dir
            folder = get_cache_dir("metadata")
            path = os.path.join(folder, "tmdb_movie_certification_v2_%d.json" % movie_id) if folder else None
        except Exception:
            path = None
        if path and os.path.isfile(path):
            try:
                with open_text(path, "r", encoding="utf-8") as stream:
                    cached = json.load(stream) or {}
                duration = 2 * 86400 if not cached.get("result") else 7 * 86400
                if time.time() - float(cached.get("checked") or 0) < duration:
                    return cached.get("result") or {}
            except Exception:
                pass
        try:
            result = select_movie_certification(self._get("/movie/%d/release_dates" % movie_id, {}) or {})
        except Exception:
            # Don't cache network failures as missing certifications.
            return {}
        if path:
            try:
                with open_text(path + ".tmp", "w", encoding="utf-8") as stream:
                    json.dump({"result": result, "checked": time.time()}, stream, ensure_ascii=False)
                atomic_replace(path + ".tmp", path)
            except Exception:
                pass
        return result

    def _fill_regional_arabic(self, tmdb_id, media, record):
        """Fill missing Arabic text from TMDb's official regional translations.

        The chosen ar-AE entry may be absent while an official ar-SA/ar-EG
        translation exists. Artwork/credits/IDs are not touched.
        """
        data = dict(record or {})
        if not str(self.language or "").lower().startswith("ar") or not data.get("id"):
            return data
        title_key = "title" if media == "movie" else "name"
        need_title = not _has_arabic_letters(data.get(title_key))
        need_overview = not _has_arabic_letters(data.get("overview"))
        if not (need_title or need_overview):
            return data
        try:
            payload = self._get("/%s/%s/translations" % (media, tmdb_id), {}) or {}
        except Exception:
            # Do not mark failed requests as checked; they can retry later.
            return data
        translations = [row for row in (payload.get("translations") or [])
                        if isinstance(row, dict) and str(row.get("iso_639_1") or "").lower() == "ar"]
        regions = ("AE", "SA", "EG", "JO", "KW", "QA", "BH", "OM", "LB", "MA", "TN", "DZ")
        translations.sort(key=lambda row: (regions.index(str(row.get("iso_3166_1") or "").upper())
                           if str(row.get("iso_3166_1") or "").upper() in regions else len(regions)))
        for row in translations:
            candidate = row.get("data") or {}
            if not isinstance(candidate, dict):
                continue
            candidate_title = candidate.get(title_key) or candidate.get("title") or candidate.get("name") or ""
            candidate_overview = candidate.get("overview") or ""
            if need_title and _has_arabic_letters(candidate_title):
                data[title_key] = text_type(candidate_title).strip()
                need_title = False
            if need_overview and _has_arabic_letters(candidate_overview):
                data["overview"] = text_type(candidate_overview).strip()
                need_overview = False
            if not (need_title or need_overview):
                break
        # Negative results are cached for 24h, not forever. Real translations
        # can be added to TMDb later.
        data["_tivimate_ar_translations_checked"] = int(time.time())
        return data

    def _is_scripted_tv_series(self, item):
        """Keep English US/UK scripted series and reject programme-style TV."""
        if not isinstance(item, dict):
            return False

        if str(item.get("original_language") or "").lower() != "en":
            return False

        origins = set(str(x or "").upper() for x in (item.get("origin_country") or []))
        if origins and not origins.intersection(set(("US", "GB"))):
            return False

        try:
            genres = set(int(x) for x in (item.get("genre_ids") or []))
        except Exception:
            genres = set()

        # Programme/factual genres we do not want in Popular or Trending TV.
        rejected = set((
            99,     # Documentary
            10763,  # News
            10764,  # Reality
            10767,  # Talk
        ))
        if genres.intersection(rejected):
            return False

        # Positive scripted-series genres. This intentionally excludes generic
        # factual/sports/reality/talk content even when TMDb marks it popular.
        allowed = set((
            16,     # Animation
            18,     # Drama
            35,     # Comedy
            37,     # Western
            80,     # Crime
            9648,   # Mystery
            10751,  # Family
            10759,  # Action & Adventure
            10765,  # Sci-Fi & Fantasy
            10766,  # Soap
            10768,  # War & Politics
        ))
        return bool(genres.intersection(allowed))


    def provider_catalog(self, kind, provider, limit=50):
        """Return TMDb titles available on one streaming provider.

        Provider ids used by TMDb:
          Netflix = 8
          Amazon Prime Video = 9
        No Popular/Trending fallback is used, so each mode remains provider-specific.
        """
        try:
            limit = max(1, min(int(limit or 200), 200))
        except Exception:
            limit = 200

        provider_key = str(provider or "").strip().lower()
        provider_id = {"netflix": 8, "prime": 9, "prime_video": 9}.get(provider_key)
        if not provider_id:
            return []

        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        page = 1

        while len(results) < limit and page <= 10:
            params = {
                "watch_region": "US",
                "with_watch_providers": str(provider_id),
                "with_original_language": "en",
                "sort_by": "popularity.desc",
                "page": page,
            }
            payload = self._get("/discover/%s" % media, params) or {}
            rows = payload.get("results") or []
            if not rows:
                break

            for item in rows:
                if kind != "vod":
                    if not self._is_scripted_tv_series(item):
                        continue
                else:
                    if str(item.get("original_language") or "").lower() != "en":
                        continue

                row = self._convert(item, kind)
                tid = row.get("tmdb_id")
                if tid and tid not in seen:
                    row["_tmdb_provider"] = provider_key
                    results.append(row)
                    seen.add(tid)
                if len(results) >= limit:
                    break
            page += 1

        return results[:limit]


    def popular(self, kind, limit=50):
        """Return up to 50 current Popular Movies/TV Shows.

        Uses TMDb popular pages directly.  No per-title detail calls are made,
        so the landing row stays lightweight.
        """
        try:
            limit = max(1, min(int(limit or 50), 50))
        except Exception:
            limit = 50
        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        page = 1
        while len(results) < limit and page <= 3:
            data = self._get("/%s/popular" % media, {"page": page})
            rows = data.get("results") or []
            if not rows:
                break
            for item in rows:
                if kind == "vod":
                    if str(item.get("original_language") or "").lower() != "en":
                        continue
                else:
                    if not self._is_scripted_tv_series(item):
                        continue
                row = self._convert(item, kind)
                tid = row.get("tmdb_id")
                if tid and tid not in seen:
                    seen.add(tid)
                    results.append(row)
                if len(results) >= limit:
                    break
            page += 1
        return results[:limit]



    def trending_2026(self, kind, limit=8):
        try:
            limit = max(1, min(int(limit or 8), 50))
        except Exception:
            limit = 8

        media = "movie" if kind == "vod" else "tv"
        results = []
        seen = set()
        page = 1
        absolute_rank = 0

        while len(results) < limit and page <= 5:
            data = self._get("/trending/%s/week" % media, {"page": page}) or {}
            rows = data.get("results") or []
            if not rows:
                break

            for item in rows:
                absolute_rank += 1
                if not self._eligible(item, kind):
                    continue
                if kind != "vod" and not self._is_scripted_tv_series(item):
                    continue

                row = self._convert(item, kind)
                tid = row.get("tmdb_id")
                if tid and tid not in seen:
                    row["_tmdb_rank"] = absolute_rank
                    results.append(row)
                    seen.add(tid)

                if len(results) >= limit:
                    break
            page += 1

        results = results[:limit]
        _save_trending_cache(kind, self.language, results)
        _log("TRENDING WEEKLY kind=%s count=%d" % (kind, len(results)))
        return results


    def home_feed(self, mode, limit=6):
        """Return distinct Popular/Trending Home rows from their real TMDb feeds."""
        mode = str(mode or "popular_movies")
        kind = "series" if mode.endswith("_series") else "vod"
        media = "tv" if kind == "series" else "movie"
        wanted = int(limit or 6)
        is_trending = mode.startswith("trending_")

        results = []
        seen = set()
        popular_ids = set()

        if is_trending:
            # Exclude current Popular titles so Home Trending is not a duplicate.
            for page in (1, 2, 3):
                payload = self._get("/%s/popular" % media, {"page": page}) or {}
                for item in payload.get("results") or []:
                    popular_ids.add(str(item.get("id") or ""))

            for page in (1, 2, 3, 4, 5):
                payload = self._get("/trending/%s/week" % media, {"page": page}) or {}
                for item in payload.get("results") or []:
                    tid = str(item.get("id") or "")
                    if tid and tid in popular_ids:
                        continue
                    if kind == "series" and not self._is_scripted_tv_series(item):
                        continue
                    if kind == "vod" and str(item.get("original_language") or "").lower() != "en":
                        continue
                    if tid and tid not in seen:
                        results.append(item)
                        seen.add(tid)
                    if len(results) >= wanted:
                        break
                if len(results) >= wanted:
                    break
        else:
            for page in (1, 2, 3, 4, 5):
                payload = self._get("/%s/popular" % media, {"page": page}) or {}
                for item in payload.get("results") or []:
                    tid = str(item.get("id") or "")
                    if kind == "series":
                        if not self._is_scripted_tv_series(item):
                            continue
                    else:
                        if str(item.get("original_language") or "").lower() != "en":
                            continue
                    if tid and tid not in seen:
                        results.append(item)
                        seen.add(tid)
                    if len(results) >= wanted:
                        break
                if len(results) >= wanted:
                    break

        converted = []
        for item in results[:wanted]:
            row = self._convert(item, kind)
            row["_tivimate_home_kind"] = kind
            row["_home_tmdb_feed"] = mode
            converted.append(row)
        return converted[:wanted]


    def title_matches(self, title, row, kind="vod"):
        """True when a TMDb record plausibly belongs to this provider title."""
        if not isinstance(row, dict) or not row:
            return False
        try:
            anchor = _tmdb_identity_anchor(title, kind)
            names = list(_tmdb_bracket_titles(title)) + list(_tmdb_title_candidates(title))
            if anchor:
                names.insert(0, anchor)
            for name in names:
                if _tmdb_identity_row_score(name, name, row, kind, None) >= 0.5:
                    return True
        except Exception:
            return True
        return False

    def search_title(self, title, kind="vod", year=None):
        """Safe generic title lookup for series and movies in any language."""
        pinned = _manual_pin(title, kind)
        if pinned:
            return pinned
        media = "movie" if kind == "vod" else "tv"
        year = _tmdb_extract_year(title, year)
        candidates = _tmdb_title_candidates(title)
        if not candidates:
            return None
        anchor = _tmdb_identity_anchor(title, kind)
        # Always try the verified cleaned identity first; it may be absent
        # from provider-derived alternatives (e.g. "مسلسل ... SH").
        if anchor and _tmdb_match_norm(anchor) not in [_tmdb_match_norm(c) for c in candidates]:
            candidates.insert(0, anchor)
        bracket_parts = _tmdb_bracket_titles(title)
        for part in reversed(bracket_parts):
            # Local title and [original title] are searched first, each alone.
            norm = _tmdb_match_norm(part)
            candidates = [c for c in candidates if _tmdb_match_norm(c) != norm]
            candidates.insert(0, part)
        attempts = [year, None] if year else [None]
        # Match Ultra's language strategy: search the configured language first,
        # then use bounded fallbacks for titles whose TMDB localized name is not
        # present in the device language. Artwork and metadata remain independent
        # of this identity lookup; the selected language is never changed.
        search_languages = []
        for lang in ((_tmdb_title_language(title) or _TMDB_LANG_HINT.get("lang"), self.language) + _tmdb_title_locales(title) + ("en-US", "de-DE", "ar-EG")):
            lang = str(lang or "").strip() or "en-US"
            if lang not in search_languages:
                search_languages.append(lang)
        _tmdb_lookup_report("SEARCH %s %r year=%s langs=%s cands=%r" % (kind, title, year, search_languages, candidates[:6]))
        for clean_title in candidates:
            own_anchor = clean_title if clean_title in bracket_parts else anchor
            if own_anchor is anchor and not _tmdb_identity_candidate_allowed(anchor, clean_title, title):
                continue
            for search_language in search_languages:
                for wanted_year in attempts:
                    cached = _load_search_cache(kind, search_language, clean_title, wanted_year)
                    if cached and _tmdb_identity_row_score(own_anchor, clean_title, cached, kind, wanted_year) >= 0.80:
                        return cached
                    if _search_was_missed(kind, search_language, clean_title, wanted_year):
                        continue
                    params = {"query": clean_title, "page": 1, "language": search_language}
                    if wanted_year:
                        params["year" if kind == "vod" else "first_air_date_year"] = str(wanted_year)
                    try:
                        payload = self._get("/search/%s" % media, params) or {}
                    except Exception as error:
                        _tmdb_lookup_report("ERR %s %s %r: %s" % (search_language, wanted_year, clean_title, error))
                        continue
                    _tmdb_lookup_report("%s %s %r -> %d" % (search_language, wanted_year, clean_title,
                                                           len(payload.get("results") or []) if isinstance(payload, dict) else -1))
                    rows = payload.get("results") or []
                    ranked = sorted((( _tmdb_identity_row_score(own_anchor, clean_title, row, kind, wanted_year), row)
                                     for row in rows[:20] if isinstance(row, dict)),
                                    key=lambda pair: pair[0], reverse=True)
                    if ranked and ranked[0][0] >= 0.80:
                        result = ranked[0][1]
                        _save_search_cache(kind, search_language, clean_title, wanted_year, result)
                        return result
                    # Only mark a query after a valid TMDB response. Network
                    # failures are not cached as misses and can retry later.
                    if isinstance(payload, dict) and isinstance(payload.get("results"), list):
                        _remember_search_miss(kind, search_language, clean_title, wanted_year)
        return None

    def search_artwork(self, title, kind="vod", year=None, required_key=None):
        """Return only artwork belonging to the matched movie/series identity.

        Server images remain the caller's first preference; this method never
        turns an unrelated TMDb result into a cached successful fallback.
        """
        pinned = _manual_pin(title, kind)
        if pinned:
            return pinned if (not required_key or pinned.get(required_key)) else None
        year = _tmdb_extract_year(title, year)
        candidates = _tmdb_title_candidates(title)
        if not candidates:
            return None
        media = "movie" if kind == "vod" else "tv"
        anchor = _tmdb_identity_anchor(title, kind)
        if anchor and _tmdb_match_norm(anchor) not in [_tmdb_match_norm(c) for c in candidates]:
            candidates.insert(0, anchor)
        bracket_parts = _tmdb_bracket_titles(title)
        for part in reversed(bracket_parts):
            # Local title and [original title] are searched first, each alone.
            norm = _tmdb_match_norm(part)
            candidates = [c for c in candidates if _tmdb_match_norm(c) != norm]
            candidates.insert(0, part)
        attempts = [year, None] if year else [None]
        best_row = None
        best_score = 0.0
        locale = str(self.language or "en-US")
        if _has_arabic_letters(title):
            locale = "ar-AE"
        # Ultra searches in the configured language first, with bounded
        # language-neutral fallbacks. This covers French, German, Spanish,
        # Italian and other catalogues without making a request for every
        # language supported by TMDB.
        languages = []
        for lang in ((_tmdb_title_language(title) or _TMDB_LANG_HINT.get("lang"), locale) + _tmdb_title_locales(title) + ("en-US", "de-DE", "ar-EG")):
            lang = str(lang or "").strip() or "en-US"
            if lang not in languages:
                languages.append(lang)
        for lang in languages:
            for candidate in candidates:
                own_anchor = candidate if candidate in bracket_parts else anchor
                if own_anchor is anchor and not _tmdb_identity_candidate_allowed(anchor, candidate, title):
                    continue
                for wanted_year in attempts:
                    try:
                        params = {"query": candidate, "page": 1, "language": lang}
                        if wanted_year:
                            params["year" if kind == "vod" else "first_air_date_year"] = str(wanted_year)
                        rows = (self._get("/search/%s" % media, params) or {}).get("results") or []
                        for row in rows[:20]:
                            if not isinstance(row, dict) or (required_key and not row.get(required_key)):
                                continue
                            score = _tmdb_identity_row_score(own_anchor, candidate, row, kind, wanted_year)
                            if score > best_score:
                                best_score, best_row = score, row
                        # A strong identity match is sufficient; no need to
                        # enqueue additional TMDb requests for every variant.
                        if best_score >= 0.95:
                            return best_row
                    except Exception:
                        continue
            if best_score >= 0.80:
                return best_row
        return best_row if best_row is not None and best_score >= 0.80 else None

    def media_videos(self, tmdb_id, kind="vod"):
        """Return exact TMDb video rows for a movie/series; no title-based YouTube search."""
        try:
            media = "movie" if kind == "vod" else "tv"
            if int(str(tmdb_id or "0").strip()) <= 0:
                return {}
            return self._get("/%s/%s/videos" % (media, str(tmdb_id)), {}) or {}
        except Exception:
            return {}

    def media_credits(self, tmdb_id, kind="vod"):
        """Return credits for one movie/TV item with a persistent disk cache.

        Kept separate from details_bundle so an older/incomplete details cache
        (metadata/artwork but no credits) cannot suppress actor profile images.
        """
        try:
            tmdb_id = int(str(tmdb_id or "0").strip())
            if tmdb_id <= 0:
                return {}
        except Exception:
            return {}
        media = "movie" if kind == "vod" else "tv"
        cache_path = None
        try:
            from .cache_manager import get_cache_dir
            cache_dir = get_cache_dir("metadata")
            safe_lang = re.sub(r"[^A-Za-z0-9_.-]+", "_", self.language.replace("/", "_"))
            cache_path = os.path.join(cache_dir, "credits_tmdb_%s_%s_%s.json" % (media, tmdb_id, safe_lang))
            if os.path.exists(cache_path) and os.path.getsize(cache_path) > 20:
                with open_text(cache_path, "r", encoding="utf-8") as f:
                    cached = json.load(f) or {}
                if isinstance(cached, dict) and (cached.get("cast") or cached.get("crew")):
                    return cached
        except Exception:
            cache_path = None
        try:
            data = self._get("/%s/%s/credits" % (media, tmdb_id)) or {}
        except Exception:
            data = {}
        if isinstance(data, dict) and (data.get("cast") or data.get("crew")) and cache_path:
            try:
                tmp = cache_path + ".tmp"
                with open_text(tmp, "w", encoding="utf-8") as f:
                    json.dump(data, f, ensure_ascii=False)
                atomic_replace(tmp, cache_path)
            except Exception:
                pass
        return data if isinstance(data, dict) else {}

    def search_person(self, name):
        """Resolve one actor name to a TMDb person row (id/profile_path)."""
        # Python 2.7 str(unicode_arabic) raises UnicodeEncodeError. Preserve
        # real Unicode here and let _request UTF-8 percent-encode the query.
        name = text_type(name or u"").strip()
        if not name:
            return {}
        try:
            payload = self._get("/search/person", {"query": name}) or {}
            rows = [x for x in (payload.get("results") or []) if isinstance(x, dict)]
        except Exception:
            rows = []
        if not rows:
            return {}
        # Prefer an exact normalized name, then the first TMDb-ranked result.
        def norm(v):
            return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", text_type(v or "")).strip()).lower()
        wanted = norm(name)
        for row in rows[:10]:
            if norm(row.get("name")) == wanted:
                return row
        return rows[0]

    def person_tv_credits(self, person_id):
        """Fetch a person's TV acting credits only when actor search is requested."""
        try:
            person_id = int(str(person_id or "0").strip())
            if person_id <= 0:
                return {}
            return self._get("/person/%s/tv_credits" % person_id) or {}
        except Exception:
            return {}

    def person_movie_credits(self, person_id):
        """Return movie acting credits for a TMDb person id.

        This request is intentionally on-demand so opening the normal details
        screen never gains another network call.
        """
        try:
            person_id = int(str(person_id or "0").strip())
            if person_id <= 0:
                return {}
        except Exception:
            return {}
        try:
            return self._get("/person/%s/movie_credits" % person_id) or {}
        except Exception:
            return {}

    def details_bundle(self, tmdb_id, kind="vod"):
        """Return movie/series details with a persistent 24-hour JSON cache.

        The cached data is returned immediately on repeat visits. When the cache
        is stale, TMDb is queried and the file is atomically refreshed.
        """
        # Never turn a missing provider id into /movie/0 or /tv/0. Besides being
        # invalid, auto auth mode would retry the same bad request with every
        # configured credential and can stall Enigma2 for several timeouts.
        try:
            if int(str(tmdb_id or "0").strip()) <= 0:
                return {}
        except Exception:
            return {}
        media = "movie" if kind == "vod" else "tv"
        try:
            from .cache_manager import get_cache_dir
            cache_dir = get_cache_dir("metadata")
        except Exception:
            # No persistent cache root available: keep details in memory/network only.
            cache_dir = None
        # Shared details record: every page uses the same TMDb-id keyed file.
        safe_lang = re.sub(r"[^A-Za-z0-9_.-]+", "_", self.language.replace("/", "_"))
        cache_key = "%s_%s_%s" % (media, str(tmdb_id), safe_lang)
        cache_path = (os.path.join(cache_dir, "details_tmdb_%s.json" % cache_key) if cache_dir else None)
        legacy_cache_path = None
        if cache_dir:
            try:
                from .cache_manager import get_cache_root
                legacy_cache_path = os.path.join(get_cache_root(), "details_json", hashlib.md5(cache_key.encode("utf-8")).hexdigest() + ".json")
            except Exception:
                legacy_cache_path = None
        def useful(payload):
            if not isinstance(payload, dict) or not payload.get("id"):
                return False
            # Details cache is data-first: a valid metadata record is useful even
            # when artwork/enrichment is absent. This keeps HDD/USB cache authoritative
            # for normal details opening instead of forcing a network refresh.
            return bool(
                payload.get("title") or payload.get("name") or payload.get("original_title") or
                payload.get("overview") or payload.get("release_date") or payload.get("first_air_date") or
                payload.get("runtime") or payload.get("genres") or payload.get("vote_average") or
                payload.get("poster_path") or payload.get("backdrop_path") or
                ((payload.get("credits") or {}).get("cast") or []) or
                ((payload.get("recommendations") or {}).get("results") or []) or
                ((payload.get("similar") or {}).get("results") or [])
            )

        try:
            if cache_path and (not os.path.exists(cache_path)) and legacy_cache_path and os.path.exists(legacy_cache_path):
                try:
                    os.rename(legacy_cache_path, cache_path)
                except Exception:
                    try:
                        import shutil
                        shutil.copy2(legacy_cache_path, cache_path)
                    except Exception:
                        pass
            if cache_path and os.path.exists(cache_path) and os.path.getsize(cache_path) > 20:
                age = time.time() - os.path.getmtime(cache_path)
                with open_text(cache_path, "r", encoding="utf-8") as f:
                    data = json.load(f) or {}
                if useful(data):
                    # Movie details written by older builds had no completion marker.
                    # Such a file may have been persisted while enrichment was still
                    # incomplete, then treated as authoritative forever.  Refresh an
                    # unmarked movie record once; completed records remain fully
                    # cache-first.  Series behaviour is intentionally unchanged.
                    movie_complete = bool(data.get("_tivimate_details_complete"))
                    if media != "movie" or movie_complete:
                        if str(self.language or "").lower().startswith("ar"):
                            title_key = "title" if media == "movie" else "name"
                            missing_arabic = (not _has_arabic_letters(data.get("overview")) or
                                              not _has_arabic_letters(data.get(title_key)))
                            checked = float(data.get("_tivimate_ar_translations_checked") or 0)
                            if missing_arabic and time.time() - checked >= DETAILS_TTL:
                                updated = self._fill_regional_arabic(tmdb_id, media, data)
                                if updated != data:
                                    data = updated
                                    try:
                                        with open_text(cache_path + ".tmp", "w", encoding="utf-8") as f:
                                            json.dump(data, f, ensure_ascii=False)
                                        atomic_replace(cache_path + ".tmp", cache_path)
                                    except Exception:
                                        pass
                        _log("DETAILS CACHE HIT %s:%s age=%ds%s" % (
                            media, tmdb_id, int(age), " stale-ok" if age >= DETAILS_TTL else ""))
                        return data
                    _log("DETAILS CACHE PARTIAL %s:%s; completing once" % (media, tmdb_id))
                else:
                    _log("DETAILS CACHE INCOMPLETE %s:%s; refreshing" % (media, tmdb_id))
        except Exception as exc:
            _log("DETAILS CACHE READ FAILED %s:%s %s" % (media, tmdb_id, exc))

        data = self._get("/%s/%s" % (media, tmdb_id), {
            "append_to_response": "credits,recommendations,similar,images,release_dates",
            # Do not restrict TMDb poster/backdrop artwork by UI language.
            # Omitting include_image_language lets the images payload expose artwork
            # across all available languages; title/metadata language stays unchanged.
        })
        # Some localized responses contain text but miss enrichment. Retry once in
        # English and merge only missing fields; this keeps Arabic metadata when present.
        if self.language != "en-US" and (not useful(data) or not (data or {}).get("overview")):
            try:
                # Explicit request language: never mutate the shared client while
                # other artwork/details requests may be running in parallel.
                fallback = self._get("/%s/%s" % (media, tmdb_id), {
                    "append_to_response": "credits,recommendations,similar,images,release_dates",
                    "language": "en-US",
                }) or {}
                merged = dict(fallback)
                merged.update(data or {})
                for key in ("credits", "recommendations", "similar", "images",
                            "poster_path", "backdrop_path", "overview", "title",
                            "name", "release_date", "first_air_date"):
                    if not merged.get(key):
                        merged[key] = fallback.get(key)
                data = merged
            except Exception as exc:
                _log("DETAILS EN FALLBACK FAILED %s:%s %s" % (media, tmdb_id, exc))
        # A language can have no ar-AE text while TMDb hosts an official ar-SA
        # or ar-EG translation. Try those before persisting English fallback.
        if useful(data) and str(self.language or "").lower().startswith("ar"):
            data = self._fill_regional_arabic(tmdb_id, media, data)
        if useful(data):
            # Only a successfully returned TMDb movie details request gets this marker.
            # Optional artwork/cast can legitimately be empty, so completeness means
            # the details request finished, not that every optional field exists.
            if media == "movie":
                try:
                    data["_tivimate_details_complete"] = 1
                except Exception:
                    pass
            if cache_path:
                try:
                    tmp = cache_path + ".tmp"
                    with open_text(tmp, "w", encoding="utf-8") as f:
                        json.dump(data or {}, f, ensure_ascii=False)
                    atomic_replace(tmp, cache_path)
                    _log("DETAILS CACHE WRITE %s:%s" % (media, tmdb_id))
                except Exception as exc:
                    _log("DETAILS CACHE WRITE FAILED %s:%s %s" % (media, tmdb_id, exc))
        else:
            _log("DETAILS NOT CACHED incomplete %s:%s" % (media, tmdb_id))
        return data or {}

    def convert_public(self, item, kind):
        return self._convert(item or {}, kind)

    def _eligible(self, item, kind):
        date = item.get("release_date") if kind == "vod" else item.get("first_air_date")
        if not str(date or "").startswith("2026"):
            return False
        if str(item.get("original_language") or "").lower() != "en":
            return False
        if kind == "series":
            origins = item.get("origin_country") or []
            if origins and "US" not in origins:
                return False
        return True

    def _convert(self, item, kind):
        title = item.get("title") or item.get("name") or ""
        original = item.get("original_title") or item.get("original_name") or title
        date = item.get("release_date") if kind == "vod" else item.get("first_air_date")
        year = str(date or "")[:4]
        poster = item.get("poster_path") or ""
        backdrop = item.get("backdrop_path") or ""
        return {
            "_tmdb": True,
            "tmdb_id": str(item.get("id") or ""),
            "name": title,
            "title": title,
            "original_title": original,
            "year": year,
            "releaseDate": date or "",
            "rating": str(item.get("vote_average") or "")[:4],
            "plot": item.get("overview") or "",
            "description": item.get("overview") or "",
            "stream_icon": (IMAGE_BASE + "w500" + poster) if poster else "",
            "cover": (IMAGE_BASE + "w500" + poster) if poster else "",
            "backdrop_path": backdrop_url(backdrop) if backdrop else "",
            "logo_path": "",
            "media_type": kind,
        }
