# -*- coding: utf-8 -*-
"""One metadata display policy for TiviMateE2's movie/series pages.

Provider information is authoritative. Show it immediately and fill only
missing fields with matching TMDb data. Catalogue text remains a local fallback.
No network, artwork, or Enigma2 widget operations run in this module.
When a caller omits language, only the local TMDb language setting is read.
Callers own background fetching and stale-selection guards.
"""
import re
import os
import io
import json
import hashlib
from .py27_compat import text_type


def as_media_text(value):
    """Normalize Python2 unicode / UTF-8 / CP1256 without losing Arabic."""
    if value is None or isinstance(value, (list, dict)):
        return u""
    try:
        return text_type(value).strip()
    except (UnicodeError, TypeError, ValueError):
        return u""


def cached_provider_info(source, kind, item, memory=None):
    """Read existing provider-info RAM and disk cache. Never fetch in the UI thread."""
    row = item if isinstance(item, dict) else {}
    identity = row.get("stream_id") or row.get("series_id") or row.get("vod_id") or row.get("id")
    if identity in (None, "") or not isinstance(source, dict):
        return {}
    try:
        scoped = provider_cache_key(kind, identity, source)
        if isinstance(memory, dict) and isinstance(memory.get(scoped), dict) and memory.get(scoped):
            return memory[scoped]
        from .cache_manager import get_cache_dir
        path = os.path.join(get_cache_dir("metadata"),
                            "provider_info_" + hashlib.md5(scoped.encode("utf-8")).hexdigest() + ".json")
        if os.path.isfile(path) and os.path.getsize(path) > 2:
            with io.open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict) and data:
                if isinstance(memory, dict):
                    if len(memory) >= 1024:
                        memory.clear()
                    memory[scoped] = data
                return data
    except Exception:
        pass
    # Reuse the metadata already fetched by GENRE for this same server/media.
    try:
        from .cache_manager import stable_cache_key, persistent_cache_get
        key = stable_cache_key(
            "genre_provider_details_v1", source.get("type"),
            source.get("url") or source.get("base_url") or source.get("host"),
            source.get("username") or source.get("user"),
            source.get("password"), kind, as_media_text(identity))
        genre_data = persistent_cache_get(key)
        if isinstance(genre_data, dict) and genre_data:
            return genre_data
    except Exception:
        pass
    return {}


def _first(record, *names):
    if not isinstance(record, dict):
        return ""
    for name in names:
        value = record.get(name)
        if value is None or value == "":
            continue
        if isinstance(value, (dict, list)):
            continue
        text = as_media_text(value)
        if text and text.lower() not in ("none", "null"):
            return text
    return ""


def _genre(record):
    if not isinstance(record, dict):
        return ""
    genres = record.get("genres")
    if isinstance(genres, list):
        names = []
        for entry in genres:
            name = _first(entry, "name") if isinstance(entry, dict) else as_media_text(entry)
            if name:
                names.append(name)
        if names:
            return u", ".join(names[:3])
    # GENRE's compact provider cache may contain a comma-separated genres
    # string rather than TMDb's list-of-dicts representation.
    return _first(record, "genres", "genre", "genre_names", "category", "genre_name")


def _year(record):
    value = _first(record, "release_date", "first_air_date", "releasedate", "releaseDate", "year")
    match = re.search(r"(?:19|20)\d{2}", value)
    return match.group(0) if match else ""


def _rating(record):
    value = _first(record, "vote_average", "rating", "rating_5based")
    return "" if value in ("0", "0.0", "-", "--") else value


def _runtime(record, kind="vod"):
    value = _first(record, "runtime", "duration")
    if value:
        return value
    if kind in ("series", "tv") and isinstance(record, dict):
        runs = record.get("episode_run_time") or []
        if runs:
            return as_media_text(runs[0])
    return ""


def extract_metadata(row):
    """Normalize flat/nested provider info; never mutate the source item."""
    if not isinstance(row, dict):
        return {}
    merged = dict(row)
    for key in ("data", "movie_data", "series_data", "metadata", "details", "info"):
        nested = row.get(key)
        if isinstance(nested, dict):
            # Nested detail fields are richer, but empty values must not erase
            # already useful catalogue fields.
            for name, value in nested.items():
                if value not in (None, "", [], {}):
                    merged[name] = value
    return merged


def _contains_arabic_letters(value):
    """Ignore punctuation and Arabic-Indic digits when identifying real text."""
    import unicodedata
    for char in as_media_text(value):
        code = ord(char)
        if ((0x0600 <= code <= 0x06FF or 0x0750 <= code <= 0x077F or
             0x08A0 <= code <= 0x08FF or 0xFB50 <= code <= 0xFDFF or
             0xFE70 <= code <= 0xFEFF) and unicodedata.category(char).startswith("L")):
            return True
    return False


def _text_options(record, *keys):
    return [_first(record, key) for key in keys if _first(record, key)]


def _genre_options(record):
    if not isinstance(record, dict):
        return []
    values = []
    genres = record.get("genres")
    if isinstance(genres, list):
        names = []
        for entry in genres:
            name = _first(entry, "name") if isinstance(entry, dict) else as_media_text(entry)
            if name:
                names.append(name)
        if names:
            values.append(u", ".join(names[:3]))
    values.extend(_text_options(record, "genres", "genre", "genre_names", "category", "genre_name"))
    return values


def _select_text(language, *sources):
    """Server order, with Arabic-script stability in Arabic TMDb mode.

    Providers may return English detail rows after an Arabic catalogue row was
    already shown. Never let those late English responses replace available
    Arabic metadata when the user explicitly selected Arabic. For other
    languages and fields, preserve strict provider -> catalogue -> TMDb order.
    """
    # Cache > server > catalogue > TMDb is a strict source order.  Prefer an
    # Arabic variant *within* the first available source in Arabic mode; never
    # let a late TMDb title blank/replace already cached provider information.
    is_ar = as_media_text(language).lower().startswith("ar")
    for group in sources:
        options = [as_media_text(v) for v in group if as_media_text(v)]
        if not options:
            continue
        if is_ar:
            for value in options:
                if _contains_arabic_letters(value):
                    return value
        return options[0]
    return u""


def keep_arabic_on_late_update(existing, incoming, language):
    """Never replace visible Arabic with a later English metadata response.

    Call only after verifying that the response belongs to the same selected
    media record.  A new selection must never inherit the previous title.
    """
    old = as_media_text(existing)
    new = as_media_text(incoming)
    if str(language or "").lower().startswith("ar") and _contains_arabic_letters(old) and not _contains_arabic_letters(new):
        return old
    return new or old


def contains_arabic_text(value):
    return _contains_arabic_letters(value)


def merge_metadata(catalog=None, provider=None, tmdb=None, language=None, kind="vod", cached=None):
    """Provide the same visible title, plot, year, genre and rating policy.

    Server/provider values win for factual fields (year, rating, runtime).
    Text fields are provider-first unless Arabic TMDb language is selected:
    in that case prefer Arabic-script text already available from provider,
    catalogue or TMDb, rather than replacing it with late English provider data.
    The separate
    ``official_rating`` is the genuine TMDb score used ONLY by the existing
    TMDb badge/circle, not as a replacement for server metadata text.
    Country, logos, banners, and backdrops keep their independent renderers.
    """
    # An omitted language must NEVER silently mean English. The user may have
    # set TMDb to Arabic/French/Turkish, and some screens build initial rows
    # without an explicit locale before their asynchronous callbacks arrive.
    if language is None:
        try:
            from .tmdb_client import load_settings
            language = load_settings().get("language") or "en-US"
        except Exception:
            language = "en-US"
    catalog = extract_metadata(catalog)
    cached = extract_metadata(cached)
    provider = extract_metadata(provider)
    tmdb = extract_metadata(tmdb)
    title = _select_text(language,
                         _text_options(cached, "title", "name", "movie_name", "series_name", "original_title"),
                         _text_options(provider, "title", "name", "movie_name", "series_name", "original_title"),
                         _text_options(catalog, "title", "name", "movie_name", "series_name", "original_title"),
                         _text_options(tmdb, "title", "name"))
    # Arabic-original productions must retain their genuine Arabic title even
    # when the server's later detail row contains only the export/English name.
    # Keep the ordinary selected-language policy for all other films.
    original_language = (_first(cached, "original_language") or
                         _first(provider, "original_language") or
                         _first(catalog, "original_language") or
                         _first(tmdb, "original_language")).lower()
    if original_language.startswith("ar"):
        for value in _text_options(cached, "title", "name") + \
                     _text_options(provider, "title", "name") + \
                     _text_options(catalog, "title", "name") + \
                     _text_options(tmdb, "title", "name"):
            if _contains_arabic_letters(value):
                title = value
                break
    description = _select_text(language,
                               _text_options(cached, "description", "plot", "overview", "storyline", "plot_outline"),
                               _text_options(provider, "description", "plot", "overview", "storyline", "plot_outline"),
                               _text_options(catalog, "description", "plot", "overview", "storyline", "plot_outline"),
                               _text_options(tmdb, "overview", "description", "plot"))
    genres = _select_text(language, _genre_options(cached), _genre_options(provider),
                          _genre_options(catalog), _genre_options(tmdb))
    official_rating = _rating(tmdb)
    # Facts remain server-first. In Arabic mode, only textual fields (title,
    # overview, genres) prefer available Arabic over a later English response.
    return {
        "title": title,
        "description": description,
        "year": _year(cached) or _year(provider) or _year(catalog) or _year(tmdb),
        "rating": _rating(cached) or _rating(provider) or _rating(catalog) or official_rating,
        "official_rating": official_rating,
        "genre": genres,
        "runtime": (_runtime(cached, kind) or _runtime(provider, kind) or
                    _runtime(catalog, kind) or _runtime(tmdb, kind)),
        "category": (_first(cached, "category", "category_name") or
                     _first(provider, "category", "category_name") or
                     _first(catalog, "category", "category_name")),
    }


def provider_cache_key(kind, item_id, source):
    """Scope provider-detail RAM/disk caches to the exact IPTV source.

    Stream IDs are *not* globally unique.  Two providers may both have movie
    123, so a cache keyed only by `vod:123` can display another film's plot.
    Do not expose URLs, credentials, or MACs in cache filenames.
    """
    import hashlib
    source = source if isinstance(source, dict) else {}
    identity = u"\x1f".join(as_media_text(source.get(k)) for k in (
        "type", "id", "name", "url", "base_url", "portal", "host",
        "username", "user", "password", "mac"))
    source_hash = hashlib.sha256(identity.encode("utf-8", "ignore")).hexdigest()[:24]
    return u"%s:%s:%s" % (as_media_text(kind or u"vod"), source_hash, as_media_text(item_id))
