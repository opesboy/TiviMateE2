# -*- coding: UTF-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import ensure_dir
import io
import sys
import os
import re
import json
import requests
import time
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import quote_plus, unquote
try:
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    _tivimate_urllib3 = requests.packages.urllib3
except (ImportError, AttributeError):
    import urllib3 as _tivimate_urllib3
    from urllib3.exceptions import InsecureRequestWarning
from ..utilities import languageTranslate, log, getFileSize
from ..seeker import SubtitlesDownloadError, SubtitlesErrors

# Suppress insecure request warnings
_tivimate_urllib3.disable_warnings(InsecureRequestWarning)
from ..user_agents import get_random_ua
# Constants
HEADERS = {
    'User-Agent': get_random_ua(),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'fr,fr-FR;q=0.8,en-US;q=0.5,en;q=0.3',
    'Content-Type': 'text/html; charset=UTF-8',
    'Host': 'subs.ath.cx',
    'Referer': 'http://subs.ath.cx',
    'Upgrade-Insecure-Requests': '1',
    'Connection': 'keep-alive',
    'Accept-Encoding': 'gzip, deflate'
}

SESSION = requests.Session()
MAIN_URL = "http://subs.ath.cx"
DEBUG_PRETEXT = "subs.ath.cx"
def _tivimate_cache_dir():
    # Keep large subtitle HTML caches off /tmp (RAM). Prefer the same HDD/USB cache area used by TiviMateE2.
    candidates = ("/hdd/.tivimatee2-cache/subtitles", "/media/hdd/.tivimatee2-cache/subtitles", "/media/usb/.tivimatee2-cache/subtitles", "/usb/.tivimatee2-cache/subtitles")
    for path in candidates:
        parent = os.path.dirname(os.path.dirname(path))
        if os.path.isdir(parent):
            try:
                ensure_dir(path)
                if os.access(path, os.W_OK):
                    return path
            except Exception:
                pass
    return "/var/volatile/tmp"

CACHE_DIR = _tivimate_cache_dir()
CACHE_FILE = os.path.join(CACHE_DIR, "subs_ath_cx.html")
CACHE_TIMEOUT = 86400  # 24 hours in seconds

# Roman numeral mapping
ROMAN_NUMERAL_MAP = [
    (r'\bII\b', '2'), (r'\bIII\b', '3'), (r'\bIV\b', '4'), (r'\bV\b', '5'),
    (r'\bVI\b', '6'), (r'\bVII\b', '7'), (r'\bVIII\b', '8'), (r'\bIX\b', '9'),
    (r'\bX\b', '10'), (r'\bXI\b', '11'), (r'\bXII\b', '12'), (r'\bXIII\b', '13'),
    (r'\bXIV\b', '14'), (r'\bXV\b', '15'), (r'\bXVI\b', '16'), (r'\bXVII\b', '17'),
    (r'\bXVIII\b', '18'), (r'\bXIX\b', '19'), (r'\bXX\b', '20'), (r'\bI\b', '1')
]

def get_url(url, referer=None):
    headers = {'User-Agent': HEADERS['User-Agent']}
    if referer:
        headers['Referer'] = referer

    response = SESSION.get(url, headers=headers, verify=False)
    return response.text.replace('\n', '')

def get_rating(downloads):
    return min(10, max(1, downloads // 50 + 1))

def generate_title_variations(text):
    """
    Generate variations of a title with both Roman numerals and digits
    """
    variations = [text]

    # Convert Roman numerals to digits
    digit_version = text
    for roman, digit in ROMAN_NUMERAL_MAP:
        digit_version = re.sub(roman, digit, digit_version, flags=re.IGNORECASE)
    if digit_version != text:
        variations.append(digit_version)

    # Convert digits to Roman numerals (reverse mapping)
    for roman, digit in ROMAN_NUMERAL_MAP:
        roman_version = re.sub(r'\b' + digit + r'\b', roman, text, flags=re.IGNORECASE)
        if roman_version != text and roman_version not in variations:
            variations.append(roman_version)

    return variations

def get_cached_content():
    """
    Get content from cache if available and not expired
    """
    if os.path.exists(CACHE_FILE):
        # Check if cache is still valid
        if time.time() - os.path.getmtime(CACHE_FILE) < CACHE_TIMEOUT:
            try:
                with io.open(CACHE_FILE, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                log(__name__, (u'{0} Error reading cache: {1}'.format(DEBUG_PRETEXT, e)))

    return None

def save_content_to_cache(content):
    """
    Save content to cache file
    """
    try:
        ensure_dir(CACHE_DIR)
        with io.open(CACHE_FILE, 'w', encoding='utf-8') as f:
            f.write(content)
        log(__name__, (u'{0} Content cached to {1}'.format(DEBUG_PRETEXT, CACHE_FILE)))
    except Exception as e:
        log(__name__, (u'{0} Error saving cache: {1}'.format(DEBUG_PRETEXT, e)))

def search_subtitles(file_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):
    subtitles_list = []
    msg = ""
    selected = [x for x in (lang1, lang2, lang3) if x]
    arabic_selected = False
    for lang in selected:
        try:
            if languageTranslate(lang, 0, 2) == "ar" or str(lang).lower() in ("arabic", "ar", "ara"):
                arabic_selected = True
                break
        except Exception:
            if str(lang).lower() in ("arabic", "ar", "ara"):
                arabic_selected = True
                break
    if not arabic_selected:
        log(__name__, "%s Arabic-only archive skipped for selected languages: %s" % (DEBUG_PRETEXT, selected))
        return subtitles_list, "", msg
    # Preserve the archive's real language. Do not label it Turkish/French/etc.
    if tvshow:
        search_string = "%s S%02dE%02d" % (tvshow, int(season), int(episode))
    else:
        search_string = "%s (%s)" % (title, year) if year else title
    title_variations = generate_title_variations(tvshow or title)
    for title_var in title_variations:
        get_subtitles_list(title_var, search_string, "ar", "Arabic", subtitles_list)
    return subtitles_list, "", msg

def get_subtitles_list(title, search_string, lang_short, lang_long, subtitles_list):
    url = (u'{0}/subtitles'.format(MAIN_URL))

    # Try to get content from cache first
    content = get_cached_content()

    if content is None:
        # Content not in cache or cache expired, download it
        log(__name__, (u'{0} Fetching: {1}'.format(DEBUG_PRETEXT, url)))
        try:
            response = SESSION.get(url, headers=HEADERS, verify=False)
            response.raise_for_status()
            content = response.text
            save_content_to_cache(content)
        except requests.RequestException as e:
            log(__name__, (u'{0} Failed to fetch subtitles: {1}'.format(DEBUG_PRETEXT, e)))
            return
    else:
        log(__name__, (u'{0} Using cached content from {1}'.format(DEBUG_PRETEXT, CACHE_FILE)))

    try:
        encoded_title = quote_plus(title).replace('+', '.')
        subtitles = re.findall((u'(<td><a href.+?>{0}.+?</a></td>)'.format(encoded_title)), content, re.IGNORECASE)

        for subtitle in subtitles:
            match = re.search(r'<td><a href="(.+?)">(.+?)</a></td>', subtitle)
            if match:
                id_, filename = match.groups()
                filename = filename.replace('.srt', '').strip()
                if filename not in ['Εργαστήρι Υποτίτλων', 'subs4series']:
                    log(__name__, (u'{0} Found subtitle: {1} (id = {2})'.format(DEBUG_PRETEXT, filename, id_)))
                    subtitles_list.append({
                        'no_files': 1,
                        'filename': filename,
                        'sync': True,
                        'id': id_,
                        'language_flag': (u'flags/{0}.gif'.format(lang_short)),
                        'language_name': lang_long
                    })
    except Exception as e:
        log(__name__, (u'{0} Error parsing subtitles: {1}'.format(DEBUG_PRETEXT, e)))

def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    subtitle_info = subtitles_list[pos]
    language = subtitle_info["language_name"]
    subtitle_id = subtitle_info["id"]

    # Construct download link
    download_link = (u'http://subs.ath.cx/subtitles/{0}'.format(subtitle_id))
    log(__name__, (u'{0} Downloading from: {1}'.format(DEBUG_PRETEXT, download_link)))

    try:
        response = SESSION.get(download_link, headers=HEADERS, verify=False, allow_redirects=True)
        response.raise_for_status()  # Ensure the request was successful
    except requests.RequestException as e:
        log(__name__, (u'{0} Download failed: {1}'.format(DEBUG_PRETEXT, e)))
        return False, language, None  # Return failure

    # Ensure tmp directory exists
    ensure_dir(tmp_sub_dir)

    # Save file
    local_tmp_file = os.path.join(tmp_sub_dir, subtitle_id)  # Use proper filename
    try:
        with open(local_tmp_file, "wb") as file:
            file.write(response.content)

        log(__name__, (u'{0} Subtitles saved to: {1}'.format(DEBUG_PRETEXT, local_tmp_file)))
    except Exception as e:
        log(__name__, (u'{0} Error saving subtitle: {1}'.format(DEBUG_PRETEXT, e)))
        return False, language, None  # Return failure

    # Check file type (RAR, ZIP, or SRT)
    packed = False
    subs_file = local_tmp_file
    try:
        with open(local_tmp_file, "rb") as file:
            file_header = file.read(2).decode(errors="ignore")
            if file_header.startswith("R"):
                packed = True
                subs_file = "rar"
            elif file_header.startswith("PK"):
                packed = True
                subs_file = "zip"
            else:
                subs_file = local_tmp_file  # It's an SRT file
    except Exception as e:
        log(__name__, (u'{0} Error checking file type: {1}'.format(DEBUG_PRETEXT, e)))

    log(__name__, (u'{0} Returning: packed={1}, language={2}, subs_file={3}'.format(DEBUG_PRETEXT, packed, language, subs_file)))
    return packed, language, subs_file  # Standard output
