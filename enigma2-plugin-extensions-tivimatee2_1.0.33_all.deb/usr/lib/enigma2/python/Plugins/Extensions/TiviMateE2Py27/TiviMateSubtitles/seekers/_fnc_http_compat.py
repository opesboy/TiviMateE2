# -*- coding: utf-8 -*-
"""Small, scoped stdlib HTTP fallback for SubDL and OpenSubtitles REST providers.

This is intentionally not a global replacement for requests.  Other providers
continue using their own HTTP clients.  TLS verification is left enabled.
Works on Python 2.7 (urllib2) and Python 3 for isolated regression tests.
"""
from __future__ import absolute_import
import json as _json
try:
    import urllib2 as _urlrequest
    import urllib as _urlparse
    from urllib2 import HTTPError as _HTTPError, URLError as _URLError
except ImportError:
    from urllib import request as _urlrequest, parse as _urlparse
    from urllib.error import HTTPError as _HTTPError, URLError as _URLError

try:
    _text_type = unicode
except NameError:
    _text_type = str


class RequestException(Exception):
    pass


class HTTPError(RequestException):
    pass


class _Exceptions(object):
    RequestException = RequestException
    HTTPError = HTTPError


exceptions = _Exceptions()


def _bytes(value):
    if isinstance(value, bytes):
        return value
    if isinstance(value, _text_type):
        return value.encode('utf-8')
    return str(value).encode('utf-8')


def _query(params):
    result = []
    for key, val in (params or {}).items():
        if val is None:
            continue
        if isinstance(val, (list, tuple)):
            for v in val:
                if v is not None:
                    result.append((_bytes(key), _bytes(v)))
        else:
            result.append((_bytes(key), _bytes(val)))
    return _urlparse.urlencode(result)


class _Response(object):
    def __init__(self, raw, status_code=None):
        self._raw = raw
        self.status_code = status_code if status_code is not None else raw.getcode()
        self.headers = dict(raw.info().items())
        self._content = None

    @property
    def content(self):
        if self._content is None:
            self._content = self._raw.read()
            self.close()
        return self._content

    @property
    def text(self):
        return self.content.decode('utf-8', 'replace')

    def json(self):
        return _json.loads(self.content.decode('utf-8'))

    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPError('HTTP %d' % self.status_code)

    def iter_content(self, chunk_size=8192):
        if self._content is not None:
            for idx in range(0, len(self._content), chunk_size):
                yield self._content[idx:idx + chunk_size]
            return
        try:
            while True:
                chunk = self._raw.read(chunk_size)
                if not chunk:
                    break
                yield chunk
        finally:
            self.close()

    def close(self):
        if self._raw is not None:
            try:
                self._raw.close()
            except Exception:
                pass
            self._raw = None


def _request(method, url, params=None, headers=None, data=None, json=None,
             timeout=10, stream=False, allow_redirects=True, verify=True, **kwargs):
    if not url or not (url.startswith('https://') or url.startswith('http://')):
        raise RequestException('Invalid URL scheme')
    if params:
        query = _query(params)
        url += ('&' if '?' in url else '?') + query
    headers = dict(headers or {})
    if json is not None:
        data = _bytes(_json.dumps(json, ensure_ascii=False))
        headers.setdefault('Content-Type', 'application/json')
    elif data is not None and not isinstance(data, (bytes, _text_type)):
        data = _bytes(_query(data))
    elif isinstance(data, _text_type):
        data = _bytes(data)
    # urllib2 follows redirects and validates HTTPS certificates on supported
    # runtimes.  Never silently disable certificate checks for these APIs.
    if verify is False:
        raise RequestException('Insecure TLS disabled for subtitle REST fallback')
    try:
        req = _urlrequest.Request(url, data=data, headers=headers)
        if method == 'POST' and data is None:
            try:
                req.get_method = lambda: 'POST'
            except Exception:
                pass
        raw = _urlrequest.urlopen(req, timeout=timeout)
        return _Response(raw)
    except _HTTPError as err:
        return _Response(err, status_code=err.code)
    except (_URLError, ValueError, IOError) as err:
        raise RequestException('%s' % (err.__class__.__name__,))


def get(url, **kwargs):
    return _request('GET', url, **kwargs)


def post(url, **kwargs):
    return _request('POST', url, **kwargs)


class Session(object):
    def get(self, url, **kwargs):
        return get(url, **kwargs)

    def post(self, url, **kwargs):
        return post(url, **kwargs)
