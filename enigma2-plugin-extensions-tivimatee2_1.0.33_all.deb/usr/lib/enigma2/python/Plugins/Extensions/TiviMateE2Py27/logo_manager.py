# -*- coding: utf-8 -*-
"""Language-aware transparent TMDb title logos for every Enigma2 screen.

Use the selected TMDb metadata language, not the device interface language.
Images are selected by TMDb's real iso_639_1 tag; no image translation.
All remote lookups in this module must run on an existing background worker.
"""
from . import artwork_queue as _queue
from .py27_compat import text_type
from collections import OrderedDict
import threading
import re
_PROVIDER_CONTEXTS = OrderedDict()
_CONTEXT_LOCK = threading.RLock()


def _provider_for(url):
    with _CONTEXT_LOCK:
        return _PROVIDER_CONTEXTS.get(_queue.normalise_url(url))


KIND = "logos"
PROVIDER_KEYS = ("logo", "title_logo", "logo_path", "clearlogo",
                 "logo_url", "clearlogo_url", "title_logo_url", "clear_logo")
# Match Python 3's TMDb candidate support. Keep JPEG available as a
# candidate, while transparent PNG validation still happens before display.
RASTER = (".png", ".jpg", ".jpeg", ".webp", ".svg")


def _ordered_languages(values):
    """Python 2.7 dict.fromkeys() does not retain preference order.

    Same stable selected -> original -> English ordering as Python 3.
    """
    return tuple(OrderedDict.fromkeys(value for value in values if value))


def provider_logo_url(source, item, extra=None):
    url = _queue.find_provider_asset(source, item, PROVIDER_KEYS, extra)
    if url and isinstance(source, dict):
        # Match the canonical lookup used by the shared artwork transport.
        key = _queue.normalise_url(url)
        with _CONTEXT_LOCK:
            _PROVIDER_CONTEXTS.pop(key, None)
            _PROVIDER_CONTEXTS[key] = dict(source)
            while len(_PROVIDER_CONTEXTS) > 384:
                _PROVIDER_CONTEXTS.popitem(last=False)
    return url


def tmdb_logo_url(value, size="original"):
    value = text_type(value or u"").strip().replace("\\/", "/")
    if value.startswith("/") and not value.startswith("//"):
        # TMDb's image CDN can rasterize SVG originals when requested as PNG.
        # Old DreamOS cannot decode SVG directly, so do not feed it an SVG.
        if value.lower().endswith('.svg'):
            value = value[:-4] + '.png'
        return "https://image.tmdb.org/t/p/%s" % size + value
    if value.startswith(("https://", "http://")):
        from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit
        try:
            if ((urlsplit(value).hostname or '').lower() == 'image.tmdb.org'
                    and value.lower().split('?', 1)[0].endswith('.svg')):
                prefix, tail = value.split('?', 1) if '?' in value else (value, '')
                value = prefix[:-4] + '.png' + (('?' + tail) if tail else '')
        except (ValueError, TypeError):
            pass
        return value
    return ""


def logo_language(client=None):
    """Resolve locale from TMDb Settings (including Auto) to ISO-639-1."""
    if client is None:
        from .tmdb_client import TMDbClient
        client = TMDbClient()
    return str(getattr(client, "language", "en-US") or "en-US").split("-")[0].split("_")[0].strip().lower() or "en"


_ARAB_COUNTRIES = frozenset(('AE', 'SA', 'EG', 'BH', 'QA', 'OM', 'KW', 'IQ',
                             'JO', 'LB', 'SY', 'PS', 'YE', 'MA', 'DZ', 'TN', 'LY', 'SD'))


def preferred_logo_languages(client=None, details=None, item=None, title='', selected=None):
    """Prefer genuine Arabic clearlogos for Arabic originals, even in English UI.

    Do not change the TMDb metadata language: this concerns title artwork only.
    Always fall back to English, then the language-neutral gallery.
    """
    wanted = text_type(selected or logo_language(client)).split('-')[0].split('_')[0].lower() or 'en'
    d = details if isinstance(details, dict) else {}
    row = item if isinstance(item, dict) else {}
    original = text_type(d.get('original_language') or row.get('original_language') or u'').split('-')[0].lower()
    countries = d.get('origin_country') or d.get('production_countries') or row.get('origin_country') or []
    if isinstance(countries, (str, unicode)):
        countries = [countries]
    codes = set()
    if isinstance(countries, (tuple, list)):
        for entry in countries:
            if isinstance(entry, dict):
                entry = entry.get('iso_3166_1') or ''
            codes.add(text_type(entry).upper())
    is_arabic = (original == 'ar' or
                 (not original and bool(codes & _ARAB_COUNTRIES)) or
                 (not original and not codes and
                  bool(re.search(u'[\u0600-\u06FF]', text_type(title or u'')))))
    if wanted == 'en' and is_arabic:
        return ('ar', 'en')
    # Original-language logos matter for Japanese, Korean, Turkish, Hindi,
    # Russian and every other media language, not just Arabic/English.
    return _ordered_languages((wanted, original, 'en'))


def image_languages(client=None, details=None, item=None, title=''):
    """Fetch actual requested/original language logos plus neutral fallbacks."""
    langs = preferred_logo_languages(client, details, item, title)
    return ",".join(_ordered_languages(langs + ('null',)))


def _valid_logos(entries):
    return [row for row in (entries or []) if isinstance(row, dict) and
            str(row.get("file_path") or "").lower().split("?")[0].endswith(RASTER)]


def has_language_logo(entries, language=None):
    selected = str(language or "en").split("-")[0].lower()
    return any(str(row.get("iso_639_1") or "").lower() == selected
               for row in _valid_logos(entries))


def best_tmdb_logo(entries, language="en"):
    """Pick the best genuine logo by ordered language preference and votes.

    `language` may be a locale string or a tuple of preferred languages.
    Never infer a translation from a neutral image or relabel its language.
    """
    if isinstance(language, (tuple, list)):
        ordered = tuple(str(x or '').split('-')[0].lower() for x in language if x)
    else:
        ordered = (str(language or 'en').split('-')[0].lower(),)
    ordered = _ordered_languages(ordered + ('en',))
    def score(row):
        lang = str(row.get('iso_639_1') or '').lower()
        rank = len(ordered) - ordered.index(lang) + 1 if lang in ordered else (1 if not lang else 0)
        try:
            votes = float(row.get('vote_average') or 0)
        except (ValueError, TypeError):
            votes = 0.0
        try:
            width = int(row.get('width') or 0)
        except (ValueError, TypeError):
            width = 0
        # Prefer a real PNG over WebP on DreamOS/Python 2.7. Some receivers
        # have no WebP decoder, leaving a valid TMDb logo invisible.
        path = text_type(row.get('file_path') or u'').lower().split('?', 1)[0]
        # Requested/original language outranks format; an SVG is fetched as
        # transparent PNG by tmdb_logo_url(), so it is not a second-class logo.
        return (rank, 1 if path.endswith('.png') else 0, votes, width)
    # A logo in ANY language for the SAME verified TMDb ID is preferable
    # to a blank logo. Preferred/original/English/neutral still score first.
    rows = _valid_logos(entries)
    return max(rows, key=score).get('file_path') if rows else ''


def localized_logo_url(client, media, tmdb_id, images=None, size="w500",
                       details=None, item=None, title=''):
    """Return a verified matching-language logo with English/neutral fallback.

    For Arabic originals use ar -> en even if TMDb interface language is en.
    Execute on a background worker: remote images metadata may be needed.
    """
    media = "tv" if str(media or "").lower() in ("tv", "series") else "movie"
    previous = _valid_logos(((images or {}).get("logos") or []) if isinstance(images, dict) else images)
    info = details if isinstance(details, dict) else {}
    if not info and isinstance(images, dict) and 'original_language' in images:
        info = images
    langs = preferred_logo_languages(client, info, item, title)
    # If callers know only the id and the interface is English, determine
    # the original language before treating an English logo as final.
    try:
        eligible = bool(tmdb_id and int(str(tmdb_id)) > 0 and client.configured())
    except (ValueError, TypeError, AttributeError):
        eligible = False
    if eligible and not info.get('original_language') and not (
            info.get('origin_country') or info.get('production_countries') or
            (isinstance(item, dict) and item.get('original_language'))):
        try:
            metadata = client._get('/%s/%s' % (media, tmdb_id), {'language': 'en-US'}) or {}
            if isinstance(metadata, dict):
                info = metadata
                langs = preferred_logo_languages(client, info, item, title)
        except Exception:
            pass
    # A preferred-language SVG is just as usable as a PNG: the TMDb CDN
    # supports a raster PNG variant. Do not force a slow gallery request here.
    if has_language_logo(previous, langs[0]):
        return tmdb_logo_url(best_tmdb_logo(previous, langs), size)
    if eligible:
        try:
            # The image gallery is tied to this exact TMDb ID. Do not limit
            # returned artwork to the interface language or English: a film
            # can have its only available clearlogo in another language.
            # TMDb's images endpoint still applies the client's default
            # language.  Passing {} previously returned mostly that locale
            # (and neutral), leaving English/foreign-only clearlogos invisible.
            # Request a bounded multilingual gallery for this VERIFIED title.
            # No language filter at all: TMDb then returns the logos of EVERY
            # language for this verified title. best_tmdb_logo() still ranks the
            # preferred/original/English/neutral ones first.
            payload = client._get('/%s/%s/images' % (media, tmdb_id), {
                'language': None,
            }) or {}
            previous.extend(_valid_logos(payload.get('logos') or []))
        except Exception:
            pass
    return tmdb_logo_url(best_tmdb_logo(previous, langs), size)


def cached(url):
    """One cache lookup policy for title logos across every screen.

    Provider/package badges may be opaque. Only TMDb title logos must use
    the genuine alpha PNG path, including DreamOS' recovered .alpha.png cache.
    This preserves the existing storage, image workers and queues.
    """
    url = _queue.normalise_url(url)
    if not url:
        return ""
    try:
        from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit
        if (urlsplit(url).hostname or '').lower() == 'image.tmdb.org':
            from .genre_ultra_artwork import _cached_transparent_logo
            return _cached_transparent_logo(url)
    except (ImportError, TypeError, ValueError):
        pass
    return _queue._cached_artwork_core(url, KIND)


def request(url, callback=None, priority=0, errback=None, source=None):
    from .unified_genre_artwork import request as genre_request
    return genre_request(url, KIND, callback=callback, priority=priority,
                         errback=errback, source=source)


def prefetch(urls, priority=1):
    return _queue.prefetch_artwork(urls, KIND, priority)
