# -*- coding: utf-8 -*-
"""CSPRNG wrapper for legacy interpreter. Never uses random.random."""
import os
import binascii

def token_bytes(nbytes=32):
    return os.urandom(int(nbytes))

def token_hex(nbytes=32):
    return binascii.hexlify(token_bytes(nbytes))

def token_urlsafe(nbytes=32):
    import base64
    return base64.urlsafe_b64encode(token_bytes(nbytes)).rstrip('=')

def compare_digest(a, b):
    # Python 2.7's hmac lacks compare_digest; constant-time for equal-size ASCII strings.
    a = str(a); b = str(b)
    different = len(a) ^ len(b)
    for x, y in zip(a, b): different |= ord(x) ^ ord(y)
    return different == 0
