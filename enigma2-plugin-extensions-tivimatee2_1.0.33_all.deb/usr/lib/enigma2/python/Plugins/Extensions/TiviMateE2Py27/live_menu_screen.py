# -*- coding: utf-8 -*-
"""Opaque Live Menu; never show the unrelated Enigma2 DVB channel."""
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from .vti_compat import VTiTextLabel as Label
from Components.Pixmap import Pixmap
from enigma import ePoint
from .display_scale import scale_skin, sx, sy

_ASSETS = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/live/'

SKIN = ('<screen name="TiviMateLiveMenu" position="center,center" size="1920,1080" '
        'flags="wfNoBorder" backgroundColor="#090E19" transparent="0">'
        '<widget name="background" position="0,0" size="1920,1080" pixmap="' + _ASSETS + 'live_menu_background.png" alphatest="off" scale="1" zPosition="1" />'
        '<widget name="focus" position="94,192" size="850,140" pixmap="' + _ASSETS + 'live_menu_gold_focus.png" alphatest="blend" scale="1" zPosition="2" />'
        '<widget name="heading" position="100,93" size="750,65" font="Regular;52" foregroundColor="#FCD431" transparent="1" zPosition="4" />'
        + ''.join('<widget name="number%d" position="105,%d" size="50,62" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#111621" halign="center" valign="center" zPosition="4" />'
                  '<widget name="icon%d" position="159,%d" size="79,79" pixmap="%slive_menu_icon_%d.png" alphatest="blend" scale="1" zPosition="5" />' % (i, 217+i*149, i, 204+i*149, _ASSETS, i) for i in range(4))
        + ''.join('<widget name="name%d" position="248,%d" size="680,56" font="Regular;38" foregroundColor="#FFFFFF" transparent="1" zPosition="5" />'
                  '<widget name="detail%d" position="250,%d" size="670,34" font="Regular;24" foregroundColor="#CAD0D6" transparent="1" zPosition="5" />' % (i, 208+i*149, i, 266+i*149) for i in range(4))
        + '<widget name="previewTitle" position="1022,790" size="730,54" font="Regular;34" foregroundColor="#E1EAF6" transparent="1" halign="center" zPosition="5" />'
        + '<widget name="previewHint" position="1020,853" size="735,36" font="Regular;24" foregroundColor="#AAB6C6" transparent="1" halign="center" zPosition="5" />'
        + ''.join('<widget name="foot%d" position="%d,949" size="310,48" font="Regular;28" foregroundColor="#E7E9EE" transparent="1" zPosition="5" />' % (i,x) for i,x in enumerate((235,670,1114,1550)))
        + '</screen>')

class LiveMenuScreen(Screen):
    skin = scale_skin(SKIN)
    ITEMS = (("Change View", "Windows / Classic", "#", "change_live_view"),
             ("Favorites", "My channels", "*", "favorites"),
             ("Export to Enigma2", "Channels, packages & picons", ">", "export_enigma2"),
             ("Live Options", "Playback and appearance", "@", "options"))
    def __init__(self, session):
        Screen.__init__(self, session)
        self.index = 0
        self['background'] = Pixmap()
        self['focus'] = Pixmap()
        self['heading'] = Label('LIVE MENU')
        self['previewTitle'] = Label('TiviMateE2 LIVE')
        self['previewHint'] = Label('Select an option on the left')
        for i,label in enumerate(('Exit','OK','Options','Info')):
            self['foot%d' % i] = Label(label)
        for i, (name, detail, icon, _action) in enumerate(self.ITEMS):
            self['number%d' % i] = Label('%d' % (i+1))
            self['icon%d' % i] = Pixmap()
            self['name%d' % i] = Label(name)
            self['detail%d' % i] = Label(detail)
        self['actions'] = ActionMap(['OkCancelActions','DirectionActions','ColorActions','NumberActions'], {
            'ok': self._choose, 'green': self._choose, 'cancel': self._cancel,
            'red': self._cancel, 'up': self._up, 'down': self._down,
            'left': self._up, 'right': self._down,
            '1': lambda: self._choose_index(0), '2': lambda: self._choose_index(1),
            '3': lambda: self._choose_index(2), '4': lambda: self._choose_index(3),
            'yellow': lambda: self._choose_index(3), 'blue': lambda: self._choose_index(2)
        }, -1)
        self.onLayoutFinish.append(self._refresh)
    def _refresh(self):
        try: self['focus'].instance.move(ePoint(sx(94),sy(192+self.index*149)))
        except Exception: pass
    def _up(self):
        self.index=(self.index-1)%len(self.ITEMS); self._refresh()
    def _down(self):
        self.index=(self.index+1)%len(self.ITEMS); self._refresh()
    def _choose_index(self,index):
        self.index=index; self._choose()
    def _choose(self):
        self.close((self.ITEMS[self.index][0],self.ITEMS[self.index][3]))
    def _cancel(self):
        self.close(None)
