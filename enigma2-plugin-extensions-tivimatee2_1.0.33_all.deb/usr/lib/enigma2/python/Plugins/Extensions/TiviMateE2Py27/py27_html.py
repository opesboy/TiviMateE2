# -*- coding: utf-8 -*-
"""Python 2.7 standalone HTML compatibility with standard-library only."""
import cgi
try:
    from HTMLParser import HTMLParser
except ImportError:
    from html.parser import HTMLParser

def escape(value, quote=True):
    return cgi.escape(value, quote=quote)

def unescape(value):
    try:
        return HTMLParser().unescape(value)
    except Exception:
        return value
