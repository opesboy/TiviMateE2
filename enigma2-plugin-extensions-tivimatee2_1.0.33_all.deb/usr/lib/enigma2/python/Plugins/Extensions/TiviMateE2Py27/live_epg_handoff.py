# -*- coding: utf-8 -*-
"""Short-lived, per-channel EPG handoff from the visible Live browser.

Only on-screen, already-resolved programme data is transferred to the player.
Never performs a network/disk lookup, and never shares a handoff across rows.
"""
import time
from .xtream_epg_normalizer import epg_row_title


def _identity(item):
    item = item or {}
    value = (item.get('ch_id') or item.get('stream_id') or
             item.get('id') or item.get('url') or item.get('cmd') or
             item.get('name') or u'')
    try:
        if isinstance(value, bytes):
            return value.decode('utf-8', 'replace').strip()
        return type(u'')(value).strip()
    except Exception:
        return u'' 


def _title(event):
    """Resolve real provider programme title fields, never the plot."""
    if not isinstance(event, dict):
        return u''
    return epg_row_title(event)


def with_handoff(channels, index, current, following=None, now_time=None):
    """Return a shallow row copy containing only its own positive EPG titles."""
    rows = list(channels or [])
    if not (0 <= index < len(rows)) or not isinstance(rows[index], dict):
        return rows
    if not _title(current):
        return rows
    row = dict(rows[index])
    now = dict(current)
    now['title'] = _title(now)
    nxt = dict(following) if isinstance(following, dict) else {}
    if _title(nxt):
        nxt['title'] = _title(nxt)
    row['_live_epg_handoff'] = {
        'at': float(time.time() if now_time is None else now_time),
        'channel': _identity(row),
        'now': now,
        'next': nxt,
    }
    rows[index] = row
    return rows


def read_handoff(item, max_age=300, now_time=None):
    """Reject a different channel, an empty title or an outdated browser snapshot."""
    if not isinstance(item, dict):
        return None
    payload = item.get('_live_epg_handoff')
    if not isinstance(payload, dict):
        return None
    try:
        age = float(time.time() if now_time is None else now_time) - float(payload.get('at'))
    except (TypeError, ValueError, OverflowError):
        return None
    if age < -5 or age > max_age or payload.get('channel') != _identity(item):
        return None
    current = payload.get('now')
    if not _title(current):
        return None
    # A programme with absolute timestamps must still be current, not an old
    # now-showing item retained after the next programme began.
    try:
        stop = int(float(current.get('stop_timestamp') or current.get('end') or 0))
    except (TypeError, ValueError, OverflowError):
        stop = 0
    if stop and stop < float(time.time() if now_time is None else now_time) - 15:
        return None
    return (dict(current), dict(payload.get('next') or {}))
