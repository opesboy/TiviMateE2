# -*- coding: utf-8 -*-
"""320x320 circular VOD poster with REAL PNG transparency on Python 2 DreamOS.

Does not alter the downloaded source artwork.  Unlike ePixmap.setCornerRadius,
this works on older DreamOS builds because the image itself contains alpha.
All image processing is outside the Enigma2 GUI thread; one concurrent worker.
"""
from __future__ import absolute_import
import hashlib
import os
import subprocess
import threading

from .storage import data_path
from .py27_compat import which, subprocess_run
from .py27_futures import ThreadPoolExecutor

_POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='TiviPlayerCircle')
_LOCK = threading.RLock()
_PENDING = {}
_MAX_PENDING = 8
_SIZE = 320


def _key(source):
    stat = os.stat(source)
    identity = (os.path.realpath(source) + '|' + str(stat.st_size) + '|'
                + str(int(stat.st_mtime)) + '|round-r2')
    if not isinstance(identity, bytes):
        identity = identity.encode('utf-8')
    return hashlib.sha256(identity).hexdigest()[:28]


def _destination(source):
    return data_path('player_circles', 'round_%s.png' % _key(source))


def cached(source):
    try:
        if not source or not os.path.isfile(source):
            return ''
        target = _destination(source)
        if os.path.isfile(target) and os.path.getsize(target) > 2000:
            return target
    except Exception:
        pass
    return ''


def _pillow(source, target):
    from PIL import Image, ImageDraw
    img = Image.open(source)
    try:
        img = img.convert('RGBA')
        w, h = img.size
        ratio = max(float(_SIZE) / max(1, w), float(_SIZE) / max(1, h))
        nw, nh = max(_SIZE, int(w * ratio + 0.5)), max(_SIZE, int(h * ratio + 0.5))
        method = getattr(Image, 'LANCZOS', getattr(Image, 'ANTIALIAS', Image.BICUBIC))
        img = img.resize((nw, nh), method)
        x, y = (nw - _SIZE)//2, (nh - _SIZE)//2
        img = img.crop((x, y, x + _SIZE, y + _SIZE))
        alpha = Image.new('L', (_SIZE, _SIZE), 0)
        artist = ImageDraw.Draw(alpha)
        artist.ellipse((2, 2, _SIZE-3, _SIZE-3), fill=255)
        img.putalpha(alpha)
        # Draw a thin anti-neutral white rim as on the Python 3 player.
        rim = ImageDraw.Draw(img)
        for d in (3, 4, 5):
            rim.ellipse((d, d, _SIZE-1-d, _SIZE-1-d), outline=(238,242,246,255))
        img.save(target, 'PNG')
    finally:
        try: img.close()
        except Exception: pass


def _ffmpeg(source, target):
    tool = which('ffmpeg')
    if not tool:
        raise RuntimeError('ffmpeg not found')
    # Old-compatible scale/crop and alpha channel, no dependency on PIL.
    # Source stays untouched; the square is center-cropped before the mask.
    vf = ("scale=320:320:force_original_aspect_ratio=increase,"
          "crop=320:320,format=rgba,"
          "geq=r='r(X,Y)':g='g(X,Y)':b='b(X,Y)':"
          "a='if(lte((X-159.5)*(X-159.5)+(Y-159.5)*(Y-159.5),24750),255,0)'")
    subprocess_run([tool, '-nostdin', '-loglevel', 'error', '-y', '-i', source,
                    '-vf', vf, '-frames:v', '1', '-c:v', 'png', target],
                   timeout=12, check=True, stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE)


def _imagemagick(source, target):
    tool = which('convert')
    if not tool:
        raise RuntimeError('ImageMagick not found')
    mask = os.path.join(os.path.dirname(__file__), 'tivimate_infobar',
                        'player', 'player_circle_alpha_mask_r2.png')
    if not os.path.isfile(mask):
        raise RuntimeError('PNG mask missing')
    subprocess_run([tool, source, '-auto-orient', '-resize', '320x320^',
                    '-gravity', 'center', '-extent', '320x320', mask,
                    '-alpha', 'off', '-compose', 'CopyOpacity', '-composite', target],
                   timeout=12, check=True, stdout=subprocess.PIPE,
                   stderr=subprocess.PIPE)


def generate(source):
    hit = cached(source)
    if hit:
        return hit
    try:
        target = _destination(source)
    except Exception:
        return ''
    temp = target + '.%d.png' % os.getpid()
    try:
        for method in (_pillow, _ffmpeg, _imagemagick):
            try:
                method(source, temp)
                if os.path.isfile(temp) and os.path.getsize(temp) > 2000:
                    # Rename atomically: never show a partially written PNG.
                    os.rename(temp, target)
                    return target
            except Exception as exc:
                print('[TiviMateE2Py27] circular poster %s: %s' % (method.__name__, exc))
            finally:
                try:
                    if os.path.exists(temp): os.unlink(temp)
                except Exception:
                    pass
    except Exception as exc:
        print('[TiviMateE2Py27] circular poster cache: %s' % exc)
    return ''


def request(source, callback):
    """Return cached path when ready; otherwise schedule one conversion.

    Callback is dispatched to Enigma2's main thread, not called from worker.
    Return True when callback is scheduled, False when nothing can be done.
    """
    hit = cached(source)
    if hit:
        return hit
    try:
        from twisted.internet import reactor
        if not hasattr(reactor, 'callFromThread'):
            return False
        if not source or not os.path.isfile(source):
            return False
        key = _key(source)
    except Exception:
        return False
    with _LOCK:
        if key in _PENDING:
            if len(_PENDING[key]) < 12:
                _PENDING[key].append(callback)
            return True
        if len(_PENDING) >= _MAX_PENDING:
            return False
        _PENDING[key] = [callback]

    def work():
        path = generate(source)
        with _LOCK:
            callbacks = _PENDING.pop(key, [])
        for cb in callbacks:
            try: reactor.callFromThread(cb, path)
            except Exception: pass
    try:
        _POOL.submit(work)
        return True
    except Exception:
        with _LOCK:
            _PENDING.pop(key, None)
        return False
