# -*- coding: utf-8 -*-
"""Scoped urllib2-compatible urllib.request bridge for Python 2.7."""
import urllib2
from Plugins.Extensions.TiviMateE2Py27.py27_compat import http_url_bytes
from urllib2 import (HTTPError, URLError, HTTPRedirectHandler, HTTPCookieProcessor,
                     HTTPHandler, HTTPSHandler, install_opener,
                     ProxyHandler, Request as _Request)
from urllib2 import build_opener as _native_build_opener
from Plugins.Extensions.TiviMateE2Py27 import py27_ssl as _py27_ssl


def _has_https_handler(handlers):
    for handler in handlers:
        try:
            if isinstance(handler, HTTPSHandler):
                return True
            if isinstance(handler, type) and issubclass(handler, HTTPSHandler):
                return True
        except TypeError:
            pass
        # Old-style handler classes on Python 2.7 are not "type" instances.
        try:
            if handler is HTTPSHandler or (hasattr(handler, '__bases__') and
                                           issubclass(handler, HTTPSHandler)):
                return True
        except TypeError:
            pass
    return False


def build_opener(*handlers):
    """urllib2.build_opener that knows the receiver/bundled CA certificates.

    VTi images often have no CA bundle; the default HTTPSHandler then fails
    every verified request. Verification itself is unchanged.
    """
    if not _has_https_handler(handlers):
        context = _py27_ssl.verified_context()
        if context is not None:
            try:
                handlers = tuple(handlers) + (HTTPSHandler(context=context),)
            except TypeError:
                pass
    return _native_build_opener(*handlers)
class Request(_Request):
    def __init__(self, url, data=None, headers={}, origin_req_host=None,
                 unverifiable=False, method=None):
        self._method_override = method
        _Request.__init__(self, http_url_bytes(url), data=data, headers=headers,
                          origin_req_host=origin_req_host, unverifiable=unverifiable)
    @property
    def full_url(self): return self.get_full_url()
    def get_method(self):
        if self._method_override: return self._method_override
        return _Request.get_method(self)

class _ContextResponse(object):
    def __init__(self, response): self._response=response
    def __getattr__(self, key): return getattr(self._response,key)
    def __iter__(self): return iter(self._response)
    def __enter__(self): return self
    def __exit__(self, typ, value, tb):
        try: self._response.close()
        except Exception:pass
        return False

def urlopen(url, data=None, timeout=10, **kwargs):
    # Python >=2.7.9 supports a TLS context. Fail closed for unsupported variants.
    # urllib2.urlopen also accepts direct URLs; protect this entry point.
    if isinstance(url, (str, unicode)):
        url = http_url_bytes(url)
    if 'context' not in kwargs and 'cafile' not in kwargs:
        context = _py27_ssl.verified_context()
        if context is not None:
            kwargs['context'] = context
    try:
        response=urllib2.urlopen(url, data=data, timeout=timeout, **kwargs)
    except TypeError:
        # Python < 2.7.9 has no context argument.
        kwargs.pop('context', None)
        response=urllib2.urlopen(url, data=data, timeout=timeout, **kwargs)
    return _ContextResponse(response)
