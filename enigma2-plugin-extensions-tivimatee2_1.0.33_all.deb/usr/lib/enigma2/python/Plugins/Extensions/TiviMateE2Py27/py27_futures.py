# -*- coding: utf-8 -*-
"""Small Python2-native bounded executor. No future/backport installation required.

Supports the methods used by the TiviMateE2 source: submit, map, callbacks,
result/exception/done/cancel, wait, as_completed, context manager, shutdown.
"""
import threading
import time
from Queue import Queue

FIRST_COMPLETED = 'FIRST_COMPLETED'
ALL_COMPLETED = 'ALL_COMPLETED'

class CancelledError(Exception): pass
class TimeoutError(Exception): pass

class Future(object):
    def __init__(self):
        self._condition = threading.Condition()
        self._state = 'PENDING'
        self._result = None
        self._exception = None
        self._callbacks = []
    def done(self):
        with self._condition:
            return self._state in ('FINISHED','CANCELLED')
    def cancelled(self):
        with self._condition: return self._state == 'CANCELLED'
    def running(self):
        with self._condition: return self._state == 'RUNNING'
    def cancel(self):
        with self._condition:
            if self._state != 'PENDING': return False
            self._state='CANCELLED';self._condition.notifyAll()
        self._fire_callbacks()
        return True
    def set_running_or_notify_cancel(self):
        with self._condition:
            if self._state == 'CANCELLED':return False
            if self._state != 'PENDING':return False
            self._state='RUNNING'
            return True
    def set_result(self, value):
        with self._condition:
            self._result = value;self._state = 'FINISHED';self._condition.notifyAll()
        self._fire_callbacks()
    def set_exception(self, err):
        with self._condition:
            self._exception = err;self._state = 'FINISHED';self._condition.notifyAll()
        self._fire_callbacks()
    def result(self, timeout=None):
        with self._condition:
            if self._state not in ('FINISHED','CANCELLED'):
                self._condition.wait(timeout)
            if self._state not in ('FINISHED','CANCELLED'):
                raise TimeoutError('future timed out')
            if self._state == 'CANCELLED': raise CancelledError()
            if self._exception is not None: raise self._exception
            return self._result
    def exception(self, timeout=None):
        with self._condition:
            if self._state not in ('FINISHED','CANCELLED'):self._condition.wait(timeout)
            if self._state not in ('FINISHED','CANCELLED'):raise TimeoutError()
            if self._state == 'CANCELLED':raise CancelledError()
            return self._exception
    def add_done_callback(self, callback):
        with self._condition:
            if self._state not in ('FINISHED','CANCELLED'):
                self._callbacks.append(callback);return
        try: callback(self)
        except Exception: pass
    def _fire_callbacks(self):
        with self._condition:
            callbacks = self._callbacks[:];self._callbacks=[]
        for callback in callbacks:
            try: callback(self)
            except Exception:pass

class ThreadPoolExecutor(object):
    def __init__(self, max_workers=2, thread_name_prefix='py27-pool'):
        self.max_workers=max(1,int(max_workers))
        self.name=thread_name_prefix
        self._queue=Queue()
        self._threads=[]
        self._lock=threading.RLock()
        self._shutdown=False
    def _worker(self):
        while True:
            task=self._queue.get()
            try:
                if task is None:return
                future,fn,args,kwargs=task
                if future.set_running_or_notify_cancel():
                    try:future.set_result(fn(*args,**kwargs))
                    except BaseException as exc:future.set_exception(exc)
            finally:self._queue.task_done()
    def submit(self, fn, *args, **kwargs):
        with self._lock:
            if self._shutdown:raise RuntimeError('executor shut down')
            f=Future()
            self._queue.put((f,fn,args,kwargs))
            if len(self._threads)<self.max_workers:
                t=threading.Thread(target=self._worker,name='%s-%d'%(self.name,len(self._threads)+1))
                t.setDaemon(True)
                t.start();self._threads.append(t)
            return f
    def map(self, fn, *iterables):
        futures=[self.submit(fn,*args) for args in zip(*iterables)]
        for f in futures:yield f.result()
    def shutdown(self, wait=True, cancel_futures=False):
        with self._lock:
            if self._shutdown:return
            self._shutdown=True
            if cancel_futures:
                try:
                    with self._queue.mutex:
                        for item in self._queue.queue:
                            if item is not None:item[0].cancel()
                except Exception:pass
            for _ in self._threads:self._queue.put(None)
        if wait:
            for thread in self._threads:thread.join()
    def __enter__(self):return self
    def __exit__(self, typ, value, tb):self.shutdown(wait=True)

def wait(fs,timeout=None,return_when=ALL_COMPLETED):
    pending=set(fs);done=set()
    start=time.time()
    while pending:
        ready=set(f for f in pending if f.done())
        done.update(ready);pending.difference_update(ready)
        if return_when==FIRST_COMPLETED and done:break
        if not pending:break
        if timeout is not None and time.time()-start>=timeout:break
        time.sleep(0.02)
    return done,pending

def as_completed(fs, timeout=None):
    pending=set(fs);start=time.time()
    while pending:
        remaining=None if timeout is None else max(0,timeout-(time.time()-start))
        done,pending=wait(pending,remaining,FIRST_COMPLETED)
        if not done:raise TimeoutError()
        for f in done:yield f
