# -*- coding: utf-8 -*-
"""UltraStalker native YouTube trailer resolver.

This module is an independent UltraStalker implementation.  It uses the exact
YouTube video id already selected by TMDb, asks YouTube's player endpoint for
stream metadata, prefers 1080p H.264, and joins split AAC audio with Enigma2's
native ``&suburi=`` convention.  It never searches YouTube by title.
"""
from __future__ import print_function

import json
import re
import threading
from Plugins.Extensions.TiviMateE2Py27 import py27_urllib
from Plugins.Extensions.TiviMateE2Py27 import py27_urlrequest as urllib2

_SUBURI = "&suburi="
_ANDROID_VERSION = "21.26.364"
_ANDROID_UA = "com.google.android.youtube/%s (Linux; U; Android 11) gzip" % _ANDROID_VERSION
_PLAYER_ENDPOINT = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"

# Same receiver-facing quality policy UltraStalker had before the resolver
# replacement: Full HD first, then 720p, with H.264/MP4 preferred.
_VIDEO_ORDER = (
    "37", "96", "301", "137", "299", "248", "303", "271", "270",
    "22", "95", "300", "136", "298", "232",
)
_AUDIO_ORDER = ("141", "140", "139", "258", "265", "325", "328", "233", "234")
_SPLIT_VIDEO = {
    "133", "134", "135", "136", "137", "138", "160", "212", "229", "230",
    "231", "232", "248", "264", "271", "272", "266", "269", "270", "298",
    "299", "303", "313", "315", "308",
}
_BLOCKED = {
    "43", "44", "45", "46", "82", "83", "84", "85", "100", "101", "102",
    "167", "168", "169", "170", "171", "172", "218", "219", "242", "243",
    "244", "245", "246", "247", "249", "250", "251", "302", "394", "395",
    "396", "397", "398", "399", "400", "401", "402", "571", "694", "695",
    "696", "697", "698", "699", "700", "701",
}


def _http_text(url, data=None, headers=None, timeout=8, limit=6 * 1024 * 1024):
    if data is not None and not isinstance(data, (bytes, bytearray)):
        data = json.dumps(data, separators=(",", ":")).encode("utf-8")
    req = urllib2.Request(url, data=data, headers=headers or {})
    with urllib2.urlopen(req, timeout=max(4, int(timeout or 8))) as response:
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise RuntimeError("response too large")
    return raw.decode("utf-8", "replace")


def _reachable_media_url(url, timeout=5):
    """Confirm a candidate Google Video URL is readable before handing to E2.

    YouTube may return a syntactically valid videoplayback URL which later
    yields HTTP 403 on the receiver. Test the first byte without downloading
    or caching the movie, and try another client when the link is rejected.
    Other origins are left alone to avoid breaking non-Google manifests.
    """
    if not url or not str(url).startswith(("https://", "http://")):
        return False
    try:
        hostname = py27_urllib.urlparse(str(url)).hostname or ""
        hostname = hostname.lower()
        if hostname != "googlevideo.com" and not hostname.endswith(".googlevideo.com"):
            return True
        request = urllib2.Request(url, headers={
            "Range": "bytes=0-0", "User-Agent": _ANDROID_UA,
            "Accept": "*/*"})
        with urllib2.urlopen(request, timeout=max(3, int(timeout))) as response:
            status = int(response.getcode() or 200)
            if status not in (200, 206):
                return False
            return bool(response.read(1))
    except Exception:
        return False


def _http_json(url, payload, headers, timeout):
    text = _http_text(url, payload, headers, timeout=timeout)
    value = json.loads(text)
    return value if isinstance(value, dict) else {}


def _balanced_body(source, open_pos):
    """Return text inside a JS brace block using a small string-aware scanner."""
    if open_pos < 0 or open_pos >= len(source) or source[open_pos] != "{":
        return ""
    depth = 0
    quote = None
    escaped = False
    i = open_pos
    while i < len(source):
        ch = source[i]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
        else:
            if ch in ("'", '"', "`"):
                quote = ch
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return source[open_pos + 1:i]
        i += 1
    return ""


def _player_script(video_id, timeout=8):
    watch = "https://www.youtube.com/watch?v=%s&bpctr=9999999999&has_verified=1" % py27_urllib.quote(video_id)
    html = _http_text(watch, headers={"User-Agent": "Mozilla/5.0"}, timeout=timeout)
    patterns = (
        r'"jsUrl"\s*:\s*"([^"]+base\.js[^"]*)"',
        r'"PLAYER_JS_URL"\s*:\s*"([^"]+base\.js[^"]*)"',
        r'<script[^>]+src="([^"]+base\.js[^"]*)"',
    )
    path = ""
    for pattern in patterns:
        match = re.search(pattern, html)
        if match:
            path = match.group(1).replace("\\/", "/")
            break
    if not path:
        return ""
    if path.startswith("//"):
        path = "https:" + path
    elif path.startswith("/"):
        path = "https://www.youtube.com" + path
    return _http_text(path, headers={"User-Agent": "Mozilla/5.0"}, timeout=timeout)


def _extract_named_function(js, name):
    escaped = re.escape(name)
    patterns = (
        r'(?:var\s+)?%s\s*=\s*function\s*\([^)]*\)\s*\{' % escaped,
        r'function\s+%s\s*\([^)]*\)\s*\{' % escaped,
    )
    for pattern in patterns:
        m = re.search(pattern, js)
        if m:
            brace = js.find("{", m.start())
            return _balanced_body(js, brace)
    return ""


def _signature_name(js):
    # Search from specific call-sites toward the generic split/join signature shape.
    patterns = (
        r'\.set\([^,]+,\s*encodeURIComponent\(\s*([A-Za-z0-9_$]+)\(',
        r'\.sig\|\|([A-Za-z0-9_$]+)\(',
        r'["\']signature["\']\s*,\s*([A-Za-z0-9_$]+)\(',
        r'\b([A-Za-z0-9_$]{2,})\s*=\s*function\(\s*([A-Za-z0-9_$]+)\s*\)\s*\{\s*\2\s*=\s*\2\.split\(\s*["\']["\']\s*\)',
    )
    for pattern in patterns:
        m = re.search(pattern, js)
        if m:
            return m.group(1)
    return ""


def _object_body(js, object_name):
    name = re.escape(object_name)
    m = re.search(r'(?:var\s+)?%s\s*=\s*\{' % name, js)
    if not m:
        return ""
    brace = js.find("{", m.start())
    return _balanced_body(js, brace)


def _classify_helper(body):
    compact = re.sub(r"\s+", "", body or "")
    if ".reverse(" in compact:
        return "reverse"
    if ".splice(0," in compact:
        return "splice"
    if ".slice(" in compact:
        return "slice"
    if "%" in compact and ".length" in compact and "[0]" in compact:
        return "swap"
    return ""


def _helper_methods(object_body):
    result = {}
    # Method names and function starts are easy to identify; balanced scanning keeps
    # nested braces from confusing the parser.
    for m in re.finditer(r'([A-Za-z0-9_$]+)\s*:\s*function\s*\([^)]*\)\s*\{', object_body):
        brace = object_body.find("{", m.start())
        body = _balanced_body(object_body, brace)
        kind = _classify_helper(body)
        if kind:
            result[m.group(1)] = kind
    return result


def _signature_plan(js):
    name = _signature_name(js)
    if not name:
        return []
    body = _extract_named_function(js, name)
    if not body:
        return []
    # The helper object is the first object.method(arg, n) owner used after split().
    call = re.search(r'([A-Za-z0-9_$]+)\.([A-Za-z0-9_$]+)\(\s*[A-Za-z0-9_$]+\s*(?:,\s*([0-9]+))?\s*\)', body)
    if not call:
        return []
    helper_name = call.group(1)
    methods = _helper_methods(_object_body(js, helper_name))
    if not methods:
        return []
    plan = []
    pattern = re.compile(r'%s\.([A-Za-z0-9_$]+)\(\s*[A-Za-z0-9_$]+\s*(?:,\s*([0-9]+))?\s*\)' % re.escape(helper_name))
    for item in pattern.finditer(body):
        kind = methods.get(item.group(1))
        if not kind:
            return []
        number = int(item.group(2) or 0)
        plan.append((kind, number))
    return plan


def _apply_signature(value, plan):
    chars = list(value or "")
    for kind, number in plan:
        if not chars:
            break
        if kind == "reverse":
            chars.reverse()
        elif kind == "splice":
            del chars[:max(0, number)]
        elif kind == "slice":
            chars = chars[max(0, number):]
        elif kind == "swap":
            index = number % len(chars)
            chars[0], chars[index] = chars[index], chars[0]
    return "".join(chars)


class UltraYouTubeResolver(object):
    def __init__(self):
        self._js = ""
        self._sig_plan = None

    def _request_player(self, video_id, timeout, profile):
        name, version, client_id, extra, user_agent = profile
        client = {"hl": "en", "clientName": name, "clientVersion": version}
        client.update(extra or {})
        if user_agent:
            client["userAgent"] = user_agent
        body = {
            "videoId": video_id,
            "playbackContext": {"contentPlaybackContext": {"html5Preference": "HTML5_PREF_WANTS"}},
            "context": {"client": client},
        }
        if name == "WEB_EMBEDDED_PLAYER":
            # Official trailers are usually embeddable. This client can work
            # when Android clients are rejected by YouTube's player endpoint.
            body["context"]["thirdParty"] = {"embedUrl": "https://www.themoviedb.org/"}
        headers = {
            "content-type": "application/json",
            "Origin": "https://www.youtube.com",
            "X-YouTube-Client-Name": str(client_id),
            "X-YouTube-Client-Version": version,
            "User-Agent": user_agent or _ANDROID_UA,
        }
        return _http_json(_PLAYER_ENDPOINT, body, headers, timeout)

    def _player_profiles(self):
        # YouTube periodically restricts individual Innertube clients. Try a
        # small receiver-safe set instead of treating one Android response as final.
        return (
            ("ANDROID", _ANDROID_VERSION, "3", {"androidSdkVersion": 30, "osName": "Android", "osVersion": "11"}, _ANDROID_UA),
            ("ANDROID_VR", "1.60.19", "28", {"androidSdkVersion": 30, "osName": "Android", "osVersion": "12"}, _ANDROID_UA),
            ("IOS", "20.10.4", "5", {"deviceMake": "Apple", "deviceModel": "iPhone16,2", "osName": "iPhone", "osVersion": "18.3.1.22D72"}, "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_1 like Mac OS X;)"),
            ("WEB_EMBEDDED_PLAYER", "2.20260708.00.00", "56", {},
             "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15"),
        )

    def _decipher(self, video_id, encrypted, timeout):
        if not encrypted:
            return ""
        if not self._js:
            try:
                self._js = _player_script(video_id, timeout=min(8, timeout))
            except Exception:
                self._js = ""
        if not self._js:
            return ""
        if self._sig_plan is None:
            self._sig_plan = _signature_plan(self._js)
        if not self._sig_plan:
            return ""
        return _apply_signature(encrypted, self._sig_plan)

    def _stream_url(self, video_id, row, timeout):
        if not isinstance(row, dict):
            return ""
        direct = str(row.get("url") or "").strip()
        if direct.startswith(("http://", "https://")):
            return direct
        cipher = str(row.get("signatureCipher") or row.get("cipher") or "").strip()
        if not cipher:
            return ""
        data = py27_urllib.parse_qs(cipher, keep_blank_values=True)
        base = str((data.get("url") or [""])[0] or "").strip()
        if not base.startswith(("http://", "https://")):
            return ""
        ready = str((data.get("sig") or data.get("signature") or [""])[0] or "").strip()
        if not ready:
            encrypted = str((data.get("s") or [""])[0] or "").strip()
            ready = self._decipher(video_id, encrypted, timeout)
        if ready:
            key = str((data.get("sp") or ["signature"])[0] or "signature")
            sep = "&" if "?" in base else "?"
            return base + sep + py27_urllib.urlencode({key: ready})
        return ""

    @staticmethod
    def _rank(itag, order):
        try:
            return order.index(str(itag))
        except ValueError:
            return 999

    def _pick_video(self, video_id, rows, timeout):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            if itag in _BLOCKED:
                continue
            rank = self._rank(itag, _VIDEO_ORDER)
            if rank >= 999:
                continue
            url = self._stream_url(video_id, row, timeout)
            if url:
                choices.append((rank, row, url))
        choices.sort(key=lambda item: item[0])
        return choices[0] if choices else None

    def _pick_audio(self, video_id, rows, timeout):
        choices = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            itag = str(row.get("itag") or "")
            rank = self._rank(itag, _AUDIO_ORDER)
            if rank >= 999:
                continue
            url = self._stream_url(video_id, row, timeout)
            if url:
                choices.append((rank, url))
        choices.sort(key=lambda item: item[0])
        return choices[0][1] if choices else ""

    def _hls_fallback(self, manifest_url, timeout):
        if not str(manifest_url or "").startswith(("http://", "https://")):
            return ""
        text = _http_text(manifest_url, headers={"User-Agent": _ANDROID_UA}, timeout=timeout, limit=3 * 1024 * 1024)
        audio_by_group = {}
        pending_audio = ""
        candidates = []
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("#EXT-X-MEDIA:") and "TYPE=AUDIO" in line.upper():
                group = re.search(r'GROUP-ID="([^"]+)"', line)
                uri = re.search(r'URI="([^"]+)"', line)
                if group and uri:
                    audio_by_group[group.group(1)] = py27_urllib.urljoin(manifest_url, uri.group(1))
                continue
            if line.startswith("#EXT-X-STREAM-INF:"):
                tag = re.search(r'(?:/itag/|itag%3D)(\d+)', line)
                group = re.search(r'AUDIO="([^"]+)"', line)
                pending_audio = audio_by_group.get(group.group(1), "") if group else ""
                # itag usually lives in the following URL, not the tag itself.
                candidates.append((line, pending_audio, ""))
                continue
            if candidates and line and not line.startswith("#") and not candidates[-1][2]:
                tag = re.search(r'(?:/itag/|itag%3D)(\d+)', line)
                itag = tag.group(1) if tag else ""
                info, audio, _ = candidates[-1]
                candidates[-1] = (info, audio, py27_urllib.urljoin(manifest_url, line) + ("|" + itag if itag else ""))
        best = []
        for _info, audio, packed in candidates:
            if not packed:
                continue
            if "|" in packed:
                url, itag = packed.rsplit("|", 1)
            else:
                url, itag = packed, ""
            rank = self._rank(itag, _VIDEO_ORDER)
            if rank < 999:
                best.append((rank, url + (_SUBURI + audio if audio else "")))
        best.sort(key=lambda item: item[0])
        return best[0][1] if best else ""

    def extract_receiver_ready(self, video_id, timeout=8, allow_split=True):
        """Resolve a trailer to a receiver-playable URL.

        A native 4097 player generally needs one URL carrying both audio and
        video. A DASH ``&suburi=`` pair is returned only when ServiceApp can
        actually play it. Check all configured clients for a progressive MP4
        before accepting a split-format fallback.
        """
        key = str(video_id or "").strip()
        if not key:
            return ""
        fallback = ""
        last_error = ""
        for profile in self._player_profiles():
            try:
                response = self._request_player(
                    key, timeout=max(4, min(9, int(timeout or 8))), profile=profile)
            except Exception as exc:
                last_error = str(exc)
                continue
            status = response.get("playabilityStatus") or {}
            if not isinstance(status, dict):
                status = {}
            if status.get("status") not in ("OK", None):
                last_error = str(status.get("reason") or status.get("status") or "")
            data = response.get("streamingData") or {}
            if not isinstance(data, dict):
                continue
            formats = data.get("formats") or []
            progressive = []
            for row in formats:
                if not isinstance(row, dict):
                    continue
                mime = str(row.get("mimeType") or "").lower()
                if not mime.startswith("video/mp4"):
                    continue
                if not (row.get("audioQuality") or row.get("audioChannels") or
                        row.get("audioSampleRate")):
                    continue
                try:
                    height = int(row.get("height") or 0)
                except (ValueError, TypeError):
                    continue
                if height < 1 or height > 1080:
                    continue
                url = self._stream_url(key, row, timeout)
                if url and _reachable_media_url(url, timeout=4):
                    progressive.append((abs(height - 720), -height, url))
            if progressive:
                progressive.sort()
                return progressive[0][2]
            # Preserve a fallback while looking for a self-contained MP4 from
            # the next client. Do NOT return here: the next profile may carry
            # the only usable progressive track.
            if not fallback:
                rows = [r for r in (formats + (data.get("adaptiveFormats") or []))
                        if isinstance(r, dict)]
                chosen = self._pick_video(key, rows, timeout)
                if chosen:
                    _, row, video = chosen
                    if str(row.get("itag") or "") in _SPLIT_VIDEO:
                        if allow_split:
                            audio = self._pick_audio(key, rows, timeout)
                            if audio:
                                fallback = video + _SUBURI + audio
                    else:
                        fallback = video
            if not fallback:
                hls = str(data.get("hlsManifestUrl") or "").strip()
                if hls:
                    try:
                        candidate = self._hls_fallback(hls, timeout=min(6, int(timeout or 8)))
                        if candidate and (allow_split or _SUBURI not in candidate):
                            fallback = candidate
                    except Exception as exc:
                        last_error = str(exc)
        if fallback and _reachable_media_url(fallback.split(_SUBURI, 1)[0], timeout=4):
            return fallback
        if last_error:
            raise RuntimeError(last_error)
        return ""

    def extract_progressive(self, video_id, timeout=10):
        """Return one MP4 URL that already contains BOTH video and audio.

        Trailer playback on stock Enigma2/4097 is more reliable with a single
        progressive file than with DASH video + ``suburi`` audio.  Only rows
        from YouTube's ``formats`` bucket are considered; adaptive/video-only
        rows are deliberately ignored.
        """
        key = str(video_id or "").strip()
        if not key:
            return ""
        last_reason = ""
        # Collect progressive candidates from ALL supported YouTube player
        # profiles before choosing.  Previously we returned as soon as the
        # first profile exposed any progressive stream; that could lock a
        # trailer to 360p even when a later profile exposed 720p.
        all_choices = []
        seen_urls = set()
        for profile in self._player_profiles():
            # Receiver may be on slow flash/Wi-Fi; a failed YouTube profile
            # must not discard good candidates from the other profiles.
            try:
                payload = self._request_player(key, timeout=max(5, min(9, int(timeout or 10))), profile=profile)
            except Exception as exc:
                last_reason = str(exc)
                continue
            status = payload.get("playabilityStatus") if isinstance(payload.get("playabilityStatus"), dict) else {}
            if status.get("status") not in ("OK", None):
                last_reason = str(status.get("reason") or "")
            streaming = payload.get("streamingData") if isinstance(payload.get("streamingData"), dict) else {}
            choices = []
            for row in (streaming.get("formats") or []):
                if not isinstance(row, dict):
                    continue
                mime = str(row.get("mimeType") or "").lower()
                if not mime.startswith("video/mp4"):
                    continue
                # Progressive formats carry an audio track in the same URL.
                has_audio = bool(row.get("audioQuality") or row.get("audioChannels") or row.get("audioSampleRate"))
                if not has_audio:
                    continue
                try:
                    height = int(row.get("height") or 0)
                except Exception:
                    height = 0
                if height <= 0 or height > 1080:
                    continue
                url = self._stream_url(key, row, timeout)
                if not url:
                    continue
                # 1080 -> 720 -> 480 -> 360 -> lower, then prefer higher bitrate.
                preferred = {1080: 0, 720: 1, 480: 2, 360: 3}.get(height, 10 + max(0, 1080 - height))
                try:
                    bitrate = int(row.get("bitrate") or 0)
                except Exception:
                    bitrate = 0
                choice = (preferred, -bitrate, -height, url)
                choices.append(choice)
                if url not in seen_urls:
                    seen_urls.add(url)
                    all_choices.append(choice)
            # 720p progressive already has video + audio and needs no extra
            # HTTP calls. Repeatedly probing three clients adds ~15-45 seconds
            # on slow receivers with no benefit to supported preview windows.
            if any(choice[0] <= 1 for choice in all_choices):
                all_choices.sort()
                return all_choices[0][3]
        if all_choices:
            all_choices.sort()
            return all_choices[0][3]
        if last_reason:
            raise RuntimeError(last_reason)
        return ""

    def extract(self, video_id, timeout=10):
        key = str(video_id or "").strip()
        if not key:
            return ""
        last_reason = ""
        for profile in self._player_profiles():
            payload = self._request_player(key, timeout=max(5, int(timeout or 10)), profile=profile)
            status = payload.get("playabilityStatus") if isinstance(payload.get("playabilityStatus"), dict) else {}
            if status.get("status") not in ("OK", None):
                last_reason = str(status.get("reason") or "")
            streaming = payload.get("streamingData") if isinstance(payload.get("streamingData"), dict) else {}
            rows = []
            for bucket in (streaming.get("formats") or [], streaming.get("adaptiveFormats") or []):
                rows.extend([row for row in bucket if isinstance(row, dict)])
            chosen = self._pick_video(key, rows, timeout)
            if chosen:
                _rank, row, video_url = chosen
                itag = str(row.get("itag") or "")
                if itag in _SPLIT_VIDEO:
                    audio_url = self._pick_audio(key, rows, timeout)
                    if audio_url:
                        return video_url + _SUBURI + audio_url
                else:
                    return video_url
            hls = str(streaming.get("hlsManifestUrl") or "").strip()
            if hls:
                try:
                    value = self._hls_fallback(hls, timeout=min(8, timeout))
                except Exception:
                    value = ""
                if value:
                    return value
        if last_reason:
            raise RuntimeError(last_reason)
        return ""
