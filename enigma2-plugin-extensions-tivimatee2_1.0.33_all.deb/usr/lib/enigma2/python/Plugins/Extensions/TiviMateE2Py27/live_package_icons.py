# -*- coding: utf-8 -*-
"""Safe, optional, online country flags for the Live package list.

No network call runs on Enigma's GUI thread.  Flags are fetched one at a time,
only for visible packages, and the package list remains usable without them.
"""
from __future__ import absolute_import
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace

import os
import re
import struct
import unicodedata
from .py27_compat import text_type
from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen

from .cache_manager import get_cache_dir
from . import artwork_queue as _artwork_queue

# These labels are explicit country identifiers at the *start* of a package
# name.  Deliberately exclude AR (Arabic, not Argentina), EN, TR? TR is
# commonly Turkey (also Turkish); only treat prefix TR as a country label.
_COUNTRIES = {
    "UK": "gb", "GB": "gb", "USA": "us", "US": "us", "UAE": "ae", "AE": "ae",
    "KSA": "sa", "SA": "sa", "CA": "ca", "CAN": "ca", "AU": "au", "AUS": "au",
    "DE": "de", "GER": "de", "FR": "fr", "FRANCE": "fr", "IT": "it", "ITALY": "it",
    "ES": "es", "SPAIN": "es", "TR": "tr", "TURKEY": "tr", "RU": "ru", "RUSSIA": "ru",
    "IN": "in", "INDIA": "in", "PK": "pk", "EG": "eg", "EGYPT": "eg",
    "JP": "jp", "JAPAN": "jp", "KR": "kr", "KOREA": "kr", "CN": "cn", "CHINA": "cn",
    "NL": "nl", "PL": "pl", "PT": "pt", "BR": "br", "MX": "mx", "ZA": "za",
    "NZ": "nz", "SE": "se", "NO": "no", "DK": "dk", "FI": "fi",
    "QA": "qa", "QATAR": "qa", "KW": "kw", "OM": "om", "BH": "bh",
    "JO": "jo", "LB": "lb", "MA": "ma", "TN": "tn", "DZ": "dz", "IQ": "iq", "PS": "ps", "PALESTINE": "ps",
    "SY": "sy", "SYR": "sy", "SYRIA": "sy", "SYRIAN": "sy",
    "YE": "ye", "YEM": "ye", "YEMEN": "ye", "YEMENI": "ye",
    "MAR": "ma", "MAROC": "ma", "MOROCCO": "ma", "MOROCCAN": "ma", "MOROCAIN": "ma",
    "LBN": "lb", "LIBAN": "lb", "LEBANON": "lb", "LEBANESE": "lb",
    "IRAK": "iq", "IRAQ": "iq", "IRAQI": "iq",
    "TUN": "tn", "TUNIS": "tn", "TUNISE": "tn", "TUNISIA": "tn", "TUNISIE": "tn",
    "EMIRATES": "ae", "SAUDI": "sa", "SAUDIARABIA": "sa",
    # Real country names from bouquet providers (not just two-letter codes).
    # Every code here has an existing bundled local flag_XX.png asset.
    "GERMANY": "de", "GERMAN": "de", "DEUTSCHLAND": "de", "DEUTSCH": "de",
    "ALLEMAGNE": "de", "ALEMANIA": "de", "ALMANYA": "de",
    "UNITEDKINGDOM": "gb", "BRITAIN": "gb", "GREATBRITAIN": "gb", "ENGLAND": "gb",
    "AMERICA": "us", "UNITEDSTATES": "us", "UNITEDSTATESOFAMERICA": "us",
    "CANADA": "ca", "AUSTRALIA": "au", "AUSTRALIAN": "au",
    "FRANCA": "fr", "FRENCH": "fr", "FRANCIA": "fr",
    "ITALIA": "it", "ITALIAN": "it", "ESPANA": "es", "SPANISH": "es",
    "TURKIYE": "tr", "TURKIY": "tr", "TURKISH": "tr", "RUSSIAN": "ru",
    "INDIAN": "in", "PAKISTAN": "pk", "PAKISTANI": "pk",
    "JAPANESE": "jp", "SOUTHKOREA": "kr", "KOREAN": "kr", "CHINESE": "cn",
    "NETHERLANDS": "nl", "HOLLAND": "nl", "DUTCH": "nl",
    "POLAND": "pl", "POLISH": "pl", "PORTUGAL": "pt", "PORTUGUESE": "pt",
    "BRAZIL": "br", "BRASIL": "br", "BRAZILIAN": "br",
    "MEXICO": "mx", "MEXICAN": "mx", "SOUTHAFRICA": "za",
    "NEWZEALAND": "nz", "SWEDEN": "se", "SWEDISH": "se",
    "NORWAY": "no", "NORWEGIAN": "no", "DENMARK": "dk", "DANISH": "dk",
    "FINLAND": "fi", "FINNISH": "fi", "GREECE": "gr", "GREEK": "gr",
    "SWITZERLAND": "ch", "SWISS": "ch", "BELGIUM": "be", "BELGIAN": "be",
    "CZECHIA": "cz", "CZECHREPUBLIC": "cz", "CZECH": "cz",
    "QATARI": "qa", "KUWAIT": "kw", "KUWAITI": "kw", "OMAN": "om", "OMANI": "om",
    "BAHRAIN": "bh", "JORDAN": "jo", "JORDANIAN": "jo",
    "ALGERIA": "dz", "ALGERIAN": "dz", "SAUDIARABIAN": "sa",
    "SYRIAN": "sy", "YEMENI": "ye", "EMIRATI": "ae",
}
# Include all ISO flags already bundled locally, including CH, BE, GR and CZ.
_COUNTRIES.update({
    code.upper(): code for code in (
        "ae", "au", "be", "bh", "br", "ca", "ch", "cn", "cz", "de", "dk",
        "dz", "eg", "es", "fi", "fr", "gb", "gr", "in", "iq", "it", "jo",
        "jp", "kr", "kw", "lb", "ma", "mx", "nl", "no", "nz", "om",
        "pk", "pl", "ps", "pt", "qa", "ru", "sa", "se", "sy", "tn",
        "tr", "us", "ye", "za"
    )
})
# Full country words may occur after provider prefixes: VIP | GERMANY | HD.
# Do NOT match loose two-letter codes in arbitrary positions (e.g. IN, IT, US),
# and do not infer a flag from generic language markers AR/EN.
_FULL_COUNTRY_NAMES = {
    name.lower(): code for name, code in _COUNTRIES.items()
    if len(name) >= 4 and name not in (
        "GER", "AUS", "USA", "UAE", "KSA", "CAN", "MAR", "TUN", "LBN", "YEM", "SYR"
    )
}
# Spellings that appear as two or three separate words in IPTV bouquet titles.
_COUNTRY_PHRASES = (
    (("united", "kingdom"), "gb"), (("great", "britain"), "gb"),
    (("united", "states"), "us"), (("united", "states", "of", "america"), "us"),
    (("saudi", "arabia"), "sa"), (("south", "africa"), "za"),
    (("south", "korea"), "kr"), (("new", "zealand"), "nz"),
    (("czech", "republic"), "cz"), (("united", "arab", "emirates"), "ae"),
)

_PREFIX = re.compile(r"^\s*[\[\({]?\s*([A-Za-z]{2,12})(?=$|[\s\]\)}|:;,_./\\\-])")
_ARABIC_MARKS = re.compile(u'[ً-ٰٟـ]')
# Only the actual explicit country label, not a server's language (AR = Arabic).
_ARABIC_COUNTRIES = (
    ((u"الامارات", u"امارات", u"اماراتيه", u"دولة الامارات", u"الامارات العربيه المتحده"), "ae"),
    ((u"قطر", u"قطري", u"قطريه"), "qa"),
    ((u"الكويت", u"كويتي", u"كويتيه"), "kw"),
    ((u"عمان", u"العمانيه", u"عماني", u"عماني", u"سلطنه عمان"), "om"),
    ((u"البحرين", u"بحريني", u"بحرينيه"), "bh"),
    ((u"الاردن", u"اردن", u"اردني", u"اردنيه"), "jo"),
    ((u"فلسطين", u"فلسطيني", u"فلسطينيه"), "ps"),
    ((u"تونس", u"تونسي", u"تونسيه"), "tn"),
    ((u"الجزائر", u"جزائري", u"جزائريه"), "dz"),
    ((u"السعوديه", u"سعوديه", u"السعودي", u"سعودي", u"المملكه العربيه السعوديه"), "sa"),
    ((u"المغرب", u"مغرب", u"المغربي", u"مغربي", u"المغربيه", u"مغربيه"), "ma"),
    ((u"لبنان", u"اللبناني", u"لبناني", u"اللبنانيه", u"لبنانيه"), "lb"),
    ((u"العراق", u"عراق", u"العراقي", u"عراقي", u"العراقيه", u"عراقيه"), "iq"),
    ((u"مصر", u"مصري", u"مصريه"), "eg"),
    ((u"سوريا", u"سوريه", u"السوري", u"سوري", u"السوريه"), "sy"),
    ((u"اليمن", u"يمن", u"اليمني", u"يمني", u"اليمنيه", u"يمنيه"), "ye"),
)


# Arabic words of countries already covered by the bundled flag assets.
_ARABIC_COUNTRIES = _ARABIC_COUNTRIES + (
    ((u"المانيا", u"الالمانيه", u"الماني", u"المانيه"), "de"),
    ((u"فرنسا", u"فرنسي", u"فرنسيه"), "fr"),
    ((u"بريطانيا", u"انجلترا", u"المملكه المتحده", u"بريطاني"), "gb"),
    ((u"امريكا", u"امريكي", u"امريكيه", u"الولايات المتحده"), "us"),
    ((u"ايطاليا", u"ايطالي", u"ايطاليه"), "it"),
    ((u"اسبانيا", u"اسباني", u"اسبانيه"), "es"),
    ((u"تركيا", u"تركي", u"تركيه"), "tr"),
    ((u"روسيا", u"روسي", u"روسيه"), "ru"),
    ((u"كندا", u"كندي", u"كنديه"), "ca"),
    ((u"استراليا", u"استرالي"), "au"),
    ((u"هولندا", u"هولندي"), "nl"),
    ((u"بلجيكا", u"بلجيكي"), "be"),
    ((u"سويسرا", u"سويسري"), "ch"),
    ((u"بولندا", u"بولندي"), "pl"),
    ((u"البرتغال", u"برتغالي"), "pt"),
    ((u"البرازيل", u"برازيلي"), "br"),
    ((u"المكسيك", u"مكسيكي"), "mx"),
    ((u"اليونان", u"يوناني"), "gr"),
    ((u"التشيك", u"تشيكي"), "cz"),
    ((u"السويد", u"سويدي"), "se"),
    ((u"النرويج", u"نرويجي"), "no"),
    ((u"الدنمارك", u"دنماركي"), "dk"),
    ((u"فنلندا", u"فنلندي"), "fi"),
    ((u"الصين", u"صيني"), "cn"),
    ((u"اليابان", u"ياباني"), "jp"),
    ((u"كوريا", u"كوري"), "kr"),
    ((u"الهند", u"هندي"), "in"),
    ((u"باكستان", u"باكستاني"), "pk"),
    ((u"جنوب افريقيا", u"افريقيا الجنوبيه"), "za"),
    ((u"نيوزيلندا", u"نيوزلندا"), "nz"),
)

def _normalized_name(name):
    # In DreamOS/Python 2, ``unicode(utf8_bytes)`` decodes as ASCII.
    # Normalize provider bouquet names without raising on Arabic UTF-8.
    # py27_compat.text_type is a *converter function*, not a type.
    # isinstance(name, text_type) previously raised TypeError for EVERY
    # bouquet, causing the GUI to silently omit its category artwork.
    # Keep provider names as Unicode for safe Arabic/CP1256 classification.
    try:
        value = text_type(name if name is not None else u'')
    except (UnicodeError, TypeError, ValueError):
        value = u''
    value = unicodedata.normalize("NFKD", value)
    value = u"".join(ch for ch in value if not unicodedata.combining(ch))
    value = _ARABIC_MARKS.sub(u"", value)
    value = value.replace(u"أ", u"ا").replace(u"إ", u"ا").replace(u"آ", u"ا")
    value = value.replace(u"ى", u"ي").replace(u"ة", u"ه")
    value = value.replace(u"٤", "4")
    return value.lower()


def _token_sequence(name):
    return re.findall(u'[a-z0-9]+|[ء-ي]+', _normalized_name(name))


def package_country(name):
    """Match an explicit country, including Arabic and AR-UAE/AR-TUNISE.

    Never interpret AR (Arabic) as Argentina. Specific country prefixes beat
    regional brands; plain MBC/إم بي سي deliberately uses the Saudi flag.
    """
    normalized = _normalized_name(name)
    tokens = _token_sequence(name)
    if not tokens:
        return ""
    # Explicit country first, including a language marker followed by country.
    prefix = tokens[0]
    if prefix.upper() in _COUNTRIES:
        return _COUNTRIES[prefix.upper()]
    if prefix in ("ar", "ara", "arabic", u"عربي", u"العربي", u"العربيه", "en", "eng", "english"):
        if len(tokens) > 1:
            match = _COUNTRIES.get(tokens[1].upper())
            if match:
                return match
            for names, country in _ARABIC_COUNTRIES:
                if tokens[1] in names:
                    return country
    if prefix in ("vip", "premium", "world", "channels", "channel", "tv", "live", "iptv", "all") and len(tokens) > 1:
        short = tokens[1].upper()
        if len(short) in (2, 3) and short in _COUNTRIES:
            return _COUNTRIES[short]
    for names, country in _ARABIC_COUNTRIES:
        # Arabic region must be a whole word, not a substring of another title.
        if any(re.search(u'(?<![ء-ي])%s(?![ء-ي])' % re.escape(n), normalized) for n in names):
            return country
    # Match explicit full country names ANYWHERE in a bouquet title, without
    # confusing generic English/Arabic language markers with countries.
    # Most two-letter ISO codes are intentionally prefix-only to avoid false
    # matches with common words (IN / IT / US / TR).
    # Keep multiword names distinct: "United States", "United Kingdom"...
    for words, country in _COUNTRY_PHRASES:
        width = len(words)
        for pos in range(len(tokens) - width + 1):
            if tuple(tokens[pos:pos+width]) == words:
                return country
    for token in tokens:
        match = _FULL_COUNTRY_NAMES.get(token)
        if match:
            return match
    # STC is a Saudi brand; a specific documentary category will take priority
    # in package_visual() before this generic national fallback is displayed.
    if "stc" in tokens or u"اس تي سي" in normalized or u"اس تي سى" in normalized:
        return "sa"
    # Explicit full English country words after language/region delimiters.
    # The accepted prefix tokens above cover formats such as AR-MOROCCO.
    # Saudi broadcasters: regional prefixes such as UAE-ROTANA still take
    # priority above this brand fallback.
    compact = "".join(tokens)
    if ("myhd" in tokens or ("my" in tokens and "hd" in tokens and tokens.index("my") + 1 == tokens.index("hd"))
            or any(v in compact for v in (u"ماياتشدي", u"مايهد"))):
        return "sa"
    if "rotana" in tokens or u"روتانا" in normalized:
        return "sa"
    # MBC is a Saudi channel group, even when prefixed by AR / Arabic label.
    if ("mbc" in tokens or any(v in normalized for v in (u"ام بي سي", u"امبيسي", u"ام بي سى"))):
        return "sa"
    return ""


def package_special_icon(name):
    """Small local logos used only on explicit matching Live package titles."""
    value = _normalized_name(name)
    compact = re.sub(r"[\s\-_|:.]+", "", value)
    tokens = _token_sequence(name)
    if ("bein" in compact or "beinsport" in compact or "beinsports" in compact
            or u"بيانسبورت" in compact or u"بينسبورت" in compact or u"بيانسبور" in compact
            or ("bein" in tokens and any(t in tokens for t in ("sport", "sports", "max", "prem", "4k")))):
        return "beinsport"
    # Do not mislabel 4K as a country or generic movie package.
    if ("4k" in tokens or "uhd" in tokens or u"فوركي" in compact or u"فوركاي" in compact
            or u"٤ك" in value or u"4ك" in value or u"اولترااتشدي" in compact):
        return "4k"
    if "ufc" in tokens or u"يوافسي" in compact or u"يوفسي" in compact:
        return "ufc"
    if "wwe" in tokens or u"دبليودبليواي" in compact or u"دبليودبليوايي" in compact:
        return "wwe"
    if "netflix" in compact or "netflex" in compact or u"نتفليكس" in compact or u"نتفلكس" in compact or u"نيتفليكس" in compact:
        return "netflix"
    if any(t in tokens for t in ("entertainment", "entertain", "showbiz", "variety")) or any(w in value for w in (u"ترفيه", u"ترفيهي", u"ترفيهيه", u"منوعات", u"تسلية")):
        return "entertainment"
    # Full-title matching: "STC DOC TV" is documentary, while "STC" is Saudi.
    # Look for whole DOC tokens so channel names containing "doctor" are safe.
    stc = "stc" in tokens or u"اس تي سي" in value or u"اس تي سى" in value
    doc = any(t in tokens for t in ("doc", "docs", "documentary", "documentaries", "culture", "cultural")) or any(w in value for w in (u"وثائقي", u"وثائقيه", u"ثقافي", u"ثقافيه"))
    if stc and doc:
        return "documentary"
    # Al Kass sports channels: connected, spaced, transliterated and Arabic.
    if ("alkass" in tokens or "alkas" in tokens or "alkass" in compact
            or ("al" in tokens and "kass" in tokens)
            or any(w in value for w in (u"الكاس", u"الكأس", u"قنوات الكاس", u"قنوات الكأس"))):
        return "sport"
    # Arab Channel: a dedicated local icon rather than a generic country flag.
    if (re.search(r"\barab(?:ic)?[\s._|:-]+(?:channel|channels|chanel)\b", value)
            or u"القنوات العربيه" in value or u"قنوات عربيه" in value):
        return "arab_channel"
    # DStv broadcasts across Africa; do not falsely use a single country flag.
    if "dstv" in tokens or "dstv" in compact or u"دي اس تي في" in value:
        return "africa"
    # OSN movie brand: keep OSN Sports/News/Series distinct when explicitly named.
    osn = "osn" in tokens or any(v in compact for v in (u"اواسان", u"اوسان"))
    if osn:
        if any(t in tokens for t in ("sport", "sports", "news", "series", "kids")):
            return ""
        return "osn"
    return ""


def package_visual(name):
    """One full-title decision for the Live category icon, with clear priority.

    Specific branded/category matches precede generic STC -> Saudi fallback.
    An explicit Morocco/Lebanon country name still gets its national flag.
    """
    special = package_special_icon(name)
    if special in ("documentary", "sport", "arab_channel", "africa", "beinsport", "entertainment"):
        return "kind", special
    country = package_country(name)
    if country:
        return "country", country
    if special:
        return "kind", special
    return "kind", package_kind(name)


def package_kind(name):
    """Lightweight fallback icon when no country flag has arrived yet."""
    value = _normalized_name(name)
    if any(word in value for word in ("sport", "football", "soccer", "bein", "espn", "nba", "epl", "fifa", "sky sport", u"رياضه", u"رياضي", u"كره", u"مصارعه", u"الكاس", u"الكأس")):
        return "beinsport" if "bein" in value else "sport"
    if any(word in value for word in ("movie", "cinema", "film", "vod", u"افلام", u"سينما")):
        return "movies"
    if any(word in value for word in ("series", "show", "drama", u"مسلسلات", u"مسلسل", u"دراما")):
        return "shows"
    if any(word in value for word in ("news", u"اخبار", u"عاجل")):
        return "news"
    if any(word in value for word in ("entertainment", "entertain", "showbiz", "variety", u"ترفيه", u"ترفيهي", u"منوعات", u"تسليه")):
        return "entertainment"
    if any(word in value for word in ("kids", "child", "cartoon", u"طفل", u"اطفال", u"كرتون")):
        return "kids"
    if any(word in value for word in ("music", "radio", u"موسيقي", u"موسيقا", u"اغاني")):
        return "music"
    if any(word in value for word in ("document", "history", "nature", "science", u"وثائق", u"طبيعه")):
        return "documentary"
    if any(word in value for word in ("religio", "quran", "islam", u"دين", u"قران", u"اسلام")):
        return "religion"
    if any(word in value for word in ("cook", "food", u"مطبخ", u"طبخ", u"طعام")):
        return "food"
    return "general"


def _valid_png(content):
    if not isinstance(content, bytes) or len(content) < 33 or len(content) > 65536:
        return False
    if content[:8] != b"\x89PNG\r\n\x1a\n" or content[12:16] != b"IHDR":
        return False
    width, height = struct.unpack(">II", content[16:24])
    return 12 <= width <= 256 and 9 <= height <= 256


def flag_cached_path(country):
    if country not in _COUNTRIES.values():
        return ""
    try:
        path = os.path.join(get_cache_dir("logos/live_country_flags"), country + ".png")
        return path if _artwork_queue.valid_image_file(path, 32) else ""
    except (OSError, IOError):
        return ""


def fetch_flag(country):
    """Background thread only; no GUI calls and no bulk country downloads."""
    if country not in _COUNTRIES.values():
        return ""
    cached = flag_cached_path(country)
    if cached:
        return cached
    # HTTPS with normal certificate checks. A failed request must never block
    # the UI or disable the local generic icon fallback.
    urls = (
        "https://flagcdn.com/24x18/%s.png" % country,
        "https://flagcdn.io/4x3/24/%s.png" % country,
    )
    for url in urls:
        try:
            from .py27_ssl import artwork_open
            response = artwork_open(Request(url, headers={"User-Agent": "TiviMateE2/1.0"}), timeout=3)
            try:
                content = response.read(65537)
            finally:
                response.close()
            if not _valid_png(content):
                continue
            directory = get_cache_dir("logos/live_country_flags")
            target = os.path.join(directory, country + ".png")
            temp = target + ".part"
            with open(temp, "wb") as f:
                f.write(content)
            try:
                atomic_replace(temp, target)
            except AttributeError:
                os.rename(temp, target)
            return target if _artwork_queue.valid_image_file(target, 32) else ""
        except Exception:
            continue
    return ""
