# -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import print_function
import requests
import json
import re, os
from bs4 import BeautifulSoup
from six.moves.urllib.parse import quote_plus, urljoin, urlparse
from .YtssubsUtilities import geturl, get_language_info
from ..utilities import log
import base64
import zipfile
import io
import time

# Explicit relative structure for cross-version compatibility
from ..user_agents import get_random_ua

# Bind this provider to a single stable browser signature for its lifecycle
PROVIDER_SESSION_KEY = "yifysubtitles"
SESSION_UA = get_random_ua()

# Initialize the persistent session object
session = requests.Session()
session.headers.update({
    "User-Agent": SESSION_UA,
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language": "en-US,en;q=0.9",
    "Referer": "https://yifysubtitles.ch",
    "priority": "u=1, i"
})

BASE_URL = "https://yifysubtitles.ch"
debug_pretext = ""

def prepare_search_string(s):
    s = s.replace("'", "").strip()
    s = re.sub(r'\(\d\d\d\d\)$', '', s)  # remove year from title
    s = s.replace(" :",":").replace(".", " ")
    pass  # debug output removed
    return s

def getallsubs(html_content, allowed_languages, filename=""):
    """ Extract subtitle links from YIFYSubtitles.ch subtitle page with multiple filenames """
    subtitles = []

    soup = BeautifulSoup(html_content, "html.parser")
    subtitle_rows = soup.select("tr[data-id]")  # Select subtitle rows

    for row in subtitle_rows:
        try:
            # Extract language
            language_cell = row.select_one("td.flag-cell span.sub-lang")
            if language_cell is None:
                continue
            language = language_cell.get_text(" ", strip=True)

            # Extract download page link
            subtitle_link_tag = row.select_one("td a[href^='/subtitles/']")
            if not subtitle_link_tag:
                continue  # Skip if no valid link

            subtitle_page_link = urljoin(BASE_URL + "/", subtitle_link_tag.get("href") or "")
            if not subtitle_page_link.startswith(BASE_URL + "/"):
                continue

            # Ensure correct `<br>` splitting, even if first two names are joined
            subtitle_names = re.split(r"<br\s*/?>", subtitle_link_tag.decode_contents(), flags=re.IGNORECASE)

            # Match language to the correct format
            language_info = get_language_info(language)
            if not language_info or language_info["name"].lower() not in {
                    str(item).lower() for item in allowed_languages if item}:
                continue

            # Add each subtitle variant separately
            for subtitle_name in subtitle_names:
                subtitle_name = BeautifulSoup(subtitle_name, "html.parser").text.strip()  # Clean HTML tags
                subtitle_name = re.sub(r"^subtitle\s*", "", subtitle_name, flags=re.IGNORECASE)  # Remove "subtitle" only at the start
                subtitle_name = re.sub(r"^\.+", "", subtitle_name)  # Remove leading dots (e.g., ".Moana" -> "Moana")

                if subtitle_name:
                    subtitles.append({
                        "filename": subtitle_name,
                        "sync": True,  # No sync info available
                        "link": subtitle_page_link,
                        "language_name": language_info["name"],
                        "lang": language_info
                    })

        except Exception as e:
            pass  # debug output removed
            continue

    return subtitles

def split_movie_title(movie_entry):
    """Extract title and release year from either YIFY search response format."""
    title = str(movie_entry.get("movie") or movie_entry.get("title") or movie_entry.get("name") or "").strip()
    match = re.search(r"^(.*?)\s+\(?((?:19|20)\d{2})\)?$", title)
    return (match.group(1).strip(), match.group(2)) if match else (title, None)


def _search_entries(payload):
    """YIFY mirrors return either an array or a wrapped JSON array."""
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        for key in ("movies", "results", "data", "items"):
            rows = payload.get(key)
            if isinstance(rows, list):
                return [row for row in rows if isinstance(row, dict)]
            if isinstance(rows, dict):
                nested = _search_entries(rows)
                if nested:
                    return nested
    return []


def search_movie(title, year, languages, filename):
    """Search YIFY with URL-encoded query; prefer correct title and year."""
    movie_title = prepare_search_string(title or "")
    if not movie_title:
        return []
    try:
        response = session.get(BASE_URL + "/ajax/search/", params={"mov": movie_title}, timeout=10)
        if response.status_code != 200:
            return []
        movies = _search_entries(response.json())
        if not movies:
            return []

        def norm(value):
            return re.sub(r"[^\w]+", "", str(value or "").lower(), flags=re.UNICODE)
        wanted = norm(movie_title)
        best_match, best_score = None, -1
        for movie in movies:
            movie_name, movie_year = split_movie_title(movie)
            current = norm(movie_name)
            exact_title = bool(wanted and current == wanted)
            matching_year = bool(year and movie_year and str(year) == str(movie_year))
            score = (4 if exact_title else 0) + (2 if matching_year else 0)
            if score > best_score:
                best_match, best_score = movie, score
        if best_match is None:
            return []
        imdb_code = best_match.get("imdb") or best_match.get("imdb_code") or best_match.get("mov_imdb_code")
        if not imdb_code:
            return []
        movie_url = BASE_URL + "/movie-imdb/" + quote_plus(str(imdb_code))
        movie_page = session.get(movie_url, timeout=10)
        if movie_page.status_code != 200:
            return []
        return getallsubs(movie_page.content, languages, filename)
    except Exception as error:
        log(__name__, "Yify search failed: %s" % str(error))
        return []

def search_tvshow(title, season, episode, languages, filename):
    """ Search for a movie on YTS-Subs and retrieve subtitles """
    tv_title = prepare_search_string(title)
    try:
        search_url = "{}/search/ajax/{}".format(BASE_URL, tv_title)
        response = session.get(search_url, timeout=10)

        if response.status_code != 200:
            pass  # debug output removed
            return []

        movies = response.json()
        if not movies:
            pass  # debug output removed
            return []

        # Select the best-matching movie (first result)
        selected_movie = movies[0]
        imdb_code = selected_movie.get("mov_imdb_code")
        if not imdb_code:
            pass  # debug output removed
            return []

        # Fetch subtitles for the selected movie
        movie_url = "{}/movie-imdb/{}".format(BASE_URL, imdb_code)
        movie_page = session.get(movie_url, timeout=10)

        if movie_page.status_code != 200:
            pass  # debug output removed
            return []

        # Pass .content instead of .text for safe auto-decoding in Python 2 & 3
        return getallsubs(movie_page.content, languages, filename)

    except Exception as error:
        pass  # debug output removed
        return []

def search_manual(title, languages, filename):
    """No title given: nothing to search."""
    return []


def search_subtitles(file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack):  # standard input
    log(__name__, "%s Search_subtitles = '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'" %
         (debug_pretext, file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack))
    if lang1 == 'Farsi':
        lang1 = 'Persian'
    if lang2 == 'Farsi':
        lang2 = 'Persian'
    if lang3 == 'Farsi':
        lang3 = 'Persian'
    if tvshow:
        sublist = search_tvshow(tvshow, season, episode, [lang1, lang2, lang3], file_original_path)
    elif title:
        sublist = search_movie(title, year, [lang1, lang2, lang3], file_original_path)
    else:
        try:
          sublist = search_manual(title, [lang1, lang2, lang3], file_original_path)
        except:
            pass  # debug output removed
    return sublist, "", ""

def _yify_download_candidates(html_content, detail_url):
    """Use the real YIFY download button, with legacy endpoint fallbacks."""
    candidates = []
    source_host = (urlparse(detail_url).hostname or "").lower()

    def add(link):
        link = (link or "").strip()
        if not link or link.startswith(("#", "javascript:", "data:")):
            return
        url = urljoin(detail_url, link)
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        # Download URLs must remain on the same YIFY mirror (not ad links).
        if parsed.scheme != "https" or host != source_host:
            return
        if url not in candidates:
            candidates.append(url)

    if html_content:
        soup = BeautifulSoup(html_content, "html.parser")
        # Button URL takes precedence over guessed slugs. Some mirrors use
        # /subtitle-api/ rather than the historical /subtitle/ path.
        for tag in soup.select('a.download-subtitle, a[href*="/subtitle/"], a[href*="/subtitle-api/"], a[href*="/download/"]'):
            add(tag.get("href") or tag.get("data-href") or tag.get("data-url"))
        for tag in soup.find_all("a"):
            if "download subtitle" in tag.get_text(" ", strip=True).lower():
                add(tag.get("href") or tag.get("data-href") or tag.get("data-url"))
    match = re.match(r"^/subtitles/([a-zA-Z0-9][a-zA-Z0-9._-]*)/?$",
                     urlparse(detail_url).path)
    if match and source_host in ("yifysubtitles.ch", "www.yifysubtitles.ch"):
        slug = match.group(1)
        slug_zip = slug if slug.lower().endswith(".zip") else slug + ".zip"
        for prefix in ("/subtitle/", "/subtitle-api/"):
            add(prefix + slug_zip)
        add("/subtitle/" + slug)
    return candidates


def _yify_trace(message):
    # No /tmp diagnostic log. Subtitle search and download stay enabled.
    return None


def _yify_log(message):
    _yify_trace(message)
    log(__name__, message)


def _yify_payload_type(payload, content_type=""):
    """Never accept a Cloudflare / error HTML page as an SRT file."""
    if not payload:
        return None
    header = payload[:128].lstrip().lower()
    ctype = (content_type or "").lower()
    if payload.startswith(b"PK\x03\x04") or payload.startswith(b"PK\x05\x06"):
        if zipfile.is_zipfile(io.BytesIO(payload)):
            return "zip"
        return None
    if "html" in ctype or header.startswith((b"<!doctype", b"<html", b"<?xml")):
        return None
    if b"<html" in payload[:1024].lower() or b"cf-browser-verification" in payload[:1024].lower():
        return None
    if payload.startswith(b"Rar!\x1a\x07"):
        return "rar"
    if len(payload) > 3 * 1024 * 1024 or b"\x00" in payload[:32] and not payload.startswith((b"\xff\xfe", b"\xfe\xff")):
        return None
    # Text must look like subtitles, not an HTTP 200 error message.
    for codec in ("utf-8-sig", "utf-16", "cp1256", "latin1"):
        try:
            body = payload[:16384].decode(codec)
            if re.search(r"\d{1,2}:\d{2}:\d{2}[,.]\d{2,3}\s*-->", body) or \
                    body.lstrip().startswith("WEBVTT") or \
                    re.search(r"(?im)^Dialogue\s*:", body) or \
                    re.search(r"(?m)^\{\d+\}\{\d+\}", body):
                return "subtitle"
        except (UnicodeError, LookupError):
            pass
    return None


def download_subtitles(subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id):
    """Fetch YIFY ZIP/SRT with exact download URL, cookies, and trace logging."""
    try:
        subtitle = subtitles_list[pos]
        detail_url = subtitle.get("link", "")
        language = subtitle.get("language_name", "")
        if not detail_url or urlparse(detail_url).scheme != "https":
            _yify_log("missing or invalid detail URL")
            return False, "", ""
        if not os.path.isdir(tmp_sub_dir):
            os.makedirs(tmp_sub_dir)
        temp_root = os.path.realpath(tmp_sub_dir)
        temp_file = os.path.realpath(zip_subs)
        if not temp_file.startswith(temp_root + os.sep) or not os.path.isdir(os.path.dirname(temp_file)):
            _yify_log("unsafe or nonexistent temp file directory")
            return False, "", ""

        _yify_log("start download detail=%s" % detail_url)
        response = None
        detail_html = b""
        referer = detail_url
        try:
            response = session.get(detail_url, timeout=12, allow_redirects=True)
            _yify_log("detail HTTP %s" % response.status_code)
            if response.status_code == 200:
                referer = response.url or detail_url
                direct_type = _yify_payload_type(response.content, response.headers.get("Content-Type", ""))
                if direct_type:
                    with open(zip_subs, "wb") as out:
                        out.write(response.content)
                    _yify_log("direct %s saved bytes=%s" % (direct_type, len(response.content)))
                    return (True, language, direct_type) if direct_type in ("zip", "rar") else (False, language, zip_subs)
                if "html" in response.headers.get("Content-Type", "text/html").lower():
                    detail_html = response.content
        except requests.RequestException as error:
            _yify_log("detail request failure: %s" % error)
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

        candidates = _yify_download_candidates(detail_html, referer)
        if not candidates:
            _yify_log("no download candidates from detail page")
            return False, "", ""

        for index, download_url in enumerate(candidates):
            response = None
            try:
                headers = {"Referer": referer, "Accept": "application/zip,application/octet-stream,text/plain,*/*"}
                response = session.get(download_url, headers=headers, timeout=15,
                                       allow_redirects=True, stream=True)
                if response.status_code != 200:
                    _yify_log("candidate %d/%d HTTP %s" % (index+1, len(candidates), response.status_code))
                    continue
                chunks, total = [], 0
                for chunk in response.iter_content(chunk_size=32768):
                    if chunk:
                        total += len(chunk)
                        if total > 20 * 1024 * 1024:
                            raise ValueError("subtitle archive exceeds 20MB")
                        chunks.append(chunk)
                payload = b"".join(chunks)
                kind = _yify_payload_type(payload, response.headers.get("Content-Type", ""))
                if not kind:
                    _yify_log("candidate %d/%d rejected content-type=%s bytes=%d" % (
                        index+1, len(candidates), response.headers.get("Content-Type", ""), len(payload)))
                    continue
                if kind == "zip":
                    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
                        if not any(name.lower().endswith((".srt", ".ass", ".sub")) for name in archive.namelist()):
                            _yify_log("candidate %d/%d ZIP contains no subtitle" % (index+1, len(candidates)))
                            continue
                with open(zip_subs, "wb") as saved:
                    saved.write(payload)
                _yify_log("saved %s bytes=%d candidate=%d/%d" % (kind, len(payload), index+1, len(candidates)))
                # The XBMC adapter expects the archive type in slot three;
                # for direct SRT it expects a path in slot three.
                if kind in ("zip", "rar"):
                    return True, language, kind
                return False, language, zip_subs
            except Exception as error:
                _yify_log("candidate %d/%d exception: %s" % (index+1, len(candidates), error))
            finally:
                if response is not None:
                    try:
                        response.close()
                    except Exception:
                        pass
        _yify_log("all %d download candidates failed" % len(candidates))
        return False, "", ""
    except Exception as error:
        _yify_log("download exception: %s" % error)
        return False, "", ""
