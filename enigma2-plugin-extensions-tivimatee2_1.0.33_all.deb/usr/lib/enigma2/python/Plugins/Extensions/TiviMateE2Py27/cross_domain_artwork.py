# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import monotonic, text_type
"""Local-only reuse of Xtream artwork across configured mirror domains.

A mirror candidate must belong to another *configured* Xtream endpoint with
exactly the same nonempty username and password and the same image path/query.
No network, fuzzy film matching, directory crawling or new download workers.
The original URL-based cache file names remain intact and are never moved.
"""
import json
import os
import re
import time
import threading
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit, urlunsplit

_LOCK = threading.RLock()
_SOURCES = ()
_SOURCE_MTIME = None
_SOURCE_FILE = None
_NEXT_CHECK = 0.0
_MAX_SOURCE_BYTES = 512 * 1024
_MAX_MIRRORS = 6
# Only avoid ambiguously generic filenames across different services.
_GENERIC = frozenset((
    'poster', 'image', 'cover', 'backdrop', 'logo', 'default', 'placeholder',
    'noimage', 'no_image', 'nopic', 'no-poster', 'no_poster', 'blank',
))


def _origin(value):
    try:
        if not isinstance(value, (str, unicode)) or not value:
            return None
        value = value.strip()
        if '://' not in value:
            value = 'http://' + value
        parsed = urlsplit(value)
        if parsed.scheme.lower() not in ('http', 'https') or not parsed.hostname:
            return None
        # Include the port; a mirror is only configured at its actual origin.
        return (parsed.scheme.lower(), parsed.netloc.lower())
    except (ValueError, TypeError):
        return None


def _source_row(row):
    if not isinstance(row, dict) or str(row.get('type') or '').lower() != 'xtream':
        return None
    user = text_type(row.get('username') or '').strip()
    password = text_type(row.get('password') or '').strip()
    base = _origin(text_type(row.get('url') or row.get('host') or ''))
    if not (base and user and password):
        return None
    return ((user, password), base)


def _source_file():
    # The authoritative file path is selected by core based on HDD/TMP
    # storage policy. Importing core is cheap after Enigma2 Home has opened.
    from .core import SOURCES_FILE
    return SOURCES_FILE


def _catalogue():
    """Cache the small configured-source list; only inspect it on a miss.

    Never use get_sources(): that call rewrites playlist mirror files and may
    perform migrations, none of which belong in an artwork hot path.
    """
    global _SOURCES, _SOURCE_MTIME, _SOURCE_FILE, _NEXT_CHECK
    now = monotonic()
    if now < _NEXT_CHECK:
        return _SOURCES
    with _LOCK:
        if now < _NEXT_CHECK:
            return _SOURCES
        _NEXT_CHECK = now + 10.0
        try:
            file_path = _source_file()
            st = os.stat(file_path)
            stamp = (st.st_mtime_ns if hasattr(st, 'st_mtime_ns') else st.st_mtime, st.st_size)
            if _SOURCE_FILE == file_path and _SOURCE_MTIME == stamp:
                return _SOURCES
            if st.st_size <= 2 or st.st_size > _MAX_SOURCE_BYTES:
                _SOURCES = ()
                _SOURCE_FILE, _SOURCE_MTIME = file_path, stamp
                return _SOURCES
            with open(file_path, 'rb') as stream:
                raw = stream.read(_MAX_SOURCE_BYTES + 1)
            entries = json.loads(raw.decode('utf-8'))
            if not isinstance(entries, list):
                entries = []
            rows = []
            seen = set()
            for item in entries[:256]:
                value = _source_row(item)
                if value and value not in seen:
                    seen.add(value)
                    rows.append(value)
            _SOURCES = tuple(rows)
            _SOURCE_FILE, _SOURCE_MTIME = file_path, stamp
        except (OSError, ValueError, TypeError, UnicodeError, ImportError, IOError):
            # A missing/migrating source file is not evidence that a server
            # image is unavailable. Just use the normal URL download path.
            _SOURCES = ()
            _SOURCE_FILE = None
            _SOURCE_MTIME = None
        return _SOURCES


def _distinct_image(url):
    """Reject generic placeholders, stream endpoints and ambiguous assets."""
    try:
        p = urlsplit(url)
        if p.scheme.lower() not in ('http', 'https') or not p.hostname:
            return False
        filename = p.path.rsplit('/', 1)[-1].strip()
        if not filename or len(p.path) < 5:
            return False
        stem = filename.rsplit('.', 1)[0].lower()
        if stem in _GENERIC or len(stem) < 3:
            return False
        if stem.startswith(('default_', 'placeholder_', 'noimage_')):
            return False
        # PHP endpoints with explicit stable identity keys are supported.
        if filename.lower().endswith('.php'):
            from Plugins.Extensions.TiviMateE2Py27.py27_urllib import parse_qs
            qs = parse_qs(p.query)
            if not any(q in qs and qs[q] and qs[q][0] for q in ('id', 'image_id', 'poster_id', 'file', 'path')):
                return False
        elif not re.search(r'\.(?:jpg|jpeg|png|webp)$', filename, re.I):
            return False
        return True
    except (ValueError, TypeError):
        return False


def cached_mirror(url, kind, cache_path, valid_image, source=None):
    """Return existing local image from an account-matched mirror, or ''.

    This adds at most 6 direct *file* checks after a normal cache miss.
    Do not copy, hard-link, persist another index, change keys, or wait on a
    network request. All pages keep their original queues and thread limits.
    """
    if kind not in ('posters', 'backdrops', 'logos') or not _distinct_image(url):
        return ''
    try:
        item = urlsplit(url)
        current_origin = _origin(url)
        rows = _catalogue()
        if not rows or not current_origin:
            return ''
        available = {group for group, endpoint in rows if endpoint == current_origin}
        if not available:
            return ''   # External CDNs are not assumed to be mirrors.
        selected = _source_row(source) if isinstance(source, dict) else None
        if selected and selected[1] == current_origin and selected[0] in available:
            group = selected[0]
        elif len(available) == 1:
            group = next(iter(available))
        else:
            return ''   # Shared origin with multiple logins: no safe match.
        checked = set()
        count = 0
        for identity, endpoint in rows:
            if identity != group or endpoint == current_origin or endpoint in checked:
                continue
            checked.add(endpoint)
            count += 1
            if count > _MAX_MIRRORS:
                break
            candidate = urlunsplit((endpoint[0], endpoint[1], item.path, item.query, item.fragment))
            path = cache_path(candidate, kind)
            if valid_image(path):
                return path
    except (OSError, ValueError, TypeError, ImportError, IOError):
        pass
    return ''
