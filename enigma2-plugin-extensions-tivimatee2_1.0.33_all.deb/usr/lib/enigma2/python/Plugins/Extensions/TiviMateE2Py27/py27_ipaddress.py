# -*- coding: utf-8 -*-
"""Conservative native Python2 inet_pton-based public/private IP classifier.

Fail closed for reserved/unknown ranges. Used only for SSRF destination checks.
"""
import socket

def _inside(value, prefix, bits, width):
    return (value >> (width-bits)) == (prefix >> (width-bits))

def _v4int(s):
    data = socket.inet_pton(socket.AF_INET, s)
    result = 0
    for x in bytearray(data): result = (result<<8)|x
    return result

def _v6int(s):
    data = socket.inet_pton(socket.AF_INET6, s)
    result=0
    for x in bytearray(data):result=(result<<8)|x
    return result

class Address(object):
    def __init__(self, raw, version, integer):
        self.raw=raw;self.version=version;self.integer=integer
        if version == 4:
            self.is_unspecified = _inside(integer,0,8,32)
            self.is_loopback = _inside(integer,0x7f000000,8,32)
            self.is_link_local = _inside(integer,0xa9fe0000,16,32)
            self.is_multicast = _inside(integer,0xe0000000,4,32)
            self.is_private = any(_inside(integer,p,b,32) for p,b in (
                (0x0a000000,8),(0xac100000,12),(0xc0a80000,16)))
            self.is_reserved = any(_inside(integer,p,b,32) for p,b in (
                (0xf0000000,4),(0x64400000,10),(0xc6120000,15),
                (0xc0000000,24),(0xc0000200,24),(0xc6336400,24),
                (0xcb007100,24)))
        else:
            self.is_unspecified=integer==0
            self.is_loopback=integer==1
            self.is_link_local=_inside(integer,0xfe800000000000000000000000000000,10,128)
            self.is_multicast=_inside(integer,0xff000000000000000000000000000000,8,128)
            self.is_private=_inside(integer,0xfc000000000000000000000000000000,7,128)
            self.is_reserved=(_inside(integer,0x20010db8000000000000000000000000,32,128)
                              or _inside(integer,0x00000000000000000000ffff00000000,96,128)
                              or not _inside(integer,0x20000000000000000000000000000000,3,128))
        self.is_global=not(any((self.is_unspecified,self.is_loopback,
                                self.is_link_local,self.is_multicast,
                                self.is_private,self.is_reserved)))

def ip_address(raw):
    raw=str(raw).strip()
    try:
        return Address(raw,4,_v4int(raw))
    except (ValueError, OSError, socket.error):
        pass
    try:
        return Address(raw,6,_v6int(raw))
    except (ValueError, OSError, socket.error):
        raise ValueError('Invalid IP address')
