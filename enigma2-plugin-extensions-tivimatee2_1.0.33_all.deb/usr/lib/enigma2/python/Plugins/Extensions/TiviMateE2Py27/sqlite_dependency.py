# -*- coding: utf-8 -*-
"""Python2 DreamOS: optional sqlite3, no package auto-install and no Python3 path."""

def sqlite_ready():
    try:
        import sqlite3
        db = sqlite3.connect(':memory:')
        try: db.execute('SELECT 1').fetchone()
        finally: db.close()
        return True
    except Exception:
        return False

def ensure_sqlite(session):
    # The plugin already implements JSON fallbacks. Never install Python3 packages.
    return sqlite_ready()
