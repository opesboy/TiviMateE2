# -*- coding: utf-8 -*-
"""HTTPS helpers for VTi / legacy Enigma2 Python 2.7 images.

Why this exists (VTi 14/15, Python 2.7):
  * many VTi images ship without a usable CA bundle, so every verified HTTPS
    request (TMDb API, image.tmdb.org, fanart.tv, https portals) fails with
    CERTIFICATE_VERIFY_FAILED;
  * BusyBox wget on VTi is usually built without HTTPS, so the old
    "retry with wget" recovery path never succeeds either;
  * old Twisted downloadPage() does not send SNI, which CDN hosts such as
    image.tmdb.org require.

Policy:
  * verification stays ON by default; a Mozilla CA bundle shipped with the
    plugin is loaded when the receiver has none;
  * public artwork requests (no Cookie / Authorization header) may retry
    with an unverified context, and image.tmdb.org may retry over plain HTTP
    (TMDb officially serves images over both). Credentials are never sent
    through those fallbacks.
"""
import os
import ssl
import threading

PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
BUNDLED_CA = os.path.join(PLUGIN_PATH, 'resources', 'cacert.pem')

_SYSTEM_CA_FILES = (
    '/etc/ssl/certs/ca-certificates.crt',
    '/etc/pki/tls/certs/ca-bundle.crt',
    '/etc/ssl/ca-bundle.pem',
    '/etc/ssl/cert.pem',
    '/usr/lib/ssl/cert.pem',
    '/usr/share/ca-certificates/ca-bundle.crt',
    '/etc/ssl/certs/ca-bundle.crt',
)

HAS_CONTEXT = hasattr(ssl, 'SSLContext') and hasattr(ssl, 'create_default_context')

# Exception classes that do not exist on Python 2.7. A class that is never
# raised keeps "except X" clauses valid instead of raising AttributeError.
class _NeverRaised(Exception):
    pass

SSLCertVerificationError = getattr(ssl, 'SSLCertVerificationError', _NeverRaised)
CertificateError = getattr(ssl, 'CertificateError', _NeverRaised)
SSLError = getattr(ssl, 'SSLError', _NeverRaised)

_LOCK = threading.Lock()
_CACHE = {}

# Hosts that only serve public artwork / metadata.
PUBLIC_ARTWORK_HOSTS = (
    'image.tmdb.org', 'assets.fanart.tv', 'img.youtube.com', 'i.ytimg.com',
    'raw.githubusercontent.com', 'upload.wikimedia.org', 'i.imgur.com',
)
SENSITIVE_HEADERS = ('cookie', 'authorization', 'x-user-agent', 'x-api-key',
                     'proxy-authorization')


def _ca_count(context):
    try:
        return int(context.cert_store_stats().get('x509_ca', 0))
    except Exception:
        return -1


def _load_ca(context):
    """Make sure the context knows at least one CA bundle."""
    if _ca_count(context) > 0:
        return context
    for path in _SYSTEM_CA_FILES + (BUNDLED_CA,):
        try:
            if os.path.isfile(path) and os.path.getsize(path) > 1024:
                context.load_verify_locations(cafile=path)
                if _ca_count(context) != 0:
                    break
        except Exception:
            continue
    return context


# Receivers without NTP/transponder time boot at 1970 (the VTi crash logs
# show "Dec 31 1969"). Every certificate is then "not yet valid" and ALL
# verified HTTPS fails. OpenSSL's X509_V_FLAG_NO_CHECK_TIME keeps chain and
# hostname verification but skips only the date check in that case.
_X509_V_FLAG_NO_CHECK_TIME = 0x200000


def clock_is_broken():
    try:
        import time
        return time.time() < 1704067200  # before 2024-01-01
    except Exception:
        return False


def new_verified_context():
    """A fresh verified SSLContext (callers may modify it)."""
    if not HAS_CONTEXT:
        return None
    try:
        context = ssl.create_default_context()
    except Exception:
        return None
    try:
        context.options |= getattr(ssl, 'OP_NO_SSLv2', 0) | getattr(ssl, 'OP_NO_SSLv3', 0)
    except Exception:
        pass
    if clock_is_broken():
        try:
            context.verify_flags |= _X509_V_FLAG_NO_CHECK_TIME
        except Exception:
            pass
    return _load_ca(context)


def verified_context():
    """Shared verified context. Do not mutate the returned object."""
    if not HAS_CONTEXT:
        return None
    if clock_is_broken() and not _CACHE.get('clock_broken'):
        # Rebuild once the clock is known to be wrong (or after it is fixed).
        _CACHE.pop('verified', None)
        _CACHE['clock_broken'] = True
    ctx = _CACHE.get('verified')
    if ctx is None:
        with _LOCK:
            ctx = _CACHE.get('verified')
            if ctx is None:
                ctx = new_verified_context()
                _CACHE['verified'] = ctx
    return ctx


def unverified_context():
    if not HAS_CONTEXT:
        return None
    ctx = _CACHE.get('unverified')
    if ctx is None:
        try:
            ctx = ssl._create_unverified_context()
        except Exception:
            try:
                ctx = ssl.SSLContext(getattr(ssl, 'PROTOCOL_SSLv23', 2))
                ctx.verify_mode = ssl.CERT_NONE
            except Exception:
                ctx = None
        _CACHE['unverified'] = ctx
    return ctx


def is_certificate_error(error):
    reason = getattr(error, 'reason', error)
    if isinstance(reason, (SSLCertVerificationError, CertificateError)):
        return True
    text = ('%s %s' % (error, reason)).lower()
    return ('certificate_verify_failed' in text or 'certificate verify failed' in text
            or 'self signed certificate' in text or 'unable to get local issuer' in text
            or "hostname" in text and "doesn't match" in text)


def is_tls_error(error):
    """Any TLS-level failure (verify, handshake, protocol, SNI)."""
    reason = getattr(error, 'reason', error)
    if isinstance(reason, (SSLError, SSLCertVerificationError, CertificateError)):
        return True
    if isinstance(error, (SSLError, SSLCertVerificationError, CertificateError)):
        return True
    text = ('%s %s' % (error, reason)).lower()
    return ('ssl' in text or 'tls' in text or 'certificate' in text or
            'handshake' in text or 'eof occurred in violation' in text)


def request_url(request):
    """Full URL of a urllib2 Request (Python 2 Requests lack .full_url)."""
    getter = getattr(request, 'get_full_url', None)
    if callable(getter):
        try:
            return getter()
        except Exception:
            pass
    return str(getattr(request, 'full_url', '') or request or '')


def _hostname(url):
    try:
        from urlparse import urlsplit
    except ImportError:  # pragma: no cover - Python 3 test runs only
        from urllib.parse import urlsplit
    try:
        return (urlsplit(str(url)).hostname or '').lower()
    except Exception:
        return ''


def has_sensitive_headers(request):
    try:
        names = list(getattr(request, 'headers', {}).keys()) + \
            list(getattr(request, 'unredirected_hdrs', {}).keys())
    except Exception:
        names = []
    return any(str(name).lower() in SENSITIVE_HEADERS for name in names)


def _https_handler(urllib2, context):
    if context is None:
        return urllib2.HTTPSHandler()
    try:
        return urllib2.HTTPSHandler(context=context)
    except TypeError:
        return urllib2.HTTPSHandler()


def _clone_request(urllib2, request, url):
    headers = {}
    try:
        headers.update(getattr(request, 'headers', {}) or {})
        headers.update(getattr(request, 'unredirected_hdrs', {}) or {})
    except Exception:
        pass
    headers.pop('Host', None)
    return urllib2.Request(url, data=getattr(request, 'data', None), headers=headers)


# image.tmdb.org officially serves the same images over plain HTTP. On weak
# Python 2.7 receivers the TLS handshake (and CA parsing) costs more than the
# download itself, and old stacks fail on SNI/CA problems. Public images
# carry no credentials, so fetch them over HTTP first (HTTPS stays fallback).
TMDB_IMAGES_HTTP_FIRST = True


def fast_image_url(url):
    """Return the quickest equivalent URL for a public TMDb image."""
    try:
        text = str(url or '')
    except Exception:
        return url
    if TMDB_IMAGES_HTTP_FIRST and text.lower().startswith('https://image.tmdb.org/'):
        return 'http://' + text[len('https://'):]
    return url


def artwork_open(request, timeout=8, handlers=()):
    """Open a public artwork request with VTi-safe HTTPS fallbacks.

    1. verified TLS (system CA, or the bundled Mozilla CA);
    2. if TLS fails and no credential header is present: unverified TLS;
    3. image.tmdb.org only: the same path over plain HTTP.
    """
    import urllib2
    if isinstance(request, basestring):
        request = urllib2.Request(request)
    url = request_url(request)
    is_https = url.lower().startswith('https://')
    if is_https and _hostname(url) == 'image.tmdb.org' and TMDB_IMAGES_HTTP_FIRST:
        try:
            opener = urllib2.build_opener(*tuple(handlers))
            return opener.open(_clone_request(urllib2, request, fast_image_url(url)),
                               timeout=timeout)
        except urllib2.HTTPError as error:
            if getattr(error, 'code', 0) == 404:
                raise
        except Exception:
            pass
    attempts = [verified_context()]
    if is_https and HAS_CONTEXT and not has_sensitive_headers(request):
        attempts.append(unverified_context())
    last_error = None
    for context in attempts:
        opener = urllib2.build_opener(*(tuple(handlers) + (_https_handler(urllib2, context),)))
        try:
            return opener.open(request, timeout=timeout)
        except urllib2.HTTPError:
            raise
        except Exception as error:
            last_error = error
            if not is_https or not is_tls_error(error):
                # DNS / timeout / refused: another TLS mode cannot help.
                break
    if is_https and _hostname(url) == 'image.tmdb.org':
        plain = 'http://' + url[len('https://'):]
        opener = urllib2.build_opener(*tuple(handlers))
        return opener.open(_clone_request(urllib2, request, plain), timeout=timeout)
    if last_error is not None:
        raise last_error
    raise IOError('artwork request failed')


def twisted_context_factory(url):
    """SNI-enabled client context factory for Twisted downloadPage(https).

    Old Twisted (VTi) uses ssl.ClientContextFactory, which sends no SNI.
    Returns None when pyOpenSSL/Twisted SSL is not installed.
    """
    host = _hostname(url)
    if not host:
        return None
    try:
        from twisted.internet import ssl as twisted_ssl
        from OpenSSL import SSL
    except Exception:
        return None
    if isinstance(host, unicode):
        host = host.encode('idna')

    class _SNIContextFactory(twisted_ssl.ClientContextFactory):
        def getContext(self, *args, **kwargs):
            context = SSL.Context(SSL.SSLv23_METHOD)
            try:
                context.set_options(SSL.OP_NO_SSLv2 | SSL.OP_NO_SSLv3)
            except Exception:
                pass

            def info_callback(connection, where, ret):
                if where & SSL.SSL_CB_HANDSHAKE_START:
                    try:
                        connection.set_tlsext_host_name(host)
                    except Exception:
                        pass
            context.set_info_callback(info_callback)
            return context
    try:
        return _SNIContextFactory()
    except Exception:
        return None


def install_ca_environment():
    """Point OpenSSL/requests/curl at the bundled CA when the image has none.

    Only fills variables that are unset and only when no system bundle file
    exists, so receivers with working certificates are not changed. Fixes
    subtitle seekers and other clients that build their own SSL contexts.
    """
    try:
        if any(os.path.isfile(path) and os.path.getsize(path) > 1024
               for path in _SYSTEM_CA_FILES):
            return False
        if not os.path.isfile(BUNDLED_CA):
            return False
        for name in ('SSL_CERT_FILE', 'REQUESTS_CA_BUNDLE', 'CURL_CA_BUNDLE'):
            if not os.environ.get(name):
                os.environ[name] = BUNDLED_CA
        return True
    except Exception:
        return False
