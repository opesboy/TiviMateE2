# -*- coding: utf-8 -*-
"""Missing-artwork recovery shared with GENRE, without modifying its screens.

Only invoked for empty/broken slots.  GENRE's extraction, its authenticated,
validated image downloader and alpha-safe logo decoder are reused unchanged.
Never falls back from a backdrop to a portrait poster or vice versa.
"""
import os
import re
from .py27_compat import text_type
from Plugins.Extensions.TiviMateE2Py27.py27_futures import ThreadPoolExecutor

from .artwork_queue import cached_artwork, cached_candidates_first
from .cache_manager import stable_cache_key, persistent_cache_get
from .genre_ultra_artwork import request as genre_ultra_request, request_transparent_logo

# Small bounded pool: provider-info lookups never run on Enigma2's GUI thread.
_HERO_POOL = ThreadPoolExecutor(max_workers=3, thread_name_prefix="TiviMateSharedHero")


def _tmdb_url(value, media):
    from .backdrop_manager import tmdb_backdrop_url
    from .logo_manager import tmdb_logo_url
    from .poster_manager import tmdb_poster_url
    if not value:
        return ''
    value = text_type(value).strip()
    if value.startswith('/') and not value.startswith('//'):
        return (tmdb_logo_url(value) if media == 'logo' else
                tmdb_backdrop_url(value) if media == 'backdrop' else tmdb_poster_url(value))
    return value if value.startswith(('http://', 'https://')) else ''


def _provider_details(source, item, kind, allow_network=False):
    """Read the EXACT GENRE provider-info cache key before making a server call."""
    source = dict(source or {})
    sid = str(item.get('series_id') or item.get('stream_id') or item.get('id') or '').strip()
    if not sid or str(source.get('type') or '').lower() not in ('xtream', 'stalker'):
        return {}
    key = stable_cache_key('genre_provider_details_v1', source.get('type'),
        source.get('url') or source.get('base_url') or source.get('host'),
        source.get('username') or source.get('user'), source.get('password'), kind, sid)
    cached = persistent_cache_get(key)
    if isinstance(cached, dict) and any(cached.get(x) for x in
            ('_genre_poster_url', '_genre_backdrop_url', '_genre_logo_url')):
        return cached
    if not allow_network:
        return {}
    # Fetch only after the local/provider-listing Hero candidates fail.
    try:
        from .core import get_source_client
        client = get_source_client(source)
        return (client.series_info(sid) if kind == 'series' else client.vod_info(sid)) or {}
    except Exception:
        return {}


def _gallery_backdrop_paths(tmdb, tmdb_id, kind, details):
    """Ultra-style same-ID gallery fallback. Only called after the quick
    provider/cached artwork has failed. Never substitutes a portrait poster.
    """
    from .content_home import _tmdb_same_movie_backdrops
    ordered = list(_tmdb_same_movie_backdrops(details))
    # Details bundles can have no images.backdrops array; use the exact
    # verified TMDb identity, not another fuzzy title search.
    if len(ordered) < 3:
        try:
            media = 'tv' if kind == 'series' else 'movie'
            gallery = tmdb._get('/%s/%s/images' % (media, int(tmdb_id)), {'language': None}) or {}
            rows = []
            for row in gallery.get('backdrops') or []:
                if not isinstance(row, dict):
                    continue
                path = str(row.get('file_path') or '').strip()
                try:
                    width = int(row.get('width') or 0)
                    height = int(row.get('height') or 0)
                    vote = float(row.get('vote_average') or 0)
                    votes = int(row.get('vote_count') or 0)
                except (TypeError, ValueError, OverflowError):
                    continue
                if (path.startswith('/') and not path.startswith('//') and
                        width >= 640 and height >= 240 and width >= height * 1.3):
                    rows.append((vote, votes, width, path))
            for _vote, _votes, _width, path in sorted(rows, reverse=True):
                ordered.append(path)
        except Exception:
            pass
    seen = set()
    results = []
    for path in ordered:
        normalized = _tmdb_url(path, 'backdrop')
        if normalized and normalized not in seen:
            seen.add(normalized)
            results.append(normalized)
        if len(results) >= 8:
            break
    return results


def _candidates(source, item, kind, media, excluded, enrich=False):
    """GENRE provider policy -> VERIFIED TMDb title -> exact-ID image gallery."""
    from .genre_page import _genre_provider_poster_urls, _genre_provider_artwork
    from .logo_manager import provider_logo_url
    from .tmdb_client import TMDbClient
    from .poster_manager import tmdb_poster_url
    source, item = dict(source or {}), dict(item or {})
    seen = set(text_type(x or u'').strip() for x in (excluded or ()))
    result = []
    def add(url):
        url = text_type(url or u'').strip().replace('\\/', '/')
        url = _tmdb_url(url, media)
        if url and url not in seen:
            seen.add(url)
            result.append(url)

    # A previously downloaded GENRE image is used ahead of all network work.
    data = _provider_details(source, item, kind, allow_network=enrich)
    records = [item, data]
    for record in records:
        if not isinstance(record, dict):
            continue
        if media == 'poster':
            if record.get('_genre_poster_url'):
                add(record['_genre_poster_url'])
            for url in _genre_provider_poster_urls(source, record, kind):
                add(url)
            if record is data:
                poster, _ = _genre_provider_artwork(source, record)
                add(poster)
        elif media == 'backdrop':
            add(record.get('_genre_backdrop_url'))
            from .genre_page import _server_backdrop_url
            add(_server_backdrop_url(source, record))
            if record is data:
                _, back = _genre_provider_artwork(source, record)
                add(back)
        else:
            add(record.get('_genre_logo_url'))
            add(provider_logo_url(source, record))

    # Cross-page image identity hit: only metadata verified by TMDb itself is
    # eligible here. Never treat a raw IPTV stream ID as a TMDb identifier.
    verified_id = item.get('_verified_tmdb_id') or item.get('_tmdb_verified_id')
    if verified_id and media in ('poster', 'backdrop'):
        try:
            from .identity_artwork_index import cached_url
            local = cached_url(kind, verified_id, media)
            if local and local not in result:
                result.insert(0, local)
        except Exception:
            pass

    # Use the same stable cache-first order as GENRE; no network operation
    # occurs until every known local candidate has been checked.
    bucket = {'poster':'posters', 'backdrop':'backdrops', 'logo':'logos'}[media]
    result = cached_candidates_first(result, bucket)

    if not enrich:
        return cached_candidates_first(result, bucket, limit=16), None, {}
    title = text_type(item.get('name') or item.get('title') or u'').strip()
    year = re.search(r'(?:19|20)\d{2}', str(item.get('year') or ''))
    year = year.group(0) if year else None
    if not title:
        return cached_candidates_first(result, bucket, limit=16), None, {}
    tmdb = TMDbClient()
    # Only a canonical TMDb ID can bypass search. Provider stream/series IDs
    # are never identities for movie/tv gallery requests.
    tid = str(item.get('tmdb_id') or data.get('tmdb_id') or '').strip()
    tid = tid if tid.isdigit() and int(tid) > 0 else ''
    found = {}
    if not tid:
        try:
            required = {'poster':'poster_path', 'backdrop':'backdrop_path', 'logo':'id'}[media]
            found = tmdb.search_artwork(title, kind, year, required_key=required) or {}
            if not found and year:
                found = tmdb.search_artwork(title, kind, None, required_key=required) or {}
            if not found:
                found = tmdb.search_title(title, kind, year) or {}
        except Exception:
            found = {}
        tid = found.get('id') or found.get('tmdb_id')
    if not tid:
        return cached_candidates_first(result, bucket, limit=16), None, {}
    try:
        details = tmdb.details_bundle(tid, kind) or {}
    except Exception:
        details = {}
    try:
        from .identity_artwork_index import remember, cached_url
        remember(kind, tid, details.get('poster_path') or found.get('poster_path'),
                 details.get('backdrop_path') or found.get('backdrop_path'))
        local = cached_url(kind, tid, media) if media in ('poster', 'backdrop') else ''
        if local:
            result.insert(0, local)
    except Exception:
        pass
    if media == 'poster':
        add(tmdb_poster_url(details.get('poster_path') or found.get('poster_path')))
    elif media == 'backdrop':
        add(details.get('backdrop_path') or found.get('backdrop_path'))
        # Ultra's alternate-gallery policy, but unlike Ultra, a failed
        # primary backdrop is followed by same-identity gallery candidates.
        for url in _gallery_backdrop_paths(tmdb, tid, kind, details):
            add(url)
    # TMDb candidates discovered during enrichment can already exist on disk.
    # Rank all known candidates before the first enriched network attempt.
    return cached_candidates_first(result, bucket, limit=16), (tmdb, tid, details) if media == 'logo' else None, found


def recover(source, item, kind, media, ready, failed, gui, excluded=(), canvas=(620, 96), cancelled=None):
    """Request one independent missing Hero component; callbacks via GUI.

    No repaint is initiated here. The owning screen must reject stale tokens
    and should never invoke this for an already successfully decoded image.
    """
    if media not in ('poster', 'backdrop', 'logo') or not isinstance(item, dict):
        gui(failed, '')
        return
    def is_cancelled():
        try:
            return bool(cancelled and cancelled())
        except Exception:
            return True
    def worker():
        if is_cancelled():
            return
        try:
            urls, _, _ = _candidates(source, item, kind, media, excluded, enrich=False)
        except Exception:
            urls = []
        attempted = set(excluded or ())
        bucket = {'poster':'posters', 'backdrop':'backdrops', 'logo':'logos'}[media]
        def attempt(urls, index, phase):
            if is_cancelled():
                return
            if index >= len(urls):
                if phase:
                    gui(failed, '')
                else:
                    try:
                        _HERO_POOL.submit(enrich)
                    except RuntimeError:
                        gui(failed, '')
                return
            url = urls[index]
            attempted.add(url)
            def got(path):
                if is_cancelled():
                    return
                if not path or not os.path.isfile(path):
                    attempt(urls, index + 1, phase)
                    return
                # Share GENRE's validation too: reject portrait backdrops
                # and generic provider "NO IMAGE" poster slate placeholders.
                # Keep pixel inspection outside the Enigma2 GUI thread.
                def validate():
                    valid = True
                    try:
                        if media == 'backdrop':
                            from .content_home import _cinematic_is_landscape_image
                            valid = _cinematic_is_landscape_image(path)
                        elif media == 'poster' and 'image.tmdb.org' not in url:
                            from .genre_page import _provider_placeholder_cached_verdict
                            valid = _provider_placeholder_cached_verdict(path) is not True
                    except Exception:
                        valid = True
                    if valid:
                        gui(ready, path)
                    else:
                        gui(attempt, urls, index + 1, phase)
                try:
                    _HERO_POOL.submit(validate)
                except RuntimeError:
                    gui(attempt, urls, index + 1, phase)
            def miss(_path):
                attempt(urls, index + 1, phase)
            if media == 'logo':
                request_transparent_logo(url, dict(source or {}), got, miss, gui)
            else:
                genre_ultra_request(url, bucket, dict(source or {}), got, miss, gui)

        def enrich():
            if is_cancelled():
                return
            try:
                urls, logo_context, _found = _candidates(
                    source, item, kind, media, attempted, enrich=True)
            except Exception:
                urls, logo_context = [], None
            if is_cancelled():
                return
            if media == 'logo' and logo_context:
                try:
                    from .title_logo_ultra_bridge import resolve_title_logo
                    client, tid, details = logo_context
                    path = resolve_title_logo(client, kind, tid,
                        title=text_type(item.get('name') or item.get('title') or u''),
                        details=details, item=item, canvas=canvas)
                    if path and os.path.isfile(path):
                        gui(ready, path)
                        return
                    if not is_cancelled():
                        from .logo_manager import localized_logo_url
                        direct = localized_logo_url(client,
                            'tv' if kind == 'series' else 'movie', tid,
                            (details or {}).get('images') or {},
                            details=details, item=item,
                            title=text_type(item.get('name') or item.get('title') or u''))
                        if direct and direct not in attempted and direct not in urls:
                            urls.insert(0, direct)
                except Exception:
                    pass
            attempt(urls, 0, True)

        if media == 'logo':
            # Details-style priority: verified TMDb canvas first, provider
            # fallback only if the identity resolver cannot prepare a logo.
            # This changes neither poster/backdrop workers nor their queues.
            enrich()
        else:
            attempt(urls, 0, False)
    try:
        _HERO_POOL.submit(worker)
    except RuntimeError:
        gui(failed, '')
