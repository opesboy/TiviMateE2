# -*- coding: utf-8 -*-
"""Small scoped Python 2.7 fallbacks: no monkey-patching system modules.

No use of Python 3 interpreter, package, cache or updater.
"""
import os
import sys
import time
import socket
import threading
import subprocess
import binascii
import struct
import ctypes
import errno
import collections

TimeoutError = socket.timeout

try:
    _libc = ctypes.CDLL('libc.so.6')
    class _Timespec(ctypes.Structure):
        _fields_ = [('tv_sec', ctypes.c_long), ('tv_nsec', ctypes.c_long)]
    def _clock_monotonic():
        t = _Timespec()
        if _libc.clock_gettime(1, ctypes.byref(t)) != 0:
            return time.time()
        return float(t.tv_sec) + float(t.tv_nsec) / 1000000000.0
except Exception:
    def _clock_monotonic(): return time.time()
monotonic = getattr(time, 'monotonic', _clock_monotonic)

def acquire_with_timeout(semaphore, wait_seconds):
    """Acquire a semaphore with a deadline on Python 2.7 and Python 3.

    Preserve the existing wait limit and concurrency (no extra workers).
    Python 2.7 semaphore.acquire() accepts no timeout keyword.
    """
    wait_seconds = max(0.0, float(wait_seconds))
    try:
        return bool(semaphore.acquire(timeout=wait_seconds))
    except TypeError:
        deadline = monotonic() + wait_seconds
        while True:
            if semaphore.acquire(False):
                return True
            remaining = deadline - monotonic()
            if remaining <= 0:
                return False
            time.sleep(min(0.05, remaining))


def gui_text(value):
    """UTF-8 byte-string for DreamOS Python 2.7 Enigma2 list widgets."""
    return text_type(value if value is not None else '').encode('utf-8')


def atomic_replace(source, destination):
    # POSIX rename atomically replaces existing file on same filesystem.
    return os.rename(source, destination)

def int_from_bytes(value, byteorder='big', signed=False):
    value = bytes(value)
    if not value: return 0
    if byteorder == 'little': value = value[::-1]
    number = 0
    for ch in bytearray(value): number = (number << 8) | ch
    if signed and (ord(value[0]) & 0x80): number -= 1 << (8 * len(value))
    return number

def thread_factory(*args, **kwargs):
    daemon = kwargs.pop('daemon', None)
    thread = threading.Thread(*args, **kwargs)
    if daemon is not None: thread.setDaemon(bool(daemon))
    return thread

def thread_ident():
    try:
        import thread
        return thread.get_ident()
    except Exception:
        return threading.currentThread().ident

def which(cmd):
    if os.path.isabs(cmd): return cmd if os.access(cmd, os.X_OK) else None
    for folder in os.environ.get('PATH', '/usr/bin:/bin').split(os.pathsep):
        path = os.path.join(folder or '.', cmd)
        if os.path.isfile(path) and os.access(path, os.X_OK): return path
    return None

class _SubprocessResult(object):
    def __init__(self, returncode, stdout=b'', stderr=b''):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr

def subprocess_run(args, **kwargs):
    check = bool(kwargs.pop('check', False))
    timeout = kwargs.pop('timeout', None)
    kwargs.pop('text', None)
    kwargs.pop('encoding', None)
    kwargs.pop('errors', None)
    proc = subprocess.Popen(args, **kwargs)
    if timeout is None:
        out, err = proc.communicate()
    else:
        # subprocess.Popen.communicate(timeout=) wasn't available in Python 2.7.
        finished = threading.Event()
        output = [b'', b'']
        def _collect():
            try: output[0], output[1] = proc.communicate()
            finally: finished.set()
        t = thread_factory(target=_collect, daemon=True)
        t.start()
        if not finished.wait(float(timeout)):
            try: proc.kill()
            except Exception: pass
            finished.wait(1.0)
            raise RuntimeError('Subprocess timeout')
        out, err = output
    if check and proc.returncode:
        raise subprocess.CalledProcessError(proc.returncode, args)
    return _SubprocessResult(proc.returncode, out, err)

def fspath(path):
    return getattr(path, '__fspath__', lambda: str(path))()

def hex_bytes(data): return binascii.hexlify(data)

def time_ns(): return int(time.time() * 1000000000)

class _DirEntry(object):
    def __init__(self, directory, name):
        self.name = name
        self.path = os.path.join(directory, name)
    def is_file(self, follow_symlinks=True):
        if not follow_symlinks and os.path.islink(self.path): return False
        return os.path.isfile(self.path)
    def is_dir(self, follow_symlinks=True):
        if not follow_symlinks and os.path.islink(self.path): return False
        return os.path.isdir(self.path)
    def is_symlink(self): return os.path.islink(self.path)
    def stat(self): return os.stat(self.path)

class _Scandir(object):
    def __init__(self, directory): self.directory = directory
    def __enter__(self): return iter(self)
    def __exit__(self, *_): return False
    def __iter__(self):
        for item in os.listdir(self.directory): yield _DirEntry(self.directory, item)

def scandir(directory): return _Scandir(directory)

# Python3 OSError subclasses are absent on Python2; use their native base classes.
FileExistsError = OSError
PermissionError = OSError
ConnectionError = OSError
ConnectionRefusedError = OSError
BrokenPipeError = IOError
ConnectionResetError = IOError

def html_escape(value, quote=True):
    import cgi
    if not isinstance(value, (str, unicode)):
        value = unicode(value)
    return cgi.escape(value, quote=quote)

# Python2.7 lacks re.fullmatch, str.casefold, and functools.lru_cache.
def is_ascii_text(value):
    """True for ASCII str/unicode in Python 2.7 and Python 3."""
    try:
        value.encode('ascii')
        return True
    except (UnicodeError, AttributeError):
        return False


def is_printable_char(value):
    """Python 2.7 equivalent of Unicode char.isprintable()."""
    import unicodedata
    if value == u' ':
        return True
    try:
        return unicodedata.category(value)[:1] not in ('C', 'Z')
    except (TypeError, ValueError):
        return False


def fullmatch(pattern, value, flags=0):
    import re
    if value is None: return None
    if hasattr(pattern, 'match') and hasattr(pattern, 'pattern'):
        match = pattern.match(value)
    else:
        match = re.match(pattern, value, flags)
    return match if match is not None and match.end() == len(value) else None

def text_type(value):
    """Return Unicode in Python 2.7; never decode a byte string as ASCII."""
    if isinstance(value, unicode):
        return value
    if isinstance(value, str):
        try:
            return value.decode('utf-8')
        except UnicodeDecodeError:
            # Legacy Arabic portal catalogues sometimes contain Windows-1256
            # strings that cannot be decoded as UTF-8 (e.g. byte 0xE0).
            try:
                return value.decode('cp1256')
            except (UnicodeError, LookupError):
                return value.decode('utf-8', 'replace')
    try:
        return unicode(value)
    except (UnicodeError, TypeError, ValueError):
        return unicode(str(value), 'utf-8', 'replace')

def digits_translation_table():
    source = u'٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹'
    target = u'01234567890123456789'
    return dict((ord(src), ord(dst)) for src, dst in zip(source,target))

def lru_cache(maxsize=128):
    from functools import wraps
    from collections import OrderedDict
    def decorate(fn):
        cache = OrderedDict()
        @wraps(fn)
        def wrapped(*args, **kwargs):
            key = (args, tuple(sorted(kwargs.items())))
            try:
                value = cache.pop(key)
            except (KeyError, TypeError):
                value = fn(*args, **kwargs)
            cache[key] = value
            if maxsize is not None and len(cache)>maxsize:
                cache.popitem(last=False)
            return value
        def clear(): cache.clear()
        wrapped.cache_clear=clear
        return wrapped
    return decorate


def native_episode_url_bytes(value):
    """Keep existing ASCII IPTV URLs unchanged; quote only non-ASCII UTF-8.

    eServiceReference on Python2 needs native str bytes, not Unicode.
    ASCII URL options such as the IPTV pipe headers are passed through.
    """
    from urllib import quote
    value = text_type(value if value is not None else u'').strip()
    try:
        return value.encode('ascii')
    except UnicodeEncodeError:
        return quote(value.encode('utf-8'), safe=":/?#[]@!$&'()*+,;=%|~")


def native_media_url_bytes(value):
    """Receiver-safe URL for VOD/episodes without changing ASCII links.

    Python2 eServiceReference expects a native byte string. Existing URL
    escape sequences and IPTV query/piped headers must not be rewritten.
    """
    from urllib import quote
    if value is None:
        return ''
    if isinstance(value, unicode):
        raw = value.strip().encode('utf-8')
    elif isinstance(value, str):
        raw = value.strip()
    else:
        raw = text_type(value).strip().encode('utf-8')
    if not raw:
        return ''
    try:
        raw.decode('ascii')
        return raw
    except UnicodeDecodeError:
        return quote(raw, safe=":/?#[]@!$&'()*+,;=%|~")


def http_url_bytes(value):
    """Return percent-escaped ASCII URL bytes for Python2 urllib2/Twisted.

    Preserve already-percent-escaped addresses, query separators and reserved
    URL syntax. No changes to saved server URLs or cache directory selection.
    """
    from urllib import quote
    text = text_type(value if value is not None else u'').strip()
    return quote(text.encode('utf-8'), safe=":/?#[]@!$&'()*+,;=%")
