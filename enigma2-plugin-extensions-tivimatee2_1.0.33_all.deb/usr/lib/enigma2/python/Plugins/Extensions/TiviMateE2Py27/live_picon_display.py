# -*- coding: utf-8 -*-
"""Receiver-native, GUI-thread, cache-only picon presentation for DreamOS.

Existing downloader/cache paths stay unchanged. No network and no PIL required.
Request identity prevents an old channel icon repainting a new selection.
"""
from __future__ import absolute_import
import os
from enigma import ePicLoad
from .picload_compat import connect_picture_data


def paint_picon(screen, widget, path, request_id, current_id):
    if not path or not os.path.isfile(path) or request_id != current_id():
        return False
    try:
        target = screen[widget]
        if target.instance is None:
            return False
        # PNG fast path works on native Enigma2 without Pillow.
        if path.lower().endswith('.png'):
            try:
                target.instance.setPixmapFromFile(path)
                target.show()
                return True
            except Exception:
                pass
        loaders = getattr(screen, '_nativeLivePiconLoaders', None)
        if loaders is None:
            loaders = {}
            screen._nativeLivePiconLoaders = loaders
        loader = ePicLoad()
        loaders[widget] = loader
        dimensions = target.instance.size()
        loader.setPara((max(1, dimensions.width()), max(1, dimensions.height()),
                        0, 0, False, 1, '#00000000'))

        def done(_=None, expected=request_id, name=widget, current=loader):
            if loaders.get(name) is not current:
                return
            loaders.pop(name, None)
            if expected != current_id():
                return
            try:
                data = current.getData()
                target = screen[name]
                if data is not None and target.instance is not None:
                    target.instance.setPixmap(data)
                    target.show()
            except Exception:
                pass
        connect_picture_data(loader, done, screen, oneshot=True)
        status = loader.startDecode(path)
        if isinstance(status, int) and status < 0:
            loaders.pop(widget, None)
            return False
        return True
    except Exception:
        return False
