# -*- coding: utf-8 -*-
"""Three-image Movies/Series PAGE DESIGN picker (no captions or bottom buttons).

Unlike GENRE's independent 4-style poster picker, this chooses among the
Classic Movies page, approved New Movies page and real 24-poster catalog.
The only focus graphic is the gold border around the active preview.
"""
import os
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from .display_scale import scale_skin, sx, sy
from enigma import ePoint, eSize
from .movies_layout_choice import get_content_layout

_ASSETS = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker'
# The preview JPEG shows New (six upper posters), Current (backdrop cards), then 24 Grid.
# Bind those visual positions to the corresponding real screens, not the previous reversed mapping.
_CHOICES = ('new', 'current', 'grid24')
_FOCUS_GEOMETRY = ((18, 146, 644, 744), (658, 146, 593, 744), (1247, 146, 655, 744))

class MoviesPagePicker(Screen):
    skin = scale_skin('''<screen name="MoviesPagePicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#06101E">
<ePixmap position="0,0" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker/layout_tile_0.jpg" scale="1" alphatest="off" zPosition="1" />
<ePixmap position="960,0" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker/layout_tile_1.jpg" scale="1" alphatest="off" zPosition="1" />
<ePixmap position="0,540" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker/layout_tile_2.jpg" scale="1" alphatest="off" zPosition="1" />
<ePixmap position="960,540" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/movies/design_picker/layout_tile_3.jpg" scale="1" alphatest="off" zPosition="1" />
<widget name="designFocus" position="0,0" size="700,760" scale="1" alphatest="blend" zPosition="2" />
</screen>''')

    def __init__(self, session, kind='vod'):
        Screen.__init__(self, session)
        self.kind = 'series' if kind == 'series' else 'vod'
        active = get_content_layout(self.kind)
        self.index = _CHOICES.index(active) if active in _CHOICES else 0
        self._finished = False
        self['designFocus'] = Pixmap()
        self['actions'] = ActionMap(
            ['OkCancelActions', 'DirectionActions', 'ChannelSelectBaseActions',
             'InfobarChannelSelection', 'MenuActions'],
            {'ok': self.accept, 'cancel': self.cancel, 'menu': self.cancel,
             'left': self.previous, 'right': self.next,
             'up': self.previous, 'down': self.next,
             'pageUp': self.previous, 'pageDown': self.next,
             'channelUp': self.previous, 'channelDown': self.next,
             'prevBouquet': self.previous, 'nextBouquet': self.next}, -1)
        self.onLayoutFinish.append(self.prepare)

    def prepare(self):
        if self._finished:
            return
        self._render_focus()

    def _render_focus(self):
        if self._finished:
            return
        x, y, w, h = _FOCUS_GEOMETRY[self.index]
        self['designFocus'].instance.move(ePoint(sx(x), sy(y)))
        self['designFocus'].instance.resize(eSize(sx(w), sy(h)))
        self['designFocus'].instance.setPixmapFromFile(
            os.path.join(_ASSETS, 'focus_compact_%d.png' % self.index))
        self['designFocus'].show()

    def previous(self):
        self.index = (self.index - 1) % 3
        self._render_focus()

    def next(self):
        self.index = (self.index + 1) % 3
        self._render_focus()

    def cancel(self):
        if not self._finished:
            self._finished = True
            self.close(None)

    def accept(self):
        if not self._finished:
            self._finished = True
            self.close(_CHOICES[self.index])
