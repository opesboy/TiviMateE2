# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import ensure_dir
from Plugins.Extensions.TiviMateE2Py27.py27_compat import hex_bytes, monotonic, time_ns
import atexit
import contextlib
import hashlib
import json
# Python 2.7 json raises plain ValueError.
_JSONDecodeError = getattr(json, "JSONDecodeError", ValueError)
import logging
import os
try:
    import sqlite3
    sqlite3.connect(":memory:").close()
except Exception:  # lean images: no sqlite extension
    sqlite3 = None
import threading
import time
from ..core.perf import PERF

DB_PATH = '/etc/enigma2/tivimatee2/ultra_protocol_cache.db'
SCHEMA_VERSION = 5
LOG = logging.getLogger('UltraStalker.Database')


class Database:
    ALLOWED_TABLES = {'favorites', 'history'}
    SQLITE_IN_CHUNK = 400
    HISTORY_MAX_ROWS = 1000
    HISTORY_PRUNE_TRIGGER = 1100

    def __init__(self, path=DB_PATH):
        self.path = path
        self._lock = threading.RLock()
        # Every mutation is serialized with backup-restore commit. Reads can
        # continue and reconnect automatically if the database inode changes.
        self._write_lock = threading.RLock()
        self._ready = False
        self._swapping = False
        self._local = threading.local()
        self._generation = 0
        self._progress_cache = {}
        self._last_checkpoint = 0.0
        self._history_writes_since_prune = 0

    @contextlib.contextmanager
    def write_guard(self):
        """Serialize all SQLite writers with destructive maintenance/restore."""
        with self._write_lock:
            yield

    def _new_connection(self):
        ensure_dir(os.path.dirname(self.path), mode=448)
        db = sqlite3.connect(self.path, timeout=8)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA synchronous=NORMAL')
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA busy_timeout=8000')
        PERF.increment('sqlite.connections')
        return db

    def connect(self):
        """Return one SQLite connection per worker thread.

        If restore replaces the database file, the inode check transparently
        reopens the connection on the next access.
        """
        if self._swapping:
            # A restore is replacing the database files. Wait for it to finish
            # (the restoring thread itself owns the re-entrant lock and passes).
            with self._write_lock:
                pass
        db = getattr(self._local, 'db', None)
        identity = getattr(self._local, 'db_identity', None)
        generation = getattr(self._local, 'db_generation', -1)
        now = monotonic()
        if db is not None and generation != self._generation:
            try: db.close()
            except Exception as exc: LOG.debug('database close after generation change failed: %s', exc)
            db = None
            identity = None
        if db is not None and identity is not None and (now - float(getattr(self._local, "db_stat_mono", 0.0) or 0.0)) < 1.5:
            return db
        try:
            stat = os.stat(self.path)
            current = (stat.st_dev, stat.st_ino)
            self._local.db_stat_mono = now
        except (OSError, IOError):
            current = None
        if db is not None and identity is not None and current is not None and identity != current:
            try: db.close()
            except Exception as exc: LOG.debug('database close after inode change failed: %s', exc)
            db = None
        if db is None:
            db = self._new_connection()
            self._local.db = db
            self._local.db_generation = self._generation
            self._local.db_stat_mono = now
            try:
                stat = os.stat(self.path)
                self._local.db_identity = (stat.st_dev, stat.st_ino)
            except (OSError, IOError):
                self._local.db_identity = None
        return db

    def close(self):
        db = getattr(self._local, 'db', None)
        if db is not None:
            try: db.close()
            except Exception as exc: LOG.debug('database close failed: %s', exc)
        self._local.db = None
        self._local.db_identity = None
        self._local.db_generation = -1

    def close_thread_connection(self):
        """Close only the calling thread's connection; call from worker-thread finally blocks."""
        self.close()

    def bump_generation(self):
        """Make every other thread drop and reopen its connection on next connect()."""
        with self._lock:
            self._generation += 1

    def checkpoint(self, truncate=False):
        try:
            self.initialize()
            with self._write_lock:
                mode="TRUNCATE" if truncate else "PASSIVE"
                self.connect().execute("PRAGMA wal_checkpoint(%s)" % mode).fetchone()
                self._last_checkpoint=monotonic()
            return True
        except Exception as exc:
            LOG.warning('SQLite checkpoint failed: %s', exc)
            return False

    def begin_swap(self):
        """Mark the DB files as being replaced; call while holding write_guard()."""
        self._swapping = True

    def end_swap(self):
        self._swapping = False

    def reset_after_restore(self):
        """Invalidate this thread and schema state after an atomic DB replacement."""
        self.close()
        with self._lock:
            self._generation += 1
            self._ready = False
        self.initialize()

    def __del__(self):
        try: self.close()
        except Exception: pass

    def initialize(self):
        if self._ready:
            return
        # Lock order is ALWAYS _write_lock -> _lock (restore holds _write_lock
        # and then calls into here); the reverse order deadlocked with readers.
        with self._write_lock:
            with self._lock:
                if self._ready:
                    return
                with PERF.timer('sqlite.initialize_ms'):
                    with self.connect() as db:
                        db.executescript('''
CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS favorites(content_key TEXT PRIMARY KEY,portal TEXT NOT NULL,media_type TEXT NOT NULL,payload TEXT NOT NULL,updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS favorite_folders(folder_id TEXT PRIMARY KEY,portal TEXT NOT NULL,mac TEXT NOT NULL,media_type TEXT NOT NULL,name TEXT NOT NULL,sort_order INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_favorite_folders_scope ON favorite_folders(portal,mac,media_type,sort_order);
CREATE TABLE IF NOT EXISTS favorite_folder_items(folder_id TEXT NOT NULL,content_key TEXT NOT NULL,sort_order INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL,PRIMARY KEY(folder_id,content_key),FOREIGN KEY(folder_id) REFERENCES favorite_folders(folder_id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_favorite_folder_items_key ON favorite_folder_items(content_key);
CREATE TABLE IF NOT EXISTS history(content_key TEXT PRIMARY KEY,portal TEXT NOT NULL,media_type TEXT NOT NULL,payload TEXT NOT NULL,position INTEGER NOT NULL DEFAULT 0,duration INTEGER NOT NULL DEFAULT 0,completed INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_history_updated ON history(updated_at DESC);
CREATE TABLE IF NOT EXISTS search_history(term TEXT PRIMARY KEY,normalized TEXT NOT NULL,updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS cache(cache_key TEXT PRIMARY KEY,payload TEXT NOT NULL,expires_at INTEGER NOT NULL,updated_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_cache_expiry ON cache(expires_at);
CREATE TABLE IF NOT EXISTS portal_state(portal_key TEXT PRIMARY KEY,payload TEXT NOT NULL,updated_at INTEGER NOT NULL);
''')
                        previous = 0
                        try:
                            row = db.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()
                            previous = int(row['value']) if row and str(row['value']).isdigit() else 0
                        except (sqlite3.Error, TypeError, ValueError, KeyError) as exc:
                            # A transient read error (locked file, I/O hiccup) must never be
                            # mistaken for a pre-v4 database: that migration wipes every
                            # saved resume position. Skip migrations; the next start retries.
                            LOG.warning('schema version read failed; leaving data untouched: %s', exc)
                            previous = SCHEMA_VERSION
                        if previous < 4:
                            db.execute("UPDATE history SET position=0,duration=0,completed=0 WHERE media_type IN ('vod','series','episode','catchup')")
                            try:
                                legacy = '/etc/enigma2/ultrastalker/resumepoints.pkl'
                                if os.path.exists(legacy): os.unlink(legacy)
                            except (OSError, IOError) as exc:
                                LOG.debug('legacy resumepoint cleanup failed: %s', exc)
                        db.execute('INSERT OR IGNORE INTO schema_migrations(version,applied_at) VALUES(?,?)', (SCHEMA_VERSION, int(time.time())))
                        db.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
                        db.execute('DELETE FROM cache WHERE expires_at < ?', (int(time.time()),))
                try: os.chmod(self.path, 0o600)
                except (OSError, IOError): pass
                self._ready = True
        # One bounded maintenance pass after initialization. This keeps legacy
        # databases from growing forever while staying off the normal UI path.
        try:
            self._prune_history_if_needed(force_check=True)
        except Exception as exc:
            LOG.debug('history maintenance prune failed: %s', exc)

    def list_payloads(self, table, limit=250):
        if table not in self.ALLOWED_TABLES:
            raise ValueError('Unsupported table')
        self.initialize()
        with self.connect() as db:
            # Favorites are a user-curated shelf, not a recency feed. Keep the
            # first item the user added at the left edge and append later saves
            # to its right. rowid is the deterministic tie-breaker when several
            # favorites are added within the same wall-clock second. History
            # remains newest-first.
            order = 'updated_at ASC, rowid ASC' if table == 'favorites' else 'updated_at DESC, rowid DESC'
            rows = db.execute('SELECT payload FROM %s ORDER BY %s LIMIT ?' % (table, order), (max(1, min(int(limit), 1000)),)).fetchall()
        out = []
        for row in rows:
            try: out.append(json.loads(row['payload']))
            except (TypeError, ValueError, _JSONDecodeError) as exc:
                LOG.debug('invalid JSON payload in %s: %s', table, exc)
        return out

    def toggle_favorite(self, key, portal, media_type, payload):
        self.initialize(); now = int(time.time())
        with self._write_lock:
            with self.connect() as db:
                if db.execute('SELECT 1 FROM favorites WHERE content_key=?', (key,)).fetchone():
                    db.execute('DELETE FROM favorite_folder_items WHERE content_key=?', (key,))
                    db.execute('DELETE FROM favorites WHERE content_key=?', (key,)); return False
                db.execute('INSERT INTO favorites(content_key,portal,media_type,payload,updated_at) VALUES(?,?,?,?,?)', (key, portal, media_type, json.dumps(payload, ensure_ascii=False), now)); return True

    def remove_favorite_payload(self, payload):
        """Remove the exact stored favorite payload.

        This is intentionally payload-based for Favorites UI removal.  A saved
        favorite may predate later identity-key refinements, so recomputing its
        content_key can point at a different key even though the visible saved
        entry is the same.  The UI already holds the exact decoded payload read
        from this table, making this the safest surgical delete path.
        """
        if not isinstance(payload, dict):
            return False
        self.initialize()
        with self._write_lock:
            with self.connect() as db:
                rows=db.execute('SELECT content_key,payload FROM favorites').fetchall()
                for row in rows:
                    try:
                        stored=json.loads(row['payload'])
                    except Exception:
                        continue
                    if stored == payload:
                        db.execute('DELETE FROM favorite_folder_items WHERE content_key=?', (row['content_key'],))
                        db.execute('DELETE FROM favorites WHERE content_key=?', (row['content_key'],))
                        return True
        return False

    def reorder_favorites(self, keys):
        """Persist an explicit user order for favorites.

        Favorites are read by ``updated_at ASC``.  Re-stamp only the supplied
        content keys in their requested order, keeping later newly-added
        favorites naturally appended to the right.
        """
        ordered=[];seen=set()
        for key in list(keys or []):
            key=str(key or '')
            if key and key not in seen:
                seen.add(key);ordered.append(key)
        if not ordered:return
        self.initialize()
        base=int(time.time())-len(ordered)-32
        with self._write_lock:
            with self.connect() as db:
                for idx,key in enumerate(ordered):
                    db.execute('UPDATE favorites SET updated_at=? WHERE content_key=?', (base+idx,key))


    def list_favorite_folders(self, portal, mac, media_type):
        self.initialize()
        portal=str(portal or '').rstrip('/').lower();mac=str(mac or '').upper();media_type=str(media_type or '').lower()
        with self.connect() as db:
            rows=db.execute("SELECT folder_id,name,sort_order,updated_at FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=? ORDER BY sort_order ASC, updated_at ASC, rowid ASC",(portal,mac,media_type)).fetchall()
            out=[]
            for row in rows:
                count=db.execute('SELECT COUNT(*) AS c FROM favorite_folder_items WHERE folder_id=?',(row['folder_id'],)).fetchone()
                out.append({'folder_id':row['folder_id'],'name':row['name'],'sort_order':int(row['sort_order'] or 0),'updated_at':int(row['updated_at'] or 0),'count':int((count['c'] if count else 0) or 0)})
            return out

    def create_favorite_folder(self, portal, mac, media_type, name):
        self.initialize();now=int(time.time())
        portal=str(portal or '');mac=str(mac or '');media_type=str(media_type or '').lower();name=str(name or '').strip()
        if not name:return None
        with self._write_lock:
            with self.connect() as db:
                row=db.execute("SELECT folder_id FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=? AND lower(name)=lower(?)",(portal.rstrip('/').lower(),mac.upper(),media_type,name)).fetchone()
                if row:return None
                order_row=db.execute("SELECT COALESCE(MAX(sort_order),-1)+1 AS n FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=?",(portal.rstrip('/').lower(),mac.upper(),media_type)).fetchone()
                order=int((order_row['n'] if order_row else 0) or 0)
                folder_id=hashlib.sha1((portal+'|'+mac+'|'+media_type+'|'+name+'|'+str(time_ns())+'|'+hex_bytes(os.urandom(8))).encode('utf-8','ignore')).hexdigest()[:24]
                db.execute('INSERT INTO favorite_folders(folder_id,portal,mac,media_type,name,sort_order,updated_at) VALUES(?,?,?,?,?,?,?)',(folder_id,portal,mac,media_type,name,order,now))
                return folder_id

    def rename_favorite_folder(self, folder_id, portal, mac, media_type, name):
        self.initialize();name=str(name or '').strip()
        if not name:return False
        portal_norm=str(portal or '').rstrip('/').lower();mac_norm=str(mac or '').upper();media_type=str(media_type or '').lower()
        with self._write_lock:
            with self.connect() as db:
                dup=db.execute("SELECT folder_id FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=? AND lower(name)=lower(?) AND folder_id<>?",(portal_norm,mac_norm,media_type,name,str(folder_id or ''))).fetchone()
                if dup:return False
                cur=db.execute("UPDATE favorite_folders SET name=?,updated_at=? WHERE folder_id=? AND lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=?",(name,int(time.time()),str(folder_id or ''),portal_norm,mac_norm,media_type))
                return bool(cur.rowcount)

    def delete_favorite_folder(self, folder_id, portal, mac, media_type):
        self.initialize();portal_norm=str(portal or '').rstrip('/').lower();mac_norm=str(mac or '').upper();media_type=str(media_type or '').lower()
        with self._write_lock:
            with self.connect() as db:
                cur=db.execute("DELETE FROM favorite_folders WHERE folder_id=? AND lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=?",(str(folder_id or ''),portal_norm,mac_norm,media_type))
                return bool(cur.rowcount)

    def favorite_folder_keys(self, folder_id):
        self.initialize()
        with self.connect() as db:
            rows=db.execute('SELECT content_key FROM favorite_folder_items WHERE folder_id=? ORDER BY sort_order ASC,updated_at ASC,rowid ASC',(str(folder_id or ''),)).fetchall()
            return [str(r['content_key']) for r in rows if str(r['content_key'] or '')]

    def favorite_folder_assign(self, folder_id, portal, mac, media_type, content_key):
        self.initialize();folder_id=str(folder_id or '');content_key=str(content_key or '')
        if not folder_id or not content_key:return False
        portal_norm=str(portal or '').rstrip('/').lower();mac_norm=str(mac or '').upper();media_type=str(media_type or '').lower();now=int(time.time())
        with self._write_lock:
            with self.connect() as db:
                owner=db.execute("SELECT 1 FROM favorite_folders WHERE folder_id=? AND lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=?",(folder_id,portal_norm,mac_norm,media_type)).fetchone()
                if not owner:return False
                db.execute("DELETE FROM favorite_folder_items WHERE content_key=? AND folder_id IN (SELECT folder_id FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=?)",(content_key,portal_norm,mac_norm,media_type))
                order_row=db.execute('SELECT COALESCE(MAX(sort_order),-1)+1 AS n FROM favorite_folder_items WHERE folder_id=?',(folder_id,)).fetchone();order=int((order_row['n'] if order_row else 0) or 0)
                db.execute('INSERT OR REPLACE INTO favorite_folder_items(folder_id,content_key,sort_order,updated_at) VALUES(?,?,?,?)',(folder_id,content_key,order,now))
                return True

    def favorite_folder_remove_key(self, portal, mac, media_type, content_key):
        self.initialize();portal_norm=str(portal or '').rstrip('/').lower();mac_norm=str(mac or '').upper();media_type=str(media_type or '').lower();content_key=str(content_key or '')
        if not content_key:return False
        with self._write_lock:
            with self.connect() as db:
                cur=db.execute("DELETE FROM favorite_folder_items WHERE content_key=? AND folder_id IN (SELECT folder_id FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=? AND media_type=?)",(content_key,portal_norm,mac_norm,media_type))
                return bool(cur.rowcount)

    def favorite_folder_membership(self, portal, mac, media_type):
        self.initialize();portal_norm=str(portal or '').rstrip('/').lower();mac_norm=str(mac or '').upper();media_type=str(media_type or '').lower()
        with self.connect() as db:
            rows=db.execute("SELECT i.content_key,i.folder_id,i.sort_order FROM favorite_folder_items i JOIN favorite_folders f ON f.folder_id=i.folder_id WHERE lower(rtrim(f.portal,'/'))=? AND upper(f.mac)=? AND f.media_type=? ORDER BY i.sort_order ASC,i.updated_at ASC,i.rowid ASC",(portal_norm,mac_norm,media_type)).fetchall()
            return {str(r['content_key']):{'folder_id':str(r['folder_id']),'sort_order':int(r['sort_order'] or 0)} for r in rows}

    def reorder_favorite_folder(self, folder_id, content_keys):
        self.initialize();folder_id=str(folder_id or '')
        ordered=[];seen=set()
        for key in list(content_keys or []):
            key=str(key or '')
            if key and key not in seen:seen.add(key);ordered.append(key)
        if not folder_id or not ordered:return
        with self._write_lock:
            with self.connect() as db:
                now=int(time.time())
                for idx,key in enumerate(ordered):
                    db.execute('UPDATE favorite_folder_items SET sort_order=?,updated_at=? WHERE folder_id=? AND content_key=?',(idx,now,folder_id,key))

    def is_favorite(self, key):
        self.initialize(); PERF.increment('sqlite.favorite_single')
        with self.connect() as db:
            return db.execute('SELECT 1 FROM favorites WHERE content_key=?', (key,)).fetchone() is not None

    def content_states(self, keys):
        self.initialize()
        unique = []; seen = set()
        for key in keys or ():
            key = str(key or '')
            if key and key not in seen:
                seen.add(key); unique.append(key)
        if not unique: return {}
        result = {key: {'favorite': False, 'position': 0, 'duration': 0, 'completed': 0} for key in unique}
        started = monotonic(); query_count = 0
        with self.connect() as db:
            for offset in range(0, len(unique), self.SQLITE_IN_CHUNK):
                chunk = unique[offset:offset+self.SQLITE_IN_CHUNK]
                placeholders = ','.join('?' for _ in chunk)
                for row in db.execute('SELECT content_key FROM favorites WHERE content_key IN (%s)' % placeholders, tuple(chunk)).fetchall():
                    result[row['content_key']]['favorite'] = True
                query_count += 1
                for row in db.execute('SELECT content_key,position,duration,completed FROM history WHERE content_key IN (%s)' % placeholders, tuple(chunk)).fetchall():
                    state = result[row['content_key']]
                    state['position'] = int(row['position'] or 0); state['duration'] = int(row['duration'] or 0); state['completed'] = int(row['completed'] or 0)
                query_count += 1
        PERF.increment('sqlite.bulk_state_queries', query_count)
        PERF.record('sqlite.bulk_state_ms', (monotonic()-started)*1000.0)
        return result

    def _prune_history_if_needed(self, force_check=False):
        """Bound history growth without touching favorites or other content tables.

        Keep the newest HISTORY_MAX_ROWS records. The count query is throttled
        during normal playback so resume saving does not add disk work on every
        progress write. initialize() calls this once for existing legacy growth.
        """
        if not force_check:
            self._history_writes_since_prune += 1
            if self._history_writes_since_prune < 128:
                return 0
        self._history_writes_since_prune = 0
        removed = 0
        with self._write_lock:
            with self.connect() as db:
                row = db.execute('SELECT COUNT(*) AS n FROM history').fetchone()
                count = int(row['n'] or 0) if row else 0
                trigger = self.HISTORY_MAX_ROWS if force_check else self.HISTORY_PRUNE_TRIGGER
                if count <= trigger:
                    return 0
                excess = max(0, count - self.HISTORY_MAX_ROWS)
                if not excess:
                    return 0
                rows = db.execute(
                    'SELECT content_key FROM history ORDER BY updated_at ASC, rowid ASC LIMIT ?',
                    (excess,)
                ).fetchall()
                keys = [str(r['content_key']) for r in rows if r and r['content_key']]
                if keys:
                    db.executemany('DELETE FROM history WHERE content_key=?', [(k,) for k in keys])
                    removed = len(keys)
                    for key in keys:
                        self._progress_cache.pop(key, None)
        if removed:
            LOG.info('History maintenance pruned %d old record(s); retained newest %d', removed, self.HISTORY_MAX_ROWS)
        return removed

    def add_history(self, key, portal, media_type, payload, position=0, duration=0, completed=False, force=False):
        self.initialize(); position=max(0,int(position or 0)); duration=max(0,int(duration or 0)); completed=bool(completed)
        now_mono=monotonic(); now_wall=int(time.time()*1000)
        previous=self._progress_cache.get(str(key))
        if not force and previous and str(media_type or "").lower() not in ("itv","live") and not (position == 0 and duration == 0):
            ppos,pdur,pcompleted,pts=previous
            if abs(position-ppos) < 15*90000 and duration == pdur and completed == pcompleted and (now_mono-pts) < 30.0:
                return False
        packed=json.dumps(payload, ensure_ascii=False)
        sql="INSERT INTO history(content_key,portal,media_type,payload,position,duration,completed,updated_at) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(content_key) DO UPDATE SET payload=excluded.payload,position=excluded.position,duration=excluded.duration,completed=excluded.completed,updated_at=excluded.updated_at"
        with self._write_lock:
            with self.connect() as db:
                db.execute(sql,(key,portal,media_type,packed,position,duration,1 if completed else 0,now_wall))
        self._progress_cache[str(key)]=(position,duration,completed,now_mono)
        if now_mono-self._last_checkpoint > 900.0:
            try:self.connect().execute("PRAGMA wal_checkpoint(PASSIVE)").fetchone();self._last_checkpoint=now_mono
            except sqlite3.Error as exc:LOG.debug('periodic WAL checkpoint failed: %s', exc)
        try:self._prune_history_if_needed(force_check=False)
        except Exception as exc:LOG.debug('history prune check failed: %s', exc)
        return True

    def touch_history(self, key, portal, media_type, payload):
        self.initialize(); now = int(time.time()*1000); packed = json.dumps(payload, ensure_ascii=False)
        with self._write_lock:
            with self.connect() as db:
                row = db.execute('SELECT 1 FROM history WHERE content_key=?', (key,)).fetchone()
                if row: db.execute('UPDATE history SET portal=?,media_type=?,payload=?,updated_at=? WHERE content_key=?', (portal, media_type, packed, now, key))
                else: db.execute('INSERT INTO history(content_key,portal,media_type,payload,position,duration,completed,updated_at) VALUES(?,?,?,?,0,0,0,?)', (key, portal, media_type, packed, now))
        return True

    def progress(self, key):
        self.initialize(); PERF.increment('sqlite.progress_single')
        with self.connect() as db: row = db.execute('SELECT position,duration,completed FROM history WHERE content_key=?', (key,)).fetchone()
        return dict(row) if row else {'position': 0, 'duration': 0, 'completed': 0}

    def list_history(self, limit=500, continue_only=False, include_completed=True):
        self.initialize(); limit = max(1, min(int(limit or 500), 5000)); where = []
        if continue_only: where.extend(('position >= ?', 'completed=0'))
        elif not include_completed: where.append('completed=0')
        sql = 'SELECT content_key,portal,media_type,payload,position,duration,completed,updated_at FROM history'; params = []
        if continue_only: params.append(45*90000)
        if where: sql += ' WHERE ' + ' AND '.join(where)
        sql += ' ORDER BY updated_at DESC, rowid DESC LIMIT ?'; params.append(limit)
        with self.connect() as db: rows = db.execute(sql, tuple(params)).fetchall()
        out = []
        for row in rows:
            try: payload = json.loads(row['payload'])
            except Exception: continue
            if not isinstance(payload, dict): continue
            payload = dict(payload); payload['_content_key'] = row['content_key']; payload['_position'] = int(row['position'] or 0); payload['_duration'] = int(row['duration'] or 0); payload['_completed'] = bool(row['completed']); payload['_updated_at'] = int(row['updated_at'] or 0)
            out.append(payload)
        return out

    def set_history_completed(self, key, completed=True):
        self.initialize()
        with self._write_lock:
            with self.connect() as db:
                if completed: db.execute('UPDATE history SET completed=1,position=CASE WHEN duration>0 THEN duration ELSE position END,updated_at=? WHERE content_key=?', (int(time.time()*1000), key))
                else: db.execute('UPDATE history SET completed=0,position=0,updated_at=? WHERE content_key=?', (int(time.time()*1000), key))

    def remove_history(self, key):
        self.initialize()
        with self._write_lock:
            with self.connect() as db:
                cur=db.execute('DELETE FROM history WHERE content_key=?', (key,))
                changed=bool(cur.rowcount and cur.rowcount > 0)
        self._progress_cache.pop(str(key), None)
        return changed

    def clear_history(self, portal=None, mac=None):
        self.initialize(); removed=0
        with self._write_lock:
            with self.connect() as db:
                if portal and mac:
                    rows = db.execute("SELECT content_key,payload FROM history WHERE lower(rtrim(portal,'/'))=?", (str(portal).rstrip('/').lower(),)).fetchall()
                    for row in rows:
                        try: payload = json.loads(row['payload'])
                        except Exception: continue
                        if str((payload or {}).get('mac') or '').upper() == str(mac).upper():
                            cur=db.execute('DELETE FROM history WHERE content_key=?', (row['content_key'],))
                            if cur.rowcount and cur.rowcount > 0: removed += int(cur.rowcount)
                elif portal:
                    cur=db.execute("DELETE FROM history WHERE lower(rtrim(portal,'/'))=?", (str(portal).rstrip('/').lower(),))
                    removed=max(0,int(cur.rowcount or 0))
                else:
                    cur=db.execute('DELETE FROM history')
                    removed=max(0,int(cur.rowcount or 0))
        if removed:
            self._progress_cache.clear()
        return bool(removed)

    def cache_get_entry(self, key):
        """Return (payload, remaining_ttl_seconds) without extending DB expiry."""
        self.initialize(); now = int(time.time())
        with self.connect() as db:
            row = db.execute('SELECT payload,expires_at FROM cache WHERE cache_key=?', (key,)).fetchone()
        if not row: return None
        expires_at = int(row['expires_at'] or 0)
        if expires_at < now:
            with self._write_lock:
                with self.connect() as db: db.execute('DELETE FROM cache WHERE cache_key=?', (key,))
            return None
        try: value = json.loads(row['payload'])
        except (TypeError, ValueError, _JSONDecodeError) as exc:
            LOG.debug('invalid cache JSON for key %s: %s', str(key)[:96], exc)
            return None
        return value, max(1, expires_at - now)

    def cache_get(self, key):
        entry = self.cache_get_entry(key)
        return entry[0] if entry is not None else None

    def cache_put(self, key, payload, ttl):
        self.initialize(); now = int(time.time())
        try: packed = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
        except (TypeError, ValueError): return
        with self._write_lock:
            with self.connect() as db: db.execute('INSERT OR REPLACE INTO cache VALUES(?,?,?,?)', (key, packed, now+max(1, int(ttl)), now))

    def clear_cache(self):
        self.initialize()
        with self._write_lock:
            with self.connect() as db: db.execute('DELETE FROM cache')

    def state_get(self, key):
        self.initialize()
        with self.connect() as db: row = db.execute('SELECT payload FROM portal_state WHERE portal_key=?', (key,)).fetchone()
        if not row: return {}
        try: return json.loads(row['payload'])
        except (TypeError, ValueError, _JSONDecodeError) as exc:
            LOG.debug('invalid portal_state JSON for key %s: %s', str(key)[:96], exc)
            return {}

    def state_put(self, key, payload):
        self.initialize()
        with self._write_lock:
            with self.connect() as db: db.execute('INSERT OR REPLACE INTO portal_state VALUES(?,?,?)', (key, json.dumps(payload, ensure_ascii=False), int(time.time())))

    def purge_portal(self, profile):
        self.initialize(); portal = str((profile or {}).get('portal') or '').rstrip('/').lower(); mac = str((profile or {}).get('mac') or '').upper(); counts = {'favorites': 0, 'history': 0, 'portal_state': 0}
        if not portal or not mac: return counts
        with self._write_lock:
            with self.connect() as db:
                for table in ('favorites', 'history'):
                    rows = db.execute("SELECT content_key,payload FROM %s WHERE lower(rtrim(portal,'/'))=?" % table, (portal,)).fetchall()
                    for row in rows:
                        try: payload = json.loads(row['payload'])
                        except Exception: continue
                        if str((payload or {}).get('mac') or '').upper() == mac:
                            if table == 'favorites':
                                db.execute('DELETE FROM favorite_folder_items WHERE content_key=?', (row['content_key'],))
                            db.execute('DELETE FROM %s WHERE content_key=?' % table, (row['content_key'],)); counts[table] += 1
                # The portal's custom favorite folders go with it (items cascade), so a
                # re-added source never inherits empty folders from the deleted one.
                db.execute("DELETE FROM favorite_folders WHERE lower(rtrim(portal,'/'))=? AND upper(mac)=?", (portal, mac))
                rows = db.execute('SELECT portal_key,payload FROM portal_state').fetchall()
                for row in rows:
                    try: payload = json.loads(row['payload'])
                    except Exception: continue
                    if str((payload or {}).get('portal') or '').rstrip('/').lower() == portal and str((payload or {}).get('mac') or '').upper() == mac:
                        db.execute('DELETE FROM portal_state WHERE portal_key=?', (row['portal_key'],)); counts['portal_state'] += 1
        return counts

    def health(self):
        try:
            self.initialize()
            with self.connect() as db:
                integrity = db.execute('PRAGMA quick_check').fetchone()[0]
                counts = {t: db.execute('SELECT COUNT(*) FROM '+t).fetchone()[0] for t in ('favorites', 'history', 'cache')}
                migrations = [int(row[0]) for row in db.execute('SELECT version FROM schema_migrations ORDER BY version').fetchall()]
            try: db_bytes = int(os.path.getsize(self.path))
            except (OSError, IOError): db_bytes = 0
            return {'ok': integrity == 'ok', 'integrity': integrity, 'schema_version': SCHEMA_VERSION, 'applied_migrations': migrations, 'counts': counts, 'bytes': db_bytes}
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}


class _MemoryDatabase(object):
    """Stalker protocol store for images without a working sqlite3.

    Only what the portal client needs: the response cache (RAM, bounded,
    expiring) and the small per-portal state (endpoint/transport/compat
    memory) kept in one JSON file next to the configured path. This lets
    the Ultra Stalker engine run on every image, with or without sqlite3.
    """
    CACHE_MAX_ENTRIES = 600

    def __init__(self, path=DB_PATH):
        self.path = path
        self._lock = threading.RLock()
        self._write_lock = threading.RLock()
        self._cache = {}
        self._state = None
        self._ready = True

    def _state_file(self):
        return str(self.path) + '.state.json'

    def _load_state(self):
        if self._state is None:
            data = {}
            try:
                with open(self._state_file(), 'rb') as handle:
                    data = json.loads(handle.read().decode('utf-8'))
                if not isinstance(data, dict):
                    data = {}
            except Exception:
                data = {}
            self._state = data
        return self._state

    def write_guard(self):
        return self._write_lock

    def initialize(self):
        return None

    def close(self):
        return None

    def close_thread_connection(self):
        return None

    def bump_generation(self):
        return None

    def checkpoint(self, truncate=False):
        return None

    def cache_get_entry(self, key):
        now = int(time.time())
        with self._lock:
            row = self._cache.get(key)
            if not row:
                return None
            if row[1] < now:
                self._cache.pop(key, None)
                return None
            return row[0], max(1, row[1] - now)

    def cache_get(self, key):
        entry = self.cache_get_entry(key)
        return entry[0] if entry is not None else None

    def cache_put(self, key, payload, ttl):
        now = int(time.time())
        with self._lock:
            self._cache[key] = (payload, now + max(1, int(ttl)))
            extra = len(self._cache) - self.CACHE_MAX_ENTRIES
            if extra > 0:
                for old in sorted(self._cache, key=lambda k: self._cache[k][1])[:extra]:
                    self._cache.pop(old, None)

    def purge_expired(self):
        now = int(time.time())
        with self._lock:
            for key in [k for k, v in self._cache.items() if v[1] < now]:
                self._cache.pop(key, None)

    def clear_cache(self):
        with self._lock:
            self._cache.clear()

    def state_get(self, key):
        with self._lock:
            value = self._load_state().get(key)
            return value if isinstance(value, dict) else {}

    def state_put(self, key, payload):
        with self._lock:
            state = self._load_state()
            state[key] = payload
            target = self._state_file()
            temp = target + '.tmp'
            try:
                folder = os.path.dirname(target)
                if folder and not os.path.isdir(folder):
                    os.makedirs(folder)
                with open(temp, 'wb') as handle:
                    handle.write(json.dumps(state, ensure_ascii=False).encode('utf-8'))
                os.rename(temp, target)
            except Exception as exc:
                LOG.debug('state file write failed: %s', exc)

    def purge_portal(self, profile):
        self.clear_cache()
        return True

    def health(self):
        return {'ok': True, 'backend': 'memory', 'counts': {'cache': len(self._cache)}}

    def __getattr__(self, name):
        # Favourites/history are handled by TiviMate itself; any other
        # Ultra UI store call becomes a harmless no-op here.
        if name.startswith('__'):
            raise AttributeError(name)
        def _noop(*args, **kwargs):
            return None
        return _noop


if sqlite3 is None:
    DB = _MemoryDatabase()
else:
    DB = Database()
atexit.register(DB.close)
