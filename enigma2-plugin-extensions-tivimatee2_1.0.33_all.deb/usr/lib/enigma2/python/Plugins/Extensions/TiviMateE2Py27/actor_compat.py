# -*- coding: utf-8 -*-
"""Actor metadata adapter for provider rows and TMDb credits (Python 2.7).

Read-only extraction.  No HTTP calls, image queues or cache mutations here.
"""
import re
from .py27_compat import text_type


def actor_rows(*sources, **kwargs):
    limit = max(1, min(int(kwargs.get('limit', 5)), 8))
    found = []
    indexes = {}

    def add(row):
        if isinstance(row, dict):
            name = text_type(row.get('name') or row.get('original_name') or
                             row.get('actor_name') or u'').strip()
            if not name:
                return
            actor = dict(row)
            actor['name'] = name
        else:
            name = text_type(row or u'').strip()
            if not name:
                return
            actor = {'name': name}
        key = u' '.join(name.lower().split())
        if not key:
            return
        if key in indexes:
            old = found[indexes[key]]
            # Prefer existing TMDb identity, fill in missing provider values.
            for field in ('id', 'profile_path', 'character'):
                if not old.get(field) and actor.get(field):
                    old[field] = actor[field]
            return
        if len(found) < limit:
            indexes[key] = len(found)
            found.append(actor)

    def visit(value, depth=0):
        if value is None or depth > 3 or len(found) >= limit:
            return
        if isinstance(value, dict):
            # Credits endpoint or cached TMDb record first.
            credits = value.get('credits')
            if isinstance(credits, dict):
                visit(credits.get('cast'), depth + 1)
            for key in ('cast', 'actors', 'actor'):
                if value.get(key):
                    row = value.get(key)
                    if isinstance(row, dict) and (row.get('name') or row.get('actor_name')):
                        add(row)
                    else:
                        visit(row, depth + 1)
            for key in ('info', 'movie_data'):
                nested = value.get(key)
                if isinstance(nested, dict):
                    visit(nested, depth + 1)
        elif isinstance(value, (tuple, list)):
            for row in value:
                if isinstance(row, dict) and (row.get('name') or row.get('original_name') or row.get('actor_name')):
                    add(row)
                else:
                    visit(row, depth + 1)
        else:
            raw = text_type(value)
            # Xtream and Stalker use comma-delimited names; permit semicolon and
            # whitespace-delimited slash as occasional provider separators.
            for part in re.split(u'[,;\n]|\\s+[/|]\\s+', raw):
                add(part)

    for source in sources:
        visit(source)
        if len(found) >= limit:
            break
    return found
