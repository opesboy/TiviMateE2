# -*- coding: utf-8 -*-
"""Read the exact subtitle cues currently active in VOD/Live on DreamOS.

No second subtitle engine, network search or re-download is started.
Prefer the downloaded SRT file; for ASS/SSA/VTT and other formats use the
already populated SubsSupport engine, which stores times in 90 kHz PTS.
"""
from __future__ import absolute_import, unicode_literals

import os
import sys

try:
    _unicode_type = unicode
except NameError:
    _unicode_type = str


def _text(value):
    if value is None:
        return u""
    if isinstance(value, _unicode_type):
        return value
    if isinstance(value, bytes):
        for encoding in ("utf-8-sig", "utf-8", "cp1256", "latin-1"):
            try:
                return value.decode(encoding)
            except (UnicodeError, LookupError):
                pass
        return value.decode("utf-8", "replace")
    try:
        return _unicode_type(value)
    except (TypeError, ValueError, UnicodeError):
        return u""


def _path(value):
    value = value or ""
    if sys.version_info[0] < 3 and isinstance(value, _unicode_type):
        return value.encode("utf-8")
    return value


def _controllers(owner):
    seen = set()
    for attr in ("_external_subs", "_tivimate_subtitles", "_subssupport", "_tivimate_subtitle_controller"):
        controller = getattr(owner, attr, None)
        if controller is not None and id(controller) not in seen:
            seen.add(id(controller))
            yield controller


def _rows_from_cues(cues):
    normalized = []
    for cue in cues:
        try:
            start_ms, end_ms, caption = cue
            start_ms = max(0, int(float(start_ms)))
            end_ms = max(start_ms + 1, int(float(end_ms)))
            caption = _text(caption)
            if caption.strip():
                normalized.append((start_ms, end_ms, caption))
        except (TypeError, ValueError, UnicodeError):
            continue
    normalized.sort(key=lambda item: (item[0], item[1]))
    display = [dict(index=index, text=cue[2], start=cue[0] / 1000.0,
                    end=cue[1] / 1000.0)
               for index, cue in enumerate(normalized)]
    return normalized, display


def _engine_rows(engine):
    """SubsEngine.subsList uses 90 kHz ticks, unlike the SRT reader's ms."""
    result = []
    for item in (getattr(engine, "subsList", None) or []):
        if not isinstance(item, dict):
            continue
        try:
            start_ms = int(round(float(item.get("start", 0)) / 90.0))
            end_ms = int(round(float(item.get("end", 0)) / 90.0))
            lines = item.get("rows")
            if isinstance(lines, (list, tuple)):
                caption = u"\n".join(_text(line.get("text", u"") if isinstance(line, dict) else line)
                                     for line in lines)
            else:
                caption = _text(item.get("text", u""))
            if caption.strip():
                result.append((start_ms, end_ms, caption))
        except (TypeError, ValueError, UnicodeError):
            continue
    return result


def get_active_subtitle_rows(owner):
    """Return (millisecond cues, editor rows) for the already loaded subtitle."""
    controllers = list(_controllers(owner))
    file_paths = [getattr(owner, "_external_subtitle_path", None)]
    for controller in controllers:
        getter = getattr(controller, "getSubsPath", None)
        if callable(getter):
            try:
                file_paths.append(getter())
            except Exception:
                pass

    # Keep SRT timestamps/text exactly as in the downloaded local file.
    for path in file_paths:
        try:
            candidate = _path(path)
            if not candidate or not os.path.isfile(candidate):
                continue
            if os.path.splitext(candidate)[1].lower() != ".srt":
                continue
            from .srt_overlay import parse_srt_file
            output = _rows_from_cues(parse_srt_file(candidate) or [])
            if output[1]:
                return output
        except Exception as exc:
            print("[TiviMateE2] red subtitle SRT read failed: %s" % exc)

    # SubsSupport exposes neither controller.engine nor engine.getSubtitlesList
    # in its bundled version. Access the *already-active* private engine safely;
    # do not create a new instance and do not change playback state.
    for controller in controllers:
        engine = (getattr(controller, "_TiviMateSubtitleSupport__subsEngine", None) or
                  getattr(controller, "engine", None))
        if engine is None:
            continue
        try:
            output = _rows_from_cues(_engine_rows(engine))
            if output[1]:
                return output
        except Exception as exc:
            print("[TiviMateE2] red subtitle active engine read failed: %s" % exc)
    return [], []
