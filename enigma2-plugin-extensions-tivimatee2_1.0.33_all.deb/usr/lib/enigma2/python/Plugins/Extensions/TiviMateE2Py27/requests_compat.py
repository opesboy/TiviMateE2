# -*- coding: utf-8 -*-
"""Minimal stdlib stand-in for python-requests on Python 2.7 Enigma2 images.

Many images (VTi, older OpenPLi/BlackHole) ship without python-requests, so
the subtitle seekers (SubDL, OpenSubtitles, Subsource, ...) could not even be
imported and movie-player subtitles never worked.

install() registers this module as ``requests`` ONLY when a real requests
package cannot be imported; receivers that have requests keep using it.
Covered API: get/post/head/request, Session (headers, cookies, get/post),
Response (content/text/json/status_code/ok/headers/url/raise_for_status/
iter_content/close), exceptions, codes, compat.urljoin and the
packages.urllib3 warning helpers used by the seekers.
"""
import json as _json
import socket
import ssl
import sys
import types
import zlib

import urllib2
import urllib
import cookielib
from urlparse import urljoin, urlsplit

__version__ = '2.0.0-tivimate-compat'


# --------------------------------------------------------------- exceptions
class RequestException(IOError):
    def __init__(self, *args, **kwargs):
        self.response = kwargs.pop('response', None)
        self.request = kwargs.pop('request', None)
        IOError.__init__(self, *args)


class HTTPError(RequestException):
    pass


class ConnectionError(RequestException):
    pass


class SSLError(ConnectionError):
    pass


class Timeout(RequestException):
    pass


class ConnectTimeout(ConnectionError, Timeout):
    pass


class ReadTimeout(Timeout):
    pass


class TooManyRedirects(RequestException):
    pass


class InvalidURL(RequestException, ValueError):
    pass


class InsecureRequestWarning(Warning):
    pass


exceptions = types.ModuleType('requests.exceptions')
for _cls in (RequestException, HTTPError, ConnectionError, SSLError, Timeout,
             ConnectTimeout, ReadTimeout, TooManyRedirects, InvalidURL):
    setattr(exceptions, _cls.__name__, _cls)
exceptions.InsecureRequestWarning = InsecureRequestWarning

compat = types.ModuleType('requests.compat')
compat.urljoin = urljoin
compat.urlencode = urllib.urlencode
compat.quote = urllib.quote
compat.unquote = urllib.unquote


class _Codes(object):
    ok = 200
    OK = 200
    created = 201
    no_content = 204
    moved = 301
    found = 302
    not_modified = 304
    bad_request = 400
    unauthorized = 401
    forbidden = 403
    not_found = 404
    too_many_requests = 429
    server_error = 500


codes = _Codes()

packages = types.ModuleType('requests.packages')
urllib3 = types.ModuleType('requests.packages.urllib3')
urllib3_exceptions = types.ModuleType('requests.packages.urllib3.exceptions')
urllib3_exceptions.InsecureRequestWarning = InsecureRequestWarning
urllib3.exceptions = urllib3_exceptions
urllib3.disable_warnings = lambda *args, **kwargs: None
packages.urllib3 = urllib3


# --------------------------------------------------------------- structures
class CaseInsensitiveDict(dict):
    def __init__(self, data=None, **kwargs):
        dict.__init__(self)
        self.update(data or {}, **kwargs)

    def __setitem__(self, key, value):
        for existing in list(dict.keys(self)):
            if existing.lower() == str(key).lower() and existing != key:
                dict.__delitem__(self, existing)
        dict.__setitem__(self, key, value)

    def _real(self, key):
        lowered = str(key).lower()
        for existing in dict.keys(self):
            if existing.lower() == lowered:
                return existing
        return None

    def __getitem__(self, key):
        real = self._real(key)
        if real is None:
            raise KeyError(key)
        return dict.__getitem__(self, real)

    def __delitem__(self, key):
        real = self._real(key)
        if real is None:
            raise KeyError(key)
        dict.__delitem__(self, real)

    def __contains__(self, key):
        return self._real(key) is not None

    def get(self, key, default=None):
        real = self._real(key)
        return default if real is None else dict.__getitem__(self, real)

    def pop(self, key, *default):
        real = self._real(key)
        if real is None:
            if default:
                return default[0]
            raise KeyError(key)
        return dict.pop(self, real)

    def update(self, data=None, **kwargs):
        if data:
            items = data.items() if hasattr(data, 'items') else data
            for key, value in items:
                self[key] = value
        for key, value in kwargs.items():
            self[key] = value

    def copy(self):
        return CaseInsensitiveDict(self)


class _CookieView(object):
    """dict-like view over a cookielib jar (get/set/update/items)."""
    def __init__(self, jar):
        self.jar = jar

    def _cookie(self, name, value, domain=''):
        return cookielib.Cookie(0, name, value, None, False, domain, bool(domain),
                                domain.startswith('.'), '/', True, False, None,
                                False, None, None, {})

    def set(self, name, value, domain='', **kwargs):
        self.jar.set_cookie(self._cookie(str(name), str(value), domain or kwargs.get('domain', '')))

    __setitem__ = set

    def update(self, other):
        for key, value in (other.items() if hasattr(other, 'items') else other):
            self.set(key, value)

    def get(self, name, default=None, **kwargs):
        for cookie in self.jar:
            if cookie.name == name:
                return cookie.value
        return default

    def __getitem__(self, name):
        value = self.get(name)
        if value is None:
            raise KeyError(name)
        return value

    def __contains__(self, name):
        return self.get(name) is not None

    def items(self):
        return [(c.name, c.value) for c in self.jar]

    def keys(self):
        return [c.name for c in self.jar]

    def get_dict(self, *args, **kwargs):
        return dict(self.items())

    def clear(self, *args):
        self.jar.clear(*args)

    def __iter__(self):
        return iter(self.jar)

    def __len__(self):
        return len(list(self.jar))


class Response(object):
    def __init__(self):
        self.content = b''
        self.status_code = 0
        self.headers = CaseInsensitiveDict()
        self.url = ''
        self.reason = ''
        self.history = []
        self.encoding = None
        self.cookies = {}
        self.request = None
        self.elapsed = None

    @property
    def ok(self):
        return self.status_code < 400

    @property
    def apparent_encoding(self):
        return 'utf-8'

    @property
    def text(self):
        encodings = []
        if self.encoding:
            encodings.append(self.encoding)
        ctype = str(self.headers.get('content-type') or '')
        if 'charset=' in ctype.lower():
            encodings.append(ctype.lower().split('charset=', 1)[1].split(';')[0].strip(' "\''))
        encodings.extend(('utf-8', 'cp1256', 'latin-1'))
        for encoding in encodings:
            try:
                return self.content.decode(encoding)
            except (UnicodeError, LookupError):
                continue
        return self.content.decode('utf-8', 'replace')

    def json(self, **kwargs):
        return _json.loads(self.text, **kwargs)

    def raise_for_status(self):
        if self.status_code >= 400:
            raise HTTPError('%s Error: %s for url: %s' % (self.status_code, self.reason, self.url),
                            response=self)

    def iter_content(self, chunk_size=8192, decode_unicode=False):
        chunk_size = int(chunk_size or 8192)
        for pos in range(0, len(self.content), chunk_size):
            yield self.content[pos:pos + chunk_size]

    def iter_lines(self, *args, **kwargs):
        for line in self.content.splitlines():
            yield line

    @property
    def raw(self):
        import io
        return io.BytesIO(self.content)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def __bool__(self):
        return self.ok
    __nonzero__ = __bool__


# --------------------------------------------------------------- transport
class _NoRedirect(urllib2.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _context(verify):
    try:
        from Plugins.Extensions.TiviMateE2Py27 import py27_ssl
        if verify is False:
            return py27_ssl.unverified_context()
        if isinstance(verify, basestring) and verify:
            ctx = py27_ssl.new_verified_context()
            if ctx is not None:
                try:
                    ctx.load_verify_locations(cafile=verify)
                except Exception:
                    pass
            return ctx
        return py27_ssl.verified_context()
    except Exception:
        return None


def _encode(value):
    if isinstance(value, unicode):
        return value.encode('utf-8')
    return value if isinstance(value, str) else str(value)


def _encode_params(params):
    if not params:
        return ''
    if isinstance(params, basestring):
        return _encode(params)
    items = params.items() if hasattr(params, 'items') else params
    pairs = []
    for key, value in items:
        if value is None:
            continue
        if isinstance(value, (list, tuple)):
            for item in value:
                pairs.append((_encode(key), _encode(item)))
        else:
            pairs.append((_encode(key), _encode(value)))
    return urllib.urlencode(pairs)


def _decode_body(data, headers):
    encoding = str(headers.get('content-encoding') or '').lower()
    try:
        if encoding == 'gzip':
            return zlib.decompress(data, 16 + zlib.MAX_WBITS)
        if encoding == 'deflate':
            try:
                return zlib.decompress(data)
            except zlib.error:
                return zlib.decompress(data, -zlib.MAX_WBITS)
    except zlib.error:
        pass
    return data


class Session(object):
    def __init__(self):
        self.headers = CaseInsensitiveDict({
            'User-Agent': 'Mozilla/5.0 (Linux; Enigma2) python-requests-compat',
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate',
        })
        self._jar = cookielib.CookieJar()
        self.cookies = _CookieView(self._jar)
        self.verify = True
        self.proxies = {}
        self.auth = None
        self.max_redirects = 30

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False

    def close(self):
        pass

    def mount(self, *args, **kwargs):
        pass

    def request(self, method, url, params=None, data=None, headers=None,
                cookies=None, files=None, auth=None, timeout=None,
                allow_redirects=True, proxies=None, hooks=None, stream=None,
                verify=None, cert=None, json=None):
        method = str(method or 'GET').upper()
        url = _encode(url)
        if not url.lower().startswith(('http://', 'https://')):
            raise InvalidURL('Invalid URL %r' % url)
        query = _encode_params(params)
        if query:
            url = url + ('&' if '?' in url else '?') + query
        merged = CaseInsensitiveDict(self.headers)
        merged.update(headers or {})
        body = None
        if json is not None:
            body = _json.dumps(json)
            if 'content-type' not in merged:
                merged['Content-Type'] = 'application/json'
        elif data is not None:
            if isinstance(data, (dict, list, tuple)):
                body = _encode_params(data)
                if 'content-type' not in merged:
                    merged['Content-Type'] = 'application/x-www-form-urlencoded'
            else:
                body = _encode(data)
        if cookies:
            self.cookies.update(cookies)
        if isinstance(timeout, (tuple, list)):
            timeout = max(float(x or 0) for x in timeout) or None
        timeout = float(timeout) if timeout else 30.0
        verify = self.verify if verify is None else verify

        handlers = [urllib2.HTTPCookieProcessor(self._jar)]
        context = _context(verify)
        if context is not None:
            try:
                handlers.append(urllib2.HTTPSHandler(context=context))
            except TypeError:
                pass
        if not allow_redirects:
            handlers.append(_NoRedirect())
        opener = urllib2.build_opener(*handlers)
        request = urllib2.Request(url, data=body)
        request.get_method = lambda: method
        for key, value in merged.items():
            if value is not None:
                request.add_header(_encode(key), _encode(value))

        response = Response()
        response.request = request
        try:
            raw = opener.open(request, timeout=timeout)
            response.status_code = int(raw.getcode() or 200)
            response.reason = getattr(raw, 'msg', '') or ''
            response.url = raw.geturl()
            info = raw.info()
            payload = raw.read()
            try:
                raw.close()
            except Exception:
                pass
        except urllib2.HTTPError as error:
            response.status_code = int(error.code or 0)
            response.reason = str(getattr(error, 'msg', '') or '')
            response.url = error.geturl() if hasattr(error, 'geturl') else url
            info = error.info()
            try:
                payload = error.read()
            except Exception:
                payload = b''
        except urllib2.URLError as error:
            reason = getattr(error, 'reason', error)
            if isinstance(reason, socket.timeout):
                raise ReadTimeout(str(reason))
            if isinstance(reason, ssl.SSLError):
                raise SSLError(str(reason))
            raise ConnectionError(str(reason))
        except socket.timeout as error:
            raise ReadTimeout(str(error))
        except ssl.SSLError as error:
            if 'timed out' in str(error).lower():
                raise ReadTimeout(str(error))
            raise SSLError(str(error))
        except (socket.error, IOError, OSError) as error:
            raise ConnectionError(str(error))
        headers_out = CaseInsensitiveDict()
        try:
            for line in info.headers:
                if ':' in line:
                    key, value = line.split(':', 1)
                    key, value = key.strip(), value.strip()
                    if key in headers_out:
                        headers_out[key] = headers_out[key] + ', ' + value
                    else:
                        headers_out[key] = value
        except Exception:
            try:
                headers_out.update(dict(info.items()))
            except Exception:
                pass
        response.headers = headers_out
        response.content = _decode_body(payload or b'', headers_out)
        response.cookies = dict(self.cookies.items())
        return response

    def get(self, url, **kwargs):
        kwargs.setdefault('allow_redirects', True)
        return self.request('GET', url, **kwargs)

    def post(self, url, data=None, json=None, **kwargs):
        return self.request('POST', url, data=data, json=json, **kwargs)

    def head(self, url, **kwargs):
        kwargs.setdefault('allow_redirects', False)
        return self.request('HEAD', url, **kwargs)

    def put(self, url, data=None, **kwargs):
        return self.request('PUT', url, data=data, **kwargs)

    def delete(self, url, **kwargs):
        return self.request('DELETE', url, **kwargs)


def session():
    return Session()


def request(method, url, **kwargs):
    return Session().request(method, url, **kwargs)


def get(url, params=None, **kwargs):
    return Session().get(url, params=params, **kwargs)


def post(url, data=None, json=None, **kwargs):
    return Session().post(url, data=data, json=json, **kwargs)


def head(url, **kwargs):
    return Session().head(url, **kwargs)


utils = types.ModuleType('requests.utils')
utils.quote = urllib.quote
utils.unquote = urllib.unquote
utils.urlparse = urlsplit


def install():
    """Register as ``requests`` only when the real package is unavailable."""
    if 'requests' in sys.modules and not getattr(sys.modules['requests'], '_tivimate_compat', False):
        return False
    try:
        import requests as _real  # noqa: F401
        if not getattr(_real, '_tivimate_compat', False):
            return False
    except Exception:
        pass
    module = sys.modules[__name__]
    module._tivimate_compat = True
    sys.modules['requests'] = module
    sys.modules['requests.exceptions'] = exceptions
    sys.modules['requests.compat'] = compat
    sys.modules['requests.utils'] = utils
    sys.modules['requests.packages'] = packages
    sys.modules['requests.packages.urllib3'] = urllib3
    sys.modules['requests.packages.urllib3.exceptions'] = urllib3_exceptions
    return True
