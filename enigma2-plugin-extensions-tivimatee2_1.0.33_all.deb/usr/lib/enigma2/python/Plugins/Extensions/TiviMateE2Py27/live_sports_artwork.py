# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
"""Optional Live football-event / team fanart lookup.

Separate from TMDb (movies / series). Never runs on the Enigma2 GUI thread.
Uses TheSportsDB public API where its free coverage permits. Only returns
actual provider image URLs, never an unrelated movie or fabricated match shot.
"""
import datetime
import json
import os
import re
import threading
import time

try:
    from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlencode
    from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen
except ImportError:  # Python 2 imports are harmless on some older images.
    from urllib import urlencode
    from Plugins.Extensions.TiviMateE2Py27.py27_urlrequest import Request, urlopen

from .storage import data_path

API_BASE = 'https://www.thesportsdb.com/api/v1/json/123/'
CACHE_FILE = data_path('live_sports_artwork.json')
_LOCK = threading.RLock()
_LOOKUP_SEM = threading.BoundedSemaphore(2)
_CACHE_LIFETIME = 60 * 60 * 24 * 7
_NEGATIVE_LIFETIME = 60 * 2
DIAGNOSTICS_FILE = data_path('live_sports_diagnostics.log')

# English and Arabic aliases, specifically club names commonly present in IPTV EPG.
# Matching is bounded for Latin names so e.g. "Real" does not label every show football.
# Stable IDs confirmed by TheSportsDB team pages. Name searches on the free
# API are restricted, so known teams must use lookupteam.php instead.
_TEAM_IDS = {
    'Barcelona': '133739', 'Real Madrid': '133738',
    'Atletico Madrid': '133729', 'Arsenal': '133604',
    'Manchester United': '133612', 'Manchester City': '133613',
    'Liverpool': '133602', 'Tottenham Hotspur': '133616',
    'Bayern Munich': '133664', 'Borussia Dortmund': '133650',
    'Juventus': '133676', 'Paris Saint-Germain': '133714',
    'Porto': '134114', 'Napoli': '133670', 'Valencia': '133725',
}


_TEAM_ALIASES = {
    'Barcelona': ['fc barcelona', 'barcelona', 'barca', 'barça', 'fc barca', 'برشلونة', 'برشلونه', 'برشلونا', 'برشلونه', 'البارسا', 'البرسا'],
    'Real Madrid': ['real madrid', 'r madrid', 'ريال مدريد', 'الريال مدريد', 'ريال مدرير'],
    'Atletico Madrid': ['atletico madrid', 'atlético madrid', 'اتلتيكو مدريد', 'أتلتيكو مدريد'],
    'Arsenal': ['arsenal', 'ارسنال', 'أرسنال'],
    'Manchester United': ['manchester united', 'man utd', 'مانشستر يونايتد'],
    'Manchester City': ['manchester city', 'man city', 'مانشستر سيتي'],
    'Liverpool': ['liverpool', 'ليفربول'],
    'Chelsea': ['chelsea', 'تشيلسي'],
    'Tottenham Hotspur': ['tottenham', 'spurs', 'توتنهام'],
    'Newcastle United': ['newcastle', 'نيوكاسل'],
    'Bayern Munich': ['bayern munich', 'bayern münchen', 'بايرن ميونخ'],
    'Borussia Dortmund': ['borussia dortmund', 'dortmund', 'بوروسيا دورتموند', 'دورتموند'],
    'Paris Saint-Germain': ['paris saint germain', 'paris saint-germain', 'psg', 'باريس سان جيرمان'],
    'Inter Milan': ['inter milan', 'internazionale', 'انتر ميلان', 'إنتر ميلان'],
    'AC Milan': ['ac milan', 'ميلان'],
    'Juventus': ['juventus', 'يوفنتوس'],
    'Napoli': ['napoli', 'نابولي'],
    'Al Hilal': ['al hilal', 'al-hilal', 'الهلال', 'هلال الرياض'],
    'Al Nassr': ['al nassr', 'al-nassr', 'النصر السعودي', 'النصر'],
    'Al Ittihad': ['al ittihad', 'al-ittihad', 'الاتحاد السعودي', 'اتحاد جدة', 'الاتحاد'],
    'Al Ahli Saudi': ['al ahli saudi', 'al-ahli saudi', 'الأهلي السعودي', 'اهلي جدة'],
    'Shabab Al Ahli': ['shabab al ahli', 'شباب الأهلي', 'شباب الاهلي'],
    'Al Ain': ['al ain fc', 'نادي العين', 'العين الاماراتي', 'العين الإماراتي'],
    'Al Wahda': ['al wahda abu dhabi', 'الوحدة الاماراتي', 'الوحدة الإماراتي'],
    'Ajax': ['ajax', 'اياكس', 'أياكس'],
    'Benfica': ['benfica', 'بنفيكا'],
    'Porto': ['fc porto', 'porto', 'بورتو'],
    'Celtic': ['celtic', 'سلتيك'],
}

_MATCH_RE = re.compile(r'\s*(?:\s+vs\.?\s+|\s+versus\s+|\s+v\.?\s+|\s+ضد\s+|\s+مقابل\s+|\s+أمام\s+|\s+امام\s+|\s+يلتقي\s+|\s+[xX]\s+|[×✕])\s*', re.I)
_DASH_RE = re.compile(r'\s+[-–—:]\s+')
_FOOTBALL_WORDS = re.compile(r'football|soccer|كرة\s*القدم|مباراة|مباراه|الدوري|champions\s+league|ucl|كاس|كأس|الدورى', re.I)
_SPORT_CHANNEL = re.compile(r'\b(sport|sports|espn|bein|football|soccer|sky\s+sport|dazn|tnt\s+sport|ssc|abu\s*dhabi\s*sports|alkass)\b|رياض[ةي]|الرياضية|الرياضيه|الكأس|الكاس|الشارقة الرياضية|بي\s*ان|بي\s*إن|اس\s*اس\s*سي', re.I)


def _log_sports(stage, **fields):
    """Short bounded diagnostics to tell absent EPG from API/image failures.

    Never log source URLs, stream credentials, MACs or playlists.
    """
    try:
        safe = {str(k): str(v)[:100].replace('\n', ' ') for k, v in fields.items()}
        record = json.dumps({'at': int(time.time()), 'stage': stage, 'data': safe}, ensure_ascii=False)
        if os.path.isfile(DIAGNOSTICS_FILE) and os.path.getsize(DIAGNOSTICS_FILE) >= 40000:
            atomic_replace(DIAGNOSTICS_FILE, DIAGNOSTICS_FILE + '.old')
        with open(DIAGNOSTICS_FILE, 'a') as handle:
            handle.write(record + '\n')
    except Exception:
        pass


def _normal(value):
    value = str(value or '').lower().strip()
    value = re.sub('[\u064b-\u065f\u0670]', '', value)
    value = re.sub('[أإآٱ]', 'ا', value).replace('ى', 'ي').replace('ة', 'ه')
    value = value.replace('ç', 'c').replace('é', 'e').replace('ü', 'u').replace('á', 'a')
    value = re.sub(u'[^\\w\u0600-ۿ ]+', ' ', value)
    return ' '.join(value.split())


_ALIASES = sorted((( _normal(alias), name) for name, values in _TEAM_ALIASES.items() for alias in values),
                  key=lambda pair: len(pair[0]), reverse=True)


def _canonical(name):
    plain = _normal(name)
    for alias, canonical in _ALIASES:
        if re.search(r'(?<!\w)%s(?!\w)' % re.escape(alias), plain, re.UNICODE):
            return canonical
    return ''


def classify_football(title, channel='', description=''):
    """Identify football teams from the actual EPG title or event description.

    Channel labels alone never imply a particular *match*. A channel with an
    identifiable club in its name may show club artwork, but never match art.
    """
    clean = str(title or '').strip()
    description = str(description or '').strip()[:300]
    if not clean or len(clean) > 180 or _normal(clean) in ('no epg data', 'epg', 'لا توجد بيانات', 'لا يوجد دليل'):
        channel_club = _canonical(str(channel or ''))
        return (channel_club, '') if channel_club else None
    supported_channel = bool(_SPORT_CHANNEL.search(str(channel or '')))
    parts = _MATCH_RE.split(clean, maxsplit=1)
    if len(parts) != 2:
        parts = _DASH_RE.split(clean, maxsplit=1)
    if len(parts) == 2:
        home, away = (_canonical(parts[0]), _canonical(parts[1]))
        if home and away and home != away:
            return (home, away)
        if supported_channel or _FOOTBALL_WORDS.search(clean):
            # Non-catalogue teams can also be searched, but never allow
            # accidental programme descriptions or gigantic query strings.
            raw = [re.sub(r'^(?:live|مباشر|مباراة|مباراه|كاس|كأس|الدوري|football|soccer)\s*[:\-]?\s*', '', x.strip(), flags=re.I).strip() for x in parts]
            if all(3 <= len(x) <= 48 for x in raw) and not any(re.search(r'\b(episode|season|الحلقه)\b', x, re.I) for x in raw):
                return (home or raw[0], away or raw[1])
    only = _canonical(clean)
    if only and (supported_channel or _FOOTBALL_WORDS.search(clean)):
        return (only, '')
    # Many EPG feeds put 'Barcelona vs Real Madrid' in the description while
    # their title contains only 'Football' / 'Live Match'. Only accept it on
    # a sports channel or when the programme itself is clearly football.
    if description and (supported_channel or _FOOTBALL_WORDS.search(clean)):
        parts = _MATCH_RE.split(description, maxsplit=1)
        if len(parts) != 2:
            parts = _DASH_RE.split(description, maxsplit=1)
        if len(parts) == 2:
            first, second = _canonical(parts[0]), _canonical(parts[1])
            if first and second and first != second:
                return (first, second)
        team = _canonical(description)
        if team:
            return (team, '')
    # A sports-channel name may specify its own club (e.g. Barça TV).
    # This is team artwork only, not an invented live fixture.
    if supported_channel:
        channel_club = _canonical(str(channel or ''))
        if channel_club:
            return (channel_club, '')
    return None


def _fetch_json(endpoint, params, fetch=None):
    if fetch is not None:
        return fetch(endpoint, params)
    url = API_BASE + endpoint + '?' + urlencode(params)
    request = Request(url, headers={'User-Agent': 'TiviMateE2/1.0 (+football artwork)', 'Accept': 'application/json'})
    with urlopen(request, timeout=4) as res:
        # Avoid spending resources on an unexpected response.
        raw = res.read(600000)
    result = json.loads(raw.decode('utf-8', 'replace'))
    return result if isinstance(result, dict) else {}


def _safe_image(candidate):
    text = str(candidate or '').strip()
    return text if text.startswith(('https://www.thesportsdb.com/images/', 'https://r2.thesportsdb.com/images/', 'https://www.thesportsdb.com//images/', 'https://www.thesportsdb.com/images/media/')) else ''


def _same_club(expected, returned):
    a = _canonical(expected) or _normal(expected)
    b = _canonical(returned) or _normal(returned)
    return bool(a and b and a == b)


def _recent_event(date_str, now=None):
    try:
        event_date = datetime.datetime.strptime(str(date_str or '')[:10], '%Y-%m-%d').date()
        today = datetime.datetime.utcfromtimestamp(float(now if now is not None else time.time())).date()
        return -5 <= (event_date - today).days <= 7
    except Exception:
        # Never use an undated match thumbnail which may be from another season.
        return False


def _select_event_image(result, home, away, now=None):
    for event in ((result or {}).get('event') or (result or {}).get('events') or []):
        if not isinstance(event, dict):
            continue
        if str(event.get('strSport') or '').lower() not in ('soccer', 'football'):
            continue
        if not (_same_club(home, event.get('strHomeTeam')) and _same_club(away, event.get('strAwayTeam')) or
                _same_club(home, event.get('strAwayTeam')) and _same_club(away, event.get('strHomeTeam'))):
            continue
        if not _recent_event(event.get('dateEvent'), now=now):
            continue
        for field in ('strThumb', 'strFanart', 'strBanner', 'strPoster'):
            image = _safe_image(event.get(field))
            if image:
                return image
    return ''


def _select_team_image(result, requested):
    teams = (result or {}).get('teams') or []
    for team in teams:
        if not isinstance(team, dict):
            continue
        if not _same_club(requested, team.get('strTeam')):
            continue
        sport = str(team.get('strSport') or '').strip().lower()
        if sport and sport not in ('soccer', 'football'):
            continue
        for field in ('strFanart1', 'strFanart2', 'strFanart3', 'strFanart4', 'strTeamBanner', 'strStadiumThumb'):
            url = _safe_image(team.get(field))
            if url:
                return url
    return ''


def _load_index():
    try:
        with open(CACHE_FILE, 'r') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_index(index):
    try:
        folder = __import__('os').path.dirname(CACHE_FILE)
        if folder and not __import__('os').path.isdir(folder):
            __import__('os').makedirs(folder)
        temp = CACHE_FILE + '.tmp'
        with open(temp, 'w') as handle:
            json.dump(index, handle, separators=(',', ':'))
        __import__('os').replace(temp, CACHE_FILE)
    except Exception:
        pass


def resolve_football_art(title, channel='', fetch=None, now=None, description=''):
    """Return (image_url, fixture) for an EPG football match, else ('', None).

    This method is intended for a daemon worker thread and never called while
    rendering. The graphics cache is handled by existing artwork_queue.
    """
    fixture = classify_football(title, channel, description)
    if fixture is None:
        _log_sports('no_fixture')
        return '', None
    cache_key = '|'.join(_normal(x) for x in fixture)
    current = float(now if now is not None else time.time())
    with _LOCK:
        entry = _load_index().get(cache_key) or {}
        if isinstance(entry, dict) and float(entry.get('expires') or 0) > current:
            return _safe_image(entry.get('url')), fixture
    if not _LOOKUP_SEM.acquire(False):
        _log_sports('lookup_busy')
        return '', fixture
    image = ''
    any_successful_response = False
    try:
        home, away = fixture
        # The public key permits lookupteam by ID; unrestricted searchevents
        # and searchteams are NOT available for arbitrary fixtures on the free
        # tier. Search the known club IDs first rather than wasting seconds on
        # an unsupported event query before displaying usable club fanart.
        for club in (home, away):
            if not club:
                continue
            known_id = _TEAM_IDS.get(club)
            if not known_id:
                continue
            try:
                teams = _fetch_json('lookupteam.php', {'id': known_id}, fetch)
                any_successful_response = True
                image = _select_team_image(teams, club)
                if image:
                    break
            except Exception as exc:
                _log_sports('team_api_failed', team=club, error=type(exc).__name__)
        if not image:
            _log_sports('no_team_art', fixture='|'.join(fixture), provider_replied=any_successful_response)
        # Never cache a network failure as "no art"; retry it next time.
        # Cached negative results from successful API responses expire quickly.
        if image or any_successful_response:
            with _LOCK:
                idx = _load_index()
                idx[cache_key] = {'url': image, 'expires': current + (_CACHE_LIFETIME if image else _NEGATIVE_LIFETIME)}
                if len(idx) > 650:
                    idx = dict(sorted(idx.items(), key=lambda item: (item[1] or {}).get('expires', 0), reverse=True)[:500])
                _save_index(idx)
    finally:
        _LOOKUP_SEM.release()
    _log_sports('resolved', fixture='|'.join(fixture), has_image=bool(image))
    return image, fixture
