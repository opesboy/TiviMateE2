# -*- coding: utf-8 -*-
"""TiviMate E2 entry point for Python 2.7 Enigma2 images.

The same package also carries the Python 3 build (Extensions/TiviMateE2).
Each build registers itself only on its own interpreter, so exactly one
"TiviMate E2" entry appears in the plugin list.
"""
import sys

if sys.version_info[0] == 2:
    from Plugins.Extensions.TiviMateE2Py27.plugin_py27 import *  # noqa: F401,F403
    from Plugins.Extensions.TiviMateE2Py27.plugin_py27 import Plugins  # noqa: F401
else:
    def Plugins(**kwargs):
        return []
