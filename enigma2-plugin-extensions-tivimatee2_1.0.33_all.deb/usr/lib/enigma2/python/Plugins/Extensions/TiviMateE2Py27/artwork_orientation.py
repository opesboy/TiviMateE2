# -*- coding: utf-8 -*-
"""Read PNG/JPEG/WebP/GIF dimensions without Pillow or GUI dependencies.

Only the Movie/TV Latest rail uses the portrait policy below; the backdrop
rail keeps its existing wide-image validator. No server/cache keys are changed.
"""

def dimensions(path):
    try:
        with open(path, 'rb') as stream:
            data = stream.read(262144)
        width = height = 0
        if data.startswith(b'\x89PNG\r\n\x1a\n') and len(data) >= 24:
            import struct
            width, height = struct.unpack('>II', data[16:24])
        elif data.startswith(b'\xff\xd8'):
            pos = 2
            while pos + 9 < len(data):
                if data[pos:pos+1] != b'\xff':
                    pos += 1
                    continue
                while pos < len(data) and data[pos:pos+1] == b'\xff':
                    pos += 1
                if pos >= len(data):
                    break
                code = ord(data[pos:pos+1])
                pos += 1
                if code in (0xD8, 0xD9, 0x01) or 0xD0 <= code <= 0xD7:
                    continue
                if pos + 2 > len(data):
                    break
                import struct
                length = struct.unpack('>H', data[pos:pos + 2])[0]
                if length < 2 or pos + length > len(data):
                    break
                if code in (0xC0,0xC1,0xC2,0xC3,0xC5,0xC6,0xC7,0xC9,0xCA,0xCB,0xCD,0xCE,0xCF) and length >= 7:
                    height, width = struct.unpack('>HH', data[pos + 3:pos + 7])
                    break
                pos += length
        elif data[:4] == b'RIFF' and data[8:12] == b'WEBP' and len(data) >= 30:
            import struct
            fmt = data[12:16]
            if fmt == b'VP8X':
                width = 1 + (ord(data[24:25]) | (ord(data[25:26]) << 8) | (ord(data[26:27]) << 16))
                height = 1 + (ord(data[27:28]) | (ord(data[28:29]) << 8) | (ord(data[29:30]) << 16))
            elif fmt == b'VP8 ' and data[23:26] == b'\x9d\x01\x2a':
                width = struct.unpack('<H', data[26:28])[0] & 0x3fff
                height = struct.unpack('<H', data[28:30])[0] & 0x3fff
            elif fmt == b'VP8L' and data[20:21] == b'\x2f':
                bits = struct.unpack('<I', data[21:25])[0]
                width = (bits & 0x3fff) + 1
                height = ((bits >> 14) & 0x3fff) + 1
        elif data[:6] in (b'GIF87a', b'GIF89a') and len(data) >= 10:
            import struct
            width, height = struct.unpack('<HH', data[6:10])
        return width, height
    except Exception:
        return 0, 0


def portrait_file(path):
    width, height = dimensions(path)
    return width >= 64 and height >= 96 and height >= width * 1.10
