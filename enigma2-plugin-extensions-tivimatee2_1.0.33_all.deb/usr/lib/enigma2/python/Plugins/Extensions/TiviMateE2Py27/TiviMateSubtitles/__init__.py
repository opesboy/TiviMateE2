# -*- coding: utf-8 -*-
from __future__ import absolute_import

import gettext
import os

# The bundled Py27 subtitle package requires six.moves.  Prefer system six;
# load the compatible vendored module only on images without it.
try:
    import six
except ImportError:
    import imp
    six = imp.load_source('six', os.path.join(os.path.dirname(__file__), '_vendor_six.py'))

# Python 2.7 images without python-requests or a CA bundle (VTi, ...):
# the subtitle seekers import requests at module level.
try:
    from Plugins.Extensions.TiviMateE2Py27.py27_ssl import install_ca_environment
    install_ca_environment()
except Exception:
    pass
try:
    from Plugins.Extensions.TiviMateE2Py27.requests_compat import install as _install_requests_compat
    _install_requests_compat()
except Exception:
    pass

from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_LANGUAGE

__author__ = "mx3L"
__email__ = "mx3Lmail@gmail.com"
__copyright__ = "Copyright (c) 2014 mx3L"
__license__ = "GPL-v2"
__mod__ = "MNASR"
__mod_email__ = "popking159@gmail.com"
__version__ = "1.3.0"


def localeInit():
    lang = language.getLanguage()
    if lang:
        os.environ["LANGUAGE"] = lang[:2]
    gettext.bindtextdomain("enigma2", resolveFilename(SCOPE_LANGUAGE))
    gettext.textdomain("enigma2")
    gettext.bindtextdomain("TiviMateSubtitles", os.path.join(
        os.path.dirname(__file__), 'locale'))


def _(txt):
    t = gettext.dgettext("TiviMateSubtitles", txt)
    if t == txt:
        t = gettext.gettext(txt)
    return t


localeInit()
language.addCallback(localeInit)

# Import at the bottom to avoid circular import issues with the '_' translation function
from .tivimate_subtitles import TiviMateSubtitleSupport, TiviMateSubtitleSupportStatus, initTiviMateSettings  # noqa: E402
