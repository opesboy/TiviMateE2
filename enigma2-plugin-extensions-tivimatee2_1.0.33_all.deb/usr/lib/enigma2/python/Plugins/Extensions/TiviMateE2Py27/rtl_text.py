# -*- coding: utf-8 -*-
"""Arabic/LTR-aware labels using the receiver's original Enigma2 skin fonts.

Preserve RTL detection, text wrapping, synopsis measurements and scrolling,
without registering a plugin-specific font or changing system fonts.
"""

import unicodedata

from Components.Label import Label
from enigma import gFont, eLabel, ePoint, eSize
from .py27_compat import text_type, gui_text

_warned = set()


def _warn_once(key, message):
    if key not in _warned:
        _warned.add(key)
        print("[TiviMateE2][RTL] %s" % message)


def has_arabic_text(value):
    """Match Arabic text, including presentation forms, not Latin metadata."""
    for char in text_type(value or u""):
        cp = ord(char)
        if ((0x0600 <= cp <= 0x06FF or 0x0750 <= cp <= 0x077F or
             0x08A0 <= cp <= 0x08FF or 0xFB50 <= cp <= 0xFDFF or
             0xFE70 <= cp <= 0xFEFF) and
                unicodedata.bidirectional(char) in ("AL", "R")):
            return True
    return False


def normalize_arabic_synopsis(value):
    """Keep complete Arabic synopsis and let native eLabel wrap by pixel width.

    Never insert a hard newline after N words: word lengths and skin widths
    differ. Collapse provider line breaks, retaining intentional paragraphs.
    English and other non-Arabic descriptions stay entirely untouched.
    """
    raw = text_type(value or u"")
    if not raw or not has_arabic_text(raw):
        return raw
    # Series feeds and older cached metadata may contain manual line breaks.
    # Keep genuine paragraph boundaries while avoiding short ragged lines.
    text = raw.replace("\r\n", "\n").replace("\r", "\n")
    paragraphs = []
    import re
    for part in re.split(r"\n[ \t]*\n+", text):
        cleaned = " ".join(part.split())
        if cleaned:
            paragraphs.append(cleaned)
    return "\n".join(paragraphs)


class DirectionalLabel(Label):
    """Keep Arabic/LTR text aligned while retaining the skin's own font.

    Never modify the global Enigma2 font registry or font replacement setting.
    """

    def __init__(self, text=""):
        self._directional_value = text_type(text or u"")
        self._regular_font = None
        self._skin_halign = "left"
        Label.__init__(self, gui_text(text))

    def _read_skin_attributes(self):
        for key, value in (getattr(self, "skinAttributes", None) or []):
            if key == "font" and self._regular_font is None:
                try:
                    family, size = str(value).rsplit(";", 1)
                    size = int(size)
                    if family and size > 0:
                        self._regular_font = (family, size)
                except (ValueError, TypeError):
                    pass
            elif str(key).lower() in ("halign", "horizontalalignment"):
                self._skin_halign = str(value).strip().lower()

    def _apply_direction(self):
        widget = getattr(self, "instance", None)
        if widget is None:
            return
        arabic = has_arabic_text(self._directional_value)
        if self._regular_font is None:
            self._read_skin_attributes()
        # Arabic headings and metadata read from the right edge; English and
        # Latin titles continue to use the skin's normal LTR alignment.
        # Explicitly centered ratings/chips are intentionally not repositioned.
        if self._skin_halign not in ("center", "centre", "block"):
            try:
                widget.setHAlign(2 if arabic or self._skin_halign == "right" else 0)
            except Exception:
                pass
        if self._regular_font is None:
            return
        family, size = self._regular_font
        face = family
        try:
            widget.setFont(gFont(face, size))
        except Exception as exc:
            _warn_once("native-font", "Could not apply label font: %s" % exc)

    def setText(self, value):
        self._directional_value = text_type(value or u"")
        Label.setText(self, gui_text(value))
        self._apply_direction()

    def _set_text_property(self, value):
        self.setText(value)

    # VariableText.text stores the base setter; override direct property use.
    text = property(Label.getText, _set_text_property)

    def applySkin(self, desktop, parent):
        self._read_skin_attributes()
        applied = Label.applySkin(self, desktop, parent)
        # The skin may have changed the native font in Label.applySkin.
        self._apply_direction()
        return applied

    def postWidgetCreate(self, instance):
        Label.postWidgetCreate(self, instance)
        # On Pure2 and older images native widgets may be created before all
        # attributes exist; applySkin does the final update later.
        self._read_skin_attributes()
        self._apply_direction()

    def onShow(self):
        try:
            Label.onShow(self)
        except Exception:
            pass
        # Reapply after returning to a previous screen, including skin switch.
        self._apply_direction()


def metadata_uses_arabic(value="", tmdb_arabic=None):
    """Center Arabic *content*, even when the menu/UI language is English.

    Many users keep the TiviMate menus English while requesting Arabic TMDb
    metadata. The previous check only used the menu language; consequently
    movie and series pages never centered their Arabic facts row.
    """
    if has_arabic_text(value):
        return True
    try:
        from .i18n import get_language
        if str(get_language() or "").lower().startswith("ar"):
            return True
    except Exception:
        pass
    if tmdb_arabic is None:
        try:
            from .tmdb_client import load_settings
            tmdb_arabic = str(load_settings().get("language") or "").lower().startswith("ar")
        except Exception:
            tmdb_arabic = False
    return bool(tmdb_arabic)


class CenteredArabicMetadataLabel(DirectionalLabel):
    """Center year/genre for Arabic metadata, regardless of the menu language.

    Read the TMDb language setting once per screen/widget, not on every cursor
    movement. An Arabic genre text overrides English app and TMDb settings.
    English-only metadata retains the skin's configured alignment unless the
    user explicitly selects an Arabic metadata language.
    """
    def __init__(self, text=""):
        self._tmdb_arabic_metadata = False
        try:
            from .tmdb_client import load_settings
            self._tmdb_arabic_metadata = str(load_settings().get("language") or "").lower().startswith("ar")
        except Exception:
            pass
        super(CenteredArabicMetadataLabel, self).__init__(text)

    def _apply_direction(self):
        super(CenteredArabicMetadataLabel, self)._apply_direction()
        widget = getattr(self, "instance", None)
        if widget is None:
            return
        try:
            if metadata_uses_arabic(self._directional_value, self._tmdb_arabic_metadata):
                widget.setHAlign(1)  # eLabel.alignCenter
            elif self._skin_halign in ("center", "centre", "block"):
                widget.setHAlign(1)
            else:
                widget.setHAlign(2 if self._skin_halign == "right" else 0)
        except Exception:
            pass

    def onShow(self):
        super(CenteredArabicMetadataLabel, self).onShow()
        self._apply_direction()


class SynopsisLabel(DirectionalLabel):
    """Display Arabic overviews in reading order on OpenATV / Pure2.

    eLabel's RTL automatic *multi-line* layout can render the last visual
    line first.  The UTF-8 text from TMDb is already in correct logical order;
    reversing its words or passing it through a whole-paragraph BiDi transform
    makes that bug worse.  For Arabic only, wrap by the native font's measured
    width and give each successive line its own non-wrapping native eLabel.
    English stays in the original, unmodified native eLabel.  Child widgets
    inherit this label's placement/clipping and do not alter the screen skin.
    """

    _MAX_LINES = 14

    def __init__(self, text=""):
        self._synopsis_lines = []
        self._synopsis_measurer = None
        self._synopsis_layout_key = None
        DirectionalLabel.__init__(self, normalize_arabic_synopsis(text))

    def _remove_native_lines(self):
        for line in self._synopsis_lines:
            try:
                line.hide()
            except Exception:
                pass
        # Keep the reusable instances so fast navigation does not continuously
        # allocate/destroy Enigma2 native widgets.

    def _wrapped_lines(self, raw, font, width):
        """Logical order, measured using the same native font as the display."""
        measurer = self._synopsis_measurer
        if measurer is None:
            return [raw]
        try:
            measurer.setFont(font)
            measurer.resize(eSize(int(max(width * 2, 2048)), 90))
            measurer.setNoWrap(True)
        except Exception:
            return [raw]

        widths = {}

        def measured(text):
            found = widths.get(text)
            if found is not None:
                return found
            try:
                measurer.setText(gui_text(text))
                found = int(measurer.calculateSize().width())
            except Exception:
                # Fallback should err toward shorter lines, never guess that a
                # paragraph fits when the native measurement is unavailable.
                found = len(text) * max(9, self._regular_font[1] // 2)
            widths[text] = found
            return found

        result = []
        for para in raw.split("\n"):
            words = para.split()
            if not words:
                if result and result[-1] != "":
                    result.append("")
                continue
            current = ""
            for word in words:
                candidate = (current + " " + word) if current else word
                if current and measured(candidate) > width:
                    result.append(current)
                    current = word
                else:
                    current = candidate
            if current:
                result.append(current)
        return result

    def _layout_arabic_lines(self):
        native = getattr(self, "instance", None)
        if native is None:
            return
        raw = self._directional_value
        if not raw or not has_arabic_text(raw):
            self._remove_native_lines()
            self._synopsis_layout_key = None
            # Keep English and other non-Arabic synopses entirely native.
            try:
                native.setText(gui_text(raw))
                native.setNoWrap(False)
            except Exception:
                pass
            return
        if self._regular_font is None:
            self._read_skin_attributes()
        if self._regular_font is None:
            return  # try again in applySkin after the font attribute is known
        family, size = self._regular_font
        face = family
        font = gFont(face, size)
        try:
            available_width = int(native.size().width())
            available_height = int(native.size().height())
        except Exception:
            return
        if available_width < 30 or available_height < 15:
            return
        key = (raw, face, size, available_width, available_height)
        if key == self._synopsis_layout_key:
            return
        self._synopsis_layout_key = key
        # The original empty label is still a native widget and a clipping
        # parent, but is not allowed to auto-wrap the Arabic paragraph.
        try:
            native.setText("")
            native.setNoWrap(True)
        except Exception:
            pass
        if self._synopsis_measurer is None:
            try:
                self._synopsis_measurer = eLabel(native)
                self._synopsis_measurer.hide()
            except Exception:
                self._synopsis_layout_key = None
                native.setText(gui_text(raw))
                return
        try:
            self._synopsis_measurer.setFont(font)
            self._synopsis_measurer.setNoWrap(True)
        except Exception:
            pass

        lines = self._wrapped_lines(raw, font, max(30, available_width - 20))
        # Keep text within the original synopsis box.  Use its native font size
        # as a guide rather than the number of words (which varies by script).
        line_height = max(1, int(round(size * 1.21)))
        count = min(self._MAX_LINES, max(1, available_height // line_height))
        visible = lines[:count]
        if len(lines) > count and visible:
            # Clip as the original single widget would do; never change the
            # logical order or move a closing sentence to the first row.
            pass

        # Extract exact foreground shade from the screen skin when possible.
        color = None
        for attr, value in (getattr(self, "skinAttributes", None) or []):
            if attr == "foregroundColor":
                try:
                    from skin import parseColor
                    color = parseColor(value)
                except Exception:
                    pass
                break

        painted = True
        for index, text in enumerate(visible):
            if index >= len(self._synopsis_lines):
                try:
                    self._synopsis_lines.append(eLabel(native))
                except Exception:
                    painted = False
                    break
            line = self._synopsis_lines[index]
            try:
                line.setFont(font)
                line.setTransparent(True)
                try:
                    line.setNoWrap(True)
                except (AttributeError, TypeError):
                    pass
                # Synopsis text only: keep Arabic right-aligned inside its
                # existing box. All other labels (titles, metadata, buttons)
                # retain their original skin alignment via DirectionalLabel.
                # Keep each wrapped line in logical top-to-bottom order.
                line.setHAlign(2)
                if color is not None:
                    line.setForegroundColor(color)
                line.resize(eSize(available_width, line_height))
                line.move(ePoint(0, index * line_height))
                line.setText(gui_text(text))
                line.show()
            except Exception:
                painted = False
                break
        if not painted:
            # An older Enigma2 build might not support native child eLabels.
            # Do not allow that to turn the description into a blank area.
            self._remove_native_lines()
            self._synopsis_layout_key = None
            try:
                native.setNoWrap(False)
                native.setText(gui_text(raw))
            except Exception:
                pass
            return
        for line in self._synopsis_lines[len(visible):]:
            try:
                line.hide()
            except Exception:
                pass

    def setText(self, value):
        DirectionalLabel.setText(self, normalize_arabic_synopsis(value))
        self._synopsis_layout_key = None
        self._layout_arabic_lines()

    def applySkin(self, desktop, parent):
        result = DirectionalLabel.applySkin(self, desktop, parent)
        self._synopsis_layout_key = None
        self._layout_arabic_lines()
        return result

    def postWidgetCreate(self, instance):
        DirectionalLabel.postWidgetCreate(self, instance)
        self._layout_arabic_lines()

    def onShow(self):
        DirectionalLabel.onShow(self)
        self._synopsis_layout_key = None
        self._layout_arabic_lines()

    def preWidgetRemove(self, instance):
        self._remove_native_lines()
        self._synopsis_lines = []
        self._synopsis_measurer = None
        self._synopsis_layout_key = None
        try:
            DirectionalLabel.preWidgetRemove(self, instance)
        except AttributeError:
            pass


class AdaptiveOverviewLabel(SynopsisLabel):
    """Ultra-style film/series overview: fit preferred size to native box.

    Only instantiated in the three dedicated Movies/Series detail screens.
    Native eLabel measures English; Arabic preserves per-line rendering and
    logical top-to-bottom line ordering using the original skin font.
    """

    def __init__(self, text=""):
        self._overview_original_font = None
        self._overview_fitted_key = None
        SynopsisLabel.__init__(self, text)

    def _fit_overview_font(self):
        try:
            from .font_preferences import read_preferences
            mode = read_preferences().get("overview_font_scale", "normal")
            if mode == "normal":
                return
            instance = getattr(self, "instance", None)
            if instance is None:
                return
            self._read_skin_attributes()
            if self._regular_font is None:
                return
            if self._overview_original_font is None:
                self._overview_original_font = self._regular_font
            family, preferred = self._overview_original_font
            width, height = int(instance.size().width()), int(instance.size().height())
            raw = text_type(self._directional_value or u"")
            if width < 80 or height < 40 or not raw:
                return
            key = (raw, width, height, family, preferred)
            if key == self._overview_fitted_key:
                return
            self._overview_fitted_key = key
            is_arabic = has_arabic_text(raw)
            face = family
            chosen = preferred
            for candidate in range(int(preferred), 17, -1):
                try:
                    instance.setFont(gFont(face, candidate))
                    instance.setNoWrap(False)
                    instance.setText(gui_text(raw))
                    measured = int(instance.calculateSize().height())
                    # Some native image versions return a single line for
                    # wrapped text. Use a conservative fallback in that case.
                    if measured <= candidate * 1.4 and len(raw) > 120:
                        char_width = candidate * (0.53 if is_arabic else 0.50)
                        estimated_lines = max(1, int((len(raw) * char_width) / max(50, width - 20)) + 1)
                        measured = max(measured, int(estimated_lines * candidate * 1.20))
                    if measured <= max(20, height - 5):
                        chosen = candidate
                        break
                except Exception:
                    chosen = max(18, min(int(preferred), int(height / 4.5)))
                    break
            self._regular_font = (family, chosen)
            instance.setFont(gFont(face, chosen))
            self._synopsis_layout_key = None
        except Exception:
            # Font preferences must never prevent details from displaying.
            return

    def _layout_arabic_lines(self):
        self._fit_overview_font()
        return SynopsisLabel._layout_arabic_lines(self)


class RisingOverviewLabel(AdaptiveOverviewLabel):
    """Slow, repeating synopsis crawl for Movies and Series details.

    The first two lines stay in view while the user starts reading. Long
    overviews then move at a readable pace, pause at the bottom, and return to
    the beginning. Native eLabel children keep Arabic in its logical line
    order, and all work remains on the Enigma2 GUI timer.
    """

    _SCROLL_TICK_MS = 110
    _SCROLL_START_MS = 2400
    _SCROLL_END_PAUSE_MS = 3500
    _SCROLL_PX_PER_TICK = 1
    _SCROLL_MAX_LINES = 48

    def __init__(self, text=""):
        from enigma import eTimer
        self._rise_timer = eTimer()
        self._rise_timer_connection = None
        try:
            self._rise_timer_connection = self._rise_timer.timeout.connect(self._rise_tick)
        except Exception:
            try:
                self._rise_timer.callback.append(self._rise_tick)
            except Exception:
                try:
                    self._rise_timer.timeout.get().append(self._rise_tick)
                except Exception:
                    pass
        self._rise_lines = []
        self._rise_offset = 0
        self._rise_limit = 0
        self._rise_font = None
        self._rise_line_height = 0
        self._rise_width = 0
        self._rise_visible = 2
        self._rise_color = None
        self._rise_arabic = False
        self._rise_original_height = None
        self._rise_animated_key = None
        self._rise_timer_started = False
        self._rise_at_end = False
        super(RisingOverviewLabel, self).__init__(text)

    def _rise_stop(self):
        try:
            self._rise_timer.stop()
        except Exception:
            pass
        self._rise_timer_started = False
        self._rise_at_end = False

    def _rise_hide_children(self):
        for child in self._synopsis_lines:
            try:
                child.hide()
            except Exception:
                pass

    def _rise_restore_height(self):
        native = getattr(self, 'instance', None)
        if native is not None and self._rise_original_height:
            try:
                native.resize(eSize(int(native.size().width()), self._rise_original_height))
            except Exception:
                pass

    def _layout_arabic_lines(self):
        """Override the regular renderer solely for long, scrolling overviews."""
        native = getattr(self, 'instance', None)
        if native is None:
            return
        # Restore true widget size before fitting or measuring a new synopsis.
        self._rise_restore_height()
        self._fit_overview_font()
        self._read_skin_attributes()
        if self._regular_font is None:
            SynopsisLabel._layout_arabic_lines(self)
            return
        family, font_size = self._regular_font
        raw = normalize_arabic_synopsis(self._directional_value)
        try:
            width = int(native.size().width())
            height = int(native.size().height())
        except Exception:
            SynopsisLabel._layout_arabic_lines(self)
            return
        if self._rise_original_height is None and height >= 35:
            self._rise_original_height = height
        height = self._rise_original_height or height
        if width < 60 or height < 35 or not raw:
            self._rise_stop()
            self._rise_hide_children()
            self._rise_restore_height()
            SynopsisLabel._layout_arabic_lines(self)
            return
        arabic = has_arabic_text(raw)
        face = family
        font = gFont(face, int(font_size))
        if self._synopsis_measurer is None:
            try:
                self._synopsis_measurer = eLabel(native)
                self._synopsis_measurer.hide()
            except Exception:
                SynopsisLabel._layout_arabic_lines(self)
                return
        wrapped = self._wrapped_lines(raw, font, max(40, width - 20))
        # Keep the existing two-line default everywhere except screens which
        # explicitly request a taller scrolling description viewport.
        target_lines = max(2, min(6, int(getattr(self, "_rise_target_lines", 2))))
        if len(wrapped) <= target_lines:
            self._rise_stop()
            self._rise_hide_children()
            self._rise_restore_height()
            SynopsisLabel._layout_arabic_lines(self)
            return
        wrapped = wrapped[:self._SCROLL_MAX_LINES]
        line_h = max(19, int(round(font_size * 1.24)))
        window_h = min(height, target_lines * line_h)
        # Native parent clips the animated child labels. Never move the parent
        # screen widget or allow the synopsis to paint over actor/buttons.
        key = (raw, width, height, face, int(font_size))
        if key == self._rise_animated_key:
            return
        self._rise_stop()
        self._rise_animated_key = key
        self._rise_offset = 0
        self._rise_lines = wrapped
        self._rise_font = font
        self._rise_line_height = line_h
        self._rise_width = width
        self._rise_visible = max(1, min(target_lines, window_h // line_h))
        self._rise_arabic = arabic
        self._rise_limit = max(0, (len(wrapped) - self._rise_visible) * line_h)
        self._rise_color = None
        for name, value in getattr(self, 'skinAttributes', None) or []:
            if name == 'foregroundColor':
                try:
                    from skin import parseColor
                    self._rise_color = parseColor(value)
                except Exception:
                    pass
                break
        try:
            native.resize(eSize(width, window_h))
            native.setNoWrap(True)
            native.setText('')
        except Exception:
            self._rise_stop()
            SynopsisLabel._layout_arabic_lines(self)
            return
        self._rise_paint()
        if self._rise_limit:
            try:
                self._rise_timer.start(self._SCROLL_START_MS, True)
                self._rise_timer_started = True
            except Exception:
                self._rise_timer_started = False

    def _rise_paint(self):
        native = getattr(self, 'instance', None)
        if native is None or not self._rise_lines:
            return
        line_h = self._rise_line_height
        start = self._rise_offset // line_h
        dy = self._rise_offset % line_h
        # Only visible rows plus the entering row are painted. This also
        # prevents overpainting on Enigma2 images that don't clip child eLabels.
        for slot in range(self._rise_visible + 1):
            line_index = start + slot
            if line_index >= len(self._rise_lines):
                # Never leave the third, previously populated child visible
                # on images that do not clip off-screen eLabels correctly.
                if slot < len(self._synopsis_lines):
                    try:
                        self._synopsis_lines[slot].hide()
                    except Exception:
                        pass
                continue
            if slot >= len(self._synopsis_lines):
                try:
                    self._synopsis_lines.append(eLabel(native))
                except Exception:
                    return
            child = self._synopsis_lines[slot]
            try:
                child.setFont(self._rise_font)
                child.setTransparent(True)
                child.setNoWrap(True)
                child.setHAlign(2 if self._rise_arabic else 0)
                if self._rise_color is not None:
                    child.setForegroundColor(self._rise_color)
                child.resize(eSize(self._rise_width, line_h))
                child.move(ePoint(0, slot * line_h - dy))
                child.setText(gui_text(self._rise_lines[line_index]))
                child.show()
            except Exception:
                try:
                    child.hide()
                except Exception:
                    pass
        for child in self._synopsis_lines[self._rise_visible + 1:]:
            try:
                child.hide()
            except Exception:
                pass

    def _rise_tick(self):
        if not self._rise_timer_started or getattr(self, 'instance', None) is None:
            return
        if self._rise_at_end:
            # After the last lines have been readable for a few seconds,
            # restore the original top position and begin another slow pass.
            self._rise_at_end = False
            self._rise_offset = 0
            self._rise_paint()
            delay = self._SCROLL_START_MS
        else:
            self._rise_offset = min(self._rise_limit,
                                    self._rise_offset + self._SCROLL_PX_PER_TICK)
            self._rise_paint()
            if self._rise_offset < self._rise_limit:
                delay = self._SCROLL_TICK_MS
            else:
                self._rise_at_end = True
                delay = self._SCROLL_END_PAUSE_MS
        try:
            self._rise_timer.start(delay, True)
        except Exception:
            self._rise_timer_started = False

    def setText(self, value):
        self._rise_animated_key = None
        self._rise_stop()
        super(RisingOverviewLabel, self).setText(value)

    def onShow(self):
        self._rise_animated_key = None
        super(RisingOverviewLabel, self).onShow()

    def onHide(self):
        # A hidden screen must not keep scrolling in the background; its
        # first visible description restarts at the top on the next show.
        self._rise_stop()
        self._rise_animated_key = None
        try:
            super(RisingOverviewLabel, self).onHide()
        except AttributeError:
            pass

    def preWidgetRemove(self, instance):
        self._rise_stop()
        self._rise_animated_key = None
        super(RisingOverviewLabel, self).preWidgetRemove(instance)
