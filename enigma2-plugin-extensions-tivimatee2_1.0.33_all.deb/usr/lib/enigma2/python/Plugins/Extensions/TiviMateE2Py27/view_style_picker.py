# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
"""Four-style image picker. Native PNG preview plus transparent gold focus."""
import os
import json
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from .display_scale import scale_skin, sx, sy
from enigma import ePoint, eSize

_STYLE_FILE = '/etc/enigma2/tivimatee2/view_style_choices.json'
_CHOICES = ('circle', 'poster', 'genre', 'cinematic')
_BASE = '/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/view_picker'
_BG_FILE = 'view_styles.png'
_FOCUS_RECT = {0: (70, 116, 841, 440), 1: (994, 118, 860, 405), 2: (70, 576, 849, 450), 3: (994, 552, 860, 477)}

def get_style(context, kind):
    try:
        with open(_STYLE_FILE, 'r') as handle:
            values = json.load(handle)
        style = values.get('%s:%s' % (context, kind), 'genre' if context == 'genre' else 'poster')
        return style if style in _CHOICES else 'poster'
    except Exception:
        return 'genre' if context == 'genre' else 'poster'


def save_style(context, kind, style):
    if style not in _CHOICES:
        return False
    try:
        try:
            with open(_STYLE_FILE, 'r') as handle:
                values = json.load(handle)
            if not isinstance(values, dict):
                values = {}
        except Exception:
            values = {}
        values['%s:%s' % (context, kind)] = style
        folder = os.path.dirname(_STYLE_FILE)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        temporary = _STYLE_FILE + '.tmp'
        with open(temporary, 'w') as handle:
            json.dump(values, handle)
        atomic_replace(temporary, _STYLE_FILE)
        return True
    except Exception:
        return False



class PosterViewPicker(Screen):
    # Screenshot already includes the four titles; no duplicated labels or buttons.
    skin = scale_skin('''<screen name="PosterViewPicker" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#050D17">
<ePixmap position="0,0" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/view_picker/view_tile_0.jpg" alphatest="off" scale="1" zPosition="1" />
<ePixmap position="960,0" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/view_picker/view_tile_1.jpg" alphatest="off" scale="1" zPosition="1" />
<ePixmap position="0,540" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/view_picker/view_tile_2.jpg" alphatest="off" scale="1" zPosition="1" />
<ePixmap position="960,540" size="960,540" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2Py27/skins/view_picker/view_tile_3.jpg" alphatest="off" scale="1" zPosition="1" />
<widget name="selectionGold" position="0,0" size="860,480" alphatest="blend" zPosition="2" />
</screen>''' % {'bg': _BG_FILE})

    def __init__(self, session, context='genre', kind='vod'):
        Screen.__init__(self, session)
        self.context=context
        self.kind=kind
        self.index=_CHOICES.index(get_style(context,kind))
        self._closing = False
        self._shown_focus = None
        self['selectionGold']=Pixmap()
        self['actions']=ActionMap(['OkCancelActions','DirectionActions',
            'ChannelSelectBaseActions','InfobarChannelSelection'], {
            'ok':self.accept,'cancel':self.cancel,
            'left':self.left,'right':self.right,'up':self.up,'down':self.down,
            'pageUp':self.previous,'pageDown':self.next,
            'channelUp':self.previous,'channelDown':self.next,
            'prevBouquet':self.previous,'nextBouquet':self.next
        },-1)
        self.onLayoutFinish.append(self.prepare)

    def prepare(self):
        if self._closing:
            return
        # Background PNG is now part of the skin itself. On old DreamOS,
        # runtime setPixmapFromFile() can leave a blank screen while the
        # separate gold-focus overlay remains visible.
        self.refresh()

    def refresh(self):
        if self._closing or self._shown_focus == self.index:
            return
        try:
            # The picker focus is authored in HD and FHD sizes. Load the
            # native file for the actual GUI desktop, not HDMI video mode.
            suffix = ''  # default FHD artwork only
            x, y, w, h = _FOCUS_RECT[self.index]
            self['selectionGold'].instance.move(ePoint(sx(x), sy(y)))
            self['selectionGold'].instance.resize(eSize(sx(w), sy(h)))
            self['selectionGold'].instance.setPixmapFromFile(os.path.join(_BASE, 'gold_focus_%d%s.png' % (self.index, suffix)))
            self['selectionGold'].show()
            self._shown_focus = self.index
        except Exception:
            pass

    def left(self):
        if self.index%2:
            self.index-=1
            self.refresh()
    def right(self):
        if not self.index%2:
            self.index+=1
            self.refresh()
    def up(self):
        if self.index>=2:
            self.index-=2
            self.refresh()
    def down(self):
        if self.index<2:
            self.index+=2
            self.refresh()
    def previous(self):
        self.index = (self.index - 1) % len(_CHOICES)
        self.refresh()

    def next(self):
        self.index = (self.index + 1) % len(_CHOICES)
        self.refresh()

    def cancel(self):
        if self._closing:
            return
        self._closing = True
        self.close(None)

    def accept(self):
        if self._closing:
            return
        self._closing = True
        chosen = _CHOICES[self.index]
        save_style(self.context, self.kind, chosen)
        self.close(chosen)
