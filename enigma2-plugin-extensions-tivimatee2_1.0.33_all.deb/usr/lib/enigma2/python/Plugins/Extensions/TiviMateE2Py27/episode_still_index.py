# -*- coding: utf-8 -*-
from Plugins.Extensions.TiviMateE2Py27.compat import json_dump_text
import io
from Plugins.Extensions.TiviMateE2Py27.py27_compat import atomic_replace
"""Persistent confirmed TMDb episode-still link index (never provider IDs)."""
import hashlib
import json
import os
import threading
from Plugins.Extensions.TiviMateE2Py27.py27_urllib import urlsplit
from .cache_manager import get_cache_dir

_LOCK = threading.RLock()

def _filename(tmdb_id, season, episode):
    vals = [str(v or "").strip() for v in (tmdb_id, season, episode)]
    if not all(v.isdigit() and int(v) >= 0 for v in vals) or int(vals[0]) == 0:
        return None
    key = ":".join(str(int(v)) for v in vals)
    return os.path.join(get_cache_dir("episode_still_index"), hashlib.sha256(key.encode("ascii")).hexdigest() + ".json"), key

def _valid(url):
    if not isinstance(url, (str, unicode)) or len(url) > 1024:
        return False
    try:
        parts = urlsplit(url)
        return (parts.scheme == "https" and parts.hostname == "image.tmdb.org"
                and parts.path.startswith("/t/p/") and not parts.username and not parts.password)
    except Exception:
        return False

def episode_still_index_lookup(tmdb_id, season, episode):
    entry = _filename(tmdb_id, season, episode)
    if not entry:
        return ""
    path, key = entry
    try:
        with _LOCK:
            with io.open(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
        url = payload.get("url") if payload.get("key") == key else ""
        return url if _valid(url) else ""
    except (IOError, OSError, ValueError, TypeError, AttributeError):
        return ""

def episode_still_index_save(tmdb_id, season, episode, url):
    entry = _filename(tmdb_id, season, episode)
    if not entry or not _valid(url):
        return False
    path, key = entry
    tmp = path + ".tmp"
    with _LOCK:
        try:
            with io.open(tmp, "w", encoding="utf-8") as handle:
                json_dump_text({"key": key, "url": url}, handle, separators=(",", ":"))
            atomic_replace(tmp, path)
            return True
        except (IOError, OSError, ValueError, TypeError):
            try:
                os.unlink(tmp)
            except (OSError, IOError):
                pass
            return False
