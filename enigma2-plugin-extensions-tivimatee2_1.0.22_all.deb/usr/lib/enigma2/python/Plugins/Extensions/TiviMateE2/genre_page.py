# -*- coding: utf-8 -*-
"""Standalone GENRE poster browser.

This module deliberately owns its screen, skin, category routing and poster grid.
It does not modify or reuse the original Packages / Movies / TV Shows screen
classes.  A small installer below redirects the existing GENRE selector to this
independent screen after the normal UI module has loaded.
"""

import os
import re
import threading
import time

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from .rtl_text import DirectionalLabel
from Components.Pixmap import Pixmap
from enigma import ePoint, eTimer, ePicLoad

from .artwork_queue import cached_artwork, request_artwork
from .content_home import MovieDetailsScreen
from .poster_manager import provider_poster_url as _server_poster_url, tmdb_poster_url
from .backdrop_manager import provider_backdrop_url as _server_backdrop_url, tmdb_backdrop_url
from .logo_manager import localized_logo_url, tmdb_logo_url
from .core import get_source_client
from .cache_manager import stable_cache_key, persistent_cache_get, persistent_cache_set
from .display_scale import scale_skin, sx, sy, scale_size
from .picload_compat import connect_picture_data
from .favorites import add_favourite, is_favourite
from .filters import filter_categories, filter_items, get_cached_categories, get_category_streams
from .i18n import nav_label, tr
from .tmdb_client import TMDbClient, preferred_metadata_text


PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
POSTER_PLACEHOLDER = os.path.join(PLUGIN_PATH, "skins", "poster", "poster_placeholder.png")
POSTER_SHELL = os.path.join(PLUGIN_PATH, "skins", "genre", "genre_frame_normal.png")
POSTER_FOCUS = os.path.join(PLUGIN_PATH, "skins", "genre", "genre_frame_selected.png")
GENRE_BACKGROUND = os.path.join(PLUGIN_PATH, "skins", "genre", "genre_background.jpg")


# The requested design is a fixed 8 x 3 page: exactly 24 poster slots are
# rendered before navigation goes to a new page.
GRID_COLUMNS = 8
GRID_ROWS = 3
PAGE_SIZE = GRID_COLUMNS * GRID_ROWS
GRID_X = (55, 282, 509, 736, 963, 1190, 1417, 1644)
GRID_Y = (240, 485, 730)
CARD_WIDTH = 170
CARD_HEIGHT = 205
GENRE_BAR_SIZE = 8


# These words keep the common movie/series classifications at the front while
# preserving every provider category as its own independent route.
PREFERRED_GENRES = (
    ("action", ("action", "اكشن", "أكشن")),
    ("comedy", ("comedy", "كوميدي", "كوميديا")),
    ("horror", ("horror", "رعب")),
    ("adventure", ("adventure", "مغامر")),
    ("crime", ("crime", "جريمة")),
    ("drama", ("drama", "دراما")),
    ("sci-fi", ("sci-fi", "sci fi", "science fiction", "خيال علمي")),
    ("thriller", ("thriller", "إثارة", "اثارة")),
)


def _dim_hero_backdrop(path):
    """Render a darkened, full-HD opaque backdrop without a compositor overlay."""
    try:
        from PIL import Image, ImageOps, ImageEnhance
        import hashlib
        out_dir = os.path.join(os.path.dirname(path), "genre_dim")
        if not os.path.isdir(out_dir):
            os.makedirs(out_dir)
        st = os.stat(path)
        key = hashlib.sha1((path + str(st.st_mtime) + str(st.st_size)).encode("utf-8")).hexdigest()
        out = os.path.join(out_dir, key + ".jpg")
        if not os.path.isfile(out):
            with Image.open(path) as im:
                im = ImageOps.fit(im.convert("RGB"), (1920, 1080), method=Image.Resampling.LANCZOS if hasattr(Image, "Resampling") else Image.LANCZOS)
                ImageEnhance.Brightness(im).enhance(0.47).save(out, "JPEG", quality=85)
        return out
    except Exception:
        return path


def _build_genre_skin():
    """Build the independent 1920x1080 skin without changing shared skins."""
    xml = [
        '<screen name="StandaloneGenreScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#05070B">',
        '<eLabel position="0,0" size="1920,1080" backgroundColor="#05070B" zPosition="0" />',
        '<ePixmap position="0,0" size="1920,1080" pixmap="%s" alphatest="off" scale="1" zPosition="1" />' % GENRE_BACKGROUND,
        '<widget name="heroBackdrop" position="0,0" size="1920,1080" alphatest="off" scale="1" zPosition="2" />',
        # Match the movie-details dimming; overlay sits above backdrop, below content.

        '<widget name="heroLogo" position="55,35" size="490,130" alphatest="blend" scale="1" zPosition="4" />',
        # The old image backdrop and the film logo remain untouched.
        # A compact, transparent typography group replaces overlapping multi-line text.
        '<widget name="heroInfo" position="0,0" size="1,1" font="Regular;1" foregroundColor="#FFFFFF" transparent="1" zPosition="3" />',
        '<widget name="heroTitle" position="570,38" size="985,43" font="Regular;32" foregroundColor="#F7F4EC" transparent="1" noWrap="1" zPosition="5" />',
        '<widget name="heroMeta" position="570,84" size="985,30" font="Regular;22" foregroundColor="#E5C478" transparent="1" noWrap="1" zPosition="5" />',
        '<widget name="heroPlot" position="570,123" size="985,88" font="Regular;20" foregroundColor="#E0E8F0" transparent="1" zPosition="5" />',
        '<widget name="heading" position="1600,43" size="255,38" font="Regular;25" foregroundColor="#E6EAF0" transparent="1" halign="right" valign="center" zPosition="5" />',
        '<widget name="subheading" position="1570,91" size="285,56" font="Regular;19" foregroundColor="#A8CDD9" transparent="1" halign="right" valign="center" zPosition="5" />',
        '<widget name="page" position="1610,169" size="245,32" font="Regular;22" foregroundColor="#F0D39B" transparent="1" halign="right" zPosition="5" />',
        '<widget name="status" position="55,952" size="1800,27" font="Regular;18" foregroundColor="#91AEC4" transparent="1" zPosition="5" />',
        '<widget name="selector" position="55,240" size="170,205" pixmap="%s" alphatest="blend" zPosition="10" />' % POSTER_FOCUS,
        '<eLabel position="0,989" size="1920,2" backgroundColor="#203A50" zPosition="2" />',
        '<eLabel position="95,1021" size="16,16" backgroundColor="#CB3D44" zPosition="4" /><widget name="redHint" position="123,1009" size="303,36" font="Regular;20" foregroundColor="#F0F2F4" transparent="1" zPosition="5" />',
        '<eLabel position="545,1021" size="16,16" backgroundColor="#32AD6E" zPosition="4" /><widget name="greenHint" position="573,1009" size="303,36" font="Regular;20" foregroundColor="#F0F2F4" transparent="1" zPosition="5" />',
        '<eLabel position="995,1021" size="16,16" backgroundColor="#D2AE38" zPosition="4" /><widget name="yellowHint" position="1023,1009" size="303,36" font="Regular;20" foregroundColor="#F0F2F4" transparent="1" zPosition="5" />',
        '<eLabel position="1445,1021" size="16,16" backgroundColor="#397FE0" zPosition="4" /><widget name="blueHint" position="1473,1009" size="303,36" font="Regular;20" foregroundColor="#F0F2F4" transparent="1" zPosition="5" />',
        '<widget name="menuHint" position="390,1051" size="1140,24" font="Regular;17" foregroundColor="#A4B8C8" transparent="1" halign="center" zPosition="5" />',
    ]

    # No navigation bar on this standalone GENRE page.

    # Eight genre routes occupy the line under the title. The active route is
    # written with square brackets, so no shared selector graphic is necessary.
    # Genre switching remains on RED/BLUE; hide the genre text row.

    for row, ypos in enumerate(GRID_Y):
        for column, xpos in enumerate(GRID_X):
            slot = row * GRID_COLUMNS + column
            title_y = ypos + 151
            meta_y = ypos + 177
            xml.extend((
                '<widget name="poster%d" position="%d,%d" size="170,205" pixmap="%s" alphatest="blend" scale="1" zPosition="4" />' % (slot, xpos, ypos, POSTER_PLACEHOLDER),
                '<widget name="shell%d" position="%d,%d" size="170,205" pixmap="%s" alphatest="blend" zPosition="5" />' % (slot, xpos, ypos, POSTER_SHELL),
                '<widget name="meta%d" position="%d,%d" size="170,22" font="Regular;14" foregroundColor="#C7D5E0" backgroundColor="#071019D9" transparent="1" halign="center" valign="center" zPosition="7" />' % (slot, xpos, meta_y),
            ))

    xml.append('</screen>')
    return scale_skin("\n".join(xml))


GENRE_POSTER_SKIN = _build_genre_skin()


def _category_name(row):
    if not isinstance(row, dict):
        return ""
    return str(row.get("category_name") or row.get("name") or row.get("title") or row.get("genre") or "").strip()


def _category_id(row):
    if not isinstance(row, dict):
        return ""
    for key in ("category_id", "id", "genre_id", "group", "group-title", "category"):
        value = row.get(key)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _short_text(value, limit):
    text = str(value or "").strip()
    return text if len(text) <= limit else text[:max(1, limit - 1)].rstrip() + "…"

def _genre_provider_metadata(payload):
    """Read detailed provider responses, not only the thin catalogue entry.

    Xtream VOD returns ``info`` plus ``movie_data``; TV returns ``info``.
    M3U/Stalker variants sometimes return flat or nested dictionaries.
    Do not copy artwork fields or alter provider data stored elsewhere.
    """
    if not isinstance(payload, dict):
        return {}
    merged = dict(payload)
    for key in ("movie_data", "series_data", "data", "info"):
        part = payload.get(key)
        if isinstance(part, dict):
            merged.update(part)
    def first(*keys):
        for key in keys:
            value = merged.get(key)
            if value is not None and str(value).strip():
                return str(value).strip()
        return ""
    return {
        "title": first("name", "title", "original_title"),
        "description": first("plot", "description", "overview", "storyline", "plot_outline"),
        "rating": first("rating", "vote_average", "rating_5based"),
        "year": first("year", "releasedate", "releaseDate", "release_date", "first_air_date")[:4],
        "tmdb_id": first("tmdb_id", "tmdb", "tmdbId", "tmdbid"),
    }


def _genre_display_metadata(catalog, provider, tmdb, language):
    """Merge asynchronous metadata without a late provider update hiding TMDb."""
    catalog = catalog if isinstance(catalog, dict) else {}
    provider = provider if isinstance(provider, dict) else {}
    tmdb = tmdb if isinstance(tmdb, dict) else {}
    return {
        "title": preferred_metadata_text(
            tmdb.get("title"), provider.get("title") or catalog.get("title"), language),
        "description": preferred_metadata_text(
            tmdb.get("description"), provider.get("description") or catalog.get("description"), language),
        "year": str(provider.get("year") or tmdb.get("year") or catalog.get("year") or "")[:4],
        "rating": str(provider.get("rating") or tmdb.get("rating") or catalog.get("rating") or ""),
        "category": str(catalog.get("category") or ""),
    }



def _genre_sort_key(row):
    name = _category_name(row).casefold()
    for position, _entry in enumerate(PREFERRED_GENRES):
        aliases = _entry[1]
        if any(alias.casefold() in name for alias in aliases):
            return (0, position, name)
    return (1, 999, name)


def _content_identity(item, kind):
    row = item or {}
    for key in ("tmdb_id", "tmdb", "tmdbId"):
        value = str(row.get(key) or "").strip()
        if value and value not in ("0", "none", "None"):
            return "tmdb:%s:%s" % (kind, value)
    for key in ("stream_id", "series_id", "vod_id", "id"):
        value = str(row.get(key) or "").strip()
        if value:
            return "id:%s:%s" % (kind, value)
    title = str(row.get("name") or row.get("title") or "").casefold().strip()
    year = str(row.get("year") or row.get("release_date") or row.get("first_air_date") or "").strip()[:4]
    return "title:%s:%s:%s" % (kind, title, year)


def _newest_key(item):
    """Copied date precedence from the current GENRE route: provider added first."""
    row = item if isinstance(item, dict) else {}

    def stamp(value):
        if value in (None, ""):
            return 0
        try:
            number = int(float(value))
            if number > 100000000000:
                number //= 1000
            if number > 100000000:
                return number
        except Exception:
            pass
        text = str(value).strip().replace("Z", "").replace("T", " ")
        for fmt, length in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%d", 10), ("%Y/%m/%d %H:%M:%S", 19), ("%Y/%m/%d", 10)):
            try:
                return int(time.mktime(time.strptime(text[:length], fmt)))
            except Exception:
                pass
        return 0

    for key in ("added", "added_timestamp", "added_at", "date_added", "created_at", "timestamp"):
        value = stamp(row.get(key))
        if value:
            return (3, value)
    for key in ("release_date", "releaseDate", "releasedate", "release_date_utc", "first_air_date"):
        value = stamp(row.get(key))
        if value:
            return (2, value)
    try:
        year = int(str(row.get("year") or "")[:4])
        if 1800 <= year <= 2200:
            return (1, year)
    except Exception:
        pass
    return (0, 0)


class StandaloneGenreScreen(Screen):
    """Independent 24-poster GENRE screen for Movies and TV Shows."""

    skin = GENRE_POSTER_SKIN
    TOP = ("Home", "Search", "Live", "Movies", "TV Shows", "Packages", "GENRE", "Resume", "Server Finder", "Settings")

    def __init__(self, session, source, initial_kind="vod", initial_category_id=""):
        Screen.__init__(self, session)
        self.source = dict(source or {})
        self.kind = "series" if str(initial_kind) == "series" else "vod"
        # Resolve settings once rather than reading TMDb settings at each arrow press.
        self._hero_language = str(TMDbClient().language or "en-US")
        self.initial_category_id = str(initial_category_id or "")
        self.categories = []
        self.genre_links = {"vod": {}, "series": {}}
        self.category_index = 0
        self.genre_items = []
        self.index = 0
        self.page_start = 0
        self._generation = 0
        self._poster_tokens = {}
        self._poster_decoders = {}
        self._rendered_page_key = None
        self._closed = False
        self._series_details_class = None
        self._hero_token = None
        self._hero_timer = eTimer()
        self._hero_timer.callback.append(self._load_hero)
        self._hero_last_index = None
        self._hero_cache = {}
        self._hero_text_token = None
        self._hero_text_sources = {}

        for index, label in enumerate(self.TOP):
            self["nav%d" % index] = Label(nav_label(label))
        for index in range(GENRE_BAR_SIZE):
            self["genre%d" % index] = Label("")
        for index in range(PAGE_SIZE):
            self["poster%d" % index] = Pixmap()
            self["shell%d" % index] = Pixmap()
            self["title%d" % index] = Label("")
            self["meta%d" % index] = Label("")
        self["heroBackdrop"] = Pixmap()
        self["heroLogo"] = Pixmap()
        self["heroInfo"] = Label("")
        self["heroTitle"] = DirectionalLabel("")
        self["heroMeta"] = DirectionalLabel("")
        self["heroPlot"] = DirectionalLabel("")
        self["heading"] = Label("")
        self["subheading"] = Label("")
        self["page"] = Label("")
        self["status"] = Label("")
        self["selector"] = Pixmap()
        self["redHint"] = Label("PREVIOUS GENRE")
        self["greenHint"] = Label("TV SHOWS")
        self["yellowHint"] = Label("MOVIES")
        self["blueHint"] = Label("NEXT GENRE")
        self["menuHint"] = Label("MENU  Add / remove favorite    EXIT  Back")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions", "MenuActions", "InfoActions"],
            {
                "ok": self.open_selected,
                "info": self.open_selected,
                "cancel": self.close,
                "left": self.left,
                "right": self.right,
                "up": self.up,
                "down": self.down,
                "pageUp": self.page_up,
                "pageDown": self.page_down,
                "red": self.previous_genre,
                "green": self.show_series,
                "yellow": self.show_movies,
                "yellowlong": self.toggle_favorite,
                "blue": self.next_genre,
                "menu": self.toggle_favorite,
            },
            -1,
        )
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._mark_closed)

    def _mark_closed(self):
        self._closed = True
        self._generation += 1
        self._poster_tokens = {}
        self._rendered_page_key = None
        # Enigma2 can dispose Screen attributes before a queued ePicLoad
        # PictureData callback fires. Never assume the decoder map survives.
        decoders = getattr(self, "_poster_decoders", None)
        if decoders is not None:
            decoders.clear()
        try:
            self._hero_timer.stop()
        except Exception:
            pass

    def _schedule_hero(self):
        key = (self._generation, self.index, self.kind)
        if key == self._hero_token:
            return
        self._hero_token = key
        # Keep existing artwork visible while navigating; reuse already resolved
        # paths without network or image processing on the GUI thread.
        entry = self._hero_cache.get(key)
        if entry:
            for widget, path in entry.get("images", {}).items():
                if path and os.path.isfile(path):
                    try:
                        self[widget].instance.setPixmapFromFile(path)
                        self[widget].show()
                    except Exception:
                        pass
            if entry.get("complete"):
                return
        try:
            self._hero_timer.stop()
            self._hero_timer.start(650, True)
        except Exception:
            pass

    def _load_provider_hero_info(self, item, token, kind):
        """Enrich selected GENRE text from provider info without blocking arrows."""
        source = dict(self.source or {})
        source_type = str(source.get("type") or "xtream").lower()
        if source_type not in ("xtream", "stalker"):
            return
        item_id = str(item.get("series_id") or item.get("stream_id") or item.get("id") or "").strip()
        if not item_id:
            return
        def worker():
            try:
                cache_key = stable_cache_key(
                    "genre_provider_details_v1", source.get("type"),
                    source.get("url") or source.get("base_url") or source.get("host"),
                    source.get("username") or source.get("user"),
                    source.get("password"), kind, item_id)
                metadata = persistent_cache_get(cache_key)
                if not isinstance(metadata, dict):
                    client = get_source_client(source)
                    payload = (client.series_info(item_id) if kind == "series"
                               else client.vod_info(item_id)) or {}
                    metadata = _genre_provider_metadata(payload)
                    # Cache only compact textual metadata, never seasons/episodes
                    # or full VOD responses that can be many megabytes.
                    persistent_cache_set(cache_key, "genre_provider_details",
                                         metadata, 6 * 60 * 60 if any(metadata.values()) else 5 * 60)
                if self._closed or token != self._hero_token:
                    return
                if any(metadata.get(key) for key in ("title", "description", "rating", "year")):
                    self._post_to_gui(self._update_hero_info, token, metadata, "provider")
                # A provider TMDb id can identify a film whose IPTV title has
                # prefixes/suffixes, where title search fails. Prefer that id.
                tmdb_id = metadata.get("tmdb_id")
                if tmdb_id and not self._closed and token == self._hero_token:
                    tmdb = TMDbClient()
                    details = tmdb.details_bundle(tmdb_id, kind) or {}
                    if details and not self._closed and token == self._hero_token:
                        self._post_to_gui(self._update_hero_info, token, {
                            "title": details.get("title") or details.get("name") or "",
                            "description": details.get("overview") or "",
                            "year": str(details.get("release_date") or details.get("first_air_date") or "")[:4],
                            "rating": str(details.get("vote_average") or ""),
                        }, "tmdb_verified")
            except Exception:
                # Retain the instant catalog fallback on a broken/unavailable provider.
                return
        thread = threading.Thread(target=worker, name="TiviMateGenreProviderInfo")
        thread.daemon = True
        thread.start()

    def _load_hero(self):
        item = self._selected_item()
        token = self._hero_token
        if not item or self._closed:
            return
        item = dict(item)
        title = str(item.get("name") or item.get("title") or "").strip()
        kind = self.kind
        year = str(item.get("year") or "")[:4]
        # Listing rows can omit the synopsis entirely, even though it is present
        # in get_vod_info/get_series_info (as seen in Movie/Series Details).
        # Resolve the detailed server record independently from TMDb artwork.
        self._load_provider_hero_info(item, token, kind)
        def worker():
            try:
                if self._closed or token != self._hero_token:
                    return
                client = TMDbClient()
                # Do not require a backdrop to identify a movie: a matching
                # TMDb row can have real metadata without any image at all.
                catalog_id = item.get("tmdb_id") or item.get("tmdb") or item.get("tmdbId")
                found = (client.details_bundle(catalog_id, kind) if catalog_id else
                         client.search_artwork(title, kind, year or None)) or {}
                backdrop = _server_backdrop_url(self.source, item) or found.get("backdrop_path")
                media_id = catalog_id or found.get("id")
                server_description = str(item.get("plot") or item.get("description") or item.get("overview") or item.get("storyline") or item.get("plot_outline") or "").strip()
                server_rating = str(item.get("rating") or item.get("vote_average") or "").strip()
                # The quick server metadata stays visible while localized TMDb
                # metadata is resolved asynchronously below.
                description = preferred_metadata_text(found.get("overview"), server_description, client.language)
                rating = server_rating or str(found.get("vote_average") or "").strip()
                release = str(item.get("year") or item.get("release_date") or found.get("release_date") or found.get("first_air_date") or "")[:4]
                info = {
                    "title": title,
                    "year": release,
                    "rating": rating,
                    "description": description,
                    "category": str(item.get("category_name") or "").strip(),
                }
                if not self._closed and token == self._hero_token:
                    try:
                        from twisted.internet import reactor
                        reactor.callFromThread(self._update_hero_info, token, info, "tmdb_search")
                    except Exception:
                        pass
                selected_lang = str(client.language or "en-US").lower()
                if media_id:
                    # Load full TMDb metadata for every selected language; the
                    # search index and poster rows often omit overview text.
                    def localize(selected_id=media_id, expected=token, base=dict(info)):
                        try:
                            if not selected_id or self._closed or expected != self._hero_token:
                                return
                            localized = client.details_bundle(selected_id, kind) or {}
                            if self._closed or expected != self._hero_token:
                                return
                            localized_title = localized.get("title") if kind == "vod" else localized.get("name")
                            localized_overview = localized.get("overview")
                            # Arabic requires actual Arabic script, because
                            # TMDb sometimes replies with original English.
                            if selected_lang.startswith("ar"):
                                def valid(value):
                                    return any("\u0600" <= c <= "\u06ff" for c in str(value or ""))
                            else:
                                # For French/Turkish, rely on TMDb's requested
                                # locale. Both legitimately use Latin letters.
                                def valid(value):
                                    return bool(str(value or "").strip())
                            merged = {
                                "title": localized_title if valid(localized_title) else base.get("title", ""),
                                "description": localized_overview if valid(localized_overview) else base.get("description", ""),
                                "year": str(localized.get("release_date") or localized.get("first_air_date") or base.get("year") or "")[:4],
                                "rating": str(localized.get("vote_average") or base.get("rating") or ""),
                            }
                            self._post_to_gui(self._update_hero_info, expected, merged, "tmdb")
                        except Exception:
                            pass
                    threading.Thread(target=localize, name="TiviMateGenreLocalizedMetadata", daemon=True).start()
                # Respect TMDb Settings, rather than forcing English/provider logos.
                # This worker-only images lookup never blocks the Enigma UI.
                provider_logo = str(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "").strip()
                tmdb_id = media_id or item.get("tmdb_id") or item.get("tmdb")
                logo = localized_logo_url(client, "tv" if kind == "series" else "movie", tmdb_id, size="original") if tmdb_id else ""
                logo = logo or provider_logo
                for url, category, widget in ((backdrop, "backdrops", "heroBackdrop"), (logo, "logos", "heroLogo")):
                    url = (tmdb_backdrop_url(url) if widget == "heroBackdrop" else tmdb_logo_url(url))
                    if not url or self._closed or token != self._hero_token:
                        continue
                    def ready(path, expected=token, name=widget):
                        if self._closed or not path or not os.path.exists(path):
                            return
                        # Dim on the background thread, never on the GUI thread.
                        def prepare():
                            try:
                                prepared = _dim_hero_backdrop(path) if name == "heroBackdrop" else path
                                entry = self._hero_cache.setdefault(expected, {"images": {}})
                                entry["images"][name] = prepared
                                if expected == self._hero_token and not self._closed:
                                    from twisted.internet import reactor
                                    reactor.callFromThread(self._show_hero_image, expected, name, prepared)
                            except Exception:
                                pass
                        threading.Thread(target=prepare, name="TiviMateGenreArtwork").start()
                    cached = cached_artwork(url, category)
                    if cached:
                        ready(cached)
                    else:
                        request_artwork(url, category, ready, priority=115)
            except Exception:
                pass
        threading.Thread(target=worker, name="TiviMateGenreHero").start()

    def _show_hero_image(self, token, name, path):
        if self._closed or token != self._hero_token or not os.path.isfile(path):
            return
        try:
            self[name].instance.setPixmapFromFile(path)
            self[name].show()
        except Exception:
            pass

    def _update_hero_info(self, token, info, origin="tmdb"):
        if self._closed or token != self._hero_token:
            return
        try:
            if not isinstance(info, dict):
                self["heroInfo"].setText(str(info or ""))
                return
            if self._hero_text_token != token:
                self._hero_text_token = token
                self._hero_text_sources = {}
            self._hero_text_sources[origin] = dict(info)
            source = self._hero_text_sources
            # Provider full-info may arrive after localized TMDb; recomputing from
            # separated sources stops an English provider response replacing Arabic.
            tmdb_info = (source.get("tmdb_verified") or source.get("tmdb")
                         or source.get("tmdb_search") or {})
            client_lang = self._hero_language
            self._set_hero_text(_genre_display_metadata(
                source.get("catalog"), source.get("provider"), tmdb_info, client_lang))
        except Exception:
            pass

    def _set_hero_text(self, info):
        """Update top information labels only; do not repaint any artwork."""
        title = str(info.get("title") or "").strip()
        year = str(info.get("year") or "").strip()[:4]
        rating = str(info.get("rating") or "").strip()
        description = str(info.get("description") or "").strip()
        category = str(info.get("category") or "").strip()
        parts = [part for part in (year, ("★ " + rating[:4]) if rating else "", category) if part]
        self["heroTitle"].setText(_short_text(title, 65))
        self["heroMeta"].setText("   •   ".join(parts))
        self["heroPlot"].setText(description[:210])

    def start(self):
        self._generation += 1
        self.genre_items = []
        self.index = 0
        self.page_start = 0
        self._poster_tokens = {}
        self._rendered_page_key = None
        self._render_nav()
        self._render_empty("Loading %s genres…" % ("TV Shows" if self.kind == "series" else "Movies"))
        self._load_categories(self._generation)

    def _render_nav(self):
        for index, label in enumerate(self.TOP):
            value = nav_label(label)
            if label == "GENRE":
                value = "[ %s ]" % value
            self["nav%d" % index].setText(value)

    def _load_categories(self, generation):
        source = dict(self.source)
        kind = self.kind

        def worker():
            try:
                client = get_source_client(source)
                cached, _origin = get_cached_categories(source, kind, client=client, wait_for_server=False)
                rows = self._normalise_categories(cached)
                if rows:
                    self._apply_categories(rows, generation, False)
                fresh, _origin = get_cached_categories(source, kind, client=client, wait_for_server=True)
                fresh_rows = self._normalise_categories(fresh)
                if fresh_rows:
                    self._apply_categories(fresh_rows, generation, True)
                elif not rows:
                    self._apply_categories([], generation, True)
            except Exception:
                self._apply_categories([], generation, True)

        thread = threading.Thread(target=worker, name="TiviMateStandaloneGenreCategories")
        thread.daemon = True
        thread.start()

    def _normalise_categories(self, rows):
        try:
            rows = filter_categories(self.source, self.kind, rows or [])
        except Exception:
            rows = list(rows or [])
        result = []
        seen = set()
        for row in rows:
            if isinstance(row, (tuple, list)) and len(row) >= 2:
                row = {"category_name": row[0], "category_id": row[1]}
            if not isinstance(row, dict):
                continue
            category_id = _category_id(row)
            name = _category_name(row)
            if not category_id or not name or category_id in seen:
                continue
            seen.add(category_id)
            result.append({"id": category_id, "name": name})
        result.sort(key=lambda item: _genre_sort_key({"category_name": item["name"]}))
        return result

    def _apply_categories(self, rows, generation, from_server):
        if self._closed or generation != self._generation:
            return
        previous_id = ""
        try:
            if self.categories:
                previous_id = str(self.categories[self.category_index].get("id") or "")
        except Exception:
            pass
        self.categories = list(rows or [])
        self.genre_links[self.kind] = dict((row["name"], {"kind": self.kind, "category_id": row["id"]}) for row in self.categories)
        if not self.categories:
            self._render_empty(tr("No categories available."))
            return
        selected = self.initial_category_id or previous_id
        self.initial_category_id = ""
        if selected:
            for index, row in enumerate(self.categories):
                if str(row.get("id")) == selected:
                    self.category_index = index
                    break
            else:
                self.category_index = min(self.category_index, len(self.categories) - 1)
        else:
            self.category_index = min(self.category_index, len(self.categories) - 1)
        self._render_genre_bar()
        self._load_selected_genre(generation)

    def _render_genre_bar(self):
        if not self.categories:
            for slot in range(GENRE_BAR_SIZE):
                self["genre%d" % slot].setText("")
            return
        start = (self.category_index // GENRE_BAR_SIZE) * GENRE_BAR_SIZE
        for slot in range(GENRE_BAR_SIZE):
            position = start + slot
            if position >= len(self.categories):
                self["genre%d" % slot].setText("")
                continue
            name = _short_text(self.categories[position].get("name"), 19)
            self["genre%d" % slot].setText(("[ %s ]" % name) if position == self.category_index else name)

    def _load_selected_genre(self, generation):
        if not self.categories:
            return
        category = dict(self.categories[self.category_index])
        source = dict(self.source)
        kind = self.kind
        self.genre_items = []
        self.index = 0
        self.page_start = 0
        self._poster_tokens = {}
        self._rendered_page_key = None
        self._render_empty("Loading %s…" % category.get("name", "GENRE"))

        def worker():
            items = []
            try:
                client = get_source_client(source)
                items, _origin = get_category_streams(source, kind, client, category["id"], use_cache=True, wait_for_server=False)
                if not items:
                    items, _origin = get_category_streams(source, kind, client, category["id"], use_cache=True, wait_for_server=True)
            except Exception:
                items = []
            rows = []
            seen = set()
            for item in list(items or []):
                if not isinstance(item, dict):
                    continue
                row = dict(item)
                row.setdefault("category_id", category["id"])
                row.setdefault("category_name", category["name"])
                row["_source_category_id"] = category["id"]
                key = _content_identity(row, kind)
                if key in seen:
                    continue
                seen.add(key)
                rows.append(row)
            try:
                rows = filter_items(source, kind, rows)
            except Exception:
                pass
            try:
                rows.sort(key=_newest_key, reverse=True)
            except Exception:
                pass
            self._apply_items(rows, category, generation)

        thread = threading.Thread(target=worker, name="TiviMateStandaloneGenreItems")
        thread.daemon = True
        thread.start()

    def _apply_items(self, rows, category, generation):
        if self._closed or generation != self._generation:
            return
        if not self.categories or self.category_index >= len(self.categories):
            return
        if str(self.categories[self.category_index].get("id")) != str(category.get("id")):
            return
        self.genre_items = list(rows or [])
        self.index = 0
        self.page_start = 0
        self._poster_tokens = {}
        self._rendered_page_key = None
        self.render()

    def _render_empty(self, message):
        try:
            self._hero_timer.stop()
        except Exception:
            pass
        self._hero_token = None
        self._hero_text_token = None
        self._hero_text_sources = {}
        heading = "TV SHOWS" if self.kind == "series" else "MOVIES"
        self["heading"].setText(heading)
        self["subheading"].setText("GENRE  •  Select a category with RED / BLUE")
        self["page"].setText("1 / 1")
        self["status"].setText(message)
        self["heroTitle"].setText("")
        self["heroMeta"].setText("")
        self["heroPlot"].setText("")
        self._render_genre_bar()
        self._rendered_page_key = None
        for slot in range(PAGE_SIZE):
            self["title%d" % slot].setText("")
            self["meta%d" % slot].setText("")
            self["poster%d" % slot].hide()
            self["shell%d" % slot].hide()
        try:
            self["selector"].hide()
        except Exception:
            pass

    def render(self):
        category = self.categories[self.category_index] if self.categories else {}
        heading = "TV SHOWS" if self.kind == "series" else "MOVIES"
        total = len(self.genre_items)
        pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
        current_page = (self.index // PAGE_SIZE) + 1 if total else 1
        self.page_start = (self.index // PAGE_SIZE) * PAGE_SIZE if total else 0
        self["heading"].setText(heading)
        self["subheading"].setText("GENRE  •  %s" % str(category.get("name") or ""))
        self["page"].setText("%d / %d" % (current_page, pages))
        self["status"].setText("%s  •  %d %s" % (str(category.get("name") or "GENRE"), total, "titles" if total != 1 else "title"))
        self._render_genre_bar()
        selected = self._selected_item() or {}
        name = str(selected.get("name") or selected.get("title") or "")
        year = str(selected.get("year") or selected.get("release_date") or "")[:4]
        rating = str(selected.get("rating") or selected.get("vote_average") or "")
        description = str(selected.get("plot") or selected.get("description") or selected.get("overview") or selected.get("storyline") or selected.get("plot_outline") or "").strip()
        self._schedule_hero()
        self._update_hero_info(self._hero_token, {
            "title": name,
            "year": year,
            "rating": rating,
            "description": description,
            "category": str(category.get("name") or ""),
        }, "catalog")

        # Navigation inside the same page only moves the selection. Redrawing
        # every card on each arrow press used to replace all 24 cached posters
        # with placeholders and queue duplicate image decodes (visible flicker).
        page_key = (self._generation, self.page_start, total)
        if page_key != self._rendered_page_key:
            self._rendered_page_key = page_key
            for slot in range(PAGE_SIZE):
                item_index = self.page_start + slot
                item = self.genre_items[item_index] if item_index < total else None
                if not item:
                    self._poster_tokens.pop(slot, None)
                    self["poster%d" % slot].hide()
                    self["shell%d" % slot].hide()
                    self["title%d" % slot].setText("")
                    self["meta%d" % slot].setText("")
                    continue
                self["poster%d" % slot].show()
                self["shell%d" % slot].show()
                year = str(item.get("year") or item.get("releaseDate") or item.get("release_date") or item.get("first_air_date") or "")[:4]
                rating = str(item.get("rating") or item.get("rating_5based") or item.get("vote_average") or "").strip()
                self["meta%d" % slot].setText("  •  ".join(part for part in (year, ("★ " + rating) if rating else "") if part))
                self._set_placeholder(slot)
                self._load_poster(slot, item, item_index)

        if total:
            slot = self.index - self.page_start
            row = slot // GRID_COLUMNS
            column = slot % GRID_COLUMNS
            self["selector"].instance.move(ePoint(sx(GRID_X[column]), sy(GRID_Y[row])))
            self["selector"].show()
        else:
            self["selector"].hide()

    def _set_placeholder(self, slot):
        try:
            self["poster%d" % slot].instance.setPixmapFromFile(POSTER_PLACEHOLDER)
        except Exception:
            pass

    def _poster_url(self, item):
        # Use the very same provider image extraction as ContentHomeScreen.
        try:
            url = _server_poster_url(self.source, item)
        except Exception:
            url = ""
        return str(url or "").strip().replace("\\/", "/")

    def _post_to_gui(self, func, *args):
        """Async artwork callbacks must never paint Enigma widgets off-thread."""
        try:
            from twisted.internet import reactor
            reactor.callFromThread(func, *args)
        except Exception:
            # The receiver normally ships with Twisted. Do not paint widgets
            # on a downloader thread if its event loop is unavailable.
            pass

    def _load_poster(self, slot, item, item_index):
        url = self._poster_url(item)
        token = "%d:%d:%s" % (self._generation, item_index, url or "tmdb")
        self._poster_tokens[slot] = token
        if not url:
            self._resolve_tmdb_poster(slot, item, token)
            return

        cached = cached_artwork(url, "posters")
        if cached and os.path.isfile(cached):
            self._decode_poster(slot, cached, token, item, "provider")
            return

        def ready(path, expected=token, current_slot=slot, record=item):
            self._post_to_gui(self._decode_poster, current_slot, path, expected, record, "provider")

        def failed(_path, expected=token, current_slot=slot, record=item):
            self._post_to_gui(self._resolve_tmdb_poster, current_slot, record, expected)

        try:
            request_artwork(url, "posters", ready, priority=160, errback=failed)
        except Exception:
            self._resolve_tmdb_poster(slot, item, token)

    def _resolve_tmdb_poster(self, slot, item, token):
        if getattr(self, "_closed", True) or getattr(self, "_poster_tokens", {}).get(slot) != token:
            return
        snapshot = dict(item or {})
        kind = self.kind

        def worker():
            try:
                title = str(snapshot.get("name") or snapshot.get("title") or "").strip()
                found = {}
                if title:
                    raw_year = " ".join(str(snapshot.get(key) or "") for key in ("year", "releaseDate", "release_date", "first_air_date"))
                    match = re.search(r"\b(?:19|20)\d{2}\b", raw_year)
                    found = TMDbClient().search_artwork(title, kind, match.group(0) if match else None, required_key="poster_path") or {}
                url = str(found.get("poster_path") or "").strip()
                # TMDb search returns a relative poster path (e.g. /abc.jpg).
                # Resolve it as a POSTER only; never substitute a backdrop.
                url = tmdb_poster_url(url)
                if self._closed or self._poster_tokens.get(slot) != token:
                    return
                if not url:
                    self._post_to_gui(self._keep_default_poster, slot, token)
                    return

                def ready(path, expected=token, current_slot=slot, record=snapshot):
                    self._post_to_gui(self._decode_poster, current_slot, path, expected, record, "tmdb")

                def failed(_path, expected=token, current_slot=slot, record=snapshot):
                    self._post_to_gui(self._keep_default_poster, current_slot, expected)

                cached = cached_artwork(url, "posters")
                if cached and os.path.isfile(cached):
                    ready(cached)
                else:
                    request_artwork(url, "posters", ready, priority=135, errback=failed)
            except Exception:
                self._post_to_gui(self._keep_default_poster, slot, token)

        thread = threading.Thread(target=worker, name="TiviMateStandaloneGenreTMDb")
        thread.daemon = True
        thread.start()

    def _keep_default_poster(self, slot, token):
        """Only use the vertical default image if server and TMDb posters fail."""
        if getattr(self, "_closed", True) or getattr(self, "_poster_tokens", {}).get(slot) != token:
            return
        self._set_placeholder(slot)

    def _decode_poster(self, slot, path, token, item, origin):
        """Decode to the card dimensions instead of stretching the source."""
        if (getattr(self, "_closed", True)
                or getattr(self, "_poster_tokens", {}).get(slot) != token):
            return
        if not path or not os.path.isfile(path):
            self._poster_decode_failed(slot, item, token, origin)
            return
        loader = ePicLoad()
        # During teardown the Screen's attributes may disappear while native
        # ePicLoad still has a queued PictureData notification.
        decoders = getattr(self, "_poster_decoders", None)
        if decoders is None:
            return
        decoders[slot] = loader

        def ready(_=None, current=loader, current_slot=slot, expected=token, record=item, stage=origin):
            try:
                active = getattr(self, "_poster_decoders", None)
                tokens = getattr(self, "_poster_tokens", {})
                if getattr(self, "_closed", True) or active is None or active.get(current_slot) is not current:
                    return
                if tokens.get(current_slot) != expected:
                    return
                pointer = current.getData()
                if pointer:
                    widget = self["poster%d" % current_slot]
                    if widget.instance:
                        widget.instance.setPixmap(pointer)
                        widget.show()
                else:
                    self._poster_decode_failed(current_slot, record, expected, stage)
            except Exception:
                pass
            finally:
                active = getattr(self, "_poster_decoders", None)
                if active is not None and active.get(current_slot) is current:
                    active.pop(current_slot, None)

        try:
            connect_picture_data(loader, ready, self, oneshot=True)
            width, height = scale_size(CARD_WIDTH, CARD_HEIGHT)
            loader.setPara((width, height, 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            active = getattr(self, "_poster_decoders", None)
            if active is not None and active.get(slot) is loader:
                active.pop(slot, None)
            self._poster_decode_failed(slot, item, token, origin)

    def _poster_decode_failed(self, slot, item, token, origin):
        if getattr(self, "_closed", True) or getattr(self, "_poster_tokens", {}).get(slot) != token:
            return
        if origin == "provider":
            self._resolve_tmdb_poster(slot, item, token)
        elif origin == "tmdb":
            self._keep_default_poster(slot, token)
        # Poster failed from both sources: keep the vertical placeholder.

    def _selected_item(self):
        if 0 <= self.index < len(self.genre_items):
            return self.genre_items[self.index]
        return None

    def left(self):
        if self.genre_items and self.index % GRID_COLUMNS:
            self.index -= 1
            self.render()

    def right(self):
        if self.genre_items and self.index + 1 < len(self.genre_items) and self.index % GRID_COLUMNS < GRID_COLUMNS - 1:
            self.index += 1
            self.render()

    def up(self):
        if self.genre_items and self.index >= GRID_COLUMNS:
            self.index -= GRID_COLUMNS
            self.render()

    def down(self):
        if self.genre_items and self.index + GRID_COLUMNS < len(self.genre_items):
            self.index += GRID_COLUMNS
            self.render()

    def page_up(self):
        if self.genre_items:
            self.index = max(0, self.index - PAGE_SIZE)
            self.render()

    def page_down(self):
        if self.genre_items:
            self.index = min(len(self.genre_items) - 1, self.index + PAGE_SIZE)
            self.render()

    def previous_genre(self):
        if not self.categories:
            return
        self.category_index = (self.category_index - 1) % len(self.categories)
        self._generation += 1
        self._render_genre_bar()
        self._load_selected_genre(self._generation)

    def next_genre(self):
        if not self.categories:
            return
        self.category_index = (self.category_index + 1) % len(self.categories)
        self._generation += 1
        self._render_genre_bar()
        self._load_selected_genre(self._generation)

    def show_movies(self):
        if self.kind != "vod":
            self.kind = "vod"
            self.start()

    def show_series(self):
        if self.kind != "series":
            self.kind = "series"
            self.start()

    def toggle_favorite(self):
        item = self._selected_item()
        if not item:
            return
        title = str(item.get("name") or item.get("title") or tr("CONTENT"))
        try:
            if is_favourite(self.source, self.kind, item):
                self["status"].setText("%s is already in Favorites" % title)
            elif add_favourite(self.source, self.kind, item):
                self["status"].setText("%s added to Favorites" % title)
            else:
                self["status"].setText("Unable to save Favorite")
        except Exception:
            self["status"].setText("Unable to save Favorite")

    def open_selected(self):
        item = self._selected_item()
        if not item:
            return
        category = self.categories[self.category_index] if self.categories else {}
        detail_item = dict(item)
        detail_item["_source_category_id"] = str(category.get("id") or detail_item.get("_source_category_id") or "")
        detail_item["_genre_standalone"] = True
        if self.kind == "series":
            try:
                if self._series_details_class is None:
                    from .ui import SeriesDetailsScreen
                    self._series_details_class = SeriesDetailsScreen
                self.session.open(self._series_details_class, dict(self.source), detail_item)
            except Exception as exc:
                self.session.open(MessageBox, "Unable to open series details:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            self.session.open(
                MovieDetailsScreen,
                dict(self.source),
                detail_item,
                list(self.genre_items),
                {"scope": "genre", "category_id": detail_item.get("_source_category_id"), "items": list(self.genre_items)},
            )
        except Exception as exc:
            self.session.open(MessageBox, "Unable to open movie details:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=4)


def install_genre_page(ui_module):
    """Link the original GENRE-backdrop screen to the independent poster page.

    The normal GENRE selector and its existing MovieGenresScreen backdrop grid
    stay exactly in their original route.  Only an OK press on one of those
    backdrop cards opens the standalone 8x3 title grid, scoped to that exact
    provider category.  This intentionally avoids touching Packages, Movies,
    TV Shows, or their original implementations.
    """
    if getattr(ui_module, "_standalone_genre_page_installed", False):
        return
    backdrop_screen = getattr(ui_module, "MovieGenresScreen", None)
    if backdrop_screen is None:
        return

    original_choose = backdrop_screen.choose

    def open_standalone_from_backdrop(self):
        rows = list(getattr(self, "rows", []) or [])
        index = int(getattr(self, "index", 0) or 0)
        if index < 0 or index >= len(rows):
            return
        row = rows[index] if isinstance(rows[index], dict) else {}
        category_id = str(row.get("id") or row.get("category_id") or "").strip()
        kind = "series" if str(row.get("kind") or getattr(self, "kind", "vod")) == "series" else "vod"
        source = dict(getattr(self, "source", {}) or {})
        if not source or not category_id:
            return original_choose(self)

        # Do not register a return callback here.  The existing GENRE backdrop
        # screen remains alive below this child screen, and Enigma2 reveals it
        # automatically when EXIT closes the 24-poster screen.  Avoiding a late
        # callback prevents a closed/invalid backdrop widget from being painted
        # during the screen-stack transition on older receiver images.
        self.session.open(
            StandaloneGenreScreen,
            source,
            kind,
            category_id,
        )

    backdrop_screen._standalone_genre_original_choose = original_choose
    backdrop_screen.choose = open_standalone_from_backdrop
    ui_module.StandaloneGenreScreen = StandaloneGenreScreen
    ui_module._standalone_genre_page_installed = True
