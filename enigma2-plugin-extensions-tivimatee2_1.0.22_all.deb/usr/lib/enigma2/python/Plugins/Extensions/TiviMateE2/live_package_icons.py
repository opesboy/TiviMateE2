# -*- coding: utf-8 -*-
"""Safe, optional, online country flags for the Live package list.

No network call runs on Enigma's GUI thread.  Flags are fetched one at a time,
only for visible packages, and the package list remains usable without them.
"""
from __future__ import absolute_import

import os
import re
import struct
import unicodedata
from urllib.request import Request, urlopen

from .cache_manager import get_cache_dir

# These labels are explicit country identifiers at the *start* of a package
# name.  Deliberately exclude AR (Arabic, not Argentina), EN, TR? TR is
# commonly Turkey (also Turkish); only treat prefix TR as a country label.
_COUNTRIES = {
    "UK": "gb", "GB": "gb", "USA": "us", "US": "us", "UAE": "ae", "AE": "ae",
    "KSA": "sa", "SA": "sa", "CA": "ca", "CAN": "ca", "AU": "au", "AUS": "au",
    "DE": "de", "GER": "de", "FR": "fr", "FRANCE": "fr", "IT": "it", "ITALY": "it",
    "ES": "es", "SPAIN": "es", "TR": "tr", "TURKEY": "tr", "RU": "ru", "RUSSIA": "ru",
    "IN": "in", "INDIA": "in", "PK": "pk", "EG": "eg", "EGYPT": "eg",
    "JP": "jp", "JAPAN": "jp", "KR": "kr", "KOREA": "kr", "CN": "cn", "CHINA": "cn",
    "NL": "nl", "PL": "pl", "PT": "pt", "BR": "br", "MX": "mx", "ZA": "za",
    "NZ": "nz", "SE": "se", "NO": "no", "DK": "dk", "FI": "fi",
    "QA": "qa", "QATAR": "qa", "KW": "kw", "OM": "om", "BH": "bh",
    "JO": "jo", "LB": "lb", "MA": "ma", "TN": "tn", "DZ": "dz", "IQ": "iq",
    "SY": "sy", "SYR": "sy", "SYRIA": "sy", "SYRIAN": "sy",
    "YE": "ye", "YEM": "ye", "YEMEN": "ye", "YEMENI": "ye",
    "MAR": "ma", "MAROC": "ma", "MOROCCO": "ma", "MOROCCAN": "ma",
    "LBN": "lb", "LIBAN": "lb", "LEBANON": "lb", "LEBANESE": "lb",
    "IRAK": "iq", "IRAQ": "iq", "IRAQI": "iq",
    "TUN": "tn", "TUNIS": "tn", "TUNISE": "tn", "TUNISIA": "tn", "TUNISIE": "tn",
    "EMIRATES": "ae", "SAUDI": "sa", "SAUDIARABIA": "sa",
}
_PREFIX = re.compile(r"^\s*[\[\({]?\s*([A-Za-z]{2,12})(?=$|[\s\]\)}|:;,_./\\\-])")
_ARABIC_MARKS = re.compile(r"[\u064b-\u065f\u0670\u0640]")
# Only the actual explicit country label, not a server's language (AR = Arabic).
_ARABIC_COUNTRIES = (
    (("الامارات", "امارات", "اماراتيه", "دولة الامارات", "الامارات العربيه المتحده"), "ae"),
    (("تونس", "تونسي", "تونسيه"), "tn"),
    (("السعوديه", "سعوديه", "السعودي", "سعودي", "المملكه العربيه السعوديه"), "sa"),
    (("المغرب", "مغرب", "المغربي", "مغربي", "المغربيه", "مغربيه"), "ma"),
    (("لبنان", "اللبناني", "لبناني", "اللبنانيه", "لبنانيه"), "lb"),
    (("العراق", "عراق", "العراقي", "عراقي", "العراقيه", "عراقيه"), "iq"),
    (("سوريا", "سوريه", "السوري", "سوري", "السوريه"), "sy"),
    (("اليمن", "يمن", "اليمني", "يمني", "اليمنيه", "يمنيه"), "ye"),
)


def _normalized_name(name):
    value = unicodedata.normalize("NFKC", str(name or ""))
    value = _ARABIC_MARKS.sub("", value)
    value = value.replace("أ", "ا").replace("إ", "ا").replace("آ", "ا")
    value = value.replace("ى", "ي").replace("ة", "ه")
    value = value.replace("٤", "4")
    return value.lower()


def _token_sequence(name):
    return re.findall(r"[a-z0-9]+|[\u0621-\u064a]+", _normalized_name(name))


def package_country(name):
    """Match an explicit country, including Arabic and AR-UAE/AR-TUNISE.

    Never interpret AR (Arabic) as Argentina. Specific country prefixes beat
    regional brands; plain MBC/إم بي سي deliberately uses the Saudi flag.
    """
    normalized = _normalized_name(name)
    tokens = _token_sequence(name)
    if not tokens:
        return ""
    # Explicit country first, including a language marker followed by country.
    prefix = tokens[0]
    if prefix.upper() in _COUNTRIES:
        return _COUNTRIES[prefix.upper()]
    if prefix in ("ar", "ara", "arabic", "عربي", "العربي", "العربيه", "en", "eng", "english"):
        if len(tokens) > 1:
            match = _COUNTRIES.get(tokens[1].upper())
            if match:
                return match
            for names, country in _ARABIC_COUNTRIES:
                if tokens[1] in names:
                    return country
    for names, country in _ARABIC_COUNTRIES:
        # Arabic region must be a whole word, not a substring of another title.
        if any(re.search(r"(?<![\u0621-\u064a])%s(?![\u0621-\u064a])" % re.escape(n), normalized) for n in names):
            return country
    # Explicit full English country words after language/region delimiters.
    # The accepted prefix tokens above cover formats such as AR-MOROCCO.
    # Saudi broadcasters: regional prefixes such as UAE-ROTANA still take
    # priority above this brand fallback.
    compact = "".join(tokens)
    if ("myhd" in tokens or ("my" in tokens and "hd" in tokens and tokens.index("my") + 1 == tokens.index("hd"))
            or any(v in compact for v in ("ماياتشدي", "مايهد"))):
        return "sa"
    if "rotana" in tokens or "روتانا" in normalized:
        return "sa"
    # MBC is a Saudi channel group, even when prefixed by AR / Arabic label.
    if ("mbc" in tokens or any(v in normalized for v in ("ام بي سي", "امبيسي", "ام بي سى"))):
        return "sa"
    return ""


def package_special_icon(name):
    """Small local logos used only on explicit matching Live package titles."""
    value = _normalized_name(name)
    compact = re.sub(r"[\s\-_|:.]+", "", value)
    tokens = _token_sequence(name)
    # Do not mislabel 4K as a country or generic movie package.
    if ("4k" in tokens or "uhd" in tokens or "فوركي" in compact or "فوركاي" in compact
            or "٤ك" in value or "4ك" in value or "اولترااتشدي" in compact):
        return "4k"
    if "ufc" in tokens or "يوافسي" in compact or "يوفسي" in compact:
        return "ufc"
    if "wwe" in tokens or "دبليودبليواي" in compact or "دبليودبليوايي" in compact:
        return "wwe"
    if "netflix" in compact or "netflex" in compact or "نتفليكس" in compact or "نتفلكس" in compact or "نيتفليكس" in compact:
        return "netflix"
    # OSN Movies is a brand package, not a country. Avoid hijacking OSN Sports.
    osn = "osn" in tokens or any(v in compact for v in ("اواسان", "اوسان"))
    movie = any(v in tokens for v in ("movie", "movies", "film", "films", "cinema")) or any(v in compact for v in ("موفيز", "افلام", "سينما"))
    if osn and movie:
        return "osn"
    return ""


def package_kind(name):
    """Lightweight fallback icon when no country flag has arrived yet."""
    value = _normalized_name(name)
    if any(word in value for word in ("sport", "football", "soccer", "bein", "espn", "nba", "epl", "fifa", "sky sport", "رياضه", "رياضي", "كره", "مصارعه")):
        return "sport"
    if any(word in value for word in ("movie", "cinema", "film", "vod", "افلام", "سينما")):
        return "movies"
    if any(word in value for word in ("series", "show", "drama", "مسلسلات", "مسلسل", "دراما")):
        return "shows"
    if any(word in value for word in ("news", "اخبار", "عاجل")):
        return "news"
    if any(word in value for word in ("kids", "child", "cartoon", "طفل", "اطفال", "كرتون")):
        return "kids"
    if any(word in value for word in ("music", "radio", "موسيقي", "موسيقا", "اغاني")):
        return "music"
    if any(word in value for word in ("document", "history", "nature", "science", "وثائق", "طبيعه")):
        return "documentary"
    if any(word in value for word in ("religio", "quran", "islam", "دين", "قران", "اسلام")):
        return "religion"
    if any(word in value for word in ("cook", "food", "مطبخ", "طبخ", "طعام")):
        return "food"
    return "general"


def _valid_png(content):
    if not isinstance(content, bytes) or len(content) < 33 or len(content) > 65536:
        return False
    if content[:8] != b"\x89PNG\r\n\x1a\n" or content[12:16] != b"IHDR":
        return False
    width, height = struct.unpack(">II", content[16:24])
    return 12 <= width <= 256 and 9 <= height <= 256


def flag_cached_path(country):
    if country not in _COUNTRIES.values():
        return ""
    try:
        path = os.path.join(get_cache_dir("logos/live_country_flags"), country + ".png")
        with open(path, "rb") as f:
            header = f.read(33)
        return path if header.startswith(b"\x89PNG\r\n\x1a\n") else ""
    except (OSError, IOError):
        return ""


def fetch_flag(country):
    """Background thread only; no GUI calls and no bulk country downloads."""
    if country not in _COUNTRIES.values():
        return ""
    cached = flag_cached_path(country)
    if cached:
        return cached
    # HTTPS with normal certificate checks. A failed request must never block
    # the UI or disable the local generic icon fallback.
    urls = (
        "https://flagcdn.com/24x18/%s.png" % country,
        "https://flagcdn.io/4x3/24/%s.png" % country,
    )
    for url in urls:
        try:
            response = urlopen(Request(url, headers={"User-Agent": "TiviMateE2/1.0"}), timeout=3)
            try:
                content = response.read(65537)
            finally:
                response.close()
            if not _valid_png(content):
                continue
            directory = get_cache_dir("logos/live_country_flags")
            target = os.path.join(directory, country + ".png")
            temp = target + ".part"
            with open(temp, "wb") as f:
                f.write(content)
            try:
                os.replace(temp, target)
            except AttributeError:
                os.rename(temp, target)
            return target
        except Exception:
            continue
    return ""
