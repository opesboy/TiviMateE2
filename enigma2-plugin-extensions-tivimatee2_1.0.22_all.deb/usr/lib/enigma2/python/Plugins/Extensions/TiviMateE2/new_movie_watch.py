# -*- coding: utf-8 -*-
"""Persistent new VOD / series announcements for each provider and package filter.

A provider refresh creates a baseline on first use. Subsequent additions are
saved in *batches* so ten simultaneous additions produce one accurate popup
stating the count, rather than silently marking nine as announced. Batches
are acknowledged only once the floating popup was actually shown.
"""
import hashlib
import json
import os
import threading
import time

def notices_enabled(source):
    """Return the per-server alert preference; old sources remain enabled."""
    raw = (source or {}).get("new_content_notices", True)
    if isinstance(raw, str):
        return raw.strip().lower() not in ("0", "false", "off", "no", "disabled")
    return bool(raw)


_STATE_LOCK = threading.Lock()
_PREVIEW_FIELDS = (
    "name", "title", "stream_icon", "cover", "cover_big", "movie_image",
    "poster", "poster_path", "image", "logo", "series_id", "stream_id",
    "tmdb_id", "category_id", "year",
)


def notice_state_path(file_key):
    """Store tiny notice state durably even when artwork uses disposable flash cache.

    Preserve the existing disk path for mounted HDD/USB, and migrate older
    /var/tmp baselines to /etc when the device has no mounted media. Never
    delete a legacy state before its replacement has been safely written.
    """
    from .storage import data_path, storage_mode, ETC_DIR

    old_path = data_path("new_movie_watch", file_key + ".json")
    if storage_mode() != "internal":
        return old_path
    path = os.path.join(ETC_DIR, "new_movie_watch", file_key + ".json")
    if os.path.isfile(path) or not os.path.isfile(old_path):
        return path
    with _STATE_LOCK:
        if not os.path.isfile(path):
            try:
                with open(old_path, "r") as handle:
                    existing = json.load(handle)
                if isinstance(existing, dict) and existing.get("version") == 1:
                    _atomic_save(path, existing)
            except Exception:
                pass
    return path if os.path.isfile(path) else old_path


def _pending_batches(state):
    """Load current batches and the single-record layout of previous builds."""
    pending = state.get("pending") if isinstance(state, dict) else None
    if isinstance(pending, dict):
        pending = [pending]
    if not isinstance(pending, list):
        return []
    return [dict(batch) for batch in pending
            if isinstance(batch, dict) and batch.get("key")
            and isinstance(batch.get("row"), dict)]


def record_catalog(path, movies):
    """Save a complete fresh catalog and queue *all* actual additions as a batch.

    Return the representative row, or None when first seeding, incomplete or
    unchanged. An empty/untrustworthy provider response never erases history.
    """
    by_key = {}
    for key, row in movies:
        if isinstance(row, dict) and key and (row.get("name") or row.get("title")):
            by_key.setdefault(str(key), row)
    if not by_key:
        return None
    current_keys = set(by_key)
    with _STATE_LOCK:
        previous = None
        try:
            with open(path, "r") as handle:
                previous = json.load(handle)
            if (not isinstance(previous, dict) or previous.get("version") != 1
                    or not isinstance(previous.get("keys"), list)):
                previous = None
        except Exception:
            previous = None
        prior_keys = set(previous.get("keys") or []) if previous else set()
        overlap = len(prior_keys.intersection(current_keys))
        # A partial provider response must not shrink the baseline: on the
        # next full fetch the omitted old titles would seem newly added.
        trustworthy = (not prior_keys or
                       (overlap >= max(1, int(len(prior_keys) * 0.45))
                        and len(current_keys) >= int(len(prior_keys) * 0.80)))
        if not trustworthy:
            return None

        batches = _pending_batches(previous)
        newly_added = sorted(current_keys - prior_keys) if prior_keys else []
        # Avoid rewriting large baseline JSON on every hourly recheck,
        # especially when no mounted HDD is present (receiver flash wear).
        if previous and not newly_added and current_keys == prior_keys:
            return dict(batches[0]["row"]) if batches else None
        if newly_added:
            chosen_key = max(newly_added, key=lambda key: (_added_time(by_key[key]), key))
            chosen_row = by_key[chosen_key]
            preview = {field: chosen_row[field] for field in _PREVIEW_FIELDS
                       if field in chosen_row and
                       isinstance(chosen_row[field], (str, int, float, bool))}
            # All keys are accounted for by a single batch. No stream URLs or
            # provider credentials are written into the persistent state.
            digest = hashlib.sha1("\n".join(newly_added).encode("utf-8")).hexdigest()
            batches.append({"key": "batch:" + digest,
                            "row": preview, "count": len(newly_added)})

        state = {"version": 1, "saved": int(time.time()), "keys": sorted(current_keys)}
        if batches:
            state["pending"] = batches
        if not _atomic_save(path, state):
            return None
        return dict(batches[0]["row"]) if batches else None


def acknowledge_notice(path, row_key):
    """Acknowledge exactly the batch displayed; never drop later arrivals."""
    with _STATE_LOCK:
        try:
            with open(path, "r") as handle:
                state = json.load(handle)
            if not isinstance(state, dict) or state.get("version") != 1:
                return False
            batches = _pending_batches(state)
            remaining = [batch for batch in batches if batch.get("key") != row_key]
            if len(remaining) == len(batches):
                return False
            if remaining:
                state["pending"] = remaining
            else:
                state.pop("pending", None)
            return _atomic_save(path, state)
        except Exception:
            return False


def pending_notice(path):
    """Return the oldest verified batch; it stays pending until visible."""
    with _STATE_LOCK:
        try:
            with open(path, "r") as handle:
                state = json.load(handle)
            batches = _pending_batches(state)
            if batches:
                batch = batches[0]
                row = dict(batch["row"])
                row["_new_count"] = max(1, int(batch.get("count") or 1))
                return batch["key"], row
        except Exception:
            pass
    return None, None


def _atomic_save(path, state):
    temp = path + ".tmp"
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(temp, "w") as handle:
            json.dump(state, handle, separators=(",", ":"), ensure_ascii=False)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        return True
    except Exception:
        try:
            if os.path.exists(temp):
                os.remove(temp)
        except Exception:
            pass
        return False


def _added_time(row):
    """Prefer the provider's actual added timestamp, not movie release year."""
    for key in ("added", "date_added", "added_at", "created_at", "timestamp"):
        value = row.get(key)
        try:
            number = int(float(value))
            if number > 100000000000:
                number //= 1000
            if number > 100000000:
                return number
        except (TypeError, ValueError, OverflowError):
            pass
        if isinstance(value, str):
            for fmt, n in (("%Y-%m-%d %H:%M:%S", 19), ("%Y-%m-%dT%H:%M:%S", 19), ("%Y-%m-%d", 10)):
                try:
                    return int(time.mktime(time.strptime(value[:n], fmt)))
                except (TypeError, ValueError, OverflowError):
                    continue
    return 0
