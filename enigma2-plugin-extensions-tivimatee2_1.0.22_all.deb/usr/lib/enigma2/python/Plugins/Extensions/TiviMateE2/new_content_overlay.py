# -*- coding: utf-8 -*-
"""Non-modal new movie/series notice above every TiviMateE2 screen.

Instantiated with session.instantiateDialog, not session.open: the current
GENRE/Search/Movie/Player screen stays active and remote keys keep working.
"""
import os

from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from enigma import ePicLoad

from .display_scale import scale_skin, sx, sy
from .picload_compat import connect_picture_data
from .i18n import get_language

_ROOT = os.path.dirname(__file__)
_PANEL = os.path.join(_ROOT, "skins", "home", "new_movie_demo_panel.png")
_POSTER = os.path.join(_ROOT, "skins", "home", "new_movie_demo_poster.png")

# This screen is only 760x282 pixels; never cover the underlying application.
_SKIN = '''
<screen name="NewContentNoticeOverlay" position="580,399" size="760,282" flags="wfNoBorder" zPosition="120" backgroundColor="#00000000" transparent="1">
    <widget name="panel" position="0,0" size="760,282" pixmap="%s" alphatest="blend" zPosition="0" />
    <widget name="poster" position="28,26" size="154,226" pixmap="%s" alphatest="blend" zPosition="1" />
    <widget name="header" position="238,38" size="475,37" font="Bold;22" foregroundColor="#DBB982" transparent="1" zPosition="2" />
    <widget name="title" position="220,80" size="494,92" font="Regular;34" foregroundColor="#FFFFFF" transparent="1" valign="center" zPosition="2" />
    <widget name="caption" position="220,176" size="492,36" font="Regular;22" foregroundColor="#D1D7DF" transparent="1" zPosition="2" />
    <widget name="footer" position="220,243" size="490,28" font="Regular;17" foregroundColor="#99A6B5" transparent="1" zPosition="2" />
</screen>''' % (_PANEL, _POSTER)

_LABELS = {
    "vod": {
        "en": ("NEW MOVIE", "New movie", "A new movie has been added", "TIVIMATE E2  •  MOVIES"),
        "ar": ("فيلم جديد", "فيلم جديد", "تمت إضافة فيلم جديد", "TIVIMATE E2  •  الأفلام"),
        "fr": ("NOUVEAU FILM", "Nouveau film", "Un nouveau film a été ajouté", "TIVIMATE E2  •  FILMS"),
        "tr": ("YENİ FİLM", "Yeni film", "Yeni bir film eklendi", "TIVIMATE E2  •  FİLMLER"),
    },
    "series": {
        "en": ("NEW SERIES", "New series", "A new series has been added", "TIVIMATE E2  •  TV SHOWS"),
        "ar": ("مسلسل جديد", "مسلسل جديد", "تمت إضافة مسلسل جديد", "TIVIMATE E2  •  المسلسلات"),
        "fr": ("NOUVELLE SÉRIE", "Nouvelle série", "Une nouvelle série a été ajoutée", "TIVIMATE E2  •  SÉRIES"),
        "tr": ("YENİ DİZİ", "Yeni dizi", "Yeni bir dizi eklendi", "TIVIMATE E2  •  DİZİLER"),
    },
}


class NewContentNoticeOverlay(Screen):
    skin = scale_skin(_SKIN)

    def __init__(self, session):
        Screen.__init__(self, session)
        self["panel"] = Pixmap()
        self["poster"] = Pixmap()
        self["header"] = Label("")
        self["title"] = Label("")
        self["caption"] = Label("")
        self["footer"] = Label("")
        self._poster_seq = 0
        self._poster_loader = None
        # No ActionMap: navigation stays on the active app page.

    def configure(self, kind, row):
        self._poster_seq += 1
        self._poster_loader = None
        labels = _LABELS.get(kind, _LABELS["vod"])
        header, fallback, caption, footer = labels.get(get_language(), labels["en"])
        title = str((row or {}).get("name") or (row or {}).get("title") or fallback).strip()
        self["header"].setText(header)
        self["title"].setText(title[:44] or fallback)
        try:
            count = max(1, int((row or {}).get("_new_count") or 1))
        except (ValueError, TypeError):
            count = 1
        if count > 1:
            language = get_language()
            captions = {
                "en": "%s new %s added" % (count, "movies" if kind == "vod" else "series"),
                "ar": "تمت إضافة %s %s جديدة" % (count, "أفلام" if kind == "vod" else "مسلسلات"),
                "fr": ("%s nouveaux films ajoutés" if kind == "vod" else "%s nouvelles séries ajoutées") % count,
                "tr": "%s yeni %s eklendi" % (count, "film" if kind == "vod" else "dizi"),
            }
            caption = captions.get(language, captions["en"])
        self["caption"].setText(caption)
        # Identify the server on multi-server installations, without altering
        # panel dimensions or the popup's existing artwork.
        server_name = str((row or {}).get("_notice_server") or "").strip()
        if server_name:
            footer = "%s • %s" % (footer, server_name[:22])
        self["footer"].setText(footer)
        try:
            self["poster"].instance.setPixmapFromFile(_POSTER)
        except Exception:
            pass

    def setPoster(self, path):
        if not path or not os.path.isfile(path):
            return
        token = self._poster_seq
        try:
            loader = ePicLoad()
            self._poster_loader = loader
            def on_decoded(_info=None):
                try:
                    if token != self._poster_seq or not self.shown:
                        return
                    pixmap = loader.getData()
                    if pixmap and self["poster"].instance:
                        self["poster"].instance.setPixmap(pixmap)
                except Exception:
                    pass
            connect_picture_data(loader, on_decoded, self)
            loader.setPara((sx(154), sy(226), 0, 0, False, 1, "#00000000"))
            loader.startDecode(path)
        except Exception:
            pass

    def hide(self):
        self._poster_seq += 1
        self._poster_loader = None
        Screen.hide(self)
