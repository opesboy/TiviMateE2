# -*- coding: utf-8 -*-
import os, time, json, hashlib, threading
from collections import OrderedDict
import queue as _queue
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap as _E2ActionMap
from .restart_debug import make_traced_actionmap
ActionMap = make_traced_actionmap(_E2ActionMap)
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.MenuList import MenuList
from enigma import eServiceReference, ePicLoad, eConsoleAppContainer, ePoint, eTimer, eSize
try:
    from twisted.internet import reactor
except Exception:
    reactor = None
from .core import get_source_client
from .tmdb_client import TMDbClient, load_settings
from .filters import get_filtered_streams, get_allowed_category_ids, filter_categories, get_category_streams, get_cached_categories, get_stalker_landing_items
from difflib import SequenceMatcher
import re
from urllib.parse import urlparse, quote

from .cache_manager import get_cache_dir
from .artwork_queue import request_artwork
from .picload_compat import connect_picture_data
from .display_scale import scale_skin, sx, sy, scale_size
from .i18n import tr, get_language
PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"

CONTENT_LANDING_CACHE_DIR = "/etc/enigma2/tivimatee2/content_landing"

_SERVER_POSTER_KEYS = (
    "stream_icon", "movie_image", "cover", "cover_big", "poster",
    "poster_url", "poster_path", "screenshot_uri", "image"
)

def _server_asset_url(source, value):
    """Normalize artwork supplied by the IPTV provider, never as a TMDb path."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = str(value or "").strip().replace("\\/", "/")
    except Exception:
        return ""
    if not value:
        return ""
    # JSON-encoded one-element artwork arrays are common on Xtream forks.
    if value.startswith("["):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, list) and decoded:
                value = str(decoded[0] or "").strip().replace("\\/", "/")
        except Exception:
            pass
    if not value:
        return ""
    if value.startswith("//"):
        base = str((source or {}).get("url") or (source or {}).get("portal") or "")
        scheme = urlparse(base).scheme or "http"
        return scheme + ":" + value
    if value.startswith(("http://", "https://")):
        return value.replace(" ", "%20")

    source = source or {}
    base = str(source.get("url") or source.get("portal") or "").strip().rstrip("/")
    if not base:
        return value.replace(" ", "%20")
    if "://" not in base:
        base = "http://" + base

    try:
        parsed = urlparse(base)
        scheme = parsed.scheme or "http"
        netloc = parsed.netloc
        # Some saved Xtream sources keep port in a separate field.
        port = str(source.get("port") or "").strip()
        if port and ":" not in netloc.rsplit("@", 1)[-1]:
            netloc = "%s:%s" % (netloc, port)
        origin = "%s://%s" % (scheme, netloc)
        if value.startswith("/"):
            return (origin + value).replace(" ", "%20")
        path = (parsed.path or "").rstrip("/")
        return ("%s%s/%s" % (origin, path, value.lstrip("/"))).replace(" ", "%20")
    except Exception:
        return value.replace(" ", "%20")

def _server_poster_url(source, item, extra=None):
    """Extract provider poster from the row and nested info before TMDb fallback."""
    item = item if isinstance(item, dict) else {}
    extra = extra if isinstance(extra, dict) else {}
    mappings = [item]
    info = item.get("info")
    if isinstance(info, dict):
        mappings.append(info)
    if extra:
        mappings.append(extra)
        extra_info = extra.get("info")
        if isinstance(extra_info, dict):
            mappings.append(extra_info)
    for mapping in mappings:
        for key in _SERVER_POSTER_KEYS:
            value = mapping.get(key)
            if value not in (None, "", [], {}):
                url = _server_asset_url(source, value)
                if url:
                    return url
    return ""

def _content_landing_cache_path(source, kind):
    try:
        raw = "%s|%s|%s|%s|%s" % (
            source.get("type") or "", source.get("url") or source.get("portal") or "",
            source.get("username") or "", source.get("mac") or "", kind or ""
        )
        digest = hashlib.md5(raw.encode("utf-8")).hexdigest()
        return os.path.join(CONTENT_LANDING_CACHE_DIR, digest + ".json")
    except Exception:
        return ""

def _load_content_landing_cache(source, kind):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path or not os.path.exists(path):
            return []
        with open(path, "r") as fh:
            data = json.load(fh)
        return list(data.get("items") or [])[:64] if isinstance(data, dict) else []
    except Exception:
        return []

def _save_content_landing_cache(source, kind, items):
    path = _content_landing_cache_path(source, kind)
    try:
        if not path:
            return
        folder = os.path.dirname(path)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump({"saved": int(time.time()), "items": list(items or [])[:64]}, fh)
        try:
            os.replace(tmp, path)
        except AttributeError:
            if os.path.exists(path):
                os.remove(path)
            os.rename(tmp, path)
    except Exception:
        pass

# Fixed-size background pool for frequent ContentHome artwork/category jobs.
# Navigation can generate requests much faster than slow portals/TMDb can answer;
# a thread-per-keypress design eventually exhausts Enigma2.  Keep only four
# workers and coalesce stale jobs by logical key instead.
_CONTENT_BG_QUEUE = _queue.Queue(maxsize=128)
_CONTENT_BG_LOCK = threading.RLock()
_CONTENT_BG_LATEST = {}
_CONTENT_BG_STARTED = [False]
_CONTENT_BG_WORKERS = 4

def _content_bg_worker(index):
    while True:
        try:
            target, args, key, generation = _CONTENT_BG_QUEUE.get()
        except Exception:
            continue
        try:
            if key is not None:
                try:
                    with _CONTENT_BG_LOCK:
                        if _CONTENT_BG_LATEST.get(key) != generation:
                            continue
                except Exception:
                    pass
            try:
                target(*args)
            except Exception:
                pass
        finally:
            try:
                _CONTENT_BG_QUEUE.task_done()
            except Exception:
                pass

def _ensure_content_bg_workers():
    with _CONTENT_BG_LOCK:
        if _CONTENT_BG_STARTED[0]:
            return
        _CONTENT_BG_STARTED[0] = True
        for index in range(_CONTENT_BG_WORKERS):
            worker = threading.Thread(target=_content_bg_worker, args=(index,), name="TiviMateContentPool-%d" % (index + 1))
            worker.daemon = True
            worker.start()

def _submit_content_bg(target, args=(), key=None):
    _ensure_content_bg_workers()
    generation = 0
    if key is not None:
        with _CONTENT_BG_LOCK:
            generation = int(_CONTENT_BG_LATEST.get(key, 0) or 0) + 1
            _CONTENT_BG_LATEST[key] = generation
    try:
        _CONTENT_BG_QUEUE.put_nowait((target, tuple(args or ()), key, generation))
        return True
    except Exception:
        # A saturated queue is safer than allocating more receiver threads.
        # Visible cards/categories naturally request again on the next user move.
        return False

IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")

# Keep recently decoded pixmaps alive in RAM. This avoids ePicLoad decoding again
# when the user reopens the same movie during the current Enigma2 session.
_DETAILS_PIXMAP_CACHE = OrderedDict()
# Decoded pixmaps consume RAM on the receiver.  Keep a small LRU only while a
# details page is open; the full-quality source remains in the disk cache.
_DETAILS_PIXMAP_CACHE_LIMIT = 8
_DETAILS_DATA_CACHE = OrderedDict()
_DETAILS_DATA_CACHE_LIMIT = 12

def _memory_get(cache, key):
    try:
        value = cache.pop(key)
        cache[key] = value
        return value
    except Exception:
        return None

def _memory_put(cache, key, value, limit):
    try:
        if key in cache:
            cache.pop(key)
        cache[key] = value
        while len(cache) > limit:
            cache.popitem(last=False)
    except Exception:
        pass


HOME_APPEARANCE_FILE = "/etc/enigma2/tivimatee2/home_appearance.json"

def _content_default_mode(kind):
    """Movies and TV Shows default to Netflix."""
    try:
        with open(HOME_APPEARANCE_FILE, "r") as handle:
            data = json.load(handle) or {}
        key = "movies_content" if kind == "vod" else "series_content"
        value = str(data.get(key) or "netflix").strip().lower()
        if value not in ("netflix", "prime", "trending", "recent"):
            value = "netflix"
        if value == "popular":
            value = "netflix"
        return value
    except Exception:
        return "netflix"


def _content_mode_title(kind, mode):
    is_movies = kind == "vod"
    mode = str(mode or "netflix").strip().lower()
    if mode == "recent":
        return "Recent Added Movies" if is_movies else "Recent Added TV Shows"
    if mode == "trending":
        return "Trending Movies" if is_movies else "Trending TV Shows"
    if mode == "prime":
        return "Prime Video Movies" if is_movies else "Prime Video TV Shows"
    return "Netflix Movies" if is_movies else "Netflix TV Shows"

def _accessibility_skin_enabled():
    try:
        with open(HOME_APPEARANCE_FILE, "r") as handle:
            data = json.load(handle) or {}
        return data.get("skin") == "skin3_accessibility"
    except Exception:
        return False

CONTENT_HOME = '''<screen name="ContentHomeScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">
<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />
<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_overlay.png" alphatest="blend" zPosition="2" />
<widget name="top0" position="60,35" size="150,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top1" position="220,35" size="130,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top2" position="360,35" size="120,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top3" position="490,35" size="150,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top4" position="650,35" size="180,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top5" position="840,35" size="300,52" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top6" position="1150,35" size="180,52" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="topSelector" position="45,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
<widget name="clock" position="1640,42" size="190,40" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<ePixmap position="1500,398" size="300,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/hero_logo_badge_wide.png" alphatest="blend" zPosition="5" />
<widget name="logoHintIcon" position="1522,420" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/logo_hint_icon.png" alphatest="blend" zPosition="6" />
<widget name="logoHint" position="1580,410" size="190,64" font="Regular;27" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="logoImage" position="1520,412" size="260,60" alphatest="blend" zPosition="7" />
<widget name="logoTitle" position="95,145" size="840,100" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroMeta" position="100,265" size="820,40" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroDesc" position="100,320" size="820,110" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="100,398" size="254,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/hero_play_c.png" alphatest="blend" zPosition="5" />
<widget name="heroPlay" position="112,410" size="230,64" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<ePixmap position="368,398" size="284,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/hero_info_c.png" alphatest="blend" zPosition="5" />
<widget name="heroInfo" position="380,410" size="260,64" font="Regular;25" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendingTitle" position="80,500" size="720,45" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trend0" position="82,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="92,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate0" position="92,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel0" position="148,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend1" position="537,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="547,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate1" position="547,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel1" position="603,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend2" position="992,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1002,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate2" position="1002,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel2" position="1058,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend3" position="1447,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1457,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate3" position="1457,730" size="48,28" font="Regular;14" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel3" position="1513,723" size="330,42" font="Regular;16" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="rank0" position="94,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank1" position="549,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank2" position="1004,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank3" position="1459,565" size="80,60" font="Regular;47" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trendSelector" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_410x210.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="latestTitle" position="80,772" size="720,45" font="Regular;32" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="latestCategoryName" position="80,772" size="1000,45" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="8" />
	<widget name="latest0" position="82,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="88,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate0" position="88,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel0" position="142,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest1" position="297,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="303,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate1" position="303,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel1" position="357,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest2" position="512,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="518,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate2" position="518,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel2" position="572,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest3" position="727,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="733,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate3" position="733,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel3" position="787,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest4" position="942,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="948,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate4" position="948,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel4" position="1002,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest5" position="1157,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1163,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate5" position="1163,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel5" position="1217,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest6" position="1372,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1378,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate6" position="1378,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel6" position="1432,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest7" position="1587,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1593,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate7" position="1593,998" size="48,28" font="Regular;13" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel7" position="1647,992" size="100,38" font="Regular;12" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latestSelector" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_170x205.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="footer" position="85,1042" size="1750,35" font="Regular;20" foregroundColor="#D4D7DD" backgroundColor="#00000000" transparent="1" halign="center" zPosition="3" />
	<widget name="actionButtons" position="85,1041" size="1750,38" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_action_buttons_r115.png" alphatest="blend" zPosition="4" />
</screen>'''

CONTENT_HOME = scale_skin(CONTENT_HOME)

CONTENT_HOME_ACCESSIBILITY = '''<screen name="ContentHomeScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#181b20">
<eLabel position="0,0" size="1920,1080" backgroundColor="#181b20" zPosition="0" />
<widget name="hero" position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,520" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_overlay.png" alphatest="blend" zPosition="2" />
<widget name="top0" position="60,35" size="150,52" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top1" position="220,35" size="130,52" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top2" position="360,35" size="120,52" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top3" position="490,35" size="150,52" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top4" position="650,35" size="180,52" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top5" position="840,35" size="300,52" font="Regular;31" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="top6" position="1150,35" size="180,52" font="Regular;37" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="topSelector" position="45,79" size="180,8" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/nav_gold.png" alphatest="blend" zPosition="9" />
<widget name="clock" position="1640,42" size="190,40" font="Regular;35" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="right" zPosition="4" />
<ePixmap position="1500,398" size="300,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/hero_logo_badge_wide.png" alphatest="blend" zPosition="5" />
<widget name="logoHintIcon" position="1522,420" size="44,44" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/logo_hint_icon.png" alphatest="blend" zPosition="6" />
<widget name="logoHint" position="1580,410" size="190,64" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="logoImage" position="1520,412" size="260,60" alphatest="blend" zPosition="7" />
<widget name="logoTitle" position="95,145" size="840,100" font="Regular;56" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroMeta" position="100,265" size="820,40" font="Regular;30" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="heroDesc" position="100,320" size="820,110" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<ePixmap position="100,398" size="254,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/hero_play_c.png" alphatest="blend" zPosition="5" />
<widget name="heroPlay" position="112,410" size="230,64" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<ePixmap position="368,398" size="284,88" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/hero_info_c.png" alphatest="blend" zPosition="5" />
<widget name="heroInfo" position="380,410" size="260,64" font="Regular;28" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendingTitle" position="80,500" size="720,45" font="Regular;34" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trend0" position="82,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="92,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate0" position="92,730" size="48,28" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel0" position="148,723" size="330,42" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend1" position="537,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="535,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="547,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate1" position="547,730" size="48,28" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel1" position="603,723" size="330,42" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend2" position="992,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="990,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1002,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate2" position="1002,730" size="48,28" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel2" position="1058,723" size="330,42" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="trend3" position="1447,557" size="406,206" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1445,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_410x210.png" alphatest="blend" zPosition="3" />
<ePixmap position="1457,730" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="trendRate3" position="1457,730" size="48,28" font="Regular;17" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="trendLabel3" position="1513,723" size="330,42" font="Regular;19" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
<widget name="rank0" position="94,565" size="80,60" font="Regular;40" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank1" position="549,565" size="80,60" font="Regular;40" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank2" position="1004,565" size="80,60" font="Regular;40" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rank3" position="1459,565" size="80,60" font="Regular;40" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="trendSelector" position="80,555" size="410,210" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_410x210.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="latestTitle" position="80,772" size="720,45" font="Regular;32" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="latestCategoryName" position="80,772" size="1000,45" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="8" />
	<widget name="latest0" position="82,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="88,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate0" position="88,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel0" position="142,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest1" position="297,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="295,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="303,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate1" position="303,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel1" position="357,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest2" position="512,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="510,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="518,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate2" position="518,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel2" position="572,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest3" position="727,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="725,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="733,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate3" position="733,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel3" position="787,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest4" position="942,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="940,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="948,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate4" position="948,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel4" position="1002,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest5" position="1157,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1155,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1163,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate5" position="1163,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel5" position="1217,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest6" position="1372,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1370,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1378,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate6" position="1378,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel6" position="1432,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latest7" position="1587,827" size="166,201" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="2" scale="1" />
<ePixmap position="1585,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_170x205.png" alphatest="blend" zPosition="3" />
<ePixmap position="1593,998" size="48,28" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_rating_badge_r74_48x28.png" alphatest="blend" zPosition="5" />
<widget name="latestRate7" position="1593,998" size="48,28" font="Regular;16" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="6" />
<widget name="latestLabel7" position="1647,992" size="100,38" font="Regular;15" foregroundColor="#F7FBFF" backgroundColor="#00000000" transparent="1" halign="left" valign="center" zPosition="6" />
	<widget name="latestSelector" position="80,825" size="170,205" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_170x205.png" alphatest="blend" zPosition="8" scale="1" />
	<widget name="footer" position="-10,-10" size="1,1" font="Regular;4" transparent="1" />
	<widget name="actionButtons" position="-10,-10" size="1,1" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/content_action_buttons_r115.png" alphatest="blend" zPosition="1" />
    <eLabel position="95,1026" size="282,48" backgroundColor="#D9363E" cornerRadius="7" zPosition="12" />
    <eLabel position="99,1030" size="274,40" text="RED  PREVIOUS" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#10151B" halign="center" valign="center" cornerRadius="5" zPosition="13" />
    <eLabel position="390,1026" size="282,48" backgroundColor="#2587D8" cornerRadius="7" zPosition="12" />
    <eLabel position="394,1030" size="274,40" text="BLUE  NEXT" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#10151B" halign="center" valign="center" cornerRadius="5" zPosition="13" />
    <eLabel position="685,1026" size="282,48" backgroundColor="#2E9B57" cornerRadius="7" zPosition="12" />
    <eLabel position="689,1030" size="274,40" text="GREEN  CATEGORIES" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#10151B" halign="center" valign="center" cornerRadius="5" zPosition="13" />
    <eLabel position="980,1026" size="282,48" backgroundColor="#D49A16" cornerRadius="7" zPosition="12" />
    <eLabel position="984,1030" size="274,40" text="YELLOW  SORT" font="Regular;26" foregroundColor="#FFFBEA" backgroundColor="#10151B" halign="center" valign="center" cornerRadius="5" zPosition="13" />
    <eLabel position="1275,1026" size="282,48" backgroundColor="#27A9C1" cornerRadius="7" zPosition="12" />
    <eLabel position="1279,1030" size="274,40" text="MENU  FAVORITE" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#10151B" halign="center" valign="center" cornerRadius="5" zPosition="13" />
    <eLabel position="1570,1026" size="255,48" backgroundColor="#7F8A94" cornerRadius="7" zPosition="12" />
    <eLabel position="1574,1030" size="247,40" text="EXIT  BACK" font="Regular;26" foregroundColor="#FFFFFF" backgroundColor="#10151B" halign="center" valign="center" cornerRadius="5" zPosition="13" />
</screen>'''
CONTENT_HOME_ACCESSIBILITY = scale_skin(CONTENT_HOME_ACCESSIBILITY)

CATEGORY_POPUP = '''<screen name="ServerCategoryList" position="300,120" size="1320,840" flags="wfNoBorder" backgroundColor="#071A2B">
<widget name="panel" position="0,0" size="1320,840" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/category_popup_panel_r67.png" alphatest="blend" zPosition="0" />
<widget name="brand" position="28,28" size="230,48" font="Regular;35" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="brandTagline" position="31,78" size="220,26" font="Regular;15" foregroundColor="#6DD8FF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideTitle" position="28,150" size="230,32" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="sideText" position="28,192" size="230,120" font="Regular;24" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="packageLogo" position="30,380" size="220,84" alphatest="blend" zPosition="4" />
<widget name="sectionBadge" position="42,696" size="196,35" font="Regular;19" foregroundColor="#FFFFFF" backgroundColor="#0D324A" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="sideHint" position="40,778" size="200,22" font="Regular;15" foregroundColor="#B8CDE0" backgroundColor="#00000000" transparent="1" halign="center" valign="center" zPosition="2" />
<widget name="title" position="350,26" size="700,46" font="Regular;38" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="subtitle" position="350,74" size="650,28" font="Regular;26" foregroundColor="#E8EDF3" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="count" position="1030,38" size="225,34" font="Regular;24" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" halign="right" valign="center" zPosition="2" />
<widget name="listHeader" position="367,134" size="400,25" font="Regular;27" foregroundColor="#F1C84C" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="list" position="350,192" size="890,472" font="Regular;27" itemHeight="58" scrollbarMode="showOnDemand" backgroundColor="#0A2134" foregroundColor="#F5F8FC" selectionBackgroundColor="#E8B83F" selectionForegroundColor="#071A2B" zPosition="2" />
<widget name="keys" position="350,720" size="910,62" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" zPosition="2" />
<widget name="actionButtons" position="350,733" size="910,62" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/category_popup_buttons_r67.png" alphatest="blend" zPosition="3" />
</screen>'''

CATEGORY_POPUP = scale_skin(CATEGORY_POPUP)

class ServerCategoryList(Screen):
    skin = CATEGORY_POPUP
    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self.source, self.kind = source, kind
        self.rows = []
        is_movies = kind == "vod"
        self["panel"] = Pixmap()
        self["brand"] = Label(tr("TiViMate"))
        self["brandTagline"] = Label(tr("IPTV EXPERIENCE"))
        self["sideTitle"] = Label(tr("YOUR LIBRARY"))
        self["sideText"] = Label(tr("Choose a collection\nto browse titles from\nyour selected server."))
        self["sectionBadge"] = Label(tr("MOVIES") if is_movies else tr("TV SHOWS"))
        self["sideHint"] = Label(tr("Press OK to open"))
        self["packageLogo"] = Pixmap()
        self["title"] = Label(tr("MOVIE CATEGORIES") if is_movies else tr("TV SHOW CATEGORIES"))
        self["subtitle"] = Label(tr("Browse the collections available on your server"))
        self["count"] = Label(tr("LOADING COLLECTIONS"))
        self["listHeader"] = Label(tr("AVAILABLE COLLECTIONS"))
        self["list"] = MenuList([])
        self["keys"] = Label("")
        self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions"], {
            "ok": self.choose, "cancel": self.close, "up": self.up, "down": self.down,
            "pageUp": self.pageUp, "pageDown": self.pageDown
        }, -1)
        self._categoryLoadToken = 0
        self._categoryLoadResult = None
        self._categoryLoadTimer = eTimer()
        self._packageLogoTimer = eTimer()
        try:
            self._packageLogoTimer_conn = self._packageLogoTimer.timeout.connect(self._updatePackageLogo)
        except Exception:
            try:
                self._packageLogoTimer.callback.append(self._updatePackageLogo)
            except Exception:
                self._packageLogoTimer.timeout.get().append(self._updatePackageLogo)
        try:
            self._categoryLoadTimer_conn = self._categoryLoadTimer.timeout.connect(self._finishCategoryLoad)
        except Exception:
            try:
                self._categoryLoadTimer.callback.append(self._finishCategoryLoad)
            except Exception:
                self._categoryLoadTimer.timeout.get().append(self._finishCategoryLoad)
        try:
            self["list"].onSelectionChanged.append(self._updatePackageLogo)
        except Exception:
            pass
        self.onLayoutFinish.append(self.load)

    def load(self):
        self._categoryLoadToken += 1
        token = self._categoryLoadToken
        source = dict(self.source)
        kind = self.kind
        self._categoryLoadResult = None
        self["count"].setText(tr("LOADING COLLECTIONS"))

        def worker():
            try:
                cats, origin = get_cached_categories(source, kind, get_source_client(source), wait_for_server=True)
                cats = filter_categories(source, kind, cats or [])
                rows = [(entry.get("category_name") or "Other", str(entry.get("category_id") or "")) for entry in cats]
                result = (token, rows, origin, "")
            except Exception as exc:
                result = (token, [], "error", str(exc))
            self._categoryLoadResult = result

        _submit_content_bg(worker, key=("category-popup", id(self)))
        try:
            self._categoryLoadTimer.start(100, False)
        except Exception:
            pass

    def _finishCategoryLoad(self):
        result = self._categoryLoadResult
        if not result:
            try:
                self._categoryLoadTimer.start(100, False)
            except Exception:
                pass
            return
        self._categoryLoadResult = None
        token, rows, origin, error = result
        if token != self._categoryLoadToken:
            return
        if error:
            self["title"].setText(tr("UNABLE TO LOAD CATEGORIES"))
            self["subtitle"].setText(tr("Check the selected server and try again"))
            self["count"].setText(tr("NO COLLECTIONS"))
            self["keys"].setText(error[:120])
            return
        self.rows = rows or []
        self["list"].setList(self.rows)
        self._updatePackageLogo()
        try:
            self._packageLogoTimer.start(120, True)
        except Exception:
            pass
        count = len(self.rows)
        self["count"].setText("%d COLLECTION%s" % (count, "" if count == 1 else "S"))
        if not count:
            self["subtitle"].setText(tr("No enabled collections are available for this server"))


    def _packageBrand(self, name):
        text = str(name or "").strip().lower()
        compact = re.sub(r"[^a-z0-9+]+", "", text)
        normalized = re.sub(r"[^a-z0-9+]+", " ", text)
        tokens = set(normalized.split())

        if ("netflix" in text or "netflix" in tokens or
                "nfx" in tokens or compact.startswith("nfx")):
            return "package_netflix.png"

        if ("amazon prime" in text or "amazonprime" in compact or
                "prime video" in text or "primevideo" in compact or
                "prime" in tokens or "amazon" in tokens or
                "amzn" in tokens or "amz" in tokens):
            return "package_prime.png"

        if ("disney+" in text or "disneyplus" in compact or
                "disney" in tokens or "dsnp" in tokens):
            return "package_disney.png"

        if ("hbo max" in text or "hbomax" in compact or
                "hbo" in tokens or "max" in tokens):
            return "package_max.png"

        if ("apple tv+" in text or "appletv+" in compact or
                "apple tv" in text or "appletv" in compact):
            return "package_apple.png"

        if ("paramount+" in text or "paramountplus" in compact or
                "paramount" in tokens or "pmt+" in text):
            return "package_paramount.png"

        return ""



    def _updatePackageLogo(self):
        try:
            current = self["list"].getCurrent()
            name = current[0] if current else ""
            logo = self._packageBrand(name)
            if not logo:
                self["packageLogo"].hide()
                return

            path = os.path.join(PLUGIN_PATH, "skins", logo)
            if not os.path.exists(path):
                self["packageLogo"].hide()
                return

            widget = self["packageLogo"]
            try:
                if widget.instance:
                    widget.instance.setPixmapFromFile(path)
            except Exception:
                pass
            widget.show()
        except Exception:
            try:
                self["packageLogo"].hide()
            except Exception:
                pass


    def choose(self):
        current = self["list"].getCurrent()
        if current:
            self.close({"name": current[0], "id": current[1]})

    def up(self):
        self["list"].up()
        self._updatePackageLogo()

    def down(self):
        self["list"].down()
        self._updatePackageLogo()

    def pageUp(self):
        try: self["list"].pageUp()
        except Exception: self["list"].up()
        self._updatePackageLogo()

    def pageDown(self):
        try: self["list"].pageDown()
        except Exception: self["list"].down()
        self._updatePackageLogo()


MOVIE_DETAILS = '''<screen name="MovieDetailsScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#17191D">
<eLabel position="0,0" size="1920,1080" backgroundColor="#17191D" zPosition="0" />
<widget name="backdrop" position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="1" />
<ePixmap position="0,0" size="1920,1080" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/details_overlay.png" alphatest="blend" zPosition="2" />
<widget name="poster" position="65,55" size="350,525" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_placeholder.png" alphatest="blend" zPosition="3" scale="1" />
<widget name="providerLogo" position="115,590" size="250,62" alphatest="blend" zPosition="12" />
<widget name="title" position="475,70" size="1040,76" font="Regular;52" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="meta" position="480,155" size="1050,42" font="Regular;24" foregroundColor="#D8DDE5" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="desc" position="480,215" size="1000,190" font="Regular;25" foregroundColor="#F2F4F7" backgroundColor="#00000000" transparent="1" zPosition="4" />
	<widget name="watch" position="480,425" size="270,62" font="Regular;27" foregroundColor="#17191D" backgroundColor="#E8B83F" halign="center" valign="center" zPosition="5" />
	<widget name="sources" position="770,425" size="270,62" font="Regular;24" foregroundColor="#FFFFFF" backgroundColor="#315976" halign="center" valign="center" zPosition="5" />
	<widget name="buttonSelector" position="475,415" size="280,82" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/details_action_selector_r68.png" alphatest="blend" zPosition="6" />
<widget name="actorsTitle" position="475,520" size="500,40" font="Regular;29" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="actor0" position="480,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="480,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel0" position="445,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor1" position="690,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="690,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel1" position="655,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor2" position="900,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="900,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel2" position="865,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor3" position="1110,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="1110,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel3" position="1075,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor4" position="1320,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="1320,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel4" position="1285,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="actor5" position="1530,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_placeholder.png" alphatest="blend" zPosition="3" />
<ePixmap position="1530,575" size="120,120" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/actor_mask.png" alphatest="blend" zPosition="4" />
<widget name="actorLabel5" position="1495,700" size="190,66" font="Regular;18" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" halign="center" valign="top" zPosition="5" />
<widget name="recommendTitle" position="65,795" size="500,42" font="Regular;30" foregroundColor="#FFFFFF" backgroundColor="#00000000" transparent="1" zPosition="4" />
<widget name="rec0" position="65,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel0" position="65,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="65,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec1" position="430,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel1" position="430,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="430,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec2" position="795,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel2" position="795,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="795,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec3" position="1160,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel3" position="1160,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="1160,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
<widget name="rec4" position="1525,845" size="330,150" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/banner_placeholder.jpg" alphatest="blend" zPosition="3" />
<widget name="recLabel4" position="1525,995" size="330,48" font="Regular;20" foregroundColor="#FFFFFF" backgroundColor="#00000000" halign="center" valign="center" zPosition="4" transparent="1" />
<ePixmap position="1525,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_shell_r75_330x198.png" alphatest="blend" zPosition="5" />
	<widget name="recSelector" position="65,845" size="330,198" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/poster_card_focus_r75_330x198.png" alphatest="blend" zPosition="8" scale="1" />
</screen>'''

MOVIE_DETAILS = scale_skin(MOVIE_DETAILS)

class MovieDetailsScreen(Screen):
    skin = MOVIE_DETAILS
    REC_X = [65, 430, 795, 1160, 1525]
    def __init__(self, session, source, item, server_items=None):
        Screen.__init__(self, session)
        self.source = source
        self.item = item or {}
        self._serverPackageProvider = str(self.item.get("_server_package_provider") or self.item.get("_tmdb_provider") or "")
        self.server_items = server_items or []
        self._sourceTitleIndex = None
        self.sources_list = []
        self.recommendations = []
        self._primaryArtworkReady = False
        self._watchResolveStarted = False
        self._watchReady = bool(self.item.get("stream_id") or self.item.get("vod_id"))
        self._sourcesSearchRunning = False
        self._sourcesSearchDone = False
        self._fastVodRowsCache = None
        self._fullVodRowsCache = None
        self._vodSelectedSource = dict(self.source or {})
        self.focus = "buttons"
        self.button_index = 0
        self.rec_index = 0
        self.downloads, self.picloads = [], []
        self._detail_pixmap_keys = set()
        self._image_requests = {}
        # Worker threads never touch Enigma2 widgets directly.  A small GUI
        # poller drains completed work on the main thread; the workers only
        # append plain Python call records to this queue.  This remains safe on
        # Python 3 Enigma2 and does not depend on Twisted reactor integration.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        self["backdrop"] = Pixmap(); self["poster"] = Pixmap()
        self["providerLogo"] = Pixmap()
        self["title"] = Label(self.item.get("name") or self.item.get("title") or "Movie")
        self["meta"] = Label(""); self["desc"] = Label(tr("Loading details..."))
        self["watch"] = Label(tr("▶  Watch") if self._watchReady else tr("Searching...")); self["sources"] = Label(tr("Press for Other Sources"))
        self["buttonSelector"] = Pixmap(); self["actorsTitle"] = Label(tr("Actors"))
        for i in range(6):
            self["actor%d" % i] = Pixmap()
            self["actorLabel%d" % i] = Label("")
        self["recommendTitle"] = Label(tr("Recommendations"))
        for i in range(5):
            self["rec%d" % i] = Pixmap(); self["recLabel%d" % i] = Label("")
        self["recSelector"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "ok": self.ok, "cancel": self.close, "left": self.left, "right": self.right,
            "up": self.up, "down": self.down, "red": self.toggleFavourite, "green": self.watchSelected
        }, -1)
        self.onLayoutFinish.append(self._startGuiDispatch)
        self.onLayoutFinish.append(self._updateProviderLogo)
        self.onLayoutFinish.append(self.start)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkMemory)


    def _updateProviderLogo(self):
        try:
            provider = str((self.item or {}).get("_server_package_provider") or (self.item or {}).get("_tmdb_provider") or self._serverPackageProvider or "").strip().lower()
            files = {
                "netflix": "provider_netflix.png",
                "prime": "provider_prime.png",
                "prime_video": "provider_prime.png",
                "disney": "package_disney.png",
                "max": "package_max.png",
                "apple": "package_apple.png",
                "paramount": "package_paramount.png",
            }
            filename = files.get(provider, "")
            path = os.path.join(PLUGIN_PATH, "skins", filename) if filename else ""
            if path and os.path.exists(path):
                self["providerLogo"].instance.setPixmapFromFile(path)
                self["providerLogo"].show()
            else:
                self["providerLogo"].hide()
        except Exception:
            try: self["providerLogo"].hide()
            except Exception: pass


    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(40, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(40, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _releaseArtworkMemory(self):
        # The local widgets are destroyed with the screen; release the LRU refs
        # too so large backdrops never accumulate between detail pages.
        self._image_requests = {}
        self.downloads = []
        self.picloads = []
        for key in list(getattr(self, "_detail_pixmap_keys", set())):
            try:
                _DETAILS_PIXMAP_CACHE.pop(key, None)
            except Exception:
                pass
        self._detail_pixmap_keys = set()


    def _deferredServerMatch(self):
        """Resolve a TMDb discovery movie only after its details screen opens."""
        wanted_id = str(self.item.get("tmdb_id") or self.item.get("id") or "").strip()
        wanted = [self._title_norm(self.item.get(field)) for field in ("name", "title", "original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)

        def row_tmdb_id(row):
            row = row or {}
            for mapping in (row, row.get("info") if isinstance(row.get("info"), dict) else {}):
                for key in ("tmdb_id", "tmdb", "tmdbid"):
                    value = mapping.get(key)
                    if value not in (None, ""):
                        try:
                            return str(int(value))
                        except Exception:
                            value = str(value).strip()
                            if value:
                                return value
            return ""

        def match_rows(rows):
            if wanted_id:
                for row in rows or []:
                    if row_tmdb_id(row) == wanted_id:
                        return dict(row)
            best = None
            best_score = 0.0
            for row in rows or []:
                row_year = self._year(row)
                if target_year and row_year and target_year != row_year:
                    continue
                candidates = [self._title_norm((row or {}).get(field)) for field in ("name", "title", "original_title")]
                score = max([self._title_score(a, b) for a in wanted for b in candidates] or [0.0])
                if target_year and row_year:
                    if score < 0.94:
                        continue
                elif score < 0.98:
                    continue
                if score > best_score:
                    best, best_score = dict(row), score
            return best

        # First use the already loaded full Xtream catalogue / warmed Home index.
        match = match_rows(self.server_items or [])
        if match:
            return match

        source = dict(self._vodSelectedSource or {})
        try:
            client = get_source_client(source)
            if source.get("type") == "xtream":
                rows = list(get_filtered_streams(source, "vod", client) or [])
                return match_rows(rows)
            if source.get("type") == "stalker":
                categories, _origin = get_cached_categories(source, "vod", client=client, wait_for_server=True)
                categories = filter_categories(source, "vod", categories or [])
                for category in categories:
                    category_id = str((category or {}).get("category_id") or "")
                    if not category_id:
                        continue
                    rows, _origin = get_category_streams(
                        source, "vod", client, category_id,
                        use_cache=True, wait_for_server=True
                    )
                    match = match_rows(rows or [])
                    if match:
                        return match
        except Exception:
            pass
        return None



    def _loadDeferredTmdbMovie(self):
        self.loadDetails()



    def start(self):
        self.applyInitialDetails()
        if self._watchReady:
            self._setWatchReady()
        else:
            self._setWatchSearching()
        self.updateFocus()
        # Artwork/details first. No provider-wide Watch/Sources scan here.
        t = threading.Thread(target=self.loadDetails, name="TiviMateMovieDetails")
        t.daemon = True
        t.start()


    def applyInitialDetails(self):
        title = self.item.get("name") or self.item.get("title") or "Movie"
        year = str(self.item.get("releaseDate") or self.item.get("release_date") or self.item.get("year") or "")[:4]
        rating = self.item.get("rating") or self.item.get("vote_average") or self.item.get("rating_5based") or ""
        genre = self.item.get("genre") or ""
        self["title"].setText(title)
        rating_text = ""
        if rating not in (None, ""):
            try:
                rating_text = "★ %.1f" % float(rating)
            except Exception:
                rating_text = "★ %s" % rating
        self["meta"].setText("  •  ".join(x for x in [year, rating_text, str(genre)] if x))
        self["desc"].setText((self.item.get("plot") or self.item.get("description") or "")[:700])
        poster = _server_poster_url(self.source, self.item)
        backdrop = self._norm(self.item.get("backdrop_path") or self.item.get("backdrop") or self.item.get("backdrop_url"), "w1280")
        if poster:
            self.loadImage(poster, "poster", 350, 525)
        if backdrop:
            self.loadImage(backdrop, "backdrop", 1920, 1080)

    def _norm(self, value, size="w1280"):
        if isinstance(value, list): value = value[0] if value else ""
        if not isinstance(value, str): return ""
        value = value.strip().replace("\\/", "/")
        if value.startswith("/"): value = "https://image.tmdb.org/t/p/%s%s" % (size, value)
        return value


    def _title_norm(self, value):
        # Normalize movie titles across provider packages. Package branding,
        # quality/language tags and year must never stop the same movie matching.
        text = str(value or "").lower().replace("&", " and ")
        text = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", text)

        # Strip common platform/package labels first.
        text = re.sub(r"\bamazon\s+prime(?:\s+video)?\b", " ", text)
        text = re.sub(r"\bprime\s+video\b", " ", text)
        text = re.sub(r"\bapple\s+tv\+?\b", " ", text)
        text = re.sub(r"\bdisney\+?\b", " ", text)
        text = re.sub(r"\bhbo\s+max\b", " ", text)
        text = re.sub(r"\bparamount\+?\b", " ", text)
        text = re.sub(r"\bnetflix\b", " ", text)

        text = re.sub(
            r"\b(nf|amz|amzn|ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|8k|uhd|fhd|hd|sd|"
            r"hevc|x265|x264|hdr|web[- ]?dl|bluray|brrip|webrip|remux|top|"
            r"2160p|1080p|720p|576p|480p|vod|movies?)\b",
            " ", text
        )
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
        return " ".join(text.split())


    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _title_score(self, wanted, candidate):
        """Return a score only for genuinely matching release titles."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens, candidate_tokens = set(wanted.split()), set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0
        # Partial title containment is safe only when every significant token matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94
        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0

    def _playable_item(self):
        if self.item.get("stream_id"):
            return self.item
        return self.sources_list[0] if self.sources_list else None


    def _fullServerVodCatalog(self):
        """Return the complete movie catalog for Other Sources on this server."""
        source = dict(self._vodSelectedSource or {})
        client = get_source_client(source)
        rows = []

        if source.get("type") == "xtream":
            # One provider-wide request includes every VOD package/category.
            try:
                rows = list(client.streams("vod") or [])
            except Exception:
                rows = list(get_filtered_streams(source, "vod", client) or [])

        elif source.get("type") == "stalker":
            # Search every real VOD package. Do not restrict to the package
            # from which the details screen was opened.
            try:
                categories = list(client.categories("vod") or [])
            except Exception:
                categories = []

            for category in categories:
                cid = str((category or {}).get("category_id") or
                          (category or {}).get("id") or "").strip()
                if not cid:
                    continue
                try:
                    cat_rows, _origin = get_category_streams(
                        source, "vod", client, cid,
                        use_cache=True, wait_for_server=True
                    )
                    rows.extend(list(cat_rows or []))
                except Exception:
                    try:
                        rows.extend(list(client.streams("vod", cid) or []))
                    except Exception:
                        pass

            if not rows:
                try:
                    rows = list(get_filtered_streams(source, "vod", client) or [])
                except Exception:
                    rows = []
        else:
            try:
                rows = list(get_filtered_streams(source, "vod", client) or [])
            except Exception:
                rows = []

        # Deduplicate provider rows while preserving provider/category order.
        out = []
        seen = set()
        for row in rows:
            if not isinstance(row, dict):
                continue
            sid = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            key = sid or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if key in seen:
                continue
            seen.add(key)
            out.append(dict(row))
        return out


    def _matchingServerSources(self, rows, exclude_primary=True):
        title_fields = ("name", "title", "original_title")
        wanted = [self._title_norm(self.item.get(field)) for field in title_fields]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        primary_id = str(self.item.get("stream_id") or self.item.get("vod_id") or "")
        matches, seen = [], set()

        for row in rows or []:
            row_id = str(row.get("stream_id") or row.get("vod_id") or row.get("id") or "")
            if exclude_primary and primary_id and row_id and row_id == primary_id:
                continue
            unique = row_id or (
                self._title_norm(row.get("name") or row.get("title") or ""),
                str(row.get("category_id") or ""),
                str(row.get("container_extension") or "")
            )
            if unique in seen:
                continue
            candidate_titles = [self._title_norm(row.get(field)) for field in title_fields]
            score = max([self._title_score(w, c) for w in wanted for c in candidate_titles] or [0.0])
            if score < 0.90:
                continue
            row_year = self._year(row)
            if target_year and row_year and abs(target_year-row_year) > 1:
                continue
            matches.append((score, 1 if target_year and row_year == target_year else 0, dict(row)))
            seen.add(unique)

        matches.sort(key=lambda value: (value[0], value[1]), reverse=True)
        return [value[2] for value in matches]


    def _buildSourceTitleIndex(self):
        """Index server rows by normalized title once, avoiding a full fuzzy scan every time."""
        if self._sourceTitleIndex is not None:
            return self._sourceTitleIndex
        index = {}
        for row in self.server_items:
            try:
                seen = set()
                for field in ("name", "title", "original_title"):
                    norm = self._title_norm(row.get(field))
                    if norm and norm not in seen:
                        seen.add(norm)
                        index.setdefault(norm, []).append(row)
            except Exception:
                continue
        self._sourceTitleIndex = index
        return index


    def findSources(self):
        try:
            rows = self._fullServerVodCatalog()
            sources = self._matchingServerSources(rows)

            # Keep a complete warmed catalog for Watch/Recommendations too.
            if rows:
                self.server_items = list(rows)
                self._sourceTitleIndex = None

            # Other Sources means alternate copies only; current playable item
            # is excluded by _matchingServerSources().
            self._queueGui(self.applySources, sources[:24])
        except Exception:
            self._queueGui(self.applySources, [])





    def applySources(self, sources):
        self.sources_list = list(sources or [])
        count = len(self.sources_list)
        if count:
            self["sources"].setText("Other Sources (%d)" % count)
        else:
            self["sources"].setText(tr("No Other Sources"))


    def loadDetails(self):
        try:
            # Recent Movies entries are often lightweight rows from get_vod_streams.
            # Enrich only that route with get_vod_info before resolving TMDb.
            if self.item.get("_recent_home"):
                sid = self.item.get("stream_id") or self.item.get("vod_id")
                if sid:
                    try:
                        raw = get_source_client(self.source).vod_info(sid) or {}
                        merged = dict(self.item)
                        if isinstance(raw.get("movie_data"), dict): merged.update(raw.get("movie_data") or {})
                        if isinstance(raw.get("info"), dict): merged.update(raw.get("info") or {})
                        # Playback identity must always remain from the original row.
                        merged["stream_id"] = self.item.get("stream_id") or merged.get("stream_id") or sid
                        merged["container_extension"] = self.item.get("container_extension") or merged.get("container_extension") or "mp4"
                        merged["_recent_home"] = True
                        self.item = merged
                    except Exception:
                        pass
            tmdb = TMDbClient()
            raw_title = self.item.get("name") or self.item.get("title") or self.item.get("original_title") or ""
            item_year = self._year(self.item) or None
            provider_tid = self.item.get("tmdb_id") or self.item.get("tmdb")
            tid = provider_tid
            data = {}

            # Provider TMDb IDs are not always valid. Try them once, but if the
            # result is empty/incomplete resolve the globally-cleaned title and
            # use that single ID for ALL detail enrichment.
            if tid:
                try:
                    data = tmdb.details_bundle(tid, "vod") or {}
                except Exception:
                    data = {}

            useful = bool(
                data.get("poster_path") or data.get("backdrop_path") or data.get("overview") or
                ((data.get("credits") or {}).get("cast") or []) or
                ((data.get("recommendations") or {}).get("results") or []) or
                ((data.get("similar") or {}).get("results") or [])
            )

            found = None
            if not useful and raw_title:
                found = tmdb.search_title(raw_title, "vod", item_year)
                if not found:
                    found = tmdb.search_title(raw_title, "vod", None)
                tid = (found or {}).get("id") or tid
                if tid and str(tid) != str(provider_tid or ""):
                    data = tmdb.details_bundle(tid, "vod") or {}
                elif tid and not data:
                    data = tmdb.details_bundle(tid, "vod") or {}

            # Search result itself can still provide poster/backdrop/overview
            # while the full details call is temporarily unavailable.
            if found:
                seed = dict(found)
                seed.update(data or {})
                data = seed

            if tid:
                self.item["tmdb_id"] = str(tid)
            mem_key = "vod:%s" % str(tid or self._title_norm(raw_title))
            cached = _memory_get(_DETAILS_DATA_CACHE, mem_key)
            if cached:
                merged_cached = dict(cached)
                merged_cached.update(data or {})
                data = merged_cached
            elif data:
                _memory_put(_DETAILS_DATA_CACHE, mem_key, data, _DETAILS_DATA_CACHE_LIMIT)

            self._queueGui(self.applyDetails, data or {})
        except Exception:
            self._queueGui(self.applyDetails, {})


    def applyDetails(self, data):
        self._tmdb_bundle = dict(data or {})
        title = data.get("title") or self.item.get("name") or self.item.get("title") or "Movie"
        year = str(data.get("release_date") or self.item.get("releaseDate") or self.item.get("year") or "")[:4]
        rating = data.get("vote_average") or self.item.get("rating") or ""
        genres = ", ".join(x.get("name", "") for x in (data.get("genres") or [])[:3])
        runtime = data.get("runtime") or ""
        self["title"].setText(title)
        self["meta"].setText("  •  ".join(x for x in [year, ("★ %.1f" % float(rating)) if rating else "", genres, ("%s min" % runtime) if runtime else ""] if x))
        self["desc"].setText((data.get("overview") or self.item.get("plot") or self.item.get("description") or "No description available")[:700])
        tmdb_poster = self._norm(data.get("poster_path"), "w500")
        server_poster = _server_poster_url(self.source, self.item)
        tmdb_backdrop = self._norm(data.get("backdrop_path"), "w1280")
        server_backdrop = self._norm(self.item.get("backdrop_path") or self.item.get("backdrop") or self.item.get("backdrop_url"), "w1280")
        # Provider poster is authoritative and first. TMDb is only fallback.
        poster = server_poster or tmdb_poster
        backdrop = tmdb_backdrop or server_backdrop
        # Carry the same resolved artwork into the VOD player.  The player does
        # not perform a different title match when this page already resolved it.
        if poster:
            self.item["_player_cover"] = poster
            self.item["poster_path"] = poster
        if backdrop:
            self.item["_tmdb_backdrop"] = backdrop
        if data.get("id"):
            self.item["tmdb_id"] = str(data.get("id"))
        if data.get("title"):
            self.item["_tmdb_title"] = data.get("title")
        if poster:
            self.loadImage(
                poster, "poster", 350, 525,
                fallback_url=(tmdb_poster if server_poster and tmdb_poster and poster == server_poster else "")
            )
        else:
            self._primaryArtworkComplete()
        if backdrop:
            self.loadImage(backdrop, "backdrop", 1920, 1080, fallback_url=(server_backdrop if backdrop != server_backdrop else ""))
        cast = ((data.get("credits") or {}).get("cast") or [])[:6]
        for i in range(6):
            if i < len(cast):
                name = cast[i].get("name") or ""
                character = cast[i].get("character") or ""
                self["actorLabel%d" % i].setText((name + ("\n" + character if character else ""))[:45])
                profile = self._norm(cast[i].get("profile_path"), "w185")
                if profile: self.loadImage(profile, "actor%d" % i, 128, 128)
            else:
                self["actorLabel%d" % i].setText(tr(""))
        raw = ((data.get("recommendations") or {}).get("results") or [])[:5]
        if len(raw) < 5: raw += ((data.get("similar") or {}).get("results") or [])[:5-len(raw)]
        self.recommendations = [TMDbClient().convert_public(x, "vod") for x in raw[:5]]
        for i in range(5):
            item = self.recommendations[i] if i < len(self.recommendations) else None
            self["recLabel%d" % i].setText((item.get("name") or "")[:34] if item else "")
            if item:
                # Recommendations frequently have no backdrop. Use the poster as
                # a reliable fallback instead of leaving an empty card.
                url = self._norm(item.get("backdrop_path") or item.get("stream_icon") or item.get("cover"), "w780")
                if url: self.loadImage(url, "rec%d" % i, 330, 150)
        self.updateFocus()

    def loadImage(self, url, widget, width, height, fallback_url="", retry=1):
        """Render detail artwork reliably: primary URL, one retry, then fallback."""
        url = (url or "").strip().replace("\\/", "/")
        fallback_url = (fallback_url or "").strip().replace("\\/", "/")
        if not url:
            if fallback_url:
                return self.loadImage(fallback_url, widget, width, height, fallback_url="", retry=0)
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        token = "%s|%s" % (widget, url)
        requests[widget] = token
        priority = 100 if widget in ("poster", "backdrop") else 45

        def done(path, w=widget, x=width, y=height, expected=token):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            key = "%s|%sx%s" % (path, x, y)
            self.decode(path, w, x, y, key)

        def failed(_path, w=widget, primary=url, fb=fallback_url, retries=retry):
            if getattr(self, "_image_requests", {}).get(w) != token:
                return
            if retries > 0:
                # One controlled retry only. request_artwork keeps cache/dedup logic.
                self.loadImage(primary, w, width, height, fallback_url=fb, retry=retries - 1)
            elif fb and fb != primary:
                self.loadImage(fb, w, width, height, fallback_url="", retry=0)

        request_artwork(url, "details", done, priority=priority, errback=failed)

    def _setWatchSearching(self):
        try:
            self["watch"].setText(tr("Searching..."))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#E8B83F"))
                self["watch"].instance.setForegroundColor(parseColor("#17191D"))
        except Exception:
            pass

    def _setWatchReady(self):
        try:
            self["watch"].setText(tr("▶  Watch"))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#2E9D57"))
                self["watch"].instance.setForegroundColor(parseColor("#FFFFFF"))
        except Exception:
            pass

    def _setWatchUnavailable(self):
        try:
            self["watch"].setText(tr("Watch unavailable"))
            if self["watch"].instance:
                self["watch"].instance.setBackgroundColor(parseColor("#555B63"))
                self["watch"].instance.setForegroundColor(parseColor("#FFFFFF"))
        except Exception:
            pass

    def _setSourcesSearching(self):
        try:
            self["sources"].setText(tr("Searching Sources..."))
        except Exception:
            pass



    def _primaryArtworkComplete(self):
        if self._primaryArtworkReady:
            return
        self._primaryArtworkReady = True
        if self._watchReady:
            self._setWatchReady()
            return
        self._startWatchResolve()




    def _fastSearchMovieRows(self):
        """Fast first pass: only the filtered/enabled Search catalog."""
        if self._fastVodRowsCache is not None:
            return list(self._fastVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or {})
            client = XtreamClient(source) if source.get("type") == "xtream" else StalkerClient(source)
            rows = list(get_filtered_streams(source, "vod", client) or [])
        except Exception:
            rows = []
        self._fastVodRowsCache = list(rows or [])
        return list(self._fastVodRowsCache)


    def _fullServerMovieRowsFallback(self):
        """Slow fallback only when the filtered catalog did not find the movie."""
        if self._fullVodRowsCache is not None:
            return list(self._fullVodRowsCache)
        rows = []
        try:
            source = dict(self._vodSelectedSource or {})
            if source.get("type") == "xtream":
                client = XtreamClient(source)
                rows = list(client.streams("vod") or [])
            else:
                # Stalker keeps the existing filtered/cache route; avoid a
                # category-by-category scan unless explicitly needed elsewhere.
                client = StalkerClient(source)
                rows = list(get_filtered_streams(source, "vod", client) or [])
        except Exception:
            rows = []
        self._fullVodRowsCache = list(rows or [])
        return list(self._fullVodRowsCache)


    def _fastTitleCandidates(self, rows):
        raw_title = (
            self.item.get("_tmdb_title") or self.item.get("name") or
            self.item.get("title") or self.item.get("original_title") or ""
        )
        query = self._title_norm(raw_title)
        if not query:
            return []

        exact = []
        loose = []
        qtokens = [x for x in query.split() if len(x) > 1]

        for row in rows or []:
            name = self._title_norm(row.get("name") or row.get("title") or row.get("original_title") or "")
            if not name:
                continue
            if name == query:
                exact.append(row)
                continue
            ntokens = [x for x in name.split() if len(x) > 1]
            if query in name or name in query:
                loose.append(row)
                continue
            if qtokens and ntokens and all(token in ntokens for token in qtokens):
                loose.append(row)

        return exact + loose





    def _startWatchResolve(self):
        if self._watchResolveStarted or self._watchReady:
            return
        self._watchResolveStarted = True
        self._setWatchSearching()

        def worker():
            match = None
            try:
                # 1. Already loaded page/package data: essentially free.
                rows = list(self.server_items or [])
                candidates = self._fastTitleCandidates(rows)
                matches = self._matchingServerSources(candidates, exclude_primary=False)
                if matches:
                    match = matches[0]

                # 2. Enabled/filtered VOD catalog used by Search.
                if match is None:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]

                # 3. Full server VOD only when the fast filtered paths failed.
                if match is None:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    matches = self._matchingServerSources(candidates, exclude_primary=False)
                    if matches:
                        match = matches[0]
            except Exception:
                match = None

            def finish():
                self._watchResolveStarted = False
                if not match:
                    self._watchReady = False
                    self._setWatchUnavailable()
                    return
                original = dict(self.item or {})
                for key in (
                    "tmdb_id", "_tmdb_title", "backdrop_path", "rating",
                    "plot", "description", "year", "_home_tmdb_feed",
                    "_tmdb_provider", "_server_package_provider"
                ):
                    if not match.get(key) and original.get(key):
                        match[key] = original.get(key)
                self.item = match
                self._watchReady = True
                self._setWatchReady()
                try:
                    self._updateProviderLogo()
                except Exception:
                    pass

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateWatchFilteredFirst")
        t.daemon = True
        t.start()




    def _searchSourcesOnDemand(self):
        if self._sourcesSearchRunning:
            return
        if self._sourcesSearchDone:
            self.showSources()
            return

        self._sourcesSearchRunning = True
        self._setSourcesSearching()

        def worker():
            sources = []
            used_rows = []
            try:
                exclude_primary = bool(self.item.get("stream_id") or self.item.get("vod_id"))

                # 1. Existing warmed data.
                rows = list(self.server_items or [])
                if rows:
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows

                # 2. Filtered/enabled Search catalog.
                if not sources:
                    rows = self._fastSearchMovieRows()
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows

                # 3. Only if still zero, expand to full server VOD.
                if not sources:
                    rows = self._fullServerMovieRowsFallback()
                    candidates = self._fastTitleCandidates(rows)
                    sources = self._matchingServerSources(
                        candidates, exclude_primary=exclude_primary
                    )[:24]
                    used_rows = rows
            except Exception:
                sources = []

            def finish():
                self._sourcesSearchRunning = False
                self._sourcesSearchDone = True
                if used_rows:
                    self.server_items = list(used_rows)
                    self._sourceTitleIndex = None
                self.applySources(sources)
                self.showSources()

            self._queueGui(finish)

        t = threading.Thread(target=worker, name="TiviMateSourcesFilteredFirst")
        t.daemon = True
        t.start()


    def decode(self,path,widget,width,height,mem_key=None):
        key = mem_key or ("%s|%sx%s" % (path, width, height))
        ptr = _memory_get(_DETAILS_PIXMAP_CACHE, key)
        if ptr is not None:
            try:
                self._detail_pixmap_keys.add(key)
                if self[widget].instance: self[widget].instance.setPixmap(ptr)
                if widget == "poster":
                    self._primaryArtworkComplete()
                return
            except Exception:
                pass
        l=ePicLoad(); self.picloads.append(l)
        def ready(_=None,loader=l,w=widget,k=key):
            try:
                ptr=loader.getData()
                if ptr:
                    self._detail_pixmap_keys.add(k)
                    _memory_put(_DETAILS_PIXMAP_CACHE, k, ptr, _DETAILS_PIXMAP_CACHE_LIMIT)
                    if self[w].instance: self[w].instance.setPixmap(ptr)
                    if w == "poster":
                        self._primaryArtworkComplete()
            except Exception:
                pass
            try:
                if loader in self.picloads:
                    self.picloads.remove(loader)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(l, ready, self, oneshot=True); l.setPara((render_width,render_height,0,0,False,1,"#00000000")); l.startDecode(path)

    def updateFocus(self):
        try:
            self["buttonSelector"].setVisible(self.focus=="buttons")
            self["recSelector"].setVisible(self.focus=="recommend" and bool(self.recommendations))
            if self.focus=="buttons": self["buttonSelector"].instance.move(ePoint(sx(475 if self.button_index==0 else 765), sy(415)))
            if self.focus=="recommend": self["recSelector"].instance.move(ePoint(sx(self.REC_X[self.rec_index]), sy(845)))
        except Exception: pass

    def left(self):
        if self.focus=="buttons": self.button_index=max(0,self.button_index-1)
        elif self.focus=="recommend": self.rec_index=max(0,self.rec_index-1)
        self.updateFocus()
    def right(self):
        if self.focus=="buttons": self.button_index=min(1,self.button_index+1)
        elif self.focus=="recommend": self.rec_index=min(max(0,len(self.recommendations)-1),self.rec_index+1)
        self.updateFocus()
    def up(self):
        self.focus="buttons"; self.updateFocus()
    def down(self):
        if self.recommendations: self.focus="recommend"
        self.updateFocus()

    def ok(self):
        if self.focus=="buttons":
            if self.button_index==0:
                self.watchSelected()
            else:
                self._searchSourcesOnDemand()
            return
        if self.focus=="recommend" and self.recommendations:
            self.session.open(MovieDetailsScreen,self.source,self.recommendations[self.rec_index],self.server_items)
            return
    def showSources(self):
        if not self.sources_list:
            self.session.open(MessageBox,"No exact alternate source is available for this movie.",MessageBox.TYPE_INFO)
            return
        rows = [(x.get("name") or x.get("title") or "Source", x) for x in self.sources_list]
        self.session.openWithCallback(self.sourceChosen, SourceChoiceScreen, rows, "EXACT MATCHING SOURCES")
    def sourceChosen(self,item=None):
        if item: self.playItem(item)
    def toggleFavourite(self):
        item = self._playable_item() or self.item
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, "vod", item)
            title = item.get("name") or item.get("title") or "الفيلم"
            if not saved:
                self["meta"].setText(tr("Unable to save favorite"))
            elif added:
                self["meta"].setText("★ تمت إضافة %s إلى المفضلات" % title)
            else:
                self["meta"].setText("☆ تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["meta"].setText("تعذر تحديث المفضلة: %s" % exc)


    def _resolveHomeMovieForPlay(self):
        if getattr(self, "_homePlayResolving", False):
            return

        # Home passes a warmed server VOD index. Resolve synchronously in memory
        # first; this avoids the visible search delay for Popular/Trending movies.
        if self.server_items:
            wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
            wanted = list(dict.fromkeys(x for x in wanted if x))
            target_year = self._year(self.item)
            best = None
            best_score = 0.0
            for row in self.server_items:
                candidate_titles = [self._title_norm((row or {}).get(field)) for field in ("name","title","original_title")]
                score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                if not score:
                    continue
                row_year = self._year(row or {})
                if target_year and row_year and abs(target_year-row_year) > 1:
                    continue
                if target_year and row_year == target_year:
                    score += 0.02
                if score > best_score:
                    best, best_score = dict(row), score
            if best is not None and best_score >= 0.90:
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                self.sources_list = [best]
                self.playItem(best)
                return

        self._homePlayResolving = True
        # Keep WATCH label stable; the lookup is background-only.
        # This avoids a visible loading/search state for short cache misses.
        wanted = [self._title_norm(self.item.get(field)) for field in ("name","title","original_title")]
        wanted = list(dict.fromkeys(x for x in wanted if x))
        target_year = self._year(self.item)
        source = dict(self.source or {})

        def worker():
            best = None
            best_score = 0.0
            try:
                client = get_source_client(source)
                rows = list(self._fullServerVodCatalog() or [])
                for row in rows:
                    candidate_titles = [self._title_norm(row.get(field)) for field in ("name","title","original_title")]
                    score = max([self._title_score(a,b) for a in wanted for b in candidate_titles] or [0.0])
                    if not score:
                        continue
                    row_year = self._year(row)
                    if target_year and row_year and abs(target_year-row_year)>1:
                        continue
                    bonus = 0.02 if target_year and row_year == target_year else 0.0
                    if score + bonus > best_score:
                        best = dict(row); best_score = score + bonus
                if best_score < 0.90:
                    best = None
            except Exception:
                best = None

            def finish():
                self._homePlayResolving = False
                self["watch"].setText(tr("▶  Watch"))
                if not best:
                    self.session.open(MessageBox, tr("This movie is not available on the current server."), MessageBox.TYPE_INFO)
                    return
                # Keep the rich TMDb artwork/details while provider identity drives playback.
                for key in ("tmdb_id","_tmdb_title","backdrop_path","stream_icon","cover","rating","plot","description","year"):
                    if not best.get(key) and self.item.get(key):
                        best[key] = self.item.get(key)
                self.sources_list = [best]
                self.playItem(best)
            self._queueGui(finish)

        t=threading.Thread(target=worker,name="TiviMateHomeMoviePlayResolve")
        t.daemon=True; t.start()


    def watchSelected(self):
        if not self._watchReady:
            return
        if not (self.item.get("stream_id") or self.item.get("vod_id")):
            return
        self.playItem(self.item)


    def playItem(self,item):
        try:
            from .tivimate_player import TiviMatePlayer
            url=get_source_client(self.source).stream_url(item,"vod")
            player_item = dict(item or {})
            # Reuse the exact TMDb match resolved by MovieDetailsScreen.
            for key in ("tmdb_id", "_tmdb_title", "_player_cover", "poster_path", "_tmdb_backdrop"):
                if self.item.get(key):
                    player_item[key] = self.item.get(key)
            try:
                from .ui import _source_identity
                player_item["_source_key"] = _source_identity(self.source)
            except Exception:
                player_item["_source_key"] = ""
            player_item["_source_type"] = self.source.get("type") or ""
            player_item["_kind"] = "vod"
            service=eServiceReference(4097,0,url); service.setName(item.get("name") or "MOVIE")
            self.session.open(TiviMatePlayer,service,player_item)
        except Exception as exc:
            self.session.open(MessageBox,"Unable to play:\n%s"%exc,MessageBox.TYPE_ERROR)

SOURCE_CHOICE = '''<screen name="SourceChoiceScreen" position="500,200" size="920,680" flags="wfNoBorder" backgroundColor="#20242A">
<widget name="title" position="40,30" size="840,55" font="Regular;34" foregroundColor="#FFFFFF" backgroundColor="#20242A" transparent="1" halign="center" />
<widget name="list" position="50,110" size="820,490" font="Regular;27" itemHeight="54" scrollbarMode="showOnDemand" backgroundColor="#20242A" foregroundColor="#FFFFFF" selectionBackgroundColor="#3A414B" selectionForegroundColor="#F2D36B" />
<widget name="keys" position="-10,-10" size="1,1" font="Regular;1" foregroundColor="#00000000" backgroundColor="#00000000" transparent="1" />
<widget name="guideBar" position="50,612" size="820,52" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2/skins/source_choice_guide_r69.png" alphatest="blend" zPosition="3" />
</screen>'''

SOURCE_CHOICE = scale_skin(SOURCE_CHOICE)

class SourceChoiceScreen(Screen):
    skin=SOURCE_CHOICE
    def __init__(self,session,rows,title="EXACT MATCHING SOURCES"):
        Screen.__init__(self,session); self.rows=rows or []
        self["title"]=Label(title)
        self["list"]=MenuList([(x[0],x[1]) for x in self.rows])
        self["keys"]=Label(tr("OK Play     EXIT Back"))
        self["guideBar"]=Pixmap()
        self["actions"]=ActionMap(["OkCancelActions","DirectionActions"],{"ok":self.ok,"cancel":self.close,"up":lambda:self["list"].up(),"down":lambda:self["list"].down()},-1)
    def ok(self):
        c=self["list"].getCurrent()
        if c:self.close(c[1])



class ContentHomeScreen(Screen):
    # Independent fixed limits: top backdrop row is always 12,
    # while Popular/Trending poster content remains 50.
    BACKDROP_ITEM_LIMIT = 12
    POSTER_ITEM_LIMIT = 50

    skin = CONTENT_HOME

    def __new__(cls, *args, **kwargs):
        obj = Screen.__new__(cls)
        obj.skin = CONTENT_HOME_ACCESSIBILITY if _accessibility_skin_enabled() else CONTENT_HOME
        return obj
    TOP = ["Search", "Home", "Live", "Movies", "TV Shows", "Continue Watching", "Settings"]
    TOP_X = [60, 220, 360, 490, 650, 840, 1150]
    TOP_W = [150, 130, 120, 150, 180, 300, 180]
    TREND_X = [80, 535, 990, 1445]
    LATEST_X = [80, 295, 510, 725, 940, 1155, 1370, 1585]

    def _title_score(self, wanted, candidate):
        """Strict normalized title score used by Popular/Trending server matching."""
        if not wanted or not candidate:
            return 0.0
        if wanted == candidate:
            return 1.0
        wanted_tokens = set(wanted.split())
        candidate_tokens = set(candidate.split())
        if not wanted_tokens or not candidate_tokens:
            return 0.0
        overlap = wanted_tokens & candidate_tokens
        coverage = float(len(overlap)) / float(min(len(wanted_tokens), len(candidate_tokens)))
        union = float(len(wanted_tokens | candidate_tokens))
        jaccard = float(len(overlap)) / union if union else 0.0

        # Safe containment only when nearly the whole meaningful title matches.
        if coverage == 1.0 and min(len(wanted_tokens), len(candidate_tokens)) >= 2:
            return 0.98 if abs(len(wanted_tokens) - len(candidate_tokens)) <= 1 else 0.94

        ratio = SequenceMatcher(None, wanted, candidate).ratio()
        if min(len(wanted_tokens), len(candidate_tokens)) >= 3 and coverage >= 0.90 and jaccard >= 0.75 and ratio >= 0.90:
            return ratio
        return 0.0



    def __init__(self, session, source, kind):
        Screen.__init__(self, session)
        self._pageOpenBusy = False
        self.source, self.kind = source, kind
        self.contentGeneration = 0
        self.contentMode = _content_default_mode(kind)
        self.focus = "top"
        self.topIndex = 3 if kind == "vod" else 4
        self.trending, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        # Fast package switching: build category indexes once, then every
        # red/blue package change is RAM-only with no timer/network wait.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        self._categorySwitchPreviewNow = False
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        self.categoryLoadToken = 0
        # Stalker category requests run in a worker.  Do not rely on Twisted
        # being integrated with Enigma2: the eTimer below is the only route that
        # applies a finished red/blue category request to the GUI thread.
        self.stalkerCategoryLoadResult = None
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadTimer = eTimer()
        try:
            self._stalkerCategoryLoadTimer_conn = self.stalkerCategoryLoadTimer.timeout.connect(self._finishStalkerCategoryLoad)
        except Exception:
            try:
                self.stalkerCategoryLoadTimer.callback.append(self._finishStalkerCategoryLoad)
            except Exception:
                self.stalkerCategoryLoadTimer.timeout.get().append(self._finishStalkerCategoryLoad)
        self.sortMode = "default"
        self.trendStart = self.trendIndex = self.latestStart = self.latestIndex = 0
        self.downloads, self.picloads = [], []
        self._image_requests = {}
        # One main-thread dispatcher is used for every worker result on Movies
        # and TV Shows.  Network/poster work stays in the background exactly as
        # before; only the final widget update is serialized on Enigma2's GUI
        # thread.  This prevents red/blue/yellow/navigation restarts on images
        # where Twisted exists but is not integrated with the Enigma2 mainloop.
        self._guiDispatchQueue = []
        self._guiDispatchLock = threading.Lock()
        self._guiDispatchClosed = False
        self._guiDispatchTimer = eTimer()
        try:
            self._guiDispatchTimer_conn = self._guiDispatchTimer.timeout.connect(self._drainGuiDispatch)
        except Exception:
            try:
                self._guiDispatchTimer.callback.append(self._drainGuiDispatch)
            except Exception:
                self._guiDispatchTimer.timeout.get().append(self._drainGuiDispatch)
        # VOD list rows frequently contain only poster art.  Delay the richer
        # backdrop lookup briefly so rapid navigation never starts one network
        # request per key press, then discard every stale result by token.
        self._previewRequestId = 0
        self._previewBackdropPending = None
        self._previewBackdropTimer = eTimer()
        try:
            self._previewBackdropTimer_conn = self._previewBackdropTimer.timeout.connect(self._beginPreviewBackdropLookup)
        except Exception:
            try:
                self._previewBackdropTimer.callback.append(self._beginPreviewBackdropLookup)
            except Exception:
                self._previewBackdropTimer.timeout.get().append(self._beginPreviewBackdropLookup)
        for i, text in enumerate(self.TOP): self["top%d" % i] = Label(tr(text))
        self["topSelector"] = Pixmap(); self["clock"] = Label("")
        self["hero"] = Pixmap(); self["logoImage"] = Pixmap(); self["logoHintIcon"] = Pixmap(); self["logoHint"] = Label("LOGO"); self["logoTitle"] = Label(""); self["heroMeta"] = Label(""); self["heroDesc"] = Label("")
        self["heroPlay"] = Label("▶  " + tr("Play")); self["heroInfo"] = Label("ⓘ  More Info")
        # Fixed top hero/trending title. Setting #6 only changes the lower row.
        primary_title = "Today's Trending Movies" if kind == "vod" else "Today's Trending Series"
        self["trendingTitle"] = Label(tr(primary_title))
        self["latestTitle"] = Label(tr(_content_mode_title(kind, self.contentMode)))
        self["latestCategoryName"] = Label("")
        for i in range(4):
            self["trend%d" % i] = Pixmap(); self["rank%d" % i] = Label("")
            self["trendLabel%d" % i] = Label(""); self["trendRate%d" % i] = Label("")
        for i in range(8):
            self["latest%d" % i] = Pixmap()
            self["latestLabel%d" % i] = Label(""); self["latestRate%d" % i] = Label("")
        self["trendSelector"] = Pixmap(); self["latestSelector"] = Pixmap()
        self["footer"] = Label(""); self["actionButtons"] = Pixmap()
        self["actions"] = ActionMap(["OkCancelActions", "DirectionActions", "ColorActions"], {
            "left": self.left, "right": self.right, "up": self.up, "down": self.down,
            "ok": self.ok, "cancel": self.close, "red": self.previousCategory, "green": self.categories, "yellow": self.toggleSort,
            "yellowlong": self.addCurrentFavourite, "blue": self.nextCategory
        }, -1)
        self.onLayoutFinish.append(self._layoutReady)
        self.onClose.append(self._stopGuiDispatch)
        self.onClose.append(self._releaseArtworkResources)
        self.onClose.append(self._stopStalkerCategoryLoadTimer)

    def _startGuiDispatch(self):
        self._guiDispatchClosed = False
        try:
            self._guiDispatchTimer.start(40, True)
        except Exception:
            pass

    def _queueGui(self, callback, *args):
        if getattr(self, "_guiDispatchClosed", False):
            return
        try:
            self._guiDispatchLock.acquire()
            self._guiDispatchQueue.append((callback, args))
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _drainGuiDispatch(self):
        if getattr(self, "_guiDispatchClosed", False):
            return
        pending = []
        try:
            self._guiDispatchLock.acquire()
            pending = self._guiDispatchQueue[:]
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass
        for callback, args in pending:
            try:
                callback(*args)
            except Exception:
                pass
        if not getattr(self, "_guiDispatchClosed", False):
            try:
                self._guiDispatchTimer.start(40, True)
            except Exception:
                pass

    def _stopGuiDispatch(self):
        self._guiDispatchClosed = True
        try:
            self._guiDispatchTimer.stop()
        except Exception:
            pass
        try:
            self._guiDispatchLock.acquire()
            del self._guiDispatchQueue[:]
        finally:
            try:
                self._guiDispatchLock.release()
            except Exception:
                pass

    def _applyArabicHeadingLayout(self):
        if get_language() != "ar":
            return
        try:
            for name, y in (("trendingTitle", 500), ("latestTitle", 772)):
                widget = self[name]
                if widget and widget.instance:
                    widget.instance.move(ePoint(sx(1110), sy(y)))
                    widget.instance.resize(eSize(sx(730), sy(45)))
                    try:
                        widget.instance.setHAlign(2)
                    except Exception:
                        pass
        except Exception:
            pass

    def _layoutReady(self):
        self._applyArabicHeadingLayout()
        self._positionLatestCategoryName()
        self._startGuiDispatch()
        self.start()

    def _releaseArtworkResources(self):
        self._image_requests = {}
        self.downloads = []
        self.picloads = []

    def _stopStalkerCategoryLoadTimer(self):
        # Invalidate workers before screen teardown, so a late portal reply
        # cannot attempt to repaint a screen that no longer exists.
        self.categoryLoadToken = getattr(self, "categoryLoadToken", 0) + 1
        self.stalkerCategoryPendingToken = None
        self.stalkerCategoryLoadResult = None
        try:
            self.stalkerCategoryLoadTimer.stop()
        except Exception:
            pass

    def start(self):
        self["clock"].setText(time.strftime("%H:%M", time.localtime()))
        # Open Recently Added instantly from the last successful landing cache.
        # The provider catalog and TMDb continue refreshing in the background.
        cached_latest = _load_content_landing_cache(self.source, self.kind) if self.contentMode == "recent" else []
        if cached_latest:
            self.latest = self._sortedItems(cached_latest)
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()
        self.updateFocus()
        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentHome"); t.daemon = True; t.start()

    def worker(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        trend_thread = threading.Thread(target=self._loadTrending, args=(generation,), name="TiviMateTrending")
        trend_thread.daemon = True
        trend_thread.start()
        self._loadServer(generation)

    def _loadServer(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        source = dict(self.source or {})
        kind = self.kind
        # Stalker catalogs can be very large.  Its small Packages endpoint is
        # loaded first; titles are fetched only after the user opens one Package.
        try:
            client = get_source_client(source)
            if source.get("type") == "stalker":
                rows, origin = get_cached_categories(source, kind, client=client, wait_for_server=True)
                categories = filter_categories(source, kind, rows or [])
                categories = [c for c in categories if str(c.get("category_id") or "")]
                if not categories:
                    raise RuntimeError("Stalker returned no packages. Check Portal URL and MAG MAC, then retry.")
                # A Stalker portal cannot provide a reliable flat VOD/Series
                # catalog.  Seed this page from one real package instead, using
                # the same cache-aware path that already powers category views.
                latest, landing_category, landing_origin = get_stalker_landing_items(
                    source, kind, client, categories=categories, limit=32
                )
                self._queueGui(self.serverReady, latest, latest, categories, landing_category, generation)
                return
            # Categories are a small independent endpoint.  Fetch them beside the
            # catalog on a cold cache so the first page has both lists ready sooner.
            category_result = {"rows": [], "origin": "error"}

            def load_categories():
                try:
                    rows, origin = get_cached_categories(
                        self.source, self.kind, client=client, wait_for_server=True
                    )
                    category_result["rows"] = rows or []
                    category_result["origin"] = origin
                except Exception:
                    pass

            category_thread = threading.Thread(target=load_categories, name="TiviMateCategories")
            category_thread.daemon = True
            category_thread.start()
            all_items = get_filtered_streams(source, kind, client)
            category_thread.join()
            raw_categories = category_result.get("rows") or []
            categories = filter_categories(source, kind, raw_categories)
            categories = [c for c in categories if str(c.get("category_id") or "")]
            latest = self._sortedItems(all_items)
            self._queueGui(self.serverReady, latest, all_items, categories, None, generation)
        except Exception as exc:
            self._queueGui(self.serverFailed, str(exc), generation)


    def _loadTrending(self, generation=None):
        if generation is None:
            generation = self.contentGeneration
        kind = self.kind
        mode = self.contentMode
        try:
            tmdb = TMDbClient()
            if not tmdb.configured():
                raise RuntimeError("TMDb API key is not configured")

            # The TOP hero/backdrop row is always Trending and is completely
            # independent from the lower poster mode selected in Settings.
            top_trending = tmdb.trending_2026(kind, self.BACKDROP_ITEM_LIMIT)
            if not top_trending:
                raise RuntimeError("TMDb returned no trending content")

            # The lower poster row follows Settings only.
            lower_items = []
            if mode == "netflix":
                lower_items = tmdb.provider_catalog(kind, "netflix", self.POSTER_ITEM_LIMIT)
            elif mode == "prime":
                lower_items = tmdb.provider_catalog(kind, "prime", self.POSTER_ITEM_LIMIT)
            elif mode == "trending":
                lower_items = tmdb.trending_2026(kind, self.POSTER_ITEM_LIMIT)

            self._queueGui(self.trendingReady, top_trending, generation, lower_items)
        except Exception as exc:
            self._queueGui(self.trendingFailed, str(exc), generation)


    def serverReady(self, latest, allItems=None, categories=None, landingCategory=None, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.serverItems = list(allItems or [])
        self.categoryItems = []
        self.categoriesList = list(categories or [])

        # Build one in-memory category map once. This removes the repeated
        # full-catalog scan that used to happen on every package key press.
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        if self.source.get("type") == "xtream":
            for row in self.serverItems:
                try:
                    cid = str((row or {}).get("category_id") or (row or {}).get("categoryId") or "")
                    if cid:
                        self._categoryRowsIndex.setdefault(cid, []).append(row)
                except Exception:
                    pass
        self.categoriesLoaded = True
        self.categoryIndex = -1
        self.categoryName = ""
        self._updateLatestTitle()
        landing_id = str((landingCategory or {}).get("category_id") or "")
        if landing_id:
            for index, category in enumerate(self.categoriesList):
                if str(category.get("category_id") or "") == landing_id:
                    self.categoryIndex = index
                    self.categoryName = category.get("category_name") or "Other"
                    self._updateLatestTitle()
                    self.categoryItems = list(allItems or [])
                    break
        server_latest = latest or []
        if self.contentMode == "recent":
            self.latest = server_latest
            self.latestStart = self.latestIndex = 0
            if self.latest:
                _submit_content_bg(_save_content_landing_cache,
                                   args=(dict(self.source), self.kind, list(self.latest)[:64]),
                                   key=("landing-cache", id(self), self.kind))
            self._updateLatestTitle()
            self.renderLatest()
        elif not self.latest:
            # Popular/Trending are supplied by TMDb. Keep the row empty until that
            # background request returns instead of briefly showing stale Latest.
            self.latest = []
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()
        if self.source.get("type") == "stalker" and not self.latest:
            self["heroDesc"].setText(tr("Stalker packages are ready. Open Categories and select a package to load its titles."))
        if not self.trending:
            # Keep the opening focus on the top navigation. Once the user presses
            # DOWN, focus goes to Trending first (or Latest only if Trending is unavailable).
            if self.focus != "top":
                self.focus = "trending" if self.trending else ("latest" if self.latest else "trending")
                self.preview()
            self.updateFocus()


    def trendingReady(self, trending, generation=None, lower_items=None):
        if generation is not None and generation != self.contentGeneration:
            return

        # Top backdrop is ALWAYS real Trending: fixed 12 maximum.
        self.trending = list(trending or [])[:self.BACKDROP_ITEM_LIMIT]

        # Lower posters are independent: Netflix / Prime / Trending = up to 50.
        if self.contentMode in ("netflix", "prime", "trending"):
            self.latest = list(lower_items or [])[:self.POSTER_ITEM_LIMIT]
            self.latestStart = self.latestIndex = 0
            self._updateLatestTitle()
            self.renderLatest()

        # Recent remains server-backed and is filled by _loadServer().
        self.renderTrending()
        if self.trending:
            self.trendStart = self.trendIndex = 0
            if self.focus != "top":
                self.focus = "trending"
        if self.focus != "top":
            self.preview()
        self.updateFocus()


    def serverFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.serverItems, self.categoryItems, self.categoriesList = [], [], []
        self.categoriesLoaded = True
        self.latest = []
        self._updateLatestTitle()
        self["heroDesc"].setText("Unable to load the selected server library: %s" % msg)
        self.renderLatest(); self.updateFocus()

    def trendingFailed(self, msg, generation=None):
        if generation is not None and generation != self.contentGeneration:
            return
        self.trending = []
        self.renderTrending()
        if self.latest:
            if self.focus != "top":
                self.focus = "latest"
                self.preview()
            self["heroDesc"].setText("TMDb Trending unavailable. Latest content is loaded from your selected server.\n%s" % msg)
        else:
            self["heroDesc"].setText("Unable to load TMDb Trending: %s" % msg)
        self.updateFocus()

    def current(self):
        arr = self.trending if self.focus == "trending" else self.latest
        idx = self.trendStart + self.trendIndex if self.focus == "trending" else self.latestStart + self.latestIndex
        return arr[idx] if 0 <= idx < len(arr) else None

    def toggleFavourite(self):
        item = self.current()
        if not item:
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import toggle_favourite
            added, saved = toggle_favourite(self.source, self.kind, target)
            title = target.get("name") or target.get("title") or "العنصر"
            if not saved:
                self["footer"].setText(tr("Unable to save favorite"))
            elif added:
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText("تمت إزالة %s من المفضلات" % title)
        except Exception as exc:
            self["footer"].setText("تعذر تحديث المفضلة: %s" % exc)

    def addCurrentFavourite(self):
        item = self.current()
        if not item:
            self["footer"].setText(tr("Select a movie or TV show first"))
            return
        target = self.matchServerItem(item) if item.get("_tmdb") else item
        if not target:
            self["footer"].setText(tr("This title is not available on the server and cannot be added to favorites"))
            return
        try:
            from .favorites import is_favourite, add_favourite
            title = target.get("name") or target.get("title") or "العنصر"
            if is_favourite(self.source, self.kind, target):
                self["footer"].setText("%s موجود بالفعل في المفضلات" % title)
            elif add_favourite(self.source, self.kind, target):
                self["footer"].setText("تمت إضافة %s إلى المفضلات" % title)
            else:
                self["footer"].setText(tr("Unable to save favorite"))
        except Exception as exc:
            self["footer"].setText("Unable to save favorite: %s" % exc)

    def norm(self, value):
        if isinstance(value, list): value = value[0] if value else ""
        if isinstance(value, str):
            value = value.strip().replace("\\/", "/")
            if value.startswith("["):
                try: value = (json.loads(value) or [""])[0]
                except Exception: pass
            if value.startswith("/"): value = "https://image.tmdb.org/t/p/w1280" + value
        return value or ""

    def imageUrl(self, item, backdrop=False):
        if backdrop:
            return self.norm(item.get("backdrop_path") or item.get("backdrop") or item.get("backdrop_url"))
        # Latest poster always starts from the connected server. Relative
        # provider paths must never be mistaken for TMDb /poster_path values.
        return _server_poster_url(self.source, item)

    def logoUrl(self, item):
        return self.norm(item.get("logo") or item.get("title_logo") or item.get("logo_path") or item.get("clearlogo") or "")

    def setPlaceholder(self, widget, name):
        try: self[widget].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", name))
        except Exception: pass

    def _tmdbTitleCandidates(self, *values):
        """Return safe TMDb title candidates without changing server list labels.

        IPTV providers often prefix names with bouquet/group tags such as
        ``FRI |`` or ``EN |``.  Those labels are useful in the UI but can make
        TMDb return no result.  Only the fallback lookup uses these cleaned
        variants, so the fast server-artwork path remains untouched.
        """
        out = []
        for value in values:
            raw = str(value or "").strip()
            if not raw:
                continue
            variants = [raw]
            if "|" in raw:
                tail = raw.split("|")[-1].strip()
                if tail:
                    variants.insert(0, tail)
            # Remove a leading [GROUP] / (GROUP) tag only for TMDb lookup.
            variants.append(re.sub(r"^\s*[\[(][^\])]{1,16}[\])]\s*", "", raw).strip())
            for candidate in variants:
                clean = self._normTitle(candidate)
                if clean and clean not in out:
                    out.append(clean)
        return out

    def _tmdbSearchArtwork(self, item, extra=None, required_key="poster_path"):
        """One TMDb artwork path for every Movies/TV Shows surface.

        r63: always let the shared TMDb client see the original provider title
        first.  Its global title normalizer handles 4K/NF/language/provider
        prefixes consistently on every server.  Local legacy candidates remain
        only as a final compatibility fallback.
        """
        tmdb = TMDbClient()
        data = dict(item or {})
        if isinstance(extra, dict):
            merged = dict(extra)
            merged.update(data)
            data = merged
        values = [data.get("name"), data.get("title"), data.get("original_title"), data.get("original_name")]
        year = self._year(data) or None
        seen = set()
        # Original labels first: TMDbClient.search_artwork() owns the canonical
        # all-server normalization introduced in r61.
        for value in values:
            candidate = str(value or "").strip()
            key = candidate.lower()
            if not candidate or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        # Keep old local variants for unusual bouquet labels, but never make
        # them the primary lookup path.
        for candidate in self._tmdbTitleCandidates(*values):
            key = str(candidate or "").strip().lower()
            if not key or key in seen:
                continue
            seen.add(key)
            found = tmdb.search_artwork(candidate, self.kind, year, required_key=required_key) or {}
            if found.get(required_key):
                return found
        return {}

    def _tmdbPosterFallback(self, item, widget, width, height, failed_url=""):
        """Find a TMDb poster only when the server poster is missing or failed."""
        # A reused card may already be loading another item. Never let an old
        # server failure replace the artwork of the new card.
        if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
            return
        def worker():
            try:
                if failed_url and getattr(self, "_image_requests", {}).get(widget) != failed_url:
                    return
                found = self._tmdbSearchArtwork(item or {}, required_key="poster_path")
                poster = self.norm(found.get("poster_path") or "")
                if not poster:
                    return
                def apply():
                    # The slot may have been reused while TMDb was queried.
                    current = getattr(self, "_image_requests", {}).get(widget)
                    if failed_url and current != failed_url:
                        return
                    self.loadImage(poster, widget, width, height)
                self._queueGui(apply)
            except Exception:
                pass
        _submit_content_bg(worker, key=("poster-fallback", id(self), str(widget)))

    def _posterFileValid(self, path):
        """Cheap local validation for server posters before decoding.

        This deliberately does not touch the downloader/queue.  It only catches
        server URLs that return an HTML/error body or a tiny/broken file, so the
        existing TMDb fallback can take over without affecting artwork speed.
        """
        try:
            if not path or not os.path.exists(path) or os.path.getsize(path) < 1024:
                return False
            with open(path, "rb") as fh:
                head = fh.read(12)
            if head.startswith(b"\xff\xd8\xff"):
                return True
            if head.startswith(b"\x89PNG\r\n\x1a\n"):
                return True
            if head.startswith(b"RIFF") and head[8:12] == b"WEBP":
                return True
            if head.startswith(b"GIF87a") or head.startswith(b"GIF89a"):
                return True
            return False
        except Exception:
            return False

    def loadImage(self, url, widget, width, height, fallback_item=None):
        """Show cached artwork fast; hero backdrops recover through TMDb if needed."""
        url = (url or "").strip().replace("\\/", "/")
        if not url:
            return
        requests = getattr(self, "_image_requests", None)
        if requests is None:
            requests = {}
            self._image_requests = requests
        requests[widget] = url

        if widget == "hero":
            priority = 120
        elif widget == "logoImage":
            priority = 100
        elif widget.startswith("trend"):
            priority = 75
        elif widget.startswith("latest"):
            priority = 85
        else:
            priority = 50

        def force_hero_tmdb(expected=url):
            if getattr(self, "_image_requests", {}).get("hero") != expected:
                return
            item = self.current()
            if not item:
                return
            self._previewRequestId += 1
            request_id = self._previewRequestId
            _submit_content_bg(
                self._lookupPreviewArtwork,
                args=(dict(item), request_id, True, False),
                key=("hero-tmdb-fallback", id(self))
            )

        def done(path, w=widget, x=width, y=height, expected=url, item=fallback_item):
            if getattr(self, "_image_requests", {}).get(w) != expected:
                return
            if item is not None and not self._posterFileValid(path):
                try:
                    if path and os.path.exists(path):
                        os.remove(path)
                except Exception:
                    pass
                self._tmdbPosterFallback(item, w, x, y, expected)
                return
            if w == "hero":
                try:
                    if not path or not os.path.exists(path) or os.path.getsize(path) < 1000:
                        try:
                            if path and os.path.exists(path):
                                os.remove(path)
                        except Exception:
                            pass
                        force_hero_tmdb(expected)
                        return
                except Exception:
                    force_hero_tmdb(expected)
                    return
            self.decode(path, w, x, y)

        def failed(_path, w=widget, expected=url, item=fallback_item, x=width, y=height):
            if w == "hero":
                force_hero_tmdb(expected)
                return
            if item is not None:
                self._tmdbPosterFallback(item, w, x, y, expected)

        cache_kind = "backdrops" if widget == "hero" else "contenthome"
        request_artwork(
            url, cache_kind, done, priority=priority,
            errback=failed if (fallback_item is not None or widget == "hero") else None
        )

    def decode(self, path, widget, width, height):
        loader = ePicLoad(); self.picloads.append(loader)
        def ready(_=None, l=loader, w=widget):
            try:
                ptr = l.getData()
                if ptr and self[w].instance:
                    self[w].instance.setPixmap(ptr)
                    try:
                        self[w].show()
                    except Exception:
                        pass
                    if w == "logoImage":
                        try:
                            self["logoHintIcon"].setVisible(False)
                            self["logoHint"].setVisible(False)
                        except Exception:
                            pass
            except Exception:
                pass
            try:
                if l in self.picloads:
                    self.picloads.remove(l)
            except Exception:
                pass
        render_width, render_height = scale_size(width, height)
        connect_picture_data(loader, ready, self, oneshot=True); loader.setPara((render_width, render_height, 0, 0, False, 1, "#00000000")); loader.startDecode(path)

    def _setCardMeta(self, prefix, slot, item):
        title = str((item or {}).get("name") or (item or {}).get("title") or "").strip()
        rating = str((item or {}).get("rating") or (item or {}).get("rating_5based") or "").strip()
        limit = 30 if prefix == "trend" else 16
        self["%sLabel%d" % (prefix, slot)].setText(title[:limit] + ("…" if len(title) > limit else ""))
        self["%sRate%d" % (prefix, slot)].setText(rating[:4])

    def renderTrending(self):
        for slot in range(4):
            idx = self.trendStart + slot
            item = self.trending[idx] if idx < len(self.trending) else None
            if item:
                # Movies keep TMDb's original rank. Series are filtered to scripted
                # TV before display, so use the visible list position to avoid gaps
                # such as #1, #5, #19 after excluded TV programmes.
                if self.kind == "vod":
                    rank = int(item.get("_tmdb_rank") or (idx + 1))
                else:
                    rank = idx + 1
            else:
                rank = 0
            self["rank%d" % slot].setText("#%d" % rank if item else "")
            self.setPlaceholder("trend%d" % slot, "banner_placeholder.jpg")
            self._setCardMeta("trend", slot, item)
            if item:
                url = self.imageUrl(item, True)
                if url: self.loadImage(url, "trend%d" % slot, 410, 210)
        self._prefetchCards(self.trending, self.trendStart + 4, 4, True, 10)

    def renderLatest(self):
        for slot in range(8):
            idx = self.latestStart + slot
            item = self.latest[idx] if idx < len(self.latest) else None
            self.setPlaceholder("latest%d" % slot, "poster_placeholder.png")
            self._setCardMeta("latest", slot, item)
            if item:
                url = self.imageUrl(item, False)
                if url:
                    self.loadImage(url, "latest%d" % slot, 170, 205, fallback_item=item)
                else:
                    self._tmdbPosterFallback(item, "latest%d" % slot, 170, 205)
        self._prefetchCards(self.latest, self.latestStart + 8, 8, False, 5)

    def _prefetchCards(self, items, start, count, backdrop=False, priority=5):
        """Warm only the next page at a low priority without decoding it yet.

        The queue writes the original JPEG/PNG response to disk, so this changes
        timing only; it never alters image dimensions, compression, or poster art.
        """
        for item in list(items or [])[start:start + count]:
            try:
                url = self.imageUrl(item, backdrop)
                if url:
                    request_artwork(url, "backdrops" if backdrop else "contenthome", None, priority=priority)
            except Exception:
                pass


    def _alignTopSelector(self):
        try:
            index = max(0, min(self.topIndex, len(self.TOP_X) - 1))
            cell_w = self.TOP_W[index]
            x = self.TOP_X[index] + ((cell_w - 180) // 2)
            self["topSelector"].instance.move(ePoint(sx(x), sy(79)))
        except Exception:
            pass


    def updateFocus(self):
        try:
            self._alignTopSelector(); self["topSelector"].setVisible(self.focus == "top")
            self["trendSelector"].instance.move(ePoint(sx(self.TREND_X[self.trendIndex]), sy(555))); self["trendSelector"].setVisible(self.focus == "trending" and bool(self.trending))
            self["latestSelector"].instance.move(ePoint(sx(self.LATEST_X[self.latestIndex]), sy(825))); self["latestSelector"].setVisible(self.focus == "latest" and bool(self.latest))
        except Exception: pass

    def preview(self):
        item = self.current()
        if not item:
            return
        try:
            self["hero"].show()
        except Exception:
            pass
        # Every move gets a new token.  It guarantees that a slower lookup for
        # a previous poster cannot overwrite the backdrop of the current movie.
        self._previewRequestId += 1
        request_id = self._previewRequestId
        title = (item.get("name") or item.get("title") or "").upper()[:34]
        logo = ""  # Always fetch the official transparent TMDb logo.
        self["logoTitle"].setText(title)
        try:
            self["logoHintIcon"].setVisible(True)
            self["logoHint"].setVisible(True)
            self["logoImage"].setVisible(True)
        except Exception:
            pass
        try:
            self["logoImage"].instance.setPixmapFromFile(os.path.join(PLUGIN_PATH, "skins", "transparent.png"))
        except Exception:
            pass
        if logo:
            self.loadImage(logo, "logoImage", 260, 60)
        year = item.get("year") or item.get("releaseDate") or ""
        rating = item.get("rating") or item.get("rating_5based") or ""
        genre = item.get("genre") or ""
        self["heroMeta"].setText("   •   ".join(x for x in [str(year), ("★ " + str(rating)) if rating else "", str(genre)] if x))
        self["heroDesc"].setText((item.get("plot") or item.get("description") or "")[:260])
        back = self.imageUrl(item, True)
        if back:
            self.loadImage(back, "hero", 1920, 520)
        if not back or not logo:
            self._previewBackdropPending = (dict(item), request_id, True, not bool(logo))
            if getattr(self, "_categorySwitchPreviewNow", False):
                self._categorySwitchPreviewNow = False
                try:
                    self._previewBackdropTimer.stop()
                except Exception:
                    pass
                self._beginPreviewBackdropLookup()
            else:
                try:
                    self._previewBackdropTimer.stop()
                    self._previewBackdropTimer.start(180, True)
                except Exception:
                    self._beginPreviewBackdropLookup()

    def _beginPreviewBackdropLookup(self):
        pending = self._previewBackdropPending
        self._previewBackdropPending = None
        if not pending:
            return
        item, request_id, need_backdrop, need_logo = pending
        if request_id != self._previewRequestId:
            return
        _submit_content_bg(
            self._lookupPreviewArtwork,
            args=(item, request_id, need_backdrop, need_logo),
            key=("preview-artwork", id(self))
        )

    def _movieBackdropUrl(self, data):
        data = data or {}
        return self.norm(
            data.get("backdrop_path") or data.get("backdrop") or
            data.get("backdrop_url") or data.get("movie_backdrop")
        )

    def _bundleLogoUrl(self, data):
        data = data or {}
        images = data.get("images") or {}
        logos = images.get("logos") or []
        if not isinstance(logos, list):
            return ""
        ordered = sorted(logos, key=lambda row: 0 if row.get("iso_639_1") == "en" else (1 if not row.get("iso_639_1") else 2))
        for row in ordered:
            path = row.get("file_path") or ""
            if path:
                return self.norm(path)
        return ""

    def _lookupPreviewArtwork(self, item, request_id, need_backdrop=True, need_logo=True):
        """Portal/server first, then TMDb enhancement without holding the UI.

        A server backdrop is applied as soon as it is available. If TMDb search
        provides a backdrop, that is also applied before the slower full details
        request used for transparent logos and richer metadata. Stale requests
        are discarded by request_id, matching EStalker's fast navigation model.
        """
        try:
            if request_id != getattr(self, "_previewRequestId", request_id):
                return
            details = {}
            if self.kind == "vod":
                stream_id = item.get("stream_id") or item.get("vod_id")
                if stream_id:
                    raw = get_source_client(self.source).vod_info(stream_id) or {}
                    if isinstance(raw.get("movie_data"), dict):
                        details.update(raw.get("movie_data") or {})
                    if isinstance(raw.get("info"), dict):
                        details.update(raw.get("info") or {})
                    if not details and isinstance(raw, dict):
                        details.update(raw)

            server_backdrop = self._movieBackdropUrl(details) if need_backdrop else ""
            server_logo = self._bundleLogoUrl(details) if need_logo else ""
            if server_backdrop or server_logo:
                self._queueGui(self._applyPreviewArtwork, server_backdrop, server_logo, request_id)
            if request_id != self._previewRequestId:
                return

            need_tmdb_backdrop = bool(need_backdrop and not server_backdrop)
            need_tmdb_logo = bool(need_logo and not server_logo)

            # Metadata is intentionally independent from artwork. Even when the
            # server already supplied backdrop/logo, Movies/Series metadata must
            # still prefer TMDb and use server fields only as fallback.
            tmdb = TMDbClient()
            tmdb_id = details.get("tmdb_id") or details.get("tmdb") or item.get("tmdb_id") or item.get("tmdb")
            found = {}
            if not tmdb_id:
                raw_title = (details.get("name") or details.get("title") or
                             item.get("name") or item.get("title") or "")
                item_year = self._year(details) or self._year(item) or None
                if raw_title:
                    try:
                        found = tmdb.search_title(raw_title, self.kind, item_year) or {}
                        if not found:
                            found = tmdb.search_title(raw_title, self.kind, None) or {}
                    except Exception:
                        found = {}
                tmdb_id = found.get("id") or found.get("tmdb_id")

            quick_backdrop = self._movieBackdropUrl(found) if need_tmdb_backdrop else ""
            if quick_backdrop:
                self._queueGui(self._applyPreviewArtwork, quick_backdrop, "", request_id)
                need_tmdb_backdrop = False
            if request_id != self._previewRequestId or not tmdb_id:
                return

            try:
                bundle = tmdb.details_bundle(tmdb_id, self.kind) or {}
            except Exception:
                bundle = {}
            if found:
                seed = dict(found)
                seed.update(bundle or {})
                bundle = seed

            # Apply TMDb text/meta first. Missing individual fields remain as the
            # already-visible server values, so a partial TMDb response is safe.
            if bundle:
                self._queueGui(self._applyPreviewMetadata, bundle, request_id)

            backdrop = self._movieBackdropUrl(bundle) if need_tmdb_backdrop else ""
            logo = self._bundleLogoUrl(bundle) if need_tmdb_logo else ""
            if backdrop or logo:
                self._queueGui(self._applyPreviewArtwork, backdrop, logo, request_id)
        except Exception:
            pass

    def _applyPreviewMetadata(self, data, request_id):
        if request_id != self._previewRequestId:
            return
        data = data or {}
        title = data.get("title") or data.get("name") or ""
        release = data.get("release_date") or data.get("first_air_date") or ""
        year = str(release or "")[:4]
        rating = data.get("vote_average")
        genres = data.get("genres") or []
        if isinstance(genres, list):
            genre = ", ".join(str(x.get("name") or "") for x in genres[:3] if isinstance(x, dict) and x.get("name"))
        else:
            genre = str(genres or "")
        overview = data.get("overview") or ""
        if title:
            self["logoTitle"].setText(str(title).upper()[:34])
        meta = []
        if year:
            meta.append(year)
        if rating not in (None, ""):
            try:
                meta.append("★ %.1f" % float(rating))
            except Exception:
                meta.append("★ " + str(rating))
        if genre:
            meta.append(genre)
        if meta:
            self["heroMeta"].setText("   •   ".join(meta))
        if overview:
            self["heroDesc"].setText(str(overview)[:260])

    def _applyPreviewArtwork(self, backdrop, logo, request_id):
        if request_id != self._previewRequestId:
            return
        if backdrop:
            self.loadImage(backdrop, "hero", 1920, 520)
        if logo:
            self.loadImage(logo, "logoImage", 260, 60)

    def left(self):
        if self.focus == "top": self.topIndex = max(0, self.topIndex - 1)
        elif self.focus == "trending":
            if self.trendIndex > 0: self.trendIndex -= 1
            elif self.trendStart > 0: self.trendStart = max(0, self.trendStart - 4); self.renderTrending()
        else:
            if self.latestIndex > 0: self.latestIndex -= 1
            elif self.latestStart > 0: self.latestStart = max(0, self.latestStart - 8); self.renderLatest()
        self.updateFocus(); self.preview()

    def right(self):
        if self.focus == "top": self.topIndex = min(len(self.TOP) - 1, self.topIndex + 1)
        elif self.focus == "trending":
            if self.trendIndex < 3 and self.trendStart + self.trendIndex + 1 < len(self.trending): self.trendIndex += 1
            elif self.trendStart + 4 < len(self.trending): self.trendStart += 4; self.trendIndex = 0; self.renderTrending()
        else:
            if self.latestIndex < 7 and self.latestStart + self.latestIndex + 1 < len(self.latest): self.latestIndex += 1
            elif self.latestStart + 8 < len(self.latest): self.latestStart += 8; self.latestIndex = 0; self.renderLatest()
        self.updateFocus(); self.preview()

    def up(self):
        if self.focus == "latest":
            self.focus = "trending"
        elif self.focus == "trending":
            self.focus = "top"
        else:
            self.focus = "top"
        self.updateFocus(); self.preview()



    def down(self):
        if self.focus == "top":
            # Trending is always the first content level. If it is still loading,
            # stay on top rather than jumping directly to the lower poster row.
            if self.trending:
                self.focus = "trending"
            elif not self.latest:
                self.focus = "top"
            else:
                # Only fall back when Trending is genuinely unavailable.
                self.focus = "latest"
        elif self.focus == "trending":
            self.focus = "latest" if self.latest else "trending"
        else:
            self.focus = "latest"
        self.updateFocus()
        if self.focus != "top":
            self.preview()


    def _normTitle(self, value):
        text = (value or "").lower()
        text = re.sub(r"\b(ar|en|us|usa|sub|subs|dub|dubbed|multi|4k|uhd|fhd|hd|hevc|x265|x264|hdr|web[- ]?dl|bluray)\b", " ", text)
        text = re.sub(r"\b(19|20)\d{2}\b", " ", text)
        text = re.sub(r"[^a-z0-9]+", " ", text)
        return " ".join(text.split())

    def _year(self, item):
        raw = " ".join(str(item.get(k) or "") for k in ("year", "releaseDate", "releasedate", "name", "title"))
        m = re.search(r"\b(19|20)\d{2}\b", raw)
        return int(m.group(0)) if m else 0

    def _serverTmdbId(self, item):
        item = item or {}
        for key in ("tmdb_id", "tmdb", "tmdbid"):
            value = item.get(key)
            if value not in (None, ""):
                try:
                    return str(int(value))
                except Exception:
                    value = str(value).strip()
                    if value:
                        return value
        info = item.get("info")
        if isinstance(info, dict):
            for key in ("tmdb_id", "tmdb", "tmdbid"):
                value = info.get(key)
                if value not in (None, ""):
                    try:
                        return str(int(value))
                    except Exception:
                        value = str(value).strip()
                        if value:
                            return value
        return ""

    def _strictMatchFromRows(self, tmdbItem, rows):
        tmdbItem = tmdbItem or {}
        target_id = self._serverTmdbId(tmdbItem)
        target_year = self._year(tmdbItem)
        wanted = [
            self._normTitle(tmdbItem.get("name") or tmdbItem.get("title")),
            self._normTitle(tmdbItem.get("original_title") or tmdbItem.get("original_name"))
        ]
        wanted = [x for x in wanted if x]
        if not wanted and not target_id:
            return None

        # 1) Exact TMDb ID is authoritative.
        if target_id:
            for row in rows or []:
                if self._serverTmdbId(row) == target_id:
                    return row

        # 2) Title/year matching is intentionally strict.  A wrong movie is
        # worse than reporting "not available".
        best = None
        best_score = 0.0
        for row in rows or []:
            candidate = self._normTitle((row or {}).get("name") or (row or {}).get("title"))
            if not candidate:
                continue
            row_year = self._year(row)
            if target_year and row_year and target_year != row_year:
                continue

            score = max([self._title_score(w, candidate) for w in wanted] or [0.0])
            if score <= 0.0:
                continue

            # If either side lacks a year, accept only an exact/near-exact
            # normalized title.  This prevents remakes and similarly named films.
            if not (target_year and row_year) and score < 0.98:
                continue

            # With an exact year, still require a strong title identity.
            if target_year and row_year and score < 0.94:
                continue

            if score > best_score:
                best, best_score = row, score
        return best

    def matchServerItem(self, tmdbItem):
        match = self._strictMatchFromRows(tmdbItem, self.serverItems or [])
        if match:
            return match

        # Xtream serverItems already contains the full enabled catalogue.
        # Stalker landing mode contains only one package, so Popular/Trending
        # must search every enabled package before declaring the title absent.
        if self.source.get("type") != "stalker":
            return None
        try:
            client = get_source_client(self.source)
            categories, _origin = get_cached_categories(
                self.source, self.kind, client=client, wait_for_server=True
            )
            categories = filter_categories(self.source, self.kind, categories or [])
            for category in categories:
                category_id = str((category or {}).get("category_id") or "")
                if not category_id:
                    continue
                rows, _origin = get_category_streams(
                    self.source, self.kind, client, category_id,
                    use_cache=True, wait_for_server=True
                )
                match = self._strictMatchFromRows(tmdbItem, rows or [])
                if match:
                    return match
        except Exception:
            pass
        return None

    def playTrendingFromServer(self, item):
        match = self.matchServerItem(item)
        if not match:
            self.session.open(MessageBox, tr("This title is not available on the current server."), MessageBox.TYPE_INFO)
            return
        if self.kind == "series":
            from .ui import SeriesDetailsScreen
            self.session.open(SeriesDetailsScreen, self.source, match)
            return
        try:
            from .tivimate_player import TiviMatePlayer
            url = get_source_client(self.source).stream_url(match, "vod")
            player_item = dict(match or {})
            try:
                from .ui import _source_identity
                player_item["_source_key"] = _source_identity(self.source)
            except Exception:
                player_item["_source_key"] = ""
            player_item["_source_type"] = self.source.get("type") or ""
            player_item["_kind"] = "vod"
            service = eServiceReference(4097, 0, url)
            service.setName(match.get("name") or item.get("name") or "MOVIE")
            self.session.open(TiviMatePlayer, service, player_item)
        except Exception as exc:
            self.session.open(MessageBox, "Unable to play:\n%s" % exc, MessageBox.TYPE_ERROR)

    def _switchContentKind(self, new_kind):
        """Switch Movies/TV Shows inside this same Screen; never stack another ContentHomeScreen."""
        if new_kind == self.kind:
            self.focus = "top"
            self.updateFocus()
            return
        self.contentGeneration += 1
        self.categoryLoadToken += 1
        self.kind = new_kind
        self.contentMode = _content_default_mode(new_kind)
        self.topIndex = 3 if new_kind == "vod" else 4
        self.focus = "top"

        self.trending, self.latest = [], []
        self.serverItems, self.categoryItems = [], []
        self.categoriesList = []
        self.categoriesLoaded = False
        self.categoryIndex = -1
        self.categoryName = ""
        self._categoryRowsIndex = {}
        self._categorySortedIndex = {}
        self.trendStart = self.trendIndex = self.latestStart = self.latestIndex = 0

        # Keep the top hero/trending title fixed while switching content type.
        primary_title = "Today's Trending Movies" if new_kind == "vod" else "Today's Trending Series"
        self["trendingTitle"].setText(tr(primary_title))
        self._updateLatestTitle()
        self["latestCategoryName"].setText("")
        self["heroDesc"].setText("")
        self["logoTitle"].setText("")
        self["heroMeta"].setText("")
        try:
            # Never hide the hero while switching Movies/TV Shows.
            # Keep a visible placeholder until the new backdrop is decoded.
            self["hero"].show()
            if self["hero"].instance:
                self["hero"].instance.setPixmapFromFile(
                    os.path.join(PLUGIN_PATH, "skins", "banner_placeholder.jpg")
                )
            self["logoImage"].hide()
        except Exception:
            pass
        self.renderTrending()
        self.renderLatest()
        self.updateFocus()

        generation = self.contentGeneration
        t = threading.Thread(target=self.worker, args=(generation,), name="TiviMateContentSwitch")
        t.daemon = True
        t.start()

    def _pageClosed(self, *args):
        self._pageOpenBusy = False

    def _openPageOnce(self, screen, *args):
        if getattr(self, "_pageOpenBusy", False):
            return
        self._pageOpenBusy = True
        try:
            self.session.openWithCallback(self._pageClosed, screen, *args)
        except Exception:
            self._pageOpenBusy = False
            self.session.open(screen, *args)


    def ok(self):
        from .ui import TiviMateE2Search, TiviMateE2Home, MediaScreen, SeriesDetailsScreen, ServerManager, ContinueWatchingScreen
        from .tivimate_player import TiviMatePlayer
        if self.focus == "top":
            if self.topIndex == 0:
                self._openPageOnce(TiviMateE2Search, self.source)
                return
            if self.topIndex == 1:
                self._openPageOnce(TiviMateE2Home)
                return
            if self.topIndex == 2:
                self._openPageOnce(MediaScreen, self.source, "live")
                return
            if self.topIndex == 3:
                self._switchContentKind("vod")
                return
            if self.topIndex == 4:
                self._switchContentKind("series")
                return
            if self.topIndex == 5:
                self._openPageOnce(ContinueWatchingScreen, self.source)
                return
            if self.topIndex == 6:
                self._openPageOnce(ServerManager)
                return
            return
        item = self.current()
        if not item:
            return
        if self.kind == "series":
            if item.get("_tmdb"):
                chosen = dict(item)
                chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
                self.session.open(SeriesDetailsScreen, self.source, chosen)
                return
            self.session.open(SeriesDetailsScreen, self.source, item)
            return
        if item.get("_tmdb"):
            chosen = dict(item)
            chosen["_home_tmdb_feed"] = "content_%s" % self.contentMode
            self.session.open(MovieDetailsScreen, self.source, chosen, self.serverItems)
            return
        self.session.open(MovieDetailsScreen, self.source, item, self.serverItems)
        return

    def _sortLabel(self):
        return {"default": "Date", "name": "Name", "rating": "Rating"}.get(self.sortMode, "Date")

    def _sortBadge(self):
        labels = {
            "default": "[🕒 %s]" % tr("Date"),
            "name": "[A-Z %s]" % tr("Name"),
            "rating": "[★ %s]" % tr("Rating"),
        }
        return labels.get(self.sortMode, labels["default"])

    def _addedSortValue(self, item):
        """Return the provider's real add/update timestamp for Latest rows.

        Movies use ``added``. Series use ``last_modified`` first and then
        ``added`` because many Xtream panels do not publish ``added`` for a
        series. Production year and TMDb release dates are deliberately not
        used here.
        """
        row = item or {}
        if self.kind == "series":
            raw = row.get("last_modified")
            if raw in (None, "", 0, "0"):
                raw = row.get("added")
        else:
            raw = row.get("added")
        if raw is None:
            return 0
        try:
            value = float(raw)
            # Some portals send Unix time in milliseconds rather than seconds.
            if value != value or value == float("inf") or value == float("-inf"):
                return 0
            if abs(value) >= 100000000000:
                value = value / 1000.0
            return value
        except Exception:
            pass
        try:
            text = str(raw).strip().replace("T", " ")
        except Exception:
            return 0
        # Stalker commonly returns e.g. "2015-08-21 18:35:31".  Parse the
        # standard date-time part and tolerate an optional time-zone suffix.
        for value, pattern in ((text[:19], "%Y-%m-%d %H:%M:%S"), (text[:10], "%Y-%m-%d")):
            try:
                return time.mktime(time.strptime(value, pattern))
            except Exception:
                pass
        return 0

    def _sortedItems(self, items):
        rows = list(items or [])
        if self.sortMode == "name":
            rows.sort(key=lambda x: (x.get("name") or x.get("title") or "").lower())
        elif self.sortMode == "rating":
            def rating_value(x):
                try: return float(x.get("rating") or x.get("rating_5based") or 0)
                except Exception: return 0
            rows.sort(key=rating_value, reverse=True)
        else:
            # Sort timestamped entries newest-first. Keep entries for which the
            # provider exposes no usable timestamp in their original server
            # order instead of hiding the whole Series section.
            dated = []
            undated = []
            for position, item in enumerate(rows):
                stamp = self._addedSortValue(item)
                if stamp > 0:
                    dated.append((stamp, position, item))
                else:
                    undated.append((position, item))
            dated.sort(key=lambda entry: (entry[0], -entry[1]), reverse=True)
            rows = [entry[2] for entry in dated] + [entry[1] for entry in undated]
        return rows

    def _activeItems(self):
        return self.categoryItems if self.categoryIndex >= 0 else self.serverItems

    def _positionLatestCategoryName(self):
        """Keep the server package name directly beside the translated mode title."""
        try:
            if not self["latestTitle"].instance or not self["latestCategoryName"].instance:
                return
            lang = get_language()
            if lang == "ar":
                # Arabic heading is right-aligned in the block moved by
                # _applyArabicHeadingLayout. Put the package immediately to its left.
                title_x = 1110
                title_w = 730
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(220, min(700, len(self["latestTitle"].getText()) * 18))
                cat_w = 720
                x = max(80, title_x + title_w - rendered - cat_w - 18)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(cat_w), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(2)
                except Exception:
                    pass
            else:
                title_x = 80
                try:
                    rendered = self["latestTitle"].instance.calculateSize().width()
                except Exception:
                    rendered = max(180, min(700, len(self["latestTitle"].getText()) * 17))
                x = min(1020, title_x + rendered + 14)
                self["latestCategoryName"].instance.move(ePoint(sx(x), sy(772)))
                self["latestCategoryName"].instance.resize(eSize(sx(820), sy(45)))
                try:
                    self["latestCategoryName"].instance.setHAlign(0)
                except Exception:
                    pass
        except Exception:
            pass

    def _updateLatestTitle(self):
        try:
            self["latestTitle"].setText(tr(_content_mode_title(self.kind, self.contentMode)))
        except Exception:
            pass
        try:
            category = str(getattr(self, "categoryName", "") or "").strip()
            badge = self._sortBadge()
            if category:
                text = "  •  %s   %s" % (category, badge)
            else:
                text = "  •  %s" % badge
            self["latestCategoryName"].setText(text)
        except Exception:
            pass
        self._positionLatestCategoryName()

    def _changeCategory(self, direction):
        if not self.categoriesLoaded:
            self["heroDesc"].setText("")
            return
        if not self.categoriesList:
            self["heroDesc"].setText(tr("No enabled categories are available for this library."))
            return
        if direction < 0 and self.categoryIndex < 0:
            self.categoryIndex = len(self.categoriesList) - 1
        else:
            self.categoryIndex = (self.categoryIndex + direction) % len(self.categoriesList)
        category = self.categoriesList[self.categoryIndex]
        category_id = str(category.get("category_id") or "")
        self.categoryName = category.get("category_name") or "Other"
        self._updateLatestTitle()
        if not category_id:
            return
        self.categoryLoadToken += 1
        token = self.categoryLoadToken

        # Xtream: package switching is completely immediate.
        # No eTimer, no network request, and no re-scan of the full catalog.
        if self.source.get("type") == "xtream" and self.serverItems:
            rows = list(self._categoryRowsIndex.get(category_id, []))
            self.categoryItems = rows
            if category_id in self._categorySortedIndex:
                self.latest = list(self._categorySortedIndex.get(category_id) or [])
            else:
                self.latest = self._sortedItems(rows)
                self._categorySortedIndex[category_id] = list(self.latest)
            self.latestStart = self.latestIndex = 0
            self.focus = "latest"
            self._categorySwitchPreviewNow = True
            self._updateLatestTitle()
            self.renderLatest()
            self.preview()
            self.updateFocus()
            self["heroDesc"].setText("")
            return

        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("")
        name = "TiviMateNextCategory" if direction > 0 else "TiviMatePreviousCategory"
        is_stalker = self.source.get("type") == "stalker"
        if is_stalker:
            # Supersede any older unfinished category request.  The worker also
            # checks the token before storing a result, preventing an old reply
            # from overwriting a newer red/blue selection.
            self.stalkerCategoryLoadResult = None
            self.stalkerCategoryPendingToken = token
        submitted = _submit_content_bg(
            self._loadCategory,
            args=(token, category_id),
            key=("category-load", id(self))
        )
        if not submitted:
            self["heroDesc"].setText(tr("Please wait for the current request to finish."))
        if is_stalker:
            try:
                self.stalkerCategoryLoadTimer.start(120, True)
            except Exception:
                pass

    def previousCategory(self):
        self._changeCategory(-1)

    def nextCategory(self):
        self._changeCategory(1)

    def _loadCategory(self, token, category_id):
        if token != getattr(self, "categoryLoadToken", token):
            return
        source = dict(self.source or {})
        try:
            client = get_source_client(source)
            items, origin = get_category_streams(source, self.kind, client, category_id, use_cache=True)
            if source.get("type") == "stalker":
                # Never call Labels/Pixmaps from a Python worker.  This fixes
                # portal category changes on images where Twisted exists but is
                # not attached to Enigma2's GUI event loop.
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, list(items or []), origin, "")
                return
            self._queueGui(self.categoryReady, token, items, origin)
        except Exception as exc:
            if source.get("type") == "stalker":
                if token == getattr(self, "categoryLoadToken", 0):
                    self.stalkerCategoryLoadResult = (token, [], "error", str(exc))
                return
            self._queueGui(self.categoryFailed, token, str(exc))

    def _finishStalkerCategoryLoad(self):
        """Apply the newest Stalker category result only on the GUI thread."""
        expected = getattr(self, "stalkerCategoryPendingToken", None)
        if expected is None:
            return
        result = self.stalkerCategoryLoadResult
        if result is None:
            if expected == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        # A completion can race with this callback; erase only the same object
        # that was observed, never a newer result written by a newer worker.
        if self.stalkerCategoryLoadResult is result:
            self.stalkerCategoryLoadResult = None
        token, items, origin, error = result
        if token != getattr(self, "categoryLoadToken", 0) or token != expected:
            if getattr(self, "stalkerCategoryPendingToken", None) == getattr(self, "categoryLoadToken", 0):
                try:
                    self.stalkerCategoryLoadTimer.start(120, True)
                except Exception:
                    pass
            return
        self.stalkerCategoryPendingToken = None
        if error:
            self.categoryFailed(token, error)
        else:
            self.categoryReady(token, items, origin)

    def categoryReady(self, token, items, origin):
        if token != self.categoryLoadToken:
            return
        self.categoryItems = list(items or [])
        self.latest = self._sortedItems(self.categoryItems)
        self.latestStart = self.latestIndex = 0
        self.focus = "latest"
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()
        if not self.latest:
            if self.source.get("type") == "stalker" and origin == "empty":
                self["heroDesc"].setText("Stalker returned no items for %s. Try another package or refresh the source." % self.categoryName)
            else:
                self["heroDesc"].setText("No titles are available in %s." % self.categoryName)

    def categoryFailed(self, token, msg):
        if token != self.categoryLoadToken:
            return
        self.categoryItems, self.latest = [], []
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.updateFocus()
        self["heroDesc"].setText("Unable to load %s: %s" % (self.categoryName, msg))

    def toggleSort(self):
        modes = ["default", "name", "rating"]
        try:
            pos = modes.index(self.sortMode)
        except Exception:
            pos = 0
        self.sortMode = modes[(pos + 1) % len(modes)]
        self.latest = self._sortedItems(self._activeItems())
        self.latestStart = self.latestIndex = 0
        self._updateLatestTitle(); self.renderLatest(); self.preview(); self.updateFocus()

    def serverList(self):
        from .ui import ServerManager
        self._openPageOnce(ServerManager)
    def categories(self):
        self.session.openWithCallback(self.categoryChosen, ServerCategoryList, self.source, self.kind)

    def categoryChosen(self, selected=None):
        if not selected:
            return
        from .ui import MediaScreen
        self._openPageOnce(MediaScreen, self.source, self.kind, selected.get("id"), selected.get("name"))
