
"""Small, UI-safe artwork download queue for Enigma2.

Artwork is always read from the local cache first.  On a cache miss this module
starts the existing helper in a separate process and keeps at most four network
transfers alive at once.  Consequently a list renderer never performs DNS,
HTTP, image conversion, or disk writes on the Enigma2 GUI thread.
"""

import hashlib
import os
import threading

from enigma import eConsoleAppContainer, eTimer

try:
    from twisted.web.client import downloadPage
except Exception:
    downloadPage = None

from .cache_manager import get_cache_dir, cleanup_cache, get_settings
from .compat import python_command

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
IMAGE_FETCH = os.path.join(PLUGIN_PATH, "image_fetch.py")
PYTHON_EXECUTABLE, PYTHON_COMMAND = python_command()
# Four transfers keep the interface responsive without creating an unbounded
# download burst on compact Enigma2 receivers.  Artwork bytes are never changed.
MAX_CONCURRENT_DOWNLOADS = 4
# Bound the queued artwork metadata/callbacks as well as active transfers. On a
# fast scroll a receiver can otherwise accumulate hundreds of stale poster jobs
# while the network is slower than the UI. Dropped stale jobs are harmless: a
# visible card requests the same cached URL again when rendered.
MAX_PENDING_DOWNLOADS = 48
MAX_CALLBACKS_PER_JOB = 8
MAX_NOTIFY_TIMERS = 24
MIN_VALID_BYTES = 100

_pending = []
_running = {}
_jobs = {}
_sequence = [0]
_cleanup_count = [0]
_cleanup_running = [False]
_notify_timers = []
_display_sequence = [0]
CLEANUP_EVERY_SUCCESSES = 12


def normalise_url(url):
    try:
        return (url or "").strip().replace("\\/", "/")
    except Exception:
        return ""


def artwork_path(url, kind="artwork"):
    """Return the stable cache path for an artwork URL without downloading it."""
    url = normalise_url(url)
    if not url:
        return ""
    clean_url = url.split("?", 1)[0]
    lower_url = clean_url.lower()
    # Preserve PNG in the common direct case.  The fetch helper validates the
    # actual content type, so a server that lies about an extension is still safe.
    ext = ".png" if lower_url.endswith(".png") else ".jpg"
    # Expiring CDN tokens often change only the query string.  The binary image
    # itself is the same, so a query-free key prevents unnecessary redownloads.
    digest = hashlib.md5(clean_url.encode("utf-8")).hexdigest()
    return os.path.join(get_cache_dir(kind), digest + ext)


def cached_artwork(url, kind="artwork"):
    path = artwork_path(url, kind)
    try:
        if path and os.path.exists(path) and os.path.getsize(path) >= MIN_VALID_BYTES:
            try:
                os.utime(path, None)
            except Exception:
                pass
            return path
    except Exception:
        pass
    return ""


def _valid(path):
    try:
        return bool(path and os.path.exists(path) and os.path.getsize(path) >= MIN_VALID_BYTES)
    except Exception:
        return False


def _schedule_cleanup():
    """Run age-based trimming only when the user enabled a retention period."""
    try:
        if int(get_settings().get("retention_days", 0) or 0) <= 0:
            # Unlimited means exactly that: no automatic cleanup task is even
            # scheduled, so no background path can remove posters/backdrops.
            return
    except Exception:
        return
    _cleanup_count[0] += 1
    if _cleanup_count[0] < CLEANUP_EVERY_SUCCESSES or _cleanup_running[0]:
        return
    _cleanup_count[0] = 0
    _cleanup_running[0] = True

    def worker():
        try:
            cleanup_cache()
        except Exception:
            pass
        finally:
            _cleanup_running[0] = False

    thread = threading.Thread(target=worker, name="TiviMateArtworkCleanup")
    thread.daemon = True
    thread.start()


def _notify(callbacks, path):
    for callback in list(callbacks or []):
        try:
            callback(path)
        except Exception:
            # A screen may legitimately have closed while an artwork transfer was
            # queued.  One dead callback must not affect another screen/job.
            pass


def _schedule_notify(callbacks, path, delay_ms):
    """Schedule one UI-thread refresh for a completed local artwork file."""
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    timer = eTimer()
    holder = {"timer": timer}

    def fire():
        try:
            _notify(callbacks, path)
        finally:
            try:
                timer.stop()
            except Exception:
                pass
            try:
                _notify_timers.remove(holder)
            except Exception:
                pass

    try:
        holder["connection"] = timer.timeout.connect(fire)
    except Exception:
        try:
            timer.callback.append(fire)
        except Exception:
            timer.timeout.get().append(fire)
    # Keep the short-lived GUI timer list bounded. Oldest timers are only refresh
    # retries; cancelling one cannot cancel the artwork download or disk cache.
    while len(_notify_timers) >= MAX_NOTIFY_TIMERS:
        old = _notify_timers.pop(0)
        try:
            old.get("timer").stop()
        except Exception:
            pass
    _notify_timers.append(holder)
    timer.start(max(1, int(delay_ms)), True)


def _notify_after_write(callbacks, path, delay_ms=90):
    """Reveal completed images progressively on every screen.

    Several Enigma2 images can finish multiple artwork helper processes in the
    same GUI cycle.  Refreshing every slot in that same cycle makes an entire
    row appear at once, and occasionally the first ePicLoad decode is missed
    until the screen is reopened.  Stagger each completed file by a small amount
    and issue one conservative retry.  The callbacks still target individual
    widgets, so this never redraws or blocks the whole page.
    """
    callbacks = list(callbacks or [])
    if not callbacks:
        return
    _display_sequence[0] += 1
    # Spread near-simultaneous completions across four short GUI slots.
    first_delay = int(delay_ms) + ((_display_sequence[0] - 1) % 4) * 85
    _schedule_notify(callbacks, path, first_delay)
    # Pure2/OpenATV may miss the first decoder signal while the file-system
    # rename is still settling. A single later retry fixes that without a page
    # refresh or another network download.
    _schedule_notify(callbacks, path, first_delay + 620)


def _finish(path, status):
    job = _running.pop(path, None)
    if job is None:
        return
    _jobs.pop(path, None)
    try:
        success = int(status) == 0
    except Exception:
        success = False
    if success and _valid(path):
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
    else:
        _notify(job.get("errbacks"), path)
    _start_next()


def _finish_twisted(path, success):
    job = _running.pop(path, None)
    if job is None:
        return
    _jobs.pop(path, None)
    part = job.get("part") or ""
    ok = False
    if success and part:
        try:
            if os.path.exists(part) and os.path.getsize(part) >= MIN_VALID_BYTES:
                try:
                    os.replace(part, path)
                except AttributeError:
                    if os.path.exists(path):
                        os.remove(path)
                    os.rename(part, path)
                ok = _valid(path)
        except Exception:
            ok = False
    if not ok:
        try:
            if part and os.path.exists(part):
                os.remove(part)
        except Exception:
            pass
    if ok:
        _notify_after_write(job.get("callbacks"), path)
        _schedule_cleanup()
    else:
        _notify(job.get("errbacks"), path)
    _start_next()


def _start_next():
    while len(_running) < MAX_CONCURRENT_DOWNLOADS and _pending:
        job = _pending.pop(0)
        path = job.get("path")
        if not path or path in _running:
            continue
        if _valid(path):
            _jobs.pop(path, None)
            _notify(job.get("callbacks"), path)
            continue
        try:
            folder = os.path.dirname(path)
            if folder and not os.path.isdir(folder):
                os.makedirs(folder)

            # Use the exact same Twisted download path that the VOD player uses.
            # This avoids launching a fresh Python interpreter for each poster and
            # keeps the image transfer inside Enigma2's proven async network stack.
            if downloadPage is not None:
                part = path + ".part"
                try:
                    if os.path.exists(part):
                        os.remove(part)
                except Exception:
                    pass
                job["part"] = part
                _running[path] = job
                request_url = job["url"].encode("utf-8") if isinstance(job["url"], str) else job["url"]
                d = downloadPage(request_url, part, timeout=7)
                job["deferred"] = d
                d.addCallback(lambda _r, cache_path=path: _finish_twisted(cache_path, True))
                d.addErrback(lambda _f, cache_path=path: _finish_twisted(cache_path, False))
                continue

            # Compatibility fallback for images without Twisted downloadPage.
            container = eConsoleAppContainer()
            job["container"] = container
            _running[path] = job

            def done(status, cache_path=path):
                _finish(cache_path, status)

            try:
                container.appClosed.append(done)
            except Exception:
                container.appClosed.get().append(done)
            container.execute(PYTHON_EXECUTABLE, PYTHON_COMMAND, IMAGE_FETCH, job["url"], path)
        except Exception:
            _running.pop(path, None)
            _jobs.pop(path, None)


def request_artwork(url, kind="artwork", callback=None, priority=0, errback=None):
    """Use cached artwork immediately or enqueue an asynchronous cache refresh.

    ``callback`` receives the completed local path only after the helper has
    written a valid file.  Duplicate requests share one network transfer while
    every interested widget still receives its own completion callback.
    """
    url = normalise_url(url)
    if not url:
        return ""
    path = cached_artwork(url, kind)
    if path:
        if callback:
            _notify([callback], path)
        return path

    path = artwork_path(url, kind)
    job = _jobs.get(path)
    if job is not None:
        if callback:
            callbacks = job.setdefault("callbacks", [])
            callbacks.append(callback)
            if len(callbacks) > MAX_CALLBACKS_PER_JOB:
                del callbacks[:-MAX_CALLBACKS_PER_JOB]
        if errback:
            errbacks = job.setdefault("errbacks", [])
            errbacks.append(errback)
            if len(errbacks) > MAX_CALLBACKS_PER_JOB:
                del errbacks[:-MAX_CALLBACKS_PER_JOB]
        return path

    _sequence[0] += 1
    job = {
        "url": url,
        "path": path,
        "callbacks": [callback] if callback else [],
        "errbacks": [errback] if errback else [],
        "priority": int(priority or 0),
        "sequence": _sequence[0],
    }
    _jobs[path] = job
    _pending.append(job)
    # Highest priority first, then preserve the visual order for equal priority.
    _pending.sort(key=lambda item: (-item.get("priority", 0), item.get("sequence", 0)))
    # RAM guard for long browsing sessions: keep active transfers plus only a
    # small window of pending artwork metadata. Prefer current/high-priority and
    # newer jobs; stale jobs will be requested again if they become visible.
    if len(_pending) > MAX_PENDING_DOWNLOADS:
        overflow = len(_pending) - MAX_PENDING_DOWNLOADS
        candidates = sorted(_pending, key=lambda item: (item.get("priority", 0), item.get("sequence", 0)))
        for stale in candidates[:overflow]:
            try:
                _pending.remove(stale)
            except Exception:
                pass
            stale_path = stale.get("path")
            if stale_path and stale_path not in _running:
                _jobs.pop(stale_path, None)
            try:
                stale["callbacks"] = []
                stale["errbacks"] = []
            except Exception:
                pass
    _start_next()
    return path


def queue_status():
    """Return lightweight diagnostics for support logs and unit tests."""
    return {"pending": len(_pending), "running": len(_running), "limit": MAX_CONCURRENT_DOWNLOADS, "pending_limit": MAX_PENDING_DOWNLOADS, "notify_timers": len(_notify_timers)}
