from .compat import atomic_replace, ensure_dir, open_text
import os, json, time, shutil, threading

BASE = "/etc/enigma2/tivimatee2"
SETTINGS_FILE = os.path.join(BASE, "cache_settings.json")
# Cache policy:
# - HDD/USB/MMC may be Unlimited (retention_days = 0).
# - No automatic deletion is ever triggered by cache size.
# - /tmp remains temporary and is naturally cleared by the receiver/system.
DEFAULTS = {"location": "auto", "max_mb": 0, "retention_days": 0}
MIN_RETENTION_DAYS = 0
MAX_RETENTION_DAYS = 3650

# Disk/mount probing involves a real write/delete test.  Reusing the selected
# root for a short interval removes that work from every poster/backdrop request
# while still rechecking removable media regularly.
CACHE_ROOT_TTL = 86400 * 365
_CACHE_ROOT = ""
_CACHE_ROOT_LOCATION = ""
_CACHE_ROOT_AT = 0.0
_CACHE_ROOT_LOCK = threading.RLock()

_SETTINGS_MEMORY = None


def _load():
    global _SETTINGS_MEMORY
    if _SETTINGS_MEMORY is not None:
        return dict(_SETTINGS_MEMORY)
    try:
        with open_text(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f) or {}
    except Exception:
        data = {}
    out = dict(DEFAULTS)
    out.update(data)
    # max_mb is retained only for backward compatibility with old settings.
    # It is deliberately ignored by cleanup_cache().
    out["max_mb"] = 0
    try:
        out["retention_days"] = max(MIN_RETENTION_DAYS, min(int(out.get("retention_days", DEFAULTS["retention_days"])), MAX_RETENTION_DAYS))
    except Exception:
        out["retention_days"] = DEFAULTS["retention_days"]
    _SETTINGS_MEMORY = dict(out)
    return dict(out)


def _invalidate_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT, _SETTINGS_MEMORY
    with _CACHE_ROOT_LOCK:
        _CACHE_ROOT = ""
        _CACHE_ROOT_LOCATION = ""
        _CACHE_ROOT_AT = 0.0
        _SETTINGS_MEMORY = None


def save_settings(location, max_mb=0, retention_days=0):
    # max_mb is accepted for compatibility, but size never causes deletion.
    try:
        safe_retention = max(MIN_RETENTION_DAYS, min(int(retention_days), MAX_RETENTION_DAYS))
    except Exception:
        safe_retention = DEFAULTS["retention_days"]
    data = {
        "location": str(location or "auto"),
        "max_mb": 0,
        "retention_days": safe_retention,
    }
    try:
        ensure_dir(BASE)
        tmp = SETTINGS_FILE + ".tmp"
        payload = json.dumps(data, ensure_ascii=False, indent=2)
        if not isinstance(payload, str):
            payload = str(payload)
        with open_text(tmp, "w", encoding="utf-8") as f: f.write(payload)
        atomic_replace(tmp, SETTINGS_FILE)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def get_settings():
    return _load()


def _usable_mount(path):
    """Fast read-only mount check.

    Do not create/delete a test file during normal UI navigation.  Real writes
    are attempted only when a caller actually saves cache content.
    """
    try:
        if not os.path.isdir(path):
            return False
        real = os.path.realpath(path)
        mounted = os.path.ismount(path) or os.path.ismount(real)
        if path == "/tmp":
            mounted = True
        if not mounted:
            return False
        return os.access(path, os.W_OK | os.X_OK)
    except Exception:
        return False


def get_cache_root():
    global _CACHE_ROOT, _CACHE_ROOT_LOCATION, _CACHE_ROOT_AT
    cfg = _load()
    location = str(cfg.get("location", "auto") or "auto")
    now = time.time()
    with _CACHE_ROOT_LOCK:
        if (_CACHE_ROOT and _CACHE_ROOT_LOCATION == location and
                now - _CACHE_ROOT_AT < CACHE_ROOT_TTL and
                os.path.isdir(_CACHE_ROOT)):
            return _CACHE_ROOT

        candidates = {
            "hdd": ["/media/hdd"],
            "usb": ["/media/usb", "/media/usb1", "/media/usb2"],
            "mmc": ["/media/mmc"],
            "internal": ["/etc/enigma2"],
            "tmp": ["/tmp"],
        }
        if location == "auto":
            order = ["hdd", "usb", "mmc", "tmp"]
        elif location in ("hdd", "usb", "mmc", "internal"):
            # A user-selected persistent device is strict: never redirect new
            # artwork to another mount or /tmp behind the user's back.  This
            # prevents a temporary mount delay from splitting the cache and
            # making the persistent cache appear to shrink or disappear.
            order = [location]
        else:
            order = [location]
        seen = set()
        for key in order:
            if key in seen:
                continue
            seen.add(key)
            for mount in candidates.get(key, []):
                if _usable_mount(mount):
                    root = os.path.join(mount, "tivimatee2-cache") if mount != "/tmp" else "/tmp/tivimatee2"
                    try:
                        ensure_dir(root)
                        _CACHE_ROOT = root
                        _CACHE_ROOT_LOCATION = location
                        _CACHE_ROOT_AT = now
                        return root
                    except Exception:
                        pass
        # Only Auto/tmp may fall back to temporary storage.  For an explicit
        # persistent location keep the configured path stable, even while the
        # mount is temporarily unavailable.  Callers will simply fail to write
        # until the device is mounted; existing HDD/USB/MMC files are untouched.
        explicit_roots = {
            "hdd": "/media/hdd/tivimatee2-cache",
            "usb": "/media/usb/tivimatee2-cache",
            "mmc": "/media/mmc/tivimatee2-cache",
            "internal": "/etc/enigma2/tivimatee2/cache",
        }
        if location in explicit_roots:
            _CACHE_ROOT = explicit_roots[location]
        else:
            _CACHE_ROOT = "/tmp/tivimatee2"
        _CACHE_ROOT_LOCATION = location
        _CACHE_ROOT_AT = now
        return _CACHE_ROOT


def get_cache_dir(kind="misc"):
    path = os.path.join(get_cache_root(), str(kind or "misc"))
    try:
        ensure_dir(path)
    except Exception:
        pass
    return path


def get_logs_dir():
    """Logs follow the user-selected cache/storage root; never force /home/root."""
    return get_cache_dir("logs")

def cleanup_stale_temp_files():
    """No-op: TiviMateE2 no longer creates upgrade backup archives."""
    return

def cache_status():
    root = get_cache_root()
    total = 0
    files = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    total += os.path.getsize(p)
                    files += 1
                except Exception:
                    pass
    except Exception:
        pass
    return root, total, files


def clear_cache():
    root = get_cache_root()
    try:
        if root.startswith(("/media/", "/tmp/tivimatee2")) and os.path.exists(root):
            shutil.rmtree(root)
        ensure_dir(root)
        _invalidate_cache_root()
        return True
    except Exception:
        return False


def cleanup_cache():
    """Delete files only by the selected age policy.

    retention_days == 0 means Unlimited: no automatic deletion.
    Cache size is informational only and never triggers a purge.
    """
    cfg = _load()
    root = get_cache_root()
    retention_days = int(cfg.get("retention_days", DEFAULTS["retention_days"]) or 0)
    if retention_days <= 0:
        # Unlimited means no automatic cleanup.  Do not walk the entire cache
        # tree just to calculate a size during startup/navigation.
        return 0
    retention = retention_days * 86400
    now = time.time()
    total = 0
    try:
        for base, _dirs, names in os.walk(root):
            for name in names:
                p = os.path.join(base, name)
                try:
                    st = os.stat(p)
                    if now - st.st_mtime > retention:
                        os.remove(p)
                    else:
                        total += st.st_size
                except Exception:
                    pass
    except Exception:
        pass
    return total

def get_log_path(name):
    """Return a bounded plugin-log path under the user-selected storage root."""
    safe = os.path.basename(str(name or "tivimatee2.log"))
    return os.path.join(get_logs_dir(), safe)


def migrate_legacy_logs():
    """Move only TiviMateE2 legacy logs out of /tmp and /home/root."""
    dst = get_logs_dir()
    try:
        ensure_dir(dst)
    except Exception:
        return
    candidates = [
        "/tmp/tivimatee2_epg_sync.log",
        "/tmp/tivimatee2_epg_local.log",
        "/tmp/tivimatee2_stalker.log",
        "/tmp/tivimatee2_web.log",
        "/tmp/tivimatee2/tmdb.log",
        "/tmp/tivimatee2/poster.log",
        "/tmp/tivimatee2/logs/tmdb.log",
        "/tmp/tivimatee2/logs/poster.log",
        "/home/root/tivimate_category_restore.log",
        "/home/root/tivimatee2_poster_debug.log",
    ]
    for src in candidates:
        try:
            if not os.path.isfile(src):
                continue
            target = os.path.join(dst, os.path.basename(src))
            if os.path.exists(target):
                # Append old content once, then remove legacy file.
                with open(src, "rb") as rf, open(target, "ab") as wf:
                    shutil.copyfileobj(rf, wf)
                os.remove(src)
            else:
                shutil.move(src, target)
        except Exception:
            pass


def migrate_legacy_tmp_cache():
    """Move persistent TiviMateE2 cache out of /tmp to the selected storage.

    True runtime scratch files (QR image, subtitle temp files, sockets) are not
    moved.  This runs only when the resolved cache root is persistent.
    """
    src_root = "/tmp/tivimatee2"
    try:
        dst_root = get_cache_root()
    except Exception:
        return
    if not dst_root or dst_root.startswith("/tmp/") or dst_root == src_root:
        return
    if not os.path.isdir(src_root):
        return
    try:
        ensure_dir(dst_root)
    except Exception:
        return
    # Known persistent cache folders.  Leave web_access_qr.png and any unknown
    # runtime scratch content in /tmp.
    persistent_names = (
        "posters", "backdrops", "logos", "picons", "epg",
        "tmdb_search", "tmdb_trending", "details_json",
        "vod", "series", "live", "metadata", "json", "info"
    )
    for name in persistent_names:
        src = os.path.join(src_root, name)
        dst = os.path.join(dst_root, name)
        if not os.path.exists(src):
            continue
        try:
            if os.path.isdir(src):
                ensure_dir(dst)
                for base, dirs, files in os.walk(src):
                    rel = os.path.relpath(base, src)
                    target_base = dst if rel == "." else os.path.join(dst, rel)
                    ensure_dir(target_base)
                    for fn in files:
                        sp = os.path.join(base, fn)
                        dp = os.path.join(target_base, fn)
                        try:
                            if not os.path.exists(dp):
                                shutil.move(sp, dp)
                            else:
                                os.remove(sp)
                        except Exception:
                            pass
                try:
                    shutil.rmtree(src)
                except Exception:
                    pass
            elif os.path.isfile(src):
                dp = os.path.join(dst_root, name)
                if not os.path.exists(dp):
                    shutil.move(src, dp)
                else:
                    os.remove(src)
        except Exception:
            pass
    # Remove empty legacy log/cache directories, but keep /tmp/tivimatee2 itself
    # if runtime scratch files are still present.
    for sub in ("logs",):
        try:
            path = os.path.join(src_root, sub)
            if os.path.isdir(path) and not os.listdir(path):
                os.rmdir(path)
        except Exception:
            pass
    try:
        if os.path.isdir(src_root) and not os.listdir(src_root):
            os.rmdir(src_root)
    except Exception:
        pass
