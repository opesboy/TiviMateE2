# -*- coding: utf-8 -*-

import json
import os
import tempfile
import threading
import hashlib
import time
import shlex
import re

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import ConfigPassword, ConfigSelection, ConfigText, getConfigListEntry
from Components.Pixmap import MultiPixmap, Pixmap
from Components.ProgressBar import ProgressBar
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
try:
    from Components.Sources.StaticText import StaticText
except Exception:
    from Components.Sources.Source import Source
    class StaticText(Source):
        def __init__(self, text=""):
            Source.__init__(self)
            self.text = text
        def setText(self, text):
            self.text = text
            self.changed((self.CHANGED_ALL,))

from enigma import eTimer, eServiceReference, ePicLoad, iPlayableService, eConsoleAppContainer
from Screens.ChoiceBox import ChoiceBox
from Screens.InfoBarGenerics import (
    InfoBarSeek, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSummarySupport,
    InfoBarMoviePlayerSummarySupport, InfoBarNotifications
)
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

try:
    from Components.PluginComponent import plugins
    from Plugins.Plugin import PluginDescriptor
except Exception:
    plugins = None
    PluginDescriptor = None

try:
    from twisted.internet import reactor
except Exception:
    reactor = None

from .display_scale import scale_skin, scale_size
from .i18n import tr
from .tmdb_client import TMDbClient
from .core import XtreamClient, StalkerClient
from .artwork_queue import request_artwork
from .subdl_client import (
    SubDLClient, SubDLError, load_settings as load_subdl_settings,
    save_settings as save_subdl_settings, LANGUAGE_CHOICES as SUBDL_LANGUAGE_CHOICES,
    KIND_CHOICES as SUBDL_KIND_CHOICES
)

try:
    from twisted.web.client import downloadPage
except Exception:
    downloadPage = None

PLUGIN_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/TiviMateE2"
PLAYER_CONFIG = "/etc/enigma2/tivimatee2/player.json"
SUBDL_IMPORT_FILE = "/tmp/tivimatee2/key.txt"
DEFAULT_COVER = os.path.join(PLUGIN_PATH, "tivimate_infobar", "common", "cover.png")
RESUME_FILE = "/etc/enigma2/tivimatee2/resume.json"
RESUME_MIN_SECONDS = 60
RESUME_END_MARGIN_SECONDS = 120
RECORD_CONFIG = "/etc/enigma2/tivimatee2/recording.json"


def _player_server_asset_url(source, value):
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = str(value or "").strip().replace("\\/", "/")
    except Exception:
        return ""
    if not value:
        return ""
    if value.startswith(("http://", "https://")):
        return value.replace(" ", "%20")
    base = str((source or {}).get("url") or (source or {}).get("portal") or "").strip().rstrip("/")
    if not base:
        return value
    if "://" not in base:
        base = "http://" + base
    try:
        parsed = urlparse(base)
        netloc = parsed.netloc
        port = str((source or {}).get("port") or "").strip()
        if port and ":" not in netloc.rsplit("@", 1)[-1]:
            netloc = "%s:%s" % (netloc, port)
        origin = "%s://%s" % (parsed.scheme or "http", netloc)
        if value.startswith("//"):
            return (parsed.scheme or "http") + ":" + value
        if value.startswith("/"):
            return (origin + value).replace(" ", "%20")
        return (origin + (parsed.path or "").rstrip("/") + "/" + value.lstrip("/")).replace(" ", "%20")
    except Exception:
        return value

def _player_server_poster(source, item):
    item = item if isinstance(item, dict) else {}
    mappings = [item]
    info = item.get("info")
    if isinstance(info, dict):
        mappings.append(info)
    keys = (
        "stream_icon", "movie_image", "cover", "cover_big", "poster",
        "poster_url", "poster_path", "screenshot_uri", "image"
    )
    for mapping in mappings:
        for key in keys:
            value = mapping.get(key)
            if value not in (None, "", [], {}):
                url = _player_server_asset_url(source, value)
                if url:
                    return url
    return ""

def _record_settings_load():
    try:
        with open(RECORD_CONFIG, "r") as handle:
            data = json.load(handle) or {}
        return {"path": str(data.get("path") or "/media/hdd/movie")}
    except Exception:
        return {"path": "/media/hdd/movie"}


def _record_settings_save(path):
    try:
        folder = os.path.dirname(RECORD_CONFIG)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with open(RECORD_CONFIG, "w") as handle:
            json.dump({"path": path}, handle)
        return True
    except Exception:
        return False


def _safe_record_name(value):
    value = re.sub(r"[^A-Za-z0-9._()\- ]+", "_", str(value or "IPTV")).strip(" ._")
    return value[:120] or "IPTV"


def _resume_load():
    try:
        with open(RESUME_FILE, "r") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _resume_save(data):
    try:
        folder = os.path.dirname(RESUME_FILE)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = RESUME_FILE + ".tmp"
        with open(tmp, "w") as handle:
            json.dump(data, handle, separators=(",", ":"), sort_keys=True)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        os.rename(tmp, RESUME_FILE)
        return True
    except Exception:
        return False


def _resume_key(item, streamurl):
    item = item or {}
    raw = "|".join([
        str(item.get("stream_id") or item.get("vod_id") or item.get("episode_id") or item.get("id") or ""),
        str(item.get("series_id") or ""),
        str(item.get("season") or item.get("season_number") or ""),
        str(item.get("episode_num") or item.get("episode_number") or item.get("episode") or ""),
        str(streamurl or ""),
    ])
    try:
        raw = raw.encode("utf-8", "ignore")
    except Exception:
        pass
    return hashlib.sha1(raw).hexdigest()


def _resume_normalize_title(value):
    text = str(value or "").lower()
    text = re.sub(r"\b(?:19|20)\d{2}\b", " ", text)
    text = re.sub(r"(?i)\b(?:4k|8k|uhd|fhd|hd|sd|2160p|1080p|720p|amz|amzn|nf|netflix|web[- ]?dl|webrip|bluray|ar|ara|arabic|en|eng|english)\b", " ", text)
    text = re.sub(r"[^\w]+", " ", text, flags=re.UNICODE)
    return " ".join(text.split())

def _resume_content_identity(item):
    item = item or {}
    kind = str(item.get("_kind") or "").lower()
    series_name = item.get("series_name") or item.get("_tmdb_title") or ""
    title = series_name or item.get("name") or item.get("title") or ""
    norm = _resume_normalize_title(title)
    season = str(item.get("season") or item.get("season_number") or item.get("_subdl_season") or "")
    episode = str(item.get("episode_num") or item.get("episode_number") or item.get("episode") or item.get("_subdl_episode") or "")
    is_episode = bool(kind in ("episode","series","tv","show") or series_name or season or episode)
    if is_episode:
        raw = "series|%s|s%s|e%s" % (norm, season, episode)
    else:
        year = str(item.get("year") or item.get("releaseDate") or item.get("release_date") or "")
        m = re.search(r"\b(19|20)\d{2}\b", year)
        raw = "movie|%s|%s" % (norm, m.group(0) if m else "")
    try:
        raw = raw.encode("utf-8", "ignore")
    except Exception:
        pass
    return hashlib.sha1(raw).hexdigest()


def _resume_clock(seconds):
    try:
        seconds = max(0, int(seconds))
    except Exception:
        seconds = 0
    return "%02d:%02d:%02d" % (seconds // 3600, (seconds % 3600) // 60, seconds % 60)


def _read_import_key(path):
    """Read exactly one non-empty API key from a temporary local file."""
    if not os.path.isfile(path):
        raise IOError("missing")
    with open(path, "rb") as handle:
        raw = handle.read(1025)
    if len(raw) > 1024:
        raise ValueError("too_long")
    try:
        text = raw.decode("utf-8", "ignore")
    except Exception:
        text = str(raw)
    lines = [line.strip() for line in text.replace("\\ufeff", "").splitlines() if line.strip()]
    if len(lines) != 1:
        raise ValueError("invalid_content")
    return lines[0]


def _read_subdl_import_key():
    return _read_import_key(SUBDL_IMPORT_FILE)


ASSET = os.path.join(PLUGIN_PATH, "tivimate_infobar", "common")


def _available_stream_types():
    """Return only usable playback backends exposed by the receiver image.

    ServiceApp images do not always expose their backend executables under the
    same filename, so detecting the plugin itself is essential for VOD files
    that play audio without a picture through the stock GStreamer type.
    """
    result = [(4097, "GStreamer 4097 (default)")]
    serviceapp = any(os.path.isdir(path) for path in (
        "/usr/lib/enigma2/python/Plugins/SystemPlugins/ServiceApp",
        "/usr/lib/enigma2/python/Plugins/Extensions/ServiceApp",
    ))
    if serviceapp or os.path.exists("/usr/bin/gstplayer"):
        result.append((5001, "GstPlayer 5001"))
    if serviceapp or os.path.exists("/usr/bin/exteplayer3"):
        result.append((5002, "ExtePlayer3 5002"))
    return result


def _load_player_type():
    available = [x[0] for x in _available_stream_types()]
    try:
        with open(PLAYER_CONFIG, "r") as handle:
            value = int(json.load(handle).get("service_type", 4097))
            if value in available:
                return value
    except Exception:
        pass
    return available[0] if available else 4097


def _save_player_type(value):
    try:
        parent = os.path.dirname(PLAYER_CONFIG)
        if not os.path.isdir(parent):
            os.makedirs(parent)
        with open(PLAYER_CONFIG, "w") as handle:
            json.dump({"service_type": int(value)}, handle)
    except Exception:
        pass


def _normalise_cover_url(value):
    """Return a downloadable artwork URL from Xtream or TMDb episode data."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    try:
        value = value.strip().replace("\\/", "/")
    except Exception:
        return ""
    if value.startswith("["):
        try:
            decoded = json.loads(value)
            if isinstance(decoded, (list, tuple)):
                value = decoded[0] if decoded else ""
            else:
                value = decoded
        except Exception:
            pass
        try:
            value = value.strip().replace("\\/", "/")
        except Exception:
            return ""
    if value.startswith("//"):
        return "https:" + value
    if value.startswith("/"):
        return "https://image.tmdb.org/t/p/w500" + value
    return value


class IPTVInfoBarShowHide(object):
    STATE_HIDDEN = 0
    STATE_SHOWN = 3
    skipToggleShow = False

    def __init__(self):
        self.__state = self.STATE_SHOWN
        self.__locked = 0
        self.hideTimer = eTimer()
        try:
            self.hideTimer_conn = self.hideTimer.timeout.connect(self.doTimerHide)
        except Exception:
            self.hideTimer.callback.append(self.doTimerHide)
        self.onShow.append(self.__onShow)
        self.onHide.append(self.__onHide)

    def __onShow(self):
        self.__state = self.STATE_SHOWN
        self.startHideTimer()

    def __onHide(self):
        self.__state = self.STATE_HIDDEN

    def OkPressed(self):
        # OK always shows the infobar and restarts the full five-second timer.
        # It must not instantly hide an already visible bar.
        try:
            self.show()
            self.__state = self.STATE_SHOWN
            self.hideTimer.stop()
            self.startHideTimer()
        except Exception:
            pass

    def startHideTimer(self):
        if self.__state == self.STATE_SHOWN and not self.__locked:
            self.hideTimer.stop()
            self.hideTimer.start(5000, True)
        self.skipToggleShow = False

    def doTimerHide(self):
        self.hideTimer.stop()
        if self.__state == self.STATE_SHOWN:
            self.hide()

    def toggleShow(self):
        if self.skipToggleShow:
            self.skipToggleShow = False
            return
        if self.__state == self.STATE_HIDDEN:
            self.show()
            self.hideTimer.stop()
        else:
            self.hide()
            self.startHideTimer()

    def lockShow(self):
        self.__locked += 1
        self.show()
        self.hideTimer.stop()

    def unlockShow(self):
        self.__locked = max(0, self.__locked - 1)
        self.startHideTimer()


class IPTVInfoBarPVRState(object):
    def __init__(self):
        self.onChangedEntry = []
        self.onPlayStateChanged.append(self.__playStateChanged)

    def __playStateChanged(self, state):
        text = ">"
        try:
            text = state[3] or ">"
        except Exception:
            pass
        icon = 0
        speed = ""
        if text == "||":
            icon = 1
        elif text == "END":
            icon = 2
        elif text.startswith(">>"):
            icon = 3
            parts = text.split()
            speed = parts[1] if len(parts) > 1 else ""
        elif text.startswith("<<"):
            icon = 4
            parts = text.split()
            speed = parts[1] if len(parts) > 1 else ""
        elif text.startswith("/"):
            icon = 5
            speed = text
        try:
            self["statusicon"].setPixmapNum(icon)
            self["speed"].setText(speed)
        except Exception:
            pass
        try:
            self.show()
            self.startHideTimer()
        except Exception:
            pass


class SubDLKeyBoard(VirtualKeyBoard):
    """A fixed-contrast keyboard for images whose default keyboard skin hides input text."""
    skin = """
        <screen name="SubDLKeyBoard" position="center,center" size="1180,700" title="SUBDL API KEY">
            <eLabel position="0,0" size="1180,700" backgroundColor="#101820" />
            <widget name="header" position="50,36" size="1080,52" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#101820" transparent="1" />
            <widget name="hint" position="50,95" size="1080,40" font="Regular;24" foregroundColor="#b9d9ff" backgroundColor="#101820" transparent="1" />
            <eLabel position="48,145" size="1084,86" backgroundColor="#ffffff" />
            <widget name="text" position="65,161" size="1050,54" font="Regular;30" foregroundColor="#101820" backgroundColor="#ffffff" />
            <widget name="list" position="48,255" size="1084,385" transparent="1" />
            <eLabel position="48,654" size="1084,2" backgroundColor="#39a9ff" />
        </screen>"""

    def __init__(self, session, title="", text=""):
        VirtualKeyBoard.__init__(self, session, title=title, text=text)
        self["hint"] = Label(tr("Use OK to enter characters. GREEN saves. RED or EXIT cancels."))


class SubDLSettingsScreen(Screen, ConfigListScreen):
    """Local configuration only; no provider key is bundled in the package."""
    skin = """
        <screen name="SubDLSettingsScreen" position="center,center" size="1120,610" title="SUBDL EXTERNAL SUBTITLES">
            <eLabel position="0,0" size="1120,610" backgroundColor="#101820" />
            <widget name="config" position="45,45" size="1030,340" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#101820" transparent="1" />
            <widget name="keyhint" position="48,410" size="1024,54" font="Regular;25" foregroundColor="#b9d9ff" backgroundColor="#101820" transparent="1" />
            <widget name="help" position="48,486" size="1024,55" font="Regular;23" foregroundColor="#ffffff" backgroundColor="#101820" transparent="1" />
            <eLabel position="48,558" size="1024,2" backgroundColor="#39a9ff" />
        </screen>"""

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        current = load_subdl_settings()
        self.apiKey = ConfigPassword(default=current.get("api_key", ""), fixed_size=False)
        self.language = ConfigSelection(default=current.get("language", "ar"), choices=SUBDL_LANGUAGE_CHOICES)
        self.kind = ConfigSelection(default=current.get("kind", "standard"), choices=SUBDL_KIND_CHOICES)
        ConfigListScreen.__init__(self, [
            getConfigListEntry(tr("SubDL API Key  (OK to edit)"), self.apiKey),
            getConfigListEntry(tr("Default Subtitle Language"), self.language),
            getConfigListEntry(tr("Default Subtitle Type"), self.kind),
        ], session=session)
        self["keyhint"] = Label("")
        self["help"] = Label(tr("OK: Edit key   YELLOW: Import /tmp/tivimatee2/key.txt   GREEN: Save   EXIT: Close"))
        self._refreshKeyHint()
        self.setTitle("SUBDL EXTERNAL SUBTITLES")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.openKeyEditor,
            "yellow": self.importKeyFromTmp,
            "green": self.save,
            "red": self.close,
            "cancel": self.close,
        }, -1)

    def _refreshKeyHint(self):
        value = self.apiKey.value or ""
        self["keyhint"].setText(
            "Key status: key entered (%d characters)." % len(value)
            if value else "Key status: no key entered."
        )

    def openKeyEditor(self):
        current = self["config"].getCurrent()
        if not current:
            return
        if current[1] is not self.apiKey:
            try:
                ConfigListScreen.keyOK(self)
            except Exception:
                pass
            return
        self.session.openWithCallback(
            self._apiKeyEntered,
            SubDLKeyBoard,
            title="Enter SubDL API Key, then press GREEN",
            text=self.apiKey.value or ""
        )

    def _apiKeyEntered(self, value=None):
        if value is None:
            return
        try:
            if isinstance(value, bytes):
                value = value.decode("utf-8", "ignore")
        except Exception:
            pass
        self.apiKey.value = str(value).strip()
        self["config"].invalidateCurrent()
        self._refreshKeyHint()

    def importKeyFromTmp(self):
        """Import and save one local key without revealing its value."""
        try:
            value = _read_subdl_import_key()
            self.apiKey.value = value
            self["config"].invalidateCurrent()
            self._refreshKeyHint()
            save_subdl_settings(self.apiKey.value, self.language.value, self.kind.value)
            removed = False
            try:
                os.remove(SUBDL_IMPORT_FILE)
                removed = True
            except Exception:
                pass
            message = (
                "SubDL key imported and saved locally. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Remove /tmp/tivimatee2/key.txt manually to protect your key."
            )
            self.session.open(MessageBox, message, MessageBox.TYPE_INFO, timeout=5)
        except IOError:
            self.session.open(
                MessageBox,
                "File not found: /tmp/tivimatee2/key.txt. Put only one SubDL key in this file, then choose Import SubDL Key from MENU.",
                MessageBox.TYPE_INFO,
                timeout=7
            )
        except ValueError:
            self.session.open(
                MessageBox,
                "Invalid /tmp/tivimatee2/key.txt. It must contain exactly one non-empty SubDL key and be under 1 KB.",
                MessageBox.TYPE_ERROR,
                timeout=7
            )
        except Exception:
            self.session.open(MessageBox, "Could not import the SubDL key from /tmp/tivimatee2/key.txt.", MessageBox.TYPE_ERROR, timeout=5)

    def save(self):
        try:
            save_subdl_settings(self.apiKey.value, self.language.value, self.kind.value)
            # Closing directly avoids an image-specific blank MessageBox after saving.
            self.close(True)
        except Exception:
            self.session.open(MessageBox, "Could not save SubDL settings.", MessageBox.TYPE_ERROR, timeout=4)


class TiviMatePlayer(
        InfoBarBase,
        IPTVInfoBarShowHide,
        IPTVInfoBarPVRState,
        InfoBarAudioSelection,
        InfoBarSubtitleSupport,
        InfoBarSeek,
        InfoBarNotifications,
        InfoBarSummarySupport,
        InfoBarMoviePlayerSummarySupport,
        Screen):

    ENABLE_RESUME_SUPPORT = True
    ALLOW_SUSPEND = True

    skin = """<screen name="TiviMateVodPlayer" position="0,0" size="1920,1080" backgroundColor="#ff000000" flags="wfNoBorder">
        <eLabel position="0,864" size="1920,216" backgroundColor="#40000000" zPosition="1"/>
        <eLabel position="0,863" size="1920,1" backgroundColor="#ffffff" zPosition="1"/>
        <widget name="cover" pixmap="%s" position="30,720" size="220,330" alphatest="blend" zPosition="2"/>
        <widget name="speed" position="1368,888" size="54,48" font="Regular;36" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" valign="center" transparent="1" zPosition="3"/>
        <widget name="notification" position="321,934" size="1143,24" font="Regular;22" noWrap="1" foregroundColor="#b9d9ff" backgroundColor="#40000000" halign="left" transparent="1" zPosition="4"/>
        <widget name="subtitleHint" position="321,1022" size="760,30" font="Regular;22" foregroundColor="#73D4FF" backgroundColor="#40000000" transparent="1" zPosition="4"/>
        <widget source="session.CurrentService" render="Label" position="321,888" size="900,48" font="Regular;36" noWrap="1" foregroundColor="#ffd21f" backgroundColor="#40000000" transparent="1" zPosition="3"><convert type="ServiceName">Name</convert></widget>
        <widget name="statusicon" position="1428,894" size="38,38" zPosition="5" alphatest="blend" pixmaps="%s,%s,%s,%s,%s,%s,%s"/>
        <eLabel position="280,894" size="1,156" backgroundColor="#ffffff" zPosition="1"/>
        <eLabel position="1512,894" size="1,156" backgroundColor="#ffffff" zPosition="1"/>
        <widget name="vodProgress" position="321,1000" size="1143,14" borderWidth="1" borderColor="#5a0000" foregroundColor="#e31b23" backgroundColor="#1a000000" zPosition="7"/>
        <widget name="vodPosition" position="321,956" size="220,48" font="Regular;30" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="left" transparent="1" zPosition="7"/>
        <widget name="vodDuration" position="1244,956" size="220,48" font="Regular;30" noWrap="1" foregroundColor="#ffffff" backgroundColor="#40000000" halign="right" transparent="1" zPosition="7"/>
        <widget source="global.CurrentTime" render="Label" position="1560,888" size="318,48" font="Regular;30" foregroundColor="#ffffff" backgroundColor="#40000000" transparent="1" zPosition="2"><convert type="ClockToText">Format:%%H:%%M | %%A</convert></widget>
        <ePixmap pixmap="%s" position="1560,939" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1656,939" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1752,939" size="90,36" alphatest="blend" zPosition="2"/>
        <ePixmap pixmap="%s" position="1560,981" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1656,981" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1752,981" size="90,36" alphatest="blend" zPosition="2"/>
        <ePixmap pixmap="%s" position="1560,1023" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1656,1023" size="90,36" alphatest="blend" zPosition="2"/><ePixmap pixmap="%s" position="1752,1023" size="90,36" alphatest="blend" zPosition="2"/>
        <widget source="streamcat" render="Label" position="1560,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
        <widget source="streamtype" render="Label" position="1560,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
        <widget source="extension" render="Label" position="1560,1023" size="90,36" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"/>
        <widget source="session.CurrentService" render="Label" position="1656,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">VideoWidth</convert></widget>
        <widget source="session.CurrentService" render="Label" position="1656,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">VideoHeight</convert></widget>
        <widget source="session.CurrentService" render="Label" position="1656,1023" size="90,36" font="Regular;24" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">Framerate</convert></widget>
        <widget text="UHD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">IsUHD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="FHD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">IsFHD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="HD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">IsHD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="SD" render="FixedLabel" source="session.CurrentService" position="1752,939" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">IsSD</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="16:9" render="FixedLabel" source="session.CurrentService" position="1752,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">IsWidescreen</convert><convert type="ConditionalShowHide"/></widget>
        <widget text="4:3" render="FixedLabel" source="session.CurrentService" position="1752,981" size="90,36" font="Regular;27" foregroundColor="#ffffff" backgroundColor="#40000000" valign="center" halign="center" transparent="1" zPosition="3"><convert type="TiviMateTestServiceInfo">IsWidescreen</convert><convert type="ConditionalShowHide">Invert</convert></widget>
        <widget source="session.CurrentService" render="Pixmap" pixmap="%s" position="1752,1023" size="90,36" alphatest="blend" zPosition="2"><convert type="TiviMateTestServiceInfo">IsMultichannel</convert><convert type="ConditionalShowHide"/></widget>
        <widget source="session.CurrentService" render="Pixmap" pixmap="%s" position="1848,939" size="38,38" alphatest="blend" zPosition="2"><convert type="TiviMateTestServiceInfo">AudioTracksAvailable</convert><convert type="ConditionalShowHide"/></widget>
    </screen>""" % tuple(
        [DEFAULT_COVER,
         os.path.join(ASSET, "state_play.png"), os.path.join(ASSET, "state_pause.png"), os.path.join(ASSET, "state_stop.png"),
         os.path.join(ASSET, "state_ff.png"), os.path.join(ASSET, "state_rw.png"), os.path.join(ASSET, "state_slow.png"), os.path.join(ASSET, "state_blank.png")] +
        [os.path.join(ASSET, "stream-box.png")] * 9 +
        [os.path.join(ASSET, "dolby.png"), os.path.join(ASSET, "key_audio.png")]
    )

    def __init__(self, session, service, item=None):
        Screen.__init__(self, session)
        self.session = session
        self.item = item or {}
        self.streamurl = ""
        try:
            self.streamurl = service.getPath()
        except Exception:
            try:
                self.streamurl = service.toString().split(":", 10)[-1]
            except Exception:
                pass
        self.servicetype = _load_player_type()
        self.originalservicetype = int(self.servicetype)
        if self.item.get("_catchup"):
            try:
                self.servicetype = int(self.item.get("_catchup_service_type") or self.servicetype)
            except Exception:
                pass
        self.original_service = None
        self._external_subs = None
        self._external_subtitle_path = ""
        self._subssupport = None
        self._subtitle_thread = None
        self._closing = False
        self._resume_from_continue = bool(self.item.get("_continue_resume"))
        self._is_stalker_resume = self.item.get("_source_type") == "stalker" or self._resume_from_continue
        self._resume_key = _resume_key(self.item, self.streamurl)
        self._resume_prompted = False
        self._resume_pending_ticks = 0
        self._resume_seek_attempts = 0
        self._resume_seek_sent = False
        self._resume_last_position = 0
        self._resume_stable_reads = 0
        self._subtitle_sync_attempts = 0
        self._subtitle_sync_target_ticks = 0
        self._resume_timer = eTimer()
        try:
            self._resume_timer_conn = self._resume_timer.timeout.connect(self._resumePeriodicSave)
        except Exception:
            self._resume_timer.callback.append(self._resumePeriodicSave)
        self._resume_seek_timer = eTimer()
        try:
            self._resume_seek_timer_conn = self._resume_seek_timer.timeout.connect(self._applyResumeSeek)
        except Exception:
            self._resume_seek_timer.callback.append(self._applyResumeSeek)
        self._subtitle_sync_timer = eTimer()
        try:
            self._subtitle_sync_timer_conn = self._subtitle_sync_timer.timeout.connect(self._syncExternalSubtitleToPlayback)
        except Exception:
            self._subtitle_sync_timer.callback.append(self._syncExternalSubtitleToPlayback)
        self._record_process = None
        self._record_path = ""
        self._episode_items = list(self.item.get("_episode_items") or [])
        try:
            self._episode_index = int(self.item.get("_episode_index") or 0)
        except Exception:
            self._episode_index = 0
        self._episode_source = dict(self.item.get("_episode_source") or {})
        try:
            self.original_service = self.session.nav.getCurrentlyPlayingServiceReference()
        except Exception:
            pass

        # OpenATV's subtitle picker calls self.enableSubtitle().  The standard
        # mixin supplies that interface, including selected_subtitle tracking
        # and the receiver-owned subtitle display window.
        for klass in (InfoBarBase, IPTVInfoBarShowHide, InfoBarAudioSelection, InfoBarSubtitleSupport, InfoBarSeek,
                      InfoBarNotifications, InfoBarSummarySupport, InfoBarMoviePlayerSummarySupport):
            klass.__init__(self)
        IPTVInfoBarPVRState.__init__(self)

        self["streamcat"] = StaticText("VOD")
        self["streamtype"] = StaticText(str(self.servicetype))
        ext = os.path.splitext(self.streamurl.split("?", 1)[0])[-1].replace(".", "").upper() or "STREAM"
        self["extension"] = StaticText(ext)
        self["cover"] = Pixmap()
        self["vodProgress"] = ProgressBar()
        try:
            self["vodProgress"].setRange((0, 1000))
        except Exception:
            pass
        self["vodPosition"] = Label("00:00")
        self["vodDuration"] = Label("00:00")
        self["speed"] = Label("")
        self["notification"] = Label("")
        self["subtitleHint"] = Label(tr("RED - Edit Subtitles"))
        self["statusicon"] = MultiPixmap()
        self._notification_timer = eTimer()
        try:
            self._notification_timer_conn = self._notification_timer.timeout.connect(self._clearNotification)
        except Exception:
            self._notification_timer.callback.append(self._clearNotification)

        self.PicLoad = ePicLoad()
        try:
            self.PicLoad.PictureData.get().append(self._decodeCover)
        except Exception:
            self._pic_conn = self.PicLoad.PictureData.connect(self._decodeCover)
        self._cover_file = None
        self._progress_timer = eTimer()
        try:
            self._progress_timer_conn = self._progress_timer.timeout.connect(self._updateVodProgress)
        except Exception:
            self._progress_timer.callback.append(self._updateVodProgress)

        self._catchup_candidates = list(self.item.get("_catchup_candidates") or [])
        if self.streamurl and self.streamurl not in self._catchup_candidates:
            self._catchup_candidates.insert(0, self.streamurl)
        self._catchup_retry_index = 0
        self._catchup_retry_attempt = 0
        self._catchup_retry_timer = eTimer()
        try:
            self._catchup_retry_conn = self._catchup_retry_timer.timeout.connect(self._checkCatchupPlayback)
        except Exception:
            self._catchup_retry_timer.callback.append(self._checkCatchupPlayback)

        self["actions"] = ActionMap([
            "OkCancelActions", "InfobarShowHideActions", "ColorActions", "MoviePlayerActions",
            "MediaPlayerActions", "DirectionActions", "ChannelSelectBaseActions", "MenuActions", "NumberActions"
        ], {
            "cancel": self.back, "stop": self.back, "red": self.openSubtitleEditor,
            "ok": self.refreshInfobar, "toggleShow": self.refreshInfobar,
            "menu": self.openPlayerMenu, "info": self.openPlayerMenu, "tv": self.toggleStreamType,
            "green": self.audioSelection,
            "channelUp": self.nextEpisode,
            "channelDown": self.prevEpisode,
            "yellow": self.autoDownloadExternalSubtitle,
            "blue": self.openSubsSupport,
            
            "0": self.seekNumber0,
            "1": self.seekNumber1,
            "3": self.seekNumber3,
            "4": self.seekNumber4,
            "6": self.seekNumber6,
            "7": self.seekNumber7,
            "9": self.seekNumber9,
        }, -2)

        self._event_tracker = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self._serviceStarted,
            iPlayableService.evEOF: self._serviceEOF,
        })
        self.onFirstExecBegin.append(self.playStream)
        self.onClose.append(self._cleanup)

    def _instantNumberSeek(self, seconds):
        """Direct numeric seek with no aggregation timer or delayed dispatch."""
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if not seek:
                return
            seconds = int(seconds)
            if seconds == 0:
                seek.seekTo(0)
            else:
                direction = 1 if seconds > 0 else -1
                seek.seekRelative(direction, abs(seconds) * 90000)
            try:
                self.refreshInfobar()
            except Exception:
                pass
        except Exception:
            pass

    def seekNumber0(self):
        self._instantNumberSeek(0)

    def seekNumber1(self):
        self._instantNumberSeek(-15)

    def seekNumber3(self):
        self._instantNumberSeek(15)

    def seekNumber4(self):
        self._instantNumberSeek(-60)

    def seekNumber6(self):
        self._instantNumberSeek(60)

    def seekNumber7(self):
        self._instantNumberSeek(-300)

    def seekNumber9(self):
        self._instantNumberSeek(300)

    def refreshInfobar(self):
        IPTVInfoBarShowHide.OkPressed(self)

    def _externalSubtitleIsActive(self):
        """Return true only while this player owns a successfully loaded SRT.

        IPTV servers can advertise many duplicated embedded subtitle tracks.  An
        external SRT is rendered by SubsSupport and is not part of Enigma2's
        native `getSubtitleList()`, so opening the native picker after a
        successful attach is both misleading and can replace the user's view.
        """
        path = getattr(self, "_external_subtitle_path", "")
        support = getattr(self, "_external_subs", None)
        if not path or not support or not os.path.isfile(path):
            return False
        checker = getattr(support, "isSubsLoaded", None)
        if callable(checker):
            try:
                return bool(checker())
            except Exception:
                # Older image ports may expose a broken status probe even while
                # their external renderer is running.  The live object and SRT
                # path are then the safest compatibility evidence.
                return True
        return True

    def subtitleSelection(self):
        """Reserve TiviMate's subtitle controls for external SRT files only.

        A server can publish many repeated `embedded` tracks.  They belong to
        the stream and cannot be safely de-duplicated by the plugin, so the VOD
        player deliberately never opens Enigma2's native track picker.  The
        user is instead guided to the independent SubDL workflow.
        """
        if self._externalSubtitleIsActive():
            message = "External SRT is active. Server embedded subtitle tracks are ignored."
        else:
            message = "No external SRT is active. Use YELLOW for SubDL; server embedded tracks are ignored."
        self._showNotification(message, MessageBox.TYPE_INFO, timeout=5)
        return 1

    def subtitleQuickMenu(self):
        """Use the same external-only policy on images with a quick subtitle key."""
        return self.subtitleSelection()

    def playStream(self):
        if not self.streamurl:
            self.session.open(MessageBox, "Invalid playback URL.", MessageBox.TYPE_ERROR, timeout=4)
            return
        try:
            ref = eServiceReference(int(self.servicetype), 0, self.streamurl)
            ref.setName(self.item.get("name") or self.item.get("title") or "IPTV")
            self.session.nav.playService(ref)
            self["streamtype"].setText(str(self.servicetype))
            self.downloadCover()
            try:
                self._progress_timer.start(3000, False)
            except Exception:
                pass
            self._updateVodProgress()
            self.show()
            self.startHideTimer()
            if self.item.get("_catchup") and len(self._catchup_candidates) > 1:
                try:
                    self._catchup_retry_timer.stop()
                    self._catchup_retry_timer.start(7000, True)
                except Exception:
                    pass
        except Exception as exc:
            self.session.open(MessageBox, "Could not start playback:\n%s" % exc, MessageBox.TYPE_ERROR, timeout=5)

    def _checkCatchupPlayback(self):
        """Retry only Catch-up URLs that never became a real playable service."""
        if self._closing or not self.item.get("_catchup"):
            return
        try:
            _seek, pos, length = self._seekInfo()
        except Exception:
            pos, length = 0, 0

        # Position or duration proves the archive stream is alive.
        if int(pos or 0) > 0 or int(length or 0) > 0:
            return

        self._catchup_retry_attempt += 1
        next_index = self._catchup_retry_index + 1
        if next_index >= len(self._catchup_candidates):
            try:
                self._showNotification(
                    "Catch-up: provider did not play this archive item.",
                    MessageBox.TYPE_ERROR, timeout=5
                )
            except Exception:
                pass
            return

        self._catchup_retry_index = next_index
        self.streamurl = str(self._catchup_candidates[next_index] or "")
        if not self.streamurl:
            return self._checkCatchupPlayback()

        try:
            self.session.nav.stopService()
        except Exception:
            pass

        try:
            ref = eServiceReference(int(self.servicetype), 0, self.streamurl)
            ref.setName(self.item.get("name") or self.item.get("title") or "Catch-up")
            self.session.nav.playService(ref)
            try:
                self["notification"].setText(
                    "Catch-up retry %d/%d" % (
                        self._catchup_retry_index + 1,
                        len(self._catchup_candidates)
                    )
                )
            except Exception:
                pass
            self._catchup_retry_timer.start(7000, True)
        except Exception:
            try:
                self._catchup_retry_timer.start(250, True)
            except Exception:
                pass

    def _fmtVodClock(self, ticks):
        try:
            sec = max(0, int(ticks) // 90000)
        except Exception:
            sec = 0
        if sec >= 3600:
            return "%02d:%02d:%02d" % (sec // 3600, (sec % 3600) // 60, sec % 60)
        return "%02d:%02d" % (sec // 60, sec % 60)

    def _updateVodProgress(self):
        try:
            _seek, pos, length = self._seekInfo()
            self["vodPosition"].setText(self._fmtVodClock(pos))
            self["vodDuration"].setText(self._fmtVodClock(length))
            value = int((float(pos) / float(length)) * 1000.0) if length > 0 else 0
            self["vodProgress"].setValue(max(0, min(1000, value)))
        except Exception:
            pass

    def _serviceStarted(self):
        try:
            self["statusicon"].setPixmapNum(0)
            self["speed"].setText(tr(""))
        except Exception:
            pass
        try:
            self._resume_timer.stop()
            self._resume_seek_timer.stop()
        except Exception:
            pass
        self._resume_pending_ticks = 0
        # Save progress for every VOD/episode. Only Stalker or an explicit
        # Continue Watching launch enables the resume-seek path.
        try:
            self._resume_timer.start(30000, False)
        except Exception:
            pass
        if self._is_stalker_resume:
            self._resume_prompted = False
            if self._resume_from_continue:
                try: self._resume_pending_ticks = int(self.item.get("_continue_position") or 0) * 90000
                except Exception: self._resume_pending_ticks = 0
                self._resume_prompted = True
                self._resume_seek_attempts = 0
                self._resume_seek_sent = False
                try: self._resume_seek_timer.start(900, True)
                except Exception: self._applyResumeSeek()
            else:
                try: self._resume_seek_timer.start(1200, True)
                except Exception: self._applyResumeSeek()
        else:
            self._resume_prompted = True

    def _serviceEOF(self):
        self._clearResumeEntry()
        try:
            self["statusicon"].setPixmapNum(2)
            self.show()
        except Exception:
            pass

    def _seekInfo(self):
        try:
            service = self.session.nav.getCurrentService()
            seek = service and service.seek()
            if not seek:
                return None, 0, 0
            pos = seek.getPlayPosition()
            length = seek.getLength()
            pos_ticks = int(pos[1]) if pos and not pos[0] else 0
            len_ticks = int(length[1]) if length and not length[0] else 0
            return seek, pos_ticks, len_ticks
        except Exception:
            return None, 0, 0

    def _offerResume(self):
        if self._closing or not self._is_stalker_resume or self._resume_prompted:
            return
        self._resume_prompted = True
        data = _resume_load()
        row = data.get(self._resume_key) or {}
        try:
            seconds = int(row.get("position", 0))
        except Exception:
            seconds = 0
        if seconds < RESUME_MIN_SECONDS:
            return
        self.lockShow()
        choices = [
            ("Continue from %s" % _resume_clock(seconds), "resume"),
            ("Start from beginning", "start"),
        ]
        self.session.openWithCallback(
            self._resumeChoice, ChoiceBox,
            title="Continue watching?", list=choices, selection=0
        )

    def _resumeChoice(self, choice):
        self.unlockShow()
        if not choice:
            return
        action = choice[1] if isinstance(choice, (tuple, list)) and len(choice) > 1 else choice
        if action == "resume":
            row = _resume_load().get(self._resume_key) or {}
            try:
                self._resume_pending_ticks = int(row.get("position", 0)) * 90000
            except Exception:
                self._resume_pending_ticks = 0
            self._resume_seek_attempts = 0
            self._resume_seek_sent = False
            self._resume_last_position = 0
            self._resume_stable_reads = 0
            try:
                self._resume_seek_timer.start(600, True)
            except Exception:
                self._applyResumeSeek()
        elif action == "start":
            self._clearResumeEntry()

    def _applyResumeSeek(self):
        if not self._is_stalker_resume:
            return

        # Do not touch playback until the service has actually started.
        # A valid current position or duration proves that the playback backend
        # is alive. This keeps normal movie startup identical to the old player.
        if not self._resume_pending_ticks:
            self._offerResume()
            return

        seek, pos, length = self._seekInfo()
        target = int(self._resume_pending_ticks)
        self._resume_seek_attempts += 1

        playback_ready = bool(seek and (pos > 0 or length > 0))
        if not playback_ready:
            # Never send seek commands while the movie is still sitting at 00:00.
            # Give the backend time to start, then abandon resume silently and
            # leave normal playback alone.
            if self._resume_seek_attempts >= 12:
                self._resume_pending_ticks = 0
                self._resume_seek_sent = False
                return
            try:
                self._resume_seek_timer.start(1000, True)
            except Exception:
                pass
            return

        if length > 0 and target >= max(0, length - RESUME_END_MARGIN_SECONDS * 90000):
            self._clearResumeEntry()
            self._resume_pending_ticks = 0
            self._resume_seek_sent = False
            return

        tolerance = 10 * 90000

        if self._resume_seek_sent:
            if pos > 0 and abs(int(pos) - target) <= tolerance:
                self._resume_pending_ticks = 0
                self._resume_seek_sent = False
                self._showNotification("Resumed from %s" % _resume_clock(target // 90000), MessageBox.TYPE_INFO, timeout=4)
                self._scheduleSubtitleSync()
                return

            # One seek was already sent. Do not hammer the playback engine.
            if self._resume_seek_attempts >= 8:
                self._resume_pending_ticks = 0
                self._resume_seek_sent = False
                return
            try:
                self._resume_seek_timer.start(1200, True)
            except Exception:
                pass
            return

        # Playback is confirmed alive: now and only now apply the saved point.
        try:
            seek.seekTo(target)
            self._resume_seek_sent = True
        except Exception:
            self._resume_pending_ticks = 0
            self._resume_seek_sent = False
            return

        try:
            self._resume_seek_timer.start(1400, True)
        except Exception:
            pass

    def _scheduleSubtitleSync(self, target_ticks=None):
        self._subtitle_sync_attempts = 0
        if target_ticks is not None:
            try:
                self._subtitle_sync_target_ticks = max(0, int(target_ticks))
            except Exception:
                self._subtitle_sync_target_ticks = 0
        try:
            self._subtitle_sync_timer.stop()
            self._subtitle_sync_timer.start(150, True)
        except Exception:
            self._syncExternalSubtitleToPlayback()

    def _syncExternalSubtitleToPlayback(self):
        """Ask SubsSupport to align itself to the receiver's current VOD PTS.

        Do not inject a large artificial subtitle delay here. SubsSupport's
        playAfterSeek() already reads the active service PTS and selects the
        matching subtitle line. Repeating that official operation briefly is
        enough for slower images whose subtitle engine becomes ready a moment
        after loadSubs().
        """
        support = getattr(self, "_external_subs", None) or getattr(self, "_subssupport", None)
        if support is None:
            return
        self._subtitle_sync_attempts += 1
        sync = getattr(support, "playAfterSeek", None)
        if callable(sync):
            try:
                sync()
            except Exception:
                pass
        else:
            resume = getattr(support, "resumeSubs", None)
            if callable(resume):
                try:
                    resume()
                except Exception:
                    pass
        if self._subtitle_sync_attempts < 6 and not getattr(self, "_closing", False):
            try:
                self._subtitle_sync_timer.start(400, True)
            except Exception:
                pass

    def _resumePeriodicSave(self):
        self._saveResumePosition()

    def _saveResumePosition(self):
        if self._closing:
            return
        _seek, position, length = self._seekInfo()
        seconds = int(position // 90000) if position > 0 else 0
        total = int(length // 90000) if length > 0 else 0
        if seconds < RESUME_MIN_SECONDS:
            return
        if total > 0 and total - seconds <= RESUME_END_MARGIN_SECONDS:
            self._clearResumeEntry()
            return
        data = _resume_load()
        clean_item = {}
        for key, value in (self.item or {}).items():
            if str(key).startswith("_"):
                continue
            if isinstance(value, (str, int, float, bool)) or value is None:
                clean_item[key] = value
        inferred_kind = self.item.get("_kind")
        if inferred_kind not in ("vod", "movie", "episode", "series", "tv", "show"):
            has_episode_identity = bool(
                self.item.get("episode_num") or
                self.item.get("episode_number") or
                self.item.get("_subdl_episode") or
                (self.item.get("season") not in (None, "") and self.item.get("episode") not in (None, ""))
            )
            inferred_kind = "episode" if (has_episode_identity or self.item.get("_tmdb_kind") == "series") else "vod"
        source_key = str(self.item.get("_source_key") or "")
        source_type = str(self.item.get("_source_type") or "xtream")
        content_id = _resume_content_identity(self.item)

        server_entry = {
            "source_key": source_key,
            "source_type": source_type,
            "streamurl": self.streamurl,
            "service_type": int(self.servicetype),
            "item": clean_item,
        }

        # One Continue Watching record per title/episode, with a direct playback
        # entry for every server on which the user has actually watched it.
        canonical_key = None
        existing = None
        for old_key, old_row in list(data.items()):
            if not isinstance(old_row, dict):
                continue
            old_content = str(old_row.get("content_id") or "")
            if not old_content:
                old_item = old_row.get("item") or {}
                try:
                    old_content = _resume_content_identity(old_item)
                except Exception:
                    old_content = ""
            if old_content and old_content == content_id:
                canonical_key = old_key
                existing = old_row
                break

        if canonical_key is None:
            canonical_key = self._resume_key
            existing = {}

        servers = dict((existing or {}).get("servers") or {})
        # Migrate a legacy single-server row into the new mapping.
        legacy_key = str((existing or {}).get("source_key") or "")
        legacy_url = str((existing or {}).get("streamurl") or "")
        if legacy_url and legacy_key and legacy_key not in servers:
            servers[legacy_key] = {
                "source_key": legacy_key,
                "source_type": (existing or {}).get("source_type") or "xtream",
                "streamurl": legacy_url,
                "service_type": int((existing or {}).get("service_type") or 4097),
                "item": dict((existing or {}).get("item") or {}),
            }
        if source_key:
            servers[source_key] = server_entry

        record = dict(existing or {})
        record.update({
            "content_id": content_id,
            "position": seconds,
            "length": total,
            "title": self.item.get("name") or self.item.get("title") or record.get("title") or "",
            "series_title": self.item.get("series_name") or self.item.get("_tmdb_title") or record.get("series_title") or "",
            "season": self.item.get("season") or self.item.get("season_number") or self.item.get("_subdl_season") or record.get("season") or "",
            "episode": self.item.get("episode_num") or self.item.get("episode_number") or self.item.get("episode") or self.item.get("_subdl_episode") or record.get("episode") or "",
            "updated": int(time.time()),
            "source_type": source_type,
            "streamurl": self.streamurl,
            "poster": self.item.get("_player_cover") or self.item.get("stream_icon") or self.item.get("cover_big") or self.item.get("cover") or self.item.get("movie_image") or self.item.get("poster_url") or self.item.get("poster_path") or record.get("poster") or "",
            "backdrop": self.item.get("_player_backdrop") or self.item.get("backdrop_path") or self.item.get("backdrop") or self.item.get("backdrop_url") or record.get("backdrop") or "",
            "source_key": source_key,
            "kind": inferred_kind,
            "service_type": int(self.servicetype),
            "item": clean_item,
            "servers": servers,
        })
        data[canonical_key] = record

        # Remove any duplicate legacy record for the same title/episode.
        for old_key, old_row in list(data.items()):
            if old_key == canonical_key or not isinstance(old_row, dict):
                continue
            try:
                old_content = str(old_row.get("content_id") or _resume_content_identity(old_row.get("item") or {}))
            except Exception:
                old_content = ""
            if old_content == content_id:
                old_servers = dict(old_row.get("servers") or {})
                for skey, sentry in old_servers.items():
                    if skey and skey not in record["servers"]:
                        record["servers"][skey] = sentry
                legacy_skey = str(old_row.get("source_key") or "")
                if legacy_skey and old_row.get("streamurl") and legacy_skey not in record["servers"]:
                    record["servers"][legacy_skey] = {
                        "source_key": legacy_skey,
                        "source_type": old_row.get("source_type") or "xtream",
                        "streamurl": old_row.get("streamurl"),
                        "service_type": int(old_row.get("service_type") or 4097),
                        "item": dict(old_row.get("item") or {}),
                    }
                try:
                    del data[old_key]
                except Exception:
                    pass
        data[canonical_key] = record
        # Keep the file small on receivers with limited flash.
        if len(data) > 300:
            rows = sorted(data.items(), key=lambda pair: int((pair[1] or {}).get("updated", 0)), reverse=True)[:250]
            data = dict(rows)
        _resume_save(data)

    def _clearResumeEntry(self):
        data = _resume_load()
        target = _resume_content_identity(self.item)
        changed = False
        for key, row in list(data.items()):
            try:
                rid = str((row or {}).get("content_id") or _resume_content_identity((row or {}).get("item") or {}))
            except Exception:
                rid = ""
            if key == self._resume_key or (target and rid == target):
                try:
                    del data[key]
                    changed = True
                except Exception:
                    pass
        if changed:
            _resume_save(data)



    def _mainThread(self, callback):
        if getattr(self, "_closing", False):
            return
        try:
            if reactor is not None:
                reactor.callFromThread(callback)
                return
        except Exception:
            pass
        callback()

    def _clearNotification(self):
        try:
            self._notification_timer.stop()
        except Exception:
            pass
        try:
            self["notification"].setText(tr(""))
        except Exception:
            pass

    def _showNotification(self, message, msg_type=MessageBox.TYPE_INFO, timeout=5):
        """Show a non-modal inline status message safely inside the player.

        Pure2startup rejects ``session.open(MessageBox, ...)`` while processing
        delayed ChoiceBox callbacks.  This method deliberately does not open a
        screen or queue a MessageBox; it only updates an existing Label and
        clears it with the player's own timer.  ``msg_type`` is kept for callers
        and future colour handling without changing the safe execution path.
        """
        if getattr(self, "_closing", False):
            return
        try:
            self["notification"].setText(message)
            self.show()
            self._notification_timer.stop()
            self._notification_timer.start(max(1, int(timeout)) * 1000, True)
        except Exception:
            pass

    def _hasSubsSupport(self):
        try:
            from Plugins.Extensions.SubsSupport.subtitles import SubsSupport  # noqa: F401
            return True
        except Exception:
            return False

    def _clearSubsSupport(self):
        support = getattr(self, "_subssupport", None)
        self._subssupport = None
        if support is None:
            return
        try:
            support.hideSubsDialog()
        except Exception:
            pass
        try:
            support.exitSubs()
        except Exception:
            pass

    def _subsSupportSearchTitle(self):
        """Use the movie/episode metadata, never the IPTV service/channel name."""
        item = self.item or {}
        for key in ("original_title", "title", "name", "movie_name", "series_name", "episode_name"):
            value = item.get(key)
            if value:
                try:
                    from .subtitle_title import clean_subtitle_title
                    cleaned = clean_subtitle_title(value)
                    return cleaned or str(value).strip()
                except Exception:
                    return str(value).strip()
        return ""

    def openSubsSupport(self):
        """Choose regular SubsSupport first, or SubsSupport Pro second."""
        choices = [("SubsSupport", "regular"), ("SubsSupport Pro", "pro")]
        self.session.openWithCallback(
            self._subtitleSupportChoice, ChoiceBox,
            title="Subtitle support", list=choices
        )

    def _subtitleSupportChoice(self, choice=None):
        if not choice:
            return
        value = choice[1]
        search_title = self._subsSupportSearchTitle()
        try:
            if value == "regular":
                from .subtitle_picker_bridge import open_subtitle_search
                if open_subtitle_search(self, search_title):
                    return
                message = "SubsSupport is not installed, or is incompatible with this receiver image."
            else:
                from .subtitle_picker_bridge import open_subtitle_pro
                if open_subtitle_pro(self, search_title):
                    return
                message = "SubsSupport Pro is not installed, or is incompatible with this receiver image."
        except Exception:
            message = "Could not open the selected subtitle support plugin."
        self._showNotification(message, MessageBox.TYPE_ERROR, timeout=6)

    def openSubtitleEditor(self):
        """Open the active SubsSupport subtitle-line picker with RED."""
        try:
            from .subtitle_picker_bridge import open_active_subtitle_picker
            supports = [getattr(self, "_external_subs", None), getattr(self, "_subssupport", None)]
            if open_active_subtitle_picker(self, supports):
                return
        except Exception:
            pass
        self._showNotification(
            "No editable subtitle is loaded. Download and start the subtitle first.",
            MessageBox.TYPE_INFO,
            timeout=5
        )

    def _openSubDLSettings(self, resume_search=False, resume_auto=False):
        self._resume_subdl_search = bool(resume_search)
        self._resume_subdl_auto = bool(resume_auto)
        self.lockShow()
        self.session.openWithCallback(self._subdlSettingsClosed, SubDLSettingsScreen)

    def _subdlSettingsClosed(self, saved=None):
        self.unlockShow()
        resume_search = bool(getattr(self, "_resume_subdl_search", False))
        resume_auto = bool(getattr(self, "_resume_subdl_auto", False))
        self._resume_subdl_search = False
        self._resume_subdl_auto = False
        if not saved or not load_subdl_settings().get("api_key"):
            return
        if resume_auto:
            self.autoDownloadExternalSubtitle()
        elif resume_search:
            self.openExternalSubtitleSearch()


    def _importSubDLKeyFromMenu(self):
        """Import the local key directly from the player's MENU list."""
        try:
            value = _read_subdl_import_key()
            current = load_subdl_settings()
            save_subdl_settings(value, current.get("language", "ar"), current.get("kind", "standard"))
            removed = False
            try:
                os.remove(SUBDL_IMPORT_FILE)
                removed = True
            except Exception:
                pass
            message = (
                "SubDL key imported and saved locally. The temporary file was removed."
                if removed else
                "SubDL key imported and saved locally. Remove /tmp/tivimatee2/key.txt manually to protect your key."
            )
            self._showNotification(message, MessageBox.TYPE_INFO, timeout=6)
        except IOError:
            self._showNotification(
                "File not found: /tmp/tivimatee2/key.txt. Put only one SubDL key in this file, then open MENU and choose Import SubDL Key.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
        except ValueError:
            self._showNotification(
                "Invalid /tmp/tivimatee2/key.txt. It must contain exactly one non-empty SubDL key and be under 1 KB.",
                MessageBox.TYPE_ERROR,
                timeout=8
            )
        except Exception:
            self._showNotification("Could not import the SubDL key from /tmp/tivimatee2/key.txt.", MessageBox.TYPE_ERROR, timeout=6)

    def autoDownloadExternalSubtitle(self):
        """YELLOW: search, download, and load the best matching SRT in one step."""
        if getattr(self, "_auto_subtitle_busy", False):
            self._showNotification("Automatic subtitle download is already running...", MessageBox.TYPE_INFO, timeout=4)
            return
        if not self._hasSubsSupport():
            self._showNotification(
                "To display external subtitles, install SubsSupport from your receiver's plugin feed, then reopen the video.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        settings = load_subdl_settings()
        if not settings.get("api_key"):
            self._showNotification(
                "Import your SubDL API key first: put it in /tmp/tivimatee2/key.txt, then choose Import SubDL API Key from MENU.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        self._auto_subtitle_busy = True
        self._showNotification("Searching and downloading the best subtitle...", MessageBox.TYPE_INFO, timeout=5)
        self._subtitle_thread = threading.Thread(
            target=self._autoDownloadExternalSubtitle,
            args=(settings.get("api_key", ""), settings.get("language", "ar"), settings.get("kind", "standard")),
            name="TiviMateSubDLAutoDownload"
        )
        self._subtitle_thread.daemon = True
        self._subtitle_thread.start()

    def _downloadBestExternalSubtitle(self, api_key, rows):
        """Download the highest-ranked usable SubDL SRT, trying two fallbacks.

        SubDL can occasionally return a stale or temporarily unavailable file URL.
        For the automatic action, trying the next compatible release avoids a
        needless failure while preserving the manual release chooser unchanged.
        """
        errors = []
        for row in list(rows or [])[:3]:
            try:
                return SubDLClient(api_key).download(row), row
            except SubDLError as exc:
                errors.append(str(exc))
        if errors:
            raise SubDLError("SubDL found subtitles, but none of the available downloads could be loaded. " + errors[-1])
        raise SubDLError("No usable SubDL subtitle download was found.")

    def _autoDownloadExternalSubtitle(self, api_key, language, kind):
        try:
            rows = SubDLClient(api_key).search(self.item, language, kind)
            if not rows:
                raise SubDLError("No matching subtitle was found. Open MENU to try another language or release.")
            path, row = self._downloadBestExternalSubtitle(api_key, rows)
            self._mainThread(lambda: self._attachAutoExternalSubtitle(path, row))
        except SubDLError as exc:
            message = str(exc)
            self._mainThread(lambda: self._autoExternalSubtitleFailed(message))
        except Exception:
            self._mainThread(lambda: self._autoExternalSubtitleFailed("Could not automatically download the external subtitle."))

    def _attachAutoExternalSubtitle(self, path, row):
        self._auto_subtitle_busy = False
        self._attachExternalSubtitle(path, row)

    def _autoExternalSubtitleFailed(self, message):
        self._auto_subtitle_busy = False
        self._showNotification(message, MessageBox.TYPE_ERROR, timeout=7)

    def openExternalSubtitleSearch(self):
        """Manual SubDL search remains available from MENU."""
        if not self._hasSubsSupport():
            self._showNotification(
                "To display external subtitles, install SubsSupport from your receiver's plugin feed, then reopen the video.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        settings = load_subdl_settings()
        if not settings.get("api_key"):
            self._showNotification(
                "Import your SubDL API key first: put it in /tmp/tivimatee2/key.txt, then choose Import SubDL API Key from MENU.",
                MessageBox.TYPE_INFO,
                timeout=8
            )
            return
        self.lockShow()
        self.session.openWithCallback(
            self._subtitleLanguageSelected,
            ChoiceBox,
            title="Choose External Subtitle Language",
            list=SUBDL_LANGUAGE_CHOICES,
            selection=0
        )

    def _subtitleLanguageSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        self._subtitle_language = selected[1]
        self.lockShow()
        self.session.openWithCallback(
            self._subtitleKindSelected,
            ChoiceBox,
            title="Choose Subtitle Type",
            list=SUBDL_KIND_CHOICES,
            selection=0
        )

    def _subtitleKindSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        language = getattr(self, "_subtitle_language", "ar")
        kind = selected[1]
        settings = load_subdl_settings()
        self._showNotification("Searching for external subtitles...", MessageBox.TYPE_INFO, timeout=3)
        self._subtitle_thread = threading.Thread(
            target=self._searchExternalSubtitles,
            args=(settings.get("api_key", ""), language, kind),
            name="TiviMateSubDLSearch"
        )
        self._subtitle_thread.daemon = True
        self._subtitle_thread.start()

    def _searchExternalSubtitles(self, api_key, language, kind):
        try:
            rows = SubDLClient(api_key).search(self.item, language, kind)
            if not rows:
                raise SubDLError("No matching subtitle was found. Try another language or subtitle type.")
            self._mainThread(lambda: self._showExternalSubtitleResults(rows))
        except SubDLError as exc:
            message = str(exc)
            self._mainThread(lambda: self._showNotification(message, MessageBox.TYPE_INFO, timeout=6))
        except Exception:
            self._mainThread(lambda: self._showNotification("Could not search for external subtitles.", MessageBox.TYPE_ERROR, timeout=5))

    def _showExternalSubtitleResults(self, rows):
        choices = [(row.get("label", "SUBTITLE"), row) for row in rows]
        self.lockShow()
        self.session.openWithCallback(
            self._externalSubtitleSelected,
            ChoiceBox,
            title="SubDL - Choose a Release",
            list=choices
        )

    def _externalSubtitleSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        row = selected[1]
        api_key = load_subdl_settings().get("api_key", "")
        self._showNotification("Downloading subtitle...", MessageBox.TYPE_INFO, timeout=3)
        self._subtitle_thread = threading.Thread(
            target=self._downloadExternalSubtitle,
            args=(api_key, row),
            name="TiviMateSubDLDownload"
        )
        self._subtitle_thread.daemon = True
        self._subtitle_thread.start()

    def _downloadExternalSubtitle(self, api_key, row):
        try:
            path = SubDLClient(api_key).download(row)
            self._mainThread(lambda: self._attachExternalSubtitle(path, row))
        except SubDLError as exc:
            message = str(exc)
            self._mainThread(lambda: self._showNotification(message, MessageBox.TYPE_ERROR, timeout=6))
        except Exception:
            self._mainThread(lambda: self._showNotification("Could not download the external subtitle.", MessageBox.TYPE_ERROR, timeout=5))

    def _clearExternalSubtitle(self):
        support = getattr(self, "_external_subs", None)
        self._external_subs = None
        self._external_subtitle_path = ""
        if support is None:
            return
        try:
            support.hideSubsDialog()
        except Exception:
            pass
        try:
            support.exitSubs()
        except Exception:
            pass

    def _loadExternalSubtitleWithSubsSupport(self, support, path):
        """Attach an SRT while the current Enigma2 service keeps playing.

        Recent SubsSupport versions expose ``loadSubs(path, newService=False)``
        for replacing an external subtitle on the already running service.  A
        small compatibility ladder keeps older builds working when they do not
        accept the keyword or second argument.
        """
        loader = getattr(support, "loadSubs", None)
        if not callable(loader):
            raise RuntimeError("load method unavailable")

        # Reset the subtitle engine before attaching the new SRT. With
        # newService=False several SubsSupport builds keep the old engine clock
        # at zero, so a movie resumed in the middle starts subtitles from line 1.
        # After the reset, playAfterSeek() synchronizes to the current video PTS.
        try:
            loaded = loader(path, newService=False)
        except TypeError:
            try:
                loaded = loader(path, False)
            except TypeError:
                loaded = loader(path)

        # Some older ports return None on success, so reject only an explicit
        # False return.  If a status method exists, it remains the stronger
        # indicator of success.
        if loaded is False:
            raise RuntimeError("load rejected")
        # Do not reject the subtitle from an immediate isSubsLoaded() probe.
        # Several Pure2/OpenATV SubsSupport builds finish parsing the SRT on an
        # eTimer callback, so the status can still be False directly after a
        # successful loadSubs() call. The delayed playAfterSeek passes below
        # verify/start the loaded engine without deleting the downloaded file.

        # After loading a subtitle on an already running IPTV/VOD service,
        # resumeSubs() starts from the engine's current list position (usually 0).
        # playAfterSeek() is the official SubsSupport path that reads the current
        # video PTS, moves to the matching subtitle line, and starts in sync.
        synchronizer = getattr(support, "playAfterSeek", None)
        if callable(synchronizer):
            try:
                synchronizer()
                return "sync"
            except Exception:
                pass

        # Older builds may not expose playAfterSeek.  Keep the same-service
        # resume path as a compatibility fallback.
        resumer = getattr(support, "resumeSubs", None)
        if callable(resumer):
            try:
                resumer()
                return "resume"
            except Exception:
                pass

        starter = getattr(support, "startSubs", None)
        if callable(starter):
            starter(0)
            return "start"
        raise RuntimeError("start method unavailable")

    def _attachExternalSubtitle(self, path, row):
        try:
            from Plugins.Extensions.SubsSupport.subtitles import SubsSupport
        except Exception:
            self._showNotification(
                "The subtitle file was downloaded, but SubsSupport is not available to load it.",
                MessageBox.TYPE_ERROR,
                timeout=6
            )
            return

        stage = "checking the downloaded SRT"
        try:
            if not path or not os.path.isfile(path):
                raise RuntimeError("downloaded file missing")
            # Preserve the exact VOD position before opening/replacing the
            # subtitle engine. Some images briefly report an older PTS after
            # SubsSupport attaches, which makes a newly downloaded subtitle lag.
            _seek, subtitle_target_ticks, _length = self._seekInfo()
            self._clearExternalSubtitle()
            stage = "starting SubsSupport"
            self._external_subs = SubsSupport(
                self.session,
                defaultPath=os.path.dirname(path),
                forceDefaultPath=True,
                autoLoad=False,
                showGUIInfoMessages=False,
                embeddedSupport=False,
                preferEmbedded=False,
                searchSupport=False,
            )
            stage = "loading the SRT into the current video"
            self._loadExternalSubtitleWithSubsSupport(self._external_subs, path)
            self._external_subtitle_path = path
            self._scheduleSubtitleSync(subtitle_target_ticks)
            release = row.get("release") or row.get("format", "SRT").upper()
            self._showNotification("External subtitle loaded: %s" % release[:80], MessageBox.TYPE_INFO, timeout=4)
        except Exception:
            try:
                print("[TiviMateE2] SubsSupport subtitle attach failed while %s" % stage)
            except Exception:
                pass
            self._clearExternalSubtitle()
            self._showNotification(
                "The subtitle was downloaded but SubsSupport could not attach it while %s. Try another release or press BLUE to check SubsSupport." % stage,
                MessageBox.TYPE_ERROR,
                timeout=8
            )

    def toggleStreamType(self):
        """XKlass-style quick playback-engine cycle for the current item."""
        engines = [value for value, _label in _available_stream_types()]
        if not engines:
            return
        try:
            current = engines.index(int(self.servicetype))
        except Exception:
            current = -1
        target = engines[(current + 1) % len(engines)]
        self._switchPlaybackEngine(target, save_default=False)

    def _episodeSharedMetadata(self, episode):
        current = self.item or {}
        episode = dict(episode or {})
        for key in (
            "series_name", "series_id", "tmdb_id", "_tmdb_title", "_tmdb_kind",
            "_source_key", "_source_type", "_subdl_type", "_subdl_title",
            "_subdl_season", "_player_cover"
        ):
            if current.get(key) not in (None, "", [], {}):
                episode[key] = current.get(key)
        episode["_episode_items"] = list(self._episode_items or [])
        episode["_episode_index"] = int(self._episode_index)
        episode["_episode_source"] = dict(self._episode_source or {})
        if not episode.get("_subdl_episode"):
            episode["_subdl_episode"] = (
                episode.get("episode_num") or episode.get("episode_number") or
                episode.get("episode") or (self._episode_index + 1)
            )
        return episode

    def _playEpisodeIndex(self, index):
        """Play adjacent series episode inside the same player, like XKlass."""
        if not self._episode_items or not self._episode_source:
            return
        if index < 0 or index >= len(self._episode_items):
            return
        try:
            self._saveResumePosition()
        except Exception:
            pass
        episode = dict(self._episode_items[index] or {})
        source = dict(self._episode_source or {})
        try:
            if source.get("type") == "stalker":
                url = StalkerClient(source).stream_url(episode, "series")
            else:
                url = XtreamClient(source).episode_url(episode)
        except Exception as exc:
            return self._showNotification(
                "Could not open episode: %s" % exc,
                MessageBox.TYPE_ERROR,
                timeout=5
            )
        if not url:
            return

        self._clearExternalSubtitle()
        self._clearSubsSupport()
        try:
            self._resume_timer.stop()
            self._resume_seek_timer.stop()
        except Exception:
            pass

        self._episode_index = int(index)
        self.item = self._episodeSharedMetadata(episode)
        self.streamurl = str(url)
        self.servicetype = int(self.originalservicetype)
        self._resume_key = _resume_key(self.item, self.streamurl)
        self._resume_prompted = False
        self._resume_pending_ticks = 0
        self._resume_seek_attempts = 0
        self._resume_seek_sent = False
        self._resume_last_position = 0
        self._resume_stable_reads = 0
        self._is_stalker_resume = True

        try:
            self["streamcat"].setText("Series")
            ext = os.path.splitext(self.streamurl.split("?", 1)[0])[-1].replace(".", "").upper() or "STREAM"
            self["extension"].setText(ext)
        except Exception:
            pass
        self.playStream()
        try:
            number = self.item.get("episode_num") or self.item.get("episode_number") or (index + 1)
            self._showNotification("Episode %s" % number, MessageBox.TYPE_INFO, timeout=2)
        except Exception:
            pass

    def nextEpisode(self):
        if self._episode_items:
            self._playEpisodeIndex(self._episode_index + 1)

    def prevEpisode(self):
        if self._episode_items:
            self._playEpisodeIndex(self._episode_index - 1)

    def openPlayerMenu(self):
        choices = [
            ("Import SubDL API Key", "import_subdl_key"),
            ("Download Best Subtitle Automatically (YELLOW button)", "auto_subtitle"),
            ("Choose SubDL Subtitle Manually", "external_subtitle"),
            ("Record / Download Current Movie or Episode", "record_current"),
            ("Stop Current Recording", "stop_recording"),
            ("Set Recording Folder", "record_folder"),
            ("Change Aspect Ratio", "aspect_ratio"),
            ("Try Next Playback Engine (this item only)", "try_next_engine"),
            ("SubsSupport (BLUE button)", "subssupport"),
        ]
        for value, name in _available_stream_types():
            prefix = "✓ " if int(value) == int(self.servicetype) else ""
            choices.append((prefix + "Set default: " + name, value))
        self.lockShow()
        self.session.openWithCallback(
            self._playerSelected,
            ChoiceBox,
            title="Player & External Subtitles",
            list=choices
        )

    def _playerSelected(self, selected):
        self.unlockShow()
        if not selected:
            return
        value = selected[1]
        if value == "record_current":
            self.startRecordingCurrent()
            return
        if value == "stop_recording":
            self.stopRecordingCurrent()
            return
        if value == "record_folder":
            self.openRecordingFolder()
            return
        if value == "settings":
            self._openSubDLSettings()
            return
        if value == "auto_subtitle":
            self.autoDownloadExternalSubtitle()
            return
        if value == "aspect_ratio":
            self.nextAspectRatio()
            return
        if value == "import_subdl_key":
            self._importSubDLKeyFromMenu()
            return
        if value == "try_next_engine":
            engines = [engine for engine, _label in _available_stream_types()]
            if not engines:
                return
            try:
                position = engines.index(int(self.servicetype))
            except Exception:
                position = -1
            self._switchPlaybackEngine(engines[(position + 1) % len(engines)], save_default=False)
            return
        if value == "subssupport":
            self.openSubsSupport()
            return
        if value == "external_subtitle":
            self.openExternalSubtitleSearch()
            return
        value = int(value)
        self._switchPlaybackEngine(value, save_default=True)

    def openRecordingFolder(self):
        current = _record_settings_load().get("path", "/media/hdd/movie")
        self.lockShow()
        self.session.openWithCallback(self._recordFolderDone, VirtualKeyBoard,
            title="Recording folder on HDD/USB", text=current)

    def _recordFolderDone(self, value=None):
        self.unlockShow()
        value = (value or "").strip()
        if not value:
            return
        if value.startswith("/tmp"):
            return self._showNotification("Recording to /tmp is not allowed. Choose HDD or USB.", MessageBox.TYPE_ERROR, timeout=6)
        try:
            if not os.path.isdir(value):
                os.makedirs(value)
            if not os.access(value, os.W_OK):
                raise IOError("not writable")
        except Exception:
            return self._showNotification("The selected recording folder is not writable.", MessageBox.TYPE_ERROR, timeout=6)
        _record_settings_save(value)
        self._showNotification("Recording folder saved: %s" % value, MessageBox.TYPE_INFO, timeout=5)

    def startRecordingCurrent(self):
        if self._record_process is not None:
            return self._showNotification("A recording is already running.", MessageBox.TYPE_INFO, timeout=4)
        folder = _record_settings_load().get("path", "/media/hdd/movie")
        if folder.startswith("/tmp"):
            return self._showNotification("Recording to /tmp is not allowed. Choose HDD or USB.", MessageBox.TYPE_ERROR, timeout=6)
        try:
            if not os.path.isdir(folder):
                os.makedirs(folder)
            if not os.access(folder, os.W_OK):
                raise IOError("not writable")
        except Exception:
            return self._showNotification("Recording folder is not writable. Set another HDD/USB folder.", MessageBox.TYPE_ERROR, timeout=7)
        title = _safe_record_name(self.item.get("name") or self.item.get("title") or "IPTV")
        url_path = self.streamurl.split("?", 1)[0].lower()
        ext = os.path.splitext(url_path)[1]
        if ext not in (".ts", ".mp4", ".mkv", ".avi", ".mov", ".m3u8"):
            ext = ".ts"
        if ext == ".m3u8":
            ext = ".ts"
        stamp = time.strftime("%Y%m%d-%H%M%S")
        output = os.path.join(folder, "%s-%s%s" % (title, stamp, ext))
        proc = eConsoleAppContainer()
        self._record_process = proc
        self._record_path = output
        def closed(code):
            running_path = self._record_path
            self._record_process = None
            self._record_path = ""
            if getattr(self, "_closing", False):
                return
            if int(code or 0) == 0 and os.path.exists(running_path):
                self._showNotification("Recording saved: %s" % running_path, MessageBox.TYPE_INFO, timeout=7)
            else:
                self._showNotification("Recording stopped or failed.", MessageBox.TYPE_ERROR, timeout=6)
        try:
            proc.appClosed.append(closed)
        except Exception:
            proc.appClosed.get().append(closed)
        ffmpeg = "/usr/bin/ffmpeg"
        if os.path.exists(ffmpeg):
            command = "%s -y -loglevel error -i %s -c copy %s" % (
                ffmpeg, shlex.quote(self.streamurl), shlex.quote(output))
        else:
            command = "/usr/bin/wget -c -O %s %s" % (shlex.quote(output), shlex.quote(self.streamurl))
        try:
            proc.execute("/bin/sh", "sh", "-c", command)
            self._showNotification("Recording started: %s" % output, MessageBox.TYPE_INFO, timeout=6)
        except Exception as exc:
            self._record_process = None
            self._record_path = ""
            self._showNotification("Could not start recording: %s" % exc, MessageBox.TYPE_ERROR, timeout=7)

    def stopRecordingCurrent(self):
        proc = self._record_process
        if proc is None:
            return self._showNotification("No recording is running.", MessageBox.TYPE_INFO, timeout=4)
        try:
            proc.sendCtrlC()
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass
        self._showNotification("Stopping recording...", MessageBox.TYPE_INFO, timeout=4)

    def _switchPlaybackEngine(self, value, save_default=False):
        """Restart the active VOD item through a chosen backend.

        Temporary retries keep the global setting intact, allowing an unsupported
        codec in one file to be tested without changing every other channel.
        """
        value = int(value)
        if value == int(self.servicetype) and not save_default:
            return
        self._clearExternalSubtitle()
        self.servicetype = value
        if save_default:
            _save_player_type(value)
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        self.playStream()
        try:
            mode = "Default playback engine saved" if save_default else "Trying this engine for the current item only"
            self._showNotification("%s: %s" % (mode, value), MessageBox.TYPE_INFO, timeout=3)
        except Exception:
            pass


    def nextAspectRatio(self):
        try:
            from enigma import eAVSwitch
        except Exception:
            try:
                from enigma import eAVControl as eAVSwitch
            except Exception:
                return
        self._aspect = (getattr(self, "_aspect", 2) + 1) % 7
        try:
            eAVSwitch.getInstance().setAspectRatio(self._aspect)
        except Exception:
            pass

    def _tmdbPlayerCoverFallback(self):
        """Resolve the player poster with the same global TMDb match as details."""
        snapshot = dict(self.item or {})
        token = str(
            snapshot.get("tmdb_id") or snapshot.get("_tmdb_title") or
            snapshot.get("_subdl_title") or snapshot.get("name") or snapshot.get("title") or ""
        )
        self._tmdb_cover_token = token
        if not token:
            return

        def worker():
            try:
                client = TMDbClient()
                kind = "series" if (
                    snapshot.get("_tmdb_kind") == "series" or
                    snapshot.get("_subdl_type") == "tv"
                ) else "vod"

                tid = snapshot.get("tmdb_id") or snapshot.get("tmdb")
                data = client.details_bundle(tid, kind) if tid else {}
                cover = (data or {}).get("poster_path") or ""

                # If the provider ID is absent/wrong/incomplete, re-resolve by the
                # same globally-cleaned title used everywhere else.
                if not cover:
                    title = (
                        snapshot.get("_tmdb_title") or snapshot.get("_subdl_title") or
                        snapshot.get("name") or snapshot.get("title") or ""
                    )
                    raw_year = (
                        snapshot.get("year") or snapshot.get("releaseDate") or
                        snapshot.get("releasedate") or ""
                    )
                    match = re.search(r"\b(?:19|20)\d{2}\b", str(raw_year))
                    found = client.search_title(title, kind, match.group(0) if match else None) if title else None
                    if not found and title:
                        found = client.search_title(title, kind, None)
                    new_tid = (found or {}).get("id")
                    if new_tid:
                        tid = new_tid
                        detail = client.details_bundle(tid, kind) or {}
                        seed = dict(found or {})
                        seed.update(detail)
                        data = seed
                    elif found:
                        data = found
                    cover = (data or {}).get("poster_path") or ""

                cover = _normalise_cover_url(cover)
                if not cover:
                    return

                def apply():
                    if getattr(self, "_tmdb_cover_token", "") != token:
                        return
                    self.item["tmdb_id"] = str(tid or self.item.get("tmdb_id") or "")
                    self.item["_player_cover"] = cover
                    self._downloadCoverUrl(cover, tmdb_fallback=False)

                if reactor:
                    reactor.callFromThread(apply)
                else:
                    apply()
            except Exception:
                pass

        t = threading.Thread(target=worker, name="TiviMatePlayerTMDbCover")
        t.daemon = True
        t.start()

    def _downloadCoverUrl(self, url, tmdb_fallback=True):
        """Load the VOD player poster through the shared artwork pipeline."""
        url = _normalise_cover_url(url)
        if not url or not str(url).startswith(("http://", "https://")):
            if tmdb_fallback:
                self._tmdbPlayerCoverFallback()
            return

        self._player_cover_request = url

        def done(path, expected=url):
            if getattr(self, "_player_cover_request", "") != expected:
                return
            self._cover_file = None  # artwork_queue owns/caches this path
            self._cover_cached_path = path
            self._resizeCover(path, remove_after=False)

        def failed(_path, expected=url):
            if getattr(self, "_player_cover_request", "") != expected:
                return
            if tmdb_fallback and not self.item.get("_tmdb_cover_attempted"):
                self.item["_tmdb_cover_attempted"] = True
                self._tmdbPlayerCoverFallback()

        request_artwork(url, "details", done, priority=120, errback=failed)

    def downloadCover(self):
        try:
            self["cover"].instance.setPixmapFromFile(DEFAULT_COVER)
        except Exception:
            pass

        # Exact details-screen poster first, then every provider poster field.
        # Relative provider paths are resolved against the IPTV server, never TMDb.
        url = self.item.get("_player_cover") or _player_server_poster({}, self.item)
        url = _normalise_cover_url(url)
        if url:
            self._downloadCoverUrl(url, tmdb_fallback=True)
        else:
            self._tmdbPlayerCoverFallback()

    def _resizeCover(self, path, remove_after=True):
        try:
            self._cover_remove_after_decode = bool(remove_after)
            render_width, render_height = scale_size(220, 330)
            self.PicLoad.setPara([render_width, render_height, 0, 0, 0, 1, "FF000000"])
            self.PicLoad.startDecode(path)
        except Exception:
            if remove_after:
                self._removeCover()

    def _decodeCover(self, _info=None):
        try:
            ptr = self.PicLoad.getData()
            if ptr is not None and self["cover"].instance:
                self["cover"].instance.setPixmap(ptr)
                self["cover"].instance.show()
        except Exception:
            pass

        if getattr(self, "_cover_remove_after_decode", False):
            self._removeCover()
        else:
            # Never delete a file owned by artwork_queue/cache.
            self._cover_file = None

    def _removeCover(self):
        path = self._cover_file
        self._cover_file = None
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def back(self):
        self._saveResumePosition()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        try:
            if self.original_service is not None:
                self.session.nav.playService(self.original_service)
        except Exception:
            pass
        self.close()

    def _cleanup(self):
        try:
            self._catchup_retry_timer.stop()
        except Exception:
            pass
        try:
            self._progress_timer.stop()
        except Exception:
            pass
        self._closing = True
        try:
            self._resume_timer.stop()
        except Exception:
            pass
        try:
            self._resume_seek_timer.stop()
        except Exception:
            pass
        try:
            self._subtitle_sync_timer.stop()
        except Exception:
            pass
        self._clearExternalSubtitle()
        self._clearSubsSupport()
        try:
            self.hideTimer.stop()
        except Exception:
            pass
        try:
            self._notification_timer.stop()
        except Exception:
            pass
        self._removeCover()


# Keep player and subtitle dialogs in the same native coordinate system as the
# active FHD or WQHD Enigma2 desktop.
SubDLKeyBoard.skin = scale_skin(SubDLKeyBoard.skin)
SubDLSettingsScreen.skin = scale_skin(SubDLSettingsScreen.skin)
TiviMatePlayer.skin = scale_skin(TiviMatePlayer.skin)
