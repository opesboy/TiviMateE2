# -*- coding: utf-8 -*-
from .compat import atomic_replace, ensure_dir, open_text
import os, json, hashlib, re, ssl, time, threading, socket, gzip, io, random, string
from urllib.request import Request, urlopen
from urllib.parse import urlencode, urlparse, parse_qs, quote

BASE = "/etc/enigma2/tivimatee2"
SOURCES_FILE = os.path.join(BASE, "sources.json")
PLAYLISTS_FILE = os.path.join(BASE, "playlists.txt")
LEGACY_TIVIMATE_PLAYLISTS_FILE = "/etc/enigma2/tivimate/playlists.txt"
from .cache_manager import get_cache_root, get_cache_dir, get_log_path
CACHE = get_cache_root()
UA = "Mozilla/5.0 (Linux; Enigma2) TiviMateE2/0.3"

# One bounded network policy and one generic catalog cache are used for every
# supported source.  Cache keys are derived from the configured source only;
# no service receives source-specific performance settings.
NETWORK_TIMEOUT = 10
CATALOG_CACHE_TTL = 24 * 60 * 60
_CATALOG_MEMORY = {}
_CATALOG_REFRESHING = set()
_CATALOG_LOCK = threading.RLock()
_STALKER_TOKENS = {}
_STALKER_TOKEN_TTL = 25 * 60
_STALKER_EPG_CACHE = {}
_STALKER_EPG_TTL = 5 * 60
STALKER_COMPAT_FILE = os.path.join(BASE, "stalker_compat.json")
STALKER_MAG_MODELS = ("MAG250", "MAG254", "MAG322")

STALKER_LOG = get_log_path("tivimatee2_stalker.log")

def stalker_log(message):
    """Write a bounded diagnostic log without exposing full tokens or MAC data."""
    try:
        if os.path.exists(STALKER_LOG) and os.path.getsize(STALKER_LOG) > 512 * 1024:
            try:
                os.rename(STALKER_LOG, STALKER_LOG + ".1")
            except Exception:
                pass
        stamp = time.strftime("%Y-%m-%d %H:%M:%S")
        with open(STALKER_LOG, "a") as handle:
            handle.write("[%s] %s\n" % (stamp, str(message)))
    except Exception:
        pass



def _stalker_compat_key(portal, mac):
    return "%s|%s" % ((portal or "").rstrip("/"), (mac or "").upper())

def load_stalker_compat(portal, mac):
    data = load_json(STALKER_COMPAT_FILE, {}) or {}
    row = data.get(_stalker_compat_key(portal, mac), {})
    return dict(row) if isinstance(row, dict) else {}

def save_stalker_compat(portal, mac, **values):
    data = load_json(STALKER_COMPAT_FILE, {}) or {}
    key = _stalker_compat_key(portal, mac)
    row = data.get(key, {})
    if not isinstance(row, dict):
        row = {}
    for name, value in values.items():
        if value in (None, ""):
            row.pop(name, None)
        else:
            row[name] = value
    data[key] = row
    save_json(STALKER_COMPAT_FILE, data)
    return row

def _mask_mac(mac):
    value = str(mac or "")
    return value[:8] + ":XX:XX:XX" if len(value) >= 8 else "hidden"

def _mask_token(token):
    value = str(token or "")
    if not value:
        return "none"
    return value[:6] + "..." + value[-4:] if len(value) > 12 else "present"


for p in (BASE, CACHE, get_cache_dir("posters"), get_cache_dir("backdrops"), get_cache_dir("logos")):
    try: ensure_dir(p)
    except Exception: pass


def load_json(path, default):
    try:
        with open_text(path, "r", encoding="utf-8") as f: return json.load(f)
    except Exception: return default


def save_json(path, data):
    try: ensure_dir(os.path.dirname(path))
    except Exception: pass
    tmp = path + ".tmp"
    payload = json.dumps(data, ensure_ascii=False, indent=2)
    if not isinstance(payload, str):
        payload = str(payload)
    with open_text(tmp, "w", encoding="utf-8") as f: f.write(payload)
    atomic_replace(tmp, path)


def _source_key(s):
    return "%s|%s|%s|%s" % (s.get("type",""), s.get("url","").rstrip("/"), s.get("username",""), s.get("mac",""))


def _normalise_stalker_source(name, portal, mac):
    """Create one local Stalker source from a compact playlist record."""
    portal = (portal or "").strip().rstrip("/")
    mac = (mac or "").strip().upper().replace("-", ":")
    if portal and "://" not in portal:
        portal = "http://" + portal
    parts = mac.split(":")
    try:
        valid_mac = len(parts) == 6 and all(len(part) == 2 and int(part, 16) >= 0 for part in parts)
    except Exception:
        valid_mac = False
    if not portal.startswith(("http://", "https://")) or not valid_mac:
        return None
    return {
        "type": "stalker",
        "name": (name or "Stalker Portal").strip() or "Stalker Portal",
        "url": portal,
        "mac": mac,
    }


def _parse_stalker_playlist_line(line, name):
    """Accept explicit STALKER records and the compact Portal/c/MAC shorthand."""
    raw = (line or "").strip()
    parts = [part.strip() for part in raw.split("|")]
    if parts and parts[0].upper() == "STALKER":
        if len(parts) == 4:
            # Prefer STALKER|Name|Portal URL|MAG MAC.  Also allow URL first.
            if parts[1].lower().startswith(("http://", "https://")):
                return _normalise_stalker_source(parts[3] or name, parts[1], parts[2])
            return _normalise_stalker_source(parts[1] or name, parts[2], parts[3])
        if len(parts) == 3:
            return _normalise_stalker_source(name, parts[1], parts[2])
        return None
    # Easy one-line form: http://SERVER:PORT/stalker_portal/c/00:1A:79:AA:BB:CC # Name
    match = re.match(r"^(https?://.+?/c/)([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})/?$", raw)
    if match:
        return _normalise_stalker_source(name, match.group(1), match.group(2))
    return None


def parse_playlist_line(raw):
    line = (raw or "").strip()
    if not line or line.startswith("#"):
        return None
    name = "IPTV"
    if " #" in line:
        line, name = line.rsplit(" #", 1)
        name = name.strip() or "IPTV"
    elif "|" in line and line.lower().startswith(("http://", "https://")):
        # Accept: URL | Name for ordinary M3U lines.
        parts = line.rsplit("|", 1)
        if len(parts) == 2:
            line, name = parts[0].strip(), parts[1].strip() or "IPTV"
    fg_parts = [part.strip() for part in line.split("|")]
    if fg_parts and fg_parts[0].upper() == "FG":
        if len(fg_parts) >= 3:
            return {"type": "fg", "name": fg_parts[1] or name or "FG Code", "url": _normalise_fg_url(fg_parts[2]), "code": fg_parts[2]}
        if len(fg_parts) == 2:
            return {"type": "fg", "name": name or "FG Code", "url": _normalise_fg_url(fg_parts[1]), "code": fg_parts[1]}
    stalker = _parse_stalker_playlist_line(line, name)
    if stalker:
        return stalker
    try:
        u = urlparse(line.strip())
        qs = parse_qs(u.query)
        username = (qs.get("username") or [""])[0]
        password = (qs.get("password") or [""])[0]
        if username and password:
            base = "%s://%s" % (u.scheme or "http", u.netloc)
            output = (qs.get("output") or ["ts"])[0]
            return {"type":"xtream", "name":name, "url":base.rstrip("/"), "username":username, "password":password, "output":output}
        if u.scheme in ("http","https"):
            return {"type":"m3u", "name":name, "url":line.strip()}
    except Exception:
        pass
    return None


def import_playlists(paths=None):
    paths = paths or (PLAYLISTS_FILE, LEGACY_TIVIMATE_PLAYLISTS_FILE)
    found = []
    for path in paths:
        try:
            with open_text(path, "r", encoding="utf-8", errors="ignore") as f:
                for raw in f:
                    s = parse_playlist_line(raw)
                    if s: found.append(s)
        except Exception:
            pass
    return found


def get_sources():
    stored = load_json(SOURCES_FILE, [])
    merged = []
    seen = set()
    for s in stored + import_playlists():
        if s.get("type") == "fg" or s.get("drama_import") or s.get("drama_fg_experimental"):
            continue
        k = _source_key(s)
        if k not in seen:
            seen.add(k); merged.append(s)
    return merged


def set_sources(v):
    save_json(SOURCES_FILE, v)
    try:
        from .epgimport_sync import sync_epgimport_sources
        sync_epgimport_sources(v)
    except Exception:
        pass


def xtream_to_playlist_line(src):
    base = src.get("url","").rstrip("/")
    output = src.get("output") or "ts"
    q = urlencode({"username":src.get("username",""), "password":src.get("password",""), "type":"m3u_plus", "output":output})
    return "%s/get.php?%s # %s" % (base, q, src.get("name") or "IPTV")


def write_playlists(sources):
    try: ensure_dir(BASE)
    except Exception: pass
    lines = []
    for s in sources:
        if s.get("type") == "xtream":
            lines.append(xtream_to_playlist_line(s))
        elif s.get("type") == "m3u" and s.get("url"):
            lines.append("%s # %s" % (s.get("url"), s.get("name") or "M3U"))
        elif s.get("type") == "stalker" and s.get("url") and s.get("mac"):
            # Keep the user-managed source portable without exposing it in package files.
            pname = (s.get("name") or "Stalker Portal").replace("|", " ")
            lines.append("STALKER|%s|%s|%s" % (pname, s.get("url").rstrip("/") + "/", s.get("mac")))
    with open_text(PLAYLISTS_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))


def fetch(url, headers=None, timeout=NETWORK_TIMEOUT, as_json=False):
    h = {"User-Agent": UA, "Accept": "*/*"}
    if headers: h.update(headers)
    req = Request(url, headers=h)
    try:
        ctx = ssl._create_unverified_context()
    except Exception:
        ctx = None
    try:
        if ctx is not None:
            response = urlopen(req, timeout=timeout, context=ctx)
        else:
            response = urlopen(req, timeout=timeout)
    except TypeError:
        response = urlopen(req, timeout=timeout)
    try:
        data = response.read()
    finally:
        try:
            response.close()
        except Exception:
            pass
    return json.loads(data.decode("utf-8", "replace")) if as_json else data



def _catalog_key(source, bucket):
    return "%s|catalog|%s" % (_source_key(source or {}), str(bucket or "default"))


def _catalog_path(source, bucket):
    digest = hashlib.md5(_catalog_key(source, bucket).encode("utf-8")).hexdigest()
    return os.path.join(get_cache_dir("source_catalog"), digest + ".json")


def _catalog_load(path):
    try:
        age = max(0, time.time() - os.path.getmtime(path))
        with open_text(path, "r", encoding="utf-8") as handle:
            rows = json.load(handle)
        return (list(rows), age) if isinstance(rows, list) else (None, None)
    except Exception:
        return None, None


def _catalog_save(path, rows):
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".tmp"
        with open_text(tmp, "w", encoding="utf-8") as handle:
            json.dump(list(rows or []), handle, ensure_ascii=False)
        atomic_replace(tmp, path)
    except Exception:
        pass


def _catalog_put(key, path, rows):
    safe_rows = list(rows or [])
    with _CATALOG_LOCK:
        _CATALOG_MEMORY[key] = (safe_rows, time.time())
    _catalog_save(path, safe_rows)
    return safe_rows


def _refresh_catalog(source, bucket, loader):
    # Refresh a catalog once in the background without delaying a visible page.
    source = dict(source or {})
    key = _catalog_key(source, bucket)
    with _CATALOG_LOCK:
        if key in _CATALOG_REFRESHING:
            return
        _CATALOG_REFRESHING.add(key)

    def worker():
        try:
            rows = list(loader() or [])
            _catalog_put(key, _catalog_path(source, bucket), rows)
        except Exception:
            pass
        finally:
            with _CATALOG_LOCK:
                _CATALOG_REFRESHING.discard(key)

    thread = threading.Thread(target=worker, name="TiviMateCatalogRefresh")
    thread.daemon = True
    thread.start()


def get_cached_catalog(source, bucket, loader, wait_for_server=False):
    # Return RAM/disk catalog data before network data for every source type.
    # The loader is evaluated only in a worker when wait_for_server is true;
    # stale rows remain usable while one daemon refreshes them.
    source = dict(source or {})
    key = _catalog_key(source, bucket)
    path = _catalog_path(source, bucket)
    now = time.time()
    with _CATALOG_LOCK:
        memory = _CATALOG_MEMORY.get(key)
    if memory is not None:
        rows, loaded_at = memory
        if now - loaded_at > CATALOG_CACHE_TTL:
            _refresh_catalog(source, bucket, loader)
            return list(rows or []), "stale"
        return list(rows or []), "ram"

    rows, age = _catalog_load(path)
    if rows is not None:
        with _CATALOG_LOCK:
            _CATALOG_MEMORY[key] = (list(rows), now - float(age or 0))
        if age is not None and age > CATALOG_CACHE_TTL:
            _refresh_catalog(source, bucket, loader)
            return list(rows), "stale"
        return list(rows), "disk"

    if wait_for_server:
        rows = list(loader() or [])
        return _catalog_put(key, path, rows), "server"

    _refresh_catalog(source, bucket, loader)
    return [], "loading"


def clear_catalog_memory():
    # Forget in-memory catalog data after the user explicitly clears cache.
    with _CATALOG_LOCK:
        _CATALOG_MEMORY.clear()
        _CATALOG_REFRESHING.clear()


def cached_image(url, kind="posters"):
    """Return an already-cached artwork file only.

    r88 keeps this helper read-only for callers that only need a local path.
    Screen artwork misses are handled separately by the bounded background queue,
    so DNS, HTTP, and conversion never execute on the Enigma2 GUI thread.
    """
    if not url:
        return ""
    ext = ".png" if ".png" in url.lower() else ".jpg"
    path = os.path.join(get_cache_dir(kind), hashlib.md5(url.encode("utf-8")).hexdigest() + ext)
    try:
        if os.path.exists(path) and os.path.getsize(path) >= 100:
            return path
    except Exception:
        pass
    return ""



def _stalker_local_timezone():
    for path in ("/etc/timezone", "/etc/TZ"):
        try:
            with open(path, "r") as handle:
                value = handle.read().strip()
            if value:
                return value
        except Exception:
            pass
    try:
        value = os.environ.get("TZ", "").strip()
        if value:
            return value
    except Exception:
        pass
    try:
        value = time.tzname[0] if time.tzname else ""
        if value:
            return value
    except Exception:
        pass
    return "GMT"

class XtreamClient:
    def __init__(self, src):
        self.base=src.get("url","").rstrip("/"); self.user=src.get("username",""); self.password=src.get("password","")
    def api(self, action=None, **params):
        q={"username":self.user,"password":self.password}
        if action:q["action"]=action
        q.update(params)
        return fetch(self.base+"/player_api.php?"+urlencode(q), as_json=True)
    def test(self): return self.api()
    def categories(self, kind): return self.api({"live":"get_live_categories","vod":"get_vod_categories","series":"get_series_categories"}[kind])
    def streams(self, kind, category_id=""):
        action={"live":"get_live_streams","vod":"get_vod_streams","series":"get_series"}[kind]
        return self.api(action, category_id=category_id) if category_id else self.api(action)
    def short_epg(self, ch_id, limit=10, epg_channel_id=""):
        """Return provider EPG for one Xtream Live stream.

        Standard Xtream panels use stream_id.  A few compatible panels expose
        EPG only through epg_channel_id, so retry with that identifier when the
        standard request is empty.
        """
        stream_id = str(ch_id or "").strip()
        epg_id = str(epg_channel_id or "").strip()
        try:
            limit = max(1, min(20, int(limit or 10)))
        except Exception:
            limit = 10

        def listings(payload):
            if isinstance(payload, dict):
                rows = (
                    payload.get("epg_listings") or
                    payload.get("listings") or
                    payload.get("epg") or
                    payload.get("data") or
                    []
                )
            elif isinstance(payload, list):
                rows = payload
            else:
                rows = []
            return rows if isinstance(rows, list) else []

        rows = []
        if stream_id:
            try:
                rows = listings(self.api("get_short_epg", stream_id=stream_id, limit=limit))
            except Exception:
                rows = []

        # Compatibility fallback for providers that key EPG by epg_channel_id.
        if not rows and epg_id:
            for key in ("epg_channel_id", "channel_id"):
                try:
                    rows = listings(self.api("get_short_epg", **{key: epg_id, "limit": limit}))
                except Exception:
                    rows = []
                if rows:
                    break
        return rows

    def catchup_epg(self, ch_id, epg_channel_id=""):
        """Return the provider EPG table used to build the Catch-up archive.

        get_simple_data_table normally exposes more historical rows than
        get_short_epg.  Fall back to short EPG for panels that do not implement
        the full table endpoint.
        """
        stream_id = str(ch_id or "").strip()
        epg_id = str(epg_channel_id or "").strip()

        def listings(payload):
            if isinstance(payload, dict):
                rows = (
                    payload.get("epg_listings") or
                    payload.get("listings") or
                    payload.get("epg") or
                    payload.get("data") or
                    []
                )
            elif isinstance(payload, list):
                rows = payload
            else:
                rows = []
            return rows if isinstance(rows, list) else []

        rows = []
        if stream_id:
            try:
                rows = listings(self.api("get_simple_data_table", stream_id=stream_id))
            except Exception:
                rows = []

        if not rows and epg_id:
            for key in ("epg_channel_id", "channel_id"):
                try:
                    rows = listings(self.api("get_simple_data_table", **{key: epg_id}))
                except Exception:
                    rows = []
                if rows:
                    break

        if not rows:
            rows = self.short_epg(stream_id, limit=20, epg_channel_id=epg_id)
        return rows



    def vod_info(self, vod_id):
        return self.api("get_vod_info", vod_id=str(vod_id))
    def series_info(self, series_id):
        return self.api("get_series_info", series_id=str(series_id))
    def episode_url(self, episode):
        eid=str(episode.get("id") or episode.get("stream_id") or "")
        ext=episode.get("container_extension") or "mp4"
        return "%s/series/%s/%s/%s.%s"%(self.base,self.user,self.password,eid,ext)
    def stream_url(self,item,kind):
        sid=str(item.get("stream_id") or "")
        output = "ts"
        if kind=="live": return "%s/live/%s/%s/%s.%s"%(self.base,self.user,self.password,sid,output)
        ext=item.get("container_extension") or "mp4"
        if kind=="vod": return "%s/movie/%s/%s/%s.%s"%(self.base,self.user,self.password,sid,ext)
        return ""



def _normalise_fg_url(value):
    raw = (value or "").strip()
    if not raw:
        return ""
    if raw.startswith(("http://", "https://")):
        return raw
    if "/" in raw or "." in raw:
        # FG links published for Drama Live are commonly supplied without a
        # scheme. Prefer HTTP first for fgcode.org because some codes are
        # served differently there; the resolver also tries HTTPS.
        return "http://" + raw.lstrip("/")
    return "http://fgcode.org/" + raw


def _fg_candidate_urls(value):
    """Return conservative public FG URLs only.

    We intentionally do not guess private application API endpoints here.
    The resolver checks the exact user supplied link and the two public
    fgcode.org scheme variants only.
    """
    raw = (value or "").strip()
    if not raw:
        return []
    out = []
    def add(url):
        if url and url not in out:
            out.append(url)
    if raw.startswith(("http://", "https://")):
        add(raw)
        try:
            plain = raw.split('://', 1)[1]
            add("https://" + plain)
            add("http://" + plain)
        except Exception:
            pass
    elif "/" in raw or "." in raw:
        plain = raw.lstrip('/')
        add("https://" + plain)
        add("http://" + plain)
    else:
        add("https://fgcode.org/" + raw)
        add("http://fgcode.org/" + raw)
    return out

def _fg_extract_candidates(text):
    """Extract possible playlist URLs or Xtream credentials from wrapper data."""
    if not text:
        return [], []
    try:
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except Exception:
        try:
            from html import unescape
        except Exception:
            unescape = lambda x: x
    try:
        from urllib import unquote
    except Exception:
        try:
            from urllib.parse import unquote
        except Exception:
            unquote = lambda x: x
    urls, xtream = [], []
    def addu(v):
        try:
            v = v.strip().replace('\\/', '/')
        except Exception:
            return
        if v.startswith(("http://", "https://")) and v not in urls:
            urls.append(v)
    def walk(value):
        if isinstance(value, dict):
            low = {}
            for k, v in value.items():
                try: low[str(k).lower()] = v
                except Exception: pass
                walk(v)
            base = low.get('url') or low.get('host') or low.get('server') or low.get('server_url')
            user = low.get('username') or low.get('user')
            password = low.get('password') or low.get('pass')
            if base and user is not None and password is not None:
                xtream.append((str(base), str(user), str(password)))
        elif isinstance(value, (list, tuple)):
            for item in value: walk(item)
        else:
            try:
                item = value if isinstance(value, str) else str(value)
            except Exception:
                return
            if item.startswith(("http://", "https://")): addu(item)
    try:
        walk(json.loads(text))
    except Exception:
        pass
    try:
        cleaned = unescape(text).replace('\\/', '/')
        for found in re.findall(r'https?://[^\\s"\'<>]+', cleaned): addu(found)
        for found in re.findall(r'https?%3A%2F%2F[^\\s"\'<>]+', cleaned, re.I):
            addu(unquote(found))
        # Values are sometimes nested once or twice in URL encoding.
        decoded = cleaned
        for _ in range(2):
            try: decoded = unquote(decoded)
            except Exception: break
        if decoded != cleaned:
            for found in re.findall(r'https?://[^\\s"\'<>]+', decoded): addu(found)
    except Exception:
        pass
    return urls, xtream


def _fg_normalise_m3u_bytes(data):
    if not data:
        return None
    if not isinstance(data, bytes):
        try: data = data.encode("utf-8")
        except Exception: return None
    stripped = data.lstrip()
    if stripped.startswith(b"#EXTM3U"):
        return stripped
    if b"#EXTINF:" in stripped and (b"http://" in stripped or b"https://" in stripped):
        return b"#EXTM3U\n" + stripped
    return None


def _fg_json_to_m3u(text):
    try:
        parsed = json.loads(text)
    except Exception:
        return None
    rows = None
    if isinstance(parsed, dict):
        for key in ("channels", "items", "streams", "data", "playlist"):
            if isinstance(parsed.get(key), list):
                rows = parsed.get(key); break
    elif isinstance(parsed, list):
        rows = parsed
    if not isinstance(rows, list):
        return None
    lines = ["#EXTM3U"]
    count = 0
    for row in rows:
        if not isinstance(row, dict): continue
        url = row.get("url") or row.get("link") or row.get("stream_url") or row.get("stream") or row.get("src")
        if not url: continue
        name = row.get("name") or row.get("title") or row.get("channel_name") or "Channel"
        group = row.get("group") or row.get("group-title") or row.get("category") or row.get("category_name") or "FG Code"
        logo = row.get("logo") or row.get("tvg-logo") or row.get("icon") or row.get("image") or ""
        lines.append('#EXTINF:-1 tvg-logo="%s" group-title="%s",%s' % (logo, group, name))
        lines.append(str(url)); count += 1
    if count:
        return ("\n".join(lines) + "\n").encode("utf-8")
    return None


def _fg_fetch(url, headers, timeout):
    """Fetch FG data and return bytes plus final redirect URL/content type."""
    h = {"User-Agent": UA, "Accept": "*/*"}
    h.update(headers or {})
    req = Request(url, headers=h)
    try: ctx = ssl._create_unverified_context()
    except Exception: ctx = None
    try:
        if ctx is not None: response = urlopen(req, timeout=timeout, context=ctx)
        else: response = urlopen(req, timeout=timeout)
    except TypeError:
        response = urlopen(req, timeout=timeout)
    try:
        data = response.read()
        try: final_url = response.geturl()
        except Exception: final_url = url
        try: ctype = response.info().getheader('Content-Type') or ''
        except Exception: ctype = ''
    finally:
        try: response.close()
        except Exception: pass
    return data, final_url, ctype


def inspect_fg_public(source):
    """Inspect only public/user-supplied FG URLs.

    Returns a diagnostic dictionary. If a public response itself contains a
    usable M3U playlist, it is returned in ``playlist``. No private Drama Live
    API/session is invoked.
    """
    source = source or {}
    raw_value = source.get("code") or source.get("url")
    starts = _fg_candidate_urls(raw_value)
    if not starts:
        raise ValueError("FG Code or URL is empty")
    headers = {
        "User-Agent": UA,
        "Accept": "application/x-mpegURL, application/vnd.apple.mpegurl, text/plain, application/json, text/html, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "close",
    }
    checks = []
    last_error = None
    for current in starts[:4]:
        try:
            data, final_url, ctype = _fg_fetch(current, headers, min(NETWORK_TIMEOUT, 10))
            size = len(data or b"")
            item = {"url": current, "final_url": final_url or current, "content_type": ctype or "", "size": size}
            playlist = _fg_normalise_m3u_bytes(data)
            if playlist is None:
                try: text = data.decode("utf-8", "replace")
                except Exception: text = ""
                playlist = _fg_json_to_m3u(text)
            if playlist is not None:
                item["playlist"] = True
                checks.append(item)
                return {"ok": True, "playlist": playlist, "checks": checks}
            item["playlist"] = False
            checks.append(item)
        except Exception as exc:
            last_error = exc
            checks.append({"url": current, "error": str(exc)})
    return {"ok": False, "playlist": None, "checks": checks, "error": str(last_error) if last_error else ""}


def resolve_fg_playlist(source):
    """Resolve only a public/user-accessible FG response to M3U bytes."""
    report = inspect_fg_public(source)
    if report.get("ok") and report.get("playlist") is not None:
        return report.get("playlist")
    checks = report.get("checks") or []
    if checks:
        last = checks[-1]
        if last.get("error"):
            raise ValueError("FG public URL failed: %s" % last.get("error"))
        raise ValueError("FG public URL responded, but no public M3U playlist was exposed (%s, %s bytes)." % (
            last.get("content_type") or "unknown type", last.get("size", 0)))
    raise ValueError("FG Code could not be checked")


class M3UClient:
    def __init__(self, src):
        self.source = src or {}
        self.url = self.source.get("url", "")

    def test(self):
        data = self._read()
        return {"ok": data.startswith(b"#EXTM3U"), "size": len(data)}

    def entries(self):
        text = self._read().decode("utf-8", "replace")
        out = []
        meta = None
        for raw in text.splitlines():
            line = raw.strip()
            if line.startswith("#EXTINF"):
                attrs = dict(re.findall(r"([\w-]+)=[\"']([^\"']*)[\"']", line))
                name = line.split(",", 1)[1].strip() if "," in line else attrs.get("tvg-name", "Channel")
                meta = {
                    "name": name,
                    "logo": attrs.get("tvg-logo", ""),
                    "group": attrs.get("group-title", "Other"),
                }
            elif line and not line.startswith("#") and meta:
                meta["url"] = line
                out.append(meta)
                meta = None

        return out

    def _read(self):
        # Playlist transport follows the same bounded timeout as every source.
        if self.source.get("type") == "fg":
            return resolve_fg_playlist(self.source)
        return fetch(self.url, timeout=NETWORK_TIMEOUT)



def _http_headers_map(raw_headers):
    """Parse HTTP headers without depending on image-specific HTTP libraries."""
    result = {}
    try:
        text = raw_headers.decode("iso-8859-1", "replace") if isinstance(raw_headers, bytes) else str(raw_headers)
    except Exception:
        return result
    for line in text.split("\r\n")[1:]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        result[key.strip().lower()] = value.strip()
    return result


def _decode_chunked_body(body):
    """Decode an RFC 7230 chunked body used by several Ministra front ends."""
    output = []
    pos = 0
    total = len(body)
    while pos < total:
        end = body.find(b"\r\n", pos)
        if end < 0:
            raise ValueError("incomplete chunk size")
        size_line = body[pos:end].split(b";", 1)[0].strip()
        size = int(size_line, 16)
        pos = end + 2
        if size == 0:
            return b"".join(output)
        if pos + size > total:
            raise ValueError("incomplete chunk data")
        output.append(body[pos:pos + size])
        pos += size
        if body[pos:pos + 2] != b"\r\n":
            raise ValueError("invalid chunk terminator")
        pos += 2
    raise ValueError("missing final chunk")


def _decode_stalker_http_body(raw_headers, body):
    headers = _http_headers_map(raw_headers)
    transfer = headers.get("transfer-encoding", "").lower()
    if "chunked" in transfer:
        body = _decode_chunked_body(body)
    encoding = headers.get("content-encoding", "").lower()
    if "gzip" in encoding:
        body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
    return body, headers


class StalkerClient:
    """Stalker / Ministra client with portal-aware session setup.

    This client is intentionally isolated from Xtream and M3U.  It keeps its token
    only in RAM, loads the small Packages list first, and fetches a package only
    when the user opens it.
    """
    PAGE_LIMIT = 3

    def __init__(self, src):
        src = src or {}
        raw_portal = (src.get("url", "") or "").strip().rstrip("/")
        self.mac = (src.get("mac", "00:1A:79:00:00:00") or "").upper()
        # Accept imported forms such as /c/MAC while keeping the MAC separate
        # for the Stalker cookie.  The portal UI path is retained for Referer,
        # while API endpoint discovery operates from the server root.
        embedded = re.search(r"/c/([0-9A-Fa-f:]{17})$", raw_portal)
        if embedded:
            if not src.get("mac"):
                self.mac = embedded.group(1).upper()
            raw_portal = raw_portal[:embedded.start()] + "/c"
        self.portal = raw_portal.rstrip("/")
        self.configured_portal = self.portal
        self._token_key = "%s|%s" % (self.configured_portal, self.mac)
        self.token = ""
        self._compat = load_stalker_compat(self.configured_portal, self.mac)
        self._endpoint = str(self._compat.get("endpoint") or "")
        self.path_prefix = str(self._compat.get("path_prefix") or "")
        self.portal_version = str(self._compat.get("portal_version") or self._compat.get("version") or "")
        self.play_token = str(self._compat.get("play_token") or "")
        self.account_status = self._compat.get("status", 1)
        self.blocked = str(self._compat.get("blocked") or "0")
        self.expiry = str(self._compat.get("expiry") or "")
        self.account_valid = True
        self.returned_mac = str(self._compat.get("returned_mac") or "")
        self.returned_id = str(self._compat.get("returned_id") or "")
        discovered = str(self._compat.get("portal") or "")
        if discovered:
            self.portal = discovered.rstrip("/")
        self._discovery_ready = bool(self._compat.get("portal") and self._compat.get("path_prefix"))
        self._profile_ready = False
        self._modules_ready = False
        # EStalker-style portal hardening: remember temporarily failing API
        # endpoints so one broken fallback does not add seconds to every call.
        self._endpoint_failures = {}
        self._endpoint_cooldown = 15.0
        # Stable MAG identity values improve compatibility with portals that bind
        # a token to one emulated device.  Values are deterministic per MAC, so
        # restarting Enigma2 does not appear as a new receiver.
        compact_mac = self.mac.replace(":", "").upper()
        self.stb_type = str(src.get("stb_type") or self._compat.get("stb_type") or "MAG250").upper()
        if self.stb_type not in STALKER_MAG_MODELS:
            self.stb_type = "MAG250"
        # Match the stable MAG identity used by mature Stalker clients.
        self.serial = str(src.get("serial") or hashlib.md5(self.mac.encode("ascii", "ignore")).hexdigest()[:13].upper())
        self.device_id = str(src.get("device_id") or hashlib.sha256(self.mac.encode("ascii", "ignore")).hexdigest().upper())
        self.device_id2 = str(src.get("device_id2") or hashlib.sha256(self.device_id.encode("ascii", "ignore")).hexdigest().upper())
        self.signature = str(src.get("signature") or hashlib.sha256((self.device_id + self.device_id).encode("ascii", "ignore")).hexdigest().upper())
        self.hw_version_2 = hashlib.sha1(self.mac.encode("ascii", "ignore")).hexdigest()
        self.prehash = hashlib.sha1((self.serial + self.mac).encode("ascii", "ignore")).hexdigest()
        self.adid = hashlib.md5((self.serial + self.mac).encode("ascii", "ignore")).hexdigest()
        self.token_random = ""
        with _CATALOG_LOCK:
            saved = _STALKER_TOKENS.get(self._token_key)
        if saved and time.time() - saved[1] < _STALKER_TOKEN_TTL:
            self.token = saved[0]
            # Newer cache entries also remember that profile/modules already
            # succeeded. This avoids repeating those calls for every short-lived
            # client object while keeping compatibility with old 2-tuples.
            if len(saved) > 2:
                self._profile_ready = bool(saved[2])
            if len(saved) > 3:
                self._modules_ready = bool(saved[3])
            if len(saved) > 4 and saved[4]:
                self._endpoint = saved[4]
            if len(saved) > 5 and saved[5] in STALKER_MAG_MODELS:
                self.stb_type = saved[5]
        stalker_log("SESSION portal=%s mac=%s model=%s cached_token=%s profile_cached=%s modules_cached=%s" % (
            self.portal, _mask_mac(self.mac), self.stb_type, bool(self.token),
            bool(self._profile_ready), bool(self._modules_ready)))

    def _launcher_root(self):
        parsed = urlparse(self.configured_portal or self.portal)
        scheme = parsed.scheme or "http"
        netloc = parsed.netloc
        path = (parsed.path or "").rstrip("/")
        for suffix in ("/stalker_portal/server/load.php", "/server/load.php", "/portal.php", "/load.php"):
            if path.endswith(suffix):
                path = path[:-len(suffix)]
                break
        for suffix in ("/stalker_portal/c", "/c"):
            if path.endswith(suffix):
                path = path[:-len(suffix)]
                break
        return ("%s://%s%s" % (scheme, netloc, path)).rstrip("/")

    def _launcher_headers(self, url=None):
        parsed = urlparse(url or self.configured_portal or self.portal)
        timezone = _stalker_local_timezone()
        encoded_mac = quote(self.mac, safe="")
        return {
            "Pragma": "no-cache", "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Connection": "keep-alive",
            "Referer": self._launcher_root() + (self.path_prefix or "/c/") + "index.html",
            "Cookie": "mac=%s; stb_lang=en; timezone=%s" % (encoded_mac, quote(timezone, safe="")),
            "Host": parsed.netloc,
        }

    def _fetch_launcher_text(self, url, timeout=5):
        req = Request(url, headers=self._launcher_headers(url))
        try: ctx = ssl._create_unverified_context()
        except Exception: ctx = None
        try:
            try:
                response = urlopen(req, timeout=timeout, context=ctx) if ctx is not None else urlopen(req, timeout=timeout)
            except TypeError:
                response = urlopen(req, timeout=timeout)
            try:
                data = response.read(1024 * 1024)
                final_url = response.geturl() if hasattr(response, "geturl") else url
            finally:
                try: response.close()
                except Exception: pass
            if isinstance(data, bytes):
                data = data.decode("utf-8", "ignore")
            return str(data or ""), str(final_url or url)
        except Exception:
            return "", url

    def _extract_portal_path_from_xpcom(self, text, source_url):
        prefix = "/stalker_portal" if "/stalker_portal/" in str(source_url) else ""
        for raw in str(text or "").splitlines():
            line = raw.strip()
            if "this.ajax_loader = this" not in line:
                continue
            urls = re.findall(r"""['"](/[^'"]*(?:portal\.php|server/load\.php|load\.php)[^'"]*)['"]""", line)
            if urls:
                path = re.sub(r"/+", "/", prefix + urls[-1])
                return path if path.startswith("/") else "/" + path
        return ""

    def _discover_portal(self, force=False):
        if self._discovery_ready and not force:
            return True
        host = self._launcher_root()
        if not host:
            return False
        configured_path = (urlparse(self.configured_portal).path or "").rstrip("/") + "/"
        candidates = ("/stalker_portal/c/", "/c/") if configured_path.endswith("/stalker_portal/c/") else ("/c/", "/stalker_portal/c/")
        chosen = ""
        for prefix in candidates:
            body, final_url = self._fetch_launcher_text(host + prefix, timeout=5)
            if body or final_url.rstrip("/") != (host + prefix).rstrip("/"):
                fpath = urlparse(final_url).path or prefix
                chosen = "/stalker_portal/c/" if "/stalker_portal/c" in fpath else ("/c/" if "/c" in fpath else prefix)
                break
        if not chosen:
            chosen = candidates[0]
        self.path_prefix = chosen

        xpcom_urls = [host + chosen + "xpcom.common.js"]
        alt = "/stalker_portal/c/" if chosen == "/c/" else "/c/"
        xpcom_urls.append(host + alt + "xpcom.common.js")
        discovered = ""
        for url in xpcom_urls:
            body, final_url = self._fetch_launcher_text(url, timeout=3)
            if body:
                path = self._extract_portal_path_from_xpcom(body, final_url)
                if path:
                    discovered = host + path
                    break
        self.portal = (discovered or (host + "/portal.php")).rstrip("/")

        body, _ = self._fetch_launcher_text(host + chosen + "version.js", timeout=3)
        if body:
            m = re.search(r"""ver\s*=\s*['"]([^'"]+)['"]""", body)
            if m:
                self.portal_version = m.group(1).strip()
        self._discovery_ready = True
        save_stalker_compat(
            self.configured_portal, self.mac, portal=self.portal,
            path_prefix=self.path_prefix, portal_version=self.portal_version,
            endpoint=self._endpoint, stb_type=self.stb_type
        )
        stalker_log("DISCOVERY portal=%s prefix=%s version=%s" % (
            self.portal, self.path_prefix, self.portal_version or "unknown"))
        return True

    def _account_info(self):
        try:
            response = self.call(type="account_info", action="get_main_info", JsHttpRequest="1-xml") or {}
            js = self._portal_js(response)
            if not isinstance(js, dict):
                return False
            expiry_value = js.get("end_date") or js.get("expire_billing_date") or js.get("expiry") or js.get("expire_date") or ""
            if not expiry_value:
                phone_value = str(js.get("phone") or "").strip()
                # Some Ministra portals overload "phone" with the subscription date.
                if re.search(r"(?:19|20)\\d{2}[-/.]", phone_value) or re.search(r"[-/.](?:19|20)\\d{2}", phone_value):
                    expiry_value = phone_value
            self.expiry = str(expiry_value or self.expiry or "")
            status_text = str(js.get("status") or js.get("account_status") or "").strip().lower()
            self.account_valid = status_text not in ("0", "disabled", "expired", "blocked", "false")
            save_stalker_compat(
                self.configured_portal, self.mac, expiry=self.expiry,
                play_token=self.play_token, status=self.account_status,
                blocked=self.blocked, returned_mac=self.returned_mac,
                returned_id=self.returned_id, portal=self.portal,
                path_prefix=self.path_prefix, portal_version=self.portal_version
            )
            return True
        except Exception as exc:
            stalker_log("ACCOUNT_INFO optional error=%s" % exc)
            return False

    def headers(self):
        parsed = urlparse(self.endpoint() or self.portal)
        encoded_mac = quote(self.mac, safe="")
        timezone = _stalker_local_timezone()
        cookie = "mac=%s; stb_lang=en; timezone=%s" % (encoded_mac, quote(timezone, safe=""))
        if "/stalker_portal/" in (self.endpoint() or self.portal):
            cookie += "; adid=%s" % self.adid
        headers = {
            "Pragma": "no-cache",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
            "Cookie": cookie,
            "X-User-Agent": "Model: %s; Link: WiFi" % self.stb_type,
            "Referer": self._launcher_root() + (self.path_prefix or "/c/") + "index.html",
            "Connection": "Close",
        }
        if parsed.netloc:
            headers["Host"] = parsed.netloc
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
            headers["Cookie"] += "; token=" + self.token
        return headers

    def endpoints(self):
        try:
            self._discover_portal(False)
        except Exception:
            pass
        portal = (self.portal or getattr(self, "configured_portal", "")).rstrip("/")
        if not portal:
            return []
        candidates = [portal]
        parsed = urlparse(getattr(self, "configured_portal", "") or portal)
        root = "%s://%s" % (parsed.scheme or "http", parsed.netloc)
        path = (parsed.path or "").rstrip("/")
        for suffix in ("/stalker_portal/c", "/c"):
            if path.endswith(suffix):
                path = path[:-len(suffix)]
                break
        base = (root + path).rstrip("/")
        roots = [base]
        if (parsed.scheme or "").lower() == "https":
            roots.append(("http://%s%s" % (parsed.netloc, path)).rstrip("/"))
        for script in ("/portal.php", "/stalker_portal/server/load.php", "/server/load.php", "/load.php"):
            for candidate_root in roots:
                candidates.append(candidate_root + script)
        unique=[]
        for value in candidates:
            if value and value not in unique:
                unique.append(value)
        return unique


    def endpoint(self):
        choices = self.endpoints()
        return self._endpoint or (choices[0] if choices else "")

    def _decode(self, value):
        if isinstance(value, bytes):
            try:
                value = value.decode("utf-8", "ignore")
            except Exception:
                return value
        if isinstance(value, str):
            raw = value.strip()
            if raw.startswith(("{", "[")):
                try:
                    return json.loads(raw)
                except Exception:
                    pass
        return value

    def _portal_js(self, response):
        response = self._decode(response)
        if not isinstance(response, dict):
            return {}
        value = response.get("js", response.get("data", response))
        return self._decode(value)

    def _response_error(self, response):
        raw = self._decode(response)
        if not isinstance(raw, dict):
            return "Invalid portal response"
        for container in (raw, self._portal_js(raw)):
            if not isinstance(container, dict):
                continue
            error = container.get("error") or container.get("error_msg") or container.get("faultString")
            if error:
                return str(error)
        return ""

    def _is_stalker_auth_error(self, value):
        """Return True only for errors that justify dropping the MAG token."""
        message = str(value or "").strip().lower()
        if not message:
            return False
        markers = (
            "access denied", "not valid token", "invalid token", "token expired",
            "authorization failed", "authorization error", "unauthorized",
            "not authorized", "auth failed", "wrong token", "session expired",
            "session invalid", "need authorization", "authentication required",
        )
        return any(marker in message for marker in markers)

    def _endpoint_available(self, endpoint):
        try:
            failed_at = float(self._endpoint_failures.get(endpoint, 0) or 0)
            return not failed_at or (time.time() - failed_at >= self._endpoint_cooldown)
        except Exception:
            return True

    def _mark_endpoint_result(self, endpoint, success):
        try:
            if success:
                self._endpoint_failures.pop(endpoint, None)
            else:
                self._endpoint_failures[endpoint] = time.time()
        except Exception:
            pass

    def _stalker_json_request(self, url, timeout=None):
        """Read one bounded Stalker JSON response without relying on EOF.

        Some legacy Ministra/Stalker front ends send a complete JSON document and
        then leave the connection open despite ``Connection: close``.  The
        generic ``urlopen(...).read()`` transport waits for EOF, times out, and
        loses the usable body.  This Stalker-only reader returns as soon as a
        complete JSON document is received, while retaining the same bounded
        timeout and an explicit response-size limit.
        """
        parsed = urlparse(url)
        host = parsed.hostname
        if not host:
            raise RuntimeError("Invalid Stalker portal URL")
        try:
            port = parsed.port or (443 if parsed.scheme == "https" else 80)
        except Exception:
            port = 443 if parsed.scheme == "https" else 80
        target = parsed.path or "/"
        if parsed.query:
            target += "?" + parsed.query
        request_headers = self.headers()
        request_headers["Host"] = parsed.netloc
        request_headers["Connection"] = "close"
        request_headers["Accept"] = "*/*"
        lines = ["GET %s HTTP/1.0" % target]
        for key, value in request_headers.items():
            lines.append("%s: %s" % (key, value))
        wire = "\r\n".join(lines) + "\r\n\r\n"
        try:
            payload = wire.encode("utf-8")
        except Exception:
            payload = wire
        # eStalker-style network bounds: fail a dead connection quickly,
        # while still allowing a slower portal up to 10 seconds to return JSON.
        read_timeout = float(timeout or NETWORK_TIMEOUT)
        connect_timeout = min(5.0, read_timeout)
        sock = socket.create_connection((host, port), connect_timeout)
        try:
            if parsed.scheme == "https":
                try:
                    context = ssl._create_unverified_context()
                    sock = context.wrap_socket(sock, server_hostname=host)
                except Exception:
                    sock = ssl.wrap_socket(sock, cert_reqs=ssl.CERT_NONE)
            sock.sendall(payload)
            sock.settimeout(read_timeout)
            received = b""
            header_end = -1
            body = b""
            status = ""
            limit = 16 * 1024 * 1024
            deadline = time.time() + read_timeout
            response = None
            while time.time() < deadline and len(received) < limit:
                try:
                    chunk = sock.recv(65536)
                except socket.timeout:
                    break
                if not chunk:
                    break
                received += chunk
                if header_end < 0:
                    header_end = received.find(b"\r\n\r\n")
                    if header_end < 0:
                        continue
                    try:
                        status = received[:header_end].decode("iso-8859-1", "replace").split("\r\n", 1)[0]
                    except Exception:
                        status = ""
                raw_headers = received[:header_end]
                body = received[header_end + 4:]
                try:
                    decoded_body, response_headers = _decode_stalker_http_body(raw_headers, body)
                    response = json.loads(decoded_body.decode("utf-8", "replace").strip())
                    break
                except Exception:
                    response = None
                    try:
                        content_length = int(_http_headers_map(raw_headers).get("content-length", "0") or 0)
                    except Exception:
                        content_length = 0
                    if content_length and len(body) >= content_length:
                        break
            else:
                response = None
            if response is None and header_end >= 0:
                try:
                    raw_headers = received[:header_end]
                    decoded_body, response_headers = _decode_stalker_http_body(raw_headers, body)
                    response = json.loads(decoded_body.decode("utf-8", "replace").strip())
                except Exception:
                    response = None
            if response is None:
                raise RuntimeError("Stalker portal did not return complete JSON")
            if status and not status.startswith("HTTP/"):
                raise RuntimeError("Invalid Stalker HTTP response")
            return response
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _request_endpoint(self, endpoint, query):
        separator = "&" if "?" in endpoint else "?"
        action = query.get("action", "")
        kind = query.get("type", "")
        started = time.time()
        try:
            response = self._stalker_json_request(endpoint + separator + urlencode(query))
            error = self._response_error(response)
            if error:
                raise RuntimeError(error)
            if not isinstance(self._decode(response), dict):
                raise RuntimeError("Portal returned an invalid response")
            stalker_log("HTTP OK type=%s action=%s endpoint=%s ms=%d" % (kind, action, endpoint, int((time.time()-started)*1000)))
            return response
        except Exception as exc:
            stalker_log("HTTP FAIL type=%s action=%s endpoint=%s ms=%d error=%s" % (kind, action, endpoint, int((time.time()-started)*1000), exc))
            raise

    def call(self, **query):
        """Call compatible endpoints with short-term health memory.

        The last successful endpoint remains first. Temporarily failing
        alternatives are skipped for a few seconds, which prevents a dead
        /portal.php or /server/load.php fallback from slowing every request.
        """
        choices = []
        endpoints = self.endpoints()
        if self._endpoint:
            choices.append(self._endpoint)
            active_scheme = (urlparse(self._endpoint).scheme or "").lower()
            for candidate in endpoints:
                if (urlparse(candidate).scheme or "").lower() == active_scheme and candidate not in choices:
                    choices.append(candidate)
        for candidate in endpoints:
            if candidate not in choices:
                choices.append(candidate)
        if not choices:
            raise RuntimeError("Portal URL is empty")

        healthy = [value for value in choices if self._endpoint_available(value)]
        if healthy:
            choices = healthy

        last_error = None
        for endpoint in choices:
            try:
                response = self._request_endpoint(endpoint, query)
                self._mark_endpoint_result(endpoint, True)
                self._endpoint = endpoint
                save_stalker_compat(self.portal, self.mac, endpoint=endpoint, stb_type=self.stb_type)
                return response
            except Exception as exc:
                self._mark_endpoint_result(endpoint, False)
                last_error = exc
        raise last_error or RuntimeError("Portal request failed")

    def handshake(self):
        try:
            self._discover_portal(False)
        except Exception:
            pass
        stalker_log("HANDSHAKE start portal=%s mac=%s" % (self.portal, _mask_mac(self.mac)))
        last_error = None
        for endpoint in self.endpoints():
            attempts = [
                {"type": "stb", "action": "handshake", "token": "", "JsHttpRequest": "1-xml"},
                {"type": "stb", "action": "handshake", "token": "", "mac": self.mac, "JsHttpRequest": "1-xml"},
            ]
            for query in attempts:
                try:
                    response = self._request_endpoint(endpoint, query) or {}
                    js = self._portal_js(response)
                    token = (js or {}).get("token", "") if isinstance(js, dict) else ""
                    self.token_random = (js or {}).get("random", "") if isinstance(js, dict) else ""
                    msg = str((js or {}).get("msg", "") if isinstance(js, dict) else "")
                    # Some portals require a prehash challenge before issuing a real token.
                    if not token and "missing" in msg.lower():
                        fake = "".join(random.choice(string.ascii_uppercase + string.digits) for _ in range(32))
                        old_token = self.token
                        self.token = fake
                        try:
                            challenge = {
                                "type": "stb", "action": "handshake", "mac": self.mac,
                                "prehash": hashlib.sha1(fake.encode("ascii")).hexdigest(),
                                "JsHttpRequest": "1-xml"
                            }
                            response = self._request_endpoint(endpoint, challenge) or {}
                            js = self._portal_js(response)
                            token = (js or {}).get("token", "") if isinstance(js, dict) else ""
                            self.token_random = (js or {}).get("random", "") if isinstance(js, dict) else ""
                        finally:
                            self.token = old_token
                    if token:
                        self._endpoint = endpoint
                        self.token = str(token)
                        save_stalker_compat(self.portal, self.mac, endpoint=endpoint, stb_type=self.stb_type)
                        self._profile_ready = False
                        self._modules_ready = False
                        with _CATALOG_LOCK:
                            _STALKER_TOKENS[self._token_key] = (self.token, time.time(), False, False, self._endpoint, self.stb_type)
                        stalker_log("HANDSHAKE success endpoint=%s token=%s" % (endpoint, _mask_token(self.token)))
                        return True
                except Exception as exc:
                    last_error = exc
        self._endpoint = ""
        self.token = ""
        self.token_random = ""
        self._profile_ready = False
        self._modules_ready = False
        stalker_log("HANDSHAKE failed error=%s" % (last_error or "no token"))
        return False

    def _ensure_token(self):
        return bool(self.token) or self.handshake()

    def _drop_token(self):
        self.token = ""
        self.token_random = ""
        self._profile_ready = False
        self._modules_ready = False
        with _CATALOG_LOCK:
            _STALKER_TOKENS.pop(self._token_key, None)

    def reauthorize(self):
        stalker_log("REAUTHORIZE start portal=%s mac=%s" % (self.portal, _mask_mac(self.mac)))
        self._drop_token()
        if not self.handshake():
            stalker_log("REAUTHORIZE failed stage=handshake")
            return False
        if not self._ensure_profile():
            stalker_log("REAUTHORIZE failed stage=profile")
            return False
        self._account_info()
        stalker_log("REAUTHORIZE success endpoint=%s token=%s play_token=%s status=%s blocked=%s" % (
            self._endpoint, _mask_token(self.token), bool(self.play_token),
            self.account_status, self.blocked))
        return True

    def _ensure_profile(self):
        if self._profile_ready:
            return True
        if not self._ensure_token():
            return False
        timestamp = str(int(time.time()))
        models = [self.stb_type] + [model for model in STALKER_MAG_MODELS if model != self.stb_type]
        last_error = None
        original_model = self.stb_type
        for model in models:
            self.stb_type = model
            metrics = json.dumps({
                "type": "stb", "model": model, "mac": self.mac,
                "sn": self.serial, "uid": self.device_id2, "random": self.token_random
            }, separators=(",", ":"))
            common = {
                "type": "stb", "action": "get_profile", "hd": "1",
                "ver": "ImageDescription: 0.2.18-r23-250; ImageDate: Thu Sep 13 11:31:16 EEST 2018; PORTAL version: 5.3.0; API Version: JS API version: 343; STB API version: 146; Player Engine version: 0x58c",
                "num_banks": "2", "sn": self.serial, "stb_type": model,
                "client_type": "STB", "image_version": "218", "video_out": "hdmi",
                "device_id": self.device_id, "device_id2": self.device_id2,
                "signature": self.signature, "auth_second_step": "1",
                "hw_version": "1.7-BD-00", "not_valid_token": "0",
                "metrics": metrics, "hw_version_2": self.hw_version_2,
                "timestamp": timestamp, "api_signature": "262", "prehash": self.prehash,
                "JsHttpRequest": "1-xml",
            }
            fallbacks = [
                ("full", common),
                ("basic", {"type": "stb", "action": "get_profile", "sn": self.serial, "device_id": "", "stb_type": model, "timestamp": timestamp, "JsHttpRequest": "1-xml"}),
                ("minimal", {"type": "stb", "action": "get_profile", "JsHttpRequest": "1-xml"}),
            ]
            for label, query in fallbacks:
                try:
                    response = self.call(**query) or {}
                    js = self._portal_js(response)
                    if not isinstance(js, dict):
                        js = {}
                    self.play_token = str(js.get("play_token") or self.play_token or "")
                    self.account_status = js.get("status", self.account_status)
                    self.blocked = str(js.get("blocked", self.blocked or "0"))
                    self.returned_mac = str(js.get("mac") or self.returned_mac or "")
                    self.returned_id = str(js.get("id") or self.returned_id or "")
                    msg = str(js.get("msg") or "")
                    if self.blocked == "1":
                        raise RuntimeError("Stalker account is blocked")
                    if label == "full" and msg and not self.play_token:
                        raise RuntimeError("profile requested basic fallback: %s" % msg)
                    self._profile_ready = True
                    save_stalker_compat(
                        self.configured_portal, self.mac, portal=self.portal,
                        path_prefix=self.path_prefix, portal_version=self.portal_version,
                        endpoint=self._endpoint, stb_type=model, play_token=self.play_token,
                        status=self.account_status, blocked=self.blocked,
                        returned_mac=self.returned_mac, returned_id=self.returned_id
                    )
                    with _CATALOG_LOCK:
                        _STALKER_TOKENS[self._token_key] = (
                            self.token, time.time(), True, self._modules_ready,
                            self._endpoint, self.stb_type
                        )
                    stalker_log("PROFILE success mode=%s model=%s play_token=%s status=%s blocked=%s" % (
                        label, model, bool(self.play_token), self.account_status, self.blocked))
                    self._account_info()
                    self._ensure_modules()
                    return True
                except Exception as exc:
                    last_error = exc
                    stalker_log("PROFILE fail mode=%s model=%s error=%s" % (label, model, exc))
        self.stb_type = original_model
        self._profile_ready = True
        stalker_log("PROFILE bypass error=%s" % (last_error or "unsupported"))
        return True

    def _ensure_modules(self):
        """Warm portal modules once when supported; never block a working portal."""
        if self._modules_ready:
            return True
        self._modules_ready = True
        try:
            self.call(type="stb", action="get_modules", JsHttpRequest="1-xml")
            stalker_log("MODULES success")
        except Exception as exc:
            stalker_log("MODULES optional error=%s" % exc)
        with _CATALOG_LOCK:
            if self.token:
                _STALKER_TOKENS[self._token_key] = (self.token, time.time(), self._profile_ready, True, self._endpoint, self.stb_type)
        return True

    def test(self):
        """Fast Stalker connectivity test for the BLUE button.

        Only verifies portal discovery/handshake, MAG profile and the small
        Live categories endpoint.  It deliberately does not download channels
        or create a stream link, because those operations can take a long time
        on slow portals and are already exercised during normal Live playback.
        """
        result = {
            "ok": False,
            "token": False,
            "endpoint": "",
            "handshake": False,
            "profile": False,
            "categories": 0,
            "channels": 0,
            "live_link": False,
            "quick_test": True,
            "expiry": "",
            "stage": "handshake",
            "error": "",
        }
        try:
            result["handshake"] = bool(self.handshake())
            result["token"] = bool(self.token)
            result["endpoint"] = self._endpoint or ""
            if not result["handshake"]:
                result["error"] = "Handshake rejected or no token returned"
                return result

            result["stage"] = "profile"
            result["profile"] = bool(self._ensure_profile())
            result["expiry"] = str(self.expiry or "")
            if not result["profile"]:
                result["error"] = "Profile request failed"
                return result

            result["stage"] = "categories"
            categories = self.live_categories() or []
            result["categories"] = len(categories)
            result["ok"] = bool(result["handshake"] and result["profile"])
            result["stage"] = "complete" if result["ok"] else result["stage"]
            return result
        except Exception as exc:
            result["error"] = str(exc)
            result["endpoint"] = self._endpoint or result.get("endpoint", "")
            result["token"] = bool(self.token)
            return result

    def _short_epg_request(self, ch_id, limit=10, timeout=6.0):
        channel_id=str(ch_id or "").strip()
        query={"type":"itv","action":"get_short_epg","ch_id":channel_id,
               "limit":str(limit),"size":str(limit),"JsHttpRequest":"1-xml"}
        if not self._ensure_token(): raise RuntimeError("Stalker handshake was rejected by the portal")
        self._ensure_profile()
        for auth_round in range(2):
            choices=([self._endpoint] if self._endpoint else [])+[x for x in self.endpoints() if x!=self._endpoint]
            healthy=[x for x in choices if self._endpoint_available(x)]
            if healthy: choices=healthy
            last_error=None
            for endpoint in choices:
                try:
                    sep="&" if "?" in endpoint else "?"
                    response=self._stalker_json_request(endpoint+sep+urlencode(query),timeout=float(timeout))
                    error=self._response_error(response)
                    if error: raise RuntimeError(error)
                    self._mark_endpoint_result(endpoint,True); self._endpoint=endpoint
                    return response or {}
                except Exception as exc:
                    self._mark_endpoint_result(endpoint,False); last_error=exc
            if auth_round==0 and self._is_stalker_auth_error(last_error) and self.reauthorize():
                continue
            raise last_error or RuntimeError("Short EPG request failed")
        return {}

    def _normalise_short_epg_rows(self, payload, ch_id):
        candidate = self._portal_js(payload)
        if isinstance(candidate, dict):
            candidate = candidate.get("data") or candidate.get("items") or candidate.get("epg") or candidate.get("list") or []
        if not isinstance(candidate, list):
            return []
        rows = []
        for raw in candidate:
            if not isinstance(raw, dict):
                continue
            item = dict(raw)
            item.setdefault("ch_id", str(ch_id))
            if not item.get("title"):
                item["title"] = item.get("name") or item.get("programme") or item.get("event_name") or ""
            if not item.get("description"):
                item["description"] = item.get("descr") or item.get("desc") or item.get("plot") or ""
            if not item.get("start_timestamp"):
                item["start_timestamp"] = item.get("start") or item.get("begin_timestamp") or item.get("begin") or item.get("time")
            if not item.get("stop_timestamp"):
                item["stop_timestamp"] = item.get("stop") or item.get("end_timestamp") or item.get("end") or item.get("time_to")
            rows.append(item)
        return rows

    def short_epg(self, ch_id, limit=10, force=False):
        channel_id = str(ch_id or "").strip()
        if not channel_id:
            return []
        try:
            limit = max(1, min(20, int(limit or 10)))
        except Exception:
            limit = 10
        cache_key = (self._token_key, channel_id, limit)
        if not force:
            with _CATALOG_LOCK:
                cached = _STALKER_EPG_CACHE.get(cache_key)
            if cached and time.time() - cached[0] < _STALKER_EPG_TTL:
                return [dict(row) for row in (cached[1] or [])]
        last_error = None
        for attempt in range(3):
            try:
                response = self._short_epg_request(channel_id, limit=limit, timeout=6.0)
                rows = self._normalise_short_epg_rows(response, channel_id)
                if rows:
                    with _CATALOG_LOCK:
                        _STALKER_EPG_CACHE[cache_key] = (time.time(), [dict(row) for row in rows])
                    return rows
                last_error = RuntimeError("empty short EPG response")
            except Exception as exc:
                last_error = exc
            if attempt < 2:
                time.sleep(0.5 * (attempt + 1))
        stalker_log("SHORT_EPG failed ch=%s error=%s" % (channel_id, last_error or "empty"))
        return []

    def short_epg_batch(self, channel_ids, limit=10, done_callback=None, partial_callback=None):
        ids=[]; seen=set()
        for value in (channel_ids or []):
            ch_id=str(value or "").strip()
            if ch_id and ch_id not in seen: seen.add(ch_id); ids.append(ch_id)
        state={"rows":[],"failed":set()}
        if not ids:
            payload={"js":[],"failed_ids":[]}
            if done_callback:
                try: done_callback(payload)
                except Exception: pass
            return payload
        lock=threading.RLock(); sem=threading.BoundedSemaphore(2)
        def fetch(ch_id,force=False):
            with sem:
                try: rows=self.short_epg(ch_id,limit=limit,force=force) or []
                except Exception: rows=[]
            with lock:
                if rows:
                    state["rows"].extend(rows); state["failed"].discard(ch_id)
                else: state["failed"].add(ch_id)
            if rows and partial_callback:
                try: partial_callback({"js":[dict(row) for row in rows]})
                except Exception: pass
        threads=[]
        for ch_id in ids:
            t=threading.Thread(target=fetch,args=(ch_id,False),name="TiviMateStalkerShortEPG")
            t.daemon=True; t.start(); threads.append(t)
        def waiter():
            for t in threads:
                try: t.join(22.0)
                except Exception: pass
            with lock: retry=list(state["failed"])
            if retry:
                time.sleep(0.6)
                rthreads=[]
                for ch_id in retry:
                    t=threading.Thread(target=fetch,args=(ch_id,True),name="TiviMateStalkerShortEPGRetry")
                    t.daemon=True; t.start(); rthreads.append(t)
                for t in rthreads:
                    try: t.join(12.0)
                    except Exception: pass
            with lock: payload={"js":[dict(x) for x in state["rows"]],"failed_ids":list(state["failed"])}
            if done_callback:
                try: done_callback(payload)
                except Exception: pass
        done=threading.Thread(target=waiter,name="TiviMateStalkerShortEPGDone")
        done.daemon=True; done.start()
        return state


    def _call_retry(self, **query):
        stalker_log("CALL type=%s action=%s token=%s" % (
            query.get("type", ""), query.get("action", ""), _mask_token(self.token)
        ))
        if not self._ensure_token():
            raise RuntimeError("Stalker handshake was rejected by the portal")
        self._ensure_profile()

        try:
            response = self.call(**query) or {}
            # Empty/invalid portal payload is treated like a failed request so
            # the session gets one clean renewal, matching eStalker behaviour.
            js = self._portal_js(response)
            if response and (js not in (None, "", [], {})):
                return response
            raise RuntimeError("Stalker portal returned an empty response")
        except Exception as first_exc:
            stalker_log("CALL first failure type=%s action=%s error=%s" % (
                query.get("type", ""), query.get("action", ""), first_exc
            ))

        # One controlled reauthorization only. Never loop indefinitely.
        stalker_log("CALL reauthorize+retry type=%s action=%s" % (
            query.get("type", ""), query.get("action", "")
        ))
        self._drop_token()
        self._profile_ready = False
        self._modules_ready = False
        if not self._ensure_token():
            raise RuntimeError("Stalker session could not be renewed")
        self._ensure_profile()

        response = self.call(**query) or {}
        js = self._portal_js(response)
        if not response or js in (None, "", [], {}):
            raise RuntimeError("Stalker portal returned an empty response after retry")
        return response


    def _portal_rows(self, response):
        """Return a row list from the common Stalker/Ministra response envelopes.

        Different portal versions put the same list below ``js``, ``data``,
        ``result``, ``items`` or a JSON-encoded variant of one of those fields.
        The traversal is deliberately bounded and read-only.
        """
        pending = [self._portal_js(response)]
        visited = set()
        list_keys = ("data", "items", "channels", "results", "list", "content", "rows", "movies", "series", "vod")
        wrapper_keys = ("js", "data", "result", "results", "response", "payload", "content", "list")
        while pending:
            candidate = self._decode(pending.pop(0))
            if isinstance(candidate, list):
                return candidate
            if not isinstance(candidate, dict):
                continue
            marker = id(candidate)
            if marker in visited:
                continue
            visited.add(marker)
            for key in list_keys:
                value = self._decode(candidate.get(key))
                if isinstance(value, list):
                    return value
            for key in wrapper_keys:
                value = self._decode(candidate.get(key))
                if isinstance(value, (dict, list)):
                    pending.append(value)
        return []

    def _portal_payload(self, response):
        """Return the useful payload while preserving detail dictionaries."""
        js = self._portal_js(response)
        if not isinstance(js, dict):
            return js
        for key in ("data", "result", "results", "response", "payload", "content"):
            value = self._decode(js.get(key))
            if isinstance(value, (dict, list)):
                return value
        return js

    def _categories(self, api_type, actions):
        """Fetch portal packages, tolerating unavailable compatibility actions."""
        for action in actions:
            try:
                response = self._call_retry(type=api_type, action=action, JsHttpRequest="1-xml")
            except Exception:
                continue
            rows, seen = [], set()
            for item in self._portal_rows(response):
                if not isinstance(item, dict):
                    continue
                if api_type == "itv" and action == "get_genres":
                    cid = item.get("id")
                else:
                    cid = item.get("id") or item.get("category_id") or item.get("genre_id") or item.get("value") or item.get("alias") or item.get("category")
                if cid is None or str(cid).strip() == "":
                    continue
                cid = str(cid)
                if cid in seen:
                    continue
                seen.add(cid)
                title = item.get("title") or item.get("name") or item.get("category_name") or item.get("alias") or item.get("label") or "Other"
                rows.append({
                    "category_id": cid, "genre_id": cid,
                    "category_name": title,
                    "_stalker_category_type": item.get("type") or item.get("content_type") or "",
                    "_stalker_is_series": item.get("is_series") or item.get("series") or "",
                })
            if rows:
                return rows
        return []

    def _list_query_variants(self, api_type, action, category_id, page):
        """Build a short, ordered list of non-conflicting catalog requests.

        IPTV keeps the r105 request unchanged.  VOD/Series portals differ on
        whether a package is called ``category``, ``genre`` or ``category_id``;
        sending all aliases together causes valid portals to return an empty list.
        """
        # Live is kept intentionally identical to EStalker's request shape:
        # type=itv&action=get_ordered_list&genre=<id>&sortby=number&p=<page>
        # &JsHttpRequest=1-xml
        if api_type == "itv":
            query = {
                "type": "itv",
                "action": action,
                "sortby": "number",
                "p": str(page),
                "JsHttpRequest": "1-xml",
            }
            if category_id:
                query["genre"] = str(category_id)
            return [query]

        base = {
            "type": api_type, "action": action, "p": str(page), "fav": "0",
            "hd": "1", "force_ch_link_check": "0", "JsHttpRequest": "1-xml"
        }
        if api_type not in ("vod", "series"):
            query = dict(base)
            query["sortby"] = "number"
            return [query]
        if not category_id:
            query = dict(base)
            query["sortby"] = "number"
            return [query]
        variants, seen = [], set()

        def add_query(query):
            marker = tuple(sorted((str(key), str(value)) for key, value in query.items()))
            if marker not in seen:
                seen.add(marker)
                variants.append(query)

        # The ordinary MAG convention is category.  It is tried first to keep
        # normal portals just as quick as r105.
        for key in ("category", "genre", "category_id", "genre_id"):
            query = dict(base)
            query["sortby"] = "number"
            query[key] = str(category_id)
            add_query(query)
            # Some older forks reject an unknown sortby field completely.
            query = dict(base)
            query[key] = str(category_id)
            add_query(query)
        query = dict(base)
        query["sortby"] = "number"
        query["category"] = str(category_id)
        query["genre"] = str(category_id)
        add_query(query)
        return variants

    def _portal_total(self, response):
        for payload in (self._portal_js(response), self._portal_payload(response)):
            if not isinstance(payload, dict):
                continue
            for key in ("total_items", "total", "total_count", "count"):
                try:
                    value = int(payload.get(key) or 0)
                except Exception:
                    value = 0
                if value:
                    return value
        return 0

    def _paged_rows(self, api_type, action, category_id="", max_pages=None):
        # EStalker-compatible Live pagination. Ministra get_ordered_list uses
        # 14 rows per page. Keep provider positions and duplicates exactly as
        # returned instead of applying a client-side identity de-duplication.
        if api_type == "itv" and action == "get_ordered_list":
            page = 1
            total = 0
            slots = []
            downloaded = set()
            safety_pages = 500
            while page <= safety_pages:
                query = self._list_query_variants(api_type, action, category_id, page)[0]
                marker = tuple(sorted((str(k), str(v)) for k, v in query.items()))
                if marker in downloaded:
                    break
                downloaded.add(marker)
                try:
                    response = self._call_retry(**query)
                except Exception:
                    break
                page_rows = self._portal_rows(response)
                if page == 1:
                    total = self._portal_total(response)
                    if total > 0:
                        slots = [{} for _ in range(total)]
                if not page_rows:
                    break
                if slots:
                    start_index = (page - 1) * 14
                    for offset, item in enumerate(page_rows):
                        pos = start_index + offset
                        if pos < len(slots) and isinstance(item, dict):
                            slots[pos] = item
                else:
                    for item in page_rows:
                        if isinstance(item, dict):
                            slots.append(item)
                if total and page * 14 >= total:
                    break
                if not total and len(page_rows) < 14:
                    break
                page += 1
            return [item for item in slots if isinstance(item, dict) and item]

        # Existing compatibility pagination remains for VOD/Series.
        max_pages = self.PAGE_LIMIT if max_pages is None else max(1, int(max_pages))
        rows, seen = [], set()
        page = 1
        while page <= max_pages:
            page_rows, total = [], 0
            for query in self._list_query_variants(api_type, action, category_id, page):
                try:
                    response = self._call_retry(**query)
                except Exception:
                    continue
                candidate = self._portal_rows(response)
                if candidate:
                    page_rows = candidate
                    total = self._portal_total(response)
                    break
            if not page_rows:
                break
            added = 0
            for item in page_rows:
                if not isinstance(item, dict):
                    continue
                identity = str(item.get("id") or item.get("stream_id") or item.get("vod_id") or item.get("movie_id") or item.get("series_id") or item.get("cmd") or item.get("name") or item.get("title") or "")
                if identity and identity in seen:
                    continue
                if identity:
                    seen.add(identity)
                rows.append(item)
                added += 1
            if not added or (total and len(rows) >= total) or (len(page_rows) < 2 and not total):
                break
            page += 1
        return rows

    def _normalise_live(self, item):
        item = dict(item or {})
        sid = item.get("id") or item.get("stream_id") or item.get("channel_id") or item.get("ch_id")
        ch_id = item.get("ch_id") or item.get("id") or item.get("stream_id") or item.get("channel_id")
        cid = item.get("tv_genre_id") or item.get("genre_id") or item.get("category_id") or item.get("genre") or ""
        logo = item.get("logo") or item.get("stream_icon") or item.get("icon") or item.get("screenshot_uri") or ""
        return {
            "stream_id": str(sid or ""), "id": str(sid or ""), "ch_id": str(ch_id or ""),
            "name": item.get("name") or item.get("title") or "CHANNEL",
            "title": item.get("name") or item.get("title") or "CHANNEL",
            "category_id": str(cid), "genre_id": str(cid),
            "stream_icon": logo, "logo": logo,
            "description": item.get("description") or item.get("plot") or "",
            "cmd": item.get("cmd") or item.get("command") or "",
            "_stalker_live": True,
        }

    def channels(self):
        response = self._call_retry(type="itv", action="get_all_channels", JsHttpRequest="1-xml")
        rows = self._portal_rows(response)
        if not rows:
            rows = self._paged_rows("itv", "get_ordered_list", max_pages=1)
        return [self._normalise_live(item) for item in rows if isinstance(item, dict)]

    def live_categories(self):
        rows = self._categories("itv", ("get_genres", "get_categories"))
        if rows:
            return rows
        categories, seen = [], set()
        for item in self.channels():
            cid = item.get("category_id") or item.get("genre_id")
            if not cid or cid in seen:
                continue
            seen.add(cid)
            categories.append({"category_id": str(cid), "genre_id": str(cid), "category_name": "Live TV"})
        return categories

    def live_page(self, category_id="", page=1, sortby="number"):
        """Fetch one 14-item Ministra Live page for progressive rendering."""
        try: page=max(1,int(page or 1))
        except Exception: page=1
        query={"type":"itv","action":"get_ordered_list","sortby":str(sortby or "number"),
               "p":str(page),"JsHttpRequest":"1-xml"}
        wanted=str(category_id or "").strip()
        if wanted: query["genre"]=wanted
        response=self._call_retry(**query)
        rows=self._portal_rows(response)
        total=self._portal_total(response)
        items=[self._normalise_live(row) for row in rows if isinstance(row,dict)]
        more=bool(items) and ((total and page*14<total) or (not total and len(items)>=14))
        return {"items":items,"page":page,"total_items":total,"has_more":bool(more)}

    def live_streams(self, category_id="", sortby="number"):
        wanted = str(category_id or "").strip()
        # EStalker request shape: get_ordered_list&genre=<id>&sortby=<mode>&p=1
        # _paged_rows follows all 14-item pages and preserves portal ordering.
        rows = self._paged_rows("itv", "get_ordered_list", wanted)
        return [
            self._normalise_live(item) if not item.get("_stalker_live") else item
            for item in rows if isinstance(item, dict)
        ]

    def search_all_live(self, query=""):
        """EStalker Search All: get_all_channels then filter by channel name."""
        response = self._call_retry(
            type="itv", action="get_all_channels", sortby="name", JsHttpRequest="1-xml"
        )
        rows = self._portal_rows(response)
        needle = str(query or "").strip().lower()
        out = []
        for raw in rows:
            if not isinstance(raw, dict):
                continue
            item = self._normalise_live(raw)
            name = str(item.get("name") or item.get("title") or "").lower()
            if not needle or needle in name:
                out.append(item)
        return out


    def _catalog_rows(self, attempts, category_id="", max_pages=None):
        """Try documented and common fork-specific catalog actions in order."""
        for api_type, action in attempts:
            try:
                rows = self._paged_rows(api_type, action, category_id, max_pages)
            except Exception:
                rows = []
            if rows:
                return rows
        return []

    def _first_item_value(self, item, keys, default=""):
        item = item if isinstance(item, dict) else {}
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        for mapping in (item, info):
            for key in keys:
                value = mapping.get(key)
                if isinstance(value, (dict, list)) or value is None:
                    continue
                try:
                    if str(value).strip():
                        return value
                except Exception:
                    continue
        return default

    def _portal_asset(self, value):
        """Make a portal-relative poster/backdrop usable by the image queue."""
        try:
            value = (value or "").strip().replace("\\/", "/")
        except Exception:
            return ""
        if not value or value.startswith(("http://", "https://", "data:")):
            return value
        parsed = urlparse(self.portal)
        if not parsed.scheme or not parsed.netloc:
            return value
        root = "%s://%s" % (parsed.scheme, parsed.netloc)
        if value.startswith("//"):
            return parsed.scheme + ":" + value
        if value.startswith("/"):
            return root + value
        path = (parsed.path or "").rstrip("/")
        if path.endswith("/c"):
            path = path[:-2].rstrip("/")
        return root + path + "/" + value.lstrip("/")

    def _is_series_item(self, item):
        marker = self._first_item_value(item, ("is_series", "is_tv", "is_tvshow", "series", "series_type"), "")
        marker = str(marker).strip().lower()
        if marker in ("1", "true", "yes", "series", "tv", "tvshow", "tv_show"):
            return True
        kind = self._first_item_value(item, ("type", "content_type", "item_type", "media_type"), "")
        kind = str(kind).strip().lower()
        if "series" in kind or "tv" in kind or "show" in kind:
            return True
        return bool(self._first_item_value(item, ("series_id",), "") and not self._first_item_value(item, ("movie_id", "vod_id"), ""))

    def _is_series_category(self, category):
        category = category if isinstance(category, dict) else {}
        marker = str(category.get("_stalker_is_series") or category.get("_stalker_category_type") or "").lower()
        if marker in ("1", "true", "yes", "series", "tv", "tvshow", "tv_show") or "series" in marker:
            return True
        name = str(category.get("category_name") or "").lower()
        keywords = ("series", "séries", "serial", "сериал", "dizi", "مسلسل", "مسلسلات", "show", "tv")
        return any(keyword in name for keyword in keywords)

    def _valid_catalog_item(self, item):
        try:
            return bool(str((item or {}).get("stream_id") or "").strip() and str((item or {}).get("name") or "").strip())
        except Exception:
            return False

    def vod_categories(self):
        return self._categories("vod", ("get_categories", "get_genres"))

    def _normalise_vod(self, item):
        item = dict(item or {})
        sid = self._first_item_value(item, ("id", "stream_id", "vod_id", "movie_id", "film_id", "item_id"), "")
        cid = self._first_item_value(item, ("category_id", "category", "genre_id", "genre", "group_id"), "")
        cmd = self._first_item_value(item, ("cmd", "command", "stream_url", "url"), "")
        title = self._first_item_value(item, ("name", "title", "movie_name", "o_name", "original_name", "display_name"), "MOVIE")
        poster = self._portal_asset(self._first_item_value(item, ("screenshot_uri", "cover", "stream_icon", "image", "movie_image", "poster", "poster_url", "poster_path", "cover_big"), ""))
        backdrop = self._portal_asset(self._first_item_value(item, ("backdrop", "backdrop_path", "backdrop_url", "fanart", "background"), ""))
        description = self._first_item_value(item, ("description", "plot", "about", "story", "overview"), "")
        return {
            "stream_id": str(sid or ""), "vod_id": str(sid or ""),
            "name": title, "title": title,
            "category_id": str(cid or ""), "genre_id": str(cid or ""), "stream_icon": poster, "cover": poster,
            "backdrop": backdrop,
            "description": description, "plot": description,
            "rating": self._first_item_value(item, ("rating_imdb", "rating", "imdb_rating", "score"), ""), "year": self._first_item_value(item, ("year", "releasedate", "release_date", "release_year"), ""),
            "added": self._first_item_value(item, ("added",), "0"), "container_extension": self._first_item_value(item, ("container_extension", "extension", "format"), "mp4"),
            "cmd": cmd, "_stalker_vod": True, "_stalker_link_type": "vod",
        }

    def vod_streams(self, category_id="", max_pages=None):
        rows = self._catalog_rows((("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies")), category_id, max_pages)
        normal = [self._normalise_vod(item) for item in rows if isinstance(item, dict) and not self._is_series_item(item)]
        return [item for item in normal if self._valid_catalog_item(item)]

    def series_categories(self):
        rows = self._categories("series", ("get_categories", "get_genres"))
        if rows:
            return rows
        # Many MAG portals place TV Shows in the VOD catalog and mark list rows
        # with is_series=1.  Prefer clearly named packages, then retain all VOD
        # packages only when the provider uses an unknown language/name scheme.
        fallback = self.vod_categories()
        marked = [row for row in fallback if self._is_series_category(row)]
        return marked or fallback

    def _normalise_series(self, item, link_type="series"):
        item = dict(item or {})
        sid = self._first_item_value(item, ("id", "series_id", "stream_id", "vod_id", "movie_id", "item_id"), "")
        cid = self._first_item_value(item, ("category_id", "category", "genre_id", "genre", "group_id"), "")
        title = self._first_item_value(item, ("name", "title", "series_name", "o_name", "original_name", "display_name"), "TV SHOW")
        poster = self._portal_asset(self._first_item_value(item, ("screenshot_uri", "cover", "stream_icon", "image", "movie_image", "poster", "poster_url", "poster_path", "cover_big"), ""))
        backdrop = self._portal_asset(self._first_item_value(item, ("backdrop", "backdrop_path", "backdrop_url", "fanart", "background"), ""))
        description = self._first_item_value(item, ("description", "plot", "about", "story", "overview"), "")
        return {
            "stream_id": str(sid or ""), "series_id": str(sid or ""),
            "name": title, "title": title,
            "category_id": str(cid or ""), "genre_id": str(cid or ""), "stream_icon": poster, "cover": poster,
            "backdrop": backdrop,
            "description": description, "plot": description,
            "rating": self._first_item_value(item, ("rating_imdb", "rating", "imdb_rating", "score"), ""), "year": self._first_item_value(item, ("year", "releasedate", "release_date", "release_year"), ""),
            "added": self._first_item_value(item, ("added",), "0"), "cmd": self._first_item_value(item, ("cmd", "command", "stream_url", "url"), ""),
            "_stalker_series": True, "_stalker_link_type": link_type,
        }

    def series_streams(self, category_id="", max_pages=None):
        rows = self._catalog_rows((("series", "get_ordered_list"), ("series", "get_series_list"), ("series", "get_all_series")), category_id, max_pages)
        if rows:
            normal = [self._normalise_series(item, "series") for item in rows if isinstance(item, dict)]
            return [item for item in normal if self._valid_catalog_item(item)]
        if not category_id:
            return []
        rows = self._catalog_rows((("vod", "get_ordered_list"), ("vod", "get_vod_list"), ("vod", "get_movies")), category_id, max_pages)
        normal = [self._normalise_series(item, "vod") for item in rows if isinstance(item, dict) and self._is_series_item(item)]
        return [item for item in normal if self._valid_catalog_item(item)]

    def categories(self, kind):
        if kind == "live": return self.live_categories()
        if kind == "vod": return self.vod_categories()
        if kind == "series": return self.series_categories()
        return []

    def streams(self, kind, category_id=""):
        if kind == "live": return self.live_streams(category_id)
        if kind == "vod": return self.vod_streams(category_id)
        if kind == "series": return self.series_streams(category_id)
        return []

    def _normalise_episode(self, item, season="", link_type="series"):
        item = dict(item or {})
        info = item.get("info") if isinstance(item.get("info"), dict) else {}
        number = item.get("episode_num") or item.get("episode_number") or item.get("number") or info.get("episode_num") or info.get("episode_number") or ""
        season_num = item.get("season") or item.get("season_number") or info.get("season") or info.get("season_number") or season or "1"
        cmd = item.get("cmd") or item.get("command") or item.get("stream_url") or info.get("cmd") or ""
        image = item.get("movie_image") or item.get("cover") or item.get("stream_icon") or item.get("screenshot_uri") or item.get("poster") or info.get("movie_image") or info.get("cover") or ""
        image = self._portal_asset(image)
        title = item.get("title") or item.get("name") or item.get("episode_name") or info.get("title") or info.get("name") or "Episode %s" % (number or "")
        eid = item.get("id") or item.get("stream_id") or item.get("episode_id") or item.get("vod_id") or item.get("movie_id") or ""
        return {
            "id": str(eid), "stream_id": str(eid),
            "title": title, "name": title,
            "episode_num": number, "episode_number": number, "season": str(season_num), "season_number": str(season_num),
            "cmd": cmd, "movie_image": image, "cover": image, "stream_icon": image, "info": info, "_stalker_episode": True, "_stalker_link_type": link_type,
        }

    def _normalise_series_info(self, payload, fallback, link_type="series"):
        raw = payload or {}
        if isinstance(raw, list): raw = {"episodes": raw}
        if not isinstance(raw, dict): return {"info": {}, "episodes": {}, "seasons": []}
        # Some portals wrap a series record twice, e.g. js.result.data.  Unwrap
        # only structural dictionaries and stop as soon as episode/info fields
        # become visible, so real detail metadata is never discarded.
        for _unused in range(3):
            nested = None
            for key in ("data", "result", "results", "response", "payload", "content"):
                value = self._decode(raw.get(key)) if isinstance(raw, dict) else None
                if isinstance(value, dict) and ("episodes" in value or "info" in value or "seasons" in value):
                    nested = value
                    break
            if nested is None:
                break
            raw = nested
        info = raw.get("info") if isinstance(raw.get("info"), dict) else {}
        if not info:
            info = {key: raw.get(key) for key in ("name", "title", "description", "plot", "rating", "year", "cover", "backdrop") if raw.get(key) is not None}
        episodes = raw.get("episodes") or raw.get("items") or raw.get("data") or []
        if not episodes:
            inferred = {}
            for key, value in raw.items():
                if str(key).isdigit() and isinstance(value, (list, dict)):
                    inferred[key] = value
            episodes = inferred
        grouped = {}
        if isinstance(episodes, dict):
            for season, values in episodes.items():
                if isinstance(values, dict): values = values.get("episodes") or values.get("items") or values.get("data") or [values]
                if not isinstance(values, list): continue
                key = str(season or "1")
                grouped[key] = [self._normalise_episode(value, key, link_type) for value in values if isinstance(value, dict)]
        elif isinstance(episodes, list):
            for value in episodes:
                if not isinstance(value, dict): continue
                normal = self._normalise_episode(value, "", link_type)
                key = str(normal.get("season") or "1")
                grouped.setdefault(key, []).append(normal)
        seasons = [{"season_number": key, "name": "Season %s" % key} for key in sorted(grouped.keys(), key=lambda value: int(value) if str(value).isdigit() else 999)]
        return {"info": info, "episodes": grouped, "seasons": seasons}

    def series_info(self, series_id):
        sid = str(series_id or "")
        if not sid: return {"info": {}, "episodes": {}, "seasons": []}
        params = {"series_id": sid, "id": sid, "movie_id": sid, "vod_id": sid, "JsHttpRequest": "1-xml"}
        fallback = None
        routes = (
            ("series", ("get_series", "get_series_info", "get_episodes")),
            ("vod", ("get_series", "get_series_info", "get_episodes", "get_vod_info")),
        )
        for api_type, actions in routes:
            for action in actions:
                try:
                    response = self._call_retry(type=api_type, action=action, **params)
                except Exception:
                    continue
                normalized = self._normalise_series_info(self._portal_payload(response), sid, api_type)
                if normalized.get("episodes"):
                    return normalized
                if normalized.get("info") and fallback is None:
                    fallback = normalized
        return fallback or {"info": {}, "episodes": {}, "seasons": []}

    def vod_info(self, vod_id):
        params = {"vod_id": str(vod_id or ""), "id": str(vod_id or ""), "movie_id": str(vod_id or ""), "JsHttpRequest": "1-xml"}
        for action in ("get_vod_info", "get_movie_info", "get_info"):
            try:
                response = self._call_retry(type="vod", action=action, **params)
            except Exception:
                continue
            payload = self._portal_payload(response)
            if isinstance(payload, dict):
                return payload
            if isinstance(payload, list) and payload and isinstance(payload[0], dict):
                return payload[0]
        return {}

    def _extract_link(self, response):
        """Extract a playable URL while keeping the original fast Stalker flow."""
        import re
        for payload in (self._portal_js(response), self._portal_payload(response)):
            if isinstance(payload, dict):
                command = payload.get("cmd") or payload.get("url") or payload.get("stream_url") or ""
            elif isinstance(payload, str):
                command = payload
            else:
                command = ""
            command = str(command or "").replace("\\/", "/").strip()
            if not command:
                continue
            if command.lower().startswith(("http://", "https://", "rtmp://", "rtsp://", "udp://", "rtp://")):
                return command
            urls = re.findall(r"(?:https?|rtmp|rtsp|udp|rtp)://[^\s\"']+", command, re.I)
            if urls:
                return urls[-1]
            if command.lower().startswith(("ffmpeg ", "ffrt ")):
                parts = command.split()
                if len(parts) > 1:
                    return parts[-1]
            return command
        return ""

    def _direct_link_from_cmd(self, cmd):
        """Return a URL already present in a channel command, if any."""
        return self._extract_link({"js": {"cmd": cmd or ""}})

    def _create_link(self, kind, item_id, cmd=""):
        original_cmd = str(cmd or item_id or "").strip()
        direct = self._direct_link_from_cmd(original_cmd)
        lower_cmd = original_cmd.lower()
        needs_resolution = (
            not direct or "localhost" in lower_cmd or "///" in original_cmd or
            "/ch/" in lower_cmd or
            not lower_cmd.startswith(("http://", "https://", "rtmp://", "rtsp://", "udp://", "rtp://"))
        )
        if not needs_resolution and direct:
            stalker_log("CREATE_LINK direct kind=%s id=%s" % (kind, item_id))
            return direct

        query = {
            "type": kind, "action": "create_link", "cmd": original_cmd,
            "series": "0" if kind == "itv" else "",
            "forced_storage": "0" if kind == "itv" else "",
            "disable_ad": "0", "download": "0", "force_ch_link_check": "0",
            "JsHttpRequest": "1-xml",
        }
        started = time.time()
        first_error = None

        def create_once():
            if not self._ensure_token():
                raise RuntimeError("Stalker handshake was rejected by the portal")
            self._ensure_profile()
            return self._extract_link(self.call(**query) or {})

        try:
            link = create_once()
            if link:
                stalker_log("CREATE_LINK result kind=%s id=%s ms=%d" % (
                    kind, item_id, int((time.time()-started)*1000)))
                return link
            first_error = RuntimeError("portal returned an empty create_link")
        except Exception as exc:
            first_error = exc
            stalker_log("CREATE_LINK primary failed kind=%s id=%s error=%s" % (kind, item_id, exc))

        if kind == "itv" and (
            first_error is None or
            self._is_stalker_auth_error(first_error) or
            "empty create_link" in str(first_error).lower()
        ):
            try:
                if self.reauthorize():
                    link = create_once()
                    if link:
                        stalker_log("CREATE_LINK reauthorized kind=%s id=%s ms=%d" % (
                            kind, item_id, int((time.time()-started)*1000)))
                        return link
                    stalker_log("CREATE_LINK reauthorized_empty kind=%s id=%s" % (kind, item_id))
            except Exception as exc:
                stalker_log("CREATE_LINK reauthorize retry failed kind=%s id=%s error=%s" % (kind, item_id, exc))

        try:
            fallback = dict(query)
            fallback["action"] = "get_link"
            link = self._extract_link(self._call_retry(**fallback))
            if link:
                return link
        except Exception as exc:
            stalker_log("CREATE_LINK get_link failed kind=%s id=%s error=%s" % (kind, item_id, exc))
        if direct:
            return direct
        raise first_error or RuntimeError("Stalker portal returned no playable URL")

    def create_catchup_link(self, item, event):
        """Resolve Stalker/Ministra TV archive with several MAG-compatible variants."""
        item = item or {}
        event = event or {}

        # Prefer an event-specific command if the portal supplied one.
        cmd = str(
            event.get("cmd") or event.get("url") or event.get("stream_url") or
            item.get("cmd") or item.get("url") or item.get("stream_id") or item.get("id") or ""
        ).strip()

        start_ts = (
            event.get("_begin") or event.get("start_timestamp") or event.get("start") or
            event.get("begin_timestamp") or event.get("begin") or event.get("time")
        )
        stop_ts = (
            event.get("_end") or event.get("stop_timestamp") or event.get("stop") or
            event.get("end_timestamp") or event.get("end")
        )

        try:
            start_ts = int(float(start_ts))
            if start_ts > 100000000000:
                start_ts = int(start_ts / 1000)
        except Exception:
            start_ts = 0

        try:
            stop_ts = int(float(stop_ts))
            if stop_ts > 100000000000:
                stop_ts = int(stop_ts / 1000)
        except Exception:
            stop_ts = 0

        if not stop_ts or stop_ts <= start_ts:
            try:
                duration = int(float(event.get("duration") or 3600))
            except Exception:
                duration = 3600
            stop_ts = start_ts + max(60, duration)

        if not cmd or not start_ts:
            raise RuntimeError("Catch-up command or start time is missing")

        now_ts = int(time.time())
        first_error = None

        # MAG/Stalker portals vary here. Important difference:
        # many portals expect lutc=current UTC, not programme end.
        time_pairs = [
            (start_ts, now_ts, "now"),
            (start_ts, stop_ts, "end"),
        ]

        forced_values = ("undefined", "0")

        for utc_value, lutc_value, time_mode in time_pairs:
            for forced_storage in forced_values:
                query = {
                    "type": "itv",
                    "action": "create_link",
                    "cmd": cmd,
                    "series": "0",
                    "forced_storage": forced_storage,
                    "disable_ad": "0",
                    "download": "0",
                    "force_ch_link_check": "0",
                    "utc": str(utc_value),
                    "lutc": str(lutc_value),
                    "JsHttpRequest": "1-xml",
                }

                for action in ("create_link", "get_link"):
                    query["action"] = action
                    try:
                        link = self._extract_link(self._call_retry(**query))
                        if link:
                            stalker_log(
                                "CATCHUP_LINK success action=%s mode=%s forced=%s utc=%s lutc=%s" %
                                (action, time_mode, forced_storage, utc_value, lutc_value)
                            )
                            return link
                    except Exception as exc:
                        first_error = first_error or exc
                        stalker_log(
                            "CATCHUP_LINK failed action=%s mode=%s forced=%s error=%s" %
                            (action, time_mode, forced_storage, exc)
                        )

        # Some portals return a normal live URL first and expect archive
        # timestamps directly on that URL.
        try:
            live_url = self._create_link(
                "itv",
                item.get("stream_id") or item.get("id"),
                item.get("cmd") or item.get("url") or cmd
            )
            if live_url:
                sep = "&" if "?" in live_url else "?"
                direct = "%s%sutc=%s&lutc=%s" % (live_url, sep, start_ts, now_ts)
                stalker_log("CATCHUP_LINK direct_url utc=%s lutc=%s" % (start_ts, now_ts))
                return direct
        except Exception as exc:
            first_error = first_error or exc
            stalker_log("CATCHUP_LINK direct_url failed error=%s" % exc)

        raise first_error or RuntimeError("Portal returned no catch-up link")


    def create_vod_link(self, item):
        item = item or {}
        return self._create_link("vod", item.get("vod_id") or item.get("stream_id"), item.get("cmd"))

    def create_series_link(self, item):
        item = item or {}
        kind = item.get("_stalker_link_type") or "series"
        if kind not in ("series", "vod"):
            kind = "series"
        return self._create_link(kind, item.get("series_id") or item.get("stream_id") or item.get("id"), item.get("cmd"))

    def watchdog(self):
        """Keep the Ministra/Stalker session alive without restarting video."""
        try:
            response = self._call_retry(
                **{
                    "type": "watchdog",
                    "action": "get_events",
                    "init": "0",
                    "cur_play_type": "1",
                    "event_active_id": "0",
                    "JsHttpRequest": "1-xml",
                }
            )
            return bool(response)
        except Exception as exc:
            stalker_log("WATCHDOG failed error=%s" % exc)
            return False


    def stream_url(self, item, kind="live"):
        item = item or {}
        if kind == "live":
            return self._create_link("itv", item.get("stream_id") or item.get("id"), item.get("cmd"))
        if kind == "series":
            return self.create_series_link(item)
        return self.create_vod_link(item)



def get_source_client(source):
    """Return the catalogue client matching a configured source type."""
    source = source or {}
    if source.get("type") == "stalker":
        return StalkerClient(source)
    if source.get("type") in ("m3u", "fg"):
        return M3UClient(source)
    return XtreamClient(source)
