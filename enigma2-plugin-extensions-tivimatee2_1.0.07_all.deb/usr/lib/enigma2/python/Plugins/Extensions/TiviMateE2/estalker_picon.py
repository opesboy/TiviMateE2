# -*- coding: utf-8 -*-
import os
import tempfile

from PIL import Image
from twisted.web.client import downloadPage
from .cache_manager import get_cache_dir

from urllib.parse import urlparse

try:
    from twisted.internet import ssl
    from twisted.internet._sslverify import ClientTLSOptions
    _SSLVERIFY = True
except Exception:
    ssl = None
    ClientTLSOptions = None
    _SSLVERIFY = False


if _SSLVERIFY:
    class SNIFactory(ssl.ClientContextFactory):
        def __init__(self, hostname=None):
            self.hostname = hostname
        def getContext(self):
            ctx = self._contextFactory(self.method)
            if self.hostname:
                ClientTLSOptions(self.hostname, ctx)
            return ctx
else:
    SNIFactory = None


def _remove(path):
    try:
        if path and os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def direct_picon(url, size, request_id, current_request_id, apply_path, prefix='tivimate_picon_'):
    """Direct EStalker-style Picon loading without accumulating files in /tmp.

    A short-lived download scratch file is created inside TiviMateE2's selected
    cache/storage root, then converted into one stable PNG per Picon context.
    Live-side and Infobar Picons therefore overwrite their own file instead of
    leaving many tivimate_*picon*.png files behind.
    """
    try:
        url = str(url or '').strip().replace('\\/', '/')
    except Exception:
        return None
    if not url or url.lower() == 'n/a' or not url.startswith(('http://','https://')):
        return None

    try:
        base_dir = get_cache_dir("live_picons")
    except Exception:
        base_dir = "/tmp/tivimatee2/live_picons"
        try:
            if not os.path.isdir(base_dir):
                os.makedirs(base_dir)
        except Exception:
            pass

    safe_prefix = ''.join(ch for ch in str(prefix or "picon") if ch.isalnum() or ch in ('_','-')).strip('_-') or "picon"
    final_path = os.path.join(base_dir, safe_prefix + "_current.png")
    scratch = final_path + ".download"

    # One scratch path per context. New requests replace the previous scratch.
    _remove(scratch)

    parsed = urlparse(url)
    domain = parsed.hostname
    scheme = parsed.scheme
    try:
        dl_url = url.encode('utf-8')
    except Exception:
        dl_url = url

    def stale():
        try:
            return int(current_request_id()) != int(request_id)
        except Exception:
            return True

    def finish_ok(_data=None):
        if stale():
            _remove(scratch)
            return
        image = None
        bg = None
        try:
            image = Image.open(scratch)
            if image.mode != 'RGBA':
                image = image.convert('RGBA')
            if not image.size[0] or not image.size[1]:
                raise ValueError('zero image size')

            width, height = int(size[0]), int(size[1])
            ratio = min(width / float(image.size[0]), height / float(image.size[1]))
            new_size = (max(1, int(image.size[0] * ratio)), max(1, int(image.size[1] * ratio)))
            try:
                image = image.resize(new_size, Image.Resampling.LANCZOS)
            except Exception:
                try:
                    image = image.resize(new_size, Image.LANCZOS)
                except Exception:
                    image = image.resize(new_size, Image.ANTIALIAS)

            bg = Image.new('RGBA', (width, height), (255,255,255,0))
            left = (width - image.size[0]) // 2
            top = (height - image.size[1]) // 2
            bg.paste(image, (left, top), mask=image)

            temp_final = final_path + ".new"
            _remove(temp_final)
            bg.save(temp_final, 'PNG')
            try:
                os.replace(temp_final, final_path)
            except AttributeError:
                _remove(final_path)
                os.rename(temp_final, final_path)

            if not stale():
                apply_path(final_path)
        except Exception:
            pass
        finally:
            try:
                if image is not None:
                    image.close()
            except Exception:
                pass
            try:
                if bg is not None:
                    bg.close()
            except Exception:
                pass
            _remove(scratch)

    def finish_err(_failure=None):
        _remove(scratch)

    try:
        if scheme == 'https' and _SSLVERIFY and SNIFactory is not None:
            factory = SNIFactory(domain)
            d = downloadPage(dl_url, scratch, factory, timeout=2)
        else:
            d = downloadPage(dl_url, scratch, timeout=2)
        d.addCallback(finish_ok)
        d.addErrback(finish_err)
        return d
    except Exception:
        _remove(scratch)
        return None

